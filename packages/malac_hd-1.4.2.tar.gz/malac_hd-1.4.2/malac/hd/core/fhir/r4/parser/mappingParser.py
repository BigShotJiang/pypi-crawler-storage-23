# Generated from mapping.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,102,560,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,2,60,7,60,2,61,7,61,1,0,1,0,5,0,127,8,0,10,0,12,0,130,9,
        0,1,0,5,0,133,8,0,10,0,12,0,136,9,0,1,0,5,0,139,8,0,10,0,12,0,142,
        9,0,1,0,4,0,145,8,0,11,0,12,0,146,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,
        2,1,2,1,3,1,3,1,4,1,4,1,5,1,5,1,5,3,5,165,8,5,1,5,1,5,1,5,1,6,1,
        6,1,6,1,7,1,7,1,7,1,8,1,8,1,8,1,8,3,8,180,8,8,1,8,3,8,183,8,8,1,
        8,1,8,1,9,1,9,5,9,189,8,9,10,9,12,9,192,9,9,1,9,1,9,1,10,1,10,1,
        10,1,10,1,11,1,11,1,11,1,12,1,12,1,12,1,12,4,12,207,8,12,11,12,12,
        12,208,1,12,1,12,1,13,1,13,1,13,3,13,216,8,13,1,14,1,14,1,14,1,15,
        1,15,1,15,3,15,224,8,15,1,15,3,15,227,8,15,1,15,3,15,230,8,15,1,
        15,1,15,1,16,1,16,1,17,1,17,1,17,5,17,239,8,17,10,17,12,17,242,9,
        17,1,18,1,18,3,18,246,8,18,1,18,3,18,249,8,18,1,18,3,18,252,8,18,
        1,18,3,18,255,8,18,1,18,3,18,258,8,18,1,18,3,18,261,8,18,1,18,3,
        18,264,8,18,1,18,3,18,267,8,18,1,19,1,19,1,19,5,19,272,8,19,10,19,
        12,19,275,9,19,1,20,1,20,1,20,1,21,1,21,1,21,1,21,1,22,1,22,1,23,
        1,23,1,23,5,23,289,8,23,10,23,12,23,292,9,23,1,24,1,24,1,24,1,25,
        1,25,1,25,1,26,1,26,1,26,1,27,1,27,1,27,1,28,1,28,1,28,1,29,1,29,
        1,29,1,29,5,29,313,8,29,10,29,12,29,316,9,29,1,29,3,29,319,8,29,
        1,29,3,29,322,8,29,1,30,1,30,1,30,3,30,327,8,30,1,30,3,30,330,8,
        30,1,30,3,30,333,8,30,1,30,1,30,3,30,337,8,30,1,30,1,30,3,30,341,
        8,30,3,30,343,8,30,1,31,1,31,1,31,1,31,3,31,349,8,31,1,32,1,32,1,
        32,1,32,1,33,1,33,1,33,3,33,358,8,33,1,33,1,33,1,34,1,34,1,34,5,
        34,365,8,34,10,34,12,34,368,9,34,1,35,1,35,3,35,372,8,35,1,36,1,
        36,3,36,376,8,36,1,37,1,37,1,38,1,38,1,39,1,39,1,40,1,40,1,41,1,
        41,1,42,1,42,1,43,1,43,1,43,1,43,4,43,394,8,43,11,43,12,43,395,1,
        43,4,43,399,8,43,11,43,12,43,400,1,43,1,43,1,44,1,44,1,44,1,44,1,
        44,1,45,1,45,1,46,1,46,1,46,1,46,1,46,1,46,1,46,1,46,1,46,1,46,1,
        46,1,46,3,46,424,8,46,1,46,1,46,1,46,1,46,1,46,3,46,431,8,46,1,47,
        1,47,1,48,1,48,1,48,1,48,3,48,439,8,48,1,48,1,48,1,48,1,48,1,48,
        1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,
        1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,1,48,
        1,48,1,48,1,48,1,48,1,48,1,48,1,48,5,48,479,8,48,10,48,12,48,482,
        9,48,1,49,1,49,1,49,1,49,1,49,1,49,1,49,3,49,491,8,49,1,50,1,50,
        1,50,1,50,1,50,1,50,1,50,1,50,1,50,1,50,3,50,503,8,50,1,51,1,51,
        1,51,3,51,508,8,51,1,52,1,52,1,52,1,52,1,52,3,52,515,8,52,1,53,1,
        53,3,53,519,8,53,1,53,1,53,3,53,523,8,53,1,53,1,53,1,54,1,54,1,54,
        5,54,530,8,54,10,54,12,54,533,9,54,1,55,1,55,3,55,537,8,55,1,56,
        1,56,1,56,3,56,542,8,56,1,57,1,57,1,58,1,58,1,59,1,59,1,60,1,60,
        1,60,5,60,553,8,60,10,60,12,60,556,9,60,1,61,1,61,1,61,0,1,96,62,
        0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,
        46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,
        90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,120,122,0,
        24,1,0,95,96,1,0,94,96,3,0,3,3,94,94,96,96,2,0,21,21,98,98,2,0,90,
        93,97,99,1,0,28,29,1,0,30,34,3,0,30,30,32,32,35,36,1,0,37,38,1,0,
        37,40,1,0,41,42,1,0,94,95,2,0,44,44,55,55,3,0,3,3,21,21,56,57,3,
        0,44,44,55,55,58,58,3,0,45,45,48,48,61,62,4,0,2,2,47,47,51,51,63,
        63,1,0,64,65,1,0,67,68,2,0,5,5,59,59,1,0,98,99,1,0,74,81,1,0,82,
        89,5,0,5,5,59,59,64,65,94,94,96,96,583,0,124,1,0,0,0,2,150,1,0,0,
        0,4,155,1,0,0,0,6,157,1,0,0,0,8,159,1,0,0,0,10,161,1,0,0,0,12,169,
        1,0,0,0,14,172,1,0,0,0,16,175,1,0,0,0,18,186,1,0,0,0,20,195,1,0,
        0,0,22,199,1,0,0,0,24,202,1,0,0,0,26,212,1,0,0,0,28,217,1,0,0,0,
        30,220,1,0,0,0,32,233,1,0,0,0,34,235,1,0,0,0,36,243,1,0,0,0,38,268,
        1,0,0,0,40,276,1,0,0,0,42,279,1,0,0,0,44,283,1,0,0,0,46,285,1,0,
        0,0,48,293,1,0,0,0,50,296,1,0,0,0,52,299,1,0,0,0,54,302,1,0,0,0,
        56,305,1,0,0,0,58,308,1,0,0,0,60,342,1,0,0,0,62,348,1,0,0,0,64,350,
        1,0,0,0,66,354,1,0,0,0,68,361,1,0,0,0,70,371,1,0,0,0,72,375,1,0,
        0,0,74,377,1,0,0,0,76,379,1,0,0,0,78,381,1,0,0,0,80,383,1,0,0,0,
        82,385,1,0,0,0,84,387,1,0,0,0,86,389,1,0,0,0,88,404,1,0,0,0,90,409,
        1,0,0,0,92,430,1,0,0,0,94,432,1,0,0,0,96,438,1,0,0,0,98,490,1,0,
        0,0,100,502,1,0,0,0,102,504,1,0,0,0,104,514,1,0,0,0,106,518,1,0,
        0,0,108,526,1,0,0,0,110,534,1,0,0,0,112,541,1,0,0,0,114,543,1,0,
        0,0,116,545,1,0,0,0,118,547,1,0,0,0,120,549,1,0,0,0,122,557,1,0,
        0,0,124,128,3,2,1,0,125,127,3,86,43,0,126,125,1,0,0,0,127,130,1,
        0,0,0,128,126,1,0,0,0,128,129,1,0,0,0,129,134,1,0,0,0,130,128,1,
        0,0,0,131,133,3,10,5,0,132,131,1,0,0,0,133,136,1,0,0,0,134,132,1,
        0,0,0,134,135,1,0,0,0,135,140,1,0,0,0,136,134,1,0,0,0,137,139,3,
        14,7,0,138,137,1,0,0,0,139,142,1,0,0,0,140,138,1,0,0,0,140,141,1,
        0,0,0,141,144,1,0,0,0,142,140,1,0,0,0,143,145,3,16,8,0,144,143,1,
        0,0,0,145,146,1,0,0,0,146,144,1,0,0,0,146,147,1,0,0,0,147,148,1,
        0,0,0,148,149,5,0,0,1,149,1,1,0,0,0,150,151,5,1,0,0,151,152,3,4,
        2,0,152,153,5,2,0,0,153,154,3,6,3,0,154,3,1,0,0,0,155,156,7,0,0,
        0,156,5,1,0,0,0,157,158,7,1,0,0,158,7,1,0,0,0,159,160,7,2,0,0,160,
        9,1,0,0,0,161,162,5,4,0,0,162,164,3,4,2,0,163,165,3,12,6,0,164,163,
        1,0,0,0,164,165,1,0,0,0,165,166,1,0,0,0,166,167,5,5,0,0,167,168,
        3,84,42,0,168,11,1,0,0,0,169,170,5,6,0,0,170,171,3,8,4,0,171,13,
        1,0,0,0,172,173,5,7,0,0,173,174,3,4,2,0,174,15,1,0,0,0,175,176,5,
        8,0,0,176,177,5,94,0,0,177,179,3,24,12,0,178,180,3,22,11,0,179,178,
        1,0,0,0,179,180,1,0,0,0,180,182,1,0,0,0,181,183,3,20,10,0,182,181,
        1,0,0,0,182,183,1,0,0,0,183,184,1,0,0,0,184,185,3,18,9,0,185,17,
        1,0,0,0,186,190,5,9,0,0,187,189,3,30,15,0,188,187,1,0,0,0,189,192,
        1,0,0,0,190,188,1,0,0,0,190,191,1,0,0,0,191,193,1,0,0,0,192,190,
        1,0,0,0,193,194,5,10,0,0,194,19,1,0,0,0,195,196,5,11,0,0,196,197,
        3,76,38,0,197,198,5,12,0,0,198,21,1,0,0,0,199,200,5,13,0,0,200,201,
        5,94,0,0,201,23,1,0,0,0,202,203,5,14,0,0,203,206,3,26,13,0,204,205,
        5,15,0,0,205,207,3,26,13,0,206,204,1,0,0,0,207,208,1,0,0,0,208,206,
        1,0,0,0,208,209,1,0,0,0,209,210,1,0,0,0,210,211,5,16,0,0,211,25,
        1,0,0,0,212,213,3,82,41,0,213,215,5,94,0,0,214,216,3,28,14,0,215,
        214,1,0,0,0,215,216,1,0,0,0,216,27,1,0,0,0,217,218,5,17,0,0,218,
        219,3,8,4,0,219,29,1,0,0,0,220,223,3,34,17,0,221,222,5,18,0,0,222,
        224,3,38,19,0,223,221,1,0,0,0,223,224,1,0,0,0,224,226,1,0,0,0,225,
        227,3,58,29,0,226,225,1,0,0,0,226,227,1,0,0,0,227,229,1,0,0,0,228,
        230,3,32,16,0,229,228,1,0,0,0,229,230,1,0,0,0,230,231,1,0,0,0,231,
        232,5,19,0,0,232,31,1,0,0,0,233,234,5,95,0,0,234,33,1,0,0,0,235,
        240,3,36,18,0,236,237,5,15,0,0,237,239,3,36,18,0,238,236,1,0,0,0,
        239,242,1,0,0,0,240,238,1,0,0,0,240,241,1,0,0,0,241,35,1,0,0,0,242,
        240,1,0,0,0,243,245,3,46,23,0,244,246,3,40,20,0,245,244,1,0,0,0,
        245,246,1,0,0,0,246,248,1,0,0,0,247,249,3,42,21,0,248,247,1,0,0,
        0,248,249,1,0,0,0,249,251,1,0,0,0,250,252,3,48,24,0,251,250,1,0,
        0,0,251,252,1,0,0,0,252,254,1,0,0,0,253,255,3,78,39,0,254,253,1,
        0,0,0,254,255,1,0,0,0,255,257,1,0,0,0,256,258,3,50,25,0,257,256,
        1,0,0,0,257,258,1,0,0,0,258,260,1,0,0,0,259,261,3,52,26,0,260,259,
        1,0,0,0,260,261,1,0,0,0,261,263,1,0,0,0,262,264,3,54,27,0,263,262,
        1,0,0,0,263,264,1,0,0,0,264,266,1,0,0,0,265,267,3,56,28,0,266,265,
        1,0,0,0,266,267,1,0,0,0,267,37,1,0,0,0,268,273,3,60,30,0,269,270,
        5,15,0,0,270,272,3,60,30,0,271,269,1,0,0,0,272,275,1,0,0,0,273,271,
        1,0,0,0,273,274,1,0,0,0,274,39,1,0,0,0,275,273,1,0,0,0,276,277,5,
        17,0,0,277,278,3,8,4,0,278,41,1,0,0,0,279,280,5,98,0,0,280,281,5,
        20,0,0,281,282,3,44,22,0,282,43,1,0,0,0,283,284,7,3,0,0,284,45,1,
        0,0,0,285,290,3,8,4,0,286,287,5,22,0,0,287,289,3,8,4,0,288,286,1,
        0,0,0,289,292,1,0,0,0,290,288,1,0,0,0,290,291,1,0,0,0,291,47,1,0,
        0,0,292,290,1,0,0,0,293,294,5,23,0,0,294,295,3,72,36,0,295,49,1,
        0,0,0,296,297,5,5,0,0,297,298,3,8,4,0,298,51,1,0,0,0,299,300,5,24,
        0,0,300,301,3,72,36,0,301,53,1,0,0,0,302,303,5,25,0,0,303,304,3,
        72,36,0,304,55,1,0,0,0,305,306,5,26,0,0,306,307,3,72,36,0,307,57,
        1,0,0,0,308,321,5,27,0,0,309,314,3,66,33,0,310,311,5,15,0,0,311,
        313,3,66,33,0,312,310,1,0,0,0,313,316,1,0,0,0,314,312,1,0,0,0,314,
        315,1,0,0,0,315,318,1,0,0,0,316,314,1,0,0,0,317,319,3,18,9,0,318,
        317,1,0,0,0,318,319,1,0,0,0,319,322,1,0,0,0,320,322,3,18,9,0,321,
        309,1,0,0,0,321,320,1,0,0,0,322,59,1,0,0,0,323,326,3,46,23,0,324,
        325,5,2,0,0,325,327,3,62,31,0,326,324,1,0,0,0,326,327,1,0,0,0,327,
        329,1,0,0,0,328,330,3,50,25,0,329,328,1,0,0,0,329,330,1,0,0,0,330,
        332,1,0,0,0,331,333,3,80,40,0,332,331,1,0,0,0,332,333,1,0,0,0,333,
        343,1,0,0,0,334,336,3,66,33,0,335,337,3,50,25,0,336,335,1,0,0,0,
        336,337,1,0,0,0,337,343,1,0,0,0,338,340,3,64,32,0,339,341,3,50,25,
        0,340,339,1,0,0,0,340,341,1,0,0,0,341,343,1,0,0,0,342,323,1,0,0,
        0,342,334,1,0,0,0,342,338,1,0,0,0,343,61,1,0,0,0,344,349,3,74,37,
        0,345,349,3,46,23,0,346,349,3,66,33,0,347,349,3,64,32,0,348,344,
        1,0,0,0,348,345,1,0,0,0,348,346,1,0,0,0,348,347,1,0,0,0,349,63,1,
        0,0,0,350,351,5,14,0,0,351,352,3,72,36,0,352,353,5,16,0,0,353,65,
        1,0,0,0,354,355,3,8,4,0,355,357,5,14,0,0,356,358,3,68,34,0,357,356,
        1,0,0,0,357,358,1,0,0,0,358,359,1,0,0,0,359,360,5,16,0,0,360,67,
        1,0,0,0,361,366,3,70,35,0,362,363,5,15,0,0,363,365,3,70,35,0,364,
        362,1,0,0,0,365,368,1,0,0,0,366,364,1,0,0,0,366,367,1,0,0,0,367,
        69,1,0,0,0,368,366,1,0,0,0,369,372,3,74,37,0,370,372,5,94,0,0,371,
        369,1,0,0,0,371,370,1,0,0,0,372,71,1,0,0,0,373,376,3,74,37,0,374,
        376,3,96,48,0,375,373,1,0,0,0,375,374,1,0,0,0,376,73,1,0,0,0,377,
        378,7,4,0,0,378,75,1,0,0,0,379,380,7,5,0,0,380,77,1,0,0,0,381,382,
        7,6,0,0,382,79,1,0,0,0,383,384,7,7,0,0,384,81,1,0,0,0,385,386,7,
        8,0,0,386,83,1,0,0,0,387,388,7,9,0,0,388,85,1,0,0,0,389,390,7,10,
        0,0,390,391,3,6,3,0,391,393,5,9,0,0,392,394,3,88,44,0,393,392,1,
        0,0,0,394,395,1,0,0,0,395,393,1,0,0,0,395,396,1,0,0,0,396,398,1,
        0,0,0,397,399,3,92,46,0,398,397,1,0,0,0,399,400,1,0,0,0,400,398,
        1,0,0,0,400,401,1,0,0,0,401,402,1,0,0,0,402,403,5,10,0,0,403,87,
        1,0,0,0,404,405,5,43,0,0,405,406,3,90,45,0,406,407,5,2,0,0,407,408,
        3,4,2,0,408,89,1,0,0,0,409,410,5,94,0,0,410,91,1,0,0,0,411,412,3,
        90,45,0,412,413,5,17,0,0,413,423,3,94,47,0,414,424,5,44,0,0,415,
        424,5,45,0,0,416,424,5,2,0,0,417,424,5,46,0,0,418,419,5,47,0,0,419,
        420,5,48,0,0,420,424,5,49,0,0,421,424,5,50,0,0,422,424,5,51,0,0,
        423,414,1,0,0,0,423,415,1,0,0,0,423,416,1,0,0,0,423,417,1,0,0,0,
        423,418,1,0,0,0,423,421,1,0,0,0,423,422,1,0,0,0,424,425,1,0,0,0,
        425,426,3,90,45,0,426,427,5,17,0,0,427,428,3,94,47,0,428,431,1,0,
        0,0,429,431,5,52,0,0,430,411,1,0,0,0,430,429,1,0,0,0,431,93,1,0,
        0,0,432,433,7,11,0,0,433,95,1,0,0,0,434,435,6,48,-1,0,435,439,3,
        98,49,0,436,437,7,12,0,0,437,439,3,96,48,11,438,434,1,0,0,0,438,
        436,1,0,0,0,439,480,1,0,0,0,440,441,10,10,0,0,441,442,7,13,0,0,442,
        479,3,96,48,11,443,444,10,9,0,0,444,445,7,14,0,0,445,479,3,96,48,
        10,446,447,10,7,0,0,447,448,5,60,0,0,448,479,3,96,48,8,449,450,10,
        6,0,0,450,451,7,15,0,0,451,479,3,96,48,7,452,453,10,5,0,0,453,454,
        7,16,0,0,454,479,3,96,48,6,455,456,10,4,0,0,456,457,7,17,0,0,457,
        479,3,96,48,5,458,459,10,3,0,0,459,460,5,66,0,0,460,479,3,96,48,
        4,461,462,10,2,0,0,462,463,7,18,0,0,463,479,3,96,48,3,464,465,10,
        1,0,0,465,466,5,69,0,0,466,479,3,96,48,2,467,468,10,13,0,0,468,469,
        5,22,0,0,469,479,3,104,52,0,470,471,10,12,0,0,471,472,5,53,0,0,472,
        473,3,96,48,0,473,474,5,54,0,0,474,479,1,0,0,0,475,476,10,8,0,0,
        476,477,7,19,0,0,477,479,3,118,59,0,478,440,1,0,0,0,478,443,1,0,
        0,0,478,446,1,0,0,0,478,449,1,0,0,0,478,452,1,0,0,0,478,455,1,0,
        0,0,478,458,1,0,0,0,478,461,1,0,0,0,478,464,1,0,0,0,478,467,1,0,
        0,0,478,470,1,0,0,0,478,475,1,0,0,0,479,482,1,0,0,0,480,478,1,0,
        0,0,480,481,1,0,0,0,481,97,1,0,0,0,482,480,1,0,0,0,483,491,3,104,
        52,0,484,491,3,100,50,0,485,491,3,102,51,0,486,487,5,14,0,0,487,
        488,3,96,48,0,488,489,5,16,0,0,489,491,1,0,0,0,490,483,1,0,0,0,490,
        484,1,0,0,0,490,485,1,0,0,0,490,486,1,0,0,0,491,99,1,0,0,0,492,493,
        5,9,0,0,493,503,5,10,0,0,494,503,5,90,0,0,495,503,5,97,0,0,496,503,
        5,99,0,0,497,503,5,98,0,0,498,503,5,91,0,0,499,503,5,92,0,0,500,
        503,5,93,0,0,501,503,3,110,55,0,502,492,1,0,0,0,502,494,1,0,0,0,
        502,495,1,0,0,0,502,496,1,0,0,0,502,497,1,0,0,0,502,498,1,0,0,0,
        502,499,1,0,0,0,502,500,1,0,0,0,502,501,1,0,0,0,503,101,1,0,0,0,
        504,507,5,70,0,0,505,508,3,122,61,0,506,508,5,97,0,0,507,505,1,0,
        0,0,507,506,1,0,0,0,508,103,1,0,0,0,509,515,3,122,61,0,510,515,3,
        106,53,0,511,515,5,71,0,0,512,515,5,72,0,0,513,515,5,73,0,0,514,
        509,1,0,0,0,514,510,1,0,0,0,514,511,1,0,0,0,514,512,1,0,0,0,514,
        513,1,0,0,0,515,105,1,0,0,0,516,519,3,122,61,0,517,519,5,24,0,0,
        518,516,1,0,0,0,518,517,1,0,0,0,519,520,1,0,0,0,520,522,5,14,0,0,
        521,523,3,108,54,0,522,521,1,0,0,0,522,523,1,0,0,0,523,524,1,0,0,
        0,524,525,5,16,0,0,525,107,1,0,0,0,526,531,3,96,48,0,527,528,5,15,
        0,0,528,530,3,96,48,0,529,527,1,0,0,0,530,533,1,0,0,0,531,529,1,
        0,0,0,531,532,1,0,0,0,532,109,1,0,0,0,533,531,1,0,0,0,534,536,7,
        20,0,0,535,537,3,112,56,0,536,535,1,0,0,0,536,537,1,0,0,0,537,111,
        1,0,0,0,538,542,3,114,57,0,539,542,3,116,58,0,540,542,5,97,0,0,541,
        538,1,0,0,0,541,539,1,0,0,0,541,540,1,0,0,0,542,113,1,0,0,0,543,
        544,7,21,0,0,544,115,1,0,0,0,545,546,7,22,0,0,546,117,1,0,0,0,547,
        548,3,120,60,0,548,119,1,0,0,0,549,554,3,122,61,0,550,551,5,22,0,
        0,551,553,3,122,61,0,552,550,1,0,0,0,553,556,1,0,0,0,554,552,1,0,
        0,0,554,555,1,0,0,0,555,121,1,0,0,0,556,554,1,0,0,0,557,558,7,23,
        0,0,558,123,1,0,0,0,55,128,134,140,146,164,179,182,190,208,215,223,
        226,229,240,245,248,251,254,257,260,263,266,273,290,314,318,321,
        326,329,332,336,340,342,348,357,366,371,375,395,400,423,430,438,
        478,480,490,502,507,514,518,522,531,536,541,554
    ]

class mappingParser ( Parser ):

    grammarFileName = "mapping.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'map'", "'='", "'div'", "'uses'", "'as'", 
                     "'alias'", "'imports'", "'group'", "'{'", "'}'", "'<<'", 
                     "'>>'", "'extends'", "'('", "','", "')'", "':'", "'->'", 
                     "';'", "'..'", "'*'", "'.'", "'default'", "'where'", 
                     "'check'", "'log'", "'then'", "'types'", "'type+'", 
                     "'first'", "'not_first'", "'last'", "'not_last'", "'only_one'", 
                     "'share'", "'single'", "'source'", "'target'", "'queried'", 
                     "'produced'", "'conceptMap'", "'conceptmap'", "'prefix'", 
                     "'-'", "'<='", "'=='", "'!='", "'>='", "'>-'", "'<-'", 
                     "'~'", "'--'", "'['", "']'", "'+'", "'/'", "'mod'", 
                     "'&'", "'is'", "'|'", "'<'", "'>'", "'!~'", "'in'", 
                     "'contains'", "'and'", "'or'", "'xor'", "'implies'", 
                     "'%'", "'$this'", "'$index'", "'$total'", "'year'", 
                     "'month'", "'week'", "'day'", "'hour'", "'minute'", 
                     "'second'", "'millisecond'", "'years'", "'months'", 
                     "'weeks'", "'days'", "'hours'", "'minutes'", "'seconds'", 
                     "'milliseconds'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "BOOL", "DATE", "DATETIME", 
                      "TIME", "IDENTIFIER", "QUOTEIDENTIFIER", "DELIMITEDIDENTIFIER", 
                      "STRING", "INTEGER", "NUMBER", "WS", "COMMENT", "LINE_COMMENT" ]

    RULE_structureMap = 0
    RULE_mapId = 1
    RULE_url = 2
    RULE_quoteidentifier = 3
    RULE_mapidentifier = 4
    RULE_structure = 5
    RULE_structureAlias = 6
    RULE_imports = 7
    RULE_group = 8
    RULE_rules = 9
    RULE_typeMode = 10
    RULE_extends = 11
    RULE_parameters = 12
    RULE_parameter = 13
    RULE_type = 14
    RULE_rule = 15
    RULE_ruleName = 16
    RULE_ruleSources = 17
    RULE_ruleSource = 18
    RULE_ruleTargets = 19
    RULE_sourceType = 20
    RULE_sourceCardinality = 21
    RULE_upperBound = 22
    RULE_ruleContext = 23
    RULE_sourceDefault = 24
    RULE_alias = 25
    RULE_whereClause = 26
    RULE_checkClause = 27
    RULE_log = 28
    RULE_dependent = 29
    RULE_ruleTarget = 30
    RULE_transform = 31
    RULE_evaluate = 32
    RULE_mapinvocation = 33
    RULE_mapparamList = 34
    RULE_param = 35
    RULE_fhirPath = 36
    RULE_mapliteral = 37
    RULE_groupTypeMode = 38
    RULE_sourceListMode = 39
    RULE_targetListMode = 40
    RULE_inputMode = 41
    RULE_modelMode = 42
    RULE_conceptMap = 43
    RULE_prefix = 44
    RULE_conceptMappingVar = 45
    RULE_conceptMapping = 46
    RULE_field = 47
    RULE_expression = 48
    RULE_term = 49
    RULE_literal = 50
    RULE_externalConstant = 51
    RULE_invocation = 52
    RULE_function = 53
    RULE_paramList = 54
    RULE_quantity = 55
    RULE_unit = 56
    RULE_dateTimePrecision = 57
    RULE_pluralDateTimePrecision = 58
    RULE_typeSpecifier = 59
    RULE_qualifiedIdentifier = 60
    RULE_identifier = 61

    ruleNames =  [ "structureMap", "mapId", "url", "quoteidentifier", "mapidentifier", 
                   "structure", "structureAlias", "imports", "group", "rules", 
                   "typeMode", "extends", "parameters", "parameter", "type", 
                   "rule", "ruleName", "ruleSources", "ruleSource", "ruleTargets", 
                   "sourceType", "sourceCardinality", "upperBound", "ruleContext", 
                   "sourceDefault", "alias", "whereClause", "checkClause", 
                   "log", "dependent", "ruleTarget", "transform", "evaluate", 
                   "mapinvocation", "mapparamList", "param", "fhirPath", 
                   "mapliteral", "groupTypeMode", "sourceListMode", "targetListMode", 
                   "inputMode", "modelMode", "conceptMap", "prefix", "conceptMappingVar", 
                   "conceptMapping", "field", "expression", "term", "literal", 
                   "externalConstant", "invocation", "function", "paramList", 
                   "quantity", "unit", "dateTimePrecision", "pluralDateTimePrecision", 
                   "typeSpecifier", "qualifiedIdentifier", "identifier" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    T__43=44
    T__44=45
    T__45=46
    T__46=47
    T__47=48
    T__48=49
    T__49=50
    T__50=51
    T__51=52
    T__52=53
    T__53=54
    T__54=55
    T__55=56
    T__56=57
    T__57=58
    T__58=59
    T__59=60
    T__60=61
    T__61=62
    T__62=63
    T__63=64
    T__64=65
    T__65=66
    T__66=67
    T__67=68
    T__68=69
    T__69=70
    T__70=71
    T__71=72
    T__72=73
    T__73=74
    T__74=75
    T__75=76
    T__76=77
    T__77=78
    T__78=79
    T__79=80
    T__80=81
    T__81=82
    T__82=83
    T__83=84
    T__84=85
    T__85=86
    T__86=87
    T__87=88
    T__88=89
    BOOL=90
    DATE=91
    DATETIME=92
    TIME=93
    IDENTIFIER=94
    QUOTEIDENTIFIER=95
    DELIMITEDIDENTIFIER=96
    STRING=97
    INTEGER=98
    NUMBER=99
    WS=100
    COMMENT=101
    LINE_COMMENT=102

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StructureMapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapId(self):
            return self.getTypedRuleContext(mappingParser.MapIdContext,0)


        def EOF(self):
            return self.getToken(mappingParser.EOF, 0)

        def conceptMap(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMapContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMapContext,i)


        def structure(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.StructureContext)
            else:
                return self.getTypedRuleContext(mappingParser.StructureContext,i)


        def imports(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ImportsContext)
            else:
                return self.getTypedRuleContext(mappingParser.ImportsContext,i)


        def group(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.GroupContext)
            else:
                return self.getTypedRuleContext(mappingParser.GroupContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_structureMap

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructureMap" ):
                listener.enterStructureMap(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructureMap" ):
                listener.exitStructureMap(self)




    def structureMap(self):

        localctx = mappingParser.StructureMapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_structureMap)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.mapId()
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==41 or _la==42:
                self.state = 125
                self.conceptMap()
                self.state = 130
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 134
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==4:
                self.state = 131
                self.structure()
                self.state = 136
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 140
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==7:
                self.state = 137
                self.imports()
                self.state = 142
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 144 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 143
                self.group()
                self.state = 146 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==8):
                    break

            self.state = 148
            self.match(mappingParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapIdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def quoteidentifier(self):
            return self.getTypedRuleContext(mappingParser.QuoteidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_mapId

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapId" ):
                listener.enterMapId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapId" ):
                listener.exitMapId(self)




    def mapId(self):

        localctx = mappingParser.MapIdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_mapId)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(mappingParser.T__0)
            self.state = 151
            self.url()
            self.state = 152
            self.match(mappingParser.T__1)
            self.state = 153
            self.quoteidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UrlContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_url

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUrl" ):
                listener.enterUrl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUrl" ):
                listener.exitUrl(self)




    def url(self):

        localctx = mappingParser.UrlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_url)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            _la = self._input.LA(1)
            if not(_la==95 or _la==96):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QuoteidentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_quoteidentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuoteidentifier" ):
                listener.enterQuoteidentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuoteidentifier" ):
                listener.exitQuoteidentifier(self)




    def quoteidentifier(self):

        localctx = mappingParser.QuoteidentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_quoteidentifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 157
            _la = self._input.LA(1)
            if not(((((_la - 94)) & ~0x3f) == 0 and ((1 << (_la - 94)) & 7) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapidentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_mapidentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapidentifier" ):
                listener.enterMapidentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapidentifier" ):
                listener.exitMapidentifier(self)




    def mapidentifier(self):

        localctx = mappingParser.MapidentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_mapidentifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159
            _la = self._input.LA(1)
            if not(_la==3 or _la==94 or _la==96):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def modelMode(self):
            return self.getTypedRuleContext(mappingParser.ModelModeContext,0)


        def structureAlias(self):
            return self.getTypedRuleContext(mappingParser.StructureAliasContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_structure

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructure" ):
                listener.enterStructure(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructure" ):
                listener.exitStructure(self)




    def structure(self):

        localctx = mappingParser.StructureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_structure)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self.match(mappingParser.T__3)
            self.state = 162
            self.url()
            self.state = 164
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 163
                self.structureAlias()


            self.state = 166
            self.match(mappingParser.T__4)
            self.state = 167
            self.modelMode()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructureAliasContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_structureAlias

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStructureAlias" ):
                listener.enterStructureAlias(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStructureAlias" ):
                listener.exitStructureAlias(self)




    def structureAlias(self):

        localctx = mappingParser.StructureAliasContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_structureAlias)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(mappingParser.T__5)
            self.state = 170
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_imports

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImports" ):
                listener.enterImports(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImports" ):
                listener.exitImports(self)




    def imports(self):

        localctx = mappingParser.ImportsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_imports)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.match(mappingParser.T__6)
            self.state = 173
            self.url()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def parameters(self):
            return self.getTypedRuleContext(mappingParser.ParametersContext,0)


        def rules(self):
            return self.getTypedRuleContext(mappingParser.RulesContext,0)


        def extends(self):
            return self.getTypedRuleContext(mappingParser.ExtendsContext,0)


        def typeMode(self):
            return self.getTypedRuleContext(mappingParser.TypeModeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_group

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroup" ):
                listener.enterGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroup" ):
                listener.exitGroup(self)




    def group(self):

        localctx = mappingParser.GroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_group)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 175
            self.match(mappingParser.T__7)
            self.state = 176
            self.match(mappingParser.IDENTIFIER)
            self.state = 177
            self.parameters()
            self.state = 179
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 178
                self.extends()


            self.state = 182
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==11:
                self.state = 181
                self.typeMode()


            self.state = 184
            self.rules()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rule_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRules" ):
                listener.enterRules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRules" ):
                listener.exitRules(self)




    def rules(self):

        localctx = mappingParser.RulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_rules)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.match(mappingParser.T__8)
            self.state = 190
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==3 or _la==94 or _la==96:
                self.state = 187
                self.rule_()
                self.state = 192
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 193
            self.match(mappingParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def groupTypeMode(self):
            return self.getTypedRuleContext(mappingParser.GroupTypeModeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_typeMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeMode" ):
                listener.enterTypeMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeMode" ):
                listener.exitTypeMode(self)




    def typeMode(self):

        localctx = mappingParser.TypeModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_typeMode)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self.match(mappingParser.T__10)
            self.state = 196
            self.groupTypeMode()
            self.state = 197
            self.match(mappingParser.T__11)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_extends

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtends" ):
                listener.enterExtends(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtends" ):
                listener.exitExtends(self)




    def extends(self):

        localctx = mappingParser.ExtendsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_extends)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 199
            self.match(mappingParser.T__12)
            self.state = 200
            self.match(mappingParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ParameterContext)
            else:
                return self.getTypedRuleContext(mappingParser.ParameterContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_parameters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters" ):
                listener.enterParameters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters" ):
                listener.exitParameters(self)




    def parameters(self):

        localctx = mappingParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.match(mappingParser.T__13)
            self.state = 203
            self.parameter()
            self.state = 206 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 204
                self.match(mappingParser.T__14)
                self.state = 205
                self.parameter()
                self.state = 208 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==15):
                    break

            self.state = 210
            self.match(mappingParser.T__15)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def inputMode(self):
            return self.getTypedRuleContext(mappingParser.InputModeContext,0)


        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def type_(self):
            return self.getTypedRuleContext(mappingParser.TypeContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)




    def parameter(self):

        localctx = mappingParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.inputMode()
            self.state = 213
            self.match(mappingParser.IDENTIFIER)
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 214
                self.type_()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)




    def type_(self):

        localctx = mappingParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(mappingParser.T__16)
            self.state = 218
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleSources(self):
            return self.getTypedRuleContext(mappingParser.RuleSourcesContext,0)


        def ruleTargets(self):
            return self.getTypedRuleContext(mappingParser.RuleTargetsContext,0)


        def dependent(self):
            return self.getTypedRuleContext(mappingParser.DependentContext,0)


        def ruleName(self):
            return self.getTypedRuleContext(mappingParser.RuleNameContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRule" ):
                listener.enterRule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRule" ):
                listener.exitRule(self)




    def rule_(self):

        localctx = mappingParser.RuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_rule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.ruleSources()
            self.state = 223
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 221
                self.match(mappingParser.T__17)
                self.state = 222
                self.ruleTargets()


            self.state = 226
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 225
                self.dependent()


            self.state = 229
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==95:
                self.state = 228
                self.ruleName()


            self.state = 231
            self.match(mappingParser.T__18)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_ruleName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleName" ):
                listener.enterRuleName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleName" ):
                listener.exitRuleName(self)




    def ruleName(self):

        localctx = mappingParser.RuleNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_ruleName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            self.match(mappingParser.QUOTEIDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleSourcesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleSource(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleSourceContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleSourceContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleSources

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleSources" ):
                listener.enterRuleSources(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleSources" ):
                listener.exitRuleSources(self)




    def ruleSources(self):

        localctx = mappingParser.RuleSourcesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_ruleSources)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235
            self.ruleSource()
            self.state = 240
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15:
                self.state = 236
                self.match(mappingParser.T__14)
                self.state = 237
                self.ruleSource()
                self.state = 242
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleSourceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def sourceType(self):
            return self.getTypedRuleContext(mappingParser.SourceTypeContext,0)


        def sourceCardinality(self):
            return self.getTypedRuleContext(mappingParser.SourceCardinalityContext,0)


        def sourceDefault(self):
            return self.getTypedRuleContext(mappingParser.SourceDefaultContext,0)


        def sourceListMode(self):
            return self.getTypedRuleContext(mappingParser.SourceListModeContext,0)


        def alias(self):
            return self.getTypedRuleContext(mappingParser.AliasContext,0)


        def whereClause(self):
            return self.getTypedRuleContext(mappingParser.WhereClauseContext,0)


        def checkClause(self):
            return self.getTypedRuleContext(mappingParser.CheckClauseContext,0)


        def log(self):
            return self.getTypedRuleContext(mappingParser.LogContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleSource

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleSource" ):
                listener.enterRuleSource(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleSource" ):
                listener.exitRuleSource(self)




    def ruleSource(self):

        localctx = mappingParser.RuleSourceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_ruleSource)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 243
            self.ruleContext()
            self.state = 245
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 244
                self.sourceType()


            self.state = 248
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==98:
                self.state = 247
                self.sourceCardinality()


            self.state = 251
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 250
                self.sourceDefault()


            self.state = 254
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 33285996544) != 0):
                self.state = 253
                self.sourceListMode()


            self.state = 257
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 256
                self.alias()


            self.state = 260
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 259
                self.whereClause()


            self.state = 263
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25:
                self.state = 262
                self.checkClause()


            self.state = 266
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==26:
                self.state = 265
                self.log()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleTargetsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleTarget(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.RuleTargetContext)
            else:
                return self.getTypedRuleContext(mappingParser.RuleTargetContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleTargets

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleTargets" ):
                listener.enterRuleTargets(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleTargets" ):
                listener.exitRuleTargets(self)




    def ruleTargets(self):

        localctx = mappingParser.RuleTargetsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_ruleTargets)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 268
            self.ruleTarget()
            self.state = 273
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15:
                self.state = 269
                self.match(mappingParser.T__14)
                self.state = 270
                self.ruleTarget()
                self.state = 275
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceType" ):
                listener.enterSourceType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceType" ):
                listener.exitSourceType(self)




    def sourceType(self):

        localctx = mappingParser.SourceTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_sourceType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 276
            self.match(mappingParser.T__16)
            self.state = 277
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceCardinalityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def upperBound(self):
            return self.getTypedRuleContext(mappingParser.UpperBoundContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceCardinality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceCardinality" ):
                listener.enterSourceCardinality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceCardinality" ):
                listener.exitSourceCardinality(self)




    def sourceCardinality(self):

        localctx = mappingParser.SourceCardinalityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_sourceCardinality)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 279
            self.match(mappingParser.INTEGER)
            self.state = 280
            self.match(mappingParser.T__19)
            self.state = 281
            self.upperBound()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UpperBoundContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_upperBound

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpperBound" ):
                listener.enterUpperBound(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpperBound" ):
                listener.exitUpperBound(self)




    def upperBound(self):

        localctx = mappingParser.UpperBoundContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_upperBound)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 283
            _la = self._input.LA(1)
            if not(_la==21 or _la==98):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleContextContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.MapidentifierContext)
            else:
                return self.getTypedRuleContext(mappingParser.MapidentifierContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleContext

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleContext" ):
                listener.enterRuleContext(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleContext" ):
                listener.exitRuleContext(self)




    def ruleContext(self):

        localctx = mappingParser.RuleContextContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_ruleContext)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.mapidentifier()
            self.state = 290
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 286
                self.match(mappingParser.T__21)
                self.state = 287
                self.mapidentifier()
                self.state = 292
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceDefaultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_sourceDefault

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceDefault" ):
                listener.enterSourceDefault(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceDefault" ):
                listener.exitSourceDefault(self)




    def sourceDefault(self):

        localctx = mappingParser.SourceDefaultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_sourceDefault)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.match(mappingParser.T__22)
            self.state = 294
            self.fhirPath()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AliasContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_alias

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlias" ):
                listener.enterAlias(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlias" ):
                listener.exitAlias(self)




    def alias(self):

        localctx = mappingParser.AliasContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_alias)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 296
            self.match(mappingParser.T__4)
            self.state = 297
            self.mapidentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhereClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_whereClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhereClause" ):
                listener.enterWhereClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhereClause" ):
                listener.exitWhereClause(self)




    def whereClause(self):

        localctx = mappingParser.WhereClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_whereClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 299
            self.match(mappingParser.T__23)
            self.state = 300
            self.fhirPath()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CheckClauseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_checkClause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCheckClause" ):
                listener.enterCheckClause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCheckClause" ):
                listener.exitCheckClause(self)




    def checkClause(self):

        localctx = mappingParser.CheckClauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_checkClause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(mappingParser.T__24)
            self.state = 303
            self.fhirPath()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_log

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLog" ):
                listener.enterLog(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLog" ):
                listener.exitLog(self)




    def log(self):

        localctx = mappingParser.LogContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_log)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            self.match(mappingParser.T__25)
            self.state = 306
            self.fhirPath()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DependentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapinvocation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.MapinvocationContext)
            else:
                return self.getTypedRuleContext(mappingParser.MapinvocationContext,i)


        def rules(self):
            return self.getTypedRuleContext(mappingParser.RulesContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_dependent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDependent" ):
                listener.enterDependent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDependent" ):
                listener.exitDependent(self)




    def dependent(self):

        localctx = mappingParser.DependentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_dependent)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 308
            self.match(mappingParser.T__26)
            self.state = 321
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3, 94, 96]:
                self.state = 309
                self.mapinvocation()
                self.state = 314
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==15:
                    self.state = 310
                    self.match(mappingParser.T__14)
                    self.state = 311
                    self.mapinvocation()
                    self.state = 316
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 318
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9:
                    self.state = 317
                    self.rules()


                pass
            elif token in [9]:
                self.state = 320
                self.rules()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleTargetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def transform(self):
            return self.getTypedRuleContext(mappingParser.TransformContext,0)


        def alias(self):
            return self.getTypedRuleContext(mappingParser.AliasContext,0)


        def targetListMode(self):
            return self.getTypedRuleContext(mappingParser.TargetListModeContext,0)


        def mapinvocation(self):
            return self.getTypedRuleContext(mappingParser.MapinvocationContext,0)


        def evaluate(self):
            return self.getTypedRuleContext(mappingParser.EvaluateContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_ruleTarget

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRuleTarget" ):
                listener.enterRuleTarget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRuleTarget" ):
                listener.exitRuleTarget(self)




    def ruleTarget(self):

        localctx = mappingParser.RuleTargetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_ruleTarget)
        self._la = 0 # Token type
        try:
            self.state = 342
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 323
                self.ruleContext()
                self.state = 326
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==2:
                    self.state = 324
                    self.match(mappingParser.T__1)
                    self.state = 325
                    self.transform()


                self.state = 329
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==5:
                    self.state = 328
                    self.alias()


                self.state = 332
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 108447924224) != 0):
                    self.state = 331
                    self.targetListMode()


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 334
                self.mapinvocation()
                self.state = 336
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==5:
                    self.state = 335
                    self.alias()


                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 338
                self.evaluate()
                self.state = 340
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==5:
                    self.state = 339
                    self.alias()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TransformContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def ruleContext(self):
            return self.getTypedRuleContext(mappingParser.RuleContextContext,0)


        def mapinvocation(self):
            return self.getTypedRuleContext(mappingParser.MapinvocationContext,0)


        def evaluate(self):
            return self.getTypedRuleContext(mappingParser.EvaluateContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_transform

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTransform" ):
                listener.enterTransform(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTransform" ):
                listener.exitTransform(self)




    def transform(self):

        localctx = mappingParser.TransformContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_transform)
        try:
            self.state = 348
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 344
                self.mapliteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 345
                self.ruleContext()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 346
                self.mapinvocation()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 347
                self.evaluate()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EvaluateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fhirPath(self):
            return self.getTypedRuleContext(mappingParser.FhirPathContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_evaluate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvaluate" ):
                listener.enterEvaluate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvaluate" ):
                listener.exitEvaluate(self)




    def evaluate(self):

        localctx = mappingParser.EvaluateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_evaluate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 350
            self.match(mappingParser.T__13)
            self.state = 351
            self.fhirPath()
            self.state = 352
            self.match(mappingParser.T__15)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapinvocationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapidentifier(self):
            return self.getTypedRuleContext(mappingParser.MapidentifierContext,0)


        def mapparamList(self):
            return self.getTypedRuleContext(mappingParser.MapparamListContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_mapinvocation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapinvocation" ):
                listener.enterMapinvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapinvocation" ):
                listener.exitMapinvocation(self)




    def mapinvocation(self):

        localctx = mappingParser.MapinvocationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_mapinvocation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self.mapidentifier()
            self.state = 355
            self.match(mappingParser.T__13)
            self.state = 357
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 90)) & ~0x3f) == 0 and ((1 << (_la - 90)) & 927) != 0):
                self.state = 356
                self.mapparamList()


            self.state = 359
            self.match(mappingParser.T__15)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapparamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ParamContext)
            else:
                return self.getTypedRuleContext(mappingParser.ParamContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_mapparamList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapparamList" ):
                listener.enterMapparamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapparamList" ):
                listener.exitMapparamList(self)




    def mapparamList(self):

        localctx = mappingParser.MapparamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_mapparamList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 361
            self.param()
            self.state = 366
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15:
                self.state = 362
                self.match(mappingParser.T__14)
                self.state = 363
                self.param()
                self.state = 368
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)




    def param(self):

        localctx = mappingParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_param)
        try:
            self.state = 371
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [90, 91, 92, 93, 97, 98, 99]:
                self.enterOuterAlt(localctx, 1)
                self.state = 369
                self.mapliteral()
                pass
            elif token in [94]:
                self.enterOuterAlt(localctx, 2)
                self.state = 370
                self.match(mappingParser.IDENTIFIER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FhirPathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapliteral(self):
            return self.getTypedRuleContext(mappingParser.MapliteralContext,0)


        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_fhirPath

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFhirPath" ):
                listener.enterFhirPath(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFhirPath" ):
                listener.exitFhirPath(self)




    def fhirPath(self):

        localctx = mappingParser.FhirPathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_fhirPath)
        try:
            self.state = 375
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 373
                self.mapliteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 374
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapliteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def DATETIME(self):
            return self.getToken(mappingParser.DATETIME, 0)

        def DATE(self):
            return self.getToken(mappingParser.DATE, 0)

        def TIME(self):
            return self.getToken(mappingParser.TIME, 0)

        def BOOL(self):
            return self.getToken(mappingParser.BOOL, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_mapliteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapliteral" ):
                listener.enterMapliteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapliteral" ):
                listener.exitMapliteral(self)




    def mapliteral(self):

        localctx = mappingParser.MapliteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_mapliteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 377
            _la = self._input.LA(1)
            if not(((((_la - 90)) & ~0x3f) == 0 and ((1 << (_la - 90)) & 911) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GroupTypeModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_groupTypeMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupTypeMode" ):
                listener.enterGroupTypeMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupTypeMode" ):
                listener.exitGroupTypeMode(self)




    def groupTypeMode(self):

        localctx = mappingParser.GroupTypeModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_groupTypeMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            _la = self._input.LA(1)
            if not(_la==28 or _la==29):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SourceListModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_sourceListMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSourceListMode" ):
                listener.enterSourceListMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSourceListMode" ):
                listener.exitSourceListMode(self)




    def sourceListMode(self):

        localctx = mappingParser.SourceListModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_sourceListMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 381
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 33285996544) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TargetListModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_targetListMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTargetListMode" ):
                listener.enterTargetListMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTargetListMode" ):
                listener.exitTargetListMode(self)




    def targetListMode(self):

        localctx = mappingParser.TargetListModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_targetListMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 383
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 108447924224) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InputModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_inputMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInputMode" ):
                listener.enterInputMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInputMode" ):
                listener.exitInputMode(self)




    def inputMode(self):

        localctx = mappingParser.InputModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_inputMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 385
            _la = self._input.LA(1)
            if not(_la==37 or _la==38):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ModelModeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_modelMode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModelMode" ):
                listener.enterModelMode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModelMode" ):
                listener.exitModelMode(self)




    def modelMode(self):

        localctx = mappingParser.ModelModeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_modelMode)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 387
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2061584302080) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def quoteidentifier(self):
            return self.getTypedRuleContext(mappingParser.QuoteidentifierContext,0)


        def prefix(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.PrefixContext)
            else:
                return self.getTypedRuleContext(mappingParser.PrefixContext,i)


        def conceptMapping(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMappingContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMappingContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_conceptMap

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMap" ):
                listener.enterConceptMap(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMap" ):
                listener.exitConceptMap(self)




    def conceptMap(self):

        localctx = mappingParser.ConceptMapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_conceptMap)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 389
            _la = self._input.LA(1)
            if not(_la==41 or _la==42):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 390
            self.quoteidentifier()
            self.state = 391
            self.match(mappingParser.T__8)
            self.state = 393 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 392
                self.prefix()
                self.state = 395 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==43):
                    break

            self.state = 398 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 397
                self.conceptMapping()
                self.state = 400 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==52 or _la==94):
                    break

            self.state = 402
            self.match(mappingParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrefixContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def conceptMappingVar(self):
            return self.getTypedRuleContext(mappingParser.ConceptMappingVarContext,0)


        def url(self):
            return self.getTypedRuleContext(mappingParser.UrlContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_prefix

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrefix" ):
                listener.enterPrefix(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrefix" ):
                listener.exitPrefix(self)




    def prefix(self):

        localctx = mappingParser.PrefixContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_prefix)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            self.match(mappingParser.T__42)
            self.state = 405
            self.conceptMappingVar()
            self.state = 406
            self.match(mappingParser.T__1)
            self.state = 407
            self.url()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMappingVarContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_conceptMappingVar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMappingVar" ):
                listener.enterConceptMappingVar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMappingVar" ):
                listener.exitConceptMappingVar(self)




    def conceptMappingVar(self):

        localctx = mappingParser.ConceptMappingVarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_conceptMappingVar)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 409
            self.match(mappingParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConceptMappingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def conceptMappingVar(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ConceptMappingVarContext)
            else:
                return self.getTypedRuleContext(mappingParser.ConceptMappingVarContext,i)


        def field(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.FieldContext)
            else:
                return self.getTypedRuleContext(mappingParser.FieldContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_conceptMapping

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConceptMapping" ):
                listener.enterConceptMapping(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConceptMapping" ):
                listener.exitConceptMapping(self)




    def conceptMapping(self):

        localctx = mappingParser.ConceptMappingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_conceptMapping)
        try:
            self.state = 430
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [94]:
                self.enterOuterAlt(localctx, 1)
                self.state = 411
                self.conceptMappingVar()
                self.state = 412
                self.match(mappingParser.T__16)
                self.state = 413
                self.field()

                self.state = 423
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44]:
                    self.state = 414
                    self.match(mappingParser.T__43)
                    pass
                elif token in [45]:
                    self.state = 415
                    self.match(mappingParser.T__44)
                    pass
                elif token in [2]:
                    self.state = 416
                    self.match(mappingParser.T__1)
                    pass
                elif token in [46]:
                    self.state = 417
                    self.match(mappingParser.T__45)
                    pass
                elif token in [47]:
                    self.state = 418
                    self.match(mappingParser.T__46)
                    self.state = 419
                    self.match(mappingParser.T__47)
                    self.state = 420
                    self.match(mappingParser.T__48)
                    pass
                elif token in [50]:
                    self.state = 421
                    self.match(mappingParser.T__49)
                    pass
                elif token in [51]:
                    self.state = 422
                    self.match(mappingParser.T__50)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 425
                self.conceptMappingVar()
                self.state = 426
                self.match(mappingParser.T__16)
                self.state = 427
                self.field()
                pass
            elif token in [52]:
                self.enterOuterAlt(localctx, 2)
                self.state = 429
                self.match(mappingParser.T__51)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def QUOTEIDENTIFIER(self):
            return self.getToken(mappingParser.QUOTEIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_field

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterField" ):
                listener.enterField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitField" ):
                listener.exitField(self)




    def field(self):

        localctx = mappingParser.FieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_field)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 432
            _la = self._input.LA(1)
            if not(_la==94 or _la==95):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class IndexerExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexerExpression" ):
                listener.enterIndexerExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexerExpression" ):
                listener.exitIndexerExpression(self)


    class PolarityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPolarityExpression" ):
                listener.enterPolarityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPolarityExpression" ):
                listener.exitPolarityExpression(self)


    class AdditiveExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpression" ):
                listener.enterAdditiveExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpression" ):
                listener.exitAdditiveExpression(self)


    class MultiplicativeExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpression" ):
                listener.enterMultiplicativeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpression" ):
                listener.exitMultiplicativeExpression(self)


    class UnionExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnionExpression" ):
                listener.enterUnionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnionExpression" ):
                listener.exitUnionExpression(self)


    class OrExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrExpression" ):
                listener.enterOrExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrExpression" ):
                listener.exitOrExpression(self)


    class AndExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAndExpression" ):
                listener.enterAndExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAndExpression" ):
                listener.exitAndExpression(self)


    class MembershipExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMembershipExpression" ):
                listener.enterMembershipExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMembershipExpression" ):
                listener.exitMembershipExpression(self)


    class InequalityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInequalityExpression" ):
                listener.enterInequalityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInequalityExpression" ):
                listener.exitInequalityExpression(self)


    class InvocationExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)

        def invocation(self):
            return self.getTypedRuleContext(mappingParser.InvocationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInvocationExpression" ):
                listener.enterInvocationExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInvocationExpression" ):
                listener.exitInvocationExpression(self)


    class EqualityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExpression" ):
                listener.enterEqualityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExpression" ):
                listener.exitEqualityExpression(self)


    class ImpliesExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImpliesExpression" ):
                listener.enterImpliesExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImpliesExpression" ):
                listener.exitImpliesExpression(self)


    class TermExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(mappingParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTermExpression" ):
                listener.enterTermExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTermExpression" ):
                listener.exitTermExpression(self)


    class TypeExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)

        def typeSpecifier(self):
            return self.getTypedRuleContext(mappingParser.TypeSpecifierContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeExpression" ):
                listener.enterTypeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeExpression" ):
                listener.exitTypeExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = mappingParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 96
        self.enterRecursionRule(localctx, 96, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 438
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 9, 14, 24, 59, 64, 65, 70, 71, 72, 73, 90, 91, 92, 93, 94, 96, 97, 98, 99]:
                localctx = mappingParser.TermExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 435
                self.term()
                pass
            elif token in [44, 55]:
                localctx = mappingParser.PolarityExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 436
                _la = self._input.LA(1)
                if not(_la==44 or _la==55):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 437
                self.expression(11)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 480
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,44,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 478
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
                    if la_ == 1:
                        localctx = mappingParser.MultiplicativeExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 440
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 441
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 216172782115880968) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 442
                        self.expression(11)
                        pass

                    elif la_ == 2:
                        localctx = mappingParser.AdditiveExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 443
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 444
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 324276765356720128) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 445
                        self.expression(10)
                        pass

                    elif la_ == 3:
                        localctx = mappingParser.UnionExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 446
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 447
                        self.match(mappingParser.T__59)
                        self.state = 448
                        self.expression(8)
                        pass

                    elif la_ == 4:
                        localctx = mappingParser.InequalityExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 449
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 450
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 6917845686989881344) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 451
                        self.expression(7)
                        pass

                    elif la_ == 5:
                        localctx = mappingParser.EqualityExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 452
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 453
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & -9220979499552735228) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 454
                        self.expression(6)
                        pass

                    elif la_ == 6:
                        localctx = mappingParser.MembershipExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 455
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 456
                        _la = self._input.LA(1)
                        if not(_la==64 or _la==65):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 457
                        self.expression(5)
                        pass

                    elif la_ == 7:
                        localctx = mappingParser.AndExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 458
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 459
                        self.match(mappingParser.T__65)
                        self.state = 460
                        self.expression(4)
                        pass

                    elif la_ == 8:
                        localctx = mappingParser.OrExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 461
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 462
                        _la = self._input.LA(1)
                        if not(_la==67 or _la==68):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 463
                        self.expression(3)
                        pass

                    elif la_ == 9:
                        localctx = mappingParser.ImpliesExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 464
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 465
                        self.match(mappingParser.T__68)
                        self.state = 466
                        self.expression(2)
                        pass

                    elif la_ == 10:
                        localctx = mappingParser.InvocationExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 467
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 468
                        self.match(mappingParser.T__21)
                        self.state = 469
                        self.invocation()
                        pass

                    elif la_ == 11:
                        localctx = mappingParser.IndexerExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 470
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 471
                        self.match(mappingParser.T__52)
                        self.state = 472
                        self.expression(0)
                        self.state = 473
                        self.match(mappingParser.T__53)
                        pass

                    elif la_ == 12:
                        localctx = mappingParser.TypeExpressionContext(self, mappingParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 475
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 476
                        _la = self._input.LA(1)
                        if not(_la==5 or _la==59):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 477
                        self.typeSpecifier()
                        pass

             
                self.state = 482
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,44,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_term

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExternalConstantTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def externalConstant(self):
            return self.getTypedRuleContext(mappingParser.ExternalConstantContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternalConstantTerm" ):
                listener.enterExternalConstantTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternalConstantTerm" ):
                listener.exitExternalConstantTerm(self)


    class LiteralTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(mappingParser.LiteralContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralTerm" ):
                listener.enterLiteralTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralTerm" ):
                listener.exitLiteralTerm(self)


    class ParenthesizedTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(mappingParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesizedTerm" ):
                listener.enterParenthesizedTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesizedTerm" ):
                listener.exitParenthesizedTerm(self)


    class InvocationTermContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def invocation(self):
            return self.getTypedRuleContext(mappingParser.InvocationContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInvocationTerm" ):
                listener.enterInvocationTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInvocationTerm" ):
                listener.exitInvocationTerm(self)



    def term(self):

        localctx = mappingParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_term)
        try:
            self.state = 490
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 24, 59, 64, 65, 71, 72, 73, 94, 96]:
                localctx = mappingParser.InvocationTermContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 483
                self.invocation()
                pass
            elif token in [9, 90, 91, 92, 93, 97, 98, 99]:
                localctx = mappingParser.LiteralTermContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 484
                self.literal()
                pass
            elif token in [70]:
                localctx = mappingParser.ExternalConstantTermContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 485
                self.externalConstant()
                pass
            elif token in [14]:
                localctx = mappingParser.ParenthesizedTermContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 486
                self.match(mappingParser.T__13)
                self.state = 487
                self.expression(0)
                self.state = 488
                self.match(mappingParser.T__15)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_literal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TimeLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TIME(self):
            return self.getToken(mappingParser.TIME, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTimeLiteral" ):
                listener.enterTimeLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTimeLiteral" ):
                listener.exitTimeLiteral(self)


    class NullLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNullLiteral" ):
                listener.enterNullLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNullLiteral" ):
                listener.exitNullLiteral(self)


    class DateTimeLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DATETIME(self):
            return self.getToken(mappingParser.DATETIME, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateTimeLiteral" ):
                listener.enterDateTimeLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateTimeLiteral" ):
                listener.exitDateTimeLiteral(self)


    class StringLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringLiteral" ):
                listener.enterStringLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringLiteral" ):
                listener.exitStringLiteral(self)


    class IntegerLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntegerLiteral" ):
                listener.enterIntegerLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntegerLiteral" ):
                listener.exitIntegerLiteral(self)


    class DateLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DATE(self):
            return self.getToken(mappingParser.DATE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateLiteral" ):
                listener.enterDateLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateLiteral" ):
                listener.exitDateLiteral(self)


    class BooleanLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BOOL(self):
            return self.getToken(mappingParser.BOOL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanLiteral" ):
                listener.enterBooleanLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanLiteral" ):
                listener.exitBooleanLiteral(self)


    class NumberLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumberLiteral" ):
                listener.enterNumberLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumberLiteral" ):
                listener.exitNumberLiteral(self)


    class QuantityLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def quantity(self):
            return self.getTypedRuleContext(mappingParser.QuantityContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuantityLiteral" ):
                listener.enterQuantityLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuantityLiteral" ):
                listener.exitQuantityLiteral(self)



    def literal(self):

        localctx = mappingParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_literal)
        try:
            self.state = 502
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,46,self._ctx)
            if la_ == 1:
                localctx = mappingParser.NullLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 492
                self.match(mappingParser.T__8)
                self.state = 493
                self.match(mappingParser.T__9)
                pass

            elif la_ == 2:
                localctx = mappingParser.BooleanLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 494
                self.match(mappingParser.BOOL)
                pass

            elif la_ == 3:
                localctx = mappingParser.StringLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 495
                self.match(mappingParser.STRING)
                pass

            elif la_ == 4:
                localctx = mappingParser.NumberLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 496
                self.match(mappingParser.NUMBER)
                pass

            elif la_ == 5:
                localctx = mappingParser.IntegerLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 497
                self.match(mappingParser.INTEGER)
                pass

            elif la_ == 6:
                localctx = mappingParser.DateLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 498
                self.match(mappingParser.DATE)
                pass

            elif la_ == 7:
                localctx = mappingParser.DateTimeLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 499
                self.match(mappingParser.DATETIME)
                pass

            elif la_ == 8:
                localctx = mappingParser.TimeLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 500
                self.match(mappingParser.TIME)
                pass

            elif la_ == 9:
                localctx = mappingParser.QuantityLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 501
                self.quantity()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExternalConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_externalConstant

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternalConstant" ):
                listener.enterExternalConstant(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternalConstant" ):
                listener.exitExternalConstant(self)




    def externalConstant(self):

        localctx = mappingParser.ExternalConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_externalConstant)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 504
            self.match(mappingParser.T__69)
            self.state = 507
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 59, 64, 65, 94, 96]:
                self.state = 505
                self.identifier()
                pass
            elif token in [97]:
                self.state = 506
                self.match(mappingParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InvocationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_invocation

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TotalInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTotalInvocation" ):
                listener.enterTotalInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTotalInvocation" ):
                listener.exitTotalInvocation(self)


    class ThisInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThisInvocation" ):
                listener.enterThisInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThisInvocation" ):
                listener.exitThisInvocation(self)


    class IndexInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexInvocation" ):
                listener.enterIndexInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexInvocation" ):
                listener.exitIndexInvocation(self)


    class FunctionInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def function(self):
            return self.getTypedRuleContext(mappingParser.FunctionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionInvocation" ):
                listener.enterFunctionInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionInvocation" ):
                listener.exitFunctionInvocation(self)


    class MemberInvocationContext(InvocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a mappingParser.InvocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMemberInvocation" ):
                listener.enterMemberInvocation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMemberInvocation" ):
                listener.exitMemberInvocation(self)



    def invocation(self):

        localctx = mappingParser.InvocationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_invocation)
        try:
            self.state = 514
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                localctx = mappingParser.MemberInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 509
                self.identifier()
                pass

            elif la_ == 2:
                localctx = mappingParser.FunctionInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 510
                self.function()
                pass

            elif la_ == 3:
                localctx = mappingParser.ThisInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 511
                self.match(mappingParser.T__70)
                pass

            elif la_ == 4:
                localctx = mappingParser.IndexInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 512
                self.match(mappingParser.T__71)
                pass

            elif la_ == 5:
                localctx = mappingParser.TotalInvocationContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 513
                self.match(mappingParser.T__72)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(mappingParser.IdentifierContext,0)


        def paramList(self):
            return self.getTypedRuleContext(mappingParser.ParamListContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction" ):
                listener.enterFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction" ):
                listener.exitFunction(self)




    def function(self):

        localctx = mappingParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 518
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 59, 64, 65, 94, 96]:
                self.state = 516
                self.identifier()
                pass
            elif token in [24]:
                self.state = 517
                self.match(mappingParser.T__23)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 520
            self.match(mappingParser.T__13)
            self.state = 522
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 612507141525226016) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 66504885187) != 0):
                self.state = 521
                self.paramList()


            self.state = 524
            self.match(mappingParser.T__15)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(mappingParser.ExpressionContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_paramList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParamList" ):
                listener.enterParamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParamList" ):
                listener.exitParamList(self)




    def paramList(self):

        localctx = mappingParser.ParamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_paramList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 526
            self.expression(0)
            self.state = 531
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15:
                self.state = 527
                self.match(mappingParser.T__14)
                self.state = 528
                self.expression(0)
                self.state = 533
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QuantityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(mappingParser.NUMBER, 0)

        def INTEGER(self):
            return self.getToken(mappingParser.INTEGER, 0)

        def unit(self):
            return self.getTypedRuleContext(mappingParser.UnitContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_quantity

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuantity" ):
                listener.enterQuantity(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuantity" ):
                listener.exitQuantity(self)




    def quantity(self):

        localctx = mappingParser.QuantityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_quantity)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 534
            _la = self._input.LA(1)
            if not(_la==98 or _la==99):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 536
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,52,self._ctx)
            if la_ == 1:
                self.state = 535
                self.unit()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dateTimePrecision(self):
            return self.getTypedRuleContext(mappingParser.DateTimePrecisionContext,0)


        def pluralDateTimePrecision(self):
            return self.getTypedRuleContext(mappingParser.PluralDateTimePrecisionContext,0)


        def STRING(self):
            return self.getToken(mappingParser.STRING, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_unit

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnit" ):
                listener.enterUnit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnit" ):
                listener.exitUnit(self)




    def unit(self):

        localctx = mappingParser.UnitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_unit)
        try:
            self.state = 541
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [74, 75, 76, 77, 78, 79, 80, 81]:
                self.enterOuterAlt(localctx, 1)
                self.state = 538
                self.dateTimePrecision()
                pass
            elif token in [82, 83, 84, 85, 86, 87, 88, 89]:
                self.enterOuterAlt(localctx, 2)
                self.state = 539
                self.pluralDateTimePrecision()
                pass
            elif token in [97]:
                self.enterOuterAlt(localctx, 3)
                self.state = 540
                self.match(mappingParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DateTimePrecisionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_dateTimePrecision

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDateTimePrecision" ):
                listener.enterDateTimePrecision(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDateTimePrecision" ):
                listener.exitDateTimePrecision(self)




    def dateTimePrecision(self):

        localctx = mappingParser.DateTimePrecisionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_dateTimePrecision)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 543
            _la = self._input.LA(1)
            if not(((((_la - 74)) & ~0x3f) == 0 and ((1 << (_la - 74)) & 255) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PluralDateTimePrecisionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return mappingParser.RULE_pluralDateTimePrecision

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPluralDateTimePrecision" ):
                listener.enterPluralDateTimePrecision(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPluralDateTimePrecision" ):
                listener.exitPluralDateTimePrecision(self)




    def pluralDateTimePrecision(self):

        localctx = mappingParser.PluralDateTimePrecisionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_pluralDateTimePrecision)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 545
            _la = self._input.LA(1)
            if not(((((_la - 82)) & ~0x3f) == 0 and ((1 << (_la - 82)) & 255) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeSpecifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedIdentifier(self):
            return self.getTypedRuleContext(mappingParser.QualifiedIdentifierContext,0)


        def getRuleIndex(self):
            return mappingParser.RULE_typeSpecifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeSpecifier" ):
                listener.enterTypeSpecifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeSpecifier" ):
                listener.exitTypeSpecifier(self)




    def typeSpecifier(self):

        localctx = mappingParser.TypeSpecifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_typeSpecifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 547
            self.qualifiedIdentifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedIdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(mappingParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(mappingParser.IdentifierContext,i)


        def getRuleIndex(self):
            return mappingParser.RULE_qualifiedIdentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedIdentifier" ):
                listener.enterQualifiedIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedIdentifier" ):
                listener.exitQualifiedIdentifier(self)




    def qualifiedIdentifier(self):

        localctx = mappingParser.QualifiedIdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_qualifiedIdentifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 549
            self.identifier()
            self.state = 554
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,54,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 550
                    self.match(mappingParser.T__21)
                    self.state = 551
                    self.identifier() 
                self.state = 556
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,54,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(mappingParser.IDENTIFIER, 0)

        def DELIMITEDIDENTIFIER(self):
            return self.getToken(mappingParser.DELIMITEDIDENTIFIER, 0)

        def getRuleIndex(self):
            return mappingParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)




    def identifier(self):

        localctx = mappingParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 122, self.RULE_identifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 557
            _la = self._input.LA(1)
            if not(_la==5 or _la==59 or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 5368709123) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[48] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 1)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 8)
         




