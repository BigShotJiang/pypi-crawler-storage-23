---
name: github-repo
description: "Manage GitHub Repositories (create, list, delete, settings). Triggers: Repositories Agent."
tags: [repo]
---

### Overview
This skill handles operations related to the Repositories Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Repositories Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
