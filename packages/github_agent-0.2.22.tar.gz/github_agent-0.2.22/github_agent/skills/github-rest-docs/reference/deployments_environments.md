[Skip to main content](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Deployments](https://docs.github.com/en/rest/deployments "Deployments")/
  * [Environments](https://docs.github.com/en/rest/deployments/environments "Environments")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
      * [About deployment environments](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#about-deployment-environments)
      * [List environments](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments)
      * [Get an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment)
      * [Create or update an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment)
      * [Delete an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment)
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Deployments](https://docs.github.com/en/rest/deployments "Deployments")/
  * [Environments](https://docs.github.com/en/rest/deployments/environments "Environments")


# REST API endpoints for deployment environments
Use the REST API to create, configure, and delete deployment environments.
## [About deployment environments](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#about-deployment-environments)
For more information about environments, see [Managing environments for deployment](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment). To manage environment secrets, see [REST API endpoints for GitHub Actions Secrets](https://docs.github.com/en/rest/actions/secrets).
Environments, environment secrets, and deployment protection rules are available in public repositories for all current GitHub plans. They are not available on legacy plans, such as Bronze, Silver, or Gold. For access to environments, environment secrets, and deployment branches in private or internal repositories, you must use GitHub Pro, GitHub Team, or GitHub Enterprise. If you are on a GitHub Free, GitHub Pro, or GitHub Team plan, other deployment protection rules, such as a wait timer or required reviewers, are only available for public repositories.
## [List environments](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments)
Lists the environments for a repository.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "List environments"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List environments"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List environments"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List environments"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#list-environments--code-samples)
#### Request example
get/repos/{owner}/{repo}/environments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "environments": [     {       "id": 161088068,       "node_id": "MDExOkVudmlyb25tZW50MTYxMDg4MDY4",       "name": "staging",       "url": "https://api.github.com/repos/github/hello-world/environments/staging",       "html_url": "https://github.com/github/hello-world/deployments/activity_log?environments_filter=staging",       "created_at": "2020-11-23T22:00:40Z",       "updated_at": "2020-11-23T22:00:40Z",       "protection_rules": [         {           "id": 3736,           "node_id": "MDQ6R2F0ZTM3MzY=",           "type": "wait_timer",           "wait_timer": 30         },         {           "id": 3755,           "node_id": "MDQ6R2F0ZTM3NTU=",           "prevent_self_review": false,           "type": "required_reviewers",           "reviewers": [             {               "type": "User",               "reviewer": {                 "login": "octocat",                 "id": 1,                 "node_id": "MDQ6VXNlcjE=",                 "avatar_url": "https://github.com/images/error/octocat_happy.gif",                 "gravatar_id": "",                 "url": "https://api.github.com/users/octocat",                 "html_url": "https://github.com/octocat",                 "followers_url": "https://api.github.com/users/octocat/followers",                 "following_url": "https://api.github.com/users/octocat/following{/other_user}",                 "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",                 "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",                 "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",                 "organizations_url": "https://api.github.com/users/octocat/orgs",                 "repos_url": "https://api.github.com/users/octocat/repos",                 "events_url": "https://api.github.com/users/octocat/events{/privacy}",                 "received_events_url": "https://api.github.com/users/octocat/received_events",                 "type": "User",                 "site_admin": false               }             },             {               "type": "Team",               "reviewer": {                 "id": 1,                 "node_id": "MDQ6VGVhbTE=",                 "url": "https://api.github.com/teams/1",                 "html_url": "https://github.com/orgs/github/teams/justice-league",                 "name": "Justice League",                 "slug": "justice-league",                 "description": "A great team.",                 "privacy": "closed",                 "notification_setting": "notifications_enabled",                 "permission": "admin",                 "members_url": "https://api.github.com/teams/1/members{/member}",                 "repositories_url": "https://api.github.com/teams/1/repos",                 "parent": null               }             }           ]         },         {           "id": 3756,           "node_id": "MDQ6R2F0ZTM3NTY=",           "type": "branch_policy"         }       ],       "deployment_branch_policy": {         "protected_branches": false,         "custom_branch_policies": true       }     }   ] }`
## [Get an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment)
To get information about name patterns that branches must match in order to deploy to this environment, see "[Get a deployment branch policy](https://docs.github.com/rest/deployments/branch-policies#get-a-deployment-branch-policy)."
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### [HTTP response status codes for "Get an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#get-an-environment--code-samples)
#### Request example
get/repos/{owner}/{repo}/environments/{environment_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 161088068,   "node_id": "MDExOkVudmlyb25tZW50MTYxMDg4MDY4",   "name": "staging",   "url": "https://api.github.com/repos/github/hello-world/environments/staging",   "html_url": "https://github.com/github/hello-world/deployments/activity_log?environments_filter=staging",   "created_at": "2020-11-23T22:00:40Z",   "updated_at": "2020-11-23T22:00:40Z",   "protection_rules": [     {       "id": 3736,       "node_id": "MDQ6R2F0ZTM3MzY=",       "type": "wait_timer",       "wait_timer": 30     },     {       "id": 3755,       "node_id": "MDQ6R2F0ZTM3NTU=",       "prevent_self_review": false,       "type": "required_reviewers",       "reviewers": [         {           "type": "User",           "reviewer": {             "login": "octocat",             "id": 1,             "node_id": "MDQ6VXNlcjE=",             "avatar_url": "https://github.com/images/error/octocat_happy.gif",             "gravatar_id": "",             "url": "https://api.github.com/users/octocat",             "html_url": "https://github.com/octocat",             "followers_url": "https://api.github.com/users/octocat/followers",             "following_url": "https://api.github.com/users/octocat/following{/other_user}",             "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",             "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",             "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",             "organizations_url": "https://api.github.com/users/octocat/orgs",             "repos_url": "https://api.github.com/users/octocat/repos",             "events_url": "https://api.github.com/users/octocat/events{/privacy}",             "received_events_url": "https://api.github.com/users/octocat/received_events",             "type": "User",             "site_admin": false           }         },         {           "type": "Team",           "reviewer": {             "id": 1,             "node_id": "MDQ6VGVhbTE=",             "url": "https://api.github.com/teams/1",             "html_url": "https://github.com/orgs/github/teams/justice-league",             "name": "Justice League",             "slug": "justice-league",             "description": "A great team.",             "privacy": "closed",             "notification_setting": "notifications_enabled",             "permission": "admin",             "members_url": "https://api.github.com/teams/1/members{/member}",             "repositories_url": "https://api.github.com/teams/1/repos",             "parent": null           }         }       ]     },     {       "id": 3756,       "node_id": "MDQ6R2F0ZTM3NTY=",       "type": "branch_policy"     }   ],   "deployment_branch_policy": {     "protected_branches": false,     "custom_branch_policies": true   } }`
## [Create or update an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment)
Create or update an environment with protection rules, such as required reviewers. For more information about environment protection rules, see "[Environments](https://docs.github.com/actions/reference/environments#environment-protection-rules)."
To create or update name patterns that branches must match in order to deploy to this environment, see "[Deployment branch policies](https://docs.github.com/rest/deployments/branch-policies)."
To create or update secrets for an environment, see "[GitHub Actions secrets](https://docs.github.com/rest/actions/secrets)."
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create or update an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create or update an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
Body parameters Name, Type, Description
---
`wait_timer` integer The amount of time to delay a job after the job is initially triggered. The time (in minutes) must be an integer between 0 and 43,200 (30 days).
`prevent_self_review` boolean Whether or not a user who created the job is prevented from approving their own job.
`reviewers` array of objects or null The people or teams that may review jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed.
Properties of `reviewers` | Name, Type, Description
---
`type` string The type of reviewer. Can be one of: `User`, `Team`
`id` integer The id of the user or team who can review the deployment
`deployment_branch_policy` object or null The type of deployment branch policy for this environment. To allow all branches to deploy, set to `null`.
Properties of `deployment_branch_policy` | Name, Type, Description
---
`protected_branches` boolean Required Whether only branches with branch protection rules can deploy to this environment. If `protected_branches` is `true`, `custom_branch_policies` must be `false`; if `protected_branches` is `false`, `custom_branch_policies` must be `true`.
`custom_branch_policies` boolean Required Whether only branches that match the specified name patterns can deploy to this environment. If `custom_branch_policies` is `true`, `protected_branches` must be `false`; if `custom_branch_policies` is `false`, `protected_branches` must be `true`.
### [HTTP response status codes for "Create or update an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation error when the environment name is invalid or when `protected_branches` and `custom_branch_policies` in `deployment_branch_policy` are set to the same value
### [Code samples for "Create or update an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#create-or-update-an-environment--code-samples)
#### Request example
put/repos/{owner}/{repo}/environments/{environment_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME \   -d '{"wait_timer":30,"prevent_self_review":false,"reviewers":[{"type":"User","id":1},{"type":"Team","id":1}],"deployment_branch_policy":{"protected_branches":false,"custom_branch_policies":true}}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 161088068,   "node_id": "MDExOkVudmlyb25tZW50MTYxMDg4MDY4",   "name": "staging",   "url": "https://api.github.com/repos/github/hello-world/environments/staging",   "html_url": "https://github.com/github/hello-world/deployments/activity_log?environments_filter=staging",   "created_at": "2020-11-23T22:00:40Z",   "updated_at": "2020-11-23T22:00:40Z",   "protection_rules": [     {       "id": 3736,       "node_id": "MDQ6R2F0ZTM3MzY=",       "type": "wait_timer",       "wait_timer": 30     },     {       "id": 3755,       "node_id": "MDQ6R2F0ZTM3NTU=",       "prevent_self_review": false,       "type": "required_reviewers",       "reviewers": [         {           "type": "User",           "reviewer": {             "login": "octocat",             "id": 1,             "node_id": "MDQ6VXNlcjE=",             "avatar_url": "https://github.com/images/error/octocat_happy.gif",             "gravatar_id": "",             "url": "https://api.github.com/users/octocat",             "html_url": "https://github.com/octocat",             "followers_url": "https://api.github.com/users/octocat/followers",             "following_url": "https://api.github.com/users/octocat/following{/other_user}",             "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",             "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",             "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",             "organizations_url": "https://api.github.com/users/octocat/orgs",             "repos_url": "https://api.github.com/users/octocat/repos",             "events_url": "https://api.github.com/users/octocat/events{/privacy}",             "received_events_url": "https://api.github.com/users/octocat/received_events",             "type": "User",             "site_admin": false           }         },         {           "type": "Team",           "reviewer": {             "id": 1,             "node_id": "MDQ6VGVhbTE=",             "url": "https://api.github.com/teams/1",             "html_url": "https://github.com/orgs/github/teams/justice-league",             "name": "Justice League",             "slug": "justice-league",             "description": "A great team.",             "privacy": "closed",             "notification_setting": "notifications_enabled",             "permission": "admin",             "members_url": "https://api.github.com/teams/1/members{/member}",             "repositories_url": "https://api.github.com/teams/1/repos",             "parent": null           }         }       ]     },     {       "id": 3756,       "node_id": "MDQ6R2F0ZTM3NTY=",       "type": "branch_policy"     }   ],   "deployment_branch_policy": {     "protected_branches": false,     "custom_branch_policies": true   } }`
## [Delete an environment](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment)
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### [HTTP response status codes for "Delete an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment--status-codes)
Status code | Description
---|---
`204` | Default response
### [Code samples for "Delete an environment"](https://docs.github.com/en/rest/deployments/environments?apiVersion=2022-11-28#delete-an-environment--code-samples)
#### Request example
delete/repos/{owner}/{repo}/environments/{environment_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME`
Default response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/deployments/environments.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for deployment environments - GitHub Docs
