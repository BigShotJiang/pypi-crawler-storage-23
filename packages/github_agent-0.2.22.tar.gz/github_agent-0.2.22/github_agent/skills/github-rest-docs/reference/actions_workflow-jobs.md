[Skip to main content](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflow jobs](https://docs.github.com/en/rest/actions/workflow-jobs "Workflow jobs")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
      * [About workflow jobs in GitHub Actions](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#about-workflow-jobs-in-github-actions)
      * [Get a job for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run)
      * [Download job logs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run)
      * [List jobs for a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt)
      * [List jobs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run)
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflow jobs](https://docs.github.com/en/rest/actions/workflow-jobs "Workflow jobs")


# REST API endpoints for workflow jobs
Use the REST API to interact with workflow jobs in GitHub Actions.
## [About workflow jobs in GitHub Actions](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#about-workflow-jobs-in-github-actions)
You can use the REST API to view logs and workflow jobs in GitHub Actions. A workflow job is a set of steps that execute on the same runner. For more information, see [Workflow syntax for GitHub Actions](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions).
## [Get a job for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run)
Gets a specific job in a workflow run.
Anyone with read access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get a job for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a job for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`job_id` integer Required The unique identifier of the job.
### [HTTP response status codes for "Get a job for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a job for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#get-a-job-for-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/jobs/{job_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/jobs/JOB_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 399444496,   "run_id": 29679449,   "run_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/29679449",   "node_id": "MDEyOldvcmtmbG93IEpvYjM5OTQ0NDQ5Ng==",   "head_sha": "f83a356604ae3c5d03e1b46ef4d1ca77d64a90b0",   "url": "https://api.github.com/repos/octo-org/octo-repo/actions/jobs/399444496",   "html_url": "https://github.com/octo-org/octo-repo/runs/29679449/jobs/399444496",   "status": "completed",   "conclusion": "success",   "started_at": "2020-01-20T17:42:40Z",   "completed_at": "2020-01-20T17:44:39Z",   "name": "build",   "steps": [     {       "name": "Set up job",       "status": "completed",       "conclusion": "success",       "number": 1,       "started_at": "2020-01-20T09:42:40.000-08:00",       "completed_at": "2020-01-20T09:42:41.000-08:00"     },     {       "name": "Run actions/checkout@v2",       "status": "completed",       "conclusion": "success",       "number": 2,       "started_at": "2020-01-20T09:42:41.000-08:00",       "completed_at": "2020-01-20T09:42:45.000-08:00"     },     {       "name": "Set up Ruby",       "status": "completed",       "conclusion": "success",       "number": 3,       "started_at": "2020-01-20T09:42:45.000-08:00",       "completed_at": "2020-01-20T09:42:45.000-08:00"     },     {       "name": "Run actions/cache@v3",       "status": "completed",       "conclusion": "success",       "number": 4,       "started_at": "2020-01-20T09:42:45.000-08:00",       "completed_at": "2020-01-20T09:42:48.000-08:00"     },     {       "name": "Install Bundler",       "status": "completed",       "conclusion": "success",       "number": 5,       "started_at": "2020-01-20T09:42:48.000-08:00",       "completed_at": "2020-01-20T09:42:52.000-08:00"     },     {       "name": "Install Gems",       "status": "completed",       "conclusion": "success",       "number": 6,       "started_at": "2020-01-20T09:42:52.000-08:00",       "completed_at": "2020-01-20T09:42:53.000-08:00"     },     {       "name": "Run Tests",       "status": "completed",       "conclusion": "success",       "number": 7,       "started_at": "2020-01-20T09:42:53.000-08:00",       "completed_at": "2020-01-20T09:42:59.000-08:00"     },     {       "name": "Deploy to Heroku",       "status": "completed",       "conclusion": "success",       "number": 8,       "started_at": "2020-01-20T09:42:59.000-08:00",       "completed_at": "2020-01-20T09:44:39.000-08:00"     },     {       "name": "Post actions/cache@v3",       "status": "completed",       "conclusion": "success",       "number": 16,       "started_at": "2020-01-20T09:44:39.000-08:00",       "completed_at": "2020-01-20T09:44:39.000-08:00"     },     {       "name": "Complete job",       "status": "completed",       "conclusion": "success",       "number": 17,       "started_at": "2020-01-20T09:44:39.000-08:00",       "completed_at": "2020-01-20T09:44:39.000-08:00"     }   ],   "check_run_url": "https://api.github.com/repos/octo-org/octo-repo/check-runs/399444496",   "labels": [     "self-hosted",     "foo",     "bar"   ],   "runner_id": 1,   "runner_name": "my runner",   "runner_group_id": 2,   "runner_group_name": "my runner group",   "workflow_name": "CI",   "head_branch": "main" }`
## [Download job logs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run)
Gets a redirect URL to download a plain text file of logs for a workflow job. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download.
Anyone with read access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Download job logs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Download job logs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`job_id` integer Required The unique identifier of the job.
### [HTTP response status codes for "Download job logs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run--status-codes)
Status code | Description
---|---
`302` | Found
### [Code samples for "Download job logs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#download-job-logs-for-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/jobs/{job_id}/logs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/jobs/JOB_ID/logs`
Response
`Status: 302`
## [List jobs for a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt)
Lists jobs for a specific workflow run attempt. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters).
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "List jobs for a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List jobs for a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
`attempt_number` integer Required The attempt number of the workflow run.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List jobs for a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List jobs for a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run-attempt--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/jobs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/attempts/ATTEMPT_NUMBER/jobs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "jobs": [     {       "id": 399444496,       "run_id": 29679449,       "run_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/29679449",       "node_id": "MDEyOldvcmtmbG93IEpvYjM5OTQ0NDQ5Ng==",       "head_sha": "f83a356604ae3c5d03e1b46ef4d1ca77d64a90b0",       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/jobs/399444496",       "html_url": "https://github.com/octo-org/octo-repo/runs/29679449/jobs/399444496",       "status": "completed",       "conclusion": "success",       "started_at": "2020-01-20T17:42:40Z",       "completed_at": "2020-01-20T17:44:39Z",       "name": "build",       "steps": [         {           "name": "Set up job",           "status": "completed",           "conclusion": "success",           "number": 1,           "started_at": "2020-01-20T09:42:40.000-08:00",           "completed_at": "2020-01-20T09:42:41.000-08:00"         },         {           "name": "Run actions/checkout@v2",           "status": "completed",           "conclusion": "success",           "number": 2,           "started_at": "2020-01-20T09:42:41.000-08:00",           "completed_at": "2020-01-20T09:42:45.000-08:00"         },         {           "name": "Set up Ruby",           "status": "completed",           "conclusion": "success",           "number": 3,           "started_at": "2020-01-20T09:42:45.000-08:00",           "completed_at": "2020-01-20T09:42:45.000-08:00"         },         {           "name": "Run actions/cache@v3",           "status": "completed",           "conclusion": "success",           "number": 4,           "started_at": "2020-01-20T09:42:45.000-08:00",           "completed_at": "2020-01-20T09:42:48.000-08:00"         },         {           "name": "Install Bundler",           "status": "completed",           "conclusion": "success",           "number": 5,           "started_at": "2020-01-20T09:42:48.000-08:00",           "completed_at": "2020-01-20T09:42:52.000-08:00"         },         {           "name": "Install Gems",           "status": "completed",           "conclusion": "success",           "number": 6,           "started_at": "2020-01-20T09:42:52.000-08:00",           "completed_at": "2020-01-20T09:42:53.000-08:00"         },         {           "name": "Run Tests",           "status": "completed",           "conclusion": "success",           "number": 7,           "started_at": "2020-01-20T09:42:53.000-08:00",           "completed_at": "2020-01-20T09:42:59.000-08:00"         },         {           "name": "Deploy to Heroku",           "status": "completed",           "conclusion": "success",           "number": 8,           "started_at": "2020-01-20T09:42:59.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         },         {           "name": "Post actions/cache@v3",           "status": "completed",           "conclusion": "success",           "number": 16,           "started_at": "2020-01-20T09:44:39.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         },         {           "name": "Complete job",           "status": "completed",           "conclusion": "success",           "number": 17,           "started_at": "2020-01-20T09:44:39.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         }       ],       "check_run_url": "https://api.github.com/repos/octo-org/octo-repo/check-runs/399444496",       "labels": [         "self-hosted",         "foo",         "bar"       ],       "runner_id": 1,       "runner_name": "my runner",       "runner_group_id": 2,       "runner_group_name": "my runner group",       "workflow_name": "CI",       "head_branch": "main"     }   ] }`
## [List jobs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run)
Lists jobs for a workflow run. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters).
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "List jobs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List jobs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
Query parameters Name, Type, Description
---
`filter` string Filters jobs by their `completed_at` timestamp. `latest` returns jobs from the most recent execution of the workflow run. `all` returns all jobs for a workflow run, including from old executions of the workflow run. Default: `latest` Can be one of: `latest`, `all`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List jobs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List jobs for a workflow run"](https://docs.github.com/en/rest/actions/workflow-jobs?apiVersion=2022-11-28#list-jobs-for-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/jobs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/jobs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "jobs": [     {       "id": 399444496,       "run_id": 29679449,       "run_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/29679449",       "node_id": "MDEyOldvcmtmbG93IEpvYjM5OTQ0NDQ5Ng==",       "head_sha": "f83a356604ae3c5d03e1b46ef4d1ca77d64a90b0",       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/jobs/399444496",       "html_url": "https://github.com/octo-org/octo-repo/runs/29679449/jobs/399444496",       "status": "completed",       "conclusion": "success",       "started_at": "2020-01-20T17:42:40Z",       "completed_at": "2020-01-20T17:44:39Z",       "name": "build",       "steps": [         {           "name": "Set up job",           "status": "completed",           "conclusion": "success",           "number": 1,           "started_at": "2020-01-20T09:42:40.000-08:00",           "completed_at": "2020-01-20T09:42:41.000-08:00"         },         {           "name": "Run actions/checkout@v2",           "status": "completed",           "conclusion": "success",           "number": 2,           "started_at": "2020-01-20T09:42:41.000-08:00",           "completed_at": "2020-01-20T09:42:45.000-08:00"         },         {           "name": "Set up Ruby",           "status": "completed",           "conclusion": "success",           "number": 3,           "started_at": "2020-01-20T09:42:45.000-08:00",           "completed_at": "2020-01-20T09:42:45.000-08:00"         },         {           "name": "Run actions/cache@v3",           "status": "completed",           "conclusion": "success",           "number": 4,           "started_at": "2020-01-20T09:42:45.000-08:00",           "completed_at": "2020-01-20T09:42:48.000-08:00"         },         {           "name": "Install Bundler",           "status": "completed",           "conclusion": "success",           "number": 5,           "started_at": "2020-01-20T09:42:48.000-08:00",           "completed_at": "2020-01-20T09:42:52.000-08:00"         },         {           "name": "Install Gems",           "status": "completed",           "conclusion": "success",           "number": 6,           "started_at": "2020-01-20T09:42:52.000-08:00",           "completed_at": "2020-01-20T09:42:53.000-08:00"         },         {           "name": "Run Tests",           "status": "completed",           "conclusion": "success",           "number": 7,           "started_at": "2020-01-20T09:42:53.000-08:00",           "completed_at": "2020-01-20T09:42:59.000-08:00"         },         {           "name": "Deploy to Heroku",           "status": "completed",           "conclusion": "success",           "number": 8,           "started_at": "2020-01-20T09:42:59.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         },         {           "name": "Post actions/cache@v3",           "status": "completed",           "conclusion": "success",           "number": 16,           "started_at": "2020-01-20T09:44:39.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         },         {           "name": "Complete job",           "status": "completed",           "conclusion": "success",           "number": 17,           "started_at": "2020-01-20T09:44:39.000-08:00",           "completed_at": "2020-01-20T09:44:39.000-08:00"         }       ],       "check_run_url": "https://api.github.com/repos/octo-org/octo-repo/check-runs/399444496",       "labels": [         "self-hosted",         "foo",         "bar"       ],       "runner_id": 1,       "runner_name": "my runner",       "runner_group_id": 2,       "runner_group_name": "my runner group",       "workflow_name": "CI",       "head_branch": "main"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/workflow-jobs.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for workflow jobs - GitHub Docs
