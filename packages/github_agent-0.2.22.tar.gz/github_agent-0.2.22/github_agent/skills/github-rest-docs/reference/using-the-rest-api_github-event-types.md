[Skip to main content](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Using the REST API](https://docs.github.com/en/rest/using-the-rest-api "Using the REST API")/
  * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types "GitHub event types")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Using the REST API](https://docs.github.com/en/rest/using-the-rest-api "Using the REST API")/
  * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types "GitHub event types")


# GitHub event types
For the GitHub Events API, learn about each event type, the triggering action on GitHub, and each event's unique properties.
## In this article
  * [Event object common properties](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties)
  * [CommitCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#commitcommentevent)
  * [CreateEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#createevent)
  * [DeleteEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#deleteevent)
  * [DiscussionEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#discussionevent)
  * [ForkEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#forkevent)
  * [GollumEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#gollumevent)
  * [IssueCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#issuecommentevent)
  * [IssuesEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#issuesevent)
  * [MemberEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#memberevent)
  * [PublicEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#publicevent)
  * [PullRequestEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestevent)
  * [PullRequestReviewEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestreviewevent)
  * [PullRequestReviewCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestreviewcommentevent)
  * [PushEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pushevent)
  * [ReleaseEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#releaseevent)
  * [WatchEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#watchevent)


The Events API can return different types of events triggered by activity on GitHub. Each event response contains shared properties, but has a unique `payload` object determined by its event type. The [Event object common properties](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) describes the properties shared by all events, and each event type describes the `payload` properties that are unique to the specific event.
## [Event object common properties](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties)
The event objects returned from the Events API endpoints have the same structure.
Event API attribute name | Type | Description
---|---|---
`id` | `integer` | Unique identifier for the event.
`type` | `string` | The type of event. Events uses PascalCase for the name.
`actor` | `object` | The user that triggered the event.
`actor.id` | `integer` | The unique identifier for the actor.
`actor.login` | `string` | The username of the actor.
`actor.display_login` | `string` | The specific display format of the username.
`actor.gravatar_id` | `string` | The unique identifier of the Gravatar profile for the actor.
`actor.url` | `string` | The REST API URL used to retrieve the user object, which includes additional user information.
`actor.avatar_url` | `string` | The URL of the actor's profile image.
`repo` | `object` | The repository object where the event occurred.
`repo.id` | `integer` | The unique identifier of the repository.
`repo.name` | `string` | The name of the repository, which includes the owner and repository name. For example, `octocat/hello-world` is the name of the `hello-world` repository owned by the `octocat` personal account.
`repo.url` | `string` | The REST API URL used to retrieve the repository object, which includes additional repository information.
`payload` | `object` | The event payload object is unique to the event type. See the event type below for the event API `payload` object.
`public` | `boolean` | Whether the event is visible to all users.
`created_at` | `string` | The date and time when the event was triggered. It is formatted according to ISO 8601.
`org` | `object` | The organization that was chosen by the actor to perform action that triggers the event.
_The property appears in the event object only if it is applicable._
`org.id` | `integer` | The unique identifier for the organization.
`org.login` | `string` | The name of the organization.
`org.gravatar_id` | `string` | The unique identifier of the Gravatar profile for the organization.
`org.url` | `string` | The REST API URL used to retrieve the organization object, which includes additional organization information.
`org.avatar_url` | `string` | The URL of the organization's profile image.
### [Example WatchEvent event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#example-watchevent-event-object)
This example shows the format of the [WatchEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#watchevent) response when using the [Events API](https://docs.github.com/en/rest/activity/events).
```
HTTP/2 200
Link: <https://api.github.com/resource?page=2>; rel="next",
      <https://api.github.com/resource?page=5>; rel="last"

```
```
[
  {
    "id": "12345",
    "type": "WatchEvent",
    "actor": {
      "id": 1,
      "login": "octocat",
      "display_login": "octocat",
      "gravatar_id": "",
      "url": "https://api.github.com/users/octocat",
      "avatar_url": "https://github.com/images/error/octocat_happy.gif"
    },
    "repo": {
      "id": 3,
      "name": "octocat/Hello-World",
      "url": "https://api.github.com/repos/octocat/Hello-World"
    },
    "payload": {
      "action": "started"
    },
    "public": false,
    "created_at": "2011-09-06T17:26:27Z",
    "org": {
      "id": 1,
      "login": "github",
      "gravatar_id": "",
      "url": "https://api.github.com/orgs/github",
      "avatar_url": "https://github.com/images/error/octocat_happy.gif"
    },
  }
]

```

## [CommitCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#commitcommentevent)
A commit comment is created. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for commit comments](https://docs.github.com/en/rest/commits/comments).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for CommitCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-commitcommentevent)
Key | Type | Description
---|---|---
`action` | `string` | The action performed. Can be `created`.
`comment` | `object` | The [commit comment](https://docs.github.com/en/rest/commits#get-a-commit-comment) resource.
## [CreateEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#createevent)
A Git branch or tag is created. For more information, see [REST API endpoints for Git database](https://docs.github.com/en/rest/git#create-a-reference).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for CreateEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-createevent)
Key | Type | Description
---|---|---
`ref` | `string` | The [`git ref`](https://docs.github.com/en/rest/git#get-a-reference) resource branch, or `null` if `ref_type` is `repository`.
`ref_type` | `string` | The type of Git ref object created in the repository. Can be either `branch`, `tag`, or `repository`.
`full_ref` | `string` | The fully-formed ref resource, meaning that for branches the format is `refs/heads/<branch_name>`.
`master_branch` | `string` | The name of the repository's default branch (usually `main`).
`description` | `string` | The repository's current description.
`pusher_type` | `string` | Can be either `user` or a deploy key.
## [DeleteEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#deleteevent)
A Git branch or tag is deleted. For more information, see the [REST API endpoints for Git database](https://docs.github.com/en/rest/git#delete-a-reference) REST API.
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for DeleteEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-deleteevent)
Key | Type | Description
---|---|---
`ref` | `string` | The [`git ref`](https://docs.github.com/en/rest/git#get-a-reference) resource branch.
`ref_type` | `string` | The type of Git ref object deleted in the repository. Can be either `branch` or `tag`.
`full_ref` | `string` | The fully-formed ref resource, meaning that for branches the format is `refs/heads/<branch_name>`.
`pusher_type` | `string` | Can be either `user` or a deploy key.
## [DiscussionEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#discussionevent)
A discussion is created in a repository. For more information, see [GitHub Discussions documentation](https://docs.github.com/en/discussions).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for DiscussionEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-discussionevent)
Key | Type | Description
---|---|---
`action` | `string` | The action performed. Can be `created`.
`discussion` | `object` | The discussion that was created.
## [ForkEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#forkevent)
A user forks a repository. For more information, see [REST API endpoints for repositories](https://docs.github.com/en/rest/repos#forks).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for ForkEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-forkevent)
Key | Type | Description
---|---|---
`action` | `string` | The action performed. Can be `forked`.
`forkee` | `object` | The created [`repository`](https://docs.github.com/en/rest/repos#get-a-repository) resource.
## [GollumEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#gollumevent)
A wiki page is created or updated. For more information, see [About wikis](https://docs.github.com/en/communities/documenting-your-project-with-wikis/about-wikis).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for GollumEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-gollumevent)
Key | Type | Description
---|---|---
`pages` | `array` | The pages that were updated.
`pages[][page_name]` | `string` | The name of the page.
`pages[][title]` | `string` | The current page title.
`pages[][summary]` | `string` | An optional note about the page. Can be `null`.
`pages[][action]` | `string` | The action that was performed on the page. Can be `created` or `edited`.
`pages[][sha]` | `string` | The latest commit SHA of the page.
`pages[][html_url]` | `string` | Points to the HTML wiki page.
## [IssueCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#issuecommentevent)
Activity related to an issue or pull request comment. The type of activity is specified in the `action` property of the payload object. For more information, see the [REST API endpoints for issues](https://docs.github.com/en/rest/issues#comments).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for IssueCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-issuecommentevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed on the comment. Can be `created`.
`issue` | `object` | The [issue](https://docs.github.com/en/rest/issues) the comment belongs to.
`comment` | `object` | The [comment](https://docs.github.com/en/rest/issues#comments) itself.
## [IssuesEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#issuesevent)
Activity related to an issue. The type of activity is specified in the `action` property of the payload object. For more information, see the [REST API endpoints for issues](https://docs.github.com/en/rest/issues).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for IssuesEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-issuesevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Can be one of `opened`, `closed`, `reopened`.
`issue` | `object` | The [issue](https://docs.github.com/en/rest/issues) itself.
`assignee` | `object` | The optional user who was assigned or unassigned from the issue.
`assignees` | `array` | The optional array of assignee objects detailing the assignees on the issue.
`label` | `object` | The optional label that was added or removed from the issue.
`labels` | `array` | The optional array of label objects describing the labels on the issue.
## [MemberEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#memberevent)
Activity related to repository collaborators. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for collaborators](https://docs.github.com/en/rest/collaborators/collaborators).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for MemberEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-memberevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Can be `added` to indicate a user accepted an invitation to a repository.
`member` | `object` | The [user](https://docs.github.com/en/rest/users) that was added.
## [PublicEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#publicevent)
When a private repository is made public.
### [Event `payload` object for PublicEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-publicevent)
This event returns an empty `payload` object.
## [PullRequestEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestevent)
Activity related to pull requests. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for pull requests](https://docs.github.com/en/rest/pulls).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for PullRequestEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-pullrequestevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Can be one of `opened`, `closed`, `merged`, `reopened`, `assigned`, `unassigned`, `labeled`, or `unlabeled`.
`number` | `integer` | The pull request number.
`pull_request` | `object` | The [pull request](https://docs.github.com/en/rest/pulls) itself.
`assignee` | `object` | The optional user who was assigned or unassigned from the issue.
`assignees` | `array` | The optional array of assignee objects detailing the assignees on the issue.
`label` | `object` | The optional label that was added or removed from the issue if the action was `labeled` or `unlabeled`.
`labels` | `array` | The optional array of label objects describing the labels on the pull request if the action was `labeled` or `unlabeled`.
## [PullRequestReviewEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestreviewevent)
Activity related to pull request reviews. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for pull requests](https://docs.github.com/en/rest/pulls#reviews).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for PullRequestReviewEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-pullrequestreviewevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Can be `created`, `updated`, or `dismissed`.
`pull_request` | `object` | The [pull request](https://docs.github.com/en/rest/pulls) the review pertains to.
`review` | `object` | The [review](https://docs.github.com/en/rest/pulls) that was affected.
## [PullRequestReviewCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pullrequestreviewcommentevent)
Activity related to pull request review comments in the pull request's unified diff. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for pull requests](https://docs.github.com/en/rest/pulls#comments).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for PullRequestReviewCommentEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-pullrequestreviewcommentevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed on the comment. Can be `created`.
`pull_request` | `object` | The [pull request](https://docs.github.com/en/rest/pulls) the comment belongs to.
`comment` | `object` | The [comment](https://docs.github.com/en/rest/pulls#comments) itself.
## [PushEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#pushevent)
One or more commits are pushed to a repository branch or tag.
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for PushEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-pushevent)
Key | Type | Description
---|---|---
`repository_id` | `integer` | The unique identifier of the repository where the push occurred.
`push_id` | `integer` | The unique identifier for the push.
`ref` | `string` | The full [`git ref`](https://docs.github.com/en/rest/git/refs) that was pushed. Example: `refs/heads/main`.
`head` | `string` | The SHA of the most recent commit on `ref` after the push.
`before` | `string` | The SHA of the most recent commit on `ref` before the push.
## [ReleaseEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#releaseevent)
Activity related to a release. The type of activity is specified in the `action` property of the payload object. For more information, see the [REST API endpoints for releases and release assets](https://docs.github.com/en/rest/releases) REST API.
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for ReleaseEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-releaseevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Can be `published`.
`release` | `object` | The [release](https://docs.github.com/en/rest/releases/releases#get-a-release) object.
## [WatchEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#watchevent)
When someone stars a repository. The type of activity is specified in the `action` property of the payload object. For more information, see [REST API endpoints for activity](https://docs.github.com/en/rest/activity#starring).
The [event object](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-object-common-properties) includes properties that are common for all events. Each event object includes a `payload` property and the value is unique to each event type. The `payload` object for this event is described below.
### [Event `payload` object for WatchEvent](https://docs.github.com/en/rest/using-the-rest-api/github-event-types?apiVersion=2022-11-28#event-payload-object-for-watchevent)
Key | Type | Description
---|---|---
`action` | `string` | The action that was performed. Currently, can only be `started`.
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/using-the-rest-api/github-event-types.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


GitHub event types - GitHub Docs
