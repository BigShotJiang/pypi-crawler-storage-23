[Skip to main content](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflows](https://docs.github.com/en/rest/actions/workflows "Workflows")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
      * [About workflows in GitHub Actions](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#about-workflows-in-github-actions)
      * [List repository workflows](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows)
      * [Get a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow)
      * [Disable a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow)
      * [Create a workflow dispatch event](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event)
      * [Enable a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow)
      * [Get workflow usage](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage)
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflows](https://docs.github.com/en/rest/actions/workflows "Workflows")


# REST API endpoints for workflows
Use the REST API to interact with workflows in GitHub Actions.
## [About workflows in GitHub Actions](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#about-workflows-in-github-actions)
You can use the REST API to view workflows for a repository in GitHub Actions. Workflows automate your software development life cycle with a wide range of tools and services. For more information, see [Workflows](https://docs.github.com/en/actions/using-workflows/about-workflows) in the GitHub Actions documentation.
## [List repository workflows](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows)
Lists the workflows in a repository.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "List repository workflows"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository workflows"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository workflows"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository workflows"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#list-repository-workflows--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/workflows
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "workflows": [     {       "id": 161335,       "node_id": "MDg6V29ya2Zsb3cxNjEzMzU=",       "name": "CI",       "path": ".github/workflows/blank.yaml",       "state": "active",       "created_at": "2020-01-08T23:48:37.000-08:00",       "updated_at": "2020-01-08T23:50:21.000-08:00",       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/161335",       "html_url": "https://github.com/octo-org/octo-repo/blob/master/.github/workflows/161335",       "badge_url": "https://github.com/octo-org/octo-repo/workflows/CI/badge.svg"     },     {       "id": 269289,       "node_id": "MDE4OldvcmtmbG93IFNlY29uZGFyeTI2OTI4OQ==",       "name": "Linter",       "path": ".github/workflows/linter.yaml",       "state": "active",       "created_at": "2020-01-08T23:48:37.000-08:00",       "updated_at": "2020-01-08T23:50:21.000-08:00",       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/269289",       "html_url": "https://github.com/octo-org/octo-repo/blob/master/.github/workflows/269289",       "badge_url": "https://github.com/octo-org/octo-repo/workflows/Linter/badge.svg"     }   ] }`
## [Get a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow)
Gets a specific workflow. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
### [HTTP response status codes for "Get a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-a-workflow--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/workflows/{workflow_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 161335,   "node_id": "MDg6V29ya2Zsb3cxNjEzMzU=",   "name": "CI",   "path": ".github/workflows/blank.yaml",   "state": "active",   "created_at": "2020-01-08T23:48:37.000-08:00",   "updated_at": "2020-01-08T23:50:21.000-08:00",   "url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/161335",   "html_url": "https://github.com/octo-org/octo-repo/blob/master/.github/workflows/161335",   "badge_url": "https://github.com/octo-org/octo-repo/workflows/CI/badge.svg" }`
## [Disable a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow)
Disables a workflow and sets the `state` of the workflow to `disabled_manually`. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Disable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Disable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
### [HTTP response status codes for "Disable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Disable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#disable-a-workflow--code-samples)
#### Request example
put/repos/{owner}/{repo}/actions/workflows/{workflow_id}/disable
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID/disable`
Response
`Status: 204`
## [Create a workflow dispatch event](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event)
You can use this endpoint to manually trigger a GitHub Actions workflow run. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`.
You must configure your GitHub Actions workflow to run when the [`workflow_dispatch` webhook](https://docs.github.com/developers/webhooks-and-events/webhook-events-and-payloads#workflow_dispatch) event occurs. The `inputs` are configured in the workflow file. For more information about how to configure the `workflow_dispatch` event in the workflow file, see "[Events that trigger workflows](https://docs.github.com/actions/reference/events-that-trigger-workflows#workflow_dispatch)."
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a workflow dispatch event"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Create a workflow dispatch event"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
Body parameters Name, Type, Description
---
`ref` string Required The git reference for the workflow. The reference can be a branch or tag name.
`inputs` object Input keys and values configured in the workflow file. The maximum number of properties is 25. Any default properties configured in the workflow file will be used when `inputs` are omitted.
`return_run_details` boolean Whether the response should include the workflow run ID and URLs.
### [HTTP response status codes for "Create a workflow dispatch event"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event--status-codes)
Status code | Description
---|---
`200` | Response including the workflow run ID and URLs when `return_run_details` parameter is `true`.
`204` | Empty response when `return_run_details` parameter is `false`.
### [Code samples for "Create a workflow dispatch event"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#create-a-workflow-dispatch-event--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID/dispatches \   -d '{"ref":"topic-branch","inputs":{"name":"Mona the Octocat","home":"San Francisco, CA"}}'`
Response including the workflow run ID and URLs when `return_run_details` parameter is `true`.
  * Example response
  * Response schema


`Status: 200`
`{   "workflow_run_id": 1,   "run_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/1",   "html_url": "https://github.com/octo-org/octo-repo/actions/runs/1" }`
## [Enable a workflow](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow)
Enables a workflow and sets the `state` of the workflow to `active`. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Enable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Enable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
### [HTTP response status codes for "Enable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Enable a workflow"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#enable-a-workflow--code-samples)
#### Request example
put/repos/{owner}/{repo}/actions/workflows/{workflow_id}/enable
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID/enable`
Response
`Status: 204`
## [Get workflow usage](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage)

This endpoint is in the process of closing down. Refer to "[Actions Get workflow usage and Get workflow run usage endpoints closing down](https://github.blog/changelog/2025-02-02-actions-get-workflow-usage-and-get-workflow-run-usage-endpoints-closing-down/)" for more information.
Gets the number of billable minutes used by a specific workflow during the current billing cycle. Billable minutes only apply to workflows in private repositories that use GitHub-hosted runners. Usage is listed for each GitHub-hosted runner operating system in milliseconds. Any job re-runs are also included in the usage. The usage does not include the multiplier for macOS and Windows runners and is not rounded up to the nearest whole minute. For more information, see "[Managing billing for GitHub Actions](https://docs.github.com/github/setting-up-and-managing-billing-and-payments-on-github/managing-billing-for-github-actions)".
You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get workflow usage"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get workflow usage"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
### [HTTP response status codes for "Get workflow usage"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get workflow usage"](https://docs.github.com/en/rest/actions/workflows?apiVersion=2022-11-28#get-workflow-usage--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/workflows/{workflow_id}/timing
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID/timing`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "billable": {     "UBUNTU": {       "total_ms": 180000     },     "MACOS": {       "total_ms": 240000     },     "WINDOWS": {       "total_ms": 300000     }   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/workflows.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for workflows - GitHub Docs
