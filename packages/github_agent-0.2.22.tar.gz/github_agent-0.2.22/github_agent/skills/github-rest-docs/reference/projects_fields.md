[Skip to main content](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Projects](https://docs.github.com/en/rest/projects "Projects")/
  * [Project fields](https://docs.github.com/en/rest/projects/fields "Project fields")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
      * [List project fields for organization](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization)
      * [Add a field to an organization-owned project.](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project)
      * [Get project field for organization](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization)
      * [List project fields for user](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user)
      * [Add field to user owned project](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project)
      * [Get project field for user](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user)
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Projects](https://docs.github.com/en/rest/projects "Projects")/
  * [Project fields](https://docs.github.com/en/rest/projects/fields "Project fields")


# REST API endpoints for Project fields
Use the REST API to manage Project fields
## [List project fields for organization](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization)
List all fields for a specific organization-owned project.
### [Fine-grained access tokens for "List project fields for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Projects" organization permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List project fields for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`project_number` integer Required The project's number.
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### [HTTP response status codes for "List project fields for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "List project fields for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-organization--code-samples)
#### Request example
get/orgs/{org}/projectsV2/{project_number}/fields
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/projectsV2/PROJECT_NUMBER/fields`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 12345,     "node_id": "PVTF_lADOABCD1234567890",     "name": "Priority",     "data_type": "single_select",     "project_url": "https://api.github.com/projects/67890",     "options": [       {         "id": "option_1",         "name": {           "html": "Low",           "raw": "Low"         },         "color": "GREEN",         "description": {           "html": "Low priority items",           "raw": "Low priority items"         }       },       {         "id": "option_2",         "name": {           "html": "Medium",           "raw": "Medium"         },         "color": "YELLOW",         "description": {           "html": "Medium priority items",           "raw": "Medium priority items"         }       },       {         "id": "option_3",         "name": {           "html": "High",           "raw": "High"         },         "color": "RED",         "description": {           "html": "High priority items",           "raw": "High priority items"         }       }     ],     "created_at": "2022-04-28T12:00:00Z",     "updated_at": "2022-04-28T12:00:00Z"   },   {     "id": 67891,     "node_id": "PVTF_lADOABCD9876543210",     "name": "Status",     "data_type": "single_select",     "project_url": "https://api.github.com/projects/67890",     "options": [       {         "id": "option_4",         "name": {           "html": "Todo",           "raw": "Todo"         },         "color": "GRAY",         "description": {           "html": "Items to be worked on",           "raw": "Items to be worked on"         }       },       {         "id": "option_5",         "name": {           "html": "In Progress",           "raw": "In Progress"         },         "color": "BLUE",         "description": {           "html": "Items currently being worked on",           "raw": "Items currently being worked on"         }       },       {         "id": "option_6",         "name": {           "html": "Done",           "raw": "Done"         },         "color": "GREEN",         "description": {           "html": "Completed items",           "raw": "Completed items"         }       }     ],     "created_at": "2022-04-29T10:30:00Z",     "updated_at": "2022-04-29T10:30:00Z"   },   {     "id": 24680,     "node_id": "PVTF_lADOABCD2468024680",     "name": "Team notes",     "data_type": "text",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-05-15T08:00:00Z",     "updated_at": "2022-05-15T08:00:00Z"   },   {     "id": 13579,     "node_id": "PVTF_lADOABCD1357913579",     "name": "Story points",     "data_type": "number",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-06-01T14:30:00Z",     "updated_at": "2022-06-01T14:30:00Z"   },   {     "id": 98765,     "node_id": "PVTF_lADOABCD9876598765",     "name": "Due date",     "data_type": "date",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-06-10T09:15:00Z",     "updated_at": "2022-06-10T09:15:00Z"   },   {     "id": 11223,     "node_id": "PVTF_lADOABCD1122311223",     "name": "Sprint",     "data_type": "iteration",     "project_url": "https://api.github.com/projects/67890",     "configuration": {       "duration": 14,       "start_day": 1,       "iterations": [         {           "id": "iter_1",           "title": {             "html": "Sprint 1",             "raw": "Sprint 1"           },           "start_date": "2022-07-01",           "duration": 14         },         {           "id": "iter_2",           "title": {             "html": "Sprint 2",             "raw": "Sprint 2"           },           "start_date": "2022-07-15",           "duration": 14         }       ]     },     "created_at": "2022-06-20T16:45:00Z",     "updated_at": "2022-06-20T16:45:00Z"   } ]`
## [Add a field to an organization-owned project.](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project)
Add a field to an organization-owned project.
### [Fine-grained access tokens for "Add a field to an organization-owned project."](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Projects" organization permissions (write)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Add a field to an organization-owned project."](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`project_number` integer Required The project's number.
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`issue_field_id` integer Required The ID of the IssueField to create the field for.
`name` string Required The name of the field.
`data_type` string Required The field's data type. Value: `iteration`
`single_select_options` array of objects The options available for single select fields. At least one option must be provided when creating a single select field.
Properties of `single_select_options` | Name, Type, Description
---
`name` string The display name of the option.
`color` string The color associated with the option. Can be one of: `BLUE`, `GRAY`, `GREEN`, `ORANGE`, `PINK`, `PURPLE`, `RED`, `YELLOW`
`description` string The description of the option.
`iteration_configuration` object Required The configuration for iteration fields.
Properties of `iteration_configuration` | Name, Type, Description
---
`start_date` string The start date of the first iteration.
`duration` integer The default duration for iterations in days. Individual iterations can override this value.
`iterations` array of objects Zero or more iterations for the field.
Properties of `iterations` | Name, Type, Description
---
`title` string The title of the iteration.
`start_date` string The start date of the iteration.
`duration` integer The duration of the iteration in days.
### [HTTP response status codes for "Add a field to an organization-owned project."](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project--status-codes)
Status code | Description
---|---
`201` | Response for adding a field to an organization-owned project.
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add a field to an organization-owned project."](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-a-field-to-an-organization-owned-project--code-samples)
#### Request examples
Select the example typeCreate a text field Create a number field Create a date field Create a single select field Create an iteration field
post/orgs/{org}/projectsV2/{project_number}/fields
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/projectsV2/PROJECT_NUMBER/fields \   -d '{"name":"Team notes","data_type":"text"}'`
Response for adding a field to an organization-owned project.
  * Example response
  * Response schema


`Status: 201`
`{   "id": 24680,   "node_id": "PVTF_lADOABCD2468024680",   "name": "Team notes",   "data_type": "text",   "project_url": "https://api.github.com/projects/67890",   "created_at": "2022-05-15T08:00:00Z",   "updated_at": "2022-05-15T08:00:00Z" }`
## [Get project field for organization](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization)
Get a specific field for an organization-owned project.
### [Fine-grained access tokens for "Get project field for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Projects" organization permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get project field for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`project_number` integer Required The project's number.
`field_id` integer Required The unique identifier of the field.
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get project field for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "Get project field for organization"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-organization--code-samples)
#### Request example
get/orgs/{org}/projectsV2/{project_number}/fields/{field_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/projectsV2/PROJECT_NUMBER/fields/FIELD_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 12345,   "node_id": "PVTF_lADOABCD1234567890",   "name": "Priority",   "data_type": "single_select",   "project_url": "https://api.github.com/projects/67890",   "options": [     {       "id": "option_1",       "name": {         "html": "Low",         "raw": "Low"       },       "color": "GREEN",       "description": {         "html": "Low priority items",         "raw": "Low priority items"       }     },     {       "id": "option_2",       "name": {         "html": "Medium",         "raw": "Medium"       },       "color": "YELLOW",       "description": {         "html": "Medium priority items",         "raw": "Medium priority items"       }     },     {       "id": "option_3",       "name": {         "html": "High",         "raw": "High"       },       "color": "RED",       "description": {         "html": "High priority items",         "raw": "High priority items"       }     }   ],   "created_at": "2022-04-28T12:00:00Z",   "updated_at": "2022-04-28T12:00:00Z" }`
## [List project fields for user](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user)
List all fields for a specific user-owned project.
### [Fine-grained access tokens for "List project fields for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List project fields for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`project_number` integer Required The project's number.
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### [HTTP response status codes for "List project fields for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "List project fields for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#list-project-fields-for-user--code-samples)
#### Request example
get/users/{username}/projectsV2/{project_number}/fields
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/projectsV2/PROJECT_NUMBER/fields`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 12345,     "node_id": "PVTF_lADOABCD1234567890",     "name": "Priority",     "data_type": "single_select",     "project_url": "https://api.github.com/projects/67890",     "options": [       {         "id": "option_1",         "name": {           "html": "Low",           "raw": "Low"         },         "color": "GREEN",         "description": {           "html": "Low priority items",           "raw": "Low priority items"         }       },       {         "id": "option_2",         "name": {           "html": "Medium",           "raw": "Medium"         },         "color": "YELLOW",         "description": {           "html": "Medium priority items",           "raw": "Medium priority items"         }       },       {         "id": "option_3",         "name": {           "html": "High",           "raw": "High"         },         "color": "RED",         "description": {           "html": "High priority items",           "raw": "High priority items"         }       }     ],     "created_at": "2022-04-28T12:00:00Z",     "updated_at": "2022-04-28T12:00:00Z"   },   {     "id": 67891,     "node_id": "PVTF_lADOABCD9876543210",     "name": "Status",     "data_type": "single_select",     "project_url": "https://api.github.com/projects/67890",     "options": [       {         "id": "option_4",         "name": {           "html": "Todo",           "raw": "Todo"         },         "color": "GRAY",         "description": {           "html": "Items to be worked on",           "raw": "Items to be worked on"         }       },       {         "id": "option_5",         "name": {           "html": "In Progress",           "raw": "In Progress"         },         "color": "BLUE",         "description": {           "html": "Items currently being worked on",           "raw": "Items currently being worked on"         }       },       {         "id": "option_6",         "name": {           "html": "Done",           "raw": "Done"         },         "color": "GREEN",         "description": {           "html": "Completed items",           "raw": "Completed items"         }       }     ],     "created_at": "2022-04-29T10:30:00Z",     "updated_at": "2022-04-29T10:30:00Z"   },   {     "id": 24680,     "node_id": "PVTF_lADOABCD2468024680",     "name": "Team notes",     "data_type": "text",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-05-15T08:00:00Z",     "updated_at": "2022-05-15T08:00:00Z"   },   {     "id": 13579,     "node_id": "PVTF_lADOABCD1357913579",     "name": "Story points",     "data_type": "number",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-06-01T14:30:00Z",     "updated_at": "2022-06-01T14:30:00Z"   },   {     "id": 98765,     "node_id": "PVTF_lADOABCD9876598765",     "name": "Due date",     "data_type": "date",     "project_url": "https://api.github.com/projects/67890",     "created_at": "2022-06-10T09:15:00Z",     "updated_at": "2022-06-10T09:15:00Z"   },   {     "id": 11223,     "node_id": "PVTF_lADOABCD1122311223",     "name": "Sprint",     "data_type": "iteration",     "project_url": "https://api.github.com/projects/67890",     "configuration": {       "duration": 14,       "start_day": 1,       "iterations": [         {           "id": "iter_1",           "title": {             "html": "Sprint 1",             "raw": "Sprint 1"           },           "start_date": "2022-07-01",           "duration": 14         },         {           "id": "iter_2",           "title": {             "html": "Sprint 2",             "raw": "Sprint 2"           },           "start_date": "2022-07-15",           "duration": 14         }       ]     },     "created_at": "2022-06-20T16:45:00Z",     "updated_at": "2022-06-20T16:45:00Z"   } ]`
## [Add field to user owned project](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project)
Add a field to a specified user owned project.
### [Fine-grained access tokens for "Add field to user owned project"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Add field to user owned project"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
`project_number` integer Required The project's number.
Body parameters Name, Type, Description
---
`name` string Required The name of the field.
`data_type` string Required The field's data type. Value: `iteration`
`single_select_options` array of objects The options available for single select fields. At least one option must be provided when creating a single select field.
Properties of `single_select_options` | Name, Type, Description
---
`name` string The display name of the option.
`color` string The color associated with the option. Can be one of: `BLUE`, `GRAY`, `GREEN`, `ORANGE`, `PINK`, `PURPLE`, `RED`, `YELLOW`
`description` string The description of the option.
`iteration_configuration` object Required The configuration for iteration fields.
Properties of `iteration_configuration` | Name, Type, Description
---
`start_date` string The start date of the first iteration.
`duration` integer The default duration for iterations in days. Individual iterations can override this value.
`iterations` array of objects Zero or more iterations for the field.
Properties of `iterations` | Name, Type, Description
---
`title` string The title of the iteration.
`start_date` string The start date of the iteration.
`duration` integer The duration of the iteration in days.
### [HTTP response status codes for "Add field to user owned project"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project--status-codes)
Status code | Description
---|---
`201` | Created
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add field to user owned project"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#add-field-to-user-owned-project--code-samples)
#### Request examples
Select the example typeCreate a text field Create a number field Create a date field Create a single select field Create an iteration field
post/users/{username}/projectsV2/{project_number}/fields
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/projectsV2/PROJECT_NUMBER/fields \   -d '{"name":"Team notes","data_type":"text"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 24680,   "node_id": "PVTF_lADOABCD2468024680",   "name": "Team notes",   "data_type": "text",   "project_url": "https://api.github.com/projects/67890",   "created_at": "2022-05-15T08:00:00Z",   "updated_at": "2022-05-15T08:00:00Z" }`
## [Get project field for user](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user)
Get a specific field for a user-owned project.
### [Fine-grained access tokens for "Get project field for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get project field for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`project_number` integer Required The project's number.
`field_id` integer Required The unique identifier of the field.
`username` string Required The handle for the GitHub user account.
### [HTTP response status codes for "Get project field for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "Get project field for user"](https://docs.github.com/en/rest/projects/fields?apiVersion=2022-11-28#get-project-field-for-user--code-samples)
#### Request example
get/users/{username}/projectsV2/{project_number}/fields/{field_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/projectsV2/PROJECT_NUMBER/fields/FIELD_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 12345,   "node_id": "PVTF_lADOABCD1234567890",   "name": "Priority",   "data_type": "single_select",   "project_url": "https://api.github.com/projects/67890",   "options": [     {       "id": "option_1",       "name": {         "html": "Low",         "raw": "Low"       },       "color": "GREEN",       "description": {         "html": "Low priority items",         "raw": "Low priority items"       }     },     {       "id": "option_2",       "name": {         "html": "Medium",         "raw": "Medium"       },       "color": "YELLOW",       "description": {         "html": "Medium priority items",         "raw": "Medium priority items"       }     },     {       "id": "option_3",       "name": {         "html": "High",         "raw": "High"       },       "color": "RED",       "description": {         "html": "High priority items",         "raw": "High priority items"       }     }   ],   "created_at": "2022-04-28T12:00:00Z",   "updated_at": "2022-04-28T12:00:00Z" }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/projects/fields.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for Project fields - GitHub Docs
