[Skip to main content](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Campaigns](https://docs.github.com/en/rest/campaigns "Campaigns")/
  * [Security campaigns](https://docs.github.com/en/rest/campaigns/campaigns "Security campaigns")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
      * [List campaigns for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization)
      * [Create a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization)
      * [Get a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization)
      * [Update a campaign](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign)
      * [Delete a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization)
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Campaigns](https://docs.github.com/en/rest/campaigns "Campaigns")/
  * [Security campaigns](https://docs.github.com/en/rest/campaigns/campaigns "Security campaigns")


# REST API endpoints for security campaigns
Use the REST API to create and manage security campaigns for your organization.
These endpoints only interact with published campaigns. Draft campaigns cannot currently be viewed or managed through the API.
## [List campaigns for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization)
Lists campaigns in an organization.
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint.
### [Fine-grained access tokens for "List campaigns for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Campaigns" organization permissions (read)


### [Parameters for "List campaigns for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`state` string If specified, only campaigns with this state will be returned. Can be one of: `open`, `closed`
`sort` string The property by which to sort the results. Default: `created` Can be one of: `created`, `updated`, `ends_at`, `published`
### [HTTP response status codes for "List campaigns for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List campaigns for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#list-campaigns-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/campaigns
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/campaigns`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "number": 3,     "created_at": "2024-02-14T12:29:18Z",     "updated_at": "2024-02-14T12:29:18Z",     "name": "Critical CodeQL alert",     "description": "Address critical alerts before they are exploited to prevent breaches, protect sensitive data, and mitigate financial and reputational damage.",     "managers": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     ],     "ends_at": "2024-03-14T12:29:18Z",     "closed_at": null,     "state": "open"   },   {     "number": 4,     "created_at": "2024-03-30T12:29:18Z",     "updated_at": "2024-03-30T12:29:18Z",     "name": "Mitre top 10 KEV",     "description": "Remediate the MITRE Top 10 KEV (Known Exploited Vulnerabilities) to enhance security by addressing vulnerabilities actively exploited by attackers. This reduces risk, prevents breaches and can help protect sensitive data.",     "managers": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     ],     "ends_at": "2024-04-30T12:29:18Z",     "closed_at": null,     "state": "open"   } ]`
## [Create a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization)
Create a campaign for an organization.
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint.
Fine-grained tokens must have the "Code scanning alerts" repository permissions (read) on all repositories included in the campaign.
### [Fine-grained access tokens for "Create a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Campaigns" organization permissions (write)


### [Parameters for "Create a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Create a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`404` | Resource not found
`422` | Unprocessable Entity
`429` | Too Many Requests
`503` | Service unavailable
### [Code samples for "Create a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#create-a-campaign-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/campaigns
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/campaigns \   -d '{"name":"Critical CodeQL alerts","description":"Address critical alerts before they are exploited to prevent breaches, protect sensitive data, and mitigate financial and reputational damage.","managers":["octocat"],"ends_at":"2024-03-14T00:00:00Z","code_scanning_alerts":[{"repository_id":1296269,"alert_numbers":[1,2]}]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "number": 3,   "created_at": "2024-02-14T12:29:18Z",   "updated_at": "2024-02-14T12:29:18Z",   "name": "Critical CodeQL alert",   "description": "Address critical alerts before they are exploited to prevent breaches, protect sensitive data, and mitigate financial and reputational damage.",   "managers": [     {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   ],   "published_at": "2024-02-14T12:29:18Z",   "ends_at": "2024-03-14T12:29:18Z",   "closed_at": null,   "state": "open",   "alert_stats": {     "open_count": 10,     "closed_count": 3,     "in_progress_count": 3   } }`
## [Get a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization)
Gets a campaign for an organization.
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint.
### [Fine-grained access tokens for "Get a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Campaigns" organization permissions (read)


### [Parameters for "Get a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`campaign_number` integer Required The campaign number.
### [HTTP response status codes for "Get a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Unprocessable Entity
`503` | Service unavailable
### [Code samples for "Get a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#get-a-campaign-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/campaigns/{campaign_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/campaigns/CAMPAIGN_NUMBER`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "number": 3,   "created_at": "2024-02-14T12:29:18Z",   "updated_at": "2024-02-14T12:29:18Z",   "name": "Critical CodeQL alert",   "description": "Address critical alerts before they are exploited to prevent breaches, protect sensitive data, and mitigate financial and reputational damage.",   "managers": [     {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   ],   "published_at": "2024-02-14T12:29:18Z",   "ends_at": "2024-03-14T12:29:18Z",   "closed_at": null,   "state": "open",   "alert_stats": {     "open_count": 10,     "closed_count": 3,     "in_progress_count": 3   } }`
## [Update a campaign](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign)
Updates a campaign in an organization.
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint.
### [Fine-grained access tokens for "Update a campaign"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Campaigns" organization permissions (write)


### [Parameters for "Update a campaign"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`campaign_number` integer Required The campaign number.
Body parameters Name, Type, Description
---
`name` string The name of the campaign
`description` string A description for the campaign
`managers` array of strings The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied.
`team_managers` array of strings The slugs of the teams to set as the campaign managers.
`ends_at` string The end date and time of the campaign, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ.
`contact_link` string or null The contact link of the campaign. Must be a URI.
`state` string Indicates whether a campaign is open or closed Can be one of: `open`, `closed`
### [HTTP response status codes for "Update a campaign"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`404` | Resource not found
`422` | Unprocessable Entity
`503` | Service unavailable
### [Code samples for "Update a campaign"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#update-a-campaign--code-samples)
#### Request example
patch/orgs/{org}/campaigns/{campaign_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/campaigns/CAMPAIGN_NUMBER \   -d '{"name":"Critical CodeQL alerts"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "number": 3,   "created_at": "2024-02-14T12:29:18Z",   "updated_at": "2024-02-14T12:29:18Z",   "name": "Critical CodeQL alert",   "description": "Address critical alerts before they are exploited to prevent breaches, protect sensitive data, and mitigate financial and reputational damage.",   "managers": [     {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   ],   "published_at": "2024-02-14T12:29:18Z",   "ends_at": "2024-03-14T12:29:18Z",   "closed_at": null,   "state": "open",   "alert_stats": {     "open_count": 10,     "closed_count": 3,     "in_progress_count": 3   } }`
## [Delete a campaign for an organization](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization)
Deletes a campaign in an organization.
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Campaigns" organization permissions (write)


### [Parameters for "Delete a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`campaign_number` integer Required The campaign number.
### [HTTP response status codes for "Delete a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization--status-codes)
Status code | Description
---|---
`204` | Deletion successful
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Delete a campaign for an organization"](https://docs.github.com/en/rest/campaigns/campaigns?apiVersion=2022-11-28#delete-a-campaign-for-an-organization--code-samples)
#### Request example
delete/orgs/{org}/campaigns/{campaign_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/campaigns/CAMPAIGN_NUMBER`
Deletion successful
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/campaigns/campaigns.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for security campaigns - GitHub Docs
