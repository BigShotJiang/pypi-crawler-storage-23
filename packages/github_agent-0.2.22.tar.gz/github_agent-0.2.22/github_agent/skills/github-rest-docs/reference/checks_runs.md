[Skip to main content](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Checks](https://docs.github.com/en/rest/checks "Checks")/
  * [Check runs](https://docs.github.com/en/rest/checks/runs "Check runs")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
      * [Create a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run)
      * [Get a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run)
      * [Update a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run)
      * [List check run annotations](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations)
      * [Rerequest a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run)
      * [List check runs in a check suite](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite)
      * [List check runs for a Git reference](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference)
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Checks](https://docs.github.com/en/rest/checks "Checks")/
  * [Check runs](https://docs.github.com/en/rest/checks/runs "Check runs")


# REST API endpoints for check runs
Use the REST API to manage check runs.
Write permission for the REST API to interact with checks is only available to GitHub Apps. OAuth apps and authenticated users can view check runs and check suites, but they are not able to create them. If you aren't building a GitHub App, you might be interested in using the REST API to interact with [commit statuses](https://docs.github.com/en/rest/commits#commit-statuses).
## [Create a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run)
Creates a new check run for a specific commit in a repository.
To create a check run, you must use a GitHub App. OAuth apps and authenticated users are not able to create a check suite.
In a check suite, GitHub limits the number of check runs with the same name to 1000. Once these check runs exceed 1000, GitHub will start to automatically delete older check runs.
The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array.
### [Fine-grained access tokens for "Create a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Create a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`status` Required Value: `completed`
### [HTTP response status codes for "Create a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#create-a-check-run--code-samples)
#### Request examples
Select the example typeExample of an in_progress conclusion Example of a completed conclusion
post/repos/{owner}/{repo}/check-runs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-runs \   -d '{"name":"mighty_readme","head_sha":"ce587453ced02b1526dfb4cb910479d431683101","status":"in_progress","external_id":"42","started_at":"2018-05-04T01:14:52Z","output":{"title":"Mighty Readme report","summary":"","text":""}}'`
Response for in_progress conclusion
  * Example response
  * Response schema


`Status: 201`
`{   "id": 4,   "head_sha": "ce587453ced02b1526dfb4cb910479d431683101",   "node_id": "MDg6Q2hlY2tSdW40",   "external_id": "42",   "url": "https://api.github.com/repos/github/hello-world/check-runs/4",   "html_url": "https://github.com/github/hello-world/runs/4",   "details_url": "https://example.com",   "status": "in_progress",   "conclusion": null,   "started_at": "2018-05-04T01:14:52Z",   "completed_at": null,   "output": {     "title": "Mighty Readme report",     "summary": "There are 0 failures, 2 warnings, and 1 notice.",     "text": "You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.",     "annotations_count": 2,     "annotations_url": "https://api.github.com/repos/github/hello-world/check-runs/4/annotations"   },   "name": "mighty_readme",   "check_suite": {     "id": 5   },   "app": {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   },   "pull_requests": [     {       "url": "https://api.github.com/repos/github/hello-world/pulls/1",       "id": 1934,       "number": 3956,       "head": {         "ref": "say-hello",         "sha": "3dca65fa3e8d4b3da3f3d056c59aee1c50f41390",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       },       "base": {         "ref": "master",         "sha": "e7fdf7640066d71ad16a86fbcbb9c6a10a18af4f",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       }     }   ] }`
## [Get a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run)
Gets a single check run using its `id`.
The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "Get a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_run_id` integer Required The unique identifier of the check run.
### [HTTP response status codes for "Get a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#get-a-check-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/check-runs/{check_run_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-runs/CHECK_RUN_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 4,   "head_sha": "ce587453ced02b1526dfb4cb910479d431683101",   "node_id": "MDg6Q2hlY2tSdW40",   "external_id": "",   "url": "https://api.github.com/repos/github/hello-world/check-runs/4",   "html_url": "https://github.com/github/hello-world/runs/4",   "details_url": "https://example.com",   "status": "completed",   "conclusion": "neutral",   "started_at": "2018-05-04T01:14:52Z",   "completed_at": "2018-05-04T01:14:52Z",   "output": {     "title": "Mighty Readme report",     "summary": "There are 0 failures, 2 warnings, and 1 notice.",     "text": "You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.",     "annotations_count": 2,     "annotations_url": "https://api.github.com/repos/github/hello-world/check-runs/4/annotations"   },   "name": "mighty_readme",   "check_suite": {     "id": 5   },   "app": {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   },   "pull_requests": [     {       "url": "https://api.github.com/repos/github/hello-world/pulls/1",       "id": 1934,       "number": 3956,       "head": {         "ref": "say-hello",         "sha": "3dca65fa3e8d4b3da3f3d056c59aee1c50f41390",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       },       "base": {         "ref": "master",         "sha": "e7fdf7640066d71ad16a86fbcbb9c6a10a18af4f",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       }     }   ] }`
## [Update a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run)
Updates a check run for a specific commit in a repository.
The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array.
OAuth apps and personal access tokens (classic) cannot use this endpoint.
### [Fine-grained access tokens for "Update a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Update a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_run_id` integer Required The unique identifier of the check run.
Body parameters Name, Type, Description
---
`name` string The name of the check. For example, "code-coverage".
`details_url` string The URL of the integrator's site that has the full details of the check.
`external_id` string A reference for the run on the integrator's system.
`started_at` string This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`status` string The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. Can be one of: `queued`, `in_progress`, `completed`, `waiting`, `requested`, `pending`
`conclusion` string **Required if you provide`completed_at` or a `status` of `completed`**. The final conclusion of the check. **Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this. Can be one of: `action_required`, `cancelled`, `failure`, `neutral`, `success`, `skipped`, `stale`, `timed_out`
`completed_at` string The time the check completed. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`output` object Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run.
Properties of `output` | Name, Type, Description
---
`title` string **Required**.
`summary` string Required Can contain Markdown.
`text` string Can contain Markdown.
`annotations` array of objects Adds information from your analysis to specific lines of code. Annotations are visible in GitHub's pull request UI. Annotations are visible in GitHub's pull request UI. The Checks API limits the number of annotations to a maximum of 50 per API request. To create more than 50 annotations, you have to make multiple requests to the [Update a check run](https://docs.github.com/rest/checks/runs#update-a-check-run) endpoint. Each time you update the check run, annotations are appended to the list of annotations that already exist for the check run. GitHub Actions are limited to 10 warning annotations and 10 error annotations per step. For details about annotations in the UI, see "[About status checks](https://docs.github.com/articles/about-status-checks#checks)".
Properties of `annotations` | Name, Type, Description
---
`path` string Required The path of the file to add an annotation to. For example, `assets/css/main.css`.
`start_line` integer Required The start line of the annotation. Line numbers start at 1.
`end_line` integer Required The end line of the annotation.
`start_column` integer The start column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values. Column numbers start at 1.
`end_column` integer The end column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values.
`annotation_level` string Required The level of the annotation. Can be one of: `notice`, `warning`, `failure`
`message` string Required A short description of the feedback for these lines of code. The maximum size is 64 KB.
`title` string The title that represents the annotation. The maximum size is 255 characters.
`raw_details` string Details about this annotation. The maximum size is 64 KB.
`images` array of objects Adds images to the output displayed in the GitHub pull request UI.
Properties of `images` | Name, Type, Description
---
`alt` string Required The alternative text for the image.
`image_url` string Required The full URL of the image.
`caption` string A short image description.
`actions` array of objects Possible further actions the integrator can perform, which a user may trigger. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)."
Properties of `actions` | Name, Type, Description
---
`label` string Required The text to be displayed on a button in the web UI. The maximum size is 20 characters.
`description` string Required A short explanation of what this action would do. The maximum size is 40 characters.
`identifier` string Required A reference for the action on the integrator's system. The maximum size is 20 characters.
### [HTTP response status codes for "Update a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Update a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#update-a-check-run--code-samples)
#### Request example
patch/repos/{owner}/{repo}/check-runs/{check_run_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-runs/CHECK_RUN_ID \   -d '{"name":"mighty_readme","started_at":"2018-05-04T01:14:52Z","status":"completed","conclusion":"success","completed_at":"2018-05-04T01:14:52Z","output":{"title":"Mighty Readme report","summary":"There are 0 failures, 2 warnings, and 1 notices.","text":"You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.","annotations":[{"path":"README.md","annotation_level":"warning","title":"Spell Checker","message":"Check your spelling for '\''banaas'\''.","raw_details":"Do you mean '\''bananas'\'' or '\''banana'\''?","start_line":2,"end_line":2},{"path":"README.md","annotation_level":"warning","title":"Spell Checker","message":"Check your spelling for '\''aples'\''","raw_details":"Do you mean '\''apples'\'' or '\''Naples'\''","start_line":4,"end_line":4}],"images":[{"alt":"Super bananas","image_url":"http://example.com/images/42"}]}}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 4,   "head_sha": "ce587453ced02b1526dfb4cb910479d431683101",   "node_id": "MDg6Q2hlY2tSdW40",   "external_id": "",   "url": "https://api.github.com/repos/github/hello-world/check-runs/4",   "html_url": "https://github.com/github/hello-world/runs/4",   "details_url": "https://example.com",   "status": "completed",   "conclusion": "neutral",   "started_at": "2018-05-04T01:14:52Z",   "completed_at": "2018-05-04T01:14:52Z",   "output": {     "title": "Mighty Readme report",     "summary": "There are 0 failures, 2 warnings, and 1 notice.",     "text": "You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.",     "annotations_count": 2,     "annotations_url": "https://api.github.com/repos/github/hello-world/check-runs/4/annotations"   },   "name": "mighty_readme",   "check_suite": {     "id": 5   },   "app": {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   },   "pull_requests": [     {       "url": "https://api.github.com/repos/github/hello-world/pulls/1",       "id": 1934,       "number": 3956,       "head": {         "ref": "say-hello",         "sha": "3dca65fa3e8d4b3da3f3d056c59aee1c50f41390",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       },       "base": {         "ref": "master",         "sha": "e7fdf7640066d71ad16a86fbcbb9c6a10a18af4f",         "repo": {           "id": 526,           "url": "https://api.github.com/repos/github/hello-world",           "name": "hello-world"         }       }     }   ] }`
## [List check run annotations](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations)
Lists annotations for a check run using the annotation `id`.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "List check run annotations"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List check run annotations"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_run_id` integer Required The unique identifier of the check run.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List check run annotations"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List check run annotations"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-run-annotations--code-samples)
#### Request example
get/repos/{owner}/{repo}/check-runs/{check_run_id}/annotations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-runs/CHECK_RUN_ID/annotations`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "path": "README.md",     "start_line": 2,     "end_line": 2,     "start_column": 5,     "end_column": 10,     "annotation_level": "warning",     "title": "Spell Checker",     "message": "Check your spelling for 'banaas'.",     "raw_details": "Do you mean 'bananas' or 'banana'?",     "blob_href": "https://api.github.com/repos/github/rest-api-description/git/blobs/abc"   } ]`
## [Rerequest a check run](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run)
Triggers GitHub to rerequest an existing check run, without pushing new code to a repository. This endpoint will trigger the [`check_run` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) event with the action `rerequested`. When a check run is `rerequested`, the `status` of the check suite it belongs to is reset to `queued` and the `conclusion` is cleared. The check run itself is not updated. GitHub apps recieving the [`check_run` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) with the `rerequested` action should then decide if the check run should be reset or updated and call the [update `check_run` endpoint](https://docs.github.com/rest/checks/runs#update-a-check-run) to update the check_run if desired.
For more information about how to re-run GitHub Actions jobs, see "[Re-run a job from a workflow run](https://docs.github.com/rest/actions/workflow-runs#re-run-a-job-from-a-workflow-run)".
### [Fine-grained access tokens for "Rerequest a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Rerequest a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_run_id` integer Required The unique identifier of the check run.
### [HTTP response status codes for "Rerequest a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run--status-codes)
Status code | Description
---|---
`201` | Created
`403` | Forbidden if the check run is not rerequestable or doesn't belong to the authenticated GitHub App
`404` | Resource not found
`422` | Validation error if the check run is not rerequestable
### [Code samples for "Rerequest a check run"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#rerequest-a-check-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/check-runs/{check_run_id}/rerequest
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-runs/CHECK_RUN_ID/rerequest`
Response
  * Example response
  * Response schema


`Status: 201`
## [List check runs in a check suite](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite)
Lists check runs for a check suite using its `id`.
The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "List check runs in a check suite"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List check runs in a check suite"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_suite_id` integer Required The unique identifier of the check suite.
Query parameters Name, Type, Description
---
`check_name` string Returns check runs with the specified `name`.
`status` string Returns check runs with the specified `status`. Can be one of: `queued`, `in_progress`, `completed`
`filter` string Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. Default: `latest` Can be one of: `latest`, `all`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List check runs in a check suite"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List check runs in a check suite"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-in-a-check-suite--code-samples)
#### Request example
get/repos/{owner}/{repo}/check-suites/{check_suite_id}/check-runs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-suites/CHECK_SUITE_ID/check-runs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "check_runs": [     {       "id": 4,       "head_sha": "ce587453ced02b1526dfb4cb910479d431683101",       "node_id": "MDg6Q2hlY2tSdW40",       "external_id": "",       "url": "https://api.github.com/repos/github/hello-world/check-runs/4",       "html_url": "https://github.com/github/hello-world/runs/4",       "details_url": "https://example.com",       "status": "completed",       "conclusion": "neutral",       "started_at": "2018-05-04T01:14:52Z",       "completed_at": "2018-05-04T01:14:52Z",       "output": {         "title": "Mighty Readme report",         "summary": "There are 0 failures, 2 warnings, and 1 notice.",         "text": "You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.",         "annotations_count": 2,         "annotations_url": "https://api.github.com/repos/github/hello-world/check-runs/4/annotations"       },       "name": "mighty_readme",       "check_suite": {         "id": 5       },       "app": {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": true         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       },       "pull_requests": [         {           "url": "https://api.github.com/repos/github/hello-world/pulls/1",           "id": 1934,           "number": 3956,           "head": {             "ref": "say-hello",             "sha": "3dca65fa3e8d4b3da3f3d056c59aee1c50f41390",             "repo": {               "id": 526,               "url": "https://api.github.com/repos/github/hello-world",               "name": "hello-world"             }           },           "base": {             "ref": "master",             "sha": "e7fdf7640066d71ad16a86fbcbb9c6a10a18af4f",             "repo": {               "id": 526,               "url": "https://api.github.com/repos/github/hello-world",               "name": "hello-world"             }           }         }       ]     }   ] }`
## [List check runs for a Git reference](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference)
Lists check runs for a commit ref. The `ref` can be a SHA, branch name, or a tag name.
The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array.
If there are more than 1000 check suites on a single git reference, this endpoint will limit check runs to the 1000 most recent check suites. To iterate over all possible check runs, use the [List check suites for a Git reference](https://docs.github.com/rest/reference/checks#list-check-suites-for-a-git-reference) endpoint and provide the `check_suite_id` parameter to the [List check runs in a check suite](https://docs.github.com/rest/reference/checks#list-check-runs-in-a-check-suite) endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "List check runs for a Git reference"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List check runs for a Git reference"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ref` string Required The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
Query parameters Name, Type, Description
---
`check_name` string Returns check runs with the specified `name`.
`status` string Returns check runs with the specified `status`. Can be one of: `queued`, `in_progress`, `completed`
`filter` string Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. Default: `latest` Can be one of: `latest`, `all`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`app_id` integer
### [HTTP response status codes for "List check runs for a Git reference"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List check runs for a Git reference"](https://docs.github.com/en/rest/checks/runs?apiVersion=2022-11-28#list-check-runs-for-a-git-reference--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits/{ref}/check-runs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits/REF/check-runs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "check_runs": [     {       "id": 4,       "head_sha": "ce587453ced02b1526dfb4cb910479d431683101",       "node_id": "MDg6Q2hlY2tSdW40",       "external_id": "",       "url": "https://api.github.com/repos/github/hello-world/check-runs/4",       "html_url": "https://github.com/github/hello-world/runs/4",       "details_url": "https://example.com",       "status": "completed",       "conclusion": "neutral",       "started_at": "2018-05-04T01:14:52Z",       "completed_at": "2018-05-04T01:14:52Z",       "output": {         "title": "Mighty Readme report",         "summary": "There are 0 failures, 2 warnings, and 1 notice.",         "text": "You may have some misspelled words on lines 2 and 4. You also may want to add a section in your README about how to install your app.",         "annotations_count": 2,         "annotations_url": "https://api.github.com/repos/github/hello-world/check-runs/4/annotations"       },       "name": "mighty_readme",       "check_suite": {         "id": 5       },       "app": {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": true         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       },       "pull_requests": [         {           "url": "https://api.github.com/repos/github/hello-world/pulls/1",           "id": 1934,           "number": 3956,           "head": {             "ref": "say-hello",             "sha": "3dca65fa3e8d4b3da3f3d056c59aee1c50f41390",             "repo": {               "id": 526,               "url": "https://api.github.com/repos/github/hello-world",               "name": "hello-world"             }           },           "base": {             "ref": "master",             "sha": "e7fdf7640066d71ad16a86fbcbb9c6a10a18af4f",             "repo": {               "id": 526,               "url": "https://api.github.com/repos/github/hello-world",               "name": "hello-world"             }           }         }       ]     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/checks/runs.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for check runs - GitHub Docs
