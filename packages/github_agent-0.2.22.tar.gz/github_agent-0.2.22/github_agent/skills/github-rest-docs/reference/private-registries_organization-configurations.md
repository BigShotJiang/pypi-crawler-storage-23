[Skip to main content](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Private registries](https://docs.github.com/en/rest/private-registries "Private registries")/
  * [Organization configurations](https://docs.github.com/en/rest/private-registries/organization-configurations "Organization configurations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
      * [List private registries for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization)
      * [Create a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization)
      * [Get private registries public key for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization)
      * [Get a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization)
      * [Update a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization)
      * [Delete a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization)
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Private registries](https://docs.github.com/en/rest/private-registries "Private registries")/
  * [Organization configurations](https://docs.github.com/en/rest/private-registries/organization-configurations "Organization configurations")


# Organization configurations
Use the REST API to manage private registry configurations for organizations.
## [List private registries for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization)
Lists all private registry configurations available at the organization-level without revealing their encrypted values.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "List private registries for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (read)


### [Parameters for "List private registries for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List private registries for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`404` | Resource not found
### [Code samples for "List private registries for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#list-private-registries-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/private-registries
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "configurations": [     {       "name": "MAVEN_REPOSITORY_SECRET",       "registry_type": "maven_repository",       "username": "monalisa",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z",       "visibility": "selected"     }   ] }`
## [Create a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization)
Creates a private registry configuration with an encrypted value for an organization. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)."
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Create a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (write)


### [Parameters for "Create a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`registry_type` string Required The registry type. Can be one of: `maven_repository`, `nuget_feed`, `goproxy_server`, `npm_registry`, `rubygems_server`, `cargo_registry`, `composer_repository`, `docker_registry`, `git_source`, `helm_registry`, `hex_organization`, `hex_repository`, `pub_repository`, `python_index`, `terraform_registry`
`url` string Required The URL of the private registry.
`username` string or null The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication.
`replaces_base` boolean Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. Default: `false`
`encrypted_value` string Required The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint.
`key_id` string Required The ID of the key you used to encrypt the secret.
`visibility` string Required Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. Can be one of: `all`, `private`, `selected`
`selected_repository_ids` array of integers An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. You can manage the list of selected repositories using the [Update a private registry for an organization](https://docs.github.com/rest/private-registries/organization-configurations#update-a-private-registry-for-an-organization) endpoint. This field should be omitted if `visibility` is set to `all` or `private`.
### [HTTP response status codes for "Create a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization--status-codes)
Status code | Description
---|---
`201` | The organization private registry configuration
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#create-a-private-registry-for-an-organization--code-samples)
#### Request examples
Select the example typeExample of a private registry configuration with private visibility Example of a private registry configuration with selected visibility
post/orgs/{org}/private-registries
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries \   -d '{"registry_type":"maven_repository","url":"https://maven.pkg.github.com/organization/","username":"monalisa","replaces_base":true,"encrypted_value":"c2VjcmV0","key_id":"012345678912345678","visibility":"private"}'`
The organization private registry configuration
  * Example response
  * Response schema


`Status: 201`
`{   "name": "MAVEN_REPOSITORY_SECRET",   "registry_type": "maven_repository",   "username": "monalisa",   "visibility": "selected",   "selected_repository_ids": [     1296269,     1296280   ],   "created_at": "2019-08-10T14:59:22Z",   "updated_at": "2020-01-10T14:59:22Z" }`
## [Get private registries public key for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization)
Gets the org public key, which is needed to encrypt private registry secrets. You need to encrypt a secret before you can create or update secrets.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get private registries public key for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (read)


### [Parameters for "Get private registries public key for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get private registries public key for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get private registries public key for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-private-registries-public-key-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/private-registries/public-key
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries/public-key`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "key_id": "012345678912345678",   "key": "2Sg8iYjAxxmI2LvUXpJjkYrMxURPc8r+dB7TJyvv1234" }`
## [Get a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization)
Get the configuration of a single private registry defined for an organization, omitting its encrypted value.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (read)


### [Parameters for "Get a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`secret_name` string Required The name of the secret.
### [HTTP response status codes for "Get a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization--status-codes)
Status code | Description
---|---
`200` | The specified private registry configuration for the organization
`404` | Resource not found
### [Code samples for "Get a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#get-a-private-registry-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/private-registries/{secret_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries/SECRET_NAME`
The specified private registry configuration for the organization
  * Example response
  * Response schema


`Status: 200`
`{   "name": "MAVEN_REPOSITORY_SECRET",   "registry_type": "maven_repository",   "username": "monalisa",   "visibility": "private",   "created_at": "2019-08-10T14:59:22Z",   "updated_at": "2020-01-10T14:59:22Z" }`
## [Update a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization)
Updates a private registry configuration with an encrypted value for an organization. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)."
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Update a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (write)


### [Parameters for "Update a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`secret_name` string Required The name of the secret.
Body parameters Name, Type, Description
---
`registry_type` string The registry type. Can be one of: `maven_repository`, `nuget_feed`, `goproxy_server`, `npm_registry`, `rubygems_server`, `cargo_registry`, `composer_repository`, `docker_registry`, `git_source`, `helm_registry`, `hex_organization`, `hex_repository`, `pub_repository`, `python_index`, `terraform_registry`
`url` string The URL of the private registry.
`username` string or null The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication.
`replaces_base` boolean Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. Default: `false`
`encrypted_value` string The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint.
`key_id` string The ID of the key you used to encrypt the secret.
`visibility` string Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. Can be one of: `all`, `private`, `selected`
`selected_repository_ids` array of integers An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. This field should be omitted if `visibility` is set to `all` or `private`.
### [HTTP response status codes for "Update a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#update-a-private-registry-for-an-organization--code-samples)
#### Request example
patch/orgs/{org}/private-registries/{secret_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries/SECRET_NAME \   -d '{"username":"monalisa","encrypted_value":"c2VjcmV0","key_id":"012345678912345678"}'`
Response
`Status: 204`
## [Delete a private registry for an organization](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization)
Delete a private registry configuration at the organization-level.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Organization private registries" organization permissions (write)


### [Parameters for "Delete a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`secret_name` string Required The name of the secret.
### [HTTP response status codes for "Delete a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
`400` | Bad Request
`404` | Resource not found
### [Code samples for "Delete a private registry for an organization"](https://docs.github.com/en/rest/private-registries/organization-configurations?apiVersion=2022-11-28#delete-a-private-registry-for-an-organization--code-samples)
#### Request example
delete/orgs/{org}/private-registries/{secret_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/private-registries/SECRET_NAME`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/private-registries/organization-configurations.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


Organization configurations - GitHub Docs
