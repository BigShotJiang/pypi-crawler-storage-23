[Skip to main content](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Organizations](https://docs.github.com/en/rest/orgs/orgs "Organizations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
      * [List organizations](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations)
      * [Get an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization)
      * [Update an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization)
      * [Delete an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization)
      * [List app installations for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization)
      * [Get immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization)
      * [Set immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization)
      * [List selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement)
      * [Set selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement)
      * [Enable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization)
      * [Disable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization)
      * [Enable or disable a security feature for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization)
      * [List organizations for the authenticated user](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user)
      * [List organizations for a user](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user)
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Organizations](https://docs.github.com/en/rest/orgs/orgs "Organizations")


# REST API endpoints for organizations
Use the REST API to interact with organizations.
## [List organizations](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations)
Lists all organizations, in the order that they were created.
Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of organizations.
### [Fine-grained access tokens for "List organizations"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List organizations"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` integer An organization ID. Only return organizations with an ID greater than this ID.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List organizations"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
### [Code samples for "List organizations"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations--code-samples)
#### Request example
get/organizations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/organizations`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization"   } ]`
## [Get an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization)
Gets information about an organization.
When the value of `two_factor_requirement_enabled` is `true`, the organization requires all members, billing managers, outside collaborators, guest collaborators, repository collaborators, or everyone with access to any repository within the organization to enable [two-factor authentication](https://docs.github.com/articles/securing-your-account-with-two-factor-authentication-2fa/).
To see the full details about an organization, the authenticated user must be an organization owner.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to see the full details about an organization.
To see information about an organization's GitHub plan, GitHub Apps need the `Organization plan` permission.
### [Fine-grained access tokens for "Get an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-an-organization--code-samples)
#### Request example
get/orgs/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "login": "github",   "id": 1,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "url": "https://api.github.com/orgs/github",   "repos_url": "https://api.github.com/orgs/github/repos",   "events_url": "https://api.github.com/orgs/github/events",   "hooks_url": "https://api.github.com/orgs/github/hooks",   "issues_url": "https://api.github.com/orgs/github/issues",   "members_url": "https://api.github.com/orgs/github/members{/member}",   "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "description": "A great organization",   "name": "github",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "twitter_username": "github",   "is_verified": true,   "has_organization_projects": true,   "has_repository_projects": true,   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "html_url": "https://github.com/octocat",   "created_at": "2008-01-14T04:33:35Z",   "type": "Organization",   "total_private_repos": 100,   "owned_private_repos": 100,   "private_gists": 81,   "disk_usage": 10000,   "collaborators": 8,   "billing_email": "mona@github.com",   "plan": {     "name": "Medium",     "space": 400,     "private_repos": 20,     "filled_seats": 4,     "seats": 5   },   "default_repository_permission": "read",   "default_repository_branch": "main",   "members_can_create_repositories": true,   "two_factor_requirement_enabled": true,   "members_allowed_repository_creation_type": "all",   "members_can_create_public_repositories": false,   "members_can_create_private_repositories": false,   "members_can_create_internal_repositories": false,   "members_can_create_pages": true,   "members_can_create_public_pages": true,   "members_can_create_private_pages": true,   "members_can_delete_repositories": true,   "members_can_change_repo_visibility": true,   "members_can_invite_outside_collaborators": true,   "members_can_delete_issues": false,   "display_commenter_full_name_setting_enabled": false,   "readers_can_create_discussions": true,   "members_can_create_teams": true,   "members_can_view_dependency_insights": true,   "members_can_fork_private_repositories": false,   "web_commit_signoff_required": false,   "updated_at": "2014-03-03T18:58:10Z",   "deploy_keys_enabled_for_repositories": false,   "dependency_graph_enabled_for_new_repositories": false,   "dependabot_alerts_enabled_for_new_repositories": false,   "dependabot_security_updates_enabled_for_new_repositories": false,   "advanced_security_enabled_for_new_repositories": false,   "secret_scanning_enabled_for_new_repositories": false,   "secret_scanning_push_protection_enabled_for_new_repositories": false,   "secret_scanning_push_protection_custom_link": "https://github.com/octo-org/octo-repo/blob/main/im-blocked.md",   "secret_scanning_push_protection_custom_link_enabled": false }`
## [Update an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization)
**Closing down notice:** GitHub will replace and discontinue `members_allowed_repository_creation_type` in favor of more granular permissions. The new input parameters are `members_can_create_public_repositories`, `members_can_create_private_repositories` for all organizations and `members_can_create_internal_repositories` for organizations associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+. For more information, see the [blog post](https://developer.github.com/changes/2019-12-03-internal-visibility-changes).
**Closing down notice:** Code security product enablement for new repositories through the organization API is closing down. Please use [code security configurations](https://docs.github.com/rest/code-security/configurations#set-a-code-security-configuration-as-a-default-for-an-organization) to set defaults instead. For more information on setting a default security configuration, see the [changelog](https://github.blog/changelog/2024-07-09-sunsetting-security-settings-defaults-parameters-in-the-organizations-rest-api/).
Updates the organization's profile and member privileges.
The authenticated user must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` or `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Update an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Update an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`billing_email` string Billing email address. This address is not publicized.
`company` string The company name.
`email` string The publicly visible email address.
`twitter_username` string The Twitter username of the company.
`location` string The location.
`name` string The shorthand name of the company.
`description` string The description of the company. The maximum size is 160 characters.
`has_organization_projects` boolean Whether an organization can use organization projects.
`has_repository_projects` boolean Whether repositories that belong to the organization can use repository projects.
`default_repository_permission` string Default permission level members have for organization repositories. Default: `read` Can be one of: `read`, `write`, `admin`, `none`
`members_can_create_repositories` boolean Whether of non-admin organization members can create repositories. **Note:** A parameter can override this parameter. See `members_allowed_repository_creation_type` in this table for details. Default: `true`
`members_can_create_internal_repositories` boolean Whether organization members can create internal repositories, which are visible to all enterprise members. You can only allow members to create internal repositories if your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
`members_can_create_private_repositories` boolean Whether organization members can create private repositories, which are visible to organization members with permission. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
`members_can_create_public_repositories` boolean Whether organization members can create public repositories, which are visible to anyone. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
`members_allowed_repository_creation_type` string Specifies which types of repositories non-admin organization members can create. `private` is only available to repositories that are part of an organization on GitHub Enterprise Cloud. **Note:** This parameter is closing down and will be removed in the future. Its return value ignores internal repositories. Using this parameter overrides values set in `members_can_create_repositories`. See the parameter deprecation notice in the operation description for details. Can be one of: `all`, `private`, `none`
`members_can_create_pages` boolean Whether organization members can create GitHub Pages sites. Existing published sites will not be impacted. Default: `true`
`members_can_create_public_pages` boolean Whether organization members can create public GitHub Pages sites. Existing published sites will not be impacted. Default: `true`
`members_can_create_private_pages` boolean Whether organization members can create private GitHub Pages sites. Existing published sites will not be impacted. Default: `true`
`members_can_fork_private_repositories` boolean Whether organization members can fork private organization repositories. Default: `false`
`web_commit_signoff_required` boolean Whether contributors to organization repositories are required to sign off on commits they make through GitHub's web interface. Default: `false`
`blog` string
`advanced_security_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether GitHub Advanced Security is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`dependabot_alerts_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot alerts are automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`dependabot_security_updates_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot security updates are automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`dependency_graph_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether dependency graph is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`secret_scanning_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`secret_scanning_push_protection_enabled_for_new_repositories` boolean **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning push protection is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
`secret_scanning_push_protection_custom_link_enabled` boolean Whether a custom link is shown to contributors who are blocked from pushing a secret by push protection.
`secret_scanning_push_protection_custom_link` string If `secret_scanning_push_protection_custom_link_enabled` is true, the URL that will be displayed to contributors who are blocked from pushing a secret.
`deploy_keys_enabled_for_repositories` boolean Controls whether or not deploy keys may be added and used for repositories in the organization.
### [HTTP response status codes for "Update an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`409` | Conflict
`422` | Validation failed
### [Code samples for "Update an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#update-an-organization--code-samples)
#### Request example
patch/orgs/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG \   -d '{"billing_email":"mona@github.com","company":"GitHub","email":"mona@github.com","twitter_username":"github","location":"San Francisco","name":"github","description":"GitHub, the company.","default_repository_permission":"read","members_can_create_repositories":true,"members_allowed_repository_creation_type":"all"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "login": "github",   "id": 1,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "url": "https://api.github.com/orgs/github",   "repos_url": "https://api.github.com/orgs/github/repos",   "events_url": "https://api.github.com/orgs/github/events",   "hooks_url": "https://api.github.com/orgs/github/hooks",   "issues_url": "https://api.github.com/orgs/github/issues",   "members_url": "https://api.github.com/orgs/github/members{/member}",   "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "description": "A great organization",   "name": "github",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "twitter_username": "github",   "is_verified": true,   "has_organization_projects": true,   "has_repository_projects": true,   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "html_url": "https://github.com/octocat",   "created_at": "2008-01-14T04:33:35Z",   "type": "Organization",   "total_private_repos": 100,   "owned_private_repos": 100,   "private_gists": 81,   "disk_usage": 10000,   "collaborators": 8,   "billing_email": "mona@github.com",   "plan": {     "name": "Medium",     "space": 400,     "private_repos": 20,     "filled_seats": 4,     "seats": 5   },   "default_repository_permission": "read",   "default_repository_branch": "main",   "members_can_create_repositories": true,   "two_factor_requirement_enabled": true,   "members_allowed_repository_creation_type": "all",   "members_can_create_public_repositories": false,   "members_can_create_private_repositories": false,   "members_can_create_internal_repositories": false,   "members_can_create_pages": true,   "members_can_create_public_pages": true,   "members_can_create_private_pages": true,   "members_can_delete_repositories": true,   "members_can_change_repo_visibility": true,   "members_can_invite_outside_collaborators": true,   "members_can_delete_issues": false,   "display_commenter_full_name_setting_enabled": false,   "readers_can_create_discussions": true,   "members_can_create_teams": true,   "members_can_view_dependency_insights": true,   "members_can_fork_private_repositories": false,   "web_commit_signoff_required": false,   "updated_at": "2014-03-03T18:58:10Z",   "deploy_keys_enabled_for_repositories": false,   "dependency_graph_enabled_for_new_repositories": false,   "dependabot_alerts_enabled_for_new_repositories": false,   "dependabot_security_updates_enabled_for_new_repositories": false,   "advanced_security_enabled_for_new_repositories": false,   "secret_scanning_enabled_for_new_repositories": false,   "secret_scanning_push_protection_enabled_for_new_repositories": false,   "secret_scanning_push_protection_custom_link": "https://github.com/octo-org/octo-repo/blob/main/im-blocked.md",   "secret_scanning_push_protection_custom_link_enabled": false }`
## [Delete an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization)
Deletes an organization and all its repositories.
The organization login will be unavailable for 90 days after deletion.
Please review the Terms of Service regarding account deletion before using this endpoint:
<https://docs.github.com/site-policy/github-terms/github-terms-of-service>
### [Fine-grained access tokens for "Delete an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Delete an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Delete an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization--status-codes)
Status code | Description
---|---
`202` | Accepted
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Delete an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#delete-an-organization--code-samples)
#### Request example
delete/orgs/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG`
Accepted
  * Example response
  * Response schema


`Status: 202`
## [List app installations for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization)
Lists all GitHub Apps in an organization. The installation count includes all GitHub Apps installed on repositories in the organization.
The authenticated user must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:read` scope to use this endpoint.
### [Fine-grained access tokens for "List app installations for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "List app installations for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List app installations for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List app installations for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-app-installations-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/installations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/installations`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "installations": [     {       "id": 25381,       "account": {         "login": "octo-org",         "id": 6811672,         "node_id": "MDEyOk9yZ2FuaXphdGlvbjY4MTE2NzI=",         "avatar_url": "https://avatars3.githubusercontent.com/u/6811672?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/octo-org",         "html_url": "https://github.com/octo-org",         "followers_url": "https://api.github.com/users/octo-org/followers",         "following_url": "https://api.github.com/users/octo-org/following{/other_user}",         "gists_url": "https://api.github.com/users/octo-org/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octo-org/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octo-org/subscriptions",         "organizations_url": "https://api.github.com/users/octo-org/orgs",         "repos_url": "https://api.github.com/users/octo-org/repos",         "events_url": "https://api.github.com/users/octo-org/events{/privacy}",         "received_events_url": "https://api.github.com/users/octo-org/received_events",         "type": "Organization",         "site_admin": false       },       "repository_selection": "selected",       "access_tokens_url": "https://api.github.com/app/installations/25381/access_tokens",       "repositories_url": "https://api.github.com/installation/repositories",       "html_url": "https://github.com/organizations/octo-org/settings/installations/25381",       "app_id": 2218,       "target_id": 6811672,       "target_type": "Organization",       "permissions": {         "deployments": "write",         "metadata": "read",         "pull_requests": "read",         "statuses": "read"       },       "events": [         "deployment",         "deployment_status"       ],       "created_at": "2017-05-16T08:47:09.000-07:00",       "updated_at": "2017-06-06T11:23:23.000-07:00",       "single_file_name": "config.yml",       "has_multiple_single_files": true,       "single_file_paths": [         "config.yml",         ".github/issue_TEMPLATE.md"       ],       "app_slug": "github-actions",       "suspended_at": null,       "suspended_by": null     }   ] }`
## [Get immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization)
Gets the immutable releases policy for repositories in an organization.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Immutable releases settings response
### [Code samples for "Get immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#get-immutable-releases-settings-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/settings/immutable-releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases`
Immutable releases settings response
  * Example response
  * Response schema


`Status: 200`
`{   "enforced_repositories": "all" }`
## [Set immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization)
Sets the immutable releases policy for repositories in an organization.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Set immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Set immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`enforced_repositories` string Required The policy that controls how immutable releases are enforced in the organization. Can be one of: `all`, `none`, `selected`
`selected_repository_ids` array of integers An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints.
### [HTTP response status codes for "Set immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Set immutable releases settings for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-immutable-releases-settings-for-an-organization--code-samples)
#### Request example
put/orgs/{org}/settings/immutable-releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases \   -d '{"enforced_repositories":"all"}'`
Response
`Status: 204`
## [List selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement)
List all of the repositories that have been selected for immutable releases enforcement in an organization.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "List selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "List selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-selected-repositories-for-immutable-releases-enforcement--code-samples)
#### Request example
get/orgs/{org}/settings/immutable-releases/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases/repositories`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "repositories": [     {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"     }   ] }`
## [Set selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement)
Replaces all repositories that have been selected for immutable releases enforcement in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Set selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write) and "Metadata" repository permissions (read)


### [Parameters for "Set selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`selected_repository_ids` array of integers Required An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints.
### [HTTP response status codes for "Set selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Set selected repositories for immutable releases enforcement"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#set-selected-repositories-for-immutable-releases-enforcement--code-samples)
#### Request example
put/orgs/{org}/settings/immutable-releases/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases/repositories \   -d '{"selected_repository_ids":[64780797]}'`
Response
`Status: 204`
## [Enable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization)
Adds a repository to the list of selected repositories that are enforced for immutable releases in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Enable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write) and "Metadata" repository permissions (read)


### [Parameters for "Enable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`repository_id` integer Required The unique identifier of the repository.
### [HTTP response status codes for "Enable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Enable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-a-selected-repository-for-immutable-releases-in-an-organization--code-samples)
#### Request example
put/orgs/{org}/settings/immutable-releases/repositories/{repository_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases/repositories/REPOSITORY_ID`
Response
`Status: 204`
## [Disable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization)
Removes a repository from the list of selected repositories that are enforced for immutable releases in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Disable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write) and "Metadata" repository permissions (read)


### [Parameters for "Disable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`repository_id` integer Required The unique identifier of the repository.
### [HTTP response status codes for "Disable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Disable a selected repository for immutable releases in an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#disable-a-selected-repository-for-immutable-releases-in-an-organization--code-samples)
#### Request example
delete/orgs/{org}/settings/immutable-releases/repositories/{repository_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/settings/immutable-releases/repositories/REPOSITORY_ID`
Response
`Status: 204`
## [Enable or disable a security feature for an organization](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization)
**Closing down notice:** The ability to enable or disable a security feature for all eligible repositories in an organization is closing down. Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. For more information, see the [changelog](https://github.blog/changelog/2024-07-22-deprecation-of-api-endpoint-to-enable-or-disable-a-security-feature-for-an-organization/).
Enables or disables the specified security feature for all eligible repositories in an organization. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."
The authenticated user must be an organization owner or be member of a team with the security manager role to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org`, `write:org`, or `repo` scopes to use this endpoint.
### [Fine-grained access tokens for "Enable or disable a security feature for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Enable or disable a security feature for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`security_product` string Required The security feature to enable or disable. Can be one of: `dependency_graph`, `dependabot_alerts`, `dependabot_security_updates`, `advanced_security`, `code_scanning_default_setup`, `secret_scanning`, `secret_scanning_push_protection`
`enablement` string Required The action to take. `enable_all` means to enable the specified security feature for all repositories in the organization. `disable_all` means to disable the specified security feature for all repositories in the organization. Can be one of: `enable_all`, `disable_all`
Body parameters Name, Type, Description
---
`query_suite` string CodeQL query suite to be used. If you specify the `query_suite` parameter, the default setup will be configured with this query suite only on all repositories that didn't have default setup already configured. It will not change the query suite on repositories that already have default setup configured. If you don't specify any `query_suite` in your request, the preferred query suite of the organization will be applied. Can be one of: `default`, `extended`
### [HTTP response status codes for "Enable or disable a security feature for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization--status-codes)
Status code | Description
---|---
`204` | Action started
`422` | The action could not be taken due to an in progress enablement, or a policy is preventing enablement
### [Code samples for "Enable or disable a security feature for an organization"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#enable-or-disable-a-security-feature-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/{security_product}/{enablement}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/SECURITY_PRODUCT/ENABLEMENT`
Action started
`Status: 204`
## [List organizations for the authenticated user](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user)
List organizations for the authenticated user.
For OAuth app tokens and personal access tokens (classic), this endpoint only lists organizations that your authorization allows you to operate on in some way (e.g., you can list teams with `read:org` scope, you can publicize your organization membership with `user` scope, etc.). Therefore, this API requires at least `user` or `read:org` scope for OAuth app tokens and personal access tokens (classic). Requests with insufficient scope will receive a `403 Forbidden` response.
Requests using a fine-grained access token will receive a `200 Success` response with an empty list.
### [Fine-grained access tokens for "List organizations for the authenticated user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List organizations for the authenticated user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organizations for the authenticated user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "List organizations for the authenticated user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-the-authenticated-user--code-samples)
#### Request example
get/user/orgs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/orgs`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization"   } ]`
## [List organizations for a user](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user)
List [public organization memberships](https://docs.github.com/articles/publicizing-or-concealing-organization-membership) for the specified user.
This method only lists _public_ memberships, regardless of authentication. If you need to fetch all of the organization memberships (public and private) for the authenticated user, use the [List organizations for the authenticated user](https://docs.github.com/rest/orgs/orgs#list-organizations-for-the-authenticated-user) API instead.
### [Fine-grained access tokens for "List organizations for a user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List organizations for a user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organizations for a user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List organizations for a user"](https://docs.github.com/en/rest/orgs/orgs?apiVersion=2022-11-28#list-organizations-for-a-user--code-samples)
#### Request example
get/users/{username}/orgs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/orgs`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization"   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/orgs.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for organizations - GitHub Docs
