[Skip to main content](https://docs.github.com/en/contributing#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [Contribute to GitHub Docs](https://docs.github.com/en/contributing "Contribute to GitHub Docs")


[](https://docs.github.com/en)
## [Contribute to GitHub Docs](https://docs.github.com/en/contributing)
  * Writing for GitHub Docs
    * [Best practices for GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs/best-practices-for-github-docs)
    * [Documentation philosophy](https://docs.github.com/en/contributing/writing-for-github-docs/about-githubs-documentation-philosophy)
    * [Documentation fundamentals](https://docs.github.com/en/contributing/writing-for-github-docs/about-githubs-documentation-fundamentals)
    * [Content design principles](https://docs.github.com/en/contributing/writing-for-github-docs/content-design-principles)
    * [Write content to be translated](https://docs.github.com/en/contributing/writing-for-github-docs/writing-content-to-be-translated)
    * [Make content findable](https://docs.github.com/en/contributing/writing-for-github-docs/making-content-findable-in-search)
    * [Versioning documentation](https://docs.github.com/en/contributing/writing-for-github-docs/versioning-documentation)
    * [Markdown and Liquid](https://docs.github.com/en/contributing/writing-for-github-docs/using-markdown-and-liquid-in-github-docs)
    * [YAML frontmatter](https://docs.github.com/en/contributing/writing-for-github-docs/using-yaml-frontmatter)
    * [Use videos](https://docs.github.com/en/contributing/writing-for-github-docs/using-videos-in-github-docs)
    * [Create reusable content](https://docs.github.com/en/contributing/writing-for-github-docs/creating-reusable-content)
    * [Create screenshots](https://docs.github.com/en/contributing/writing-for-github-docs/creating-screenshots)
    * [Create diagrams](https://docs.github.com/en/contributing/writing-for-github-docs/creating-diagrams-for-github-docs)
    * [Create tool switchers](https://docs.github.com/en/contributing/writing-for-github-docs/creating-tool-switchers-in-articles)
    * [Configure redirects](https://docs.github.com/en/contributing/writing-for-github-docs/configuring-redirects)
    * [Change an article's title](https://docs.github.com/en/contributing/writing-for-github-docs/changing-an-articles-title)
    * [Annotate code examples](https://docs.github.com/en/contributing/writing-for-github-docs/annotating-code-examples)
    * [Templates](https://docs.github.com/en/contributing/writing-for-github-docs/templates)
  * Style guide and content model
    * [Style guide](https://docs.github.com/en/contributing/style-guide-and-content-model/style-guide)
    * [About the content model](https://docs.github.com/en/contributing/style-guide-and-content-model/about-the-content-model)
    * [Contents of an article](https://docs.github.com/en/contributing/style-guide-and-content-model/contents-of-a-github-docs-article)
    * [About topics](https://docs.github.com/en/contributing/style-guide-and-content-model/about-topics)
    * [Conceptual content type](https://docs.github.com/en/contributing/style-guide-and-content-model/conceptual-content-type)
    * [Referential content type](https://docs.github.com/en/contributing/style-guide-and-content-model/referential-content-type)
    * [Procedural content type](https://docs.github.com/en/contributing/style-guide-and-content-model/procedural-content-type)
    * [Troubleshooting content type](https://docs.github.com/en/contributing/style-guide-and-content-model/troubleshooting-content-type)
    * [Release note content type](https://docs.github.com/en/contributing/style-guide-and-content-model/release-note-content-type)
    * [Quickstart content type](https://docs.github.com/en/contributing/style-guide-and-content-model/quickstart-content-type)
    * [Tutorial content type](https://docs.github.com/en/contributing/style-guide-and-content-model/tutorial-content-type)
    * [Combining multiple types](https://docs.github.com/en/contributing/style-guide-and-content-model/about-combining-multiple-content-types)
  * Collaborate on GitHub Docs
    * [About contributing](https://docs.github.com/en/contributing/collaborating-on-github-docs/about-contributing-to-github-docs)
    * [Using Git](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-git-on-github-docs)
    * [Using the TODOCS placeholder](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-the-todocs-placeholder-to-leave-notes)
    * [Using the content linter](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-the-content-linter)
    * [Label reference](https://docs.github.com/en/contributing/collaborating-on-github-docs/label-reference)
  * Your working environment
    * [Working in a codespace](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/working-on-github-docs-in-a-codespace)
    * [Create a local environment](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/creating-a-local-environment)
    * [Troubleshooting your environment](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/troubleshooting-your-environment)


# Contributing to GitHub Docs documentation
Learn about how the GitHub Docs team creates documentation and how you can contribute.
## Start here
  * ### [Best practices for GitHub Docs Follow these best practices to create documentation that's user-friendly and easy to understand. ](https://docs.github.com/en/contributing/writing-for-github-docs/best-practices-for-github-docs)
  * ### [Style guide Follow this guide to make sure GitHub's documentation stays consistent and follows clear patterns that our readers can understand. ](https://docs.github.com/en/contributing/style-guide-and-content-model/style-guide)
  * ### [About the content model The content model describes the structure and types of content that we publish. ](https://docs.github.com/en/contributing/style-guide-and-content-model/about-the-content-model)
  * ### [About contributing to GitHub Docs You can contribute to GitHub Docs content in several ways. ](https://docs.github.com/en/contributing/collaborating-on-github-docs/about-contributing-to-github-docs)


## [All Contribute to GitHub Docs docs](https://docs.github.com/en/contributing#all-docs)
### [Writing for GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs)
  * [Best practices for GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs/best-practices-for-github-docs)
  * [About GitHub's documentation philosophy](https://docs.github.com/en/contributing/writing-for-github-docs/about-githubs-documentation-philosophy)
  * [About GitHub's documentation fundamentals](https://docs.github.com/en/contributing/writing-for-github-docs/about-githubs-documentation-fundamentals)
  * [Content design principles](https://docs.github.com/en/contributing/writing-for-github-docs/content-design-principles)
  * [Writing content to be translated](https://docs.github.com/en/contributing/writing-for-github-docs/writing-content-to-be-translated)
  * [Making content findable in search](https://docs.github.com/en/contributing/writing-for-github-docs/making-content-findable-in-search)
  * [Versioning documentation](https://docs.github.com/en/contributing/writing-for-github-docs/versioning-documentation)
  * [Using Markdown and Liquid in GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs/using-markdown-and-liquid-in-github-docs)
  * [Using YAML frontmatter](https://docs.github.com/en/contributing/writing-for-github-docs/using-yaml-frontmatter)
  * [Using videos in GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs/using-videos-in-github-docs)
  * [Creating reusable content](https://docs.github.com/en/contributing/writing-for-github-docs/creating-reusable-content)
  * [Creating screenshots](https://docs.github.com/en/contributing/writing-for-github-docs/creating-screenshots)
  * [Creating diagrams for GitHub Docs](https://docs.github.com/en/contributing/writing-for-github-docs/creating-diagrams-for-github-docs)
  * [Creating tool switchers in articles](https://docs.github.com/en/contributing/writing-for-github-docs/creating-tool-switchers-in-articles)
  * [Configuring redirects](https://docs.github.com/en/contributing/writing-for-github-docs/configuring-redirects)
  * [Changing an article's title](https://docs.github.com/en/contributing/writing-for-github-docs/changing-an-articles-title)
  * [Annotating code examples](https://docs.github.com/en/contributing/writing-for-github-docs/annotating-code-examples)
  * [Templates](https://docs.github.com/en/contributing/writing-for-github-docs/templates)


### [Style guide and content model](https://docs.github.com/en/contributing/style-guide-and-content-model)
  * [Style guide](https://docs.github.com/en/contributing/style-guide-and-content-model/style-guide)
  * [About the content model](https://docs.github.com/en/contributing/style-guide-and-content-model/about-the-content-model)
  * [Contents of a GitHub Docs article](https://docs.github.com/en/contributing/style-guide-and-content-model/contents-of-a-github-docs-article)
  * [About topics](https://docs.github.com/en/contributing/style-guide-and-content-model/about-topics)
  * [Conceptual content type](https://docs.github.com/en/contributing/style-guide-and-content-model/conceptual-content-type)
  * [Referential content type](https://docs.github.com/en/contributing/style-guide-and-content-model/referential-content-type)
  * [Procedural content type](https://docs.github.com/en/contributing/style-guide-and-content-model/procedural-content-type)
  * [Troubleshooting content type](https://docs.github.com/en/contributing/style-guide-and-content-model/troubleshooting-content-type)
  * [Release note content type](https://docs.github.com/en/contributing/style-guide-and-content-model/release-note-content-type)
  * [Quickstart content type](https://docs.github.com/en/contributing/style-guide-and-content-model/quickstart-content-type)
  * [Tutorial content type](https://docs.github.com/en/contributing/style-guide-and-content-model/tutorial-content-type)
  * [About combining multiple content types](https://docs.github.com/en/contributing/style-guide-and-content-model/about-combining-multiple-content-types)


### [Collaborating on GitHub Docs](https://docs.github.com/en/contributing/collaborating-on-github-docs)
  * [About contributing to GitHub Docs](https://docs.github.com/en/contributing/collaborating-on-github-docs/about-contributing-to-github-docs)
  * [Using Git on GitHub Docs](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-git-on-github-docs)
  * [Using the TODOCS placeholder to leave notes](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-the-todocs-placeholder-to-leave-notes)
  * [Using the content linter](https://docs.github.com/en/contributing/collaborating-on-github-docs/using-the-content-linter)
  * [Label reference](https://docs.github.com/en/contributing/collaborating-on-github-docs/label-reference)


### [Setting up your environment to work on GitHub Docs](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs)
  * [Working on GitHub Docs in a codespace](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/working-on-github-docs-in-a-codespace)
  * [Creating a local environment](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/creating-a-local-environment)
  * [Troubleshooting your environment](https://docs.github.com/en/contributing/setting-up-your-environment-to-work-on-github-docs/troubleshooting-your-environment)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/contributing/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)
