[Skip to main content](https://docs.github.com/en/rest?apiversion=2022-11-28&apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
# GitHub REST API documentation
Create integrations, retrieve data, and automate your workflows with the GitHub REST API.
[Overview ](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)[Quickstart ](https://docs.github.com/en/rest/quickstart)
## Start here
[View all ](https://docs.github.com/en/rest/guides)
  * ### [About the REST API Get oriented to the REST API documentation. ](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
  * ### [Getting started with the REST API Learn how to use the GitHub REST API. ](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
  * ### [Authenticating to the REST API You can authenticate to the REST API to access more endpoints and have a higher rate limit. ](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
  * ### [Best practices for using the REST API Follow these best practices when using GitHub's API. ](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)


## Popular
  * ### [Rate limits for the REST API Learn about REST API rate limits, how to avoid exceeding them, and what to do if you do exceed them. ](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
  * ### [Troubleshooting the REST API Learn how to diagnose and resolve common problems for the REST API. ](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
  * ### [Scripting with the REST API and JavaScript Write a script using the Octokit.js SDK to interact with the REST API. ](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
  * ### [Keeping your API credentials secure Follow these best practices to keep your API credentials and tokens secure. ](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)


## [Guides](https://docs.github.com/en/rest?apiversion=2022-11-28&apiVersion=2022-11-28#guides-2)
  * ### [Delivering deployments Using the Deployments REST API, you can build custom tooling that interacts with your server and a third-party app. @GitHub](https://docs.github.com/en/rest/guides/delivering-deployments)
  * ### [Using the REST API to interact with checks You can use the REST API to build GitHub Apps that run powerful checks against code changes in a repository. You can create apps that perform continuous integration, code linting, or code scanning services and provide detailed feedback on commits. @GitHub](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
  * ### [Using pagination in the REST API Learn how to navigate through paginated responses from the REST API. @GitHub](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)


[Explore guides ](https://docs.github.com/en/rest/guides)
## [All REST API docs](https://docs.github.com/en/rest?apiversion=2022-11-28&apiVersion=2022-11-28#all-docs)
### [About the REST API](https://docs.github.com/en/rest/about-the-rest-api)
  * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
  * [Comparing GitHub's REST API and GraphQL API](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
  * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
  * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
  * [About the OpenAPI description for the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)


### [Using the REST API](https://docs.github.com/en/rest/using-the-rest-api)
  * [Getting started with the REST API](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
  * [Rate limits for the REST API](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
  * [Using pagination in the REST API](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
  * [Libraries for the REST API](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
  * [Best practices for using the REST API](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
  * [Troubleshooting the REST API](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
  * [Timezones and the REST API](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
  * [Using CORS and JSONP to make cross-origin requests](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
  * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
  * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)


### [Authenticating to the REST API](https://docs.github.com/en/rest/authentication)
  * [Authenticating to the REST API](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
  * [Keeping your API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
  * [Endpoints available for GitHub App installation access tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
  * [Endpoints available for GitHub App user access tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
  * [Endpoints available for fine-grained personal access tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
  * [Permissions required for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
  * [Permissions required for fine-grained personal access tokens](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)


### [Guides](https://docs.github.com/en/rest/guides)
  * [Scripting with the REST API and JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
  * [Scripting with the REST API and Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
  * [Discovering resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
  * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
  * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
  * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
  * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
  * [Using the REST API to interact with your Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
  * [Using the REST API to interact with checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
  * [Encrypting secrets for the REST API](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


### [REST API endpoints for GitHub Actions](https://docs.github.com/en/rest/actions)
  * [REST API endpoints for GitHub Actions artifacts](https://docs.github.com/en/rest/actions/artifacts)
  * [REST API endpoints for GitHub Actions cache](https://docs.github.com/en/rest/actions/cache)
  * [GitHub-hosted runners](https://docs.github.com/en/rest/actions/hosted-runners)
  * [REST API endpoints for GitHub Actions OIDC](https://docs.github.com/en/rest/actions/oidc)
  * [REST API endpoints for GitHub Actions permissions](https://docs.github.com/en/rest/actions/permissions)
  * [REST API endpoints for GitHub Actions Secrets](https://docs.github.com/en/rest/actions/secrets)
  * [REST API endpoints for self-hosted runner groups](https://docs.github.com/en/rest/actions/self-hosted-runner-groups)
  * [REST API endpoints for self-hosted runners](https://docs.github.com/en/rest/actions/self-hosted-runners)
  * [REST API endpoints for GitHub Actions variables](https://docs.github.com/en/rest/actions/variables)
  * [REST API endpoints for workflow jobs](https://docs.github.com/en/rest/actions/workflow-jobs)
  * [REST API endpoints for workflow runs](https://docs.github.com/en/rest/actions/workflow-runs)
  * [REST API endpoints for workflows](https://docs.github.com/en/rest/actions/workflows)


### [REST API endpoints for activity](https://docs.github.com/en/rest/activity)
  * [REST API endpoints for events](https://docs.github.com/en/rest/activity/events)
  * [REST API endpoints for feeds](https://docs.github.com/en/rest/activity/feeds)
  * [REST API endpoints for notifications](https://docs.github.com/en/rest/activity/notifications)
  * [REST API endpoints for starring](https://docs.github.com/en/rest/activity/starring)
  * [REST API endpoints for watching](https://docs.github.com/en/rest/activity/watching)


### [REST API endpoints for apps](https://docs.github.com/en/rest/apps)
  * [REST API endpoints for GitHub Apps](https://docs.github.com/en/rest/apps/apps)
  * [REST API endpoints for GitHub App installations](https://docs.github.com/en/rest/apps/installations)
  * [REST API endpoints for GitHub Marketplace](https://docs.github.com/en/rest/apps/marketplace)
  * [REST API endpoints for OAuth authorizations](https://docs.github.com/en/rest/apps/oauth-applications)
  * [REST API endpoints for GitHub App webhooks](https://docs.github.com/en/rest/apps/webhooks)


### [REST API endpoints for billing](https://docs.github.com/en/rest/billing)
  * [Budgets](https://docs.github.com/en/rest/billing/budgets)
  * [Billing usage](https://docs.github.com/en/rest/billing/usage)


### [REST API endpoints for branches and their settings](https://docs.github.com/en/rest/branches)
  * [REST API endpoints for branches](https://docs.github.com/en/rest/branches/branches)
  * [REST API endpoints for protected branches](https://docs.github.com/en/rest/branches/branch-protection)


### [REST API endpoints for security campaigns](https://docs.github.com/en/rest/campaigns)
  * [REST API endpoints for security campaigns](https://docs.github.com/en/rest/campaigns/campaigns)


### [REST API endpoints for checks](https://docs.github.com/en/rest/checks)
  * [REST API endpoints for check runs](https://docs.github.com/en/rest/checks/runs)
  * [REST API endpoints for check suites](https://docs.github.com/en/rest/checks/suites)


### [REST API endpoints for GitHub Classroom](https://docs.github.com/en/rest/classroom)
  * [REST API endpoints for GitHub Classroom](https://docs.github.com/en/rest/classroom/classroom)


### [REST API endpoints for code scanning](https://docs.github.com/en/rest/code-scanning)
  * [REST API endpoints for code scanning](https://docs.github.com/en/rest/code-scanning/code-scanning)


### [REST API endpoints for code security settings](https://docs.github.com/en/rest/code-security)
  * [Configurations](https://docs.github.com/en/rest/code-security/configurations)


### [REST API endpoints for codes of conduct](https://docs.github.com/en/rest/codes-of-conduct)
  * [REST API endpoints for codes of conduct](https://docs.github.com/en/rest/codes-of-conduct/codes-of-conduct)


### [REST API endpoints for Codespaces](https://docs.github.com/en/rest/codespaces)
  * [REST API endpoints for Codespaces](https://docs.github.com/en/rest/codespaces/codespaces)
  * [REST API endpoints for Codespaces organizations](https://docs.github.com/en/rest/codespaces/organizations)
  * [REST API endpoints for Codespaces organization secrets](https://docs.github.com/en/rest/codespaces/organization-secrets)
  * [REST API endpoints for Codespaces machines](https://docs.github.com/en/rest/codespaces/machines)
  * [REST API endpoints for Codespaces repository secrets](https://docs.github.com/en/rest/codespaces/repository-secrets)
  * [REST API endpoints for Codespaces user secrets](https://docs.github.com/en/rest/codespaces/secrets)


### [REST API endpoints for collaborators](https://docs.github.com/en/rest/collaborators)
  * [REST API endpoints for collaborators](https://docs.github.com/en/rest/collaborators/collaborators)
  * [REST API endpoints for repository invitations](https://docs.github.com/en/rest/collaborators/invitations)


### [REST API endpoints for commits](https://docs.github.com/en/rest/commits)
  * [REST API endpoints for commits](https://docs.github.com/en/rest/commits/commits)
  * [REST API endpoints for commit comments](https://docs.github.com/en/rest/commits/comments)
  * [REST API endpoints for commit statuses](https://docs.github.com/en/rest/commits/statuses)


### [REST API endpoints for Copilot](https://docs.github.com/en/rest/copilot)
  * [REST API endpoints for Copilot content exclusion management](https://docs.github.com/en/rest/copilot/copilot-content-exclusion-management)
  * [REST API endpoints for Copilot metrics](https://docs.github.com/en/rest/copilot/copilot-metrics)
  * [REST API endpoints for Copilot user management](https://docs.github.com/en/rest/copilot/copilot-user-management)


### [Credentials](https://docs.github.com/en/rest/credentials)
  * [Revocation](https://docs.github.com/en/rest/credentials/revoke)


### [REST API endpoints for Dependabot](https://docs.github.com/en/rest/dependabot)
  * [REST API endpoints for Dependabot alerts](https://docs.github.com/en/rest/dependabot/alerts)
  * [REST API endpoints for Dependabot repository access](https://docs.github.com/en/rest/dependabot/repository-access)
  * [REST API endpoints for Dependabot secrets](https://docs.github.com/en/rest/dependabot/secrets)


### [REST API endpoints for the dependency graph](https://docs.github.com/en/rest/dependency-graph)
  * [REST API endpoints for dependency review](https://docs.github.com/en/rest/dependency-graph/dependency-review)
  * [REST API endpoints for dependency submission](https://docs.github.com/en/rest/dependency-graph/dependency-submission)
  * [REST API endpoints for software bill of materials (SBOM)](https://docs.github.com/en/rest/dependency-graph/sboms)


### [REST API endpoints for deploy keys](https://docs.github.com/en/rest/deploy-keys)
  * [REST API endpoints for deploy keys](https://docs.github.com/en/rest/deploy-keys/deploy-keys)


### [REST API endpoints for deployments](https://docs.github.com/en/rest/deployments)
  * [REST API endpoints for deployment branch policies](https://docs.github.com/en/rest/deployments/branch-policies)
  * [REST API endpoints for deployments](https://docs.github.com/en/rest/deployments/deployments)
  * [REST API endpoints for deployment environments](https://docs.github.com/en/rest/deployments/environments)
  * [REST API endpoints for protection rules](https://docs.github.com/en/rest/deployments/protection-rules)
  * [REST API endpoints for deployment statuses](https://docs.github.com/en/rest/deployments/statuses)


### [REST API endpoints for emojis](https://docs.github.com/en/rest/emojis)
  * [REST API endpoints for emojis](https://docs.github.com/en/rest/emojis/emojis)


### [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams)
  * [REST API endpoints for enterprise team memberships](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-members)
  * [REST API endpoints for enterprise team organizations](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations)
  * [REST API endpoints for enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams)


### [REST API endpoints for gists and gist comments](https://docs.github.com/en/rest/gists)
  * [REST API endpoints for gists](https://docs.github.com/en/rest/gists/gists)
  * [REST API endpoints for gist comments](https://docs.github.com/en/rest/gists/comments)


### [REST API endpoints for Git database](https://docs.github.com/en/rest/git)
  * [REST API endpoints for Git blobs](https://docs.github.com/en/rest/git/blobs)
  * [REST API endpoints for Git commits](https://docs.github.com/en/rest/git/commits)
  * [REST API endpoints for Git references](https://docs.github.com/en/rest/git/refs)
  * [REST API endpoints for Git tags](https://docs.github.com/en/rest/git/tags)
  * [REST API endpoints for Git trees](https://docs.github.com/en/rest/git/trees)


### [REST API endpoints for gitignore](https://docs.github.com/en/rest/gitignore)
  * [REST API endpoints for gitignore](https://docs.github.com/en/rest/gitignore/gitignore)


### [REST API endpoints for interactions](https://docs.github.com/en/rest/interactions)
  * [REST API endpoints for organization interactions](https://docs.github.com/en/rest/interactions/orgs)
  * [REST API endpoints for repository interactions](https://docs.github.com/en/rest/interactions/repos)
  * [REST API endpoints for user interactions](https://docs.github.com/en/rest/interactions/user)


### [REST API endpoints for issues](https://docs.github.com/en/rest/issues)
  * [REST API endpoints for issue assignees](https://docs.github.com/en/rest/issues/assignees)
  * [REST API endpoints for issue comments](https://docs.github.com/en/rest/issues/comments)
  * [REST API endpoints for issue events](https://docs.github.com/en/rest/issues/events)
  * [REST API endpoints for issues](https://docs.github.com/en/rest/issues/issues)
  * [REST API endpoints for issue dependencies](https://docs.github.com/en/rest/issues/issue-dependencies)
  * [REST API endpoints for labels](https://docs.github.com/en/rest/issues/labels)
  * [REST API endpoints for milestones](https://docs.github.com/en/rest/issues/milestones)
  * [REST API endpoints for sub-issues](https://docs.github.com/en/rest/issues/sub-issues)
  * [REST API endpoints for timeline events](https://docs.github.com/en/rest/issues/timeline)


### [REST API endpoints for licenses](https://docs.github.com/en/rest/licenses)
  * [REST API endpoints for licenses](https://docs.github.com/en/rest/licenses/licenses)


### [REST API endpoints for Markdown](https://docs.github.com/en/rest/markdown)
  * [REST API endpoints for Markdown](https://docs.github.com/en/rest/markdown/markdown)


### [REST API endpoints for meta data](https://docs.github.com/en/rest/meta)
  * [REST API endpoints for meta data](https://docs.github.com/en/rest/meta/meta)


### [REST API endpoints for metrics](https://docs.github.com/en/rest/metrics)
  * [REST API endpoints for community metrics](https://docs.github.com/en/rest/metrics/community)
  * [REST API endpoints for repository statistics](https://docs.github.com/en/rest/metrics/statistics)
  * [REST API endpoints for repository traffic](https://docs.github.com/en/rest/metrics/traffic)


### [REST API endpoints for migrations](https://docs.github.com/en/rest/migrations)
  * [REST API endpoints for organization migrations](https://docs.github.com/en/rest/migrations/orgs)
  * [REST API endpoints for source imports](https://docs.github.com/en/rest/migrations/source-imports)
  * [REST API endpoints for user migrations](https://docs.github.com/en/rest/migrations/users)


### [Models](https://docs.github.com/en/rest/models)
  * [REST API endpoints for models catalog](https://docs.github.com/en/rest/models/catalog)
  * [REST API endpoints for model embeddings](https://docs.github.com/en/rest/models/embeddings)
  * [REST API endpoints for models inference](https://docs.github.com/en/rest/models/inference)


### [REST API endpoints for organizations](https://docs.github.com/en/rest/orgs)
  * [REST API endpoints for API Insights](https://docs.github.com/en/rest/orgs/api-insights)
  * [REST API endpoints for artifact metadata](https://docs.github.com/en/rest/orgs/artifact-metadata)
  * [REST API endpoints for artifact attestations](https://docs.github.com/en/rest/orgs/attestations)
  * [REST API endpoints for blocking users](https://docs.github.com/en/rest/orgs/blocking)
  * [REST API endpoints for custom properties](https://docs.github.com/en/rest/orgs/custom-properties)
  * [REST API endpoints for issue types](https://docs.github.com/en/rest/orgs/issue-types)
  * [REST API endpoints for organization members](https://docs.github.com/en/rest/orgs/members)
  * [REST API endpoints for network configurations](https://docs.github.com/en/rest/orgs/network-configurations)
  * [REST API endpoints for organization roles](https://docs.github.com/en/rest/orgs/organization-roles)
  * [REST API endpoints for organizations](https://docs.github.com/en/rest/orgs/orgs)
  * [REST API endpoints for outside collaborators](https://docs.github.com/en/rest/orgs/outside-collaborators)
  * [REST API endpoints for personal access tokens](https://docs.github.com/en/rest/orgs/personal-access-tokens)
  * [REST API endpoints for rule suites](https://docs.github.com/en/rest/orgs/rule-suites)
  * [REST API endpoints for rules](https://docs.github.com/en/rest/orgs/rules)
  * [REST API endpoints for security managers](https://docs.github.com/en/rest/orgs/security-managers)
  * [REST API endpoints for organization webhooks](https://docs.github.com/en/rest/orgs/webhooks)


### [REST API endpoints for packages](https://docs.github.com/en/rest/packages)
  * [REST API endpoints for packages](https://docs.github.com/en/rest/packages/packages)


### [REST API endpoints for GitHub Pages](https://docs.github.com/en/rest/pages)
  * [REST API endpoints for GitHub Pages](https://docs.github.com/en/rest/pages/pages)


### [Private registries](https://docs.github.com/en/rest/private-registries)
  * [Organization configurations](https://docs.github.com/en/rest/private-registries/organization-configurations)


### [Projects](https://docs.github.com/en/rest/projects)
  * [REST API endpoints for draft Project items](https://docs.github.com/en/rest/projects/drafts)
  * [REST API endpoints for Project fields](https://docs.github.com/en/rest/projects/fields)
  * [REST API endpoints for Project items](https://docs.github.com/en/rest/projects/items)
  * [REST API endpoints for Projects](https://docs.github.com/en/rest/projects/projects)
  * [REST API endpoints for Project views](https://docs.github.com/en/rest/projects/views)


### [REST API endpoints for pull requests](https://docs.github.com/en/rest/pulls)
  * [REST API endpoints for pull requests](https://docs.github.com/en/rest/pulls/pulls)
  * [REST API endpoints for pull request review comments](https://docs.github.com/en/rest/pulls/comments)
  * [REST API endpoints for review requests](https://docs.github.com/en/rest/pulls/review-requests)
  * [REST API endpoints for pull request reviews](https://docs.github.com/en/rest/pulls/reviews)


### [REST API endpoints for rate limits](https://docs.github.com/en/rest/rate-limit)
  * [REST API endpoints for rate limits](https://docs.github.com/en/rest/rate-limit/rate-limit)


### [REST API endpoints for reactions](https://docs.github.com/en/rest/reactions)
  * [REST API endpoints for reactions](https://docs.github.com/en/rest/reactions/reactions)


### [REST API endpoints for releases and release assets](https://docs.github.com/en/rest/releases)
  * [REST API endpoints for releases](https://docs.github.com/en/rest/releases/releases)
  * [REST API endpoints for release assets](https://docs.github.com/en/rest/releases/assets)


### [REST API endpoints for repositories](https://docs.github.com/en/rest/repos)
  * [REST API endpoints for repository attestations](https://docs.github.com/en/rest/repos/attestations)
  * [REST API endpoints for repository autolinks](https://docs.github.com/en/rest/repos/autolinks)
  * [REST API endpoints for repository contents](https://docs.github.com/en/rest/repos/contents)
  * [REST API endpoints for custom properties](https://docs.github.com/en/rest/repos/custom-properties)
  * [REST API endpoints for forks](https://docs.github.com/en/rest/repos/forks)
  * [REST API endpoints for repositories](https://docs.github.com/en/rest/repos/repos)
  * [REST API endpoints for rule suites](https://docs.github.com/en/rest/repos/rule-suites)
  * [REST API endpoints for rules](https://docs.github.com/en/rest/repos/rules)
  * [REST API endpoints for repository webhooks](https://docs.github.com/en/rest/repos/webhooks)


### [REST API endpoints for search](https://docs.github.com/en/rest/search)
  * [REST API endpoints for search](https://docs.github.com/en/rest/search/search)


### [REST API endpoints for secret scanning](https://docs.github.com/en/rest/secret-scanning)
  * [REST API endpoints for secret scanning push protection](https://docs.github.com/en/rest/secret-scanning/push-protection)
  * [REST API endpoints for secret scanning](https://docs.github.com/en/rest/secret-scanning/secret-scanning)


### [REST API endpoints for security advisories](https://docs.github.com/en/rest/security-advisories)
  * [REST API endpoints for global security advisories](https://docs.github.com/en/rest/security-advisories/global-advisories)
  * [REST API endpoints for repository security advisories](https://docs.github.com/en/rest/security-advisories/repository-advisories)


### [REST API endpoints for teams](https://docs.github.com/en/rest/teams)
  * [REST API endpoints for team members](https://docs.github.com/en/rest/teams/members)
  * [REST API endpoints for teams](https://docs.github.com/en/rest/teams/teams)


### [REST API endpoints for users](https://docs.github.com/en/rest/users)
  * [REST API endpoints for artifact attestations](https://docs.github.com/en/rest/users/attestations)
  * [REST API endpoints for blocking users](https://docs.github.com/en/rest/users/blocking)
  * [REST API endpoints for emails](https://docs.github.com/en/rest/users/emails)
  * [REST API endpoints for followers](https://docs.github.com/en/rest/users/followers)
  * [REST API endpoints for GPG keys](https://docs.github.com/en/rest/users/gpg-keys)
  * [REST API endpoints for Git SSH keys](https://docs.github.com/en/rest/users/keys)
  * [REST API endpoints for social accounts](https://docs.github.com/en/rest/users/social-accounts)
  * [REST API endpoints for SSH signing keys](https://docs.github.com/en/rest/users/ssh-signing-keys)
  * [REST API endpoints for users](https://docs.github.com/en/rest/users/users)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


GitHub REST API documentation - GitHub Docs
