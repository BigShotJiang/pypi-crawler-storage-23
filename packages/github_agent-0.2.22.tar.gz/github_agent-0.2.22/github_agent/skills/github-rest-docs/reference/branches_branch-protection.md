[Skip to main content](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Branches](https://docs.github.com/en/rest/branches "Branches")/
  * [Protected branches](https://docs.github.com/en/rest/branches/branch-protection "Protected branches")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
      * [Get branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection)
      * [Update branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection)
      * [Delete branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection)
      * [Get admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection)
      * [Set admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection)
      * [Delete admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection)
      * [Get pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection)
      * [Update pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection)
      * [Delete pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection)
      * [Get commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection)
      * [Create commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection)
      * [Delete commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection)
      * [Get status checks protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection)
      * [Update status check protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection)
      * [Remove status check protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection)
      * [Get all status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts)
      * [Add status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts)
      * [Set status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts)
      * [Remove status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts)
      * [Get access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions)
      * [Delete access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions)
      * [Get apps with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch)
      * [Add app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions)
      * [Set app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions)
      * [Remove app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions)
      * [Get teams with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch)
      * [Add team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions)
      * [Set team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions)
      * [Remove team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions)
      * [Get users with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch)
      * [Add user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions)
      * [Set user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions)
      * [Remove user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions)
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Branches](https://docs.github.com/en/rest/branches "Branches")/
  * [Protected branches](https://docs.github.com/en/rest/branches/branch-protection "Protected branches")


# REST API endpoints for protected branches
Use the REST API to manage protected branches.
## [Get branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Get branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-branch-protection--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection",   "required_status_checks": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks",     "contexts": [       "continuous-integration/travis-ci"     ],     "contexts_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks/contexts",     "enforcement_level": "non_admins"   },   "enforce_admins": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/enforce_admins",     "enabled": true   },   "required_pull_request_reviews": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_pull_request_reviews",     "dismissal_restrictions": {       "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions",       "users_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/users",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/teams",       "users": [         {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         }       ],       "teams": [         {           "id": 1,           "node_id": "MDQ6VGVhbTE=",           "url": "https://api.github.com/teams/1",           "html_url": "https://github.com/orgs/github/teams/justice-league",           "name": "Justice League",           "slug": "justice-league",           "description": "A great team.",           "privacy": "closed",           "notification_setting": "notifications_enabled",           "permission": "admin",           "members_url": "https://api.github.com/teams/1/members{/member}",           "repositories_url": "https://api.github.com/teams/1/repos",           "parent": null         }       ],       "apps": [         {           "id": 1,           "slug": "octoapp",           "node_id": "MDExOkludGVncmF0aW9uMQ==",           "owner": {             "login": "github",             "id": 1,             "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",             "url": "https://api.github.com/orgs/github",             "repos_url": "https://api.github.com/orgs/github/repos",             "events_url": "https://api.github.com/orgs/github/events",             "hooks_url": "https://api.github.com/orgs/github/hooks",             "issues_url": "https://api.github.com/orgs/github/issues",             "members_url": "https://api.github.com/orgs/github/members{/member}",             "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",             "avatar_url": "https://github.com/images/error/octocat_happy.gif",             "description": "A great organization"           },           "name": "Octocat App",           "description": "",           "external_url": "https://example.com",           "html_url": "https://github.com/apps/octoapp",           "created_at": "2017-07-08T16:18:44-04:00",           "updated_at": "2017-07-08T16:18:44-04:00",           "permissions": {             "metadata": "read",             "contents": "read",             "issues": "write",             "single_file": "write"           },           "events": [             "push",             "pull_request"           ]         }       ]     },     "dismiss_stale_reviews": true,     "require_code_owner_reviews": true,     "required_approving_review_count": 2,     "require_last_push_approval": true   },   "restrictions": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions",     "users_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/users",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/teams",     "apps_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/apps",     "users": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     ],     "teams": [       {         "id": 1,         "node_id": "MDQ6VGVhbTE=",         "url": "https://api.github.com/teams/1",         "html_url": "https://github.com/orgs/github/teams/justice-league",         "name": "Justice League",         "slug": "justice-league",         "description": "A great team.",         "privacy": "closed",         "notification_setting": "notifications_enabled",         "permission": "admin",         "members_url": "https://api.github.com/teams/1/members{/member}",         "repositories_url": "https://api.github.com/teams/1/repos",         "parent": null       }     ],     "apps": [       {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "hooks_url": "https://api.github.com/orgs/github/hooks",           "issues_url": "https://api.github.com/orgs/github/issues",           "members_url": "https://api.github.com/orgs/github/members{/member}",           "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "description": "A great organization"         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       }     ]   },   "required_linear_history": {     "enabled": true   },   "allow_force_pushes": {     "enabled": true   },   "allow_deletions": {     "enabled": true   },   "required_conversation_resolution": {     "enabled": true   },   "lock_branch": {     "enabled": true   },   "allow_fork_syncing": {     "enabled": true   } }`
## [Update branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Protecting a branch requires admin or owner permissions to the repository.
Passing new arrays of `users` and `teams` replaces their previous values.
The list of users, apps, and teams in total is limited to 100 items.
### [Fine-grained access tokens for "Update branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`required_status_checks` object or null Required Require status checks to pass before merging. Set to `null` to disable.
Properties of `required_status_checks` | Name, Type, Description
---
`strict` boolean Required Require branches to be up to date before merging.
`contexts` array of strings Required **Closing down notice** : The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control.
`checks` array of objects The list of status checks to require in order to merge into this branch.
Properties of `checks` | Name, Type, Description
---
`context` string Required The name of the required check
`app_id` integer The ID of the GitHub App that must provide this check. Omit this field to automatically select the GitHub App that has recently provided this check, or any app if it was not set by a GitHub App. Pass -1 to explicitly allow any app to set the status.
`enforce_admins` boolean or null Required Enforce all configured restrictions for administrators. Set to `true` to enforce required status checks for repository administrators. Set to `null` to disable.
`required_pull_request_reviews` object or null Required Require at least one approving review on a pull request, before merging. Set to `null` to disable.
Properties of `required_pull_request_reviews` | Name, Type, Description
---
`dismissal_restrictions` object Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories.
Properties of `dismissal_restrictions` | Name, Type, Description
---
`users` array of strings The list of user `login`s with dismissal access
`teams` array of strings The list of team `slug`s with dismissal access
`apps` array of strings The list of app `slug`s with dismissal access
`dismiss_stale_reviews` boolean Set to `true` if you want to automatically dismiss approving reviews when someone pushes a new commit.
`require_code_owner_reviews` boolean Blocks merging pull requests until [code owners](https://docs.github.com/articles/about-code-owners/) review them.
`required_approving_review_count` integer Specify the number of reviewers required to approve pull requests. Use a number between 1 and 6 or 0 to not require reviewers.
`require_last_push_approval` boolean Whether the most recent push must be approved by someone other than the person who pushed it. Default: `false`. Default: `false`
`bypass_pull_request_allowances` object Allow specific users, teams, or apps to bypass pull request requirements.
Properties of `bypass_pull_request_allowances` | Name, Type, Description
---
`users` array of strings The list of user `login`s allowed to bypass pull request requirements.
`teams` array of strings The list of team `slug`s allowed to bypass pull request requirements.
`apps` array of strings The list of app `slug`s allowed to bypass pull request requirements.
`restrictions` object or null Required Restrict who can push to the protected branch. User, app, and team `restrictions` are only available for organization-owned repositories. Set to `null` to disable.
Properties of `restrictions` | Name, Type, Description
---
`users` array of strings Required The list of user `login`s with push access
`teams` array of strings Required The list of team `slug`s with push access
`apps` array of strings The list of app `slug`s with push access
`required_linear_history` boolean Enforces a linear commit Git history, which prevents anyone from pushing merge commits to a branch. Set to `true` to enforce a linear commit history. Set to `false` to disable a linear commit Git history. Your repository must allow squash merging or rebase merging before you can enable a linear commit history. Default: `false`. For more information, see "[Requiring a linear commit history](https://docs.github.com/github/administering-a-repository/requiring-a-linear-commit-history)" in the GitHub Help documentation.
`allow_force_pushes` boolean or null Permits force pushes to the protected branch by anyone with write access to the repository. Set to `true` to allow force pushes. Set to `false` or `null` to block force pushes. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation."
`allow_deletions` boolean Allows deletion of the protected branch by anyone with write access to the repository. Set to `false` to prevent deletion of the protected branch. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation.
`block_creations` boolean If set to `true`, the `restrictions` branch protection settings which limits who can push will also block pushes which create new branches, unless the push is initiated by a user, team, or app which has the ability to push. Set to `true` to restrict new branch creation. Default: `false`.
`required_conversation_resolution` boolean Requires all conversations on code to be resolved before a pull request can be merged into a branch that matches this rule. Set to `false` to disable. Default: `false`.
`lock_branch` boolean Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. Default: `false`. Default: `false`
`allow_fork_syncing` boolean Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. Default: `false`. Default: `false`
### [HTTP response status codes for "Update branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-branch-protection--code-samples)
#### Request example
put/repos/{owner}/{repo}/branches/{branch}/protection
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection \   -d '{"required_status_checks":{"strict":true,"contexts":["continuous-integration/travis-ci"]},"enforce_admins":true,"required_pull_request_reviews":{"dismissal_restrictions":{"users":["octocat"],"teams":["justice-league"]},"dismiss_stale_reviews":true,"require_code_owner_reviews":true,"required_approving_review_count":2,"require_last_push_approval":true,"bypass_pull_request_allowances":{"users":["octocat"],"teams":["justice-league"]}},"restrictions":{"users":["octocat"],"teams":["justice-league"],"apps":["super-ci"]},"required_linear_history":true,"allow_force_pushes":true,"allow_deletions":true,"block_creations":true,"required_conversation_resolution":true,"lock_branch":true,"allow_fork_syncing":true}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection",   "required_status_checks": {     "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/required_status_checks",     "strict": true,     "contexts": [       "continuous-integration/travis-ci"     ],     "contexts_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/required_status_checks/contexts",     "checks": [       {         "context": "continuous-integration/travis-ci",         "app_id": null       }     ]   },   "restrictions": {     "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/restrictions",     "users_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/restrictions/users",     "teams_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/restrictions/teams",     "apps_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/restrictions/apps",     "users": [],     "teams": [],     "apps": []   },   "required_pull_request_reviews": {     "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/required_pull_request_reviews",     "dismiss_stale_reviews": true,     "require_code_owner_reviews": true,     "required_approving_review_count": 2,     "require_last_push_approval": true,     "dismissal_restrictions": {       "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/dismissal_restrictions",       "users_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/dismissal_restrictions/users",       "teams_url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/dismissal_restrictions/teams",       "users": [],       "teams": [],       "apps": []     }   },   "required_signatures": {     "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/required_signatures",     "enabled": false   },   "enforce_admins": {     "url": "https://api.github.com/repos/octocat/hello-world/branches/main/protection/enforce_admins",     "enabled": true   },   "required_linear_history": {     "enabled": true   },   "allow_force_pushes": {     "enabled": true   },   "allow_deletions": {     "enabled": true   },   "block_creations": {     "enabled": true   },   "required_conversation_resolution": {     "enabled": true   },   "lock_branch": {     "enabled": true   },   "allow_fork_syncing": {     "enabled": true   } }`
## [Delete branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Delete branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Delete branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection--status-codes)
Status code | Description
---|---
`204` | No Content
`403` | Forbidden
### [Code samples for "Delete branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-branch-protection--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection`
Response
`Status: 204`
## [Get admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Get admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-admin-branch-protection--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/enforce_admins`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/enforce_admins",   "enabled": true }`
## [Set admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Adding admin enforcement requires admin or owner permissions to the repository and branch protection to be enabled.
### [Fine-grained access tokens for "Set admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Set admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Set admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-admin-branch-protection--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/enforce_admins`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/enforce_admins",   "enabled": true }`
## [Delete admin branch protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Removing admin enforcement requires admin or owner permissions to the repository and branch protection to be enabled.
### [Fine-grained access tokens for "Delete admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Delete admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete admin branch protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-admin-branch-protection--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/enforce_admins`
Response
`Status: 204`
## [Get pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Get pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-pull-request-review-protection--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_pull_request_reviews`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_pull_request_reviews",   "dismissal_restrictions": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions",     "users_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/users",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/teams",     "users": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     ],     "teams": [       {         "id": 1,         "node_id": "MDQ6VGVhbTE=",         "url": "https://api.github.com/teams/1",         "html_url": "https://github.com/orgs/github/teams/justice-league",         "name": "Justice League",         "slug": "justice-league",         "description": "A great team.",         "privacy": "closed",         "notification_setting": "notifications_enabled",         "permission": "admin",         "members_url": "https://api.github.com/teams/1/members{/member}",         "repositories_url": "https://api.github.com/teams/1/repos",         "parent": null       }     ],     "apps": [       {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "hooks_url": "https://api.github.com/orgs/github/hooks",           "issues_url": "https://api.github.com/orgs/github/issues",           "members_url": "https://api.github.com/orgs/github/members{/member}",           "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "description": "A great organization"         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       }     ]   },   "dismiss_stale_reviews": true,   "require_code_owner_reviews": true,   "required_approving_review_count": 2,   "require_last_push_approval": true }`
## [Update pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Updating pull request review enforcement requires admin or owner permissions to the repository and branch protection to be enabled.
Passing new arrays of `users` and `teams` replaces their previous values.
### [Fine-grained access tokens for "Update pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`dismissal_restrictions` object Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories.
Properties of `dismissal_restrictions` | Name, Type, Description
---
`users` array of strings The list of user `login`s with dismissal access
`teams` array of strings The list of team `slug`s with dismissal access
`apps` array of strings The list of app `slug`s with dismissal access
`dismiss_stale_reviews` boolean Set to `true` if you want to automatically dismiss approving reviews when someone pushes a new commit.
`require_code_owner_reviews` boolean Blocks merging pull requests until [code owners](https://docs.github.com/articles/about-code-owners/) have reviewed.
`required_approving_review_count` integer Specifies the number of reviewers required to approve pull requests. Use a number between 1 and 6 or 0 to not require reviewers.
`require_last_push_approval` boolean Whether the most recent push must be approved by someone other than the person who pushed it. Default: `false` Default: `false`
`bypass_pull_request_allowances` object Allow specific users, teams, or apps to bypass pull request requirements.
Properties of `bypass_pull_request_allowances` | Name, Type, Description
---
`users` array of strings The list of user `login`s allowed to bypass pull request requirements.
`teams` array of strings The list of team `slug`s allowed to bypass pull request requirements.
`apps` array of strings The list of app `slug`s allowed to bypass pull request requirements.
### [HTTP response status codes for "Update pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-pull-request-review-protection--code-samples)
#### Request example
patch/repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_pull_request_reviews \   -d '{"dismissal_restrictions":{"users":["octocat"],"teams":["justice-league"],"apps":["octoapp"]},"bypass_pull_request_allowances":{"users":["octocat"],"teams":["justice-league"],"apps":["octoapp"]},"dismiss_stale_reviews":true,"require_code_owner_reviews":true,"required_approving_review_count":2,"require_last_push_approval":true}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_pull_request_reviews",   "dismissal_restrictions": {     "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions",     "users_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/users",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/dismissal_restrictions/teams",     "users": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     ],     "teams": [       {         "id": 1,         "node_id": "MDQ6VGVhbTE=",         "url": "https://api.github.com/teams/1",         "html_url": "https://github.com/orgs/github/teams/justice-league",         "name": "Justice League",         "slug": "justice-league",         "description": "A great team.",         "privacy": "closed",         "notification_setting": "notifications_enabled",         "permission": "admin",         "members_url": "https://api.github.com/teams/1/members{/member}",         "repositories_url": "https://api.github.com/teams/1/repos",         "parent": null       }     ],     "apps": [       {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "hooks_url": "https://api.github.com/orgs/github/hooks",           "issues_url": "https://api.github.com/orgs/github/issues",           "members_url": "https://api.github.com/orgs/github/members{/member}",           "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "description": "A great organization"         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       }     ]   },   "dismiss_stale_reviews": true,   "require_code_owner_reviews": true,   "required_approving_review_count": 2,   "require_last_push_approval": true }`
## [Delete pull request review protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Delete pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Delete pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete pull request review protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-pull-request-review-protection--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_pull_request_reviews`
Response
`Status: 204`
## [Get commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
When authenticated with admin or owner permissions to the repository, you can use this endpoint to check whether a branch requires signed commits. An enabled status of `true` indicates you must sign commits on this branch. For more information, see [Signing commits with GPG](https://docs.github.com/articles/signing-commits-with-gpg) in GitHub Help.
You must enable branch protection to require signed commits.
### [Fine-grained access tokens for "Get commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-commit-signature-protection--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/required_signatures
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_signatures`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_signatures",   "enabled": true }`
## [Create commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
When authenticated with admin or owner permissions to the repository, you can use this endpoint to require signed commits on a branch. You must enable branch protection to require signed commits.
### [Fine-grained access tokens for "Create commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Create commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Create commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#create-commit-signature-protection--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/required_signatures
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_signatures`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_signatures",   "enabled": true }`
## [Delete commit signature protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
When authenticated with admin or owner permissions to the repository, you can use this endpoint to disable required signed commits on a branch. You must enable branch protection to require signed commits.
### [Fine-grained access tokens for "Delete commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Delete commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete commit signature protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-commit-signature-protection--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/required_signatures
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_signatures`
Response
`Status: 204`
## [Get status checks protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Get status checks protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get status checks protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get status checks protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get status checks protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-status-checks-protection--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks",   "strict": true,   "contexts": [     "continuous-integration/travis-ci"   ],   "contexts_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks/contexts" }`
## [Update status check protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Updating required status checks requires admin or owner permissions to the repository and branch protection to be enabled.
### [Fine-grained access tokens for "Update status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`strict` boolean Require branches to be up to date before merging.
`contexts` array of strings **Closing down notice** : The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control.
`checks` array of objects The list of status checks to require in order to merge into this branch.
Properties of `checks` | Name, Type, Description
---
`context` string Required The name of the required check
`app_id` integer The ID of the GitHub App that must provide this check. Omit this field to automatically select the GitHub App that has recently provided this check, or any app if it was not set by a GitHub App. Pass -1 to explicitly allow any app to set the status.
### [HTTP response status codes for "Update status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#update-status-check-protection--code-samples)
#### Request example
patch/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks \   -d '{"strict":true,"contexts":["continuous-integration/travis-ci"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks",   "strict": true,   "contexts": [     "continuous-integration/travis-ci"   ],   "contexts_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/required_status_checks/contexts" }`
## [Remove status check protection](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Remove status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Remove status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove status check protection"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-protection--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks`
Response
`Status: 204`
## [Get all status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Get all status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get all status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get all status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get all status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-all-status-check-contexts--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks/contexts`
Response
  * Example response
  * Response schema


`Status: 200`
`[   "continuous-integration/travis-ci" ]`
## [Add status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Add status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Add status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`contexts` array of strings Required The name of the status checks
### [HTTP response status codes for "Add status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-status-check-contexts--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks/contexts \   -d '{"contexts":["continuous-integration/travis-ci","continuous-integration/jenkins"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   "continuous-integration/travis-ci",   "continuous-integration/jenkins" ]`
## [Set status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Set status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`contexts` array of strings Required The name of the status checks
### [HTTP response status codes for "Set status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-status-check-contexts--code-samples)
#### Request example
put/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks/contexts \   -d '{"contexts":["continuous-integration/travis-ci"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   "continuous-integration/travis-ci" ]`
## [Remove status check contexts](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
### [Fine-grained access tokens for "Remove status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`contexts` array of strings Required The name of the status checks
### [HTTP response status codes for "Remove status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove status check contexts"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-status-check-contexts--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/required_status_checks/contexts \   -d '{"contexts":["continuous-integration/jenkins"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   "continuous-integration/travis-ci" ]`
## [Get access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Lists who has access to this protected branch.
Users, apps, and teams `restrictions` are only available for organization-owned repositories.
### [Fine-grained access tokens for "Get access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-access-restrictions--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/restrictions
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions",   "users_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/users",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/teams",   "apps_url": "https://api.github.com/repos/octocat/Hello-World/branches/master/protection/restrictions/apps",   "users": [     {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   ],   "teams": [     {       "id": 1,       "node_id": "MDQ6VGVhbTE=",       "url": "https://api.github.com/teams/1",       "html_url": "https://github.com/orgs/github/teams/justice-league",       "name": "Justice League",       "slug": "justice-league",       "description": "A great team.",       "privacy": "closed",       "notification_setting": "notifications_enabled",       "permission": "admin",       "members_url": "https://api.github.com/teams/1/members{/member}",       "repositories_url": "https://api.github.com/teams/1/repos",       "parent": null     }   ],   "apps": [     {       "id": 1,       "slug": "octoapp",       "node_id": "MDExOkludGVncmF0aW9uMQ==",       "owner": {         "login": "github",         "id": 1,         "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",         "url": "https://api.github.com/orgs/github",         "repos_url": "https://api.github.com/orgs/github/repos",         "events_url": "https://api.github.com/orgs/github/events",         "hooks_url": "https://api.github.com/orgs/github/hooks",         "issues_url": "https://api.github.com/orgs/github/issues",         "members_url": "https://api.github.com/orgs/github/members{/member}",         "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "description": "A great organization"       },       "name": "Octocat App",       "description": "",       "external_url": "https://example.com",       "html_url": "https://github.com/apps/octoapp",       "created_at": "2017-07-08T16:18:44-04:00",       "updated_at": "2017-07-08T16:18:44-04:00",       "permissions": {         "metadata": "read",         "contents": "read",         "issues": "write",         "single_file": "write"       },       "events": [         "push",         "pull_request"       ]     }   ] }`
## [Delete access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Disables the ability to restrict who can push to this branch.
### [Fine-grained access tokens for "Delete access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Delete access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#delete-access-restrictions--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/restrictions
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions`
Response
`Status: 204`
## [Get apps with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Lists the GitHub Apps that have push access to this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch.
### [Fine-grained access tokens for "Get apps with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get apps with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get apps with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get apps with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-apps-with-access-to-the-protected-branch--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/apps`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   } ]`
## [Add app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Grants the specified apps push access for this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch.
### [Fine-grained access tokens for "Add app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Add app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`apps` array of strings Required The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [HTTP response status codes for "Add app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-app-access-restrictions--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/apps \   -d '{"apps":["octoapp"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   } ]`
## [Set app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Replaces the list of apps that have push access to this branch. This removes all apps that previously had push access and grants push access to the new list of apps. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch.
### [Fine-grained access tokens for "Set app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`apps` array of strings Required The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [HTTP response status codes for "Set app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-app-access-restrictions--code-samples)
#### Request example
put/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/apps \   -d '{"apps":["octoapp"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   } ]`
## [Remove app access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Removes the ability of an app to push to this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch.
### [Fine-grained access tokens for "Remove app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`apps` array of strings Required The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [HTTP response status codes for "Remove app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove app access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-app-access-restrictions--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/apps \   -d '{"apps":["my-app"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   } ]`
## [Get teams with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Lists the teams who have push access to this branch. The list includes child teams.
### [Fine-grained access tokens for "Get teams with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get teams with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get teams with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get teams with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-teams-with-access-to-the-protected-branch--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/teams`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Add team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Grants the specified teams push access for this branch. You can also give push access to child teams.
### [Fine-grained access tokens for "Add team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Add team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`teams` array of strings Required The slug values for teams
### [HTTP response status codes for "Add team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-team-access-restrictions--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/teams \   -d '{"teams":["justice-league"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Set team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Replaces the list of teams that have push access to this branch. This removes all teams that previously had push access and grants push access to the new list of teams. Team restrictions include child teams.
### [Fine-grained access tokens for "Set team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`teams` array of strings Required The slug values for teams
### [HTTP response status codes for "Set team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-team-access-restrictions--code-samples)
#### Request example
put/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/teams \   -d '{"teams":["justice-league"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Remove team access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Removes the ability of a team to push to this branch. You can also remove push access for child teams.
### [Fine-grained access tokens for "Remove team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`teams` array of strings Required The slug values for teams
### [HTTP response status codes for "Remove team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove team access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-team-access-restrictions--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/teams \   -d '{"teams":["octocats"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Get users with access to the protected branch](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Lists the people who have push access to this branch.
### [Fine-grained access tokens for "Get users with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get users with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### [HTTP response status codes for "Get users with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get users with access to the protected branch"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#get-users-with-access-to-the-protected-branch--code-samples)
#### Request example
get/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/users`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## [Add user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Grants the specified people push access for this branch.
Type | Description
---|---
`array` | Usernames for people who can have push access. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [Fine-grained access tokens for "Add user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Add user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`users` array of strings Required The username for users
### [HTTP response status codes for "Add user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#add-user-access-restrictions--code-samples)
#### Request example
post/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/users \   -d '{"users":["octocat"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## [Set user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Replaces the list of people that have push access to this branch. This removes all people that previously had push access and grants push access to the new list of people.
Type | Description
---|---
`array` | Usernames for people who can have push access. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [Fine-grained access tokens for "Set user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`users` array of strings Required The username for users
### [HTTP response status codes for "Set user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#set-user-access-restrictions--code-samples)
#### Request example
put/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/users \   -d '{"users":["octocat"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## [Remove user access restrictions](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Removes the ability of a user to push to this branch.
Type | Description
---|---
`array` | Usernames of the people who should no longer have push access. **Note** : The list of users, apps, and teams in total is limited to 100 items.
### [Fine-grained access tokens for "Remove user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Body parameters Name, Type, Description
---
`users` array of strings Required The username for users
### [HTTP response status codes for "Remove user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove user access restrictions"](https://docs.github.com/en/rest/branches/branch-protection?apiVersion=2022-11-28#remove-user-access-restrictions--code-samples)
#### Request example
delete/repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/branches/BRANCH/protection/restrictions/users \   -d '{"users":["octocat"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/branches/branch-protection.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for protected branches - GitHub Docs
