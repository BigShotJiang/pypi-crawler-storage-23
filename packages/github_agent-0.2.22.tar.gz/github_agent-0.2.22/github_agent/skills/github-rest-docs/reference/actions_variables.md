[Skip to main content](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Variables](https://docs.github.com/en/rest/actions/variables "Variables")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
      * [About variables in GitHub Actions](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#about-variables-in-github-actions)
      * [List organization variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables)
      * [Create an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable)
      * [Get an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable)
      * [Update an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable)
      * [Delete an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable)
      * [List selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable)
      * [Set selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable)
      * [Add selected repository to an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable)
      * [Remove selected repository from an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable)
      * [List repository organization variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables)
      * [List repository variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables)
      * [Create a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable)
      * [Get a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable)
      * [Update a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable)
      * [Delete a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable)
      * [List environment variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables)
      * [Create an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable)
      * [Get an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable)
      * [Update an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable)
      * [Delete an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable)
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Variables](https://docs.github.com/en/rest/actions/variables "Variables")


# REST API endpoints for GitHub Actions variables
Use the REST API to interact with variables in GitHub Actions.
## [About variables in GitHub Actions](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#about-variables-in-github-actions)
You can use the REST API to create, update, delete, and retrieve information about variables that can be used in workflows in GitHub Actions. Variables allow you to store non-sensitive information, such as a username, in your repository, repository environments, or organization. For more information, see [Store information in variables](https://docs.github.com/en/actions/learn-github-actions/variables) in the GitHub Actions documentation.
## [List organization variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables)
Lists all organization variables.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "List organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (read)


### [Parameters for "List organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `10`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-organization-variables--code-samples)
#### Request example
get/orgs/{org}/actions/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 3,   "variables": [     {       "name": "USERNAME",       "value": "octocat",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z",       "visibility": "private"     },     {       "name": "ACTIONS_RUNNER_DEBUG",       "value": true,       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z",       "visibility": "all"     },     {       "name": "ADMIN_EMAIL",       "value": "octocat@github.com",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z",       "visibility": "selected",       "selected_repositories_url": "https://api.github.com/orgs/octo-org/actions/variables/ADMIN_EMAIL/repositories"     }   ] }`
## [Create an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable)
Creates an organization variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write)


### [Parameters for "Create an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the variable.
`value` string Required The value of the variable.
`visibility` string Required The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. Can be one of: `all`, `private`, `selected`
`selected_repository_ids` array of integers An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`.
### [HTTP response status codes for "Create an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable--status-codes)
Status code | Description
---|---
`201` | Response when creating a variable
### [Code samples for "Create an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-organization-variable--code-samples)
#### Request example
post/orgs/{org}/actions/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables \   -d '{"name":"USERNAME","value":"octocat","visibility":"selected","selected_repository_ids":[1296269,1296280]}'`
Response when creating a variable
  * Example response
  * Response schema


`Status: 201`
## [Get an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable)
Gets a specific variable in an organization.
The authenticated user must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (read)


### [Parameters for "Get an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
### [HTTP response status codes for "Get an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-organization-variable--code-samples)
#### Request example
get/orgs/{org}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "name": "USERNAME",   "value": "octocat",   "created_at": "2019-08-10T14:59:22Z",   "updated_at": "2020-01-10T14:59:22Z",   "visibility": "selected",   "selected_repositories_url": "https://api.github.com/orgs/octo-org/actions/variables/USERNAME/repositories" }`
## [Update an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable)
Updates an organization variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Update an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write)


### [Parameters for "Update an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
Body parameters Name, Type, Description
---
`name` string The name of the variable.
`value` string The value of the variable.
`visibility` string The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. Can be one of: `all`, `private`, `selected`
`selected_repository_ids` array of integers An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`.
### [HTTP response status codes for "Update an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Update an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-organization-variable--code-samples)
#### Request example
patch/orgs/{org}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME \   -d '{"name":"USERNAME","value":"octocat","visibility":"selected","selected_repository_ids":[1296269,1296280]}'`
Response
`Status: 204`
## [Delete an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable)
Deletes an organization variable using the variable name.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write)


### [Parameters for "Delete an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
### [HTTP response status codes for "Delete an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-organization-variable--code-samples)
#### Request example
delete/orgs/{org}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME`
Response
`Status: 204`
## [List selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable)
Lists all repositories that can access an organization variable that is available to selected repositories.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "List selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (read)


### [Parameters for "List selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable--status-codes)
Status code | Description
---|---
`200` | OK
`409` | Response when the visibility of the variable is not set to `selected`
### [Code samples for "List selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-selected-repositories-for-an-organization-variable--code-samples)
#### Request example
get/orgs/{org}/actions/variables/{name}/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME/repositories`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "repositories": [     {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"     }   ] }`
## [Set selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable)
Replaces all repositories for an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Set selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write)


### [Parameters for "Set selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
Body parameters Name, Type, Description
---
`selected_repository_ids` array of integers Required The IDs of the repositories that can access the organization variable.
### [HTTP response status codes for "Set selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable--status-codes)
Status code | Description
---|---
`204` | No Content
`409` | Response when the visibility of the variable is not set to `selected`
### [Code samples for "Set selected repositories for an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#set-selected-repositories-for-an-organization-variable--code-samples)
#### Request example
put/orgs/{org}/actions/variables/{name}/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME/repositories \   -d '{"selected_repository_ids":[64780797]}'`
Response
`Status: 204`
## [Add selected repository to an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable)
Adds a repository to an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`.
Authenticated users must have collaborator access to a repository to create, update, or read secrets.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Add selected repository to an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write) and "Metadata" repository permissions (read)


### [Parameters for "Add selected repository to an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
`repository_id` integer Required
### [HTTP response status codes for "Add selected repository to an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable--status-codes)
Status code | Description
---|---
`204` | No Content
`409` | Response when the visibility of the variable is not set to `selected`
### [Code samples for "Add selected repository to an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#add-selected-repository-to-an-organization-variable--code-samples)
#### Request example
put/orgs/{org}/actions/variables/{name}/repositories/{repository_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME/repositories/REPOSITORY_ID`
Response
`Status: 204`
## [Remove selected repository from an organization variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable)
Removes a repository from an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Remove selected repository from an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" organization permissions (write) and "Metadata" repository permissions (read)


### [Parameters for "Remove selected repository from an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`name` string Required The name of the variable.
`repository_id` integer Required
### [HTTP response status codes for "Remove selected repository from an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable--status-codes)
Status code | Description
---|---
`204` | No Content
`409` | Response when the visibility of the variable is not set to `selected`
### [Code samples for "Remove selected repository from an organization variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#remove-selected-repository-from-an-organization-variable--code-samples)
#### Request example
delete/orgs/{org}/actions/variables/{name}/repositories/{repository_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/variables/NAME/repositories/REPOSITORY_ID`
Response
`Status: 204`
## [List repository organization variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables)
Lists all organization variables shared with a repository.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List repository organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (read)


### [Parameters for "List repository organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `10`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository organization variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-organization-variables--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/organization-variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/organization-variables`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "variables": [     {       "name": "USERNAME",       "value": "octocat",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z"     },     {       "name": "EMAIL",       "value": "octocat@github.com",       "created_at": "2020-01-10T10:59:22Z",       "updated_at": "2020-01-11T11:59:22Z"     }   ] }`
## [List repository variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables)
Lists all repository variables.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List repository variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (read)


### [Parameters for "List repository variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `10`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-repository-variables--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/variables`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "variables": [     {       "name": "USERNAME",       "value": "octocat",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z"     },     {       "name": "EMAIL",       "value": "octocat@github.com",       "created_at": "2020-01-10T10:59:22Z",       "updated_at": "2020-01-11T11:59:22Z"     }   ] }`
## [Create a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable)
Creates a repository variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (write)


### [Parameters for "Create a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the variable.
`value` string Required The value of the variable.
### [HTTP response status codes for "Create a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-a-repository-variable--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/variables \   -d '{"name":"USERNAME","value":"octocat"}'`
Response
  * Example response
  * Response schema


`Status: 201`
## [Get a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable)
Gets a specific variable in a repository.
The authenticated user must have collaborator access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (read)


### [Parameters for "Get a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required The name of the variable.
### [HTTP response status codes for "Get a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-a-repository-variable--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/variables/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "name": "USERNAME",   "value": "octocat",   "created_at": "2021-08-10T14:59:22Z",   "updated_at": "2022-01-10T14:59:22Z" }`
## [Update a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable)
Updates a repository variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Update a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (write)


### [Parameters for "Update a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required The name of the variable.
Body parameters Name, Type, Description
---
`name` string The name of the variable.
`value` string The value of the variable.
### [HTTP response status codes for "Update a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Update a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-a-repository-variable--code-samples)
#### Request example
patch/repos/{owner}/{repo}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/variables/NAME \   -d '{"name":"USERNAME","value":"octocat"}'`
Response
`Status: 204`
## [Delete a repository variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable)
Deletes a repository variable using the variable name.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Variables" repository permissions (write)


### [Parameters for "Delete a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required The name of the variable.
### [HTTP response status codes for "Delete a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete a repository variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-a-repository-variable--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/variables/NAME`
Response
`Status: 204`
## [List environment variables](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables)
Lists all environment variables.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List environment variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Environments" repository permissions (read)


### [Parameters for "List environment variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `10`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List environment variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List environment variables"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#list-environment-variables--code-samples)
#### Request example
get/repos/{owner}/{repo}/environments/{environment_name}/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME/variables`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "variables": [     {       "name": "USERNAME",       "value": "octocat",       "created_at": "2019-08-10T14:59:22Z",       "updated_at": "2020-01-10T14:59:22Z"     },     {       "name": "EMAIL",       "value": "octocat@github.com",       "created_at": "2020-01-10T10:59:22Z",       "updated_at": "2020-01-11T11:59:22Z"     }   ] }`
## [Create an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable)
Create an environment variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Environments" repository permissions (write)


### [Parameters for "Create an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
Body parameters Name, Type, Description
---
`name` string Required The name of the variable.
`value` string Required The value of the variable.
### [HTTP response status codes for "Create an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#create-an-environment-variable--code-samples)
#### Request example
post/repos/{owner}/{repo}/environments/{environment_name}/variables
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME/variables \   -d '{"name":"USERNAME","value":"octocat"}'`
Response
  * Example response
  * Response schema


`Status: 201`
## [Get an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable)
Gets a specific variable in an environment.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Environments" repository permissions (read)


### [Parameters for "Get an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
`name` string Required The name of the variable.
### [HTTP response status codes for "Get an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#get-an-environment-variable--code-samples)
#### Request example
get/repos/{owner}/{repo}/environments/{environment_name}/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME/variables/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "name": "USERNAME",   "value": "octocat",   "created_at": "2021-08-10T14:59:22Z",   "updated_at": "2022-01-10T14:59:22Z" }`
## [Update an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable)
Updates an environment variable that you can reference in a GitHub Actions workflow.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Update an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Environments" repository permissions (write)


### [Parameters for "Update an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required The name of the variable.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
Body parameters Name, Type, Description
---
`name` string The name of the variable.
`value` string The value of the variable.
### [HTTP response status codes for "Update an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Update an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#update-an-environment-variable--code-samples)
#### Request example
patch/repos/{owner}/{repo}/environments/{environment_name}/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME/variables/NAME \   -d '{"name":"USERNAME","value":"octocat"}'`
Response
`Status: 204`
## [Delete an environment variable](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable)
Deletes an environment variable using the variable name.
Authenticated users must have collaborator access to a repository to create, update, or read variables.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Environments" repository permissions (write)


### [Parameters for "Delete an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required The name of the variable.
`environment_name` string Required The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### [HTTP response status codes for "Delete an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete an environment variable"](https://docs.github.com/en/rest/actions/variables?apiVersion=2022-11-28#delete-an-environment-variable--code-samples)
#### Request example
delete/repos/{owner}/{repo}/environments/{environment_name}/variables/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/environments/ENVIRONMENT_NAME/variables/NAME`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/variables.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Actions variables - GitHub Docs
