[Skip to main content](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Authentication](https://docs.github.com/en/rest/authentication "Authentication")/
  * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens "Permissions for fine-grained PATs")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Authentication](https://docs.github.com/en/rest/authentication "Authentication")/
  * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens "Permissions for fine-grained PATs")


# Permissions required for fine-grained personal access tokens
For each permission granted to a fine-grained personal access token, these are the REST API endpoints that the app can use.
## In this article
  * [About permissions required for fine-grained personal access token](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#about-permissions-required-for-fine-grained-personal-access-token)
  * [Organization permissions for "API Insights"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-api-insights)
  * [Organization permissions for "Administration"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-administration)
  * [Organization permissions for "Blocking users"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-blocking-users)
  * [Organization permissions for "Campaigns"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-campaigns)
  * [Organization permissions for "Copilot content exclusion"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-copilot-content-exclusion)
  * [Organization permissions for "Custom organization roles"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-custom-organization-roles)
  * [Organization permissions for "Custom properties"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-custom-properties)
  * [Organization permissions for "Events"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-events)
  * [Organization permissions for "GitHub Copilot Business"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-github-copilot-business)
  * [Organization permissions for "Hosted runner custom images"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-hosted-runner-custom-images)
  * [Organization permissions for "Issue Types"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-issue-types)
  * [Organization permissions for "Members"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-members)
  * [Organization permissions for "Network configurations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-network-configurations)
  * [Organization permissions for "Organization codespaces secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces-secrets)
  * [Organization permissions for "Organization codespaces settings"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces-settings)
  * [Organization permissions for "Organization codespaces"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces)
  * [Organization permissions for "Organization dependabot secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-dependabot-secrets)
  * [Organization permissions for "Organization private registries"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-private-registries)
  * [Organization permissions for "Projects"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-projects)
  * [Organization permissions for "Secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-secrets)
  * [Organization permissions for "Self-hosted runners"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-self-hosted-runners)
  * [Organization permissions for "Variables"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-variables)
  * [Organization permissions for "Webhooks"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-webhooks)
  * [Repository permissions for "Actions"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-actions)
  * [Repository permissions for "Administration"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-administration)
  * [Repository permissions for "Artifact metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-artifact-metadata)
  * [Repository permissions for "Attestations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-attestations)
  * [Repository permissions for "Code scanning alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-code-scanning-alerts)
  * [Repository permissions for "Codespaces lifecycle admin"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-lifecycle-admin)
  * [Repository permissions for "Codespaces metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-metadata)
  * [Repository permissions for "Codespaces secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-secrets)
  * [Repository permissions for "Codespaces"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces)
  * [Repository permissions for "Commit statuses"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-commit-statuses)
  * [Repository permissions for "Contents"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-contents)
  * [Repository permissions for "Custom properties"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-custom-properties)
  * [Repository permissions for "Dependabot alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-dependabot-alerts)
  * [Repository permissions for "Dependabot secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-dependabot-secrets)
  * [Repository permissions for "Deployments"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-deployments)
  * [Repository permissions for "Environments"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-environments)
  * [Repository permissions for "Issues"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-issues)
  * [Repository permissions for "Metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-metadata)
  * [Repository permissions for "Pages"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-pages)
  * [Repository permissions for "Pull requests"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-pull-requests)
  * [Repository permissions for "Repository security advisories"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-repository-security-advisories)
  * [Repository permissions for "Secret scanning alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-secret-scanning-alerts)
  * [Repository permissions for "Secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-secrets)
  * [Repository permissions for "Variables"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-variables)
  * [Repository permissions for "Webhooks"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-webhooks)
  * [Repository permissions for "Workflows"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-workflows)
  * [User permissions for "Block another user"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-block-another-user)
  * [User permissions for "Codespaces user secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-codespaces-user-secrets)
  * [User permissions for "Email addresses"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-email-addresses)
  * [User permissions for "Followers"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-followers)
  * [User permissions for "GPG keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-gpg-keys)
  * [User permissions for "Gists"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-gists)
  * [User permissions for "Git SSH keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-git-ssh-keys)
  * [User permissions for "Interaction limits"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-interaction-limits)
  * [User permissions for "Plan"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-plan)
  * [User permissions for "Private repository invitations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-private-repository-invitations)
  * [User permissions for "Profile"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-profile)
  * [User permissions for "SSH signing keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-ssh-signing-keys)
  * [User permissions for "Starring"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-starring)
  * [User permissions for "Watching"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-watching)


## [About permissions required for fine-grained personal access token](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#about-permissions-required-for-fine-grained-personal-access-token)
When you create a fine-grained personal access token, you grant it a set of permissions. Permissions define what resources the GitHub App can access via the API. For more information, see [Managing your personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token).
To help you choose the correct permissions, you will receive the `X-Accepted-GitHub-Permissions` header in the REST API response. The header will tell you what permissions are required in order to access the endpoint. For more information, see [Troubleshooting the REST API](https://docs.github.com/en/rest/overview/troubleshooting#resource-not-accessible).
These permissions are required to access private resources. Some endpoints can also be used to access public resources without these permissions. To see whether an endpoint can access public resources without a permission, see the documentation for that endpoint.
Some endpoints require more than one permission. Other endpoints work with any one permission from a set of permissions. In these cases, the "Additional permissions" column will include a checkmark. For full details about the permissions that are required to use the endpoint, see the documentation for that endpoint.
## [Organization permissions for "API Insights"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-api-insights)
Endpoint | Access | Additional permissions
---|---|---
[GET /orgs/{org}/insights/api/route-stats/{actor_type}/{actor_id}](https://docs.github.com/en/rest/orgs/api-insights#get-route-stats-by-actor) | read |
[GET /orgs/{org}/insights/api/subject-stats](https://docs.github.com/en/rest/orgs/api-insights#get-subject-stats) | read |
[GET /orgs/{org}/insights/api/summary-stats](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats) | read |
[GET /orgs/{org}/insights/api/summary-stats/users/{user_id}](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats-by-user) | read |
[GET /orgs/{org}/insights/api/summary-stats/{actor_type}/{actor_id}](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats-by-actor) | read |
[GET /orgs/{org}/insights/api/time-stats](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats) | read |
[GET /orgs/{org}/insights/api/time-stats/users/{user_id}](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats-by-user) | read |
[GET /orgs/{org}/insights/api/time-stats/{actor_type}/{actor_id}](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats-by-actor) | read |
[GET /orgs/{org}/insights/api/user-stats/{user_id}](https://docs.github.com/en/rest/orgs/api-insights#get-user-stats) | read |
## [Organization permissions for "Administration"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-administration)
Endpoint | Access | Additional permissions
---|---|---
[PUT /organizations/{org}/actions/cache/retention-limit](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-retention-limit-for-an-organization) | write |
[PUT /organizations/{org}/actions/cache/storage-limit](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-storage-limit-for-an-organization) | write |
[PATCH /organizations/{org}/dependabot/repository-access](https://docs.github.com/en/rest/dependabot/repository-access#updates-dependabots-repository-access-list-for-an-organization) | write |
[PUT /organizations/{org}/dependabot/repository-access/default-level](https://docs.github.com/en/rest/dependabot/repository-access#set-the-default-repository-access-level-for-dependabot) | write |
[PATCH /organizations/{org}/settings/billing/budgets/{budget_id}](https://docs.github.com/en/rest/billing/budgets#update-a-budget-for-an-organization) | write |
[DELETE /organizations/{org}/settings/billing/budgets/{budget_id}](https://docs.github.com/en/rest/billing/budgets#delete-a-budget-for-an-organization) | write |
[PATCH /orgs/{org}](https://docs.github.com/en/rest/orgs/orgs#update-an-organization) | write |
[DELETE /orgs/{org}](https://docs.github.com/en/rest/orgs/orgs#delete-an-organization) | write |
[POST /orgs/{org}/actions/hosted-runners](https://docs.github.com/en/rest/actions/hosted-runners#create-a-github-hosted-runner-for-an-organization) | write |
[PATCH /orgs/{org}/actions/hosted-runners/{hosted_runner_id}](https://docs.github.com/en/rest/actions/hosted-runners#update-a-github-hosted-runner-for-an-organization) | write |
[DELETE /orgs/{org}/actions/hosted-runners/{hosted_runner_id}](https://docs.github.com/en/rest/actions/hosted-runners#delete-a-github-hosted-runner-for-an-organization) | write |
[PUT /orgs/{org}/actions/oidc/customization/sub](https://docs.github.com/en/rest/actions/oidc#set-the-customization-template-for-an-oidc-subject-claim-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions](https://docs.github.com/en/rest/actions/permissions#set-github-actions-permissions-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/artifact-and-log-retention](https://docs.github.com/en/rest/actions/permissions#set-artifact-and-log-retention-settings-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/fork-pr-contributor-approval](https://docs.github.com/en/rest/actions/permissions#set-fork-pr-contributor-approval-permissions-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/fork-pr-workflows-private-repos](https://docs.github.com/en/rest/actions/permissions#set-private-repo-fork-pr-workflow-settings-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/repositories](https://docs.github.com/en/rest/actions/permissions#set-selected-repositories-enabled-for-github-actions-in-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/repositories/{repository_id}](https://docs.github.com/en/rest/actions/permissions#enable-a-selected-repository-for-github-actions-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/permissions#enable-a-selected-repository-for-github-actions-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/actions/permissions/repositories/{repository_id}](https://docs.github.com/en/rest/actions/permissions#disable-a-selected-repository-for-github-actions-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/permissions#disable-a-selected-repository-for-github-actions-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/actions/permissions/selected-actions](https://docs.github.com/en/rest/actions/permissions#set-allowed-actions-and-reusable-workflows-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/self-hosted-runners](https://docs.github.com/en/rest/actions/permissions#set-self-hosted-runners-settings-for-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/self-hosted-runners/repositories](https://docs.github.com/en/rest/actions/permissions#set-repositories-allowed-to-use-self-hosted-runners-in-an-organization) | write |
[PUT /orgs/{org}/actions/permissions/self-hosted-runners/repositories/{repository_id}](https://docs.github.com/en/rest/actions/permissions#add-a-repository-to-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/permissions#add-a-repository-to-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/actions/permissions/self-hosted-runners/repositories/{repository_id}](https://docs.github.com/en/rest/actions/permissions#remove-a-repository-from-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/permissions#remove-a-repository-from-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/actions/permissions/workflow](https://docs.github.com/en/rest/actions/permissions#set-default-workflow-permissions-for-an-organization) | write |
[POST /orgs/{org}/code-security/configurations](https://docs.github.com/en/rest/code-security/configurations#create-a-code-security-configuration) | write |
[DELETE /orgs/{org}/code-security/configurations/detach](https://docs.github.com/en/rest/code-security/configurations#detach-configurations-from-repositories) | write |
[PATCH /orgs/{org}/code-security/configurations/{configuration_id}](https://docs.github.com/en/rest/code-security/configurations#update-a-code-security-configuration) | write |
[DELETE /orgs/{org}/code-security/configurations/{configuration_id}](https://docs.github.com/en/rest/code-security/configurations#delete-a-code-security-configuration) | write |
[POST /orgs/{org}/code-security/configurations/{configuration_id}/attach](https://docs.github.com/en/rest/code-security/configurations#attach-a-configuration-to-repositories) | write |
[PUT /orgs/{org}/code-security/configurations/{configuration_id}/defaults](https://docs.github.com/en/rest/code-security/configurations#set-a-code-security-configuration-as-a-default-for-an-organization) | write |
[POST /orgs/{org}/copilot/billing/selected_teams](https://docs.github.com/en/rest/copilot/copilot-user-management#add-teams-to-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#add-teams-to-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/copilot/billing/selected_teams](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-teams-from-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-teams-from-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/copilot/billing/selected_users](https://docs.github.com/en/rest/copilot/copilot-user-management#add-users-to-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#add-users-to-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/copilot/billing/selected_users](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-users-from-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-users-from-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/interaction-limits](https://docs.github.com/en/rest/interactions/orgs#set-interaction-restrictions-for-an-organization) | write |
[DELETE /orgs/{org}/interaction-limits](https://docs.github.com/en/rest/interactions/orgs#remove-interaction-restrictions-for-an-organization) | write |
[GET /orgs/{org}/rulesets](https://docs.github.com/en/rest/orgs/rules#get-all-organization-repository-rulesets) | write |
[POST /orgs/{org}/rulesets](https://docs.github.com/en/rest/orgs/rules#create-an-organization-repository-ruleset) | write |
[GET /orgs/{org}/rulesets/rule-suites](https://docs.github.com/en/rest/orgs/rule-suites#list-organization-rule-suites) | write |
[GET /orgs/{org}/rulesets/rule-suites/{rule_suite_id}](https://docs.github.com/en/rest/orgs/rule-suites#get-an-organization-rule-suite) | write |
[GET /orgs/{org}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/orgs/rules#get-an-organization-repository-ruleset) | write |
[PUT /orgs/{org}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/orgs/rules#update-an-organization-repository-ruleset) | write |
[DELETE /orgs/{org}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/orgs/rules#delete-an-organization-repository-ruleset) | write |
[GET /orgs/{org}/rulesets/{ruleset_id}/history](https://docs.github.com/en/rest/orgs/rules#get-organization-ruleset-history) | write |
[GET /orgs/{org}/rulesets/{ruleset_id}/history/{version_id}](https://docs.github.com/en/rest/orgs/rules#get-organization-ruleset-version) | write |
[PATCH /orgs/{org}/secret-scanning/pattern-configurations](https://docs.github.com/en/rest/secret-scanning/push-protection#update-organization-pattern-configurations) | write |
[PUT /orgs/{org}/security-managers/teams/{team_slug}](https://docs.github.com/en/rest/orgs/security-managers#add-a-security-manager-team) | write |
[DELETE /orgs/{org}/security-managers/teams/{team_slug}](https://docs.github.com/en/rest/orgs/security-managers#remove-a-security-manager-team) | write |
[PUT /orgs/{org}/settings/immutable-releases](https://docs.github.com/en/rest/orgs/orgs#set-immutable-releases-settings-for-an-organization) | write |
[PUT /orgs/{org}/settings/immutable-releases/repositories](https://docs.github.com/en/rest/orgs/orgs#set-selected-repositories-for-immutable-releases-enforcement) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/orgs#set-selected-repositories-for-immutable-releases-enforcement "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/settings/immutable-releases/repositories/{repository_id}](https://docs.github.com/en/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/settings/immutable-releases/repositories/{repository_id}](https://docs.github.com/en/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/{security_product}/{enablement}](https://docs.github.com/en/rest/orgs/orgs#enable-or-disable-a-security-feature-for-an-organization) | write |
[GET /organizations/{org}/actions/cache/retention-limit](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-retention-limit-for-an-organization) | read |
[GET /organizations/{org}/actions/cache/storage-limit](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-storage-limit-for-an-organization) | read |
[GET /organizations/{org}/dependabot/repository-access](https://docs.github.com/en/rest/dependabot/repository-access#lists-the-repositories-dependabot-can-access-in-an-organization) | read |
[GET /organizations/{org}/settings/billing/budgets](https://docs.github.com/en/rest/billing/budgets#get-all-budgets-for-an-organization) | read |
[GET /organizations/{org}/settings/billing/budgets/{budget_id}](https://docs.github.com/en/rest/billing/budgets#get-a-budget-by-id-for-an-organization) | read |
[GET /organizations/{org}/settings/billing/premium_request/usage](https://docs.github.com/en/rest/billing/usage#get-billing-premium-request-usage-report-for-an-organization) | read |
[GET /organizations/{org}/settings/billing/usage](https://docs.github.com/en/rest/billing/usage#get-billing-usage-report-for-an-organization) | read |
[GET /organizations/{org}/settings/billing/usage/summary](https://docs.github.com/en/rest/billing/usage#get-billing-usage-summary-for-an-organization) | read |
[GET /orgs/{org}/actions/cache/usage](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-usage-for-an-organization) | read |
[GET /orgs/{org}/actions/cache/usage-by-repository](https://docs.github.com/en/rest/actions/cache#list-repositories-with-github-actions-cache-usage-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners](https://docs.github.com/en/rest/actions/hosted-runners#list-github-hosted-runners-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/images/github-owned](https://docs.github.com/en/rest/actions/hosted-runners#get-github-owned-images-for-github-hosted-runners-in-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/images/partner](https://docs.github.com/en/rest/actions/hosted-runners#get-partner-images-for-github-hosted-runners-in-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/limits](https://docs.github.com/en/rest/actions/hosted-runners#get-limits-on-github-hosted-runners-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/machine-sizes](https://docs.github.com/en/rest/actions/hosted-runners#get-github-hosted-runners-machine-specs-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/platforms](https://docs.github.com/en/rest/actions/hosted-runners#get-platforms-for-github-hosted-runners-in-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/{hosted_runner_id}](https://docs.github.com/en/rest/actions/hosted-runners#get-a-github-hosted-runner-for-an-organization) | read |
[GET /orgs/{org}/actions/oidc/customization/sub](https://docs.github.com/en/rest/actions/oidc#get-the-customization-template-for-an-oidc-subject-claim-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions](https://docs.github.com/en/rest/actions/permissions#get-github-actions-permissions-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/artifact-and-log-retention](https://docs.github.com/en/rest/actions/permissions#get-artifact-and-log-retention-settings-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/fork-pr-contributor-approval](https://docs.github.com/en/rest/actions/permissions#get-fork-pr-contributor-approval-permissions-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/fork-pr-workflows-private-repos](https://docs.github.com/en/rest/actions/permissions#get-private-repo-fork-pr-workflow-settings-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/repositories](https://docs.github.com/en/rest/actions/permissions#list-selected-repositories-enabled-for-github-actions-in-an-organization) | read |
[GET /orgs/{org}/actions/permissions/selected-actions](https://docs.github.com/en/rest/actions/permissions#get-allowed-actions-and-reusable-workflows-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/self-hosted-runners](https://docs.github.com/en/rest/actions/permissions#get-self-hosted-runners-settings-for-an-organization) | read |
[GET /orgs/{org}/actions/permissions/self-hosted-runners/repositories](https://docs.github.com/en/rest/actions/permissions#list-repositories-allowed-to-use-self-hosted-runners-in-an-organization) | read |
[GET /orgs/{org}/actions/permissions/workflow](https://docs.github.com/en/rest/actions/permissions#get-default-workflow-permissions-for-an-organization) | read |
[GET /orgs/{org}/code-security/configurations](https://docs.github.com/en/rest/code-security/configurations#get-code-security-configurations-for-an-organization) | read |
[GET /orgs/{org}/code-security/configurations/defaults](https://docs.github.com/en/rest/code-security/configurations#get-default-code-security-configurations) | read |
[GET /orgs/{org}/code-security/configurations/{configuration_id}](https://docs.github.com/en/rest/code-security/configurations#get-a-code-security-configuration) | read |
[GET /orgs/{org}/code-security/configurations/{configuration_id}/repositories](https://docs.github.com/en/rest/code-security/configurations#get-repositories-associated-with-a-code-security-configuration) | read |
[GET /orgs/{org}/copilot/billing](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-information-and-settings-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-information-and-settings-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/copilot/billing/seats](https://docs.github.com/en/rest/copilot/copilot-user-management#list-all-copilot-seat-assignments-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#list-all-copilot-seat-assignments-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/copilot/metrics](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/installations](https://docs.github.com/en/rest/orgs/orgs#list-app-installations-for-an-organization) | read |
[GET /orgs/{org}/interaction-limits](https://docs.github.com/en/rest/interactions/orgs#get-interaction-restrictions-for-an-organization) | read |
[GET /orgs/{org}/members/{username}/copilot](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-assignment-details-for-a-user) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-assignment-details-for-a-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/secret-scanning/pattern-configurations](https://docs.github.com/en/rest/secret-scanning/push-protection#list-organization-pattern-configurations) | read |
[GET /orgs/{org}/security-managers](https://docs.github.com/en/rest/orgs/security-managers#list-security-manager-teams) | read |
[GET /orgs/{org}/settings/immutable-releases](https://docs.github.com/en/rest/orgs/orgs#get-immutable-releases-settings-for-an-organization) | read |
[GET /orgs/{org}/settings/immutable-releases/repositories](https://docs.github.com/en/rest/orgs/orgs#list-selected-repositories-for-immutable-releases-enforcement) | read |
[GET /orgs/{org}/team/{team_slug}/copilot/metrics](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-a-team) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-a-team "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Organization permissions for "Blocking users"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-blocking-users)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/blocks/{username}](https://docs.github.com/en/rest/orgs/blocking#block-a-user-from-an-organization) | write |
[DELETE /orgs/{org}/blocks/{username}](https://docs.github.com/en/rest/orgs/blocking#unblock-a-user-from-an-organization) | write |
[GET /orgs/{org}/blocks](https://docs.github.com/en/rest/orgs/blocking#list-users-blocked-by-an-organization) | read |
[GET /orgs/{org}/blocks/{username}](https://docs.github.com/en/rest/orgs/blocking#check-if-a-user-is-blocked-by-an-organization) | read |
## [Organization permissions for "Campaigns"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-campaigns)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/campaigns](https://docs.github.com/en/rest/campaigns/campaigns#create-a-campaign-for-an-organization) | write |
[PATCH /orgs/{org}/campaigns/{campaign_number}](https://docs.github.com/en/rest/campaigns/campaigns#update-a-campaign) | write |
[DELETE /orgs/{org}/campaigns/{campaign_number}](https://docs.github.com/en/rest/campaigns/campaigns#delete-a-campaign-for-an-organization) | write |
[GET /orgs/{org}/campaigns](https://docs.github.com/en/rest/campaigns/campaigns#list-campaigns-for-an-organization) | read |
[GET /orgs/{org}/campaigns/{campaign_number}](https://docs.github.com/en/rest/campaigns/campaigns#get-a-campaign-for-an-organization) | read |
## [Organization permissions for "Copilot content exclusion"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-copilot-content-exclusion)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/copilot/content_exclusion](https://docs.github.com/en/rest/copilot/copilot-content-exclusion-management#set-copilot-content-exclusion-rules-for-an-organization) | write |
[GET /orgs/{org}/copilot/content_exclusion](https://docs.github.com/en/rest/copilot/copilot-content-exclusion-management#get-copilot-content-exclusion-rules-for-an-organization) | read |
## [Organization permissions for "Custom organization roles"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-custom-organization-roles)
Endpoint | Access | Additional permissions
---|---|---
[GET /orgs/{org}/organization-roles](https://docs.github.com/en/rest/orgs/organization-roles#get-all-organization-roles-for-an-organization) | read |
[GET /orgs/{org}/organization-roles/{role_id}](https://docs.github.com/en/rest/orgs/organization-roles#get-an-organization-role) | read |
## [Organization permissions for "Custom properties"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-custom-properties)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /orgs/{org}/properties/schema](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-custom-properties-for-an-organization) | admin |
[PUT /orgs/{org}/properties/schema/{custom_property_name}](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-a-custom-property-for-an-organization) | admin |
[DELETE /orgs/{org}/properties/schema/{custom_property_name}](https://docs.github.com/en/rest/orgs/custom-properties#remove-a-custom-property-for-an-organization) | admin |
[PATCH /orgs/{org}/properties/values](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-custom-property-values-for-organization-repositories) | write |
[GET /orgs/{org}/properties/schema](https://docs.github.com/en/rest/orgs/custom-properties#get-all-custom-properties-for-an-organization) | read |
[GET /orgs/{org}/properties/schema/{custom_property_name}](https://docs.github.com/en/rest/orgs/custom-properties#get-a-custom-property-for-an-organization) | read |
[GET /orgs/{org}/properties/values](https://docs.github.com/en/rest/orgs/custom-properties#list-custom-property-values-for-organization-repositories) | read |
## [Organization permissions for "Events"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-events)
Endpoint | Access | Additional permissions
---|---|---
[GET /users/{username}/events/orgs/{org}](https://docs.github.com/en/rest/activity/events#list-organization-events-for-the-authenticated-user) | read |
## [Organization permissions for "GitHub Copilot Business"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-github-copilot-business)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/copilot/billing/selected_teams](https://docs.github.com/en/rest/copilot/copilot-user-management#add-teams-to-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#add-teams-to-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/copilot/billing/selected_teams](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-teams-from-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-teams-from-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/copilot/billing/selected_users](https://docs.github.com/en/rest/copilot/copilot-user-management#add-users-to-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#add-users-to-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/copilot/billing/selected_users](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-users-from-the-copilot-subscription-for-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#remove-users-from-the-copilot-subscription-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/copilot/billing](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-information-and-settings-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-information-and-settings-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/copilot/billing/seats](https://docs.github.com/en/rest/copilot/copilot-user-management#list-all-copilot-seat-assignments-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#list-all-copilot-seat-assignments-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/copilot/metrics](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-an-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/members/{username}/copilot](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-assignment-details-for-a-user) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-user-management#get-copilot-seat-assignment-details-for-a-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/team/{team_slug}/copilot/metrics](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-a-team) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/copilot/copilot-metrics#get-copilot-metrics-for-a-team "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Organization permissions for "Hosted runner custom images"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-hosted-runner-custom-images)
Endpoint | Access | Additional permissions
---|---|---
[DELETE /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}](https://docs.github.com/en/rest/actions/hosted-runners#delete-a-custom-image-from-the-organization) | write |
[DELETE /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions/{version}](https://docs.github.com/en/rest/actions/hosted-runners#delete-an-image-version-of-custom-image-from-the-organization) | write |
[GET /orgs/{org}/actions/hosted-runners/images/custom](https://docs.github.com/en/rest/actions/hosted-runners#list-custom-images-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}](https://docs.github.com/en/rest/actions/hosted-runners#get-a-custom-image-definition-for-github-actions-hosted-runners) | read |
[GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions](https://docs.github.com/en/rest/actions/hosted-runners#list-image-versions-of-a-custom-image-for-an-organization) | read |
[GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions/{version}](https://docs.github.com/en/rest/actions/hosted-runners#get-an-image-version-of-a-custom-image-for-github-actions-hosted-runners) | read |
## [Organization permissions for "Issue Types"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-issue-types)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/issue-types](https://docs.github.com/en/rest/orgs/issue-types#create-issue-type-for-an-organization) | write |
[PUT /orgs/{org}/issue-types/{issue_type_id}](https://docs.github.com/en/rest/orgs/issue-types#update-issue-type-for-an-organization) | write |
[DELETE /orgs/{org}/issue-types/{issue_type_id}](https://docs.github.com/en/rest/orgs/issue-types#delete-issue-type-for-an-organization) | write |
[GET /orgs/{org}/issue-types](https://docs.github.com/en/rest/orgs/issue-types#list-issue-types-for-an-organization) | read |
## [Organization permissions for "Members"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-members)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/invitations](https://docs.github.com/en/rest/orgs/members#create-an-organization-invitation) | write |
[DELETE /orgs/{org}/invitations/{invitation_id}](https://docs.github.com/en/rest/orgs/members#cancel-an-organization-invitation) | write |
[DELETE /orgs/{org}/members/{username}](https://docs.github.com/en/rest/orgs/members#remove-an-organization-member) | write |
[PUT /orgs/{org}/memberships/{username}](https://docs.github.com/en/rest/orgs/members#set-organization-membership-for-a-user) | write |
[DELETE /orgs/{org}/memberships/{username}](https://docs.github.com/en/rest/orgs/members#remove-organization-membership-for-a-user) | write |
[DELETE /orgs/{org}/organization-roles/teams/{team_slug}](https://docs.github.com/en/rest/orgs/organization-roles#remove-all-organization-roles-for-a-team) | write |
[PUT /orgs/{org}/organization-roles/teams/{team_slug}/{role_id}](https://docs.github.com/en/rest/orgs/organization-roles#assign-an-organization-role-to-a-team) | write |
[DELETE /orgs/{org}/organization-roles/teams/{team_slug}/{role_id}](https://docs.github.com/en/rest/orgs/organization-roles#remove-an-organization-role-from-a-team) | write |
[DELETE /orgs/{org}/organization-roles/users/{username}](https://docs.github.com/en/rest/orgs/organization-roles#remove-all-organization-roles-for-a-user) | write |
[PUT /orgs/{org}/organization-roles/users/{username}/{role_id}](https://docs.github.com/en/rest/orgs/organization-roles#assign-an-organization-role-to-a-user) | write |
[DELETE /orgs/{org}/organization-roles/users/{username}/{role_id}](https://docs.github.com/en/rest/orgs/organization-roles#remove-an-organization-role-from-a-user) | write |
[PUT /orgs/{org}/outside_collaborators/{username}](https://docs.github.com/en/rest/orgs/outside-collaborators#convert-an-organization-member-to-outside-collaborator) | write |
[DELETE /orgs/{org}/outside_collaborators/{username}](https://docs.github.com/en/rest/orgs/outside-collaborators#remove-outside-collaborator-from-an-organization) | write |
[PUT /orgs/{org}/public_members/{username}](https://docs.github.com/en/rest/orgs/members#set-public-organization-membership-for-the-authenticated-user) | write |
[DELETE /orgs/{org}/public_members/{username}](https://docs.github.com/en/rest/orgs/members#remove-public-organization-membership-for-the-authenticated-user) | write |
[POST /orgs/{org}/teams](https://docs.github.com/en/rest/teams/teams#create-a-team) | write |
[PATCH /orgs/{org}/teams/{team_slug}](https://docs.github.com/en/rest/teams/teams#update-a-team) | write |
[DELETE /orgs/{org}/teams/{team_slug}](https://docs.github.com/en/rest/teams/teams#delete-a-team) | write |
[PUT /orgs/{org}/teams/{team_slug}/memberships/{username}](https://docs.github.com/en/rest/teams/members#add-or-update-team-membership-for-a-user) | write |
[DELETE /orgs/{org}/teams/{team_slug}/memberships/{username}](https://docs.github.com/en/rest/teams/members#remove-team-membership-for-a-user) | write |
[PATCH /teams/{team_id}](https://docs.github.com/en/rest/teams/teams#update-a-team-legacy) | write |
[DELETE /teams/{team_id}](https://docs.github.com/en/rest/teams/teams#delete-a-team-legacy) | write |
[PUT /teams/{team_id}/members/{username}](https://docs.github.com/en/rest/teams/members#add-team-member-legacy) | write |
[DELETE /teams/{team_id}/members/{username}](https://docs.github.com/en/rest/teams/members#remove-team-member-legacy) | write |
[PUT /teams/{team_id}/memberships/{username}](https://docs.github.com/en/rest/teams/members#add-or-update-team-membership-for-a-user-legacy) | write |
[DELETE /teams/{team_id}/memberships/{username}](https://docs.github.com/en/rest/teams/members#remove-team-membership-for-a-user-legacy) | write |
[PATCH /user/memberships/orgs/{org}](https://docs.github.com/en/rest/orgs/members#update-an-organization-membership-for-the-authenticated-user) | write |
[GET /orgs/{org}/failed_invitations](https://docs.github.com/en/rest/orgs/members#list-failed-organization-invitations) | read |
[GET /orgs/{org}/invitations](https://docs.github.com/en/rest/orgs/members#list-pending-organization-invitations) | read |
[GET /orgs/{org}/invitations/{invitation_id}/teams](https://docs.github.com/en/rest/orgs/members#list-organization-invitation-teams) | read |
[GET /orgs/{org}/members](https://docs.github.com/en/rest/orgs/members#list-organization-members) | read |
[GET /orgs/{org}/members/{username}](https://docs.github.com/en/rest/orgs/members#check-organization-membership-for-a-user) | read |
[GET /orgs/{org}/memberships/{username}](https://docs.github.com/en/rest/orgs/members#get-organization-membership-for-a-user) | read |
[GET /orgs/{org}/organization-roles/{role_id}/teams](https://docs.github.com/en/rest/orgs/organization-roles#list-teams-that-are-assigned-to-an-organization-role) | read |
[GET /orgs/{org}/organization-roles/{role_id}/users](https://docs.github.com/en/rest/orgs/organization-roles#list-users-that-are-assigned-to-an-organization-role) | read |
[GET /orgs/{org}/outside_collaborators](https://docs.github.com/en/rest/orgs/outside-collaborators#list-outside-collaborators-for-an-organization) | read |
[GET /orgs/{org}/public_members](https://docs.github.com/en/rest/orgs/members#list-public-organization-members) | read |
[GET /orgs/{org}/public_members/{username}](https://docs.github.com/en/rest/orgs/members#check-public-organization-membership-for-a-user) | read |
[GET /orgs/{org}/teams](https://docs.github.com/en/rest/teams/teams#list-teams) | read |
[GET /orgs/{org}/teams/{team_slug}](https://docs.github.com/en/rest/teams/teams#get-a-team-by-name) | read |
[GET /orgs/{org}/teams/{team_slug}/invitations](https://docs.github.com/en/rest/teams/members#list-pending-team-invitations) | read |
[GET /orgs/{org}/teams/{team_slug}/members](https://docs.github.com/en/rest/teams/members#list-team-members) | read |
[GET /orgs/{org}/teams/{team_slug}/memberships/{username}](https://docs.github.com/en/rest/teams/members#get-team-membership-for-a-user) | read |
[GET /orgs/{org}/teams/{team_slug}/repos](https://docs.github.com/en/rest/teams/teams#list-team-repositories) | read |
[GET /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#check-team-permissions-for-a-repository) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#check-team-permissions-for-a-repository "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/teams/{team_slug}/teams](https://docs.github.com/en/rest/teams/teams#list-child-teams) | read |
[GET /teams/{team_id}](https://docs.github.com/en/rest/teams/teams#get-a-team-legacy) | read |
[GET /teams/{team_id}/invitations](https://docs.github.com/en/rest/teams/members#list-pending-team-invitations-legacy) | read |
[GET /teams/{team_id}/members](https://docs.github.com/en/rest/teams/members#list-team-members-legacy) | read |
[GET /teams/{team_id}/members/{username}](https://docs.github.com/en/rest/teams/members#get-team-member-legacy) | read |
[GET /teams/{team_id}/memberships/{username}](https://docs.github.com/en/rest/teams/members#get-team-membership-for-a-user-legacy) | read |
[GET /teams/{team_id}/repos](https://docs.github.com/en/rest/teams/teams#list-team-repositories-legacy) | read |
[GET /teams/{team_id}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#check-team-permissions-for-a-repository-legacy) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#check-team-permissions-for-a-repository-legacy "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /teams/{team_id}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions-legacy) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions-legacy "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /teams/{team_id}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team-legacy) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team-legacy "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /teams/{team_id}/teams](https://docs.github.com/en/rest/teams/teams#list-child-teams-legacy) | read |
[GET /user/memberships/orgs/{org}](https://docs.github.com/en/rest/orgs/members#get-an-organization-membership-for-the-authenticated-user) | read |
## [Organization permissions for "Network configurations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-network-configurations)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/settings/network-configurations](https://docs.github.com/en/rest/orgs/network-configurations#create-a-hosted-compute-network-configuration-for-an-organization) | write |
[PATCH /orgs/{org}/settings/network-configurations/{network_configuration_id}](https://docs.github.com/en/rest/orgs/network-configurations#update-a-hosted-compute-network-configuration-for-an-organization) | write |
[DELETE /orgs/{org}/settings/network-configurations/{network_configuration_id}](https://docs.github.com/en/rest/orgs/network-configurations#delete-a-hosted-compute-network-configuration-from-an-organization) | write |
[GET /orgs/{org}/settings/network-configurations](https://docs.github.com/en/rest/orgs/network-configurations#list-hosted-compute-network-configurations-for-an-organization) | read |
[GET /orgs/{org}/settings/network-configurations/{network_configuration_id}](https://docs.github.com/en/rest/orgs/network-configurations#get-a-hosted-compute-network-configuration-for-an-organization) | read |
[GET /orgs/{org}/settings/network-settings/{network_settings_id}](https://docs.github.com/en/rest/orgs/network-configurations#get-a-hosted-compute-network-settings-resource-for-an-organization) | read |
## [Organization permissions for "Organization codespaces secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/organization-secrets#create-or-update-an-organization-secret) | write |
[DELETE /orgs/{org}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/organization-secrets#delete-an-organization-secret) | write |
[PUT /orgs/{org}/codespaces/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret) | write |
[PUT /orgs/{org}/codespaces/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/codespaces/organization-secrets#add-selected-repository-to-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organization-secrets#add-selected-repository-to-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/codespaces/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/codespaces/secrets](https://docs.github.com/en/rest/codespaces/organization-secrets#list-organization-secrets) | read |
[GET /orgs/{org}/codespaces/secrets/public-key](https://docs.github.com/en/rest/codespaces/organization-secrets#get-an-organization-public-key) | read |
[GET /orgs/{org}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/organization-secrets#get-an-organization-secret) | read |
[GET /orgs/{org}/codespaces/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/codespaces/organization-secrets#list-selected-repositories-for-an-organization-secret) | read |
## [Organization permissions for "Organization codespaces settings"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces-settings)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/codespaces/access](https://docs.github.com/en/rest/codespaces/organizations#manage-access-control-for-organization-codespaces) | write |
[POST /orgs/{org}/codespaces/access/selected_users](https://docs.github.com/en/rest/codespaces/organizations#add-users-to-codespaces-access-for-an-organization) | write |
[DELETE /orgs/{org}/codespaces/access/selected_users](https://docs.github.com/en/rest/codespaces/organizations#remove-users-from-codespaces-access-for-an-organization) | write |
## [Organization permissions for "Organization codespaces"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-codespaces)
Endpoint | Access | Additional permissions
---|---|---
[DELETE /orgs/{org}/members/{username}/codespaces/{codespace_name}](https://docs.github.com/en/rest/codespaces/organizations#delete-a-codespace-from-the-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#delete-a-codespace-from-the-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/members/{username}/codespaces/{codespace_name}/stop](https://docs.github.com/en/rest/codespaces/organizations#stop-a-codespace-for-an-organization-user) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#stop-a-codespace-for-an-organization-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/codespaces](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-the-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-the-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/members/{username}/codespaces](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-a-user-in-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-a-user-in-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Organization permissions for "Organization dependabot secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-dependabot-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#create-or-update-an-organization-secret) | write |
[DELETE /orgs/{org}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#delete-an-organization-secret) | write |
[PUT /orgs/{org}/dependabot/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret) | write |
[PUT /orgs/{org}/dependabot/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/dependabot/secrets#add-selected-repository-to-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/dependabot/secrets#add-selected-repository-to-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/dependabot/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/dependabot/secrets](https://docs.github.com/en/rest/dependabot/secrets#list-organization-secrets) | read |
[GET /orgs/{org}/dependabot/secrets/public-key](https://docs.github.com/en/rest/dependabot/secrets#get-an-organization-public-key) | read |
[GET /orgs/{org}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#get-an-organization-secret) | read |
[GET /orgs/{org}/dependabot/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/dependabot/secrets#list-selected-repositories-for-an-organization-secret) | read |
## [Organization permissions for "Organization private registries"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-organization-private-registries)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/private-registries](https://docs.github.com/en/rest/private-registries/organization-configurations#create-a-private-registry-for-an-organization) | write |
[PATCH /orgs/{org}/private-registries/{secret_name}](https://docs.github.com/en/rest/private-registries/organization-configurations#update-a-private-registry-for-an-organization) | write |
[DELETE /orgs/{org}/private-registries/{secret_name}](https://docs.github.com/en/rest/private-registries/organization-configurations#delete-a-private-registry-for-an-organization) | write |
[GET /orgs/{org}/private-registries](https://docs.github.com/en/rest/private-registries/organization-configurations#list-private-registries-for-an-organization) | read |
[GET /orgs/{org}/private-registries/public-key](https://docs.github.com/en/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) | read |
[GET /orgs/{org}/private-registries/{secret_name}](https://docs.github.com/en/rest/private-registries/organization-configurations#get-a-private-registry-for-an-organization) | read |
## [Organization permissions for "Projects"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-projects)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/projectsV2/{project_number}/drafts](https://docs.github.com/en/rest/projects/drafts#create-draft-item-for-organization-owned-project) | write |
[POST /orgs/{org}/projectsV2/{project_number}/fields](https://docs.github.com/en/rest/projects/fields#add-a-field-to-an-organization-owned-project) | write |
[POST /orgs/{org}/projectsV2/{project_number}/items](https://docs.github.com/en/rest/projects/items#add-item-to-organization-owned-project) | write |
[PATCH /orgs/{org}/projectsV2/{project_number}/items/{item_id}](https://docs.github.com/en/rest/projects/items#update-project-item-for-organization) | write |
[DELETE /orgs/{org}/projectsV2/{project_number}/items/{item_id}](https://docs.github.com/en/rest/projects/items#delete-project-item-for-organization) | write |
[POST /orgs/{org}/projectsV2/{project_number}/views](https://docs.github.com/en/rest/projects/views#create-a-view-for-an-organization-owned-project) | write |
[GET /orgs/{org}/projectsV2](https://docs.github.com/en/rest/projects/projects#list-projects-for-organization) | read |
[GET /orgs/{org}/projectsV2/{project_number}](https://docs.github.com/en/rest/projects/projects#get-project-for-organization) | read |
[GET /orgs/{org}/projectsV2/{project_number}/fields](https://docs.github.com/en/rest/projects/fields#list-project-fields-for-organization) | read |
[GET /orgs/{org}/projectsV2/{project_number}/fields/{field_id}](https://docs.github.com/en/rest/projects/fields#get-project-field-for-organization) | read |
[GET /orgs/{org}/projectsV2/{project_number}/items](https://docs.github.com/en/rest/projects/items#list-items-for-an-organization-owned-project) | read |
[GET /orgs/{org}/projectsV2/{project_number}/items/{item_id}](https://docs.github.com/en/rest/projects/items#get-an-item-for-an-organization-owned-project) | read |
[GET /orgs/{org}/projectsV2/{project_number}/views/{view_number}/items](https://docs.github.com/en/rest/projects/items#list-items-for-an-organization-project-view) | read |
## [Organization permissions for "Secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /orgs/{org}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#create-or-update-an-organization-secret) | write |
[DELETE /orgs/{org}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#delete-an-organization-secret) | write |
[PUT /orgs/{org}/actions/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/actions/secrets#set-selected-repositories-for-an-organization-secret) | write |
[PUT /orgs/{org}/actions/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/secrets#add-selected-repository-to-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/secrets#add-selected-repository-to-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/actions/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/secrets#remove-selected-repository-from-an-organization-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/actions/secrets](https://docs.github.com/en/rest/actions/secrets#list-organization-secrets) | read |
[GET /orgs/{org}/actions/secrets/public-key](https://docs.github.com/en/rest/actions/secrets#get-an-organization-public-key) | read |
[GET /orgs/{org}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#get-an-organization-secret) | read |
[GET /orgs/{org}/actions/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/actions/secrets#list-selected-repositories-for-an-organization-secret) | read |
## [Organization permissions for "Self-hosted runners"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-self-hosted-runners)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/actions/runner-groups](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#create-a-self-hosted-runner-group-for-an-organization) | write |
[PATCH /orgs/{org}/actions/runner-groups/{runner_group_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#update-a-self-hosted-runner-group-for-an-organization) | write |
[DELETE /orgs/{org}/actions/runner-groups/{runner_group_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#delete-a-self-hosted-runner-group-from-an-organization) | write |
[PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#set-repository-access-for-a-self-hosted-runner-group-in-an-organization) | write |
[PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#add-repository-access-to-a-self-hosted-runner-group-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#add-repository-access-to-a-self-hosted-runner-group-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#remove-repository-access-to-a-self-hosted-runner-group-in-an-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#remove-repository-access-to-a-self-hosted-runner-group-in-an-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/runners](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#set-self-hosted-runners-in-a-group-for-an-organization) | write |
[PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#add-a-self-hosted-runner-to-a-group-for-an-organization) | write |
[DELETE /orgs/{org}/actions/runner-groups/{runner_group_id}/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#remove-a-self-hosted-runner-from-a-group-for-an-organization) | write |
[POST /orgs/{org}/actions/runners/generate-jitconfig](https://docs.github.com/en/rest/actions/self-hosted-runners#create-configuration-for-a-just-in-time-runner-for-an-organization) | write |
[POST /orgs/{org}/actions/runners/registration-token](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-registration-token-for-an-organization) | write |
[POST /orgs/{org}/actions/runners/remove-token](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-remove-token-for-an-organization) | write |
[DELETE /orgs/{org}/actions/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runners#delete-a-self-hosted-runner-from-an-organization) | write |
[POST /orgs/{org}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#add-custom-labels-to-a-self-hosted-runner-for-an-organization) | write |
[PUT /orgs/{org}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#set-custom-labels-for-a-self-hosted-runner-for-an-organization) | write |
[DELETE /orgs/{org}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization) | write |
[DELETE /orgs/{org}/actions/runners/{runner_id}/labels/{name}](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization) | write |
[GET /orgs/{org}/actions/runner-groups](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-self-hosted-runner-groups-for-an-organization) | read |
[GET /orgs/{org}/actions/runner-groups/{runner_group_id}](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#get-a-self-hosted-runner-group-for-an-organization) | read |
[GET /orgs/{org}/actions/runner-groups/{runner_group_id}/hosted-runners](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-github-hosted-runners-in-a-group-for-an-organization) | read |
[GET /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-repository-access-to-a-self-hosted-runner-group-in-an-organization) | read |
[GET /orgs/{org}/actions/runner-groups/{runner_group_id}/runners](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-self-hosted-runners-in-a-group-for-an-organization) | read |
[GET /orgs/{org}/actions/runners](https://docs.github.com/en/rest/actions/self-hosted-runners#list-self-hosted-runners-for-an-organization) | read |
[GET /orgs/{org}/actions/runners/downloads](https://docs.github.com/en/rest/actions/self-hosted-runners#list-runner-applications-for-an-organization) | read |
[GET /orgs/{org}/actions/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runners#get-a-self-hosted-runner-for-an-organization) | read |
[GET /orgs/{org}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#list-labels-for-a-self-hosted-runner-for-an-organization) | read |
## [Organization permissions for "Variables"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-variables)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/actions/variables](https://docs.github.com/en/rest/actions/variables#create-an-organization-variable) | write |
[PATCH /orgs/{org}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#update-an-organization-variable) | write |
[DELETE /orgs/{org}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#delete-an-organization-variable) | write |
[PUT /orgs/{org}/actions/variables/{name}/repositories](https://docs.github.com/en/rest/actions/variables#set-selected-repositories-for-an-organization-variable) | write |
[PUT /orgs/{org}/actions/variables/{name}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/variables#add-selected-repository-to-an-organization-variable) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/variables#add-selected-repository-to-an-organization-variable "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/actions/variables/{name}/repositories/{repository_id}](https://docs.github.com/en/rest/actions/variables#remove-selected-repository-from-an-organization-variable) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/actions/variables#remove-selected-repository-from-an-organization-variable "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/actions/variables](https://docs.github.com/en/rest/actions/variables#list-organization-variables) | read |
[GET /orgs/{org}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#get-an-organization-variable) | read |
[GET /orgs/{org}/actions/variables/{name}/repositories](https://docs.github.com/en/rest/actions/variables#list-selected-repositories-for-an-organization-variable) | read |
## [Organization permissions for "Webhooks"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#organization-permissions-for-webhooks)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/hooks](https://docs.github.com/en/rest/orgs/webhooks#create-an-organization-webhook) | write |
[PATCH /orgs/{org}/hooks/{hook_id}](https://docs.github.com/en/rest/orgs/webhooks#update-an-organization-webhook) | write |
[DELETE /orgs/{org}/hooks/{hook_id}](https://docs.github.com/en/rest/orgs/webhooks#delete-an-organization-webhook) | write |
[PATCH /orgs/{org}/hooks/{hook_id}/config](https://docs.github.com/en/rest/orgs/webhooks#update-a-webhook-configuration-for-an-organization) | write |
[POST /orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id}/attempts](https://docs.github.com/en/rest/orgs/webhooks#redeliver-a-delivery-for-an-organization-webhook) | write |
[POST /orgs/{org}/hooks/{hook_id}/pings](https://docs.github.com/en/rest/orgs/webhooks#ping-an-organization-webhook) | write |
[GET /orgs/{org}/hooks](https://docs.github.com/en/rest/orgs/webhooks#list-organization-webhooks) | read |
[GET /orgs/{org}/hooks/{hook_id}](https://docs.github.com/en/rest/orgs/webhooks#get-an-organization-webhook) | read |
[GET /orgs/{org}/hooks/{hook_id}/config](https://docs.github.com/en/rest/orgs/webhooks#get-a-webhook-configuration-for-an-organization) | read |
[GET /orgs/{org}/hooks/{hook_id}/deliveries](https://docs.github.com/en/rest/orgs/webhooks#list-deliveries-for-an-organization-webhook) | read |
[GET /orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id}](https://docs.github.com/en/rest/orgs/webhooks#get-a-webhook-delivery-for-an-organization-webhook) | read |
## [Repository permissions for "Actions"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-actions)
Endpoint | Access | Additional permissions
---|---|---
[DELETE /repos/{owner}/{repo}/actions/artifacts/{artifact_id}](https://docs.github.com/en/rest/actions/artifacts#delete-an-artifact) | write |
[DELETE /repos/{owner}/{repo}/actions/caches](https://docs.github.com/en/rest/actions/cache#delete-github-actions-caches-for-a-repository-using-a-cache-key) | write |
[DELETE /repos/{owner}/{repo}/actions/caches/{cache_id}](https://docs.github.com/en/rest/actions/cache#delete-a-github-actions-cache-for-a-repository-using-a-cache-id) | write |
[POST /repos/{owner}/{repo}/actions/jobs/{job_id}/rerun](https://docs.github.com/en/rest/actions/workflow-runs#re-run-a-job-from-a-workflow-run) | write |
[PUT /repos/{owner}/{repo}/actions/oidc/customization/sub](https://docs.github.com/en/rest/actions/oidc#set-the-customization-template-for-an-oidc-subject-claim-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/actions/runs/{run_id}](https://docs.github.com/en/rest/actions/workflow-runs#delete-a-workflow-run) | write |
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/approve](https://docs.github.com/en/rest/actions/workflow-runs#approve-a-workflow-run-for-a-fork-pull-request) | write |
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/cancel](https://docs.github.com/en/rest/actions/workflow-runs#cancel-a-workflow-run) | write |
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/force-cancel](https://docs.github.com/en/rest/actions/workflow-runs#force-cancel-a-workflow-run) | write |
[DELETE /repos/{owner}/{repo}/actions/runs/{run_id}/logs](https://docs.github.com/en/rest/actions/workflow-runs#delete-workflow-run-logs) | write |
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/rerun](https://docs.github.com/en/rest/actions/workflow-runs#re-run-a-workflow) | write |
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/rerun-failed-jobs](https://docs.github.com/en/rest/actions/workflow-runs#re-run-failed-jobs-from-a-workflow-run) | write |
[PUT /repos/{owner}/{repo}/actions/workflows/{workflow_id}/disable](https://docs.github.com/en/rest/actions/workflows#disable-a-workflow) | write |
[POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches](https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event) | write |
[PUT /repos/{owner}/{repo}/actions/workflows/{workflow_id}/enable](https://docs.github.com/en/rest/actions/workflows#enable-a-workflow) | write |
[GET /repos/{owner}/{repo}/actions/artifacts](https://docs.github.com/en/rest/actions/artifacts#list-artifacts-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/artifacts/{artifact_id}](https://docs.github.com/en/rest/actions/artifacts#get-an-artifact) | read |
[GET /repos/{owner}/{repo}/actions/artifacts/{artifact_id}/{archive_format}](https://docs.github.com/en/rest/actions/artifacts#download-an-artifact) | read |
[GET /repos/{owner}/{repo}/actions/cache/storage-limit](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-storage-limit-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/cache/usage](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-usage-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/caches](https://docs.github.com/en/rest/actions/cache#list-github-actions-caches-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/jobs/{job_id}](https://docs.github.com/en/rest/actions/workflow-jobs#get-a-job-for-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/jobs/{job_id}/logs](https://docs.github.com/en/rest/actions/workflow-jobs#download-job-logs-for-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/oidc/customization/sub](https://docs.github.com/en/rest/actions/oidc#get-the-customization-template-for-an-oidc-subject-claim-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runs](https://docs.github.com/en/rest/actions/workflow-runs#list-workflow-runs-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}](https://docs.github.com/en/rest/actions/workflow-runs#get-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/approvals](https://docs.github.com/en/rest/actions/workflow-runs#get-the-review-history-for-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/artifacts](https://docs.github.com/en/rest/actions/artifacts#list-workflow-run-artifacts) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}](https://docs.github.com/en/rest/actions/workflow-runs#get-a-workflow-run-attempt) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/jobs](https://docs.github.com/en/rest/actions/workflow-jobs#list-jobs-for-a-workflow-run-attempt) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/logs](https://docs.github.com/en/rest/actions/workflow-runs#download-workflow-run-attempt-logs) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs](https://docs.github.com/en/rest/actions/workflow-jobs#list-jobs-for-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/logs](https://docs.github.com/en/rest/actions/workflow-runs#download-workflow-run-logs) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments](https://docs.github.com/en/rest/actions/workflow-runs#get-pending-deployments-for-a-workflow-run) | read |
[GET /repos/{owner}/{repo}/actions/runs/{run_id}/timing](https://docs.github.com/en/rest/actions/workflow-runs#get-workflow-run-usage) | read |
[GET /repos/{owner}/{repo}/actions/workflows](https://docs.github.com/en/rest/actions/workflows#list-repository-workflows) | read |
[GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}](https://docs.github.com/en/rest/actions/workflows#get-a-workflow) | read |
[GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs](https://docs.github.com/en/rest/actions/workflow-runs#list-workflow-runs-for-a-workflow) | read |
[GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/timing](https://docs.github.com/en/rest/actions/workflows#get-workflow-usage) | read |
[GET /repos/{owner}/{repo}/environments](https://docs.github.com/en/rest/deployments/environments#list-environments) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}](https://docs.github.com/en/rest/deployments/environments#get-an-environment) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies](https://docs.github.com/en/rest/deployments/branch-policies#list-deployment-branch-policies) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id}](https://docs.github.com/en/rest/deployments/branch-policies#get-a-deployment-branch-policy) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules](https://docs.github.com/en/rest/deployments/protection-rules#get-all-deployment-protection-rules-for-an-environment) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/{protection_rule_id}](https://docs.github.com/en/rest/deployments/protection-rules#get-a-custom-deployment-protection-rule) | read |
## [Repository permissions for "Administration"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-administration)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/repos](https://docs.github.com/en/rest/repos/repos#create-an-organization-repository) | write |
[PUT /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}](https://docs.github.com/en/rest/repos/repos#update-a-repository) | write |
[DELETE /repos/{owner}/{repo}](https://docs.github.com/en/rest/repos/repos#delete-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/cache/retention-limit](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-retention-limit-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/cache/storage-limit](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-storage-limit-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions](https://docs.github.com/en/rest/actions/permissions#set-github-actions-permissions-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/access](https://docs.github.com/en/rest/actions/permissions#set-the-level-of-access-for-workflows-outside-of-the-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/artifact-and-log-retention](https://docs.github.com/en/rest/actions/permissions#set-artifact-and-log-retention-settings-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/fork-pr-contributor-approval](https://docs.github.com/en/rest/actions/permissions#set-fork-pr-contributor-approval-permissions-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/fork-pr-workflows-private-repos](https://docs.github.com/en/rest/actions/permissions#set-private-repo-fork-pr-workflow-settings-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/selected-actions](https://docs.github.com/en/rest/actions/permissions#set-allowed-actions-and-reusable-workflows-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/permissions/workflow](https://docs.github.com/en/rest/actions/permissions#set-default-workflow-permissions-for-a-repository) | write |
[POST /repos/{owner}/{repo}/actions/runners/generate-jitconfig](https://docs.github.com/en/rest/actions/self-hosted-runners#create-configuration-for-a-just-in-time-runner-for-a-repository) | write |
[POST /repos/{owner}/{repo}/actions/runners/registration-token](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-registration-token-for-a-repository) | write |
[POST /repos/{owner}/{repo}/actions/runners/remove-token](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-remove-token-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/actions/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runners#delete-a-self-hosted-runner-from-a-repository) | write |
[POST /repos/{owner}/{repo}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#add-custom-labels-to-a-self-hosted-runner-for-a-repository) | write |
[PUT /repos/{owner}/{repo}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#set-custom-labels-for-a-self-hosted-runner-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/actions/runners/{runner_id}/labels/{name}](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository) | write |
[POST /repos/{owner}/{repo}/autolinks](https://docs.github.com/en/rest/repos/autolinks#create-an-autolink-reference-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/autolinks/{autolink_id}](https://docs.github.com/en/rest/repos/autolinks#delete-an-autolink-reference-from-a-repository) | write |
[PUT /repos/{owner}/{repo}/automated-security-fixes](https://docs.github.com/en/rest/repos/repos#enable-dependabot-security-updates) | write |
[DELETE /repos/{owner}/{repo}/automated-security-fixes](https://docs.github.com/en/rest/repos/repos#disable-dependabot-security-updates) | write |
[PUT /repos/{owner}/{repo}/branches/{branch}/protection](https://docs.github.com/en/rest/branches/branch-protection#update-branch-protection) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection](https://docs.github.com/en/rest/branches/branch-protection#delete-branch-protection) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins](https://docs.github.com/en/rest/branches/branch-protection#set-admin-branch-protection) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins](https://docs.github.com/en/rest/branches/branch-protection#delete-admin-branch-protection) | write |
[PATCH /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews](https://docs.github.com/en/rest/branches/branch-protection#update-pull-request-review-protection) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews](https://docs.github.com/en/rest/branches/branch-protection#delete-pull-request-review-protection) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures](https://docs.github.com/en/rest/branches/branch-protection#create-commit-signature-protection) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures](https://docs.github.com/en/rest/branches/branch-protection#delete-commit-signature-protection) | write |
[PATCH /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks](https://docs.github.com/en/rest/branches/branch-protection#update-status-check-protection) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks](https://docs.github.com/en/rest/branches/branch-protection#remove-status-check-protection) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts](https://docs.github.com/en/rest/branches/branch-protection#add-status-check-contexts) | write |
[PUT /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts](https://docs.github.com/en/rest/branches/branch-protection#set-status-check-contexts) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts](https://docs.github.com/en/rest/branches/branch-protection#remove-status-check-contexts) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions](https://docs.github.com/en/rest/branches/branch-protection#delete-access-restrictions) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps](https://docs.github.com/en/rest/branches/branch-protection#add-app-access-restrictions) | write |
[PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps](https://docs.github.com/en/rest/branches/branch-protection#set-app-access-restrictions) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps](https://docs.github.com/en/rest/branches/branch-protection#remove-app-access-restrictions) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams](https://docs.github.com/en/rest/branches/branch-protection#add-team-access-restrictions) | write |
[PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams](https://docs.github.com/en/rest/branches/branch-protection#set-team-access-restrictions) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams](https://docs.github.com/en/rest/branches/branch-protection#remove-team-access-restrictions) | write |
[POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users](https://docs.github.com/en/rest/branches/branch-protection#add-user-access-restrictions) | write |
[PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users](https://docs.github.com/en/rest/branches/branch-protection#set-user-access-restrictions) | write |
[DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users](https://docs.github.com/en/rest/branches/branch-protection#remove-user-access-restrictions) | write |
[PATCH /repos/{owner}/{repo}/code-scanning/default-setup](https://docs.github.com/en/rest/code-scanning/code-scanning#update-a-code-scanning-default-setup-configuration) | write |
[PUT /repos/{owner}/{repo}/collaborators/{username}](https://docs.github.com/en/rest/collaborators/collaborators#add-a-repository-collaborator) | write |
[DELETE /repos/{owner}/{repo}/collaborators/{username}](https://docs.github.com/en/rest/collaborators/collaborators#remove-a-repository-collaborator) | write |
[PUT /repos/{owner}/{repo}/environments/{environment_name}](https://docs.github.com/en/rest/deployments/environments#create-or-update-an-environment) | write |
[DELETE /repos/{owner}/{repo}/environments/{environment_name}](https://docs.github.com/en/rest/deployments/environments#delete-an-environment) | write |
[POST /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies](https://docs.github.com/en/rest/deployments/branch-policies#create-a-deployment-branch-policy) | write |
[PUT /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id}](https://docs.github.com/en/rest/deployments/branch-policies#update-a-deployment-branch-policy) | write |
[DELETE /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id}](https://docs.github.com/en/rest/deployments/branch-policies#delete-a-deployment-branch-policy) | write |
[POST /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules](https://docs.github.com/en/rest/deployments/protection-rules#create-a-custom-deployment-protection-rule-on-an-environment) | write |
[DELETE /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/{protection_rule_id}](https://docs.github.com/en/rest/deployments/protection-rules#disable-a-custom-protection-rule-for-an-environment) | write |
[POST /repos/{owner}/{repo}/forks](https://docs.github.com/en/rest/repos/forks#create-a-fork) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/forks#create-a-fork "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/immutable-releases](https://docs.github.com/en/rest/repos/repos#enable-immutable-releases) | write |
[DELETE /repos/{owner}/{repo}/immutable-releases](https://docs.github.com/en/rest/repos/repos#disable-immutable-releases) | write |
[PUT /repos/{owner}/{repo}/interaction-limits](https://docs.github.com/en/rest/interactions/repos#set-interaction-restrictions-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/interaction-limits](https://docs.github.com/en/rest/interactions/repos#remove-interaction-restrictions-for-a-repository) | write |
[PATCH /repos/{owner}/{repo}/invitations/{invitation_id}](https://docs.github.com/en/rest/collaborators/invitations#update-a-repository-invitation) | write |
[DELETE /repos/{owner}/{repo}/invitations/{invitation_id}](https://docs.github.com/en/rest/collaborators/invitations#delete-a-repository-invitation) | write |
[POST /repos/{owner}/{repo}/keys](https://docs.github.com/en/rest/deploy-keys/deploy-keys#create-a-deploy-key) | write |
[DELETE /repos/{owner}/{repo}/keys/{key_id}](https://docs.github.com/en/rest/deploy-keys/deploy-keys#delete-a-deploy-key) | write |
[POST /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#update-information-about-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#update-information-about-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#delete-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#delete-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/pages/health](https://docs.github.com/en/rest/pages/pages#get-a-dns-health-check-for-github-pages) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#get-a-dns-health-check-for-github-pages "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/private-vulnerability-reporting](https://docs.github.com/en/rest/repos/repos#enable-private-vulnerability-reporting-for-a-repository) | write |
[DELETE /repos/{owner}/{repo}/private-vulnerability-reporting](https://docs.github.com/en/rest/repos/repos#disable-private-vulnerability-reporting-for-a-repository) | write |
[POST /repos/{owner}/{repo}/rulesets](https://docs.github.com/en/rest/repos/rules#create-a-repository-ruleset) | write |
[GET /repos/{owner}/{repo}/rulesets/rule-suites](https://docs.github.com/en/rest/repos/rule-suites#list-repository-rule-suites) | write |
[GET /repos/{owner}/{repo}/rulesets/rule-suites/{rule_suite_id}](https://docs.github.com/en/rest/repos/rule-suites#get-a-repository-rule-suite) | write |
[PUT /repos/{owner}/{repo}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/repos/rules#update-a-repository-ruleset) | write |
[DELETE /repos/{owner}/{repo}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/repos/rules#delete-a-repository-ruleset) | write |
[GET /repos/{owner}/{repo}/rulesets/{ruleset_id}/history](https://docs.github.com/en/rest/repos/rules#get-repository-ruleset-history) | write |
[GET /repos/{owner}/{repo}/rulesets/{ruleset_id}/history/{version_id}](https://docs.github.com/en/rest/repos/rules#get-repository-ruleset-version) | write |
[POST /repos/{owner}/{repo}/security-advisories/{ghsa_id}/forks](https://docs.github.com/en/rest/security-advisories/repository-advisories#create-a-temporary-private-fork) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/security-advisories/repository-advisories#create-a-temporary-private-fork "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/topics](https://docs.github.com/en/rest/repos/repos#replace-all-repository-topics) | write |
[PUT /repos/{owner}/{repo}/vulnerability-alerts](https://docs.github.com/en/rest/repos/repos#enable-vulnerability-alerts) | write |
[DELETE /repos/{owner}/{repo}/vulnerability-alerts](https://docs.github.com/en/rest/repos/repos#disable-vulnerability-alerts) | write |
[POST /repos/{template_owner}/{template_repo}/generate](https://docs.github.com/en/rest/repos/repos#create-a-repository-using-a-template) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/repos#create-a-repository-using-a-template "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /teams/{team_id}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions-legacy) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#add-or-update-team-repository-permissions-legacy "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /teams/{team_id}/repos/{owner}/{repo}](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team-legacy) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/teams/teams#remove-a-repository-from-a-team-legacy "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /user/repos](https://docs.github.com/en/rest/repos/repos#create-a-repository-for-the-authenticated-user) | write |
[DELETE /user/repository_invitations/{invitation_id}](https://docs.github.com/en/rest/collaborators/invitations#decline-a-repository-invitation) | write |
[GET /repos/{owner}/{repo}/actions/cache/retention-limit](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-retention-limit-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions](https://docs.github.com/en/rest/actions/permissions#get-github-actions-permissions-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/access](https://docs.github.com/en/rest/actions/permissions#get-the-level-of-access-for-workflows-outside-of-the-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/artifact-and-log-retention](https://docs.github.com/en/rest/actions/permissions#get-artifact-and-log-retention-settings-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/fork-pr-contributor-approval](https://docs.github.com/en/rest/actions/permissions#get-fork-pr-contributor-approval-permissions-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/fork-pr-workflows-private-repos](https://docs.github.com/en/rest/actions/permissions#get-private-repo-fork-pr-workflow-settings-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/selected-actions](https://docs.github.com/en/rest/actions/permissions#get-allowed-actions-and-reusable-workflows-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/permissions/workflow](https://docs.github.com/en/rest/actions/permissions#get-default-workflow-permissions-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runners](https://docs.github.com/en/rest/actions/self-hosted-runners#list-self-hosted-runners-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runners/downloads](https://docs.github.com/en/rest/actions/self-hosted-runners#list-runner-applications-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runners/{runner_id}](https://docs.github.com/en/rest/actions/self-hosted-runners#get-a-self-hosted-runner-for-a-repository) | read |
[GET /repos/{owner}/{repo}/actions/runners/{runner_id}/labels](https://docs.github.com/en/rest/actions/self-hosted-runners#list-labels-for-a-self-hosted-runner-for-a-repository) | read |
[GET /repos/{owner}/{repo}/autolinks](https://docs.github.com/en/rest/repos/autolinks#get-all-autolinks-of-a-repository) | read |
[GET /repos/{owner}/{repo}/autolinks/{autolink_id}](https://docs.github.com/en/rest/repos/autolinks#get-an-autolink-reference-of-a-repository) | read |
[GET /repos/{owner}/{repo}/automated-security-fixes](https://docs.github.com/en/rest/repos/repos#check-if-dependabot-security-updates-are-enabled-for-a-repository) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection](https://docs.github.com/en/rest/branches/branch-protection#get-branch-protection) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins](https://docs.github.com/en/rest/branches/branch-protection#get-admin-branch-protection) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews](https://docs.github.com/en/rest/branches/branch-protection#get-pull-request-review-protection) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures](https://docs.github.com/en/rest/branches/branch-protection#get-commit-signature-protection) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks](https://docs.github.com/en/rest/branches/branch-protection#get-status-checks-protection) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts](https://docs.github.com/en/rest/branches/branch-protection#get-all-status-check-contexts) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions](https://docs.github.com/en/rest/branches/branch-protection#get-access-restrictions) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps](https://docs.github.com/en/rest/branches/branch-protection#get-apps-with-access-to-the-protected-branch) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams](https://docs.github.com/en/rest/branches/branch-protection#get-teams-with-access-to-the-protected-branch) | read |
[GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users](https://docs.github.com/en/rest/branches/branch-protection#get-users-with-access-to-the-protected-branch) | read |
[GET /repos/{owner}/{repo}/code-scanning/default-setup](https://docs.github.com/en/rest/code-scanning/code-scanning#get-a-code-scanning-default-setup-configuration) | read |
[GET /repos/{owner}/{repo}/code-security-configuration](https://docs.github.com/en/rest/code-security/configurations#get-the-code-security-configuration-associated-with-a-repository) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/apps](https://docs.github.com/en/rest/deployments/protection-rules#list-custom-deployment-rule-integrations-available-for-an-environment) | read |
[GET /repos/{owner}/{repo}/immutable-releases](https://docs.github.com/en/rest/repos/repos#check-if-immutable-releases-are-enabled-for-a-repository) | read |
[GET /repos/{owner}/{repo}/interaction-limits](https://docs.github.com/en/rest/interactions/repos#get-interaction-restrictions-for-a-repository) | read |
[GET /repos/{owner}/{repo}/invitations](https://docs.github.com/en/rest/collaborators/invitations#list-repository-invitations) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/collaborators/invitations#list-repository-invitations "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/keys](https://docs.github.com/en/rest/deploy-keys/deploy-keys#list-deploy-keys) | read |
[GET /repos/{owner}/{repo}/keys/{key_id}](https://docs.github.com/en/rest/deploy-keys/deploy-keys#get-a-deploy-key) | read |
[GET /repos/{owner}/{repo}/teams](https://docs.github.com/en/rest/repos/repos#list-repository-teams) | read |
[GET /repos/{owner}/{repo}/traffic/clones](https://docs.github.com/en/rest/metrics/traffic#get-repository-clones) | read |
[GET /repos/{owner}/{repo}/traffic/popular/paths](https://docs.github.com/en/rest/metrics/traffic#get-top-referral-paths) | read |
[GET /repos/{owner}/{repo}/traffic/popular/referrers](https://docs.github.com/en/rest/metrics/traffic#get-top-referral-sources) | read |
[GET /repos/{owner}/{repo}/traffic/views](https://docs.github.com/en/rest/metrics/traffic#get-page-views) | read |
[GET /repos/{owner}/{repo}/vulnerability-alerts](https://docs.github.com/en/rest/repos/repos#check-if-vulnerability-alerts-are-enabled-for-a-repository) | read |
[GET /user/repository_invitations](https://docs.github.com/en/rest/collaborators/invitations#list-repository-invitations-for-the-authenticated-user) | read |
## [Repository permissions for "Artifact metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-artifact-metadata)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/artifacts/metadata/deployment-record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-an-artifact-deployment-record) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#create-an-artifact-deployment-record "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/artifacts/metadata/deployment-record/cluster/{cluster}](https://docs.github.com/en/rest/orgs/artifact-metadata#set-cluster-deployment-records) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#set-cluster-deployment-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/artifacts/metadata/storage-record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-artifact-metadata-storage-record) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#create-artifact-metadata-storage-record "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/artifacts/{subject_digest}/metadata/deployment-records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-deployment-records) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-deployment-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/artifacts/{subject_digest}/metadata/storage-records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-storage-records) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-storage-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Repository permissions for "Attestations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-attestations)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/attestations/delete-request](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-in-bulk) | write |
[DELETE /orgs/{org}/attestations/digest/{subject_digest}](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-by-subject-digest) | write |
[DELETE /orgs/{org}/attestations/{attestation_id}](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-by-id) | write |
[POST /repos/{owner}/{repo}/attestations](https://docs.github.com/en/rest/repos/attestations#create-an-attestation) | write |
[POST /users/{username}/attestations/delete-request](https://docs.github.com/en/rest/users/attestations#delete-attestations-in-bulk) | write |
[DELETE /users/{username}/attestations/digest/{subject_digest}](https://docs.github.com/en/rest/users/attestations#delete-attestations-by-subject-digest) | write |
[DELETE /users/{username}/attestations/{attestation_id}](https://docs.github.com/en/rest/users/attestations#delete-attestations-by-id) | write |
[GET /orgs/{org}/attestations/repositories](https://docs.github.com/en/rest/orgs/attestations#list-attestation-repositories) | read |
[GET /repos/{owner}/{repo}/attestations/{subject_digest}](https://docs.github.com/en/rest/repos/attestations#list-attestations) | read |
## [Repository permissions for "Code scanning alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-code-scanning-alerts)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}](https://docs.github.com/en/rest/code-scanning/code-scanning#update-a-code-scanning-alert) | write |
[POST /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix](https://docs.github.com/en/rest/code-scanning/code-scanning#create-an-autofix-for-a-code-scanning-alert) | write |
[DELETE /repos/{owner}/{repo}/code-scanning/analyses/{analysis_id}](https://docs.github.com/en/rest/code-scanning/code-scanning#delete-a-code-scanning-analysis-from-a-repository) | write |
[POST /repos/{owner}/{repo}/code-scanning/sarifs](https://docs.github.com/en/rest/code-scanning/code-scanning#upload-an-analysis-as-sarif-data) | write |
[GET /orgs/{org}/code-scanning/alerts](https://docs.github.com/en/rest/code-scanning/code-scanning#list-code-scanning-alerts-for-an-organization) | read |
[GET /repos/{owner}/{repo}/code-scanning/alerts](https://docs.github.com/en/rest/code-scanning/code-scanning#list-code-scanning-alerts-for-a-repository) | read |
[GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-a-code-scanning-alert) | read |
[GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix](https://docs.github.com/en/rest/code-scanning/code-scanning#get-the-status-of-an-autofix-for-a-code-scanning-alert) | read |
[GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/instances](https://docs.github.com/en/rest/code-scanning/code-scanning#list-instances-of-a-code-scanning-alert) | read |
[GET /repos/{owner}/{repo}/code-scanning/analyses](https://docs.github.com/en/rest/code-scanning/code-scanning#list-code-scanning-analyses-for-a-repository) | read |
[GET /repos/{owner}/{repo}/code-scanning/analyses/{analysis_id}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-a-code-scanning-analysis-for-a-repository) | read |
[GET /repos/{owner}/{repo}/code-scanning/sarifs/{sarif_id}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-information-about-a-sarif-upload) | read |
## [Repository permissions for "Codespaces lifecycle admin"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-lifecycle-admin)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/members/{username}/codespaces/{codespace_name}/stop](https://docs.github.com/en/rest/codespaces/organizations#stop-a-codespace-for-an-organization-user) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#stop-a-codespace-for-an-organization-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /user/codespaces/{codespace_name}/exports](https://docs.github.com/en/rest/codespaces/codespaces#export-a-codespace-for-the-authenticated-user) | write |
[POST /user/codespaces/{codespace_name}/start](https://docs.github.com/en/rest/codespaces/codespaces#start-a-codespace-for-the-authenticated-user) | write |
[POST /user/codespaces/{codespace_name}/stop](https://docs.github.com/en/rest/codespaces/codespaces#stop-a-codespace-for-the-authenticated-user) | write |
[GET /user/codespaces/{codespace_name}/exports/{export_id}](https://docs.github.com/en/rest/codespaces/codespaces#get-details-about-a-codespace-export) | read |
## [Repository permissions for "Codespaces metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-metadata)
Endpoint | Access | Additional permissions
---|---|---
[GET /repos/{owner}/{repo}/codespaces/devcontainers](https://docs.github.com/en/rest/codespaces/codespaces#list-devcontainer-configurations-in-a-repository-for-the-authenticated-user) | read |
[GET /repos/{owner}/{repo}/codespaces/machines](https://docs.github.com/en/rest/codespaces/machines#list-available-machine-types-for-a-repository) | read |
[GET /user/codespaces/{codespace_name}/machines](https://docs.github.com/en/rest/codespaces/machines#list-machine-types-for-a-codespace) | read |
## [Repository permissions for "Codespaces secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces-secrets)
Endpoint | Access | Additional permissions
---|---|---
[GET /repos/{owner}/{repo}/codespaces/secrets](https://docs.github.com/en/rest/codespaces/repository-secrets#list-repository-secrets) | write |
[GET /repos/{owner}/{repo}/codespaces/secrets/public-key](https://docs.github.com/en/rest/codespaces/repository-secrets#get-a-repository-public-key) | write |
[GET /repos/{owner}/{repo}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/repository-secrets#get-a-repository-secret) | write |
[PUT /repos/{owner}/{repo}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/repository-secrets#create-or-update-a-repository-secret) | write |
[DELETE /repos/{owner}/{repo}/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/repository-secrets#delete-a-repository-secret) | write |
## [Repository permissions for "Codespaces"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-codespaces)
Endpoint | Access | Additional permissions
---|---|---
[DELETE /orgs/{org}/members/{username}/codespaces/{codespace_name}](https://docs.github.com/en/rest/codespaces/organizations#delete-a-codespace-from-the-organization) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#delete-a-codespace-from-the-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/codespaces](https://docs.github.com/en/rest/codespaces/codespaces#create-a-codespace-in-a-repository) | write |
[GET /repos/{owner}/{repo}/codespaces/new](https://docs.github.com/en/rest/codespaces/codespaces#get-default-attributes-for-a-codespace) | write |
[GET /repos/{owner}/{repo}/codespaces/permissions_check](https://docs.github.com/en/rest/codespaces/codespaces#check-if-permissions-defined-by-a-devcontainer-have-been-accepted-by-the-authenticated-user) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/codespaces](https://docs.github.com/en/rest/codespaces/codespaces#create-a-codespace-from-a-pull-request) | write |
[POST /user/codespaces](https://docs.github.com/en/rest/codespaces/codespaces#create-a-codespace-for-the-authenticated-user) | write |
[PATCH /user/codespaces/{codespace_name}](https://docs.github.com/en/rest/codespaces/codespaces#update-a-codespace-for-the-authenticated-user) | write |
[DELETE /user/codespaces/{codespace_name}](https://docs.github.com/en/rest/codespaces/codespaces#delete-a-codespace-for-the-authenticated-user) | write |
[POST /user/codespaces/{codespace_name}/publish](https://docs.github.com/en/rest/codespaces/codespaces#create-a-repository-from-an-unpublished-codespace) | write |
[GET /orgs/{org}/codespaces](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-the-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-the-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/members/{username}/codespaces](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-a-user-in-organization) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/organizations#list-codespaces-for-a-user-in-organization "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/codespaces](https://docs.github.com/en/rest/codespaces/codespaces#list-codespaces-in-a-repository-for-the-authenticated-user) | read |
[GET /user/codespaces](https://docs.github.com/en/rest/codespaces/codespaces#list-codespaces-for-the-authenticated-user) | read |
[GET /user/codespaces/{codespace_name}](https://docs.github.com/en/rest/codespaces/codespaces#get-a-codespace-for-the-authenticated-user) | read |
## [Repository permissions for "Commit statuses"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-commit-statuses)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/statuses/{sha}](https://docs.github.com/en/rest/commits/statuses#create-a-commit-status) | write |
[GET /repos/{owner}/{repo}/commits/{ref}/status](https://docs.github.com/en/rest/commits/statuses#get-the-combined-status-for-a-specific-reference) | read |
[GET /repos/{owner}/{repo}/commits/{ref}/statuses](https://docs.github.com/en/rest/commits/statuses#list-commit-statuses-for-a-reference) | read |
## [Repository permissions for "Contents"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-contents)
Endpoint | Access | Additional permissions
---|---|---
[POST /orgs/{org}/artifacts/metadata/deployment-record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-an-artifact-deployment-record) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#create-an-artifact-deployment-record "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/artifacts/metadata/deployment-record/cluster/{cluster}](https://docs.github.com/en/rest/orgs/artifact-metadata#set-cluster-deployment-records) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#set-cluster-deployment-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /orgs/{org}/artifacts/metadata/storage-record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-artifact-metadata-storage-record) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#create-artifact-metadata-storage-record "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/branches/{branch}/rename](https://docs.github.com/en/rest/branches/branches#rename-a-branch) | write |
[POST /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix/commits](https://docs.github.com/en/rest/code-scanning/code-scanning#commit-an-autofix-for-a-code-scanning-alert) | write |
[DELETE /repos/{owner}/{repo}/code-scanning/codeql/databases/{language}](https://docs.github.com/en/rest/code-scanning/code-scanning#delete-a-codeql-database) | write |
[POST /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses](https://docs.github.com/en/rest/code-scanning/code-scanning#create-a-codeql-variant-analysis) | write |
[PATCH /repos/{owner}/{repo}/comments/{comment_id}](https://docs.github.com/en/rest/commits/comments#update-a-commit-comment) | write |
[DELETE /repos/{owner}/{repo}/comments/{comment_id}](https://docs.github.com/en/rest/commits/comments#delete-a-commit-comment) | write |
[POST /repos/{owner}/{repo}/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#create-reaction-for-a-commit-comment) | write |
[DELETE /repos/{owner}/{repo}/comments/{comment_id}/reactions/{reaction_id}](https://docs.github.com/en/rest/reactions/reactions#delete-a-commit-comment-reaction) | write |
[PUT /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#delete-a-file) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#delete-a-file "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#delete-a-file) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#delete-a-file "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/dependency-graph/snapshots](https://docs.github.com/en/rest/dependency-graph/dependency-submission#create-a-snapshot-of-dependencies-for-a-repository) | write |
[POST /repos/{owner}/{repo}/dispatches](https://docs.github.com/en/rest/repos/repos#create-a-repository-dispatch-event) | write |
[POST /repos/{owner}/{repo}/git/blobs](https://docs.github.com/en/rest/git/blobs#create-a-blob) | write |
[POST /repos/{owner}/{repo}/git/commits](https://docs.github.com/en/rest/git/commits#create-a-commit) | write |
[POST /repos/{owner}/{repo}/git/refs](https://docs.github.com/en/rest/git/refs#create-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#create-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/git/refs](https://docs.github.com/en/rest/git/refs#create-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#create-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/git/refs/{ref}](https://docs.github.com/en/rest/git/refs#update-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#update-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/git/refs/{ref}](https://docs.github.com/en/rest/git/refs#update-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#update-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/git/refs/{ref}](https://docs.github.com/en/rest/git/refs#delete-a-reference) | write |
[POST /repos/{owner}/{repo}/git/tags](https://docs.github.com/en/rest/git/tags#create-a-tag-object) | write |
[POST /repos/{owner}/{repo}/git/trees](https://docs.github.com/en/rest/git/trees#create-a-tree) | write |
[PUT /repos/{owner}/{repo}/import](https://docs.github.com/en/rest/migrations/source-imports#start-an-import) | write |
[PATCH /repos/{owner}/{repo}/import](https://docs.github.com/en/rest/migrations/source-imports#update-an-import) | write |
[DELETE /repos/{owner}/{repo}/import](https://docs.github.com/en/rest/migrations/source-imports#cancel-an-import) | write |
[PATCH /repos/{owner}/{repo}/import/authors/{author_id}](https://docs.github.com/en/rest/migrations/source-imports#map-a-commit-author) | write |
[PATCH /repos/{owner}/{repo}/import/lfs](https://docs.github.com/en/rest/migrations/source-imports#update-git-lfs-preference) | write |
[POST /repos/{owner}/{repo}/merge-upstream](https://docs.github.com/en/rest/branches/branches#sync-a-fork-branch-with-the-upstream-repository) | write |
[POST /repos/{owner}/{repo}/merges](https://docs.github.com/en/rest/branches/branches#merge-a-branch) | write |
[PUT /repos/{owner}/{repo}/pulls/{pull_number}/merge](https://docs.github.com/en/rest/pulls/pulls#merge-a-pull-request) | write |
[POST /repos/{owner}/{repo}/releases](https://docs.github.com/en/rest/releases/releases#create-a-release) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/releases/releases#create-a-release "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/releases](https://docs.github.com/en/rest/releases/releases#create-a-release) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/releases/releases#create-a-release "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/releases/assets/{asset_id}](https://docs.github.com/en/rest/releases/assets#update-a-release-asset) | write |
[DELETE /repos/{owner}/{repo}/releases/assets/{asset_id}](https://docs.github.com/en/rest/releases/assets#delete-a-release-asset) | write |
[POST /repos/{owner}/{repo}/releases/generate-notes](https://docs.github.com/en/rest/releases/releases#generate-release-notes-content-for-a-release) | write |
[PATCH /repos/{owner}/{repo}/releases/{release_id}](https://docs.github.com/en/rest/releases/releases#update-a-release) | write |
[DELETE /repos/{owner}/{repo}/releases/{release_id}](https://docs.github.com/en/rest/releases/releases#delete-a-release) | write |
[POST /repos/{owner}/{repo}/secret-scanning/push-protection-bypasses](https://docs.github.com/en/rest/secret-scanning/secret-scanning#create-a-push-protection-bypass) | write |
[POST /markdown](https://docs.github.com/en/rest/markdown/markdown#render-a-markdown-document) | read |
[GET /orgs/{org}/artifacts/{subject_digest}/metadata/deployment-records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-deployment-records) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-deployment-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /orgs/{org}/artifacts/{subject_digest}/metadata/storage-records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-storage-records) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-storage-records "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/activity](https://docs.github.com/en/rest/repos/repos#list-repository-activities) | read |
[GET /repos/{owner}/{repo}/branches](https://docs.github.com/en/rest/branches/branches#list-branches) | read |
[GET /repos/{owner}/{repo}/branches/{branch}](https://docs.github.com/en/rest/branches/branches#get-a-branch) | read |
[GET /repos/{owner}/{repo}/code-scanning/codeql/databases](https://docs.github.com/en/rest/code-scanning/code-scanning#list-codeql-databases-for-a-repository) | read |
[GET /repos/{owner}/{repo}/code-scanning/codeql/databases/{language}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-a-codeql-database-for-a-repository) | read |
[GET /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-the-summary-of-a-codeql-variant-analysis) | read |
[GET /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id}/repos/{repo_owner}/{repo_name}](https://docs.github.com/en/rest/code-scanning/code-scanning#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis) | read |
[GET /repos/{owner}/{repo}/codeowners/errors](https://docs.github.com/en/rest/repos/repos#list-codeowners-errors) | read |
[GET /repos/{owner}/{repo}/commits](https://docs.github.com/en/rest/commits/commits#list-commits) | read |
[GET /repos/{owner}/{repo}/commits/{commit_sha}/branches-where-head](https://docs.github.com/en/rest/commits/commits#list-branches-for-head-commit) | read |
[POST /repos/{owner}/{repo}/commits/{commit_sha}/comments](https://docs.github.com/en/rest/commits/comments#create-a-commit-comment) | read |
[GET /repos/{owner}/{repo}/commits/{ref}](https://docs.github.com/en/rest/commits/commits#get-a-commit) | read |
[GET /repos/{owner}/{repo}/community/profile](https://docs.github.com/en/rest/metrics/community#get-community-profile-metrics) | read |
[GET /repos/{owner}/{repo}/compare/{basehead}](https://docs.github.com/en/rest/commits/commits#compare-two-commits) | read |
[GET /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#get-repository-content) | read |
[GET /repos/{owner}/{repo}/dependency-graph/compare/{basehead}](https://docs.github.com/en/rest/dependency-graph/dependency-review#get-a-diff-of-the-dependencies-between-commits) | read |
[GET /repos/{owner}/{repo}/dependency-graph/sbom](https://docs.github.com/en/rest/dependency-graph/sboms#export-a-software-bill-of-materials-sbom-for-a-repository) | read |
[POST /repos/{owner}/{repo}/forks](https://docs.github.com/en/rest/repos/forks#create-a-fork) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/forks#create-a-fork "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/git/blobs/{file_sha}](https://docs.github.com/en/rest/git/blobs#get-a-blob) | read |
[GET /repos/{owner}/{repo}/git/commits/{commit_sha}](https://docs.github.com/en/rest/git/commits#get-a-commit-object) | read |
[GET /repos/{owner}/{repo}/git/matching-refs/{ref}](https://docs.github.com/en/rest/git/refs#list-matching-references) | read |
[GET /repos/{owner}/{repo}/git/ref/{ref}](https://docs.github.com/en/rest/git/refs#get-a-reference) | read |
[GET /repos/{owner}/{repo}/git/tags/{tag_sha}](https://docs.github.com/en/rest/git/tags#get-a-tag) | read |
[GET /repos/{owner}/{repo}/git/trees/{tree_sha}](https://docs.github.com/en/rest/git/trees#get-a-tree) | read |
[GET /repos/{owner}/{repo}/import](https://docs.github.com/en/rest/migrations/source-imports#get-an-import-status) | read |
[GET /repos/{owner}/{repo}/import/authors](https://docs.github.com/en/rest/migrations/source-imports#get-commit-authors) | read |
[GET /repos/{owner}/{repo}/import/large_files](https://docs.github.com/en/rest/migrations/source-imports#get-large-files) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}](https://docs.github.com/en/rest/pulls/pulls#get-a-pull-request) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pulls/pulls#get-a-pull-request "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/readme](https://docs.github.com/en/rest/repos/contents#get-a-repository-readme) | read |
[GET /repos/{owner}/{repo}/readme/{dir}](https://docs.github.com/en/rest/repos/contents#get-a-repository-readme-for-a-directory) | read |
[GET /repos/{owner}/{repo}/releases](https://docs.github.com/en/rest/releases/releases#list-releases) | read |
[GET /repos/{owner}/{repo}/releases/assets/{asset_id}](https://docs.github.com/en/rest/releases/assets#get-a-release-asset) | read |
[GET /repos/{owner}/{repo}/releases/latest](https://docs.github.com/en/rest/releases/releases#get-the-latest-release) | read |
[GET /repos/{owner}/{repo}/releases/tags/{tag}](https://docs.github.com/en/rest/releases/releases#get-a-release-by-tag-name) | read |
[GET /repos/{owner}/{repo}/releases/{release_id}](https://docs.github.com/en/rest/releases/releases#get-a-release) | read |
[GET /repos/{owner}/{repo}/releases/{release_id}/assets](https://docs.github.com/en/rest/releases/assets#list-release-assets) | read |
[GET /repos/{owner}/{repo}/tarball/{ref}](https://docs.github.com/en/rest/repos/contents#download-a-repository-archive-tar) | read |
[GET /repos/{owner}/{repo}/zipball/{ref}](https://docs.github.com/en/rest/repos/contents#download-a-repository-archive-zip) | read |
[POST /repos/{template_owner}/{template_repo}/generate](https://docs.github.com/en/rest/repos/repos#create-a-repository-using-a-template) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/repos#create-a-repository-using-a-template "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Repository permissions for "Custom properties"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-custom-properties)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /repos/{owner}/{repo}/properties/values](https://docs.github.com/en/rest/repos/custom-properties#create-or-update-custom-property-values-for-a-repository) | write |
## [Repository permissions for "Dependabot alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-dependabot-alerts)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /repos/{owner}/{repo}/dependabot/alerts/{alert_number}](https://docs.github.com/en/rest/dependabot/alerts#update-a-dependabot-alert) | write |
[GET /orgs/{org}/dependabot/alerts](https://docs.github.com/en/rest/dependabot/alerts#list-dependabot-alerts-for-an-organization) | read |
[GET /repos/{owner}/{repo}/dependabot/alerts](https://docs.github.com/en/rest/dependabot/alerts#list-dependabot-alerts-for-a-repository) | read |
[GET /repos/{owner}/{repo}/dependabot/alerts/{alert_number}](https://docs.github.com/en/rest/dependabot/alerts#get-a-dependabot-alert) | read |
## [Repository permissions for "Dependabot secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-dependabot-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /repos/{owner}/{repo}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#create-or-update-a-repository-secret) | write |
[DELETE /repos/{owner}/{repo}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#delete-a-repository-secret) | write |
[GET /repos/{owner}/{repo}/dependabot/secrets](https://docs.github.com/en/rest/dependabot/secrets#list-repository-secrets) | read |
[GET /repos/{owner}/{repo}/dependabot/secrets/public-key](https://docs.github.com/en/rest/dependabot/secrets#get-a-repository-public-key) | read |
[GET /repos/{owner}/{repo}/dependabot/secrets/{secret_name}](https://docs.github.com/en/rest/dependabot/secrets#get-a-repository-secret) | read |
## [Repository permissions for "Deployments"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-deployments)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments](https://docs.github.com/en/rest/actions/workflow-runs#review-pending-deployments-for-a-workflow-run) | write |
[POST /repos/{owner}/{repo}/deployments](https://docs.github.com/en/rest/deployments/deployments#create-a-deployment) | write |
[DELETE /repos/{owner}/{repo}/deployments/{deployment_id}](https://docs.github.com/en/rest/deployments/deployments#delete-a-deployment) | write |
[POST /repos/{owner}/{repo}/deployments/{deployment_id}/statuses](https://docs.github.com/en/rest/deployments/statuses#create-a-deployment-status) | write |
[GET /repos/{owner}/{repo}/deployments](https://docs.github.com/en/rest/deployments/deployments#list-deployments) | read |
[GET /repos/{owner}/{repo}/deployments/{deployment_id}](https://docs.github.com/en/rest/deployments/deployments#get-a-deployment) | read |
[GET /repos/{owner}/{repo}/deployments/{deployment_id}/statuses](https://docs.github.com/en/rest/deployments/statuses#list-deployment-statuses) | read |
[GET /repos/{owner}/{repo}/deployments/{deployment_id}/statuses/{status_id}](https://docs.github.com/en/rest/deployments/statuses#get-a-deployment-status) | read |
## [Repository permissions for "Environments"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-environments)
Endpoint | Access | Additional permissions
---|---|---
[PUT /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#create-or-update-an-environment-secret) | write |
[DELETE /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#delete-an-environment-secret) | write |
[POST /repos/{owner}/{repo}/environments/{environment_name}/variables](https://docs.github.com/en/rest/actions/variables#create-an-environment-variable) | write |
[PATCH /repos/{owner}/{repo}/environments/{environment_name}/variables/{name}](https://docs.github.com/en/rest/actions/variables#update-an-environment-variable) | write |
[DELETE /repos/{owner}/{repo}/environments/{environment_name}/variables/{name}](https://docs.github.com/en/rest/actions/variables#delete-an-environment-variable) | write |
[GET /repos/{owner}/{repo}/environments/{environment_name}/secrets](https://docs.github.com/en/rest/actions/secrets#list-environment-secrets) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/secrets/public-key](https://docs.github.com/en/rest/actions/secrets#get-an-environment-public-key) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#get-an-environment-secret) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/variables](https://docs.github.com/en/rest/actions/variables#list-environment-variables) | read |
[GET /repos/{owner}/{repo}/environments/{environment_name}/variables/{name}](https://docs.github.com/en/rest/actions/variables#get-an-environment-variable) | read |
## [Repository permissions for "Issues"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-issues)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/issues](https://docs.github.com/en/rest/issues/issues#create-an-issue) | write |
[PATCH /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#update-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#update-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#delete-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#delete-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/issues/comments/{comment_id}/pin](https://docs.github.com/en/rest/issues/comments#pin-an-issue-comment) | write |
[DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}/pin](https://docs.github.com/en/rest/issues/comments#unpin-an-issue-comment) | write |
[POST /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#create-reaction-for-an-issue-comment) | write |
[DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions/{reaction_id}](https://docs.github.com/en/rest/reactions/reactions#delete-an-issue-comment-reaction) | write |
[PATCH /repos/{owner}/{repo}/issues/{issue_number}](https://docs.github.com/en/rest/issues/issues#update-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#update-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/assignees](https://docs.github.com/en/rest/issues/assignees#add-assignees-to-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#add-assignees-to-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/assignees](https://docs.github.com/en/rest/issues/assignees#remove-assignees-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#remove-assignees-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/comments](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by](https://docs.github.com/en/rest/issues/issue-dependencies#add-a-dependency-an-issue-is-blocked-by) | write |
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by/{issue_id}](https://docs.github.com/en/rest/issues/issue-dependencies#remove-dependency-an-issue-is-blocked-by) | write |
[POST /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#add-labels-to-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#add-labels-to-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#set-labels-for-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#set-labels-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#remove-all-labels-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#remove-all-labels-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels/{name}](https://docs.github.com/en/rest/issues/labels#remove-a-label-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#remove-a-label-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/issues/{issue_number}/lock](https://docs.github.com/en/rest/issues/issues#lock-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#lock-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/lock](https://docs.github.com/en/rest/issues/issues#unlock-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#unlock-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/reactions](https://docs.github.com/en/rest/reactions/reactions#create-reaction-for-an-issue) | write |
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/reactions/{reaction_id}](https://docs.github.com/en/rest/reactions/reactions#delete-an-issue-reaction) | write |
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/sub_issue](https://docs.github.com/en/rest/issues/sub-issues#remove-sub-issue) | write |
[POST /repos/{owner}/{repo}/issues/{issue_number}/sub_issues](https://docs.github.com/en/rest/issues/sub-issues#add-sub-issue) | write |
[PATCH /repos/{owner}/{repo}/issues/{issue_number}/sub_issues/priority](https://docs.github.com/en/rest/issues/sub-issues#reprioritize-sub-issue) | write |
[POST /repos/{owner}/{repo}/labels](https://docs.github.com/en/rest/issues/labels#create-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#create-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#update-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#update-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#delete-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#delete-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/milestones](https://docs.github.com/en/rest/issues/milestones#create-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#create-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#update-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#update-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#delete-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#delete-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/assignees](https://docs.github.com/en/rest/issues/assignees#list-assignees) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#list-assignees "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/assignees/{assignee}](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues](https://docs.github.com/en/rest/issues/issues#list-repository-issues) | read |
[GET /repos/{owner}/{repo}/issues/comments](https://docs.github.com/en/rest/issues/comments#list-issue-comments-for-a-repository) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#list-issue-comments-for-a-repository "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#get-an-issue-comment) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#get-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#list-reactions-for-an-issue-comment) | read |
[GET /repos/{owner}/{repo}/issues/events](https://docs.github.com/en/rest/issues/events#list-issue-events-for-a-repository) | read |
[GET /repos/{owner}/{repo}/issues/events/{event_id}](https://docs.github.com/en/rest/issues/events#get-an-issue-event) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/events#get-an-issue-event "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}](https://docs.github.com/en/rest/issues/issues#get-an-issue) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/assignees/{assignee}](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned-to-a-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned-to-a-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/comments](https://docs.github.com/en/rest/issues/comments#list-issue-comments) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#list-issue-comments "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by](https://docs.github.com/en/rest/issues/issue-dependencies#list-dependencies-an-issue-is-blocked-by) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocking](https://docs.github.com/en/rest/issues/issue-dependencies#list-dependencies-an-issue-is-blocking) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/events](https://docs.github.com/en/rest/issues/events#list-issue-events) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/events#list-issue-events "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-an-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/parent](https://docs.github.com/en/rest/issues/sub-issues#get-parent-issue) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/reactions](https://docs.github.com/en/rest/reactions/reactions#list-reactions-for-an-issue) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/sub_issues](https://docs.github.com/en/rest/issues/sub-issues#list-sub-issues) | read |
[GET /repos/{owner}/{repo}/issues/{issue_number}/timeline](https://docs.github.com/en/rest/issues/timeline#list-timeline-events-for-an-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/timeline#list-timeline-events-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-a-repository) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-a-repository "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#get-a-label) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#get-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones](https://docs.github.com/en/rest/issues/milestones#list-milestones) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#list-milestones "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#get-a-milestone) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#get-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones/{milestone_number}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-issues-in-a-milestone) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-issues-in-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Repository permissions for "Metadata"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-metadata)
Endpoint | Access | Additional permissions
---|---|---
[GET /orgs/{org}/repos](https://docs.github.com/en/rest/repos/repos#list-organization-repositories) | read |
[GET /repos/{owner}/{repo}](https://docs.github.com/en/rest/repos/repos#get-a-repository) | read |
[GET /repos/{owner}/{repo}/collaborators](https://docs.github.com/en/rest/collaborators/collaborators#list-repository-collaborators) | read |
[GET /repos/{owner}/{repo}/collaborators/{username}](https://docs.github.com/en/rest/collaborators/collaborators#check-if-a-user-is-a-repository-collaborator) | read |
[GET /repos/{owner}/{repo}/collaborators/{username}/permission](https://docs.github.com/en/rest/collaborators/collaborators#get-repository-permissions-for-a-user) | read |
[GET /repos/{owner}/{repo}/comments](https://docs.github.com/en/rest/commits/comments#list-commit-comments-for-a-repository) | read |
[GET /repos/{owner}/{repo}/comments/{comment_id}](https://docs.github.com/en/rest/commits/comments#get-a-commit-comment) | read |
[GET /repos/{owner}/{repo}/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#list-reactions-for-a-commit-comment) | read |
[GET /repos/{owner}/{repo}/commits/{commit_sha}/comments](https://docs.github.com/en/rest/commits/comments#list-commit-comments) | read |
[GET /repos/{owner}/{repo}/contributors](https://docs.github.com/en/rest/repos/repos#list-repository-contributors) | read |
[GET /repos/{owner}/{repo}/events](https://docs.github.com/en/rest/activity/events#list-repository-events) | read |
[GET /repos/{owner}/{repo}/forks](https://docs.github.com/en/rest/repos/forks#list-forks) | read |
[GET /repos/{owner}/{repo}/languages](https://docs.github.com/en/rest/repos/repos#list-repository-languages) | read |
[GET /repos/{owner}/{repo}/license](https://docs.github.com/en/rest/licenses/licenses#get-the-license-for-a-repository) | read |
[GET /repos/{owner}/{repo}/private-vulnerability-reporting](https://docs.github.com/en/rest/repos/repos#check-if-private-vulnerability-reporting-is-enabled-for-a-repository) | read |
[GET /repos/{owner}/{repo}/properties/values](https://docs.github.com/en/rest/repos/custom-properties#get-all-custom-property-values-for-a-repository) | read |
[GET /repos/{owner}/{repo}/rules/branches/{branch}](https://docs.github.com/en/rest/repos/rules#get-rules-for-a-branch) | read |
[GET /repos/{owner}/{repo}/rulesets](https://docs.github.com/en/rest/repos/rules#get-all-repository-rulesets) | read |
[GET /repos/{owner}/{repo}/rulesets/{ruleset_id}](https://docs.github.com/en/rest/repos/rules#get-a-repository-ruleset) | read |
[GET /repos/{owner}/{repo}/stargazers](https://docs.github.com/en/rest/activity/starring#list-stargazers) | read |
[GET /repos/{owner}/{repo}/stats/code_frequency](https://docs.github.com/en/rest/metrics/statistics#get-the-weekly-commit-activity) | read |
[GET /repos/{owner}/{repo}/stats/commit_activity](https://docs.github.com/en/rest/metrics/statistics#get-the-last-year-of-commit-activity) | read |
[GET /repos/{owner}/{repo}/stats/contributors](https://docs.github.com/en/rest/metrics/statistics#get-all-contributor-commit-activity) | read |
[GET /repos/{owner}/{repo}/stats/participation](https://docs.github.com/en/rest/metrics/statistics#get-the-weekly-commit-count) | read |
[GET /repos/{owner}/{repo}/stats/punch_card](https://docs.github.com/en/rest/metrics/statistics#get-the-hourly-commit-count-for-each-day) | read |
[GET /repos/{owner}/{repo}/subscribers](https://docs.github.com/en/rest/activity/watching#list-watchers) | read |
[GET /repos/{owner}/{repo}/tags](https://docs.github.com/en/rest/repos/repos#list-repository-tags) | read |
[GET /repos/{owner}/{repo}/topics](https://docs.github.com/en/rest/repos/repos#get-all-repository-topics) | read |
[GET /repositories](https://docs.github.com/en/rest/repos/repos#list-public-repositories) | read |
[GET /search/labels](https://docs.github.com/en/rest/search/search#search-labels) | read |
[GET /user/repos](https://docs.github.com/en/rest/repos/repos#list-repositories-for-the-authenticated-user) | read |
[GET /users/{username}/repos](https://docs.github.com/en/rest/repos/repos#list-repositories-for-a-user) | read |
## [Repository permissions for "Pages"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-pages)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#update-information-about-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#update-information-about-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#delete-a-github-pages-site) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#delete-a-github-pages-site "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/pages/builds](https://docs.github.com/en/rest/pages/pages#request-a-github-pages-build) | write |
[POST /repos/{owner}/{repo}/pages/deployments](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-deployment) | write |
[POST /repos/{owner}/{repo}/pages/deployments/{pages_deployment_id}/cancel](https://docs.github.com/en/rest/pages/pages#cancel-a-github-pages-deployment) | write |
[GET /repos/{owner}/{repo}/pages/health](https://docs.github.com/en/rest/pages/pages#get-a-dns-health-check-for-github-pages) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pages/pages#get-a-dns-health-check-for-github-pages "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/pages](https://docs.github.com/en/rest/pages/pages#get-a-github-pages-site) | read |
[GET /repos/{owner}/{repo}/pages/builds](https://docs.github.com/en/rest/pages/pages#list-github-pages-builds) | read |
[GET /repos/{owner}/{repo}/pages/builds/latest](https://docs.github.com/en/rest/pages/pages#get-latest-pages-build) | read |
[GET /repos/{owner}/{repo}/pages/builds/{build_id}](https://docs.github.com/en/rest/pages/pages#get-github-pages-build) | read |
[GET /repos/{owner}/{repo}/pages/deployments/{pages_deployment_id}](https://docs.github.com/en/rest/pages/pages#get-the-status-of-a-github-pages-deployment) | read |
## [Repository permissions for "Pull requests"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-pull-requests)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#update-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#update-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#delete-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#delete-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/issues/{issue_number}](https://docs.github.com/en/rest/issues/issues#update-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#update-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/assignees](https://docs.github.com/en/rest/issues/assignees#add-assignees-to-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#add-assignees-to-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/assignees](https://docs.github.com/en/rest/issues/assignees#remove-assignees-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#remove-assignees-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/comments](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#add-labels-to-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#add-labels-to-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#set-labels-for-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#set-labels-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#remove-all-labels-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#remove-all-labels-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels/{name}](https://docs.github.com/en/rest/issues/labels#remove-a-label-from-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#remove-a-label-from-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PUT /repos/{owner}/{repo}/issues/{issue_number}/lock](https://docs.github.com/en/rest/issues/issues#lock-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#lock-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/issues/{issue_number}/lock](https://docs.github.com/en/rest/issues/issues#unlock-an-issue) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/issues#unlock-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/labels](https://docs.github.com/en/rest/issues/labels#create-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#create-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#update-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#update-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#delete-a-label) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#delete-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/milestones](https://docs.github.com/en/rest/issues/milestones#create-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#create-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#update-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#update-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#delete-a-milestone) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#delete-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/pulls](https://docs.github.com/en/rest/pulls/pulls#create-a-pull-request) | write |
[PATCH /repos/{owner}/{repo}/pulls/comments/{comment_id}](https://docs.github.com/en/rest/pulls/comments#update-a-review-comment-for-a-pull-request) | write |
[DELETE /repos/{owner}/{repo}/pulls/comments/{comment_id}](https://docs.github.com/en/rest/pulls/comments#delete-a-review-comment-for-a-pull-request) | write |
[POST /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#create-reaction-for-a-pull-request-review-comment) | write |
[DELETE /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions/{reaction_id}](https://docs.github.com/en/rest/reactions/reactions#delete-a-pull-request-comment-reaction) | write |
[PATCH /repos/{owner}/{repo}/pulls/{pull_number}](https://docs.github.com/en/rest/pulls/pulls#update-a-pull-request) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/comments](https://docs.github.com/en/rest/pulls/comments#create-a-review-comment-for-a-pull-request) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/comments/{comment_id}/replies](https://docs.github.com/en/rest/pulls/comments#create-a-reply-for-a-review-comment) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers](https://docs.github.com/en/rest/pulls/review-requests#request-reviewers-for-a-pull-request) | write |
[DELETE /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers](https://docs.github.com/en/rest/pulls/review-requests#remove-requested-reviewers-from-a-pull-request) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews](https://docs.github.com/en/rest/pulls/reviews#create-a-review-for-a-pull-request) | write |
[PUT /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}](https://docs.github.com/en/rest/pulls/reviews#update-a-review-for-a-pull-request) | write |
[DELETE /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}](https://docs.github.com/en/rest/pulls/reviews#delete-a-pending-review-for-a-pull-request) | write |
[PUT /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/dismissals](https://docs.github.com/en/rest/pulls/reviews#dismiss-a-review-for-a-pull-request) | write |
[POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/events](https://docs.github.com/en/rest/pulls/reviews#submit-a-review-for-a-pull-request) | write |
[PUT /repos/{owner}/{repo}/pulls/{pull_number}/update-branch](https://docs.github.com/en/rest/pulls/pulls#update-a-pull-request-branch) | write |
[GET /repos/{owner}/{repo}/assignees](https://docs.github.com/en/rest/issues/assignees#list-assignees) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#list-assignees "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/assignees/{assignee}](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/commits/{commit_sha}/pulls](https://docs.github.com/en/rest/commits/commits#list-pull-requests-associated-with-a-commit) | read |
[GET /repos/{owner}/{repo}/issues/comments](https://docs.github.com/en/rest/issues/comments#list-issue-comments-for-a-repository) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#list-issue-comments-for-a-repository "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/comments/{comment_id}](https://docs.github.com/en/rest/issues/comments#get-an-issue-comment) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#get-an-issue-comment "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/events/{event_id}](https://docs.github.com/en/rest/issues/events#get-an-issue-event) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/events#get-an-issue-event "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/assignees/{assignee}](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned-to-a-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned-to-a-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/comments](https://docs.github.com/en/rest/issues/comments#list-issue-comments) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/comments#list-issue-comments "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/events](https://docs.github.com/en/rest/issues/events#list-issue-events) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/events#list-issue-events "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-an-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/issues/{issue_number}/timeline](https://docs.github.com/en/rest/issues/timeline#list-timeline-events-for-an-issue) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/timeline#list-timeline-events-for-an-issue "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-a-repository) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-a-repository "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/labels/{name}](https://docs.github.com/en/rest/issues/labels#get-a-label) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#get-a-label "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones](https://docs.github.com/en/rest/issues/milestones#list-milestones) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#list-milestones "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones/{milestone_number}](https://docs.github.com/en/rest/issues/milestones#get-a-milestone) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/milestones#get-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/milestones/{milestone_number}/labels](https://docs.github.com/en/rest/issues/labels#list-labels-for-issues-in-a-milestone) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/issues/labels#list-labels-for-issues-in-a-milestone "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/pulls](https://docs.github.com/en/rest/pulls/pulls#list-pull-requests) | read |
[GET /repos/{owner}/{repo}/pulls/comments](https://docs.github.com/en/rest/pulls/comments#list-review-comments-in-a-repository) | read |
[GET /repos/{owner}/{repo}/pulls/comments/{comment_id}](https://docs.github.com/en/rest/pulls/comments#get-a-review-comment-for-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions](https://docs.github.com/en/rest/reactions/reactions#list-reactions-for-a-pull-request-review-comment) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}](https://docs.github.com/en/rest/pulls/pulls#get-a-pull-request) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/pulls/pulls#get-a-pull-request "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /repos/{owner}/{repo}/pulls/{pull_number}/comments](https://docs.github.com/en/rest/pulls/comments#list-review-comments-on-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/commits](https://docs.github.com/en/rest/pulls/pulls#list-commits-on-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/files](https://docs.github.com/en/rest/pulls/pulls#list-pull-requests-files) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/merge](https://docs.github.com/en/rest/pulls/pulls#check-if-a-pull-request-has-been-merged) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers](https://docs.github.com/en/rest/pulls/review-requests#get-all-requested-reviewers-for-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews](https://docs.github.com/en/rest/pulls/reviews#list-reviews-for-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}](https://docs.github.com/en/rest/pulls/reviews#get-a-review-for-a-pull-request) | read |
[GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/comments](https://docs.github.com/en/rest/pulls/reviews#list-comments-for-a-pull-request-review) | read |
## [Repository permissions for "Repository security advisories"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-repository-security-advisories)
Endpoint | Access | Additional permissions
---|---|---
[GET /orgs/{org}/security-advisories](https://docs.github.com/en/rest/security-advisories/repository-advisories#list-repository-security-advisories-for-an-organization) | write |
[POST /repos/{owner}/{repo}/security-advisories](https://docs.github.com/en/rest/security-advisories/repository-advisories#create-a-repository-security-advisory) | write |
[POST /repos/{owner}/{repo}/security-advisories/reports](https://docs.github.com/en/rest/security-advisories/repository-advisories#privately-report-a-security-vulnerability) | write |
[PATCH /repos/{owner}/{repo}/security-advisories/{ghsa_id}](https://docs.github.com/en/rest/security-advisories/repository-advisories#update-a-repository-security-advisory) | write |
[POST /repos/{owner}/{repo}/security-advisories/{ghsa_id}/cve](https://docs.github.com/en/rest/security-advisories/repository-advisories#request-a-cve-for-a-repository-security-advisory) | write |
[GET /repos/{owner}/{repo}/security-advisories](https://docs.github.com/en/rest/security-advisories/repository-advisories#list-repository-security-advisories) | read |
[GET /repos/{owner}/{repo}/security-advisories/{ghsa_id}](https://docs.github.com/en/rest/security-advisories/repository-advisories#get-a-repository-security-advisory) | read |
[POST /repos/{owner}/{repo}/security-advisories/{ghsa_id}/forks](https://docs.github.com/en/rest/security-advisories/repository-advisories#create-a-temporary-private-fork) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/security-advisories/repository-advisories#create-a-temporary-private-fork "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [Repository permissions for "Secret scanning alerts"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-secret-scanning-alerts)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number}](https://docs.github.com/en/rest/secret-scanning/secret-scanning#update-a-secret-scanning-alert) | write |
[GET /orgs/{org}/secret-scanning/alerts](https://docs.github.com/en/rest/secret-scanning/secret-scanning#list-secret-scanning-alerts-for-an-organization) | read |
[GET /repos/{owner}/{repo}/secret-scanning/alerts](https://docs.github.com/en/rest/secret-scanning/secret-scanning#list-secret-scanning-alerts-for-a-repository) | read |
[GET /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number}](https://docs.github.com/en/rest/secret-scanning/secret-scanning#get-a-secret-scanning-alert) | read |
[GET /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number}/locations](https://docs.github.com/en/rest/secret-scanning/secret-scanning#list-locations-for-a-secret-scanning-alert) | read |
[GET /repos/{owner}/{repo}/secret-scanning/scan-history](https://docs.github.com/en/rest/secret-scanning/secret-scanning#get-secret-scanning-scan-history-for-a-repository) | read |
## [Repository permissions for "Secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /repos/{owner}/{repo}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#create-or-update-a-repository-secret) | write |
[DELETE /repos/{owner}/{repo}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#delete-a-repository-secret) | write |
[GET /repos/{owner}/{repo}/actions/organization-secrets](https://docs.github.com/en/rest/actions/secrets#list-repository-organization-secrets) | read |
[GET /repos/{owner}/{repo}/actions/secrets](https://docs.github.com/en/rest/actions/secrets#list-repository-secrets) | read |
[GET /repos/{owner}/{repo}/actions/secrets/public-key](https://docs.github.com/en/rest/actions/secrets#get-a-repository-public-key) | read |
[GET /repos/{owner}/{repo}/actions/secrets/{secret_name}](https://docs.github.com/en/rest/actions/secrets#get-a-repository-secret) | read |
## [Repository permissions for "Variables"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-variables)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/actions/variables](https://docs.github.com/en/rest/actions/variables#create-a-repository-variable) | write |
[PATCH /repos/{owner}/{repo}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#update-a-repository-variable) | write |
[DELETE /repos/{owner}/{repo}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#delete-a-repository-variable) | write |
[GET /repos/{owner}/{repo}/actions/organization-variables](https://docs.github.com/en/rest/actions/variables#list-repository-organization-variables) | read |
[GET /repos/{owner}/{repo}/actions/variables](https://docs.github.com/en/rest/actions/variables#list-repository-variables) | read |
[GET /repos/{owner}/{repo}/actions/variables/{name}](https://docs.github.com/en/rest/actions/variables#get-a-repository-variable) | read |
## [Repository permissions for "Webhooks"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-webhooks)
Endpoint | Access | Additional permissions
---|---|---
[POST /repos/{owner}/{repo}/hooks](https://docs.github.com/en/rest/repos/webhooks#create-a-repository-webhook) | write |
[PATCH /repos/{owner}/{repo}/hooks/{hook_id}](https://docs.github.com/en/rest/repos/webhooks#update-a-repository-webhook) | write |
[DELETE /repos/{owner}/{repo}/hooks/{hook_id}](https://docs.github.com/en/rest/repos/webhooks#delete-a-repository-webhook) | write |
[PATCH /repos/{owner}/{repo}/hooks/{hook_id}/config](https://docs.github.com/en/rest/repos/webhooks#update-a-webhook-configuration-for-a-repository) | write |
[POST /repos/{owner}/{repo}/hooks/{hook_id}/deliveries/{delivery_id}/attempts](https://docs.github.com/en/rest/repos/webhooks#redeliver-a-delivery-for-a-repository-webhook) | write |
[GET /repos/{owner}/{repo}/hooks](https://docs.github.com/en/rest/repos/webhooks#list-repository-webhooks) | read |
[GET /repos/{owner}/{repo}/hooks/{hook_id}](https://docs.github.com/en/rest/repos/webhooks#get-a-repository-webhook) | read |
[GET /repos/{owner}/{repo}/hooks/{hook_id}/config](https://docs.github.com/en/rest/repos/webhooks#get-a-webhook-configuration-for-a-repository) | read |
[GET /repos/{owner}/{repo}/hooks/{hook_id}/deliveries](https://docs.github.com/en/rest/repos/webhooks#list-deliveries-for-a-repository-webhook) | read |
[GET /repos/{owner}/{repo}/hooks/{hook_id}/deliveries/{delivery_id}](https://docs.github.com/en/rest/repos/webhooks#get-a-delivery-for-a-repository-webhook) | read |
[POST /repos/{owner}/{repo}/hooks/{hook_id}/pings](https://docs.github.com/en/rest/repos/webhooks#ping-a-repository-webhook) | read |
[POST /repos/{owner}/{repo}/hooks/{hook_id}/tests](https://docs.github.com/en/rest/repos/webhooks#test-the-push-repository-webhook) | read |
## [Repository permissions for "Workflows"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#repository-permissions-for-workflows)
Endpoint | Access | Additional permissions
---|---|---
[PUT /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /repos/{owner}/{repo}/contents/{path}](https://docs.github.com/en/rest/repos/contents#delete-a-file) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/repos/contents#delete-a-file "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/git/refs](https://docs.github.com/en/rest/git/refs#create-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#create-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[PATCH /repos/{owner}/{repo}/git/refs/{ref}](https://docs.github.com/en/rest/git/refs#update-a-reference) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/git/refs#update-a-reference "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[POST /repos/{owner}/{repo}/releases](https://docs.github.com/en/rest/releases/releases#create-a-release) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/releases/releases#create-a-release "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [User permissions for "Block another user"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-block-another-user)
Endpoint | Access | Additional permissions
---|---|---
[PUT /user/blocks/{username}](https://docs.github.com/en/rest/users/blocking#block-a-user) | write |
[DELETE /user/blocks/{username}](https://docs.github.com/en/rest/users/blocking#unblock-a-user) | write |
[GET /user/blocks](https://docs.github.com/en/rest/users/blocking#list-users-blocked-by-the-authenticated-user) | read |
[GET /user/blocks/{username}](https://docs.github.com/en/rest/users/blocking#check-if-a-user-is-blocked-by-the-authenticated-user) | read |
## [User permissions for "Codespaces user secrets"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-codespaces-user-secrets)
Endpoint | Access | Additional permissions
---|---|---
[PUT /user/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/secrets#create-or-update-a-secret-for-the-authenticated-user) | write |
[DELETE /user/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/secrets#delete-a-secret-for-the-authenticated-user) | write |
[PUT /user/codespaces/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/codespaces/secrets#set-selected-repositories-for-a-user-secret) | write |
[PUT /user/codespaces/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/codespaces/secrets#add-a-selected-repository-to-a-user-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/secrets#add-a-selected-repository-to-a-user-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /user/codespaces/secrets/{secret_name}/repositories/{repository_id}](https://docs.github.com/en/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /user/codespaces/secrets](https://docs.github.com/en/rest/codespaces/secrets#list-secrets-for-the-authenticated-user) | read |
[GET /user/codespaces/secrets/public-key](https://docs.github.com/en/rest/codespaces/secrets#get-public-key-for-the-authenticated-user) | read |
[GET /user/codespaces/secrets/{secret_name}](https://docs.github.com/en/rest/codespaces/secrets#get-a-secret-for-the-authenticated-user) | read |
[GET /user/codespaces/secrets/{secret_name}/repositories](https://docs.github.com/en/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret) | read |
## [User permissions for "Email addresses"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-email-addresses)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /user/email/visibility](https://docs.github.com/en/rest/users/emails#set-primary-email-visibility-for-the-authenticated-user) | write |
[POST /user/emails](https://docs.github.com/en/rest/users/emails#add-an-email-address-for-the-authenticated-user) | write |
[DELETE /user/emails](https://docs.github.com/en/rest/users/emails#delete-an-email-address-for-the-authenticated-user) | write |
[GET /user/emails](https://docs.github.com/en/rest/users/emails#list-email-addresses-for-the-authenticated-user) | read |
[GET /user/public_emails](https://docs.github.com/en/rest/users/emails#list-public-email-addresses-for-the-authenticated-user) | read |
## [User permissions for "Followers"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-followers)
Endpoint | Access | Additional permissions
---|---|---
[PUT /user/following/{username}](https://docs.github.com/en/rest/users/followers#follow-a-user) | write |
[DELETE /user/following/{username}](https://docs.github.com/en/rest/users/followers#unfollow-a-user) | write |
[GET /user/followers](https://docs.github.com/en/rest/users/followers#list-followers-of-the-authenticated-user) | read |
[GET /user/following](https://docs.github.com/en/rest/users/followers#list-the-people-the-authenticated-user-follows) | read |
[GET /user/following/{username}](https://docs.github.com/en/rest/users/followers#check-if-a-person-is-followed-by-the-authenticated-user) | read |
## [User permissions for "GPG keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-gpg-keys)
Endpoint | Access | Additional permissions
---|---|---
[POST /user/gpg_keys](https://docs.github.com/en/rest/users/gpg-keys#create-a-gpg-key-for-the-authenticated-user) | write |
[DELETE /user/gpg_keys/{gpg_key_id}](https://docs.github.com/en/rest/users/gpg-keys#delete-a-gpg-key-for-the-authenticated-user) | write |
[GET /user/gpg_keys](https://docs.github.com/en/rest/users/gpg-keys#list-gpg-keys-for-the-authenticated-user) | read |
[GET /user/gpg_keys/{gpg_key_id}](https://docs.github.com/en/rest/users/gpg-keys#get-a-gpg-key-for-the-authenticated-user) | read |
## [User permissions for "Gists"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-gists)
Endpoint | Access | Additional permissions
---|---|---
[POST /gists](https://docs.github.com/en/rest/gists/gists#create-a-gist) | write |
[PATCH /gists/{gist_id}](https://docs.github.com/en/rest/gists/gists#update-a-gist) | write |
[DELETE /gists/{gist_id}](https://docs.github.com/en/rest/gists/gists#delete-a-gist) | write |
[POST /gists/{gist_id}/comments](https://docs.github.com/en/rest/gists/comments#create-a-gist-comment) | write |
[PATCH /gists/{gist_id}/comments/{comment_id}](https://docs.github.com/en/rest/gists/comments#update-a-gist-comment) | write |
[DELETE /gists/{gist_id}/comments/{comment_id}](https://docs.github.com/en/rest/gists/comments#delete-a-gist-comment) | write |
[POST /gists/{gist_id}/forks](https://docs.github.com/en/rest/gists/gists#fork-a-gist) | write |
[PUT /gists/{gist_id}/star](https://docs.github.com/en/rest/gists/gists#star-a-gist) | write |
[DELETE /gists/{gist_id}/star](https://docs.github.com/en/rest/gists/gists#unstar-a-gist) | write |
## [User permissions for "Git SSH keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-git-ssh-keys)
Endpoint | Access | Additional permissions
---|---|---
[POST /user/keys](https://docs.github.com/en/rest/users/keys#create-a-public-ssh-key-for-the-authenticated-user) | write |
[DELETE /user/keys/{key_id}](https://docs.github.com/en/rest/users/keys#delete-a-public-ssh-key-for-the-authenticated-user) | write |
[GET /user/keys](https://docs.github.com/en/rest/users/keys#list-public-ssh-keys-for-the-authenticated-user) | read |
[GET /user/keys/{key_id}](https://docs.github.com/en/rest/users/keys#get-a-public-ssh-key-for-the-authenticated-user) | read |
[GET /users/{username}/keys](https://docs.github.com/en/rest/users/keys#list-public-keys-for-a-user) | read |
## [User permissions for "Interaction limits"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-interaction-limits)
Endpoint | Access | Additional permissions
---|---|---
[PUT /user/interaction-limits](https://docs.github.com/en/rest/interactions/user#set-interaction-restrictions-for-your-public-repositories) | write |
[DELETE /user/interaction-limits](https://docs.github.com/en/rest/interactions/user#remove-interaction-restrictions-from-your-public-repositories) | write |
[GET /user/interaction-limits](https://docs.github.com/en/rest/interactions/user#get-interaction-restrictions-for-your-public-repositories) | read |
## [User permissions for "Plan"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-plan)
Endpoint | Access | Additional permissions
---|---|---
[GET /users/{username}/settings/billing/premium_request/usage](https://docs.github.com/en/rest/billing/usage#get-billing-premium-request-usage-report-for-a-user) | read |
[GET /users/{username}/settings/billing/usage](https://docs.github.com/en/rest/billing/usage#get-billing-usage-report-for-a-user) | read |
[GET /users/{username}/settings/billing/usage/summary](https://docs.github.com/en/rest/billing/usage#get-billing-usage-summary-for-a-user) | read |
## [User permissions for "Private repository invitations"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-private-repository-invitations)
Endpoint | Access | Additional permissions
---|---|---
[GET /repos/{owner}/{repo}/invitations](https://docs.github.com/en/rest/collaborators/invitations#list-repository-invitations) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/collaborators/invitations#list-repository-invitations "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
## [User permissions for "Profile"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-profile)
Endpoint | Access | Additional permissions
---|---|---
[PATCH /user](https://docs.github.com/en/rest/users/users#update-the-authenticated-user) | write |
[POST /user/social_accounts](https://docs.github.com/en/rest/users/social-accounts#add-social-accounts-for-the-authenticated-user) | write |
[DELETE /user/social_accounts](https://docs.github.com/en/rest/users/social-accounts#delete-social-accounts-for-the-authenticated-user) | write |
## [User permissions for "SSH signing keys"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-ssh-signing-keys)
Endpoint | Access | Additional permissions
---|---|---
[POST /user/ssh_signing_keys](https://docs.github.com/en/rest/users/ssh-signing-keys#create-a-ssh-signing-key-for-the-authenticated-user) | write |
[DELETE /user/ssh_signing_keys/{ssh_signing_key_id}](https://docs.github.com/en/rest/users/ssh-signing-keys#delete-an-ssh-signing-key-for-the-authenticated-user) | write |
[GET /user/ssh_signing_keys](https://docs.github.com/en/rest/users/ssh-signing-keys#list-ssh-signing-keys-for-the-authenticated-user) | read |
[GET /user/ssh_signing_keys/{ssh_signing_key_id}](https://docs.github.com/en/rest/users/ssh-signing-keys#get-an-ssh-signing-key-for-the-authenticated-user) | read |
## [User permissions for "Starring"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-starring)
Endpoint | Access | Additional permissions
---|---|---
[PUT /user/starred/{owner}/{repo}](https://docs.github.com/en/rest/activity/starring#star-a-repository-for-the-authenticated-user) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/activity/starring#star-a-repository-for-the-authenticated-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[DELETE /user/starred/{owner}/{repo}](https://docs.github.com/en/rest/activity/starring#unstar-a-repository-for-the-authenticated-user) | write | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/activity/starring#unstar-a-repository-for-the-authenticated-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /user/starred](https://docs.github.com/en/rest/activity/starring#list-repositories-starred-by-the-authenticated-user) | read |
[GET /user/starred/{owner}/{repo}](https://docs.github.com/en/rest/activity/starring#check-if-a-repository-is-starred-by-the-authenticated-user) | read | [Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.](https://docs.github.com/en/rest/activity/starring#check-if-a-repository-is-starred-by-the-authenticated-user "Multiple permissions are required, or a different permission may be used. For more information about the permissions, see the documentation for this endpoint.")
[GET /users/{username}/starred](https://docs.github.com/en/rest/activity/starring#list-repositories-starred-by-a-user) | read |
## [User permissions for "Watching"](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens?apiVersion=2022-11-28#user-permissions-for-watching)
Endpoint | Access | Additional permissions
---|---|---
[GET /user/subscriptions](https://docs.github.com/en/rest/activity/watching#list-repositories-watched-by-the-authenticated-user) | read |
[GET /users/{username}/subscriptions](https://docs.github.com/en/rest/activity/watching#list-repositories-watched-by-a-user) | read |
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


Permissions required for fine-grained personal access tokens - GitHub Docs
