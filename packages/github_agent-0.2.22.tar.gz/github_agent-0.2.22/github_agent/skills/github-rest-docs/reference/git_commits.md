[Skip to main content](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Git database](https://docs.github.com/en/rest/git "Git database")/
  * [Commits](https://docs.github.com/en/rest/git/commits "Commits")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
      * [About Git commits](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#about-git-commits)
      * [Create a commit](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit)
      * [Get a commit object](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object)
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Git database](https://docs.github.com/en/rest/git "Git database")/
  * [Commits](https://docs.github.com/en/rest/git/commits "Commits")


# REST API endpoints for Git commits
Use the REST API to interact with commit objects in your Git database on GitHub.
## [About Git commits](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#about-git-commits)
A Git commit is a snapshot of the hierarchy ([Git tree](https://docs.github.com/en/rest/git/trees)) and the contents of the files ([Git blob](https://docs.github.com/en/rest/git/blobs)) in a Git repository. These endpoints allow you to read and write [commit objects](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects#_git_commit_objects) to your Git database on GitHub.
## [Create a commit](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit)
Creates a new Git [commit object](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects).
**Signature verification object**
The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object:
Name | Type | Description
---|---|---
`verified` | `boolean` | Indicates whether GitHub considers the signature in this commit to be verified.
`reason` | `string` | The reason for verified value. Possible values and their meanings are enumerated in the table below.
`signature` | `string` | The signature that was extracted from the commit.
`payload` | `string` | The value that was signed.
`verified_at` | `string` | The date the signature was verified by GitHub.
These are the possible values for `reason` in the `verification` object:
Value | Description
---|---
`expired_key` | The key that made the signature is expired.
`not_signing_key` | The "signing" flag is not among the usage flags in the GPG key that made the signature.
`gpgverify_error` | There was an error communicating with the signature verification service.
`gpgverify_unavailable` | The signature verification service is currently unavailable.
`unsigned` | The object does not include a signature.
`unknown_signature_type` | A non-PGP signature was found in the commit.
`no_user` | No user was associated with the `committer` email address in the commit.
`unverified_email` | The `committer` email address in the commit was associated with a user, but the email address is not verified on their account.
`bad_email` | The `committer` email address in the commit is not included in the identities of the PGP key that made the signature.
`unknown_key` | The key that made the signature has not been registered with any user's account.
`malformed_signature` | There was an error parsing the signature.
`invalid` | The signature could not be cryptographically verified using the key whose key-id was found in the signature.
`valid` | None of the above errors applied, so the signature is considered to be verified.
### [Fine-grained access tokens for "Create a commit"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Create a commit"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`message` string Required The commit message
`tree` string Required The SHA of the tree object this commit points to
`parents` array of strings The full SHAs of the commits that were the parents of this commit. If omitted or empty, the commit will be written as a root commit. For a single parent, an array of one SHA should be provided; for a merge commit, an array of more than one should be provided.
`author` object Information about the author of the commit. By default, the `author` will be the authenticated user and the current date. See the `author` and `committer` object below for details.
Properties of `author` | Name, Type, Description
---
`name` string Required The name of the author (or committer) of the commit
`email` string Required The email of the author (or committer) of the commit
`date` string Indicates when this commit was authored (or committed). This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`committer` object Information about the person who is making the commit. By default, `committer` will use the information set in `author`. See the `author` and `committer` object below for details.
Properties of `committer` | Name, Type, Description
---
`name` string The name of the author (or committer) of the commit
`email` string The email of the author (or committer) of the commit
`date` string Indicates when this commit was authored (or committed). This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`signature` string The [PGP signature](https://en.wikipedia.org/wiki/Pretty_Good_Privacy) of the commit. GitHub adds the signature to the `gpgsig` header of the created commit. For a commit signature to be verifiable by Git or GitHub, it must be an ASCII-armored detached PGP signature over the string commit as it would be written to the object database. To pass a `signature` parameter, you need to first manually create a valid PGP signature, which can be complicated. You may find it easier to [use the command line](https://git-scm.com/book/id/v2/Git-Tools-Signing-Your-Work) to create signed commits.
### [HTTP response status codes for "Create a commit"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a commit"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#create-a-commit--code-samples)
#### Request example
post/repos/{owner}/{repo}/git/commits
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/git/commits \   -d '{"message":"my commit message","author":{"name":"Mona Octocat","email":"octocat@github.com","date":"2008-07-09T16:13:30+12:00"},"parents":["7d1b31e74ee336d15cbd21741bc88a537ed063a0"],"tree":"827efc6d56897b048c772eb4087f854f46256132","signature":"-----BEGIN PGP SIGNATURE-----\n\niQIzBAABAQAdFiEESn/54jMNIrGSE6Tp6cQjvhfv7nAFAlnT71cACgkQ6cQjvhfv\n7nCWwA//XVqBKWO0zF+bZl6pggvky3Oc2j1pNFuRWZ29LXpNuD5WUGXGG209B0hI\nDkmcGk19ZKUTnEUJV2Xd0R7AW01S/YSub7OYcgBkI7qUE13FVHN5ln1KvH2all2n\n2+JCV1HcJLEoTjqIFZSSu/sMdhkLQ9/NsmMAzpf/iIM0nQOyU4YRex9eD1bYj6nA\nOQPIDdAuaTQj1gFPHYLzM4zJnCqGdRlg0sOM/zC5apBNzIwlgREatOYQSCfCKV7k\nnrU34X8b9BzQaUx48Qa+Dmfn5KQ8dl27RNeWAqlkuWyv3pUauH9UeYW+KyuJeMkU\n+NyHgAsWFaCFl23kCHThbLStMZOYEnGagrd0hnm1TPS4GJkV4wfYMwnI4KuSlHKB\njHl3Js9vNzEUQipQJbgCgTiWvRJoK3ENwBTMVkKHaqT4x9U4Jk/XZB6Q8MA09ezJ\n3QgiTjTAGcum9E9QiJqMYdWQPWkaBIRRz5cET6HPB48YNXAAUsfmuYsGrnVLYbG+\nUpC6I97VybYHTy2O9XSGoaLeMI9CsFn38ycAxxbWagk5mhclNTP5mezIq6wKSwmr\nX11FW3n1J23fWZn5HJMBsRnUCgzqzX3871IqLYHqRJ/bpZ4h20RhTyPj5c/z7QXp\neSakNQMfbbMcljkha+ZMuVQX1K9aRlVqbmv3ZMWh+OijLYVU2bc=\n=5Io4\n-----END PGP SIGNATURE-----\n"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "sha": "7638417db6d59f3c431d3e1f261cc637155684cd",   "node_id": "MDY6Q29tbWl0NzYzODQxN2RiNmQ1OWYzYzQzMWQzZTFmMjYxY2M2MzcxNTU2ODRjZA==",   "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/7638417db6d59f3c431d3e1f261cc637155684cd",   "author": {     "date": "2014-11-07T22:01:45Z",     "name": "Monalisa Octocat",     "email": "octocat@github.com"   },   "committer": {     "date": "2014-11-07T22:01:45Z",     "name": "Monalisa Octocat",     "email": "octocat@github.com"   },   "message": "my commit message",   "tree": {     "url": "https://api.github.com/repos/octocat/Hello-World/git/trees/827efc6d56897b048c772eb4087f854f46256132",     "sha": "827efc6d56897b048c772eb4087f854f46256132"   },   "parents": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/7d1b31e74ee336d15cbd21741bc88a537ed063a0",       "sha": "7d1b31e74ee336d15cbd21741bc88a537ed063a0",       "html_url": "https://github.com/octocat/Hello-World/commit/7d1b31e74ee336d15cbd21741bc88a537ed063a0"     }   ],   "verification": {     "verified": false,     "reason": "unsigned",     "signature": null,     "payload": null,     "verified_at": null   },   "html_url": "https://github.com/octocat/Hello-World/commit/7638417db6d59f3c431d3e1f261cc637155684cd" }`
## [Get a commit object](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object)
Gets a Git [commit object](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects).
To get the contents of a commit, see "[Get a commit](https://docs.github.com/rest/commits/commits#get-a-commit)."
**Signature verification object**
The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object:
Name | Type | Description
---|---|---
`verified` | `boolean` | Indicates whether GitHub considers the signature in this commit to be verified.
`reason` | `string` | The reason for verified value. Possible values and their meanings are enumerated in the table below.
`signature` | `string` | The signature that was extracted from the commit.
`payload` | `string` | The value that was signed.
`verified_at` | `string` | The date the signature was verified by GitHub.
These are the possible values for `reason` in the `verification` object:
Value | Description
---|---
`expired_key` | The key that made the signature is expired.
`not_signing_key` | The "signing" flag is not among the usage flags in the GPG key that made the signature.
`gpgverify_error` | There was an error communicating with the signature verification service.
`gpgverify_unavailable` | The signature verification service is currently unavailable.
`unsigned` | The object does not include a signature.
`unknown_signature_type` | A non-PGP signature was found in the commit.
`no_user` | No user was associated with the `committer` email address in the commit.
`unverified_email` | The `committer` email address in the commit was associated with a user, but the email address is not verified on their account.
`bad_email` | The `committer` email address in the commit is not included in the identities of the PGP key that made the signature.
`unknown_key` | The key that made the signature has not been registered with any user's account.
`malformed_signature` | There was an error parsing the signature.
`invalid` | The signature could not be cryptographically verified using the key whose key-id was found in the signature.
`valid` | None of the above errors applied, so the signature is considered to be verified.
### [Fine-grained access tokens for "Get a commit object"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a commit object"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`commit_sha` string Required The SHA of the commit.
### [HTTP response status codes for "Get a commit object"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`409` | Conflict
### [Code samples for "Get a commit object"](https://docs.github.com/en/rest/git/commits?apiVersion=2022-11-28#get-a-commit-object--code-samples)
#### Request example
get/repos/{owner}/{repo}/git/commits/{commit_sha}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/git/commits/COMMIT_SHA`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "sha": "7638417db6d59f3c431d3e1f261cc637155684cd",   "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",   "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/7638417db6d59f3c431d3e1f261cc637155684cd",   "html_url": "https://github.com/octocat/Hello-World/commit/7638417db6d59f3c431d3e1f261cc637155684cd",   "author": {     "date": "2014-11-07T22:01:45Z",     "name": "Monalisa Octocat",     "email": "octocat@github.com"   },   "committer": {     "date": "2014-11-07T22:01:45Z",     "name": "Monalisa Octocat",     "email": "octocat@github.com"   },   "message": "added readme, because im a good github citizen",   "tree": {     "url": "https://api.github.com/repos/octocat/Hello-World/git/trees/691272480426f78a0138979dd3ce63b77f706feb",     "sha": "691272480426f78a0138979dd3ce63b77f706feb"   },   "parents": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/1acc419d4d6a9ce985db7be48c6349a0475975b5",       "sha": "1acc419d4d6a9ce985db7be48c6349a0475975b5",       "html_url": "https://github.com/octocat/Hello-World/commit/7638417db6d59f3c431d3e1f261cc637155684cd"     }   ],   "verification": {     "verified": false,     "reason": "unsigned",     "signature": null,     "payload": null,     "verified_at": null   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/git/commits.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for Git commits - GitHub Docs
