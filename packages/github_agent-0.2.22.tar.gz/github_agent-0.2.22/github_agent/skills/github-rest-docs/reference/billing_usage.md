[Skip to main content](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Billing](https://docs.github.com/en/rest/billing "Billing")/
  * [Billing usage](https://docs.github.com/en/rest/billing/usage "Billing usage")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
      * [Get billing premium request usage report for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization)
      * [Get billing usage report for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization)
      * [Get billing usage summary for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization)
      * [Get billing premium request usage report for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user)
      * [Get billing usage report for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user)
      * [Get billing usage summary for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user)
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Billing](https://docs.github.com/en/rest/billing "Billing")/
  * [Billing usage](https://docs.github.com/en/rest/billing/usage "Billing usage")


# Billing usage
Use the REST API to get billing usage information.
The endpoints on this page return usage that is billed to the account associated with the endpoint. For help deciding which level of usage to report on, see [Automating usage reporting with the REST API](https://docs.github.com/en/billing/tutorials/automate-usage-reporting#step-1-decide-what-level-to-report-on).
  * User endpoints return Copilot usage that is billed directly to an individual user’s personal account. These endpoints are only applicable if the user has purchased their own Copilot plan.
  * If a user’s Copilot license is managed and billed through an organization or enterprise, their usage is not included in user-level endpoints. In that case, you must use the organization- or enterprise-level endpoints instead.


To view enterprise-level endpoints, select the dropdown menu at the top of the page and switch from Free, Pro, & Team to GitHub Enterprise Cloud.
## [Get billing premium request usage report for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization)
Gets a report of premium request usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account.
**Note:** Only data from the past 24 months is accessible via this endpoint.
### [Fine-grained access tokens for "Get billing premium request usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get billing premium request usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
`user` string The user name to query usage for. The name is not case sensitive.
`model` string The model name to query usage for. The name is not case sensitive.
`product` string The product name to query usage for. The name is not case sensitive.
### [HTTP response status codes for "Get billing premium request usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Response when getting a billing premium request usage report
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing premium request usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-an-organization--code-samples)
#### Request example
get/organizations/{org}/settings/billing/premium_request/usage
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/organizations/ORG/settings/billing/premium_request/usage`
Response when getting a billing premium request usage report
  * Example response
  * Response schema


`Status: 200`
`{   "timePeriod": {     "year": 2025   },   "organization": "GitHub",   "usageItems": [     {       "product": "Copilot",       "sku": "Copilot Premium Request",       "model": "GPT-5",       "unitType": "requests",       "pricePerUnit": 0.04,       "grossQuantity": 100,       "grossAmount": 4,       "discountQuantity": 0,       "discountAmount": 0,       "netQuantity": 100,       "netAmount": 4     }   ] }`
## [Get billing usage report for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization)
Gets a report of the total usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account.
**Note:** This endpoint is only available to organizations with access to the enhanced billing platform. For more information, see "[About the enhanced billing platform](https://docs.github.com/billing/using-the-new-billing-platform)."
### [Fine-grained access tokens for "Get billing usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get billing usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
### [HTTP response status codes for "Get billing usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Billing usage report response for an organization
`400` | Bad Request
`403` | Forbidden
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing usage report for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-an-organization--code-samples)
#### Request example
get/organizations/{org}/settings/billing/usage
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/organizations/ORG/settings/billing/usage`
Billing usage report response for an organization
  * Example response
  * Response schema


`Status: 200`
`{   "usageItems": [     {       "date": "2023-08-01",       "product": "Actions",       "sku": "Actions Linux",       "quantity": 100,       "unitType": "minutes",       "pricePerUnit": 0.008,       "grossAmount": 0.8,       "discountAmount": 0,       "netAmount": 0.8,       "organizationName": "GitHub",       "repositoryName": "github/example"     }   ] }`
## [Get billing usage summary for an organization](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization)
This endpoint is in public preview and is subject to change.
Gets a summary report of usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account.
**Note:** Only data from the past 24 months is accessible via this endpoint.
### [Fine-grained access tokens for "Get billing usage summary for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get billing usage summary for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
`repository` string The repository name to query for usage in the format owner/repository.
`product` string The product name to query usage for. The name is not case sensitive.
`sku` string The SKU to query for usage.
### [HTTP response status codes for "Get billing usage summary for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Response when getting a billing usage summary
`400` | Bad Request
`403` | Forbidden
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing usage summary for an organization"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-an-organization--code-samples)
#### Request example
get/organizations/{org}/settings/billing/usage/summary
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/organizations/ORG/settings/billing/usage/summary`
Response when getting a billing usage summary
  * Example response
  * Response schema


`Status: 200`
`{   "timePeriod": {     "year": 2025   },   "organization": "GitHub",   "usageItems": [     {       "product": "Actions",       "sku": "actions_linux",       "unitType": "minutes",       "pricePerUnit": 0.008,       "grossQuantity": 1000,       "grossAmount": 8,       "discountQuantity": 0,       "discountAmount": 0,       "netQuantity": 1000,       "netAmount": 8     }   ] }`
## [Get billing premium request usage report for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user)
Gets a report of premium request usage for a user.
**Note:** Only data from the past 24 months is accessible via this endpoint.
### [Fine-grained access tokens for "Get billing premium request usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Plan" user permissions (read)


### [Parameters for "Get billing premium request usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
`model` string The model name to query usage for. The name is not case sensitive.
`product` string The product name to query usage for. The name is not case sensitive.
### [HTTP response status codes for "Get billing premium request usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user--status-codes)
Status code | Description
---|---
`200` | Response when getting a billing premium request usage report
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing premium request usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-premium-request-usage-report-for-a-user--code-samples)
#### Request example
get/users/{username}/settings/billing/premium_request/usage
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/settings/billing/premium_request/usage`
Response when getting a billing premium request usage report
  * Example response
  * Response schema


`Status: 200`
`{   "timePeriod": {     "year": 2025   },   "user": "monalisa",   "usageItems": [     {       "product": "Copilot",       "sku": "Copilot Premium Request",       "model": "GPT-5",       "unitType": "requests",       "pricePerUnit": 0.04,       "grossQuantity": 100,       "grossAmount": 4,       "discountQuantity": 0,       "discountAmount": 0,       "netQuantity": 100,       "netAmount": 4     }   ] }`
## [Get billing usage report for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user)
Gets a report of the total usage for a user.
**Note:** This endpoint is only available to users with access to the enhanced billing platform.
### [Fine-grained access tokens for "Get billing usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Plan" user permissions (read)


### [Parameters for "Get billing usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
### [HTTP response status codes for "Get billing usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user--status-codes)
Status code | Description
---|---
`200` | Response when getting a billing usage report
`400` | Bad Request
`403` | Forbidden
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing usage report for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-report-for-a-user--code-samples)
#### Request example
get/users/{username}/settings/billing/usage
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/settings/billing/usage`
Response when getting a billing usage report
  * Example response
  * Response schema


`Status: 200`
`{   "usageItems": [     {       "date": "2023-08-01",       "product": "Actions",       "sku": "Actions Linux",       "quantity": 100,       "unitType": "minutes",       "pricePerUnit": 0.008,       "grossAmount": 0.8,       "discountAmount": 0,       "netAmount": 0.8,       "repositoryName": "user/example"     }   ] }`
## [Get billing usage summary for a user](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user)
This endpoint is in public preview and is subject to change.
Gets a summary report of usage for a user.
**Note:** Only data from the past 24 months is accessible via this endpoint.
### [Fine-grained access tokens for "Get billing usage summary for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Plan" user permissions (read)


### [Parameters for "Get billing usage summary for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`year` integer If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
`month` integer If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
`day` integer If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
`repository` string The repository name to query for usage in the format owner/repository.
`product` string The product name to query usage for. The name is not case sensitive.
`sku` string The SKU to query for usage.
### [HTTP response status codes for "Get billing usage summary for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user--status-codes)
Status code | Description
---|---
`200` | Response when getting a billing usage summary
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get billing usage summary for a user"](https://docs.github.com/en/rest/billing/usage?apiVersion=2022-11-28#get-billing-usage-summary-for-a-user--code-samples)
#### Request example
get/users/{username}/settings/billing/usage/summary
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/settings/billing/usage/summary`
Response when getting a billing usage summary
  * Example response
  * Response schema


`Status: 200`
`{   "timePeriod": {     "year": 2025   },   "user": "monalisa",   "usageItems": [     {       "product": "Actions",       "sku": "actions_linux",       "unitType": "minutes",       "pricePerUnit": 0.008,       "grossQuantity": 1000,       "grossAmount": 8,       "discountQuantity": 0,       "discountAmount": 0,       "netQuantity": 1000,       "netAmount": 8     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/billing/usage.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


Billing usage - GitHub Docs
