[Skip to main content](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams "Enterprise teams")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams "Enterprise teams")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
      * [About enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#about-enterprise-teams)
      * [List enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams)
      * [Create an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team)
      * [Get an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team)
      * [Update an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team)
      * [Delete an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team)
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams "Enterprise teams")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams "Enterprise teams")


# REST API endpoints for enterprise teams
Use the REST API to create and manage enterprise teams in your GitHub enterprise.
## [About enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#about-enterprise-teams)
These endpoints are currently in public preview and subject to change.
This API documentation is for enterprises on GitHub Enterprise Cloud.
If your enterprise is Copilot Business for non-GHE, please refer to the early access documentation link that was previously shared to you.
These endpoints are only available to authenticated members of the enterprise team's enterprise with classic personal access tokens with the `read:enterprise` [scope](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps) for `GET` APIs and `admin:enterprise` for other APIs.
These endpoints are not compatible with fine-grained personal access tokens or GitHub App access tokens.
GitHub generates the enterprise team's `slug` from the team `name` and adds the `ent:` prefix.
## [List enterprise teams](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams)
List all teams in the enterprise for the authenticated user
### [Fine-grained access tokens for "List enterprise teams"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (read)


### [Parameters for "List enterprise teams"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List enterprise teams"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
### [Code samples for "List enterprise teams"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#list-enterprise-teams--code-samples)
#### Request example
get/enterprises/{enterprise}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "name": "Justice League",     "description": "A great team.",     "slug": "justice-league",     "url": "https://api.github.com/enterprises/dc/teams/justice-league",     "group_id": "62ab9291-fae2-468e-974b-7e45096d5021",     "html_url": "https://github.com/enterprises/dc/teams/justice-league",     "members_url": "https://api.github.com/enterprises/dc/teams/justice-league/members{/member}",     "created_at": "2019-01-26T19:01:12Z",     "updated_at": "2019-01-26T19:14:43Z"   } ]`
## [Create an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team)
To create an enterprise team, the authenticated user must be an owner of the enterprise.
### [Fine-grained access tokens for "Create an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Create an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
Body parameters Name, Type, Description
---
`name` string Required The name of the team.
`description` string or null A description of the team.
`sync_to_organizations` string Retired: this field is no longer supported. Whether the enterprise team should be reflected in each organization. This value cannot be set. Default: `disabled` Can be one of: `all`, `disabled`
`organization_selection_type` string Specifies which organizations in the enterprise should have access to this team. Can be one of `disabled`, `selected`, or `all`. `disabled`: The team is not assigned to any organizations. This is the default when you create a new team. `selected`: The team is assigned to specific organizations. You can then use the [add organization assignments API](https://docs.github.com/rest/enterprise-teams/enterprise-team-organizations#add-organization-assignments) endpoint. `all`: The team is assigned to all current and future organizations in the enterprise. Default: `disabled` Can be one of: `disabled`, `selected`, `all`
`group_id` string or null The ID of the IdP group to assign team membership with. You can get this value from the [REST API endpoints for SCIM](https://docs.github.com/rest/scim#list-provisioned-scim-groups-for-an-enterprise).
### [HTTP response status codes for "Create an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#create-an-enterprise-team--code-samples)
#### Request example
post/enterprises/{enterprise}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams \   -d '{"name":"Justice League","description":"A great team.","group_id":"62ab9291-fae2-468e-974b-7e45096d5021"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1,   "name": "Justice League",   "description": "A great team.",   "slug": "justice-league",   "url": "https://api.github.com/enterprises/dc/teams/justice-league",   "group_id": "62ab9291-fae2-468e-974b-7e45096d5021",   "html_url": "https://github.com/enterprises/dc/teams/justice-league",   "members_url": "https://api.github.com/enterprises/dc/teams/justice-league/members{/member}",   "created_at": "2019-01-26T19:01:12Z",   "updated_at": "2019-01-26T19:14:43Z" }`
## [Get an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team)
Gets a team using the team's slug. To create the slug, GitHub replaces special characters in the name string, changes all words to lowercase, and replaces spaces with a `-` separator and adds the "ent:" prefix. For example, "My TEam Näme" would become `ent:my-team-name`.
### [Fine-grained access tokens for "Get an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (read)


### [Parameters for "Get an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`team_slug` string Required The slug of the team name.
### [HTTP response status codes for "Get an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
### [Code samples for "Get an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#get-an-enterprise-team--code-samples)
#### Request example
get/enterprises/{enterprise}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/TEAM_SLUG`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "name": "Justice League",   "description": "A great team.",   "slug": "justice-league",   "url": "https://api.github.com/enterprises/dc/teams/justice-league",   "group_id": "62ab9291-fae2-468e-974b-7e45096d5021",   "html_url": "https://github.com/enterprises/dc/teams/justice-league",   "members_url": "https://api.github.com/enterprises/dc/teams/justice-league/members{/member}",   "created_at": "2019-01-26T19:01:12Z",   "updated_at": "2019-01-26T19:14:43Z" }`
## [Update an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team)
To edit a team, the authenticated user must be an enterprise owner.
### [Fine-grained access tokens for "Update an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Update an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`team_slug` string Required The slug of the team name.
Body parameters Name, Type, Description
---
`name` string or null A new name for the team.
`description` string or null A new description for the team.
`sync_to_organizations` string Retired: this field is no longer supported. Whether the enterprise team should be reflected in each organization. This value cannot be changed. Default: `disabled` Can be one of: `all`, `disabled`
`organization_selection_type` string Specifies which organizations in the enterprise should have access to this team. Can be one of `disabled`, `selected`, or `all`. `disabled`: The team is not assigned to any organizations. This is the default when you create a new team. `selected`: The team is assigned to specific organizations. You can then use the [add organization assignments API](https://docs.github.com/rest/enterprise-teams/enterprise-team-organizations#add-organization-assignments). `all`: The team is assigned to all current and future organizations in the enterprise. Default: `disabled` Can be one of: `disabled`, `selected`, `all`
`group_id` string or null The ID of the IdP group to assign team membership with. The new IdP group will replace the existing one, or replace existing direct members if the team isn't currently linked to an IdP group.
### [HTTP response status codes for "Update an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
### [Code samples for "Update an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#update-an-enterprise-team--code-samples)
#### Request example
patch/enterprises/{enterprise}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/TEAM_SLUG \   -d '{"name":"Justice League","description":"A great team.","group_id":"62ab9291-fae2-468e-974b-7e45096d5021"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "name": "Justice League",   "description": "A great team.",   "slug": "justice-league",   "url": "https://api.github.com/enterprises/dc/teams/justice-league",   "group_id": "62ab9291-fae2-468e-974b-7e45096d5021",   "html_url": "https://github.com/enterprises/dc/teams/justice-league",   "members_url": "https://api.github.com/enterprises/dc/teams/justice-league/members{/member}",   "created_at": "2019-01-26T19:01:12Z",   "updated_at": "2019-01-26T19:14:43Z" }`
## [Delete an enterprise team](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team)
To delete an enterprise team, the authenticated user must be an enterprise owner.
If you are an enterprise owner, deleting an enterprise team will delete all of its IdP mappings as well.
### [Fine-grained access tokens for "Delete an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Delete an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`team_slug` string Required The slug of the team name.
### [HTTP response status codes for "Delete an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team--status-codes)
Status code | Description
---|---
`204` | No Content
`403` | Forbidden
### [Code samples for "Delete an enterprise team"](https://docs.github.com/en/rest/enterprise-teams/enterprise-teams?apiVersion=2022-11-28#delete-an-enterprise-team--code-samples)
#### Request example
delete/enterprises/{enterprise}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/TEAM_SLUG`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/enterprise-teams/enterprise-teams.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for enterprise teams - GitHub Docs
