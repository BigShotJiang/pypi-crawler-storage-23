[Skip to main content](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Gists](https://docs.github.com/en/rest/gists "Gists")/
  * [Gists](https://docs.github.com/en/rest/gists/gists "Gists")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
      * [About gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#about-gists)
      * [List gists for the authenticated user](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user)
      * [Create a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist)
      * [List public gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists)
      * [List starred gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists)
      * [Get a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist)
      * [Update a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist)
      * [Delete a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist)
      * [List gist commits](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits)
      * [List gist forks](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks)
      * [Fork a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist)
      * [Check if a gist is starred](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred)
      * [Star a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist)
      * [Unstar a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist)
      * [Get a gist revision](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision)
      * [List gists for a user](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user)
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Gists](https://docs.github.com/en/rest/gists "Gists")/
  * [Gists](https://docs.github.com/en/rest/gists/gists "Gists")


# REST API endpoints for gists
Use the REST API to list, create, update and delete the public gists on GitHub.
## [About gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#about-gists)
You can use the REST API to view and modify gists. For more information about gists, see [Editing and sharing content with gists](https://docs.github.com/en/get-started/writing-on-github/editing-and-sharing-content-with-gists).
### [Authentication](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#authentication)
You can read public gists anonymously, but you must be signed into GitHub to create gists. To read or write gists on a user's behalf, you need the gist OAuth scope and a token. For more information, see [Scopes for OAuth apps](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps).
### [Truncation](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#truncation)
The API provides up to one megabyte of content for each file in the gist. Each file returned for a gist through the API has a key called `truncated`. If `truncated` is `true`, the file is too large and only a portion of the contents were returned in `content`.
If you need the full contents of the file, you can make a `GET` request to the URL specified by `raw_url`. Be aware that for files larger than ten megabytes, you'll need to clone the gist via the URL provided by `git_pull_url`.
In addition to a specific file's contents being truncated, the entire files list may be truncated if the total number exceeds 300 files. If the top level `truncated` key is `true`, only the first 300 files have been returned in the files list. If you need to fetch all of the gist's files, you'll need to clone the gist via the URL provided by `git_pull_url`.
## [List gists for the authenticated user](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user)
Lists the authenticated user's gists or if called anonymously, this endpoint returns all public gists:
### [Fine-grained access tokens for "List gists for the authenticated user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List gists for the authenticated user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List gists for the authenticated user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
### [Code samples for "List gists for the authenticated user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-the-authenticated-user--code-samples)
#### Request example
get/gists
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",     "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",     "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",     "id": "aa5a315d61ae9438b18d",     "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",     "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",     "files": {       "hello_world.rb": {         "filename": "hello_world.rb",         "type": "application/x-ruby",         "language": "Ruby",         "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",         "size": 167       }     },     "public": true,     "created_at": "2010-04-14T02:15:15Z",     "updated_at": "2011-06-20T11:34:15Z",     "description": "Hello World Examples",     "comments": 0,     "user": null,     "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "truncated": false   } ]`
## [Create a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist)
Allows you to add a new gist with one or more files.
Don't name your files "gistfile" with a numerical suffix. This is the format of the automatic naming scheme that Gist uses internally.
### [Fine-grained access tokens for "Create a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Create a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Body parameters Name, Type, Description
---
`description` string Description of the gist
`files` object Required Names and content for the files that make up the gist
Properties of `files` | Name, Type, Description
---
`key` object A user-defined key to represent an item in `files`.
Properties of `key` | Name, Type, Description
---
`content` string Required Content of the file
`public` boolean or string Flag indicating whether the gist is public
### [HTTP response status codes for "Create a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist--status-codes)
Status code | Description
---|---
`201` | Created
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#create-a-gist--code-samples)
#### Request example
post/gists
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists \   -d '{"description":"Example of a gist","public":false,"files":{"README.md":{"content":"Hello World"}}}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "url": "https://api.github.com/gists/2decf6c462d9b4418f2",   "forks_url": "https://api.github.com/gists/2decf6c462d9b4418f2/forks",   "commits_url": "https://api.github.com/gists/2decf6c462d9b4418f2/commits",   "id": "2decf6c462d9b4418f2",   "node_id": "G_kwDOBhHyLdZDliNDQxOGYy",   "git_pull_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "git_push_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "html_url": "https://gist.github.com/2decf6c462d9b4418f2",   "files": {     "README.md": {       "filename": "README.md",       "type": "text/markdown",       "language": "Markdown",       "raw_url": "https://gist.githubusercontent.com/monalisa/2decf6c462d9b4418f2/raw/ac3e6daf176fafe73609fd000cd188e4472010fb/README.md",       "size": 23,       "truncated": false,       "content": "Hello world from GitHub",       "encoding": "utf-8"     }   },   "public": true,   "created_at": "2022-09-20T12:11:58Z",   "updated_at": "2022-09-21T10:28:06Z",   "description": "An updated gist description.",   "comments": 0,   "comments_enabled": true,   "user": null,   "comments_url": "https://api.github.com/gists/2decf6c462d9b4418f2/comments",   "owner": {     "login": "monalisa",     "id": 104456405,     "node_id": "U_kgDOBhHyLQ",     "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",     "gravatar_id": "",     "url": "https://api.github.com/users/monalisa",     "html_url": "https://github.com/monalisa",     "followers_url": "https://api.github.com/users/monalisa/followers",     "following_url": "https://api.github.com/users/monalisa/following{/other_user}",     "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",     "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",     "organizations_url": "https://api.github.com/users/monalisa/orgs",     "repos_url": "https://api.github.com/users/monalisa/repos",     "events_url": "https://api.github.com/users/monalisa/events{/privacy}",     "received_events_url": "https://api.github.com/users/monalisa/received_events",     "type": "User",     "site_admin": true   },   "forks": [],   "history": [     {       "user": {         "login": "monalisa",         "id": 104456405,         "node_id": "U_kgyLQ",         "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/monalisa",         "html_url": "https://github.com/monalisa",         "followers_url": "https://api.github.com/users/monalisa/followers",         "following_url": "https://api.github.com/users/monalisa/following{/other_user}",         "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",         "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",         "organizations_url": "https://api.github.com/users/monalisa/orgs",         "repos_url": "https://api.github.com/users/monalisa/repos",         "events_url": "https://api.github.com/users/monalisa/events{/privacy}",         "received_events_url": "https://api.github.com/users/monalisa/received_events",         "type": "User",         "site_admin": true       },       "version": "468aac8caed5f0c3b859b8286968",       "committed_at": "2022-09-21T10:28:06Z",       "change_status": {         "total": 2,         "additions": 1,         "deletions": 1       },       "url": "https://api.github.com/gists/8481a81af6b7a2d418f2/468aac8caed5f0c3b859b8286968"     }   ],   "truncated": false }`
## [List public gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists)
List public gists sorted by most recently updated to least recently updated.
Note: With [pagination](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api), you can fetch up to 3000 gists. For example, you can fetch 100 pages with 30 gists per page or 30 pages with 100 gists per page.
### [Fine-grained access tokens for "List public gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List public gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-public-gists--code-samples)
#### Request example
get/gists/public
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/public`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",     "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",     "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",     "id": "aa5a315d61ae9438b18d",     "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",     "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",     "files": {       "hello_world.rb": {         "filename": "hello_world.rb",         "type": "application/x-ruby",         "language": "Ruby",         "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",         "size": 167       }     },     "public": true,     "created_at": "2010-04-14T02:15:15Z",     "updated_at": "2011-06-20T11:34:15Z",     "description": "Hello World Examples",     "comments": 0,     "user": null,     "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "truncated": false   } ]`
## [List starred gists](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists)
List the authenticated user's starred gists:
### [Fine-grained access tokens for "List starred gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List starred gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List starred gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "List starred gists"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-starred-gists--code-samples)
#### Request example
get/gists/starred
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/starred`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",     "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",     "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",     "id": "aa5a315d61ae9438b18d",     "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",     "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",     "files": {       "hello_world.rb": {         "filename": "hello_world.rb",         "type": "application/x-ruby",         "language": "Ruby",         "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",         "size": 167       }     },     "public": true,     "created_at": "2010-04-14T02:15:15Z",     "updated_at": "2011-06-20T11:34:15Z",     "description": "Hello World Examples",     "comments": 0,     "user": null,     "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "truncated": false   } ]`
## [Get a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist)
Gets a specified gist.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Get a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "Get a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Get a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden Gist
`404` | Resource not found
### [Code samples for "Get a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist--code-samples)
#### Request example
get/gists/{gist_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/gists/2decf6c462d9b4418f2",   "forks_url": "https://api.github.com/gists/2decf6c462d9b4418f2/forks",   "commits_url": "https://api.github.com/gists/2decf6c462d9b4418f2/commits",   "id": "2decf6c462d9b4418f2",   "node_id": "G_kwDOBhHyLdZDliNDQxOGYy",   "git_pull_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "git_push_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "html_url": "https://gist.github.com/2decf6c462d9b4418f2",   "files": {     "README.md": {       "filename": "README.md",       "type": "text/markdown",       "language": "Markdown",       "raw_url": "https://gist.githubusercontent.com/monalisa/2decf6c462d9b4418f2/raw/ac3e6daf176fafe73609fd000cd188e4472010fb/README.md",       "size": 23,       "truncated": false,       "content": "Hello world from GitHub",       "encoding": "utf-8"     }   },   "public": true,   "created_at": "2022-09-20T12:11:58Z",   "updated_at": "2022-09-21T10:28:06Z",   "description": "An updated gist description.",   "comments": 0,   "comments_enabled": true,   "user": null,   "comments_url": "https://api.github.com/gists/2decf6c462d9b4418f2/comments",   "owner": {     "login": "monalisa",     "id": 104456405,     "node_id": "U_kgDOBhHyLQ",     "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",     "gravatar_id": "",     "url": "https://api.github.com/users/monalisa",     "html_url": "https://github.com/monalisa",     "followers_url": "https://api.github.com/users/monalisa/followers",     "following_url": "https://api.github.com/users/monalisa/following{/other_user}",     "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",     "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",     "organizations_url": "https://api.github.com/users/monalisa/orgs",     "repos_url": "https://api.github.com/users/monalisa/repos",     "events_url": "https://api.github.com/users/monalisa/events{/privacy}",     "received_events_url": "https://api.github.com/users/monalisa/received_events",     "type": "User",     "site_admin": true   },   "forks": [],   "history": [     {       "user": {         "login": "monalisa",         "id": 104456405,         "node_id": "U_kgyLQ",         "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/monalisa",         "html_url": "https://github.com/monalisa",         "followers_url": "https://api.github.com/users/monalisa/followers",         "following_url": "https://api.github.com/users/monalisa/following{/other_user}",         "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",         "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",         "organizations_url": "https://api.github.com/users/monalisa/orgs",         "repos_url": "https://api.github.com/users/monalisa/repos",         "events_url": "https://api.github.com/users/monalisa/events{/privacy}",         "received_events_url": "https://api.github.com/users/monalisa/received_events",         "type": "User",         "site_admin": true       },       "version": "468aac8caed5f0c3b859b8286968",       "committed_at": "2022-09-21T10:28:06Z",       "change_status": {         "total": 2,         "additions": 1,         "deletions": 1       },       "url": "https://api.github.com/gists/8481a81af6b7a2d418f2/468aac8caed5f0c3b859b8286968"     }   ],   "truncated": false }`
## [Update a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist)
Allows you to update a gist's description and to update, delete, or rename gist files. Files from the previous version of the gist that aren't explicitly changed during an edit are unchanged.
At least one of `description` or `files` is required.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Update a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Update a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
Body parameters Name, Type, Description
---
`description` string The description of the gist.
`files` object The gist files to be updated, renamed, or deleted. Each `key` must match the current filename (including extension) of the targeted gist file. For example: `hello.py`. To delete a file, set the whole file to null. For example: `hello.py : null`. The file will also be deleted if the specified object does not contain at least one of `content` or `filename`.
Properties of `files` | Name, Type, Description
---
`key` object A user-defined key to represent an item in `files`.
Properties of `key` | Name, Type, Description
---
`content` string The new content of the file.
`filename` string or null The new filename for the file.
### [HTTP response status codes for "Update a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#update-a-gist--code-samples)
#### Request examples
Select the example typeUpdating a gist Deleting a gist file Renaming a gist file
patch/gists/{gist_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID \   -d '{"description":"An updated gist description","files":{"README.md":{"content":"Hello World from GitHub"}}}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/gists/2decf6c462d9b4418f2",   "forks_url": "https://api.github.com/gists/2decf6c462d9b4418f2/forks",   "commits_url": "https://api.github.com/gists/2decf6c462d9b4418f2/commits",   "id": "2decf6c462d9b4418f2",   "node_id": "G_kwDOBhHyLdZDliNDQxOGYy",   "git_pull_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "git_push_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "html_url": "https://gist.github.com/2decf6c462d9b4418f2",   "files": {     "README.md": {       "filename": "README.md",       "type": "text/markdown",       "language": "Markdown",       "raw_url": "https://gist.githubusercontent.com/monalisa/2decf6c462d9b4418f2/raw/ac3e6daf176fafe73609fd000cd188e4472010fb/README.md",       "size": 23,       "truncated": false,       "content": "Hello world from GitHub",       "encoding": "utf-8"     }   },   "public": true,   "created_at": "2022-09-20T12:11:58Z",   "updated_at": "2022-09-21T10:28:06Z",   "description": "An updated gist description.",   "comments": 0,   "comments_enabled": true,   "user": null,   "comments_url": "https://api.github.com/gists/2decf6c462d9b4418f2/comments",   "owner": {     "login": "monalisa",     "id": 104456405,     "node_id": "U_kgDOBhHyLQ",     "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",     "gravatar_id": "",     "url": "https://api.github.com/users/monalisa",     "html_url": "https://github.com/monalisa",     "followers_url": "https://api.github.com/users/monalisa/followers",     "following_url": "https://api.github.com/users/monalisa/following{/other_user}",     "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",     "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",     "organizations_url": "https://api.github.com/users/monalisa/orgs",     "repos_url": "https://api.github.com/users/monalisa/repos",     "events_url": "https://api.github.com/users/monalisa/events{/privacy}",     "received_events_url": "https://api.github.com/users/monalisa/received_events",     "type": "User",     "site_admin": true   },   "forks": [],   "history": [     {       "user": {         "login": "monalisa",         "id": 104456405,         "node_id": "U_kgyLQ",         "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/monalisa",         "html_url": "https://github.com/monalisa",         "followers_url": "https://api.github.com/users/monalisa/followers",         "following_url": "https://api.github.com/users/monalisa/following{/other_user}",         "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",         "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",         "organizations_url": "https://api.github.com/users/monalisa/orgs",         "repos_url": "https://api.github.com/users/monalisa/repos",         "events_url": "https://api.github.com/users/monalisa/events{/privacy}",         "received_events_url": "https://api.github.com/users/monalisa/received_events",         "type": "User",         "site_admin": true       },       "version": "468aac8caed5f0c3b859b8286968",       "committed_at": "2022-09-21T10:28:06Z",       "change_status": {         "total": 2,         "additions": 1,         "deletions": 1       },       "url": "https://api.github.com/gists/8481a81af6b7a2d418f2/468aac8caed5f0c3b859b8286968"     }   ],   "truncated": false }`
## [Delete a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist)
### [Fine-grained access tokens for "Delete a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Delete a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Delete a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist--status-codes)
Status code | Description
---|---
`204` | No Content
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Delete a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#delete-a-gist--code-samples)
#### Request example
delete/gists/{gist_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID`
Response
`Status: 204`
## [List gist commits](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits)
### [Fine-grained access tokens for "List gist commits"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List gist commits"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List gist commits"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List gist commits"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-commits--code-samples)
#### Request example
get/gists/{gist_id}/commits
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/commits`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d/57a7f021a713b1c5a6a199b54cc514735d2d462f",     "version": "57a7f021a713b1c5a6a199b54cc514735d2d462f",     "user": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "change_status": {       "deletions": 0,       "additions": 180,       "total": 180     },     "committed_at": "2010-04-14T02:15:15Z"   } ]`
## [List gist forks](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks)
### [Fine-grained access tokens for "List gist forks"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List gist forks"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List gist forks"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List gist forks"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gist-forks--code-samples)
#### Request example
get/gists/{gist_id}/forks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/forks`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",     "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",     "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",     "id": "aa5a315d61ae9438b18d",     "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",     "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",     "files": {       "hello_world.rb": {         "filename": "hello_world.rb",         "type": "application/x-ruby",         "language": "Ruby",         "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",         "size": 167       }     },     "public": true,     "created_at": "2010-04-14T02:15:15Z",     "updated_at": "2011-06-20T11:34:15Z",     "description": "Hello World Examples",     "comments": 1,     "user": null,     "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   } ]`
## [Fork a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist)
### [Fine-grained access tokens for "Fork a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Fork a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Fork a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist--status-codes)
Status code | Description
---|---
`201` | Created
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Fork a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#fork-a-gist--code-samples)
#### Request example
post/gists/{gist_id}/forks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/forks`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",   "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",   "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",   "id": "aa5a315d61ae9438b18d",   "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",   "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",   "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",   "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",   "files": {     "hello_world.rb": {       "filename": "hello_world.rb",       "type": "application/x-ruby",       "language": "Ruby",       "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",       "size": 167     }   },   "public": true,   "created_at": "2010-04-14T02:15:15Z",   "updated_at": "2011-06-20T11:34:15Z",   "description": "Hello World Examples",   "comments": 0,   "user": null,   "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "truncated": false }`
## [Check if a gist is starred](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred)
### [Fine-grained access tokens for "Check if a gist is starred"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "Check if a gist is starred"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Check if a gist is starred"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred--status-codes)
Status code | Description
---|---
`204` | Response if gist is starred
`304` | Not modified
`403` | Forbidden
`404` | Not Found if gist is not starred
### [Code samples for "Check if a gist is starred"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#check-if-a-gist-is-starred--code-samples)
#### Request example
get/gists/{gist_id}/star
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/star`
Response if gist is starred
`Status: 204`
## [Star a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist)
Note that you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)."
### [Fine-grained access tokens for "Star a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Star a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Star a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist--status-codes)
Status code | Description
---|---
`204` | No Content
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Star a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#star-a-gist--code-samples)
#### Request example
put/gists/{gist_id}/star
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/star`
Response
`Status: 204`
## [Unstar a gist](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist)
### [Fine-grained access tokens for "Unstar a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Unstar a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
### [HTTP response status codes for "Unstar a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist--status-codes)
Status code | Description
---|---
`204` | No Content
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Unstar a gist"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#unstar-a-gist--code-samples)
#### Request example
delete/gists/{gist_id}/star
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/star`
Response
`Status: 204`
## [Get a gist revision](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision)
Gets a specified gist revision.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Get a gist revision"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "Get a gist revision"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
`sha` string Required
### [HTTP response status codes for "Get a gist revision"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Get a gist revision"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#get-a-gist-revision--code-samples)
#### Request example
get/gists/{gist_id}/{sha}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/SHA`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/gists/2decf6c462d9b4418f2",   "forks_url": "https://api.github.com/gists/2decf6c462d9b4418f2/forks",   "commits_url": "https://api.github.com/gists/2decf6c462d9b4418f2/commits",   "id": "2decf6c462d9b4418f2",   "node_id": "G_kwDOBhHyLdZDliNDQxOGYy",   "git_pull_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "git_push_url": "https://gist.github.com/2decf6c462d9b4418f2.git",   "html_url": "https://gist.github.com/2decf6c462d9b4418f2",   "files": {     "README.md": {       "filename": "README.md",       "type": "text/markdown",       "language": "Markdown",       "raw_url": "https://gist.githubusercontent.com/monalisa/2decf6c462d9b4418f2/raw/ac3e6daf176fafe73609fd000cd188e4472010fb/README.md",       "size": 23,       "truncated": false,       "content": "Hello world from GitHub",       "encoding": "utf-8"     }   },   "public": true,   "created_at": "2022-09-20T12:11:58Z",   "updated_at": "2022-09-21T10:28:06Z",   "description": "An updated gist description.",   "comments": 0,   "comments_enabled": true,   "user": null,   "comments_url": "https://api.github.com/gists/2decf6c462d9b4418f2/comments",   "owner": {     "login": "monalisa",     "id": 104456405,     "node_id": "U_kgDOBhHyLQ",     "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",     "gravatar_id": "",     "url": "https://api.github.com/users/monalisa",     "html_url": "https://github.com/monalisa",     "followers_url": "https://api.github.com/users/monalisa/followers",     "following_url": "https://api.github.com/users/monalisa/following{/other_user}",     "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",     "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",     "organizations_url": "https://api.github.com/users/monalisa/orgs",     "repos_url": "https://api.github.com/users/monalisa/repos",     "events_url": "https://api.github.com/users/monalisa/events{/privacy}",     "received_events_url": "https://api.github.com/users/monalisa/received_events",     "type": "User",     "site_admin": true   },   "forks": [],   "history": [     {       "user": {         "login": "monalisa",         "id": 104456405,         "node_id": "U_kgyLQ",         "avatar_url": "https://avatars.githubusercontent.com/u/104456405?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/monalisa",         "html_url": "https://github.com/monalisa",         "followers_url": "https://api.github.com/users/monalisa/followers",         "following_url": "https://api.github.com/users/monalisa/following{/other_user}",         "gists_url": "https://api.github.com/users/monalisa/gists{/gist_id}",         "starred_url": "https://api.github.com/users/monalisa/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/monalisa/subscriptions",         "organizations_url": "https://api.github.com/users/monalisa/orgs",         "repos_url": "https://api.github.com/users/monalisa/repos",         "events_url": "https://api.github.com/users/monalisa/events{/privacy}",         "received_events_url": "https://api.github.com/users/monalisa/received_events",         "type": "User",         "site_admin": true       },       "version": "468aac8caed5f0c3b859b8286968",       "committed_at": "2022-09-21T10:28:06Z",       "change_status": {         "total": 2,         "additions": 1,         "deletions": 1       },       "url": "https://api.github.com/gists/8481a81af6b7a2d418f2/468aac8caed5f0c3b859b8286968"     }   ],   "truncated": false }`
## [List gists for a user](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user)
Lists public gists for the specified user:
### [Fine-grained access tokens for "List gists for a user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List gists for a user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List gists for a user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List gists for a user"](https://docs.github.com/en/rest/gists/gists?apiVersion=2022-11-28#list-gists-for-a-user--code-samples)
#### Request example
get/users/{username}/gists
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/gists`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/gists/aa5a315d61ae9438b18d",     "forks_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/forks",     "commits_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/commits",     "id": "aa5a315d61ae9438b18d",     "node_id": "MDQ6R2lzdGFhNWEzMTVkNjFhZTk0MzhiMThk",     "git_pull_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "git_push_url": "https://gist.github.com/aa5a315d61ae9438b18d.git",     "html_url": "https://gist.github.com/aa5a315d61ae9438b18d",     "files": {       "hello_world.rb": {         "filename": "hello_world.rb",         "type": "application/x-ruby",         "language": "Ruby",         "raw_url": "https://gist.githubusercontent.com/octocat/6cad326836d38bd3a7ae/raw/db9c55113504e46fa076e7df3a04ce592e2e86d8/hello_world.rb",         "size": 167       }     },     "public": true,     "created_at": "2010-04-14T02:15:15Z",     "updated_at": "2011-06-20T11:34:15Z",     "description": "Hello World Examples",     "comments": 0,     "user": null,     "comments_url": "https://api.github.com/gists/aa5a315d61ae9438b18d/comments/",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "truncated": false   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/gists/gists.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for gists - GitHub Docs
