[Skip to main content](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Artifact metadata](https://docs.github.com/en/rest/orgs/artifact-metadata "Artifact metadata")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
      * [Create an artifact deployment record](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record)
      * [Set cluster deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records)
      * [Create artifact metadata storage record](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record)
      * [List artifact deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records)
      * [List artifact storage records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records)
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Artifact metadata](https://docs.github.com/en/rest/orgs/artifact-metadata "Artifact metadata")


# REST API endpoints for artifact metadata
Use these endpoints to retrieve and manage metadata for artifacts in your organization. Artifact metadata provides information about build artifacts, their provenance, and related details.
You can use these endpoints to upload storage and deployment records for software that your organization builds with GitHub Actions. The records are displayed on the organization's linked artifacts page. See [About linked artifacts](https://docs.github.com/en/code-security/concepts/supply-chain-security/linked-artifacts).
## [Create an artifact deployment record](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record)
Create or update deployment records for an artifact associated with an organization. This endpoint allows you to record information about a specific artifact, such as its name, digest, environments, cluster, and deployment. The deployment name has to be uniqe within a cluster (i.e a combination of logical, physical environment and cluster) as it identifies unique deployment. Multiple requests for the same combination of logical, physical environment, cluster and deployment name will only create one record, successive request will update the existing record. This allows for a stable tracking of a deployment where the actual deployed artifact can change over time.
### [Fine-grained access tokens for "Create an artifact deployment record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (write)
  * "Artifact metadata" repository permissions (write)


### [Parameters for "Create an artifact deployment record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the artifact.
`digest` string Required The hex encoded digest of the artifact.
`version` string The artifact version.
`status` string Required The status of the artifact. Can be either deployed or decommissioned. Can be one of: `deployed`, `decommissioned`
`logical_environment` string Required The stage of the deployment.
`physical_environment` string The physical region of the deployment.
`cluster` string The deployment cluster.
`deployment_name` string Required The unique identifier for the deployment represented by the new record. To accommodate differing containers and namespaces within a cluster, the following format is recommended: {namespaceName}-{deploymentName}-{containerName}.
`tags` object The tags associated with the deployment.
`runtime_risks` array of strings A list of runtime risks associated with the deployment. Supported values are: `critical-resource`, `internet-exposed`, `lateral-movement`, `sensitive-data`
`github_repository` string The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter.
### [HTTP response status codes for "Create an artifact deployment record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record--status-codes)
Status code | Description
---|---
`200` | Artifact deployment record stored successfully.
### [Code samples for "Create an artifact deployment record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-an-artifact-deployment-record--code-samples)
#### Request example
post/orgs/{org}/artifacts/metadata/deployment-record
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/artifacts/metadata/deployment-record \   -d '{"name":"awesome-image","digest":"sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72","status":"deployed","logical_environment":"prod","physical_environment":"pacific-east","cluster":"moda-1","deployment_name":"deployment-pod","tags":{"data-access":"sensitive"}}'`
Artifact deployment record stored successfully.
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "deployment_records": [     {       "id": 123,       "digest": "sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72",       "logical_environment": "prod",       "physical_environment": "pacific-east",       "cluster": "moda-1",       "deployment_name": "prod-deployment",       "tags": {         "data": "sensitive"       },       "created": "2011-01-26T19:14:43Z",       "updated_at": "2011-01-26T19:14:43Z",       "attestation_id": 456     }   ] }`
## [Set cluster deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records)
Set deployment records for a given cluster. If proposed records in the 'deployments' field have identical 'cluster', 'logical_environment', 'physical_environment', and 'deployment_name' values as existing records, the existing records will be updated. If no existing records match, new records will be created.
### [Fine-grained access tokens for "Set cluster deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (write)
  * "Artifact metadata" repository permissions (write)


### [Parameters for "Set cluster deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`cluster` string Required The cluster name.
Body parameters Name, Type, Description
---
`logical_environment` string Required The stage of the deployment.
`physical_environment` string The physical region of the deployment.
`deployments` array of objects Required The list of deployments to record.
Properties of `deployments` | Name, Type, Description
---
`name` string Required The name of the artifact. Note that if multiple deployments have identical 'digest' parameter values, the name parameter must also be identical across all entries.
`digest` string Required The hex encoded digest of the artifact. Note that if multiple deployments have identical 'digest' parameter values, the name and version parameters must also be identical across all entries.
`version` string The artifact version. Note that if multiple deployments have identical 'digest' parameter values, the version parameter must also be identical across all entries.
`status` string The deployment status of the artifact. Can be one of: `deployed`, `decommissioned`
`deployment_name` string Required The unique identifier for the deployment represented by the new record. To accommodate differing containers and namespaces within a record set, the following format is recommended: {namespaceName}-{deploymentName}-{containerName}. The deployment_name must be unique across all entries in the deployments array.
`github_repository` string The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter.
`tags` object Key-value pairs to tag the deployment record.
`runtime_risks` array of strings A list of runtime risks associated with the deployment. Supported values are: `critical-resource`, `internet-exposed`, `lateral-movement`, `sensitive-data`
### [HTTP response status codes for "Set cluster deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records--status-codes)
Status code | Description
---|---
`200` | Deployment records created or updated successfully.
### [Code samples for "Set cluster deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#set-cluster-deployment-records--code-samples)
#### Request example
post/orgs/{org}/artifacts/metadata/deployment-record/cluster/{cluster}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/artifacts/metadata/deployment-record/cluster/CLUSTER \   -d '{"logical_environment":"prod","physical_environment":"pacific-east","deployments":[{"name":"awesome-image","digest":"sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72","version":"2.1.0","status":"deployed","deployment_name":"deployment-pod","tags":{"runtime-risk":"sensitive-data"}}]}'`
Deployment records created or updated successfully.
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "deployment_records": [     {       "id": 123,       "digest": "sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72",       "logical_environment": "prod",       "physical_environment": "pacific-east",       "cluster": "moda-1",       "deployment_name": "prod-deployment",       "tags": {         "data": "sensitive"       },       "created": "2011-01-26T19:14:43Z",       "updated_at": "2011-01-26T19:14:43Z",       "attestation_id": 456     }   ] }`
## [Create artifact metadata storage record](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record)
Create metadata storage records for artifacts associated with an organization. This endpoint will create a new artifact storage record on behalf of any artifact matching the provided digest and associated with a repository owned by the organization.
### [Fine-grained access tokens for "Create artifact metadata storage record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (write)
  * "Artifact metadata" repository permissions (write)


### [Parameters for "Create artifact metadata storage record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the artifact.
`digest` string Required The digest of the artifact (algorithm:hex-encoded-digest).
`version` string The artifact version.
`artifact_url` string The URL where the artifact is stored.
`path` string The path of the artifact.
`registry_url` string Required The base URL of the artifact registry.
`repository` string The repository name within the registry.
`status` string The status of the artifact (e.g., active, inactive). Default: `active` Can be one of: `active`, `eol`, `deleted`
`github_repository` string The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter.
### [HTTP response status codes for "Create artifact metadata storage record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record--status-codes)
Status code | Description
---|---
`200` | Artifact metadata storage record stored successfully.
### [Code samples for "Create artifact metadata storage record"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#create-artifact-metadata-storage-record--code-samples)
#### Request example
post/orgs/{org}/artifacts/metadata/storage-record
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/artifacts/metadata/storage-record \   -d '{"name":"libfoo","version":"1.2.3","digest":"sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72","artifact_url":"https://reg.example.com/artifactory/bar/libfoo-1.2.3","registry_url":"https://reg.example.com/artifactory/","repository":"bar","status":"active"}'`
Artifact metadata storage record stored successfully.
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "storage_records": [     {       "name": "libfoo",       "digest": "sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72",       "artifact_url": "https://reg.example.com/artifactory/bar/libfoo-1.2.3",       "registry_url": "https://reg.example.com/artifactory/",       "repository": "bar",       "status": "active",       "created_at": "2023-10-01T12:00:00Z",       "updated_at": "2023-10-01T12:00:00Z"     }   ] }`
## [List artifact deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records)
List deployment records for an artifact metadata associated with an organization.
### [Fine-grained access tokens for "List artifact deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (read)
  * "Artifact metadata" repository permissions (read)


### [Parameters for "List artifact deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`subject_digest` string Required The SHA256 digest of the artifact, in the form `sha256:HEX_DIGEST`.
### [HTTP response status codes for "List artifact deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records--status-codes)
Status code | Description
---|---
`200` | Successful response
### [Code samples for "List artifact deployment records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-deployment-records--code-samples)
#### Request example
get/orgs/{org}/artifacts/{subject_digest}/metadata/deployment-records
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/artifacts/SUBJECT_DIGEST/metadata/deployment-records`
Successful response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "deployment_records": [     {       "id": 123,       "digest": "sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72",       "logical_environment": "prod",       "physical_environment": "pacific-east",       "cluster": "moda-1",       "deployment_name": "prod-deployment",       "tags": {         "data": "sensitive"       },       "created": "2011-01-26T19:14:43Z",       "updated_at": "2011-01-26T19:14:43Z",       "attestation_id": 456     }   ] }`
## [List artifact storage records](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records)
List a collection of artifact storage records with a given subject digest that are associated with repositories owned by an organization.
The collection of storage records returned by this endpoint is filtered according to the authenticated user's permissions; if the authenticated user cannot read a repository, the attestations associated with that repository will not be included in the response. In addition, when using a fine-grained access token the `content:read` permission is required.
### [Fine-grained access tokens for "List artifact storage records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (read)
  * "Artifact metadata" repository permissions (read)


### [Parameters for "List artifact storage records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`subject_digest` string Required The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`.
### [HTTP response status codes for "List artifact storage records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List artifact storage records"](https://docs.github.com/en/rest/orgs/artifact-metadata?apiVersion=2022-11-28#list-artifact-storage-records--code-samples)
#### Request example
get/orgs/{org}/artifacts/{subject_digest}/metadata/storage-records
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/artifacts/SUBJECT_DIGEST/metadata/storage-records`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "storage_records": [     {       "name": "libfoo-1.2.3",       "digest": "sha256:1bb1e949e55dcefc6353e7b36c8897d2a107d8e8dca49d4e3c0ea8493fc0bc72",       "artifact_url": "https://reg.example.com/artifactory/bar/libfoo-1.2.3",       "registry_url": "https://reg.example.com/artifactory/",       "repository": "bar",       "status": "active",       "created_at": "2023-10-01T12:00:00Z",       "updated_at": "2023-10-01T12:00:00Z"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/artifact-metadata.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for artifact metadata - GitHub Docs
