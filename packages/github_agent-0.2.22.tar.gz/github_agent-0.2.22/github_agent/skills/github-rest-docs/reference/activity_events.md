[Skip to main content](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Activity](https://docs.github.com/en/rest/activity "Activity")/
  * [Events](https://docs.github.com/en/rest/activity/events "Events")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
      * [About GitHub events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#about-github-events)
      * [List public events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events)
      * [List public events for a network of repositories](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories)
      * [List public organization events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events)
      * [List repository events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events)
      * [List events for the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user)
      * [List organization events for the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user)
      * [List public events for a user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user)
      * [List events received by the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user)
      * [List public events received by a user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user)
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Activity](https://docs.github.com/en/rest/activity "Activity")/
  * [Events](https://docs.github.com/en/rest/activity/events "Events")


# REST API endpoints for events
Use the REST API to interact with GitHub events.
## [About GitHub events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#about-github-events)
GitHub events power the various activity streams on the site.
You can use the REST API to return different types of events triggered by activity on GitHub. For more information about the specific events that you can receive, see [GitHub event types](https://docs.github.com/en/webhooks-and-events/events/github-event-types). Endpoints for repository issues are also available. For more information, see [REST API endpoints for issue events](https://docs.github.com/en/rest/issues/events).
Events are optimized for polling with the "ETag" header. If no new events have been triggered, you will see a "304 Not Modified" response, and your current rate limit will be untouched. There is also an "X-Poll-Interval" header that specifies how often (in seconds) you are allowed to poll. In times of high server load, the time may increase. Please obey the header.
```
$ curl -I https://api.github.com/users/tater/events
> HTTP/2 200
> X-Poll-Interval: 60
> ETag: "a18c3bded88eb5dbb5c849a489412bf3"

# The quotes around the ETag value are important
$ curl -I https://api.github.com/users/tater/events \
$    -H 'If-None-Match: "a18c3bded88eb5dbb5c849a489412bf3"'
> HTTP/2 304
> X-Poll-Interval: 60

```

The timeline will include up to 300 events. Only events created within the past 30 days will be included. Events older than 30 days will not be included (even if the total number of events in the timeline is less than 300).
## [List public events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List public events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `15`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`503` | Service unavailable
### [Code samples for "List public events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events--code-samples)
#### Request example
get/events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084947",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-07T07:50:26Z"   } ]`
## [List public events for a network of repositories](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List public events for a network of repositories"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public events for a network of repositories"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public events for a network of repositories"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List public events for a network of repositories"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-network-of-repositories--code-samples)
#### Request example
get/networks/{owner}/{repo}/events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/networks/OWNER/REPO/events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22237752260",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-08T23:29:25Z"   } ]`
## [List public organization events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List public organization events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public organization events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public organization events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List public organization events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-organization-events--code-samples)
#### Request example
get/orgs/{org}/events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22237752260",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octo-org/octo-repo",       "url": "https://api.github.com/repos/octo-org/octo-repo"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-08T23:29:25Z",     "org": {       "id": 9919,       "login": "octo-org",       "gravatar_id": "",       "url": "https://api.github.com/orgs/octo-org",       "avatar_url": "https://avatars.githubusercontent.com/u/9919?"     }   },   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octo-org/octo-repo",       "url": "https://api.github.com/repos/octo-org/octo-repo"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z",     "org": {       "id": 9919,       "login": "octo-org",       "gravatar_id": "",       "url": "https://api.github.com/orgs/octo-org",       "avatar_url": "https://avatars.githubusercontent.com/u/9919?"     }   } ]`
## [List repository events](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List repository events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository events"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-repository-events--code-samples)
#### Request example
get/repos/{owner}/{repo}/events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22237752260",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-08T23:29:25Z"   } ]`
## [List events for the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user)
If you are authenticated as the given user, you will see your private events. Otherwise, you'll only see public events. _Optional_ : use the fine-grained token with following permission set to view private events: "Events" user permissions (read).
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-for-the-authenticated-user--code-samples)
#### Request example
get/users/{username}/events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084947",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": false,     "created_at": "2022-06-07T07:50:26Z"   } ]`
## [List organization events for the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user)
This is the user's organization dashboard. You must be authenticated as the user to view this.
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List organization events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Events" organization permissions (read)


### [Parameters for "List organization events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organization events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List organization events for the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-organization-events-for-the-authenticated-user--code-samples)
#### Request example
get/users/{username}/events/orgs/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/events/orgs/ORG`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octo-org/octo-repo",       "url": "https://api.github.com/repos/octo-org/octo-repo"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": false,     "created_at": "2022-06-09T12:47:28Z",     "org": {       "id": 9919,       "login": "octo-org",       "gravatar_id": "",       "url": "https://api.github.com/orgs/octo-org",       "avatar_url": "https://avatars.githubusercontent.com/u/9919?"     }   },   {     "id": "22196946742",     "type": "CreateEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octo-org/octo-repo",       "url": "https://api.github.com/repos/octo-org/octo-repo"     },     "payload": {       "ref": "master",       "ref_type": "repository",       "full_ref": "refs/heads/master",       "master_branch": "master",       "description": null,       "pusher_type": "user"     },     "public": false,     "created_at": "2022-06-07T07:50:26Z",     "org": {       "id": 9919,       "login": "octo-org",       "gravatar_id": "",       "url": "https://api.github.com/orgs/octo-org",       "avatar_url": "https://avatars.githubusercontent.com/u/9919?"     }   } ]`
## [List public events for a user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List public events for a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public events for a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public events for a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List public events for a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-for-a-user--code-samples)
#### Request example
get/users/{username}/events/public
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/events/public`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084947",     "type": "WatchEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "action": "started"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-08T23:29:25Z"   } ]`
## [List events received by the authenticated user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user)
These are events that you've received by watching repositories and following users. If you are authenticated as the given user, you will see private events. Otherwise, you'll only see public events.
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List events received by the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List events received by the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List events received by the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List events received by the authenticated user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-events-received-by-the-authenticated-user--code-samples)
#### Request example
get/users/{username}/received_events
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/received_events`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22196946742",     "type": "CreateEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "ref": "master",       "ref_type": "repository",       "full_ref": "refs/heads/master",       "master_branch": "master",       "description": null,       "pusher_type": "user"     },     "public": false,     "created_at": "2022-06-07T07:50:26Z"   } ]`
## [List public events received by a user](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user)
This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h.
### [Fine-grained access tokens for "List public events received by a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List public events received by a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List public events received by a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List public events received by a user"](https://docs.github.com/en/rest/activity/events?apiVersion=2022-11-28#list-public-events-received-by-a-user--code-samples)
#### Request example
get/users/{username}/received_events/public
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/received_events/public`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": "22249084964",     "type": "PushEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "repository_id": 1296269,       "push_id": 10115855396,       "ref": "refs/heads/master",       "head": "7a8f3ac80e2ad2f6842cb86f576d4bfe2c03e300",       "before": "883efe034920928c47fe18598c01249d1a9fdabd"     },     "public": true,     "created_at": "2022-06-09T12:47:28Z"   },   {     "id": "22196946742",     "type": "CreateEvent",     "actor": {       "id": 583231,       "login": "octocat",       "display_login": "octocat",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "avatar_url": "https://avatars.githubusercontent.com/u/583231?v=4"     },     "repo": {       "id": 1296269,       "name": "octocat/Hello-World",       "url": "https://api.github.com/repos/octocat/Hello-World"     },     "payload": {       "ref": "master",       "ref_type": "repository",       "full_ref": "refs/heads/master",       "master_branch": "master",       "description": null,       "pusher_type": "user"     },     "public": false,     "created_at": "2022-06-07T07:50:26Z"   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/activity/events.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for events - GitHub Docs
