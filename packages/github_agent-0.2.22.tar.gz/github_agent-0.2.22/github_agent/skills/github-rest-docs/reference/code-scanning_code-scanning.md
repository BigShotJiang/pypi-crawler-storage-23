[Skip to main content](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Code scanning](https://docs.github.com/en/rest/code-scanning "Code scanning")/
  * [Code scanning](https://docs.github.com/en/rest/code-scanning/code-scanning "Code scanning")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
      * [About code scanning](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#about-code-scanning)
      * [List code scanning alerts for an organization](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization)
      * [List code scanning alerts for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository)
      * [Get a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert)
      * [Update a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert)
      * [Get the status of an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert)
      * [Create an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert)
      * [Commit an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert)
      * [List instances of a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert)
      * [List code scanning analyses for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository)
      * [Get a code scanning analysis for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository)
      * [Delete a code scanning analysis from a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository)
      * [List CodeQL databases for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository)
      * [Get a CodeQL database for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository)
      * [Delete a CodeQL database](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database)
      * [Create a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis)
      * [Get the summary of a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis)
      * [Get the analysis status of a repository in a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis)
      * [Get a code scanning default setup configuration](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration)
      * [Update a code scanning default setup configuration](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration)
      * [Upload an analysis as SARIF data](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data)
      * [Get information about a SARIF upload](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload)
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Code scanning](https://docs.github.com/en/rest/code-scanning "Code scanning")/
  * [Code scanning](https://docs.github.com/en/rest/code-scanning/code-scanning "Code scanning")


# REST API endpoints for code scanning
Use the REST API to retrieve and update code scanning alerts from a repository.
## [About code scanning](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#about-code-scanning)
You can retrieve and update code scanning alerts from a repository. You can use the endpoints to create automated reports for the code scanning alerts in an organization or upload analysis results generated using offline code scanning tools. For more information, see [Scan code for vulnerabilities](https://docs.github.com/en/code-security/code-scanning).
## [List code scanning alerts for an organization](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization)
Lists code scanning alerts for the default branch for all eligible repositories in an organization. Eligible repositories are repositories that are owned by organizations that you own or for which you are a security manager. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."
The authenticated user must be an owner or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `security_events` or `repo`s cope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "List code scanning alerts for an organization"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "List code scanning alerts for an organization"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`tool_name` string The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
`tool_guid` string or null The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`state` string If specified, only code scanning alerts with this state will be returned. Can be one of: `open`, `closed`, `dismissed`, `fixed`
`sort` string The property by which to sort the results. Default: `created` Can be one of: `created`, `updated`
`severity` string If specified, only code scanning alerts with this severity will be returned. Can be one of: `critical`, `high`, `medium`, `low`, `warning`, `note`, `error`
`assignees` string Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`). Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
### [HTTP response status codes for "List code scanning alerts for an organization"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List code scanning alerts for an organization"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/code-scanning/alerts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-scanning/alerts`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "number": 4,     "created_at": "2020-02-13T12:29:18Z",     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/4",     "html_url": "https://github.com/octocat/hello-world/code-scanning/4",     "state": "open",     "dismissed_by": null,     "dismissed_at": null,     "dismissed_reason": null,     "dismissed_comment": null,     "rule": {       "id": "js/zipslip",       "severity": "error",       "tags": [         "security",         "external/cwe/cwe-022"       ],       "description": "Arbitrary file write during zip extraction",       "name": "js/zipslip"     },     "tool": {       "name": "CodeQL",       "guid": null,       "version": "2.4.0"     },     "most_recent_instance": {       "ref": "refs/heads/main",       "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "environment": "{}",       "state": "open",       "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",       "message": {         "text": "This path depends on a user-provided value."       },       "location": {         "path": "spec-main/api-session-spec.ts",         "start_line": 917,         "end_line": 917,         "start_column": 7,         "end_column": 18       },       "classifications": [         "test"       ]     },     "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/4/instances",     "repository": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks"     }   },   {     "number": 3,     "created_at": "2020-02-13T12:29:18Z",     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/3",     "html_url": "https://github.com/octocat/hello-world/code-scanning/3",     "state": "dismissed",     "dismissed_by": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "dismissed_at": "2020-02-14T12:29:18Z",     "dismissed_reason": "false positive",     "dismissed_comment": "This alert is not actually correct, because there's a sanitizer included in the library.",     "rule": {       "id": "js/zipslip",       "severity": "error",       "tags": [         "security",         "external/cwe/cwe-022"       ],       "description": "Arbitrary file write during zip extraction",       "name": "js/zipslip"     },     "tool": {       "name": "CodeQL",       "guid": null,       "version": "2.4.0"     },     "most_recent_instance": {       "ref": "refs/heads/main",       "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "environment": "{}",       "state": "open",       "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",       "message": {         "text": "This path depends on a user-provided value."       },       "location": {         "path": "lib/ab12-gen.js",         "start_line": 917,         "end_line": 917,         "start_column": 7,         "end_column": 18       },       "classifications": []     },     "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/3/instances",     "repository": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks"     }   } ]`
## [List code scanning alerts for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository)
Lists code scanning alerts.
The response includes a `most_recent_instance` object. This provides details of the most recent instance of this alert for the default branch (or for the specified Git reference if you used `ref` in the request).
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "List code scanning alerts for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "List code scanning alerts for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`tool_name` string The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
`tool_guid` string or null The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`ref` string The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
`pr` integer The number of the pull request for the results you want to list.
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`sort` string The property by which to sort the results. Default: `created` Can be one of: `created`, `updated`
`state` string If specified, only code scanning alerts with this state will be returned. Can be one of: `open`, `closed`, `dismissed`, `fixed`
`severity` string If specified, only code scanning alerts with this severity will be returned. Can be one of: `critical`, `high`, `medium`, `low`, `warning`, `note`, `error`
`assignees` string Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`). Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
### [HTTP response status codes for "List code scanning alerts for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List code scanning alerts for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-alerts-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/alerts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "number": 4,     "created_at": "2020-02-13T12:29:18Z",     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/4",     "html_url": "https://github.com/octocat/hello-world/code-scanning/4",     "state": "open",     "fixed_at": null,     "dismissed_by": null,     "dismissed_at": null,     "dismissed_reason": null,     "dismissed_comment": null,     "rule": {       "id": "js/zipslip",       "severity": "error",       "tags": [         "security",         "external/cwe/cwe-022"       ],       "description": "Arbitrary file write during zip extraction",       "name": "js/zipslip"     },     "tool": {       "name": "CodeQL",       "guid": null,       "version": "2.4.0"     },     "most_recent_instance": {       "ref": "refs/heads/main",       "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "environment": "{}",       "state": "open",       "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",       "message": {         "text": "This path depends on a user-provided value."       },       "location": {         "path": "spec-main/api-session-spec.ts",         "start_line": 917,         "end_line": 917,         "start_column": 7,         "end_column": 18       },       "classifications": [         "test"       ]     },     "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/4/instances"   },   {     "number": 3,     "created_at": "2020-02-13T12:29:18Z",     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/3",     "html_url": "https://github.com/octocat/hello-world/code-scanning/3",     "state": "dismissed",     "fixed_at": null,     "dismissed_by": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "dismissed_at": "2020-02-14T12:29:18Z",     "dismissed_reason": "false positive",     "dismissed_comment": "This alert is not actually correct, because there's a sanitizer included in the library.",     "rule": {       "id": "js/zipslip",       "severity": "error",       "tags": [         "security",         "external/cwe/cwe-022"       ],       "description": "Arbitrary file write during zip extraction",       "name": "js/zipslip"     },     "tool": {       "name": "CodeQL",       "guid": null,       "version": "2.4.0"     },     "most_recent_instance": {       "ref": "refs/heads/main",       "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",       "environment": "{}",       "state": "open",       "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",       "message": {         "text": "This path depends on a user-provided value."       },       "location": {         "path": "lib/ab12-gen.js",         "start_line": 917,         "end_line": 917,         "start_column": 7,         "end_column": 18       },       "classifications": []     },     "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/3/instances"   } ]`
## [Get a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert)
Gets a single code scanning alert.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "Get a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### [HTTP response status codes for "Get a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-alert--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "number": 42,   "created_at": "2020-06-19T11:21:34Z",   "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/42",   "html_url": "https://github.com/octocat/hello-world/code-scanning/42",   "state": "dismissed",   "fixed_at": null,   "dismissed_by": {     "login": "octocat",     "id": 54933897,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "dismissed_at": "2020-02-14T12:29:18Z",   "dismissed_reason": "false positive",   "dismissed_comment": "This alert is not actually correct, because there's a sanitizer included in the library.",   "rule": {     "id": "js/zipslip",     "severity": "error",     "security_severity_level": "high",     "description": "Arbitrary file write during zip extraction (\"Zip Slip\")",     "name": "js/zipslip",     "full_description": "Extracting files from a malicious zip archive without validating that the destination file path is within the destination directory can cause files outside the destination directory to be overwritten.",     "tags": [       "security",       "external/cwe/cwe-022"     ],     "help": "# Arbitrary file write during zip extraction (\"Zip Slip\")\\nExtracting files from a malicious zip archive without validating that the destination file path is within the destination directory can cause files outside the destination directory to be overwritten ...",     "help_uri": "https://codeql.github.com/"   },   "tool": {     "name": "CodeQL",     "guid": null,     "version": "2.4.0"   },   "most_recent_instance": {     "ref": "refs/heads/main",     "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "environment": "{}",     "state": "dismissed",     "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",     "message": {       "text": "This path depends on a user-provided value."     },     "location": {       "path": "spec-main/api-session-spec.ts",       "start_line": 917,       "end_line": 917,       "start_column": 7,       "end_column": 18     },     "classifications": [       "test"     ]   },   "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/42/instances" }`
## [Update a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert)
Updates the status of a single code scanning alert. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Update a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (write)


### [Parameters for "Update a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
Body parameters Name, Type, Description
---
`state` string Sets the state of the code scanning alert. You must provide `dismissed_reason` when you set the state to `dismissed`. Can be one of: `open`, `dismissed`
`dismissed_reason` string or null **Required when the state is dismissed.** The reason for dismissing or closing the alert. Can be one of: `false positive`, `won't fix`, `used in tests`, `_null_`
`dismissed_comment` string or null The dismissal comment associated with the dismissal of the alert.
`create_request` boolean If `true`, attempt to create an alert dismissal request.
`assignees` array of strings The list of users to assign to the code scanning alert. An empty array unassigns all previous assignees from the alert.
### [HTTP response status codes for "Update a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Update a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-alert--code-samples)
#### Request example
patch/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER \   -d '{"state":"dismissed","dismissed_reason":"false positive","dismissed_comment":"This alert is not actually correct, because there'\''s a sanitizer included in the library.","create_request":true}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "number": 42,   "created_at": "2020-08-25T21:28:36Z",   "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/42",   "html_url": "https://github.com/octocat/hello-world/code-scanning/42",   "state": "dismissed",   "fixed_at": null,   "dismissed_by": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "dismissed_at": "2020-09-02T22:34:56Z",   "dismissed_reason": "false positive",   "dismissed_comment": "This alert is not actually correct, because there's a sanitizer included in the library.",   "rule": {     "id": "js/zipslip",     "severity": "error",     "security_severity_level": "high",     "description": "Arbitrary file write during zip extraction (\"Zip Slip\")",     "name": "js/zipslip",     "full_description": "Extracting files from a malicious zip archive without validating that the destination file path is within the destination directory can cause files outside the destination directory to be overwritten.",     "tags": [       "security",       "external/cwe/cwe-022"     ],     "help": "# Arbitrary file write during zip extraction (\"Zip Slip\")\\nExtracting files from a malicious zip archive without validating that the destination file path is within the destination directory can cause files outside the destination directory to be overwritten ...",     "help_uri": "https://codeql.github.com/"   },   "tool": {     "name": "CodeQL",     "guid": null,     "version": "2.4.0"   },   "most_recent_instance": {     "ref": "refs/heads/main",     "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "environment": "{}",     "state": "dismissed",     "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",     "message": {       "text": "This path depends on a user-provided value."     },     "location": {       "path": "spec-main/api-session-spec.ts",       "start_line": 917,       "end_line": 917,       "start_column": 7,       "end_column": 18     },     "classifications": [       "test"     ]   },   "instances_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/alerts/42/instances" }`
## [Get the status of an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert)
Gets the status and description of an autofix for a code scanning alert.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get the status of an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "Get the status of an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### [HTTP response status codes for "Get the status of an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get the status of an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-status-of-an-autofix-for-a-code-scanning-alert--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER/autofix`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "status": "success",   "description": "This fixes an XSS vulnerability by escaping the user input.",   "started_at": "2024-02-14T12:29:18Z" }`
## [Create an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert)
Creates an autofix for a code scanning alert.
If a new autofix is to be created as a result of this request or is currently being generated, then this endpoint will return a 202 Accepted response.
If an autofix already exists for a given alert, then this endpoint will return a 200 OK response.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Create an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (write)


### [Parameters for "Create an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### [HTTP response status codes for "Create an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`200` | OK
`202` | Accepted
`400` | Bad Request
`403` | Response if the repository is archived, if GitHub Advanced Security is not enabled for this repository or if rate limit is exceeded
`404` | Resource not found
`422` | Unprocessable Entity
`503` | Service unavailable
### [Code samples for "Create an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-an-autofix-for-a-code-scanning-alert--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 202
post/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER/autofix`
OK
  * Example response
  * Response schema


`Status: 200`
`{   "status": "success",   "description": "This fixes an XSS vulnerability by escaping the user input.",   "started_at": "2024-02-14T12:29:18Z" }`
## [Commit an autofix for a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert)
Commits an autofix for a code scanning alert.
If an autofix is committed as a result of this request, then this endpoint will return a 201 Created response.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Commit an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Commit an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
Body parameters Name, Type, Description
---
`target_ref` string The Git reference of target branch for the commit. Branch needs to already exist. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
`message` string Commit message to be used.
### [HTTP response status codes for "Commit an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`201` | Created
`400` | Bad Request
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`422` | Unprocessable Entity
`503` | Service unavailable
### [Code samples for "Commit an autofix for a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#commit-an-autofix-for-a-code-scanning-alert--code-samples)
#### Request example
post/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix/commits
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER/autofix/commits \   -d '{"target_ref":"refs/heads/fix-bug","message":"Let'\''s fix this 🪲!"}'`
Created
  * Example response
  * Response schema


`Status: 201`
`{   "target_ref": "refs/heads/main",   "sha": "178f4f6090b3fccad4a65b3e83d076a622d59652" }`
## [List instances of a code scanning alert](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert)
Lists all instances of the specified code scanning alert.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "List instances of a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "List instances of a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`alert_number` integer Required The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`ref` string The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
`pr` integer The number of the pull request for the results you want to list.
### [HTTP response status codes for "List instances of a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List instances of a code scanning alert"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-instances-of-a-code-scanning-alert--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/instances
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/alerts/ALERT_NUMBER/instances`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "ref": "refs/heads/main",     "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "environment": "",     "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "state": "open",     "commit_sha": "39406e42cb832f683daa691dd652a8dc36ee8930",     "message": {       "text": "This path depends on a user-provided value."     },     "location": {       "path": "lib/ab12-gen.js",       "start_line": 917,       "end_line": 917,       "start_column": 7,       "end_column": 18     },     "classifications": [       "library"     ]   },   {     "ref": "refs/pull/3740/merge",     "analysis_key": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "environment": "",     "category": ".github/workflows/codeql-analysis.yml:CodeQL-Build",     "state": "fixed",     "commit_sha": "b09da05606e27f463a2b49287684b4ae777092f2",     "message": {       "text": "This suffix check is missing a length comparison to correctly handle lastIndexOf returning -1."     },     "location": {       "path": "app/script.js",       "start_line": 2,       "end_line": 2,       "start_column": 10,       "end_column": 50     },     "classifications": [       "source"     ]   } ]`
## [List code scanning analyses for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository)
Lists the details of all code scanning analyses for a repository, starting with the most recent. The response is paginated and you can use the `page` and `per_page` parameters to list the analyses you're interested in. By default 30 analyses are listed per page.
The `rules_count` field in the response give the number of rules that were run in the analysis. For very old analyses this data is not available, and `0` is returned in this field.
**Closing down notice:** The `tool_name` field is closing down and will, in future, not be included in the response for this endpoint. The example response reflects this change. The tool name can now be found inside the `tool` field.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "List code scanning analyses for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "List code scanning analyses for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`tool_name` string The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
`tool_guid` string or null The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`pr` integer The number of the pull request for the results you want to list.
`ref` string The Git reference for the analyses you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
`sarif_id` string Filter analyses belonging to the same SARIF upload.
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`sort` string The property by which to sort the results. Default: `created` Value: `created`
### [HTTP response status codes for "List code scanning analyses for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List code scanning analyses for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-code-scanning-analyses-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/analyses
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/analyses`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "ref": "refs/heads/main",     "commit_sha": "d99612c3e1f2970085cfbaeadf8f010ef69bad83",     "analysis_key": ".github/workflows/codeql-analysis.yml:analyze",     "environment": "{\"language\":\"python\"}",     "error": "",     "category": ".github/workflows/codeql-analysis.yml:analyze/language:python",     "created_at": "2020-08-27T15:05:21Z",     "results_count": 17,     "rules_count": 49,     "id": 201,     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses/201",     "sarif_id": "6c81cd8e-b078-4ac3-a3be-1dad7dbd0b53",     "tool": {       "name": "CodeQL",       "guid": null,       "version": "2.4.0"     },     "deletable": true,     "warning": ""   },   {     "ref": "refs/heads/my-branch",     "commit_sha": "c8cff6510d4d084fb1b4aa13b64b97ca12b07321",     "analysis_key": ".github/workflows/shiftleft.yml:build",     "environment": "{}",     "error": "",     "category": ".github/workflows/shiftleft.yml:build/",     "created_at": "2020-08-31T22:46:44Z",     "results_count": 17,     "rules_count": 32,     "id": 200,     "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses/200",     "sarif_id": "8981cd8e-b078-4ac3-a3be-1dad7dbd0b582",     "tool": {       "name": "Python Security Analysis",       "guid": null,       "version": "1.2.0"     },     "deletable": true,     "warning": ""   } ]`
## [Get a code scanning analysis for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository)
Gets a specified code scanning analysis for a repository.
The default JSON response contains fields that describe the analysis. This includes the Git reference and commit SHA to which the analysis relates, the datetime of the analysis, the name of the code scanning tool, and the number of alerts.
The `rules_count` field in the default response give the number of rules that were run in the analysis. For very old analyses this data is not available, and `0` is returned in this field.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/sarif+json`**: Instead of returning a summary of the analysis, this endpoint returns a subset of the analysis data that was uploaded. The data is formatted as[SARIF version 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/cs01/sarif-v2.1.0-cs01.html). It also returns additional data such as the `github/alertNumber` and `github/alertUrl` properties.


OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get a code scanning analysis for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "Get a code scanning analysis for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`analysis_id` integer Required The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation.
### [HTTP response status codes for "Get a code scanning analysis for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`422` | Response if analysis could not be processed
`503` | Service unavailable
### [Code samples for "Get a code scanning analysis for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-analysis-for-a-repository--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 (application/json) Example 2: Status Code 200 (application/sarif+json)
get/repos/{owner}/{repo}/code-scanning/analyses/{analysis_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/analyses/ANALYSIS_ID`
application/json response
  * Example response
  * Response schema


`Status: 200`
`{   "ref": "refs/heads/main",   "commit_sha": "c18c69115654ff0166991962832dc2bd7756e655",   "analysis_key": ".github/workflows/codeql-analysis.yml:analyze",   "environment": "{\"language\":\"javascript\"}",   "error": "",   "category": ".github/workflows/codeql-analysis.yml:analyze/language:javascript",   "created_at": "2021-01-13T11:55:49Z",   "results_count": 3,   "rules_count": 67,   "id": 3602840,   "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses/201",   "sarif_id": "47177e22-5596-11eb-80a1-c1e54ef945c6",   "tool": {     "name": "CodeQL",     "guid": null,     "version": "2.4.0"   },   "deletable": true,   "warning": "" }`
## [Delete a code scanning analysis from a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository)
Deletes a specified code scanning analysis from a repository.
You can delete one analysis at a time. To delete a series of analyses, start with the most recent analysis and work backwards. Conceptually, the process is similar to the undo function in a text editor.
When you list the analyses for a repository, one or more will be identified as deletable in the response:
```
"deletable": true

```

An analysis is deletable when it's the most recent in a set of analyses. Typically, a repository will have multiple sets of analyses for each enabled code scanning tool, where a set is determined by a unique combination of analysis values:
  * `ref`
  * `tool`
  * `category`


If you attempt to delete an analysis that is not the most recent in a set, you'll get a 400 response with the message:
```
Analysis specified is not deletable.

```

The response from a successful `DELETE` operation provides you with two alternative URLs for deleting the next analysis in the set: `next_analysis_url` and `confirm_delete_url`. Use the `next_analysis_url` URL if you want to avoid accidentally deleting the final analysis in a set. This is a useful option if you want to preserve at least one analysis for the specified tool in your repository. Use the `confirm_delete_url` URL if you are content to remove all analyses for a tool. When you delete the last analysis in a set, the value of `next_analysis_url` and `confirm_delete_url` in the 200 response is `null`.
As an example of the deletion process, let's imagine that you added a workflow that configured a particular code scanning tool to analyze the code in a repository. This tool has added 15 analyses: 10 on the default branch, and another 5 on a topic branch. You therefore have two separate sets of analyses for this tool. You've now decided that you want to remove all of the analyses for the tool. To do this you must make 15 separate deletion requests. To start, you must find an analysis that's identified as deletable. Each set of analyses always has one that's identified as deletable. Having found the deletable analysis for one of the two sets, delete this analysis and then continue deleting the next analysis in the set until they're all deleted. Then repeat the process for the second set. The procedure therefore consists of a nested loop:
**Outer loop** :
  * List the analyses for the repository, filtered by tool.
  * Parse this list to find a deletable analysis. If found:
**Inner loop** :
    * Delete the identified analysis.
    * Parse the response for the value of `confirm_delete_url` and, if found, use this in the next iteration.


The above process assumes that you want to remove all trace of the tool's analyses from the GitHub user interface, for the specified repository, and it therefore uses the `confirm_delete_url` value. Alternatively, you could use the `next_analysis_url` value, which would leave the last analysis in each set undeleted to avoid removing a tool's analysis entirely.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Delete a code scanning analysis from a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (write)


### [Parameters for "Delete a code scanning analysis from a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`analysis_id` integer Required The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation.
Query parameters Name, Type, Description
---
`confirm_delete` string or null Allow deletion if the specified analysis is the last in a set. If you attempt to delete the final analysis in a set without setting this parameter to `true`, you'll get a 400 response with the message: `Analysis is last of its type and deletion may result in the loss of historical alert data. Please specify confirm_delete.`
### [HTTP response status codes for "Delete a code scanning analysis from a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Delete a code scanning analysis from a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-code-scanning-analysis-from-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}/code-scanning/analyses/{analysis_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/analyses/ANALYSIS_ID`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "next_analysis_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses/41",   "confirm_delete_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses/41?confirm_delete" }`
## [List CodeQL databases for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository)
Lists the CodeQL databases that are available in a repository.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "List CodeQL databases for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List CodeQL databases for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "List CodeQL databases for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "List CodeQL databases for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#list-codeql-databases-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/codeql/databases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/databases`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "name": "database.zip",     "language": "java",     "uploader": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "content_type": "application/zip",     "size": 1024,     "created_at": "2022-09-12T12:14:32Z",     "updated_at": "2022-09-12T12:14:32Z",     "url": "https://api.github.com/repos/octocat/Hello-World/code-scanning/codeql/databases/java",     "commit_oid": "1927de39fefa25a9d0e64e3f540ff824a72f538c"   },   {     "id": 2,     "name": "database.zip",     "language": "ruby",     "uploader": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "content_type": "application/zip",     "size": 1024,     "created_at": "2022-09-12T12:14:32Z",     "updated_at": "2022-09-12T12:14:32Z",     "url": "https://api.github.com/repos/octocat/Hello-World/code-scanning/codeql/databases/ruby",     "commit_oid": "1927de39fefa25a9d0e64e3f540ff824a72f538c"   } ]`
## [Get a CodeQL database for a repository](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository)
Gets a CodeQL database for a language in a repository.
By default this endpoint returns JSON metadata about the CodeQL database. To download the CodeQL database binary content, set the `Accept` header of the request to [`application/zip`](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types), and make sure your HTTP client is configured to follow redirects or use the `Location` header to make a second request to get the redirect URL.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get a CodeQL database for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a CodeQL database for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`language` string Required The language of the CodeQL database.
### [HTTP response status codes for "Get a CodeQL database for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`302` | Found
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get a CodeQL database for a repository"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-codeql-database-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/codeql/databases/{language}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/databases/LANGUAGE`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "name": "database.zip",   "language": "java",   "uploader": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "content_type": "application/zip",   "size": 1024,   "created_at": "2022-09-12T12:14:32Z",   "updated_at": "2022-09-12T12:14:32Z",   "url": "https://api.github.com/repos/octocat/Hello-World/code-scanning/codeql/databases/java",   "commit_oid": "1927de39fefa25a9d0e64e3f540ff824a72f538c" }`
## [Delete a CodeQL database](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database)
Deletes a CodeQL database for a language in a repository.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Delete a CodeQL database"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Delete a CodeQL database"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`language` string Required The language of the CodeQL database.
### [HTTP response status codes for "Delete a CodeQL database"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database--status-codes)
Status code | Description
---|---
`204` | No Content
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Delete a CodeQL database"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#delete-a-codeql-database--code-samples)
#### Request example
delete/repos/{owner}/{repo}/code-scanning/codeql/databases/{language}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/databases/LANGUAGE`
Response
`Status: 204`
## [Create a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis)
Creates a new CodeQL variant analysis, which will run a CodeQL query against one or more repositories.
Get started by learning more about [running CodeQL queries at scale with Multi-Repository Variant Analysis](https://docs.github.com/code-security/codeql-for-vs-code/getting-started-with-codeql-for-vs-code/running-codeql-queries-at-scale-with-multi-repository-variant-analysis).
Use the `owner` and `repo` parameters in the URL to specify the controller repository that will be used for running GitHub Actions workflows and storing the results of the CodeQL variant analysis.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Create a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Create a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis--status-codes)
Status code | Description
---|---
`201` | Variant analysis submitted for processing
`404` | Resource not found
`422` | Unable to process variant analysis submission
`503` | Service unavailable
### [Code samples for "Create a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#create-a-codeql-variant-analysis--code-samples)
#### Request examples
Select the example typeUsing the "repositories" field. "query_pack" is abridged for brevity. Using the "repository_owners" field. "query_pack" is abridged. Using the "repository_lists" field. "query_pack" is abridged.
post/repos/{owner}/{repo}/code-scanning/codeql/variant-analyses
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/variant-analyses \   -d '{"language":"csharp","query_pack":"aGVsbG8=","repositories":["octocat/Hello-World","octocat/example"]}'`
Response for a successful variant analysis submission
  * Example response
  * Response schema


`Status: 201`
`{   "summary": "Default response",   "value": {     "id": 1,     "controller_repo": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks"     },     "actor": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "query_language": "python",     "query_pack_url": "https://www.example.com",     "created_at": "2022-09-12T12:14:32Z",     "updated_at": "2022-09-12T12:14:32Z",     "completed_at": "2022-09-12T13:15:33Z",     "status": "succeeded",     "actions_workflow_run_id": 3453588,     "scanned_repositories": [       {         "repository": {           "id": 1296269,           "name": "Hello-World",           "full_name": "octocat/Hello-World",           "private": false         },         "analysis_status": "succeeded",         "result_count": 532,         "artifact_size_in_bytes": 12345       }     ],     "skipped_repositories": {       "access_mismatch_repos": {         "repository_count": 2,         "repositories": [           {             "id": 1,             "name": "octo-repo1",             "full_name": "octo-org/octo-repo1",             "private": false           },           {             "id": 2,             "name": "octo-repo2",             "full_name": "octo-org/octo-repo2",             "private": false           }         ]       },       "not_found_repos": {         "repository_count": 3,         "repository_full_names": [           "octo-org/octo-repo4",           "octo-org/octo-repo5",           "octo-org/octo-repo6"         ]       },       "no_codeql_db_repos": {         "repository_count": 2,         "repositories": [           {             "id": 7,             "name": "octo-repo7",             "full_name": "octo-org/octo-repo7",             "private": false           },           {             "id": 8,             "name": "octo-repo8",             "full_name": "octo-org/octo-repo8",             "private": false           }         ]       },       "over_limit_repos": {         "repository_count": 2,         "repositories": [           {             "id": 9,             "name": "octo-repo9",             "full_name": "octo-org/octo-repo9",             "private": false           },           {             "id": 10,             "name": "octo-repo10",             "full_name": "octo-org/octo-repo10",             "private": false           }         ]       }     }   } }`
## [Get the summary of a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis)
Gets the summary of a CodeQL variant analysis.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get the summary of a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get the summary of a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`codeql_variant_analysis_id` integer Required The unique identifier of the variant analysis.
### [HTTP response status codes for "Get the summary of a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get the summary of a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-summary-of-a-codeql-variant-analysis--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/variant-analyses/CODEQL_VARIANT_ANALYSIS_ID`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "controller_repo": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks"   },   "actor": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "query_language": "python",   "query_pack_url": "https://www.example.com",   "created_at": "2022-09-12T12:14:32Z",   "updated_at": "2022-09-12T12:14:32Z",   "completed_at": "2022-09-12T13:15:33Z",   "status": "succeeded",   "actions_workflow_run_id": 3453588,   "scanned_repositories": [     {       "repository": {         "id": 1296269,         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "private": false       },       "analysis_status": "succeeded",       "result_count": 532,       "artifact_size_in_bytes": 12345     }   ],   "skipped_repositories": {     "access_mismatch_repos": {       "repository_count": 2,       "repositories": [         {           "id": 1,           "name": "octo-repo1",           "full_name": "octo-org/octo-repo1",           "private": false         },         {           "id": 2,           "name": "octo-repo2",           "full_name": "octo-org/octo-repo2",           "private": false         }       ]     },     "not_found_repos": {       "repository_count": 3,       "repository_full_names": [         "octo-org/octo-repo4",         "octo-org/octo-repo5",         "octo-org/octo-repo6"       ]     },     "no_codeql_db_repos": {       "repository_count": 2,       "repositories": [         {           "id": 7,           "name": "octo-repo7",           "full_name": "octo-org/octo-repo7",           "private": false         },         {           "id": 8,           "name": "octo-repo8",           "full_name": "octo-org/octo-repo8",           "private": false         }       ]     },     "over_limit_repos": {       "repository_count": 2,       "repositories": [         {           "id": 9,           "name": "octo-repo9",           "full_name": "octo-org/octo-repo9",           "private": false         },         {           "id": 10,           "name": "octo-repo10",           "full_name": "octo-org/octo-repo10",           "private": false         }       ]     }   } }`
## [Get the analysis status of a repository in a CodeQL variant analysis](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis)
Gets the analysis status of a repository in a CodeQL variant analysis.
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get the analysis status of a repository in a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


### [Parameters for "Get the analysis status of a repository in a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the controller repository.
`codeql_variant_analysis_id` integer Required The ID of the variant analysis.
`repo_owner` string Required The account owner of the variant analysis repository. The name is not case sensitive.
`repo_name` string Required The name of the variant analysis repository.
### [HTTP response status codes for "Get the analysis status of a repository in a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get the analysis status of a repository in a CodeQL variant analysis"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-the-analysis-status-of-a-repository-in-a-codeql-variant-analysis--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id}/repos/{repo_owner}/{repo_name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/codeql/variant-analyses/CODEQL_VARIANT_ANALYSIS_ID/repos/REPO_OWNER/REPO_NAME`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks"   },   "analysis_status": "succeeded",   "artifact_size_in_bytes": 12345,   "result_count": 532,   "database_commit_sha": "2d870c2a717a524627af38fa2da382188a096f90",   "source_location_prefix": "/",   "artifact_url": "https://example.com" }`
## [Get a code scanning default setup configuration](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration)
Gets a code scanning default setup configuration.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`503` | Service unavailable
### [Code samples for "Get a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-a-code-scanning-default-setup-configuration--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/default-setup
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/default-setup`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "state": "configured",   "languages": [     "ruby",     "python"   ],   "query_suite": "default",   "threat_model": "remote",   "updated_at": "2023-01-19T11:21:34Z",   "schedule": "weekly" }`
## [Update a code scanning default setup configuration](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration)
Updates a code scanning default setup configuration.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Update a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`state` string The desired state of code scanning default setup. Can be one of: `configured`, `not-configured`
`runner_type` string Runner type to be used. Can be one of: `standard`, `labeled`
`runner_label` string or null Runner label to be used if the runner type is labeled.
`query_suite` string CodeQL query suite to be used. Can be one of: `default`, `extended`
`threat_model` string Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input. Can be one of: `remote`, `remote_and_local`
`languages` array of strings CodeQL languages to be analyzed. Supported values are: `actions`, `c-cpp`, `csharp`, `go`, `java-kotlin`, `javascript-typescript`, `python`, `ruby`, `swift`
### [HTTP response status codes for "Update a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration--status-codes)
Status code | Description
---|---
`200` | OK
`202` | Accepted
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`409` | Response if there is already a validation run in progress with a different default setup configuration
`422` | Response if the configuration change cannot be made because the repository is not in the required state
`503` | Service unavailable
### [Code samples for "Update a code scanning default setup configuration"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#update-a-code-scanning-default-setup-configuration--code-samples)
#### Request example
patch/repos/{owner}/{repo}/code-scanning/default-setup
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/default-setup \   -d '{"state":"configured","threat_model":"remote_and_local"}'`
Response
  * Example response
  * Response schema


`Status: 202`
`{   "run_id": 42,   "run_url": "https://api.github.com/repos/octoorg/octocat/actions/runs/42" }`
## [Upload an analysis as SARIF data](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data)
Uploads SARIF data containing the results of a code scanning analysis to make the results available in a repository. For troubleshooting information, see "[Troubleshooting SARIF uploads](https://docs.github.com/code-security/code-scanning/troubleshooting-sarif)."
There are two places where you can upload code scanning results.
  * If you upload to a pull request, for example `--ref refs/pull/42/merge` or `--ref refs/pull/42/head`, then the results appear as alerts in a pull request check. For more information, see "[Triaging code scanning alerts in pull requests](https://docs.github.com/code-security/secure-coding/triaging-code-scanning-alerts-in-pull-requests)."
  * If you upload to a branch, for example `--ref refs/heads/my-branch`, then the results appear in the **Security** tab for your repository. For more information, see "[Managing code scanning alerts for your repository](https://docs.github.com/code-security/secure-coding/managing-code-scanning-alerts-for-your-repository#viewing-the-alerts-for-a-repository)."


You must compress the SARIF-formatted analysis data that you want to upload, using `gzip`, and then encode it as a Base64 format string. For example:
```
gzip -c analysis-data.sarif | base64 -w0

```

SARIF upload supports a maximum number of entries per the following data objects, and an analysis will be rejected if any of these objects is above its maximum value. For some objects, there are additional values over which the entries will be ignored while keeping the most important entries whenever applicable. To get the most out of your analysis when it includes data above the supported limits, try to optimize the analysis configuration. For example, for the CodeQL tool, identify and remove the most noisy queries. For more information, see "[SARIF results exceed one or more limits](https://docs.github.com/code-security/code-scanning/troubleshooting-sarif/results-exceed-limit)."
**SARIF data** | **Maximum values** | **Additional limits**
---|---|---
Runs per file | 20 |
Results per run | 25,000 | Only the top 5,000 results will be included, prioritized by severity.
Rules per run | 25,000 |
Tool extensions per run | 100 |
Thread Flow Locations per result | 10,000 | Only the top 1,000 Thread Flow Locations will be included, using prioritization.
Location per result | 1,000 | Only 100 locations will be included.
Tags per rule | 20 | Only 10 tags will be included.
The `202 Accepted` response includes an `id` value. You can use this ID to check the status of the upload by using it in the `/sarifs/{sarif_id}` endpoint. For more information, see "[Get information about a SARIF upload](https://docs.github.com/rest/code-scanning/code-scanning#get-information-about-a-sarif-upload)."
OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
This endpoint is limited to 1,000 requests per hour for each user or app installation calling it.
### [Fine-grained access tokens for "Upload an analysis as SARIF data"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (write)


### [Parameters for "Upload an analysis as SARIF data"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`commit_sha` string Required The SHA of the commit to which the analysis you are uploading relates.
`ref` string Required The full Git reference, formatted as `refs/heads/<branch name>`, `refs/tags/<tag>`, `refs/pull/<number>/merge`, or `refs/pull/<number>/head`.
`sarif` string Required A Base64 string representing the SARIF file to upload. You must first compress your SARIF file using [`gzip`](http://www.gnu.org/software/gzip/manual/gzip.html) and then translate the contents of the file into a Base64 encoding string. For more information, see "[SARIF support for code scanning](https://docs.github.com/code-security/secure-coding/sarif-support-for-code-scanning)."
`checkout_uri` string The base directory used in the analysis, as it appears in the SARIF file. This property is used to convert file paths from absolute to relative, so that alerts can be mapped to their correct location in the repository.
`started_at` string The time that the analysis run began. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`tool_name` string The name of the tool used to generate the code scanning analysis. If this parameter is not used, the tool name defaults to "API". If the uploaded SARIF contains a tool GUID, this will be available for filtering using the `tool_guid` parameter of operations such as `GET /repos/{owner}/{repo}/code-scanning/alerts`.
`validate` boolean Whether the SARIF file will be validated according to the code scanning specifications. This parameter is intended to help integrators ensure that the uploaded SARIF files are correctly rendered by code scanning.
### [HTTP response status codes for "Upload an analysis as SARIF data"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data--status-codes)
Status code | Description
---|---
`202` | Accepted
`400` | Bad Request if the sarif field is invalid
`403` | Response if the repository is archived or if GitHub Advanced Security is not enabled for this repository
`404` | Resource not found
`413` | Payload Too Large if the sarif field is too large
`503` | Service unavailable
### [Code samples for "Upload an analysis as SARIF data"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#upload-an-analysis-as-sarif-data--code-samples)
#### Request example
post/repos/{owner}/{repo}/code-scanning/sarifs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/sarifs \   -d '{"commit_sha":"4b6472266afd7b471e86085a6659e8c7f2b119da","ref":"refs/heads/master","sarif":"H4sICMLGdF4AA2V4YW1wbGUuc2FyaWYAvVjdbts2FL7PUxDCijaA/CM7iRNfLkPXYgHSNstumlzQ0pHFVCI1korjFgH2ONtr7Ul2KFmy/mOn6QIkjsjDw0/nfN85NL8dEGL9pNwAImqRObECrWM1H40kXQ2XTAfJIlEgXcE1cD10RTQSVDE10K4aKSqZP1AxuKOIKg1ydJU60jSfSh8Hk6EzHA/vlOCWbfa7B6kYPpj90rlsWCZcmbHP5Bs+4oAWIjQD2SMOeJLh2vIQDnIaQerqXHjw8YIgxohybxAyDsS4cAPKsp03K4RcUs6+Up2D+JXpd8mibKIQN9fM/aMCdbyBujGSSQgVxJtx5qX2d2qUcIweQhEuDQf3GBO6CKHkogx/N3MVCKl/AeVKFuf4y5ubsMGDTj1ep+5I7sgmLIpxtU38hLtmMRGSuCFVyip5eKzs5ydh+LztVL6f2m6oih1BkYiuyQIIJWodxVpERPj4sEiWBNNH8EWT0DMG8EAjzKVHXCrB4FkPu/F64NMk1OeC+2yZSNoBOoR7CC0EzYWGbm+xFDFIzbI011+cLjfZtyJkmMZfumAh02uL3NpV2y+MZ6RAjxibyKrNxxJcVjANSb4eBGwZ1M0KsuyR2poLr5rMl8vaDSeVn6eTWEO2j2xIEcmhwlTKNOi4GMOI8gfuZYkvJ7b4v5Tiumyz7RnHeodFzpS8ASIZCH/AYdWi2z3sG8JtFxJ6fF9yR9CdifBr9Pd6d5V2+zbJKjjCFGGmsHuYFy2ytJq9tUxcLSRSQecppOGKrpUxYfxefMEFK+wOGa4hudQByBVT0L+EKtyACxnRsABhEx1QjVDs1KNI9MbpnhqfE45B6FJvu3hRu5VRU9MhZLmK7fqkKyQSTHNoyMqUFMqXCV3CwAeqEwmVokraK8IuBaGvHjQ0gMYrKjnjyw7uk9uD8tgmsBbFMPnU1bV2ZhkJNkuolUiWys3UPWzs5aaIUz9TBe8zMb+6+nT+6fLy91dlE3xzeDDT4zYszb0bW6NjJd0Rvn2EnLvWLFSdKPpBzInzfRgu8ETyMcH8nIfMnJCeC2PyfTA+UKngcnGH7Hw2hGkVQs5YlIRCtdWZYQ4/73es2JlxkfViOEIhoWJq5Oo6UBBfiKIqFBWhiE3jJGbFwVoxBHTRSuIS67sMeplei24X20shLjG+8gqbKC/bESiNMC+wd5q5id0yeS7CJEqXzmrTWNq3k05l84P6f4/bEmXFJjI0fIt1BGQssUnUDkBYeVhE5TqPnMH3jqogDcP0zKcTgLPTMSzOjhbjuVOmW23l1fYNStulfo6sXlFsGLhbDy5RECPRYGCTgOj2bd4nUQEivEd0H7KKYxqnEhFohuur3a3UPskbH/+Yg0+M5P2MHRJu3ziHh3Z2NCrWt3XF1rWTw8Ne/pfbWYXnDSE0SNZQQt1i18q7te2vOhu7ehWuvVyeu0wbLZi24mhoo6aOOTltzG/lgdVvVoXQq5V+pewkFIzL8fjEcadT55jOjpzFzHuOTtDNrMkJPMVQDd7F09RID72O/UPZ0tmctqZ7kWX6EmSZnDpP8GU67SXM8XE3YSrxbKsx6UReZ4y6n/FVZfJjs9Z7stma75W5yQtkzjk5eSJxk1lv4o7+j8TlhaJ2lsKWZO6lruDPBLib3x5ZN/KGWzZ+pn///evv7OOf4iIBv3oY9L/l1wiJ9p0Tc+F1zZnOE9NxXWEus6IQhr5pMfoqxi8WPsuu0azsns4UC6WzNzHIzbeEx4P/AJ3SefgcFAAA"}'`
Default response
  * Example response
  * Response schema


`Status: 202`
`{   "id": "47177e22-5596-11eb-80a1-c1e54ef945c6",   "url": "https://api.github.com/repos/octocat/hello-world/code-scanning/sarifs/47177e22-5596-11eb-80a1-c1e54ef945c6" }`
## [Get information about a SARIF upload](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload)
Gets information about a SARIF upload, including the status and the URL of the analysis that was uploaded so that you can retrieve details of the analysis. For more information, see "[Get a code scanning analysis for a repository](https://docs.github.com/rest/code-scanning/code-scanning#get-a-code-scanning-analysis-for-a-repository)." OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories.
### [Fine-grained access tokens for "Get information about a SARIF upload"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Code scanning alerts" repository permissions (read)


### [Parameters for "Get information about a SARIF upload"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`sarif_id` string Required The SARIF ID obtained after uploading.
### [HTTP response status codes for "Get information about a SARIF upload"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Response if GitHub Advanced Security is not enabled for this repository
`404` | Not Found if the sarif id does not match any upload
`503` | Service unavailable
### [Code samples for "Get information about a SARIF upload"](https://docs.github.com/en/rest/code-scanning/code-scanning?apiVersion=2022-11-28#get-information-about-a-sarif-upload--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-scanning/sarifs/{sarif_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-scanning/sarifs/SARIF_ID`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "processing_status": "complete",   "analyses_url": "https://api.github.com/repos/octocat/hello-world/code-scanning/analyses?sarif_id=47177e22-5596-11eb-80a1-c1e54ef945c6" }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/code-scanning/code-scanning.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for code scanning - GitHub Docs
