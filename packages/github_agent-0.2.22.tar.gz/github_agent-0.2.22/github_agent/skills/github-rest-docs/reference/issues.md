[Skip to main content](https://docs.github.com/en/rest/issues?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Issues](https://docs.github.com/en/rest/issues "Issues")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Issues](https://docs.github.com/en/rest/issues "Issues")


# REST API endpoints for issues
Use the REST API to view and manage issues, including issue assignees, comments, labels, and milestones.
  * [REST API endpoints for issues](https://docs.github.com/en/rest/issues/issues)
    * [List issues assigned to the authenticated user](https://docs.github.com/en/rest/issues/issues#list-issues-assigned-to-the-authenticated-user)
    * [List organization issues assigned to the authenticated user](https://docs.github.com/en/rest/issues/issues#list-organization-issues-assigned-to-the-authenticated-user)
    * [List repository issues](https://docs.github.com/en/rest/issues/issues#list-repository-issues)
    * [Create an issue](https://docs.github.com/en/rest/issues/issues#create-an-issue)
    * [Get an issue](https://docs.github.com/en/rest/issues/issues#get-an-issue)
    * [Update an issue](https://docs.github.com/en/rest/issues/issues#update-an-issue)
    * [Lock an issue](https://docs.github.com/en/rest/issues/issues#lock-an-issue)
    * [Unlock an issue](https://docs.github.com/en/rest/issues/issues#unlock-an-issue)
    * [List user account issues assigned to the authenticated user](https://docs.github.com/en/rest/issues/issues#list-user-account-issues-assigned-to-the-authenticated-user)
  * [REST API endpoints for issue assignees](https://docs.github.com/en/rest/issues/assignees)
    * [List assignees](https://docs.github.com/en/rest/issues/assignees#list-assignees)
    * [Check if a user can be assigned](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned)
    * [Add assignees to an issue](https://docs.github.com/en/rest/issues/assignees#add-assignees-to-an-issue)
    * [Remove assignees from an issue](https://docs.github.com/en/rest/issues/assignees#remove-assignees-from-an-issue)
    * [Check if a user can be assigned to a issue](https://docs.github.com/en/rest/issues/assignees#check-if-a-user-can-be-assigned-to-a-issue)
  * [REST API endpoints for issue comments](https://docs.github.com/en/rest/issues/comments)
    * [List issue comments for a repository](https://docs.github.com/en/rest/issues/comments#list-issue-comments-for-a-repository)
    * [Get an issue comment](https://docs.github.com/en/rest/issues/comments#get-an-issue-comment)
    * [Update an issue comment](https://docs.github.com/en/rest/issues/comments#update-an-issue-comment)
    * [Delete an issue comment](https://docs.github.com/en/rest/issues/comments#delete-an-issue-comment)
    * [Pin an issue comment](https://docs.github.com/en/rest/issues/comments#pin-an-issue-comment)
    * [Unpin an issue comment](https://docs.github.com/en/rest/issues/comments#unpin-an-issue-comment)
    * [List issue comments](https://docs.github.com/en/rest/issues/comments#list-issue-comments)
    * [Create an issue comment](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment)
  * [REST API endpoints for issue events](https://docs.github.com/en/rest/issues/events)
    * [List issue events for a repository](https://docs.github.com/en/rest/issues/events#list-issue-events-for-a-repository)
    * [Get an issue event](https://docs.github.com/en/rest/issues/events#get-an-issue-event)
    * [List issue events](https://docs.github.com/en/rest/issues/events#list-issue-events)
  * [REST API endpoints for issue dependencies](https://docs.github.com/en/rest/issues/issue-dependencies)
    * [List dependencies an issue is blocked by](https://docs.github.com/en/rest/issues/issue-dependencies#list-dependencies-an-issue-is-blocked-by)
    * [Add a dependency an issue is blocked by](https://docs.github.com/en/rest/issues/issue-dependencies#add-a-dependency-an-issue-is-blocked-by)
    * [Remove dependency an issue is blocked by](https://docs.github.com/en/rest/issues/issue-dependencies#remove-dependency-an-issue-is-blocked-by)
    * [List dependencies an issue is blocking](https://docs.github.com/en/rest/issues/issue-dependencies#list-dependencies-an-issue-is-blocking)
  * [REST API endpoints for labels](https://docs.github.com/en/rest/issues/labels)
    * [List labels for an issue](https://docs.github.com/en/rest/issues/labels#list-labels-for-an-issue)
    * [Add labels to an issue](https://docs.github.com/en/rest/issues/labels#add-labels-to-an-issue)
    * [Set labels for an issue](https://docs.github.com/en/rest/issues/labels#set-labels-for-an-issue)
    * [Remove all labels from an issue](https://docs.github.com/en/rest/issues/labels#remove-all-labels-from-an-issue)
    * [Remove a label from an issue](https://docs.github.com/en/rest/issues/labels#remove-a-label-from-an-issue)
    * [List labels for a repository](https://docs.github.com/en/rest/issues/labels#list-labels-for-a-repository)
    * [Create a label](https://docs.github.com/en/rest/issues/labels#create-a-label)
    * [Get a label](https://docs.github.com/en/rest/issues/labels#get-a-label)
    * [Update a label](https://docs.github.com/en/rest/issues/labels#update-a-label)
    * [Delete a label](https://docs.github.com/en/rest/issues/labels#delete-a-label)
    * [List labels for issues in a milestone](https://docs.github.com/en/rest/issues/labels#list-labels-for-issues-in-a-milestone)
  * [REST API endpoints for milestones](https://docs.github.com/en/rest/issues/milestones)
    * [List milestones](https://docs.github.com/en/rest/issues/milestones#list-milestones)
    * [Create a milestone](https://docs.github.com/en/rest/issues/milestones#create-a-milestone)
    * [Get a milestone](https://docs.github.com/en/rest/issues/milestones#get-a-milestone)
    * [Update a milestone](https://docs.github.com/en/rest/issues/milestones#update-a-milestone)
    * [Delete a milestone](https://docs.github.com/en/rest/issues/milestones#delete-a-milestone)
  * [REST API endpoints for sub-issues](https://docs.github.com/en/rest/issues/sub-issues)
    * [Get parent issue](https://docs.github.com/en/rest/issues/sub-issues#get-parent-issue)
    * [Remove sub-issue](https://docs.github.com/en/rest/issues/sub-issues#remove-sub-issue)
    * [List sub-issues](https://docs.github.com/en/rest/issues/sub-issues#list-sub-issues)
    * [Add sub-issue](https://docs.github.com/en/rest/issues/sub-issues#add-sub-issue)
    * [Reprioritize sub-issue](https://docs.github.com/en/rest/issues/sub-issues#reprioritize-sub-issue)
  * [REST API endpoints for timeline events](https://docs.github.com/en/rest/issues/timeline)
    * [List timeline events for an issue](https://docs.github.com/en/rest/issues/timeline#list-timeline-events-for-an-issue)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/issues/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for issues - GitHub Docs
