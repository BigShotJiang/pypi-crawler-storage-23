[Skip to main content](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Code security settings](https://docs.github.com/en/rest/code-security "Code security settings")/
  * [Configurations](https://docs.github.com/en/rest/code-security/configurations "Configurations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
      * [Get code security configurations for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise)
      * [Create a code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise)
      * [Get default code security configurations for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise)
      * [Retrieve a code security configuration of an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise)
      * [Update a custom code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise)
      * [Delete a code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise)
      * [Attach an enterprise configuration to repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories)
      * [Set a code security configuration as a default for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise)
      * [Get repositories associated with an enterprise code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration)
      * [Get code security configurations for an organization](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization)
      * [Create a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration)
      * [Get default code security configurations](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations)
      * [Detach configurations from repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories)
      * [Get a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration)
      * [Update a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration)
      * [Delete a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration)
      * [Attach a configuration to repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories)
      * [Set a code security configuration as a default for an organization](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization)
      * [Get repositories associated with a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration)
      * [Get the code security configuration associated with a repository](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository)
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Code security settings](https://docs.github.com/en/rest/code-security "Code security settings")/
  * [Configurations](https://docs.github.com/en/rest/code-security/configurations "Configurations")


# Configurations
Use the REST API to create and manage security configurations for your organization.
## [Get code security configurations for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise)
Lists all code security configurations available in an enterprise.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Get code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### [HTTP response status codes for "Get code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-enterprise--code-samples)
#### Request example
get/enterprises/{enterprise}/code-security/configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 17,     "target_type": "global",     "name": "GitHub recommended",     "description": "Suggested settings for Dependabot, secret scanning, and code scanning.",     "advanced_security": "enabled",     "dependency_graph": "enabled",     "dependency_graph_autosubmit_action": "not_set",     "dependency_graph_autosubmit_action_options": {       "labeled_runners": false     },     "dependabot_alerts": "enabled",     "dependabot_security_updates": "not_set",     "code_scanning_default_setup": "enabled",     "code_scanning_default_setup_options": {       "runner_type": "not_set",       "runner_label": null     },     "secret_scanning": "enabled",     "secret_scanning_push_protection": "enabled",     "secret_scanning_validity_checks": "enabled",     "secret_scanning_non_provider_patterns": "enabled",     "private_vulnerability_reporting": "enabled",     "enforcement": "enforced",     "url": "https://api.github.com/enterprises/octo-enterprise/code-security/configurations/17",     "html_url": "https://github.com/organizations/octo-enterprise/settings/security_analysis/configurations/17/view",     "created_at": "2023-12-04T15:58:07Z",     "updated_at": "2023-12-04T15:58:07Z"   },   {     "id": 1326,     "target_type": "enterprise",     "name": "High risk settings",     "description": "This is a code security configuration for octo-enterprise high risk repositories",     "advanced_security": "enabled",     "dependency_graph": "enabled",     "dependency_graph_autosubmit_action": "enabled",     "dependency_graph_autosubmit_action_options": {       "labeled_runners": false     },     "dependabot_alerts": "enabled",     "dependabot_security_updates": "enabled",     "code_scanning_default_setup": "enabled",     "code_scanning_default_setup_options": {       "runner_type": "not_set",       "runner_label": null     },     "secret_scanning": "enabled",     "secret_scanning_push_protection": "enabled",     "secret_scanning_validity_checks": "disabled",     "secret_scanning_non_provider_patterns": "disabled",     "private_vulnerability_reporting": "enabled",     "enforcement": "enforced",     "url": "https://api.github.com/enterprises/octo-enterprise/code-security/configurations/1326",     "html_url": "https://github.com/enterprises/octo-enterprise/settings/security_analysis/configurations/1326/edit",     "created_at": "2024-05-10T00:00:00Z",     "updated_at": "2024-05-10T00:00:00Z"   } ]`
## [Create a code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise)
Creates a code security configuration in an enterprise.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Create a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Create a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
Body parameters Name, Type, Description
---
`name` string Required The name of the code security configuration. Must be unique within the enterprise.
`description` string Required A description of the code security configuration
`advanced_security` string The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. Default: `disabled` Can be one of: `enabled`, `disabled`, `code_security`, `secret_protection`
`code_security` string The enablement status of GitHub Code Security features. Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph` string The enablement status of Dependency Graph Default: `enabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action` string The enablement status of Automatic dependency submission Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action_options` object Feature options for Automatic dependency submission
Properties of `dependency_graph_autosubmit_action_options` | Name, Type, Description
---
`labeled_runners` boolean Whether to use runners labeled with 'dependency-submission' or standard GitHub runners. Default: `false`
`dependabot_alerts` string The enablement status of Dependabot alerts Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_security_updates` string The enablement status of Dependabot security updates Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_options` object or null Security Configuration feature options for code scanning
Properties of `code_scanning_options` | Name, Type, Description
---
`allow_advanced` boolean or null Whether to allow repos which use advanced setup
`code_scanning_default_setup` string The enablement status of code scanning default setup Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup_options` object or null Feature options for code scanning default setup
Properties of `code_scanning_default_setup_options` | Name, Type, Description
---
`runner_type` string Whether to use labeled runners or standard GitHub runners. Can be one of: `standard`, `labeled`, `not_set`
`runner_label` string or null The label of the runner to use for code scanning default setup when runner_type is 'labeled'.
`code_scanning_delegated_alert_dismissal` string The enablement status of code scanning delegated alert dismissal Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_protection` string The enablement status of GitHub Secret Protection features. Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning` string The enablement status of secret scanning Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_push_protection` string The enablement status of secret scanning push protection Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_validity_checks` string The enablement status of secret scanning validity checks Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_non_provider_patterns` string The enablement status of secret scanning non provider patterns Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_generic_secrets` string The enablement status of Copilot secret scanning Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_alert_dismissal` string The enablement status of secret scanning delegated alert dismissal Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_extended_metadata` string The enablement status of secret scanning extended metadata Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`private_vulnerability_reporting` string The enablement status of private vulnerability reporting Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`enforcement` string The enforcement status for a security configuration Default: `enforced` Can be one of: `enforced`, `unenforced`
### [HTTP response status codes for "Create a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise--status-codes)
Status code | Description
---|---
`201` | Successfully created code security configuration
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Create a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration-for-an-enterprise--code-samples)
#### Request example
post/enterprises/{enterprise}/code-security/configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations \   -d '{"name":"High rish settings","description":"This is a code security configuration for octo-enterprise","advanced_security":"enabled","dependabot_alerts":"enabled","dependabot_security_updates":"not_set","secret_scanning":"enabled"}'`
Successfully created code security configuration
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1325,   "target_type": "enterprise",   "name": "High risk settings",   "description": "This is a code security configuration for octo-enterprise",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "disabled",   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "enabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/enterprises/octo-enterprise/code-security/configurations/1325",   "html_url": "https://github.com/enterprises/octo-enterprise/settings/security_analysis/configurations/1325/edit",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Get default code security configurations for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise)
Lists the default code security configurations for an enterprise.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Get default code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get default code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
### [HTTP response status codes for "Get default code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get default code security configurations for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations-for-an-enterprise--code-samples)
#### Request example
get/enterprises/{enterprise}/code-security/configurations/defaults
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/defaults`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "default_for_new_repos": "public",     "configuration": {       "id": 1325,       "target_type": "organization",       "name": "octo-org recommended settings",       "description": "This is a code security configuration for octo-org",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "not_set",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "enabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "secret_scanning": "enabled",       "secret_scanning_push_protection": "enabled",       "secret_scanning_delegated_bypass": "enabled",       "secret_scanning_delegated_bypass_options": {         "reviewers": [           {             "security_configuration_id": 1325,             "reviewer_id": 5678,             "reviewer_type": "TEAM"           }         ]       },       "secret_scanning_validity_checks": "enabled",       "secret_scanning_non_provider_patterns": "enabled",       "private_vulnerability_reporting": "enabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",       "created_at": "2024-05-01T00:00:00Z",       "updated_at": "2024-05-01T00:00:00Z"     }   },   {     "default_for_new_repos": "private_and_internal",     "configuration": {       "id": 17,       "target_type": "global",       "name": "GitHub recommended",       "description": "Suggested settings for Dependabot, secret scanning, and code scanning.",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "not_set",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "enabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "secret_scanning": "enabled",       "secret_scanning_push_protection": "enabled",       "secret_scanning_delegated_bypass": "disabled",       "secret_scanning_validity_checks": "disabled",       "private_vulnerability_reporting": "enabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/17",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/view",       "created_at": "2023-12-04T15:58:07Z",       "updated_at": "2023-12-04T15:58:07Z"     }   } ]`
## [Retrieve a code security configuration of an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise)
Gets a code security configuration available in an enterprise.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Retrieve a code security configuration of an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Retrieve a code security configuration of an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
### [HTTP response status codes for "Retrieve a code security configuration of an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Retrieve a code security configuration of an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#retrieve-a-code-security-configuration-of-an-enterprise--code-samples)
#### Request example
get/enterprises/{enterprise}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1325,   "target_type": "enterprise",   "name": "High risk settings",   "description": "This is a code security configuration for octo-enterprise",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "disabled",   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "enabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/enterprises/octo-enterprise/code-security/configurations/1325",   "html_url": "https://github.com/enterprises/octo-enterprise/settings/security_analysis/configurations/1325/edit",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Update a custom code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise)
Updates a code security configuration in an enterprise.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Update a custom code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Update a custom code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`name` string The name of the code security configuration. Must be unique across the enterprise.
`description` string A description of the code security configuration
`advanced_security` string The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. Can be one of: `enabled`, `disabled`, `code_security`, `secret_protection`
`code_security` string The enablement status of GitHub Code Security features. Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph` string The enablement status of Dependency Graph Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action` string The enablement status of Automatic dependency submission Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action_options` object Feature options for Automatic dependency submission
Properties of `dependency_graph_autosubmit_action_options` | Name, Type, Description
---
`labeled_runners` boolean Whether to use runners labeled with 'dependency-submission' or standard GitHub runners.
`dependabot_alerts` string The enablement status of Dependabot alerts Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_security_updates` string The enablement status of Dependabot security updates Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup` string The enablement status of code scanning default setup Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup_options` object or null Feature options for code scanning default setup
Properties of `code_scanning_default_setup_options` | Name, Type, Description
---
`runner_type` string Whether to use labeled runners or standard GitHub runners. Can be one of: `standard`, `labeled`, `not_set`
`runner_label` string or null The label of the runner to use for code scanning default setup when runner_type is 'labeled'.
`code_scanning_options` object or null Security Configuration feature options for code scanning
Properties of `code_scanning_options` | Name, Type, Description
---
`allow_advanced` boolean or null Whether to allow repos which use advanced setup
`code_scanning_delegated_alert_dismissal` string The enablement status of code scanning delegated alert dismissal Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_protection` string The enablement status of GitHub Secret Protection features. Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning` string The enablement status of secret scanning Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_push_protection` string The enablement status of secret scanning push protection Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_validity_checks` string The enablement status of secret scanning validity checks Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_non_provider_patterns` string The enablement status of secret scanning non-provider patterns Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_generic_secrets` string The enablement status of Copilot secret scanning Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_alert_dismissal` string The enablement status of secret scanning delegated alert dismissal Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_extended_metadata` string The enablement status of secret scanning extended metadata Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`private_vulnerability_reporting` string The enablement status of private vulnerability reporting Can be one of: `enabled`, `disabled`, `not_set`
`enforcement` string The enforcement status for a security configuration Can be one of: `enforced`, `unenforced`
### [HTTP response status codes for "Update a custom code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
### [Code samples for "Update a custom code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-custom-code-security-configuration-for-an-enterprise--code-samples)
#### Request example
patch/enterprises/{enterprise}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID \   -d '{"name":"octo-enterprise recommended settings v2","secret_scanning":"disabled","code_scanning_default_setup":"enabled"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1325,   "target_type": "enterprise",   "name": "High risk settings",   "description": "This is a code security configuration for octo-enterprise",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "disabled",   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "enabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/enterprises/octo-enterprise/code-security/configurations/1325",   "html_url": "https://github.com/enterprises/octo-enterprise/settings/security_analysis/configurations/1325/edit",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Delete a code security configuration for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise)
Deletes a code security configuration from an enterprise. Repositories attached to the configuration will retain their settings but will no longer be associated with the configuration.
The authenticated user must be an administrator for the enterprise to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Delete a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
### [HTTP response status codes for "Delete a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
### [Code samples for "Delete a code security configuration for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration-for-an-enterprise--code-samples)
#### Request example
delete/enterprises/{enterprise}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID`
A header with no content is returned.
`Status: 204`
## [Attach an enterprise configuration to repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories)
Attaches an enterprise code security configuration to repositories. If the repositories specified are already attached to a configuration, they will be re-attached to the provided configuration.
If insufficient GHAS licenses are available to attach the configuration to a repository, only free features will be enabled.
The authenticated user must be an administrator for the enterprise to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Attach an enterprise configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Attach an enterprise configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`scope` string Required The type of repositories to attach the configuration to. Can be one of: `all`, `all_without_configurations`
### [HTTP response status codes for "Attach an enterprise configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories--status-codes)
Status code | Description
---|---
`202` | Accepted
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
### [Code samples for "Attach an enterprise configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-an-enterprise-configuration-to-repositories--code-samples)
#### Request example
post/enterprises/{enterprise}/code-security/configurations/{configuration_id}/attach
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID/attach \   -d '{"scope":"all"}'`
Accepted
  * Example response
  * Response schema


`Status: 202`
## [Set a code security configuration as a default for an enterprise](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise)
Sets a code security configuration as a default to be applied to new repositories in your enterprise.
This configuration will be applied by default to the matching repository type when created, but only for organizations within the enterprise that do not already have a default code security configuration set.
The authenticated user must be an administrator for the enterprise to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Set a code security configuration as a default for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Set a code security configuration as a default for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`default_for_new_repos` string Specify which types of repository this security configuration should be applied to by default. Can be one of: `all`, `none`, `private_and_internal`, `public`
### [HTTP response status codes for "Set a code security configuration as a default for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise--status-codes)
Status code | Description
---|---
`200` | Default successfully changed.
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Set a code security configuration as a default for an enterprise"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-enterprise--code-samples)
#### Request example
put/enterprises/{enterprise}/code-security/configurations/{configuration_id}/defaults
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID/defaults \   -d '{"default_for_new_repos":"all"}'`
Default successfully changed.
  * Example response
  * Response schema


`Status: 200`
`{   "default_for_new_repos": "all",   "configuration": {     "value": {       "id": 1325,       "target_type": "organization",       "name": "octo-org recommended settings",       "description": "This is a code security configuration for octo-org",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "enabled",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "disabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "code_scanning_delegated_alert_dismissal": "disabled",       "secret_scanning": "enabled",       "secret_scanning_push_protection": "disabled",       "secret_scanning_delegated_bypass": "disabled",       "secret_scanning_validity_checks": "disabled",       "secret_scanning_non_provider_patterns": "disabled",       "secret_scanning_generic_secrets": "disabled",       "secret_scanning_delegated_alert_dismissal": "disabled",       "private_vulnerability_reporting": "disabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",       "created_at": "2024-05-01T00:00:00Z",       "updated_at": "2024-05-01T00:00:00Z"     }   } }`
## [Get repositories associated with an enterprise code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration)
Lists the repositories associated with an enterprise code security configuration in an organization.
The authenticated user must be an administrator of the enterprise in order to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint.
### [Fine-grained access tokens for "Get repositories associated with an enterprise code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get repositories associated with an enterprise code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`configuration_id` integer Required The unique identifier of the code security configuration.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`status` string A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned. Can be: `all`, `attached`, `attaching`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise` Default: `all`
### [HTTP response status codes for "Get repositories associated with an enterprise code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get repositories associated with an enterprise code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-an-enterprise-code-security-configuration--code-samples)
#### Request example
get/enterprises/{enterprise}/code-security/configurations/{configuration_id}/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/code-security/configurations/CONFIGURATION_ID/repositories`
Example of code security configuration repositories
  * Example response
  * Response schema


`Status: 200`
`[   {     "status": "attached",     "repository": {       "value": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"       }     }   } ]`
## [Get code security configurations for an organization](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization)
Lists all code security configurations available in an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get code security configurations for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get code security configurations for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`target_type` string The target type of the code security configuration Default: `all` Can be one of: `global`, `all`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### [HTTP response status codes for "Get code security configurations for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get code security configurations for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-code-security-configurations-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/code-security/configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 17,     "target_type": "global",     "name": "GitHub recommended",     "description": "Suggested settings for Dependabot, secret scanning, and code scanning.",     "advanced_security": "enabled",     "dependency_graph": "enabled",     "dependency_graph_autosubmit_action": "not_set",     "dependency_graph_autosubmit_action_options": {       "labeled_runners": false     },     "dependabot_alerts": "enabled",     "dependabot_security_updates": "not_set",     "code_scanning_default_setup": "enabled",     "code_scanning_delegated_alert_dismissal": "enabled",     "secret_scanning": "enabled",     "secret_scanning_push_protection": "enabled",     "secret_scanning_delegated_bypass": "enabled",     "secret_scanning_delegated_bypass_options": {       "reviewers": [         {           "security_configuration_id": 17,           "reviewer_id": 5678,           "reviewer_type": "TEAM"         }       ]     },     "secret_scanning_validity_checks": "enabled",     "secret_scanning_non_provider_patterns": "enabled",     "secret_scanning_delegated_alert_dismissal": "not_set",     "private_vulnerability_reporting": "enabled",     "enforcement": "enforced",     "url": "https://api.github.com/orgs/octo-org/code-security/configurations/17",     "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/view",     "created_at": "2023-12-04T15:58:07Z",     "updated_at": "2023-12-04T15:58:07Z"   },   {     "id": 1326,     "target_type": "organization",     "name": "High risk settings",     "description": "This is a code security configuration for octo-org high risk repositories",     "advanced_security": "enabled",     "dependency_graph": "enabled",     "dependency_graph_autosubmit_action": "enabled",     "dependency_graph_autosubmit_action_options": {       "labeled_runners": false     },     "dependabot_alerts": "enabled",     "dependabot_security_updates": "enabled",     "code_scanning_default_setup": "enabled",     "code_scanning_delegated_alert_dismissal": "enabled",     "secret_scanning": "enabled",     "secret_scanning_push_protection": "enabled",     "secret_scanning_delegated_bypass": "disabled",     "secret_scanning_validity_checks": "disabled",     "secret_scanning_non_provider_patterns": "disabled",     "secret_scanning_delegated_alert_dismissal": "disabled",     "private_vulnerability_reporting": "enabled",     "enforcement": "enforced",     "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1326",     "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1326",     "created_at": "2024-05-10T00:00:00Z",     "updated_at": "2024-05-10T00:00:00Z"   } ]`
## [Create a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration)
Creates a code security configuration in an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Create a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Create a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the code security configuration. Must be unique within the organization.
`description` string Required A description of the code security configuration
`advanced_security` string The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. Default: `disabled` Can be one of: `enabled`, `disabled`, `code_security`, `secret_protection`
`code_security` string The enablement status of GitHub Code Security features. Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph` string The enablement status of Dependency Graph Default: `enabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action` string The enablement status of Automatic dependency submission Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action_options` object Feature options for Automatic dependency submission
Properties of `dependency_graph_autosubmit_action_options` | Name, Type, Description
---
`labeled_runners` boolean Whether to use runners labeled with 'dependency-submission' or standard GitHub runners. Default: `false`
`dependabot_alerts` string The enablement status of Dependabot alerts Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_security_updates` string The enablement status of Dependabot security updates Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_delegated_alert_dismissal` string The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_options` object or null Security Configuration feature options for code scanning
Properties of `code_scanning_options` | Name, Type, Description
---
`allow_advanced` boolean or null Whether to allow repos which use advanced setup
`code_scanning_default_setup` string The enablement status of code scanning default setup Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup_options` object or null Feature options for code scanning default setup
Properties of `code_scanning_default_setup_options` | Name, Type, Description
---
`runner_type` string Whether to use labeled runners or standard GitHub runners. Can be one of: `standard`, `labeled`, `not_set`
`runner_label` string or null The label of the runner to use for code scanning default setup when runner_type is 'labeled'.
`code_scanning_delegated_alert_dismissal` string The enablement status of code scanning delegated alert dismissal Default: `not_set` Can be one of: `enabled`, `disabled`, `not_set`
`secret_protection` string The enablement status of GitHub Secret Protection features. Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning` string The enablement status of secret scanning Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_push_protection` string The enablement status of secret scanning push protection Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_bypass` string The enablement status of secret scanning delegated bypass Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_bypass_options` object Feature options for secret scanning delegated bypass
Properties of `secret_scanning_delegated_bypass_options` | Name, Type, Description
---
`reviewers` array of objects The bypass reviewers for secret scanning delegated bypass
Properties of `reviewers` | Name, Type, Description
---
`reviewer_id` integer Required The ID of the team or role selected as a bypass reviewer
`reviewer_type` string Required The type of the bypass reviewer Can be one of: `TEAM`, `ROLE`
`secret_scanning_validity_checks` string The enablement status of secret scanning validity checks Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_non_provider_patterns` string The enablement status of secret scanning non provider patterns Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_generic_secrets` string The enablement status of Copilot secret scanning Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_alert_dismissal` string The enablement status of secret scanning delegated alert dismissal Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_extended_metadata` string The enablement status of secret scanning extended metadata Can be one of: `enabled`, `disabled`, `not_set`
`private_vulnerability_reporting` string The enablement status of private vulnerability reporting Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`enforcement` string The enforcement status for a security configuration Default: `enforced` Can be one of: `enforced`, `unenforced`
### [HTTP response status codes for "Create a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration--status-codes)
Status code | Description
---|---
`201` | Successfully created code security configuration
### [Code samples for "Create a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#create-a-code-security-configuration--code-samples)
#### Request example
post/orgs/{org}/code-security/configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations \   -d '{"name":"octo-org recommended settings","description":"This is a code security configuration for octo-org","advanced_security":"enabled","dependabot_alerts":"enabled","dependabot_security_updates":"not_set","secret_scanning":"enabled"}'`
Successfully created code security configuration
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1325,   "target_type": "organization",   "name": "octo-org recommended settings",   "description": "This is a code security configuration for octo-org",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "disabled",   "code_scanning_default_setup_options": {     "runner_type": "not_set",     "runner_label": null   },   "code_scanning_options": {     "allow_advanced": false   },   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "enabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",   "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Get default code security configurations](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations)
Lists the default code security configurations for an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get default code security configurations"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get default code security configurations"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get default code security configurations"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get default code security configurations"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-default-code-security-configurations--code-samples)
#### Request example
get/orgs/{org}/code-security/configurations/defaults
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/defaults`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "default_for_new_repos": "public",     "configuration": {       "id": 1325,       "target_type": "organization",       "name": "octo-org recommended settings",       "description": "This is a code security configuration for octo-org",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "not_set",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "enabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "secret_scanning": "enabled",       "secret_scanning_push_protection": "enabled",       "secret_scanning_delegated_bypass": "enabled",       "secret_scanning_delegated_bypass_options": {         "reviewers": [           {             "security_configuration_id": 1325,             "reviewer_id": 5678,             "reviewer_type": "TEAM"           }         ]       },       "secret_scanning_validity_checks": "enabled",       "secret_scanning_non_provider_patterns": "enabled",       "private_vulnerability_reporting": "enabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",       "created_at": "2024-05-01T00:00:00Z",       "updated_at": "2024-05-01T00:00:00Z"     }   },   {     "default_for_new_repos": "private_and_internal",     "configuration": {       "id": 17,       "target_type": "global",       "name": "GitHub recommended",       "description": "Suggested settings for Dependabot, secret scanning, and code scanning.",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "not_set",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "enabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "secret_scanning": "enabled",       "secret_scanning_push_protection": "enabled",       "secret_scanning_delegated_bypass": "disabled",       "secret_scanning_validity_checks": "disabled",       "private_vulnerability_reporting": "enabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/17",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/view",       "created_at": "2023-12-04T15:58:07Z",       "updated_at": "2023-12-04T15:58:07Z"     }   } ]`
## [Detach configurations from repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories)
Detach code security configuration(s) from a set of repositories. Repositories will retain their settings but will no longer be associated with the configuration.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Detach configurations from repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Detach configurations from repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`selected_repository_ids` array of integers An array of repository IDs to detach from configurations. Up to 250 IDs can be provided.
### [HTTP response status codes for "Detach configurations from repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
### [Code samples for "Detach configurations from repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#detach-configurations-from-repositories--code-samples)
#### Request example
delete/orgs/{org}/code-security/configurations/detach
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/detach \   -d '{"selected_repository_ids":[32,91]}'`
A header with no content is returned.
`Status: 204`
## [Get a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration)
Gets a code security configuration available in an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
### [HTTP response status codes for "Get a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-a-code-security-configuration--code-samples)
#### Request example
get/orgs/{org}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1325,   "target_type": "organization",   "name": "octo-org recommended settings",   "description": "This is a code security configuration for octo-org",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "disabled",   "code_scanning_default_setup_options": {     "runner_type": "not_set",     "runner_label": null   },   "code_scanning_options": {     "allow_advanced": false   },   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "enabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",   "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Update a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration)
Updates a code security configuration in an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Update a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Update a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`name` string The name of the code security configuration. Must be unique within the organization.
`description` string A description of the code security configuration
`advanced_security` string The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. Can be one of: `enabled`, `disabled`, `code_security`, `secret_protection`
`code_security` string The enablement status of GitHub Code Security features. Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph` string The enablement status of Dependency Graph Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action` string The enablement status of Automatic dependency submission Can be one of: `enabled`, `disabled`, `not_set`
`dependency_graph_autosubmit_action_options` object Feature options for Automatic dependency submission
Properties of `dependency_graph_autosubmit_action_options` | Name, Type, Description
---
`labeled_runners` boolean Whether to use runners labeled with 'dependency-submission' or standard GitHub runners.
`dependabot_alerts` string The enablement status of Dependabot alerts Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_security_updates` string The enablement status of Dependabot security updates Can be one of: `enabled`, `disabled`, `not_set`
`dependabot_delegated_alert_dismissal` string The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup` string The enablement status of code scanning default setup Can be one of: `enabled`, `disabled`, `not_set`
`code_scanning_default_setup_options` object or null Feature options for code scanning default setup
Properties of `code_scanning_default_setup_options` | Name, Type, Description
---
`runner_type` string Whether to use labeled runners or standard GitHub runners. Can be one of: `standard`, `labeled`, `not_set`
`runner_label` string or null The label of the runner to use for code scanning default setup when runner_type is 'labeled'.
`code_scanning_options` object or null Security Configuration feature options for code scanning
Properties of `code_scanning_options` | Name, Type, Description
---
`allow_advanced` boolean or null Whether to allow repos which use advanced setup
`code_scanning_delegated_alert_dismissal` string The enablement status of code scanning delegated alert dismissal Default: `disabled` Can be one of: `enabled`, `disabled`, `not_set`
`secret_protection` string The enablement status of GitHub Secret Protection features. Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning` string The enablement status of secret scanning Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_push_protection` string The enablement status of secret scanning push protection Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_bypass` string The enablement status of secret scanning delegated bypass Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_bypass_options` object Feature options for secret scanning delegated bypass
Properties of `secret_scanning_delegated_bypass_options` | Name, Type, Description
---
`reviewers` array of objects The bypass reviewers for secret scanning delegated bypass
Properties of `reviewers` | Name, Type, Description
---
`reviewer_id` integer Required The ID of the team or role selected as a bypass reviewer
`reviewer_type` string Required The type of the bypass reviewer Can be one of: `TEAM`, `ROLE`
`secret_scanning_validity_checks` string The enablement status of secret scanning validity checks Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_non_provider_patterns` string The enablement status of secret scanning non-provider patterns Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_generic_secrets` string The enablement status of Copilot secret scanning Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_delegated_alert_dismissal` string The enablement status of secret scanning delegated alert dismissal Can be one of: `enabled`, `disabled`, `not_set`
`secret_scanning_extended_metadata` string The enablement status of secret scanning extended metadata Can be one of: `enabled`, `disabled`, `not_set`
`private_vulnerability_reporting` string The enablement status of private vulnerability reporting Can be one of: `enabled`, `disabled`, `not_set`
`enforcement` string The enforcement status for a security configuration Can be one of: `enforced`, `unenforced`
### [HTTP response status codes for "Update a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration--status-codes)
Status code | Description
---|---
`200` | Response when a configuration is updated
`204` | Response when no new updates are made
### [Code samples for "Update a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#update-a-code-security-configuration--code-samples)
#### Request example
patch/orgs/{org}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID \   -d '{"name":"octo-org recommended settings v2","secret_scanning":"disabled","code_scanning_default_setup":"enabled"}'`
Response when a configuration is updated
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1325,   "target_type": "organization",   "name": "octo-org recommended settings v2",   "description": "This is a code security configuration for octo-org",   "advanced_security": "enabled",   "dependency_graph": "enabled",   "dependency_graph_autosubmit_action": "enabled",   "dependency_graph_autosubmit_action_options": {     "labeled_runners": false   },   "dependabot_alerts": "enabled",   "dependabot_security_updates": "not_set",   "code_scanning_default_setup": "enabled",   "code_scanning_default_setup_options": {     "runner_type": "not_set",     "runner_label": null   },   "code_scanning_options": {     "allow_advanced": false   },   "code_scanning_delegated_alert_dismissal": "disabled",   "secret_scanning": "disabled",   "secret_scanning_push_protection": "disabled",   "secret_scanning_delegated_bypass": "disabled",   "secret_scanning_validity_checks": "disabled",   "secret_scanning_non_provider_patterns": "disabled",   "secret_scanning_generic_secrets": "disabled",   "secret_scanning_delegated_alert_dismissal": "disabled",   "private_vulnerability_reporting": "disabled",   "enforcement": "enforced",   "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",   "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",   "created_at": "2024-05-01T00:00:00Z",   "updated_at": "2024-05-01T00:00:00Z" }`
## [Delete a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration)
Deletes the desired code security configuration from an organization. Repositories attached to the configuration will retain their settings but will no longer be associated with the configuration.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Delete a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
### [HTTP response status codes for "Delete a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
### [Code samples for "Delete a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#delete-a-code-security-configuration--code-samples)
#### Request example
delete/orgs/{org}/code-security/configurations/{configuration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID`
A header with no content is returned.
`Status: 204`
## [Attach a configuration to repositories](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories)
Attach a code security configuration to a set of repositories. If the repositories specified are already attached to a configuration, they will be re-attached to the provided configuration.
If insufficient GHAS licenses are available to attach the configuration to a repository, only free features will be enabled.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Attach a configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Attach a configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`scope` string Required The type of repositories to attach the configuration to. `selected` means the configuration will be attached to only the repositories specified by `selected_repository_ids` Can be one of: `all`, `all_without_configurations`, `public`, `private_or_internal`, `selected`
`selected_repository_ids` array of integers An array of repository IDs to attach the configuration to. You can only provide a list of repository ids when the `scope` is set to `selected`.
### [HTTP response status codes for "Attach a configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories--status-codes)
Status code | Description
---|---
`202` | Accepted
### [Code samples for "Attach a configuration to repositories"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#attach-a-configuration-to-repositories--code-samples)
#### Request example
post/orgs/{org}/code-security/configurations/{configuration_id}/attach
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID/attach \   -d '{"scope":"selected","selected_repository_ids":[32,91]}'`
Accepted
  * Example response
  * Response schema


`Status: 202`
## [Set a code security configuration as a default for an organization](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization)
Sets a code security configuration as a default to be applied to new repositories in your organization.
This configuration will be applied to the matching repository type (all, none, public, private and internal) by default when they are created.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Set a code security configuration as a default for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Set a code security configuration as a default for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
Body parameters Name, Type, Description
---
`default_for_new_repos` string Specify which types of repository this security configuration should be applied to by default. Can be one of: `all`, `none`, `private_and_internal`, `public`
### [HTTP response status codes for "Set a code security configuration as a default for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Default successfully changed.
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Set a code security configuration as a default for an organization"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#set-a-code-security-configuration-as-a-default-for-an-organization--code-samples)
#### Request example
put/orgs/{org}/code-security/configurations/{configuration_id}/defaults
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID/defaults \   -d '{"default_for_new_repos":"all"}'`
Default successfully changed.
  * Example response
  * Response schema


`Status: 200`
`{   "default_for_new_repos": "all",   "configuration": {     "value": {       "id": 1325,       "target_type": "organization",       "name": "octo-org recommended settings",       "description": "This is a code security configuration for octo-org",       "advanced_security": "enabled",       "dependency_graph": "enabled",       "dependency_graph_autosubmit_action": "enabled",       "dependency_graph_autosubmit_action_options": {         "labeled_runners": false       },       "dependabot_alerts": "enabled",       "dependabot_security_updates": "not_set",       "code_scanning_default_setup": "disabled",       "code_scanning_default_setup_options": {         "runner_type": "not_set",         "runner_label": null       },       "code_scanning_options": {         "allow_advanced": false       },       "code_scanning_delegated_alert_dismissal": "disabled",       "secret_scanning": "enabled",       "secret_scanning_push_protection": "disabled",       "secret_scanning_delegated_bypass": "disabled",       "secret_scanning_validity_checks": "disabled",       "secret_scanning_non_provider_patterns": "disabled",       "secret_scanning_generic_secrets": "disabled",       "secret_scanning_delegated_alert_dismissal": "disabled",       "private_vulnerability_reporting": "disabled",       "enforcement": "enforced",       "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",       "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",       "created_at": "2024-05-01T00:00:00Z",       "updated_at": "2024-05-01T00:00:00Z"     }   } }`
## [Get repositories associated with a code security configuration](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration)
Lists the repositories associated with a code security configuration in an organization.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get repositories associated with a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "Get repositories associated with a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`configuration_id` integer Required The unique identifier of the code security configuration.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`status` string A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned. Can be: `all`, `attached`, `attaching`, `detached`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise` Default: `all`
### [HTTP response status codes for "Get repositories associated with a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get repositories associated with a code security configuration"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-repositories-associated-with-a-code-security-configuration--code-samples)
#### Request example
get/orgs/{org}/code-security/configurations/{configuration_id}/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/code-security/configurations/CONFIGURATION_ID/repositories`
Example of code security configuration repositories
  * Example response
  * Response schema


`Status: 200`
`[   {     "status": "attached",     "repository": {       "value": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"       }     }   } ]`
## [Get the code security configuration associated with a repository](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository)
Get the code security configuration that manages a repository's code security settings.
The authenticated user must be an administrator or security manager for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get the code security configuration associated with a repository"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get the code security configuration associated with a repository"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get the code security configuration associated with a repository"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`204` | A header with no content is returned.
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get the code security configuration associated with a repository"](https://docs.github.com/en/rest/code-security/configurations?apiVersion=2022-11-28#get-the-code-security-configuration-associated-with-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/code-security-configuration
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/code-security-configuration`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "status": "attached",   "configuration": {     "id": 1325,     "target_type": "organization",     "name": "octo-org recommended settings",     "description": "This is a code security configuration for octo-org",     "advanced_security": "enabled",     "dependency_graph": "enabled",     "dependency_graph_autosubmit_action": "enabled",     "dependency_graph_autosubmit_action_options": {       "labeled_runners": false     },     "dependabot_alerts": "enabled",     "dependabot_security_updates": "not_set",     "code_scanning_default_setup": "disabled",     "code_scanning_delegated_alert_dismissal": "disabled",     "secret_scanning": "enabled",     "secret_scanning_push_protection": "disabled",     "secret_scanning_delegated_bypass": "disabled",     "secret_scanning_validity_checks": "disabled",     "secret_scanning_non_provider_patterns": "disabled",     "secret_scanning_generic_secrets": "disabled",     "secret_scanning_delegated_alert_dismissal": "disabled",     "private_vulnerability_reporting": "disabled",     "enforcement": "enforced",     "url": "https://api.github.com/orgs/octo-org/code-security/configurations/1325",     "html_url": "https://github.com/organizations/octo-org/settings/security_products/configurations/edit/1325",     "created_at": "2024-05-01T00:00:00Z",     "updated_at": "2024-05-01T00:00:00Z"   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/code-security/configurations.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


Configurations - GitHub Docs
