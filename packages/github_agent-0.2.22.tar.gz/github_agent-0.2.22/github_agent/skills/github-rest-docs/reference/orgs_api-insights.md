[Skip to main content](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [API Insights](https://docs.github.com/en/rest/orgs/api-insights "API Insights")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
      * [Get route stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor)
      * [Get subject stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats)
      * [Get summary stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats)
      * [Get summary stats by user](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user)
      * [Get summary stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor)
      * [Get time stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats)
      * [Get time stats by user](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user)
      * [Get time stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor)
      * [Get user stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats)
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [API Insights](https://docs.github.com/en/rest/orgs/api-insights "API Insights")


# REST API endpoints for API Insights
Use the REST API to view statistics for API usage in an organization.
## [Get route stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor)
Get API request count statistics for an actor broken down by route within a specified time frame.
### [Fine-grained access tokens for "Get route stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get route stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`actor_type` string Required The type of the actor Can be one of: `installation`, `classic_pat`, `fine_grained_pat`, `oauth_app`, `github_app_user_to_server`
`actor_id` integer Required The ID of the actor
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`sort` array The property to sort the results by.
`api_route_substring` string Providing a substring will filter results where the API route contains the substring. This is a case-insensitive search.
### [HTTP response status codes for "Get route stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get route stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-route-stats-by-actor--code-samples)
#### Request example
get/orgs/{org}/insights/api/route-stats/{actor_type}/{actor_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/route-stats/ACTOR_TYPE/ACTOR_ID?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "http_method": "GET",     "api_route": "/repositories/:repository_id",     "total_request_count": 544665,     "rate_limited_request_count": 13,     "last_request_timestamp": "2024-09-18T15:43:03Z",     "last_rate_limited_timestamp": "2024-09-18T06:30:09Z"   } ]`
## [Get subject stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats)
Get API request statistics for all subjects within an organization within a specified time frame. Subjects can be users or GitHub Apps.
### [Fine-grained access tokens for "Get subject stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get subject stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`sort` array The property to sort the results by.
`subject_name_substring` string Providing a substring will filter results where the subject name contains the substring. This is a case-insensitive search.
### [HTTP response status codes for "Get subject stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get subject stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-subject-stats--code-samples)
#### Request example
get/orgs/{org}/insights/api/subject-stats
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/subject-stats?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "subject_type": "installation",     "subject_id": 954453,     "subject_name": "GitHub Actions",     "total_request_count": 544665,     "rate_limited_request_count": 13,     "last_request_timestamp": "2024-09-18T15:43:03Z",     "last_rate_limited_timestamp": "2024-09-18T06:30:09Z"   } ]`
## [Get summary stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats)
Get overall statistics of API requests made within an organization by all users and apps within a specified time frame.
### [Fine-grained access tokens for "Get summary stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get summary stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### [HTTP response status codes for "Get summary stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get summary stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats--code-samples)
#### Request example
get/orgs/{org}/insights/api/summary-stats
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/summary-stats?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_request_count": 34225,   "rate_limited_request_count": 23 }`
## [Get summary stats by user](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user)
Get overall statistics of API requests within the organization for a user.
### [Fine-grained access tokens for "Get summary stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get summary stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`user_id` string Required The ID of the user to query for stats
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### [HTTP response status codes for "Get summary stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get summary stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-user--code-samples)
#### Request example
get/orgs/{org}/insights/api/summary-stats/users/{user_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/summary-stats/users/USER_ID?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_request_count": 34225,   "rate_limited_request_count": 23 }`
## [Get summary stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor)
Get overall statistics of API requests within the organization made by a specific actor. Actors can be GitHub App installations, OAuth apps or other tokens on behalf of a user.
### [Fine-grained access tokens for "Get summary stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get summary stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`actor_type` string Required The type of the actor Can be one of: `installation`, `classic_pat`, `fine_grained_pat`, `oauth_app`, `github_app_user_to_server`
`actor_id` integer Required The ID of the actor
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### [HTTP response status codes for "Get summary stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get summary stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-summary-stats-by-actor--code-samples)
#### Request example
get/orgs/{org}/insights/api/summary-stats/{actor_type}/{actor_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/summary-stats/ACTOR_TYPE/ACTOR_ID?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_request_count": 34225,   "rate_limited_request_count": 23 }`
## [Get time stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats)
Get the number of API requests and rate-limited requests made within an organization over a specified time period.
### [Fine-grained access tokens for "Get time stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get time stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`timestamp_increment` string Required The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### [HTTP response status codes for "Get time stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get time stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats--code-samples)
#### Request example
get/orgs/{org}/insights/api/time-stats
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/time-stats?min_timestamp=MIN_TIMESTAMP&timestamp_increment=TIMESTAMP_INCREMENT"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "timestamp": "2024-09-11T15:00:00Z",     "total_request_count": 34225,     "rate_limited_request_count": 0   },   {     "timestamp": "2024-09-11T15:05:00Z",     "total_request_count": 10587,     "rate_limited_request_count": 18   },   {     "timestamp": "2024-09-11T15:10:00Z",     "total_request_count": 43587,     "rate_limited_request_count": 14   },   {     "timestamp": "2024-09-11T15:15:00Z",     "total_request_count": 19463,     "rate_limited_request_count": 4   },   {     "timestamp": "2024-09-11T15:20:00Z",     "total_request_count": 60542,     "rate_limited_request_count": 3   },   {     "timestamp": "2024-09-11T15:25:00Z",     "total_request_count": 55872,     "rate_limited_request_count": 23   } ]`
## [Get time stats by user](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user)
Get the number of API requests and rate-limited requests made within an organization by a specific user over a specified time period.
### [Fine-grained access tokens for "Get time stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get time stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`user_id` string Required The ID of the user to query for stats
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`timestamp_increment` string Required The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### [HTTP response status codes for "Get time stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get time stats by user"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-user--code-samples)
#### Request example
get/orgs/{org}/insights/api/time-stats/users/{user_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/time-stats/users/USER_ID?min_timestamp=MIN_TIMESTAMP&timestamp_increment=TIMESTAMP_INCREMENT"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "timestamp": "2024-09-11T15:00:00Z",     "total_request_count": 34225,     "rate_limited_request_count": 0   },   {     "timestamp": "2024-09-11T15:05:00Z",     "total_request_count": 10587,     "rate_limited_request_count": 18   },   {     "timestamp": "2024-09-11T15:10:00Z",     "total_request_count": 43587,     "rate_limited_request_count": 14   },   {     "timestamp": "2024-09-11T15:15:00Z",     "total_request_count": 19463,     "rate_limited_request_count": 4   },   {     "timestamp": "2024-09-11T15:20:00Z",     "total_request_count": 60542,     "rate_limited_request_count": 3   },   {     "timestamp": "2024-09-11T15:25:00Z",     "total_request_count": 55872,     "rate_limited_request_count": 23   } ]`
## [Get time stats by actor](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor)
Get the number of API requests and rate-limited requests made within an organization by a specific actor within a specified time period.
### [Fine-grained access tokens for "Get time stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get time stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`actor_type` string Required The type of the actor Can be one of: `installation`, `classic_pat`, `fine_grained_pat`, `oauth_app`, `github_app_user_to_server`
`actor_id` integer Required The ID of the actor
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`timestamp_increment` string Required The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### [HTTP response status codes for "Get time stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get time stats by actor"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-time-stats-by-actor--code-samples)
#### Request example
get/orgs/{org}/insights/api/time-stats/{actor_type}/{actor_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/time-stats/ACTOR_TYPE/ACTOR_ID?min_timestamp=MIN_TIMESTAMP&timestamp_increment=TIMESTAMP_INCREMENT"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "timestamp": "2024-09-11T15:00:00Z",     "total_request_count": 34225,     "rate_limited_request_count": 0   },   {     "timestamp": "2024-09-11T15:05:00Z",     "total_request_count": 10587,     "rate_limited_request_count": 18   },   {     "timestamp": "2024-09-11T15:10:00Z",     "total_request_count": 43587,     "rate_limited_request_count": 14   },   {     "timestamp": "2024-09-11T15:15:00Z",     "total_request_count": 19463,     "rate_limited_request_count": 4   },   {     "timestamp": "2024-09-11T15:20:00Z",     "total_request_count": 60542,     "rate_limited_request_count": 3   },   {     "timestamp": "2024-09-11T15:25:00Z",     "total_request_count": 55872,     "rate_limited_request_count": 23   } ]`
## [Get user stats](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats)
Get API usage statistics within an organization for a user broken down by the type of access.
### [Fine-grained access tokens for "Get user stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "API Insights" organization permissions (read)


### [Parameters for "Get user stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`user_id` string Required The ID of the user to query for stats
Query parameters Name, Type, Description
---
`min_timestamp` string Required The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`max_timestamp` string The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`sort` array The property to sort the results by.
`actor_name_substring` string Providing a substring will filter results where the actor name contains the substring. This is a case-insensitive search.
### [HTTP response status codes for "Get user stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get user stats"](https://docs.github.com/en/rest/orgs/api-insights?apiVersion=2022-11-28#get-user-stats--code-samples)
#### Request example
get/orgs/{org}/insights/api/user-stats/{user_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   "https://api.github.com/orgs/ORG/insights/api/user-stats/USER_ID?min_timestamp=MIN_TIMESTAMP"`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "actor_type": "oauth_app",     "actor_id": 954453,     "actor_name": "GitHub Actions",     "oauth_application_id": 1245,     "total_request_count": 544665,     "rate_limited_request_count": 13,     "last_request_timestamp": "2024-09-18T15:43:03Z",     "last_rate_limited_timestamp": "2024-09-18T06:30:09Z"   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/api-insights.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for API Insights - GitHub Docs
