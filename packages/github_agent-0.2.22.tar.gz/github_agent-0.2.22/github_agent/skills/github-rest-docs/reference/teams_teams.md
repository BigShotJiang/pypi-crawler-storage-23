[Skip to main content](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Teams](https://docs.github.com/en/rest/teams "Teams")/
  * [Teams](https://docs.github.com/en/rest/teams/teams "Teams")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
      * [About teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#about-teams)
      * [List teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams)
      * [Create a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team)
      * [Get a team by name](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name)
      * [Update a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team)
      * [Delete a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team)
      * [List team repositories](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories)
      * [Check team permissions for a repository](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository)
      * [Add or update team repository permissions](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions)
      * [Remove a repository from a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team)
      * [List child teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams)
      * [Get a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy)
      * [Update a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy)
      * [Delete a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy)
      * [List team repositories (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy)
      * [Check team permissions for a repository (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy)
      * [Add or update team repository permissions (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy)
      * [Remove a repository from a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy)
      * [List child teams (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy)
      * [List teams for the authenticated user](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user)
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Teams](https://docs.github.com/en/rest/teams "Teams")/
  * [Teams](https://docs.github.com/en/rest/teams/teams "Teams")


# REST API endpoints for teams
Use the REST API to create and manage teams in your GitHub organization.
## [About teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#about-teams)
These endpoints are only available to authenticated members of the team's [organization](https://docs.github.com/en/rest/orgs). OAuth access tokens require the `read:org` [scope](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps). GitHub generates the team's `slug` from the team `name`.
Where `pull` and `push` permissions are accepted, these will map to the **Read** and **Write** roles for an organization repository. For more information about repository roles, see [Repository roles for an organization](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization).
## [List teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams)
Lists all teams in an organization that are visible to the authenticated user.
### [Fine-grained access tokens for "List teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
### [Code samples for "List teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams--code-samples)
#### Request example
get/orgs/{org}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Create a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team)
To create a team, the authenticated user must be a member or owner of `{org}`. By default, organization members can create teams. Organization owners can limit team creation to organization owners. For more information, see "[Setting team creation permissions](https://docs.github.com/articles/setting-team-creation-permissions-in-your-organization)."
When you create a new team, you automatically become a team maintainer without explicitly adding yourself to the optional array of `maintainers`. For more information, see "[About teams](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/about-teams)".
### [Fine-grained access tokens for "Create a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Create a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the team.
`description` string The description of the team.
`maintainers` array of strings List GitHub usernames for organization members who will become team maintainers.
`repo_names` array of strings The full name (e.g., "organization-name/repository-name") of repositories to add the team to.
`privacy` string The level of privacy this team should have. The options are:
**For a non-nested team:**
  * `secret` - only visible to organization owners and members of this team.
  * `closed` - visible to all members of this organization.
Default: `secret`
**For a parent or child team:**
  * `closed` - visible to all members of this organization.
Default for child team: `closed`

Can be one of: `secret`, `closed`
`notification_setting` string The notification setting the team has chosen. The options are:
  * `notifications_enabled` - team members receive notifications when the team is @mentioned.
  * `notifications_disabled` - no one receives notifications.
Default: `notifications_enabled`

Can be one of: `notifications_enabled`, `notifications_disabled`
`permission` string **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. Default: `pull` Can be one of: `pull`, `push`
`parent_team_id` integer The ID of a team to set as the parent team.
### [HTTP response status codes for "Create a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team--status-codes)
Status code | Description
---|---
`201` | Created
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#create-a-team--code-samples)
#### Request example
post/orgs/{org}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams \   -d '{"name":"Justice League","description":"A great team","permission":"push","notification_setting":"notifications_enabled","privacy":"closed"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1,   "node_id": "MDQ6VGVhbTE=",   "url": "https://api.github.com/teams/1",   "html_url": "https://github.com/orgs/github/teams/justice-league",   "name": "Justice League",   "slug": "justice-league",   "description": "A great team.",   "privacy": "closed",   "notification_setting": "notifications_enabled",   "permission": "admin",   "members_url": "https://api.github.com/teams/1/members{/member}",   "repositories_url": "https://api.github.com/teams/1/repos",   "parent": null,   "members_count": 3,   "repos_count": 10,   "created_at": "2017-07-14T16:53:42Z",   "updated_at": "2017-08-17T12:37:15Z",   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization",     "name": "github",     "company": "GitHub",     "blog": "https://github.com/blog",     "location": "San Francisco",     "email": "octocat@github.com",     "is_verified": true,     "has_organization_projects": true,     "has_repository_projects": true,     "public_repos": 2,     "public_gists": 1,     "followers": 20,     "following": 0,     "html_url": "https://github.com/octocat",     "created_at": "2008-01-14T04:33:35Z",     "updated_at": "2017-08-17T12:37:15Z",     "type": "Organization"   } }`
## [Get a team by name](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name)
Gets a team using the team's `slug`. To create the `slug`, GitHub replaces special characters in the `name` string, changes all words to lowercase, and replaces spaces with a `-` separator. For example, `"My TEam Näme"` would become `my-team-name`.
You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}`.
### [Fine-grained access tokens for "Get a team by name"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "Get a team by name"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
### [HTTP response status codes for "Get a team by name"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a team by name"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-by-name--code-samples)
#### Request example
get/orgs/{org}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDQ6VGVhbTE=",   "url": "https://api.github.com/teams/1",   "html_url": "https://github.com/orgs/github/teams/justice-league",   "name": "Justice League",   "slug": "justice-league",   "description": "A great team.",   "privacy": "closed",   "notification_setting": "notifications_enabled",   "permission": "admin",   "members_url": "https://api.github.com/teams/1/members{/member}",   "repositories_url": "https://api.github.com/teams/1/repos",   "parent": null,   "members_count": 3,   "repos_count": 10,   "created_at": "2017-07-14T16:53:42Z",   "updated_at": "2017-08-17T12:37:15Z",   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization",     "name": "github",     "company": "GitHub",     "blog": "https://github.com/blog",     "location": "San Francisco",     "email": "octocat@github.com",     "is_verified": true,     "has_organization_projects": true,     "has_repository_projects": true,     "public_repos": 2,     "public_gists": 1,     "followers": 20,     "following": 0,     "html_url": "https://github.com/octocat",     "created_at": "2008-01-14T04:33:35Z",     "updated_at": "2017-08-17T12:37:15Z",     "type": "Organization"   } }`
## [Update a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team)
To edit a team, the authenticated user must either be an organization owner or a team maintainer.
You can also specify a team by `org_id` and `team_id` using the route `PATCH /organizations/{org_id}/team/{team_id}`.
### [Fine-grained access tokens for "Update a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Update a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
Body parameters Name, Type, Description
---
`name` string The name of the team.
`description` string The description of the team.
`privacy` string The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. When a team is nested, the `privacy` for parent teams cannot be `secret`. The options are:
**For a non-nested team:**
  * `secret` - only visible to organization owners and members of this team.
  * `closed` - visible to all members of this organization.
**For a parent or child team:**
  * `closed` - visible to all members of this organization.

Can be one of: `secret`, `closed`
`notification_setting` string The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are:
  * `notifications_enabled` - team members receive notifications when the team is @mentioned.
  * `notifications_disabled` - no one receives notifications.

Can be one of: `notifications_enabled`, `notifications_disabled`
`permission` string **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. Default: `pull` Can be one of: `pull`, `push`, `admin`
`parent_team_id` integer or null The ID of a team to set as the parent team.
### [HTTP response status codes for "Update a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team--status-codes)
Status code | Description
---|---
`200` | Response when the updated information already exists
`201` | Created
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 201
patch/orgs/{org}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG \   -d '{"name":"new team name","description":"new team description","privacy":"closed","notification_setting":"notifications_enabled"}'`
Response when the updated information already exists
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDQ6VGVhbTE=",   "url": "https://api.github.com/teams/1",   "html_url": "https://github.com/orgs/github/teams/justice-league",   "name": "Justice League",   "slug": "justice-league",   "description": "A great team.",   "privacy": "closed",   "notification_setting": "notifications_enabled",   "permission": "admin",   "members_url": "https://api.github.com/teams/1/members{/member}",   "repositories_url": "https://api.github.com/teams/1/repos",   "parent": null,   "members_count": 3,   "repos_count": 10,   "created_at": "2017-07-14T16:53:42Z",   "updated_at": "2017-08-17T12:37:15Z",   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization",     "name": "github",     "company": "GitHub",     "blog": "https://github.com/blog",     "location": "San Francisco",     "email": "octocat@github.com",     "is_verified": true,     "has_organization_projects": true,     "has_repository_projects": true,     "public_repos": 2,     "public_gists": 1,     "followers": 20,     "following": 0,     "html_url": "https://github.com/octocat",     "created_at": "2008-01-14T04:33:35Z",     "updated_at": "2017-08-17T12:37:15Z",     "type": "Organization"   } }`
## [Delete a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team)
To delete a team, the authenticated user must be an organization owner or team maintainer.
If you are an organization owner, deleting a parent team will delete all of its child teams as well.
You can also specify a team by `org_id` and `team_id` using the route `DELETE /organizations/{org_id}/team/{team_id}`.
### [Fine-grained access tokens for "Delete a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Delete a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
### [HTTP response status codes for "Delete a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team--status-codes)
Status code | Description
---|---
`204` | No Content
`422` | Unprocessable entity if you attempt to modify an enterprise team at the organization level.
### [Code samples for "Delete a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team--code-samples)
#### Request example
delete/orgs/{org}/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG`
Response
`Status: 204`
## [List team repositories](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories)
Lists a team's repositories visible to the authenticated user.
You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/repos`.
### [Fine-grained access tokens for "List team repositories"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List team repositories"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List team repositories"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List team repositories"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories--code-samples)
#### Request example
get/orgs/{org}/teams/{team_slug}/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG/repos`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "has_discussions": false,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } ]`
## [Check team permissions for a repository](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository)
Checks whether a team has `admin`, `push`, `maintain`, `triage`, or `pull` permission for a repository. Repositories inherited through a parent team will also be checked.
You can also get information about the specified repository, including what permissions the team grants on it, by passing the following custom [media type](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types/) via the `application/vnd.github.v3.repository+json` accept header.
If a team doesn't have permission for the repository, you will receive a `404 Not Found` response status.
If the repository is private, you must have at least `read` permission for that repository, and your token must have the `repo` or `admin:org` scope. Otherwise, you will receive a `404 Not Found` response status.
You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`.
### [Fine-grained access tokens for "Check team permissions for a repository"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Check team permissions for a repository"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check team permissions for a repository"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository--status-codes)
Status code | Description
---|---
`200` | Alternative response with repository permissions
`204` | Response if team has permission for the repository. This is the response when the repository media type hasn't been provded in the Accept header.
`404` | Not Found if team does not have permission for the repository
### [Code samples for "Check team permissions for a repository"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository--code-samples)
#### Request example
get/orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG/repos/OWNER/REPO`
Alternative response with repository permissions
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "language": null,   "forks_count": 9,   "stargazers_count": 80,   "watchers_count": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "admin": false,     "maintain": false,     "push": false,     "triage": false,     "pull": true   },   "role_name": "read",   "allow_rebase_merge": true,   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "subscribers_count": 42,   "network_count": 0,   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://api.github.com/licenses/mit"   },   "forks": 1,   "open_issues": 1,   "watchers": 1 }`
## [Add or update team repository permissions](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions)
To add a repository to a team or update the team's permission on a repository, the authenticated user must have admin access to the repository, and must be able to see the team. The repository must be owned by the organization, or a direct fork of a repository owned by the organization. You will get a `422 Unprocessable Entity` status if you attempt to add a repository to a team that is not owned by the organization. Note that, if you choose not to pass any parameters, you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)."
You can also specify a team by `org_id` and `team_id` using the route `PUT /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`.
For more information about the permission levels, see "[Repository permission levels for an organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/repository-permission-levels-for-an-organization#permission-levels-for-repositories-owned-by-an-organization)".
### [Fine-grained access tokens for "Add or update team repository permissions"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Add or update team repository permissions"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`permission` string The permission to grant the team on this repository. We accept the following permissions to be set: `pull`, `triage`, `push`, `maintain`, `admin` and you can also specify a custom repository role name, if the owning organization has defined any. If no permission is specified, the team's `permission` attribute will be used to determine what permission to grant the team on this repository.
### [HTTP response status codes for "Add or update team repository permissions"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Add or update team repository permissions"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions--code-samples)
#### Request example
put/orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG/repos/OWNER/REPO \   -d '{"permission":"push"}'`
Response
`Status: 204`
## [Remove a repository from a team](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team)
If the authenticated user is an organization owner or a team maintainer, they can remove any repositories from the team. To remove a repository from a team as an organization member, the authenticated user must have admin access to the repository and must be able to see the team. This does not delete the repository, it just removes it from the team.
You can also specify a team by `org_id` and `team_id` using the route `DELETE /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`.
### [Fine-grained access tokens for "Remove a repository from a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Remove a repository from a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Remove a repository from a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove a repository from a team"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team--code-samples)
#### Request example
delete/orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG/repos/OWNER/REPO`
Response
`Status: 204`
## [List child teams](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams)
Lists the child teams of the team specified by `{team_slug}`.
You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/teams`.
### [Fine-grained access tokens for "List child teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List child teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List child teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams--status-codes)
Status code | Description
---|---
`200` | if child teams exist
### [Code samples for "List child teams"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams--code-samples)
#### Request example
get/orgs/{org}/teams/{team_slug}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/teams/TEAM_SLUG/teams`
if child teams exist
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 2,     "node_id": "MDQ6VGVhbTI=",     "url": "https://api.github.com/teams/2",     "name": "Original Roster",     "slug": "original-roster",     "description": "Started it all.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/2/members{/member}",     "repositories_url": "https://api.github.com/teams/2/repos",     "parent": {       "id": 1,       "node_id": "MDQ6VGVhbTE=",       "url": "https://api.github.com/teams/1",       "html_url": "https://github.com/orgs/github/teams/justice-league",       "name": "Justice League",       "slug": "justice-league",       "description": "A great team.",       "privacy": "closed",       "notification_setting": "notifications_enabled",       "permission": "admin",       "members_url": "https://api.github.com/teams/1/members{/member}",       "repositories_url": "https://api.github.com/teams/1/repos"     },     "html_url": "https://github.com/orgs/rails/teams/core"   } ]`
## [Get a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the [Get a team by name](https://docs.github.com/rest/teams/teams#get-a-team-by-name) endpoint.
### [Fine-grained access tokens for "Get a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "Get a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
### [HTTP response status codes for "Get a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#get-a-team-legacy--code-samples)
#### Request example
get/teams/{team_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDQ6VGVhbTE=",   "url": "https://api.github.com/teams/1",   "html_url": "https://github.com/orgs/github/teams/justice-league",   "name": "Justice League",   "slug": "justice-league",   "description": "A great team.",   "privacy": "closed",   "notification_setting": "notifications_enabled",   "permission": "admin",   "members_url": "https://api.github.com/teams/1/members{/member}",   "repositories_url": "https://api.github.com/teams/1/repos",   "parent": null,   "members_count": 3,   "repos_count": 10,   "created_at": "2017-07-14T16:53:42Z",   "updated_at": "2017-08-17T12:37:15Z",   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization",     "name": "github",     "company": "GitHub",     "blog": "https://github.com/blog",     "location": "San Francisco",     "email": "octocat@github.com",     "is_verified": true,     "has_organization_projects": true,     "has_repository_projects": true,     "public_repos": 2,     "public_gists": 1,     "followers": 20,     "following": 0,     "html_url": "https://github.com/octocat",     "created_at": "2008-01-14T04:33:35Z",     "updated_at": "2017-08-17T12:37:15Z",     "type": "Organization"   } }`
## [Update a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [Update a team](https://docs.github.com/rest/teams/teams#update-a-team) endpoint.
To edit a team, the authenticated user must either be an organization owner or a team maintainer.
With nested teams, the `privacy` for parent teams cannot be `secret`.
### [Fine-grained access tokens for "Update a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Update a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
Body parameters Name, Type, Description
---
`name` string Required The name of the team.
`description` string The description of the team.
`privacy` string The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. The options are:
**For a non-nested team:**
  * `secret` - only visible to organization owners and members of this team.
  * `closed` - visible to all members of this organization.
**For a parent or child team:**
  * `closed` - visible to all members of this organization.

Can be one of: `secret`, `closed`
`notification_setting` string The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are:
  * `notifications_enabled` - team members receive notifications when the team is @mentioned.
  * `notifications_disabled` - no one receives notifications.

Can be one of: `notifications_enabled`, `notifications_disabled`
`permission` string **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. Default: `pull` Can be one of: `pull`, `push`, `admin`
`parent_team_id` integer or null The ID of a team to set as the parent team.
### [HTTP response status codes for "Update a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy--status-codes)
Status code | Description
---|---
`200` | Response when the updated information already exists
`201` | Created
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#update-a-team-legacy--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 201
patch/teams/{team_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID \   -d '{"name":"new team name","description":"new team description","privacy":"closed","notification_setting":"notifications_enabled"}'`
Response when the updated information already exists
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDQ6VGVhbTE=",   "url": "https://api.github.com/teams/1",   "html_url": "https://github.com/orgs/github/teams/justice-league",   "name": "Justice League",   "slug": "justice-league",   "description": "A great team.",   "privacy": "closed",   "notification_setting": "notifications_enabled",   "permission": "admin",   "members_url": "https://api.github.com/teams/1/members{/member}",   "repositories_url": "https://api.github.com/teams/1/repos",   "parent": null,   "members_count": 3,   "repos_count": 10,   "created_at": "2017-07-14T16:53:42Z",   "updated_at": "2017-08-17T12:37:15Z",   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization",     "name": "github",     "company": "GitHub",     "blog": "https://github.com/blog",     "location": "San Francisco",     "email": "octocat@github.com",     "is_verified": true,     "has_organization_projects": true,     "has_repository_projects": true,     "public_repos": 2,     "public_gists": 1,     "followers": 20,     "following": 0,     "html_url": "https://github.com/octocat",     "created_at": "2008-01-14T04:33:35Z",     "updated_at": "2017-08-17T12:37:15Z",     "type": "Organization"   } }`
## [Delete a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [Delete a team](https://docs.github.com/rest/teams/teams#delete-a-team) endpoint.
To delete a team, the authenticated user must be an organization owner or team maintainer.
If you are an organization owner, deleting a parent team will delete all of its child teams as well.
### [Fine-grained access tokens for "Delete a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Delete a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
### [HTTP response status codes for "Delete a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#delete-a-team-legacy--code-samples)
#### Request example
delete/teams/{team_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID`
Response
`Status: 204`
## [List team repositories (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [List team repositories](https://docs.github.com/rest/teams/teams#list-team-repositories) endpoint.
### [Fine-grained access tokens for "List team repositories (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List team repositories (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List team repositories (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List team repositories (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-team-repositories-legacy--code-samples)
#### Request example
get/teams/{team_id}/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID/repos`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "has_discussions": false,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } ]`
## [Check team permissions for a repository (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [Check team permissions for a repository](https://docs.github.com/rest/teams/teams#check-team-permissions-for-a-repository) endpoint.
Repositories inherited through a parent team will also be checked.
You can also get information about the specified repository, including what permissions the team grants on it, by passing the following custom [media type](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types/) via the `Accept` header:
### [Fine-grained access tokens for "Check team permissions for a repository (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Check team permissions for a repository (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check team permissions for a repository (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy--status-codes)
Status code | Description
---|---
`200` | Alternative response with extra repository information
`204` | Response if repository is managed by this team
`404` | Not Found if repository is not managed by this team
### [Code samples for "Check team permissions for a repository (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#check-team-permissions-for-a-repository-legacy--code-samples)
#### Request example
get/teams/{team_id}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID/repos/OWNER/REPO`
Alternative response with extra repository information
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "language": null,   "forks_count": 9,   "stargazers_count": 80,   "watchers_count": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "admin": false,     "maintain": false,     "push": false,     "triage": false,     "pull": true   },   "role_name": "read",   "allow_rebase_merge": true,   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "subscribers_count": 42,   "network_count": 0,   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://api.github.com/licenses/mit"   },   "forks": 1,   "open_issues": 1,   "watchers": 1 }`
## [Add or update team repository permissions (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new "[Add or update team repository permissions](https://docs.github.com/rest/teams/teams#add-or-update-team-repository-permissions)" endpoint.
To add a repository to a team or update the team's permission on a repository, the authenticated user must have admin access to the repository, and must be able to see the team. The repository must be owned by the organization, or a direct fork of a repository owned by the organization. You will get a `422 Unprocessable Entity` status if you attempt to add a repository to a team that is not owned by the organization.
Note that, if you choose not to pass any parameters, you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)."
### [Fine-grained access tokens for "Add or update team repository permissions (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Add or update team repository permissions (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`permission` string The permission to grant the team on this repository. If no permission is specified, the team's `permission` attribute will be used to determine what permission to grant the team on this repository. Can be one of: `pull`, `push`, `admin`
### [HTTP response status codes for "Add or update team repository permissions (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy--status-codes)
Status code | Description
---|---
`204` | No Content
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add or update team repository permissions (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#add-or-update-team-repository-permissions-legacy--code-samples)
#### Request example
put/teams/{team_id}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID/repos/OWNER/REPO \   -d '{"permission":"push"}'`
Response
`Status: 204`
## [Remove a repository from a team (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [Remove a repository from a team](https://docs.github.com/rest/teams/teams#remove-a-repository-from-a-team) endpoint.
If the authenticated user is an organization owner or a team maintainer, they can remove any repositories from the team. To remove a repository from a team as an organization member, the authenticated user must have admin access to the repository and must be able to see the team. NOTE: This does not delete the repository, it just removes it from the team.
### [Fine-grained access tokens for "Remove a repository from a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Members" organization permissions (read) and "Metadata" repository permissions (read)


### [Parameters for "Remove a repository from a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Remove a repository from a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove a repository from a team (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#remove-a-repository-from-a-team-legacy--code-samples)
#### Request example
delete/teams/{team_id}/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID/repos/OWNER/REPO`
Response
`Status: 204`
## [List child teams (Legacy)](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy)
**Endpoint closing down notice:** This endpoint route is closing down and will be removed from the Teams API. We recommend migrating your existing code to use the new [`List child teams`](https://docs.github.com/rest/teams/teams#list-child-teams) endpoint.
### [Fine-grained access tokens for "List child teams (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List child teams (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`team_id` integer Required The unique identifier of the team.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List child teams (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy--status-codes)
Status code | Description
---|---
`200` | if child teams exist
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List child teams (Legacy)"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-child-teams-legacy--code-samples)
#### Request example
get/teams/{team_id}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/teams/TEAM_ID/teams`
if child teams exist
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 2,     "node_id": "MDQ6VGVhbTI=",     "url": "https://api.github.com/teams/2",     "name": "Original Roster",     "slug": "original-roster",     "description": "Started it all.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/2/members{/member}",     "repositories_url": "https://api.github.com/teams/2/repos",     "parent": {       "id": 1,       "node_id": "MDQ6VGVhbTE=",       "url": "https://api.github.com/teams/1",       "html_url": "https://github.com/orgs/github/teams/justice-league",       "name": "Justice League",       "slug": "justice-league",       "description": "A great team.",       "privacy": "closed",       "notification_setting": "notifications_enabled",       "permission": "admin",       "members_url": "https://api.github.com/teams/1/members{/member}",       "repositories_url": "https://api.github.com/teams/1/repos"     },     "html_url": "https://github.com/orgs/rails/teams/core"   } ]`
## [List teams for the authenticated user](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user)
List all of the teams across all of the organizations to which the authenticated user belongs.
OAuth app tokens and personal access tokens (classic) need the `user`, `repo`, or `read:org` scope to use this endpoint.
When using a fine-grained personal access token, the resource owner of the token must be a single organization, and the response will only include the teams from that organization.
### [Fine-grained access tokens for "List teams for the authenticated user"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List teams for the authenticated user"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List teams for the authenticated user"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List teams for the authenticated user"](https://docs.github.com/en/rest/teams/teams?apiVersion=2022-11-28#list-teams-for-the-authenticated-user--code-samples)
#### Request example
get/user/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/teams`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null,     "members_count": 3,     "repos_count": 10,     "created_at": "2017-07-14T16:53:42Z",     "updated_at": "2017-08-17T12:37:15Z",     "organization": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "hooks_url": "https://api.github.com/orgs/github/hooks",       "issues_url": "https://api.github.com/orgs/github/issues",       "members_url": "https://api.github.com/orgs/github/members{/member}",       "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "description": "A great organization",       "name": "github",       "company": "GitHub",       "blog": "https://github.com/blog",       "location": "San Francisco",       "email": "octocat@github.com",       "is_verified": true,       "has_organization_projects": true,       "has_repository_projects": true,       "public_repos": 2,       "public_gists": 1,       "followers": 20,       "following": 0,       "html_url": "https://github.com/octocat",       "created_at": "2008-01-14T04:33:35Z",       "updated_at": "2017-08-17T12:37:15Z",       "type": "Organization"     }   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/teams/teams.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for teams - GitHub Docs
