[Skip to main content](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflow runs](https://docs.github.com/en/rest/actions/workflow-runs "Workflow runs")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
      * [About workflow runs in GitHub Actions](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#about-workflow-runs-in-github-actions)
      * [Re-run a job from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run)
      * [List workflow runs for a repository](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository)
      * [Get a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run)
      * [Delete a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run)
      * [Get the review history for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run)
      * [Approve a workflow run for a fork pull request](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request)
      * [Get a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt)
      * [Download workflow run attempt logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs)
      * [Cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run)
      * [Review custom deployment protection rules for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run)
      * [Force cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run)
      * [Download workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs)
      * [Delete workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs)
      * [Get pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run)
      * [Review pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run)
      * [Re-run a workflow](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow)
      * [Re-run failed jobs from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run)
      * [Get workflow run usage](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage)
      * [List workflow runs for a workflow](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow)
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Workflow runs](https://docs.github.com/en/rest/actions/workflow-runs "Workflow runs")


# REST API endpoints for workflow runs
Use the REST API to interact with workflow runs in GitHub Actions.
## [About workflow runs in GitHub Actions](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#about-workflow-runs-in-github-actions)
You can use the REST API to view, re-run, cancel, and view logs for workflow runs in GitHub Actions. A workflow run is an instance of your workflow that runs when the pre-configured event occurs. For more information, see [Managing workflow runs](https://docs.github.com/en/actions/managing-workflow-runs).
## [Re-run a job from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run)
Re-run a job and its dependent jobs in a workflow run.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Re-run a job from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Re-run a job from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`job_id` integer Required The unique identifier of the job.
Body parameters Name, Type, Description
---
`enable_debug_logging` boolean Whether to enable debug logging for the re-run. Default: `false`
### [HTTP response status codes for "Re-run a job from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run--status-codes)
Status code | Description
---|---
`201` | Created
`403` | Forbidden
### [Code samples for "Re-run a job from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-job-from-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/jobs/{job_id}/rerun
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/jobs/JOB_ID/rerun`
Response
  * Example response
  * Response schema


`Status: 201`
## [List workflow runs for a repository](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository)
Lists all workflow runs for a repository. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters).
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
This endpoint will return up to 1,000 results for each search when using the following parameters: `actor`, `branch`, `check_suite_id`, `created`, `event`, `head_sha`, `status`.
### [Fine-grained access tokens for "List workflow runs for a repository"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List workflow runs for a repository"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`actor` string Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run.
`branch` string Returns workflow runs associated with a branch. Use the name of the branch of the `push`.
`event` string Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)."
`status` string Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. Can be one of: `completed`, `action_required`, `cancelled`, `failure`, `neutral`, `skipped`, `stale`, `success`, `timed_out`, `in_progress`, `queued`, `requested`, `waiting`, `pending`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`created` string Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
`exclude_pull_requests` boolean If `true` pull requests are omitted from the response (empty array). Default: `false`
`check_suite_id` integer Returns workflow runs with the `check_suite_id` that you specify.
`head_sha` string Only returns workflow runs that are associated with the specified `head_sha`.
### [HTTP response status codes for "List workflow runs for a repository"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List workflow runs for a repository"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "workflow_runs": [     {       "id": 30433642,       "name": "Build",       "node_id": "MDEyOldvcmtmbG93IFJ1bjI2OTI4OQ==",       "check_suite_id": 42,       "check_suite_node_id": "MDEwOkNoZWNrU3VpdGU0Mg==",       "head_branch": "master",       "head_sha": "acb5820ced9479c074f688cc328bf03f341a511d",       "path": ".github/workflows/build.yml@main",       "run_number": 562,       "event": "push",       "display_title": "Update README.md",       "status": "queued",       "conclusion": null,       "workflow_id": 159038,       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642",       "html_url": "https://github.com/octo-org/octo-repo/actions/runs/30433642",       "pull_requests": [],       "created_at": "2020-01-22T19:33:08Z",       "updated_at": "2020-01-22T19:33:08Z",       "actor": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "run_attempt": 1,       "run_started_at": "2020-01-22T19:33:08Z",       "triggering_actor": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "jobs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/jobs",       "logs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/logs",       "check_suite_url": "https://api.github.com/repos/octo-org/octo-repo/check-suites/414944374",       "artifacts_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/artifacts",       "cancel_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/cancel",       "rerun_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/rerun",       "workflow_url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/159038",       "head_commit": {         "id": "acb5820ced9479c074f688cc328bf03f341a511d",         "tree_id": "d23f6eedb1e1b9610bbc754ddb5197bfe7271223",         "message": "Create linter.yaml",         "timestamp": "2020-01-22T19:33:05Z",         "author": {           "name": "Octo Cat",           "email": "octocat@github.com"         },         "committer": {           "name": "GitHub",           "email": "noreply@github.com"         }       },       "repository": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"       },       "head_repository": {         "id": 217723378,         "node_id": "MDEwOlJlcG9zaXRvcnkyMTc3MjMzNzg=",         "name": "octo-repo",         "full_name": "octo-org/octo-repo",         "private": true,         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "html_url": "https://github.com/octo-org/octo-repo",         "description": null,         "fork": false,         "url": "https://api.github.com/repos/octo-org/octo-repo",         "forks_url": "https://api.github.com/repos/octo-org/octo-repo/forks",         "keys_url": "https://api.github.com/repos/octo-org/octo-repo/keys{/key_id}",         "collaborators_url": "https://api.github.com/repos/octo-org/octo-repo/collaborators{/collaborator}",         "teams_url": "https://api.github.com/repos/octo-org/octo-repo/teams",         "hooks_url": "https://api.github.com/repos/octo-org/octo-repo/hooks",         "issue_events_url": "https://api.github.com/repos/octo-org/octo-repo/issues/events{/number}",         "events_url": "https://api.github.com/repos/octo-org/octo-repo/events",         "assignees_url": "https://api.github.com/repos/octo-org/octo-repo/assignees{/user}",         "branches_url": "https://api.github.com/repos/octo-org/octo-repo/branches{/branch}",         "tags_url": "https://api.github.com/repos/octo-org/octo-repo/tags",         "blobs_url": "https://api.github.com/repos/octo-org/octo-repo/git/blobs{/sha}",         "git_tags_url": "https://api.github.com/repos/octo-org/octo-repo/git/tags{/sha}",         "git_refs_url": "https://api.github.com/repos/octo-org/octo-repo/git/refs{/sha}",         "trees_url": "https://api.github.com/repos/octo-org/octo-repo/git/trees{/sha}",         "statuses_url": "https://api.github.com/repos/octo-org/octo-repo/statuses/{sha}",         "languages_url": "https://api.github.com/repos/octo-org/octo-repo/languages",         "stargazers_url": "https://api.github.com/repos/octo-org/octo-repo/stargazers",         "contributors_url": "https://api.github.com/repos/octo-org/octo-repo/contributors",         "subscribers_url": "https://api.github.com/repos/octo-org/octo-repo/subscribers",         "subscription_url": "https://api.github.com/repos/octo-org/octo-repo/subscription",         "commits_url": "https://api.github.com/repos/octo-org/octo-repo/commits{/sha}",         "git_commits_url": "https://api.github.com/repos/octo-org/octo-repo/git/commits{/sha}",         "comments_url": "https://api.github.com/repos/octo-org/octo-repo/comments{/number}",         "issue_comment_url": "https://api.github.com/repos/octo-org/octo-repo/issues/comments{/number}",         "contents_url": "https://api.github.com/repos/octo-org/octo-repo/contents/{+path}",         "compare_url": "https://api.github.com/repos/octo-org/octo-repo/compare/{base}...{head}",         "merges_url": "https://api.github.com/repos/octo-org/octo-repo/merges",         "archive_url": "https://api.github.com/repos/octo-org/octo-repo/{archive_format}{/ref}",         "downloads_url": "https://api.github.com/repos/octo-org/octo-repo/downloads",         "issues_url": "https://api.github.com/repos/octo-org/octo-repo/issues{/number}",         "pulls_url": "https://api.github.com/repos/octo-org/octo-repo/pulls{/number}",         "milestones_url": "https://api.github.com/repos/octo-org/octo-repo/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octo-org/octo-repo/notifications{?since,all,participating}",         "labels_url": "https://api.github.com/repos/octo-org/octo-repo/labels{/name}",         "releases_url": "https://api.github.com/repos/octo-org/octo-repo/releases{/id}",         "deployments_url": "https://api.github.com/repos/octo-org/octo-repo/deployments"       }     }   ] }`
## [Get a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run)
Gets a specific workflow run.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
Query parameters Name, Type, Description
---
`exclude_pull_requests` boolean If `true` pull requests are omitted from the response (empty array). Default: `false`
### [HTTP response status codes for "Get a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 30433642,   "name": "Build",   "node_id": "MDEyOldvcmtmbG93IFJ1bjI2OTI4OQ==",   "check_suite_id": 42,   "check_suite_node_id": "MDEwOkNoZWNrU3VpdGU0Mg==",   "head_branch": "main",   "head_sha": "acb5820ced9479c074f688cc328bf03f341a511d",   "path": ".github/workflows/build.yml@main",   "run_number": 562,   "event": "push",   "display_title": "Update README.md",   "status": "queued",   "conclusion": null,   "workflow_id": 159038,   "url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642",   "html_url": "https://github.com/octo-org/octo-repo/actions/runs/30433642",   "pull_requests": [],   "created_at": "2020-01-22T19:33:08Z",   "updated_at": "2020-01-22T19:33:08Z",   "actor": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "run_attempt": 1,   "referenced_workflows": [     {       "path": "octocat/Hello-World/.github/workflows/deploy.yml@main",       "sha": "86e8bc9ecf7d38b1ed2d2cfb8eb87ba9b35b01db",       "ref": "refs/heads/main"     },     {       "path": "octo-org/octo-repo/.github/workflows/report.yml@v2",       "sha": "79e9790903e1c3373b1a3e3a941d57405478a232",       "ref": "refs/tags/v2"     },     {       "path": "octo-org/octo-repo/.github/workflows/secure.yml@1595d4b6de6a9e9751fb270a41019ce507d4099e",       "sha": "1595d4b6de6a9e9751fb270a41019ce507d4099e"     }   ],   "run_started_at": "2020-01-22T19:33:08Z",   "triggering_actor": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "jobs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/jobs",   "logs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/logs",   "check_suite_url": "https://api.github.com/repos/octo-org/octo-repo/check-suites/414944374",   "artifacts_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/artifacts",   "cancel_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/cancel",   "rerun_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/rerun",   "previous_attempt_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/attempts/1",   "workflow_url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/159038",   "head_commit": {     "id": "acb5820ced9479c074f688cc328bf03f341a511d",     "tree_id": "d23f6eedb1e1b9610bbc754ddb5197bfe7271223",     "message": "Create linter.yaml",     "timestamp": "2020-01-22T19:33:05Z",     "author": {       "name": "Octo Cat",       "email": "octocat@github.com"     },     "committer": {       "name": "GitHub",       "email": "noreply@github.com"     }   },   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"   },   "head_repository": {     "id": 217723378,     "node_id": "MDEwOlJlcG9zaXRvcnkyMTc3MjMzNzg=",     "name": "octo-repo",     "full_name": "octo-org/octo-repo",     "private": true,     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "html_url": "https://github.com/octo-org/octo-repo",     "description": null,     "fork": false,     "url": "https://api.github.com/repos/octo-org/octo-repo",     "forks_url": "https://api.github.com/repos/octo-org/octo-repo/forks",     "keys_url": "https://api.github.com/repos/octo-org/octo-repo/keys{/key_id}",     "collaborators_url": "https://api.github.com/repos/octo-org/octo-repo/collaborators{/collaborator}",     "teams_url": "https://api.github.com/repos/octo-org/octo-repo/teams",     "hooks_url": "https://api.github.com/repos/octo-org/octo-repo/hooks",     "issue_events_url": "https://api.github.com/repos/octo-org/octo-repo/issues/events{/number}",     "events_url": "https://api.github.com/repos/octo-org/octo-repo/events",     "assignees_url": "https://api.github.com/repos/octo-org/octo-repo/assignees{/user}",     "branches_url": "https://api.github.com/repos/octo-org/octo-repo/branches{/branch}",     "tags_url": "https://api.github.com/repos/octo-org/octo-repo/tags",     "blobs_url": "https://api.github.com/repos/octo-org/octo-repo/git/blobs{/sha}",     "git_tags_url": "https://api.github.com/repos/octo-org/octo-repo/git/tags{/sha}",     "git_refs_url": "https://api.github.com/repos/octo-org/octo-repo/git/refs{/sha}",     "trees_url": "https://api.github.com/repos/octo-org/octo-repo/git/trees{/sha}",     "statuses_url": "https://api.github.com/repos/octo-org/octo-repo/statuses/{sha}",     "languages_url": "https://api.github.com/repos/octo-org/octo-repo/languages",     "stargazers_url": "https://api.github.com/repos/octo-org/octo-repo/stargazers",     "contributors_url": "https://api.github.com/repos/octo-org/octo-repo/contributors",     "subscribers_url": "https://api.github.com/repos/octo-org/octo-repo/subscribers",     "subscription_url": "https://api.github.com/repos/octo-org/octo-repo/subscription",     "commits_url": "https://api.github.com/repos/octo-org/octo-repo/commits{/sha}",     "git_commits_url": "https://api.github.com/repos/octo-org/octo-repo/git/commits{/sha}",     "comments_url": "https://api.github.com/repos/octo-org/octo-repo/comments{/number}",     "issue_comment_url": "https://api.github.com/repos/octo-org/octo-repo/issues/comments{/number}",     "contents_url": "https://api.github.com/repos/octo-org/octo-repo/contents/{+path}",     "compare_url": "https://api.github.com/repos/octo-org/octo-repo/compare/{base}...{head}",     "merges_url": "https://api.github.com/repos/octo-org/octo-repo/merges",     "archive_url": "https://api.github.com/repos/octo-org/octo-repo/{archive_format}{/ref}",     "downloads_url": "https://api.github.com/repos/octo-org/octo-repo/downloads",     "issues_url": "https://api.github.com/repos/octo-org/octo-repo/issues{/number}",     "pulls_url": "https://api.github.com/repos/octo-org/octo-repo/pulls{/number}",     "milestones_url": "https://api.github.com/repos/octo-org/octo-repo/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octo-org/octo-repo/notifications{?since,all,participating}",     "labels_url": "https://api.github.com/repos/octo-org/octo-repo/labels{/name}",     "releases_url": "https://api.github.com/repos/octo-org/octo-repo/releases{/id}",     "deployments_url": "https://api.github.com/repos/octo-org/octo-repo/deployments"   } }`
## [Delete a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run)
Deletes a specific workflow run.
Anyone with write access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Delete a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Delete a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-a-workflow-run--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/runs/{run_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID`
Response
`Status: 204`
## [Get the review history for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run)
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get the review history for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get the review history for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Get the review history for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get the review history for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-the-review-history-for-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/approvals
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/approvals`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "state": "approved",     "comment": "Ship it!",     "environments": [       {         "id": 161088068,         "node_id": "MDExOkVudmlyb25tZW50MTYxMDg4MDY4",         "name": "staging",         "url": "https://api.github.com/repos/github/hello-world/environments/staging",         "html_url": "https://github.com/github/hello-world/deployments/activity_log?environments_filter=staging",         "created_at": "2020-11-23T22:00:40Z",         "updated_at": "2020-11-23T22:00:40Z"       }     ],     "user": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   } ]`
## [Approve a workflow run for a fork pull request](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request)
Approves a workflow run for a pull request from a public fork of a first time contributor. For more information, see ["Approving workflow runs from public forks](https://docs.github.com/actions/managing-workflow-runs/approving-workflow-runs-from-public-forks)."
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Approve a workflow run for a fork pull request"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Approve a workflow run for a fork pull request"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Approve a workflow run for a fork pull request"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request--status-codes)
Status code | Description
---|---
`201` | Created
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Approve a workflow run for a fork pull request"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#approve-a-workflow-run-for-a-fork-pull-request--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/approve
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/approve`
Response
  * Example response
  * Response schema


`Status: 201`
## [Get a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt)
Gets a specific workflow run attempt.
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
`attempt_number` integer Required The attempt number of the workflow run.
Query parameters Name, Type, Description
---
`exclude_pull_requests` boolean If `true` pull requests are omitted from the response (empty array). Default: `false`
### [HTTP response status codes for "Get a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a workflow run attempt"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-a-workflow-run-attempt--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/attempts/ATTEMPT_NUMBER`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 30433642,   "name": "Build",   "node_id": "MDEyOldvcmtmbG93IFJ1bjI2OTI4OQ==",   "check_suite_id": 42,   "check_suite_node_id": "MDEwOkNoZWNrU3VpdGU0Mg==",   "head_branch": "main",   "head_sha": "acb5820ced9479c074f688cc328bf03f341a511d",   "path": ".github/workflows/build.yml@main",   "run_number": 562,   "event": "push",   "display_title": "Update README.md",   "status": "queued",   "conclusion": null,   "workflow_id": 159038,   "url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642",   "html_url": "https://github.com/octo-org/octo-repo/actions/runs/30433642",   "pull_requests": [],   "created_at": "2020-01-22T19:33:08Z",   "updated_at": "2020-01-22T19:33:08Z",   "actor": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "run_attempt": 1,   "referenced_workflows": [     {       "path": "octocat/Hello-World/.github/workflows/deploy.yml@main",       "sha": "86e8bc9ecf7d38b1ed2d2cfb8eb87ba9b35b01db",       "ref": "refs/heads/main"     },     {       "path": "octo-org/octo-repo/.github/workflows/report.yml@v2",       "sha": "79e9790903e1c3373b1a3e3a941d57405478a232",       "ref": "refs/tags/v2"     },     {       "path": "octo-org/octo-repo/.github/workflows/secure.yml@1595d4b6de6a9e9751fb270a41019ce507d4099e",       "sha": "1595d4b6de6a9e9751fb270a41019ce507d4099e"     }   ],   "run_started_at": "2020-01-22T19:33:08Z",   "triggering_actor": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "jobs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/jobs",   "logs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/logs",   "check_suite_url": "https://api.github.com/repos/octo-org/octo-repo/check-suites/414944374",   "artifacts_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/artifacts",   "cancel_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/cancel",   "rerun_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/rerun",   "previous_attempt_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/attempts/1",   "workflow_url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/159038",   "head_commit": {     "id": "acb5820ced9479c074f688cc328bf03f341a511d",     "tree_id": "d23f6eedb1e1b9610bbc754ddb5197bfe7271223",     "message": "Create linter.yaml",     "timestamp": "2020-01-22T19:33:05Z",     "author": {       "name": "Octo Cat",       "email": "octocat@github.com"     },     "committer": {       "name": "GitHub",       "email": "noreply@github.com"     }   },   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"   },   "head_repository": {     "id": 217723378,     "node_id": "MDEwOlJlcG9zaXRvcnkyMTc3MjMzNzg=",     "name": "octo-repo",     "full_name": "octo-org/octo-repo",     "private": true,     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "html_url": "https://github.com/octo-org/octo-repo",     "description": null,     "fork": false,     "url": "https://api.github.com/repos/octo-org/octo-repo",     "forks_url": "https://api.github.com/repos/octo-org/octo-repo/forks",     "keys_url": "https://api.github.com/repos/octo-org/octo-repo/keys{/key_id}",     "collaborators_url": "https://api.github.com/repos/octo-org/octo-repo/collaborators{/collaborator}",     "teams_url": "https://api.github.com/repos/octo-org/octo-repo/teams",     "hooks_url": "https://api.github.com/repos/octo-org/octo-repo/hooks",     "issue_events_url": "https://api.github.com/repos/octo-org/octo-repo/issues/events{/number}",     "events_url": "https://api.github.com/repos/octo-org/octo-repo/events",     "assignees_url": "https://api.github.com/repos/octo-org/octo-repo/assignees{/user}",     "branches_url": "https://api.github.com/repos/octo-org/octo-repo/branches{/branch}",     "tags_url": "https://api.github.com/repos/octo-org/octo-repo/tags",     "blobs_url": "https://api.github.com/repos/octo-org/octo-repo/git/blobs{/sha}",     "git_tags_url": "https://api.github.com/repos/octo-org/octo-repo/git/tags{/sha}",     "git_refs_url": "https://api.github.com/repos/octo-org/octo-repo/git/refs{/sha}",     "trees_url": "https://api.github.com/repos/octo-org/octo-repo/git/trees{/sha}",     "statuses_url": "https://api.github.com/repos/octo-org/octo-repo/statuses/{sha}",     "languages_url": "https://api.github.com/repos/octo-org/octo-repo/languages",     "stargazers_url": "https://api.github.com/repos/octo-org/octo-repo/stargazers",     "contributors_url": "https://api.github.com/repos/octo-org/octo-repo/contributors",     "subscribers_url": "https://api.github.com/repos/octo-org/octo-repo/subscribers",     "subscription_url": "https://api.github.com/repos/octo-org/octo-repo/subscription",     "commits_url": "https://api.github.com/repos/octo-org/octo-repo/commits{/sha}",     "git_commits_url": "https://api.github.com/repos/octo-org/octo-repo/git/commits{/sha}",     "comments_url": "https://api.github.com/repos/octo-org/octo-repo/comments{/number}",     "issue_comment_url": "https://api.github.com/repos/octo-org/octo-repo/issues/comments{/number}",     "contents_url": "https://api.github.com/repos/octo-org/octo-repo/contents/{+path}",     "compare_url": "https://api.github.com/repos/octo-org/octo-repo/compare/{base}...{head}",     "merges_url": "https://api.github.com/repos/octo-org/octo-repo/merges",     "archive_url": "https://api.github.com/repos/octo-org/octo-repo/{archive_format}{/ref}",     "downloads_url": "https://api.github.com/repos/octo-org/octo-repo/downloads",     "issues_url": "https://api.github.com/repos/octo-org/octo-repo/issues{/number}",     "pulls_url": "https://api.github.com/repos/octo-org/octo-repo/pulls{/number}",     "milestones_url": "https://api.github.com/repos/octo-org/octo-repo/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octo-org/octo-repo/notifications{?since,all,participating}",     "labels_url": "https://api.github.com/repos/octo-org/octo-repo/labels{/name}",     "releases_url": "https://api.github.com/repos/octo-org/octo-repo/releases{/id}",     "deployments_url": "https://api.github.com/repos/octo-org/octo-repo/deployments"   } }`
## [Download workflow run attempt logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs)
Gets a redirect URL to download an archive of log files for a specific workflow run attempt. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download.
Anyone with read access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Download workflow run attempt logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Download workflow run attempt logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
`attempt_number` integer Required The attempt number of the workflow run.
### [HTTP response status codes for "Download workflow run attempt logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs--status-codes)
Status code | Description
---|---
`302` | Found
### [Code samples for "Download workflow run attempt logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-attempt-logs--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/logs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/attempts/ATTEMPT_NUMBER/logs`
Response
`Status: 302`
## [Cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run)
Cancels a workflow run using its `id`.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run--status-codes)
Status code | Description
---|---
`202` | Accepted
`409` | Conflict
### [Code samples for "Cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#cancel-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/cancel
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/cancel`
Response
  * Example response
  * Response schema


`Status: 202`
## [Review custom deployment protection rules for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run)
Approve or reject custom deployment protection rules provided by a GitHub App for a workflow run. For more information, see "[Using environments for deployment](https://docs.github.com/actions/deployment/targeting-different-environments/using-environments-for-deployment)."
GitHub Apps can only review their own custom deployment protection rules. To approve or reject pending deployments that are waiting for review from a specific person or team, see [`POST /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments`](https://docs.github.com/rest/actions/workflow-runs#review-pending-deployments-for-a-workflow-run).
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Review custom deployment protection rules for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Deployments" repository permissions (write)


### [Parameters for "Review custom deployment protection rules for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Review custom deployment protection rules for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Review custom deployment protection rules for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-custom-deployment-protection-rules-for-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/deployment_protection_rule
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/deployment_protection_rule \   -d '{"environment_name":"prod-eus","state":"approved","comment":"All health checks passed."}'`
Response
`Status: 204`
## [Force cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run)
Cancels a workflow run and bypasses conditions that would otherwise cause a workflow execution to continue, such as an `always()` condition on a job. You should only use this endpoint to cancel a workflow run when the workflow run is not responding to [`POST /repos/{owner}/{repo}/actions/runs/{run_id}/cancel`](https://docs.github.com/rest/actions/workflow-runs#cancel-a-workflow-run).
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Force cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Force cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Force cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run--status-codes)
Status code | Description
---|---
`202` | Accepted
`409` | Conflict
### [Code samples for "Force cancel a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#force-cancel-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/force-cancel
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/force-cancel`
Response
  * Example response
  * Response schema


`Status: 202`
## [Download workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs)
Gets a redirect URL to download an archive of log files for a workflow run. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download.
Anyone with read access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Download workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Download workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Download workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs--status-codes)
Status code | Description
---|---
`302` | Found
### [Code samples for "Download workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#download-workflow-run-logs--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/logs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/logs`
Response
`Status: 302`
## [Delete workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs)
Deletes all logs for a workflow run.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Delete workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Delete workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs--status-codes)
Status code | Description
---|---
`204` | No Content
`403` | Forbidden
`500` | Internal Error
### [Code samples for "Delete workflow run logs"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#delete-workflow-run-logs--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/runs/{run_id}/logs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/logs`
Response
`Status: 204`
## [Get pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run)
Get all deployment environments for a workflow run that are waiting for protection rules to pass.
Anyone with read access to the repository can use this endpoint.
If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Get pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-pending-deployments-for-a-workflow-run--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/pending_deployments`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "environment": {       "id": 161088068,       "node_id": "MDExOkVudmlyb25tZW50MTYxMDg4MDY4",       "name": "staging",       "url": "https://api.github.com/repos/github/hello-world/environments/staging",       "html_url": "https://github.com/github/hello-world/deployments/activity_log?environments_filter=staging"     },     "wait_timer": 30,     "wait_timer_started_at": "2020-11-23T22:00:40Z",     "current_user_can_approve": true,     "reviewers": [       {         "type": "User",         "reviewer": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         }       },       {         "type": "Team",         "reviewer": {           "id": 1,           "node_id": "MDQ6VGVhbTE=",           "url": "https://api.github.com/teams/1",           "html_url": "https://github.com/orgs/github/teams/justice-league",           "name": "Justice League",           "slug": "justice-league",           "description": "A great team.",           "privacy": "closed",           "notification_setting": "notifications_enabled",           "permission": "admin",           "members_url": "https://api.github.com/teams/1/members{/member}",           "repositories_url": "https://api.github.com/teams/1/repos",           "parent": null         }       }     ]   } ]`
## [Review pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run)
Approve or reject pending deployments that are waiting on approval by a required reviewer.
Required reviewers with read access to the repository contents and deployments can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Review pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Deployments" repository permissions (write)


### [Parameters for "Review pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
Body parameters Name, Type, Description
---
`environment_ids` array of integers Required The list of environment ids to approve or reject
`state` string Required Whether to approve or reject deployment to the specified environments. Can be one of: `approved`, `rejected`
`comment` string Required A comment to accompany the deployment review
### [HTTP response status codes for "Review pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Review pending deployments for a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#review-pending-deployments-for-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/pending_deployments \   -d '{"environment_ids":[161171787],"state":"approved","comment":"Ship it!"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/repos/octocat/example/deployments/1",     "id": 1,     "node_id": "MDEwOkRlcGxveW1lbnQx",     "sha": "a84d88e7554fc1fa21bcbc4efae3c782a70d2b9d",     "ref": "topic-branch",     "task": "deploy",     "payload": {},     "original_environment": "staging",     "environment": "production",     "description": "Deploy request from hubot",     "creator": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "created_at": "2012-07-20T01:19:13Z",     "updated_at": "2012-07-20T01:19:13Z",     "statuses_url": "https://api.github.com/repos/octocat/example/deployments/1/statuses",     "repository_url": "https://api.github.com/repos/octocat/example",     "transient_environment": false,     "production_environment": true   } ]`
## [Re-run a workflow](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow)
Re-runs your workflow run using its `id`.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Re-run a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Re-run a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
Body parameters Name, Type, Description
---
`enable_debug_logging` boolean Whether to enable debug logging for the re-run. Default: `false`
### [HTTP response status codes for "Re-run a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Re-run a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-a-workflow--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/rerun
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/rerun`
Response
  * Example response
  * Response schema


`Status: 201`
## [Re-run failed jobs from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run)
Re-run all of the failed jobs and their dependent jobs in a workflow run using the `id` of the workflow run.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Re-run failed jobs from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (write)


### [Parameters for "Re-run failed jobs from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
Body parameters Name, Type, Description
---
`enable_debug_logging` boolean Whether to enable debug logging for the re-run. Default: `false`
### [HTTP response status codes for "Re-run failed jobs from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Re-run failed jobs from a workflow run"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#re-run-failed-jobs-from-a-workflow-run--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runs/{run_id}/rerun-failed-jobs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/rerun-failed-jobs`
Response
  * Example response
  * Response schema


`Status: 201`
## [Get workflow run usage](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage)

This endpoint is in the process of closing down. Refer to "[Actions Get workflow usage and Get workflow run usage endpoints closing down](https://github.blog/changelog/2025-02-02-actions-get-workflow-usage-and-get-workflow-run-usage-endpoints-closing-down/)" for more information.
Gets the number of billable minutes and total run time for a specific workflow run. Billable minutes only apply to workflows in private repositories that use GitHub-hosted runners. Usage is listed for each GitHub-hosted runner operating system in milliseconds. Any job re-runs are also included in the usage. The usage does not include the multiplier for macOS and Windows runners and is not rounded up to the nearest whole minute. For more information, see "[Managing billing for GitHub Actions](https://docs.github.com/github/setting-up-and-managing-billing-and-payments-on-github/managing-billing-for-github-actions)".
Anyone with read access to the repository can use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "Get workflow run usage"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get workflow run usage"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`run_id` integer Required The unique identifier of the workflow run.
### [HTTP response status codes for "Get workflow run usage"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get workflow run usage"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#get-workflow-run-usage--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runs/{run_id}/timing
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runs/RUN_ID/timing`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "billable": {     "UBUNTU": {       "total_ms": 180000,       "jobs": 1,       "job_runs": [         {           "job_id": 1,           "duration_ms": 180000         }       ]     },     "MACOS": {       "total_ms": 240000,       "jobs": 4,       "job_runs": [         {           "job_id": 2,           "duration_ms": 60000         },         {           "job_id": 3,           "duration_ms": 60000         },         {           "job_id": 4,           "duration_ms": 60000         },         {           "job_id": 5,           "duration_ms": 60000         }       ]     },     "WINDOWS": {       "total_ms": 300000,       "jobs": 2,       "job_runs": [         {           "job_id": 6,           "duration_ms": 150000         },         {           "job_id": 7,           "duration_ms": 150000         }       ]     }   },   "run_duration_ms": 500000 }`
## [List workflow runs for a workflow](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow)
List all workflow runs for a workflow. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters).
Anyone with read access to the repository can use this endpoint
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository.
This endpoint will return up to 1,000 results for each search when using the following parameters: `actor`, `branch`, `check_suite_id`, `created`, `event`, `head_sha`, `status`.
### [Fine-grained access tokens for "List workflow runs for a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Actions" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List workflow runs for a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`workflow_id` Required The ID of the workflow. You can also pass the workflow file name as a string.
Query parameters Name, Type, Description
---
`actor` string Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run.
`branch` string Returns workflow runs associated with a branch. Use the name of the branch of the `push`.
`event` string Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)."
`status` string Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. Can be one of: `completed`, `action_required`, `cancelled`, `failure`, `neutral`, `skipped`, `stale`, `success`, `timed_out`, `in_progress`, `queued`, `requested`, `waiting`, `pending`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`created` string Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
`exclude_pull_requests` boolean If `true` pull requests are omitted from the response (empty array). Default: `false`
`check_suite_id` integer Returns workflow runs with the `check_suite_id` that you specify.
`head_sha` string Only returns workflow runs that are associated with the specified `head_sha`.
### [HTTP response status codes for "List workflow runs for a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List workflow runs for a workflow"](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2022-11-28#list-workflow-runs-for-a-workflow--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/workflows/WORKFLOW_ID/runs`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "workflow_runs": [     {       "id": 30433642,       "name": "Build",       "node_id": "MDEyOldvcmtmbG93IFJ1bjI2OTI4OQ==",       "check_suite_id": 42,       "check_suite_node_id": "MDEwOkNoZWNrU3VpdGU0Mg==",       "head_branch": "master",       "head_sha": "acb5820ced9479c074f688cc328bf03f341a511d",       "path": ".github/workflows/build.yml@main",       "run_number": 562,       "event": "push",       "display_title": "Update README.md",       "status": "queued",       "conclusion": null,       "workflow_id": 159038,       "url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642",       "html_url": "https://github.com/octo-org/octo-repo/actions/runs/30433642",       "pull_requests": [],       "created_at": "2020-01-22T19:33:08Z",       "updated_at": "2020-01-22T19:33:08Z",       "actor": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "run_attempt": 1,       "run_started_at": "2020-01-22T19:33:08Z",       "triggering_actor": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "jobs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/jobs",       "logs_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/logs",       "check_suite_url": "https://api.github.com/repos/octo-org/octo-repo/check-suites/414944374",       "artifacts_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/artifacts",       "cancel_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/cancel",       "rerun_url": "https://api.github.com/repos/octo-org/octo-repo/actions/runs/30433642/rerun",       "workflow_url": "https://api.github.com/repos/octo-org/octo-repo/actions/workflows/159038",       "head_commit": {         "id": "acb5820ced9479c074f688cc328bf03f341a511d",         "tree_id": "d23f6eedb1e1b9610bbc754ddb5197bfe7271223",         "message": "Create linter.yaml",         "timestamp": "2020-01-22T19:33:05Z",         "author": {           "name": "Octo Cat",           "email": "octocat@github.com"         },         "committer": {           "name": "GitHub",           "email": "noreply@github.com"         }       },       "repository": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"       },       "head_repository": {         "id": 217723378,         "node_id": "MDEwOlJlcG9zaXRvcnkyMTc3MjMzNzg=",         "name": "octo-repo",         "full_name": "octo-org/octo-repo",         "private": true,         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "html_url": "https://github.com/octo-org/octo-repo",         "description": null,         "fork": false,         "url": "https://api.github.com/repos/octo-org/octo-repo",         "forks_url": "https://api.github.com/repos/octo-org/octo-repo/forks",         "keys_url": "https://api.github.com/repos/octo-org/octo-repo/keys{/key_id}",         "collaborators_url": "https://api.github.com/repos/octo-org/octo-repo/collaborators{/collaborator}",         "teams_url": "https://api.github.com/repos/octo-org/octo-repo/teams",         "hooks_url": "https://api.github.com/repos/octo-org/octo-repo/hooks",         "issue_events_url": "https://api.github.com/repos/octo-org/octo-repo/issues/events{/number}",         "events_url": "https://api.github.com/repos/octo-org/octo-repo/events",         "assignees_url": "https://api.github.com/repos/octo-org/octo-repo/assignees{/user}",         "branches_url": "https://api.github.com/repos/octo-org/octo-repo/branches{/branch}",         "tags_url": "https://api.github.com/repos/octo-org/octo-repo/tags",         "blobs_url": "https://api.github.com/repos/octo-org/octo-repo/git/blobs{/sha}",         "git_tags_url": "https://api.github.com/repos/octo-org/octo-repo/git/tags{/sha}",         "git_refs_url": "https://api.github.com/repos/octo-org/octo-repo/git/refs{/sha}",         "trees_url": "https://api.github.com/repos/octo-org/octo-repo/git/trees{/sha}",         "statuses_url": "https://api.github.com/repos/octo-org/octo-repo/statuses/{sha}",         "languages_url": "https://api.github.com/repos/octo-org/octo-repo/languages",         "stargazers_url": "https://api.github.com/repos/octo-org/octo-repo/stargazers",         "contributors_url": "https://api.github.com/repos/octo-org/octo-repo/contributors",         "subscribers_url": "https://api.github.com/repos/octo-org/octo-repo/subscribers",         "subscription_url": "https://api.github.com/repos/octo-org/octo-repo/subscription",         "commits_url": "https://api.github.com/repos/octo-org/octo-repo/commits{/sha}",         "git_commits_url": "https://api.github.com/repos/octo-org/octo-repo/git/commits{/sha}",         "comments_url": "https://api.github.com/repos/octo-org/octo-repo/comments{/number}",         "issue_comment_url": "https://api.github.com/repos/octo-org/octo-repo/issues/comments{/number}",         "contents_url": "https://api.github.com/repos/octo-org/octo-repo/contents/{+path}",         "compare_url": "https://api.github.com/repos/octo-org/octo-repo/compare/{base}...{head}",         "merges_url": "https://api.github.com/repos/octo-org/octo-repo/merges",         "archive_url": "https://api.github.com/repos/octo-org/octo-repo/{archive_format}{/ref}",         "downloads_url": "https://api.github.com/repos/octo-org/octo-repo/downloads",         "issues_url": "https://api.github.com/repos/octo-org/octo-repo/issues{/number}",         "pulls_url": "https://api.github.com/repos/octo-org/octo-repo/pulls{/number}",         "milestones_url": "https://api.github.com/repos/octo-org/octo-repo/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octo-org/octo-repo/notifications{?since,all,participating}",         "labels_url": "https://api.github.com/repos/octo-org/octo-repo/labels{/name}",         "releases_url": "https://api.github.com/repos/octo-org/octo-repo/releases{/id}",         "deployments_url": "https://api.github.com/repos/octo-org/octo-repo/deployments"       }     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/workflow-runs.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for workflow runs - GitHub Docs
