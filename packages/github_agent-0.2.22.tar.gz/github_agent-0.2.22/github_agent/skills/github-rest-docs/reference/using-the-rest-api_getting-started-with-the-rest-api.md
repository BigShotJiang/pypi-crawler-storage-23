[Skip to main content](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Using the REST API](https://docs.github.com/en/rest/using-the-rest-api "Using the REST API")/
  * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api "Getting started")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Using the REST API](https://docs.github.com/en/rest/using-the-rest-api "Using the REST API")/
  * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api "Getting started")


# Getting started with the REST API
Learn how to use the GitHub REST API.
## Tool navigation
  * [GitHub CLI](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28&tool=cli)
  * [curl](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28&tool=curl)
  * [JavaScript](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28&tool=javascript)


## In this article
  * [Introduction](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#introduction)
  * [About requests to the REST API](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#about-requests-to-the-rest-api)
  * [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request)
  * [Using the response](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#using-the-response)
  * [Next steps](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#next-steps)


## [Introduction](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#introduction)
This article describes how to use the GitHub REST API with GitHub CLI, `curl`, or JavaScript. For a quickstart guide, see [Quickstart for GitHub REST API](https://docs.github.com/en/rest/quickstart).
## [About requests to the REST API](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#about-requests-to-the-rest-api)
This section describes the elements that make up an API request:
  * [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method)
  * [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path)
  * [Headers](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#headers)
  * [Media types](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#media-types)
  * [Authentication](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authentication)
  * [Parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#parameters)


Every request to the REST API includes an HTTP method and a path. Depending on the REST API endpoint, you might also need to specify request headers, authentication information, query parameters, or body parameters.
The REST API reference documentation describes the HTTP method, path, and parameters for every endpoint. It also displays example requests and responses for each endpoint. For more information, see the [REST reference documentation](https://docs.github.com/en/rest).
### [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method)
The HTTP method of an endpoint defines the type of action it performs on a given resource. Some common HTTP methods are `GET`, `POST`, `DELETE`, and `PATCH`. The REST API reference documentation provides the HTTP method for every endpoint.
For example, the HTTP method for the ["List repository issues" endpoint](https://docs.github.com/en/rest/issues/issues#list-repository-issues) is `GET`."
Where possible, the GitHub REST API strives to use an appropriate HTTP method for each action.
  * `GET`: Used for retrieving resources.
  * `POST`: Used for creating resources.
  * `PATCH`: Used for updating properties of resources.
  * `PUT`: Used for replacing resources or collections of resources.
  * `DELETE`: Used for deleting resources.


### [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path)
Each endpoint has a path. The REST API reference documentation gives the path for every endpoint. For example, the path for the ["List repository issues" endpoint](https://docs.github.com/en/rest/issues/issues#list-repository-issues) is `/repos/{owner}/{repo}/issues`.
The curly brackets `{}` in a path denote path parameters that you need to specify. Path parameters modify the endpoint path and are required in your request. For example, the path parameters for the ["List repository issues" endpoint](https://docs.github.com/en/rest/issues/issues#list-repository-issues) are `{owner}` and `{repo}`. To use this path in your API request, replace `{repo}` with the name of the repository where you would like to request a list of issues, and replace `{owner}` with the name of the account that owns the repository.
### [Headers](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#headers)
Headers provide extra information about the request and the desired response. Following are some examples of headers that you can use in your requests to the GitHub REST API. For an example of a request that uses headers, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
#### [`Accept`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#accept)
Most GitHub REST API endpoints specify that you should pass an `Accept` header with a value of `application/vnd.github+json`. The value of the `Accept` header is a media type. For more information about media types, see [Media types](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#media-types).
#### [`X-GitHub-Api-Version`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#x-github-api-version)
You should use this header to specify a version of the REST API to use for your request. For more information, see [API Versions](https://docs.github.com/en/rest/overview/api-versions).
#### [`User-Agent`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#user-agent)
All API requests must include a valid `User-Agent` header. The `User-Agent` header identifies the user or application that is making the request.
By default, GitHub CLI sends a valid `User-Agent` header. However, GitHub recommends using your GitHub username, or the name of your application, for the `User-Agent` header value. This allows GitHub to contact you if there are problems.
By default, `curl` sends a valid `User-Agent` header. However GitHub recommends using your GitHub username, or the name of your application, for the `User-Agent` header value. This allows GitHub to contact you if there are problems.
If you use the Octokit.js SDK, the SDK will send a valid `User-Agent` header for you. However, GitHub recommends using your GitHub username, or the name of your application, for the `User-Agent` header value. This allows GitHub to contact you if there are problems.
The following is an example `User-Agent` for an app named `Awesome-Octocat-App`:
```
User-Agent: Awesome-Octocat-App

```

Requests with no `User-Agent` header will be rejected. If you provide an invalid `User-Agent` header, you will receive a `403 Forbidden` response.
### [Media types](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#media-types)
You can specify one or more media types by adding them to the `Accept` header of your request. For more information about the `Accept` header, see [`Accept`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#accept).
Media types specify the format of the data you want to consume from the API. Media types are specific to resources, allowing them to change independently and support formats that other resources don't. The documentation for each GitHub REST API endpoint will describe the media types that it supports. For more information, see the [GitHub REST API documentation](https://docs.github.com/en/rest).
The most common media types supported by the GitHub REST API are `application/vnd.github+json` and `application/json`.
There are custom media types that you can use with some endpoints. For example, the REST API to manage [commits](https://docs.github.com/en/rest/commits/commits#get-a-commit) and [pull requests](https://docs.github.com/en/rest/pulls/pulls) support the media types `diff`, `patch`, and `sha`. The media types `full`, `raw`, `text`, or `html` are used by some other endpoints.
All custom media types for GitHub look like this: `application/vnd.github.PARAM+json`, where `PARAM` is the name of the media type. For example, to specify the `raw` media type, you would use `application/vnd.github.raw+json`.
For an example of a request that uses media types, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
### [Authentication](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authentication)
Many endpoints require authentication or return additional information if you are authenticated. Additionally, you can make more requests per hour when you are authenticated.
To authenticate your request, you will need to provide an authentication token with the required scopes or permissions. There a few different ways to get a token: You can create a personal access token, generate a token with a GitHub App, or use the built-in `GITHUB_TOKEN` in a GitHub Actions workflow. For more information, see [Authenticating to the REST API](https://docs.github.com/en/rest/overview/authenticating-to-the-rest-api).
For an example of a request that uses an authentication token, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
If you don't want to create a token, you can use GitHub CLI. GitHub CLI will take care of authentication for you, and help keep your account secure. For more information, see the [GitHub CLI version of this page](https://docs.github.com/en/rest/guides/getting-started-with-the-rest-api?tool=cli).
Treat your access token the same way you would treat your passwords or other sensitive credentials. For more information, see [Keeping your API credentials secure](https://docs.github.com/en/rest/overview/keeping-your-api-credentials-secure).
Although some REST API endpoints are accessible without authentication, GitHub CLI requires you to authenticate before you can use the `api` subcommand to make an API request. Use the `auth login` subcommand to authenticate to GitHub. For more information, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
To authenticate your request, you will need to provide an authentication token with the required scopes or permissions. There a few different ways to get a token: You can create a personal access token, generate a token with a GitHub App, or use the built-in `GITHUB_TOKEN` in a GitHub Actions workflow. For more information, see [Authenticating to the REST API](https://docs.github.com/en/rest/overview/authenticating-to-the-rest-api).
For an example of a request that uses an authentication token, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
Treat your access token the same way you would treat your passwords or other sensitive credentials. For more information, see [Keeping your API credentials secure](https://docs.github.com/en/rest/overview/keeping-your-api-credentials-secure).
### [Parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#parameters)
Many API methods require or allow you to send additional information in parameters in your request. There are a few different types of parameters: Path parameters, body parameters, and query parameters.
#### [Path parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path-parameters)
Path parameters modify the endpoint path. These parameters are required in your request. For more information, see [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
#### [Body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#body-parameters)
Body parameters allow you to pass additional data to the API. These parameters can be optional or required, depending on the endpoint. For example, a body parameter may allow you to specify an issue title when creating a new issue, or specify certain settings when enabling or disabling a feature. The documentation for each GitHub REST API endpoint will describe the body parameters that it supports. For more information, see the [GitHub REST API documentation](https://docs.github.com/en/rest).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) requires that you specify a title for the new issue in your request. It also allows you to optionally specify other information, such as text to put in the issue body, users to assign to the new issue, or labels to apply to the new issue. For an example of a request that uses body parameters, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
You must authenticate your request to pass body parameters. For more information, see [Authenticating](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authenticating).
#### [Query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#query-parameters)
Query parameters allow you to control what data is returned for a request. These parameters are usually optional. The documentation for each GitHub REST API endpoint will describe any query parameters that it supports. For more information, see the [GitHub REST API documentation](https://docs.github.com/en/rest).
For example, the ["List public events" endpoint](https://docs.github.com/en/rest/activity/events#list-public-events) returns thirty issues by default. You can use the `per_page` query parameter to return two issues instead of 30. You can use the `page` query parameter to fetch only the first page of results. For an example of a request that uses query parameters, see [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request).
## [Making a request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#making-a-request)
This section demonstrates how to make an authenticated request to the GitHub REST API using GitHub CLI.
### [1. Setup](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#1-setup)
Install GitHub CLI on macOS, Windows, or Linux. For more information, see [Installation](https://github.com/cli/cli#installation) in the GitHub CLI repository.
### [2. Authenticate](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#2-authenticate)
  1. To authenticate to GitHub, run the following command from your terminal.
```
gh auth login

```

You can use the `--scopes` option to specify what scopes you want. If you want to authenticate with a token that you created, you can use the `--with-token` option. For more information, see the [GitHub CLI `auth login` documentation](https://cli.github.com/manual/gh_auth_login).
  2. Select where you want to authenticate to:
     * If you access GitHub at GitHub.com, select **GitHub.com**.
     * If you access GitHub at a different domain, select **Other** , then enter your hostname (for example: `octocorp.ghe.com`).
  3. Follow the rest of the on-screen prompts.
GitHub CLI automatically stores your Git credentials for you when you choose HTTPS as your preferred protocol for Git operations and answer "yes" to the prompt asking if you would like to authenticate to Git with your GitHub credentials. This can be useful as it allows you to use Git commands like `git push` and `git pull` without needing to set up a separate credential manager or use SSH.


### [3. Choose an endpoint for your request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#3-choose-an-endpoint-for-your-request)
  1. Choose an endpoint to make a request to. You can explore GitHub's [REST API documentation](https://docs.github.com/en/rest) to discover endpoints that you can use to interact with GitHub.
  2. Identify the HTTP method and path of the endpoint. You will send these with your request. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method) and [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the HTTP method `POST` and the path `/repos/{owner}/{repo}/issues`.
  3. Identify any required path parameters. Required path parameters appear in curly brackets `{}` in the path of the endpoint. Replace each parameter placeholder with the desired value. For more information, see [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the path `/repos/{owner}/{repo}/issues`, and the path parameters are `{owner}` and `{repo}`. To use this path in your API request, replace `{repo}` with the name of the repository where you would like to create a new issue, and replace `{owner}` with the name of the account that owns the repository.


### [4. Make a request with GitHub CLI](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#4-make-a-request-with-github-cli)
Use the GitHub CLI `api` subcommand to make your API request. For more information, see the [GitHub CLI `api` documentation](https://cli.github.com/manual/gh_api).
In your request, specify the following options and values:
  * **--method** followed by the HTTP method and the path of the endpoint. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method) and [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
  * **--header:**
    * **`Accept`:** Pass the media type in an `Accept` header. To pass multiple media types in an `Accept` header, separate the media types with a comma: `Accept: application/vnd.github+json,application/vnd.github.diff`. For more information, see [`Accept`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#accept) and [Media types](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#media-types).
    * **`X-GitHub-Api-Version`:** Pass the API version in a `X-GitHub-Api-Version` header. For more information, see [`X-GitHub-Api-Version`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#x-github-api-version).
  * **`-f`**or**`-F`**followed by any body parameters or query parameters in`key=value` format. Use the `-F` option to pass a parameter that is a number, Boolean, or null. Use the `-f` option to pass string parameters.
Some endpoints use query parameters that are arrays. To send an array in the query string, use the query parameter once per array item, and append `[]` after the query parameter name. For example, to provide an array of two repository IDs, use `-f repository_ids[]=REPOSITORY_A_ID -f repository_ids[]=REPOSITORY_B_ID`.
If you do not need to specify any body parameters or query parameters in your request, omit this option. For more information, see [Body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#body-parameters) and [Query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#query-parameters). For examples, see [Example request using body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-body-parameters) and [Example request using query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-query-parameters).


#### [Example request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request)
The following example request uses the ["Get Octocat" endpoint](https://docs.github.com/en/rest/meta/meta#get-octocat) to return the octocat as ASCII art.
Shell```
gh api --method GET /octocat \
--header 'Accept: application/vnd.github+json' \
--header "X-GitHub-Api-Version: 2022-11-28"

```
```
gh api --method GET /octocat \
--header 'Accept: application/vnd.github+json' \
--header "X-GitHub-Api-Version: 2022-11-28"

```

#### [Example request using query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-query-parameters)
The ["List public events" endpoint](https://docs.github.com/en/rest/activity/events#list-public-events) returns thirty issues by default. The following example uses the `per_page` query parameter to return two issues instead of 30, and the `page` query parameter to fetch only the first page of results.
Shell```
gh api --method GET /events -F per_page=2 -F page=1
--header 'Accept: application/vnd.github+json' \

```
```
gh api --method GET /events -F per_page=2 -F page=1
--header 'Accept: application/vnd.github+json' \

```

#### [Example request using body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-body-parameters)
The following example uses the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) to create a new issue in the octocat/Spoon-Knife repository. In the response, find the `html_url` of your issue, and navigate to your issue in the browser.
Shell```
gh api --method POST /repos/octocat/Spoon-Knife/issues \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
-f title='Created with the REST API' \
-f body='This is a test issue created by the REST API' \

```
```
gh api --method POST /repos/octocat/Spoon-Knife/issues \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
-f title='Created with the REST API' \
-f body='This is a test issue created by the REST API' \

```

This section demonstrates how to make an authenticated request to the GitHub REST API using `curl`.
### [1. Setup](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#1-setup-1)
You must have `curl` installed on your machine. To check if `curl` is already installed, run `curl --version` on the command line.
  * If the output provides information about the version of `curl`, that means `curl` is installed.
  * If you get a message similar to `command not found: curl`, that means `curl` is not installed. Download and install `curl`. For more information, see [the curl download page](https://curl.se/download.html).


### [2. Choose an endpoint for your request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#2-choose-an-endpoint-for-your-request)
  1. Choose an endpoint to make a request to. You can explore GitHub's [REST API documentation](https://docs.github.com/en/rest) to discover endpoints that you can use to interact with GitHub.
  2. Identify the HTTP method and path of the endpoint. You will send these with your request. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method) and [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the HTTP method `POST` and the path `/repos/{owner}/{repo}/issues`.
  3. Identify any required path parameters. Required path parameters appear in curly brackets `{}` in the path of the endpoint. Replace each parameter placeholder with the desired value. For more information, see [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the path `/repos/{owner}/{repo}/issues`, and the path parameters are `{owner}` and `{repo}`. To use this path in your API request, replace `{repo}` with the name of the repository where you would like to create a new issue, and replace `{owner}` with the name of the account that owns the repository.


### [3. Create authentication credentials](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#3-create-authentication-credentials)
Create an access token to authenticate your request. You can save your token and use it for multiple requests. Give the token any scopes or permissions that are required to access the endpoint. You will send this token in an `Authorization` header with your request. For more information, see [Authentication](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authentication).
### [4. Make a `curl` request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#4-make-a-curl-request)
Use the `curl` command to make your request. For more information, see [the curl documentation](https://curl.se/docs/manpage.html).
Specify the following options and values in your request:
  * **`--request`or`-X`** followed by the HTTP method as the value. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method).
  * **`--url`**followed by the full path as the value. The full path is a URL that includes the base URL for the GitHub REST API (`https://api.github.com`) and the path of the endpoint, like this: `https://api.github.com/PATH`. Replace `PATH` with the path of the endpoint. For more information, see [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
To use query parameters, add a `?` to the end of the path, then append your query parameter name and value in the form `parameter_name=value`. Separate multiple query parameters with `&`. If you need to send an array in the query string, use the query parameter once per array item, and append `[]` after the query parameter name. For example, to provide an array of two repository IDs, use `?repository_ids[]=REPOSITORY_A_ID&repository_ids[]=REPOSITORY_B_ID`. For more information, see [Query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#query-parameters). For an example, see [Example request using query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-query-parameters-1).
  * **`--header`or`-H` :**
    * **`Accept`:** Pass the media type in an `Accept` header. To pass multiple media types in an `Accept` header, separate the media types with a comma, for example: `Accept: application/vnd.github+json,application/vnd.github.diff`. For more information, see [`Accept`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#accept) and [Media types](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#media-types).
    * **`X-GitHub-Api-Version`:** Pass the API version in a `X-GitHub-Api-Version` header. For more information, see [`X-GitHub-Api-Version`](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#x-github-api-version).
    * **`Authorization`:** Pass your authentication token in an `Authorization` header. Note that in most cases you can use `Authorization: Bearer` or `Authorization: token` to pass a token. However, if you are passing a JSON web token (JWT), you must use `Authorization: Bearer`. For more information, see [Authentication](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authentication). For an example of a request that uses an `Authorization` header, see [Example request using body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-body-parameters-1).
  * **`--data`or`-d`** followed by any body parameters within a JSON object. If you do not need to specify any body parameters in your request, omit this option. For more information, see [Body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#body-parameters). For an example, see [Example request using body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-body-parameters-1).


#### [Example request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-1)
The following example request uses the ["Get Octocat" endpoint](https://docs.github.com/en/rest/meta/meta#get-octocat) to return the octocat as ASCII art.
Shell```
curl --request GET \
--url "https://api.github.com/octocat" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28"

```
```
curl --request GET \
--url "https://api.github.com/octocat" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28"

```

#### [Example request using query parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-query-parameters-1)
The ["List public events" endpoint](https://docs.github.com/en/rest/activity/events#list-public-events) returns thirty issues by default. The following example uses the `per_page` query parameter to return two issues instead of 30, and the `page` query parameter to fetch only the first page of results.
Shell```
curl --request GET \
--url "https://api.github.com/events?per_page=2&page=1" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
  https://api.github.com/events

```
```
curl --request GET \
--url "https://api.github.com/events?per_page=2&page=1" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
  https://api.github.com/events

```

#### [Example request using body parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#example-request-using-body-parameters-1)
The following example uses the [Create an issue](https://docs.github.com/en/rest/issues/issues#create-an-issue) endpoint to create a new issue in the octocat/Spoon-Knife repository. Replace `YOUR-TOKEN` with the authentication token you created in a previous step.
If you are using a fine-grained personal access token, you must replace `octocat/Spoon-Knife` with a repository that you own or that is owned by an organization that you are a member of. Your token must have access to that repository and have read and write permissions for repository issues. For more information, see [Managing your personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token).
Shell```
curl \
--request POST \
--url "https://api.github.com/repos/octocat/Spoon-Knife/issues" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
--header "Authorization: Bearer YOUR-TOKEN" \
--data '{
  "title": "Created with the REST API",
  "body": "This is a test issue created by the REST API"
}'

```
```
curl \
--request POST \
--url "https://api.github.com/repos/octocat/Spoon-Knife/issues" \
--header "Accept: application/vnd.github+json" \
--header "X-GitHub-Api-Version: 2022-11-28" \
--header "Authorization: Bearer YOUR-TOKEN" \
--data '{
  "title": "Created with the REST API",
  "body": "This is a test issue created by the REST API"
}'

```

This section demonstrates how to make a request to the GitHub REST API using JavaScript and [Octokit.js](https://github.com/octokit/octokit.js). For a more detailed guide, see [Scripting with the REST API and JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript).
### [1. Setup](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#1-setup-2)
You must install `octokit` to use the Octokit.js library shown in the following examples.
  * Install `octokit`. For example, `npm install octokit`. For other ways to install or load `octokit`, see [the Octokit.js README](https://github.com/octokit/octokit.js/#readme).


### [2. Choose an endpoint for your request](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#2-choose-an-endpoint-for-your-request-1)
  1. Choose an endpoint to make a request to. You can explore GitHub's [REST API documentation](https://docs.github.com/en/rest) to discover endpoints that you can use to interact with GitHub.
  2. Identify the HTTP method and path of the endpoint. You will send these with your request. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method) and [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the HTTP method `POST` and the path `/repos/{owner}/{repo}/issues`.
  3. Identify any required path parameters. Required path parameters appear in curly brackets `{}` in the path of the endpoint. Replace each parameter placeholder with the desired value. For more information, see [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
For example, the ["Create an issue" endpoint](https://docs.github.com/en/rest/issues/issues#create-an-issue) uses the path `/repos/{owner}/{repo}/issues`, and the path parameters are `{owner}` and `{repo}`. To use this path in your API request, replace `{repo}` with the name of the repository where you would like to create a new issue, and replace `{owner}` with the name of the account that owns the repository.


### [3. Create an access token](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#3-create-an-access-token)
Create an access token to authenticate your request. You can save your token and use it for multiple requests. Give the token any scopes or permissions that are required to access the endpoint. You will send this token in an `Authorization` header with your request. For more information, see [Authentication](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#authentication).
### [4. Make a request with Octokit.js](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#4-make-a-request-with-octokitjs)
  1. Import `octokit` in your script. For example, `import { Octokit } from "octokit";`. For other ways to import `octokit`, see [the Octokit.js README](https://github.com/octokit/octokit.js/#readme).
  2. Create an instance of `Octokit` with your token. Replace `YOUR-TOKEN` with your token.
JavaScript```
const octokit = new Octokit({
  auth: 'YOUR-TOKEN'
});

```
```
const octokit = new Octokit({
  auth: 'YOUR-TOKEN'
});

```

  3. Use `octokit.request` to execute your request.
     * Send the HTTP method and path as the first argument to the `request` method. For more information, see [HTTP method](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#http-method) and [Path](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#path).
     * Specify all path, query, and body parameters in an object as the second argument to the `request` method. For more information, see [Parameters](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#parameters).
In the following example request, the HTTP method is `POST`, the path is `/repos/{owner}/{repo}/issues`, the path parameters are `owner: "octocat"` and `repo: "Spoon-Knife"`, and the body parameters are `title: "Created with the REST API"` and `body: "This is a test issue created by the REST API"`.
If you are using a fine-grained personal access token, you must replace `octocat/Spoon-Knife` with a repository that you own or that is owned by an organization that you are a member of. Your token must have access to that repository and have read and write permissions for repository issues. For more information, see [Managing your personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token).
JavaScript```
await octokit.request("POST /repos/{owner}/{repo}/issues", {
  owner: "octocat",
  repo: "Spoon-Knife",
  title: "Created with the REST API",
  body: "This is a test issue created by the REST API",
});

```
```
await octokit.request("POST /repos/{owner}/{repo}/issues", {
  owner: "octocat",
  repo: "Spoon-Knife",
  title: "Created with the REST API",
  body: "This is a test issue created by the REST API",
});

```

The `request` method automatically passes the `Accept: application/vnd.github+json` header. To pass additional headers or a different `Accept` header, add a `headers` property to the object that is passed as a second argument. The value of the `headers` property is an object with the header names as keys and header values as values.
For example, the following code will send a `content-type` header with a value of `text/plain` and a `X-GitHub-Api-Version` header with a value of `2022-11-28`.
JavaScript```
await octokit.request("GET /octocat", {
  headers: {
    "content-type": "text/plain",
    "X-GitHub-Api-Version": "2022-11-28",
  },
});

```
```
await octokit.request("GET /octocat", {
  headers: {
    "content-type": "text/plain",
    "X-GitHub-Api-Version": "2022-11-28",
  },
});

```



## [Using the response](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#using-the-response)
After you make a request, the API will return the response status code, response headers, and potentially a response body.
### [About the response code and headers](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#about-the-response-code-and-headers)
Every request will return an HTTP status code that indicates the success of the response. For more information about response codes, see [the MDN HTTP response status code documentation](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status).
Additionally, the response will include headers that give more details about the response. Headers that start with `X-` or `x-` are custom to GitHub. For example, the `x-ratelimit-remaining` and `x-ratelimit-reset` headers tell you how many requests you can make in a time period.
To view the status code and headers, use the `--include` or `--i` option when you send your request.
For example, this request gets a list of issues in the octocat/Spoon-Knife repository:
```
gh api \
--header 'Accept: application/vnd.github+json' \
--method GET /repos/octocat/Spoon-Knife/issues \
-F per_page=2 --include

```

And it returns a response code and headers that look something like this:
```
HTTP/2.0 200 OK
Access-Control-Allow-Origin: *
Access-Control-Expose-Headers: ETag, Link, Location, Retry-After, X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Used, X-RateLimit-Resource, X-RateLimit-Reset, X-OAuth-Scopes, X-Accepted-OAuth-Scopes, X-Poll-Interval, X-GitHub-Media-Type, X-GitHub-SSO, X-GitHub-Request-Id, Deprecation, Sunset
Cache-Control: private, max-age=60, s-maxage=60
Content-Security-Policy: default-src 'none'
Content-Type: application/json; charset=utf-8
Date: Thu, 04 Aug 2022 19:56:41 GMT
Etag: W/"a63dfbcfdb73621e9d2e89551edcf9856731ced534bd7f1e114a5da1f5f73418"
Link: <https://api.github.com/repositories/1300192/issues?per_page=1&page=2>; rel="next", <https://api.github.com/repositories/1300192/issues?per_page=1&page=14817>; rel="last"
Referrer-Policy: origin-when-cross-origin, strict-origin-when-cross-origin
Server: GitHub.com
Strict-Transport-Security: max-age=31536000; includeSubdomains; preload
Vary: Accept, Authorization, Cookie, Accept-Encoding, Accept, X-Requested-With
X-Accepted-Oauth-Scopes: repo
X-Content-Type-Options: nosniff
X-Frame-Options: deny
X-Github-Api-Version-Selected: 2022-08-09
X-Github-Media-Type: github.v3; format=json
X-Github-Request-Id: 1C73:26D4:E2E500:1EF78F4:62EC2479
X-Oauth-Client-Id: 178c6fc778ccc68e1d6a
X-Oauth-Scopes: gist, read:org, repo, workflow
X-Ratelimit-Limit: 15000
X-Ratelimit-Remaining: 14996
X-Ratelimit-Reset: 1659645499
X-Ratelimit-Resource: core
X-Ratelimit-Used: 4
X-Xss-Protection: 0

```

In this example, the response code is `200`, which indicates a successful request.
When you make a request with Octokit.js, the `request` method returns a promise. If the request was successful, the promise resolves to an object that includes the HTTP status code of the response (`status`) and the response headers (`headers`). If an error occurs, the promise resolves to an object that includes the HTTP status code of the response (`status`) and the response headers (`response.headers`).
You can use a `try/catch` block to catch an error if it occurs. For example, if the request in the following script is successful, the script will log the status code and the value of the `x-ratelimit-remaining` header. If the request was not successful, the script will log the status code, the value of the `x-ratelimit-remaining` header, and the error message.
In the following example, replace `REPO-OWNER` with the name of the account that owns the repository, and `REPO-NAME` with the name of the repository.
JavaScript```
try {
  const result = await octokit.request("GET /repos/{owner}/{repo}/issues", {
    owner: "REPO-OWNER",
    repo: "REPO-NAME",
    per_page: 2,
  });

  console.log(`Success! Status: ${result.status}. Rate limit remaining: ${result.headers["x-ratelimit-remaining"]}`)

} catch (error) {
  console.log(`Error! Status: ${error.status}. Rate limit remaining: ${error.headers["x-ratelimit-remaining"]}. Message: ${error.response.data.message}`)
}

```
```
try {
  const result = await octokit.request("GET /repos/{owner}/{repo}/issues", {
    owner: "REPO-OWNER",
    repo: "REPO-NAME",
    per_page: 2,
  });

  console.log(`Success! Status: ${result.status}. Rate limit remaining: ${result.headers["x-ratelimit-remaining"]}`)

} catch (error) {
  console.log(`Error! Status: ${error.status}. Rate limit remaining: ${error.headers["x-ratelimit-remaining"]}. Message: ${error.response.data.message}`)
}

```

To view the status code and headers, use the `--include` or `--i` option when you send your request.
For example, this request gets a list of issues in the octocat/Spoon-Knife repository:
```
curl --request GET \
--url "https://api.github.com/repos/octocat/Spoon-Knife/issues?per_page=2" \
--header "Accept: application/vnd.github+json" \
--header "Authorization: Bearer YOUR-TOKEN" \
--include

```

And it returns a response code and headers that look something like this:
```
HTTP/2 200
server: GitHub.com
date: Thu, 04 Aug 2022 20:07:51 GMT
content-type: application/json; charset=utf-8
cache-control: public, max-age=60, s-maxage=60
vary: Accept, Accept-Encoding, Accept, X-Requested-With
etag: W/"7fceb7e8c958d3ec4d02524b042578dcc7b282192e6c939070f4a70390962e18"
x-github-media-type: github.v3; format=json
link: <https://api.github.com/repositories/1300192/issues?per_page=2&sort=updated&direction=asc&page=2>; rel="next", <https://api.github.com/repositories/1300192/issues?per_page=2&sort=updated&direction=asc&page=7409>; rel="last"
access-control-expose-headers: ETag, Link, Location, Retry-After, X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Used, X-RateLimit-Resource, X-RateLimit-Reset, X-OAuth-Scopes, X-Accepted-OAuth-Scopes, X-Poll-Interval, X-GitHub-Media-Type, X-GitHub-SSO, X-GitHub-Request-Id, Deprecation, Sunset
access-control-allow-origin: *
strict-transport-security: max-age=31536000; includeSubdomains; preload
x-frame-options: deny
x-content-type-options: nosniff
x-xss-protection: 0
referrer-policy: origin-when-cross-origin, strict-origin-when-cross-origin
content-security-policy: default-src 'none'
x-ratelimit-limit: 15000
x-ratelimit-remaining: 14996
x-ratelimit-reset: 1659645535
x-ratelimit-resource: core
x-ratelimit-used: 4
accept-ranges: bytes
content-length: 4936
x-github-request-id: 14E0:4BC6:F1B8BA:208E317:62EC2715

```

In this example, the response code is `200`, which indicates a successful request.
### [About the response body](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#about-the-response-body)
Many endpoints will return a response body. Unless otherwise specified, the response body is in JSON format. Blank fields are included as `null` instead of being omitted. All timestamps return in UTC time, ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`.
Unlike the GraphQL API where you specify what information you want, the REST API typically returns more information than you need. If desired, you can parse the response to pull out specific pieces of information.
For example, you can use `>` to redirect the response to a file. In the following example, replace `REPO-OWNER` with the name of the account that owns the repository, and `REPO-NAME` with the name of the repository.
Shell```
gh api \
--header 'Accept: application/vnd.github+json' \
--method GET /repos/REPO-OWNER/REPO-NAME/issues \
-F per_page=2 > data.json

```
```
gh api \
--header 'Accept: application/vnd.github+json' \
--method GET /repos/REPO-OWNER/REPO-NAME/issues \
-F per_page=2 > data.json

```

Then you can use jq to get the title and author ID of each issue:
Shell```
jq '.[] | {title: .title, authorID: .user.id}' data.json

```
```
jq '.[] | {title: .title, authorID: .user.id}' data.json

```

The previous two commands return something like:
```
{
  "title": "Update index.html",
  "authorID": 10701255
}
{
  "title": "Edit index file",
  "authorID": 53709285
}

```

For more information about jq, see [the jq documentation](https://stedolan.github.io/jq/).
For example, you can get the title and author ID of each issue. In the following example, replace `REPO-OWNER` with the name of the account that owns the repository, and `REPO-NAME` with the name of the repository.
JavaScript```
try {
  const result = await octokit.request("GET /repos/{owner}/{repo}/issues", {
    owner: "REPO-OWNER",
    repo: "REPO-NAME",
    per_page: 2,
  });

  const titleAndAuthor = result.data.map(issue => {title: issue.title, authorID: issue.user.id})

  console.log(titleAndAuthor)

} catch (error) {
  console.log(`Error! Status: ${error.status}. Message: ${error.response.data.message}`)
}

```
```
try {
  const result = await octokit.request("GET /repos/{owner}/{repo}/issues", {
    owner: "REPO-OWNER",
    repo: "REPO-NAME",
    per_page: 2,
  });

  const titleAndAuthor = result.data.map(issue => {title: issue.title, authorID: issue.user.id})

  console.log(titleAndAuthor)

} catch (error) {
  console.log(`Error! Status: ${error.status}. Message: ${error.response.data.message}`)
}

```

For example, you can use `>` to redirect the response to a file. In the following example, replace `REPO-OWNER` with the name of the account that owns the repository, and `REPO-NAME` with the name of the repository.
Shell```
curl --request GET \
--url "https://api.github.com/repos/REPO-OWNER/REPO-NAME/issues?per_page=2" \
--header "Accept: application/vnd.github+json" \
--header "Authorization: Bearer YOUR-TOKEN" > data.json

```
```
curl --request GET \
--url "https://api.github.com/repos/REPO-OWNER/REPO-NAME/issues?per_page=2" \
--header "Accept: application/vnd.github+json" \
--header "Authorization: Bearer YOUR-TOKEN" > data.json

```

Then you can use jq to get the title and author ID of each issue:
Shell```
jq '.[] | {title: .title, authorID: .user.id}' data.json

```
```
jq '.[] | {title: .title, authorID: .user.id}' data.json

```

The previous two commands return something like:
```
{
  "title": "Update index.html",
  "authorID": 10701255
}
{
  "title": "Edit index file",
  "authorID": 53709285
}

```

For more information about jq, see [the jq documentation](https://stedolan.github.io/jq/).
#### [Detailed versus summary representations](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#detailed-versus-summary-representations)
A response can include all attributes for a resource or only a subset of attributes, depending on whether you fetch an individual resource or a list of resources.
  * When you fetch an _individual resource_ , like a specific repository, the response will typically include all attributes for that resource. This is the "detailed" representation of the resource.
  * When you fetch a _list of resources_ , like a list of multiple repositories, the response will only include a subset of the attributes for each resource. This is the "summary" representation of the resource.


Note that authorization sometimes influences the amount of detail included in a representation.
The reason for this is because some attributes are computationally expensive for the API to provide, so GitHub excludes those attributes from the summary representation. To obtain those attributes, you can fetch the detailed representation.
The documentation provides an example response for each API method. The example response illustrates all attributes that are returned by that method.
#### [Hypermedia](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#hypermedia)
All resources may have one or more `*_url` properties linking to other resources. These are meant to provide explicit URLs so that proper API clients don't need to construct URLs on their own. It is highly recommended that API clients use these. Doing so will make future upgrades of the API easier for developers. All URLs are expected to be proper [RFC 6570](https://datatracker.ietf.org/doc/html/rfc6570) URI templates.
You can then expand these templates using something like the [uri_template](https://github.com/hannesg/uri_template) gem:
```
>> tmpl = URITemplate.new('/notifications{?since,all,participating}')
>> tmpl.expand
=> "/notifications"

>> tmpl.expand all: 1
=> "/notifications?all=1"

>> tmpl.expand all: 1, participating: 1
=> "/notifications?all=1&participating=1"

```

## [Next steps](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api?apiVersion=2022-11-28#next-steps)
This article demonstrated how to list and create issues in a repository. For more practice, try to comment on an issue, edit the title of an issue, or close an issue. For more information, see the ["Create an issue comment" endpoint](https://docs.github.com/en/rest/issues/comments#create-an-issue-comment) and the ["Update an issue" endpoint](https://docs.github.com/en/rest/issues/issues#update-an-issue).
For more information about other endpoints that you can use, see the [REST reference documentation](https://docs.github.com/en/rest).
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/using-the-rest-api/getting-started-with-the-rest-api.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


Getting started with the REST API - GitHub Docs
