[Skip to main content](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Migrations](https://docs.github.com/en/rest/migrations "Migrations")/
  * [Source endpoints](https://docs.github.com/en/rest/migrations/source-imports "Source endpoints")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
      * [About source imports](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#about-source-imports)
      * [Get an import status](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status)
      * [Start an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import)
      * [Update an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import)
      * [Cancel an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import)
      * [Get commit authors](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors)
      * [Map a commit author](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author)
      * [Get large files](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files)
      * [Update Git LFS preference](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference)
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Migrations](https://docs.github.com/en/rest/migrations "Migrations")/
  * [Source endpoints](https://docs.github.com/en/rest/migrations/source-imports "Source endpoints")


# REST API endpoints for source imports
Use the REST API to start an import from a Git source repository.
## [About source imports](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#about-source-imports)
Due to very low levels of usage and available alternatives, the Source Imports API has been retired. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
You can use these endpoints to start an import from a Git repository hosted with another service. This is the same functionality as the GitHub Importer. For more information, see [Importing a repository with GitHub Importer](https://docs.github.com/en/migrations/importing-source-code/using-github-importer/importing-a-repository-with-github-importer). A typical source import would start the import and then (optionally) update the authors and/or update the preference for using Git LFS if large files exist in the import. You can also create a webhook that listens for the [`RepositoryImportEvent`](https://docs.github.com/en/webhooks-and-events/webhooks/webhook-events-and-payloads#repository_import) to find out the status of the import.
These endpoints only support authentication using a personal access token (classic). For more information, see [Managing your personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token).
The following diagram provides a more detailed example:
```
+---------+                     +--------+                              +---------------------+
| Tooling |                     | GitHub |                              | Original Repository |
+---------+                     +--------+                              +---------------------+
     |                              |                                              |
     |  Start import                |                                              |
     |----------------------------->|                                              |
     |                              |                                              |
     |                              |  Download source data                        |
     |                              |--------------------------------------------->|
     |                              |                        Begin streaming data  |
     |                              |<---------------------------------------------|
     |                              |                                              |
     |  Get import progress         |                                              |
     |----------------------------->|                                              |
     |       "status": "importing"  |                                              |
     |<-----------------------------|                                              |
     |                              |                                              |
     |  Get commit authors          |                                              |
     |----------------------------->|                                              |
     |                              |                                              |
     |  Map a commit author         |                                              |
     |----------------------------->|                                              |
     |                              |                                              |
     |                              |                                              |
     |                              |                       Finish streaming data  |
     |                              |<---------------------------------------------|
     |                              |                                              |
     |                              |  Rewrite commits with mapped authors         |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |                              |  Update repository on GitHub                 |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |  Map a commit author         |                                              |
     |----------------------------->|                                              |
     |                              |  Rewrite commits with mapped authors         |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |                              |  Update repository on GitHub                 |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |  Get large files             |                                              |
     |----------------------------->|                                              |
     |                              |                                              |
     |  opt_in to Git LFS           |                                              |
     |----------------------------->|                                              |
     |                              |  Rewrite commits for large files             |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |                              |  Update repository on GitHub                 |
     |                              |------+                                       |
     |                              |      |                                       |
     |                              |<-----+                                       |
     |                              |                                              |
     |  Get import progress         |                                              |
     |----------------------------->|                                              |
     |        "status": "complete"  |                                              |
     |<-----------------------------|                                              |
     |                              |                                              |
     |                              |                                              |

```

## [Get an import status](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status)
View the progress of an import.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
**Import status**
This section includes details about the possible values of the `status` field of the Import Progress response.
An import that does not have errors will progress through these steps:
  * `detecting` - the "detection" step of the import is in progress because the request did not include a `vcs` parameter. The import is identifying the type of source control present at the URL.
  * `importing` - the "raw" step of the import is in progress. This is where commit data is fetched from the original repository. The import progress response will include `commit_count` (the total number of raw commits that will be imported) and `percent` (0 - 100, the current progress through the import).
  * `mapping` - the "rewrite" step of the import is in progress. This is where SVN branches are converted to Git branches, and where author updates are applied. The import progress response does not include progress information.
  * `pushing` - the "push" step of the import is in progress. This is where the importer updates the repository on GitHub. The import progress response will include `push_percent`, which is the percent value reported by `git push` when it is "Writing objects".
  * `complete` - the import is complete, and the repository is ready on GitHub.


If there are problems, you will see one of these in the `status` field:
  * `auth_failed` - the import requires authentication in order to connect to the original repository. To update authentication for the import, please see the [Update an import](https://docs.github.com/rest/migrations/source-imports#update-an-import) section.
  * `error` - the import encountered an error. The import progress response will include the `failed_step` and an error message. Contact [GitHub Support](https://support.github.com/contact?tags=dotcom-rest-api) for more information.
  * `detection_needs_auth` - the importer requires authentication for the originating repository to continue detection. To update authentication for the import, please see the [Update an import](https://docs.github.com/rest/migrations/source-imports#update-an-import) section.
  * `detection_found_nothing` - the importer didn't recognize any source control at the URL. To resolve, [Cancel the import](https://docs.github.com/rest/migrations/source-imports#cancel-an-import) and [retry](https://docs.github.com/rest/migrations/source-imports#start-an-import) with the correct URL.
  * `detection_found_multiple` - the importer found several projects or repositories at the provided URL. When this is the case, the Import Progress response will also include a `project_choices` field with the possible project choices as values. To update project choice, please see the [Update an import](https://docs.github.com/rest/migrations/source-imports#update-an-import) section.


**The project_choices field**
When multiple projects are found at the provided URL, the response hash will include a `project_choices` field, the value of which is an array of hashes each representing a project choice. The exact key/value pairs of the project hashes will differ depending on the version control type.
**Git LFS related fields**
This section includes details about Git LFS related fields that may be present in the Import Progress response.
  * `use_lfs` - describes whether the import has been opted in or out of using Git LFS. The value can be `opt_in`, `opt_out`, or `undecided` if no action has been taken.
  * `has_large_files` - the boolean value describing whether files larger than 100MB were found during the `importing` step.
  * `large_files_size` - the total size in gigabytes of files larger than 100MB found in the originating repository.
  * `large_files_count` - the total number of files larger than 100MB found in the originating repository. To see a list of these files, make a "Get Large Files" request.


### [Fine-grained access tokens for "Get an import status"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


### [Parameters for "Get an import status"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get an import status"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Unavailable due to service under maintenance.
### [Code samples for "Get an import status"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-an-import-status--code-samples)
#### Request example
get/repos/{owner}/{repo}/import
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "vcs": "subversion",   "use_lfs": true,   "vcs_url": "http://svn.mycompany.com/svn/myproject",   "status": "complete",   "status_text": "Done",   "has_large_files": true,   "large_files_size": 132331036,   "large_files_count": 1,   "authors_count": 4,   "url": "https://api.github.com/repos/octocat/socm/import",   "html_url": "https://import.github.com/octocat/socm/import",   "authors_url": "https://api.github.com/repos/octocat/socm/import/authors",   "repository_url": "https://api.github.com/repos/octocat/socm" }`
## [Start an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import)
Start a source import to a GitHub repository using GitHub Importer. Importing into a GitHub repository with GitHub Actions enabled is not supported and will return a status `422 Unprocessable Entity` response.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Start an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Start an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`vcs_url` string Required The URL of the originating repository.
`vcs` string The originating VCS type. Without this parameter, the import job will take additional time to detect the VCS type before beginning the import. This detection step will be reflected in the response. Can be one of: `subversion`, `git`, `mercurial`, `tfvc`
`vcs_username` string If authentication is required, the username to provide to `vcs_url`.
`vcs_password` string If authentication is required, the password to provide to `vcs_url`.
`tfvc_project` string For a tfvc import, the name of the project that is being imported.
### [HTTP response status codes for "Start an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
`503` | Unavailable due to service under maintenance.
### [Code samples for "Start an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#start-an-import--code-samples)
#### Request example
put/repos/{owner}/{repo}/import
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import \   -d '{"vcs":"subversion","vcs_url":"http://svn.mycompany.com/svn/myproject","vcs_username":"octocat","vcs_password":"secret"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "vcs": "subversion",   "use_lfs": true,   "vcs_url": "http://svn.mycompany.com/svn/myproject",   "status": "importing",   "status_text": "Importing...",   "has_large_files": false,   "large_files_size": 0,   "large_files_count": 0,   "authors_count": 0,   "commit_count": 1042,   "url": "https://api.github.com/repos/octocat/socm/import",   "html_url": "https://import.github.com/octocat/socm/import",   "authors_url": "https://api.github.com/repos/octocat/socm/import/authors",   "repository_url": "https://api.github.com/repos/octocat/socm" }`
## [Update an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import)
An import can be updated with credentials or a project choice by passing in the appropriate parameters in this API request. If no parameters are provided, the import will be restarted.
Some servers (e.g. TFS servers) can have several projects at a single URL. In those cases the import progress will have the status `detection_found_multiple` and the Import Progress response will include a `project_choices` array. You can select the project to import by providing one of the objects in the `project_choices` array in the update request.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Update an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Update an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`vcs_username` string The username to provide to the originating repository.
`vcs_password` string The password to provide to the originating repository.
`vcs` string The type of version control system you are migrating from. Can be one of: `subversion`, `tfvc`, `git`, `mercurial`
`tfvc_project` string For a tfvc import, the name of the project that is being imported.
### [HTTP response status codes for "Update an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import--status-codes)
Status code | Description
---|---
`200` | OK
`503` | Unavailable due to service under maintenance.
### [Code samples for "Update an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-an-import--code-samples)
#### Request examples
Select the example typeUpdate authentication for an import Updating the project choice Restarting an import
patch/repos/{owner}/{repo}/import
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import \   -d '{"vcs_username":"octocat","vcs_password":"secret"}'`
Example 1
  * Example response
  * Response schema


`Status: 200`
`{   "vcs": "subversion",   "use_lfs": true,   "vcs_url": "http://svn.mycompany.com/svn/myproject",   "status": "detecting",   "url": "https://api.github.com/repos/octocat/socm/import",   "html_url": "https://import.github.com/octocat/socm/import",   "authors_url": "https://api.github.com/repos/octocat/socm/import/authors",   "repository_url": "https://api.github.com/repos/octocat/socm" }`
## [Cancel an import](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import)
Stop an import for a repository.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Cancel an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Cancel an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Cancel an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import--status-codes)
Status code | Description
---|---
`204` | No Content
`503` | Unavailable due to service under maintenance.
### [Code samples for "Cancel an import"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#cancel-an-import--code-samples)
#### Request example
delete/repos/{owner}/{repo}/import
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import`
Response
`Status: 204`
## [Get commit authors](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors)
Each type of source control system represents authors in a different way. For example, a Git commit author has a display name and an email address, but a Subversion commit author just has a username. The GitHub Importer will make the author information valid, but the author might not be correct. For example, it will change the bare Subversion username `hubot` into something like `hubot <hubot@12341234-abab-fefe-8787-fedcba987654>`.
This endpoint and the [Map a commit author](https://docs.github.com/rest/migrations/source-imports#map-a-commit-author) endpoint allow you to provide correct Git author information.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Get commit authors"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


### [Parameters for "Get commit authors"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`since` integer A user ID. Only return users with an ID greater than this ID.
### [HTTP response status codes for "Get commit authors"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`503` | Unavailable due to service under maintenance.
### [Code samples for "Get commit authors"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-commit-authors--code-samples)
#### Request example
get/repos/{owner}/{repo}/import/authors
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import/authors`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 2268557,     "remote_id": "nobody@fc7da526-431c-80fe-3c8c-c148ff18d7ef",     "remote_name": "nobody",     "email": "hubot@github.com",     "name": "Hubot",     "url": "https://api.github.com/repos/octocat/socm/import/authors/2268557",     "import_url": "https://api.github.com/repos/octocat/socm/import"   },   {     "id": 2268558,     "remote_id": "svner@fc7da526-431c-80fe-3c8c-c148ff18d7ef",     "remote_name": "svner",     "email": "svner@fc7da526-431c-80fe-3c8c-c148ff18d7ef",     "name": "svner",     "url": "https://api.github.com/repos/octocat/socm/import/authors/2268558",     "import_url": "https://api.github.com/repos/octocat/socm/import"   },   {     "id": 2268559,     "remote_id": "svner@example.com@fc7da526-431c-80fe-3c8c-c148ff18d7ef",     "remote_name": "svner@example.com",     "email": "svner@example.com@fc7da526-431c-80fe-3c8c-c148ff18d7ef",     "name": "svner@example.com",     "url": "https://api.github.com/repos/octocat/socm/import/authors/2268559",     "import_url": "https://api.github.com/repos/octocat/socm/import"   } ]`
## [Map a commit author](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author)
Update an author's identity for the import. Your application can continue updating authors any time before you push new commits to the repository.
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Map a commit author"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Map a commit author"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`author_id` integer Required
Body parameters Name, Type, Description
---
`email` string The new Git author email.
`name` string The new Git author name.
### [HTTP response status codes for "Map a commit author"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
`503` | Unavailable due to service under maintenance.
### [Code samples for "Map a commit author"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#map-a-commit-author--code-samples)
#### Request example
patch/repos/{owner}/{repo}/import/authors/{author_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import/authors/AUTHOR_ID \   -d '{"email":"hubot@github.com","name":"Hubot the Robot"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 2268557,   "remote_id": "nobody@fc7da526-431c-80fe-3c8c-c148ff18d7ef",   "remote_name": "nobody",   "email": "hubot@github.com",   "name": "Hubot",   "url": "https://api.github.com/repos/octocat/socm/import/authors/2268557",   "import_url": "https://api.github.com/repos/octocat/socm/import" }`
## [Get large files](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files)
List files larger than 100MB found during the import
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Get large files"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


### [Parameters for "Get large files"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get large files"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files--status-codes)
Status code | Description
---|---
`200` | OK
`503` | Unavailable due to service under maintenance.
### [Code samples for "Get large files"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#get-large-files--code-samples)
#### Request example
get/repos/{owner}/{repo}/import/large_files
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import/large_files`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "ref_name": "refs/heads/master",     "path": "foo/bar/1",     "oid": "d3d9446802a44259755d38e6d163e820",     "size": 10485760   },   {     "ref_name": "refs/heads/master",     "path": "foo/bar/2",     "oid": "6512bd43d9caa6e02c990b0a82652dca",     "size": 11534336   },   {     "ref_name": "refs/heads/master",     "path": "foo/bar/3",     "oid": "c20ad4d76fe97759aa27a0c99bff6710",     "size": 12582912   } ]`
## [Update Git LFS preference](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference)
You can import repositories from Subversion, Mercurial, and TFS that include files larger than 100MB. This ability is powered by [Git LFS](https://git-lfs.com).
You can learn more about our LFS feature and working with large files [on our help site](https://docs.github.com/repositories/working-with-files/managing-large-files).
**Endpoint closing down notice:** Due to very low levels of usage and available alternatives, this endpoint is closing down and will no longer be available from 00:00 UTC on April 12, 2024. For more details and alternatives, see the [changelog](https://gh.io/source-imports-api-deprecation).
### [Fine-grained access tokens for "Update Git LFS preference"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Update Git LFS preference"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`use_lfs` string Required Whether to store large files during the import. `opt_in` means large files will be stored using Git LFS. `opt_out` means large files will be removed during the import. Can be one of: `opt_in`, `opt_out`
### [HTTP response status codes for "Update Git LFS preference"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
`503` | Unavailable due to service under maintenance.
### [Code samples for "Update Git LFS preference"](https://docs.github.com/en/rest/migrations/source-imports?apiVersion=2022-11-28#update-git-lfs-preference--code-samples)
#### Request example
patch/repos/{owner}/{repo}/import/lfs
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/import/lfs \   -d '{"use_lfs":"opt_in"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "vcs": "subversion",   "use_lfs": true,   "vcs_url": "http://svn.mycompany.com/svn/myproject",   "status": "complete",   "status_text": "Done",   "has_large_files": true,   "large_files_size": 132331036,   "large_files_count": 1,   "authors_count": 4,   "url": "https://api.github.com/repos/octocat/socm/import",   "html_url": "https://import.github.com/octocat/socm/import",   "authors_url": "https://api.github.com/repos/octocat/socm/import/authors",   "repository_url": "https://api.github.com/repos/octocat/socm" }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/migrations/source-imports.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for source imports - GitHub Docs
