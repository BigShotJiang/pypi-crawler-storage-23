[Skip to main content](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Gists](https://docs.github.com/en/rest/gists "Gists")/
  * [Comments](https://docs.github.com/en/rest/gists/comments "Comments")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot content exclusion management
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
      * [About gist comments](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#about-gist-comments)
      * [List gist comments](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments)
      * [Create a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment)
      * [Get a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment)
      * [Update a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment)
      * [Delete a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment)
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Gists](https://docs.github.com/en/rest/gists "Gists")/
  * [Comments](https://docs.github.com/en/rest/gists/comments "Comments")


# REST API endpoints for gist comments
Use the REST API to view and modify comments on a gist.
## [About gist comments](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#about-gist-comments)
You can use the REST API to view and modify comments on a gist. For more information about gists, see [Editing and sharing content with gists](https://docs.github.com/en/get-started/writing-on-github/editing-and-sharing-content-with-gists).
## [List gist comments](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments)
Lists the comments on a gist.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "List gist comments"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List gist comments"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List gist comments"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List gist comments"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#list-gist-comments--code-samples)
#### Request example
get/gists/{gist_id}/comments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/comments`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDExOkdpc3RDb21tZW50MQ==",     "url": "https://api.github.com/gists/a6db0bec360bb87e9418/comments/1",     "body": "Just commenting for the sake of commenting",     "user": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "created_at": "2011-04-18T23:23:56Z",     "updated_at": "2011-04-18T23:23:56Z",     "author_association": "COLLABORATOR"   } ]`
## [Create a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment)
Creates a comment on a gist.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Create a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Create a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
Body parameters Name, Type, Description
---
`body` string Required The comment text.
### [HTTP response status codes for "Create a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment--status-codes)
Status code | Description
---|---
`201` | Created
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Create a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#create-a-gist-comment--code-samples)
#### Request example
post/gists/{gist_id}/comments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/comments \   -d '{"body":"This is a comment to a gist"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1,   "node_id": "MDExOkdpc3RDb21tZW50MQ==",   "url": "https://api.github.com/gists/a6db0bec360bb87e9418/comments/1",   "body": "Just commenting for the sake of commenting",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "created_at": "2011-04-18T23:23:56Z",   "updated_at": "2011-04-18T23:23:56Z",   "author_association": "COLLABORATOR" }`
## [Get a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment)
Gets a comment on a gist.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Get a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "Get a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
`comment_id` integer Required The unique identifier of the comment.
### [HTTP response status codes for "Get a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`403` | Forbidden Gist
`404` | Resource not found
### [Code samples for "Get a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#get-a-gist-comment--code-samples)
#### Request example
get/gists/{gist_id}/comments/{comment_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/comments/COMMENT_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDExOkdpc3RDb21tZW50MQ==",   "url": "https://api.github.com/gists/a6db0bec360bb87e9418/comments/1",   "body": "Just commenting for the sake of commenting",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "created_at": "2011-04-18T23:23:56Z",   "updated_at": "2011-04-18T23:23:56Z",   "author_association": "COLLABORATOR" }`
## [Update a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment)
Updates a comment on a gist.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type.
  * **`application/vnd.github.base64+json`**: Returns the base64-encoded contents. This can be useful if your gist contains any invalid UTF-8 sequences.


### [Fine-grained access tokens for "Update a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Update a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
`comment_id` integer Required The unique identifier of the comment.
Body parameters Name, Type, Description
---
`body` string Required The comment text.
### [HTTP response status codes for "Update a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Update a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#update-a-gist-comment--code-samples)
#### Request example
patch/gists/{gist_id}/comments/{comment_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/comments/COMMENT_ID \   -d '{"body":"This is an update to a comment in a gist"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "node_id": "MDExOkdpc3RDb21tZW50MQ==",   "url": "https://api.github.com/gists/a6db0bec360bb87e9418/comments/1",   "body": "Just commenting for the sake of commenting",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "created_at": "2011-04-18T23:23:56Z",   "updated_at": "2011-04-18T23:23:56Z",   "author_association": "COLLABORATOR" }`
## [Delete a gist comment](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment)
### [Fine-grained access tokens for "Delete a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Gists" user permissions (write)


### [Parameters for "Delete a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`gist_id` string Required The unique identifier of the gist.
`comment_id` integer Required The unique identifier of the comment.
### [HTTP response status codes for "Delete a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment--status-codes)
Status code | Description
---|---
`204` | No Content
`304` | Not modified
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Delete a gist comment"](https://docs.github.com/en/rest/gists/comments?apiVersion=2022-11-28#delete-a-gist-comment--code-samples)
#### Request example
delete/gists/{gist_id}/comments/{comment_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/gists/GIST_ID/comments/COMMENT_ID`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/gists/comments.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for gist comments - GitHub Docs
