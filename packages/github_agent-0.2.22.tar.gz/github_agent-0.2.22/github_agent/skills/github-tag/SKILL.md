---
name: github-tag
description: "Manage repository labels. Triggers: Labels Agent."
tags: [tag]
---

### Overview
This skill handles operations related to the Labels Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Labels Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
