---
name: github-copilot-spaces
description: "Manage Copilot Spaces. Triggers: Copilot Spaces Agent."
tags: [copilot-spaces]
---

### Overview
This skill handles operations related to the Copilot Spaces Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Copilot Spaces Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
