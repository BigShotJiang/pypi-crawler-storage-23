---
name: github-workflow
description: "Manage GitHub Actions workflows and CI/CD operations. Triggers: Actions Agent."
tags: [workflow]
---

### Overview
This skill handles operations related to the Actions Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Actions Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
