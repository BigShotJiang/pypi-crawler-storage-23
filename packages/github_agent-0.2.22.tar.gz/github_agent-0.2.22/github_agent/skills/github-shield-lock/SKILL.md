---
name: github-shield-lock
description: "Manage secret scanning and protection features. Triggers: Secret Protection Agent."
tags: [shield-lock]
---

### Overview
This skill handles operations related to the Secret Protection Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Secret Protection Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
