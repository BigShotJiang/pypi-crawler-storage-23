"""Entry point for running CJE as a module."""

from .interface.cli import main

if __name__ == "__main__":
    exit(main())
