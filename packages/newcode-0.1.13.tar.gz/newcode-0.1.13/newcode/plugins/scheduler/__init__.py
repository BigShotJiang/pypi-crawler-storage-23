"""Scheduler plugin - manages scheduled tasks via /scheduler command."""
