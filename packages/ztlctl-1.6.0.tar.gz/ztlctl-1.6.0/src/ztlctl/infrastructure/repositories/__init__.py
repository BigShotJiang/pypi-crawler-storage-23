"""Infrastructure repositories for persistence access patterns."""

from ztlctl.infrastructure.repositories.query import QueryRepository

__all__ = ["QueryRepository"]
