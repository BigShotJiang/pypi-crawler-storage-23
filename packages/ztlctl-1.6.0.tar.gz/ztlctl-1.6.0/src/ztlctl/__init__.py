"""ztlctl — Zettelkasten Control CLI utility."""

__version__ = "1.6.0"
