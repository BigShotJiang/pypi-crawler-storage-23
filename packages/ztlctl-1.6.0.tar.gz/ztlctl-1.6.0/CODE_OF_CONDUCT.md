# Code of Conduct

## Our Standards

This project aims to be a welcoming and inclusive space for everyone. All participants are expected to show respect and courtesy to others.

### Expected Behavior

- Use welcoming and inclusive language
- Respect differing viewpoints and experiences
- Accept constructive criticism gracefully
- Focus on what is best for the project
- Show empathy towards others

### Unacceptable Behavior

- Harassment, intimidation, or discrimination of any kind
- Trolling, insulting or derogatory comments, and personal attacks
- Publishing others' private information without explicit permission
- Sustained disruption of discussions or project activities

## Scope

This Code of Conduct applies to all project spaces, including issues, pull requests, discussions, and any other communication channels associated with this project.

## Enforcement

Instances of unacceptable behavior may be reported via [GitHub Issues](https://github.com/ThatDevStudio/ztlctl/issues). Reports will be handled with discretion and respect for the reporter's privacy.

## Attribution

This Code of Conduct is adapted from common open source community standards.
