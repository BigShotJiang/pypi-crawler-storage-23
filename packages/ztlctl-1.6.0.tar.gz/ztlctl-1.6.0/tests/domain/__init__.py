"""Tests for the domain layer."""
