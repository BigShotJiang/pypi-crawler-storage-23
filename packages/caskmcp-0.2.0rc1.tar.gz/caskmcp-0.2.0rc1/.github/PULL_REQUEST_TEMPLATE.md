## Summary

Brief description of changes (1-3 sentences).

## Changes

-

## Test plan

- [ ] New tests added for behavior changes
- [ ] All existing tests pass (`python -m pytest tests/ -v`)
- [ ] Manual verification performed
- [ ] Docs updated (if public behavior changed)
