---
name: Feature request
about: Suggest a feature for CaskMCP
title: "[Feature] "
labels: enhancement
assignees: ''
---

**Problem**
What problem does this solve? What's the use case?

**Proposed solution**
How should this work?

**Alternatives considered**
Other approaches you've thought about.

**Additional context**
Any other context, examples, or references.
