# Release Notes Archive

`CHANGELOG.md` in the repository root is the canonical release history.

Files in this directory are historical alpha-era notes kept for reference.

For new releases, update only:

- `CHANGELOG.md`
- tagged GitHub release notes (if used)
