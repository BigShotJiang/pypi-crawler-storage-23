"""Branding constants."""

from __future__ import annotations

PRODUCT_NAME = "CaskMCP"
CLI_PRIMARY_COMMAND = "cask"
