"""Package assets for CaskMCP."""
