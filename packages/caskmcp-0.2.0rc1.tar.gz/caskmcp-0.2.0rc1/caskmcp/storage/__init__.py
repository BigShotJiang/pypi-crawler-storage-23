"""Storage layer for CaskMCP."""

from caskmcp.storage.filesystem import Storage

__all__ = ["Storage"]
