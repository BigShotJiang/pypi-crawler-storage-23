"""Authentication profiles and provider interfaces."""

from caskmcp.core.auth.profiles import AuthProfileManager

__all__ = ["AuthProfileManager"]
