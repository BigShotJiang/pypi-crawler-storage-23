"""CaskMCP core modules."""
