"""Project initialization — detect context and generate config."""
