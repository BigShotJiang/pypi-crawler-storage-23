"""CaskMCP CLI commands."""
