"""Tests for CaskMCP."""
