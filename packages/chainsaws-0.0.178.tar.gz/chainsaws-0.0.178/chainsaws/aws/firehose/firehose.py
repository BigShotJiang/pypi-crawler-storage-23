import json
import logging
from time import sleep
from typing import Optional

from chainsaws.aws.firehose._firehose_internal import Firehose
from chainsaws.aws.firehose.firehose_models import (
    FirehoseAPIConfig,
    PutRecordBatchFailure,
    PutRecordBatchSummary,
)
from chainsaws.aws.firehose.response.RecordResponse import PutRecordBatchResponse, PutRecordResponse
from chainsaws.aws.shared.session import get_boto_session

logger = logging.getLogger(__name__)
_MAX_BATCH_SIZE = 500
_MAX_RECORD_BYTES = 1_000_000


def _validate_stream_name(name: str) -> None:
    if not name.strip():
        raise ValueError("delivery_stream_name must not be empty")


def _serialize_record_data(data: str | bytes | dict[str, object] | list[object]) -> bytes:
    if isinstance(data, bytes):
        return data
    if isinstance(data, str):
        return data.encode("utf-8")
    if isinstance(data, (dict, list)):
        return json.dumps(data).encode("utf-8")
    raise TypeError("record data must be str, bytes, dict, or list")


def _validate_record_size(data: bytes) -> None:
    if len(data) > _MAX_RECORD_BYTES:
        raise ValueError(f"record data must be <= {_MAX_RECORD_BYTES} bytes")


class FirehoseAPI:
    """High-level Kinesis Firehose operations."""

    def __init__(
        self,
        delivery_stream_name: str,
        config: Optional[FirehoseAPIConfig] = None,
    ) -> None:
        self.config = config or FirehoseAPIConfig()
        _validate_stream_name(delivery_stream_name)
        self.delivery_stream_name = delivery_stream_name
        self.boto3_session = get_boto_session(
            self.config.credentials if self.config.credentials else None,
        )
        self.firehose = Firehose(boto3_session=self.boto3_session, config=self.config)


    def put_record(self, data: str | bytes | dict[str, object] | list[object]) -> PutRecordResponse:
        """Put record into delivery stream."""
        serialized_data = _serialize_record_data(data)
        _validate_record_size(serialized_data)

        return self.firehose.put_record(
            stream_name=self.delivery_stream_name,
            data=serialized_data,
        )

    def put_record_batch(
        self,
        records: list[str | bytes | dict[str, object] | list[object]],
        batch_size: int = 500,
        retry_failed: bool = True,
        max_retries: int = 3,
        *,
        return_summary: bool = False,
    ) -> list[PutRecordBatchResponse] | PutRecordBatchSummary:
        """Put multiple records into delivery stream with automatic batching.

        Args:
            records: List of records to put (strings, bytes, or JSON-serializable objects)
            batch_size: Maximum size of each batch (default: 500, max: 500)
            retry_failed: Whether to retry failed records (default: True)
            max_retries: Maximum number of retries for failed records (default: 3)
            return_summary: When True, returns detailed summary dictionary.
                When False (default), returns raw batch responses for backward compatibility.

        Returns:
            Either raw batch responses (default) or a detailed summary when
            ``return_summary=True``.

        Example:
            >>> records = [{"id": i, "message": f"Test {i}"} for i in range(1000)]
            >>> result = firehose.put_record_batch(records)
            >>> print(f"Successfully delivered {result['successful_records']} records")

        """
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or not 1 <= batch_size <= _MAX_BATCH_SIZE:
            raise ValueError("batch_size must be an integer between 1 and 500")
        if isinstance(max_retries, bool) or not isinstance(max_retries, int) or max_retries < 1:
            raise ValueError("max_retries must be a positive integer")

        prepared_records = [
            _serialize_record_data(record)
            for record in records
        ]
        for record in prepared_records:
            _validate_record_size(record)

        total_records = len(prepared_records)
        successful_records = 0
        failed_records: list[PutRecordBatchFailure] = []
        attempt_failures: list[PutRecordBatchFailure] = []
        batch_responses: list[PutRecordBatchResponse] = []

        for attempt in range(max_retries):
            if not prepared_records:
                break

            current_batch_records: list[bytes] = []
            current_attempt_failures: list[PutRecordBatchFailure] = []

            for i in range(0, len(prepared_records), batch_size):
                batch = prepared_records[i:i + batch_size]

                try:
                    response = self.firehose.put_record_batch(
                        stream_name=self.delivery_stream_name,
                        records=batch,
                    )
                    batch_responses.append(response)

                    # Process results
                    failed_count = response.get("FailedPutCount", 0)
                    if failed_count > 0:
                        # Collect failed records for retry
                        request_responses = response.get(
                            "RequestResponses", [])
                        for idx, resp in enumerate(request_responses):
                            if "ErrorCode" in resp:
                                failure: PutRecordBatchFailure = {
                                    "record": batch[idx],
                                    "error": resp.get("ErrorMessage", "Unknown error"),
                                    "attempt": attempt + 1,
                                }
                                current_attempt_failures.append(failure)
                                current_batch_records.append(batch[idx])
                            else:
                                successful_records += 1
                    else:
                        successful_records += len(batch)

                except Exception as ex:
                    logger.exception(f"Batch processing failed: {ex!s}")
                    current_batch_records.extend(batch)
                    current_attempt_failures.extend([
                        {
                            "record": record,
                            "error": str(ex),
                            "attempt": attempt + 1,
                        }
                        for record in batch
                    ])

            attempt_failures.extend(current_attempt_failures)

            # Update records for next retry attempt
            if retry_failed and current_batch_records and attempt < max_retries - 1:
                prepared_records = current_batch_records
                logger.warning(
                    f"Retrying {len(prepared_records)} failed records. Attempt {attempt + 2}/{max_retries}",
                )
                # Exponential backoff
                sleep(2 ** attempt)
            else:
                failed_records.extend(current_attempt_failures)
                break

        result: PutRecordBatchSummary = {
            "total_records": total_records,
            "successful_records": successful_records,
            "failed_records": failed_records,
            "attempt_failures": attempt_failures,
            "batch_responses": batch_responses,
        }

        # Log final status
        if failed_records:
            logger.warning(
                f"Completed with {len(failed_records)} failed records out of {total_records}",
            )
        else:
            logger.info(f"Successfully delivered all {total_records} records")

        if return_summary:
            return result
        return batch_responses
