"""AWS Simple Email Service (SES) API package.

This package provides a high-level interface for AWS SES operations including
email sending, template management, and bulk operations.

Example:
    ```python
    from chainsaws.aws.ses import SESAPI, EmailFormat, EmailAddress

    # Initialize API
    ses = SESAPI()

    # Send single email
    ses.send_email(
        recipients="user@example.com",
        subject="Welcome!",
        body="<h1>Welcome to our service!</h1>",
        email_format=EmailFormat.HTML
    )

    # Send bulk emails with template
    ses.send_bulk_emails(
        recipients=[
            {
                "email": "user1@example.com",
                "template_data": {"name": "User 1"}
            },
            {
                "email": "user2@example.com",
                "template_data": {"name": "User 2"}
            }
        ],
        template_name="welcome_template"
    )
    ```

"""

from chainsaws.aws.ses.ses import SESAPI
from chainsaws.aws.ses.ses_models import (
    BulkEmailConfig,
    BulkEmailRecipient,
    BulkEmailResult,
    EmailAddress,
    RawEmailAttachment,
    SendRawEmailConfig,
    EmailContent,
    EmailIdentityDetails,
    EmailFormat,
    SESIdentityType,
    EmailPriority,
    EmailQuota,
    ListManagementOptions,
    SuppressedDestinationSummary,
    SuppressionReason,
    SendEmailConfig,
    SendTemplateConfig,
    SESAPIConfig,
    TemplateContent,
    TemplateUpsertResult,
)
from chainsaws.aws.ses.ses_exception import (
    SESAlreadyExistsError,
    SESBatchError,
    SESError,
    SESException,
    SESIdentityNotFoundError,
    SESLimitExceededError,
    SESMessageRejectedError,
    SESNotFoundError,
    SESTemplateNotFoundError,
    SESThrottlingError,
    SESValidationError,
)
from chainsaws.aws.ses.response import (
    SendEmailResponse,
    SendTemplatedEmailResponse,
    GetSendQuotaResponse,
    TemplateMetadata,
    Template,
    GetTemplateResponse,
    ListTemplatesResponse,
)

__all__ = [
    "SESAPI",
    "BulkEmailConfig",
    "BulkEmailRecipient",
    "BulkEmailResult",
    "EmailAddress",
    "RawEmailAttachment",
    "SendRawEmailConfig",
    "EmailContent",
    "EmailIdentityDetails",
    "EmailFormat",
    "SESIdentityType",
    "EmailPriority",
    "EmailQuota",
    "ListManagementOptions",
    "SuppressedDestinationSummary",
    "SuppressionReason",
    "SESAPIConfig",
    "SendEmailConfig",
    "SendTemplateConfig",
    "TemplateContent",
    "TemplateUpsertResult",
    "SendEmailResponse",
    "SendTemplatedEmailResponse",
    "GetSendQuotaResponse",
    "TemplateMetadata",
    "Template",
    "GetTemplateResponse",
    "ListTemplatesResponse",
    "SESException",
    "SESError",
    "SESValidationError",
    "SESBatchError",
    "SESThrottlingError",
    "SESMessageRejectedError",
    "SESNotFoundError",
    "SESTemplateNotFoundError",
    "SESIdentityNotFoundError",
    "SESAlreadyExistsError",
    "SESLimitExceededError",
]
