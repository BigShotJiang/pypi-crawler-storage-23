from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Literal, NotRequired, Required, TypeAlias, TypedDict

from chainsaws.aws.shared.config import APIConfig

JSONPrimitive = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]
SESIdentityType: TypeAlias = Literal["EMAIL_ADDRESS", "DOMAIN", "MANAGED_DOMAIN"]


class EmailFormat(str, Enum):
    """Email content format."""

    TEXT = "Text"
    HTML = "Html"
    BOTH = "Both"


class EmailPriority(str, Enum):
    """Email priority level."""

    HIGH = "1"
    NORMAL = "3"
    LOW = "5"


class EmailContent(TypedDict, total=False):
    """Email content configuration."""

    subject: Required[str]
    body_text: NotRequired[str | None]
    body_html: NotRequired[str | None]
    charset: NotRequired[str]


@dataclass
class EmailAddress:
    """Email address with optional name."""

    email: str
    name: str | None = None

    def __str__(self) -> str:
        if self.name:
            return f"{self.name} <{self.email}>"
        return self.email


@dataclass
class SESAPIConfig(APIConfig):
    """Configuration for SES API."""

    default_region: str = field(default="ap-northeast-2")
    default_sender: EmailAddress | None = None
    default_format: EmailFormat = field(default=EmailFormat.BOTH)
    default_configuration_set: str | None = None


class ListManagementOptions(TypedDict, total=False):
    """SESv2 list management options for one email send."""

    contact_list_name: Required[str]
    topic_name: NotRequired[str]


class SendEmailConfig(TypedDict, total=False):
    """Configuration for sending email."""

    sender: Required[EmailAddress]
    recipients: Required[list[EmailAddress]]
    content: Required[EmailContent]
    cc: NotRequired[list[EmailAddress]]
    bcc: NotRequired[list[EmailAddress]]
    reply_to: NotRequired[list[EmailAddress]]
    priority: NotRequired[EmailPriority]
    tags: NotRequired[dict[str, str]]
    configuration_set_name: NotRequired[str]
    list_management_options: NotRequired[ListManagementOptions]


class TemplateContent(TypedDict, total=False):
    """Email template content."""

    subject: Required[str]
    text: NotRequired[str | None]
    html: NotRequired[str | None]


class RawEmailAttachment(TypedDict, total=False):
    """Attachment metadata used by raw MIME builder."""

    filename: Required[str]
    data: Required[bytes]
    content_type: NotRequired[str]
    disposition: NotRequired[Literal["attachment", "inline"]]
    content_id: NotRequired[str]


class SendRawEmailConfig(TypedDict, total=False):
    """Configuration for sending raw MIME email payload."""

    sender: Required[EmailAddress]
    recipients: Required[list[EmailAddress]]
    raw_data: Required[bytes]
    cc: NotRequired[list[EmailAddress]]
    bcc: NotRequired[list[EmailAddress]]
    reply_to: NotRequired[list[EmailAddress]]
    tags: NotRequired[dict[str, str]]
    configuration_set_name: NotRequired[str]
    list_management_options: NotRequired[ListManagementOptions]


class SendTemplateConfig(TypedDict, total=False):
    """Configuration for sending templated email."""

    template_name: Required[str]
    sender: Required[EmailAddress]
    recipients: Required[list[EmailAddress]]
    template_data: Required[dict[str, JSONValue]]
    cc: NotRequired[list[EmailAddress]]
    bcc: NotRequired[list[EmailAddress]]
    tags: NotRequired[dict[str, str]]
    configuration_set_name: NotRequired[str]
    list_management_options: NotRequired[ListManagementOptions]


class EmailQuota(TypedDict):
    """SES sending quota information."""

    max_24_hour_send: float
    max_send_rate: float
    sent_last_24_hours: float


SuppressionReason: TypeAlias = Literal["BOUNCE", "COMPLAINT"]


class SuppressedDestinationSummary(TypedDict, total=False):
    """Suppressed destination metadata."""

    email_address: Required[str]
    reason: NotRequired[SuppressionReason]
    last_update_time: NotRequired[datetime]


class BulkEmailRecipient(TypedDict, total=False):
    """Recipient for bulk email sending."""

    email: Required[EmailAddress]
    template_data: NotRequired[dict[str, JSONValue]]
    tags: NotRequired[dict[str, str]]


class BulkEmailConfig(TypedDict, total=False):
    """Configuration for bulk email sending."""

    sender: Required[EmailAddress]
    recipients: Required[list[BulkEmailRecipient]]
    template_name: NotRequired[str]
    content: NotRequired[EmailContent]
    batch_size: NotRequired[int]
    max_workers: NotRequired[int]
    email_format: NotRequired[EmailFormat]
    configuration_set_name: NotRequired[str]
    list_management_options: NotRequired[ListManagementOptions]
    default_tags: NotRequired[dict[str, str]]


class BulkEmailResult(TypedDict):
    """Result for one recipient in bulk send."""

    email: str
    status: Literal["success", "error"]
    message_id: str | None
    error: str | None


TemplateUpsertResult: TypeAlias = Literal["created", "updated"]


class EmailIdentityDetails(TypedDict, total=False):
    """Key identity metadata returned by SESv2 get_email_identity."""

    identity_name: Required[str]
    identity_type: NotRequired[SESIdentityType]
    verified_for_sending_status: NotRequired[bool]
    sending_enabled_for_configuration_set: NotRequired[bool]
    configuration_set_name: NotRequired[str]
