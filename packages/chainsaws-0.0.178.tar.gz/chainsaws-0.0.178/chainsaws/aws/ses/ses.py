"""High-level SES API."""

from __future__ import annotations

import logging
import time
from uuid import uuid4
from datetime import datetime
from email.message import EmailMessage
from email.policy import SMTP

from chainsaws.aws.ses._ses_internal import SES
from chainsaws.aws.ses.response import ListTemplatesResponse, SendEmailResponse, SendTemplatedEmailResponse
from chainsaws.aws.ses.ses_exception import SESBatchError, SESTemplateNotFoundError, SESValidationError
from chainsaws.aws.ses.ses_models import (
    BulkEmailConfig,
    BulkEmailRecipient,
    BulkEmailResult,
    EmailAddress,
    EmailContent,
    EmailIdentityDetails,
    EmailFormat,
    EmailPriority,
    EmailQuota,
    SESIdentityType,
    JSONValue,
    ListManagementOptions,
    RawEmailAttachment,
    SESAPIConfig,
    SuppressedDestinationSummary,
    SuppressionReason,
    SendEmailConfig,
    SendRawEmailConfig,
    SendTemplateConfig,
    TemplateContent,
    TemplateUpsertResult,
)
from chainsaws.aws.shared import session

logger = logging.getLogger(__name__)

_DEFAULT_BULK_BATCH_SIZE = 50
_DEFAULT_VERIFICATION_TIMEOUT_SECONDS = 300.0
_DEFAULT_VERIFICATION_INTERVAL_SECONDS = 5.0
_MAX_DESTINATION_ADDRESSES = 50
_MAX_RAW_EMAIL_BYTES = 40 * 1024 * 1024


def _to_email_address(address: str | EmailAddress) -> EmailAddress:
    if isinstance(address, EmailAddress):
        return address
    return EmailAddress(email=address)


def _normalize_email_addresses(
    addresses: str | list[str] | EmailAddress | list[EmailAddress] | None,
) -> list[EmailAddress] | None:
    if addresses is None:
        return None

    if isinstance(addresses, str | EmailAddress):
        addresses = [addresses]

    normalized = [_to_email_address(address) for address in addresses]
    return normalized if normalized else None


def _require_non_empty_text(value: str, field_name: str) -> str:
    normalized = value.strip()
    if normalized == "":
        msg = f"{field_name} must not be empty"
        raise SESValidationError(msg)
    return normalized


def _normalize_list_management_options(
    options: ListManagementOptions | None,
) -> ListManagementOptions | None:
    if options is None:
        return None

    contact_list_name = _require_non_empty_text(
        options["contact_list_name"],
        "list_management_options.contact_list_name",
    )
    normalized: ListManagementOptions = {
        "contact_list_name": contact_list_name,
    }

    topic_name = options.get("topic_name")
    if topic_name is not None:
        normalized["topic_name"] = _require_non_empty_text(
            topic_name,
            "list_management_options.topic_name",
        )
    return normalized


def _require_positive(value: float, field_name: str) -> float:
    if value <= 0:
        msg = f"{field_name} must be a positive number"
        raise SESValidationError(msg)
    return value


def _validate_destination_count(
    recipients: list[EmailAddress],
    cc: list[EmailAddress] | None,
    bcc: list[EmailAddress] | None,
) -> None:
    cc_count = len(cc) if cc is not None else 0
    bcc_count = len(bcc) if bcc is not None else 0
    total = len(recipients) + cc_count + bcc_count
    if total > _MAX_DESTINATION_ADDRESSES:
        msg = (
            "Total recipient count must be <= 50 across To/Cc/Bcc "
            f"(current: {total})"
        )
        raise SESValidationError(msg)


class SESAPI:
    """High-level SES API."""

    def __init__(self, config: SESAPIConfig | None = None) -> None:
        self.config = config or SESAPIConfig()
        self.boto3_session = session.get_boto_session(
            self.config.credentials if self.config.credentials else None,
        )
        self.ses = SES(self.boto3_session, config=self.config)

    def _resolve_sender(self, sender: str | EmailAddress | None) -> EmailAddress:
        if sender is not None:
            return _to_email_address(sender)
        if self.config.default_sender is not None:
            return self.config.default_sender
        msg = "Sender is required when default_sender is not configured"
        raise SESValidationError(msg)

    def _resolve_configuration_set_name(
        self,
        configuration_set_name: str | None,
    ) -> str | None:
        if configuration_set_name is not None:
            return _require_non_empty_text(
                configuration_set_name,
                "configuration_set_name",
            )
        default_name = self.config.default_configuration_set
        if default_name:
            return _require_non_empty_text(
                default_name,
                "default_configuration_set",
            )
        return None

    def _normalize_required_recipients(
        self,
        recipients: str | list[str] | EmailAddress | list[EmailAddress],
    ) -> list[EmailAddress]:
        normalized = _normalize_email_addresses(recipients)
        if not normalized:
            msg = "At least one recipient is required"
            raise SESValidationError(msg)
        return normalized

    def _build_email_content(
        self,
        *,
        subject: str,
        body: str,
        email_format: EmailFormat,
    ) -> EmailContent:
        validated_subject = _require_non_empty_text(subject, "subject")
        validated_body = _require_non_empty_text(body, "body")

        content: EmailContent = {
            "subject": validated_subject,
            "charset": "UTF-8",
        }

        if email_format in (EmailFormat.TEXT, EmailFormat.BOTH):
            content["body_text"] = validated_body
        if email_format in (EmailFormat.HTML, EmailFormat.BOTH):
            content["body_html"] = validated_body
        return content

    def send_email(
        self,
        recipients: str | list[str] | EmailAddress | list[EmailAddress],
        subject: str,
        body: str,
        email_format: EmailFormat | None = None,
        sender: str | EmailAddress | None = None,
        cc: list[str] | list[EmailAddress] | None = None,
        bcc: list[str] | list[EmailAddress] | None = None,
        reply_to: list[str] | list[EmailAddress] | None = None,
        priority: EmailPriority = EmailPriority.NORMAL,
        tags: dict[str, str] | None = None,
        configuration_set_name: str | None = None,
        list_management_options: ListManagementOptions | None = None,
    ) -> SendEmailResponse:
        normalized_recipients = self._normalize_required_recipients(recipients)
        normalized_cc = _normalize_email_addresses(cc)
        normalized_bcc = _normalize_email_addresses(bcc)
        _validate_destination_count(normalized_recipients, normalized_cc, normalized_bcc)
        selected_format = email_format or self.config.default_format

        config: SendEmailConfig = {
            "sender": self._resolve_sender(sender),
            "recipients": normalized_recipients,
            "cc": normalized_cc,
            "bcc": normalized_bcc,
            "reply_to": _normalize_email_addresses(reply_to),
            "content": self._build_email_content(
                subject=subject,
                body=body,
                email_format=selected_format,
            ),
            "priority": priority,
            "tags": tags or {},
        }
        resolved_configuration_set = self._resolve_configuration_set_name(
            configuration_set_name,
        )
        if resolved_configuration_set is not None:
            config["configuration_set_name"] = resolved_configuration_set

        normalized_list_management_options = _normalize_list_management_options(
            list_management_options,
        )
        if normalized_list_management_options is not None:
            config["list_management_options"] = normalized_list_management_options

        return self.ses.send_email(config)

    @staticmethod
    def build_raw_mime_email(
        *,
        sender: str | EmailAddress,
        recipients: str | list[str] | EmailAddress | list[EmailAddress],
        subject: str,
        body_text: str | None = None,
        body_html: str | None = None,
        cc: list[str] | list[EmailAddress] | None = None,
        bcc: list[str] | list[EmailAddress] | None = None,
        reply_to: list[str] | list[EmailAddress] | None = None,
        attachments: list[RawEmailAttachment] | None = None,
    ) -> bytes:
        normalized_recipients = _normalize_email_addresses(recipients)
        if not normalized_recipients:
            msg = "At least one recipient is required"
            raise SESValidationError(msg)

        if not body_text and not body_html:
            msg = "body_text or body_html must be provided"
            raise SESValidationError(msg)

        message = EmailMessage(policy=SMTP)
        message["From"] = str(_to_email_address(sender))
        message["To"] = ", ".join(str(address) for address in normalized_recipients)
        message["Subject"] = _require_non_empty_text(subject, "subject")

        normalized_cc = _normalize_email_addresses(cc)
        if normalized_cc:
            message["Cc"] = ", ".join(str(address) for address in normalized_cc)

        normalized_bcc = _normalize_email_addresses(bcc)
        _validate_destination_count(
            normalized_recipients,
            normalized_cc,
            normalized_bcc,
        )

        normalized_reply_to = _normalize_email_addresses(reply_to)
        if normalized_reply_to:
            message["Reply-To"] = ", ".join(
                str(address)
                for address in normalized_reply_to
            )

        if body_text:
            message.set_content(body_text)
        if body_html:
            if body_text:
                message.add_alternative(body_html, subtype="html")
            else:
                message.set_content(body_html, subtype="html")

        for attachment in attachments or []:
            filename = _require_non_empty_text(attachment["filename"], "attachment.filename")
            disposition = attachment.get("disposition", "attachment")
            content_type = attachment.get("content_type", "application/octet-stream")
            content_id = attachment.get("content_id")
            if disposition == "inline" and not content_id:
                content_id = f"inline-{uuid4().hex}"
            maintype, subtype = (
                content_type.split("/", 1)
                if "/" in content_type
                else ("application", "octet-stream")
            )

            message.add_attachment(
                attachment["data"],
                maintype=maintype,
                subtype=subtype,
                filename=filename,
                disposition=disposition,
                cid=content_id,
            )

        return message.as_bytes()

    @staticmethod
    def build_inline_image_attachment(
        *,
        filename: str,
        data: bytes,
        content_type: str,
        content_id: str | None = None,
    ) -> tuple[RawEmailAttachment, str]:
        normalized_filename = _require_non_empty_text(filename, "filename")
        normalized_content_type = _require_non_empty_text(content_type, "content_type")
        resolved_content_id = content_id or f"inline-{uuid4().hex}"
        attachment: RawEmailAttachment = {
            "filename": normalized_filename,
            "data": data,
            "content_type": normalized_content_type,
            "disposition": "inline",
            "content_id": resolved_content_id,
        }
        return attachment, resolved_content_id

    def send_raw_email(
        self,
        recipients: str | list[str] | EmailAddress | list[EmailAddress],
        raw_data: bytes,
        sender: str | EmailAddress | None = None,
        cc: list[str] | list[EmailAddress] | None = None,
        bcc: list[str] | list[EmailAddress] | None = None,
        reply_to: list[str] | list[EmailAddress] | None = None,
        tags: dict[str, str] | None = None,
        configuration_set_name: str | None = None,
        list_management_options: ListManagementOptions | None = None,
    ) -> SendEmailResponse:
        if len(raw_data) == 0:
            msg = "raw_data must not be empty"
            raise SESValidationError(msg)
        if len(raw_data) > _MAX_RAW_EMAIL_BYTES:
            msg = f"raw_data must be <= {_MAX_RAW_EMAIL_BYTES} bytes"
            raise SESValidationError(msg)

        normalized_recipients = self._normalize_required_recipients(recipients)
        normalized_cc = _normalize_email_addresses(cc)
        normalized_bcc = _normalize_email_addresses(bcc)
        _validate_destination_count(normalized_recipients, normalized_cc, normalized_bcc)

        config: SendRawEmailConfig = {
            "sender": self._resolve_sender(sender),
            "recipients": normalized_recipients,
            "raw_data": raw_data,
            "cc": normalized_cc,
            "bcc": normalized_bcc,
            "reply_to": _normalize_email_addresses(reply_to),
            "tags": tags or {},
        }
        resolved_configuration_set = self._resolve_configuration_set_name(
            configuration_set_name,
        )
        if resolved_configuration_set is not None:
            config["configuration_set_name"] = resolved_configuration_set

        normalized_list_management_options = _normalize_list_management_options(
            list_management_options,
        )
        if normalized_list_management_options is not None:
            config["list_management_options"] = normalized_list_management_options

        return self.ses.send_raw_email(config)

    def create_template(
        self,
        name: str,
        subject: str,
        text_content: str | None = None,
        html_content: str | None = None,
    ) -> None:
        validated_name = _require_non_empty_text(name, "name")
        validated_subject = _require_non_empty_text(subject, "subject")

        if not text_content and not html_content:
            msg = "Either text_content or html_content must be provided"
            raise SESValidationError(msg)

        content: TemplateContent = {
            "subject": validated_subject,
            "text": text_content,
            "html": html_content,
        }
        self.ses.create_template(validated_name, content)

    def upsert_template(
        self,
        name: str,
        subject: str,
        text_content: str | None = None,
        html_content: str | None = None,
    ) -> TemplateUpsertResult:
        validated_name = _require_non_empty_text(name, "name")
        validated_subject = _require_non_empty_text(subject, "subject")

        if not text_content and not html_content:
            msg = "Either text_content or html_content must be provided"
            raise SESValidationError(msg)

        content: TemplateContent = {
            "subject": validated_subject,
            "text": text_content,
            "html": html_content,
        }

        try:
            self.ses.get_template(validated_name)
        except SESTemplateNotFoundError:
            self.ses.create_template(validated_name, content)
            return "created"

        self.ses.update_template(validated_name, content)
        return "updated"

    def send_template(
        self,
        template_name: str,
        recipients: str | list[str] | EmailAddress | list[EmailAddress],
        template_data: dict[str, JSONValue],
        sender: str | EmailAddress | None = None,
        cc: list[str] | list[EmailAddress] | None = None,
        bcc: list[str] | list[EmailAddress] | None = None,
        tags: dict[str, str] | None = None,
        configuration_set_name: str | None = None,
        list_management_options: ListManagementOptions | None = None,
    ) -> SendTemplatedEmailResponse:
        validated_template_name = _require_non_empty_text(template_name, "template_name")
        normalized_recipients = self._normalize_required_recipients(recipients)
        normalized_cc = _normalize_email_addresses(cc)
        normalized_bcc = _normalize_email_addresses(bcc)
        _validate_destination_count(normalized_recipients, normalized_cc, normalized_bcc)

        config: SendTemplateConfig = {
            "template_name": validated_template_name,
            "sender": self._resolve_sender(sender),
            "recipients": normalized_recipients,
            "template_data": template_data,
            "cc": normalized_cc,
            "bcc": normalized_bcc,
            "tags": tags or {},
        }
        resolved_configuration_set = self._resolve_configuration_set_name(
            configuration_set_name,
        )
        if resolved_configuration_set is not None:
            config["configuration_set_name"] = resolved_configuration_set

        normalized_list_management_options = _normalize_list_management_options(
            list_management_options,
        )
        if normalized_list_management_options is not None:
            config["list_management_options"] = normalized_list_management_options

        return self.ses.send_templated_email(config)

    def get_quota(self) -> EmailQuota:
        quota = self.ses.get_send_quota()
        return {
            "max_24_hour_send": float(quota["Max24HourSend"]),
            "max_send_rate": float(quota["MaxSendRate"]),
            "sent_last_24_hours": float(quota["SentLast24Hours"]),
        }

    def verify_email(self, email: str) -> None:
        self.ses.verify_email_identity(_require_non_empty_text(email, "email"))

    def wait_for_identity_verification(
        self,
        identity_name: str,
        *,
        timeout_seconds: float = _DEFAULT_VERIFICATION_TIMEOUT_SECONDS,
        poll_interval_seconds: float = _DEFAULT_VERIFICATION_INTERVAL_SECONDS,
    ) -> bool:
        normalized_identity_name = _require_non_empty_text(identity_name, "identity_name")
        timeout = _require_positive(timeout_seconds, "timeout_seconds")
        interval = _require_positive(poll_interval_seconds, "poll_interval_seconds")

        deadline = time.monotonic() + timeout
        while True:
            details = self.get_identity(normalized_identity_name)
            if details.get("verified_for_sending_status") is True:
                return True

            if time.monotonic() >= deadline:
                return False

            time.sleep(interval)

    def list_verified_emails(self) -> list[str]:
        return self.ses.list_identities(identity_types=["EMAIL_ADDRESS"])

    def list_identities(
        self,
        *,
        identity_types: list[SESIdentityType] | None = None,
    ) -> list[str]:
        return self.ses.list_identities(identity_types=identity_types)

    def get_identity(self, identity_name: str) -> EmailIdentityDetails:
        return self.ses.get_email_identity(
            _require_non_empty_text(identity_name, "identity_name"),
        )

    def delete_identity(self, identity_name: str) -> None:
        self.ses.delete_email_identity(
            _require_non_empty_text(identity_name, "identity_name"),
        )

    def suppress_destination(
        self,
        email_address: str,
        reason: SuppressionReason = "BOUNCE",
    ) -> None:
        normalized_email = _require_non_empty_text(email_address, "email_address")
        self.ses.put_suppressed_destination(normalized_email, reason)

    def unsuppress_destination(self, email_address: str) -> None:
        normalized_email = _require_non_empty_text(email_address, "email_address")
        self.ses.delete_suppressed_destination(normalized_email)

    def list_suppressed_destinations(
        self,
        *,
        reasons: list[SuppressionReason] | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> list[SuppressedDestinationSummary]:
        return self.ses.list_suppressed_destinations(
            reasons=reasons,
            start_date=start_date,
            end_date=end_date,
        )

    def list_templates(self) -> ListTemplatesResponse:
        return self.ses.list_templates()

    def delete_template(self, name: str) -> None:
        self.ses.delete_template(_require_non_empty_text(name, "name"))

    def _normalize_bulk_recipients(
        self,
        recipients: list[str | EmailAddress | dict[str, object] | BulkEmailRecipient],
    ) -> list[BulkEmailRecipient]:
        normalized: list[BulkEmailRecipient] = []

        for raw_recipient in recipients:
            if isinstance(raw_recipient, str | EmailAddress):
                normalized.append({"email": _to_email_address(raw_recipient)})
                continue

            if not isinstance(raw_recipient, dict):
                msg = "Bulk recipient must be a string email, EmailAddress, or mapping"
                raise SESValidationError(msg)

            raw_email = raw_recipient.get("email")
            if not isinstance(raw_email, str | EmailAddress):
                msg = "Bulk recipient 'email' must be str or EmailAddress"
                raise SESValidationError(msg)

            recipient: BulkEmailRecipient = {"email": _to_email_address(raw_email)}

            raw_template_data = raw_recipient.get("template_data")
            if raw_template_data is not None:
                if not isinstance(raw_template_data, dict):
                    msg = "Bulk recipient 'template_data' must be a dict"
                    raise SESValidationError(msg)
                recipient["template_data"] = raw_template_data

            raw_tags = raw_recipient.get("tags")
            if raw_tags is not None:
                if not isinstance(raw_tags, dict):
                    msg = "Bulk recipient 'tags' must be a dict"
                    raise SESValidationError(msg)
                tags: dict[str, str] = {}
                for key, value in raw_tags.items():
                    if not isinstance(key, str) or not isinstance(value, str):
                        msg = "Bulk recipient 'tags' keys and values must be strings"
                        raise SESValidationError(msg)
                    tags[key] = value
                recipient["tags"] = tags

            normalized.append(recipient)

        if not normalized:
            msg = "At least one recipient is required"
            raise SESValidationError(msg)

        return normalized

    def send_bulk_emails(
        self,
        recipients: list[str | EmailAddress | dict[str, object] | BulkEmailRecipient],
        subject: str | None = None,
        body: str | None = None,
        template_name: str | None = None,
        email_format: EmailFormat | None = None,
        sender: str | EmailAddress | None = None,
        batch_size: int = _DEFAULT_BULK_BATCH_SIZE,
        max_workers: int | None = None,
        configuration_set_name: str | None = None,
        list_management_options: ListManagementOptions | None = None,
        default_tags: dict[str, str] | None = None,
        idempotency_key: str | None = None,
        trace_tag_name: str | None = None,
        trace_tag_value: str | None = None,
        *,
        raise_on_error: bool = False,
    ) -> list[BulkEmailResult]:
        _ = max_workers  # kept for backward compatibility; SESv2 bulk send is server-side.

        if batch_size <= 0:
            msg = "batch_size must be a positive integer"
            raise SESValidationError(msg)

        use_template = template_name is not None
        content: EmailContent | None = None
        selected_format = email_format or self.config.default_format

        if use_template:
            validated_template_name = _require_non_empty_text(template_name, "template_name")
        else:
            if subject is None or body is None:
                msg = "subject and body are required when template_name is not provided"
                raise SESValidationError(msg)
            validated_template_name = None
            content = self._build_email_content(
                subject=subject,
                body=body,
                email_format=selected_format,
            )

        bulk_config: BulkEmailConfig = {
            "sender": self._resolve_sender(sender),
            "recipients": self._normalize_bulk_recipients(recipients),
            "batch_size": batch_size,
            "email_format": selected_format,
        }
        merged_default_tags: dict[str, str] = {}
        if default_tags:
            merged_default_tags.update(default_tags)
        if idempotency_key is not None:
            merged_default_tags["idempotency_key"] = _require_non_empty_text(
                idempotency_key,
                "idempotency_key",
            )
        if trace_tag_name is not None:
            normalized_trace_tag_name = _require_non_empty_text(
                trace_tag_name,
                "trace_tag_name",
            )
            resolved_trace_tag_value = _require_non_empty_text(
                trace_tag_value or uuid4().hex,
                "trace_tag_value",
            )
            merged_default_tags[normalized_trace_tag_name] = resolved_trace_tag_value
        if merged_default_tags:
            bulk_config["default_tags"] = merged_default_tags

        resolved_configuration_set = self._resolve_configuration_set_name(
            configuration_set_name,
        )
        if resolved_configuration_set is not None:
            bulk_config["configuration_set_name"] = resolved_configuration_set

        normalized_list_management_options = _normalize_list_management_options(
            list_management_options,
        )
        if normalized_list_management_options is not None:
            bulk_config["list_management_options"] = normalized_list_management_options

        if validated_template_name is not None:
            bulk_config["template_name"] = validated_template_name
        if content is not None:
            bulk_config["content"] = content

        results = self.ses.send_bulk_email(bulk_config)

        if raise_on_error:
            failures = [result for result in results if result["status"] == "error"]
            if failures:
                sample = failures[0]
                msg = (
                    f"Bulk send failed for {len(failures)} recipients; "
                    f"first failure={sample['email']}: {sample['error']}"
                )
                raise SESBatchError(msg)

        return results
