from datetime import datetime
from typing import TypedDict, NotRequired


class TemplateMetadata(TypedDict, total=False):
    """Metadata for an SES template."""

    TemplateName: NotRequired[str]
    CreatedTimestamp: NotRequired[datetime]
