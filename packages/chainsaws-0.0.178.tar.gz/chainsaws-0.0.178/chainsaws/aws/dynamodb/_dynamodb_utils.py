import base64
from collections.abc import Iterator
from decimal import Decimal
from numbers import Number
from typing import Callable, ParamSpec, TypeVar, cast, overload
import logging

from chainsaws.aws.dynamodb._dynamodb_config import (
    DELIMITER,
    DYNAMODB_BASE64_CHARSET,
    SORT_KEY_DECIMAL_PLACES,
    SORT_KEY_LENGTH,
    SORT_KEY_MAX_HALF_VALUE,
    SORT_KEY_MAX_VALUE,
)
from chainsaws.aws.dynamodb.dynamodb_models import DynamoItem, PartitionMetaItem
from chainsaws.aws.dynamodb.dynamodb_exception import DynamoDBError

P = ParamSpec("P")
R = TypeVar("R")
T = TypeVar("T")
K = TypeVar("K")
V = TypeVar("V")


logger = logging.getLogger(__name__)

RustDecodeImpl = Callable[[object, type[Decimal]], object]
RustFormatIntImpl = Callable[[int], str]
RustFormatImpl = Callable[
    [
        object,
        int,
        str,
        int,
        int,
        int,
        str,
        Callable[[int | float | Decimal], int],
        Callable[[int], str],
        type[Decimal],
    ],
    str,
]
RustCustomBase64EncodeImpl = Callable[[int, str], str]
RustCustomBase64DecodeImpl = Callable[[str, str], int]
RustMergePkSkImpl = Callable[[str, str], str]
RustSplitPkSkImpl = Callable[[str], tuple[str, str]]

try:
    from chainsaws_pyo3 import decode_dict as _decode_dict_rust_impl
    from chainsaws_pyo3 import format_value_int as _format_value_int_rust_impl
    from chainsaws_pyo3 import format_value as _format_value_rust_impl
    from chainsaws_pyo3 import convert_int_to_custom_base64 as _convert_int_to_custom_base64_rust_impl
    from chainsaws_pyo3 import convert_custom_base64_to_int as _convert_custom_base64_to_int_rust_impl
    from chainsaws_pyo3 import merge_pk_sk as _merge_pk_sk_rust_impl
    from chainsaws_pyo3 import split_pk_sk as _split_pk_sk_rust_impl
except Exception:
    _decode_dict_rust_impl: RustDecodeImpl | None = None
    _format_value_int_rust_impl: RustFormatIntImpl | None = None
    _format_value_rust_impl: RustFormatImpl | None = None
    _convert_int_to_custom_base64_rust_impl: RustCustomBase64EncodeImpl | None = None
    _convert_custom_base64_to_int_rust_impl: RustCustomBase64DecodeImpl | None = None
    _merge_pk_sk_rust_impl: RustMergePkSkImpl | None = None
    _split_pk_sk_rust_impl: RustSplitPkSkImpl | None = None

HAS_DYNAMODB_RUST_ACCELERATION = (
    _decode_dict_rust_impl is not None
    or _format_value_int_rust_impl is not None
    or _format_value_rust_impl is not None
    or _convert_int_to_custom_base64_rust_impl is not None
    or _convert_custom_base64_to_int_rust_impl is not None
    or _merge_pk_sk_rust_impl is not None
    or _split_pk_sk_rust_impl is not None
)

_USE_RUST_DECODE = True
_USE_RUST_FORMAT = True
_USE_RUST_FORMAT_GENERIC = True
_USE_RUST_KEY_UTILS = True


def _require_rust_impl(name: str, impl: T | None) -> T:
    if impl is None:
        msg = (
            f"Rust DynamoDB hotpath is enabled for '{name}', "
            "but chainsaws_pyo3 implementation is unavailable."
        )
        raise RuntimeError(msg)
    return impl


_require_rust_impl("decode_dict", _decode_dict_rust_impl)
_require_rust_impl("format_value_int", _format_value_int_rust_impl)
_require_rust_impl("format_value", _format_value_rust_impl)
_require_rust_impl("convert_int_to_custom_base64", _convert_int_to_custom_base64_rust_impl)
_require_rust_impl("convert_custom_base64_to_int", _convert_custom_base64_to_int_rust_impl)
_require_rust_impl("merge_pk_sk", _merge_pk_sk_rust_impl)
_require_rust_impl("split_pk_sk", _split_pk_sk_rust_impl)


_SYSTEM_KEYS = frozenset(
    ["_pk", "_sk"] +
    [f"_{key}{i}" for key in ("pk", "sk") for i in range(1, 21)]
)

_BASE64_CHAR_TO_INT = {char: idx for idx, char in enumerate(DYNAMODB_BASE64_CHARSET)}

_DECIMAL_POWER = Decimal(10) ** SORT_KEY_DECIMAL_PLACES


@overload
def encode_dict(obj: DynamoItem) -> DynamoItem: ...


@overload
def encode_dict(obj: list[object]) -> list[object]: ...


@overload
def encode_dict(obj: object) -> object: ...


def encode_dict(obj: object) -> object:
    """Encode DynamoDB objects by converting Decimal types to native Python numbers.

    Args:
        obj: Object to encode (dict, list, or scalar value)
            - For dicts: Recursively encodes all values
            - For lists: Recursively encodes all elements
            - For scalars: Converts Decimal to int/float

    Returns:
        Encoded object with same structure but converted number types

    Examples:
        >>> encode_dict({'count': Decimal('10'), 'price': Decimal('19.99')})
        {'count': 10, 'price': 19.99}

        >>> encode_dict([Decimal('1'), Decimal('2.5')])
        [1, 2.5]

        >>> encode_dict({'items': [{'qty': Decimal('5')}]})
        {'items': [{'qty': 5}]}

    """
    def _cast_number(value: object) -> object:
        """Cast a value to appropriate number type if needed.

        Args:
            value: Value to cast

        Returns:
            - dict -> recursively encoded
            - list -> recursively encoded
            - bool -> unchanged boolean
            - Number -> int if whole number, float if decimal
            - other -> unchanged value

        """
        if isinstance(value, dict):
            return encode_dict(cast(DynamoItem, value))
        if isinstance(value, list):
            return encode_dict(value)

        if isinstance(value, bool):
            return value

        if isinstance(value, Number):
            return int(value) if value % 1 == 0 else float(value)

        return value

    if isinstance(obj, dict):
        return {
            key: _cast_number(value)
            for key, value in obj.items()
        }
    if isinstance(obj, list):
        return [_cast_number(value) for value in obj]
    return obj


@overload
def decode_dict(dict_obj: DynamoItem) -> DynamoItem: ...


@overload
def decode_dict(dict_obj: list[object]) -> list[object]: ...


@overload
def decode_dict(dict_obj: object) -> object: ...


def _decode_dict_python(dict_obj: object) -> object:
    """Recursively convert float numbers to Decimal in nested dictionaries and lists.

    This function traverses through nested dictionaries and lists, converting any float
    values to Decimal for DynamoDB compatibility. The conversion is done recursively
    to handle arbitrary levels of nesting.

    Args:
        dict_obj: Input object to process. Can be:
            - Dictionary: All float values will be converted to Decimal
            - List: All float values in the list and nested structures will be converted
            - Other types: Returned as-is

    Returns:
        dict/list/scalar: input structure with float values converted to Decimal

    Examples:
        >>> decode_dict({'a': 1.0, 'b': {'c': 2.5}})
        {'a': Decimal('1.0'), 'b': {'c': Decimal('2.5')}}

        >>> decode_dict([1.0, {'a': 2.5}])
        [Decimal('1.0'), {'a': Decimal('2.5')}]

        >>> decode_dict('not a dict')
        'not a dict'

    """
    def cast_number(v: object) -> object:
        if isinstance(v, dict):
            return _decode_dict_python(cast(DynamoItem, v))
        if isinstance(v, list):
            return _decode_dict_python(v)
        if isinstance(v, float):
            return Decimal(str(v))
        return v

    if isinstance(dict_obj, dict):
        return {k: cast_number(v) for k, v in dict_obj.items()}
    if isinstance(dict_obj, list):
        return [cast_number(v) for v in dict_obj]
    return dict_obj


def decode_dict(dict_obj: object) -> object:
    if _USE_RUST_DECODE:
        decode_impl = _require_rust_impl("decode_dict", _decode_dict_rust_impl)
        return decode_impl(dict_obj, Decimal)
    return _decode_dict_python(dict_obj)


def has_sub_tuple(tuple_list: list[tuple], sub_tuple: tuple) -> bool:
    """Check if any tuple in the list contains sub_tuple as a prefix.

    Args:
        tuple_list: List of tuples to search in
        sub_tuple: Tuple to search for as a prefix

    Returns:
        bool: True if sub_tuple is a prefix of any tuple in the list

    """
    return any(
        all(t[i] == s for i, s in enumerate(sub_tuple))
        for t in tuple_list
        if len(sub_tuple) <= len(t)
    )


def is_sub_tuple(tup: tuple, sub_tuple: tuple) -> bool:
    """Check if sub_tuple is a prefix of tup.

    Args:
        tup: Main tuple to check against
        sub_tuple: Potential prefix tuple

    Returns:
        bool: True if sub_tuple is a prefix of tup

    """
    if len(sub_tuple) > len(tup):
        return False

    return all(tup[i] == sub_tuple[i] for i in range(len(sub_tuple)))


def get_item(tup: tuple[T, ...], index: int, default: T | None = None) -> T | None:
    """Safely get item from tuple at index with default value.

    Args:
        tup: Tuple to get item from
        index: Index to retrieve
        default: Default value if index out of range

    Returns:
        Item at index or default value

    """
    return tup[index] if len(tup) > index else default


@overload
def divide_chunks(data: list[T], chunk_size: int) -> Iterator[list[T]]: ...


@overload
def divide_chunks(data: dict[K, V], chunk_size: int) -> Iterator[dict[K, V]]: ...


def divide_chunks(data: list[T] | dict[K, V], chunk_size: int) -> Iterator[list[T] | dict[K, V]]:
    """Split list or dictionary into chunks of specified size.

    Args:
        data: List or dictionary to split
        chunk_size: Size of each chunk

    Yields:
        Iterator of chunks

    """
    if isinstance(data, list):
        data_len = len(data)
        for i in range(0, data_len, chunk_size):
            yield data[i:i + chunk_size]

    elif isinstance(data, dict):
        items = tuple(data.items())
        items_len = len(items)
        for i in range(0, items_len, chunk_size):
            yield dict(items[i:i + chunk_size])


def _convert_int_to_custom_base64_python(number: int) -> str:
    """Convert integer to custom base64 string for sort key ordering.

    Args:
        number: Integer to convert

    Returns:
        str: Custom base64 representation

    """
    if number == 0:
        return DYNAMODB_BASE64_CHARSET[0]

    chars = []
    base = 64
    charset = DYNAMODB_BASE64_CHARSET

    while number > 0:
        chars.append(charset[number % base])
        number //= base

    return "".join(reversed(chars))


def convert_int_to_custom_base64(number: int) -> str:
    if _USE_RUST_KEY_UTILS:
        convert_impl = _require_rust_impl(
            "convert_int_to_custom_base64",
            _convert_int_to_custom_base64_rust_impl,
        )
        return convert_impl(number, DYNAMODB_BASE64_CHARSET)
    return _convert_int_to_custom_base64_python(number)


def _convert_custom_base64_to_int_python(custom_base64: str) -> int:
    """Convert custom base64 string back to integer.

    Args:
        custom_base64: Custom base64 string to convert

    Returns:
        int: Original integer value

    """
    base = 64
    result = 0
    for power, c in enumerate(reversed(custom_base64)):
        result += _BASE64_CHAR_TO_INT[c] * (base ** power)
    return result


def convert_custom_base64_to_int(custom_base64: str) -> int:
    if _USE_RUST_KEY_UTILS:
        convert_impl = _require_rust_impl(
            "convert_custom_base64_to_int",
            _convert_custom_base64_to_int_rust_impl,
        )
        return convert_impl(custom_base64, DYNAMODB_BASE64_CHARSET)
    return _convert_custom_base64_to_int_python(custom_base64)


def str_to_base64_str(text: str) -> str:
    """Convert string to URL-safe base64 encoding.

    Args:
        text: String to encode

    Returns:
        str: Base64 encoded string

    """
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode("utf-8")


def base64_str_to_str(b64_string: str) -> str:
    """Convert URL-safe base64 string back to original string.

    Args:
        b64_string: Base64 encoded string

    Returns:
        str: Original decoded string

    """
    return base64.urlsafe_b64decode(b64_string.encode("utf-8")).decode("utf-8")


def unsigned_number(number: int | float | Decimal) -> int:
    """Convert number to unsigned format for base64 conversion.

    Shifts negative numbers to positive range for sort key ordering.
    Valid range: -8.834235323891921e+55 to +8.834235323891921e+55

    Args:
        number: Number to convert

    Returns:
        int: Unsigned number

    Raises:
        ValueError: If number is outside valid range

    """
    scaled = int(Decimal(number) * _DECIMAL_POWER)
    shifted = scaled + SORT_KEY_MAX_HALF_VALUE

    if not (0 <= shifted < SORT_KEY_MAX_VALUE):
        msg = "Number must be between -8.834235323891921e+55 and +8.834235323891921e+55"
        raise ValueError(
            msg,
        )

    return shifted


def _merge_pk_sk_python(partition_key: str, sort_key: str) -> str:
    """Merge partition key and sort key with escape handling.

    Args:
        partition_key: Partition key
        sort_key: Sort key

    Returns:
        str: Merged key with escaped delimiters

    """
    return (
        partition_key.replace("&", "-&") +
        "&" +
        sort_key.replace("&", "-&")
    )


def merge_pk_sk(partition_key: str, sort_key: str) -> str:
    if _USE_RUST_KEY_UTILS:
        merge_impl = _require_rust_impl("merge_pk_sk", _merge_pk_sk_rust_impl)
        return merge_impl(partition_key, sort_key)
    return _merge_pk_sk_python(partition_key, sort_key)


def _split_pk_sk_python(merged_id: str) -> tuple[str, str]:
    """Split merged key back into partition key and sort key.

    Args:
        merged_id: Merged key string in format 'partition_key&sort_key'
                 where & is the delimiter

    Returns:
        Tuple[str, str]: (partition_key, sort_key)

    Raises:
        ValueError: If merged_id is invalid or doesn't contain the delimiter
    """
    if "&" not in merged_id:
        msg = f"Invalid item_id format: '{merged_id}'. Expected '<partition_key>&<sort_key>'."
        raise ValueError(msg)

    parts: list[str] = []
    prev_char = None
    buffer: list[str] = []

    for char in merged_id:
        if char == "&" and prev_char != "-":
            parts.append("".join(buffer).replace("-&", "&"))
            buffer = []
        else:
            buffer.append(char)
        prev_char = char

    if buffer:
        parts.append("".join(buffer).replace("-&", "&"))

    if len(parts) != 2:
        msg = f"Invalid item_id format: '{merged_id}'. Expected '<partition_key>&<sort_key>'."
        raise ValueError(msg)

    return parts[0], parts[1]


def split_pk_sk(merged_id: str) -> tuple[str, str]:
    if _USE_RUST_KEY_UTILS:
        split_impl = _require_rust_impl("split_pk_sk", _split_pk_sk_rust_impl)
        return split_impl(merged_id)
    return _split_pk_sk_python(merged_id)


def convert_if_number_to_decimal(value: object) -> object:
    """Convert numeric values to Decimal for DynamoDB compatibility.

    Args:
        value: Value to potentially convert

    Returns:
        Converted value or original if not numeric

    """
    if isinstance(value, bool):
        return value
    if isinstance(value, int | float):
        return Decimal(str(value))
    return value


def find_proper_index(
    partition_object: PartitionMetaItem,
    pk_field: str,
    sk_field: str | None = None,
) -> tuple[str | None, str, str]:
    """Find the appropriate index for querying.

    If sk_field is None, returns the first index that matches pk_field.
    If sk_field is provided, strictly searches for an exact match of both fields.

    Args:
        partition_object: Partition configuration object
        pk_field: Partition key field name
        sk_field: Sort key field name (optional)

    Returns:
        Tuple of (index_name, pk_name, sk_name)
        index_name will be None for main table, otherwise GSI name
        pk_name and sk_name are the key names for the chosen index

    """
    logger.debug(
        "find_proper_index: %s, pk_field=%s, sk_field=%s",
        partition_object,
        pk_field,
        sk_field,
    )

    def _build_invalid_pair_message(indexes: list[dict[str, object]]) -> str:
        partition_name = str(partition_object.get("_partition_name", "<unknown>"))
        requested_sk = "None" if sk_field is None else f"'{sk_field}'"
        message = (
            f"Invalid key field pair for partition '{partition_name}': "
            f"pk_field='{pk_field}', sk_field={requested_sk}.\n"
            "Allowed pairs:\n"
        )
        message += (
            f"- pk='{partition_object['_pk_field']}', "
            f"sk='{partition_object['_sk_field']}'\n"
        )
        for index in indexes:
            message += f"- pk='{index['_pk_field']}', sk='{index['_sk_field']}'\n"
        return message.rstrip()

    index_name = None
    pk_name = "_pk"
    sk_name = "_sk"
    if sk_field:
        # Strict search with both fields
        # Check main table first
        if pk_field == partition_object["_pk_field"] and sk_field == partition_object["_sk_field"]:
            index_name = None
        else:
            indexes = partition_object.get("indexes", [])
            for index in indexes:
                if pk_field == index["_pk_field"] and sk_field == index["_sk_field"]:
                    # Exact match found
                    index_name = index["index_name"]
                    pk_name = index["pk_name"]
                    sk_name = index["sk_name"]
                    break
            if not index_name:
                # No matching index found
                raise DynamoDBError(_build_invalid_pair_message(indexes=indexes))

    elif pk_field == partition_object["_pk_field"]:
        # Match on main table
        index_name = None
    else:
        indexes = partition_object.get("indexes", [])
        for index in indexes:
            if pk_field == index["_pk_field"]:
                # Found matching index
                index_name = index["index_name"]
                pk_name = index["pk_name"]
                sk_name = index["sk_name"]
                break
        # No match found in main table or indexes
        if not index_name:
            raise DynamoDBError(_build_invalid_pair_message(indexes=indexes))

    return index_name, pk_name, sk_name


def pop_system_keys(item: DynamoItem | None) -> DynamoItem | None:
    """Remove internal system keys from item.

    Args:
        item: Dictionary to process

    Returns:
        Copy of item with system keys removed

    Note:
        Removes primary keys (_pk, _sk) and GSI keys (_pk1 through _pk5, _sk1 through _sk5)

    """
    if not item or not isinstance(item, dict):
        return item

    return {k: v for k, v in item.items() if k not in _SYSTEM_KEYS}


def _format_value_python(value: object) -> str:
    """Format value for use as sort key with consistent ordering.

    Args:
        value: Value to format (number or string)

    Returns:
        Formatted string value

    Note:
        - Numbers are right-justified with prefix 'D'
        - Strings are terminated with delimiter and prefix 'S'
        - Numbers are converted to custom base64 for proper sorting
        - String length is padded to SORT_KEY_LENGTH for numbers

    """
    if isinstance(value, int | float | Decimal):
        base64_value = convert_int_to_custom_base64(unsigned_number(value))
        return f"D{base64_value.rjust(SORT_KEY_LENGTH)}"
    return f"S{str(value)}{DELIMITER}"


def format_value(value: object) -> str:
    if _USE_RUST_FORMAT and isinstance(value, int):
        format_int_impl = _require_rust_impl("format_value_int", _format_value_int_rust_impl)
        return format_int_impl(int(value))

    if _USE_RUST_FORMAT_GENERIC:
        format_generic_impl = _require_rust_impl("format_value", _format_value_rust_impl)
        return format_generic_impl(
            value,
            SORT_KEY_LENGTH,
            DELIMITER,
            SORT_KEY_DECIMAL_PLACES,
            SORT_KEY_MAX_HALF_VALUE,
            SORT_KEY_MAX_VALUE,
            DYNAMODB_BASE64_CHARSET,
            unsigned_number,
            convert_int_to_custom_base64,
            Decimal,
        )
    return _format_value_python(value)
