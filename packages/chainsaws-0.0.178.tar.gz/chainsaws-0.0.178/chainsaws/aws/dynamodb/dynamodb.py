import logging
import time
import orjson
from copy import deepcopy
from dataclasses import fields as dataclass_fields
from collections.abc import Callable, Generator, Iterator
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from decimal import Decimal
from functools import wraps
from typing import (
    Optional,
    ParamSpec,
    TypeVar,
    Final,
    Protocol,
    overload,
)

from chainsaws.aws.dynamodb._dynamodb_config import (
    DELIMITER,
    PARTITION_KEY_META_INFO,
    SORT_KEY_LENGTH,
)
from chainsaws.aws.dynamodb._dynamodb_internal import DynamoDB
from chainsaws.aws.dynamodb._dynamodb_utils import (
    convert_int_to_custom_base64,
    decode_dict,
    encode_dict,
    find_proper_index,
    format_value,
    merge_pk_sk,
    pop_system_keys,
    split_pk_sk,
    unsigned_number,
)
from chainsaws.aws.dynamodb.dynamodb_exception import (
    BatchOperationError,
    DuplicateIndexError,
    DynamoDBError,
    DynamoDBPartitionError,
    DynamoDBValidationError,
    PartitionNotFoundError,
)
from chainsaws.aws.dynamodb.dynamodb_models import (
    DynamoItem,
    DynamoKey,
    DynamoDBAPIConfig,
    DynamoModel,
    FilterCondition,
    FilterDict,
    PartitionConfigDict,
    PartitionMetaItem,
    RecursiveFilterNode,
    QueryPage,
)
from chainsaws.aws.shared import session

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=DynamoModel)
R = TypeVar("R")
P = ParamSpec("P")
MAX_BATCH_ERROR_ITEMS: Final[int] = 1000


class DynamoDBInternalProtocol(Protocol):
    def init_db_table(self) -> None: ...
    def get_item(
        self,
        pk: str,
        sk: str | None = None,
        consistent_read: bool = False,
    ) -> DynamoItem | None: ...
    def get_items(
        self,
        pk_sk_pairs: list[tuple[str, str]],
        consistent_read: bool = False,
    ) -> list[DynamoItem | None]: ...
    def put_item(self, item: DynamoItem, can_overwrite: bool = True) -> dict[str, object]: ...
    def batch_put(self, items: list[DynamoItem], can_overwrite: bool = False) -> bool: ...
    def update_item(self, pk: str, sk: str, item: DynamoItem) -> dict[str, object]: ...
    def delete_item(self, pk: str, sk: str) -> dict[str, object]: ...
    def batch_delete(self, pk_sk_pairs: list[tuple[str, str]]) -> bool: ...
    def query_items(
        self,
        partition_key_name: str,
        partition_key_value: str,
        sort_condition: str | None = None,
        sort_key_name: str | None = None,
        sort_key_value: object | None = None,
        sort_key_second_value: object | None = None,
        filters: list[FilterDict] | None = None,
        start_key: DynamoKey | None = None,
        reverse: bool = False,
        limit: int = 100,
        consistent_read: bool = False,
        index_name: str | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage: ...
    def scan_table(
        self,
        filters: list[FilterDict] | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        start_key: DynamoKey | None = None,
        limit: int | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage: ...
    def create_db_partition_index(self, index_name: str, pk_name: str, sk_name: str) -> dict[str, object]: ...
    def delete_db_partition_index(self, index_name: str) -> dict[str, object]: ...


def validate_partition_keys(func: Callable[P, R]) -> Callable[P, R]:
    """Decorator to validate partition key fields."""
    @wraps(func)
    def wrapper(self: "DynamoDBAPI", *args: P.args, **kwargs: P.kwargs) -> R:
        partition = kwargs.get("partition")
        pk_field = kwargs.get("pk_field")
        sk_field = kwargs.get("sk_field")

        # Support positional calls:
        # fn(partition, pk_field, sk_field, ...)
        if partition is None and len(args) >= 1:
            partition = args[0]
        if pk_field is None and len(args) >= 2:
            pk_field = args[1]
        if sk_field is None and len(args) >= 3:
            sk_field = args[2]

        if not partition:
            msg = "Partition name is required"
            raise DynamoDBError(msg)

        # Get partition configuration
        partition_obj = self.get_partition(partition)
        if not partition_obj:
            raise PartitionNotFoundError(partition)

        pk_field_val = partition_obj.get("_pk_field", "")
        sk_field_val = partition_obj.get("_sk_field", "")
        indexes_list = partition_obj.get("indexes", [])

        valid_pk_fields: set[str] = {"_ptn"}
        if pk_field_val:
            valid_pk_fields.add(pk_field_val)
        valid_sk_fields: set[str] = set()
        if sk_field_val:
            valid_sk_fields.add(sk_field_val)

        for index in indexes_list:
            idx_pk = index.get("_pk_field", "")
            idx_sk = index.get("_sk_field", "")
            if idx_pk:
                valid_pk_fields.add(idx_pk)
            if idx_sk:
                valid_sk_fields.add(idx_sk)

        if pk_field and pk_field not in valid_pk_fields:
            index_pks = sorted(valid_pk_fields - {"_ptn", pk_field_val})
            msg = (
                f"Invalid partition key field '{pk_field}' for partition '{partition}'.\n"
                f"Valid partition key fields:\n"
                f"- Primary: {pk_field_val}\n"
                f"- Indexes: {index_pks}\n"
                f"- Special: '_ptn'"
            )
            raise DynamoDBError(msg)

        if sk_field and sk_field not in valid_sk_fields:
            index_sks = sorted(valid_sk_fields - {sk_field_val})
            msg = (
                f"Invalid sort key field '{sk_field}' for partition '{partition}'.\n"
                f"Valid sort key fields:\n"
                f"- Primary: {sk_field_val}\n"
                f"- Indexes: {index_sks}"
            )
            raise DynamoDBError(msg)

        return func(self, *args, **kwargs)
    return wrapper


class DynamoDBAPI:
    """High-level DynamoDB API with partition and index management."""
    __slots__ = ('config', 'boto3_session', 'table_name', 'dynamo_db', 'cache', '_partition_cache')

    def __init__(
        self,
        table_name: str,
        config: Optional[DynamoDBAPIConfig] = None,
        internal: DynamoDBInternalProtocol | None = None,
    ) -> None:
        self.config = config or DynamoDBAPIConfig()
        self.table_name = table_name

        if internal is None:
            self.boto3_session = session.get_boto_session(
                credentials=self.config.credentials if self.config.credentials else None,
            )
            self.dynamo_db: DynamoDBInternalProtocol = DynamoDB(
                boto3_session=self.boto3_session,
                table_name=table_name,
                config=self.config,
            )
        else:
            self.boto3_session = None
            self.dynamo_db = internal

        self.cache: dict[str, list[PartitionMetaItem]] = {}
        self._partition_cache: dict[str, PartitionMetaItem | None] = {}

    def init_db_table(self) -> None:
        """Initialize DynamoDB table."""
        self.dynamo_db.init_db_table()

    def get_item(
        self,
        item_id: str,
        consistent_read: bool = False,
    ) -> DynamoItem | None:
        """Get single item by ID.

        Args:
            item_id: The ID of the item to retrieve, in format 'partition_key|sort_key'
            consistent_read: Whether to use strongly consistent reads

        Returns:
            The item data with system keys removed and values encoded, or None if not found

        Raises:
            Exception: If the provided item_id is invalid

        """
        try:
            _pk, _sk = split_pk_sk(item_id)
        except ValueError as e:
            msg = (
                f"Invalid item_id format: '{item_id}'. "
                "Expected '<partition_key>&<sort_key>'."
            )
            raise DynamoDBError(msg) from e
        if not _pk or not _sk:
            msg = (
                f"Invalid item_id format: '{item_id}'. "
                "Expected '<partition_key>&<sort_key>'."
            )
            raise DynamoDBError(msg)

        item = self.dynamo_db.get_item(_pk, _sk, consistent_read)

        if not item:
            return None

        item["_id"] = merge_pk_sk(
            partition_key=item["_pk"], sort_key=item["_sk"])

        return pop_system_keys(encode_dict(item))

    def get_items(
        self,
        item_ids: list[str],
        consistent_read: bool = False,
    ) -> list[DynamoItem | None]:
        """Batch query items by their IDs.

        Args:
            item_ids: List of item IDs to retrieve
            consistent_read: Whether to use strongly consistent reads

        Returns:
            List of items in the same order as ``item_ids``.
            Missing items are returned as ``None``.

        """
        pk_sk_pairs: list[tuple[str, str]] = []
        invalid_ids: list[str] = []
        for item_id in item_ids:
            try:
                pk_sk_pairs.append(split_pk_sk(item_id))
            except ValueError:
                invalid_ids.append(item_id)

        if invalid_ids:
            invalid_list = "\n".join(f"- {item_id}" for item_id in invalid_ids)
            raise DynamoDBError(f"Invalid item IDs found:\n{invalid_list}")

        items = self.dynamo_db.get_items(
            pk_sk_pairs=pk_sk_pairs,
            consistent_read=consistent_read,
        )

        normalized_items: list[DynamoItem | None] = []
        for item in items:
            if item is None:
                normalized_items.append(None)
                continue

            item["_id"] = merge_pk_sk(item["_pk"], item["_sk"])
            normalized_items.append(pop_system_keys(encode_dict(item)))

        return normalized_items

    @overload
    def put_item(
        self,
        partition: str,
        item: T,
        can_overwrite: bool = True,
    ) -> T: ...

    @overload
    def put_item(
        self,
        partition: str,
        item: DynamoItem,
        can_overwrite: bool = True,
    ) -> DynamoItem: ...

    def put_item(
        self,
        partition: str,
        item: T | DynamoItem,
        can_overwrite: bool = True
    ) -> T | DynamoItem:
        """Put a single item into DynamoDB

        Args:
            partition: Partition name to store the item in
            item: Item data to store
            can_overwrite: Whether existing items can be overwritten

        Returns:
            Stored item with system keys removed
        """
        is_model = isinstance(item, DynamoModel)
        model_class = item.__class__ if is_model else None
        item_dict = item.to_dict() if is_model else item
        processed_item = self.process_item_with_partition(item_dict, partition)
        item_id_for_error = str(processed_item.get("_id", ""))
        original_id = processed_item.pop('_id', None)

        try:
            self.dynamo_db.put_item(item=processed_item, can_overwrite=can_overwrite)
        except Exception as ex:
            msg = (
                f"Failed to put item in partition '{partition}' "
                f"with id '{item_id_for_error}': {ex!s}"
            )
            raise DynamoDBError(msg) from ex

        if original_id:
            processed_item['_id'] = original_id

        result = encode_dict(pop_system_keys(processed_item))

        if is_model and model_class:
            return model_class.from_dict(result)

        return result

    @overload
    def put_items(
        self,
        partition: str,
        items: list[T],
        can_overwrite: bool = True,
    ) -> list[T]: ...

    @overload
    def put_items(
        self,
        partition: str,
        items: list[DynamoItem],
        can_overwrite: bool = True,
    ) -> list[DynamoItem]: ...

    def put_items(
        self,
        partition: str,
        items: list[T] | list[DynamoItem],
        can_overwrite: bool = True,
    ) -> list[T] | list[DynamoItem]:
        """Put multiple items using batch operation.

        Args:
            partition: Partition name to store items in
            items: List of items to store (either all DynamoModel instances or all dictionaries)
            can_overwrite: Whether existing items can be overwritten

        Returns:
            List of processed items (same type as input)

        Raises:
            PartitionNotFoundError: If partition does not exist
            BatchOperationError: If batch operation fails

        """
        if not items:
            return []

        partition_obj = self.get_partition(partition)
        if not partition_obj:
            raise PartitionNotFoundError(partition)

        is_model = isinstance(items[0], DynamoModel)
        processed_items = []

        try:
            items_to_put = []
            for item in items:
                item_dict = item.to_dict() if is_model else item

                processed_item = self.process_item_with_partition(
                    item_dict,
                    partition,
                )

                processed_item.pop("_id", None)
                items_to_put.append(processed_item)

            success = self.dynamo_db.batch_put(
                items=items_to_put,
                can_overwrite=can_overwrite,
            )

            if not success:
                msg = "Failed to put items in batch"
                raise BatchOperationError(
                    message=msg,
                    succeeded_items=[],
                    failed_items=items,
                )

            for original_item, processed_item in zip(items, items_to_put, strict=False):
                item_id = (
                    getattr(original_item, "_id", None)
                    if is_model
                    else original_item.get("_id")
                )
                if item_id is not None:
                    processed_item["_id"] = item_id

                result = encode_dict(pop_system_keys(processed_item))

                if is_model:
                    result = original_item.__class__.from_dict(result)

                processed_items.append(result)

            return processed_items
        except Exception as e:
            logger.exception(
                "Batch put operation failed: partition=%s count=%s error=%s",
                partition,
                len(items),
                e,
            )
            raise BatchOperationError(
                message=(
                    f"Failed to put items in partition '{partition}' "
                    f"(count={len(items)}): {e!s}"
                ),
                failed_items=items,
            ) from e

    def _check_keys_cannot_update(self, partition_name: str) -> set[str]:
        """Return list of fields that cannot be updated (primary key and unique key fields).

        This method checks which fields in a partition cannot be updated by:
        1. Getting the partition configuration
        2. Identifying primary key fields (partition key and sort key)
        3. Identifying any unique key fields
        4. Combining them into a set of protected fields

        Args:
            partition_name: Name of the partition to check

        Returns:
            Set[str]: Set of field names that cannot be updated

        Raises:
            PartitionNotFoundError: If the specified partition does not exist

        """
        # Initialize empty set to store protected field names
        keys_cannot_update = set()
        partition = self.get_partition(partition_name)

        if not partition:
            msg = f"No such partition: {partition_name}"
            raise PartitionNotFoundError(
                msg)

        pk_field = partition["_pk_field"]
        sk_field = partition["_sk_field"]
        uk_fields = partition["_uk_fields"]

        keys_cannot_update.add(pk_field)
        keys_cannot_update.add(sk_field)

        if uk_fields:
            for uk_field in uk_fields:
                keys_cannot_update.add(uk_field)

        return keys_cannot_update

    @staticmethod
    def _is_numeric_value(value: object) -> bool:
        return isinstance(value, int | float | Decimal) and not isinstance(value, bool)

    @staticmethod
    def _type_name(value: object) -> str:
        return type(value).__name__

    @classmethod
    def _is_update_value_type_compatible(cls, expected_value: object, update_value: object) -> bool:
        if expected_value is None or update_value is None:
            return True

        if isinstance(expected_value, bool):
            return isinstance(update_value, bool)

        if cls._is_numeric_value(expected_value):
            return cls._is_numeric_value(update_value)

        if isinstance(expected_value, dict):
            return isinstance(update_value, dict)

        if isinstance(expected_value, list):
            return isinstance(update_value, list)

        if isinstance(expected_value, tuple):
            return isinstance(update_value, tuple)

        if isinstance(expected_value, set | frozenset):
            return isinstance(update_value, set | frozenset)

        if isinstance(expected_value, bytes | bytearray):
            return isinstance(update_value, bytes | bytearray)

        return isinstance(update_value, type(expected_value))

    @classmethod
    def _collect_type_mismatch_fields(
        cls,
        target_item: DynamoItem,
        update_item: DynamoItem,
    ) -> list[str]:
        mismatched_fields: list[str] = []

        for field_name, update_value in update_item.items():
            if field_name.startswith("_"):
                continue

            if field_name not in target_item:
                mismatched_fields.append(f"{field_name}(field_not_found)")
                continue

            expected_value = target_item[field_name]
            if not cls._is_update_value_type_compatible(expected_value, update_value):
                mismatched_fields.append(
                    f"{field_name}(expected={cls._type_name(expected_value)}, "
                    f"got={cls._type_name(update_value)})",
                )

        return mismatched_fields

    @overload
    def update_item(
        self,
        partition: str,
        item_id: str,
        item: T,
        consistent_read: bool = False,
    ) -> T: ...

    @overload
    def update_item(
        self,
        partition: str,
        item_id: str,
        item: DynamoItem,
        consistent_read: bool = False,
    ) -> DynamoItem: ...

    def update_item(
        self,
        partition: str,
        item_id: str,
        item: T | DynamoItem,
        consistent_read: bool = False,
    ) -> T | DynamoItem:
        """Update a single item in DynamoDB.

        Args:
            partition: Partition name where the item exists
            item_id: ID of the item to update
            item: Model instance or dictionary containing fields to update
            consistent_read: Use strong consistent read if True

        Returns:
            The updated item with system keys removed, same type as input

        Notes:
            1. Cannot update partition key (pk) and sort key (sk) fields
            2. Will validate that key fields are not being modified

        """
        is_model = isinstance(item, DynamoModel)
        model_class = item.__class__ if is_model else None
        item_dict = item.to_dict() if is_model else item

        target_item = self.get_item(
            item_id=item_id, consistent_read=consistent_read)

        if not target_item:
            msg = f"Cannot find item with given id: {item_id}"
            raise DynamoDBError(msg)

        if target_item["_ptn"] != partition:
            msg = (
                f"Partition mismatch for item id '{item_id}': "
                f"expected partition '{partition}', actual partition '{target_item['_ptn']}'"
            )
            raise DynamoDBError(msg)

        origin_pk, origin_sk = split_pk_sk(merged_id=item_id)
        key_fields = self._check_keys_cannot_update(partition_name=partition)
        item_to_insert = item_dict.copy()
        removed_key_fields: list[str] = []

        for key_field in key_fields:
            if key_field in item_to_insert:
                item_to_insert.pop(key_field)
                removed_key_fields.append(key_field)

        if removed_key_fields:
            logger.warning(
                "Ignored key fields in update payload: partition=%s item_id=%s fields=%s",
                partition,
                item_id,
                ",".join(sorted(removed_key_fields)),
            )

        mismatch_fields = self._collect_type_mismatch_fields(
            target_item=target_item,
            update_item=item_to_insert,
        )
        if mismatch_fields:
            mismatch_field_names = ", ".join(sorted(set(mismatch_fields)))
            logger.warning(
                "Type mismatch detected in update payload: partition=%s item_id=%s details=%s",
                partition,
                item_id,
                mismatch_field_names,
            )
            raise DynamoDBError(f"Type mismatch in fields: {mismatch_field_names}")

        item_to_insert = self.process_item_with_partition(
            item_to_insert, partition, for_creation=False)

        ban_keys = ["_pk", "_sk", "_id", "_crt", "_ptn"]
        for ban_key in ban_keys:
            if ban_key in item_to_insert:
                item_to_insert.pop(ban_key)

        response = self.dynamo_db.update_item(
            pk=origin_pk, sk=origin_sk, item=item_to_insert)

        attributes = response.get("Attributes", {})

        if attributes:
            attributes["_id"] = item_id

        result = pop_system_keys(encode_dict(attributes))

        if is_model and model_class:
            return model_class.from_dict(result)

        return result

    @overload
    def update_items(
        self,
        partition: str,
        item_updates: dict[str, T],
        max_workers: int = 32,
    ) -> list[T]: ...

    @overload
    def update_items(
        self,
        partition: str,
        item_updates: dict[str, DynamoItem],
        max_workers: int = 32,
    ) -> list[DynamoItem]: ...

    def update_items(
        self,
        partition: str,
        item_updates: dict[str, T] | dict[str, DynamoItem],
        max_workers: int = 32,
    ) -> list[T] | list[DynamoItem]:
        """Update multiple items in parallel.

        Args:
            partition: Partition name where items exist
            item_updates: Dictionary mapping item_ids to update data
                        (either all model instances or all dictionaries)
            max_workers: Maximum number of parallel workers

        Returns:
            List of updated items (same type as input)

        Raises:
            BatchOperationError: If any update operation fails

        Example:
            # Using model instances
            updates = {
                "user#123": User(name="Updated Name"),
                "user#456": User(email="new@email.com")
            }
            updated_users = db.update_items(
                "user", updates)  # Returns List[User]

            # Using dictionaries
            updates = {
                "user#123": {"name": "Updated Name"},
                "user#456": {"email": "new@email.com"}
            }
            updated_items = db.update_items(
                "user", updates)  # Returns List[Dict]

        """
        if not item_updates:
            return []
        if max_workers < 1:
            raise DynamoDBError("max_workers must be greater than 0")

        completed_updates: list[tuple[int, T | DynamoItem]] = []
        failed_updates: list[tuple[str, T | DynamoItem]] = []
        items_list = list(item_updates.items())

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            inflight: dict[Future[T | DynamoItem], tuple[int, str, T | DynamoItem]] = {}
            next_submit_idx = 0

            while next_submit_idx < len(items_list) or inflight:
                while next_submit_idx < len(items_list) and len(inflight) < max_workers:
                    item_id, item = items_list[next_submit_idx]
                    future = executor.submit(
                        self.update_item,
                        partition=partition,
                        item_id=item_id,
                        item=item,
                    )
                    inflight[future] = (next_submit_idx, item_id, item)
                    next_submit_idx += 1

                if not inflight:
                    break

                done_future = next(as_completed(inflight))
                update_idx, item_id, original_item = inflight.pop(done_future)
                try:
                    result = done_future.result()
                    completed_updates.append((update_idx, result))
                except Exception as e:
                    logger.exception(
                        "Failed to update item in batch: partition=%s item_id=%s error=%s",
                        partition,
                        item_id,
                        e,
                    )
                    failed_updates.append((item_id, original_item))

            if failed_updates:
                updated_items = [
                    item
                    for _, item in sorted(completed_updates, key=lambda pair: pair[0])
                ]
                failed_ids = ", ".join(item_id for item_id, _ in failed_updates[:5])
                msg = (
                    f"Failed to update items: {len(failed_updates)} failed out of {len(items_list)}. "
                    f"failed_ids=[{failed_ids}]"
                )
                logger.error(
                    "Batch update failed: partition=%s failed=%s total=%s failed_ids=%s",
                    partition,
                    len(failed_updates),
                    len(items_list),
                    failed_ids,
                )
                raise BatchOperationError(
                    msg,
                    updated_items,
                    failed_updates,
                )

        return [
            item
            for _, item in sorted(completed_updates, key=lambda pair: pair[0])
        ]

    def delete_item(
        self,
        item_id: str,
    ) -> DynamoItem:
        """Delete single item by ID.

        Args:
            item_id: ID of the item to delete in format 'partition_key&sort_key'

        Returns:
            Dict containing the deleted item attributes

        Raises:
            DynamoDBError: If the item ID is invalid or the item does not exist
        """
        try:
            pk, sk = split_pk_sk(merged_id=item_id)
        except ValueError as e:
            msg = (
                f"Invalid item_id format: '{item_id}'. "
                "Expected '<partition_key>&<sort_key>'."
            )
            raise DynamoDBError(msg) from e
        if not pk or not sk:
            msg = (
                f"Invalid item_id format: '{item_id}'. "
                "Expected '<partition_key>&<sort_key>'."
            )
            raise DynamoDBError(msg)

        try:
            response = self.dynamo_db.delete_item(pk=pk, sk=sk)
            return encode_dict(response.get("Attributes", {}))
        except Exception as ex:
            ex_str = str(ex)
            if (
                "Item not found with pk:" in ex_str
                or "Cannot find item with given keys" in ex_str
                or "Cannot find item with given id" in ex_str
            ):
                raise DynamoDBError(f"Cannot find item with given id: {item_id}") from ex
            msg = f"Failed to delete item {item_id}: {ex!s}"
            raise DynamoDBError(msg) from ex

    def delete_items(
        self,
        item_ids: list[str],
    ) -> bool:
        """Delete multiple items by IDs in parallel.

        This method deletes multiple items from DynamoDB in a batch operation.
        It splits each item ID into partition key and sort key pairs before deletion.

        Args:
            item_ids: List of item IDs to delete. Each ID should be in the format
                     'partition_key|sort_key'

        Returns:
            True if all batch delete calls succeed

        Raises:
            DynamoDBError: If any item ID is invalid

        Note:
            Uses DynamoDB batch delete operation which has a limit of 25 items per batch.
            For larger deletes, the underlying batch_delete method handles batching.

        """
        pk_sk_pairs = []
        invalid_ids = []

        for item_id in item_ids:
            try:
                pk, sk = split_pk_sk(merged_id=item_id)
            except ValueError:
                invalid_ids.append(item_id)
                continue
            if not pk or not sk:
                invalid_ids.append(item_id)
            else:
                pk_sk_pairs.append((pk, sk))

        if invalid_ids:
            invalid_list = "\n".join(f"- {item_id}" for item_id in invalid_ids)
            raise DynamoDBError(f"Invalid item IDs found:\n{invalid_list}")

        return self.dynamo_db.batch_delete(pk_sk_pairs=pk_sk_pairs)

    @validate_partition_keys
    def query_items(
        self,
        partition: str,
        pk_field: Optional[str] = None,
        sk_field: Optional[str] = None,
        pk_value: Optional[object] = None,
        sk_condition: Optional[FilterCondition] = None,
        sk_value: Optional[object] = None,
        sk_second_value: Optional[object] = None,
        start_key: Optional[str | DynamoKey] = None,
        limit: int = 100,
        max_scan_rep: int = 100,
        filters: Optional[list[FilterDict]] = None,
        recursive_filters: Optional[RecursiveFilterNode] = None,
        reverse: bool = False,
        consistent_read: bool = False,
        projection_fields: Optional[list[str]] = None,
    ) -> tuple[list[DynamoItem], Optional[str]]:
        """Query items with complex filtering.

        Args:
            partition: Partition name
            pk_field: Partition key field name
            sk_field: Sort key field name
            pk_value: Partition key value
            sk_condition: Sort key operation condition
            sk_value: Sort key value
            sk_second_value: Second sort key value for between operations
            filters: List of filter conditions. Example:
                [
                    {
                        'field': 'name',           # Field to filter on
                        'value': 'John',           # Value to compare against
                        # One of: eq|neq|lte|lt|gte|gt|btw|stw|is_in|contains|exist|not_exist
                        'condition': 'eq'
                    }
                ]
            recursive_filters: Nested filter conditions with AND/OR operations. Example:
                {
                    'left': {
                        'field': 'age',
                        'value': 25,
                        'condition': 'gte'
                    },
                    'operation': 'and',
                    'right': {
                        'left': {
                            'field': 'city',
                            'value': 'Seoul',
                            'condition': 'eq'
                        },
                        'operation': 'or',
                        'right': {
                            'field': 'status',
                            'value': 'active',
                            'condition': 'eq'
                        }
                    }
                }
            max_scan_rep: Maximum number of scan repetitions
            start_key: Start key for pagination
            limit: Maximum number of items to return
            reverse: Sort in descending order if True
            consistent_read: Use strong consistent read if True

        Returns:
            Tuple of (items, last_evaluated_key)

        """
        if pk_field is None or pk_value is None:
            pk_field, pk_value = "_ptn", partition

        if sk_value is not None and sk_field is None:
            msg = "sk_field is required when sk_value is provided"
            raise DynamoDBError(
                msg)
        if sk_value is not None and sk_condition is None:
            msg = "sk_condition is required when sk_value is provided"
            raise DynamoDBError(
                msg)
        if sk_second_value is not None and sk_value is None:
            msg = "sk_value is required when sk_second_value is provided"
            raise DynamoDBError(
                msg)

        # Get partition configuration
        partition_obj = self.get_partition(partition)
        if not partition_obj:
            raise PartitionNotFoundError(partition)

        # Initialize filter lists
        filters = filters or []
        recursive_filters = recursive_filters or None

        # Find appropriate index
        index_name, pk_name, sk_name = find_proper_index(
            partition_object=partition_obj,
            pk_field=pk_field,
            sk_field=sk_field,
        )

        if isinstance(start_key, str):
            start_key = orjson.loads(start_key)
            if isinstance(start_key, str):
                start_key = orjson.loads(start_key)

        items = []
        end_key = start_key
        scan_count = 0

        while scan_count < max_scan_rep:
            batch_items, end_key = self._query_items_batch(
                pk_field=pk_field,
                pk_value=pk_value,
                sort_condition=sk_condition,
                partition=partition,
                sk_field=sk_field,
                sk_value=sk_value,
                sk_second_value=sk_second_value,
                start_key=end_key,
                filters=filters,
                limit=limit,
                reverse=reverse,
                consistent_read=consistent_read,
                index_name=index_name,
                pk_name=pk_name,
                sk_name=sk_name,
                recursive_filters=recursive_filters,
                projection_fields=projection_fields,
            )

            scan_count += 1
            items.extend(batch_items)

            if len(items) >= limit:
                items = items[:limit]
                break
            if not end_key:
                break

        filtered_items = []
        for item in items:
            item_id = item.get("_id")
            if item_id and item.get("_ptn"):
                filtered_items.append(encode_dict(obj=pop_system_keys(item)))

        if end_key:
            end_key = orjson.dumps(end_key).decode('utf-8')

        return filtered_items, end_key

    def iter_query(
        self,
        partition: str,
        pk_field: Optional[str] = None,
        sk_field: Optional[str] = None,
        pk_value: Optional[object] = None,
        sk_condition: Optional[FilterCondition] = None,
        sk_value: Optional[object] = None,
        sk_second_value: Optional[object] = None,
        filters: Optional[list[FilterDict]] = None,
        recursive_filters: Optional[RecursiveFilterNode] = None,
        reverse: bool = False,
        consistent_read: bool = False,
        projection_fields: Optional[list[str]] = None,
        page_limit: int = 100,
        max_scan_rep: int = 100,
    ) -> Generator[DynamoItem, None, None]:
        start_key: Optional[str | DynamoKey] = None

        while True:
            items, next_key = self.query_items(
                partition=partition,
                pk_field=pk_field,
                sk_field=sk_field,
                pk_value=pk_value,
                sk_condition=sk_condition,
                sk_value=sk_value,
                sk_second_value=sk_second_value,
                start_key=start_key,
                limit=page_limit,
                max_scan_rep=max_scan_rep,
                filters=filters,
                recursive_filters=recursive_filters,
                reverse=reverse,
                consistent_read=consistent_read,
                projection_fields=projection_fields,
            )
            for it in items:
                yield it
            if not next_key:
                break
            start_key = next_key

    def iter_scan(
        self,
        filters: Optional[list[FilterDict]] = None,
        recursive_filters: Optional[RecursiveFilterNode] = None,
        projection_fields: Optional[list[str]] = None,
        page_limit: Optional[int] = None,
    ) -> Generator[DynamoItem, None, None]:
        """Iterate over full table scan with automatic pagination.

        Yields processed items (system 키 제거 및 타입 인코딩 포함).
        """
        start_key: Optional[DynamoKey] = None
        while True:
            response = self.dynamo_db.scan_table(
                filters=filters,
                recursive_filters=recursive_filters or None,
                start_key=start_key,
                limit=page_limit,
                projection_fields=projection_fields,
            )
            items = response.get("Items", [])
            for item in items:
                if item:
                    item["_id"] = merge_pk_sk(item.get("_pk", ""), item.get("_sk", ""))
            for item in items:
                item_id = item.get("_id")
                if item_id and item.get("_ptn"):
                    yield encode_dict(pop_system_keys(item))
            start_key = response.get("LastEvaluatedKey")
            if not start_key:
                break


## AsyncDynamoDBAPI intentionally removed: prefer sync iterator + app-level concurrency

    def _query_items_batch(
        self,
        pk_field: str,
        pk_value: object,
        sort_condition: str | None = None,
        partition: str = "",
        sk_field: str = "",
        sk_value: object | None = None,
        sk_second_value: object | None = None,
        filters: list[FilterDict] | None = None,
        start_key: DynamoKey | None = None,
        limit: int = 100,
        reverse: bool = False,
        consistent_read: bool = False,
        index_name: str | None = None,
        pk_name: str = "_pk",
        sk_name: str = "_sk",
        recursive_filters: RecursiveFilterNode | None = None,
        projection_fields: list[str] | None = None,
    ) -> tuple[list[DynamoItem], DynamoKey | None]:
        """Execute a low-level optimized NoSQL query operation.

        Partition key fields are required for queries, while sort key fields help with
        sequential item querying. Sort key values can only be used when partition is provided,
        as sk_field is determined through the partition.

        Args:
            pk_field: Partition key field name
            pk_value: Partition key value
            sort_condition: Sort key condition
            partition: Partition name
            sk_field: Sort key field name
            sk_value: Sort key value
            sk_second_value: Second sort key value for between operations
            filters: List of filter conditions. Example:
                [
                    {
                        'field': '<FIELD>',
                        'value': '<VALUE>',
                        'second_value': '<SECOND_VALUE>' | None,  # For between operations
                        'condition': 'eq|neq|lte|lt|gte|gt|btw|stw|is_in|contains|exist|not_exist'
                    }
                ]
            start_key: Start key for pagination
            limit: Maximum number of items to return
            reverse: Sort in descending order if True
            consistent_read: Use strongly consistent reads if True
            index_name: Index name for querying (uses default parameters if None)
            pk_name: Partition key name in table/index
            sk_name: Sort key name in table/index
            recursive_filters: Nested filter conditions. Example:
                {
                    'left': {
                        'field': '<FIELD>',
                        'value': '<VALUE>',
                        'second_value': '<SECOND_VALUE>' | None,
                        'condition': 'eq|neq|lte|lt|gte|gt|btw|stw|is_in|contains|exist|not_exist'
                    },
                    'operation': 'and|or',
                    'right': {
                        'left': {...},
                        'operation': 'and|or',
                        'right': {...}
                    }
                }

        Returns:
            Tuple of (items, last_evaluated_key)

        """
        sk_digit_fit = SORT_KEY_LENGTH

        if sk_value is not None:
            if isinstance(sk_value, int | float | Decimal):
                sk_value = convert_int_to_custom_base64(
                    number=unsigned_number(sk_value))
                sk_value = "D" + sk_value.rjust(sk_digit_fit)
                if sort_condition == "eq":
                    sort_condition = "stw"
            else:
                sk_value = str(sk_value)
                if sort_condition == "eq":
                    sk_value = sk_value + DELIMITER
                    sort_condition = "stw"
                sk_value = "S" + sk_value
        else:
            sk_value = ""

        if sk_second_value is not None:
            if isinstance(sk_second_value, int | float | Decimal):
                sk_second_value = convert_int_to_custom_base64(
                    number=unsigned_number(sk_second_value))
                sk_second_value = "D" + sk_second_value.rjust(sk_digit_fit)
            else:
                sk_second_value = str(sk_second_value)
                sk_second_value = "S" + sk_second_value
        else:
            sk_second_value = ""

        if pk_field == "_ptn":
            pk = f"{partition}"
        else:
            pk = f"{partition}#{pk_field}#{pk_value}"

        if not sk_field:
            sk_field = " "

        sk_parts = [sk_field]
        sk_high = ""

        if sk_second_value:
            sk_high = f"{sk_field}#{sk_second_value}"
        if sk_value:
            sk_parts.append(sk_value)
            if sort_condition == "gt":
                sk_parts.append("A")
            elif sort_condition == "lte":
                sk_parts.append("A")
        sk = "#".join(sk_parts)

        response = self.dynamo_db.query_items(
            partition_key_name=pk_name, partition_key_value=pk,
            sort_condition=sort_condition, sort_key_name=sk_name, sort_key_value=sk,
            sort_key_second_value=sk_high,
            filters=filters,
            start_key=start_key,
            reverse=reverse,
            limit=limit,
            consistent_read=consistent_read,
            index_name=index_name,
            recursive_filters=recursive_filters,
            projection_fields=projection_fields,
        )

        end_key = response.get("LastEvaluatedKey", None)
        items = response.get("Items", [])

        for item in items:
            if item:
                item["_id"] = merge_pk_sk(
                    partition_key=item["_pk"],
                    sort_key=item["_sk"],
                )

        return items, end_key

    def get_partitions(self, use_cache=False) -> list[PartitionMetaItem]:
        """Get list of all partitions in the DynamoDB table.

        Args:
            use_cache: If True, returns cached partition list if available.
                      Cache is valid within the current hour bucket.

        Returns:
            List of partition configuration dictionaries containing metadata
            like partition name, key fields, and indexes.

        """
        cache_key = f"partitions{int(time.time() // 3600)}"
        if use_cache and cache_key in self.cache:
            return deepcopy(self.cache[cache_key])

        items = []
        start_key = None
        while True:
            response = self.dynamo_db.query_items(
                partition_key_name="_pk", partition_key_value=PARTITION_KEY_META_INFO,
                sort_condition="gte", sort_key_name="_sk", sort_key_value=" ",
                limit=1000, consistent_read=True, start_key=start_key,
            )

            _items = response.get("Items", [])
            start_key = response.get("LastEvaluatedKey", None)
            items.extend(_items)

            if not start_key:
                break

        for item in items:
            item.pop("_pk")
            item.pop("_sk")

        items = [encode_dict(item) for item in items]
        cached_items = deepcopy(items)
        self.cache[cache_key] = cached_items
        return deepcopy(items)

    def get_partition(self, partition: str, use_cache: bool = True) -> PartitionMetaItem | None:
        """Get configuration for a specific partition.

        Args:
            partition: Name of the partition to retrieve
            use_cache: If True, uses cached partition list if available

        Returns:
            Partition configuration dictionary if found, None otherwise

        """
        cache_key = f"partition_{partition}"
        if use_cache and cache_key in self._partition_cache:
            cached = self._partition_cache[cache_key]
            return deepcopy(cached) if cached is not None else None

        pts = self.get_partitions(use_cache=use_cache)
        result = next(
            (pt for pt in pts if pt.get("_partition_name") == partition),
            None
        )
        if use_cache:
            self._partition_cache[cache_key] = deepcopy(result) if result is not None else None
        return deepcopy(result) if result is not None else None

    def process_item_with_partition(self, item: DynamoItem, partition: str, for_creation=True) -> DynamoItem:
        """Process item according to partition configuration before inserting into DB.

        Args:
            item: Item to process
            partition: Partition name
            for_creation: If False, prevents key duplication during updates

        Returns:
            Processed item with partition keys and indexes

        """
        partition_obj = self.get_partition(partition, use_cache=True)
        if not partition_obj:
            msg = f"No such partition: {partition}"
            raise DynamoDBError(msg)

        pk_field = partition_obj["_pk_field"]
        sk_field = partition_obj["_sk_field"]
        uk_fields = partition_obj.get("_uk_fields", [])

        indexes = partition_obj.get("indexes", [])
        if for_creation:
            item["_crt"] = int(time.time())
        item["_ptn"] = partition
        item = decode_dict(item)

        pk_value = ""
        if for_creation:
            if pk_field not in item:
                msg = (
                    f"Missing required field for partition '{partition}': '{pk_field}' "
                    "(partition key)"
                )
                raise DynamoDBError(msg)
            if sk_field and sk_field not in item:
                msg = (
                    f"Missing required field for partition '{partition}': '{sk_field}' "
                    "(sort key)"
                )
                raise DynamoDBError(msg)
            pk_value = item[pk_field]

        sk_value = item[sk_field] if sk_field and sk_field in item else ""
        sk_value = format_value(sk_value)

        if sk_field is None:
            sk_field = ""

        if pk_field == "_ptn":
            pk = f"{partition}"
        else:
            pk = f"{partition}#{pk_field}#{pk_value}"
        sk = f"{sk_field}#{sk_value}"

        if uk_fields:
            sk_parts = [sk]
            for uk_field in uk_fields:
                uk_value = item.get(uk_field, "")
                uk_value = format_value(uk_value)
                sk_parts.append(f"{uk_field}#{uk_value}")
            sk = "#".join(sk_parts)

        item["_pk"] = pk
        item["_sk"] = sk

        for index in indexes:
            pk_name = index["pk_name"]
            sk_name = index["sk_name"]
            pk_field = index["_pk_field"]
            sk_field = index["_sk_field"]
            has_pk = pk_field in item
            has_sk = sk_field in item

            pk_value = item.get(pk_field, None)
            sk_value = item.get(sk_field, "") if sk_field else ""
            sk_value = format_value(sk_value)

            if sk_field is None:
                sk_field = ""

            if pk_field == "_ptn":
                _pk_v = f"{partition}"
            else:
                _pk_v = f"{partition}#{pk_field}#{pk_value}"
            _sk_v = f"{sk_field}#{sk_value}"

            if for_creation:
                item[pk_name] = _pk_v
                item[sk_name] = _sk_v
            else:
                if has_pk:
                    item[pk_name] = _pk_v
                if has_sk:
                    item[sk_name] = _sk_v

        item["_id"] = merge_pk_sk(partition_key=pk, sort_key=sk)
        return item

    @validate_partition_keys
    def generate_items(
        self,
        partition: str,
        pk_field: str | None = None,
        sk_field: str | None = None,
        pk_value: str | None = None,
        sk_condition: FilterCondition | None = None,
        sk_value: str | None = None,
        sk_second_value: str | None = None,
        filters: list[FilterDict] | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        reverse: bool = False,
        consistent_read: bool = False,
        limit: int = 500,
        max_scan_rep: int = 100,
    ) -> Generator[DynamoItem, None, None]:
        """Generate all items from the query API in a convenient generator format.

        Args:
            partition: Partition to query
            pk_field: Partition key field name
            sk_field: Sort key field name
            pk_value: Partition key value to match
            sk_condition: Sort key condition operator
            sk_value: Sort key value to compare
            sk_second_value: Second sort key value for between conditions
            filters: List of filter conditions to apply
            recursive_filters: Recursive filter conditions
            reverse: Whether to return items in reverse order
            consistent_read: Whether to use strongly consistent reads
            limit: Maximum number of items per page
            max_scan_rep: Maximum number of scan repetitions

        Returns:
            Generator yielding items from the query results

        """
        start_key = None

        while True:
            items, end_key = self.query_items(
                partition=partition,
                pk_field=pk_field,
                sk_field=sk_field,
                pk_value=pk_value,
                sk_condition=sk_condition,
                sk_value=sk_value,
                sk_second_value=sk_second_value,
                filters=filters,
                recursive_filters=recursive_filters,
                max_scan_rep=max_scan_rep,
                start_key=start_key,
                limit=limit,
                reverse=reverse,
                consistent_read=consistent_read,
            )

            start_key = end_key
            yield from items

            if not end_key:
                break

    def copy_partition(
        self,
        source_partition: str,
        target_partition: str,
        transform_func: Callable[[DynamoItem],
                                 DynamoItem] | None = None,
        batch_size: int = 1000,
        max_workers: int = 10,
    ) -> None:
        """Copy items from one partition to another."""
        if batch_size < 1:
            raise DynamoDBError("batch_size must be greater than 0")
        if max_workers < 1:
            raise DynamoDBError("max_workers must be greater than 0")

        def _iter_batches(
            iterable: Iterator[DynamoItem],
            size: int,
        ) -> Iterator[list[DynamoItem]]:
            batch: list[DynamoItem] = []
            for item in iterable:
                batch.append(item)
                if len(batch) >= size:
                    yield batch
                    batch = []
            if batch:
                yield batch

        try:
            # Validate partitions exist
            if not self.get_partition(source_partition):
                raise PartitionNotFoundError(source_partition)
            if not self.get_partition(target_partition):
                raise PartitionNotFoundError(target_partition)

            items_iter = self.generate_items(partition=source_partition)

            if transform_func:
                items_iter = (transform_func(item) for item in items_iter)

            failed_items: list[DynamoItem] = []
            succeeded_items: list[DynamoItem] = []
            future_to_batch: dict[Future[list[DynamoItem]], list[DynamoItem]] = {}
            succeeded_count = 0
            failed_count = 0

            def _extend_capped(target: list[DynamoItem], source: list[DynamoItem]) -> None:
                if len(target) >= MAX_BATCH_ERROR_ITEMS:
                    return
                remain = MAX_BATCH_ERROR_ITEMS - len(target)
                target.extend(source[:remain])

            def _collect_done(wait_for_one: bool) -> None:
                nonlocal succeeded_count, failed_count
                if not future_to_batch:
                    return

                if wait_for_one:
                    done_futures = [next(as_completed(future_to_batch))]
                else:
                    done_futures = list(as_completed(future_to_batch))

                for future in done_futures:
                    batch = future_to_batch.pop(future)
                    try:
                        future.result()
                        succeeded_count += len(batch)
                        _extend_capped(succeeded_items, batch)
                        logger.info(
                            f"Copied {len(batch)} items from {source_partition} to {target_partition} "
                            f"(total: {succeeded_count})",
                        )
                    except Exception as ex:
                        logger.exception(
                            "Failed to copy batch: source=%s target=%s batch_size=%s error=%s",
                            source_partition,
                            target_partition,
                            len(batch),
                            ex,
                        )
                        failed_count += len(batch)
                        _extend_capped(failed_items, batch)

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                for batch in _iter_batches(items_iter, batch_size):
                    future = executor.submit(self.put_items, target_partition, batch)
                    future_to_batch[future] = batch

                    if len(future_to_batch) >= max_workers:
                        _collect_done(wait_for_one=True)

                _collect_done(wait_for_one=False)

            if failed_count:
                msg = (
                    f"Failed to copy {failed_count} items "
                    f"(captured up to {MAX_BATCH_ERROR_ITEMS} failed/succeeded samples)"
                )
                raise BatchOperationError(
                    msg,
                    succeeded_items=succeeded_items,
                    failed_items=failed_items,
                )

        except BatchOperationError:
            raise
        except Exception as ex:
            msg = (
                f"Failed to copy partition from '{
                    source_partition}' to '{target_partition}': {ex!s}"
            )
            raise DynamoDBPartitionError(
                msg,
            ) from ex

    def scan_items(
        self,
        filters: list[FilterDict] | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        start_key: DynamoKey | None = None,
        limit: int = 1000,
    ) -> Generator[DynamoItem, None, None]:
        """Generate scanned items (memory efficient).

        Returned items follow the same shape as ``query_items``/``iter_scan``:
        system keys are removed and values are encoded.
        """
        while True:
            response = self.dynamo_db.scan_table(
                filters=filters,
                recursive_filters=recursive_filters,
                start_key=start_key,
                limit=limit,
            )
            items = response.get("Items", [])
            last_key = response.get("LastEvaluatedKey")

            for item in items:
                if item:
                    item["_id"] = merge_pk_sk(item.get("_pk", ""), item.get("_sk", ""))

            for item in items:
                if item.get("_id") and item.get("_ptn"):
                    yield encode_dict(pop_system_keys(item))

            if not last_key:
                break

            start_key = last_key

    def get_partition_names(self) -> list[str]:
        """Get all partition names."""
        response = self.dynamo_db.query_items(
            partition_key_name="_pk",
            partition_key_value=PARTITION_KEY_META_INFO,
        )

        return [
            item["_sk"]
            for item in response.get("Items", [])
            if item.get("_sk")
        ]

    def delete_partition(self, partition: str) -> None:
        """Delete a partition and all its items."""
        try:
            # Read and delete data first, then remove partition metadata.
            # This keeps deletion safe even when caches are cold.
            if not self.get_partition(partition, use_cache=False):
                raise PartitionNotFoundError(partition)

            items = self.generate_items(partition=partition)
            item_ids = [item["_id"] for item in items if item.get("_id")]
            if item_ids:
                self.delete_items(item_ids)

            self.dynamo_db.delete_item(
                PARTITION_KEY_META_INFO,
                partition,
            )

            # Clear cache
            cache_key = f"partition_{partition}"
            if cache_key in self.cache:
                del self.cache[cache_key]
            self._remove_partition_cache()

            logger.info(f"Deleted partition: {partition}")

        except Exception as ex:
            logger.exception(f"Failed to delete partition {partition}: {ex!s}")
            msg = f"Failed to delete partition {partition}: {ex!s}"
            raise DynamoDBPartitionError(
                msg,
            ) from ex

    def apply_partition_map(
        self,
        partition_map: dict[str, PartitionConfigDict],
    ) -> None:
        """Apply partition map configuration to DynamoDB table.

        Args:
            partition_map: Configuration dictionary in format:
                {
                    "<partition_name>": {
                        "pk": "_ptn",  # Primary partition key
                        "sk": "_crt",  # Primary sort key
                        "uks": None,   # Unique keys
                        "indexes": [    # GSI configurations
                            {
                                "pk": "_ptn",
                                "sk": "_crt"
                            },
                            {
                                "pk": "_ptn",
                                "sk": "phone"
                            }
                        ]
                    }
                }

        Raises:
            ValueError: If partition map configuration is invalid

        """
        self._validate_partition_map(partition_map)

        # Get existing partitions
        existing_partitions = self.get_partitions(use_cache=False)
        existing_partition_names = {
            partition["_partition_name"] for partition in existing_partitions
        }

        # Apply partition configurations
        for partition_name, config in partition_map.items():
            self._apply_partition_config(
                partition_name=partition_name,
                config=config,
                exists=partition_name in existing_partition_names,
            )

    def _validate_partition_map(
        self,
        partition_map: dict[str, PartitionConfigDict],
    ) -> None:
        """Validate partition map structure and content.

        Args:
            partition_map: Partition configuration dictionary

        Raises:
            ValueError: If validation fails

        """
        for partition_name, config in partition_map.items():
            # Validate partition name
            if not isinstance(partition_name, str):
                msg = (
                    f"Partition name '{
                        partition_name}' must be a string"
                )
                raise DynamoDBPartitionError(msg)

            # Validate partition config
            if not isinstance(config, dict):
                msg = (
                    f"Config for partition '{
                        partition_name}' must be a dictionary"
                )
                raise DynamoDBPartitionError(msg)

            # Validate required fields
            if "pk" not in config or "sk" not in config:
                msg = (
                    f"Both 'pk' and 'sk' are required in config for partition '{
                        partition_name}'"
                )
                raise DynamoDBPartitionError(
                    msg,
                )

            # Validate indexes if present
            if "indexes" in config:
                if not isinstance(config["indexes"], list):
                    msg = (
                        f"'indexes' for partition '{
                            partition_name}' must be a list"
                    )
                    raise DynamoDBPartitionError(
                        msg,
                    )

                for index in config["indexes"]:
                    if not isinstance(index, dict):
                        msg = (
                            f"Each index in partition '{
                                partition_name}' must be a dictionary"
                        )
                        raise DynamoDBPartitionError(
                            msg,
                        )
                    if "pk" not in index or "sk" not in index:
                        msg = (
                            f"Both 'pk' and 'sk' are required in each index for partition '{
                                partition_name}'"
                        )
                        raise DynamoDBPartitionError(
                            msg,
                        )

    def _apply_partition_config(
        self,
        partition_name: str,
        config: PartitionConfigDict,
        exists: bool,
    ) -> None:
        """Apply configuration for a single partition.

        Args:
            partition_name: Name of the partition
            config: Partition configuration
            exists: Whether partition already exists

        """
        # Update or create partition
        if exists:
            self.update_partition(
                partition=partition_name,
                pk_field=config["pk"],
                sk_field=config["sk"],
                uk_fields=config.get("uks", []),
            )

            logger.info(f"Updated partition: {partition_name}")
        else:
            self.create_partition(
                partition=partition_name,
                pk_field=config["pk"],
                sk_field=config["sk"],
                uk_fields=config.get("uks", []),
                create_default_index=True,
            )

            logger.info(f"Created partition: {partition_name}")

        # Apply index configurations
        for index in config.get("indexes", []):
            try:
                response = self.append_index(
                    partition_name=partition_name,
                    pk_field=index["pk"],
                    sk_field=index["sk"],
                )
                logger.info(f"Added index: {response}")
            except DuplicateIndexError as ex:
                logger.info(f"Index already exists: {ex!s}")
            except Exception:
                raise

    def apply_model_partitions(self, *models: type[DynamoModel]) -> None:
        """Apply partition configurations from model classes.

        Args:
            *models: Model classes that inherit from DynamoModel

        Raises:
            TypeError: If any model is not a valid DynamoModel subclass
            ValueError: If partition key, sort key or index fields don't exist in model
        """
        if not models:
            raise DynamoDBError("No models to apply partition configuration")

        invalid_models = [
            model.__name__ for model in models
            if not DynamoModel.is_dynamo_model(model)
        ]

        if invalid_models:
            msg = (
                f"All models must be DynamoModel subclasses with required attributes. The required attributes are: _partition, _pk, _sk\nInvalid models: {
                    ', '.join(invalid_models)}"
            )
            raise DynamoDBError(msg)

        partition_owners: dict[str, str] = {}
        for model in models:
            owner = partition_owners.get(model._partition)
            if owner:
                raise DynamoDBPartitionError(
                    message=(
                        f"Duplicate partition '{model._partition}' is defined by "
                        f"{owner} and {model.__name__}"
                    ),
                )
            partition_owners[model._partition] = model.__name__

        default_keys = ['_ptn', '_crt']

        for model in models:
            try:
                model_fields = {field.name for field in dataclass_fields(model)}
            except TypeError:
                model_fields = set(model.__annotations__.keys())
            seen_pk_sk_pairs: set[tuple[str, str]] = {(model._pk, model._sk)}

            # Check partition and sort keys
            if model._pk not in model_fields and model._pk not in default_keys:
                raise DynamoDBPartitionError(message=f"Partition key '{
                    model._pk}' not found in model {model.__name__}")
            if model._sk not in model_fields and model._sk not in default_keys:
                raise DynamoDBPartitionError(message=f"Sort key '{model._sk}' not found in model {
                    model.__name__}")

            # Check index fields
            for idx in model._indexes:
                pair = (idx.pk, idx.sk)
                if pair in seen_pk_sk_pairs:
                    raise DynamoDBValidationError(
                        message=(
                            f"Validation error: Duplicate pk-sk pair found in model {model.__name__}: "
                            f"pk='{idx.pk}', sk='{idx.sk}'"
                        ),
                    )
                seen_pk_sk_pairs.add(pair)

                if idx.pk not in model_fields and idx.pk != "_ptn":
                    raise DynamoDBPartitionError(message=f"Index partition key '{
                        idx.pk}' not found in model {model.__name__}")
                if idx.sk not in model_fields and idx.sk != "_crt":
                    raise DynamoDBPartitionError(message=f"Index sort key '{
                        idx.sk}' not found in model {model.__name__}")

        partition_map = {}
        for model in models:
            config = model.get_partition_config()
            seen_index_pairs: set[tuple[str, str]] = set()
            index_entries: list[dict[str, str]] = []

            def _append_index(pk: str, sk: str) -> None:
                pair = (pk, sk)
                if pair in seen_index_pairs:
                    return
                seen_index_pairs.add(pair)
                index_entries.append({"pk": pk, "sk": sk})

            # Every model partition gets default query index.
            _append_index("_ptn", "_crt")
            for idx in config.indexes:
                _append_index(idx.pk, idx.sk)

            partition_map[config.partition] = {
                "pk": config.pk_field,
                "sk": config.sk_field,
                "indexes": index_entries,
            }

        self.apply_partition_map(partition_map)

    def create_partition(
        self,
        partition: str,
        pk_field: str,
        sk_field: str | None = None,
        uk_fields: list[str] | None = None,
        create_default_index: bool = True,
    ) -> DynamoItem:
        """Create or declare a partition in DynamoDB.

        This method creates a partition configuration. If the partition already exists,
        it will be updated. Note that deleting a partition does not delete its internal data.

        Args:
            partition: Partition name (e.g., 'order')
            pk_field: Partition key field (e.g., 'user_id'). Used for parallel processing
                    and debugging. The actual DB pk field will contain '<pk_field>#<pk.value>'
            sk_field: Sort key field (e.g., 'created_at'). Useful for date-based sorting
            uk_fields: Additional fields appended to sort key. Useful for preventing duplicate data
            create_default_index: If True, creates default index with '_ptn' and '_crt'

        Returns:
            Dict containing the created partition attributes

        """
        self._remove_partition_cache()

        try:
            response = self.dynamo_db.put_item(item={
                "_pk": PARTITION_KEY_META_INFO,
                "_sk": partition,
                "_partition_name": partition,
                "_pk_field": pk_field,
                "_sk_field": sk_field,
                "_uk_fields": uk_fields,
                "_crt": int(time.time()),
            }, can_overwrite=False)
            result_item = response.get("Attributes", {})
        except DynamoDBError:
            # Keep behavior aligned with docstring: update if it already exists.
            result_item = self.update_partition(
                partition=partition,
                pk_field=pk_field,
                sk_field=sk_field,
                uk_fields=uk_fields,
            )

        if create_default_index:
            try:
                self.append_index(
                    partition_name=partition,
                    pk_field="_ptn",
                    sk_field="_crt",
                )
            except DuplicateIndexError:
                pass

        return result_item

    def update_partition(
        self,
        partition: str,
        pk_field: str,
        sk_field: str | None = None,
        uk_fields: list[str] | None = None,
    ) -> DynamoItem:
        """Update an existing partition in DynamoDB.

        Updates partition configuration. Note that modifying a partition
        does not affect its existing data.

        Args:
            partition: Partition name (e.g., 'order')
            pk_field: Partition key field (e.g., 'user_id'). Used for parallel processing
                    and debugging. The actual DB pk field will contain '<pk_field>#<pk.value>'
            sk_field: Sort key field (e.g., 'created_at'). Useful for date-based sorting
            uk_fields: Additional fields appended to sort key. Useful for preventing duplicate data

        Returns:
            Dict containing the updated partition attributes

        """
        self._remove_partition_cache()

        response = self.dynamo_db.update_item(
            pk=PARTITION_KEY_META_INFO,
            sk=partition,
            item={
                "_pk_field": pk_field,
                "_sk_field": sk_field,
                "_uk_fields": uk_fields,
                "_crt": int(time.time()),
            })
        return response.get("Attributes", {})

    def append_index(
        self,
        partition_name: str,
        pk_field: str,
        sk_field: str,
    ) -> dict[str, object]:
        """Appends a new index to a partition.

        Args:
            partition_name: Name of the partition to add index to.
            pk_field: Partition key field for the index.
            sk_field: Sort key field for the index.

        Returns:
            Dict containing the updated partition attributes.

        Raises:
            DynamoDBPartitionError: If partition not found or index already exists.
        """
        partitions = self.get_partitions()
        partitions = [p for p in partitions if p.get('_partition_name') == partition_name]

        if not partitions:
            raise DynamoDBPartitionError(
                f'No such partition: {partition_name}')

        partition = partitions[0]
        indexes = partition.get('indexes', [])

        for index in indexes:
            if index['_pk_field'] == pk_field and index['_sk_field'] == sk_field:
                raise DuplicateIndexError(
                    message=(
                        f"Index already exists in partition '{partition_name}': "
                        f"pk_field='{pk_field}', sk_field='{sk_field}'"
                    ),
                )

        MAX_GSI_LIMIT: Final[int] = 20

        # Find lowest available index number
        index_number = None
        for idx_num in range(1, MAX_GSI_LIMIT + 1):
            has_number = False
            for index in indexes:
                if index['index_number'] == idx_num:
                    has_number = True
            if not has_number:
                index_number = idx_num
                break

        if not index_number:
            raise DynamoDBPartitionError(
                message='Maximum number of allowed indexes exceeded')

        pk_name = f"_pk{index_number}"
        sk_name = f"_sk{index_number}"
        index_name = f'{pk_name}-{sk_name}'

        try:
            # Create physical index in DynamoDB if it doesn't exist
            self.dynamo_db.create_db_partition_index(
                index_name=index_name,
                pk_name=pk_name,
                sk_name=sk_name,
            )
        except Exception as ex:
            logger.warning(
                "Failed to create physical index '%s': %s",
                index_name,
                ex,
                exc_info=True,
            )

        index_item = {
            '_pk_field': pk_field,
            '_sk_field': sk_field,
            'pk_name': pk_name,
            'sk_name': sk_name,
            'index_number': index_number,
            'index_name': index_name
        }

        indexes.append(index_item)
        partition['indexes'] = indexes

        return self.dynamo_db.update_item(
            pk=PARTITION_KEY_META_INFO,
            sk=partition_name,
            item={
                'indexes': indexes
            }
        )

    def detach_index(self, partition_name: str, index_name: str) -> dict[str, object]:
        """Detach an index from a partition.

        Args:
            partition_name: Name of the partition
            index_name: Name of the index to detach

        Returns:
            Updated partition configuration

        Raises:
            DynamoDBError: If partition does not exist

        """
        # Get partition configuration
        partition = next(
            (p for p in self.get_partitions() if p.get(
                "_partition_name") == partition_name),
            None,
        )
        if not partition:
            msg = f"No such partition: {partition_name}"
            raise DynamoDBError(msg)

        existing_indexes = partition.get("indexes", [])
        target_index = next(
            (index for index in existing_indexes if index.get("index_name") == index_name),
            None,
        )

        # Remove index from configuration
        indexes = [
            index for index in existing_indexes
            if index.get("index_name") != index_name
        ]

        if target_index is not None:
            try:
                self.dynamo_db.delete_db_partition_index(index_name=index_name)
            except Exception as ex:
                msg = str(ex).lower()
                if not (
                    "not found" in msg
                    or "does not exist" in msg
                    or "non-existent" in msg
                ):
                    raise DynamoDBPartitionError(
                        f"Failed to delete physical index '{index_name}': {ex!s}",
                    ) from ex

        # Update partition configuration
        response = self.dynamo_db.update_item(
            pk=PARTITION_KEY_META_INFO,
            sk=partition_name,
            item={"indexes": indexes},
        )
        self._remove_partition_cache()
        return response

    def _remove_partition_cache(self) -> None:
        """Remove cache, needed when adding a new partition."""
        for k in list(self.cache.keys()):
            if k.startswith("partitions"):
                del self.cache[k]
        self._partition_cache.clear()
