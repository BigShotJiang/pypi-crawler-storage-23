"""Reusable test helpers for DynamoDB API.

These helpers are intended for both this repository and external projects.
"""

from __future__ import annotations

from copy import deepcopy
from typing import TypedDict

from chainsaws.aws.dynamodb._dynamodb_config import PARTITION_KEY_META_INFO
from chainsaws.aws.dynamodb._dynamodb_inmemory_internal import InMemoryDynamoDBInternal
from chainsaws.aws.dynamodb.dynamodb import DynamoDBAPI


class PartitionIndexForTest(TypedDict):
    _pk_field: str
    _sk_field: str
    pk_name: str
    sk_name: str
    index_number: int
    index_name: str


_DEFAULT_TEST_INDEXES: tuple[PartitionIndexForTest, ...] = (
    {
        "_pk_field": "_ptn",
        "_sk_field": "_crt",
        "pk_name": "_pk1",
        "sk_name": "_sk1",
        "index_number": 1,
        "index_name": "_pk1-_sk1",
    },
)


def create_inmemory_dynamodb_api(table_name: str = "test-table") -> DynamoDBAPI:
    """Create a DynamoDBAPI instance backed by in-memory internal storage."""
    return DynamoDBAPI(
        table_name=table_name,
        internal=InMemoryDynamoDBInternal(table_name=table_name),
    )


def register_test_partition(
    api: DynamoDBAPI,
    partition: str,
    pk_field: str,
    sk_field: str | None,
    *,
    uk_fields: list[str] | None = None,
    indexes: list[PartitionIndexForTest] | None = None,
) -> None:
    """Register a partition meta item for test usage."""
    partition_indexes = (
        deepcopy(indexes)
        if indexes is not None
        else [deepcopy(index) for index in _DEFAULT_TEST_INDEXES]
    )

    api.dynamo_db.put_item(
        item={
            "_pk": PARTITION_KEY_META_INFO,
            "_sk": partition,
            "_partition_name": partition,
            "_pk_field": pk_field,
            "_sk_field": sk_field,
            "_uk_fields": uk_fields or [],
            "indexes": partition_indexes,
            "_crt": 0,
        },
        can_overwrite=True,
    )
    api.cache.clear()
    api._partition_cache.clear()


__all__ = [
    "PartitionIndexForTest",
    "create_inmemory_dynamodb_api",
    "register_test_partition",
]
