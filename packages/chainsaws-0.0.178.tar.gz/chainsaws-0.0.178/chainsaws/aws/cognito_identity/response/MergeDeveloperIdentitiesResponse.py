from typing import TypedDict


class MergeDeveloperIdentitiesResponse(TypedDict):
    IdentityId: str


