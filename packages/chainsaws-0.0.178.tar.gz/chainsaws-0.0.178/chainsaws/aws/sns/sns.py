"""High-level AWS SNS client implementation."""

import json
import logging
from datetime import datetime
from typing import Generator

from chainsaws.aws.shared import session
from chainsaws.aws.shared.session import AWSCredentialsInput
from chainsaws.aws.sns._sns_internal import SNS
from chainsaws.aws.sns.sns_models import (
    BatchPublishResult,
    BatchSubscribeResult,
    JSONValue,
    SNSAPIConfig,
    SNSBatchSubscriptionRequest,
    SNSMessage,
    SNSProtocol,
    SNSSubscription,
    SNSTopic,
)

logger = logging.getLogger(__name__)

_SUPPORTED_PROTOCOLS: set[str] = {
    "http",
    "https",
    "email",
    "email-json",
    "sms",
    "sqs",
    "application",
    "lambda",
    "firehose",
}


def _serialize_json_payload(payload: dict[str, JSONValue] | None) -> str | None:
    if payload is None:
        return None
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _to_message_model(message: str | SNSMessage) -> SNSMessage:
    return message if isinstance(message, SNSMessage) else SNSMessage(message=message)


def _validate_protocol(protocol: SNSProtocol | str) -> None:
    if protocol not in _SUPPORTED_PROTOCOLS:
        msg = f"Unsupported SNS protocol: {protocol}"
        raise ValueError(msg)


def _validate_sms_message_constraints(message: SNSMessage) -> None:
    """Validate fields that SNS SMS publishing does not support."""
    if message.subject is not None:
        msg = "SMS publish does not support subject"
        raise ValueError(msg)
    if message.message_structure is not None:
        msg = "SMS publish does not support message_structure"
        raise ValueError(msg)
    if message.message_group_id is not None:
        msg = "SMS publish does not support message_group_id"
        raise ValueError(msg)
    if message.message_deduplication_id is not None:
        msg = "SMS publish does not support message_deduplication_id"
        raise ValueError(msg)


def _build_subscription_attributes(
    raw_message_delivery: bool = False,
    filter_policy: dict[str, JSONValue] | None = None,
) -> dict[str, str]:
    attributes: dict[str, str] = {}
    if raw_message_delivery:
        attributes["RawMessageDelivery"] = "true"
    filter_policy_payload = _serialize_json_payload(filter_policy)
    if filter_policy_payload is not None:
        attributes["FilterPolicy"] = filter_policy_payload
    return attributes


class SNSAPI:
    """High-level SNS API for topic, publish and subscription operations."""

    def __init__(
        self,
        config: SNSAPIConfig | None = None,
        *,
        credentials: AWSCredentialsInput | None = None,
        region: str | None = None,
    ) -> None:
        """Initialize SNS API.

        Args:
            config: Optional SNS config object.
            credentials: Optional credentials shortcut (overrides config.credentials).
            region: Optional region shortcut (overrides config.region).
        """
        self.config = config or SNSAPIConfig()
        if credentials is not None:
            self.config.credentials = credentials
        if region is not None:
            self.config.region = region
        self.boto3_session = session.get_boto_session(
            credentials=self.config.credentials if self.config.credentials else None,
        )
        self.sns = SNS(
            boto3_session=self.boto3_session,
            region_name=self.config.region,
        )

    def create_topic(
        self,
        name: str,
        display_name: str | None = None,
        policy: dict[str, JSONValue] | None = None,
        delivery_policy: dict[str, JSONValue] | None = None,
        tags: dict[str, str] | None = None,
    ) -> SNSTopic:
        """Create a new SNS topic."""
        attributes: dict[str, str] = {}
        if display_name:
            attributes["DisplayName"] = display_name
        policy_payload = _serialize_json_payload(policy)
        if policy_payload:
            attributes["Policy"] = policy_payload
        delivery_policy_payload = _serialize_json_payload(delivery_policy)
        if delivery_policy_payload:
            attributes["DeliveryPolicy"] = delivery_policy_payload

        topic_attrs = self.sns.create_topic(
            name=name,
            attributes=attributes,
            tags=tags,
        )

        return SNSTopic(
            topic_arn=topic_attrs["TopicArn"],
            topic_name=name,
            display_name=display_name,
            policy=policy,
            delivery_policy=delivery_policy,
            tags=tags,
            created_at=datetime.now(),
        )

    def delete_topic(self, topic_arn: str) -> None:
        self.sns.delete_topic(topic_arn)

    def publish(
        self,
        topic_arn: str,
        message: str | SNSMessage,
    ) -> str:
        """Publish a message to an SNS topic."""
        message_model = _to_message_model(message)
        return self.sns.publish(
            topic_arn=topic_arn,
            message=message_model.message,
            subject=message_model.subject,
            message_attributes={
                key: value.to_dict()
                for key, value in (message_model.message_attributes or {}).items()
            } if message_model.message_attributes else None,
            message_structure=message_model.message_structure,
            message_group_id=message_model.message_group_id,
            message_deduplication_id=message_model.message_deduplication_id,
        )

    def publish_to_target(
        self,
        target_arn: str,
        message: str | SNSMessage,
    ) -> str:
        """Publish a direct message to an endpoint Target ARN."""
        message_model = _to_message_model(message)
        return self.sns.publish(
            topic_arn=None,
            target_arn=target_arn,
            message=message_model.message,
            subject=message_model.subject,
            message_attributes={
                key: value.to_dict()
                for key, value in (message_model.message_attributes or {}).items()
            } if message_model.message_attributes else None,
            message_structure=message_model.message_structure,
        )

    def publish_to_phone(
        self,
        phone_number: str,
        message: str | SNSMessage,
    ) -> str:
        """Publish a direct SMS message to a phone number."""
        message_model = _to_message_model(message)
        _validate_sms_message_constraints(message_model)
        return self.sns.publish(
            topic_arn=None,
            phone_number=phone_number,
            message=message_model.message,
            subject=message_model.subject,
            message_attributes={
                key: value.to_dict()
                for key, value in (message_model.message_attributes or {}).items()
            } if message_model.message_attributes else None,
            message_structure=message_model.message_structure,
        )

    def subscribe(
        self,
        topic_arn: str,
        protocol: SNSProtocol | str,
        endpoint: str,
        raw_message_delivery: bool = False,
        filter_policy: dict[str, JSONValue] | None = None,
    ) -> SNSSubscription:
        """Subscribe an endpoint to an SNS topic."""
        _validate_protocol(protocol)
        attributes = _build_subscription_attributes(
            raw_message_delivery=raw_message_delivery,
            filter_policy=filter_policy,
        )
        subscription_arn = self.sns.subscribe(
            topic_arn=topic_arn,
            protocol=protocol,
            endpoint=endpoint,
            attributes=attributes or None,
        )

        return SNSSubscription(
            subscription_arn=subscription_arn,
            topic_arn=topic_arn,
            protocol=protocol,
            endpoint=endpoint,
            raw_message_delivery=raw_message_delivery,
            filter_policy=filter_policy,
            created_at=datetime.now(),
        )

    def confirm_subscription(
        self,
        topic_arn: str,
        token: str,
        authenticate_on_unsubscribe: bool | None = None,
    ) -> str:
        """Confirm a pending subscription."""
        return self.sns.confirm_subscription(
            topic_arn=topic_arn,
            token=token,
            authenticate_on_unsubscribe=authenticate_on_unsubscribe,
        )

    def unsubscribe(self, subscription_arn: str) -> None:
        self.sns.unsubscribe(subscription_arn)

    def get_topic_attributes(self, topic_arn: str) -> dict[str, str]:
        """Get topic attribute map."""
        return self.sns.get_topic_attributes(topic_arn)

    def set_topic_attributes(
        self,
        topic_arn: str,
        attribute_name: str,
        attribute_value: str,
    ) -> None:
        """Set one topic attribute."""
        self.sns.set_topic_attributes(
            topic_arn=topic_arn,
            attribute_name=attribute_name,
            attribute_value=attribute_value,
        )

    def get_subscription_attributes(self, subscription_arn: str) -> dict[str, str]:
        """Get subscription attribute map."""
        return self.sns.get_subscription_attributes(subscription_arn)

    def set_subscription_attributes(
        self,
        subscription_arn: str,
        attribute_name: str,
        attribute_value: str,
    ) -> None:
        """Set one subscription attribute."""
        self.sns.set_subscription_attributes(
            subscription_arn=subscription_arn,
            attribute_name=attribute_name,
            attribute_value=attribute_value,
        )

    def list_topics(self) -> Generator[SNSTopic, None, None]:
        """List all SNS topics."""
        next_token: str | None = None
        while True:
            topics, next_token = self.sns.list_topics(next_token=next_token)
            for topic in topics:
                topic_arn = topic["TopicArn"]
                topic_name = topic_arn.split(":")[-1]
                yield SNSTopic(
                    topic_arn=topic_arn,
                    topic_name=topic_name,
                )
            if not next_token:
                break

    def list_subscriptions(
        self,
        topic_arn: str,
    ) -> Generator[SNSSubscription, None, None]:
        """List subscriptions for a topic."""
        next_token: str | None = None
        while True:
            subscriptions, next_token = self.sns.list_subscriptions_by_topic(
                topic_arn=topic_arn,
                next_token=next_token,
            )
            for sub in subscriptions:
                yield SNSSubscription(
                    subscription_arn=sub["SubscriptionArn"],
                    topic_arn=sub["TopicArn"],
                    protocol=sub["Protocol"],
                    endpoint=sub["Endpoint"],
                )
            if not next_token:
                break

    def list_all_subscriptions(self) -> Generator[SNSSubscription, None, None]:
        """List subscriptions across the account/region."""
        next_token: str | None = None
        while True:
            subscriptions, next_token = self.sns.list_subscriptions(next_token=next_token)
            for sub in subscriptions:
                yield SNSSubscription(
                    subscription_arn=sub["SubscriptionArn"],
                    topic_arn=sub["TopicArn"],
                    protocol=sub["Protocol"],
                    endpoint=sub["Endpoint"],
                )
            if not next_token:
                break

    def batch_publish(
        self,
        topic_arn: str,
        messages: list[str | SNSMessage],
    ) -> BatchPublishResult:
        """Publish multiple messages to an SNS topic using PublishBatch."""
        message_models = [_to_message_model(message) for message in messages]
        message_dicts = [message.to_dict() for message in message_models]
        results = self.sns.batch_publish(
            topic_arn=topic_arn,
            messages=message_dicts,
        )
        return BatchPublishResult(results)

    def batch_subscribe(
        self,
        topic_arn: str,
        subscriptions: list[SNSBatchSubscriptionRequest],
    ) -> BatchSubscribeResult:
        """Subscribe multiple endpoints to an SNS topic in parallel."""
        sub_configs: list[dict[str, str | None]] = []
        for index, sub in enumerate(subscriptions):
            if "protocol" not in sub:
                msg = f"subscriptions[{index}] missing required field: protocol"
                raise ValueError(msg)
            if "endpoint" not in sub:
                msg = f"subscriptions[{index}] missing required field: endpoint"
                raise ValueError(msg)

            protocol = sub["protocol"]
            endpoint = sub["endpoint"]
            _validate_protocol(protocol)
            attributes = _build_subscription_attributes(
                raw_message_delivery=sub.get("raw_message_delivery", False),
                filter_policy=sub.get("filter_policy"),
            )
            sub_configs.append(
                {
                    "protocol": protocol,
                    "endpoint": endpoint,
                    "attributes": attributes if attributes else None,
                },
            )

        results = self.sns.batch_subscribe(
            topic_arn=topic_arn,
            subscriptions=sub_configs,
        )
        return BatchSubscribeResult(results)

    def batch_unsubscribe(
        self,
        subscription_arns: list[str],
    ) -> BatchSubscribeResult:
        """Unsubscribe multiple subscriptions in parallel."""
        results = self.sns.batch_unsubscribe(subscription_arns=subscription_arns)
        return BatchSubscribeResult(results)


# Backward-compatible alias used by README and historical imports.
SNSClient = SNSAPI
