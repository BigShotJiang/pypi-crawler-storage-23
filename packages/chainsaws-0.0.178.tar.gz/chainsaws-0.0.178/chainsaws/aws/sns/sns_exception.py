class SNSException(Exception):
    """Exception for SNS operations."""
