from __future__ import annotations

import base64
import json
import logging
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import cast

from chainsaws.aws.lambda_client import LambdaAPI, LambdaAPIConfig
from chainsaws.aws.secrets_manager._secrets_manager_internal import SecretsManager
from chainsaws.aws.secrets_manager.secrets_manager_exception import (
    SecretsManagerException,
    SecretsManagerValidationException,
)
from chainsaws.aws.secrets_manager.secrets_manager_models import (
    BatchSecretOperation,
    BatchSecretOperationResult,
    BackupSecretRecord,
    CreateSecretResponse,
    DeleteSecretResponse,
    DescribeSecretResponse,
    PutSecretValueResponse,
    RestoreSecretsResult,
    RotateSecretResponse,
    RotationConfig,
    RotationRules,
    SecretBackupConfig,
    SecretBackupPayload,
    SecretConfig,
    SecretFilterConfig,
    SecretListEntry,
    SecretValue,
    SecretValueInput,
    SecretsManagerAPIConfig,
    TagResourceResponse,
    UntagResourceResponse,
)
from chainsaws.aws.shared import session

logger = logging.getLogger(__name__)


def _decode_secret_value(secret_string: str) -> SecretValue:
    try:
        parsed = json.loads(secret_string)
    except json.JSONDecodeError:
        return secret_string
    return cast(SecretValue, parsed)


def _extract_secret_value(response: dict[str, object]) -> SecretValue | None:
    secret_binary = response.get("SecretBinary")
    if isinstance(secret_binary, bytes):
        return secret_binary

    secret_string = response.get("SecretString")
    if isinstance(secret_string, str):
        return _decode_secret_value(secret_string)

    return None


def _encode_backup_value(value: SecretValue | None) -> SecretValue | dict[str, str] | None:
    if isinstance(value, bytes):
        return {
            "__type__": "bytes_base64",
            "value": base64.b64encode(value).decode("ascii"),
        }
    return value


def _decode_backup_value(value: object) -> SecretValueInput:
    if isinstance(value, dict):
        maybe_type = value.get("__type__")
        maybe_value = value.get("value")
        if maybe_type == "bytes_base64" and isinstance(maybe_value, str):
            return base64.b64decode(maybe_value)
        return cast(dict[str, object], value)
    if isinstance(value, str | bytes):
        return value
    msg = "backup secret value must be str, bytes, or object"
    raise SecretsManagerValidationException(msg)


class SecretsManagerAPI:
    """High-level AWS Secrets Manager operations."""

    def __init__(self, config: SecretsManagerAPIConfig | None = None) -> None:
        self.config = config or SecretsManagerAPIConfig()
        self.boto3_session = session.get_boto_session(
            credentials=self.config.credentials if self.config.credentials else None,
        )
        self.secrets = SecretsManager(
            boto3_session=self.boto3_session,
            config=self.config,
        )

    def _run_parallel(
        self,
        *,
        items: list[object],
        worker: Callable[[object], tuple[bool, str, str | None]],
    ) -> tuple[list[str], list[dict[str, str]]]:
        successful: list[str] = []
        failed: list[dict[str, str]] = []
        with ThreadPoolExecutor(max_workers=self.config.batch_max_workers) as executor:
            future_to_item = {
                executor.submit(worker, item): item
                for item in items
            }
            for future in as_completed(future_to_item):
                fallback_secret_id = str(future_to_item[future])
                try:
                    success, secret_id, error = future.result()
                except Exception as exception:
                    failed.append(
                        {
                            "secret_id": fallback_secret_id,
                            "error": str(exception),
                        },
                    )
                    continue
                if success:
                    successful.append(secret_id)
                else:
                    failed.append(
                        {
                            "secret_id": secret_id,
                            "error": error or "unknown error",
                        },
                    )
        return successful, failed

    def create_secret(
        self,
        name: str,
        secret_value: SecretValueInput,
        description: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> CreateSecretResponse:
        if isinstance(secret_value, bytes):
            config = SecretConfig(
                name=name,
                description=description,
                secret_binary=secret_value,
                tags=tags,
            )
        elif isinstance(secret_value, str):
            config = SecretConfig(
                name=name,
                description=description,
                secret_string=secret_value,
                tags=tags,
            )
        else:
            config = SecretConfig(
                name=name,
                description=description,
                secret_string=json.dumps(
                    secret_value,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
                tags=tags,
            )
        return self.secrets.create_secret(config)

    def get_secret(
        self,
        secret_id: str,
        version_id: str | None = None,
        version_stage: str | None = None,
    ) -> SecretValue | None:
        response = self.secrets.get_secret_value(
            secret_id=secret_id,
            version_id=version_id,
            version_stage=version_stage,
        )
        return _extract_secret_value(cast(dict[str, object], response))

    def update_secret(
        self,
        secret_id: str,
        secret_value: SecretValueInput,
        version_stages: list[str] | None = None,
    ) -> PutSecretValueResponse:
        return self.secrets.put_secret_value(
            secret_id=secret_id,
            secret_value=secret_value,
            version_stages=version_stages,
        )

    def delete_secret(
        self,
        secret_id: str,
        force: bool = False,
        recovery_window_days: int | None = 30,
    ) -> DeleteSecretResponse:
        return self.secrets.delete_secret(
            secret_id=secret_id,
            force_delete=force,
            recovery_window_in_days=None if force else recovery_window_days,
        )

    def setup_rotation(
        self,
        secret_id: str,
        lambda_arn: str,
        rotation_days: int,
        rotation_rules: RotationRules | None = None,
        lambda_config: LambdaAPIConfig | None = None,
        *,
        validate_lambda: bool = True,
    ) -> RotateSecretResponse:
        if validate_lambda:
            lambda_client = LambdaAPI(config=lambda_config)
            try:
                lambda_client.get_function(function_name=lambda_arn)
            except Exception as error:
                msg = f"Invalid or non-existent Lambda function ARN: {lambda_arn}"
                raise SecretsManagerValidationException(msg) from error

        return self.secrets.rotate_secret(
            secret_id=secret_id,
            config=RotationConfig(
                rotation_lambda_arn=lambda_arn,
                rotation_rules=rotation_rules or {},
                automatically_after_days=rotation_days,
            ),
        )

    def list_all_secrets(
        self,
        max_results: int | None = None,
    ) -> Iterator[SecretListEntry]:
        if max_results is not None and max_results <= 0:
            msg = "max_results must be a positive integer"
            raise SecretsManagerValidationException(msg)

        paginator = self.secrets.client.get_paginator("list_secrets")
        params: dict[str, object] = {}
        if max_results is not None:
            params["PaginationConfig"] = {"MaxItems": max_results}

        for page in paginator.paginate(**params):
            secret_list = page.get("SecretList", [])
            if isinstance(secret_list, list):
                for secret in secret_list:
                    if isinstance(secret, dict):
                        yield cast(SecretListEntry, secret)

    def get_secret_metadata(self, secret_id: str) -> DescribeSecretResponse:
        return self.secrets.describe_secret(secret_id)

    def get_secret_value_if_changed(
        self,
        secret_id: str,
        last_updated: datetime | None = None,
    ) -> SecretValue | None:
        metadata = self.get_secret_metadata(secret_id)
        changed_at = metadata.get("LastChangedDate")

        if last_updated is None:
            return self.get_secret(secret_id)
        if isinstance(changed_at, datetime) and changed_at <= last_updated:
            return None
        return self.get_secret(secret_id)

    def batch_operation(self, batch_config: BatchSecretOperation) -> BatchSecretOperationResult:
        def worker(item: object) -> tuple[bool, str, str | None]:
            secret_id = cast(str, item)
            try:
                if batch_config.operation == "delete":
                    force = bool(batch_config.params.get("force", False))
                    recovery_window_days = cast(
                        int | None,
                        batch_config.params.get("recovery_window_days", 30),
                    )
                    self.delete_secret(
                        secret_id=secret_id,
                        force=force,
                        recovery_window_days=recovery_window_days,
                    )
                elif batch_config.operation == "rotate":
                    lambda_arn = batch_config.params.get("lambda_arn")
                    rotation_days = batch_config.params.get("rotation_days")
                    rotation_rules = batch_config.params.get("rotation_rules")
                    if not isinstance(lambda_arn, str) or not isinstance(rotation_days, int):
                        msg = "rotate batch params require lambda_arn(str) and rotation_days(int)"
                        raise SecretsManagerValidationException(msg)
                    normalized_rules: RotationRules | None = None
                    if isinstance(rotation_rules, dict):
                        normalized_rules = cast(RotationRules, rotation_rules)
                    self.setup_rotation(
                        secret_id=secret_id,
                        lambda_arn=lambda_arn,
                        rotation_days=rotation_days,
                        rotation_rules=normalized_rules,
                    )
                elif batch_config.operation == "update":
                    if "secret_value" not in batch_config.params:
                        msg = "update batch params require secret_value"
                        raise SecretsManagerValidationException(msg)
                    secret_value = _decode_backup_value(batch_config.params["secret_value"])
                    version_stages = cast(
                        list[str] | None,
                        batch_config.params.get("version_stages"),
                    )
                    self.update_secret(
                        secret_id=secret_id,
                        secret_value=secret_value,
                        version_stages=version_stages,
                    )
                return True, secret_id, None
            except Exception as error:
                return False, secret_id, str(error)

        successful, failed = self._run_parallel(
            items=cast(list[object], batch_config.secret_ids),
            worker=worker,
        )
        return {
            "successful": successful,
            "failed": failed,
        }

    def backup_secrets(self, config: SecretBackupConfig) -> None:
        backup_data: SecretBackupPayload = {
            "secrets": [],
            "metadata": {
                "timestamp": datetime.now(tz=None).isoformat(),
                "version": "2.0",
            },
        }

        def worker(item: object) -> BackupSecretRecord | None:
            secret_id = cast(str, item)
            try:
                value = self.get_secret(secret_id)
                metadata = self.get_secret_metadata(secret_id)
                encoded_value = _encode_backup_value(value)
                return {
                    "id": secret_id,
                    "value": encoded_value if encoded_value is not None else "",
                    "metadata": metadata,
                }
            except Exception:
                logger.exception("Failed to backup secret %s", secret_id)
                return None

        with ThreadPoolExecutor(max_workers=self.config.batch_max_workers) as executor:
            futures = [executor.submit(worker, secret_id) for secret_id in config.secret_ids]
            for future in as_completed(futures):
                record = future.result()
                if record is not None:
                    backup_data["secrets"].append(record)

        backup_path = Path(config.backup_path)
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        with backup_path.open("w", encoding="utf-8") as file:
            json.dump(backup_data, file, indent=2, default=str)

    def restore_secrets(
        self,
        backup_path: str,
    ) -> RestoreSecretsResult:
        path = Path(backup_path)
        try:
            with path.open(encoding="utf-8") as file:
                payload = cast(SecretBackupPayload, json.load(file))
        except Exception as error:
            msg = f"Failed to load backup file: {backup_path}"
            raise SecretsManagerException(msg) from error

        secrets = payload.get("secrets", [])

        def worker(item: object) -> tuple[bool, str, str | None]:
            if not isinstance(item, dict):
                return False, "unknown", "backup record must be an object"
            secret_id = str(item.get("id", "")).strip()
            if secret_id == "":
                return False, "unknown", "backup record id is missing"

            try:
                description = None
                metadata = item.get("metadata")
                if isinstance(metadata, dict):
                    raw_description = metadata.get("Description")
                    if isinstance(raw_description, str):
                        description = raw_description

                secret_value = _decode_backup_value(item.get("value"))
                self.create_secret(
                    name=secret_id,
                    secret_value=secret_value,
                    description=description,
                )
                return True, secret_id, None
            except Exception as error:
                return False, secret_id, str(error)

        restored, failed = self._run_parallel(
            items=cast(list[object], secrets),
            worker=worker,
        )
        return {
            "restored": restored,
            "failed": failed,
        }

    def filter_secrets(
        self,
        filter_config: SecretFilterConfig,
    ) -> Iterator[SecretListEntry]:
        for secret in self.list_all_secrets():
            name = secret.get("Name")
            if filter_config.name_prefix and (
                not isinstance(name, str) or not name.startswith(filter_config.name_prefix)
            ):
                continue

            if filter_config.tags:
                secret_tags = {
                    tag["Key"]: tag["Value"]
                    for tag in secret.get("Tags", [])
                    if isinstance(tag, dict) and "Key" in tag and "Value" in tag
                }
                if not all(secret_tags.get(key) == value for key, value in filter_config.tags.items()):
                    continue

            created_at = secret.get("CreatedDate")
            if filter_config.created_after and isinstance(created_at, datetime):
                if created_at < filter_config.created_after:
                    continue

            updated_at = secret.get("LastChangedDate", created_at)
            if filter_config.last_updated_after and isinstance(updated_at, datetime):
                if updated_at < filter_config.last_updated_after:
                    continue

            yield secret

    def generate_random_password(
        self,
        length: int = 32,
        exclude_characters: str | None = None,
        exclude_numbers: bool = False,
        exclude_punctuation: bool = False,
        exclude_uppercase: bool = False,
        exclude_lowercase: bool = False,
        include_space: bool = False,
        require_each_included_type: bool = False,
    ) -> str:
        response = self.secrets.get_random_password(
            length=length,
            exclude_characters=exclude_characters,
            exclude_numbers=exclude_numbers,
            exclude_punctuation=exclude_punctuation,
            exclude_uppercase=exclude_uppercase,
            exclude_lowercase=exclude_lowercase,
            include_space=include_space,
            require_each_included_type=require_each_included_type,
        )
        return response["RandomPassword"]

    def tag_secret(self, secret_id: str, tags: dict[str, str]) -> TagResourceResponse:
        return self.secrets.tag_secret(secret_id=secret_id, tags=tags)

    def untag_secret(self, secret_id: str, tag_keys: list[str]) -> UntagResourceResponse:
        return self.secrets.untag_secret(secret_id=secret_id, tag_keys=tag_keys)
