class SecretsManagerException(Exception):
    """Base exception for Secrets Manager operations."""

    def __init__(
        self,
        message: str,
        *,
        operation: str | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.operation = operation
        self.error_code = error_code


class SecretsManagerValidationException(SecretsManagerException):
    """Raised when Secrets Manager input validation fails."""


class SecretNotFoundException(SecretsManagerException):
    """Raised when a secret is not found."""


class SecretAlreadyExistsException(SecretsManagerException):
    """Raised when a secret already exists."""


class SecretsManagerDeletionAlreadyScheduledException(SecretsManagerException):
    """Raised when a secret is already scheduled for deletion."""


class SecretsManagerThrottlingException(SecretsManagerException):
    """Raised when AWS returns throttling errors."""


class SecretsManagerAccessDeniedException(SecretsManagerException):
    """Raised when principal is not authorized for the operation."""


class SecretsManagerInvalidRequestException(SecretsManagerException):
    """Raised when AWS rejects request parameters or state."""
