"""Stream processing manager for S3 operations."""

import orjson
import csv
import gzip
import bz2
from typing import TypeVar, Generator, Callable, Optional
from io import TextIOWrapper
from contextlib import contextmanager

from chainsaws.aws.s3.s3_types import StreamConfig
from chainsaws.aws.s3.s3_exception import S3StreamingError

T = TypeVar('T')

class StreamManager:
    """Manager class for S3 streaming operations."""

    def __init__(self, s3_api):
        """Initialize StreamManager.

        Args:
            s3_api: Reference to S3API instance
        """
        self.s3_api = s3_api

    @contextmanager
    def stream_context(
        self,
        object_key: str,
        config: StreamConfig,
    ) -> Generator[object, None, None]:
        """Context manager for stream processing.

        Args:
            object_key: Target object key
            config: Stream configuration

        Example:
            ```python
            config = StreamConfig(
                mode="TEXT",
                encoding='utf-8',
                chunk_size=8192
            )
            with stream_manager.stream_context("logs/app.log", config) as stream:
                for line in stream:
                    process_log_line(line)
            ```
        """
        stream: object | None = None
        try:
            stream = self._create_stream_processor(object_key, config)
            yield stream
        except Exception as e:
            if config.get('error_handler'):
                config['error_handler'](e)
            else:
                raise
        finally:
            if stream is not None and hasattr(stream, 'close'):
                stream.close()

    def stream_process(
        self,
        object_key: str,
        processor: Callable[[bytes], T],
        config: Optional[StreamConfig] = None
    ) -> Generator[T, None, None]:
        """Process an object as a stream and generate transformed results.

        Args:
            object_key: Target object key
            processor: Function to process each chunk
            config: Stream configuration

        Yields:
            Transformed data

        Example:
            ```python
            def process_chunk(chunk: bytes) -> dict:
                return orjson.loads(chunk)

            for item in stream_manager.stream_process("data.json", process_chunk):
                print(item)
            ```
        """
        config = config or StreamConfig(chunk_size=8192)
        chunk_size = int(config.get("chunk_size", 8192))
        
        try:
            for chunk in self.s3_api.stream_object(object_key, chunk_size):
                try:
                    result = processor(chunk)
                    if result is not None:
                        yield result
                except Exception as e:
                    if config.get('error_handler'):
                        config['error_handler'](e)
                    else:
                        raise
        except Exception as e:
            if config.get('error_handler'):
                config['error_handler'](e)
            else:
                raise

    def stream_lines(
        self,
        object_key: str,
        encoding: str = 'utf-8',
        chunk_size: int = 8192,
        keep_ends: bool = False
    ) -> Generator[str, None, None]:
        """Stream an object line by line.

        Args:
            object_key: Target object key
            encoding: Text encoding
            chunk_size: Size of each chunk
            keep_ends: Whether to keep line endings

        Yields:
            Each line of text

        Example:
            ```python
            for line in stream_manager.stream_lines("logs/app.log"):
                process_log_line(line)
            ```
        """
        buffer = ""
        
        for chunk in self.s3_api.stream_object(object_key, chunk_size):
            buffer += chunk.decode(encoding)
            while True:
                line_end = buffer.find('\n')
                if line_end == -1:
                    break
                    
                line = buffer[:line_end + 1] if keep_ends else buffer[:line_end]
                buffer = buffer[line_end + 1:]
                yield line
                
        if buffer:
            yield buffer

    def stream_json(
        self,
        object_key: str,
        chunk_size: int = 8192,
        array_mode: bool = False
    ) -> Generator[dict, None, None]:
        """Stream JSON objects.

        Args:
            object_key: Target object key
            chunk_size: Size of each chunk
            array_mode: JSON array processing mode

        Yields:
            Parsed JSON objects

        Example:
            ```python
            for record in stream_manager.stream_json("data.json"):
                process_record(record)
            ```
        """
        if array_mode:
            import json
            decoder = json.JSONDecoder()
            buffer = ""
            for chunk in self.s3_api.stream_object(object_key, chunk_size):
                buffer += chunk.decode('utf-8')
                while buffer:
                    try:
                        obj, index = decoder.raw_decode(buffer)
                        buffer = buffer[index:].lstrip()
                        yield obj
                    except json.JSONDecodeError:
                        break
        else:
            for line in self.stream_lines(object_key, chunk_size=chunk_size):
                if line.strip():
                    yield orjson.loads(line)

    def stream_csv(
        self,
        object_key: str,
        delimiter: str = ',',
        encoding: str = 'utf-8',
        header: bool = True
    ) -> Generator[dict, None, None]:
        """Stream CSV records.

        Args:
            object_key: Target object key
            delimiter: CSV delimiter
            encoding: File encoding
            header: Whether file includes header

        Yields:
            CSV records as dictionaries

        Example:
            ```python
            for record in stream_manager.stream_csv("data.csv"):
                process_record(record)
            ```
        """
        with self.stream_context(object_key, StreamConfig(
            mode="TEXT",
            encoding=encoding
        )) as stream:
            csv_reader = csv.DictReader(stream, delimiter=delimiter) if header else csv.reader(stream, delimiter=delimiter)
            yield from csv_reader

    @staticmethod
    def _stream_json_lines(text_stream: TextIOWrapper) -> Generator[dict, None, None]:
        try:
            for line in text_stream:
                normalized = line.strip()
                if normalized:
                    yield orjson.loads(normalized)
        finally:
            text_stream.close()

    @staticmethod
    def _stream_csv_rows(
        text_stream: TextIOWrapper,
        delimiter: str,
    ) -> Generator[list[str], None, None]:
        try:
            reader = csv.reader(text_stream, delimiter=delimiter)
            yield from reader
        finally:
            text_stream.close()

    def _create_stream_processor(self, object_key: str, config: StreamConfig) -> object:
        """Create a stream processor.

        Args:
            object_key: Target object key
            config: Stream configuration

        Returns:
            Stream processor object
        """
        try:
            response = self.s3_api.get_object(object_key)
            body = response.get("Body")
            if body is None or not hasattr(body, "read"):
                raise ValueError("Object body is not readable")
            compression = config.get("compression")
            stream = body
            if compression == "gzip":
                stream = gzip.GzipFile(fileobj=stream)
            elif compression == "bzip2":
                stream = bz2.BZ2File(stream)
            elif compression:
                raise ValueError(f"Unsupported compression: {compression}")

            mode = config.get("mode", "BINARY")
            encoding = config.get("encoding", "utf-8")
            if mode == "TEXT":
                return TextIOWrapper(stream, encoding=encoding)
            if mode == "BINARY":
                return stream
            if mode == "JSON":
                return self._stream_json_lines(TextIOWrapper(stream, encoding=encoding))
            if mode == "CSV":
                delimiter = config.get("delimiter", ",")
                return self._stream_csv_rows(
                    TextIOWrapper(stream, encoding=encoding),
                    delimiter=delimiter,
                )

            raise ValueError(f"Unsupported mode: {mode}")
        except Exception as e:
            raise S3StreamingError(object_key=object_key, reason=str(e)) from e
