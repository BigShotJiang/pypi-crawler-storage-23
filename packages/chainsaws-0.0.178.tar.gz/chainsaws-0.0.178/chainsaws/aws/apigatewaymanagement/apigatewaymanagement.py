import json

from chainsaws.aws.apigatewaymanagement._apigatewaymanagement_internal import APIGatewayManagement
from chainsaws.aws.apigatewaymanagement.apigatewaymanagement_exceptions import (
    APIGatewayManagementEndpointURLRequiredException,
    APIGatewayManagementGoneConnectionError,
)
from chainsaws.aws.apigatewaymanagement.apigatewaymanagement_models import (
    APIGatewayManagementAPIConfig,
    ConnectionPostResult,
    JSONValue,
)
from chainsaws.aws.apigatewaymanagement.response.GetConnectionResponse import GetConnectionResponse
from chainsaws.aws.shared import session
from chainsaws.aws.shared.session import AWSCredentialsInput


class APIGatewayManagementAPI:
    """High-level API Gateway Management API wrapper."""

    def __init__(
        self,
        config: APIGatewayManagementAPIConfig | None = None,
        *,
        endpoint_url: str | None = None,
        region: str | None = None,
        credentials: AWSCredentialsInput | None = None,
    ) -> None:
        resolved_config = self._resolve_config(
            config=config,
            endpoint_url=endpoint_url,
            region=region,
            credentials=credentials,
        )

        self.config = resolved_config
        self.boto3_session = session.get_boto_session(
            credentials=self.config.credentials if self.config.credentials else None,
        )
        self.apigateway_management = APIGatewayManagement(
            boto3_session=self.boto3_session,
            config=self.config,
        )

    @staticmethod
    def _resolve_config(
        *,
        config: APIGatewayManagementAPIConfig | None,
        endpoint_url: str | None,
        region: str | None,
        credentials: AWSCredentialsInput | None,
    ) -> APIGatewayManagementAPIConfig:
        resolved = config
        if resolved is None:
            if endpoint_url is None or endpoint_url.strip() == "":
                msg = "endpoint_url is required"
                raise APIGatewayManagementEndpointURLRequiredException(msg)
            resolved = APIGatewayManagementAPIConfig(endpoint_url=endpoint_url)

        if endpoint_url is not None and endpoint_url.strip() != "":
            resolved.endpoint_url = endpoint_url
        if region is not None:
            resolved.region = region
        if credentials is not None:
            resolved.credentials = credentials

        return resolved

    def post_to_connection(
        self,
        connection_id: str,
        data: str | bytes,
        *,
        ignore_gone: bool | None = None,
    ) -> None:
        self.apigateway_management.post_to_connection(
            connection_id=connection_id,
            data=data,
            ignore_gone=(
                self.config.default_ignore_gone
                if ignore_gone is None
                else ignore_gone
            ),
        )

    def post_json_to_connection(
        self,
        connection_id: str,
        payload: JSONValue,
        *,
        ignore_gone: bool | None = None,
        ensure_ascii: bool = False,
    ) -> None:
        data = json.dumps(payload, ensure_ascii=ensure_ascii, separators=(",", ":"))
        self.post_to_connection(
            connection_id=connection_id,
            data=data,
            ignore_gone=ignore_gone,
        )

    def broadcast(
        self,
        connection_ids: list[str],
        data: str | bytes,
        *,
        ignore_gone: bool | None = None,
    ) -> list[ConnectionPostResult]:
        return self.apigateway_management.post_to_connections(
            connection_ids=connection_ids,
            data=data,
            ignore_gone=(
                self.config.default_ignore_gone
                if ignore_gone is None
                else ignore_gone
            ),
        )

    def get_connection(self, connection_id: str) -> GetConnectionResponse:
        return self.apigateway_management.get_connection(
            connection_id=connection_id,
        )

    def is_connected(self, connection_id: str) -> bool:
        try:
            self.get_connection(connection_id)
            return True
        except APIGatewayManagementGoneConnectionError:
            return False

    def delete_connection(
        self,
        connection_id: str,
        *,
        ignore_gone: bool | None = None,
    ) -> None:
        self.apigateway_management.delete_connection(
            connection_id=connection_id,
            ignore_gone=(
                self.config.default_ignore_gone
                if ignore_gone is None
                else ignore_gone
            ),
        )
