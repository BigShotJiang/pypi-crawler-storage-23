from dataclasses import dataclass, field
from typing import Literal, NotRequired, TypeAlias, TypedDict

from chainsaws.aws.shared.config import APIConfig
from chainsaws.aws.apigatewaymanagement.apigatewaymanagement_exceptions import (
    APIGatewayManagementEndpointURLRequiredException,
    APIGatewayManagementValidationError,
)

DEFAULT_MAX_PAYLOAD_BYTES = 32 * 1024
MAX_ALLOWED_PAYLOAD_BYTES = 128 * 1024
DEFAULT_RETRY_ATTEMPTS = 3
DEFAULT_RETRY_BASE_DELAY_SECONDS = 0.2
DEFAULT_RETRY_MAX_DELAY_SECONDS = 2.0

JSONPrimitive = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]
APIGatewayManagementKnownErrorCode: TypeAlias = Literal[
    "BadRequestException",
    "ForbiddenException",
    "GoneException",
    "LimitExceededException",
    "MissingAuthenticationTokenException",
    "PayloadTooLargeException",
    "RequestLimitExceeded",
    "ServiceUnavailableException",
    "Throttling",
    "ThrottlingException",
    "TooManyRequestsException",
    "UnauthorizedException",
]


@dataclass
class APIGatewayManagementAPIConfig(APIConfig):
    """Configuration for APIGatewayManagement."""

    endpoint_url: str = field(kw_only=True)
    max_payload_bytes: int = DEFAULT_MAX_PAYLOAD_BYTES
    default_ignore_gone: bool = False
    retry_attempts: int = DEFAULT_RETRY_ATTEMPTS
    retry_base_delay_seconds: float = DEFAULT_RETRY_BASE_DELAY_SECONDS
    retry_max_delay_seconds: float = DEFAULT_RETRY_MAX_DELAY_SECONDS

    def __post_init__(self) -> None:
        self.endpoint_url = self.endpoint_url.strip()
        if self.endpoint_url == "":
            msg = "endpoint_url is required"
            raise APIGatewayManagementEndpointURLRequiredException(msg)

        if self.max_payload_bytes <= 0:
            msg = "max_payload_bytes must be a positive integer"
            raise APIGatewayManagementValidationError(msg)
        if self.max_payload_bytes > MAX_ALLOWED_PAYLOAD_BYTES:
            msg = (
                f"max_payload_bytes must be <= {MAX_ALLOWED_PAYLOAD_BYTES} "
                f"(got {self.max_payload_bytes})"
            )
            raise APIGatewayManagementValidationError(msg)

        if self.retry_attempts <= 0:
            msg = "retry_attempts must be a positive integer"
            raise APIGatewayManagementValidationError(msg)
        if self.retry_base_delay_seconds <= 0:
            msg = "retry_base_delay_seconds must be > 0"
            raise APIGatewayManagementValidationError(msg)
        if self.retry_max_delay_seconds <= 0:
            msg = "retry_max_delay_seconds must be > 0"
            raise APIGatewayManagementValidationError(msg)
        if self.retry_base_delay_seconds > self.retry_max_delay_seconds:
            msg = "retry_base_delay_seconds must be <= retry_max_delay_seconds"
            raise APIGatewayManagementValidationError(msg)


class ConnectionPostResult(TypedDict):
    """Result of posting a message to a specific connection."""

    connection_id: str
    success: bool
    error_code: NotRequired[str | None]
    error_message: NotRequired[str | None]
