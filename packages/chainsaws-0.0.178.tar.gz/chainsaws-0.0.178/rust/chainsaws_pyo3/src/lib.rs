use pyo3::prelude::*;

#[path = "../../aws/dynamodb/lib.rs"]
mod dynamodb;

#[pymodule]
fn chainsaws_pyo3(m: &Bound<'_, PyModule>) -> PyResult<()> {
    dynamodb::register_dynamodb_module(m)
}
