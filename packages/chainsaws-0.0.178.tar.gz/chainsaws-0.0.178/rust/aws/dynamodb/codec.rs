use pyo3::exceptions::PyTypeError;
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyDict, PyFloat, PyList, PySet};

type PyObject = pyo3::Py<pyo3::PyAny>;

fn decode_value(
    py: Python<'_>,
    value: &Bound<'_, PyAny>,
    decimal_type: &Bound<'_, PyAny>,
) -> PyResult<PyObject> {
    if let Ok(dict_value) = value.downcast::<PyDict>() {
        let output = PyDict::new(py);
        for (key, item) in dict_value.iter() {
            output.set_item(key, decode_value(py, &item, decimal_type)?)?;
        }
        return Ok(output.into_pyobject(py)?.unbind().into());
    }

    if let Ok(list_value) = value.downcast::<PyList>() {
        let output = PyList::empty(py);
        for item in list_value.iter() {
            output.append(decode_value(py, &item, decimal_type)?)?;
        }
        return Ok(output.into_pyobject(py)?.unbind().into());
    }

    if value.is_instance_of::<PyFloat>() {
        let value_as_str = value.str()?.to_string();
        let decimal = decimal_type.call1((value_as_str,))?;
        return Ok(decimal.into_pyobject(py)?.unbind().into());
    }

    Ok(value.clone().unbind().into())
}

#[pyfunction]
pub(crate) fn decode_dict(value: PyObject, decimal_type: PyObject) -> PyResult<PyObject> {
    Python::attach(|py| {
        let bound_value = value.bind(py);
        let bound_decimal_type = decimal_type.bind(py);
        decode_value(py, bound_value, bound_decimal_type)
    })
}

#[pyfunction]
pub(crate) fn deserialize_items(
    items: PyObject,
    decimal_context: PyObject,
    binary_type: PyObject,
    fallback_deserializer: PyObject,
) -> PyResult<()> {
    Python::attach(|py| {
        let bound_items = items.bind(py);
        let bound_decimal_context = decimal_context.bind(py);
        let bound_binary_type = binary_type.bind(py);
        let bound_fallback_deserializer = fallback_deserializer.bind(py);
        let items_list = bound_items
            .downcast::<PyList>()
            .map_err(|_| PyTypeError::new_err("items must be a list"))?;
        deserialize_items_in_place(
            py,
            items_list,
            bound_decimal_context,
            bound_binary_type,
            bound_fallback_deserializer,
        )
    })
}

fn deserialize_attribute_value(
    py: Python<'_>,
    attribute_value: &Bound<'_, PyAny>,
    decimal_context: &Bound<'_, PyAny>,
    binary_type: &Bound<'_, PyAny>,
    fallback_deserializer: &Bound<'_, PyAny>,
) -> PyResult<PyObject> {
    let attr_dict = attribute_value
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("attribute value must be a dict"))?;

    if attr_dict.len() != 1 {
        let fallback = fallback_deserializer.call_method1("deserialize", (attribute_value,))?;
        return Ok(fallback.into_pyobject(py)?.unbind().into());
    }

    let (type_key, raw_value) = attr_dict
        .iter()
        .next()
        .ok_or_else(|| PyTypeError::new_err("attribute value dict cannot be empty"))?;
    let dynamodb_type = type_key.extract::<&str>()?;

    match dynamodb_type {
        "S" => Ok(raw_value.clone().unbind().into()),
        "N" => {
            let decimal = decimal_context.call_method1("create_decimal", (raw_value,))?;
            Ok(decimal.into_pyobject(py)?.unbind().into())
        }
        "B" => {
            let binary = binary_type.call1((raw_value,))?;
            Ok(binary.into_pyobject(py)?.unbind().into())
        }
        "BOOL" => Ok(raw_value.clone().unbind().into()),
        "NULL" => Ok(py.None()),
        "L" => {
            let input_list = raw_value
                .downcast::<PyList>()
                .map_err(|_| PyTypeError::new_err("L value must be a list"))?;
            let output_list = PyList::empty(py);
            for item in input_list.iter() {
                let parsed = deserialize_attribute_value(
                    py,
                    &item,
                    decimal_context,
                    binary_type,
                    fallback_deserializer,
                )?;
                output_list.append(parsed)?;
            }
            Ok(output_list.into_pyobject(py)?.unbind().into())
        }
        "M" => {
            let input_map = raw_value
                .downcast::<PyDict>()
                .map_err(|_| PyTypeError::new_err("M value must be a dict"))?;
            let output_map = PyDict::new(py);
            for (map_key, map_value) in input_map.iter() {
                let parsed = deserialize_attribute_value(
                    py,
                    &map_value,
                    decimal_context,
                    binary_type,
                    fallback_deserializer,
                )?;
                output_map.set_item(map_key, parsed)?;
            }
            Ok(output_map.into_pyobject(py)?.unbind().into())
        }
        "SS" => {
            let output_set = PySet::empty(py)?;
            for item in raw_value.try_iter()? {
                output_set.add(item?)?;
            }
            Ok(output_set.into_pyobject(py)?.unbind().into())
        }
        "NS" => {
            let output_set = PySet::empty(py)?;
            for item in raw_value.try_iter()? {
                let decimal = decimal_context.call_method1("create_decimal", (item?,))?;
                output_set.add(decimal)?;
            }
            Ok(output_set.into_pyobject(py)?.unbind().into())
        }
        "BS" => {
            let output_set = PySet::empty(py)?;
            for item in raw_value.try_iter()? {
                let binary = binary_type.call1((item?,))?;
                output_set.add(binary)?;
            }
            Ok(output_set.into_pyobject(py)?.unbind().into())
        }
        _ => {
            let fallback = fallback_deserializer.call_method1("deserialize", (attribute_value,))?;
            Ok(fallback.into_pyobject(py)?.unbind().into())
        }
    }
}

pub(crate) fn deserialize_items_in_place(
    py: Python<'_>,
    items_list: &Bound<'_, PyList>,
    decimal_context: &Bound<'_, PyAny>,
    binary_type: &Bound<'_, PyAny>,
    fallback_deserializer: &Bound<'_, PyAny>,
) -> PyResult<()> {
    for item_any in items_list.iter() {
        let item_dict = item_any
            .downcast::<PyDict>()
            .map_err(|_| PyTypeError::new_err("each item must be a dict"))?;

        let mut updates: Vec<(PyObject, PyObject)> = Vec::with_capacity(item_dict.len());
        for (key, value) in item_dict.iter() {
            let parsed = deserialize_attribute_value(
                py,
                &value,
                decimal_context,
                binary_type,
                fallback_deserializer,
            )?;
            updates.push((key.into_pyobject(py)?.unbind().into(), parsed));
        }

        for (key, value) in updates {
            item_dict.set_item(key, value)?;
        }
    }
    Ok(())
}

pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(decode_dict, m)?)?;
    m.add_function(wrap_pyfunction!(deserialize_items, m)?)?;
    Ok(())
}
