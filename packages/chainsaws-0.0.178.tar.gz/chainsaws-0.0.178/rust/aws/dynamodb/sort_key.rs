use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyFloat, PyInt};

type PyObject = pyo3::Py<pyo3::PyAny>;

const NUMBER_RANGE_ERROR_MESSAGE: &str =
    "Number must be between -8.834235323891921e+55 and +8.834235323891921e+55";
const SORT_KEY_LENGTH_NATIVE: usize = 20;
const SORT_KEY_DECIMAL_PLACES_NATIVE: u32 = 16;
const SORT_KEY_MAX_HALF_VALUE_NATIVE: i128 = 664_613_997_892_457_936_451_903_530_140_172_288;
const SORT_KEY_MAX_VALUE_NATIVE: i128 = SORT_KEY_MAX_HALF_VALUE_NATIVE * 2;
const DYNAMODB_BASE64_CHARSET_NATIVE: &[u8; 64] =
    b"+/0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

fn convert_int_to_custom_base64_native(number: i128, charset: &[u8]) -> PyResult<String> {
    if charset.len() != 64 {
        return Err(PyValueError::new_err("base64_charset length must be 64"));
    }
    if number == 0 {
        return Ok((charset[0] as char).to_string());
    }

    let mut value = number;
    let mut chars: Vec<char> = Vec::new();
    while value > 0 {
        let remainder = (value % 64) as usize;
        chars.push(charset[remainder] as char);
        value /= 64;
    }
    chars.reverse();
    Ok(chars.iter().collect())
}

#[pyfunction]
pub(crate) fn format_value(
    value: PyObject,
    sort_key_length: usize,
    delimiter: &str,
    sort_key_decimal_places: u32,
    sort_key_max_half_value: i128,
    sort_key_max_value: i128,
    base64_charset: &str,
    unsigned_number_fn: PyObject,
    convert_int_to_custom_base64_fn: PyObject,
    decimal_type: PyObject,
) -> PyResult<String> {
    Python::attach(|py| {
        let bound_value = value.bind(py);
        let bound_decimal_type = decimal_type.bind(py);

        if bound_value.is_instance_of::<PyInt>() {
            if let Ok(integer_value) = bound_value.extract::<i128>() {
                let decimal_power = 10_i128
                    .checked_pow(sort_key_decimal_places)
                    .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;
                let scaled = integer_value
                    .checked_mul(decimal_power)
                    .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;
                let shifted = scaled
                    .checked_add(sort_key_max_half_value)
                    .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;

                if !(0 <= shifted && shifted < sort_key_max_value) {
                    return Err(PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE));
                }

                let base64_text =
                    convert_int_to_custom_base64_native(shifted, base64_charset.as_bytes())?;
                return Ok(format!("D{base64_text:>width$}", width = sort_key_length));
            }
        }

        let is_decimal = bound_value.is_instance(bound_decimal_type)?;
        if bound_value.is_instance_of::<PyInt>()
            || bound_value.is_instance_of::<PyFloat>()
            || is_decimal
        {
            let unsigned_number = unsigned_number_fn.bind(py).call1((bound_value,))?;
            let base64_value = convert_int_to_custom_base64_fn
                .bind(py)
                .call1((unsigned_number,))?;
            let base64_text = base64_value.str()?.to_string();
            return Ok(format!("D{base64_text:>width$}", width = sort_key_length));
        }

        let string_value = bound_value.str()?.to_string();
        Ok(format!("S{string_value}{delimiter}"))
    })
}

#[pyfunction]
pub(crate) fn format_value_int(value: i128) -> PyResult<String> {
    let decimal_power = 10_i128
        .checked_pow(SORT_KEY_DECIMAL_PLACES_NATIVE)
        .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;
    let scaled = value
        .checked_mul(decimal_power)
        .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;
    let shifted = scaled
        .checked_add(SORT_KEY_MAX_HALF_VALUE_NATIVE)
        .ok_or_else(|| PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE))?;

    if !(0 <= shifted && shifted < SORT_KEY_MAX_VALUE_NATIVE) {
        return Err(PyValueError::new_err(NUMBER_RANGE_ERROR_MESSAGE));
    }

    let base64_text =
        convert_int_to_custom_base64_native(shifted, DYNAMODB_BASE64_CHARSET_NATIVE.as_slice())?;
    Ok(format!(
        "D{base64_text:>width$}",
        width = SORT_KEY_LENGTH_NATIVE
    ))
}

pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(format_value, m)?)?;
    m.add_function(wrap_pyfunction!(format_value_int, m)?)?;
    Ok(())
}
