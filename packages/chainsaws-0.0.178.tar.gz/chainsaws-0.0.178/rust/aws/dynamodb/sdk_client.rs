use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Duration;

use aws_config::BehaviorVersion;
use aws_credential_types::provider::SharedCredentialsProvider;
use aws_credential_types::Credentials;
use aws_sdk_dynamodb::config::Builder as DynamoConfigBuilder;
use aws_sdk_dynamodb::types::{
    AttributeValue, DeleteRequest, KeysAndAttributes, PutRequest, ReturnValue, WriteRequest,
};
use aws_sdk_dynamodb::Client;
use aws_types::region::Region;
use once_cell::sync::Lazy;
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList, PyTuple};

use crate::dynamodb::codec::deserialize_items_in_place;
use crate::dynamodb::sdk_wire::{
    attr_map_to_py_wire_item, attr_maps_to_py_wire_items, optional_attr_map_to_py_wire_item,
    py_object_expr_values_to_attr_map, py_object_item_to_attr_map, py_object_items_to_attr_maps,
    py_string_map_to_hash_map, py_wire_items_to_attr_maps,
};

type PyObject = pyo3::Py<pyo3::PyAny>;

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
struct ClientConfigKey {
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
}

static RUNTIME: Lazy<tokio::runtime::Runtime> = Lazy::new(|| {
    tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("failed to initialize Tokio runtime")
});

static CLIENT_CACHE: Lazy<Mutex<HashMap<ClientConfigKey, Client>>> =
    Lazy::new(|| Mutex::new(HashMap::new()));

const DDB_BATCH_GET_MAX_KEYS_PER_CALL: usize = 100;
const DDB_BATCH_WRITE_MAX_ITEMS_PER_CALL: usize = 25;
const DDB_BATCH_CHUNK_CONCURRENCY_MAX: usize = 64;
const DDB_BATCH_GET_CHUNK_CONCURRENCY_DEFAULT: usize = 12;
const DDB_BATCH_WRITE_CHUNK_CONCURRENCY_DEFAULT: usize = 16;

fn parse_chunk_concurrency_env(var_name: &str, default_value: usize) -> usize {
    std::env::var(var_name)
        .ok()
        .and_then(|raw| raw.trim().parse::<usize>().ok())
        .or_else(|| {
            std::env::var("CHAINSAWS_DDB_BATCH_CHUNK_CONCURRENCY")
                .ok()
                .and_then(|raw| raw.trim().parse::<usize>().ok())
        })
        .filter(|value| *value > 0)
        .map(|value| value.min(DDB_BATCH_CHUNK_CONCURRENCY_MAX))
        .unwrap_or(default_value)
}

static DDB_BATCH_GET_CHUNK_CONCURRENCY: Lazy<usize> = Lazy::new(|| {
    parse_chunk_concurrency_env(
        "CHAINSAWS_DDB_BATCH_GET_CHUNK_CONCURRENCY",
        DDB_BATCH_GET_CHUNK_CONCURRENCY_DEFAULT,
    )
});

static DDB_BATCH_WRITE_CHUNK_CONCURRENCY: Lazy<usize> = Lazy::new(|| {
    parse_chunk_concurrency_env(
        "CHAINSAWS_DDB_BATCH_WRITE_CHUNK_CONCURRENCY",
        DDB_BATCH_WRITE_CHUNK_CONCURRENCY_DEFAULT,
    )
});

fn sdk_error_to_py<E: std::fmt::Display + std::fmt::Debug>(err: E) -> PyErr {
    PyRuntimeError::new_err(format!("{err} | debug={err:?}"))
}

fn sdk_error_to_string<E: std::fmt::Display + std::fmt::Debug>(err: E) -> String {
    format!("{err} | debug={err:?}")
}

async fn run_batch_get_chunk_with_retries(
    client: Client,
    table_name: String,
    pair_chunk: Vec<(String, String)>,
    consistent_read: bool,
    max_unprocessed_retries: usize,
) -> Result<Vec<HashMap<String, AttributeValue>>, String> {
    let mut pending_keys: Vec<HashMap<String, AttributeValue>> =
        Vec::with_capacity(pair_chunk.len());
    for (pk, sk) in pair_chunk {
        let mut key: HashMap<String, AttributeValue> = HashMap::with_capacity(2);
        key.insert("_pk".to_string(), AttributeValue::S(pk));
        key.insert("_sk".to_string(), AttributeValue::S(sk));
        pending_keys.push(key);
    }

    let mut chunk_items: Vec<HashMap<String, AttributeValue>> = Vec::new();
    let mut retry_count = 0usize;

    while !pending_keys.is_empty() {
        let mut request_map: HashMap<String, KeysAndAttributes> = HashMap::new();
        let request_keys = KeysAndAttributes::builder()
            .set_keys(Some(pending_keys))
            .set_consistent_read(Some(consistent_read))
            .build()
            .map_err(sdk_error_to_string)?;
        request_map.insert(table_name.clone(), request_keys);

        let response = client
            .batch_get_item()
            .set_request_items(Some(request_map))
            .send()
            .await
            .map_err(sdk_error_to_string)?;

        if let Some(items) = response
            .responses()
            .and_then(|entries| entries.get(&table_name))
        {
            chunk_items.extend(items.to_vec());
        }

        let next_pending = response
            .unprocessed_keys()
            .and_then(|entries| entries.get(&table_name).cloned())
            .map(|entry| entry.keys().to_vec())
            .unwrap_or_default();

        if next_pending.is_empty() {
            break;
        }

        if retry_count >= max_unprocessed_retries {
            return Err(format!(
                "Unprocessed keys remained after retries: {} keys",
                next_pending.len()
            ));
        }

        retry_count += 1;
        tokio::time::sleep(Duration::from_secs((retry_count * retry_count) as u64)).await;
        pending_keys = next_pending;
    }

    Ok(chunk_items)
}

async fn run_batch_write_chunk_with_retries(
    client: Client,
    table_name: String,
    mut pending: Vec<WriteRequest>,
    max_unprocessed_retries: usize,
) -> Result<(), String> {
    let mut retry_count = 0usize;

    while !pending.is_empty() {
        let mut request_map = HashMap::new();
        request_map.insert(table_name.clone(), pending);

        let response = client
            .batch_write_item()
            .set_request_items(Some(request_map))
            .send()
            .await
            .map_err(sdk_error_to_string)?;

        let unprocessed = response
            .unprocessed_items()
            .and_then(|entries| entries.get(&table_name).cloned())
            .unwrap_or_default();

        if unprocessed.is_empty() {
            break;
        }

        if retry_count >= max_unprocessed_retries {
            return Err(format!(
                "Unprocessed write requests remained after retries: {} requests",
                unprocessed.len()
            ));
        }

        retry_count += 1;
        tokio::time::sleep(Duration::from_secs((retry_count * retry_count) as u64)).await;
        pending = unprocessed;
    }

    Ok(())
}

fn get_or_create_client(config_key: &ClientConfigKey) -> PyResult<Client> {
    {
        let cache = CLIENT_CACHE
            .lock()
            .map_err(|_| PyRuntimeError::new_err("failed to acquire client cache lock"))?;
        if let Some(cached) = cache.get(config_key) {
            return Ok(cached.clone());
        }
    }

    let new_client = {
        let config_key = config_key.clone();
        RUNTIME.block_on(async move {
            let mut loader = aws_config::defaults(BehaviorVersion::latest());

            if let Some(region) = &config_key.region {
                loader = loader.region(Region::new(region.clone()));
            }

            if let Some(profile_name) = &config_key.profile_name {
                loader = loader.profile_name(profile_name.clone());
            }

            if let (Some(access_key_id), Some(secret_access_key)) =
                (&config_key.access_key_id, &config_key.secret_access_key)
            {
                let credentials = Credentials::new(
                    access_key_id.clone(),
                    secret_access_key.clone(),
                    config_key.session_token.clone(),
                    None,
                    "chainsaws-pyo3",
                );
                loader = loader.credentials_provider(SharedCredentialsProvider::new(credentials));
            }

            let shared_config = loader.load().await;
            let mut dynamo_builder = DynamoConfigBuilder::from(&shared_config);
            if let Some(endpoint_url) = &config_key.endpoint_url {
                dynamo_builder = dynamo_builder.endpoint_url(endpoint_url.clone());
            }
            let dynamo_config = dynamo_builder.build();
            Client::from_conf(dynamo_config)
        })
    };

    let mut cache = CLIENT_CACHE
        .lock()
        .map_err(|_| PyRuntimeError::new_err("failed to acquire client cache lock"))?;
    cache.insert(config_key.clone(), new_client.clone());
    Ok(new_client)
}

fn parse_client_key(
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> ClientConfigKey {
    ClientConfigKey {
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    }
}

fn py_optional_string_map(
    values: Option<PyObject>,
    py: Python<'_>,
) -> PyResult<Option<HashMap<String, String>>> {
    values
        .map(|obj| py_string_map_to_hash_map(obj.bind(py)))
        .transpose()
}

fn py_optional_attr_map(
    values: Option<PyObject>,
    py: Python<'_>,
) -> PyResult<Option<HashMap<String, AttributeValue>>> {
    values
        .map(|obj| py_object_expr_values_to_attr_map(obj.bind(py)))
        .transpose()
}

fn parse_key_part(value: &Bound<'_, PyAny>) -> PyResult<String> {
    if let Ok(as_str) = value.extract::<String>() {
        return Ok(as_str);
    }
    if let Ok(as_dict) = value.downcast::<PyDict>() {
        if let Ok(Some(raw_s)) = as_dict.get_item("S") {
            return raw_s.extract::<String>();
        }
    }
    Err(PyRuntimeError::new_err(
        "pk/sk values must be strings or {'S': '<value>'}",
    ))
}

fn parse_pk_sk_pairs(pairs: &Bound<'_, PyAny>) -> PyResult<Vec<(String, String)>> {
    let items = pairs
        .downcast::<PyList>()
        .map_err(|_| PyRuntimeError::new_err("pk_sk_pairs must be a list"))?;
    let mut out: Vec<(String, String)> = Vec::with_capacity(items.len());
    for pair_any in items.iter() {
        if !pair_any.is_truthy()? {
            continue;
        }
        if let Ok(pair_tuple) = pair_any.downcast::<PyTuple>() {
            if pair_tuple.len() >= 2 {
                let pk = parse_key_part(&pair_tuple.get_item(0)?)?;
                let sk = parse_key_part(&pair_tuple.get_item(1)?)?;
                out.push((pk, sk));
                continue;
            }
        }
        if let Ok(pair_list) = pair_any.downcast::<PyList>() {
            if pair_list.len() >= 2 {
                let pk = parse_key_part(&pair_list.get_item(0)?)?;
                let sk = parse_key_part(&pair_list.get_item(1)?)?;
                out.push((pk, sk));
                continue;
            }
        }
        if let Ok(pair_dict) = pair_any.downcast::<PyDict>() {
            let pk_raw = pair_dict
                .get_item("_pk")?
                .ok_or_else(|| PyRuntimeError::new_err("dict pair must contain _pk"))?;
            let sk_raw = pair_dict
                .get_item("_sk")?
                .ok_or_else(|| PyRuntimeError::new_err("dict pair must contain _sk"))?;
            let pk = parse_key_part(&pk_raw)?;
            let sk = parse_key_part(&sk_raw)?;
            out.push((pk, sk));
            continue;
        }
        return Err(PyRuntimeError::new_err(
            "each pk_sk_pairs entry must be tuple/list/dict with _pk and _sk",
        ));
    }
    Ok(out)
}

fn maybe_deserialize_items(
    py: Python<'_>,
    items: &Bound<'_, PyList>,
    decimal_context: Option<&PyObject>,
    binary_type: Option<&PyObject>,
    fallback_deserializer: Option<&PyObject>,
) -> PyResult<()> {
    match (decimal_context, binary_type, fallback_deserializer) {
        (None, None, None) => Ok(()),
        (Some(decimal_context), Some(binary_type), Some(fallback_deserializer)) => {
            deserialize_items_in_place(
                py,
                items,
                decimal_context.bind(py),
                binary_type.bind(py),
                fallback_deserializer.bind(py),
            )
        }
        _ => Err(PyRuntimeError::new_err(
            "decimal_context, binary_type, fallback_deserializer must be provided together",
        )),
    }
}

fn maybe_deserialize_optional_item(
    py: Python<'_>,
    item: Option<PyObject>,
    decimal_context: Option<&PyObject>,
    binary_type: Option<&PyObject>,
    fallback_deserializer: Option<&PyObject>,
) -> PyResult<Option<PyObject>> {
    match (decimal_context, binary_type, fallback_deserializer) {
        (None, None, None) => Ok(item),
        (Some(decimal_context), Some(binary_type), Some(fallback_deserializer)) => {
            if let Some(item_obj) = item {
                let decode_targets = PyList::empty(py);
                decode_targets.append(item_obj.clone_ref(py))?;
                deserialize_items_in_place(
                    py,
                    &decode_targets,
                    decimal_context.bind(py),
                    binary_type.bind(py),
                    fallback_deserializer.bind(py),
                )?;
                Ok(Some(item_obj))
            } else {
                Ok(None)
            }
        }
        _ => Err(PyRuntimeError::new_err(
            "decimal_context, binary_type, fallback_deserializer must be provided together",
        )),
    }
}

#[pyfunction(signature = (
    table_name,
    pk,
    sk,
    consistent_read,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_get_item(
    py: Python<'_>,
    table_name: String,
    pk: String,
    sk: String,
    consistent_read: bool,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<Option<PyObject>> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let output_item = py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        RUNTIME
            .block_on(async move {
                client
                    .get_item()
                    .table_name(table_name)
                    .key("_pk", AttributeValue::S(pk))
                    .key("_sk", AttributeValue::S(sk))
                    .set_consistent_read(Some(consistent_read))
                    .send()
                    .await
                    .map_err(sdk_error_to_py)
            })
            .map(|response| response.item().cloned())
    })?;

    let output_item_obj = optional_attr_map_to_py_wire_item(py, output_item.as_ref())?;
    maybe_deserialize_optional_item(
        py,
        output_item_obj,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )
}

#[pyfunction(signature = (
    table_name,
    keys,
    consistent_read,
    max_unprocessed_retries,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_batch_get_items(
    py: Python<'_>,
    table_name: String,
    keys: PyObject,
    consistent_read: bool,
    max_unprocessed_retries: usize,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<PyObject> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );
    let key_maps = py_wire_items_to_attr_maps(keys.bind(py))?;

    let output_items = py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        let table_name_for_request = table_name.clone();

        RUNTIME.block_on(async move {
            let mut all_items: Vec<HashMap<String, AttributeValue>> = Vec::new();

            let mut request_map: HashMap<String, KeysAndAttributes> = HashMap::new();
            let base_keys = KeysAndAttributes::builder()
                .set_keys(Some(key_maps))
                .set_consistent_read(Some(consistent_read))
                .build()
                .map_err(sdk_error_to_py)?;
            request_map.insert(table_name_for_request.clone(), base_keys);

            let mut response = client
                .batch_get_item()
                .set_request_items(Some(request_map))
                .send()
                .await
                .map_err(sdk_error_to_py)?;

            if let Some(items) = response
                .responses()
                .and_then(|entries| entries.get(&table_name_for_request))
            {
                all_items.extend(items.to_vec());
            }

            let mut retry_count = 0usize;
            let mut unprocessed_keys = response
                .unprocessed_keys()
                .and_then(|entries| entries.get(&table_name_for_request).cloned());

            while let Some(unprocessed) = unprocessed_keys {
                let keys = unprocessed.keys().to_vec();
                if keys.is_empty() {
                    break;
                }
                if retry_count >= max_unprocessed_retries {
                    return Err(PyRuntimeError::new_err(format!(
                        "Unprocessed keys remained after retries: {} keys",
                        keys.len()
                    )));
                }

                retry_count += 1;
                tokio::time::sleep(Duration::from_secs((retry_count * retry_count) as u64)).await;

                let mut retry_request_map: HashMap<String, KeysAndAttributes> = HashMap::new();
                let retry_keys = KeysAndAttributes::builder()
                    .set_keys(Some(keys))
                    .set_consistent_read(Some(consistent_read))
                    .build()
                    .map_err(sdk_error_to_py)?;
                retry_request_map.insert(table_name_for_request.clone(), retry_keys);

                response = client
                    .batch_get_item()
                    .set_request_items(Some(retry_request_map))
                    .send()
                    .await
                    .map_err(sdk_error_to_py)?;

                if let Some(items) = response
                    .responses()
                    .and_then(|entries| entries.get(&table_name_for_request))
                {
                    all_items.extend(items.to_vec());
                }

                unprocessed_keys = response
                    .unprocessed_keys()
                    .and_then(|entries| entries.get(&table_name_for_request).cloned());
            }

            Ok(all_items)
        })
    })?;

    let output_object = attr_maps_to_py_wire_items(py, &output_items)?;
    let output_list = output_object
        .bind(py)
        .downcast::<PyList>()
        .map_err(|_| PyRuntimeError::new_err("internal error: expected list output"))?;
    maybe_deserialize_items(
        py,
        output_list,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;
    Ok(output_object)
}

#[pyfunction(signature = (
    table_name,
    pk_sk_pairs,
    consistent_read,
    max_unprocessed_retries,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_batch_get_items_ordered(
    py: Python<'_>,
    table_name: String,
    pk_sk_pairs: PyObject,
    consistent_read: bool,
    max_unprocessed_retries: usize,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<PyObject> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );
    let ordered_pairs = parse_pk_sk_pairs(pk_sk_pairs.bind(py))?;
    let pairs_for_fetch = ordered_pairs.clone();

    let item_by_key = py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        let table_name_for_request = table_name.clone();

        RUNTIME.block_on(async move {
            let mut all_items: Vec<HashMap<String, AttributeValue>> = Vec::new();
            let chunk_concurrency = *DDB_BATCH_GET_CHUNK_CONCURRENCY;

            let pair_chunks: Vec<Vec<(String, String)>> = pairs_for_fetch
                .chunks(DDB_BATCH_GET_MAX_KEYS_PER_CALL)
                .map(|chunk| chunk.to_vec())
                .collect();
            let mut next_chunk_idx = 0usize;
            let mut join_set = tokio::task::JoinSet::new();

            while next_chunk_idx < pair_chunks.len() && join_set.len() < chunk_concurrency {
                let pair_chunk = pair_chunks[next_chunk_idx].clone();
                let chunk_client = client.clone();
                let chunk_table_name = table_name_for_request.clone();
                join_set.spawn(async move {
                    run_batch_get_chunk_with_retries(
                        chunk_client,
                        chunk_table_name,
                        pair_chunk,
                        consistent_read,
                        max_unprocessed_retries,
                    )
                    .await
                });
                next_chunk_idx += 1;
            }

            while let Some(chunk_result) = join_set.join_next().await {
                let mut chunk_items = chunk_result
                    .map_err(|err| {
                        PyRuntimeError::new_err(format!("batch get chunk task failed: {err}"))
                    })?
                    .map_err(PyRuntimeError::new_err)?;
                all_items.append(&mut chunk_items);

                if next_chunk_idx < pair_chunks.len() {
                    let pair_chunk = pair_chunks[next_chunk_idx].clone();
                    let chunk_client = client.clone();
                    let chunk_table_name = table_name_for_request.clone();
                    join_set.spawn(async move {
                        run_batch_get_chunk_with_retries(
                            chunk_client,
                            chunk_table_name,
                            pair_chunk,
                            consistent_read,
                            max_unprocessed_retries,
                        )
                        .await
                    });
                    next_chunk_idx += 1;
                }
            }

            let mut map: HashMap<(String, String), HashMap<String, AttributeValue>> =
                HashMap::with_capacity(all_items.len());
            for item in all_items {
                let pk = match item.get("_pk") {
                    Some(AttributeValue::S(value)) => value.clone(),
                    _ => continue,
                };
                let sk = match item.get("_sk") {
                    Some(AttributeValue::S(value)) => value.clone(),
                    _ => continue,
                };
                map.insert((pk, sk), item);
            }

            Ok::<HashMap<(String, String), HashMap<String, AttributeValue>>, PyErr>(map)
        })
    })?;

    let output = PyList::empty(py);
    let decode_targets = PyList::empty(py);
    for (pk, sk) in ordered_pairs {
        if let Some(item) = item_by_key.get(&(pk.clone(), sk.clone())) {
            let wire_item = attr_map_to_py_wire_item(py, item)?;
            output.append(wire_item.clone_ref(py))?;
            decode_targets.append(wire_item)?;
        } else {
            output.append(py.None())?;
        }
    }
    maybe_deserialize_items(
        py,
        &decode_targets,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;

    Ok(output.into_pyobject(py)?.unbind().into())
}

#[pyfunction(signature = (
    table_name,
    item,
    can_overwrite,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_put_item(
    py: Python<'_>,
    table_name: String,
    item: PyObject,
    can_overwrite: bool,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<PyObject> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );
    let item_map = py_object_item_to_attr_map(item.bind(py))?;

    py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        RUNTIME.block_on(async move {
            let mut request = client
                .put_item()
                .table_name(table_name)
                .set_item(Some(item_map));

            if !can_overwrite {
                request = request
                    .condition_expression("attribute_not_exists(#pk) AND attribute_not_exists(#sk)")
                    .expression_attribute_names("#pk", "_pk")
                    .expression_attribute_names("#sk", "_sk");
            }

            request.send().await.map_err(sdk_error_to_py)?;
            Ok::<(), PyErr>(())
        })
    })?;

    Ok(PyDict::new(py).into_pyobject(py)?.unbind().into())
}

#[pyfunction(signature = (
    table_name,
    pk,
    sk,
    update_expression,
    expression_attribute_names,
    expression_attribute_values,
    condition_expression,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_update_item(
    py: Python<'_>,
    table_name: String,
    pk: String,
    sk: String,
    update_expression: String,
    expression_attribute_names: PyObject,
    expression_attribute_values: PyObject,
    condition_expression: String,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<Option<PyObject>> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let expr_names = py_string_map_to_hash_map(expression_attribute_names.bind(py))?;
    let expr_values = py_object_expr_values_to_attr_map(expression_attribute_values.bind(py))?;

    let updated_attrs = py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        RUNTIME
            .block_on(async move {
                client
                    .update_item()
                    .table_name(table_name)
                    .key("_pk", AttributeValue::S(pk))
                    .key("_sk", AttributeValue::S(sk))
                    .update_expression(update_expression)
                    .set_expression_attribute_names(Some(expr_names))
                    .set_expression_attribute_values(Some(expr_values))
                    .condition_expression(condition_expression)
                    .return_values(ReturnValue::AllNew)
                    .send()
                    .await
                    .map_err(sdk_error_to_py)
            })
            .map(|response| response.attributes().cloned())
    })?;

    let output_item_obj = optional_attr_map_to_py_wire_item(py, updated_attrs.as_ref())?;
    maybe_deserialize_optional_item(
        py,
        output_item_obj,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )
}

#[pyfunction(signature = (
    table_name,
    pk,
    sk,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_delete_item(
    py: Python<'_>,
    table_name: String,
    pk: String,
    sk: String,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<Option<PyObject>> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let deleted_attrs = py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        RUNTIME
            .block_on(async move {
                client
                    .delete_item()
                    .table_name(table_name)
                    .key("_pk", AttributeValue::S(pk))
                    .key("_sk", AttributeValue::S(sk))
                    .return_values(ReturnValue::AllOld)
                    .send()
                    .await
                    .map_err(sdk_error_to_py)
            })
            .map(|response| response.attributes().cloned())
    })?;

    let output_item_obj = optional_attr_map_to_py_wire_item(py, deleted_attrs.as_ref())?;
    maybe_deserialize_optional_item(
        py,
        output_item_obj,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )
}

#[pyfunction(signature = (
    table_name,
    put_items,
    delete_keys,
    max_unprocessed_retries,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_batch_write(
    py: Python<'_>,
    table_name: String,
    put_items: Option<PyObject>,
    delete_keys: Option<PyObject>,
    max_unprocessed_retries: usize,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<bool> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let put_maps = match put_items {
        Some(items) => py_object_items_to_attr_maps(items.bind(py))?,
        None => Vec::new(),
    };
    let delete_maps = match delete_keys {
        Some(items) => py_wire_items_to_attr_maps(items.bind(py))?,
        None => Vec::new(),
    };

    py.detach(|| {
        let client = get_or_create_client(&config_key)?;
        let table_name_for_request = table_name.clone();

        RUNTIME.block_on(async move {
            let mut write_requests: Vec<WriteRequest> =
                Vec::with_capacity(put_maps.len() + delete_maps.len());
            let chunk_concurrency = *DDB_BATCH_WRITE_CHUNK_CONCURRENCY;

            for item in put_maps {
                let put_request = PutRequest::builder()
                    .set_item(Some(item))
                    .build()
                    .map_err(sdk_error_to_py)?;
                write_requests.push(WriteRequest::builder().put_request(put_request).build());
            }

            for key in delete_maps {
                let delete_request = DeleteRequest::builder()
                    .set_key(Some(key))
                    .build()
                    .map_err(sdk_error_to_py)?;
                write_requests.push(
                    WriteRequest::builder()
                        .delete_request(delete_request)
                        .build(),
                );
            }

            let write_chunks: Vec<Vec<WriteRequest>> = write_requests
                .chunks(DDB_BATCH_WRITE_MAX_ITEMS_PER_CALL)
                .map(|chunk| chunk.to_vec())
                .collect();

            let mut next_chunk_idx = 0usize;
            let mut join_set = tokio::task::JoinSet::new();

            while next_chunk_idx < write_chunks.len() && join_set.len() < chunk_concurrency {
                let write_chunk = write_chunks[next_chunk_idx].clone();
                let chunk_client = client.clone();
                let chunk_table_name = table_name_for_request.clone();
                join_set.spawn(async move {
                    run_batch_write_chunk_with_retries(
                        chunk_client,
                        chunk_table_name,
                        write_chunk,
                        max_unprocessed_retries,
                    )
                    .await
                });
                next_chunk_idx += 1;
            }

            while let Some(chunk_result) = join_set.join_next().await {
                chunk_result
                    .map_err(|err| {
                        PyRuntimeError::new_err(format!("batch write chunk task failed: {err}"))
                    })?
                    .map_err(PyRuntimeError::new_err)?;

                if next_chunk_idx < write_chunks.len() {
                    let write_chunk = write_chunks[next_chunk_idx].clone();
                    let chunk_client = client.clone();
                    let chunk_table_name = table_name_for_request.clone();
                    join_set.spawn(async move {
                        run_batch_write_chunk_with_retries(
                            chunk_client,
                            chunk_table_name,
                            write_chunk,
                            max_unprocessed_retries,
                        )
                        .await
                    });
                    next_chunk_idx += 1;
                }
            }

            Ok(true)
        })
    })
}

#[pyfunction(signature = (
    table_name,
    key_condition_expression,
    expression_attribute_names=None,
    expression_attribute_values=None,
    filter_expression=None,
    index_name=None,
    exclusive_start_key=None,
    limit=None,
    consistent_read=false,
    scan_index_forward=true,
    projection_expression=None,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_query_items(
    py: Python<'_>,
    table_name: String,
    key_condition_expression: String,
    expression_attribute_names: Option<PyObject>,
    expression_attribute_values: Option<PyObject>,
    filter_expression: Option<String>,
    index_name: Option<String>,
    exclusive_start_key: Option<PyObject>,
    limit: Option<i32>,
    consistent_read: bool,
    scan_index_forward: bool,
    projection_expression: Option<String>,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<PyObject> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let expr_names = py_optional_string_map(expression_attribute_names, py)?;
    let expr_values = py_optional_attr_map(expression_attribute_values, py)?;
    let start_key = exclusive_start_key
        .map(|entry| py_object_item_to_attr_map(entry.bind(py)))
        .transpose()?;

    let (items, last_evaluated_key) = py.detach(|| {
        let client = get_or_create_client(&config_key)?;

        RUNTIME.block_on(async move {
            let mut request = client
                .query()
                .table_name(table_name)
                .key_condition_expression(key_condition_expression)
                .set_scan_index_forward(Some(scan_index_forward));

            if let Some(expr) = filter_expression {
                request = request.filter_expression(expr);
            }
            if let Some(name) = index_name {
                request = request.index_name(name);
            }
            if let Some(start) = start_key {
                request = request.set_exclusive_start_key(Some(start));
            }
            if let Some(limit_value) = limit {
                request = request.limit(limit_value);
            }
            if let Some(expr) = projection_expression {
                request = request.projection_expression(expr);
            }

            request = request.set_consistent_read(Some(consistent_read));
            request = request.set_expression_attribute_names(expr_names);
            request = request.set_expression_attribute_values(expr_values);

            let response = request.send().await.map_err(sdk_error_to_py)?;
            Ok::<
                (
                    Vec<HashMap<String, AttributeValue>>,
                    Option<HashMap<String, AttributeValue>>,
                ),
                PyErr,
            >((
                response.items().to_vec(),
                response.last_evaluated_key().cloned(),
            ))
        })
    })?;

    let items_obj = attr_maps_to_py_wire_items(py, &items)?;
    let items_list = items_obj
        .bind(py)
        .downcast::<PyList>()
        .map_err(|_| PyRuntimeError::new_err("internal error: expected list output"))?;
    maybe_deserialize_items(
        py,
        items_list,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;

    let last_key_obj = optional_attr_map_to_py_wire_item(py, last_evaluated_key.as_ref())?;
    let decoded_last_key = maybe_deserialize_optional_item(
        py,
        last_key_obj,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;

    let out = PyDict::new(py);
    out.set_item("Items", items_obj)?;
    out.set_item("LastEvaluatedKey", decoded_last_key)?;
    Ok(out.into_pyobject(py)?.unbind().into())
}

#[pyfunction(signature = (
    table_name,
    expression_attribute_names=None,
    expression_attribute_values=None,
    filter_expression=None,
    exclusive_start_key=None,
    limit=None,
    projection_expression=None,
    decimal_context=None,
    binary_type=None,
    fallback_deserializer=None,
    region=None,
    endpoint_url=None,
    profile_name=None,
    access_key_id=None,
    secret_access_key=None,
    session_token=None
))]
pub(crate) fn dynamodb_sdk_scan_items(
    py: Python<'_>,
    table_name: String,
    expression_attribute_names: Option<PyObject>,
    expression_attribute_values: Option<PyObject>,
    filter_expression: Option<String>,
    exclusive_start_key: Option<PyObject>,
    limit: Option<i32>,
    projection_expression: Option<String>,
    decimal_context: Option<PyObject>,
    binary_type: Option<PyObject>,
    fallback_deserializer: Option<PyObject>,
    region: Option<String>,
    endpoint_url: Option<String>,
    profile_name: Option<String>,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
) -> PyResult<PyObject> {
    let config_key = parse_client_key(
        region,
        endpoint_url,
        profile_name,
        access_key_id,
        secret_access_key,
        session_token,
    );

    let expr_names = py_optional_string_map(expression_attribute_names, py)?;
    let expr_values = py_optional_attr_map(expression_attribute_values, py)?;
    let start_key = exclusive_start_key
        .map(|entry| py_object_item_to_attr_map(entry.bind(py)))
        .transpose()?;

    let (items, last_evaluated_key) = py.detach(|| {
        let client = get_or_create_client(&config_key)?;

        RUNTIME.block_on(async move {
            let mut request = client.scan().table_name(table_name);

            if let Some(expr) = filter_expression {
                request = request.filter_expression(expr);
            }
            if let Some(start) = start_key {
                request = request.set_exclusive_start_key(Some(start));
            }
            if let Some(limit_value) = limit {
                request = request.limit(limit_value);
            }
            if let Some(expr) = projection_expression {
                request = request.projection_expression(expr);
            }

            request = request.set_expression_attribute_names(expr_names);
            request = request.set_expression_attribute_values(expr_values);

            let response = request.send().await.map_err(sdk_error_to_py)?;
            Ok::<
                (
                    Vec<HashMap<String, AttributeValue>>,
                    Option<HashMap<String, AttributeValue>>,
                ),
                PyErr,
            >((
                response.items().to_vec(),
                response.last_evaluated_key().cloned(),
            ))
        })
    })?;

    let items_obj = attr_maps_to_py_wire_items(py, &items)?;
    let items_list = items_obj
        .bind(py)
        .downcast::<PyList>()
        .map_err(|_| PyRuntimeError::new_err("internal error: expected list output"))?;
    maybe_deserialize_items(
        py,
        items_list,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;

    let last_key_obj = optional_attr_map_to_py_wire_item(py, last_evaluated_key.as_ref())?;
    let decoded_last_key = maybe_deserialize_optional_item(
        py,
        last_key_obj,
        decimal_context.as_ref(),
        binary_type.as_ref(),
        fallback_deserializer.as_ref(),
    )?;

    let out = PyDict::new(py);
    out.set_item("Items", items_obj)?;
    out.set_item("LastEvaluatedKey", decoded_last_key)?;
    Ok(out.into_pyobject(py)?.unbind().into())
}

pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(dynamodb_sdk_get_item, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_batch_get_items, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_batch_get_items_ordered, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_put_item, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_update_item, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_delete_item, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_batch_write, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_query_items, m)?)?;
    m.add_function(wrap_pyfunction!(dynamodb_sdk_scan_items, m)?)?;
    Ok(())
}
