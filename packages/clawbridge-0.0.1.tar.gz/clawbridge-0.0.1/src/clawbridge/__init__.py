"""
ClawBridge
The official PyPI package for ClawBridge.
"""
__version__ = "0.0.1"

def main():
    print("Welcome to ClawBridge! Please visit https://github.com/dreamwing/clawbridge for more information.")
