"""Integration adapters for agentshield.

Optional third-party integrations. Install extras to enable:

    pip install aumos-agentshield[nemo]
"""
