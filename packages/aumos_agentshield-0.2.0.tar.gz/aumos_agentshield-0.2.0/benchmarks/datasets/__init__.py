"""Synthetic datasets for agentshield benchmarks."""
