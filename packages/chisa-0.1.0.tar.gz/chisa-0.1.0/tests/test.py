from chisa import convert, axiom
from chisa.units.time import Hour, Minute, TimeUnit, Second, Millennium, Year
from chisa.units.force import Newton
from chisa.exceptions import AxiomViolationError

res = Hour(-1.3) + Minute(20)
print(res.flex())

res = convert(1.3, 'hour').to('kilometers')
print(res)

@axiom.require(waktu='time')
def konversi_ke_detik(waktu: TimeUnit) -> Second:
    return waktu.to(Second)

print(konversi_ke_detik(Millennium()))

@axiom.require(tahun=Year)
def konversi_usia_ke_detik(tahun: Year) -> Second:
    return Year.to(Second)

print(konversi_usia_ke_detik(Newton(20)))
