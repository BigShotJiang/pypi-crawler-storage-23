"""
Cekura SDK - Observability for AI Agents
"""

__author__ = "Cekura"
__email__ = "support@cekura.ai"

# Version will be set dynamically from git tags via setuptools_scm
try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"

from cekura.livekit import LiveKitTracer

__all__ = ["LiveKitTracer", "__version__"]
