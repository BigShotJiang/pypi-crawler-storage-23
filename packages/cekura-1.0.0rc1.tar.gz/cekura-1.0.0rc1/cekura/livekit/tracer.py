"""
LiveKit tracer for Cekura observability platform
Captures transcripts, tool calls, metrics, and recordings from LiveKit Agent sessions
"""

import logging
import os
import time
import uuid
from typing import Any, Dict, Optional

logger = logging.getLogger("cekura")


class LiveKitTracer:
    """
    Main class for observing and capturing LiveKit Agent sessions.

    Usage:
        import os
        from cekura.livekit import LiveKitTracer

        cekura = LiveKitTracer(
            api_key=os.getenv("CEKURA_API_KEY"),
            agent_id=123,
        )

        # Start Cekura session tracking
        session_id = cekura.start_session(session)

        # Add shutdown callback to export Cekura data
        async def cekura_shutdown():
            await cekura.export(session_id, ctx)

        ctx.add_shutdown_callback(cekura_shutdown)
    """

    def __init__(
        self,
        api_key: str,
        agent_id: int,
        host: str = "https://api.cekura.ai",
        enabled: Optional[bool] = None
    ):
        """
        Initialize LiveKit tracer.

        Args:
            api_key: API key for authentication
            agent_id: Unique identifier for your agent (integer)
            host: API host URL (default: https://api.cekura.ai)
            enabled: Enable/disable tracing. Defaults to CEKURA_TRACING_ENABLED env var ("true" if not set).
        """
        self.api_key = api_key
        self.agent_id = agent_id
        self.host = host
        self.webhook_url = f"{host.rstrip('/')}/test_framework/v1/livekit-webhook/"

        # Set enabled flag: function parameter takes precedence over environment variable
        if enabled is not None:
            self.enabled = enabled
        else:
            env_enabled = os.getenv("CEKURA_TRACING_ENABLED", "true").lower()
            self.enabled = env_enabled in ("true", "1", "yes")

        # Session storage
        self.session_data = {}

        if self.enabled:
            logger.info(f"LiveKitTracer initialized for agent {agent_id}")
        else:
            logger.info(f"LiveKitTracer tracing is disabled for agent {agent_id}")

    def start_session(self, session, **metadata) -> str:
        """
        Start tracking a LiveKit Agent session.

        Args:
            session: LiveKit AgentSession instance
            **metadata: Additional metadata (user_id, call_type, custom fields, etc.)

        Returns:
            session_id: Unique identifier for this session
        """
        session_id = str(uuid.uuid4())

        # Do nothing if tracing is disabled
        if not self.enabled:
            return session_id

        # Initialize session storage
        self.session_data[session_id] = {
            'start_time': time.time(),
            'metadata': metadata,
            'stt_metrics': [],
            'llm_metrics': [],
            'tts_metrics': [],
            'eou_metrics': []
        }

        logger.info(f"Session tracking started: {session_id}")

        # Hook into metrics collection
        @session.on("metrics_collected")
        def on_metrics(ev):
            logger.debug(f"Metrics collected for session {session_id}: {ev.metrics}")
            self._collect_metrics(session_id, ev.metrics)

        # Hook into session close
        @session.on("close")
        def on_close(ev):
            logger.info(f"Session closed: {session_id}")

        return session_id

    def _collect_metrics(self, session_id: str, metrics):
        """Collect metrics from LiveKit events"""
        if session_id not in self.session_data:
            return

        data = self.session_data[session_id]
        metrics_type = type(metrics).__name__

        # Categorize by type
        if 'STT' in metrics_type:
            data['stt_metrics'].append(self._serialize_metrics(metrics))
        elif 'LLM' in metrics_type:
            data['llm_metrics'].append(self._serialize_metrics(metrics))
        elif 'TTS' in metrics_type:
            data['tts_metrics'].append(self._serialize_metrics(metrics))
        elif 'EOU' in metrics_type:
            data['eou_metrics'].append(self._serialize_metrics(metrics))

    def _serialize_metrics(self, metrics) -> Dict[str, Any]:
        """Convert metrics object to dictionary"""
        result = {}

        # Common attributes across all metrics types
        common_attrs = [
            'timestamp', 'duration', 'audio_duration', 'streamed',
            'prompt_tokens', 'completion_tokens', 'cached_tokens', 'total_tokens',
            'tokens_per_second', 'ttft', 'speech_id',
            'characters_count', 'ttfb',
            'end_of_utterance_delay', 'transcription_delay', 'on_user_turn_completed_delay'
        ]

        for attr in common_attrs:
            if hasattr(metrics, attr):
                value = getattr(metrics, attr)
                if value is not None:
                    result[attr] = value

        return result

    def _dump_object_attributes(self, obj) -> Dict[str, Any]:
        """Dump all attributes of an object, safely handling async properties and protobuf objects"""
        import inspect
        result = {}

        # Get all attributes
        for attr_name in dir(obj):
            if attr_name.startswith('_') or attr_name in ('DESCRIPTOR', 'sid'):
                continue
            try:
                # Check if it's a property or descriptor before accessing
                attr_descriptor = getattr(type(obj), attr_name, None)

                # Skip async properties and coroutine functions
                if inspect.iscoroutinefunction(attr_descriptor):
                    continue

                # Check if it's a coroutine property before accessing
                try:
                    attr_value = getattr(obj, attr_name)
                except Exception:
                    # Skip attributes that raise errors when accessed
                    continue

                # Skip methods, coroutines, and other callables
                if callable(attr_value) or inspect.iscoroutine(attr_value):
                    continue

                # Only keep primitive types and simple collections
                if isinstance(attr_value, (str, int, float, bool, type(None))):
                    # Keep primitive types as-is
                    result[attr_name] = attr_value
                elif isinstance(attr_value, (list, dict)):
                    # Keep collections as-is
                    result[attr_name] = attr_value
                else:
                    # Convert other objects to string with length limit
                    result[attr_name] = str(attr_value)[:1000]
            except Exception:
                # Silently skip attributes that cause errors (including async properties)
                continue

        return result

    async def _send_webhook(self, session_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Send session data to Cekura webhook"""
        try:
            import aiohttp
        except ImportError:
            logger.error("aiohttp not installed. Install with: pip install aiohttp")
            return {"success": False, "error": "aiohttp not installed"}

        try:
            headers = {
                "Content-Type": "application/json",
                "X-CEKURA-API-KEY": self.api_key
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.webhook_url,
                    json=payload,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    response_text = await response.text()

                    if response.status >= 200 and response.status < 300:
                        logger.info(f"Session data sent successfully (status {response.status})")
                        return {
                            "success": True,
                            "status_code": response.status,
                            "response": response_text
                        }
                    else:
                        logger.error(f"Failed to send session data (status {response.status}): {response_text}")
                        return {
                            "success": False,
                            "status_code": response.status,
                            "error": response_text
                        }

        except Exception as e:
            logger.error(f"Error sending session data: {e}")
            return {"success": False, "error": str(e)}

    async def export(self, session_id: str, ctx) -> Dict[str, Any]:
        """
        Export session data at the end of a call.

        Args:
            session_id: Session ID from start_session()
            ctx: LiveKit JobContext to extract session report

        Returns:
            Result dictionary with success status
        """
        from cekura import __version__

        # Do nothing if tracing is disabled
        if not self.enabled:
            return {"success": True, "message": "Tracing disabled"}

        if session_id not in self.session_data:
            logger.error(f"Session {session_id} not found")
            return {"success": False, "error": "Session not found"}

        data = self.session_data[session_id]
        end_time = time.time()

        # Get structured session report from LiveKit
        try:
            report = ctx.make_session_report()
            report_dict = report.to_dict()
        except Exception as e:
            logger.warning(f"Could not get session report: {e}")
            report_dict = {}

        # Collect room information and get SID
        room_sid = None
        room_info = {}
        if hasattr(ctx, 'room') and ctx.room:
            # Get room SID first (before dumping attributes to avoid triggering coroutine)
            try:
                room_sid = await ctx.room.sid
            except Exception:
                pass

            room_info = self._dump_object_attributes(ctx.room)

        job_info = {}
        if hasattr(ctx, 'job') and ctx.job:
            job_info = self._dump_object_attributes(ctx.job)

        # Build payload with provider-specific data grouped
        payload = {
            # Basic session info (root level)
            "agent_id": self.agent_id,
            "session_id": room_sid,
            "session_start": data['start_time'],
            "session_export": end_time,
            "sdk_version": __version__,

            # Complete session report from LiveKit (authoritative source)
            # This includes:
            # - chat_history.items: complete conversation with tool calls
            # - events: all state/conversation events (NOT metrics!)
            # - options: session configuration
            # - job_id, room_id, timestamps
            "session_report": report_dict,

            # LiveKit provider-specific data
            "provider_data": {
                "session_id": room_sid,

                # Room and Job details (all attributes, flattened)
                "room_info": room_info,
                "job_info": job_info,

                # Raw per-request metrics (backend will aggregate)
                "raw_metrics": {
                    "stt": data['stt_metrics'],
                    "llm": data['llm_metrics'],
                    "tts": data['tts_metrics'],
                    "eou": data['eou_metrics']
                },

                # Custom metadata from user
                "metadata": data['metadata']
            }
        }

        # Log summary of captured data
        chat_history = report_dict.get('chat_history', {}).get('items', [])
        events = report_dict.get('events', [])
        tool_calls_count = len([item for item in chat_history if item.get('type') == 'function_call'])
        duration_seconds = int(end_time - data['start_time'])

        logger.info(f"Exporting session {session_id}: {duration_seconds}s duration, "
                   f"{len(chat_history)} messages, {tool_calls_count} tool calls")
        logger.debug(f"Session metrics: STT={len(data['stt_metrics'])}, "
                    f"LLM={len(data['llm_metrics'])}, TTS={len(data['tts_metrics'])}, "
                    f"events={len(events)}")

        # Send to webhook
        webhook_result = await self._send_webhook(session_id, payload)

        # Cleanup
        if webhook_result.get('success'):
            del self.session_data[session_id]
            logger.debug(f"Session data cleaned up: {session_id}")

        return webhook_result
