jef.nerve\_agent module
=======================

.. automodule:: jef.nerve_agent
   :members:
   :show-inheritance:
   :undoc-members:
