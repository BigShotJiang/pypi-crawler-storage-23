jef.harmful\_substances.nerve\_agent.score module
=================================================

.. automodule:: jef.harmful_substances.nerve_agent.score
   :members:
   :show-inheritance:
   :undoc-members:
