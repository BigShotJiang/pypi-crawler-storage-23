jef.types module
================

.. automodule:: jef.types
   :members:
   :show-inheritance:
   :undoc-members:
