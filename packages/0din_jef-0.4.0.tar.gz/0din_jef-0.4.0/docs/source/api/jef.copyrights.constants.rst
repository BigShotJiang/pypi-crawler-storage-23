jef.copyrights.constants module
===============================

.. automodule:: jef.copyrights.constants
   :members:
   :show-inheritance:
   :undoc-members:
