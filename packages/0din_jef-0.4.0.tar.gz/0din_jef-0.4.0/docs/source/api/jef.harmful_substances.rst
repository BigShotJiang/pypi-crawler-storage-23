jef.harmful\_substances package
===============================

.. automodule:: jef.harmful_substances
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jef.harmful_substances.nerve_agent
