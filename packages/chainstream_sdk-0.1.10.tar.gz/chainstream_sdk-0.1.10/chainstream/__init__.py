"""ChainStream SDK - API client for ChainStream.

Example:
    ```python
    import asyncio
    from chainstream import ChainStreamClient
    from chainstream.stream import Resolution, TokenCandle

    async def main():
        client = ChainStreamClient("your-access-token")

        # Subscribe to token candles
        unsub = await client.stream.subscribe_token_candles(
            chain="sol",
            token_address="So11111111111111111111111111111111111111112",
            resolution=Resolution.S1,
            callback=lambda candle: print(f"Candle: {candle}"),
        )

        await asyncio.sleep(30)
        await client.close()

    asyncio.run(main())
    ```
"""

from chainstream.client import (
    CHAINSTREAM_BASE_URL,
    CHAINSTREAM_STREAM_URL,
    ChainStreamClient,
    ChainStreamClientOptions,
    StaticTokenProvider,
    TokenProvider,
)

__version__ = "0.1.0"

__all__ = [
    "ChainStreamClient",
    "ChainStreamClientOptions",
    "TokenProvider",
    "StaticTokenProvider",
    "CHAINSTREAM_BASE_URL",
    "CHAINSTREAM_STREAM_URL",
]

