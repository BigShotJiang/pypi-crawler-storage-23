# ChainStream Python SDK

Official Python client library for ChainStream API.

## Installation

```bash
pip install chainstream-sdk
```

## Quick Start

```python
from chainstream import ChainStreamClient

# Create client
client = ChainStreamClient(access_token="your-access-token")

# Use the client for API calls...
```

## Documentation

For detailed documentation, visit [https://docs.chainstream.io](https://docs.chainstream.io)

## Development

```bash
# Install dependencies
make install

# Run tests
make test

# Lint
make lint

# Generate OpenAPI client
make python-client
```

## License

MIT
