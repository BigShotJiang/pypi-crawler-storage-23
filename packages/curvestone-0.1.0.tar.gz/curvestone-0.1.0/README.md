# Curvestone Python SDK

Python client for the [Curvestone](https://curvestone.ai) compliance API.

## Installation

```bash
pip install curvestone
```

## Quick Start

```python
from curvestone import Agent

agent = Agent()  # reads CURVESTONE_API_KEY env var

result = agent.check(
    case_type="residential_mortgage",
    depth="full_check",
    documents=[open("fact_find.pdf", "rb"), open("suitability.pdf", "rb")],
)

print(result.triage)        # "green" | "amber" | "red"
print(result.summary)       # Executive summary
print(result.findings)      # List of Finding objects
print(result.stats)         # Stats(green=35, amber=5, red=2)
```

## Low-Level Client

For more control, use the resource-based client (similar to Stripe/Anthropic SDKs):

```python
from curvestone import Curvestone

client = Curvestone(api_key="cs_live_...")

# Upload files
f = client.files.upload(open("fact_find.pdf", "rb"), purpose="check_document")

# Submit a check
job = client.checks.create(
    case_type="residential_mortgage",
    depth="full_check",
    file_ids=[f.file_id],
)

# Poll until complete
result = client.jobs.poll(job.job_id)
print(result.status)  # "completed"
print(result.result)  # Full result dict
```

## Async Support

Every method has an async equivalent:

```python
from curvestone import AsyncAgent

async def main():
    agent = AsyncAgent()
    result = await agent.check(
        case_type="residential_mortgage",
        depth="admin_check",
        documents=[open("fact_find.pdf", "rb")],
    )
    print(result.triage)
```

## Available Resources

| Resource | Methods |
|---|---|
| `client.checks` | `create()` |
| `client.jobs` | `retrieve()`, `list()`, `cancel()`, `poll()`, `stream()` |
| `client.files` | `upload()`, `retrieve()`, `delete()` |
| `client.ask` | `create()` |
| `client.generate` | `create()` |
| `client.monitors` | `create()`, `retrieve()`, `list()`, `update()`, `delete()`, `run()` |
| `client.webhooks` | `create()`, `retrieve()`, `list()`, `update()`, `delete()`, `test()` |

## Configuration

```python
from curvestone import Curvestone

client = Curvestone(
    api_key="cs_live_...",          # or set CURVESTONE_API_KEY env var
    base_url="https://...",          # default: https://agent.curvestone.ai/agent
    timeout=120.0,                   # request timeout in seconds (default: 60)
    max_retries=3,                   # retries on 429/5xx (default: 2)
)
```

## Documentation

Full API documentation: [hub.curvestone.ai/docs](https://hub.curvestone.ai/docs)
