"""Check result types."""

from __future__ import annotations

from pydantic import BaseModel


class Finding(BaseModel):
    skill: str
    question: str
    rating: str
    explanation: str
    evidence: str | None = None


class Stats(BaseModel):
    green: int = 0
    amber: int = 0
    red: int = 0


class CheckResult(BaseModel):
    triage: str
    summary: str
    key_risks: list[str] = []
    skills_executed: int = 0
    questions_answered: int = 0
    findings: list[Finding] = []
    stats: Stats = Stats()
