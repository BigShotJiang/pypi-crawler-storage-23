"""Webhook types."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class Webhook(BaseModel):
    webhook_id: str
    url: str
    events: list[str]
    description: str | None = None
    status: str
    created_at: datetime


class WebhookCreated(Webhook):
    secret: str
