"""Monitor types."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class MonitorTarget(BaseModel):
    type: str
    url: str | None = None
    platform: str | None = None
    handle: str | None = None
    source: str | None = None
    entity_id: str | None = None


class MonitorSchedule(BaseModel):
    frequency: str
    notify: list[str] = []
    webhook_url: str | None = None


class Monitor(BaseModel):
    monitor_id: str
    status: str
    targets: list[dict[str, Any]]
    schedule: dict[str, Any]
    next_run_at: datetime | None = None
    last_run_at: datetime | None = None
    created_at: datetime


class MonitorList(BaseModel):
    data: list[Monitor]
    has_more: bool
    next_cursor: str | None = None
