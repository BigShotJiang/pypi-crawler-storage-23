"""File types."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class FileObject(BaseModel):
    file_id: str
    filename: str
    size_bytes: int
    purpose: str
    content_type: str | None = None
    created_at: datetime
    download_url: str | None = None
