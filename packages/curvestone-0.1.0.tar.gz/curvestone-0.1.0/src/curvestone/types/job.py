"""Job types."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class JobCreated(BaseModel):
    job_id: str
    status: str
    estimated_seconds: int | None = None
    poll_url: str | None = None
    stream_url: str | None = None


class Job(BaseModel):
    job_id: str
    type: str
    status: str
    triage: str | None = None
    reference: str | None = None
    progress: dict[str, Any] | None = None
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class JobList(BaseModel):
    data: list[Job]
    has_more: bool
    next_cursor: str | None = None
