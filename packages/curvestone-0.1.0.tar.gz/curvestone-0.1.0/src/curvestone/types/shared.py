"""Shared enums and base types."""

from __future__ import annotations

from enum import Enum


class Triage(str, Enum):
    GREEN = "green"
    AMBER = "amber"
    RED = "red"


class JobStatus(str, Enum):
    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class CaseType(str, Enum):
    RESIDENTIAL_MORTGAGE = "residential_mortgage"
    BUY_TO_LET = "buy_to_let"
    COMMERCIAL_MORTGAGE = "commercial_mortgage"


class Depth(str, Enum):
    ADMIN_CHECK = "admin_check"
    SOFT_CHECK = "soft_check"
    FULL_CHECK = "full_check"
    MORTGAGE_CLUB_CHECK = "mortgage_club_check"


class FilePurpose(str, Enum):
    CHECK_DOCUMENT = "check_document"
    REFERENCE = "reference"
