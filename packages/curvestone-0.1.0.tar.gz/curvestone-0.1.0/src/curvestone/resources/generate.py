"""Generate resource — POST /generate."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from curvestone.types.job import JobCreated

if TYPE_CHECKING:
    from curvestone._client import AsyncCurvestone, Curvestone


class SyncGenerate:
    def __init__(self, client: Curvestone) -> None:
        self._client = client

    def create(
        self,
        *,
        type: str,
        job_id: str,
        format: str = "pdf",
        lender: str | None = None,
        template: str | None = None,
    ) -> JobCreated:
        """Generate a document from a completed check job."""
        body: dict[str, Any] = {"type": type, "job_id": job_id, "format": format}
        if lender is not None:
            body["lender"] = lender
        if template is not None:
            body["template"] = template

        resp = self._client._request("POST", "/generate", json=body)
        return JobCreated.model_validate(resp)


class AsyncGenerate:
    def __init__(self, client: AsyncCurvestone) -> None:
        self._client = client

    async def create(
        self,
        *,
        type: str,
        job_id: str,
        format: str = "pdf",
        lender: str | None = None,
        template: str | None = None,
    ) -> JobCreated:
        """Generate a document from a completed check job."""
        body: dict[str, Any] = {"type": type, "job_id": job_id, "format": format}
        if lender is not None:
            body["lender"] = lender
        if template is not None:
            body["template"] = template

        resp = await self._client._request("POST", "/generate", json=body)
        return JobCreated.model_validate(resp)
