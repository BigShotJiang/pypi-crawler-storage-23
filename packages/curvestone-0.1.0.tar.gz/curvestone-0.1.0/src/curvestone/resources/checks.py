"""Checks resource — POST /check."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from curvestone.types.job import JobCreated

if TYPE_CHECKING:
    from curvestone._client import AsyncCurvestone, Curvestone


class SyncChecks:
    def __init__(self, client: Curvestone) -> None:
        self._client = client

    def create(
        self,
        *,
        case_type: str,
        depth: str,
        file_ids: list[str] | None = None,
        variations: list[str] | None = None,
        reference: str | None = None,
        webhook_url: str | None = None,
        brokerage: str | None = None,
        config: dict | None = None,
        idempotency_key: str | None = None,
    ) -> JobCreated:
        """Submit a compliance check. Returns immediately with a job ID."""
        body: dict[str, Any] = {
            "case_type": case_type,
            "depth": depth,
        }
        if file_ids:
            body["file_ids"] = file_ids
        if variations:
            body["variations"] = variations
        if reference is not None:
            body["reference"] = reference
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if brokerage is not None:
            body["brokerage"] = brokerage
        if config is not None:
            body["config"] = config

        headers = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        resp = self._client._request("POST", "/check", json=body)
        return JobCreated.model_validate(resp)


class AsyncChecks:
    def __init__(self, client: AsyncCurvestone) -> None:
        self._client = client

    async def create(
        self,
        *,
        case_type: str,
        depth: str,
        file_ids: list[str] | None = None,
        variations: list[str] | None = None,
        reference: str | None = None,
        webhook_url: str | None = None,
        brokerage: str | None = None,
        config: dict | None = None,
        idempotency_key: str | None = None,
    ) -> JobCreated:
        """Submit a compliance check. Returns immediately with a job ID."""
        body: dict[str, Any] = {
            "case_type": case_type,
            "depth": depth,
        }
        if file_ids:
            body["file_ids"] = file_ids
        if variations:
            body["variations"] = variations
        if reference is not None:
            body["reference"] = reference
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if brokerage is not None:
            body["brokerage"] = brokerage
        if config is not None:
            body["config"] = config

        resp = await self._client._request("POST", "/check", json=body)
        return JobCreated.model_validate(resp)
