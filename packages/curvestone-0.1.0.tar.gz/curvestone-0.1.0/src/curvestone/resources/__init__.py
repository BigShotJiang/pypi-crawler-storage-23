"""Curvestone API resource classes."""
