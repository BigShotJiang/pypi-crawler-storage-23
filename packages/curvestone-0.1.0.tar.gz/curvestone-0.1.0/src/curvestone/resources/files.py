"""Files resource — /files endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, BinaryIO

from curvestone.types.file import FileObject

if TYPE_CHECKING:
    from curvestone._client import AsyncCurvestone, Curvestone


class SyncFiles:
    def __init__(self, client: Curvestone) -> None:
        self._client = client

    def upload(self, file: BinaryIO, *, purpose: str = "check_document") -> FileObject:
        """Upload a file for use in checks."""
        resp = self._client._upload("/files", file, purpose)
        return FileObject.model_validate(resp)

    def retrieve(self, file_id: str) -> FileObject:
        """Get file metadata."""
        resp = self._client._request("GET", f"/files/{file_id}")
        return FileObject.model_validate(resp)

    def delete(self, file_id: str) -> None:
        """Delete a file."""
        self._client._request("DELETE", f"/files/{file_id}")


class AsyncFiles:
    def __init__(self, client: AsyncCurvestone) -> None:
        self._client = client

    async def upload(self, file: BinaryIO, *, purpose: str = "check_document") -> FileObject:
        """Upload a file for use in checks."""
        resp = await self._client._upload("/files", file, purpose)
        return FileObject.model_validate(resp)

    async def retrieve(self, file_id: str) -> FileObject:
        """Get file metadata."""
        resp = await self._client._request("GET", f"/files/{file_id}")
        return FileObject.model_validate(resp)

    async def delete(self, file_id: str) -> None:
        """Delete a file."""
        await self._client._request("DELETE", f"/files/{file_id}")
