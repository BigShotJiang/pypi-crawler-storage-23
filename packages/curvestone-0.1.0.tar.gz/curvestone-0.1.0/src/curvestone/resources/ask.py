"""Ask resource — POST /ask."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from curvestone.types.job import JobCreated

if TYPE_CHECKING:
    from curvestone._client import AsyncCurvestone, Curvestone


class SyncAsk:
    def __init__(self, client: Curvestone) -> None:
        self._client = client

    def create(
        self,
        *,
        question: str,
        context: dict | None = None,
        thread_id: str | None = None,
    ) -> JobCreated:
        """Submit a natural-language question."""
        body: dict[str, Any] = {"question": question}
        if context is not None:
            body["context"] = context
        if thread_id is not None:
            body["thread_id"] = thread_id

        resp = self._client._request("POST", "/ask", json=body)
        return JobCreated.model_validate(resp)


class AsyncAsk:
    def __init__(self, client: AsyncCurvestone) -> None:
        self._client = client

    async def create(
        self,
        *,
        question: str,
        context: dict | None = None,
        thread_id: str | None = None,
    ) -> JobCreated:
        """Submit a natural-language question."""
        body: dict[str, Any] = {"question": question}
        if context is not None:
            body["context"] = context
        if thread_id is not None:
            body["thread_id"] = thread_id

        resp = await self._client._request("POST", "/ask", json=body)
        return JobCreated.model_validate(resp)
