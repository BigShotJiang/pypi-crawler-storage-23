"""Parsing and extraction utilities for sharepoint2text."""
