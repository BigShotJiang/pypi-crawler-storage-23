# apollo-time

极简 Apollo 配置客户端 - Python 版

## 特性

- ✅ **极简使用**：配置像变量一样直接访问，无需 `get()`
- ✅ **自动更新**：后台长轮询，配置实时同步
- ✅ **线程安全**：多线程环境下安全访问
- ✅ **变更回调**：支持监听配置变更事件
- ✅ **环境变量**：支持 `.env` 文件配置

## 安装

```bash
# 从本地安装
pip install /path/to/apollo-time

# 或从 tar.gz 安装
pip install apollo-time-0.1.0.tar.gz
```

## 快速开始

### 基础使用

```python
from apollo_time import apollo_time_config

# 直接使用配置（自动从 .env 读取连接信息）
url = apollo_time_config.RAG_SERVER_URL
db_host = apollo_time_config.DB_HOST

# 监听配置变更
apollo_time_config.on_change('API_KEY', lambda old, new: print(f"API Key 已更新"))
```

### .env 配置

```bash
# .env 文件
APOLLO_APP_ID=your_app_id
APOLLO_CLUSTER=default
APOLLO_CONFIG_URL=http://your-apollo-server:8080
APOLLO_NAMESPACE=application
```

### 手动初始化

```python
from apollo_time import init

config = init(
    app_id="my_app",
    cluster="default",
    server="http://apollo:8080",
    namespace="application"
)
```

## 高级用法

### 类型转换

```python
# 自动类型转换
port = apollo_time_config.get_int("SERVER_PORT", 8080)
debug = apollo_time_config.get_bool("DEBUG", False)
timeout = apollo_time_config.get_float("TIMEOUT", 1.5)
config_dict = apollo_time_config.get_json("FEATURES")
tags = apollo_time_config.get_list("TAGS", sep=",")
```

### Flask 集成

```python
from flask import Flask
from apollo_time import apollo_time_config

app = Flask(__name__)

@app.route('/api/config')
def get_config():
    return jsonify({
        'api_url': apollo_time_config.API_URL,
        'timeout': apollo_time_config.get_int('TIMEOUT')
    })
```

### 多实例

```python
from apollo_time import Apollo

# 创建多个独立的客户端
config1 = Apollo("app1", server="http://apollo1:8080").start()
config2 = Apollo("app2", server="http://apollo2:8080").start()
```

## 配置优先级

参数 > 环境变量 > .env 文件 > 默认值

## 常见问题

**Q: 如何禁用自动初始化？**

A: 在导入前设置环境变量：
```python
import os
os.environ['APOLLO_AUTO_INIT'] = 'false'
```

**Q: 配置多久更新一次？**

A: 使用长轮询，Apollo 有变更时立即推送，最长 70 秒。

## License

MIT
