"""
极简 Apollo 配置客户端
支持后台监听、内存缓存、动态属性访问和回调机制
"""
import requests
import threading
import time
import hashlib
import logging
import os
from typing import Any, Callable, Dict, Optional
from pathlib import Path

logger = logging.getLogger(__name__)


class Apollo:
    """极简 Apollo 客户端"""

    def __init__(
        self,
        app_id: str,
        cluster: str = "default",
        server: str = "http://localhost:8080",
        namespace: str = "application",
        timeout: int = 70
    ):
        self.app_id = app_id
        self.cluster = cluster
        self.server = server.rstrip('/')
        self.namespace = namespace
        self.timeout = timeout

        # 配置缓存
        self._config: Dict[str, str] = {}
        self._release_key: str = "-1"

        # 回调函数: {key: [callbacks]}
        self._callbacks: Dict[str, list] = {}

        # 线程控制
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def start(self) -> 'Apollo':
        """启动客户端"""
        if self._running:
            return self

        logger.info(f"🚀 启动 Apollo: {self.server}")
        self._load_config()  # 初始加载

        self._running = True
        self._thread = threading.Thread(target=self._watch, daemon=True)
        self._thread.start()
        return self

    def stop(self):
        """停止客户端"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)

    # ========== 配置访问 ==========

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值"""
        return self._config.get(key, default)

    def get_int(self, key: str, default: int = 0) -> int:
        """获取整数配置"""
        try:
            return int(self._config.get(key, default))
        except (ValueError, TypeError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """获取布尔配置"""
        v = self._config.get(key, default)
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.lower() in ('true', '1', 'yes', 'on')
        return bool(v)

    def get_float(self, key: str, default: float = 0.0) -> float:
        """获取浮点配置"""
        try:
            return float(self._config.get(key, default))
        except (ValueError, TypeError):
            return default

    def get_json(self, key: str, default: dict = None) -> dict:
        """获取 JSON 配置"""
        import json
        v = self._config.get(key)
        if not v:
            return default or {}
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            return default or {}

    def get_list(self, key: str, sep: str = ',', default: list = None) -> list:
        """获取列表配置"""
        v = self._config.get(key, '')
        if not v:
            return default or []
        return [x.strip() for x in v.split(sep) if x.strip()]

    # ========== 动态属性访问 ==========

    def __getattr__(self, key: str) -> Any:
        """支持 config.key_name 访问，自动从缓存读取最新值"""
        # 防止递归
        if key.startswith('_'):
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{key}'")
        return self.get(key)

    def __getitem__(self, key: str) -> Any:
        """支持 config['key'] 访问"""
        return self.get(key)

    # ========== 回调机制 ==========

    def on_change(self, key: str, callback: Callable[[Any, Any], None]):
        """注册配置变更回调"""
        if key not in self._callbacks:
            self._callbacks[key] = []
        self._callbacks[key].append(callback)
        logger.debug(f"注册回调: {key}")

    def _trigger_callbacks(self, key: str, old_val: Any, new_val: Any):
        """触发回调"""
        if key in self._callbacks:
            for cb in self._callbacks[key]:
                try:
                    cb(old_val, new_val)
                except Exception as e:
                    logger.error(f"回调失败 [{key}]: {e}")

    # ========== 内部实现 ==========

    def _load_config(self):
        """加载配置"""
        url = f"{self.server}/configs/{self.app_id}/{self.cluster}/{self.namespace}"
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                data = r.json()
                configs = data.get('configurations', {})
                release_key = data.get('releaseKey', '')

                with self._lock:
                    old_config = self._config.copy()
                    self._config = configs
                    self._release_key = release_key

                # 触发变更回调
                for key, new_val in configs.items():
                    old_val = old_config.get(key)
                    if old_val != new_val:
                        self._trigger_callbacks(key, old_val, new_val)
                        logger.info(f"配置变更: {key} = {old_val} → {new_val}")

                logger.info(f"✅ 加载配置: {len(configs)} 项")

        except Exception as e:
            logger.error(f"加载配置失败: {e}")

    def _watch(self):
        """后台监听配置变更"""
        logger.info("👀 开始监听配置变更")
        while self._running:
            try:
                self._long_poll()
            except Exception as e:
                logger.error(f"监听异常: {e}")
                time.sleep(5)

    def _long_poll(self):
        """长轮询"""
        # 计算 notificationId
        notification_id = int(hashlib.md5(self._release_key.encode()).hexdigest()[:8], 16)

        url = f"{self.server}/notifications/v2"
        params = {
            "appId": self.app_id,
            "cluster": self.cluster,
            "notifications": f'[{{"namespaceName":"{self.namespace}","notificationId":{notification_id}}}]'
        }

        try:
            r = requests.get(url, params=params, timeout=self.timeout, allow_redirects=False)

            if r.status_code == 302:  # 需要认证
                logger.warning("Apollo 需要认证")
                time.sleep(10)
                return

            if r.status_code == 200:  # 有变更
                logger.info("🔔 检测到配置变更")
                self._load_config()

            # 304 表示无变更，正常

        except requests.Timeout:
            pass  # 长轮询超时是正常的
        except Exception as e:
            logger.debug(f"长轮询异常: {e}")

    def __repr__(self):
        return f"<Apollo {self.app_id} {len(self._config)} configs>"


# 全局单例
_client: Optional[Apollo] = None
apollo_time_config: Optional[Apollo] = None  # 全局配置实例，方便直接使用


def _load_env(env_file: str = ".env") -> Dict[str, str]:
    """加载 .env 文件"""
    env_vars = {}
    env_path = Path(env_file)

    if env_path.exists():
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key.strip()] = value.strip()
                    # 同时设置到环境变量
                    os.environ[key.strip()] = value.strip()

    return env_vars


def init(
    app_id: str = None,
    cluster: str = None,
    server: str = None,
    namespace: str = None,
    env_file: str = ".env"
) -> Apollo:
    """
    初始化全局 Apollo 客户端

    优先级：参数 > 环境变量 > .env 文件 > 默认值
    """
    # 加载 .env 文件
    _load_env(env_file)

    # 获取配置（支持参数覆盖）
    app_id = app_id or os.getenv("APOLLO_APP_ID", "application")
    cluster = cluster or os.getenv("APOLLO_CLUSTER", "default")
    server = server or os.getenv("APOLLO_CONFIG_URL", "http://localhost:8080")
    namespace = namespace or os.getenv("APOLLO_NAMESPACE", "application")

    global _client, apollo_time_config
    _client = Apollo(app_id, cluster, server, namespace).start()
    apollo_time_config = _client
    return _client


def get() -> Optional[Apollo]:
    """获取全局 Apollo 客户端"""
    return _client

# 自动初始化（如果 .env 存在）
def _auto_init():
    """尝试自动初始化 - 智能查找 .env 文件"""
    global apollo_time_config

    # 检查环境变量是否禁用自动初始化
    if os.getenv('APOLLO_AUTO_INIT', 'true').lower() == 'false':
        return

    if apollo_time_config is None:
        # 按优先级查找 .env 文件
        env_candidates = [
            # 1. 当前工作目录
            os.path.join(os.getcwd(), '.env'),
            # 2. 用户主目录
            os.path.join(os.path.expanduser('~'), '.env'),
        ]

        # 3. 从当前目录向上查找，最多 5 层
        current_dir = os.getcwd()
        for _ in range(5):
            env_candidates.append(os.path.join(current_dir, '.env'))
            parent = os.path.dirname(current_dir)
            if parent == current_dir:  # 到达根目录
                break
            current_dir = parent

        for env_file in env_candidates:
            if os.path.exists(env_file):
                try:
                    init(env_file=env_file)
                    logger.info(f"✅ Apollo 自动初始化成功 (从 {env_file})")
                    return
                except Exception as e:
                    logger.debug(f"尝试从 {env_file} 初始化失败: {e}")

# 导入时自动初始化
_auto_init()

# 导出
__all__ = ['Apollo', 'init', 'get', 'apollo_time_config']




