"""SovereignEG Python client — the main SDK entrypoint."""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator, Iterator
from pathlib import Path

import httpx

from sovereigneg.exceptions import (
    APIError,
    AuthenticationError,
    QuotaExceededError,
    RateLimitError,
    SovereignEGError,
)

DEFAULT_BASE_URL = "https://api.sovereigneg.ai"
DEFAULT_TIMEOUT = 120.0
DEFAULT_MAX_RETRIES = 2


class ChatCompletion:
    """A chat completion response."""

    def __init__(self, data: dict):
        self._data = data
        self.id: str = data.get("id", "")
        self.model: str = data.get("model", "")
        self.choices: list[dict] = data.get("choices", [])
        self.usage: dict = data.get("usage", {})
        self.created: int = data.get("created", 0)
        self.rag_sources: list[dict] = data.get("rag_sources", [])

    @property
    def content(self) -> str:
        """Get the assistant's response text."""
        if self.choices:
            msg = self.choices[0].get("message", {})
            return msg.get("content", "")
        return ""

    @property
    def total_tokens(self) -> int:
        return self.usage.get("total_tokens", 0)

    @property
    def has_rag(self) -> bool:
        """Whether RAG context was used for this response."""
        return len(self.rag_sources) > 0

    def __repr__(self):
        rag = f", rag_sources={len(self.rag_sources)}" if self.rag_sources else ""
        return f"ChatCompletion(id={self.id!r}, content={self.content[:60]!r}...{rag})"


class ChatStream:
    """An iterator over streamed chat chunks."""

    def __init__(self, response: httpx.Response):
        self._response = response
        self._content_parts: list[str] = []

    def __iter__(self) -> Iterator[str]:
        for line in self._response.iter_lines():
            if not line or not line.startswith("data: "):
                continue
            data = line[6:]
            if data.strip() == "[DONE]":
                return
            try:
                chunk = json.loads(data)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    self._content_parts.append(content)
                    yield content
            except json.JSONDecodeError:
                continue

    @property
    def full_content(self) -> str:
        return "".join(self._content_parts)

    def close(self):
        self._response.close()


class AsyncChatStream:
    """An async iterator over streamed chat chunks."""

    def __init__(self, response: httpx.Response):
        self._response = response
        self._content_parts: list[str] = []

    async def __aiter__(self) -> AsyncIterator[str]:
        async for line in self._response.aiter_lines():
            if not line or not line.startswith("data: "):
                continue
            data = line[6:]
            if data.strip() == "[DONE]":
                return
            try:
                chunk = json.loads(data)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    self._content_parts.append(content)
                    yield content
            except json.JSONDecodeError:
                continue

    @property
    def full_content(self) -> str:
        return "".join(self._content_parts)

    async def close(self):
        await self._response.aclose()


class Embedding:
    """An embedding response."""

    def __init__(self, data: dict):
        self._data = data
        self.model: str = data.get("model", "")
        self.embeddings: list[list[float]] = [item["embedding"] for item in data.get("data", [])]
        self.usage: dict = data.get("usage", {})

    @property
    def embedding(self) -> list[float]:
        """Get the first embedding (convenience for single-input calls)."""
        return self.embeddings[0] if self.embeddings else []

    def __repr__(self):
        dim = len(self.embedding) if self.embeddings else 0
        return f"Embedding(dim={dim}, count={len(self.embeddings)})"


class DocumentUpload:
    """A document upload response."""

    def __init__(self, data: dict):
        self.document_id: str = data.get("document_id", "")
        self.document_name: str = data.get("document_name", "")
        self.chunks_stored: int = data.get("chunks_stored", 0)
        self.total_characters: int = data.get("total_characters", 0)

    def __repr__(self):
        return f"DocumentUpload(id={self.document_id!r}, chunks={self.chunks_stored})"


class SearchResult:
    """A single search result from RAG retrieval."""

    def __init__(self, data: dict):
        self.text: str = data.get("text", "")
        self.document_name: str = data.get("document_name", "")
        self.document_id: str = data.get("document_id", "")
        self.score: float = data.get("score", 0.0)

    def __repr__(self):
        return f"SearchResult(doc={self.document_name!r}, score={self.score:.3f})"


# ──────────────────────────────────────────────────────────
# Main Client
# ──────────────────────────────────────────────────────────
class SovereignEG:
    """SovereignEG API client.

    Usage:
        client = SovereignEG(api_key="sk-seg-...")

        # Chat
        response = client.chat("What is AI?")
        print(response.content)

        # Streaming
        for token in client.chat("Tell me a story", stream=True):
            print(token, end="", flush=True)

        # Embeddings
        emb = client.embed("Hello world")
        print(emb.embedding[:5])

        # RAG
        client.upload("report.pdf")
        results = client.search("quarterly revenue")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        tenant_id: str | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not api_key:
            raise AuthenticationError("API key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.tenant_id = tenant_id
        self.max_retries = max_retries

        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "sovereigneg-python/0.1.0",
            },
            timeout=timeout,
        )

    def _handle_error(self, response: httpx.Response) -> None:
        """Convert HTTP errors into SDK exceptions."""
        if response.status_code == 200 or response.status_code == 201:
            return

        try:
            body = response.json()
        except Exception:
            body = {"detail": response.text}

        detail = body.get("detail", str(body))
        if isinstance(detail, dict):
            detail = detail.get("error", str(detail))

        if response.status_code == 401:
            raise AuthenticationError(detail, response.status_code, body)
        elif response.status_code == 429:
            msg = body.get("detail", {})
            if isinstance(msg, dict) and "quota" in str(msg).lower():
                raise QuotaExceededError(detail, response.status_code, body)
            raise RateLimitError(detail, response.status_code, body)
        else:
            raise APIError(detail, response.status_code, body)

    def _request_with_retry(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Execute an HTTP request with automatic retry on 429 and 5xx.

        Uses exponential backoff. Respects Retry-After header from the server.
        Does NOT retry on 401 (auth) or 4xx (client error).
        """
        last_exc: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(method, path, **kwargs)

                if response.status_code in (200, 201):
                    return response

                # Retry on 429 (rate limited) or 5xx (server error)
                if response.status_code == 429 or response.status_code >= 500:
                    if attempt < self.max_retries:
                        retry_after = float(response.headers.get("Retry-After", "0"))
                        delay = max(retry_after, 0.5 * (2 ** attempt))
                        time.sleep(delay)
                        continue

                # Non-retryable error or retries exhausted
                return response

            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    time.sleep(0.5 * (2 ** attempt))
                    continue
                raise SovereignEGError(f"Connection failed after {self.max_retries + 1} attempts: {exc}")

        raise SovereignEGError(f"Request failed after retries: {last_exc}")

    # ── Chat ──
    def chat(
        self,
        message: str,
        *,
        model: str = "default",
        system: str | None = None,
        messages: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False,
        use_rag: bool = False,
        rag_top_k: int = 5,
    ) -> ChatCompletion | ChatStream:
        """Send a chat completion request.

        Args:
            message: The user message (simple mode).
            model: Model to use.
            system: Optional system prompt.
            messages: Full message list (overrides message/system).
            temperature: Sampling temperature.
            max_tokens: Max response tokens.
            stream: If True, returns a ChatStream iterator.
            use_rag: If True, retrieve relevant docs and augment the prompt.
            rag_top_k: Number of document chunks to retrieve for RAG.

        Returns:
            ChatCompletion (non-stream) or ChatStream (stream).
        """
        if messages is None:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": message})

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
            "use_rag": use_rag,
            "rag_top_k": rag_top_k,
        }

        if stream:
            # Streaming requests are not retried (connection is held open)
            response = self._client.send(
                self._client.build_request("POST", "/v1/chat/completions", json=payload),
                stream=True,
            )
            if response.status_code != 200:
                response.read()
                self._handle_error(response)
            return ChatStream(response)
        else:
            response = self._request_with_retry("POST", "/v1/chat/completions", json=payload)
            self._handle_error(response)
            return ChatCompletion(response.json())

    # ── Embeddings ──
    def embed(
        self,
        input: str | list[str],
        *,
        model: str = "default",
    ) -> Embedding:
        """Generate embeddings for text.

        Args:
            input: A string or list of strings to embed.
            model: Embedding model to use.

        Returns:
            Embedding object with .embedding or .embeddings.
        """
        response = self._request_with_retry(
            "POST", "/v1/embeddings",
            json={"model": model, "input": input},
        )
        self._handle_error(response)
        return Embedding(response.json())

    # ── RAG: Upload ──
    def upload(
        self,
        file_path: str | Path,
        *,
        tenant_id: str | None = None,
    ) -> DocumentUpload:
        """Upload a document for RAG.

        Args:
            file_path: Path to PDF, DOCX, or TXT file.
            tenant_id: Tenant ID (uses self.tenant_id if not provided).

        Returns:
            DocumentUpload with document_id and chunks_stored.
        """
        tid = tenant_id or self.tenant_id
        if not tid:
            raise SovereignEGError("tenant_id is required for document upload")

        path = Path(file_path)
        if not path.exists():
            raise SovereignEGError(f"File not found: {file_path}")

        # Use a separate client without JSON content-type for multipart
        with open(path, "rb") as f:
            response = httpx.post(
                f"{self.base_url}/documents/upload",
                files={"file": (path.name, f)},
                data={"tenant_id": tid},
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "User-Agent": "sovereigneg-python/0.1.0",
                },
                timeout=self.timeout,
            )

        self._handle_error(response)
        return DocumentUpload(response.json())

    # ── RAG: Search ──
    def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        tenant_id: str | None = None,
    ) -> list[SearchResult]:
        """Search uploaded documents.

        Args:
            query: Natural language search query.
            top_k: Number of results to return.
            tenant_id: Tenant ID (uses self.tenant_id if not provided).

        Returns:
            List of SearchResult objects.
        """
        tid = tenant_id or self.tenant_id
        if not tid:
            raise SovereignEGError("tenant_id is required for search")

        response = httpx.post(
            f"{self.base_url}/documents/search",
            json={"tenant_id": tid, "query": query, "top_k": top_k},
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "sovereigneg-python/0.1.0",
            },
            timeout=self.timeout,
        )
        self._handle_error(response)
        data = response.json()
        return [SearchResult(r) for r in data.get("results", [])]

    # ── Cleanup ──
    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self):
        return f"SovereignEG(base_url={self.base_url!r})"
