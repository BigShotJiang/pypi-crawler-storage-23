"""SovereignEG Python SDK — Sovereign AI on Egyptian Infrastructure."""

from sovereigneg.client import SovereignEG
from sovereigneg.exceptions import (
    APIError,
    AuthenticationError,
    QuotaExceededError,
    RateLimitError,
    SovereignEGError,
)

__version__ = "0.1.0"
__all__ = [
    "SovereignEG",
    "SovereignEGError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "APIError",
]
