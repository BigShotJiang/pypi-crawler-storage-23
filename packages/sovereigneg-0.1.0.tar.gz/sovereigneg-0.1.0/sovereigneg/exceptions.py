"""SDK exceptions."""


class SovereignEGError(Exception):
    """Base exception for SovereignEG SDK."""

    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None):
        self.message = message
        self.status_code = status_code
        self.body = body or {}
        super().__init__(message)


class AuthenticationError(SovereignEGError):
    """Raised when API key is invalid or missing."""

    pass


class RateLimitError(SovereignEGError):
    """Raised when rate limit is exceeded (HTTP 429)."""

    @property
    def retry_after(self) -> float:
        """Seconds to wait before retrying. Parsed from error body or defaults to 1."""
        detail = self.body.get("detail", {})
        if isinstance(detail, dict):
            error = detail.get("error", {})
            if isinstance(error, dict):
                return float(error.get("retry_after", 1.0))
        return 1.0


class QuotaExceededError(SovereignEGError):
    """Raised when monthly token quota is exceeded."""

    pass


class APIError(SovereignEGError):
    """Raised for general API errors."""

    pass
