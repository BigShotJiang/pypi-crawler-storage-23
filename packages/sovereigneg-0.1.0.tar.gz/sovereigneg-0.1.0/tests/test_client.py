"""Unit tests for the SovereignEG Python SDK — no server needed."""

import pytest
from sovereigneg import SovereignEG
from sovereigneg.client import ChatCompletion, DocumentUpload, Embedding, SearchResult
from sovereigneg.exceptions import (
    AuthenticationError,
    SovereignEGError,
)

# ── Client Initialization ──


def test_client_requires_api_key():
    with pytest.raises(AuthenticationError, match="API key is required"):
        SovereignEG(api_key="")


def test_client_creates_with_valid_key():
    client = SovereignEG(api_key="sk-seg-test123", base_url="http://localhost:8000")
    assert client.api_key == "sk-seg-test123"
    assert client.base_url == "http://localhost:8000"
    client.close()


def test_client_strips_trailing_slash():
    client = SovereignEG(api_key="sk-seg-test", base_url="http://localhost:8000/")
    assert client.base_url == "http://localhost:8000"
    client.close()


def test_client_stores_tenant_id():
    client = SovereignEG(api_key="sk-seg-test", tenant_id="tenant-123")
    assert client.tenant_id == "tenant-123"
    client.close()


def test_client_context_manager():
    with SovereignEG(api_key="sk-seg-test") as client:
        assert client.api_key == "sk-seg-test"


def test_client_repr():
    client = SovereignEG(api_key="sk-seg-test", base_url="http://localhost:8000")
    assert "localhost:8000" in repr(client)
    client.close()


# ── Response Classes ──


def test_chat_completion_parsing():
    data = {
        "id": "chatcmpl-123",
        "model": "default",
        "choices": [{"message": {"role": "assistant", "content": "Hello!"}, "index": 0}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        "created": 1700000000,
    }
    resp = ChatCompletion(data)
    assert resp.id == "chatcmpl-123"
    assert resp.model == "default"
    assert resp.content == "Hello!"
    assert resp.total_tokens == 15
    assert resp.has_rag is False
    assert resp.rag_sources == []


def test_chat_completion_with_rag():
    data = {
        "id": "chatcmpl-456",
        "model": "default",
        "choices": [{"message": {"role": "assistant", "content": "Based on the report..."}}],
        "usage": {"total_tokens": 25},
        "rag_sources": [{"document_name": "report.pdf", "score": 0.95, "text": "Revenue is $10M"}],
    }
    resp = ChatCompletion(data)
    assert resp.has_rag is True
    assert len(resp.rag_sources) == 1
    assert resp.rag_sources[0]["document_name"] == "report.pdf"


def test_chat_completion_empty_choices():
    resp = ChatCompletion({"id": "empty"})
    assert resp.content == ""
    assert resp.total_tokens == 0


def test_embedding_parsing():
    data = {
        "model": "default",
        "data": [
            {"embedding": [0.1, 0.2, 0.3], "index": 0},
            {"embedding": [0.4, 0.5, 0.6], "index": 1},
        ],
        "usage": {"prompt_tokens": 8, "total_tokens": 8},
    }
    resp = Embedding(data)
    assert resp.model == "default"
    assert len(resp.embeddings) == 2
    assert resp.embedding == [0.1, 0.2, 0.3]  # first embedding shorthand


def test_embedding_empty():
    resp = Embedding({})
    assert resp.embedding == []
    assert resp.embeddings == []


def test_document_upload_parsing():
    data = {
        "document_id": "doc-abc",
        "document_name": "report.pdf",
        "chunks_stored": 12,
        "total_characters": 5432,
    }
    resp = DocumentUpload(data)
    assert resp.document_id == "doc-abc"
    assert resp.document_name == "report.pdf"
    assert resp.chunks_stored == 12
    assert resp.total_characters == 5432


def test_search_result_parsing():
    data = {
        "text": "Revenue was $10M in Q4",
        "document_name": "report.pdf",
        "document_id": "doc-abc",
        "score": 0.95,
    }
    result = SearchResult(data)
    assert result.text == "Revenue was $10M in Q4"
    assert result.document_name == "report.pdf"
    assert result.score == 0.95


# ── Error Classes ──


def test_authentication_error():
    err = AuthenticationError("Invalid key", 401, {"detail": "bad key"})
    assert err.status_code == 401
    assert err.message == "Invalid key"
    assert "bad key" in str(err.body)


def test_sovereign_error_base():
    err = SovereignEGError("Something went wrong")
    assert str(err) == "Something went wrong"
    assert err.status_code is None
    assert err.body == {}


# ── Input Validation ──


def test_upload_requires_tenant_id():
    client = SovereignEG(api_key="sk-seg-test")
    with pytest.raises(SovereignEGError, match="tenant_id is required"):
        client.upload("/tmp/test.txt")
    client.close()


def test_search_requires_tenant_id():
    client = SovereignEG(api_key="sk-seg-test")
    with pytest.raises(SovereignEGError, match="tenant_id is required"):
        client.search("test query")
    client.close()


def test_upload_nonexistent_file():
    client = SovereignEG(api_key="sk-seg-test", tenant_id="t-1")
    with pytest.raises(SovereignEGError, match="File not found"):
        client.upload("/tmp/definitely_not_a_real_file_12345.txt")
    client.close()
