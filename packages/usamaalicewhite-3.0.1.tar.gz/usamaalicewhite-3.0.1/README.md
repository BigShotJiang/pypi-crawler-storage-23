Copyright 2026 UsamaAliceWhite All Rights Reserved


## ------ Core ------
### 説明  
メタクラスなどの基底システムに関連するライブラリ。

### 関数
SingletonPattern
- シングルトンパターン。メタクラスとして利用。


## ------ Desktop ------
### 説明
モニターやマウスなどデスクトップに関連するライブラリ。

### 関数
get_monitor_geometry()
- モニターの幾何学情報（x,y,width,height）を取得する。


## ------ Log ------
### 説明
「アプリケーション全体でログを一元管理する」「簡単にログが出力出来る」  
これらをコンセプトとし開発している。  
本機能はアプリ全体で一つの設定を共有する。  
その為、初回に設定した内容がアプリ終了時まで維持される。  
維持されている間は変更が出来ない。  

### 関数
Declaration()
- ログの設定を行う。
- Emitter()を呼び出す前に1度のみ実行可能。以降は無視される。
- 初期値は「毎日0時にログファイルのローテーションを行う。なお過去ファイルは30ファイルまで保存される。

Emitter()
- ログの書き込みを行う。
- Declaration()を呼び出さずに利用可能。その際は初期値が適応される。

### サンプルコード
```
from UsamaAliceWhite import Log

def main():
    Declaration(file_path= "C:/Logs/memory.log")
    Emitter(message= "In Python we trust.")

if __name__ == "__main__":
    main()
```


## ------ Media ------
### 説明
MP4やPNGなど動画・画像に関連するライブラリ。

### 関数
video_download()
- Webサイトから動画（MP4）をダウンロードする。利用規約等は対象のWebサイトに準ずる。


## ------ ディレクトリ構造 ------
```
UsamaAliceWhite/
├── Core/
│   ├── __init__.py
│   ├── Pattern.py
│   └── py.typed
├── Desktop/
│   ├── __init__.py
│   ├── Monitor.py
│   └── py.typed
├── Log/
│   ├── Core/
│   │   ├── __init__.py
│   │   ├── Handler.py
│   │   └── Logger.py
│   ├── Share/
│   │   ├── __init__.py
│   │   └── Pattern.py
│   ├── __init__.py
│   └── py.typed
├── Media/
│   ├── __init__.py
│   ├── py.typed
│   └── Video.py
├── LICENSE
├── pyproject.toml
└── README.md
```