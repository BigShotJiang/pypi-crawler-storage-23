# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 自作モジュール
from .Monitor import get_monitor_geometry


# 公開API
__all__ = ["get_monitor_geometry"]