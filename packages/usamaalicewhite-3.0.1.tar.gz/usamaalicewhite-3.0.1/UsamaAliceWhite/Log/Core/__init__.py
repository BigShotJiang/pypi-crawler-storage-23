# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 標準モジュール
import datetime
import inspect
import logging
import pathlib

# 自作モジュール
from .Handler import HandlerManager, HandlerParameter
from .Logger import LoggerManager, LoggerParameter


# 公開API
__all__ = ["Declaration", "Emitter"]


# --- ログの設定 ---
class Declaration:
    """
    Parameter:
        log_file_path:
            ログファイルの保存先のパス
        log_message_format:
            ログの出力形式
        log_datetime_format:
            ログの日時の出力形式
        handler_when:
            ログのローテーションの間隔
            - S : 秒
            - M : 分
            - H : 時
            - D : 日
            - midnight : 00時00分
            - W0 - W6 : W0=月曜日、W6=日曜日
        handler_interval:
            ログのローテーションの頻度
        handler_backupcount:
            保持するバックアップファイルの上限数
        handler_encoding:
            ログファイルの文字コード
        handler_delay:
            ログファイルの作成タイミングの遅延
            - True  : 初回のログ出力時にログファイルを作成
            - False : ログハンドラの作成時にログファイルを作成
        handler_utc:
            使用する基準時刻
            - True  : 世界標準時
            - False : ローカル時刻
        handler_attime:
            ログのローテーションの時刻
        handler_errors:
            ファイル書き込み時の文字コードに関するエラー表示
        handler_level:
            ログハンドラのログレベル
            - 10 or logging.DEBUG
            - 20 or logging.INFO
            - 30 or logging.WARNING
            - 40 or logging.ERROR
            - 50 or logging.CRITICAL
    """
    def __new__(cls,
                log_file_path: pathlib.Path | str = pathlib.Path.home() / "Anonymous.log",
                *,
                log_message_format: str = "%(asctime)s [%(levelname)-8s] %(name)-20s:%(funcName)-20s:%(lineno)-4d - %(message)s",
                log_datetime_format: str = "%Y-%m-%d %H:%M:%S",
                handler_when: str = "midnight",
                handler_interval: int = 1,
                handler_backupcount: int = 30,
                handler_encoding: str | None = "utf-8",
                handler_delay: bool = False,
                handler_utc: bool = False,
                handler_attime: datetime.time | None = None,
                handler_errors: str | None = None,
                handler_level: int = logging.DEBUG
                ) -> None:
        HandlerManager(HandlerParameter(
            file_path= pathlib.Path(log_file_path),
            when= handler_when,
            interval= handler_interval,
            backupcount= handler_backupcount,
            encoding= handler_encoding,
            delay= handler_delay,
            utc= handler_utc,
            attime= handler_attime,
            errors= handler_errors,
            level= handler_level,
            message_format= log_message_format,
            datetime_format= log_datetime_format
        ))


# --- ログの出力 ---
class Emitter:
    """
    Parameter:
        message:
            ログに出力する文字
        logger_name:
            ロガー名（初期値はファイル名）
        logger_level:
            ロガーのログレベル
            - 10 or logging.DEBUG
            - 20 or logging.INFO
            - 30 or logging.WARNING
            - 40 or logging.ERROR
            - 50 or logging.CRITICAL
    """
    def __new__(cls,
                message: str,
                *,
                logger_name: str | None = None,
                logger_level: int = logging.DEBUG
                ) -> None:
        logger_name = logger_name or pathlib.Path(inspect.stack()[1].filename).stem
        handler_manager: HandlerManager = HandlerManager()
        logger_manager: LoggerManager = LoggerManager(LoggerParameter(
            handler= handler_manager.create_handler(),
            name= logger_name,
            level= logger_level
        ))
        logger: logging.Logger = logger_manager.create_logger()
        logger.log(level= logger_level, msg= message, stacklevel= 2)