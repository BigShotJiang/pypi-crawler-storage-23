# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 自作モジュール
from .Pattern import SingletonPattern


# 公開API
__all__ = ["SingletonPattern"]