# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 標準モジュール
import pathlib

# サードパーティーライブラリ
import yt_dlp


# --- ダウンロード機能 ---
def video_download(url: str, file_path: pathlib.Path | str) -> None:
    """
    Parameter:
        url = 動画のURL
        file_path = 保存先のファイルパス
    """
    options: dict[str, str | bool] = {
        "format": "best[ext=mp4]",
        "outtmpl": str(file_path),
        "quiet": False,
        "no_warnings": False,
        "noplaylist": True
    }
    try:
        directory_path: pathlib.Path = file_path.parent
        directory_path.mkdir(parents= True, exist_ok= True)
    except Exception as e:
        raise RuntimeError("Failed to create directory.") from e

    try:
        with yt_dlp.YoutubeDL(params= options) as downloader:
            downloader.download(url_list= [url])
    except Exception as e:
        raise RuntimeError("Download failed.") from e