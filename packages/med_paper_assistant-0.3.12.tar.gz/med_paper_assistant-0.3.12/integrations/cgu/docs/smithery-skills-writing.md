# Smithery Skills - Writing 類別精選

> 來源：[smithery.ai/skills](https://smithery.ai/skills?category=Writing)
> 總數：2,956 個 Skills
> 整理日期：2025-12-16

## Top 15 Writing Skills

| # | 名稱 | 作者 | 說明 | 適用場景 |
|---|------|------|------|----------|
| 1 | **pptx** | anthropics | 簡報建立/編輯/分析：版面、註解、講者備註 | PowerPoint 簡報 |
| 2 | **docx** | anthropics | 文件建立/編輯：追蹤修訂、註解、格式保留 | Word 文件 |
| 3 | **content-creator** | alirezarezvani | SEO 優化內容：品牌聲音、社群模板、內容日曆 | 部落格、社群行銷 |
| 4 | **skill-development** | anthropics | Skill 撰寫指南：結構、漸進式揭露、最佳實踐 | Claude Code Plugin 開發 |
| 5 | **workthrough** | bear2u | 自動記錄開發工作為結構化文件 | 開發文件記錄 |
| 6 | **email-composer** | davila7 | 專業郵件撰寫：商業、技術、客服 | Email 撰寫 |
| 7 | **theme-factory** | anthropics | 主題樣式工具：10種預設主題，支援自訂 | 簡報/文件/網頁樣式 |
| 8 | **scientific-writing** | K-Dense-AI | 科學論文：IMRAD、引用、圖表、報告指南 | 學術論文 |
| 9 | **youtube-wisdom** | sammcj | YouTube 影片洞見萃取：重點、引言、摘要 | 影片內容分析 |
| 10 | **docs-review** | metabase | 文件審查：遵循 Metabase 寫作風格 | 文件 PR 審查 |
| 11 | **content-trend-researcher** | alirezarezvani | 跨平台趨勢分析生成文章大綱 | 內容企劃 |
| 12 | **docstring** | pytorch | PyTorch 風格 docstring 撰寫 | Python 文件字串 |
| 13 | **claude-code-analyzer** | nicknisi | Claude Code 使用分析與建議 | 工作流優化 |
| 14 | **literature-review** | K-Dense-AI | 系統性文獻回顧：多資料庫、多引用格式 | 學術研究 |
| 15 | **deepwiki-rs** | sopaco | AI 驅動 Rust 文件生成：C4 架構圖 | 技術文件 |

---

## 文件處理類

| 名稱 | 說明 |
|------|------|
| `pptx` | PowerPoint 簡報建立/編輯 |
| `docx` | Word 文件建立/編輯/追蹤修訂 |
| `theme-factory` | 文件/簡報主題樣式 |

## 內容創作類

| 名稱 | 說明 |
|------|------|
| `content-creator` | SEO 優化行銷內容 |
| `email-composer` | 專業郵件撰寫 |
| `content-trend-researcher` | 趨勢分析與內容企劃 |

## 技術文件類

| 名稱 | 說明 |
|------|------|
| `workthrough` | 開發工作自動文件化 |
| `docstring` | PyTorch 風格文件字串 |
| `deepwiki-rs` | Rust 程式碼文件生成 |
| `skill-development` | Claude Skill 撰寫指南 |

## 學術寫作類

| 名稱 | 說明 |
|------|------|
| `scientific-writing` | 科學論文撰寫 |
| `literature-review` | 系統性文獻回顧 |

---

## 對 CGU 專案的參考價值

| Skill | CGU 可借鏡之處 |
|-------|----------------|
| `workthrough` | 📝 自動文件化可用於創意 Session 記錄 |
| `theme-factory` | 🎨 創意報告的樣式主題系統 |
| `content-creator` | 📊 創意發想結果的內容化輸出 |

---

*下一個類別：Planning*
