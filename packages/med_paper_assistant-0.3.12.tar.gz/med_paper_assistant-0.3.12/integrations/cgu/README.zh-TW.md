# CGU - Creativity Generation Unit

> 🧠 MCP-based Agent-to-Agent 創意發想服務，採用「快思慢想」架構

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![MCP](https://img.shields.io/badge/MCP-FastMCP-green.svg)](https://github.com/modelcontextprotocol)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## ✨ 特色

- 🚀 **快思慢想架構** - 多個快速小步驟 + 慢速大步驟組合
- 🎨 **16 種創意方法** - SCAMPER、六頂思考帽、心智圖、九宮格等
- 🔌 **MCP 協議** - 標準化的 Agent-to-Agent 通訊
- 🤖 **LangGraph 編排** - 靈活的思考流程控制
- 🏠 **本地推理** - Ollama + Qwen 支援，隱私優先
- 🔄 **思考引擎切換** - Ollama 本地思考 / Copilot 框架模式

## 🏗️ 架構

```
┌─────────────────────────────────────────────────────────┐
│                    CGU Architecture                      │
├─────────────────────────────────────────────────────────┤
│  ┌─────────┐    ┌─────────┐    ┌─────────┐             │
│  │  MCP    │───▶│ LangGraph│───▶│  Ollama │             │
│  │ Server  │    │  Agent   │    │   LLM   │             │
│  └─────────┘    └─────────┘    └─────────┘             │
│       │              │                                   │
│       ▼              ▼                                   │
│  ┌─────────────────────────────────────┐               │
│  │         Creativity Methods          │               │
│  │  SCAMPER │ 六頂帽 │ 九宮格 │ ...    │               │
│  └─────────────────────────────────────┘               │
└─────────────────────────────────────────────────────────┘
```

## 📦 安裝

```bash
# 使用 uv（推薦）
uv sync

# 或使用 pip
pip install -e .
```

## 🚀 快速開始

### CLI 使用

```bash
# 生成創意點子
cgu generate "如何提升團隊創造力"

# 概念碰撞
cgu spark "人工智慧" "傳統手工藝"

# 使用特定方法
cgu apply scamper "智慧手錶"

# 查看可用方法
cgu methods
```

### MCP Server

```bash
# 啟動 MCP Server
cgu-server
```

### 程式碼使用

```python
from cgu.graph import run_cgu
from cgu.core import CreativityLevel

# 運行創意生成
result = await run_cgu(
    topic="未來的教育方式",
    creativity_level=CreativityLevel.L2_EXPLORATORY,
    target_count=5,
)

for idea in result["final_ideas"]:
    print(f"💡 {idea.content}")
```

## 🎯 創意層級

| 層級 | 名稱 | 關聯性 | 說明 |
|------|------|--------|------|
| L1 | 組合創意 | 0.7-1.0 | 已知元素的新組合 |
| L2 | 探索創意 | 0.3-0.7 | 在既有規則內探索邊界 |
| L3 | 變革創意 | 0.0-0.3 | 打破規則，創造新範式 |

## 🧰 創意方法

### 發散類
- 🧠 心智圖 (Mind Map)
- 💡 腦力激盪 (Brainstorm)
- 🔄 SCAMPER 檢核表
- 🎲 隨機輸入法

### 結構類
- 📊 曼陀羅九宮格
- 🔬 形態分析法
- ❓ 5W2H
- 🐟 魚骨圖

### 觀點類
- 🎩 六頂思考帽
- 👥 角色扮演法
- 🔄 逆向思考法

## ⚙️ 配置

### 環境變數

```bash
# .env 配置
CGU_USE_LLM=true                          # 啟用 LLM
CGU_LLM_PROVIDER=ollama                   # 思考引擎：ollama / copilot
OLLAMA_BASE_URL=http://localhost:11434/v1  # Ollama 地址
OLLAMA_MODEL=qwen2.5:3b                    # 模型名稱
```

### 思考引擎模式

| 模式 | 說明 |
|------|------|
| `ollama` | 使用本地 Ollama 模型思考（預設） |
| `copilot` | 僅提供方法框架，讓 Copilot/Claude 填充內容 |

### VS Code MCP 配置

將 `.vscode/mcp.json` 放在專案根目錄：

```json
{
  "servers": {
    "cgu": {
      "type": "stdio",
      "command": "uv",
      "args": ["--directory", "${workspaceFolder}", "run", "cgu-server"],
      "env": {
        "CGU_USE_LLM": "true",
        "CGU_LLM_PROVIDER": "ollama"
      }
    },
    "cgu-copilot": {
      "type": "stdio", 
      "command": "uv",
      "args": ["--directory", "${workspaceFolder}", "run", "cgu-server"],
      "env": {
        "CGU_USE_LLM": "true",
        "CGU_LLM_PROVIDER": "copilot"
      }
    }
  }
}
```

在 VS Code 中使用 `MCP: List Servers` 選擇啟動哪個模式。

## 🔧 開發

```bash
# 安裝開發依賴
uv sync --all-extras

# 運行測試
pytest

# 程式碼檢查
ruff check src/
```

## 📚 文檔

- [創意生成單元概念](docs/creativity-generation-unit.md)
- [API 參考](docs/api.md)
- [MCP 工具說明](docs/mcp-tools.md)

## 📄 授權

MIT License - 詳見 [LICENSE](LICENSE)

---

<p align="center">
  Made with 💡 by CGU Team
</p>
