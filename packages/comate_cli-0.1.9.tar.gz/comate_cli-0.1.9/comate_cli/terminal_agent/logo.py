from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from rich.console import Console
from rich.text import Text

_LOGO_LINES: tuple[str, ...] = (
    "",
    "  ██████╗ ██████╗ ███╗   ███╗ █████╗ ████████╗███████╗",
    " ██╔════╝██╔═══██╗████╗ ████║██╔══██╗╚══██╔══╝██╔════╝",
    " ██║     ██║   ██║██╔████╔██║███████║   ██║   █████╗  ",
    " ██║     ██║   ██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝  ",
    " ╚██████╗╚██████╔╝██║ ╚═╝ ██║██║  ██║   ██║   ███████╗",
    "  ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝",
)


def _lerp_rgb(
    start_rgb: tuple[int, int, int],
    end_rgb: tuple[int, int, int],
    ratio: float,
) -> tuple[int, int, int]:
    clamped = max(0.0, min(1.0, ratio))
    r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * clamped)
    g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * clamped)
    b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * clamped)
    return r, g, b


def _resolve_version() -> str:
    try:
        return f"v{version('comate-cli')}"
    except PackageNotFoundError:
        try:
            return f"v{version('comate-agent-sdk')}"
        except PackageNotFoundError:
            return "v0.1.0-dev"


def _format_directory_for_display(project_root: Path) -> str:
    resolved_root = project_root.expanduser().resolve()
    home = Path.home().expanduser().resolve()
    if resolved_root == home:
        return "~/"
    return str(resolved_root)


def print_logo(console: Console, *, project_root: Path | None = None) -> None:
    resolved_root = (project_root or Path.cwd()).expanduser().resolve()
    start_rgb = (67, 114, 240)
    end_rgb = (54, 214, 220)
    line_count = len(_LOGO_LINES)

    ver = _resolve_version()
    logo_text = Text()
    for idx, line in enumerate(_LOGO_LINES):
        ratio = idx / max(line_count - 1, 1)
        r, g, b = _lerp_rgb(start_rgb, end_rgb, ratio)
        logo_text.append(line, style=f"bold rgb({r},{g},{b})")
        if idx == line_count - 1:
            logo_text.append(f"  {ver}", style="dim")
        if idx < line_count - 1:
            logo_text.append("\n")

    console.print(logo_text)
    console.print()
    console.print(
        Text(
            f"  directory: {_format_directory_for_display(resolved_root)}",
            style="dim",
        )
    )
    console.print()
