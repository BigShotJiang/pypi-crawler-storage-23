from __future__ import annotations

import time
import unittest
from unittest.mock import patch

from comate_cli.terminal_agent.tui import TerminalAgentTUI


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def append_elapsed_message(self, content: str) -> None:
        self.messages.append(content)


class TestTUIElapsedStatus(unittest.TestCase):
    def test_append_run_elapsed_uses_interrupted_phrase(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._renderer = _FakeRenderer()
        tui._run_start_time = time.monotonic() - 11.0

        tui._append_run_elapsed_to_history(stop_reason="interrupted")

        self.assertTrue(tui._renderer.messages)
        self.assertTrue(tui._renderer.messages[-1].startswith("Interrupted after "))

    def test_append_run_elapsed_uses_default_verb_when_not_interrupted(self) -> None:
        tui = TerminalAgentTUI.__new__(TerminalAgentTUI)
        tui._renderer = _FakeRenderer()
        tui._run_start_time = time.monotonic() - 11.0

        with patch("comate_cli.terminal_agent.tui.random.choice", return_value="Resolved"):
            tui._append_run_elapsed_to_history(stop_reason="completed")

        self.assertEqual(tui._renderer.messages[-1], "Resolved in 11s")


if __name__ == "__main__":
    unittest.main()
