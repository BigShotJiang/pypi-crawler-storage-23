import math
import matplotlib.pyplot as plt
import numpy as np
from .Generaldistribution import Distribution


class Binomial(Distribution):

    """
    Binomial distribution class for calculating and visualizing
    a Binomial distribution.
    """

    def __init__(self, p=0.5, n=20):
        self.p = p
        self.n = n

        mean = self.calculate_mean()
        stdev = self.calculate_stdev()

        super().__init__(mean, stdev)

    def calculate_mean(self):
        self.mean = self.p * self.n
        return self.mean

    def calculate_stdev(self):
        self.stdev = math.sqrt(self.n * self.p * (1 - self.p))
        return self.stdev

    def replace_stats_with_data(self):
        """
        Calculate p and n from dataset
        """

        self.n = len(self.data)
        self.p = sum(self.data) / float(self.n)

        self.mean = self.calculate_mean()
        self.stdev = self.calculate_stdev()

        return self.p, self.n

    def plot_bar(self):
        """
        Plot bar chart of outcomes
        """

        plt.bar(
            x=['0', '1'],
            height=[(1 - self.p) * self.n, self.p * self.n]
        )

        plt.title('Bar Chart of Data')
        plt.xlabel('Outcome')
        plt.ylabel('Count')
        plt.show()

    def pdf(self, k):
        """
        Binomial probability density function
        """

        factor_1 = math.factorial(self.n) / (
            math.factorial(k) * math.factorial(self.n - k)
        )

        factor_2 = (self.p ** k) * ((1 - self.p) ** (self.n - k))

        return factor_1 * factor_2

    def plot_pdf_bar(self):
        """
        Plot probability distribution
        """

        x = []
        y = []

        for k in range(self.n + 1):
            x.append(k)
            y.append(self.pdf(k))

        plt.bar(x, y)
        plt.title('Binomial Distribution')
        plt.xlabel('k')
        plt.ylabel('Probability')
        plt.show()

        return x, y

    def __add__(self, other):

        if self.p != other.p:
            raise ValueError("p values are not equal")

        result = Binomial(self.p, self.n + other.n)

        return result

    def __repr__(self):
        return "mean {}, standard deviation {}, p {}, n {}".format(
            self.mean, self.stdev, self.p, self.n
        )