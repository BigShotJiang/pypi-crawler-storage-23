from setuptools import setup, find_packages

setup(
    name="jyothi_binomial_distribution",
    version="1.3",
    description="A Python package for binomial and gaussian distributions",
    author="Jyothi",
    packages=['jyothi_binomial_distribution'],
    install_requires=[
        "numpy",
        "matplotlib"
    ],
    python_requires=">=3.7",
)