"""
One Bathymetry file that covers the whole coast of BC and 5 substrate files that togethercover the whole coast of BC.
"""
