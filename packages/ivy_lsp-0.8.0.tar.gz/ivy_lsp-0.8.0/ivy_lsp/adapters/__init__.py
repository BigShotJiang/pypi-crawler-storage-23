"""Adapter layer isolating ivy internal imports behind Protocol interfaces."""
