"""Unified semantic model for the Ivy LSP analysis pipeline."""
