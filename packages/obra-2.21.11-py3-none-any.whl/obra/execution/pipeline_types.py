"""Typed pipeline contracts for LLM subprocess invocation.

This module defines the three-stage typed pipeline:
1. CommandSpec: High-level LLM invocation intent
2. ProviderSpec: Provider-specific command construction
3. ExecSpec: Final subprocess.Popen-ready specification

All types are frozen dataclasses to enforce immutability through the pipeline.
Shell injection prevention is enforced via ExecSpec.shell = Literal[False].
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal
import uuid


@dataclass(frozen=True)
class CommandSpec:
    """High-level specification for LLM subprocess invocation intent.

    This is the first stage of the pipeline, capturing what the user wants
    to do with the LLM (text generation, code execution, model selection, etc.).

    Fields are provider-agnostic and describe user intent, not implementation.
    `allowed_tools` restricts tool usage when supported by the provider/runtime.
    A unique spec_id is assigned at creation and carried through all pipeline stages.
    """

    provider: str
    model: str
    mode: Literal['text', 'execute']
    response_format: Literal['json', 'text']
    thinking_level: str
    provider_reasoning_level: str | None
    cwd: Path
    streaming: bool
    timeout_s: int
    auth_method: str
    codex_config: dict | None  # For bypass_sandbox/approval_mode/skip_git_check
    allowed_tools: list[str] | None = None
    spec_id: str = field(default_factory=lambda: str(uuid.uuid4()))


@dataclass(frozen=True)
class ProviderSpec:
    """Provider-specific command construction specification.

    This is the second stage, translating CommandSpec into provider-specific
    argv, environment, and execution details. Each provider (Anthropic, OpenAI,
    Google, Ollama) has its own builder function that produces a ProviderSpec.

    The spec_id from CommandSpec is preserved for correlation across pipeline stages.
    """

    argv: list[str]
    cli_executable: str
    env_overrides: dict[str, str]
    prompt_delivery: Literal['file', 'inline', 'stdin']
    stdin_content: str | None
    use_absolute_paths: bool
    provider_meta: dict
    spec_id: str


@dataclass(frozen=True)
class ExecSpec:
    """Final subprocess.Popen-ready execution specification.

    This is the third and final stage, ready to pass directly to subprocess.Popen.
    All platform-specific and provider-specific logic has been resolved.

    Security constraint: shell is Literal[False] to prevent shell injection.
    Any attempt to construct ExecSpec with shell=True will fail at runtime.

    The spec_id from CommandSpec is preserved for end-to-end correlation.
    """

    cmd: list[str]
    env: dict[str, str]
    cwd: str
    encoding: str
    preexec_fn: Callable | None
    shell: Literal[False]  # Security: shell injection prevention
    timeout_s: int
    streaming: bool
    temp_files: list[str]
    spec_id: str

    def __post_init__(self):
        """Enforce shell=False at runtime (Literal check happens at type-check time)."""
        if self.shell is not False:
            raise TypeError(
                'ExecSpec.shell must be False — shell injection prevention. '
                'Use list[str] cmd format instead of shell string.'
            )
