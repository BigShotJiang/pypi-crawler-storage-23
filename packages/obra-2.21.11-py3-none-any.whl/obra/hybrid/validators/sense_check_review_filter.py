"""SenseCheck review filter response parser."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from obra.api.protocol import ValidatorResult


@dataclass
class ReviewFilterResult:
    """Result from review filter validation."""

    sound: bool
    decisions: list[dict[str, Any]]


def _normalize_decision(decision: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(decision)
    issue_id = decision.get("issue_id") or decision.get("id") or ""
    if issue_id:
        normalized["issue_id"] = str(issue_id).strip()
    agent_type = decision.get("agent_type") or ""
    if agent_type:
        normalized["agent_type"] = str(agent_type).strip()
    action = decision.get("action")
    if action is not None:
        normalized["action"] = str(action).strip().lower()
    for key in ("original_priority", "adjusted_priority"):
        if key in normalized and normalized[key] is not None:
            normalized[key] = str(normalized[key]).strip()
    if "is_band_aid" in normalized:
        value = normalized["is_band_aid"]
        if isinstance(value, str):
            normalized["is_band_aid"] = value.strip().lower() in {"true", "yes", "1"}
        elif isinstance(value, (int, float)):
            normalized["is_band_aid"] = bool(value)
    return normalized


def _coerce_decisions(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("Review filter decisions must be a list")

    decisions: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            if item:
                decisions.append(_normalize_decision(item))
            continue
        if item is None:
            continue
        reason = str(item).strip()
        if reason:
            decisions.append({"reason": reason})
    return decisions


def parse_review_filter_response(response: str) -> ValidatorResult:
    """Parse SenseCheck review filter response into ValidatorResult.

    Args:
        response: Raw LLM response from review filter SenseCheck prompt.

    Returns:
        ValidatorResult with decisions populated.
    """
    if response is None or not response.strip():
        raise ValueError("Review filter response was empty")

    stripped = response.strip()
    if stripped.upper() == "SOUND":
        return ValidatorResult(sound=True)

    try:
        data = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Review filter response was not valid JSON: {exc!s}") from exc

    if not isinstance(data, dict):
        raise ValueError("Review filter JSON response must be an object")

    decisions = _coerce_decisions(data.get("filter_decisions") or data.get("decisions"))

    result = ReviewFilterResult(
        sound=not decisions,
        decisions=decisions,
    )

    return ValidatorResult(
        sound=result.sound,
        decisions=result.decisions,
    )
