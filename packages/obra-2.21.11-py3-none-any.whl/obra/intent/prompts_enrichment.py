"""Prompt builders for intent enrichment stages."""

from __future__ import annotations

from collections.abc import Iterable

__all__ = [
    "build_assumptions_prompt",
    "build_assumptions_template",
    "build_brief_prompt",
    "build_brief_template",
    "build_expert_alignment_prompt",
    "build_expert_alignment_template",
    "build_review_prompt",
]


def build_assumptions_prompt(
    objective: str,
    intent_markdown: str,
    non_inferable_categories: Iterable[str],
    *,
    unresolved_questions: Iterable[str] | None = None,
    non_inferable_questions: Iterable[str] | None = None,
    resolved_inputs: Iterable[dict[str, str]] | None = None,
    proceed_override: bool = False,
) -> str:
    """Build prompt for assumptions + question generation.

    Args:
        objective: The user's objective.
        intent_markdown: Current intent rendered as markdown.
        non_inferable_categories: Categories that require user input.
        unresolved_questions: Previously asked general questions.
        non_inferable_questions: Previously asked non-inferable questions.
        resolved_inputs: User-confirmed answers from prior passes. Each dict has
            keys: ``question``, ``answer``, ``type`` (``"direct"`` or ``"delegated"``).
        proceed_override: If True, instruct the LLM not to ask further questions.
    """
    categories = ", ".join(non_inferable_categories)
    prior_questions = "\n".join(f"- {q}" for q in (unresolved_questions or []))
    prior_non_inferable = "\n".join(f"- {q}" for q in (non_inferable_questions or []))

    # Build resolved inputs section (FIX-ENRICHMENT-INTEGRATION-001)
    resolved_section = ""
    if resolved_inputs:
        lines: list[str] = []
        for inp in resolved_inputs:
            q = inp.get("question", "")
            a = inp.get("answer", "")
            inp_type = inp.get("type", "direct")
            if inp_type == "delegated":
                lines.append(f"- {q}: User delegates decision [DELEGATED — make reasonable assumption, add to assumptions]")
            else:
                lines.append(f"- {q}: {a} [DIRECT — incorporate into requirements/constraints]")
        resolved_block = "\n".join(lines)
        resolved_section = (
            "\nUSER-CONFIRMED INPUTS (RESOLVED — incorporate into your structured output):\n"
            f"{resolved_block}\n\n"
            "IMPORTANT: These topics are RESOLVED. Do not include them in "
            "quality_signal.missing_sections. Do not re-ask these questions. "
            "Incorporate direct answers into assumptions_add or constraints_add. "
            "Convert delegated decisions into explicit assumptions.\n"
        )

    prior_section = ""
    if prior_questions or prior_non_inferable:
        prior_section = "\nPreviously asked questions (do not repeat):\n"
        if prior_questions:
            prior_section += f"{prior_questions}\n"
        if prior_non_inferable:
            prior_section += f"{prior_non_inferable}\n"
    override_section = ""
    if proceed_override:
        override_section = (
            "\nProceed override is set. Do not ask new questions. "
            "Return empty lists for questions and non_inferable_questions.\n"
        )
    return f"""You are refining a user intent before planning.

Objective:
"{objective}"

Current intent:
{intent_markdown}
{resolved_section}{prior_section}{override_section}

Task:
1) Identify missing context or assumptions required to plan successfully.
2) Generate explicit questions for gaps that CANNOT be safely inferred.
3) Keep answers intent-level (requirements/constraints), not implementation details.

Non-inferable categories (ASK if these are missing or ambiguous):
- {categories}

IMPORTANT - Question Generation Rules:
- For VAGUE objectives (short, underspecified): You MUST ask 1-3 clarifying questions.
  A vague objective lacks specific requirements, constraints, or acceptance criteria.
- For RICH objectives (detailed specs): Questions are optional, only for true ambiguities.
- When in doubt, ASK. Wrong assumptions waste more time than asking.

Lean guidance:
- Focus on minimum viable scope.
- Do not add speculative features or future-proofing.
- Keep questions few, high-impact, and answerable in one sentence.
- Ask for acceptance criteria or constraints when missing.
- Do not repeat prior questions.
- You may ask user questions via the questions list, but NEVER run interactive shell commands.

Quality check:
- Set ready_to_proceed: false if the objective is vague and you have questions.
- Set ready_to_proceed: true only if you have enough context to plan confidently.

IMPORTANT: Edit the provided template file following its structural format. Do not respond with prose. Use the template structure to record your analysis.
"""


def build_expert_alignment_prompt(
    objective: str,
    intent_markdown: str,
    analogue_cache: str | None = None,
) -> str:
    cache_section = ""
    if analogue_cache:
        cache_section = f"\nAnalogue cache (use only if relevant):\n{analogue_cache}\n"

    return f"""You are performing expert-aligned intent enrichment.

Objective:
"{objective}"

Current intent:
{intent_markdown}
{cache_section}

Task:
1) Infer domain(s) and expert roles (include top 2 if ambiguous).
2) Describe how experts in those domains approach similar problems.
3) Compare current intent to expert approach and identify gaps.
4) Propose intent-level updates only (requirements, constraints, non-goals, risks, acceptance criteria, assumptions).

Lean expert guidance:
- Focus on minimum viable steps.
- Do NOT add speculative features, future-proofing, or extra abstractions.
- Prefer reversible, incremental scope.
- Flag scope creep explicitly.

IMPORTANT: Edit the provided template file following its structural format. Do not respond with prose. Use the template structure to record your analysis.
"""


def build_brief_prompt(objective: str, intent_markdown: str) -> str:
    return f"""You are consolidating an updated intent after expert alignment.

Objective:
"{objective}"

Current intent:
{intent_markdown}

Task:
- Produce a cleaned, consolidated intent with the same sections.
- Keep it lean and scoped to the objective.
- Do NOT add speculative features or implementation details.

IMPORTANT: Edit the provided template file following its structural format. Do not respond with prose. Use the template structure to record your consolidated intent.
"""


def build_review_prompt(
    objective: str,
    intent_markdown: str,
    story_json: str,
    tasks_json: str,
) -> str:
    """Build a story-level review prompt.

    Reviews a single story and its tasks for correctness and completeness.
    Designed for one-pass, parsimonious evaluation.
    """
    return f"""Review this story for correctness and completeness.

## Context

Objective: "{objective}"

Intent:
{intent_markdown}

## Story to Review

{story_json}

## Tasks for This Story

{tasks_json}

## Evaluate

1. Are tasks sufficient to complete the story's acceptance criteria?
2. Any over-engineering, unnecessary abstraction, or scope drift?
3. Any missing tasks required to complete the story?
4. Do tasks have clear, actionable descriptions?

## Guidelines

- Favor minimal viable scope
- Do NOT add speculative features or extra abstractions
- Each task should be atomic and directly serve the story

## Output

Edit the template file to record your review:
- changes_required: true if any issues found, false if story is sound
- issues: list each issue concisely (empty array if none)
- tasks: corrected task array if changes needed (omit or [] if no changes)

### Task Schema (REQUIRED when tasks are provided)
Each task MUST be a full task object with:
- id: "E#.S#.T#"
- item_type: "task"
- title: string
- description: string
- acceptance_criteria: array of strings (can be empty)
- dependencies: array of item IDs (can be empty)
- parent_id: MUST equal the story id under review

Rules:
- Do NOT return partial task objects (no missing fields)
- Do NOT invent epic/story IDs; use the story id provided
- If you cannot produce valid tasks, set changes_required=false and tasks=[]

You MUST edit the file to record your conclusion.
"""


def build_assumptions_template() -> dict:
    """Build template for assumptions + question generation stage.

    Returns:
        Template dict with schema structure and _instructions for LLM guidance.
    """
    return {
        "assumptions_add": [
            "<FILL: assumption>",
            "<FILL: assumption>",
            "<FILL: assumption>",
        ],
        "constraints_add": [
            "<FILL: constraint>",
            "<FILL: constraint>",
        ],
        "questions": [],
        "non_inferable_questions": [],
        "quality_signal": {
            "ready_to_proceed": False,
            "missing_sections": []
        },
        "rationale": "<FILL: rationale>",
        "_instructions": (
            "Add assumptions to assumptions_add array (explicit assumptions required "
            "for planning). Add constraints to constraints_add array. Add general "
            "clarification questions to questions array. Add questions that MUST be "
            "answered by the user to non_inferable_questions array. Set "
            "ready_to_proceed to true only if you have enough context to plan "
            "confidently. List missing sections in missing_sections array if the "
            "objective is vague. Provide a short rationale."
        )
    }


def build_brief_template() -> dict:
    """Build template for brief generation stage.

    Returns:
        Template dict with schema structure and _instructions for LLM guidance.
    """
    return {
        "problem_statement": "<FILL: problem statement>",
        "assumptions": [],
        "requirements": [],
        "constraints": [],
        "acceptance_criteria": [],
        "non_goals": [],
        "risks": [],
        "context_items": [
            "<FILL: context item>",
            "<FILL: context item>",
        ],
        "_instructions": (
            "Produce a cleaned, consolidated intent with all sections filled. "
            "Keep it lean and scoped to the objective. Do NOT add speculative "
            "features or implementation details. Add relevant context items to "
            "context_items array."
        )
    }


def build_expert_alignment_template() -> dict:
    """Build template for expert alignment stage.

    Returns:
        Template dict with schema structure and _instructions for LLM guidance.
    """
    return {
        "domain_inference": [
            {
                "domain": "<FILL: domain>",
                "confidence": 0.0,
                "expert_roles": ["<FILL: expert role>"]
            }
        ],
        "expert_approach": ["<FILL: expert approach>"],
        "intent_gaps": [],
        "expert_perspective": "<FILL: expert perspective>",
        "technical_considerations": [
            "<FILL: technical consideration>",
            "<FILL: technical consideration>",
            "<FILL: technical consideration>",
        ],
        "patterns": [
            "<FILL: pattern>",
            "<FILL: pattern>",
        ],
        "proposed_intent_updates": {
            "assumptions_add": [],
            "requirements_add": [],
            "constraints_add": [],
            "non_goals_add": [],
            "risks_add": [],
            "acceptance_criteria_add": []
        },
        "rationale": "<FILL: rationale>",
        "_instructions": (
            "Infer the domain(s) and expert roles (include top 2 if ambiguous). "
            "Describe how experts in those domains approach similar problems "
            "(expert_approach array). Provide expert perspective on the problem. "
            "List technical considerations (3 slots). Identify relevant patterns "
            "(2 slots). Compare current intent to expert approach and identify "
            "gaps (intent_gaps array). Propose intent-level updates only in "
            "proposed_intent_updates. Focus on minimum viable steps. Do NOT add "
            "speculative features or future-proofing. Provide a short rationale."
        )
    }
