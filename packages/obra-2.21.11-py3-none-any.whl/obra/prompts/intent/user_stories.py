"""LLM prompt templates for user story generation.

This module provides prompts for generating user stories with verification
methods from intent documents. Generated stories include acceptance criteria,
proof commands for automated verification, and manual steps for non-automatable
scenarios.

Design philosophy:
    - Generate concrete, testable user stories from abstract intent
    - Include domain-specific verification patterns (API, CLI, library)
    - Ground stories in intent requirements and acceptance criteria
    - Support both automated and manual verification methods

Related:
    - docs/design/prds/USER_STORY_QA_GATE_PRD.md
    - obra/intent/models.py (UserStory, VerificationMethod, ProofType)
    - obra/intent/user_story_generator.py
"""

from obra.intent.models import IntentModel


def build_user_story_generation_prompt(
    objective: str,
    intent: IntentModel,
    project_context: str | None = None,
    max_stories: int = 10,
) -> str:
    """Build LLM prompt for user story generation from intent.

    Args:
        objective: Original user objective
        intent: Enriched intent document with requirements and acceptance criteria
        project_context: Optional project context (file listing, framework info)
        max_stories: Maximum number of stories to generate

    Returns:
        Formatted prompt string for LLM

    Example:
        >>> from obra.intent.models import IntentModel
        >>> intent = IntentModel(
        ...     objective="add auth",
        ...     problem_statement="Need user authentication",
        ...     requirements=["Secure login", "Token-based auth"],
        ...     acceptance_criteria=["Users can log in", "Sessions persist"]
        ... )
        >>> prompt = build_user_story_generation_prompt("add auth", intent)
        >>> "VerificationMethod" in prompt
        True
        >>> "proof_command" in prompt
        True
    """
    # Build context sections
    intent_context = _build_intent_context(intent)
    project_ctx = _build_project_context_section(project_context) if project_context else ""
    domain_patterns = _build_domain_patterns(objective)

    return f"""Generate user stories with verification methods from this intent.

OBJECTIVE:
{objective}

{intent_context}{project_ctx}
USER STORY SCHEMA:

You must generate a JSON array of UserStory objects. Each story has these fields:

- id (str): Story identifier in format "US-1", "US-2", etc. (sequential numbering)
- role (str): User role (e.g., "developer", "end user", "system admin")
- action (str): What the user wants to do (e.g., "authenticate via OAuth")
- outcome (str): Why they want to do it / expected benefit (e.g., "secure access without managing passwords")
- verification_method (str): One of: "automated", "manual", "not_verifiable"
- proof_type (str | null): For automated stories, one of: "cli_command", "api_call", "file_exists", "file_content", "test_suite", "manual"
- proof_command (str | null): For automated stories, the exact command to verify (e.g., "curl -X POST /api/auth/login -d '{{"user":"test"}}'")
- proof_expected (str | null): For automated stories, what the proof_command should output/return
- preconditions (list[str] | null): Any setup required before verification
- manual_steps (list[str] | null): For manual verification, ordered steps to verify

VERIFICATION METHOD VALUES:
- automated: Can be verified programmatically via proof_command
- manual: Requires human verification via manual_steps checklist
- not_verifiable: No concrete verification possible (conceptual/exploratory work)

PROOF TYPE VALUES (for automated stories):
- cli_command: Shell command invocation (e.g., "pytest tests/test_auth.py -v")
- api_call: HTTP request (e.g., "curl -X GET /api/health")
- file_exists: Check file presence (e.g., "test -f config/auth.yaml")
- file_content: Verify file contents (e.g., "grep 'AUTH_ENABLED=true' .env")
- test_suite: Run test suite (e.g., "npm test")
- manual: Human verification (use "manual" verification_method instead)

{domain_patterns}
VALIDATION RULES:
- If verification_method is "automated", proof_command MUST be provided (not null)
- If verification_method is "manual", manual_steps MUST be provided and non-empty
- If verification_method is "not_verifiable", both proof_command and manual_steps should be null
- Generate at most {max_stories} stories
- Each story should be independently verifiable
- Stories should trace to specific requirements or acceptance criteria from the intent

OUTPUT FORMAT:
Return a JSON array of UserStory objects. Example:

[
  {{
    "id": "US-1",
    "role": "developer",
    "action": "run authentication tests",
    "outcome": "verify auth logic works correctly",
    "verification_method": "automated",
    "proof_type": "cli_command",
    "proof_command": "pytest tests/test_auth.py -v --tb=short",
    "proof_expected": "exit code 0, all tests pass",
    "preconditions": ["test environment configured", "test database seeded"],
    "manual_steps": null
  }},
  {{
    "id": "US-2",
    "role": "end user",
    "action": "log in with username and password",
    "outcome": "access protected resources",
    "verification_method": "manual",
    "proof_type": null,
    "proof_command": null,
    "proof_expected": null,
    "preconditions": ["test user account exists"],
    "manual_steps": [
      "Navigate to /login",
      "Enter test credentials",
      "Click login button",
      "Verify redirect to dashboard",
      "Verify session cookie present"
    ]
  }}
]

Generate the stories now as a JSON array.
"""


def _build_intent_context(intent: IntentModel) -> str:
    """Build intent context section for the prompt.

    Args:
        intent: Intent document to extract context from

    Returns:
        Formatted intent context string
    """
    sections = ["INTENT CONTEXT:"]

    if hasattr(intent, "problem_statement") and intent.problem_statement:
        sections.append(f"\nProblem Statement:\n{intent.problem_statement}")

    if hasattr(intent, "requirements") and intent.requirements:
        sections.append("\nRequirements:")
        for i, req in enumerate(intent.requirements, 1):
            sections.append(f"{i}. {req}")

    if hasattr(intent, "acceptance_criteria") and intent.acceptance_criteria:
        sections.append("\nAcceptance Criteria:")
        for i, criterion in enumerate(intent.acceptance_criteria, 1):
            sections.append(f"{i}. {criterion}")

    return "\n".join(sections) + "\n"


def _build_project_context_section(project_context: str) -> str:
    """Build project context section for the prompt.

    Args:
        project_context: JSON-serialized project context dict

    Returns:
        Formatted project context string
    """
    return f"""
PROJECT CONTEXT:
{project_context}

Use this context to ground your stories in the actual project structure and frameworks.
"""


def _build_domain_patterns(objective: str) -> str:
    """Build domain-specific verification patterns based on objective.

    Args:
        objective: User objective string

    Returns:
        Domain-specific pattern guidance
    """
    patterns = []
    objective_lower = objective.lower()

    # API/REST patterns
    if any(kw in objective_lower for kw in ["api", "endpoint", "rest", "graphql", "http"]):
        patterns.append("""
API/REST VERIFICATION PATTERNS:
- Use curl commands with -X <METHOD> /api/path
- Include -d '{"payload": "here"}' for POST/PUT
- Verify HTTP status codes (200, 201, 404, etc.)
- Check response body structure
Example: "curl -X GET http://localhost:8000/api/users -H 'Accept: application/json'"
""")

    # CLI/Command patterns
    if any(kw in objective_lower for kw in ["cli", "command", "script", "tool"]):
        patterns.append("""
CLI VERIFICATION PATTERNS:
- Use actual command invocations
- Verify exit codes (0 for success, non-zero for failure)
- Check stdout/stderr output
- Include relevant flags
Example: "python script.py --check && echo $? # should be 0"
""")

    # Library/Package patterns
    if any(kw in objective_lower for kw in ["library", "package", "module", "import"]):
        patterns.append("""
LIBRARY/PACKAGE VERIFICATION PATTERNS:
- Use import statements or usage examples
- Verify function/class availability
- Check version requirements
Example: "python -c 'from mylib import MyClass; print(MyClass.__version__)'"
""")

    # If no specific patterns matched, provide generic guidance
    if not patterns:
        patterns.append("""
GENERIC VERIFICATION PATTERNS:
- For testing: Use test runner commands (pytest, jest, go test, etc.)
- For file operations: Use file existence checks, content verification
- For builds: Use build commands (make, npm run build, cargo build, etc.)
- For services: Use health checks, status endpoints
""")

    return "\n".join(patterns)
