"""Simple LLM Configuration View widget.

Provides a simple interface with a one-click provider selector that auto-populates
detailed settings, plus manual override capability for orchestrator and implementation.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Label, Rule, Select, Static

from obra.config.explorer.llm_registry import (
    build_authoritative_llm_preview,
    get_model_default_reasoning,
    get_model_cost,
    get_models,
    get_providers,
    resolve_tier_model_display,
)
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin

REASONING_LEVELS = ["off", "low", "medium", "high", "extra high", "maximum"]


class SimpleLLMView(SaveableViewMixin, Static):
    """Simple LLM configuration view with one-click provider + detailed settings.

    Features:
    - One-Click Setting: Pick a provider and auto-populate all settings
    - Detailed Settings: Manual control over orchestrator and implementation
      providers and models (4 dropdowns total)

    Emits:
        Changed: When any configuration changes.
    """

    DEFAULT_CSS = """
    SimpleLLMView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    SimpleLLMView > Vertical {
        width: 100%;
        height: 100%;
        align: center top;
    }

    SimpleLLMView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
        min-width: 80;
    }

    SimpleLLMView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    SimpleLLMView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    SimpleLLMView .section-header {
        text-style: bold;
        margin-top: 1;
        margin-bottom: 1;
        color: $primary;
    }

    SimpleLLMView .one-click-section {
        width: 100%;
        height: auto;
        padding: 1;
        background: $surface;
        margin-bottom: 1;
    }

    SimpleLLMView .one-click-row {
        width: 100%;
        height: auto;
    }

    SimpleLLMView .one-click-label {
        width: 20;
    }

    SimpleLLMView .one-click-select {
        width: 1fr;
    }

    SimpleLLMView .detailed-section {
        width: 100%;
        height: auto;
        padding: 1;
    }

    SimpleLLMView .role-section {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    SimpleLLMView .role-header {
        text-style: bold;
        margin-bottom: 0;
    }

    SimpleLLMView .role-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    SimpleLLMView .role-label {
        width: 15;
    }

    SimpleLLMView .role-select {
        width: 1fr;
    }

    SimpleLLMView .model-hint {
        color: $text-muted;
        margin-left: 15;
        margin-bottom: 1;
    }

    SimpleLLMView .model-hint-resolved {
        color: $success;
    }

    SimpleLLMView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
    }

    SimpleLLMView .preview-box {
        width: 100%;
        height: auto;
        min-height: 6;
        margin-top: 2;
        padding: 1 2;
        background: $surface;
        border: solid $primary-darken-2;
        text-align: left;
    }

    SimpleLLMView .preview-title {
        text-style: bold;
        margin-bottom: 1;
    }

    SimpleLLMView .preview-content {
        color: $text;
    }

    SimpleLLMView Rule {
        margin: 1 0;
    }
    """

    class Changed(Message):
        """Message emitted when LLM configuration changes."""

        def __init__(
            self,
            orchestrator_provider: str,
            orchestrator_model: str,
            orchestrator_reasoning: str,
            implementation_provider: str,
            implementation_model: str,
            implementation_reasoning: str,
        ) -> None:
            """Initialize the Changed message.

            Args:
                orchestrator_provider: Selected orchestrator provider ID
                orchestrator_model: Selected orchestrator model ID
                orchestrator_reasoning: Selected orchestrator reasoning level
                implementation_provider: Selected implementation provider ID
                implementation_model: Selected implementation model ID
                implementation_reasoning: Selected implementation reasoning level
            """
            super().__init__()
            self.orchestrator_provider = orchestrator_provider
            self.orchestrator_model = orchestrator_model
            self.orchestrator_reasoning = orchestrator_reasoning
            self.implementation_provider = implementation_provider
            self.implementation_model = implementation_model
            self.implementation_reasoning = implementation_reasoning

    def __init__(
        self,
        current_provider: str = "anthropic",
        current_model: str = "default",
        current_reasoning: str = "medium",
        orchestrator_provider: str | None = None,
        orchestrator_model: str | None = None,
        orchestrator_reasoning: str | None = None,
        orchestrator_tiers: dict[str, Any] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_model: str | None = None,
        implementation_reasoning: str | None = None,
        implementation_tiers: dict[str, Any] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
        role_configs: dict[str, dict[str, Any]] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the SimpleLLMView.

        Args:
            current_provider: Default provider (for backward compat)
            current_model: Default model (for backward compat)
            current_reasoning: Default reasoning level (for backward compat)
            orchestrator_provider: Orchestrator provider (overrides current_provider)
            orchestrator_model: Orchestrator model (overrides current_model)
            orchestrator_reasoning: Orchestrator reasoning level
            orchestrator_tiers: Orchestrator tier models from authoritative config
            orchestrator_reasoning_tiers: Orchestrator tier reasoning from authoritative config
            implementation_provider: Implementation provider (overrides current_provider)
            implementation_model: Implementation model (overrides current_model)
            implementation_reasoning: Implementation reasoning level
            implementation_tiers: Implementation tier models from authoritative config
            implementation_reasoning_tiers: Implementation tier reasoning from authoritative config
            role_configs: Optional explicit llm.roles.* overrides from Menu 3
        """
        from obra.config.explorer.debug import is_debug_enabled, log_action

        super().__init__(**kwargs)
        # Use explicit values or fall back to current_provider/model
        self._orchestrator_provider = orchestrator_provider or current_provider
        self._orchestrator_model = orchestrator_model or current_model
        self._orchestrator_reasoning = orchestrator_reasoning or current_reasoning
        self._implementation_provider = implementation_provider or current_provider
        self._implementation_model = implementation_model or current_model
        self._implementation_reasoning = implementation_reasoning or current_reasoning
        # Authoritative preview state (includes child overrides)
        self._orchestrator_tiers = orchestrator_tiers or {
            "fast": self._orchestrator_model,
            "medium": self._orchestrator_model,
            "high": self._orchestrator_model,
        }
        self._implementation_tiers = implementation_tiers or {
            "fast": self._implementation_model,
            "medium": self._implementation_model,
            "high": self._implementation_model,
        }
        self._orchestrator_reasoning_tiers = orchestrator_reasoning_tiers or {
            "fast": self._orchestrator_reasoning,
            "medium": self._orchestrator_reasoning,
            "high": self._orchestrator_reasoning,
        }
        self._implementation_reasoning_tiers = implementation_reasoning_tiers or {
            "fast": self._implementation_reasoning,
            "medium": self._implementation_reasoning,
            "high": self._implementation_reasoning,
        }
        self._role_configs = role_configs or {}
        # Track one-click selection (None = manual/mixed)
        self._one_click_provider: str | None = self._detect_one_click_provider()
        # Guard to prevent programmatic one-click indicator updates from
        # triggering one-click preset application/reset loops.
        self._suppress_one_click_event = False
        # Suppress change emissions during initial mount
        self._initializing = True

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.__init__",
                f"_initializing=True, orch={self._orchestrator_provider}/{self._orchestrator_model}, "
                f"impl={self._implementation_provider}/{self._implementation_model}",
            )

        # Take snapshot for dirty tracking
        self._snapshot_state()

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.__init__.snapshot",
                f"snapshot={self._initial_snapshot}",
            )

    def _detect_one_click_provider(self) -> str | None:
        """Detect if current settings match a one-click preset.

        Returns:
            Provider ID if all settings match a preset, None otherwise.
        """
        if self._orchestrator_provider != self._implementation_provider:
            return None
        # One-click semantics are provider + "Let Obra choose" models.
        # If either role is an explicit model, keep indicator on Manual.
        if self._orchestrator_model != "default" or self._implementation_model != "default":
            return None
        return self._orchestrator_provider

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("simple_llm")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            with ScrollableContainer(id="content-scroll"):
                # One-Click Setting section
                with Vertical(classes="one-click-section"):
                    yield Static("One-Click Setting", classes="section-header")
                    with Horizontal(classes="one-click-row"):
                        yield Label("Provider", classes="one-click-label")
                        yield Select(
                            self._build_one_click_options(),
                            id="one-click-select",
                            value=self._one_click_provider or "manual",
                            allow_blank=False,
                            classes="one-click-select",
                        )

                yield Rule()

                # Detailed Settings section
                with Vertical(classes="detailed-section"):
                    yield Static("Detailed Settings", classes="section-header")

                    # Orchestrator section
                    with Vertical(classes="role-section"):
                        yield Static("Orchestrator (Planning)", classes="role-header")
                        with Horizontal(classes="role-row"):
                            yield Label("Provider", classes="role-label")
                            yield Select(
                                self._build_provider_options(),
                                id="orch-provider-select",
                                value=self._orchestrator_provider,
                                allow_blank=False,
                                classes="role-select",
                            )
                        with Horizontal(classes="role-row"):
                            yield Label("Model", classes="role-label")
                            yield Select(
                                self._build_model_options(self._orchestrator_provider),
                                id="orch-model-select",
                                value=self._orchestrator_model,
                                allow_blank=False,
                                classes="role-select",
                            )
                        yield Static("", id="orch-model-hint", classes="model-hint")
                        with Horizontal(classes="role-row"):
                            yield Label("Reasoning", classes="role-label")
                            yield Select(
                                self._build_reasoning_options(),
                                id="orch-reasoning-select",
                                value=self._orchestrator_reasoning,
                                allow_blank=False,
                                classes="role-select",
                            )

                    # Implementation section
                    with Vertical(classes="role-section"):
                        yield Static("Implementation (Execution)", classes="role-header")
                        with Horizontal(classes="role-row"):
                            yield Label("Provider", classes="role-label")
                            yield Select(
                                self._build_provider_options(),
                                id="impl-provider-select",
                                value=self._implementation_provider,
                                allow_blank=False,
                                classes="role-select",
                            )
                        with Horizontal(classes="role-row"):
                            yield Label("Model", classes="role-label")
                            yield Select(
                                self._build_model_options(self._implementation_provider),
                                id="impl-model-select",
                                value=self._implementation_model,
                                allow_blank=False,
                                classes="role-select",
                            )
                        yield Static("", id="impl-model-hint", classes="model-hint")
                        with Horizontal(classes="role-row"):
                            yield Label("Reasoning", classes="role-label")
                            yield Select(
                                self._build_reasoning_options(),
                                id="impl-reasoning-select",
                                value=self._implementation_reasoning,
                                allow_blank=False,
                                classes="role-select",
                            )

                # Preview box
                with Vertical(classes="preview-box"):
                    yield Static("What Obra will use:", classes="preview-title")
                    yield Static(
                        self._build_preview_text(),
                        id="preview-content",
                        classes="preview-content",
                    )

            yield Static(
                "One-Click applies Obra-recommended defaults.\n"
                "For tier-based config, use 'Configure LLM - Moderate' (press 2).",
                classes="help-text",
            )

    def on_mount(self) -> None:
        """Initialize preview and hints after widget is mounted."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_mount.start",
                f"_initializing={self._initializing}, state={self._get_saveable_state()}",
            )

        self._update_preview()
        self._update_model_hints()

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued Select.Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            # This ensures the snapshot matches the actual widget state
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "SimpleLLMView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot={self._initial_snapshot}",
                )

        self.call_after_refresh(finish_initialization)

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_mount.end",
                f"_initializing still={self._initializing} (deferred to call_after_refresh)",
            )

    def _build_one_click_options(self) -> list[tuple[str, str]]:
        """Build options for the one-click provider selector.

        Returns:
            List of (display_text, value) tuples including 'Manual' option.
        """
        options = [("Manual (customize below)", "manual")]
        providers = get_providers()
        for provider_id, display_name, description in providers:
            label = f"{display_name} - {description}"
            options.append((label, provider_id))
        return options

    def _build_provider_options(self) -> list[tuple[str, str]]:
        """Build provider options for Select widget.

        Returns:
            List of (display_text, value) tuples for Select options.
        """
        providers = get_providers()
        options = []
        for provider_id, display_name, _description in providers:
            options.append((display_name, provider_id))
        return options

    def _build_model_options(self, provider: str) -> list[tuple[str, str]]:
        """Build model options for a specific provider.

        Options are sorted by tier: Recommended → High → Medium → Fast.
        Each option shows a cost indicator ($, $$, $$$).

        Args:
            provider: Provider ID to get models for.

        Returns:
            List of (display_text, value) tuples for Select options.
        """
        all_models = get_models()
        models = all_models.get(provider, all_models.get("anthropic", []))

        options = []
        for model_id, display, _tier in models:
            cost = get_model_cost(provider, model_id)
            # Recommended gets a star, others get cost indicator
            label = f"★  {display}" if model_id == "default" else f"{cost} {display}"
            options.append((label, model_id))
        return options

    def _build_reasoning_options(self) -> list[tuple[str, str]]:
        """Build reasoning level options for Select widget."""
        return [(level.capitalize(), level) for level in REASONING_LEVELS]

    def _build_preview_text(self) -> str:
        """Build preview text from authoritative effective config."""
        return build_authoritative_llm_preview(
            orch_provider=self._orchestrator_provider,
            impl_provider=self._implementation_provider,
            orch_tiers=self._orchestrator_tiers,
            impl_tiers=self._implementation_tiers,
            orch_reasoning_tiers=self._orchestrator_reasoning_tiers,
            impl_reasoning_tiers=self._implementation_reasoning_tiers,
            orch_fallback_reasoning=self._orchestrator_reasoning,
            impl_fallback_reasoning=self._implementation_reasoning,
            role_configs=self._role_configs,
        )

    def _sync_simple_cascade_preview_tiers(self) -> None:
        """Apply Menu 1 cascade semantics to authoritative preview tier state."""
        for tier in ("fast", "medium", "high"):
            self._orchestrator_tiers[tier] = self._orchestrator_model
            self._implementation_tiers[tier] = self._implementation_model
            self._orchestrator_reasoning_tiers[tier] = self._orchestrator_reasoning
            self._implementation_reasoning_tiers[tier] = self._implementation_reasoning

    def _update_preview(self) -> None:
        """Update the preview box with current selection."""
        try:
            preview = self.query_one("#preview-content", Static)
            preview.update(self._build_preview_text())
        except Exception:
            pass

    def _get_model_hint(self, role: str, provider: str, model_id: str) -> str:
        """Get hint text showing resolved model for 'Let Obra choose'.

        Args:
            role: Role name (orchestrator, implementation)
            provider: Provider ID
            model_id: Current model selection (may be 'default')

        Returns:
            Hint text to display, or empty string if specific model chosen.
        """
        if model_id != "default":
            return ""

        # Show what Obra will use for medium tier (the default tier for single-model)
        resolved = resolve_tier_model_display(provider, role, "medium", "default")
        return f"→ {resolved} (and Obra picks per-tier models)"

    def _update_model_hints(self) -> None:
        """Update model hint labels to show resolved models."""
        try:
            # Orchestrator hint
            orch_hint = self.query_one("#orch-model-hint", Static)
            orch_text = self._get_model_hint(
                "orchestrator", self._orchestrator_provider, self._orchestrator_model
            )
            orch_hint.update(orch_text)
            orch_hint.set_class(bool(orch_text), "model-hint-resolved")

            # Implementation hint
            impl_hint = self.query_one("#impl-model-hint", Static)
            impl_text = self._get_model_hint(
                "implementation",
                self._implementation_provider,
                self._implementation_model,
            )
            impl_hint.update(impl_text)
            impl_hint.set_class(bool(impl_text), "model-hint-resolved")
        except Exception:
            pass

    def _update_one_click_indicator(self) -> None:
        """Update the one-click dropdown to reflect manual if settings diverged."""
        detected = self._detect_one_click_provider()
        if detected != self._one_click_provider:
            self._one_click_provider = detected
            try:
                one_click = self.query_one("#one-click-select", Select)
                self._suppress_one_click_event = True
                one_click.value = detected or "manual"
            except Exception:
                pass
            finally:
                self._suppress_one_click_event = False

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select widget changes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        select_id = event.select.id

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_select_changed",
                f"id={select_id}, value={event.value}, _initializing={self._initializing}",
            )

        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            if is_debug_enabled():
                log_action("SimpleLLMView.on_select_changed.SKIPPED", "still initializing")
            return

        # Handle Select.BLANK sentinel with field-appropriate fallback
        if event.value is Select.BLANK:
            value = "medium" if (select_id or "").endswith("reasoning-select") else "default"
        else:
            value = str(event.value)

        if select_id == "one-click-select":
            if self._suppress_one_click_event:
                return
            self._handle_one_click_change(value)
        elif select_id == "orch-provider-select":
            self._handle_orch_provider_change(value)
        elif select_id == "orch-model-select":
            self._handle_orch_model_change(value)
        elif select_id == "orch-reasoning-select":
            self._handle_orch_reasoning_change(value)
        elif select_id == "impl-provider-select":
            self._handle_impl_provider_change(value)
        elif select_id == "impl-model-select":
            self._handle_impl_model_change(value)
        elif select_id == "impl-reasoning-select":
            self._handle_impl_reasoning_change(value)

    def _handle_one_click_change(self, value: str) -> None:
        """Handle one-click provider selection.

        When a provider is selected, set both roles to that provider with
        "default" model (Let Obra choose). The preview will show the actual
        models that will be used via ROLE_TIER_DEFAULTS.

        Args:
            value: Selected provider ID or 'manual'.
        """
        if value == "manual":
            self._one_click_provider = None
            return  # Don't change anything, user wants manual control

        self._one_click_provider = value

        # Set both roles to selected provider with "default" (Let Obra choose)
        # The preview will show the resolved models via ROLE_TIER_DEFAULTS
        self._orchestrator_provider = value
        self._orchestrator_model = "default"
        self._implementation_provider = value
        self._implementation_model = "default"
        self._sync_simple_cascade_preview_tiers()

        # Update UI (includes hints via _update_all_dropdowns)
        self._update_all_dropdowns()
        self._update_preview()
        self._emit_change()

    def _update_all_dropdowns(self) -> None:
        """Update all 4 detail dropdowns and hints to reflect current state."""
        try:
            # Orchestrator provider
            orch_prov = self.query_one("#orch-provider-select", Select)
            orch_prov.value = self._orchestrator_provider

            # Orchestrator model
            orch_model = self.query_one("#orch-model-select", Select)
            orch_model.set_options(self._build_model_options(self._orchestrator_provider))
            orch_model.value = self._orchestrator_model

            # Implementation provider
            impl_prov = self.query_one("#impl-provider-select", Select)
            impl_prov.value = self._implementation_provider

            # Implementation model
            impl_model = self.query_one("#impl-model-select", Select)
            impl_model.set_options(self._build_model_options(self._implementation_provider))
            impl_model.value = self._implementation_model

            # Reasoning
            orch_reasoning = self.query_one("#orch-reasoning-select", Select)
            orch_reasoning.set_options(self._build_reasoning_options())
            orch_reasoning.value = self._orchestrator_reasoning

            impl_reasoning = self.query_one("#impl-reasoning-select", Select)
            impl_reasoning.set_options(self._build_reasoning_options())
            impl_reasoning.value = self._implementation_reasoning

            # Update hints
            self._update_model_hints()
        except Exception:
            pass

    def _handle_orch_provider_change(self, new_provider: str) -> None:
        """Handle orchestrator provider change."""
        self._orchestrator_provider = new_provider
        self._sync_simple_cascade_preview_tiers()

        # Update model dropdown
        try:
            model_select = self.query_one("#orch-model-select", Select)
            new_options = self._build_model_options(new_provider)
            model_select.set_options(new_options)

            valid_ids = [opt[1] for opt in new_options]
            if self._orchestrator_model not in valid_ids:
                self._orchestrator_model = valid_ids[0] if valid_ids else "default"
                model_select.value = self._orchestrator_model
        except Exception:
            pass

        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_orch_model_change(self, new_model: str) -> None:
        """Handle orchestrator model change."""
        self._orchestrator_model = new_model
        self._orchestrator_reasoning = get_model_default_reasoning(
            self._orchestrator_provider,
            new_model,
            self._orchestrator_reasoning,
        )
        self._sync_simple_cascade_preview_tiers()
        try:
            orch_reasoning = self.query_one("#orch-reasoning-select", Select)
            orch_reasoning.value = self._orchestrator_reasoning
        except Exception:
            pass
        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_impl_provider_change(self, new_provider: str) -> None:
        """Handle implementation provider change."""
        self._implementation_provider = new_provider
        self._sync_simple_cascade_preview_tiers()

        # Update model dropdown
        try:
            model_select = self.query_one("#impl-model-select", Select)
            new_options = self._build_model_options(new_provider)
            model_select.set_options(new_options)

            valid_ids = [opt[1] for opt in new_options]
            if self._implementation_model not in valid_ids:
                self._implementation_model = valid_ids[0] if valid_ids else "default"
                model_select.value = self._implementation_model
        except Exception:
            pass

        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_impl_model_change(self, new_model: str) -> None:
        """Handle implementation model change."""
        self._implementation_model = new_model
        self._implementation_reasoning = get_model_default_reasoning(
            self._implementation_provider,
            new_model,
            self._implementation_reasoning,
        )
        self._sync_simple_cascade_preview_tiers()
        try:
            impl_reasoning = self.query_one("#impl-reasoning-select", Select)
            impl_reasoning.value = self._implementation_reasoning
        except Exception:
            pass
        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_orch_reasoning_change(self, new_reasoning: str) -> None:
        """Handle orchestrator reasoning change."""
        self._orchestrator_reasoning = new_reasoning
        self._sync_simple_cascade_preview_tiers()
        self._update_preview()
        self._emit_change()

    def _handle_impl_reasoning_change(self, new_reasoning: str) -> None:
        """Handle implementation reasoning change."""
        self._implementation_reasoning = new_reasoning
        self._sync_simple_cascade_preview_tiers()
        self._update_preview()
        self._emit_change()

    def _emit_change(self) -> None:
        """Emit the Changed message with current configuration.

        Skips emission during initial mount to prevent spurious changes.
        """
        # Don't emit during initial mount - only after user interaction
        if self._initializing:
            return

        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "emit_changed",
                f"orch={self._orchestrator_provider}/{self._orchestrator_model}, "
                f"impl={self._implementation_provider}/{self._implementation_model}",
            )

        self.post_message(
            self.Changed(
                self._orchestrator_provider,
                self._orchestrator_model,
                self._orchestrator_reasoning,
                self._implementation_provider,
                self._implementation_model,
                self._implementation_reasoning,
            )
        )

    def set_values(
        self,
        provider: str | None = None,
        model: str | None = None,
        reasoning: str | None = None,
        orchestrator_provider: str | None = None,
        orchestrator_model: str | None = None,
        orchestrator_reasoning: str | None = None,
        orchestrator_tiers: dict[str, Any] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_model: str | None = None,
        implementation_reasoning: str | None = None,
        implementation_tiers: dict[str, Any] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
        role_configs: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """Set the current values.

        Args:
            provider: Legacy single provider (used if specific values not provided)
            model: Legacy single model (used if specific values not provided)
            reasoning: Legacy single reasoning level (used if specific values not provided)
            orchestrator_provider: Orchestrator provider
            orchestrator_model: Orchestrator model
            orchestrator_reasoning: Orchestrator reasoning level
            orchestrator_tiers: Orchestrator tier models for authoritative preview
            orchestrator_reasoning_tiers: Orchestrator tier reasoning for authoritative preview
            implementation_provider: Implementation provider
            implementation_model: Implementation model
            implementation_reasoning: Implementation reasoning level
            implementation_tiers: Implementation tier models for authoritative preview
            implementation_reasoning_tiers: Implementation tier reasoning for authoritative preview
            role_configs: Optional explicit llm.roles.* overrides from Menu 3
        """
        # Use explicit values or fall back to legacy single values
        self._orchestrator_provider = orchestrator_provider or provider or "anthropic"
        self._orchestrator_model = orchestrator_model or model or "default"
        self._orchestrator_reasoning = orchestrator_reasoning or reasoning or "medium"
        self._implementation_provider = implementation_provider or provider or "anthropic"
        self._implementation_model = implementation_model or model or "default"
        self._implementation_reasoning = implementation_reasoning or reasoning or "medium"
        if role_configs is not None:
            self._role_configs = role_configs

        self._orchestrator_tiers = {
            "fast": (orchestrator_tiers or {}).get("fast", self._orchestrator_model),
            "medium": (orchestrator_tiers or {}).get("medium", self._orchestrator_model),
            "high": (orchestrator_tiers or {}).get("high", self._orchestrator_model),
        }
        self._implementation_tiers = {
            "fast": (implementation_tiers or {}).get("fast", self._implementation_model),
            "medium": (implementation_tiers or {}).get("medium", self._implementation_model),
            "high": (implementation_tiers or {}).get("high", self._implementation_model),
        }
        self._orchestrator_reasoning_tiers = {
            "fast": (orchestrator_reasoning_tiers or {}).get("fast", self._orchestrator_reasoning),
            "medium": (orchestrator_reasoning_tiers or {}).get(
                "medium", self._orchestrator_reasoning
            ),
            "high": (orchestrator_reasoning_tiers or {}).get("high", self._orchestrator_reasoning),
        }
        self._implementation_reasoning_tiers = {
            "fast": (implementation_reasoning_tiers or {}).get(
                "fast", self._implementation_reasoning
            ),
            "medium": (implementation_reasoning_tiers or {}).get(
                "medium", self._implementation_reasoning
            ),
            "high": (implementation_reasoning_tiers or {}).get(
                "high", self._implementation_reasoning
            ),
        }

        self._one_click_provider = self._detect_one_click_provider()
        self._update_all_dropdowns()
        self._update_one_click_indicator()
        self._update_preview()

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return {
            "llm.orchestrator.provider": self._orchestrator_provider,
            "llm.orchestrator.model": self._orchestrator_model,
            "llm.orchestrator.thinking_level": self._orchestrator_reasoning,
            "llm.implementation.provider": self._implementation_provider,
            "llm.implementation.model": self._implementation_model,
            "llm.implementation.thinking_level": self._implementation_reasoning,
        }

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._orchestrator_provider = state.get(
            "llm.orchestrator.provider", self._orchestrator_provider
        )
        self._orchestrator_model = state.get("llm.orchestrator.model", self._orchestrator_model)
        self._orchestrator_reasoning = state.get(
            "llm.orchestrator.thinking_level", self._orchestrator_reasoning
        )
        self._implementation_provider = state.get(
            "llm.implementation.provider", self._implementation_provider
        )
        self._implementation_model = state.get(
            "llm.implementation.model", self._implementation_model
        )
        self._implementation_reasoning = state.get(
            "llm.implementation.thinking_level", self._implementation_reasoning
        )
        self._one_click_provider = self._detect_one_click_provider()
        self._update_all_dropdowns()
        self._update_one_click_indicator()
        self._update_preview()
