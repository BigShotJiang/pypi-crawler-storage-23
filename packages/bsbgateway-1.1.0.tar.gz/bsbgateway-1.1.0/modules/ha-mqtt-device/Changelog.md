# Changelog

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [0.15.0](#0150)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## 0.15.0

- Removed `thelogrus` from the dependency list
