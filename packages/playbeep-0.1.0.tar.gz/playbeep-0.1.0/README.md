# How To Use:
```py
import playbeep, time
mixer = playbeep.play()
mixer.beep(500, 0.5)
time.sleep(1)
```