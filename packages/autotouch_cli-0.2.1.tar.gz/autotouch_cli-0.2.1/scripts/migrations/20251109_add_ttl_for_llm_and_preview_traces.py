#!/usr/bin/env python3
"""
Migration: Enforce 7-day TTL for LLM observations and preview traces.

Creates TTL indexes on:
 - llm_responses.created_at (expireAfterSeconds = 604800)
 - preview_traces.request_timestamp (expireAfterSeconds = 604800)

Idempotent: if an index with the same name exists but with a different TTL,
it will be dropped and recreated.
"""
import os
import sys
from datetime import datetime
from typing import Optional

from pymongo import MongoClient, ASCENDING


def _get_db() -> "tuple[MongoClient, str]":
    mongodb_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    db_name = os.getenv("MONGODB_DB_NAME", "autotouch")
    client = MongoClient(mongodb_uri)
    return client, db_name


def _ensure_ttl_index(collection, field: str, ttl_seconds: int, name: str) -> None:
    """Create or update a TTL index on a single date field.

    If an index with the same name exists but a different TTL, drop and recreate.
    """
    existing = None
    for idx in collection.list_indexes():
        if idx.get("name") == name:
            existing = idx
            break

    if existing:
        current_ttl: Optional[int] = existing.get("expireAfterSeconds")
        if current_ttl != ttl_seconds:
            print(f"  - Dropping existing index '{name}' (expireAfterSeconds={current_ttl})")
            collection.drop_index(name)
            print(f"  - Recreating index '{name}' with expireAfterSeconds={ttl_seconds}")
            collection.create_index([(field, ASCENDING)], name=name, expireAfterSeconds=ttl_seconds)
        else:
            print(f"  - TTL index '{name}' already up-to-date (expireAfterSeconds={ttl_seconds})")
    else:
        print(f"  - Creating TTL index '{name}' on {field} (expireAfterSeconds={ttl_seconds})")
        collection.create_index([(field, ASCENDING)], name=name, expireAfterSeconds=ttl_seconds)


def main() -> None:
    print("=== TTL Migration: LLM + Preview Traces ===")
    print(f"Timestamp: {datetime.utcnow().isoformat()}Z")

    client, db_name = _get_db()
    db = client[db_name]

    # Collections
    llm_responses = db.get_collection("llm_responses")
    # preview_traces may live in a separate database if TRACE_DB_NAME is set
    trace_db_name = os.getenv("TRACE_DB_NAME")
    trace_db = client[trace_db_name] if trace_db_name else db
    preview_traces = trace_db.get_collection("preview_traces")

    # TTL = 7 days
    TTL_SECONDS = 7 * 24 * 60 * 60  # 604800

    print(f"Connecting to MongoDB database: {db_name}")
    if trace_db_name and trace_db_name != db_name:
        print(f"Using separate trace database for preview_traces: {trace_db_name}")

    # llm_responses TTL on created_at
    print("\n[llm_responses]")
    _ensure_ttl_index(
        llm_responses,
        field="created_at",
        ttl_seconds=TTL_SECONDS,
        name="created_at_ttl_7d",
    )

    # preview_traces TTL on request_timestamp
    print("\n[preview_traces]")
    _ensure_ttl_index(
        preview_traces,
        field="request_timestamp",
        ttl_seconds=TTL_SECONDS,
        name="request_timestamp_ttl_7d",
    )

    print("\n✅ TTL migration complete.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        sys.exit(1)
