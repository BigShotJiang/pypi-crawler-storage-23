#!/usr/bin/env python3
"""
Migration to fix legacy column fields.
Converts old 'name' field to 'key' and 'label' fields.
"""

import os
import sys
from pymongo import MongoClient
from bson import ObjectId

# MongoDB connection
MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
MONGODB_DB_NAME = os.getenv('MONGODB_DB_NAME', 'smart_table')

def migrate():
    """Fix legacy column fields in tables."""
    client = MongoClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    # Find all tables with columns that have 'name' field
    tables_to_fix = db.tables.find({'columns.name': {'$exists': True}})
    
    fixed_count = 0
    
    for table in tables_to_fix:
        print(f"\nFixing table: {table['name']} (ID: {table['_id']})")
        
        # Fix each column
        updated_columns = []
        for col in table['columns']:
            if 'name' in col and 'key' not in col:
                # Convert name to key and label
                col['key'] = col['name'].lower().replace(' ', '_')
                col['label'] = col['name']
                del col['name']
                print(f"  - Fixed column: {col['label']} (key: {col['key']})")
            
            # Ensure all required fields exist
            if 'origin' not in col:
                col['origin'] = 'manual'
            if 'status' not in col:
                col['status'] = 'idle'
            if 'auto_run' not in col:
                col['auto_run'] = 'never'
            if 'data_type' not in col and 'dataType' in col:
                col['data_type'] = col['dataType']
                del col['dataType']
                
            updated_columns.append(col)
        
        # Update the table
        db.tables.update_one(
            {'_id': table['_id']},
            {'$set': {'columns': updated_columns}}
        )
        
        fixed_count += 1
    
    print(f"\n✅ Fixed {fixed_count} tables with legacy column fields")
    
    # Also check columns collection for any standalone columns
    standalone_cols = db.columns.find({'name': {'$exists': True}, 'key': {'$exists': False}})
    standalone_fixed = 0
    
    for col in standalone_cols:
        key = col['name'].lower().replace(' ', '_')
        label = col['name']
        
        db.columns.update_one(
            {'_id': col['_id']},
            {
                '$set': {
                    'key': key,
                    'label': label
                },
                '$unset': {'name': ''}
            }
        )
        standalone_fixed += 1
        print(f"Fixed standalone column: {label} (key: {key})")
    
    if standalone_fixed > 0:
        print(f"\n✅ Fixed {standalone_fixed} standalone columns")
    
    client.close()

if __name__ == '__main__':
    print("Starting migration to fix legacy column fields...")
    migrate()
    print("\nMigration completed!")