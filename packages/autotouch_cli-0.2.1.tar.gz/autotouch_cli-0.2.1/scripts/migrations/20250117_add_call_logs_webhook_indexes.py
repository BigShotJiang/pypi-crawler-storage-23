#!/usr/bin/env python3
"""
Migration script to add indexes for RingCentral webhook fields in call_logs collection.
This script adds indexes for the new agnostic field names.
"""

import asyncio
import sys
import os
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "autotouch")

async def add_call_logs_indexes():
    """Add indexes for call_logs collection to optimize webhook queries"""
    
    print("🔧 Adding indexes for call_logs collection...")
    
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    # Indexes for webhook processing
    indexes_to_create = [
        # Session ID lookup (most common query)
        {"keys": [("session_id", ASCENDING)], "name": "session_id_lookup"},
        
        # Party ID lookup
        {"keys": [("party_id", ASCENDING)], "name": "party_id_lookup"},
        
        # Provider call ID lookup
        {"keys": [("provider_call_id", ASCENDING)], "name": "provider_call_id_lookup"},
        
        # Agent + organization queries (common for task queue)
        {"keys": [("agent_id", ASCENDING), ("organization_id", ASCENDING)], "name": "agent_org_lookup"},
        
        # Status + time queries (for active calls)
        {"keys": [("status", ASCENDING), ("updated_at", DESCENDING)], "name": "status_updated"},
        
        # Webhook processing queries
        {"keys": [("webhook_received_at", DESCENDING)], "name": "webhook_received_time"},
        
        # Recording URL queries
        {"keys": [("recording_url", ASCENDING)], "name": "recording_url_lookup"},
        
        # Compound index for session + party (webhook deduplication)
        {"keys": [("session_id", ASCENDING), ("party_id", ASCENDING)], "name": "session_party_unique"},
        
        # Compound index for provider + call ID (provider-specific queries)
        {"keys": [("provider", ASCENDING), ("provider_call_id", ASCENDING)], "name": "provider_call_lookup"},
    ]
    
    created_count = 0
    for index_spec in indexes_to_create:
        try:
            await db['call_logs'].create_index(
                index_spec["keys"],
                name=index_spec["name"],
                background=True  # Create in background to avoid blocking
            )
            print(f"✅ Created index: {index_spec['name']}")
            created_count += 1
        except Exception as e:
            if "already exists" in str(e).lower():
                print(f"⏭️  Index already exists: {index_spec['name']}")
            else:
                print(f"❌ Failed to create index {index_spec['name']}: {e}")
    
    print(f"\n🎉 Migration complete! Created {created_count} new indexes.")
    print("\n📊 Index Summary:")
    print("   - session_id_lookup: Fast session-based queries")
    print("   - party_id_lookup: Fast party-based queries") 
    print("   - agent_org_lookup: Fast agent + organization queries")
    print("   - status_updated: Fast status + time queries")
    print("   - webhook_received_time: Fast webhook processing queries")
    print("   - session_party_unique: Webhook deduplication")
    print("   - provider_call_lookup: Provider-specific queries")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(add_call_logs_indexes())
