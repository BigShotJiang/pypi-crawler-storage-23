#!/usr/bin/env python3
"""
Add indexes to support efficient MongoDB query-based filtering
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, TEXT
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def add_filter_indexes():
    """Add indexes to support efficient filtering"""
    
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    try:
        # 1. Compound index on rows for table + position
        logger.info("Creating compound index on rows (table_id, position)")
        await db.rows.create_index([
            ("table_id", ASCENDING),
            ("position", ASCENDING)
        ])
        
        # 2. Compound index on cells for efficient lookups
        logger.info("Creating compound index on cells (row_id, column_id)")
        await db.cells.create_index([
            ("row_id", ASCENDING),
            ("column_id", ASCENDING)
        ])
        
        # 3. Index on cells.column_id for filtering
        logger.info("Creating index on cells.column_id")
        await db.cells.create_index("column_id")
        
        # 4. Index on cells.value for common filter operations
        # Note: This might be expensive for large datasets
        # Consider adding only for specific columns that are frequently filtered
        logger.info("Creating index on cells.value")
        await db.cells.create_index("value")
        
        # 5. Text index on cells.value for text search
        # This enables efficient "contains" searches
        logger.info("Creating text index on cells.value")
        try:
            await db.cells.create_index([("value", TEXT)])
        except Exception as e:
            logger.warning(f"Text index creation failed (might already exist): {e}")
        
        # 6. Compound index for aggregation pipeline efficiency
        logger.info("Creating compound index on cells (column_id, value)")
        await db.cells.create_index([
            ("column_id", ASCENDING),
            ("value", ASCENDING)
        ])
        
        # List all indexes
        logger.info("\nCurrent indexes on rows collection:")
        rows_indexes = await db.rows.list_indexes().to_list(None)
        for idx in rows_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")
        
        logger.info("\nCurrent indexes on cells collection:")
        cells_indexes = await db.cells.list_indexes().to_list(None)
        for idx in cells_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")
        
        logger.info("\nIndex creation completed successfully!")
        
    except Exception as e:
        logger.error(f"Error creating indexes: {e}")
        raise
    finally:
        client.close()


async def analyze_filter_performance():
    """Analyze query performance with explain()"""
    
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    try:
        # Get a sample table ID
        sample_table = await db.tables.find_one()
        if not sample_table:
            logger.warning("No tables found for performance analysis")
            return
        
        table_id = str(sample_table["_id"])
        logger.info(f"\nAnalyzing filter performance for table: {table_id}")
        
        # Test aggregation pipeline performance
        pipeline = [
            {"$match": {"table_id": table_id}},
            {"$lookup": {
                "from": "cells",
                "let": {"row_id": {"$toString": "$_id"}},
                "pipeline": [
                    {"$match": {
                        "$expr": {"$eq": ["$row_id", "$$row_id"]}
                    }}
                ],
                "as": "cells"
            }},
            {"$limit": 10}
        ]
        
        # Get execution stats
        result = await db.rows.aggregate(pipeline).explain()
        logger.info(f"\nAggregation pipeline execution stats:")
        logger.info(f"  - Execution time: {result.get('executionTimeMillis', 'N/A')}ms")
        
    except Exception as e:
        logger.error(f"Error analyzing performance: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    # Run migrations
    asyncio.run(add_filter_indexes())
    
    # Analyze performance
    asyncio.run(analyze_filter_performance())