#!/usr/bin/env python3
"""
Normalize legacy table filter operator values stored in column configs.

Targets enrichment column configs with autoRunFilters / auto_run_filters.
Maps legacy operators to the canonical backend vocabulary:
  - numberBetween -> between
  - not_in -> notIn
  - any -> in
  - none -> notIn

Run with:
  python scripts/migrations/20260113_normalize_table_filter_operators.py
"""

import os
import asyncio
from datetime import datetime
from typing import Any, Dict, Optional

from motor.motor_asyncio import AsyncIOMotorClient


LEGACY_OPERATOR_MAP = {
    "numberBetween": "between",
    "not_in": "notIn",
    "any": "in",
    "none": "notIn",
}


def _normalize_operator(op: Any) -> Any:
    if op is None:
        return op
    op_str = str(op)
    return LEGACY_OPERATOR_MAP.get(op_str, op)


def _normalize_filters_block(filters_block: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(filters_block, dict):
        return None
    raw_filters = filters_block.get("filters")
    if not isinstance(raw_filters, list):
        return None

    changed = False
    next_filters = []
    for f in raw_filters:
        if not isinstance(f, dict):
            next_filters.append(f)
            continue
        f2 = dict(f)
        if "operator" in f2:
            next_op = _normalize_operator(f2.get("operator"))
            if next_op != f2.get("operator"):
                f2["operator"] = next_op
                changed = True
        next_filters.append(f2)

    if not changed:
        return None
    return {**filters_block, "filters": next_filters}


async def run() -> None:
    mongodb_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    db_name = os.getenv("MONGODB_DB_NAME", "smart_table")

    client = AsyncIOMotorClient(mongodb_uri)
    db = client[db_name]

    print(f"Starting filter operator normalization on database: {db_name}")
    print(f"Timestamp: {datetime.now()}")

    query = {
        "config": {"$type": "object"},
        "$or": [
            {"config.autoRunFilters": {"$exists": True}},
            {"config.auto_run_filters": {"$exists": True}},
        ],
    }

    total_candidates = await db.columns.count_documents(query)
    print(f"Found {total_candidates} columns with auto-run filters to inspect")

    updated_columns = 0
    updated_blocks = 0

    async for col in db.columns.find(query):
        config = col.get("config") or {}
        updates = {}

        for key in ("autoRunFilters", "auto_run_filters"):
            if key not in config:
                continue
            normalized = _normalize_filters_block(config.get(key))
            if normalized is not None:
                updates[f"config.{key}"] = normalized
                updated_blocks += 1

        if updates:
            result = await db.columns.update_one({"_id": col["_id"]}, {"$set": updates})
            if result.modified_count:
                updated_columns += 1

    print("\nNormalization complete.")
    print(f"Columns updated: {updated_columns}")
    print(f"Filter blocks updated: {updated_blocks}")
    client.close()


if __name__ == "__main__":
    asyncio.run(run())
