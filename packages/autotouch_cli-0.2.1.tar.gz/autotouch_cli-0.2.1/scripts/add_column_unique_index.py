#!/usr/bin/env python3
"""
Add unique index on (table_id, key) to columns collection.
This prevents duplicate column keys within the same table.
"""

import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING
from pymongo.errors import DuplicateKeyError
import os


async def add_unique_index(db):
    """Add unique compound index on (table_id, key) to prevent duplicates."""
    
    print("Adding unique index on columns collection...")
    
    try:
        # List existing indexes
        existing_indexes = await db.columns.list_indexes().to_list(None)
        print(f"Existing indexes: {[idx['name'] for idx in existing_indexes]}")
        
        # Check if index already exists
        index_exists = any(
            idx.get('name') == 'table_id_key_unique' 
            for idx in existing_indexes
        )
        
        if index_exists:
            print("Index 'table_id_key_unique' already exists")
            return True
        
        # Create unique compound index
        result = await db.columns.create_index(
            [('table_id', ASCENDING), ('key', ASCENDING)],
            unique=True,
            name='table_id_key_unique'
        )
        print(f"Successfully created unique index: {result}")
        return True
        
    except DuplicateKeyError as e:
        print(f"ERROR: Cannot create unique index due to duplicate keys!")
        print(f"Error details: {e}")
        
        # Find and report duplicates
        pipeline = [
            {'$group': {
                '_id': {'table_id': '$table_id', 'key': '$key'},
                'count': {'$sum': 1},
                'ids': {'$push': '$_id'},
                'names': {'$push': '$name'}
            }},
            {'$match': {'count': {'$gt': 1}}}
        ]
        
        duplicates = await db.columns.aggregate(pipeline).to_list(None)
        
        if duplicates:
            print(f"\nFound {len(duplicates)} duplicate (table_id, key) pairs:")
            for i, dup in enumerate(duplicates):
                print(f"\n{i+1}. Table: {dup['_id']['table_id']}, Key: '{dup['_id']['key']}'")
                print(f"   Count: {dup['count']}")
                print(f"   IDs: {[str(id) for id in dup['ids']]}")
                print(f"   Names: {dup['names']}")
            
            print("\nPlease run the fix_duplicate_columns.py script first to clean up duplicates.")
        
        return False
        
    except Exception as e:
        print(f"ERROR: Failed to create index - {e}")
        return False


async def main():
    """Run the index creation."""
    
    # Get MongoDB URL from environment or use default
    mongodb_url = os.getenv('MONGODB_URL', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB', 'smart_table')
    
    print(f"Connecting to MongoDB at {mongodb_url}/{db_name}")
    
    # Connect to MongoDB
    client = AsyncIOMotorClient(mongodb_url)
    db = client[db_name]
    
    try:
        # Test connection
        await db.command('ping')
        print("Successfully connected to MongoDB\n")
        
        # Add the unique index
        success = await add_unique_index(db)
        
        if success:
            print("\nIndex creation completed successfully!")
            print("Duplicate column keys are now prevented at the database level.")
        else:
            print("\nIndex creation failed. Please resolve issues and try again.")
            
    except Exception as e:
        print(f"\nERROR: {e}")
        raise
    finally:
        client.close()


if __name__ == '__main__':
    asyncio.run(main())