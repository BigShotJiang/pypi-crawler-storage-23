#!/usr/bin/env python3
"""
Smart Table CLI

Agent-friendly command-line helper for Smart Table API automation.

Features:
- Capabilities discovery
- Table and column management
- Row creation and cell patching
- Column run + estimate
- Bulk-job polling
- Optional Mongo-backed status/watch helpers

Environment variables:
- SMARTTABLE_API_URL   (default: https://app.autotouch.ai)
- SMARTTABLE_TOKEN     (developer key or JWT bearer, or pass --token)
- MONGODB_URI          (for status when using direct DB aggregation)
- MONGODB_DB_NAME      (default: autotouch)
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

try:
    from pymongo import MongoClient  # type: ignore
except Exception:  # pragma: no cover
    MongoClient = None  # type: ignore

try:
    from dotenv import load_dotenv  # type: ignore
except Exception:  # pragma: no cover
    load_dotenv = None  # type: ignore


DEFAULT_API_URL = "https://app.autotouch.ai"
DEFAULT_TIMEOUT_SECONDS = 30
TERMINAL_JOB_STATUSES = {"completed", "partial", "error", "cancelled"}
CONFIG_ENV_KEY = "AUTOTOUCH_CONFIG_PATH"
CONFIG_DIR_NAME = "autotouch"
CONFIG_FILE_NAME = "config.json"


def _load_env_files() -> None:
    if load_dotenv is None:
        return
    script_root = Path(__file__).resolve().parent.parent
    candidates = [Path.cwd() / ".env", script_root / ".env"]
    seen = set()
    for candidate in candidates:
        path = candidate.resolve()
        if path in seen:
            continue
        seen.add(path)
        if path.exists():
            load_dotenv(path, override=False)


_load_env_files()


def _config_path() -> Path:
    override = os.environ.get(CONFIG_ENV_KEY)
    if override:
        return Path(override).expanduser()
    xdg_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_home:
        return Path(xdg_home).expanduser() / CONFIG_DIR_NAME / CONFIG_FILE_NAME
    return Path.home() / ".config" / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def _load_config() -> Dict[str, Any]:
    path = _config_path()
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _save_config(data: Dict[str, Any]) -> Path:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return path


def _mask_api_key(value: Optional[str]) -> str:
    token = str(value or "").strip()
    if not token:
        return ""
    if len(token) <= 8:
        return "*" * len(token)
    return f"{token[:6]}...{token[-4:]}"


def _api_url(value: Optional[str] = None) -> str:
    if value:
        return str(value).rstrip("/")
    env_base = os.environ.get("SMARTTABLE_API_URL") or os.environ.get("AUTOTOUCH_API_URL")
    if env_base:
        return str(env_base).rstrip("/")
    cfg = _load_config()
    cfg_base = cfg.get("base_url")
    if cfg_base:
        return str(cfg_base).rstrip("/")
    return DEFAULT_API_URL.rstrip("/")


def _resolve_token(explicit_token: Optional[str], required: bool = True) -> Optional[str]:
    tok = (
        explicit_token
        or os.environ.get("SMARTTABLE_TOKEN")
        or os.environ.get("AUTOTOUCH_API_KEY")
        or os.environ.get("AUTOTOUCH_TOKEN")
    )
    if not tok:
        cfg = _load_config()
        tok = cfg.get("api_key")
    if not tok:
        if required:
            print(
                "ERROR: missing token. Pass --token, set SMARTTABLE_TOKEN/AUTOTOUCH_API_KEY, or run `autotouch auth set-key`.",
                file=sys.stderr,
            )
            sys.exit(2)
        return None
    return tok


def _auth_headers(token: Optional[str], use_x_api_key: bool = False) -> Dict[str, str]:
    if not token:
        return {}
    if use_x_api_key:
        return {"X-API-Key": token}
    return {"Authorization": f"Bearer {token}"}


def _print_json(data: Any, compact: bool = False) -> None:
    if compact:
        print(json.dumps(data, separators=(",", ":"), default=str))
        return
    print(json.dumps(data, indent=2, default=str))


def _parse_json_string(raw: str, context: str) -> Any:
    try:
        return json.loads(raw)
    except Exception as exc:
        print(f"ERROR: invalid JSON for {context}: {exc}", file=sys.stderr)
        sys.exit(2)


def _load_json_input(
    *,
    inline_json: Optional[str],
    file_path: Optional[str],
    context: str,
    default: Any = None,
) -> Any:
    if inline_json and file_path:
        print(f"ERROR: pass either --{context}-json or --{context}-file, not both", file=sys.stderr)
        sys.exit(2)
    if inline_json:
        return _parse_json_string(inline_json, context)
    if file_path:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            print(f"ERROR: failed to read {context} file '{file_path}': {exc}", file=sys.stderr)
            sys.exit(2)
    return default


def _request_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    use_x_api_key: bool = False,
    params: Optional[Dict[str, Any]] = None,
    payload: Optional[Any] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    verbose: bool = False,
) -> Any:
    url = f"{_api_url(base_url)}{path if path.startswith('/') else f'/{path}'}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)
    if verbose:
        print(f"[HTTP] {method.upper()} {url}", file=sys.stderr)
        if params:
            print(f"[HTTP] params={json.dumps(params, default=str)}", file=sys.stderr)
        if payload is not None:
            print(f"[HTTP] payload={json.dumps(payload, default=str)}", file=sys.stderr)

    try:
        response = requests.request(
            method=method.upper(),
            url=url,
            headers=headers,
            params=params,
            json=payload,
            timeout=max(1, int(timeout or DEFAULT_TIMEOUT_SECONDS)),
        )
    except requests.RequestException as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        sys.exit(1)

    content_type = response.headers.get("content-type", "").lower()
    body: Any
    if "application/json" in content_type:
        try:
            body = response.json()
        except Exception:
            body = response.text
    else:
        body = response.text

    if response.status_code >= 300:
        print(f"ERROR: API {response.status_code}", file=sys.stderr)
        if isinstance(body, (dict, list)):
            _print_json(body, compact=False)
        else:
            print(str(body), file=sys.stderr)
        sys.exit(1)
    return body


def _normalize_run_payload(args: argparse.Namespace) -> Dict[str, Any]:
    # If an explicit payload was provided, use it verbatim.
    explicit_payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if explicit_payload is not None:
        if not isinstance(explicit_payload, dict):
            print("ERROR: run payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        return explicit_payload

    scope = str(getattr(args, "scope", "all") or "all")
    payload: Dict[str, Any] = {"scope": scope}
    row_ids = [r.strip() for r in (getattr(args, "row_ids", None) or []) if r and str(r).strip()]

    if scope == "row":
        if getattr(args, "row_id", None):
            payload["rowIds"] = [str(args.row_id)]
        elif row_ids:
            payload["rowIds"] = [str(row_ids[0])]
        else:
            print("ERROR: --row-id or --row-ids is required for scope=row", file=sys.stderr)
            sys.exit(2)

    if scope == "subset":
        if not row_ids:
            print("ERROR: --row-ids required for scope=subset", file=sys.stderr)
            sys.exit(2)
        payload["rowIds"] = row_ids

    if scope == "firstN":
        first_n = getattr(args, "first_n", None)
        if not first_n or int(first_n) <= 0:
            print("ERROR: --first-n must be > 0 for scope=firstN", file=sys.stderr)
            sys.exit(2)
        payload["firstN"] = int(first_n)

    filters = _load_json_input(
        inline_json=getattr(args, "filters_json", None),
        file_path=getattr(args, "filters_file", None),
        context="filters",
        default=None,
    )
    if filters is not None:
        payload["filters"] = filters

    if getattr(args, "unprocessed_only", False):
        payload["unprocessedOnly"] = True

    return payload


def _create_rows_and_patch_records(
    *,
    table_id: str,
    records: Optional[List[Dict[str, Any]]],
    blank_count: int,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
    detect_types: bool,
) -> Dict[str, Any]:
    created_row_ids: List[str] = []
    patch_updates: List[Dict[str, Any]] = []

    if records is not None:
        for idx, record in enumerate(records):
            if not isinstance(record, dict):
                print(f"ERROR: record at index {idx} is not a JSON object", file=sys.stderr)
                sys.exit(2)
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            row_id = str(row_id)
            created_row_ids.append(row_id)
            for key, value in record.items():
                patch_updates.append({"rowId": row_id, "key": str(key), "value": value})
    else:
        count = max(0, int(blank_count or 0))
        if count <= 0:
            print("ERROR: --count must be > 0", file=sys.stderr)
            sys.exit(2)
        for _ in range(count):
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            created_row_ids.append(str(row_id))

    patch_result: Optional[Any] = None
    if patch_updates:
        params = {"detect_types": "true"} if detect_types else None
        patch_result = _request_api(
            "PATCH",
            f"/api/tables/{table_id}/cells",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            payload={"updates": patch_updates},
            params=params,
            timeout=timeout,
            verbose=verbose,
        )

    return {
        "created": len(created_row_ids),
        "rowIds": created_row_ids,
        "updatedCells": len(patch_updates),
        "patchResult": patch_result,
    }


def _read_records_from_csv(
    file_path: str,
    *,
    delimiter: str = ",",
    encoding: str = "utf-8",
    trim_headers: bool = True,
    trim_values: bool = False,
    empty_as_null: bool = True,
    skip_empty_rows: bool = True,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    try:
        with open(file_path, "r", encoding=encoding, newline="") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            if not reader.fieldnames:
                print("ERROR: CSV file has no header row", file=sys.stderr)
                sys.exit(2)

            normalized_headers = []
            for header in reader.fieldnames:
                key = (header or "")
                key = key.strip() if trim_headers else key
                normalized_headers.append(key)
            reader.fieldnames = normalized_headers

            for raw_row in reader:
                row_obj: Dict[str, Any] = {}
                for key, value in (raw_row or {}).items():
                    col_key = str(key or "").strip() if trim_headers else str(key or "")
                    if not col_key:
                        continue
                    cell_value: Any = value
                    if isinstance(cell_value, str) and trim_values:
                        cell_value = cell_value.strip()
                    if empty_as_null and (cell_value is None or (isinstance(cell_value, str) and cell_value.strip() == "")):
                        cell_value = None
                    row_obj[col_key] = cell_value

                if skip_empty_rows:
                    has_value = any(
                        value is not None and (not isinstance(value, str) or value.strip() != "")
                        for value in row_obj.values()
                    )
                    if not has_value:
                        continue

                records.append(row_obj)
                if limit is not None and limit > 0 and len(records) >= limit:
                    break
    except FileNotFoundError:
        print(f"ERROR: CSV file not found: {file_path}", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        print(f"ERROR: failed to read CSV '{file_path}': {exc}", file=sys.stderr)
        sys.exit(2)
    return records


def _job_snapshot(job_doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "job_id": job_doc.get("job_id") or job_doc.get("jobId"),
        "status": job_doc.get("status"),
        "provider": job_doc.get("provider"),
        "processed_rows": int(job_doc.get("processed_rows") or 0),
        "total_rows": int(job_doc.get("total_rows") or 0),
        "error_rows": int(job_doc.get("error_rows") or 0),
        "credits_used": float(job_doc.get("credits_used") or 0.0),
        "billable": bool(job_doc.get("billable", False)),
        "updated_at": job_doc.get("updated_at"),
    }


def _poll_job(
    *,
    job_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    interval_seconds: int,
    wait_timeout_seconds: int,
    request_timeout_seconds: int,
    verbose: bool,
    compact: bool,
    once: bool = False,
    print_updates: bool = True,
) -> Dict[str, Any]:
    interval = max(1, int(interval_seconds or 2))
    max_wait = max(0, int(wait_timeout_seconds or 0))
    started = time.monotonic()
    polls = 0
    last_status: Optional[str] = None
    url = f"{_api_url(base_url)}/api/bulk-jobs/{job_id}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)

    while True:
        polls += 1
        if verbose:
            print(f"[HTTP] GET {url}", file=sys.stderr)
        try:
            response = requests.get(
                url,
                headers=headers,
                timeout=max(1, int(request_timeout_seconds or DEFAULT_TIMEOUT_SECONDS)),
            )
        except requests.RequestException as exc:
            print(f"ERROR: request failed while polling job {job_id}: {exc}", file=sys.stderr)
            sys.exit(1)

        if response.status_code == 404 and not once:
            job_doc = {
                "job_id": job_id,
                "status": "queued",
                "provider": None,
                "processed_rows": 0,
                "total_rows": 0,
                "error_rows": 0,
                "credits_used": 0.0,
                "billable": False,
                "updated_at": None,
            }
        else:
            content_type = response.headers.get("content-type", "").lower()
            if "application/json" in content_type:
                try:
                    parsed_body: Any = response.json()
                except Exception:
                    parsed_body = response.text
            else:
                parsed_body = response.text

            if response.status_code >= 300:
                print(f"ERROR: API {response.status_code}", file=sys.stderr)
                if isinstance(parsed_body, (dict, list)):
                    _print_json(parsed_body, compact=False)
                else:
                    print(str(parsed_body), file=sys.stderr)
                sys.exit(1)

            if not isinstance(parsed_body, dict):
                print(f"ERROR: unexpected bulk job response: {parsed_body}", file=sys.stderr)
                sys.exit(1)
            job_doc = parsed_body

        status = str(job_doc.get("status") or "").lower()
        snapshot = _job_snapshot(job_doc)

        should_print = print_updates and (once or polls == 1 or status != last_status)
        if should_print:
            _print_json(snapshot, compact=compact)
        last_status = status

        if once:
            return {"job": job_doc, "polls": polls, "timed_out": False}
        if status in TERMINAL_JOB_STATUSES:
            return {"job": job_doc, "polls": polls, "timed_out": False}
        if max_wait > 0 and (time.monotonic() - started) >= max_wait:
            return {"job": job_doc, "polls": polls, "timed_out": True}

        time.sleep(interval)


def cmd_auth_check(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    body = _request_api(
        "GET",
        "/api/capabilities",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    output = {
        "ok": True,
        "base_url": _api_url(args.base_url),
        "api_version": body.get("api_version") if isinstance(body, dict) else None,
        "auth_header_mode": "x-api-key" if args.use_x_api_key else "authorization",
    }
    _print_json(output, compact=args.compact)


def cmd_auth_set_key(args: argparse.Namespace) -> None:
    api_key = (args.api_key or "").strip() if getattr(args, "api_key", None) else None
    if not api_key:
        api_key = _resolve_token(None, required=False)
    if not api_key:
        print("ERROR: missing api key. Pass --api-key or set AUTOTOUCH_API_KEY/SMARTTABLE_TOKEN.", file=sys.stderr)
        sys.exit(2)

    cfg = _load_config()
    if cfg.get("api_key") and not args.overwrite:
        print(
            "ERROR: config already has an API key. Pass --overwrite to replace it.",
            file=sys.stderr,
        )
        sys.exit(2)

    base_url = str(args.base_url or cfg.get("base_url") or _api_url()).rstrip("/")
    cfg["api_key"] = api_key
    cfg["base_url"] = base_url
    cfg["updated_at_epoch"] = int(time.time())
    path = _save_config(cfg)

    _print_json(
        {
            "saved": True,
            "config_path": str(path),
            "base_url": base_url,
            "api_key_masked": _mask_api_key(api_key),
        },
        compact=args.compact,
    )


def cmd_auth_show(args: argparse.Namespace) -> None:
    cfg = _load_config()
    api_key = str(cfg.get("api_key") or "").strip()
    base_url = str(cfg.get("base_url") or _api_url()).rstrip("/")
    path = _config_path()
    output = {
        "config_path": str(path),
        "config_exists": path.exists(),
        "has_api_key": bool(api_key),
        "api_key_masked": _mask_api_key(api_key) if api_key else None,
        "base_url": base_url,
        "updated_at_epoch": cfg.get("updated_at_epoch"),
    }
    _print_json(output, compact=args.compact)


def cmd_auth_clear(args: argparse.Namespace) -> None:
    cfg = _load_config()
    changed = False
    if args.all:
        cfg = {}
        changed = True
    else:
        if "api_key" in cfg:
            cfg.pop("api_key", None)
            changed = True
        if args.clear_base_url and "base_url" in cfg:
            cfg.pop("base_url", None)
            changed = True
        if "updated_at_epoch" in cfg:
            cfg["updated_at_epoch"] = int(time.time())
            changed = True

    path = _save_config(cfg) if changed else _config_path()
    _print_json(
        {
            "cleared": changed,
            "config_path": str(path),
            "remaining_keys": sorted(list(cfg.keys())),
        },
        compact=args.compact,
    )


def cmd_capabilities(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        "/api/capabilities",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_tables_list(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    params: Dict[str, Any] = {}
    if args.view_mode:
        params["view_mode"] = args.view_mode
    data = _request_api(
        "GET",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params or None,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_tables_create(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data_payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if data_payload is not None:
        if not isinstance(data_payload, dict):
            print("ERROR: table create payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = data_payload
    else:
        if not args.name:
            print("ERROR: --name is required when --data-* is not provided", file=sys.stderr)
            sys.exit(2)
        metadata = _load_json_input(
            inline_json=args.metadata_json,
            file_path=args.metadata_file,
            context="metadata",
            default={},
        )
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            print("ERROR: metadata must be a JSON object", file=sys.stderr)
            sys.exit(2)
        payload = {"name": args.name, "metadata": metadata}

    data = _request_api(
        "POST",
        "/api/tables",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_rows_add(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    records_payload = _load_json_input(
        inline_json=args.records_json,
        file_path=args.records_file,
        context="records",
        default=None,
    )

    if records_payload is not None:
        records: List[Dict[str, Any]]
        if isinstance(records_payload, dict):
            if isinstance(records_payload.get("records"), list):
                records = records_payload.get("records")  # type: ignore[assignment]
            else:
                records = [records_payload]
        elif isinstance(records_payload, list):
            records = records_payload
        else:
            print("ERROR: records payload must be an object, list, or {records:[...]}", file=sys.stderr)
            sys.exit(2)

    else:
        records = None

    output = _create_rows_and_patch_records(
        table_id=args.table_id,
        records=records,
        blank_count=int(args.count or 1),
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
        detect_types=bool(args.detect_types),
    )
    _print_json(output, compact=args.compact)


def cmd_rows_delete(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "DELETE",
        f"/api/tables/{args.table_id}/rows/{args.row_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_rows_import_csv(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    records = _read_records_from_csv(
        args.file,
        delimiter=args.delimiter,
        encoding=args.encoding,
        trim_headers=bool(args.trim_headers),
        trim_values=bool(args.trim_values),
        empty_as_null=bool(args.empty_as_null),
        skip_empty_rows=bool(args.skip_empty_rows),
        limit=(int(args.limit) if args.limit else None),
    )
    if not records:
        output = {
            "created": 0,
            "rowIds": [],
            "updatedCells": 0,
            "patchResult": None,
            "recordsParsed": 0,
            "source": args.file,
        }
        _print_json(output, compact=args.compact)
        return

    output = _create_rows_and_patch_records(
        table_id=args.table_id,
        records=records,
        blank_count=0,
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
        detect_types=bool(args.detect_types),
    )
    output["recordsParsed"] = len(records)
    output["source"] = args.file
    _print_json(output, compact=args.compact)


def cmd_cells_patch(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.updates_json,
        file_path=args.updates_file,
        context="updates",
        default=None,
    )
    if payload is None:
        print("ERROR: provide --updates-json or --updates-file", file=sys.stderr)
        sys.exit(2)
    if isinstance(payload, list):
        payload = {"updates": payload}
    if not isinstance(payload, dict) or not isinstance(payload.get("updates"), list):
        print("ERROR: updates payload must be a list or an object with an 'updates' list", file=sys.stderr)
        sys.exit(2)

    params = {"detect_types": "true"} if args.detect_types else None
    data = _request_api(
        "PATCH",
        f"/api/tables/{args.table_id}/cells",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_list(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        f"/api/tables/{args.table_id}/columns",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_create(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if not isinstance(payload, dict):
        print("ERROR: column create requires --data-json/--data-file with a JSON object", file=sys.stderr)
        sys.exit(2)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_projections(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=args.data_json,
        file_path=args.data_file,
        context="data",
        default=None,
    )
    if not isinstance(payload, dict):
        print("ERROR: projection create requires --data-json/--data-file with a JSON object", file=sys.stderr)
        sys.exit(2)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/projections",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_columns_run(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _normalize_run_payload(args)
    estimate_data: Optional[Dict[str, Any]] = None
    should_estimate = bool(args.show_estimate or args.max_credits is not None or args.dry_run)
    if should_estimate:
        estimate_raw = _request_api(
            "POST",
            f"/api/tables/{args.table_id}/columns/{args.column_id}/estimate",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            payload=payload,
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if not isinstance(estimate_raw, dict):
            print(f"ERROR: unexpected estimate response: {estimate_raw}", file=sys.stderr)
            sys.exit(1)
        estimate_data = estimate_raw

    if args.max_credits is not None:
        if estimate_data is None:
            print("ERROR: failed to compute estimate for --max-credits guard", file=sys.stderr)
            sys.exit(1)
        limit = float(args.max_credits)
        estimated_max = estimate_data.get("estimated_credits_max")
        estimated_min = float(estimate_data.get("estimated_credits_min") or 0.0)

        if estimated_max is None and not bool(args.allow_unknown_max):
            output = {
                "blocked": True,
                "reason": "estimated_credits_max is unknown; pass --allow-unknown-max to proceed",
                "max_credits_limit": limit,
                "estimate": estimate_data,
            }
            _print_json(output, compact=args.compact)
            sys.exit(3)

        compare_value = float(estimated_max if estimated_max is not None else estimated_min)
        if compare_value > limit:
            output = {
                "blocked": True,
                "reason": "estimated credits exceed max-credits limit",
                "max_credits_limit": limit,
                "estimate_compare_value": compare_value,
                "estimate": estimate_data,
            }
            _print_json(output, compact=args.compact)
            sys.exit(3)

    if args.dry_run:
        _print_json(
            {
                "dry_run": True,
                "run_payload": payload,
                "estimate": estimate_data,
            },
            compact=args.compact,
        )
        return

    run_data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/{args.column_id}/run",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if not isinstance(run_data, dict):
        _print_json(run_data, compact=args.compact)
        return

    if args.wait:
        job_id = run_data.get("job_id") or run_data.get("jobId")
        if not job_id:
            print("ERROR: run response missing job_id; cannot wait", file=sys.stderr)
            _print_json(run_data, compact=args.compact)
            sys.exit(1)

        poll_result = _poll_job(
            job_id=str(job_id),
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            interval_seconds=int(args.poll_interval or 2),
            wait_timeout_seconds=int(args.wait_timeout or 0),
            request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=args.verbose,
            compact=args.compact,
            once=False,
            print_updates=not args.quiet_wait,
        )
        final_job = poll_result.get("job") or {}
        timed_out = bool(poll_result.get("timed_out"))
        output = {
            "run": run_data,
            "estimate": estimate_data if args.show_estimate or args.max_credits is not None else None,
            "final_job": final_job,
            "timed_out": timed_out,
            "polls": int(poll_result.get("polls") or 0),
        }
        _print_json(output, compact=args.compact)

        if timed_out:
            sys.exit(4)
        final_status = str((final_job or {}).get("status") or "").lower()
        if args.fail_on_error and final_status in {"error", "cancelled"}:
            sys.exit(1)
        if args.fail_on_partial and final_status == "partial":
            sys.exit(1)
        return

    output: Any = run_data
    if estimate_data is not None and args.show_estimate:
        output = {"estimate": estimate_data, "run": run_data}
    _print_json(output, compact=args.compact)


def cmd_columns_estimate(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    payload = _normalize_run_payload(args)
    data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/{args.column_id}/estimate",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_jobs_get(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "GET",
        f"/api/bulk-jobs/{args.job_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_jobs_watch(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    poll_result = _poll_job(
        job_id=args.job_id,
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        interval_seconds=int(args.interval or 2),
        wait_timeout_seconds=int(args.wait_timeout or 0),
        request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
        verbose=args.verbose,
        compact=args.compact,
        once=bool(args.once),
        print_updates=True,
    )
    final_job = poll_result.get("job") or {}
    timed_out = bool(poll_result.get("timed_out"))

    if args.once:
        return

    final_summary = {
        "job_id": final_job.get("job_id") or final_job.get("jobId") or args.job_id,
        "status": final_job.get("status"),
        "timed_out": timed_out,
        "polls": int(poll_result.get("polls") or 0),
    }
    _print_json(final_summary, compact=args.compact)

    if timed_out:
        sys.exit(4)
    status = str(final_job.get("status") or "").lower()
    if args.fail_on_error and status in {"error", "cancelled"}:
        sys.exit(1)
    if args.fail_on_partial and status == "partial":
        sys.exit(1)


def _mongo_client(uri: Optional[str], db_name: Optional[str]):
    if MongoClient is None:
        print("ERROR: pymongo not installed. Install requirements and retry.", file=sys.stderr)
        sys.exit(2)
    _uri = uri or os.environ.get("MONGODB_URI")
    if not _uri:
        print("ERROR: MONGODB_URI not set. Export MONGODB_URI or pass --mongo-uri", file=sys.stderr)
        sys.exit(2)
    _db = (db_name or os.environ.get("MONGODB_DB_NAME") or "autotouch")
    client = MongoClient(_uri)
    return client[_db]


def _status_counts(db, table_id: str, column_id: str) -> Dict[str, int]:
    row_ids = [str(r["_id"]) for r in db["rows"].find({"table_id": table_id}, {"_id": 1})]
    if not row_ids:
        return {"pending": 0, "done": 0, "error": 0}
    pipeline = [
        {"$match": {"column_id": column_id, "row_id": {"$in": row_ids}}},
        {"$group": {"_id": {"$ifNull": ["$status", "missing"]}, "count": {"$sum": 1}}},
    ]
    res = list(db["cells"].aggregate(pipeline))
    m = {d.get("_id"): int(d.get("count") or 0) for d in res}
    for k in ("pending", "done", "error"):
        m.setdefault(k, 0)
    return {k: m[k] for k in ("pending", "done", "error")}


def cmd_status(args: argparse.Namespace) -> None:
    db = _mongo_client(args.mongo_uri, args.db_name)
    counts = _status_counts(db, args.table_id, args.column_id)
    total = sum(counts.values())
    _print_json(
        {"pending": counts["pending"], "done": counts["done"], "error": counts["error"], "totalCells": total},
        compact=False,
    )


def cmd_watch(args: argparse.Namespace) -> None:
    db = _mongo_client(args.mongo_uri, args.db_name)
    interval = max(1, int(args.interval or 5))
    try:
        while True:
            counts = _status_counts(db, args.table_id, args.column_id)
            total = sum(counts.values())
            print(f"pending={counts['pending']} done={counts['done']} error={counts['error']} total={total}")
            sys.stdout.flush()
            time.sleep(interval)
    except KeyboardInterrupt:
        pass


def _add_api_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    parser.add_argument("--token", help="Developer API key / JWT token")
    parser.add_argument("--use-x-api-key", action="store_true", help="Send token via X-API-Key header")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    parser.add_argument("--compact", action="store_true", help="Print compact JSON")
    parser.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")


def _add_run_scope_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--scope", choices=["all", "subset", "row", "firstN", "filtered"], default="all")
    parser.add_argument("--row-id", help="Single row ID for scope=row")
    parser.add_argument("--row-ids", nargs="*", help="Row IDs for subset/row scopes")
    parser.add_argument("--first-n", type=int, help="First N rows (for scope=firstN)")
    parser.add_argument("--unprocessed-only", action="store_true", help="Only process rows without values")
    parser.add_argument("--filters-json", help="JSON object for scope=filtered")
    parser.add_argument("--filters-file", help="Path to JSON file for scope=filtered")
    parser.add_argument("--data-json", help="Explicit RunRequest payload JSON (overrides scope flags)")
    parser.add_argument("--data-file", help="Path to RunRequest payload JSON file (overrides scope flags)")


def _add_run_execution_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--show-estimate", action="store_true", help="Include estimate response in output")
    parser.add_argument("--dry-run", action="store_true", help="Only estimate; do not execute run")
    parser.add_argument("--max-credits", type=float, help="Block run when estimate exceeds this value")
    parser.add_argument(
        "--allow-unknown-max",
        action="store_true",
        help="Allow run when estimated_credits_max is null (max-credits guard uses min estimate)",
    )
    parser.add_argument("--wait", action="store_true", help="Wait for bulk job terminal status")
    parser.add_argument("--quiet-wait", action="store_true", help="Suppress per-poll output in --wait mode")
    parser.add_argument("--poll-interval", type=int, default=2, help="Polling interval seconds for --wait")
    parser.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    parser.add_argument("--fail-on-error", action="store_true", help="Exit non-zero when final status is error/cancelled")
    parser.add_argument("--fail-on-partial", action="store_true", help="Exit non-zero when final status is partial")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="autotouch", description="Smart Table CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    # auth
    auth = sub.add_parser("auth", help="Auth helpers")
    auth_sub = auth.add_subparsers(dest="auth_cmd", required=True)
    pa = auth_sub.add_parser("check", help="Validate token against /api/capabilities")
    _add_api_common_arguments(pa)
    pa.set_defaults(func=cmd_auth_check)

    pask = auth_sub.add_parser("set-key", help="Persist API key/base URL to user config")
    pask.add_argument("--api-key", help="Developer API key to store (defaults from env if omitted)")
    pask.add_argument("--base-url", help=f"Default API base URL (default: {DEFAULT_API_URL})")
    pask.add_argument("--overwrite", action="store_true", help="Replace existing stored API key")
    pask.add_argument("--compact", action="store_true", help="Print compact JSON")
    pask.set_defaults(func=cmd_auth_set_key)

    pashow = auth_sub.add_parser("show", help="Show current auth config")
    pashow.add_argument("--compact", action="store_true", help="Print compact JSON")
    pashow.set_defaults(func=cmd_auth_show)

    paclear = auth_sub.add_parser("clear", help="Clear stored auth config")
    paclear.add_argument("--all", action="store_true", help="Clear all config keys")
    paclear.add_argument("--clear-base-url", action="store_true", help="Also clear stored base_url")
    paclear.add_argument("--compact", action="store_true", help="Print compact JSON")
    paclear.set_defaults(func=cmd_auth_clear)

    # capabilities
    pc = sub.add_parser("capabilities", help="Get machine-readable API capabilities")
    _add_api_common_arguments(pc)
    pc.set_defaults(func=cmd_capabilities)

    # tables
    pt = sub.add_parser("tables", help="Table operations")
    tables_sub = pt.add_subparsers(dest="tables_cmd", required=True)
    ptl = tables_sub.add_parser("list", help="List tables")
    ptl.add_argument("--view-mode", choices=["org", "user", "all"], default="org")
    _add_api_common_arguments(ptl)
    ptl.set_defaults(func=cmd_tables_list)

    ptc = tables_sub.add_parser("create", help="Create a table")
    ptc.add_argument("--name", help="Table name")
    ptc.add_argument("--metadata-json", help="Metadata JSON object")
    ptc.add_argument("--metadata-file", help="Metadata JSON file path")
    ptc.add_argument("--data-json", help="Explicit TableCreate payload JSON")
    ptc.add_argument("--data-file", help="Explicit TableCreate payload file")
    _add_api_common_arguments(ptc)
    ptc.set_defaults(func=cmd_tables_create)

    # rows
    pr = sub.add_parser("rows", help="Row operations")
    rows_sub = pr.add_subparsers(dest="rows_cmd", required=True)
    pra = rows_sub.add_parser("add", help="Add rows (blank count or records payload)")
    pra.add_argument("--table-id", required=True)
    pra.add_argument("--count", type=int, default=1, help="Blank rows to create (ignored if records provided)")
    pra.add_argument("--records-json", help="Object, list, or {records:[...]} payload")
    pra.add_argument("--records-file", help="Path to JSON file containing records payload")
    pra.add_argument("--detect-types", action="store_true", help="Enable detect_types when patching record values")
    _add_api_common_arguments(pra)
    pra.set_defaults(func=cmd_rows_add)

    pric = rows_sub.add_parser("import-csv", help="Import CSV rows by creating rows + patching cells")
    pric.add_argument("--table-id", required=True)
    pric.add_argument("--file", required=True, help="CSV file path")
    pric.add_argument("--delimiter", default=",", help="CSV delimiter (default: ,)")
    pric.add_argument("--encoding", default="utf-8", help="File encoding (default: utf-8)")
    pric.add_argument("--limit", type=int, help="Optional max records to import")
    pric.add_argument("--no-trim-headers", dest="trim_headers", action="store_false", help="Do not trim header whitespace")
    pric.add_argument("--trim-values", action="store_true", help="Trim cell string values")
    pric.add_argument("--no-empty-as-null", dest="empty_as_null", action="store_false", help="Preserve empty strings instead of null")
    pric.add_argument("--no-skip-empty-rows", dest="skip_empty_rows", action="store_false", help="Keep fully empty rows")
    pric.add_argument("--detect-types", action="store_true", help="Enable detect_types while patching")
    pric.set_defaults(trim_headers=True, empty_as_null=True, skip_empty_rows=True)
    _add_api_common_arguments(pric)
    pric.set_defaults(func=cmd_rows_import_csv)

    prd = rows_sub.add_parser("delete", help="Delete a single row")
    prd.add_argument("--table-id", required=True)
    prd.add_argument("--row-id", required=True)
    _add_api_common_arguments(prd)
    prd.set_defaults(func=cmd_rows_delete)

    # cells
    pcell = sub.add_parser("cells", help="Cell operations")
    cells_sub = pcell.add_subparsers(dest="cells_cmd", required=True)
    pcp = cells_sub.add_parser("patch", help="Patch cells in batch")
    pcp.add_argument("--table-id", required=True)
    pcp.add_argument("--updates-json", help="JSON list or {updates:[...]} object")
    pcp.add_argument("--updates-file", help="Path to JSON file with updates payload")
    pcp.add_argument("--detect-types", action="store_true", help="Set detect_types=true query flag")
    _add_api_common_arguments(pcp)
    pcp.set_defaults(func=cmd_cells_patch)

    # columns
    pcol = sub.add_parser("columns", help="Column operations")
    col_sub = pcol.add_subparsers(dest="columns_cmd", required=True)

    pcl = col_sub.add_parser("list", help="List table columns")
    pcl.add_argument("--table-id", required=True)
    _add_api_common_arguments(pcl)
    pcl.set_defaults(func=cmd_columns_list)

    pcc = col_sub.add_parser("create", help="Create a column")
    pcc.add_argument("--table-id", required=True)
    pcc.add_argument("--data-json", help="ColumnCreate payload JSON")
    pcc.add_argument("--data-file", help="ColumnCreate payload file path")
    _add_api_common_arguments(pcc)
    pcc.set_defaults(func=cmd_columns_create)

    pcpj = col_sub.add_parser("projections", help="Create JSON projection columns")
    pcpj.add_argument("--table-id", required=True)
    pcpj.add_argument("--data-json", help="CreateProjectionsRequest payload JSON")
    pcpj.add_argument("--data-file", help="CreateProjectionsRequest payload file path")
    _add_api_common_arguments(pcpj)
    pcpj.set_defaults(func=cmd_columns_projections)

    pcr = col_sub.add_parser("run", help="Run a column")
    pcr.add_argument("--table-id", required=True)
    pcr.add_argument("--column-id", required=True)
    _add_run_scope_arguments(pcr)
    _add_run_execution_arguments(pcr)
    _add_api_common_arguments(pcr)
    pcr.set_defaults(func=cmd_columns_run)

    pce = col_sub.add_parser("estimate", help="Estimate a column run")
    pce.add_argument("--table-id", required=True)
    pce.add_argument("--column-id", required=True)
    _add_run_scope_arguments(pce)
    _add_api_common_arguments(pce)
    pce.set_defaults(func=cmd_columns_estimate)

    # jobs
    pj = sub.add_parser("jobs", help="Bulk job operations")
    jobs_sub = pj.add_subparsers(dest="jobs_cmd", required=True)
    pjg = jobs_sub.add_parser("get", help="Get bulk job details")
    pjg.add_argument("--job-id", required=True)
    _add_api_common_arguments(pjg)
    pjg.set_defaults(func=cmd_jobs_get)

    pjw = jobs_sub.add_parser("watch", help="Poll bulk job status until terminal (or once)")
    pjw.add_argument("--job-id", required=True)
    pjw.add_argument("--once", action="store_true", help="Fetch once and exit")
    pjw.add_argument("--interval", type=int, default=2, help="Polling interval seconds")
    pjw.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    pjw.add_argument("--fail-on-error", action="store_true", help="Exit non-zero on error/cancelled")
    pjw.add_argument("--fail-on-partial", action="store_true", help="Exit non-zero on partial")
    _add_api_common_arguments(pjw)
    pjw.set_defaults(func=cmd_jobs_watch)

    # Backward-compatible aliases
    # run
    palias_run = sub.add_parser("run", help="Alias for: columns run")
    palias_run.add_argument("--table-id", required=True)
    palias_run.add_argument("--column-id", required=True)
    _add_run_scope_arguments(palias_run)
    _add_run_execution_arguments(palias_run)
    _add_api_common_arguments(palias_run)
    palias_run.set_defaults(func=cmd_columns_run)

    # status
    ps = sub.add_parser("status", help="Show pending/done/error counts for a table/column (Mongo)")
    ps.add_argument("--table-id", required=True)
    ps.add_argument("--column-id", required=True)
    ps.add_argument("--mongo-uri", help="Override MONGODB_URI")
    ps.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    ps.set_defaults(func=cmd_status)

    # watch
    pw = sub.add_parser("watch", help="Watch status periodically (Mongo)")
    pw.add_argument("--table-id", required=True)
    pw.add_argument("--column-id", required=True)
    pw.add_argument("--interval", type=int, default=5)
    pw.add_argument("--mongo-uri", help="Override MONGODB_URI")
    pw.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    pw.set_defaults(func=cmd_watch)

    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
