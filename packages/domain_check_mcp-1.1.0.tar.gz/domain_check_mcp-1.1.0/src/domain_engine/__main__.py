from domain_engine.server import main

main()
