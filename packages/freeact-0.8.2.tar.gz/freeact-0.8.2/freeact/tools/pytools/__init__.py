MCPTOOLS_DIR = "mcptools"
GENTOOLS_DIR = "gentools"
