# Unmanic migrations v1

This directory contains DB migrations for Unmanic >= 0.1.0.
