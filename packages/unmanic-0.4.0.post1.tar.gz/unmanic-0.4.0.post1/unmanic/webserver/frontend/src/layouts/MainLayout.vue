<template>
  <q-layout view="hHh lpR lFf">

    <q-header
      reveal
      class="header-background text-white"
      height-hint="98"
      :style="leftMainNavDrawerOpen ? 'z-index: 3001' : ''"
    >
      <q-toolbar>

        <!--SHOW DRAWER MENU BUTTON-->
        <q-btn
          v-if="$route.meta.showMainNavDrawer"
          dense
          flat
          round
          :icon="leftMainNavDrawerOpen ? 'menu_open' : 'menu'"
          @click="toggleMainNavDrawer"/>

        <!--SHOW SETTINGS MENU BUTTON-->
        <q-btn
          v-if="$route.meta.showSettingsDrawer"
          dense
          flat
          round
          :icon="leftSettingsDrawerOpen ? 'menu_open' : 'menu'"
          @click="toggleSettingsDrawer"/>

        <!--SHOW DATA PANELS MENU BUTTON-->
        <q-btn
          v-if="$route.meta.showDataPanelsDrawer"
          dense
          flat
          round
          :icon="leftDataPanelsDrawerOpen ? 'menu_open' : 'menu'"
          @click="toggleDataPanelsDrawer"/>

        <!--SHOW HOME BUTTON-->
        <q-btn
          v-if="$route.meta.showHome"
          dense
          flat
          round
          @click="$router.push('/ui/dashboard'); leftMainNavDrawerOpen = false"
          icon="home">
        </q-btn>

        <q-toolbar-title shrink>
          <q-avatar rounded size="2rem" font-size="82px" class="q-mr-lg">
            <img src="~assets/unmanic-logo-white.png">
          </q-avatar>
        </q-toolbar-title>

        <div class="gt-xs">
          <SharedLinkDropdown/>
        </div>

        <q-space/>

        <div class="gt-xs">
          <ThemeSwitch/>
        </div>

        <!-- TODO: Enable notifications for mobile -->
        <div
          v-if="!$q.platform.is.mobile"
          class="q-gutter-sm row items-center no-wrap">
          <q-btn
            dense
            flat
            round
            icon="notifications"
            @click="toggleNotificationsDrawer">
            <q-badge
              v-if="notificationsCount > 0"
              color="red" text-color="white" floating>
              {{ notificationsCount }}
            </q-badge>
            <q-tooltip>Notifications</q-tooltip>
          </q-btn>
        </div>
      </q-toolbar>

    </q-header>

    <q-drawer
      v-if="$route.meta.showMainNavDrawer"
      v-model="leftMainNavDrawerOpen"
      side="left"
      :behavior="$q.screen.lt.md ? 'mobile' : 'desktop'">
      <DrawerMainNav/>
    </q-drawer>

    <q-drawer
      v-if="$route.meta.showSettingsDrawer"
      v-model="leftSettingsDrawerOpen"
      side="left"
      :behavior="$q.screen.lt.md ? 'mobile' : 'desktop'">
      <DrawerSettingsNav/>
    </q-drawer>

    <q-drawer
      v-if="$route.meta.showDataPanelsDrawer"
      v-model="leftDataPanelsDrawerOpen"
      side="left"
      :behavior="$q.screen.lt.md ? 'mobile' : 'desktop'">
      <DrawerDataPanelsNav/>
    </q-drawer>

    <!-- TODO: Enable notifications for mobile -->
    <q-drawer
      v-if="!$q.platform.is.mobile"
      v-model="rightNotificationsDrawerOpen"
      side="right"
      :width="650"
      :overlay="$route.meta.showMainNavDrawer"
      bordered
      :behavior="$q.screen.lt.md ? 'mobile' : 'desktop'">
      <DrawerNotifications/>
    </q-drawer>

    <q-page-container>
      <router-view/>
    </q-page-container>

    <q-footer
      class="footer-background text-white gt-sm">
      <q-toolbar>
        <q-toolbar-title>
          <FooterData/>
        </q-toolbar-title>
      </q-toolbar>
    </q-footer>

  </q-layout>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue';
import DrawerMainNav from "components/drawers/DrawerMainNav";
import FooterData from "components/FooterData";
import DrawerSettingsNav from "components/drawers/DrawerSettingsNav";
import { useQuasar } from "quasar";
import DrawerDataPanelsNav from "components/drawers/DrawerDataPanelsNav";
import ThemeSwitch from "components/ThemeSwitch";
import DrawerNotifications from "components/drawers/DrawerNotifications";
import SharedLinkDropdown from "components/SharedLinkDropdown";
import unmanicGlobals from "src/js/unmanicGlobals";

export default {
  components: {
    DrawerDataPanelsNav,
    DrawerMainNav,
    DrawerNotifications,
    DrawerSettingsNav,
    FooterData,
    ThemeSwitch,
    SharedLinkDropdown
  },
  setup() {
    const $q = useQuasar();

    let reloadInterval = null;

    const leftMainNavDrawerOpen = ref(false)
    const leftSettingsDrawerOpen = ref(false)
    const leftDataPanelsDrawerOpen = ref(false)
    const rightNotificationsDrawerOpen = ref(false)

    const notificationsCount = ref(null)

    if (!$q.screen.lt.md) {
      leftSettingsDrawerOpen.value = true;
      leftDataPanelsDrawerOpen.value = true;
    }

    function toggleMainNavDrawer() {
      leftMainNavDrawerOpen.value = !leftMainNavDrawerOpen.value
    }

    function toggleSettingsDrawer() {
      leftSettingsDrawerOpen.value = !leftSettingsDrawerOpen.value
    }

    function toggleDataPanelsDrawer() {
      leftDataPanelsDrawerOpen.value = !leftDataPanelsDrawerOpen.value
    }

    function toggleNotificationsDrawer() {
      rightNotificationsDrawerOpen.value = !rightNotificationsDrawerOpen.value
    }

    function getNotificationsCount() {
      let notificationsList = unmanicGlobals.getUnmanicNotifications();
      notificationsCount.value = notificationsList.length;
    }

    onMounted(() => {
      // If the reloadInterval has not yet been set
      if (reloadInterval === null) {
        // Set the interval to refresh every second
        reloadInterval = setInterval(() => {
          getNotificationsCount();
        }, 1000);
      }
    })

    onUnmounted(() => {
      if (reloadInterval !== null) {
        clearInterval(reloadInterval);
      }
    })

    return {
      leftMainNavDrawerOpen,
      leftSettingsDrawerOpen,
      leftDataPanelsDrawerOpen,
      rightNotificationsDrawerOpen,
      toggleMainNavDrawer,
      toggleSettingsDrawer,
      toggleDataPanelsDrawer,
      toggleNotificationsDrawer,

      notificationsCount
    }
  }
}
</script>

<style>

</style>
