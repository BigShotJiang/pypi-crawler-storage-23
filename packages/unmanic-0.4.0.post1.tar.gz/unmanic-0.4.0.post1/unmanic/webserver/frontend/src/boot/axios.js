import { boot } from 'quasar/wrappers'
import axios from 'axios'
import { sharedLinksStore } from 'src/js/sharedLinksStore'

// Add interceptor to safely attach the proxy header only to internal requests
axios.interceptors.request.use((config) => {
  const target = sharedLinksStore.target
  if (target && target !== 'local' && !config.skipProxy) {
    // Determine if the request is destined for this Unmanic instance (Internal)
    // Relative URLs are internal. Absolute URLs must match the current origin.
    const isAbsolute = config.url.startsWith('http://') || config.url.startsWith('https://');
    const isInternal = !isAbsolute || config.url.startsWith(window.location.origin);

    if (isInternal) {
      config.headers['X-Unmanic-Target-Installation'] = target
    }
  }
  return config
}, (error) => {
  return Promise.reject(error)
})

// Be careful when using SSR for cross-request state pollution
// due to creating a Singleton instance here;
// If any client changes this (global) instance, it might be a
// good idea to move this instance creation inside of the
// "export default () => {}" function below (which runs individually
// for each client)
const api = axios.create({ baseURL: 'https://api.example.com' })

export default boot(({ app }) => {
  // for use inside Vue files (Options API) through this.$axios and this.$api

  app.config.globalProperties.$axios = axios
  // ^ ^ ^ this will allow you to use this.$axios (for Vue Options API form)
  //       so you won't necessarily have to import axios in each vue file

  app.config.globalProperties.$api = api
  // ^ ^ ^ this will allow you to use this.$api (for Vue Options API form)
  //       so you can easily perform requests against your app's API
})

export { axios, api }
