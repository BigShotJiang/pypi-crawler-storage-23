"""Migration executor for applying and rolling back database migrations."""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from types import TracebackType
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from confiture.config.environment import Environment
    from confiture.models.results import (
        MigrateDownResult,
        MigrateRebuildResult,
        MigrateReinitResult,
        MigrateUpResult,
        StatusResult,
    )

import psycopg

from confiture.core.checksum import (
    ChecksumConfig,
    MigrationChecksumVerifier,
    compute_checksum,
)
from confiture.core.connection import (
    create_connection,
    get_migration_class,
    load_migration_class,
    load_migration_module,
)
from confiture.core.dry_run import DryRunExecutor, DryRunResult
from confiture.core.hooks import HookError
from confiture.core.locking import LockConfig, MigrationLock
from confiture.core.preconditions import PreconditionValidationError, PreconditionValidator
from confiture.core.progress import ProgressManager
from confiture.exceptions import MigrationError, SQLError
from confiture.models.migration import Migration

logger = logging.getLogger(__name__)

# Allows 'table_name' or 'schema.table_name' (letters, digits, underscores only)
_VALID_TABLE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)?$")


def _version_from_migration_filename(filename: str) -> str:
    """Extract version prefix from a migration filename.

    Args:
        filename: Migration filename (e.g., "001_create_users.py")

    Returns:
        Version string (e.g., "001")
    """
    if filename.endswith(".up.sql"):
        filename = filename[:-7]
    elif filename.endswith(".down.sql"):
        filename = filename[:-9]
    return filename.split("_")[0]


def find_duplicate_migration_versions(migrations_dir: Path) -> dict[str, list[Path]]:
    """Find migration files that share the same version prefix.

    Standalone function (no Migrator instance needed). Scans .py and .up.sql
    files, groups by version prefix, returns only versions with >1 file.

    Args:
        migrations_dir: Directory containing migration files

    Returns:
        Dict mapping version strings to lists of conflicting file paths.
        Empty dict if no duplicates exist or directory doesn't exist.
    """
    if not migrations_dir.exists():
        return {}

    py_files = [
        f
        for f in migrations_dir.glob("*.py")
        if f.name != "__init__.py" and not f.name.startswith("_")
    ]
    sql_files = list(migrations_dir.glob("*.up.sql"))
    all_files = py_files + sql_files

    version_map: dict[str, list[Path]] = {}
    for f in all_files:
        version = _version_from_migration_filename(f.name)
        version_map.setdefault(version, []).append(f)

    return {
        v: sorted(files, key=lambda p: p.name) for v, files in version_map.items() if len(files) > 1
    }


class Migrator:
    """Executes database migrations and tracks their state.

    The Migrator class is responsible for:
    - Creating and managing the tb_confiture tracking table
    - Applying migrations (running up() methods)
    - Rolling back migrations (running down() methods)
    - Recording execution time and checksums
    - Ensuring transaction safety

    Example:
        >>> conn = psycopg.connect("postgresql://localhost/mydb")
        >>> migrator = Migrator(connection=conn)
        >>> migrator.initialize()
        >>> migrator.apply(my_migration)
    """

    def __init__(
        self,
        connection: psycopg.Connection,
        migration_table: str = "tb_confiture",
    ):
        """Initialize migrator with database connection.

        Args:
            connection: psycopg3 database connection
            migration_table: Name of the tracking table. May be schema-qualified
                (e.g. ``public.tb_confiture``). Defaults to ``tb_confiture``.

        Raises:
            ValueError: If migration_table contains characters that are not
                safe for use as an unquoted SQL identifier.
        """
        if not _VALID_TABLE_RE.match(migration_table):
            raise ValueError(
                f"Invalid migration_table name: {migration_table!r}. "
                "Use letters, digits, and underscores only, optionally "
                "schema-qualified (e.g. 'public.tb_confiture')."
            )
        self.connection = connection
        self.migration_table = migration_table
        # Unqualified table name — used for index names and information_schema lookups
        self._table_base = migration_table.split(".")[-1]
        # Schema part (None when not schema-qualified)
        parts = migration_table.split(".", 1)
        self._table_schema: str | None = parts[0] if len(parts) == 2 else None

    def _execute_sql(self, sql: str, params: tuple[str, ...] | None = None) -> None:
        """Execute SQL with detailed error reporting.

        Args:
            sql: SQL statement to execute
            params: Optional query parameters

        Raises:
            SQLError: If SQL execution fails with detailed context
        """
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
        except Exception as e:
            raise SQLError(sql, params, e) from e

    def initialize(self) -> None:
        """Create tb_confiture tracking table with Trinity pattern.

        Identity pattern (Trinity):
        - id: UUID (external, stable identifier)
        - pk_confiture: BIGINT (internal, sequential)
        - slug: TEXT (human-readable reference)

        This method is idempotent - safe to call multiple times.

        Raises:
            MigrationError: If table creation fails
        """
        try:
            # Enable UUID extension
            self._execute_sql('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

            # Check if table exists (schema-aware)
            with self.connection.cursor() as cursor:
                if self._table_schema is not None:
                    cursor.execute(
                        """
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables
                            WHERE table_schema = %s AND table_name = %s
                        )
                        """,
                        (self._table_schema, self._table_base),
                    )
                else:
                    cursor.execute(
                        """
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables
                            WHERE table_name = %s
                        )
                        """,
                        (self._table_base,),
                    )
                result = cursor.fetchone()
                table_exists = result[0] if result else False

            if not table_exists:
                # Create new table with Trinity pattern
                self._execute_sql(f"""
                    CREATE TABLE {self.migration_table} (
                        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                        pk_confiture BIGINT GENERATED ALWAYS AS IDENTITY UNIQUE,
                        slug TEXT NOT NULL UNIQUE,
                        version VARCHAR(255) NOT NULL UNIQUE,
                        name VARCHAR(255) NOT NULL,
                        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        execution_time_ms INTEGER,
                        checksum VARCHAR(64)
                    )
                """)

                # Create indexes
                self._execute_sql(f"""
                    CREATE INDEX idx_{self._table_base}_pk_confiture
                        ON {self.migration_table}(pk_confiture)
                """)
                self._execute_sql(f"""
                    CREATE INDEX idx_{self._table_base}_slug
                        ON {self.migration_table}(slug)
                """)
                self._execute_sql(f"""
                    CREATE INDEX idx_{self._table_base}_version
                        ON {self.migration_table}(version)
                """)
                self._execute_sql(f"""
                    CREATE INDEX idx_{self._table_base}_applied_at
                        ON {self.migration_table}(applied_at DESC)
                """)

            self.connection.commit()
        except Exception as e:
            self.connection.rollback()
            if isinstance(e, SQLError):
                raise MigrationError(f"Failed to initialize migrations table: {e}") from e
            else:
                raise MigrationError(f"Failed to initialize migrations table: {e}") from e

    def apply(
        self,
        migration: Migration,
        force: bool = False,
        migration_file: Path | None = None,
        skip_preconditions: bool = False,
    ) -> None:
        """Apply a migration and record it in the tracking table.

        For transactional migrations (default):
        - Uses savepoints for clean rollback on failure
        - Executes hooks before and after DDL execution

        For non-transactional migrations (transactional=False):
        - Runs in autocommit mode
        - No automatic rollback on failure
        - Required for CREATE INDEX CONCURRENTLY, etc.

        Precondition Validation:
        - If migration defines up_preconditions, they are validated first
        - If any precondition fails, the migration is aborted
        - Use skip_preconditions=True to bypass validation (not recommended)

        Args:
            migration: Migration instance to apply
            force: If True, skip the "already applied" check
            migration_file: Path to migration file for checksum computation
            skip_preconditions: If True, skip precondition validation (not recommended)

        Raises:
            MigrationError: If migration fails or hooks fail
            PreconditionValidationError: If precondition validation fails
        """
        already_applied = self._is_applied(migration.version)

        if not force and already_applied:
            raise MigrationError(
                f"Migration {migration.version} ({migration.name}) has already been applied"
            )

        # Validate preconditions before applying
        if not skip_preconditions:
            self._validate_preconditions(
                migration, direction="up", preconditions=migration.up_preconditions
            )

        if migration.transactional:
            self._apply_transactional(migration, already_applied, migration_file)
        else:
            self._apply_non_transactional(migration, already_applied, migration_file)

    def _validate_preconditions(
        self,
        migration: Migration,
        direction: str,
        preconditions: list,
    ) -> None:
        """Validate migration preconditions before execution.

        Args:
            migration: Migration being validated
            direction: "up" or "down" for error messages
            preconditions: List of preconditions to check

        Raises:
            PreconditionValidationError: If any precondition fails
        """
        if not preconditions:
            return

        logger.debug(
            f"Validating {len(preconditions)} preconditions for migration "
            f"{migration.version} ({direction})"
        )

        validator = PreconditionValidator(self.connection)
        try:
            validator.validate(
                preconditions,
                migration_version=migration.version,
                migration_name=migration.name,
            )
            logger.debug(f"All preconditions passed for migration {migration.version}")
        except PreconditionValidationError as e:
            logger.error(f"Precondition validation failed for migration {migration.version}: {e}")
            raise

    def _apply_transactional(
        self,
        migration: Migration,
        already_applied: bool,
        migration_file: Path | None = None,
    ) -> None:
        """Apply migration within a transaction using savepoints.

        Args:
            migration: Migration instance to apply
            already_applied: Whether migration was already applied (force mode)
            migration_file: Path to migration file for checksum computation
        """
        savepoint_name = f"migration_{migration.version}"
        try:
            self._create_savepoint(savepoint_name)

            # Execute migration DDL
            logger.debug(f"Executing DDL for migration {migration.version}")
            start_time = time.perf_counter()
            migration.up()
            execution_time_ms = int((time.perf_counter() - start_time) * 1000)

            # Only record the migration if it's not already applied
            # In force mode, we re-apply but don't re-record
            if not already_applied:
                self._record_migration(migration, execution_time_ms, migration_file)
            self._release_savepoint(savepoint_name)

            self.connection.commit()
            logger.info(f"Successfully applied migration {migration.version} ({migration.name})")

        except Exception as e:
            self._rollback_to_savepoint(savepoint_name)
            if isinstance(e, (MigrationError, HookError)):
                raise
            else:
                raise MigrationError(
                    f"Failed to apply migration {migration.version} ({migration.name}): {e}"
                ) from e

    def _apply_non_transactional(
        self,
        migration: Migration,
        already_applied: bool,
        migration_file: Path | None = None,
    ) -> None:
        """Apply migration in autocommit mode (no transaction).

        WARNING: If this fails, manual cleanup may be required.

        Args:
            migration: Migration instance to apply
            already_applied: Whether migration was already applied (force mode)
            migration_file: Path to migration file for checksum computation
        """
        logger.warning(
            f"Running migration {migration.version} in non-transactional mode. "
            "Manual cleanup may be required on failure."
        )

        # Ensure any pending transaction is committed
        self.connection.commit()

        # Set autocommit mode
        original_autocommit = self.connection.autocommit
        self.connection.autocommit = True

        try:
            logger.debug(f"Executing DDL for migration {migration.version} (autocommit)")
            start_time = time.perf_counter()
            migration.up()
            execution_time_ms = int((time.perf_counter() - start_time) * 1000)

            # Record migration (in autocommit, this commits immediately)
            if not already_applied:
                self._record_migration(migration, execution_time_ms, migration_file)

            logger.info(
                f"Successfully applied non-transactional migration "
                f"{migration.version} ({migration.name})"
            )

        except Exception as e:
            logger.error(
                f"Non-transactional migration {migration.version} failed. "
                "Manual cleanup may be required."
            )
            raise MigrationError(
                f"Failed to apply non-transactional migration "
                f"{migration.version} ({migration.name}): {e}. "
                "Manual cleanup may be required."
            ) from e

        finally:
            # Restore original autocommit setting
            self.connection.autocommit = original_autocommit

    def _create_savepoint(self, name: str) -> None:
        """Create a savepoint for transaction rollback."""
        with self.connection.cursor() as cursor:
            cursor.execute(f"SAVEPOINT {name}")

    def _release_savepoint(self, name: str) -> None:
        """Release a savepoint (commit nested transaction)."""
        with self.connection.cursor() as cursor:
            cursor.execute(f"RELEASE SAVEPOINT {name}")

    def _rollback_to_savepoint(self, name: str) -> None:
        """Rollback to a savepoint (undo nested transaction)."""
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(f"ROLLBACK TO SAVEPOINT {name}")
            self.connection.commit()
        except Exception:
            # Savepoint rollback failed, do full rollback
            self.connection.rollback()

    def _record_migration(
        self,
        migration: Migration,
        execution_time_ms: int,
        migration_file: Path | None = None,
    ) -> None:
        """Record migration in tracking table with checksum.

        Args:
            migration: Migration that was applied
            execution_time_ms: Time taken to apply migration
            migration_file: Path to migration file for checksum computation
        """
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = f"{migration.name}_{timestamp}"

        # Compute checksum if file path provided
        checksum = None
        if migration_file is not None and migration_file.exists():
            checksum = compute_checksum(migration_file)
            logger.debug(f"Computed checksum for {migration.version}: {checksum[:16]}...")

        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                INSERT INTO {self.migration_table}
                    (slug, version, name, execution_time_ms, checksum)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (slug, migration.version, migration.name, execution_time_ms, checksum),
            )

    def mark_applied(
        self,
        migration_file: Path,
        reason: str = "baseline",
    ) -> str:
        """Mark a migration as applied without executing it.

        Records the migration in the tracking table without running the up() method.
        Useful for:
        - Establishing a baseline when adopting confiture on an existing database
        - Setting up a new environment from a backup
        - Recovering from a failed migration state

        Args:
            migration_file: Path to migration file (.py or .up.sql)
            reason: Reason for marking as applied (stored in notes)

        Returns:
            Version of the migration that was marked as applied

        Raises:
            MigrationError: If migration is already applied or cannot be loaded

        Example:
            >>> migrator.mark_applied(Path("db/migrations/001_create_users.py"))
            "001"
        """
        from datetime import datetime

        from confiture.core.connection import load_migration_class

        # Load the migration class to get version and name
        migration_class = load_migration_class(migration_file)

        # Create a minimal instance just to read attributes
        # We need to pass a connection but won't use it
        migration = migration_class(connection=self.connection)

        # Check if already applied
        applied_versions = set(self.get_applied_versions())
        if migration.version in applied_versions:
            logger.info(f"Migration {migration.version} already applied, skipping")
            return migration.version

        # Generate slug with reason marker
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = f"{migration.name}_{timestamp}_{reason}"

        # Compute checksum
        checksum = compute_checksum(migration_file)

        # Record in tracking table with execution_time_ms = 0 (not executed)
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                INSERT INTO {self.migration_table}
                    (slug, version, name, execution_time_ms, checksum)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (slug, migration.version, migration.name, 0, checksum),
            )

        self.connection.commit()
        logger.info(
            f"Marked migration {migration.version} ({migration.name}) as applied ({reason})"
        )

        return migration.version

    def _clear_tracking_table(self) -> int:
        """Delete all entries from the tracking table.

        Used internally by reinit() to reset migration state before
        re-baselining. Uses DELETE (not TRUNCATE) for transaction safety.

        Returns:
            Number of rows deleted.
        """
        with self.connection.cursor() as cursor:
            cursor.execute(f"DELETE FROM {self.migration_table}")
            deleted = cursor.rowcount
        return deleted

    def reinit(
        self,
        through: str | None = None,
        dry_run: bool = False,
        migrations_dir: Path | None = None,
    ) -> MigrateReinitResult:
        """Reset tracking table and re-mark migrations as applied.

        Clears all entries from tb_confiture, then re-marks migration files
        on disk as applied. Used after consolidating migration files to
        re-establish a clean tracking state.

        Args:
            through: Mark migrations up to and including this version.
                If None, marks all migration files on disk.
            dry_run: If True, perform the operation inside a transaction
                that is rolled back, returning what would have happened.
            migrations_dir: Directory containing migration files.
                Defaults to the migrator's configured directory.

        Returns:
            MigrateReinitResult with details of the operation.

        Raises:
            MigrationError: If the through version is not found on disk.

        Example:
            >>> migrator.reinit(through="005")
            MigrateReinitResult(success=True, deleted_count=5, ...)

            >>> migrator.reinit()  # marks all files
            MigrateReinitResult(success=True, deleted_count=3, ...)
        """
        from confiture.models.results import MigrateReinitResult, MigrationApplied

        start_time = time.time()

        # Discover migration files
        all_migrations = self.find_migration_files(migrations_dir)

        # Filter to target version if specified
        if through is not None:
            migrations_to_mark: list[Path] = []
            found = False
            for migration_file in all_migrations:
                version = self._version_from_filename(migration_file.name)
                migrations_to_mark.append(migration_file)
                if version == through:
                    found = True
                    break
            if not found:
                raise MigrationError(f"Migration version '{through}' not found on disk")
        else:
            migrations_to_mark = list(all_migrations)

        try:
            # Clear tracking table
            deleted_count = self._clear_tracking_table()

            # Re-mark each migration using direct INSERT (avoid mark_applied's
            # commit which would interfere with dry-run rollback)
            from datetime import datetime

            from confiture.core.checksum import compute_checksum
            from confiture.core.connection import load_migration_class

            marked: list[MigrationApplied] = []
            for migration_file in migrations_to_mark:
                migration_class = load_migration_class(migration_file)
                migration = migration_class(connection=self.connection)

                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                slug = f"{migration.name}_{timestamp}_reinit"
                checksum = compute_checksum(migration_file)

                with self.connection.cursor() as cursor:
                    cursor.execute(
                        f"""
                        INSERT INTO {self.migration_table}
                            (slug, version, name, execution_time_ms, checksum)
                        VALUES (%s, %s, %s, %s, %s)
                        """,
                        (slug, migration.version, migration.name, 0, checksum),
                    )

                name_parts = migration_file.stem.split("_", 1)
                name = name_parts[1] if len(name_parts) > 1 else migration_file.stem
                if name.endswith(".up"):
                    name = name[:-3]
                marked.append(
                    MigrationApplied(
                        version=migration.version,
                        name=name,
                        execution_time_ms=0,
                    )
                )

            if dry_run:
                self.connection.rollback()
            else:
                self.connection.commit()

            elapsed_ms = int((time.time() - start_time) * 1000)

            return MigrateReinitResult(
                success=True,
                deleted_count=deleted_count,
                migrations_marked=marked,
                total_execution_time_ms=elapsed_ms,
                dry_run=dry_run,
            )

        except Exception:
            self.connection.rollback()
            raise

    def rollback(
        self,
        migration: Migration,
        skip_preconditions: bool = False,
    ) -> None:
        """Rollback a migration and remove it from tracking table.

        For transactional migrations (default):
        - Executes within a transaction with automatic rollback on failure
        - Safe and consistent

        For non-transactional migrations (transactional=False):
        - Runs in autocommit mode
        - No automatic rollback on failure
        - Manual cleanup may be required

        Precondition Validation:
        - If migration defines down_preconditions, they are validated first
        - If any precondition fails, the rollback is aborted
        - Use skip_preconditions=True to bypass validation (not recommended)

        Args:
            migration: Migration instance to rollback
            skip_preconditions: If True, skip precondition validation (not recommended)

        Raises:
            MigrationError: If migration fails or was not applied
            PreconditionValidationError: If precondition validation fails
        """
        # Check if applied
        if not self._is_applied(migration.version):
            raise MigrationError(
                f"Migration {migration.version} ({migration.name}) "
                "has not been applied, cannot rollback"
            )

        # Validate preconditions before rolling back
        if not skip_preconditions:
            self._validate_preconditions(
                migration, direction="down", preconditions=migration.down_preconditions
            )

        if migration.transactional:
            self._rollback_transactional(migration)
        else:
            self._rollback_non_transactional(migration)

    def _rollback_transactional(self, migration: Migration) -> None:
        """Rollback a migration within a transaction.

        Args:
            migration: Migration instance to rollback
        """
        try:
            # Execute down() method
            logger.debug(f"Executing rollback (down) for migration {migration.version}")
            migration.down()

            # Remove from tracking table
            self._execute_sql(
                f"""
                DELETE FROM {self.migration_table}
                WHERE version = %s
                """,
                (migration.version,),
            )

            # Commit transaction
            self.connection.commit()
            logger.info(
                f"Successfully rolled back migration {migration.version} ({migration.name})"
            )

        except Exception as e:
            self.connection.rollback()
            raise MigrationError(
                f"Failed to rollback migration {migration.version} ({migration.name}): {e}"
            ) from e

    def _rollback_non_transactional(self, migration: Migration) -> None:
        """Rollback a migration in autocommit mode (no transaction).

        WARNING: If this fails, manual cleanup may be required.

        Args:
            migration: Migration instance to rollback
        """
        logger.warning(
            f"Rolling back migration {migration.version} in non-transactional mode. "
            "Manual cleanup may be required on failure."
        )

        # Ensure any pending transaction is committed
        self.connection.commit()

        # Set autocommit mode
        original_autocommit = self.connection.autocommit
        self.connection.autocommit = True

        try:
            # Execute down() method
            logger.debug(
                f"Executing rollback (down) for migration {migration.version} (autocommit)"
            )
            migration.down()

            # Remove from tracking table
            self._execute_sql(
                f"""
                DELETE FROM {self.migration_table}
                WHERE version = %s
                """,
                (migration.version,),
            )

            logger.info(
                f"Successfully rolled back non-transactional migration "
                f"{migration.version} ({migration.name})"
            )

        except Exception as e:
            logger.error(
                f"Non-transactional rollback of migration {migration.version} failed. "
                "Manual cleanup may be required."
            )
            raise MigrationError(
                f"Failed to rollback non-transactional migration "
                f"{migration.version} ({migration.name}): {e}. "
                "Manual cleanup may be required."
            ) from e

        finally:
            # Restore original autocommit setting
            self.connection.autocommit = original_autocommit

    def _is_applied(self, version: str) -> bool:
        """Check if migration version has been applied.

        Args:
            version: Migration version to check

        Returns:
            True if migration has been applied, False otherwise
        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT COUNT(*)
                FROM {self.migration_table}
                WHERE version = %s
                """,
                (version,),
            )
            result = cursor.fetchone()
            if result is None:
                return False
            count: int = result[0]
            return count > 0

    def get_applied_versions(self) -> list[str]:
        """Get list of all applied migration versions.

        Returns:
            List of migration versions, sorted by applied_at timestamp
        """
        with self.connection.cursor() as cursor:
            cursor.execute(f"""
                SELECT version
                FROM {self.migration_table}
                ORDER BY applied_at ASC
            """)
            return [row[0] for row in cursor.fetchall()]

    def get_applied_migrations_with_timestamps(self) -> list[dict[str, Any]]:
        """Return applied migrations with version, name, and applied_at timestamp.

        Returns:
            List of dicts with 'version', 'name', and 'applied_at' (ISO string or None),
            ordered by applied_at ascending.
        """
        with self.connection.cursor() as cursor:
            cursor.execute(f"""
                SELECT version, name, applied_at
                FROM {self.migration_table}
                ORDER BY applied_at ASC
            """)
            return [
                {
                    "version": row[0],
                    "name": row[1],
                    "applied_at": row[2].isoformat() if row[2] else None,
                }
                for row in cursor.fetchall()
            ]

    def find_migration_files(self, migrations_dir: Path | None = None) -> list[Path]:
        """Find all migration files in the migrations directory.

        Discovers both Python migrations (.py) and SQL file migrations (.up.sql).
        For SQL migrations, returns the .up.sql file path (the .down.sql is
        inferred when loading).

        Args:
            migrations_dir: Optional custom migrations directory.
                           If None, uses db/migrations/ (default)

        Returns:
            List of migration file paths, sorted by version number.
            Includes both .py files and .up.sql files.

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> files = migrator.find_migration_files()
            >>> # [Path("db/migrations/001_create_users.py"),
            >>> #  Path("db/migrations/002_add_posts.up.sql"), ...]
        """
        if migrations_dir is None:
            migrations_dir = Path("db") / "migrations"

        if not migrations_dir.exists():
            return []

        # Find all .py files (excluding __pycache__, __init__.py)
        py_files = [
            f
            for f in migrations_dir.glob("*.py")
            if f.name != "__init__.py" and not f.name.startswith("_")
        ]

        # Find all .up.sql files (SQL migrations)
        sql_files = list(migrations_dir.glob("*.up.sql"))

        # Combine and sort by version
        all_files = py_files + sql_files
        migration_files = sorted(all_files, key=lambda f: self._version_from_filename(f.name))

        return migration_files

    # ------------------------------------------------------------------
    # Rebuild helpers
    # ------------------------------------------------------------------

    _SYSTEM_SCHEMAS = frozenset(
        {
            "pg_catalog",
            "information_schema",
            "pg_toast",
        }
    )

    def _discover_user_schemas(self) -> list[str]:
        """Query all user-created schemas, excluding system schemas.

        Returns:
            List of schema names (e.g. ``["public", "myapp"]``).
        """
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT schema_name FROM information_schema.schemata")
            rows = cursor.fetchall()

        return [
            row[0]
            for row in rows
            if row[0] not in self._SYSTEM_SCHEMAS
            and not row[0].startswith("pg_temp_")
            and not row[0].startswith("pg_toast_temp_")
        ]

    def _drop_user_schemas(self, schemas: list[str]) -> list[str]:
        """Drop user schemas with CASCADE and recreate ``public``.

        Runs in autocommit mode (DDL cannot be rolled back safely).

        Args:
            schemas: Schema names to drop.

        Returns:
            List of schemas that were actually dropped.
        """
        if not schemas:
            return []

        original_autocommit = self.connection.autocommit
        self.connection.autocommit = True
        try:
            with self.connection.cursor() as cursor:
                for schema in schemas:
                    logger.info("Dropping schema %s", schema)
                    cursor.execute(f"DROP SCHEMA {schema} CASCADE")
                # Always recreate public
                cursor.execute("CREATE SCHEMA public")
            return list(schemas)
        finally:
            self.connection.autocommit = original_autocommit

    def _apply_ddl_string(self, ddl: str) -> tuple[int, list[str]]:
        """Execute DDL statements in autocommit mode.

        Strips BEGIN/COMMIT wrappers, splits into statements, and executes
        each one. CREATE EXTENSION failures are captured as warnings rather
        than raised.

        Args:
            ddl: Raw DDL string (may contain multiple statements).

        Returns:
            Tuple of (statements_executed, warnings).
        """
        import sqlparse

        from confiture.core.sql_utils import strip_transaction_wrappers

        cleaned = strip_transaction_wrappers(ddl)
        statements = [s.strip() for s in sqlparse.split(cleaned) if s.strip()]

        if not statements:
            return 0, []

        warnings: list[str] = []
        executed = 0

        original_autocommit = self.connection.autocommit
        self.connection.autocommit = True
        try:
            with self.connection.cursor() as cursor:
                for stmt in statements:
                    if not stmt or stmt == ";":
                        continue
                    try:
                        cursor.execute(stmt)
                        executed += 1
                    except Exception as exc:
                        if "CREATE EXTENSION" in stmt.upper():
                            warnings.append(f"CREATE EXTENSION warning: {exc}")
                        else:
                            raise
        finally:
            self.connection.autocommit = original_autocommit

        return executed, warnings

    def _backup_tracking_table(self) -> list[dict[str, Any]]:
        """Dump current tracking table contents as list of dicts.

        Returns:
            List of row dicts, or empty list if table does not exist.
        """
        if not self.tracking_table_exists():
            return []

        with self.connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM {self.migration_table}")
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row, strict=False)) for row in cursor.fetchall()]

    def rebuild(
        self,
        *,
        drop_schemas: bool = False,
        dry_run: bool = False,
        apply_seeds: bool = False,
        backup_tracking: bool = False,
        schema_dir: Path | None = None,
        migrations_dir: Path | None = None,
        seeds_dir: Path | None = None,
        env_config: Any | None = None,
    ) -> MigrateRebuildResult:
        """Rebuild database from DDL and bootstrap tracking table.

        Orchestrates: (1) optional tracking backup, (2) optional schema
        cleanup, (3) DDL build + apply, (4) tracking table init +
        re-baseline, (5) optional seed application.

        Args:
            drop_schemas: Drop all user schemas before rebuild.
            dry_run: Build DDL and report what would happen without executing.
            apply_seeds: Apply seed files after DDL.
            backup_tracking: Dump tracking table before clearing.
            schema_dir: Path to schema directory (default: db/schema).
            migrations_dir: Path to migrations directory (default: db/migrations).
            seeds_dir: Path to seeds directory (default: db/seeds).
            env_config: Optional Environment config for SchemaBuilder.

        Returns:
            MigrateRebuildResult with operation details.

        Raises:
            RebuildError: If schema build or DDL application fails.
        """
        from confiture.exceptions import RebuildError
        from confiture.models.results import MigrateRebuildResult

        start_time = time.time()
        warnings: list[str] = []
        schemas_dropped: list[str] = []
        ddl_count = 0
        seeds_applied: int | None = None

        if schema_dir is None:
            schema_dir = Path("db") / "schema"
        if migrations_dir is None:
            migrations_dir = Path("db") / "migrations"
        if seeds_dir is None:
            seeds_dir = Path("db") / "seeds"

        # Step 1: Backup tracking table if requested
        if backup_tracking:
            self._backup_tracking_table()  # result used by CLI for JSON dump

        # Step 2: Build DDL via SchemaBuilder
        try:
            from confiture.core.builder import SchemaBuilder

            builder = SchemaBuilder(
                env=env_config.name if env_config and hasattr(env_config, "name") else "rebuild",
                include_dirs=[str(schema_dir)],
            )
            ddl = builder.build(schema_only=True)
        except Exception as exc:
            raise RebuildError(f"Schema build failed: {exc}") from exc

        if dry_run:
            # Count what would be executed
            import sqlparse

            from confiture.core.sql_utils import strip_transaction_wrappers

            cleaned = strip_transaction_wrappers(ddl)
            stmts = [s.strip() for s in sqlparse.split(cleaned) if s.strip()]
            ddl_count = len(stmts)

            # Count migrations that would be marked
            all_migrations = self.find_migration_files(migrations_dir)
            from confiture.models.results import MigrationApplied

            marked = []
            for mf in all_migrations:
                version = self._version_from_filename(mf.name)
                name_parts = mf.stem.split("_", 1)
                name = name_parts[1] if len(name_parts) > 1 else mf.stem
                if name.endswith(".up"):
                    name = name[:-3]
                marked.append(MigrationApplied(version=version, name=name, execution_time_ms=0))

            # Discover schemas that would be dropped
            if drop_schemas:
                schemas_dropped = self._discover_user_schemas()

            elapsed_ms = int((time.time() - start_time) * 1000)
            return MigrateRebuildResult(
                success=True,
                schemas_dropped=schemas_dropped,
                ddl_statements_executed=ddl_count,
                migrations_marked=marked,
                total_execution_time_ms=elapsed_ms,
                dry_run=True,
                warnings=warnings,
            )

        # Step 3: Drop schemas if requested
        if drop_schemas:
            user_schemas = self._discover_user_schemas()
            schemas_dropped = self._drop_user_schemas(user_schemas)

        # Step 4: Apply DDL
        ddl_count, ddl_warnings = self._apply_ddl_string(ddl)
        warnings.extend(ddl_warnings)

        # Step 5: Initialize tracking table + re-baseline
        self.initialize()
        reinit_result = self.reinit(migrations_dir=migrations_dir)
        migrations_marked = reinit_result.migrations_marked

        # Step 6: Optionally apply seeds
        if apply_seeds:
            from confiture.core.seed_applier import SeedApplier

            applier = SeedApplier(
                seeds_dir=seeds_dir,
                connection=self.connection,
            )
            seed_result = applier.apply_sequential()
            seeds_applied = seed_result.total_applied

        elapsed_ms = int((time.time() - start_time) * 1000)

        return MigrateRebuildResult(
            success=True,
            schemas_dropped=schemas_dropped,
            ddl_statements_executed=ddl_count,
            migrations_marked=migrations_marked,
            total_execution_time_ms=elapsed_ms,
            dry_run=False,
            warnings=warnings,
            seeds_applied=seeds_applied,
        )

    def tracking_table_exists(self) -> bool:
        """Return True if the tb_confiture tracking table exists in the database.

        Useful for detecting whether a database has been initialised with
        confiture (e.g. after a staging restore that wiped the tracking table).

        Returns:
            True if ``tb_confiture`` exists, False otherwise.

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> if not migrator.tracking_table_exists():
            ...     migrator.initialize()
        """
        with self.connection.cursor() as cursor:
            if self._table_schema is not None:
                cursor.execute(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_schema = %s AND table_name = %s
                    )
                    """,
                    (self._table_schema, self._table_base),
                )
            else:
                cursor.execute(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_name = %s
                    )
                    """,
                    (self._table_base,),
                )
            result = cursor.fetchone()
            return bool(result[0]) if result else False

    def baseline_through(
        self,
        through: str,
        migrations_dir: Path,
    ) -> list[str]:
        """Mark migrations as applied through a version without clearing the table.

        Unlike :meth:`reinit`, this method does **not** delete existing
        tracking entries.  It only inserts new rows for migrations that are
        not yet recorded.  Intended for use by auto-detect baseline after a
        restore wipes the tracking table.

        Args:
            through: Target version string (e.g. ``"007"``).  All migration
                files from the first through this version are marked applied.
            migrations_dir: Directory containing migration files.

        Returns:
            List of version strings that were newly marked as applied.

        Raises:
            MigrationError: If ``through`` version is not found on disk.

        Example:
            >>> migrator.baseline_through("007", Path("db/migrations"))
            ["001", "002", "003", "004", "005", "006", "007"]
        """
        all_migrations = self.find_migration_files(migrations_dir)

        migrations_to_mark: list[Path] = []
        found = False
        for migration_file in all_migrations:
            version = self._version_from_filename(migration_file.name)
            migrations_to_mark.append(migration_file)
            if version == through:
                found = True
                break

        if not found:
            raise MigrationError(f"Migration version '{through}' not found on disk")

        already_applied = set(self.get_applied_versions())
        newly_marked: list[str] = []
        for migration_file in migrations_to_mark:
            version = self._version_from_filename(migration_file.name)
            if version not in already_applied:
                self.mark_applied(migration_file, reason="auto-baseline")
                newly_marked.append(version)
        return newly_marked

    def find_duplicate_versions(self, migrations_dir: Path | None = None) -> dict[str, list[Path]]:
        """Find migration files that share the same version prefix.

        Groups migration files by version prefix and returns only versions
        with more than one file. This detects conflicts that would cause
        a UNIQUE constraint violation on tb_confiture.version at apply time.

        Args:
            migrations_dir: Optional custom migrations directory.
                           If None, uses db/migrations/ (default)

        Returns:
            Dict mapping version strings to lists of conflicting file paths.
            Empty dict if no duplicates exist.

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> dupes = migrator.find_duplicate_versions()
            >>> # {"001": [Path("001_a.py"), Path("001_b.up.sql")]}
        """
        if migrations_dir is None:
            migrations_dir = Path("db") / "migrations"
        return find_duplicate_migration_versions(migrations_dir)

    def find_orphaned_sql_files(self, migrations_dir: Path | None = None) -> list[Path]:
        """Find .sql files that don't match the expected naming pattern.

        Confiture only recognizes:
        - {NNN}_{name}.up.sql (forward migrations)
        - {NNN}_{name}.down.sql (rollback migrations)

        Files like {NNN}_{name}.sql (without .up/.down) are silently ignored
        by the migration discovery and should be renamed.

        Args:
            migrations_dir: Optional custom migrations directory.
                           If None, uses db/migrations/ (default)

        Returns:
            List of orphaned .sql file paths, sorted by name.

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> orphaned = migrator.find_orphaned_sql_files()
            >>> # [Path("db/migrations/001_create_users.sql"),
            >>> #  Path("db/migrations/002_add_columns.sql")]
        """
        if migrations_dir is None:
            migrations_dir = Path("db") / "migrations"

        if not migrations_dir.exists():
            return []

        # Find all .sql files
        all_sql_files = set(migrations_dir.glob("*.sql"))

        # Find all properly named migration files
        expected_files = set(migrations_dir.glob("*.up.sql")) | set(
            migrations_dir.glob("*.down.sql")
        )

        # Orphaned files are SQL files that don't match the expected pattern
        orphaned = all_sql_files - expected_files
        return sorted(orphaned, key=lambda f: f.name)

    def fix_orphaned_sql_files(
        self, migrations_dir: Path | None = None, dry_run: bool = False
    ) -> dict[str, list[tuple[str, str]]]:
        """Rename orphaned SQL files to match the expected naming pattern.

        For each orphaned file {NNN}_{name}.sql, renames it to {NNN}_{name}.up.sql
        (assuming it's a forward migration).

        Args:
            migrations_dir: Optional custom migrations directory.
                           If None, uses db/migrations/ (default)
            dry_run: If True, return what would be renamed without making changes

        Returns:
            Dictionary with:
            - 'renamed': List of tuples (old_name, new_name) for successfully renamed files
            - 'errors': List of tuples (filename, error_message) for failures

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> result = migrator.fix_orphaned_sql_files(dry_run=False)
            >>> print(f"Renamed: {result['renamed']}")
            Renamed: [('001_create_users.sql', '001_create_users.up.sql')]
        """
        if migrations_dir is None:
            migrations_dir = Path("db") / "migrations"

        if not migrations_dir.exists():
            return {"renamed": [], "errors": []}

        orphaned_files = self.find_orphaned_sql_files(migrations_dir)
        renamed: list[tuple[str, str]] = []
        errors: list[tuple[str, str]] = []

        for orphaned_file in orphaned_files:
            # Suggest renaming by adding .up suffix before .sql
            # Example: 001_create_users.sql -> 001_create_users.up.sql
            old_name = orphaned_file.name
            new_name = f"{orphaned_file.stem}.up.sql"
            new_path = orphaned_file.parent / new_name

            try:
                if not dry_run:
                    # Check if target already exists
                    if new_path.exists():
                        errors.append((old_name, f"Target file already exists: {new_name}"))
                        continue

                    # Rename the file
                    orphaned_file.rename(new_path)
                    logger.info(f"Renamed migration file: {old_name} -> {new_name}")

                renamed.append((old_name, new_name))
            except Exception as e:
                errors.append((old_name, str(e)))
                logger.error(f"Failed to rename {old_name}: {e}")

        return {"renamed": renamed, "errors": errors}

    def find_pending(self, migrations_dir: Path | None = None) -> list[Path]:
        """Find migrations that have not been applied yet.

        Args:
            migrations_dir: Optional custom migrations directory

        Returns:
            List of pending migration file paths

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> pending = migrator.find_pending()
            >>> print(f"Found {len(pending)} pending migrations")
        """
        # Get all migration files
        all_migrations = self.find_migration_files(migrations_dir)

        # Get applied versions
        applied_versions = set(self.get_applied_versions())

        # Filter to pending only
        pending_migrations = [
            migration_file
            for migration_file in all_migrations
            if self._version_from_filename(migration_file.name) not in applied_versions
        ]

        return pending_migrations

    def _version_from_filename(self, filename: str) -> str:
        """Extract version from migration filename.

        Supports both Python and SQL migrations:
        - Python: {version}_{name}.py -> "001_create_users.py" -> "001"
        - SQL: {version}_{name}.up.sql -> "001_create_users.up.sql" -> "001"

        Args:
            filename: Migration filename

        Returns:
            Version string

        Example:
            >>> migrator._version_from_filename("042_add_column.py")
            "042"
            >>> migrator._version_from_filename("042_add_column.up.sql")
            "042"
        """
        # Remove SQL file extensions if present
        if filename.endswith(".up.sql"):
            filename = filename[:-7]  # Remove ".up.sql"
        elif filename.endswith(".down.sql"):
            filename = filename[:-9]  # Remove ".down.sql"

        # Split on first underscore
        version = filename.split("_")[0]
        return version

    def migrate_up(
        self,
        force: bool = False,
        migrations_dir: Path | None = None,
        target: str | None = None,
        lock_config: LockConfig | None = None,
        checksum_config: ChecksumConfig | None = None,
        progress: ProgressManager | None = None,
    ) -> list[str]:
        """Apply pending migrations up to target version.

        Uses distributed locking to ensure only one migration process runs
        at a time. This is critical for multi-pod Kubernetes deployments.

        Optionally verifies checksums before running migrations to detect
        unauthorized modifications to migration files.

        Args:
            force: If True, skip migration state checks and apply all migrations
            migrations_dir: Custom migrations directory (default: db/migrations)
            target: Target migration version (applies all if None)
            lock_config: Locking configuration. If None, uses default (enabled,
                30s timeout, blocking mode). Pass LockConfig(enabled=False)
                to disable locking.
            checksum_config: Checksum verification configuration. If None, uses
                default (enabled, fail on mismatch). Pass
                ChecksumConfig(enabled=False) to disable verification.
            progress: Optional ProgressManager for displaying migration progress

        Returns:
            List of applied migration versions

        Raises:
            MigrationError: If migration application fails
            LockAcquisitionError: If lock cannot be acquired within timeout
            ChecksumVerificationError: If checksum mismatch and behavior is FAIL

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> migrator.initialize()
            >>> # Default: verify checksums, fail on mismatch
            >>> applied = migrator.migrate_up()
            >>>
            >>> # With progress tracking
            >>> with ProgressManager() as pm:
            ...     applied = migrator.migrate_up(progress=pm)
        """
        effective_migrations_dir = migrations_dir or Path("db/migrations")

        # Phase 1: Verification
        verify_task = None
        if progress:
            verify_task = progress.add_task("Verifying checksums...", total=None)

        # Verify checksums before running migrations (unless force mode)
        if checksum_config is None:
            checksum_config = ChecksumConfig()

        if checksum_config.enabled and not force:
            verifier = MigrationChecksumVerifier(self.connection, checksum_config)
            verifier.verify_all(effective_migrations_dir)

        if progress and verify_task is not None:
            progress.finish_task(verify_task)

        # Create lock manager
        lock = MigrationLock(self.connection, lock_config)

        # Acquire lock and run migrations
        with lock.acquire():
            return self._migrate_up_internal(force, migrations_dir, target, progress=progress)

    def _migrate_up_internal(
        self,
        force: bool = False,
        migrations_dir: Path | None = None,
        target: str | None = None,
        progress: ProgressManager | None = None,
    ) -> list[str]:
        """Internal implementation of migrate_up (called within lock).

        Args:
            force: If True, skip migration state checks
            migrations_dir: Custom migrations directory
            target: Target migration version
            progress: Optional ProgressManager for tracking progress

        Returns:
            List of applied migration versions
        """
        # Phase 1: Discovery
        discover_task = None
        if progress:
            discover_task = progress.add_task("Discovering migrations...", total=None)

        # Find migrations to apply
        if force:
            # In force mode, apply all migrations regardless of state
            migrations_to_apply = self.find_migration_files(migrations_dir)
        else:
            # Normal mode: only apply pending migrations
            migrations_to_apply = self.find_pending(migrations_dir)

        if progress and discover_task is not None:
            progress.update(discover_task, len(migrations_to_apply))

        # Check for mixed transactional modes and warn
        self._warn_mixed_transactional_modes(migrations_to_apply)

        # Phase 2: Application
        apply_task = None
        if progress:
            apply_task = progress.add_task("Applying migrations...", total=len(migrations_to_apply))

        applied_versions = []

        for migration_file in migrations_to_apply:
            # Load migration module
            module = load_migration_module(migration_file)
            migration_class = get_migration_class(module)

            # Create migration instance
            migration = migration_class(connection=self.connection)

            # Check target
            if target and migration.version > target:
                break

            # Apply migration with file path for checksum computation
            self.apply(migration, force=force, migration_file=migration_file)
            applied_versions.append(migration.version)

            # Update progress
            if progress and apply_task is not None:
                progress.update(apply_task, advance=1)

        if progress and apply_task is not None:
            progress.finish_task(apply_task)

        return applied_versions

    def _warn_mixed_transactional_modes(self, migration_files: list[Path]) -> None:
        """Warn if batch contains both transactional and non-transactional migrations.

        Mixed batches can be problematic because non-transactional migrations
        cannot be automatically rolled back if a later transactional migration fails.

        Args:
            migration_files: List of migration files to check
        """
        if len(migration_files) <= 1:
            return

        transactional_migrations: list[str] = []
        non_transactional_migrations: list[str] = []

        for migration_file in migration_files:
            module = load_migration_module(migration_file)
            migration_class = get_migration_class(module)

            # Check transactional attribute (default is True)
            is_transactional = getattr(migration_class, "transactional", True)

            if is_transactional:
                transactional_migrations.append(migration_file.name)
            else:
                non_transactional_migrations.append(migration_file.name)

        if transactional_migrations and non_transactional_migrations:
            logger.warning(
                "Batch contains both transactional and non-transactional migrations. "
                "If a transactional migration fails after a non-transactional one succeeds, "
                "manual cleanup of the non-transactional changes may be required.\n"
                f"  Non-transactional: {', '.join(non_transactional_migrations)}\n"
                f"  Transactional: {', '.join(transactional_migrations[:3])}"
                f"{'...' if len(transactional_migrations) > 3 else ''}"
            )

    def dry_run(self, migration: Migration) -> DryRunResult:
        """Test a migration without making permanent changes.

        Executes the migration in dry-run mode using DryRunExecutor,
        which automatically rolls back all changes. Useful for:
        - Verifying migrations work before production deployment
        - Estimating execution time
        - Detecting constraint violations
        - Identifying table locking issues

        Args:
            migration: Migration instance to test

        Returns:
            DryRunResult with execution metrics and estimates

        Raises:
            DryRunError: If migration execution fails during dry-run

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> migration = MyMigration(connection=conn)
            >>> result = migrator.dry_run(migration)
            >>> print(f"Estimated time: {result.estimated_production_time_ms}ms")
            >>> print(f"Confidence: {result.confidence_percent}%")
        """
        executor = DryRunExecutor()
        return executor.run(self.connection, migration)

    def check_preconditions(
        self,
        migration: Migration,
        direction: str = "up",
    ) -> tuple[bool, list[tuple[Any, str]]]:
        """Check migration preconditions without running the migration.

        Useful for:
        - CI/CD pipelines to verify preconditions before deployment
        - Pre-flight validation in production
        - Debugging precondition issues

        Args:
            migration: Migration instance to check
            direction: "up" or "down" to specify which preconditions to check

        Returns:
            Tuple of (all_passed, failures):
                - all_passed: True if all preconditions passed
                - failures: List of (precondition, error_message) for failures

        Example:
            >>> migrator = Migrator(connection=conn)
            >>> migration = MyMigration(connection=conn)
            >>> passed, failures = migrator.check_preconditions(migration)
            >>> if not passed:
            ...     for precondition, error in failures:
            ...         print(f"FAILED: {precondition}: {error}")
        """
        preconditions = (
            migration.up_preconditions if direction == "up" else migration.down_preconditions
        )

        if not preconditions:
            return (True, [])

        validator = PreconditionValidator(self.connection)
        return validator.check(preconditions)

    @classmethod
    def from_config(
        cls,
        config: Environment | Path | str,
        *,
        migrations_dir: Path | str = Path("db/migrations"),
    ) -> MigratorSession:
        """Create a managed MigratorSession from an Environment config.

        Args:
            config: Environment object, or path to a YAML config file.
            migrations_dir: Directory containing migration files.

        Returns:
            MigratorSession context manager. Use as::

                with Migrator.from_config("db/environments/prod.yaml") as m:
                    result = m.status()

        Raises:
            MigrationError: If the config file cannot be found or is invalid.
        """
        from confiture.config.environment import Environment

        if isinstance(config, Environment):
            env = config
        else:
            import yaml

            config_path = Path(config)
            if not config_path.exists():
                from confiture.exceptions import MigrationError

                raise MigrationError(f"Configuration file not found: {config_path}")
            with open(config_path) as f:
                raw: dict[str, Any] = yaml.safe_load(f)
            env = Environment.model_validate(raw)

        return MigratorSession(env, Path(migrations_dir))


class MigratorSession:
    """Context manager that wraps Migrator with connection lifecycle management.

    Created via ``Migrator.from_config()``. Ensures the database connection is
    always closed, even when an exception is raised inside the ``with`` block.

    Example::

        with Migrator.from_config("db/environments/prod.yaml") as m:
            result = m.status()
            if result.has_pending:
                m.up()
    """

    def __init__(self, config: Environment, migrations_dir: Path) -> None:
        self._config = config
        self._migrations_dir = migrations_dir
        self._conn: Any = None
        self._migrator: Migrator | None = None

    def __enter__(self) -> MigratorSession:
        self._conn = create_connection(self._config.database_url)
        self._migrator = Migrator(
            connection=self._conn,
            migration_table=self._config.migration.tracking_table,
        )
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------ #
    # High-level library methods (implemented in B.3–B.6)                 #
    # ------------------------------------------------------------------ #

    def status(self) -> StatusResult:
        """Return migration status without any output.

        Returns:
            StatusResult with full migration list and summary.

        Raises:
            MigrationError: On database connection failure.
        """
        from datetime import datetime

        from confiture.models.results import MigrationInfo, StatusResult

        assert self._migrator is not None, "Call status() inside a 'with' block"

        tracking_table = self._config.migration.tracking_table

        # Discover migration files (Python and SQL)
        if not self._migrations_dir.exists():
            return StatusResult(
                migrations=[],
                tracking_table_exists=False,
                tracking_table=tracking_table,
                summary={"applied": 0, "pending": 0, "total": 0},
            )

        py_files = list(self._migrations_dir.glob("*.py"))
        sql_files = list(self._migrations_dir.glob("*.up.sql"))
        migration_files = sorted(py_files + sql_files, key=lambda f: f.name.split("_")[0])

        if not migration_files:
            table_exists = self._migrator.tracking_table_exists()
            return StatusResult(
                migrations=[],
                tracking_table_exists=table_exists,
                tracking_table=tracking_table,
                summary={"applied": 0, "pending": 0, "total": 0},
            )

        # Query tracking table
        table_exists = self._migrator.tracking_table_exists()
        applied_versions: set[str] = set()
        applied_at_by_version: dict[str, datetime | None] = {}

        if table_exists:
            applied_versions = set(self._migrator.get_applied_versions())
            for row in self._migrator.get_applied_migrations_with_timestamps():
                raw_ts = row.get("applied_at")
                if raw_ts is not None and isinstance(raw_ts, str):
                    try:
                        applied_at_by_version[row["version"]] = datetime.fromisoformat(raw_ts)
                    except ValueError:
                        applied_at_by_version[row["version"]] = None
                elif isinstance(raw_ts, datetime):
                    applied_at_by_version[row["version"]] = raw_ts
                else:
                    applied_at_by_version[row["version"]] = None

        # Build MigrationInfo list
        infos: list[MigrationInfo] = []
        for mf in migration_files:
            base_name = mf.stem
            if base_name.endswith(".up"):
                base_name = base_name[:-3]
            parts = base_name.split("_", 1)
            version = parts[0] if parts else "???"
            name = parts[1] if len(parts) > 1 else base_name

            migration_status = (
                "applied" if (table_exists and version in applied_versions) else "pending"
            )

            at = applied_at_by_version.get(version) if migration_status == "applied" else None
            infos.append(
                MigrationInfo(version=version, name=name, status=migration_status, applied_at=at)
            )

        applied_count = sum(1 for m in infos if m.status == "applied")
        pending_count = sum(1 for m in infos if m.status == "pending")

        return StatusResult(
            migrations=infos,
            tracking_table_exists=table_exists,
            tracking_table=tracking_table,
            summary={"applied": applied_count, "pending": pending_count, "total": len(infos)},
        )

    def up(
        self,
        *,
        target: str | None = None,
        dry_run: bool = False,
        dry_run_execute: bool = False,  # noqa: ARG002
        auto_detect_baseline: bool = False,  # noqa: ARG002
        snapshots_dir: Path | None = None,  # noqa: ARG002
        verify_checksums: bool = True,
        on_checksum_mismatch: str = "fail",  # noqa: ARG002
        strict: bool = False,  # noqa: ARG002
        force: bool = False,
        lock_timeout: int = 30000,
        no_lock: bool = False,
    ) -> MigrateUpResult:
        """Apply pending migrations.

        Returns:
            MigrateUpResult with applied migrations and timing.

        Raises:
            MigrationError: If a migration fails.
            MigrationError: If the migrations directory does not exist.
        """
        import time as _time

        from confiture.models.results import MigrateUpResult, MigrationApplied

        assert self._migrator is not None, "Call up() inside a 'with' block"

        if not self._migrations_dir.exists():
            raise MigrationError(
                f"Migrations directory not found: {self._migrations_dir.absolute()}"
            )

        self._migrator.initialize()

        # Resolve migrations to apply
        all_files = self._migrator.find_migration_files(migrations_dir=self._migrations_dir)
        if force:
            pending_files = all_files
        else:
            pending_files = self._migrator.find_pending(migrations_dir=self._migrations_dir)

        apply_versions = {self._migrator._version_from_filename(f.name) for f in pending_files}
        skipped_versions = [
            self._migrator._version_from_filename(f.name)
            for f in all_files
            if self._migrator._version_from_filename(f.name) not in apply_versions
        ]

        # Dry-run: return without applying
        if dry_run:
            return MigrateUpResult(
                success=True,
                migrations_applied=[],
                total_execution_time_ms=0,
                checksums_verified=verify_checksums,
                dry_run=True,
                skipped=skipped_versions,
            )

        if not pending_files:
            return MigrateUpResult(
                success=True,
                migrations_applied=[],
                total_execution_time_ms=0,
                checksums_verified=verify_checksums,
                dry_run=False,
                skipped=skipped_versions,
            )

        # Apply with distributed lock
        lock_config = LockConfig(enabled=not no_lock, timeout_ms=lock_timeout)
        lock = MigrationLock(self._conn, lock_config)

        migrations_applied: list[MigrationApplied] = []
        total_execution_time_ms = 0
        failed_exception: Exception | None = None

        try:
            with lock.acquire():
                for migration_file in pending_files:
                    migration_class = load_migration_class(migration_file)
                    migration = migration_class(connection=self._conn)

                    # Stop at target version
                    if target and migration.version > target:
                        break

                    try:
                        start = _time.time()
                        self._migrator.apply(migration, force=force, migration_file=migration_file)
                        elapsed = int((_time.time() - start) * 1000)
                        total_execution_time_ms += elapsed
                        migrations_applied.append(
                            MigrationApplied(
                                version=migration.version,
                                name=migration.name,
                                execution_time_ms=elapsed,
                            )
                        )
                    except Exception as exc:
                        failed_exception = exc
                        break
        except Exception as exc:
            if failed_exception is None:
                failed_exception = exc

        if failed_exception is not None:
            return MigrateUpResult(
                success=False,
                migrations_applied=migrations_applied,
                total_execution_time_ms=total_execution_time_ms,
                checksums_verified=verify_checksums,
                dry_run=False,
                errors=[str(failed_exception)],
                skipped=skipped_versions,
            )

        return MigrateUpResult(
            success=True,
            migrations_applied=migrations_applied,
            total_execution_time_ms=total_execution_time_ms,
            checksums_verified=verify_checksums,
            dry_run=False,
            warnings=["Force mode enabled"] if force else [],
            skipped=skipped_versions,
        )

    def down(
        self,
        *,
        steps: int = 1,
        dry_run: bool = False,
    ) -> MigrateDownResult:
        """Roll back applied migrations.

        Args:
            steps: Number of migrations to roll back (default: 1).
            dry_run: If True, analyze without executing.

        Returns:
            MigrateDownResult with rolled-back migrations and timing.
        """
        import time as _time

        from confiture.models.results import MigrateDownResult, MigrationApplied

        assert self._migrator is not None, "Call down() inside a 'with' block"

        self._migrator.initialize()
        applied_versions = self._migrator.get_applied_versions()

        if not applied_versions:
            return MigrateDownResult(
                success=True,
                migrations_rolled_back=[],
                total_execution_time_ms=0,
            )

        versions_to_rollback = applied_versions[-steps:]
        migration_files = self._migrator.find_migration_files(migrations_dir=self._migrations_dir)

        rolled_back: list[MigrationApplied] = []
        total_execution_time_ms = 0

        for version in reversed(versions_to_rollback):
            migration_file = next(
                (
                    f
                    for f in migration_files
                    if self._migrator._version_from_filename(f.name) == version
                ),
                None,
            )
            if migration_file is None:
                continue

            migration_class = load_migration_class(migration_file)
            migration = migration_class(connection=self._conn)

            if not dry_run:
                start = _time.time()
                self._migrator.rollback(migration)
                elapsed = int((_time.time() - start) * 1000)
                total_execution_time_ms += elapsed
            else:
                elapsed = 0

            rolled_back.append(
                MigrationApplied(
                    version=migration.version,
                    name=migration.name,
                    execution_time_ms=elapsed,
                )
            )

        return MigrateDownResult(
            success=True,
            migrations_rolled_back=rolled_back,
            total_execution_time_ms=total_execution_time_ms,
        )

    def reinit(
        self,
        *,
        through: str | None = None,
        dry_run: bool = False,
    ) -> MigrateReinitResult:
        """Reset tracking table and re-baseline from migration files on disk.

        Args:
            through: Mark migrations as applied through this version.
                If None, marks all migration files on disk as applied.
            dry_run: If True, show what would happen without making changes.

        Returns:
            MigrateReinitResult with deleted count and re-marked migrations.
        """
        assert self._migrator is not None, "Call reinit() inside a 'with' block"
        self._migrator.initialize()
        return self._migrator.reinit(
            through=through, dry_run=dry_run, migrations_dir=self._migrations_dir
        )

    def rebuild(
        self,
        *,
        drop_schemas: bool = False,
        dry_run: bool = False,
        apply_seeds: bool = False,
        backup_tracking: bool = False,
    ) -> MigrateRebuildResult:
        """Rebuild database from DDL and bootstrap tracking table.

        Args:
            drop_schemas: Drop all user schemas before rebuild.
            dry_run: Report what would happen without executing.
            apply_seeds: Apply seed files after DDL.
            backup_tracking: Dump tracking table before clearing.

        Returns:
            MigrateRebuildResult with operation details.
        """
        assert self._migrator is not None, "Call rebuild() inside a 'with' block"
        return self._migrator.rebuild(
            drop_schemas=drop_schemas,
            dry_run=dry_run,
            apply_seeds=apply_seeds,
            backup_tracking=backup_tracking,
            migrations_dir=self._migrations_dir,
        )
