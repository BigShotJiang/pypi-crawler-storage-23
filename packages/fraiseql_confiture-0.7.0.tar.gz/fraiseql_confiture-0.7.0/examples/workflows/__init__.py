"""Example workflow implementations for agent-driven operations."""
