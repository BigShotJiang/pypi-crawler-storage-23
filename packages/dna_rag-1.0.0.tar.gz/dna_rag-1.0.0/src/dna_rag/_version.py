"""Single-source version for dna-rag."""

__version__ = "1.0.0"
