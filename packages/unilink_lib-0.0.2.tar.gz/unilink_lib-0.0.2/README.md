# Unilink Python Client

## Overview

This document provides instructions for the Python client used to connect to the Unilink web service. The Unilink service receives text requests, processes them through artificial intelligence programs, and returns text responses.

## Connection and Setup

To use the client, you must provide an access token and the base web address. Every request requires this access token, which is placed in the request headers automatically by the client.

The client verifies the connection upon creation. It returns a 403 error if the token is incorrect. It returns a connection error if the web address is incorrect.

## Client Functions

The client provides the following functions to interact with the service:

* `send_message(user_id, message)`: Sends a user text request to the service and returns a generated answer. This function has a 120-second timeout.
* `get_history(user_id)`: Returns a list of saved text records for a specific user.
* `clear_history(user_id)`: Deletes all saved text records for a specific user.
* `get_user(user_id)`: Retrieves stored information for a specific user. It returns nothing if the user is not found.
* `create_user(user_id)`: Adds a new user to the database.
* `update_user(user_id, new_user_id, content)`: Modifies existing information for a user. This includes changing their identification number or updating their data content.
* `delete_user(user_id)`: Removes a user from the database.

## Data Structures

The client receives data organized into the following structures:

* **UserData**: Contains the user details, including name, phone, email, address, city, problem_summary, and preferences.
* **User**: Contains the system identification number, unit identification number, external identification string, the user data content, and a timestamp.
* **MessageResponse**: Contains the text response from the artificial intelligence and the user information.
* **Message**: Contains the message identification number, user identification number, the text content, and a timestamp. The content is automatically converted from text format into a dictionary.

---

I can generate executable code examples demonstrating how to initialize the client and call these specific functions.