from datetime import datetime
from typing import List, Literal, Optional, TypeAlias, Union
from dataclasses import dataclass, field
import re
from typing import NotRequired, TypedDict

from chainsaws.aws.lambda_client import LambdaAPIConfig
from chainsaws.aws.shared.session import AWSCredentials


ScheduleState: TypeAlias = Literal["ENABLED", "DISABLED"]
TimeUnit: TypeAlias = Literal["minute", "minutes", "hour", "hours", "day", "days"]
FlexibleTimeWindowMode: TypeAlias = Literal["OFF", "FLEXIBLE"]
_TIME_UNITS = ("minute", "minutes", "hour", "hours", "day", "days")
_AWS_CRON_FIELD_PATTERN = re.compile(r"^[A-Za-z0-9*/?,\-LW#]+$")


class ScheduleRetryPolicyDict(TypedDict):
    """Target retry policy for EventBridge Scheduler."""

    maximum_event_age_in_seconds: NotRequired[int]
    maximum_retry_attempts: NotRequired[int]


class ScheduleResponseDict(TypedDict):
    """Typed dictionary for schedule payloads returned by SchedulerAPI."""

    name: str
    arn: str
    state: ScheduleState
    group_name: str
    schedule_expression: str
    target_arn: str
    description: str | None
    next_invocation: datetime | str | None
    last_invocation: datetime | str | None


class ScheduleListResponseDict(TypedDict):
    """Typed dictionary for list_schedules payload."""

    schedules: list[ScheduleResponseDict]
    next_token: str | None


class ScheduleExpression(str):
    """Custom type for schedule expressions with validation."""

    @classmethod
    def validate(cls, value: object) -> "ScheduleExpression":
        """Validate schedule expression."""
        if not isinstance(value, str):
            raise ValueError("Schedule expression must be a string")

        # at 표현식 검증 (at(yyyy-mm-ddThh:mm:ss))
        at_pattern = r"^at\(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\)$"
        if re.match(at_pattern, value):
            try:
                time_str = value[3:-1]  # 'at(' 와 ')' 제거
                datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S")
                return cls(value)
            except ValueError as e:
                raise ValueError(f"Invalid at expression format: {e}") from e

        # rate 표현식 검증 (rate(value unit))
        rate_match = re.match(
            r"^rate\((\d+) (minute|minutes|hour|hours|day|days)\)$",
            value,
        )
        if rate_match:
            amount = int(rate_match.group(1))
            unit = rate_match.group(2)
            if amount < 1:
                raise ValueError("Invalid rate expression: value must be >= 1")
            if amount == 1 and unit.endswith("s"):
                raise ValueError("Invalid rate expression: use singular unit for value 1")
            if amount != 1 and not unit.endswith("s"):
                raise ValueError("Invalid rate expression: use plural unit for value > 1")
            return cls(value)

        # cron 표현식 검증 (cron(* * * * * *))
        if value.startswith("cron(") and value.endswith(")"):
            cron_expr = value[5:-1].strip()  # 'cron(' 와 ')' 제거
            fields = cron_expr.split()
            if len(fields) != 6:
                raise ValueError("Invalid cron expression: expected exactly 6 fields")
            if fields[2] != "?" and fields[4] != "?":
                raise ValueError(
                    "Invalid cron expression: either day-of-month or day-of-week must be '?'",
                )
            if not all(_AWS_CRON_FIELD_PATTERN.match(field) for field in fields):
                raise ValueError("Invalid cron expression: contains unsupported characters")
            return cls(value)

        raise ValueError(
            "Invalid schedule expression. Must be one of:\n"
            "- at(yyyy-mm-ddThh:mm:ss)\n"
            "- rate(value unit)\n"
            "- cron(* * * * * *)"
        )


class ScheduleExpressionBuilder:
    """Builder for creating valid schedule expressions."""

    @staticmethod
    def at(time: Union[str, datetime]) -> ScheduleExpression:
        """Create an at expression.

        Args:
            time: Time to schedule at. Can be a datetime object or ISO format string.

        Returns:
            ScheduleExpression: Valid at expression

        Example:
            ```python
            # Using datetime
            expr1 = ScheduleExpressionBuilder.at(datetime(2024, 3, 15, 14, 30))
            # Using string
            expr2 = ScheduleExpressionBuilder.at("2024-03-15T14:30:00")
            ```
        """
        if isinstance(time, datetime):
            time_str = time.strftime("%Y-%m-%dT%H:%M:%S")
        else:
            time_str = time
        return ScheduleExpression(f"at({time_str})")

    @staticmethod
    def rate(value: int, unit: TimeUnit | str) -> ScheduleExpression:
        """Create a rate expression.

        Args:
            value: Number of time units
            unit: Time unit (minute/minutes/hour/hours/day/days)

        Returns:
            ScheduleExpression: Valid rate expression

        Example:
            ```python
            expr1 = ScheduleExpressionBuilder.rate(5, "minutes")
            expr2 = ScheduleExpressionBuilder.rate(1, "day")
            ```
        """
        if unit not in _TIME_UNITS:
            raise ValueError(f"Invalid rate unit: {unit}")
        return ScheduleExpression(f"rate({value} {unit})")

    @staticmethod
    def cron(
        minute: str = "*",
        hour: str = "*",
        day_of_month: str = "*",
        month: str = "*",
        day_of_week: str = "*",
        year: str = "*",
    ) -> ScheduleExpression:
        """Create a cron expression.

        Args:
            minute: Minute field (0-59)
            hour: Hour field (0-23)
            day_of_month: Day of month field (1-31)
            month: Month field (1-12 or JAN-DEC)
            day_of_week: Day of week field (0-6 or SUN-SAT)
            year: Year field

        Returns:
            ScheduleExpression: Valid cron expression

        Example:
            ```python
            # Every day at 8:00 AM UTC
            expr1 = ScheduleExpressionBuilder.cron(minute="0", hour="8")

            # Every Monday at 9:15 AM UTC
            expr2 = ScheduleExpressionBuilder.cron(
                minute="15",
                hour="9",
                day_of_week="MON"
            )
            ```
        """
        cron_expr = f"{minute} {hour} {day_of_month} {month} {day_of_week} {year}"
        return ScheduleExpression(f"cron({cron_expr})")

    @staticmethod
    def every_n_minutes(n: int) -> ScheduleExpression:
        """Create a rate expression for every n minutes."""
        unit: TimeUnit = "minute" if n == 1 else "minutes"
        return ScheduleExpressionBuilder.rate(n, unit)

    @staticmethod
    def every_n_hours(n: int) -> ScheduleExpression:
        """Create a rate expression for every n hours."""
        unit: TimeUnit = "hour" if n == 1 else "hours"
        return ScheduleExpressionBuilder.rate(n, unit)

    @staticmethod
    def every_n_days(n: int) -> ScheduleExpression:
        """Create a rate expression for every n days."""
        unit: TimeUnit = "day" if n == 1 else "days"
        return ScheduleExpressionBuilder.rate(n, unit)

    @staticmethod
    def daily_at(hour: int, minute: int = 0) -> ScheduleExpression:
        """Create a cron expression for daily schedule at specific time."""
        return ScheduleExpressionBuilder.cron(minute=str(minute), hour=str(hour))

    @staticmethod
    def weekly_on(
        day: Union[str, int],
        hour: int = 0,
        minute: int = 0
    ) -> ScheduleExpression:
        """Create a cron expression for weekly schedule."""
        return ScheduleExpressionBuilder.cron(
            minute=str(minute),
            hour=str(hour),
            day_of_week=str(day)
        )

    @staticmethod
    def monthly_on(
        day: int,
        hour: int = 0,
        minute: int = 0
    ) -> ScheduleExpression:
        """Create a cron expression for monthly schedule."""
        return ScheduleExpressionBuilder.cron(
            minute=str(minute),
            hour=str(hour),
            day_of_month=str(day)
        )


@dataclass
class SchedulerAPIConfig:
    """Configuration for Scheduler API."""

    region: Optional[str] = None
    credentials: Optional[AWSCredentials] = None
    max_retries: int = 3  # Maximum number of API call retries
    timeout: int = 10  # API call timeout in seconds

    def to_lambda_config(self) -> LambdaAPIConfig:
        """Convert to Lambda API config."""
        return LambdaAPIConfig(
            region=self.region,
            credentials=self.credentials,
        )


@dataclass
class ScheduleRequest:
    """Schedule creation request."""

    name: str
    group_name: str
    schedule_expression: ScheduleExpression
    lambda_function_arn: str
    description: Optional[str] = None
    input_data: Optional[dict[str, object]] = None
    state: ScheduleState = "ENABLED"
    flexible_time_window_mode: FlexibleTimeWindowMode = "OFF"
    flexible_time_window_minutes: Optional[int] = None
    schedule_expression_timezone: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    client_token: Optional[str] = None
    role_arn: Optional[str] = None
    dead_letter_arn: Optional[str] = None
    retry_policy: Optional[ScheduleRetryPolicyDict] = None


@dataclass
class ScheduleResponse:
    """Schedule response."""

    name: str
    arn: str
    state: ScheduleState
    group_name: str
    schedule_expression: str
    target_arn: str
    description: Optional[str] = None
    next_invocation: Optional[datetime] = None
    last_invocation: Optional[datetime] = None


@dataclass
class ScheduleListResponse:
    """Schedule list response."""

    schedules: List[ScheduleResponseDict] = field(default_factory=list)
    next_token: Optional[str] = None
