import json
import logging
from datetime import datetime
from typing import Optional

from boto3.session import Session
from botocore.config import Config

from chainsaws.aws.iam import IAMAPI
from chainsaws.aws.scheduler.scheduler_models import (
    FlexibleTimeWindowMode,
    ScheduleRequest,
    ScheduleRetryPolicyDict,
    SchedulerAPIConfig,
)
from chainsaws.aws.scheduler.scheduler_exception import (
    ScheduleConflictError,
    ScheduleGroupNotFoundException,
    ScheduleNotFoundException,
    ScheduleValidationError,
    SchedulerException,
)
from chainsaws.aws.sts import STSAPI

logger = logging.getLogger(__name__)


def _build_retry_policy_payload(policy: ScheduleRetryPolicyDict) -> dict[str, int]:
    payload: dict[str, int] = {}
    if "maximum_event_age_in_seconds" in policy:
        payload["MaximumEventAgeInSeconds"] = policy["maximum_event_age_in_seconds"]
    if "maximum_retry_attempts" in policy:
        payload["MaximumRetryAttempts"] = policy["maximum_retry_attempts"]
    return payload


def _build_flexible_time_window(
    mode: FlexibleTimeWindowMode,
    minutes: Optional[int],
) -> dict[str, object]:
    if mode == "FLEXIBLE":
        if minutes is None:
            raise ScheduleValidationError(
                "flexible_time_window_minutes is required when mode is FLEXIBLE",
            )
        return {
            "Mode": "FLEXIBLE",
            "MaximumWindowInMinutes": minutes,
        }
    return {
        "Mode": "OFF",
    }


class Scheduler:
    """Low-level EventBridge Scheduler client wrapper."""

    def __init__(
        self,
        boto3_session: Session,
        config: SchedulerAPIConfig | None = None,
    ) -> None:
        self.config = config or SchedulerAPIConfig()

        client_config = Config(
            region_name=self.config.region,
            retries={"max_attempts": self.config.max_retries},
            connect_timeout=self.config.timeout,
            read_timeout=self.config.timeout,
        )

        self.client = boto3_session.client(
            "scheduler",
            config=client_config,
            region_name=self.config.region,
        )
        self._role_arn_cache: str | None = None

    def create_schedule_group(self, group_name: str) -> None:
        """Create schedule group."""
        try:
            self.client.create_schedule_group(Name=group_name)
        except self.client.exceptions.ConflictException:
            # If exist, pass generating schedule_group
            pass
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid schedule group create request '{group_name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to create schedule group '{group_name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def create_schedule(self, request: ScheduleRequest) -> dict[str, object]:
        """Create schedule."""
        target: dict[str, object] = {
            "Arn": request.lambda_function_arn,
            "RoleArn": request.role_arn if request.role_arn else self._get_role_arn(),
        }
        if request.input_data is not None:
            target["Input"] = json.dumps(request.input_data)
        if request.dead_letter_arn is not None:
            target["DeadLetterConfig"] = {"Arn": request.dead_letter_arn}
        if request.retry_policy is not None:
            target["RetryPolicy"] = _build_retry_policy_payload(request.retry_policy)

        schedule_args = {
            "Name": request.name,
            "GroupName": request.group_name,
            "ScheduleExpression": request.schedule_expression,
            "State": request.state,
            "Target": target,
            "FlexibleTimeWindow": _build_flexible_time_window(
                request.flexible_time_window_mode,
                request.flexible_time_window_minutes,
            ),
        }

        if request.description:
            schedule_args["Description"] = request.description
        if request.schedule_expression_timezone is not None:
            schedule_args["ScheduleExpressionTimezone"] = request.schedule_expression_timezone
        if request.start_date is not None:
            schedule_args["StartDate"] = request.start_date
        if request.end_date is not None:
            schedule_args["EndDate"] = request.end_date
        if request.client_token is not None:
            schedule_args["ClientToken"] = request.client_token

        try:
            return self.client.create_schedule(**schedule_args)
        except self.client.exceptions.ConflictException as e:
            logger.error(f"Schedule '{request.name}' already exists in group '{request.group_name}': {e!s}")
            raise ScheduleConflictError(
                f"Schedule '{request.name}' already exists in group '{request.group_name}'",
            ) from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid schedule create request for '{request.name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.exception(f"Failed to create schedule '{request.name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def _get_role_arn(self) -> str:
        """Get or create IAM role ARN for scheduler."""
        if self._role_arn_cache is not None:
            return self._role_arn_cache

        try:
            sts = STSAPI(config=self.config)
            identity = sts.get_caller_identity()
            role_name = "EventBridgeSchedulerRole"
            role_arn = f"arn:aws:iam::{identity.account}:role/{role_name}"

            iam = IAMAPI(config=self.config)
            try:
                iam.get_role(role_name)
            except Exception as ex:
                if self._is_missing_role_error(iam, ex):
                    self._create_scheduler_role(iam, role_name)
                    logger.info(f"Created IAM role: {role_name}")
                else:
                    raise

            self._role_arn_cache = role_arn
            return role_arn
        except Exception as e:
            logger.exception(f"Failed to get/create scheduler role: {e!s}")
            raise

    @staticmethod
    def _is_missing_role_error(iam: IAMAPI, error: Exception) -> bool:
        no_such_entity_exception = getattr(
            iam.iam.client.exceptions,
            "NoSuchEntityException",
            None,
        )
        if no_such_entity_exception is None:
            return False
        return isinstance(error, no_such_entity_exception)

    def _create_scheduler_role(self, iam: IAMAPI, role_name: str) -> None:
        """Create IAM role for EventBridge Scheduler."""
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {
                    "Service": "scheduler.amazonaws.com",
                },
                "Action": "sts:AssumeRole",
            }],
        }

        permission_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": [
                    "lambda:InvokeFunction",
                ],
                "Resource": ["arn:aws:lambda:*:*:function:*"],
            }],
        }

        iam.create_role(
            role_name=role_name,
            trust_policy=trust_policy,
            description="Role for EventBridge Scheduler to invoke Lambda functions (Generated By Chainsaws",
        )

        iam.put_role_policy(
            role_name=role_name,
            policy_name=f"{role_name}Policy",
            policy_document=permission_policy,
        )

    def delete_schedule(self, name: str, group_name: str) -> None:
        """Delete schedule."""
        try:
            self.client.delete_schedule(
                Name=name,
                GroupName=group_name,
            )
        except self.client.exceptions.ResourceNotFoundException as e:
            logger.error(f"Schedule '{name}' not found in group '{group_name}': {e!s}")
            raise ScheduleNotFoundException(
                f"Schedule '{name}' not found") from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid schedule delete request for '{name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to delete schedule '{name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def update_schedule_state(self, name: str, group_name: str, state: str) -> None:
        """Update schedule state."""
        try:
            current = self.get_schedule(name, group_name)
            params = {
                "Name": name,
                "GroupName": group_name,
                "State": state,
                "ScheduleExpression": current["ScheduleExpression"],
                "Target": current["Target"],
                "FlexibleTimeWindow": current["FlexibleTimeWindow"],
            }
            if "Description" in current:
                params["Description"] = current["Description"]
            self.client.update_schedule(**params)
        except self.client.exceptions.ResourceNotFoundException as e:
            logger.error(f"Schedule '{name}' not found in group '{group_name}': {e!s}")
            raise ScheduleNotFoundException(
                f"Schedule '{name}' not found") from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid schedule state update for '{name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to update schedule state '{name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def list_schedules(
        self,
        group_name: str,
        next_token: Optional[str] = None,
        max_results: int = 100,
    ) -> dict[str, object]:
        """List schedules in group."""
        try:
            params = {
                "GroupName": group_name,
                "MaxResults": max_results,
            }
            if next_token:
                params["NextToken"] = next_token

            return self.client.list_schedules(**params)
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid list schedules request for group '{group_name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to list schedules in group '{group_name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def get_schedule(self, name: str, group_name: str) -> dict[str, object]:
        """Get schedule details."""
        try:
            return self.client.get_schedule(
                Name=name,
                GroupName=group_name,
            )
        except self.client.exceptions.ResourceNotFoundException as e:
            logger.error(f"Schedule '{name}' not found in group '{group_name}': {e!s}")
            raise ScheduleNotFoundException(
                f"Schedule '{name}' not found") from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid get schedule request for '{name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to get schedule '{name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def update_schedule(
        self,
        name: str,
        group_name: str,
        schedule_expression: Optional[str] = None,
        description: Optional[str] = None,
        input_data: Optional[dict[str, object]] = None,
        state: Optional[str] = None,
        schedule_expression_timezone: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        clear_description: bool = False,
        clear_input_data: bool = False,
        role_arn: Optional[str] = None,
        dead_letter_arn: Optional[str] = None,
        retry_policy: Optional[ScheduleRetryPolicyDict] = None,
        remove_target_dead_letter: bool = False,
        remove_target_retry_policy: bool = False,
    ) -> dict[str, object]:
        """Update schedule."""
        try:
            # Get current schedule
            current = self.get_schedule(name, group_name)

            # Prepare update params
            params = {
                "Name": name,
                "GroupName": group_name,
                "ScheduleExpression": schedule_expression or current["ScheduleExpression"],
                "Target": current["Target"],
                "FlexibleTimeWindow": current["FlexibleTimeWindow"],
            }

            if description is not None:
                params["Description"] = description
            elif clear_description:
                pass
            elif "Description" in current:
                params["Description"] = current["Description"]

            target = dict(current["Target"])
            if role_arn is not None:
                target["RoleArn"] = role_arn
            if input_data is not None:
                target["Input"] = json.dumps(input_data)
            elif clear_input_data:
                target.pop("Input", None)
            if dead_letter_arn is not None:
                target["DeadLetterConfig"] = {"Arn": dead_letter_arn}
            elif remove_target_dead_letter:
                target.pop("DeadLetterConfig", None)
            if retry_policy is not None:
                target["RetryPolicy"] = _build_retry_policy_payload(retry_policy)
            elif remove_target_retry_policy:
                target.pop("RetryPolicy", None)
            params["Target"] = target

            if schedule_expression_timezone is not None:
                params["ScheduleExpressionTimezone"] = schedule_expression_timezone
            elif "ScheduleExpressionTimezone" in current:
                params["ScheduleExpressionTimezone"] = current["ScheduleExpressionTimezone"]

            if start_date is not None:
                params["StartDate"] = start_date
            elif "StartDate" in current:
                params["StartDate"] = current["StartDate"]

            if end_date is not None:
                params["EndDate"] = end_date
            elif "EndDate" in current:
                params["EndDate"] = current["EndDate"]

            if state is not None:
                params["State"] = state
            else:
                params["State"] = current["State"]

            self.client.update_schedule(**params)
            return self.get_schedule(name, group_name)
        except ScheduleNotFoundException:
            raise
        except self.client.exceptions.ConflictException as e:
            logger.error(f"Schedule '{name}' update conflict: {e!s}")
            raise ScheduleConflictError(f"Schedule '{name}' update conflict") from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid schedule update request for '{name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to update schedule '{name}': {e!s}")
            raise SchedulerException(str(e)) from e

    def get_schedule_group(self, group_name: str) -> dict[str, object]:
        """Get schedule group."""
        try:
            return self.client.get_schedule_group(Name=group_name)
        except self.client.exceptions.ResourceNotFoundException as e:
            logger.error(f"Schedule group '{group_name}' not found: {e!s}")
            raise ScheduleGroupNotFoundException(
                f"Schedule group '{group_name}' not found") from e
        except self.client.exceptions.ValidationException as e:
            logger.error(f"Invalid get schedule group request for '{group_name}': {e!s}")
            raise ScheduleValidationError(str(e)) from e
        except Exception as e:
            logger.error(f"Failed to get schedule group '{group_name}': {e!s}")
            raise SchedulerException(str(e)) from e
