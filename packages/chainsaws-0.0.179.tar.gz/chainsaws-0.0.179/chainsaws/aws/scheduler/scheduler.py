import logging
from datetime import datetime
from typing import Optional

from chainsaws.aws.lambda_client import LambdaAPI
from chainsaws.aws.scheduler._scheduler_internal import Scheduler
from chainsaws.aws.scheduler.scheduler_models import (
    FlexibleTimeWindowMode,
    SchedulerAPIConfig,
    ScheduleRequest,
    ScheduleRetryPolicyDict,
    ScheduleResponseDict,
    ScheduleListResponseDict,
    ScheduleState,
)
from chainsaws.aws.scheduler.scheduler_models import (
    ScheduleExpression as ModelScheduleExpression,
)
from chainsaws.aws.scheduler.scheduler_exception import (
    InvalidScheduleExpressionError,
    ScheduleConflictError,
    ScheduleGroupNotFoundException,
    ScheduleNotFoundException,
    ScheduleValidationError,
    SchedulerException,
)
from chainsaws.aws.scheduler.scheduler_utils import (
    generate_schedule_name,
)

from chainsaws.aws.lambda_client.lambda_exception import LambdaException

from chainsaws.aws.shared import session

logger = logging.getLogger(__name__)
_MAX_RESULTS_PER_PAGE = 100
_MIN_MAXIMUM_EVENT_AGE_IN_SECONDS = 60
_MAX_MAXIMUM_EVENT_AGE_IN_SECONDS = 86400
_MAX_MAXIMUM_RETRY_ATTEMPTS = 185


def _require_non_empty(name: str, value: str) -> None:
    if not value.strip():
        raise ScheduleValidationError(f"{name} must not be empty")


def _validate_max_results(value: int) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ScheduleValidationError("max_results must be an integer between 1 and 100")
    if not 1 <= value <= _MAX_RESULTS_PER_PAGE:
        raise ScheduleValidationError("max_results must be between 1 and 100")


def _extract_lambda_function_name(lambda_arn: str) -> str:
    marker = ":function:"
    if marker not in lambda_arn:
        return lambda_arn.split(":")[-1]
    suffix = lambda_arn.split(marker, 1)[1]
    return suffix.split(":", 1)[0]


def _validate_schedule_timezone(schedule_expression_timezone: Optional[str]) -> None:
    if schedule_expression_timezone is not None and not schedule_expression_timezone.strip():
        raise ScheduleValidationError("schedule_expression_timezone must not be empty")


def _validate_retry_policy(retry_policy: Optional[ScheduleRetryPolicyDict]) -> None:
    if retry_policy is None:
        return
    if "maximum_event_age_in_seconds" in retry_policy:
        value = retry_policy["maximum_event_age_in_seconds"]
        if (
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < _MIN_MAXIMUM_EVENT_AGE_IN_SECONDS
            or value > _MAX_MAXIMUM_EVENT_AGE_IN_SECONDS
        ):
            raise ScheduleValidationError(
                "maximum_event_age_in_seconds must be an integer between 60 and 86400",
            )
    if "maximum_retry_attempts" in retry_policy:
        value = retry_policy["maximum_retry_attempts"]
        if isinstance(value, bool) or not isinstance(value, int) or value < 0 or value > _MAX_MAXIMUM_RETRY_ATTEMPTS:
            raise ScheduleValidationError(
                "maximum_retry_attempts must be an integer between 0 and 185",
            )


def _validate_flexible_window(
    mode: FlexibleTimeWindowMode,
    minutes: Optional[int],
) -> None:
    if mode == "OFF":
        if minutes is not None:
            raise ScheduleValidationError(
                "flexible_time_window_minutes must be None when mode is OFF",
            )
        return
    if minutes is None:
        raise ScheduleValidationError(
            "flexible_time_window_minutes is required when mode is FLEXIBLE",
        )
    if isinstance(minutes, bool) or not isinstance(minutes, int) or not 1 <= minutes <= 1440:
        raise ScheduleValidationError(
            "flexible_time_window_minutes must be an integer between 1 and 1440",
        )


class SchedulerAPI:
    """High-level EventBridge Scheduler manager."""

    def __init__(
        self,
        schedule_group: Optional[str] = None,
        config: Optional[SchedulerAPIConfig] = None,
    ) -> None:
        """Initialize scheduler."""
        self.config = config or SchedulerAPIConfig()
        self.schedule_group = schedule_group or "chainsaws-default"
        _require_non_empty("schedule_group", self.schedule_group)

        self.boto3_session = session.get_boto_session(
            credentials=self.config.credentials if self.config.credentials else None,
        )

        self.scheduler = Scheduler(
            self.boto3_session,
            self.config,
        )

        self.lambda_client = LambdaAPI(config=self.config.to_lambda_config())

    def init_scheduler(
        self,
        lambda_function: str,
        schedule_expression: Optional[str] = 'rate(1 minute)',
        description: Optional[str] = None,
        input_data: Optional[dict[str, object]] = None,
        name_prefix: Optional[str] = None,
        *,
        state: ScheduleState = "ENABLED",
        flexible_time_window_mode: FlexibleTimeWindowMode = "OFF",
        flexible_time_window_minutes: Optional[int] = None,
        schedule_expression_timezone: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        client_token: Optional[str] = None,
        role_arn: Optional[str] = None,
        dead_letter_arn: Optional[str] = None,
        retry_policy: Optional[ScheduleRetryPolicyDict] = None,
    ) -> str:
        """Initialize scheduler for Lambda function.

        Args:
            lambda_function: Name or ARN of Lambda function
            schedule_expression: Optional custom schedule expression
            description: Optional schedule description
            input_data: Optional input data for Lambda
            name_prefix: Optional prefix for schedule name

        Returns:
            str: Created schedule name

        Raises:
            ValueError: If Lambda function doesn't exist or isn't properly configured
            Exception: Other AWS API errors
        """
        _require_non_empty("lambda_function", lambda_function)
        _validate_schedule_timezone(schedule_expression_timezone)
        _validate_retry_policy(retry_policy)
        _validate_flexible_window(
            flexible_time_window_mode,
            flexible_time_window_minutes,
        )
        try:
            # Get Lambda function details and full ARN
            try:
                lambda_details = self.lambda_client.get_function(
                    function_name=lambda_function)
                lambda_function_arn = lambda_details['FunctionArn']
            except Exception as ex:
                msg = f"Failed to validate Lambda function: {ex!s}"
                raise LambdaException(msg) from ex

            try:
                self.scheduler.get_schedule_group(
                    group_name=self.schedule_group)
                logger.warning(
                    msg=f"Schedule group '{self.schedule_group}' already exists. Skipping creation...")
                pass
            except ScheduleGroupNotFoundException:
                self.scheduler.create_schedule_group(self.schedule_group)

            # Extract function name from ARN for schedule name generation
            function_name = _extract_lambda_function_name(lambda_function_arn)
            name = generate_schedule_name(function_name, prefix=name_prefix)

            # Validate/normalize schedule expression
            validated_expr = ModelScheduleExpression.validate(schedule_expression) if schedule_expression else ModelScheduleExpression.validate('rate(1 minute)')

            request = ScheduleRequest(
                name=name,
                group_name=self.schedule_group,
                schedule_expression=validated_expr,
                lambda_function_arn=lambda_function_arn,
                description=description,
                input_data=input_data,
                state=state,
                flexible_time_window_mode=flexible_time_window_mode,
                flexible_time_window_minutes=flexible_time_window_minutes,
                schedule_expression_timezone=schedule_expression_timezone,
                start_date=start_date,
                end_date=end_date,
                client_token=client_token,
                role_arn=role_arn,
                dead_letter_arn=dead_letter_arn,
                retry_policy=retry_policy,
            )

            try:
                self.scheduler.get_schedule(
                    name, group_name=self.schedule_group)
                logger.warning(
                    msg=f"Schedule {name} already exists for Lambda function, skipping generation... : {function_name}",
                )

                return name
            except ScheduleNotFoundException:
                try:
                    self.scheduler.create_schedule(request)
                    logger.info(
                        msg=f"Created schedule: {name} for Lambda function: {function_name}",
                    )
                    return name
                except ScheduleConflictError:
                    # Idempotent behavior under concurrent create race.
                    logger.warning(
                        msg=f"Schedule '{name}' already exists due to concurrent create. Returning existing name.",
                    )
                    return name
            except Exception:
                logger.info(
                    msg=f"Failed to create schedule: {name} for Lambda function: {function_name}",
                )
                raise

        except (
            LambdaException,
            ScheduleValidationError,
            ScheduleGroupNotFoundException,
            ScheduleNotFoundException,
            SchedulerException,
        ):
            raise
        except Exception as ex:
            logger.exception(f"Failed to create schedule: {ex!s}")
            raise SchedulerException(str(ex)) from ex

    def delete_schedule(self, name: str) -> None:
        """Delete a schedule.

        Args:
            name: Name of the schedule to delete

        Raises:
            ScheduleNotFoundException: If schedule doesn't exist
            SchedulerException: Other AWS API errors
        """
        _require_non_empty("name", name)
        try:
            self.scheduler.delete_schedule(name, self.schedule_group)
            logger.info(f"Deleted schedule: {name}")
        except (ScheduleNotFoundException, SchedulerException):
            raise
        except Exception as ex:
            logger.exception(f"Failed to delete schedule: {ex!s}")
            raise SchedulerException(str(ex)) from ex

    def disable_schedule(self, name: str) -> None:
        """Disable a schedule.

        Args:
            name: Name of the schedule to disable

        Raises:
            ScheduleNotFoundException: If schedule doesn't exist
            SchedulerException: Other AWS API errors
        """
        _require_non_empty("name", name)
        try:
            self.scheduler.update_schedule_state(
                name, self.schedule_group, "DISABLED")
            logger.info(f"Disabled schedule: {name}")
        except (ScheduleNotFoundException, SchedulerException):
            raise
        except Exception as ex:
            logger.exception(f"Failed to disable schedule: {ex!s}")
            raise SchedulerException(str(ex)) from ex

    def enable_schedule(self, name: str) -> None:
        """Enable a schedule.

        Args:
            name: Name of the schedule to enable

        Raises:
            ScheduleNotFoundException: If schedule doesn't exist
            SchedulerException: Other AWS API errors
        """
        _require_non_empty("name", name)
        try:
            self.scheduler.update_schedule_state(
                name, self.schedule_group, "ENABLED")
            logger.info(f"Enabled schedule: {name}")
        except (ScheduleNotFoundException, SchedulerException):
            raise
        except Exception as ex:
            logger.exception(f"Failed to enable schedule: {ex!s}")
            raise SchedulerException(str(ex)) from ex

    def list_schedules(
        self,
        next_token: Optional[str] = None,
        max_results: int = 100,
    ) -> ScheduleListResponseDict:
        """List schedules in the group.

        Args:
            next_token: Token for pagination
            max_results: Maximum number of results to return

        Returns:
            ScheduleListResponse: List of schedules and next token

        Raises:
            SchedulerException: AWS API errors
        """
        _validate_max_results(max_results)
        try:
            response = self.scheduler.list_schedules(
                self.schedule_group,
                next_token=next_token,
                max_results=max_results,
            )

            schedules: list[ScheduleResponseDict] = []
            for schedule in response.get("Schedules", []):
                schedule_response = {
                    "name": schedule["Name"],
                    "arn": schedule["Arn"],
                    "state": schedule["State"],
                    "group_name": schedule["GroupName"],
                    "schedule_expression": schedule["ScheduleExpression"],
                    "description": schedule.get("Description"),
                    "next_invocation": schedule.get("NextInvocation"),
                    "last_invocation": schedule.get("LastInvocation"),
                    "target_arn": schedule["Target"]["Arn"],
                }
                schedules.append(schedule_response)

            return {
                "schedules": schedules,
                "next_token": response.get("NextToken"),
            }
        except SchedulerException:
            raise
        except Exception as ex:
            logger.exception(f"Failed to list schedules: {ex!s}")
            raise SchedulerException(str(ex)) from ex

    def update_schedule(
        self,
        name: str,
        schedule_expression: Optional[str] = None,
        description: Optional[str] = None,
        input_data: Optional[dict[str, object]] = None,
        state: Optional[ScheduleState] = None,
        *,
        schedule_expression_timezone: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        clear_description: bool = False,
        clear_input_data: bool = False,
        role_arn: Optional[str] = None,
        dead_letter_arn: Optional[str] = None,
        retry_policy: Optional[ScheduleRetryPolicyDict] = None,
        remove_target_dead_letter: bool = False,
        remove_target_retry_policy: bool = False,
    ) -> ScheduleResponseDict:
        """Update a schedule.

        Args:
            name: Name of the schedule to update
            schedule_expression: New schedule expression
            description: New description
            input_data: New input data
            state: New state

        Returns:
            ScheduleResponse: Updated schedule details

        Raises:
            ScheduleNotFoundException: If schedule doesn't exist
            InvalidScheduleExpressionError: If schedule expression is invalid
            SchedulerException: Other AWS API errors
        """
        _require_non_empty("name", name)
        _validate_schedule_timezone(schedule_expression_timezone)
        _validate_retry_policy(retry_policy)
        if clear_description and description is not None:
            raise ScheduleValidationError("description and clear_description cannot be used together")
        if clear_input_data and input_data is not None:
            raise ScheduleValidationError("input_data and clear_input_data cannot be used together")
        if dead_letter_arn is not None and remove_target_dead_letter:
            raise ScheduleValidationError("dead_letter_arn and remove_target_dead_letter cannot be used together")
        if retry_policy is not None and remove_target_retry_policy:
            raise ScheduleValidationError("retry_policy and remove_target_retry_policy cannot be used together")
        validated_expression: Optional[str] = None
        if schedule_expression is not None:
            try:
                validated_expression = str(ModelScheduleExpression.validate(schedule_expression))
            except ValueError as ex:
                raise InvalidScheduleExpressionError(str(ex)) from ex

        try:
            response = self.scheduler.update_schedule(
                name=name,
                group_name=self.schedule_group,
                schedule_expression=validated_expression,
                description=description,
                input_data=input_data,
                state=state if state else None,
                schedule_expression_timezone=schedule_expression_timezone,
                start_date=start_date,
                end_date=end_date,
                clear_description=clear_description,
                clear_input_data=clear_input_data,
                role_arn=role_arn,
                dead_letter_arn=dead_letter_arn,
                retry_policy=retry_policy,
                remove_target_dead_letter=remove_target_dead_letter,
                remove_target_retry_policy=remove_target_retry_policy,
            )

            return {
                "name": response["Name"],
                "arn": response["Arn"],
                "state": response["State"],
                "group_name": response["GroupName"],
                "schedule_expression": response["ScheduleExpression"],
                "description": response.get("Description"),
                "next_invocation": response.get("NextInvocation"),
                "last_invocation": response.get("LastInvocation"),
                "target_arn": response["Target"]["Arn"],
            }
        except SchedulerException:
            raise
        except Exception as ex:
            logger.exception(f"Failed to update schedule: {ex!s}")
            raise SchedulerException(str(ex)) from ex
