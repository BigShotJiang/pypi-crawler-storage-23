from __future__ import annotations

import base64
import json
import logging
from typing import NoReturn, cast

from boto3.session import Session
from botocore.config import Config
from botocore.exceptions import ClientError

from chainsaws.aws.secrets_manager.secrets_manager_exception import (
    SecretAlreadyExistsException,
    SecretNotFoundException,
    SecretsManagerAccessDeniedException,
    SecretsManagerDeletionAlreadyScheduledException,
    SecretsManagerException,
    SecretsManagerInvalidRequestException,
    SecretsManagerThrottlingException,
    SecretsManagerValidationException,
)
from chainsaws.aws.secrets_manager.secrets_manager_models import (
    CreateSecretResponse,
    DeleteSecretResponse,
    DescribeSecretResponse,
    GetRandomPasswordResponse,
    GetSecretResponse,
    ListSecretsResponse,
    PutSecretValueResponse,
    RotateSecretResponse,
    RotationConfig,
    SecretConfig,
    SecretValueInput,
    SecretsManagerAPIConfig,
    TagResourceResponse,
    UntagResourceResponse,
)

logger = logging.getLogger(__name__)

_RETRYABLE_ERROR_CODES = frozenset(
    {
        "ThrottlingException",
        "TooManyRequestsException",
        "RequestLimitExceeded",
        "ServiceUnavailableException",
    },
)
_ACCESS_DENIED_ERROR_CODES = frozenset(
    {
        "AccessDeniedException",
        "NotAuthorizedException",
        "UnrecognizedClientException",
    },
)

RequestMap = dict[str, object]
ResponseMap = dict[str, object]


def _normalize_secret_id(secret_id: str) -> str:
    normalized = secret_id.strip()
    if normalized == "":
        msg = "secret_id must not be empty"
        raise SecretsManagerValidationException(msg)
    return normalized


def _error_code(error: ClientError) -> str:
    return str(error.response.get("Error", {}).get("Code", ""))


def _error_message(error: ClientError, operation: str) -> str:
    code = _error_code(error)
    message = str(error.response.get("Error", {}).get("Message", ""))
    if message:
        return f"{operation} failed ({code}): {message}"
    return f"{operation} failed ({code})"


def _raise_mapped_client_error(operation: str, error: ClientError) -> NoReturn:
    code = _error_code(error)
    message = _error_message(error, operation)

    if code == "ResourceNotFoundException":
        raise SecretNotFoundException(message, operation=operation, error_code=code) from error
    if code == "ResourceExistsException":
        raise SecretAlreadyExistsException(message, operation=operation, error_code=code) from error
    if code == "InvalidRequestException":
        if "scheduled for deletion" in message.lower():
            raise SecretsManagerDeletionAlreadyScheduledException(
                message,
                operation=operation,
                error_code=code,
            ) from error
        raise SecretsManagerInvalidRequestException(
            message,
            operation=operation,
            error_code=code,
        ) from error
    if code in _RETRYABLE_ERROR_CODES:
        raise SecretsManagerThrottlingException(
            message,
            operation=operation,
            error_code=code,
        ) from error
    if code in _ACCESS_DENIED_ERROR_CODES:
        raise SecretsManagerAccessDeniedException(
            message,
            operation=operation,
            error_code=code,
        ) from error

    raise SecretsManagerException(message, operation=operation, error_code=code) from error


class SecretsManager:
    """Low-level Secrets Manager client wrapper."""

    def __init__(
        self,
        boto3_session: Session,
        config: SecretsManagerAPIConfig | None = None,
    ) -> None:
        self.config = config or SecretsManagerAPIConfig()

        client_config = Config(
            region_name=self.config.region,
            retries={
                "max_attempts": self.config.retry_modes["max_attempts"],
                "mode": self.config.retry_modes["mode"],
            },
            connect_timeout=self.config.timeout,
            read_timeout=self.config.timeout,
        )
        self.client = boto3_session.client(
            "secretsmanager",
            config=client_config,
            region_name=self.config.region,
        )

    def create_secret(self, config: SecretConfig) -> CreateSecretResponse:
        params: RequestMap = {"Name": config.name}
        if config.description:
            params["Description"] = config.description
        if config.tags:
            params["Tags"] = [{"Key": key, "Value": value} for key, value in config.tags.items()]
        if config.secret_string is not None:
            params["SecretString"] = config.secret_string
        if config.secret_binary is not None:
            params["SecretBinary"] = config.secret_binary

        try:
            response = cast(ResponseMap, self.client.create_secret(**params))
            return cast(CreateSecretResponse, response)
        except ClientError as error:
            logger.exception("Failed to create secret")
            _raise_mapped_client_error("create_secret", error)

    def get_secret_value(
        self,
        secret_id: str,
        version_id: str | None = None,
        version_stage: str | None = None,
    ) -> GetSecretResponse:
        params: RequestMap = {"SecretId": _normalize_secret_id(secret_id)}
        if version_id:
            params["VersionId"] = version_id
        if version_stage:
            params["VersionStage"] = version_stage

        try:
            response = cast(ResponseMap, self.client.get_secret_value(**params))
            secret_binary = response.get("SecretBinary")
            if isinstance(secret_binary, str):
                response["SecretBinary"] = base64.b64decode(secret_binary)
            elif isinstance(secret_binary, bytes | bytearray | memoryview):
                response["SecretBinary"] = bytes(secret_binary)
            elif secret_binary is not None:
                msg = f"Unexpected SecretBinary type: {type(secret_binary).__name__}"
                raise SecretsManagerInvalidRequestException(msg, operation="get_secret_value")

            return cast(GetSecretResponse, response)
        except ClientError as error:
            logger.exception("Failed to get secret value")
            _raise_mapped_client_error("get_secret_value", error)

    def put_secret_value(
        self,
        secret_id: str,
        secret_value: SecretValueInput,
        version_stages: list[str] | None = None,
    ) -> PutSecretValueResponse:
        params: RequestMap = {"SecretId": _normalize_secret_id(secret_id)}
        if isinstance(secret_value, bytes):
            params["SecretBinary"] = secret_value
        elif isinstance(secret_value, str):
            params["SecretString"] = secret_value
        else:
            params["SecretString"] = json.dumps(
                secret_value,
                ensure_ascii=False,
                separators=(",", ":"),
            )

        if version_stages:
            params["VersionStages"] = version_stages

        try:
            response = cast(ResponseMap, self.client.put_secret_value(**params))
            return cast(PutSecretValueResponse, response)
        except ClientError as error:
            logger.exception("Failed to put secret value")
            _raise_mapped_client_error("put_secret_value", error)

    def delete_secret(
        self,
        secret_id: str,
        force_delete: bool = False,
        recovery_window_in_days: int | None = None,
    ) -> DeleteSecretResponse:
        params: RequestMap = {"SecretId": _normalize_secret_id(secret_id)}
        if force_delete:
            params["ForceDeleteWithoutRecovery"] = True
        elif recovery_window_in_days is not None:
            if recovery_window_in_days < 7 or recovery_window_in_days > 30:
                msg = "recovery_window_in_days must be between 7 and 30"
                raise SecretsManagerValidationException(msg)
            params["RecoveryWindowInDays"] = recovery_window_in_days

        try:
            response = cast(ResponseMap, self.client.delete_secret(**params))
            return cast(DeleteSecretResponse, response)
        except ClientError as error:
            logger.exception("Failed to delete secret")
            _raise_mapped_client_error("delete_secret", error)

    def rotate_secret(
        self,
        secret_id: str,
        config: RotationConfig,
    ) -> RotateSecretResponse:
        params: RequestMap = {
            "SecretId": _normalize_secret_id(secret_id),
            "RotationLambdaARN": config.rotation_lambda_arn,
        }

        rotation_rules = dict(config.rotation_rules)
        if config.automatically_after_days is not None:
            rotation_rules["AutomaticallyAfterDays"] = config.automatically_after_days
        if rotation_rules:
            params["RotationRules"] = rotation_rules

        try:
            response = cast(ResponseMap, self.client.rotate_secret(**params))
            return cast(RotateSecretResponse, response)
        except ClientError as error:
            logger.exception("Failed to configure rotation")
            _raise_mapped_client_error("rotate_secret", error)

    def describe_secret(self, secret_id: str) -> DescribeSecretResponse:
        try:
            response = cast(
                ResponseMap,
                self.client.describe_secret(SecretId=_normalize_secret_id(secret_id)),
            )
            return cast(DescribeSecretResponse, response)
        except ClientError as error:
            logger.exception("Failed to describe secret")
            _raise_mapped_client_error("describe_secret", error)

    def list_secrets(
        self,
        max_results: int | None = None,
        next_token: str | None = None,
    ) -> ListSecretsResponse:
        params: RequestMap = {}
        if max_results is not None:
            if max_results <= 0 or max_results > 100:
                msg = "max_results must be between 1 and 100"
                raise SecretsManagerValidationException(msg)
            params["MaxResults"] = max_results
        if next_token:
            params["NextToken"] = next_token

        try:
            response = cast(ResponseMap, self.client.list_secrets(**params))
            secret_list = response.get("SecretList")
            if not isinstance(secret_list, list):
                response["SecretList"] = []
            return cast(ListSecretsResponse, response)
        except ClientError as error:
            logger.exception("Failed to list secrets")
            _raise_mapped_client_error("list_secrets", error)

    def tag_secret(
        self,
        secret_id: str,
        tags: dict[str, str],
    ) -> TagResourceResponse:
        if not tags:
            msg = "tags must not be empty"
            raise SecretsManagerValidationException(msg)

        try:
            response = cast(
                ResponseMap,
                self.client.tag_resource(
                    SecretId=_normalize_secret_id(secret_id),
                    Tags=[{"Key": key, "Value": value} for key, value in tags.items()],
                ),
            )
            return cast(TagResourceResponse, response)
        except ClientError as error:
            logger.exception("Failed to tag secret")
            _raise_mapped_client_error("tag_secret", error)

    def untag_secret(
        self,
        secret_id: str,
        tag_keys: list[str],
    ) -> UntagResourceResponse:
        normalized_tag_keys = [tag_key.strip() for tag_key in tag_keys]
        if not normalized_tag_keys or any(tag_key == "" for tag_key in normalized_tag_keys):
            msg = "tag_keys must contain at least one non-empty key"
            raise SecretsManagerValidationException(msg)

        try:
            response = cast(
                ResponseMap,
                self.client.untag_resource(
                    SecretId=_normalize_secret_id(secret_id),
                    TagKeys=normalized_tag_keys,
                ),
            )
            return cast(UntagResourceResponse, response)
        except ClientError as error:
            logger.exception("Failed to untag secret")
            _raise_mapped_client_error("untag_secret", error)

    def get_random_password(
        self,
        length: int = 32,
        exclude_characters: str | None = None,
        exclude_numbers: bool = False,
        exclude_punctuation: bool = False,
        exclude_uppercase: bool = False,
        exclude_lowercase: bool = False,
        include_space: bool = False,
        require_each_included_type: bool = False,
    ) -> GetRandomPasswordResponse:
        if length <= 0 or length > 4096:
            msg = "length must be between 1 and 4096"
            raise SecretsManagerValidationException(msg)

        params: RequestMap = {
            "PasswordLength": length,
            "ExcludeNumbers": exclude_numbers,
            "ExcludePunctuation": exclude_punctuation,
            "ExcludeUppercase": exclude_uppercase,
            "ExcludeLowercase": exclude_lowercase,
            "IncludeSpace": include_space,
            "RequireEachIncludedType": require_each_included_type,
        }
        if exclude_characters:
            params["ExcludeCharacters"] = exclude_characters

        try:
            response = cast(ResponseMap, self.client.get_random_password(**params))
            return cast(GetRandomPasswordResponse, response)
        except ClientError as error:
            logger.exception("Failed to generate random password")
            _raise_mapped_client_error("get_random_password", error)
