from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, NotRequired, Required, TypeAlias, TypedDict

from chainsaws.aws.secrets_manager.secrets_manager_exception import (
    SecretsManagerValidationException,
)
from chainsaws.aws.shared.config import APIConfig

JSONPrimitive = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]
SecretValueInput: TypeAlias = str | bytes | dict[str, JSONValue]
SecretValue: TypeAlias = bytes | JSONValue
RetryMode: TypeAlias = Literal["adaptive", "standard", "legacy"]
BatchSecretOperationType: TypeAlias = Literal["delete", "rotate", "update"]


class RetryConfig(TypedDict, total=False):
    max_attempts: int
    mode: RetryMode


class SecretTag(TypedDict):
    Key: str
    Value: str


class RotationRules(TypedDict, total=False):
    AutomaticallyAfterDays: int
    Duration: str
    ScheduleExpression: str


class CreateSecretResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    VersionId: NotRequired[str]


class GetSecretResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    VersionId: NotRequired[str]
    SecretBinary: NotRequired[bytes]
    SecretString: NotRequired[str]
    VersionStages: NotRequired[list[str]]
    CreatedDate: NotRequired[datetime]


class PutSecretValueResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    VersionId: NotRequired[str]
    VersionStages: NotRequired[list[str]]


class DeleteSecretResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    DeletionDate: NotRequired[datetime]


class SecretListEntry(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    Description: NotRequired[str]
    CreatedDate: NotRequired[datetime]
    LastChangedDate: NotRequired[datetime]
    DeletedDate: NotRequired[datetime]
    Tags: NotRequired[list[SecretTag]]


class ListSecretsResponse(TypedDict, total=False):
    SecretList: Required[list[SecretListEntry]]
    NextToken: NotRequired[str]


class DescribeSecretResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    Description: NotRequired[str]
    RotationEnabled: NotRequired[bool]
    LastRotatedDate: NotRequired[datetime]
    LastChangedDate: NotRequired[datetime]
    NextRotationDate: NotRequired[datetime]
    DeletedDate: NotRequired[datetime]
    Tags: NotRequired[list[SecretTag]]


class RotateSecretResponse(TypedDict, total=False):
    ARN: Required[str]
    Name: Required[str]
    VersionId: NotRequired[str]


class TagResourceResponse(TypedDict, total=False):
    ARN: NotRequired[str]
    Name: NotRequired[str]


class UntagResourceResponse(TypedDict, total=False):
    ARN: NotRequired[str]
    Name: NotRequired[str]


class GetRandomPasswordResponse(TypedDict):
    RandomPassword: str


class BatchSecretFailure(TypedDict):
    secret_id: str
    error: str


class BatchSecretOperationResult(TypedDict):
    successful: list[str]
    failed: list[BatchSecretFailure]


class RestoreSecretsResult(TypedDict):
    restored: list[str]
    failed: list[BatchSecretFailure]


class BackupSecretRecord(TypedDict):
    id: str
    value: SecretValue | dict[str, str]
    metadata: DescribeSecretResponse


class SecretBackupPayload(TypedDict):
    secrets: list[BackupSecretRecord]
    metadata: dict[str, str]


@dataclass
class SecretsManagerAPIConfig(APIConfig):
    """Secrets Manager configuration."""

    max_retries: int = 3
    timeout: int = 30
    retry_modes: RetryConfig = field(
        default_factory=lambda: {"mode": "adaptive"},
    )
    batch_max_workers: int = 8

    def __post_init__(self) -> None:
        if self.max_retries <= 0:
            msg = "max_retries must be a positive integer"
            raise SecretsManagerValidationException(msg)
        if self.timeout <= 0:
            msg = "timeout must be a positive integer"
            raise SecretsManagerValidationException(msg)
        if self.batch_max_workers <= 0:
            msg = "batch_max_workers must be a positive integer"
            raise SecretsManagerValidationException(msg)

        max_attempts = int(self.retry_modes.get("max_attempts", self.max_retries))
        mode = self.retry_modes.get("mode", "adaptive")
        if max_attempts <= 0:
            msg = "retry_modes.max_attempts must be a positive integer"
            raise SecretsManagerValidationException(msg)
        if mode not in ("adaptive", "standard", "legacy"):
            msg = "retry_modes.mode must be one of adaptive|standard|legacy"
            raise SecretsManagerValidationException(msg)
        self.retry_modes = {"max_attempts": max_attempts, "mode": mode}


@dataclass
class SecretConfig:
    """Secret configuration."""

    name: str
    description: str | None = None
    secret_string: str | None = None
    secret_binary: bytes | None = None
    tags: dict[str, str] | None = None

    def __post_init__(self) -> None:
        self.name = self.name.strip()
        if self.name == "" or len(self.name) > 512:
            msg = "Secret name must be between 1 and 512 characters"
            raise SecretsManagerValidationException(msg)

        if self.secret_string is None and self.secret_binary is None:
            msg = "Either secret_string or secret_binary must be provided"
            raise SecretsManagerValidationException(msg)
        if self.secret_string is not None and self.secret_binary is not None:
            msg = "secret_string and secret_binary are mutually exclusive"
            raise SecretsManagerValidationException(msg)


@dataclass
class RotationConfig:
    """Secret rotation configuration."""

    rotation_lambda_arn: str
    rotation_rules: RotationRules = field(default_factory=dict)
    automatically_after_days: int | None = None

    def __post_init__(self) -> None:
        self.rotation_lambda_arn = self.rotation_lambda_arn.strip()
        if self.rotation_lambda_arn == "":
            msg = "rotation_lambda_arn must not be empty"
            raise SecretsManagerValidationException(msg)
        if self.automatically_after_days is not None and self.automatically_after_days <= 0:
            msg = "automatically_after_days must be a positive integer"
            raise SecretsManagerValidationException(msg)


@dataclass
class BatchSecretOperation:
    """Batch operation configuration."""

    secret_ids: list[str]
    operation: BatchSecretOperationType
    params: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        normalized_secret_ids = [secret_id.strip() for secret_id in self.secret_ids]
        if not normalized_secret_ids or any(secret_id == "" for secret_id in normalized_secret_ids):
            msg = "secret_ids must contain at least one non-empty id"
            raise SecretsManagerValidationException(msg)
        self.secret_ids = normalized_secret_ids


@dataclass
class SecretBackupConfig:
    """Secret backup configuration."""

    secret_ids: list[str]
    backup_path: str

    def __post_init__(self) -> None:
        normalized_secret_ids = [secret_id.strip() for secret_id in self.secret_ids]
        if not normalized_secret_ids or any(secret_id == "" for secret_id in normalized_secret_ids):
            msg = "secret_ids must contain at least one non-empty id"
            raise SecretsManagerValidationException(msg)
        self.secret_ids = normalized_secret_ids

        self.backup_path = self.backup_path.strip()
        if self.backup_path == "":
            msg = "backup_path must not be empty"
            raise SecretsManagerValidationException(msg)


@dataclass
class SecretFilterConfig:
    """Secret filtering configuration."""

    name_prefix: str | None = None
    tags: dict[str, str] | None = None
    created_after: datetime | None = None
    last_updated_after: datetime | None = None
