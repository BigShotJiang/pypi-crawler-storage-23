from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Literal, TypedDict

from chainsaws.aws.shared.config import APIConfig


class LogLevel(str, Enum):
    """Log levels for CloudWatch Logs."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class RetentionDays(int, Enum):
    """Available retention periods for log groups."""

    ONE_DAY = 1
    THREE_DAYS = 3
    FIVE_DAYS = 5
    ONE_WEEK = 7
    TWO_WEEKS = 14
    ONE_MONTH = 30
    TWO_MONTHS = 60
    THREE_MONTHS = 90
    FOUR_MONTHS = 120
    FIVE_MONTHS = 150
    SIX_MONTHS = 180
    ONE_YEAR = 365
    FOREVER = 0


class QueryStatus(str, Enum):
    """CloudWatch Logs Insights query statuses."""

    SCHEDULED = "Scheduled"
    RUNNING = "Running"
    COMPLETE = "Complete"
    FAILED = "Failed"
    CANCELLED = "Cancelled"
    TIMEOUT = "Timeout"
    UNKNOWN = "Unknown"


class QuerySortBy(str, Enum):
    """Sort options for Insights queries."""

    TIME_ASC = "asc"
    TIME_DESC = "desc"


class QueryStatistics(TypedDict, total=False):
    """Statistics returned by CloudWatch Logs Insights."""

    recordsMatched: float
    recordsScanned: float
    bytesScanned: float


class QueryField(TypedDict):
    """Single key-value pair for a query result field."""

    field: str
    value: str


class MetricTransformation(TypedDict, total=False):
    """CloudWatch metric transformation payload."""

    metricName: str
    metricNamespace: str
    metricValue: str
    defaultValue: float


SubscriptionDistribution = Literal["Random", "ByLogStream"]


@dataclass
class CloudWatchAPIConfig(APIConfig):
    """Configuration for CloudWatch Logs API."""

    default_region: str = "ap-northeast-2"
    max_retries: int = 3


@dataclass
class FilterPattern:
    """Filter pattern wrapper."""

    pattern: str
    fields: list[str] = field(default_factory=list)


@dataclass
class LogGroupConfig:
    """Configuration for log group creation."""

    log_group_name: str
    retention_days: RetentionDays | None = None
    kms_key_id: str | None = None
    tags: dict[str, str] = field(default_factory=dict)


@dataclass
class LogStreamConfig:
    """Configuration for log stream creation."""

    log_group_name: str
    log_stream_name: str


@dataclass
class LogEvent:
    """Single log event."""

    message: str
    timestamp: datetime | int
    level: LogLevel = LogLevel.INFO

    def __post_init__(self) -> None:
        """Normalize timestamp for internal comparisons."""
        if isinstance(self.timestamp, int):
            self.timestamp = datetime.fromtimestamp(self.timestamp / 1000, tz=UTC)


@dataclass
class PutLogsConfig:
    """Configuration for put_log_events."""

    log_group_name: str
    log_stream_name: str
    events: list[LogEvent]
    sequence_token: str | None = None


@dataclass
class GetLogsConfig:
    """Configuration for get_log_events."""

    log_group_name: str
    log_stream_name: str
    start_time: datetime | None = None
    end_time: datetime | None = None
    limit: int | None = None
    next_token: str | None = None


@dataclass
class LogBatch:
    """Batch of log events."""

    log_group_name: str
    log_stream_name: str
    events: list[LogEvent]
    sequence_token: str | None = None


@dataclass
class LogFilter:
    """Filter for log events."""

    log_group_name: str
    filter_pattern: str
    start_time: datetime | None = None
    end_time: datetime | None = None
    log_stream_names: list[str] | None = field(default_factory=list)
    limit: int | None = None


@dataclass
class MetricFilter:
    """Metric filter configuration."""

    filter_name: str
    log_group_name: str
    filter_pattern: FilterPattern | str
    metric_namespace: str | None = None
    metric_name: str | None = None
    metric_value: str | None = None
    default_value: float | None = None
    metric_transformations: list[MetricTransformation] | None = None

    def __post_init__(self) -> None:
        if isinstance(self.filter_pattern, str):
            self.filter_pattern = FilterPattern(pattern=self.filter_pattern)

    def to_metric_transformations(self) -> list[MetricTransformation]:
        """Convert configuration to AWS metric transformations payload."""
        if self.metric_transformations is not None:
            return self.metric_transformations

        if (
            self.metric_name is None
            or self.metric_namespace is None
            or self.metric_value is None
        ):
            msg = (
                "Either metric_transformations or "
                "metric_name/metric_namespace/metric_value is required"
            )
            raise ValueError(msg)

        transformation: MetricTransformation = {
            "metricName": self.metric_name,
            "metricNamespace": self.metric_namespace,
            "metricValue": self.metric_value,
        }
        if self.default_value is not None:
            transformation["defaultValue"] = self.default_value
        return [transformation]


@dataclass
class SubscriptionFilter:
    """Subscription filter configuration."""

    filter_name: str
    log_group_name: str
    filter_pattern: FilterPattern | str
    destination_arn: str
    role_arn: str | None = None
    distribution: SubscriptionDistribution | None = None

    def __post_init__(self) -> None:
        if isinstance(self.filter_pattern, str):
            self.filter_pattern = FilterPattern(pattern=self.filter_pattern)


@dataclass
class LogsInsightsQuery:
    """Configuration for CloudWatch Logs Insights query execution."""

    query_string: str
    log_group_names: list[str]
    start_time: datetime
    end_time: datetime
    limit: int | None = None
    sort_by: QuerySortBy = QuerySortBy.TIME_DESC


@dataclass
class QueryResult:
    """Result of a CloudWatch Logs Insights query."""

    query_id: str
    status: QueryStatus
    results: list[dict[str, str]] = field(default_factory=list)
    statistics: QueryStatistics = field(default_factory=dict)
    error_message: str | None = None


@dataclass
class MetricDataQuery:
    """Query configuration for metric data."""

    metric_name: str
    namespace: str
    dimensions: dict[str, str]
    period: int
    stat: str
    unit: str | None = None
    return_data: bool = True


@dataclass
class MetricAlarm:
    """Alarm configuration for metrics."""

    alarm_name: str
    metric_name: str
    namespace: str
    comparison_operator: str
    evaluation_periods: int
    period: int
    threshold: float
    statistic: str
    dimensions: dict[str, str] = field(default_factory=dict)
    actions_enabled: bool = True
    alarm_actions: list[str] = field(default_factory=list)
    ok_actions: list[str] = field(default_factory=list)
    insufficient_data_actions: list[str] = field(default_factory=list)
