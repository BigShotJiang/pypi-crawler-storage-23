from __future__ import annotations

import logging
import time
from typing import NoReturn

from boto3 import Session
from botocore.exceptions import ClientError

from chainsaws.aws.apigatewaymanagement.apigatewaymanagement_exceptions import (
    APIGatewayManagementBadRequestError,
    APIGatewayManagementDeleteConnectionError,
    APIGatewayManagementEndpointURLRequiredException,
    APIGatewayManagementException,
    APIGatewayManagementForbiddenError,
    APIGatewayManagementGetConnectionError,
    APIGatewayManagementGoneConnectionError,
    APIGatewayManagementLimitExceededError,
    APIGatewayManagementPayloadTooLargeError,
    APIGatewayManagementPostToConnectionError,
    APIGatewayManagementThrottlingError,
    APIGatewayManagementValidationError,
)
from chainsaws.aws.apigatewaymanagement.apigatewaymanagement_models import (
    APIGatewayManagementAPIConfig,
    APIGatewayManagementKnownErrorCode,
    ConnectionPostResult,
)
from chainsaws.aws.apigatewaymanagement.response.GetConnectionResponse import GetConnectionResponse

logger = logging.getLogger(__name__)

_RETRYABLE_ERROR_CODES: frozenset[APIGatewayManagementKnownErrorCode] = frozenset(
    {
        "Throttling",
        "ThrottlingException",
        "TooManyRequestsException",
        "RequestLimitExceeded",
        "LimitExceededException",
        "ServiceUnavailableException",
    },
)

_LIMIT_EXCEEDED_ERROR_CODES: frozenset[APIGatewayManagementKnownErrorCode] = frozenset(
    {"LimitExceededException", "RequestLimitExceeded"},
)


def _normalize_connection_id(connection_id: str) -> str:
    normalized = connection_id.strip()
    if normalized == "":
        msg = "connection_id must not be empty"
        raise APIGatewayManagementValidationError(msg)
    return normalized


def _to_payload_bytes(data: str | bytes) -> bytes:
    if isinstance(data, bytes):
        return data
    return data.encode("utf-8")


class APIGatewayManagement:
    """Low-level APIGatewayManagementAPI wrapper."""

    def __init__(
        self,
        boto3_session: Session,
        config: APIGatewayManagementAPIConfig | None = None,
    ) -> None:
        self.config = config
        if self.config is None:
            msg = "endpoint_url is required"
            raise APIGatewayManagementEndpointURLRequiredException(msg)

        self.apigateway_management_client = boto3_session.client(
            service_name="apigatewaymanagementapi",
            region_name=self.config.region,
            endpoint_url=self.config.endpoint_url,
        )

    @staticmethod
    def _error_code(error: ClientError) -> str:
        return str(error.response.get("Error", {}).get("Code", ""))

    @staticmethod
    def _error_message(error: ClientError) -> str:
        return str(error.response.get("Error", {}).get("Message", ""))

    @staticmethod
    def _request_id(error: ClientError) -> str | None:
        request_id = error.response.get("ResponseMetadata", {}).get("RequestId")
        if request_id is None:
            return None
        return str(request_id)

    @staticmethod
    def _status_code(error: ClientError) -> int | None:
        status_code = error.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if isinstance(status_code, int):
            return status_code
        return None

    def _raise_mapped_client_error(
        self,
        *,
        error: ClientError,
        operation: str,
        default_exception: type[APIGatewayManagementException],
    ) -> NoReturn:
        code = self._error_code(error)
        message = self._error_message(error)
        request_id = self._request_id(error)
        status_code = self._status_code(error)
        reason = f"{operation} failed ({code})"
        if message:
            reason = f"{reason}: {message}"

        common_kwargs = {
            "operation": operation,
            "error_code": code,
            "request_id": request_id,
            "status_code": status_code,
        }

        if code == "GoneException":
            raise APIGatewayManagementGoneConnectionError(reason, **common_kwargs) from error
        if code == "PayloadTooLargeException":
            raise APIGatewayManagementPayloadTooLargeError(reason, **common_kwargs) from error
        if code == "BadRequestException":
            raise APIGatewayManagementBadRequestError(reason, **common_kwargs) from error
        if code in _LIMIT_EXCEEDED_ERROR_CODES:
            raise APIGatewayManagementLimitExceededError(reason, **common_kwargs) from error
        if code in {
            "ForbiddenException",
            "UnauthorizedException",
            "MissingAuthenticationTokenException",
        }:
            raise APIGatewayManagementForbiddenError(reason, **common_kwargs) from error
        if code in _RETRYABLE_ERROR_CODES:
            raise APIGatewayManagementThrottlingError(reason, **common_kwargs) from error

        raise default_exception(reason, **common_kwargs) from error

    def _call_with_retries(
        self,
        *,
        method_name: str,
        operation: str,
        default_exception: type[APIGatewayManagementException],
        **kwargs: object,
    ) -> dict[str, object]:
        method = getattr(self.apigateway_management_client, method_name)
        last_error: ClientError | None = None

        for attempt in range(self.config.retry_attempts):
            try:
                return method(**kwargs)
            except ClientError as error:
                last_error = error
                code = self._error_code(error)
                if code not in _RETRYABLE_ERROR_CODES:
                    self._raise_mapped_client_error(
                        error=error,
                        operation=operation,
                        default_exception=default_exception,
                    )
                if attempt == self.config.retry_attempts - 1:
                    break
                delay_seconds = min(
                    self.config.retry_base_delay_seconds * (2**attempt),
                    self.config.retry_max_delay_seconds,
                )
                time.sleep(delay_seconds)

        assert last_error is not None
        self._raise_mapped_client_error(
            error=last_error,
            operation=operation,
            default_exception=default_exception,
        )

    def post_to_connection(
        self,
        connection_id: str,
        data: str | bytes,
        *,
        ignore_gone: bool = False,
    ) -> None:
        normalized_connection_id = _normalize_connection_id(connection_id)
        payload = _to_payload_bytes(data)

        if len(payload) > self.config.max_payload_bytes:
            msg = (
                f"payload must be <= {self.config.max_payload_bytes} bytes "
                f"(got {len(payload)})"
            )
            raise APIGatewayManagementPayloadTooLargeError(msg)

        try:
            self._call_with_retries(
                method_name="post_to_connection",
                operation="post_to_connection",
                default_exception=APIGatewayManagementPostToConnectionError,
                ConnectionId=normalized_connection_id,
                Data=payload,
            )
        except APIGatewayManagementGoneConnectionError:
            if ignore_gone:
                return
            raise

    def post_to_connections(
        self,
        connection_ids: list[str],
        data: str | bytes,
        *,
        ignore_gone: bool = False,
    ) -> list[ConnectionPostResult]:
        payload = _to_payload_bytes(data)
        results: list[ConnectionPostResult] = []

        for connection_id in connection_ids:
            normalized_connection_id = _normalize_connection_id(connection_id)
            try:
                self.post_to_connection(
                    connection_id=normalized_connection_id,
                    data=payload,
                    ignore_gone=ignore_gone,
                )
                results.append(
                    {
                        "connection_id": normalized_connection_id,
                        "success": True,
                        "error_code": None,
                        "error_message": None,
                    },
                )
            except APIGatewayManagementException as error:
                results.append(
                    {
                        "connection_id": normalized_connection_id,
                        "success": False,
                        "error_code": error.error_code,
                        "error_message": str(error),
                    },
                )

        return results

    def get_connection(self, connection_id: str) -> GetConnectionResponse:
        normalized_connection_id = _normalize_connection_id(connection_id)
        response = self._call_with_retries(
            method_name="get_connection",
            operation="get_connection",
            default_exception=APIGatewayManagementGetConnectionError,
            ConnectionId=normalized_connection_id,
        )
        return response

    def delete_connection(
        self,
        connection_id: str,
        *,
        ignore_gone: bool = False,
    ) -> None:
        normalized_connection_id = _normalize_connection_id(connection_id)
        try:
            self._call_with_retries(
                method_name="delete_connection",
                operation="delete_connection",
                default_exception=APIGatewayManagementDeleteConnectionError,
                ConnectionId=normalized_connection_id,
            )
        except APIGatewayManagementGoneConnectionError:
            if ignore_gone:
                return
            raise
