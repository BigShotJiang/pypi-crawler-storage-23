class APIGatewayManagementException(Exception):
    """Base exception for APIGatewayManagement."""

    def __init__(
        self,
        message: str,
        *,
        operation: str | None = None,
        error_code: str | None = None,
        request_id: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.operation = operation
        self.error_code = error_code
        self.request_id = request_id
        self.status_code = status_code


class APIGatewayManagementServiceError(APIGatewayManagementException):
    """Raised when AWS APIGatewayManagement service returns an error."""


class APIGatewayManagementValidationError(APIGatewayManagementException):
    """Raised when APIGatewayManagement input validation fails."""


class APIGatewayManagementEndpointURLRequiredException(APIGatewayManagementValidationError):
    """Raised when endpoint_url is required."""


class APIGatewayManagementPostToConnectionError(APIGatewayManagementServiceError):
    """Raised when post_to_connection fails."""


class APIGatewayManagementGetConnectionError(APIGatewayManagementServiceError):
    """Raised when get_connection fails."""


class APIGatewayManagementDeleteConnectionError(APIGatewayManagementServiceError):
    """Raised when delete_connection fails."""


class APIGatewayManagementGoneConnectionError(APIGatewayManagementPostToConnectionError):
    """Raised when target connection is gone."""


class APIGatewayManagementPayloadTooLargeError(APIGatewayManagementPostToConnectionError):
    """Raised when payload exceeds size limit."""


class APIGatewayManagementThrottlingError(APIGatewayManagementServiceError):
    """Raised for retryable throttling errors."""


class APIGatewayManagementLimitExceededError(APIGatewayManagementServiceError):
    """Raised when service/account limits are exceeded."""


class APIGatewayManagementForbiddenError(APIGatewayManagementServiceError):
    """Raised for forbidden/unauthorized access."""


class APIGatewayManagementBadRequestError(APIGatewayManagementValidationError):
    """Raised when AWS reports request parameters are invalid."""
