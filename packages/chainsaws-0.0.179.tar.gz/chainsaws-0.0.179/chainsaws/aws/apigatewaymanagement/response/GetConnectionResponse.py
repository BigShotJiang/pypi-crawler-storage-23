from datetime import datetime
from typing import NotRequired, TypedDict

class ConnectionIdentity(TypedDict, total=False):
    SourceIp: str
    UserAgent: str

class GetConnectionResponse(TypedDict, total=False):
    ConnectedAt: NotRequired[datetime]
    Identity: NotRequired[ConnectionIdentity]
    LastActiveAt: NotRequired[datetime]
