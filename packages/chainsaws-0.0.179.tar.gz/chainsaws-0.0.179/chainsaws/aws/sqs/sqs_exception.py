class SQSException(Exception):
    """Base class for all SQS exceptions."""

    def __init__(self, message: str, *args: object) -> None:
        self.message = message
        super().__init__(message, *args)


class SQSValidationError(ValueError, SQSException):
    """Raised when request parameters are invalid before calling AWS."""


class SQSBatchOperationError(SQSException):
    """Raised when a batch operation reports failed items."""

    def __init__(
        self,
        operation: str,
        failed: list[dict[str, object]],
    ) -> None:
        self.operation = operation
        self.failed = failed
        super().__init__(f"{operation} failed for {len(failed)} batch entries")
