import hashlib

import orjson
from collections.abc import Iterator
from typing import Optional
from urllib.parse import urlparse

from chainsaws.aws.shared import session
from chainsaws.aws.sqs._sqs_internal import SQS
from chainsaws.aws.sqs.request.MessageRequest import (
    DeleteMessageBatchRequestEntry,
    MessageAttributes,
    ReceiveMessageAttributeNames,
    MessageSystemAttributes,
    ReceiveMessageMessageSystemAttributeNames,
    SendMessageBatchRequestEntry,
)
from chainsaws.aws.sqs.response.MessageResponse import (
    DeleteMessageBatchResponse,
    ReceiveMessageResponse,
    ReceiveMessageResponseMessage,
    SendMessageBatchResponse,
    SendMessageResponse,
)
from chainsaws.aws.sqs.sqs_config import (
    _ATTRIBUTE_DATA_TYPE_PATTERN,
    _ATTRIBUTE_NAME_PATTERN,
    _DELETE_BATCH_ALLOWED_KEYS,
    _DEFAULT_FIFO_MESSAGE_GROUP_ID,
    _ENTRY_ID_PATTERN,
    _MAX_BATCH_SIZE,
    _MAX_DELAY_SECONDS,
    _MAX_FIFO_ID_BYTES,
    _MAX_MESSAGE_ATTRIBUTES_COUNT,
    _MAX_MESSAGE_BODY_BYTES,
    _MAX_VISIBILITY_TIMEOUT_SECONDS,
    _MAX_WAIT_TIME_SECONDS,
    _RECEIVE_ATTRIBUTE_WILDCARD_PATTERN,
    _RECEIVE_SYSTEM_ATTRIBUTE_KEYS,
    _SEND_BATCH_ALLOWED_KEYS,
    _SYSTEM_ATTRIBUTE_KEYS,
)
from chainsaws.aws.sqs.sqs_exception import SQSBatchOperationError, SQSValidationError
from chainsaws.aws.sqs.sqs_models import JSONValue, SQSAPIConfig


def _is_fifo_queue(queue_url: str) -> bool:
    return queue_url.rstrip("/").endswith(".fifo")


def _validate_queue_url(queue_url: str) -> None:
    parsed = urlparse(queue_url)
    if parsed.scheme not in {"https", "http"} or not parsed.netloc or not parsed.path.strip("/"):
        raise SQSValidationError("queue_url must be a valid SQS queue URL")


def _ensure_optional_range(name: str, value: Optional[int], minimum: int, maximum: int) -> None:
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, int):
        raise SQSValidationError(f"{name} must be an integer between {minimum} and {maximum}")
    if not minimum <= value <= maximum:
        raise SQSValidationError(f"{name} must be between {minimum} and {maximum}")


def _validate_batch_size(name: str, size: int) -> None:
    if size < 1:
        raise SQSValidationError(f"{name} must contain at least one entry")
    if size > _MAX_BATCH_SIZE:
        raise SQSValidationError(f"{name} can contain at most {_MAX_BATCH_SIZE} entries")


def _validate_entry_id(entry_id: str) -> None:
    if not isinstance(entry_id, str):
        raise SQSValidationError("entry Id must be a string")
    if _ENTRY_ID_PATTERN.match(entry_id) is None:
        raise SQSValidationError(
            "entry Id must be 1-80 chars of alphanumeric, '-' or '_'",
        )


def _validate_message_body_size(message_body: str) -> None:
    if not isinstance(message_body, str):
        raise SQSValidationError("message body must be a string")
    message_body_size = len(message_body.encode("utf-8"))
    if message_body_size == 0:
        raise SQSValidationError("message body must not be empty")
    if message_body_size > _MAX_MESSAGE_BODY_BYTES:
        raise SQSValidationError(
            f"message body must be <= {_MAX_MESSAGE_BODY_BYTES} bytes",
        )


def _validate_unique_entry_ids(
    entries: list[SendMessageBatchRequestEntry | DeleteMessageBatchRequestEntry],
) -> None:
    ids = [entry["Id"] for entry in entries]
    if len(ids) != len(set(ids)):
        raise SQSValidationError("batch entry Id values must be unique")


def _serialize_message_body(
    message_body: str | dict[str, JSONValue] | list[JSONValue],
) -> str:
    if isinstance(message_body, (dict, list)):
        return orjson.dumps(message_body).decode("utf-8")
    return message_body


def _raise_for_failed_batch_entries(
    operation: str,
    response: SendMessageBatchResponse | DeleteMessageBatchResponse,
    strict: bool,
) -> None:
    if not strict:
        return

    failed_entries = response.get("Failed", [])
    if failed_entries:
        raise SQSBatchOperationError(operation=operation, failed=[dict(entry) for entry in failed_entries])


def _validate_message_attributes(
    attributes: MessageAttributes | MessageSystemAttributes | None,
    *,
    field_name: str,
    is_system_attributes: bool = False,
) -> None:
    if attributes is None:
        return

    if len(attributes) > _MAX_MESSAGE_ATTRIBUTES_COUNT:
        raise SQSValidationError(
            f"{field_name} can contain at most {_MAX_MESSAGE_ATTRIBUTES_COUNT} entries",
        )

    for key, value in attributes.items():
        if not isinstance(key, str) or not key.strip():
            raise SQSValidationError(f"{field_name} key must not be empty")
        if is_system_attributes and key not in _SYSTEM_ATTRIBUTE_KEYS:
            raise SQSValidationError(f"{field_name} only supports AWSTraceHeader")
        if (
            not is_system_attributes
            and (
                _ATTRIBUTE_NAME_PATTERN.match(key) is None
                or key.lower().startswith("aws.")
                or key.lower().startswith("amazon.")
            )
        ):
            raise SQSValidationError(
                f"{field_name}.{key} is not a valid message attribute name",
            )
        if not isinstance(value, dict):
            raise SQSValidationError(f"{field_name}.{key} must be an attribute dictionary")

        data_type = value.get("DataType")
        if not isinstance(data_type, str):
            raise SQSValidationError(f"{field_name}.{key}.DataType must be a string")
        if _ATTRIBUTE_DATA_TYPE_PATTERN.match(data_type) is None:
            raise SQSValidationError(
                f"{field_name}.{key}.DataType must start with String, Number, or Binary",
            )
        base_data_type = data_type.split(".", 1)[0]
        string_value = value.get("StringValue")
        binary_value = value.get("BinaryValue")

        if base_data_type in {"String", "Number"} and "StringValue" not in value:
            raise SQSValidationError(
                f"{field_name}.{key}.StringValue is required for DataType={data_type}",
            )
        if base_data_type in {"String", "Number"} and not isinstance(string_value, str):
            raise SQSValidationError(f"{field_name}.{key}.StringValue must be a string")
        if base_data_type in {"String", "Number"} and "BinaryValue" in value:
            raise SQSValidationError(
                f"{field_name}.{key}.BinaryValue is not valid for DataType={data_type}",
            )
        if is_system_attributes and base_data_type != "String":
            raise SQSValidationError(
                f"{field_name}.{key}.DataType must be String",
            )

        if base_data_type == "Binary" and "BinaryValue" not in value:
            raise SQSValidationError(
                f"{field_name}.{key}.BinaryValue is required for DataType=Binary",
            )
        if base_data_type == "Binary" and not isinstance(binary_value, (bytes, bytearray)):
            raise SQSValidationError(f"{field_name}.{key}.BinaryValue must be bytes-like")
        if base_data_type == "Binary" and "StringValue" in value:
            raise SQSValidationError(
                f"{field_name}.{key}.StringValue is not valid for DataType={data_type}",
            )
        if "StringListValues" in value:
            raise SQSValidationError(
                f"{field_name}.{key}.StringListValues is not supported by SQS",
            )
        if "BinaryListValues" in value:
            raise SQSValidationError(
                f"{field_name}.{key}.BinaryListValues is not supported by SQS",
            )


def _validate_fifo_identifier(name: str, value: str | None) -> None:
    if value is None:
        return
    if not isinstance(value, str):
        raise SQSValidationError(f"{name} must be a string")
    identifier_size = len(value.encode("utf-8"))
    if identifier_size == 0:
        raise SQSValidationError(f"{name} must not be empty")
    if identifier_size > _MAX_FIFO_ID_BYTES:
        raise SQSValidationError(f"{name} must be <= {_MAX_FIFO_ID_BYTES} bytes")


def _validate_entry_keys(
    entry: SendMessageBatchRequestEntry | DeleteMessageBatchRequestEntry,
    *,
    allowed_keys: frozenset[str],
    entry_kind: str,
) -> None:
    unknown_keys = set(entry.keys()) - allowed_keys
    if unknown_keys:
        unknown = ", ".join(sorted(unknown_keys))
        raise SQSValidationError(f"{entry_kind} has unsupported keys: {unknown}")


def _validate_receive_message_attribute_names(
    names: ReceiveMessageAttributeNames | None,
) -> None:
    if names is None:
        return
    if len(names) > _MAX_MESSAGE_ATTRIBUTES_COUNT:
        raise SQSValidationError(
            f"message_attributes_names can contain at most {_MAX_MESSAGE_ATTRIBUTES_COUNT} entries",
        )
    seen_names: set[str] = set()
    for name in names:
        if not isinstance(name, str) or not name.strip():
            raise SQSValidationError("message_attributes_names entries must be non-empty strings")
        if name in seen_names:
            raise SQSValidationError("message_attributes_names must not contain duplicates")
        seen_names.add(name)
        if name == "All":
            continue
        if name == ".*":
            continue
        if _RECEIVE_ATTRIBUTE_WILDCARD_PATTERN.match(name) is not None:
            continue
        if (
            _ATTRIBUTE_NAME_PATTERN.match(name) is None
            or name.lower().startswith("aws.")
            or name.lower().startswith("amazon.")
        ):
            raise SQSValidationError(
                f"message_attributes_names entry '{name}' is invalid",
            )


def _validate_receive_message_system_attribute_names(
    names: ReceiveMessageMessageSystemAttributeNames | None,
) -> None:
    if names is None:
        return
    if len(names) > _MAX_MESSAGE_ATTRIBUTES_COUNT:
        raise SQSValidationError(
            f"message_system_attributes_names can contain at most {_MAX_MESSAGE_ATTRIBUTES_COUNT} entries",
        )
    seen_names: set[str] = set()
    for name in names:
        if name in seen_names:
            raise SQSValidationError("message_system_attributes_names must not contain duplicates")
        seen_names.add(name)
        if name not in _RECEIVE_SYSTEM_ATTRIBUTE_KEYS:
            raise SQSValidationError(
                f"message_system_attributes_names contains unsupported key '{name}'",
            )


class SQSAPI:
    """SQS high-level client."""

    def __init__(
        self,
        queue_url: str,
        config: Optional[SQSAPIConfig] = None,
    ) -> None:
        """Initialize SQS client.

        Args:
            queue_url: The URL of the Amazon SQS queue
            config: Optional SQS configuration

        """
        if not queue_url.strip():
            raise SQSValidationError("queue_url must not be empty")
        _validate_queue_url(queue_url)

        self.config = config or SQSAPIConfig()
        self.queue_url = queue_url
        self.boto3_session = session.get_boto_session(
            self.config.credentials if self.config.credentials else None,
        )
        self._sqs = SQS(
            boto3_session=self.boto3_session,
            config=self.config,
        )

    def send_message(
        self,
        message_body: str | dict[str, JSONValue] | list[JSONValue],
        delay_seconds: Optional[int] = None,
        message_attributes: Optional[MessageAttributes] = None,
        message_system_attributes: Optional[MessageSystemAttributes] = None,
        message_deduplication_id: Optional[str] = None,
        message_group_id: Optional[str] = None,
    ) -> SendMessageResponse:
        """Send a single message to the queue."""
        _ensure_optional_range("delay_seconds", delay_seconds, 0, _MAX_DELAY_SECONDS)
        _validate_message_attributes(message_attributes, field_name="message_attributes")
        _validate_message_attributes(
            message_system_attributes,
            field_name="message_system_attributes",
            is_system_attributes=True,
        )

        serialized_body = _serialize_message_body(message_body)
        _validate_message_body_size(serialized_body)

        fifo_queue = _is_fifo_queue(self.queue_url)

        if fifo_queue:
            if delay_seconds is not None:
                raise SQSValidationError("delay_seconds is not supported for FIFO queues")
            if message_group_id is None:
                message_group_id = _DEFAULT_FIFO_MESSAGE_GROUP_ID
            _validate_fifo_identifier("message_group_id", message_group_id)
            _validate_fifo_identifier(
                "message_deduplication_id",
                message_deduplication_id,
            )
            if message_deduplication_id is None:
                message_deduplication_id = hashlib.md5(serialized_body.encode("utf-8")).hexdigest()
        elif message_group_id is not None or message_deduplication_id is not None:
            raise SQSValidationError(
                "message_group_id/message_deduplication_id are only valid for FIFO queues",
            )

        return self._sqs.send_message(
            queue_url=self.queue_url,
            message_body=serialized_body,
            delay_seconds=delay_seconds,
            message_attributes=message_attributes,
            message_system_attributes=message_system_attributes,
            message_deduplication_id=message_deduplication_id,
            message_group_id=message_group_id,
        )

    def send_message_batch(
        self,
        entries: list[SendMessageBatchRequestEntry],
        *,
        strict: bool = False,
    ) -> SendMessageBatchResponse:
        """Send multiple messages in a single request."""
        _validate_batch_size("entries", len(entries))
        _validate_unique_entry_ids(entries)

        fifo_queue = _is_fifo_queue(self.queue_url)
        normalized_entries: list[SendMessageBatchRequestEntry] = []

        for entry in entries:
            _validate_entry_keys(
                entry,
                allowed_keys=_SEND_BATCH_ALLOWED_KEYS,
                entry_kind="send_message_batch entry",
            )
            entry_id = entry["Id"]
            message_body = entry["MessageBody"]
            _validate_entry_id(entry_id)
            _validate_message_body_size(message_body)

            delay_seconds = entry.get("DelaySeconds")
            _ensure_optional_range("DelaySeconds", delay_seconds, 0, _MAX_DELAY_SECONDS)

            normalized_entry: SendMessageBatchRequestEntry = {
                "Id": entry_id,
                "MessageBody": message_body,
            }

            if "MessageAttributes" in entry:
                _validate_message_attributes(
                    entry["MessageAttributes"],
                    field_name=f"entries[{entry_id}].MessageAttributes",
                )
                normalized_entry["MessageAttributes"] = entry["MessageAttributes"]
            if "MessageSystemAttributes" in entry:
                _validate_message_attributes(
                    entry["MessageSystemAttributes"],
                    field_name=f"entries[{entry_id}].MessageSystemAttributes",
                    is_system_attributes=True,
                )
                normalized_entry["MessageSystemAttributes"] = entry["MessageSystemAttributes"]

            if fifo_queue:
                if delay_seconds is not None:
                    raise SQSValidationError("DelaySeconds is not supported for FIFO queues")
                message_group_id = entry.get("MessageGroupId", _DEFAULT_FIFO_MESSAGE_GROUP_ID)
                message_deduplication_id = entry.get("MessageDeduplicationId")
                _validate_fifo_identifier("MessageGroupId", message_group_id)
                _validate_fifo_identifier("MessageDeduplicationId", message_deduplication_id)
                normalized_entry["MessageGroupId"] = message_group_id
                normalized_entry["MessageDeduplicationId"] = (
                    message_deduplication_id
                    if message_deduplication_id is not None
                    else hashlib.md5(message_body.encode("utf-8")).hexdigest()
                )
            else:
                if "MessageGroupId" in entry or "MessageDeduplicationId" in entry:
                    raise SQSValidationError(
                        "MessageGroupId/MessageDeduplicationId are only valid for FIFO queues",
                    )
                if delay_seconds is not None:
                    normalized_entry["DelaySeconds"] = delay_seconds

            normalized_entries.append(normalized_entry)

        response = self._sqs.send_message_batch(self.queue_url, normalized_entries)
        _raise_for_failed_batch_entries("send_message_batch", response, strict)
        return response

    def receive_messages(
        self,
        message_attributes_names: Optional[ReceiveMessageAttributeNames] = None,
        message_system_attributes_names: Optional[ReceiveMessageMessageSystemAttributeNames] = None,
        max_number_of_messages: Optional[int] = None,
        visibility_timeout: Optional[int] = None,
        wait_time_seconds: Optional[int] = None,
        receive_request_attempt_id: Optional[str] = None,
    ) -> ReceiveMessageResponse:
        """Receive messages from the queue."""
        _validate_receive_message_attribute_names(message_attributes_names)
        _validate_receive_message_system_attribute_names(message_system_attributes_names)
        _ensure_optional_range("max_number_of_messages", max_number_of_messages, 1, _MAX_BATCH_SIZE)
        _ensure_optional_range(
            "visibility_timeout",
            visibility_timeout,
            0,
            _MAX_VISIBILITY_TIMEOUT_SECONDS,
        )
        _ensure_optional_range("wait_time_seconds", wait_time_seconds, 0, _MAX_WAIT_TIME_SECONDS)

        if receive_request_attempt_id is not None and not _is_fifo_queue(self.queue_url):
            raise SQSValidationError("receive_request_attempt_id is only valid for FIFO queues")
        _validate_fifo_identifier("receive_request_attempt_id", receive_request_attempt_id)

        return self._sqs.receive_message(
            queue_url=self.queue_url,
            message_attributes_names=message_attributes_names,
            message_system_attributes_names=message_system_attributes_names,
            max_number_of_messages=max_number_of_messages,
            visibility_timeout=visibility_timeout,
            wait_time_seconds=wait_time_seconds,
            receive_request_attempt_id=receive_request_attempt_id,
        )

    def send_messages(
        self,
        messages: list[str | dict[str, JSONValue] | list[JSONValue]],
        *,
        delay_seconds: Optional[int] = None,
        fifo: bool = False,
        message_group_id: Optional[str] = None,
        strict: bool = False,
    ) -> SendMessageBatchResponse:
        _validate_batch_size("messages", len(messages))
        _ensure_optional_range("delay_seconds", delay_seconds, 0, _MAX_DELAY_SECONDS)

        queue_is_fifo = _is_fifo_queue(self.queue_url)
        if fifo and not queue_is_fifo:
            raise SQSValidationError("fifo=True is only valid for FIFO queues")

        fifo_queue = fifo or queue_is_fifo
        if fifo_queue and delay_seconds is not None:
            raise SQSValidationError("delay_seconds is not supported for FIFO queues")
        if not fifo_queue and message_group_id is not None:
            raise SQSValidationError("message_group_id is only valid for FIFO queues")
        _validate_fifo_identifier("message_group_id", message_group_id)

        entries: list[SendMessageBatchRequestEntry] = []
        for idx, body in enumerate(messages, start=1):
            serialized_body = _serialize_message_body(body)
            _validate_message_body_size(serialized_body)

            entry: SendMessageBatchRequestEntry = {
                "Id": str(idx),
                "MessageBody": serialized_body,
            }

            if delay_seconds is not None:
                entry["DelaySeconds"] = delay_seconds

            if fifo_queue:
                gid = message_group_id or _DEFAULT_FIFO_MESSAGE_GROUP_ID
                entry["MessageGroupId"] = gid
                entry["MessageDeduplicationId"] = hashlib.md5(serialized_body.encode("utf-8")).hexdigest()

            entries.append(entry)

        response = self._sqs.send_message_batch(self.queue_url, entries)
        _raise_for_failed_batch_entries("send_messages", response, strict)
        return response

    def delete_messages(
        self,
        receipt_handles: list[str],
        *,
        strict: bool = False,
    ) -> DeleteMessageBatchResponse:
        _validate_batch_size("receipt_handles", len(receipt_handles))
        entries: list[DeleteMessageBatchRequestEntry] = []

        for idx, receipt_handle in enumerate(receipt_handles, start=1):
            if not receipt_handle.strip():
                raise SQSValidationError("receipt handle must not be empty")
            entries.append({"Id": str(idx), "ReceiptHandle": receipt_handle})

        response = self._sqs.delete_message_batch(self.queue_url, entries)
        _raise_for_failed_batch_entries("delete_messages", response, strict)
        return response

    def iter_messages(
        self,
        *,
        max_number_of_messages: int = 10,
        visibility_timeout: Optional[int] = None,
        wait_time_seconds: int = 20,
        auto_delete: bool = False,
        auto_delete_strict: bool = False,
        stop_after: Optional[int] = None,
    ) -> Iterator[ReceiveMessageResponseMessage]:
        _ensure_optional_range("max_number_of_messages", max_number_of_messages, 1, _MAX_BATCH_SIZE)
        _ensure_optional_range(
            "visibility_timeout",
            visibility_timeout,
            0,
            _MAX_VISIBILITY_TIMEOUT_SECONDS,
        )
        _ensure_optional_range("wait_time_seconds", wait_time_seconds, 0, _MAX_WAIT_TIME_SECONDS)
        if stop_after is not None and stop_after < 1:
            raise SQSValidationError("stop_after must be greater than 0")

        yielded = 0
        pending_receipt_handles: list[str] = []

        def _flush_pending_receipts() -> None:
            nonlocal pending_receipt_handles
            if not pending_receipt_handles:
                return
            self.delete_messages(pending_receipt_handles, strict=auto_delete_strict)
            pending_receipt_handles = []

        try:
            while True:
                resp = self.receive_messages(
                    max_number_of_messages=max_number_of_messages,
                    visibility_timeout=visibility_timeout,
                    wait_time_seconds=wait_time_seconds,
                )
                messages = resp.get("Messages", [])
                if not messages:
                    break

                for msg in messages:
                    yield msg
                    if auto_delete:
                        receipt_handle = msg.get("ReceiptHandle")
                        if receipt_handle is not None:
                            pending_receipt_handles.append(receipt_handle)

                    yielded += 1
                    if stop_after is not None and yielded >= stop_after:
                        _flush_pending_receipts()
                        return

                if auto_delete:
                    _flush_pending_receipts()
        finally:
            if auto_delete:
                _flush_pending_receipts()

    def delete_message(self, receipt_handle: str) -> None:
        """Delete a message from the queue."""
        if not receipt_handle.strip():
            raise SQSValidationError("receipt handle must not be empty")
        self._sqs.delete_message(
            queue_url=self.queue_url,
            receipt_handle=receipt_handle,
        )

    def delete_message_batch(
        self,
        entries: list[DeleteMessageBatchRequestEntry],
        *,
        strict: bool = False,
    ) -> DeleteMessageBatchResponse:
        """Delete multiple messages in a single request."""
        _validate_batch_size("entries", len(entries))
        _validate_unique_entry_ids(entries)

        for entry in entries:
            _validate_entry_keys(
                entry,
                allowed_keys=_DELETE_BATCH_ALLOWED_KEYS,
                entry_kind="delete_message_batch entry",
            )
            _validate_entry_id(entry["Id"])
            if not entry["ReceiptHandle"].strip():
                raise SQSValidationError("receipt handle must not be empty")

        response = self._sqs.delete_message_batch(
            queue_url=self.queue_url,
            entries=entries,
        )
        _raise_for_failed_batch_entries("delete_message_batch", response, strict)
        return response

    def purge_queue(self) -> None:
        """Delete all messages from the queue."""
        self._sqs.purge_queue(self.queue_url)
