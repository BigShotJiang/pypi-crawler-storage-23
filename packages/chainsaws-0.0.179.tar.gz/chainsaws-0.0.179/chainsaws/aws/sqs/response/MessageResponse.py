from typing import TypedDict

from chainsaws.aws.sqs.sqs_models import MessageAttributesValue, SQSResponseMetadata


class MessageResponse(TypedDict, total=False):
    MD5OfMessageBody: str
    MD5OfMessageAttributes: str
    MD5OfMessageSystemAttributes: str
    MessageId: str
    SequenceNumber: str
    ResponseMetadata: SQSResponseMetadata


SendMessageResponse = MessageResponse


class SendMessageBatchResultSuccessEntry(MessageResponse):
    Id: str


class SendMessageBatchResultErrorEntry(TypedDict):
    Id: str
    Code: str
    Message: str
    SenderFault: bool


class SendMessageBatchResponse(TypedDict, total=False):
    Successful: list[SendMessageBatchResultSuccessEntry]
    Failed: list[SendMessageBatchResultErrorEntry]
    ResponseMetadata: SQSResponseMetadata


class ReceiveMessageResponseMessage(MessageResponse):
    ReceiptHandle: str
    MD5OfBody: str
    Body: str
    Attributes: dict[str, str]
    MD5OfMessageAttributes: str
    MessageAttributes: dict[str, MessageAttributesValue]


class ReceiveMessageResponse(TypedDict, total=False):
    Messages: list[ReceiveMessageResponseMessage]
    ResponseMetadata: SQSResponseMetadata


class DeleteMessageBatchSuccessResponseEntry(TypedDict):
    Id: str


class DeleteMessageBatchFailedResponseEntry(TypedDict):
    Id: str
    Code: str
    Message: str
    SenderFault: bool


class DeleteMessageBatchResponse(TypedDict, total=False):
    Successful: list[DeleteMessageBatchSuccessResponseEntry]
    Failed: list[DeleteMessageBatchFailedResponseEntry]
    ResponseMetadata: SQSResponseMetadata
