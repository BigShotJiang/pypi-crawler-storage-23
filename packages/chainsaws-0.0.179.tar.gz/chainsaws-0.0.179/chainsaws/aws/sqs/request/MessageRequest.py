from typing import Literal, NotRequired, Required, TypeAlias, TypedDict

from chainsaws.aws.sqs.sqs_models import MessageAttributesValue, MessageSystemAttributeValue

MessageAttributes = dict[str, MessageAttributesValue]
MessageSystemAttributeKey = Literal["AWSTraceHeader"]
MessageSystemAttributes = dict[MessageSystemAttributeKey, MessageSystemAttributeValue]


class SendMessageBatchRequestEntry(TypedDict):
    Id: Required[str]
    MessageBody: Required[str]
    DelaySeconds: NotRequired[int]
    MessageAttributes: NotRequired[MessageAttributes]
    MessageSystemAttributes: NotRequired[MessageSystemAttributes]
    MessageDeduplicationId: NotRequired[str]
    MessageGroupId: NotRequired[str]


ReceiveMessageMessageSystemAttributeName = Literal[
    "All",
    "SenderId",
    "SentTimestamp",
    "ApproximateReceiveCount",
    "ApproximateFirstReceiveTimestamp",
    "SequenceNumber",
    "MessageDeduplicationId",
    "MessageGroupId",
    "AWSTraceHeader",
    "DeadLetterQueueSourceArn",
]
ReceiveMessageMessageSystemAttributeNames = list[ReceiveMessageMessageSystemAttributeName]

ReceiveMessageAttributeSpecialName = Literal["All", ".*"]
ReceiveMessageAttributeName: TypeAlias = ReceiveMessageAttributeSpecialName | str
ReceiveMessageAttributeNames = list[ReceiveMessageAttributeName]


class DeleteMessageBatchRequestEntry(TypedDict):
    Id: Required[str]
    ReceiptHandle: Required[str]
