from __future__ import annotations

import re

from chainsaws.aws.sqs.sqs_models import SQSAPIConfig


_MAX_BATCH_SIZE = 10
_MAX_DELAY_SECONDS = 900
_MAX_MESSAGE_BODY_BYTES = 262_144
_MAX_VISIBILITY_TIMEOUT_SECONDS = 43_200
_MAX_WAIT_TIME_SECONDS = 20
_MAX_FIFO_ID_BYTES = 128
_MAX_MESSAGE_ATTRIBUTES_COUNT = 10
_DEFAULT_FIFO_MESSAGE_GROUP_ID = "default"

_ENTRY_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
_ATTRIBUTE_DATA_TYPE_PATTERN = re.compile(r"^(String|Number|Binary)(\..+)?$")
_ATTRIBUTE_NAME_PATTERN = re.compile(r"^(?![.])(?!.*[.]{2})[A-Za-z0-9_.-]{1,256}(?<![.])$")
_RECEIVE_ATTRIBUTE_WILDCARD_PATTERN = re.compile(r"^(?!aws\.)(?!amazon\.)[A-Za-z0-9_.-]{1,254}\.\*$", re.IGNORECASE)

_SEND_BATCH_ALLOWED_KEYS = frozenset(
    {
        "Id",
        "MessageBody",
        "DelaySeconds",
        "MessageAttributes",
        "MessageSystemAttributes",
        "MessageDeduplicationId",
        "MessageGroupId",
    },
)
_DELETE_BATCH_ALLOWED_KEYS = frozenset({"Id", "ReceiptHandle"})
_SYSTEM_ATTRIBUTE_KEYS = frozenset({"AWSTraceHeader"})
_RECEIVE_SYSTEM_ATTRIBUTE_KEYS = frozenset(
    {
        "All",
        "SenderId",
        "SentTimestamp",
        "ApproximateReceiveCount",
        "ApproximateFirstReceiveTimestamp",
        "SequenceNumber",
        "MessageDeduplicationId",
        "MessageGroupId",
        "AWSTraceHeader",
        "DeadLetterQueueSourceArn",
    },
)


__all__ = [
    "SQSAPIConfig",
    "_MAX_BATCH_SIZE",
    "_MAX_DELAY_SECONDS",
    "_MAX_MESSAGE_BODY_BYTES",
    "_MAX_VISIBILITY_TIMEOUT_SECONDS",
    "_MAX_WAIT_TIME_SECONDS",
    "_MAX_FIFO_ID_BYTES",
    "_MAX_MESSAGE_ATTRIBUTES_COUNT",
    "_DEFAULT_FIFO_MESSAGE_GROUP_ID",
    "_ENTRY_ID_PATTERN",
    "_ATTRIBUTE_DATA_TYPE_PATTERN",
    "_ATTRIBUTE_NAME_PATTERN",
    "_RECEIVE_ATTRIBUTE_WILDCARD_PATTERN",
    "_SEND_BATCH_ALLOWED_KEYS",
    "_DELETE_BATCH_ALLOWED_KEYS",
    "_SYSTEM_ATTRIBUTE_KEYS",
    "_RECEIVE_SYSTEM_ATTRIBUTE_KEYS",
]
