from __future__ import annotations

from typing import Literal, NotRequired, TypeAlias, TypedDict

from chainsaws.aws.shared.config import APIConfig


class SQSAPIConfig(APIConfig):
    pass


JSONPrimitive: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]


class MessageAttributesValue(TypedDict):
    DataType: Literal["String", "Number", "Binary"]
    StringValue: NotRequired[str]
    BinaryValue: NotRequired[bytes]
    StringListValues: NotRequired[list[str]]
    BinaryListValues: NotRequired[list[bytes]]


class MessageSystemAttributeValue(TypedDict):
    DataType: Literal["String"]
    StringValue: str


class SQSResponseMetadata(TypedDict, total=False):
    RequestId: str
    HTTPStatusCode: int
    RetryAttempts: int
    HostId: str


__all__ = [
    "SQSAPIConfig",
    "JSONPrimitive",
    "JSONValue",
    "MessageAttributesValue",
    "MessageSystemAttributeValue",
    "SQSResponseMetadata",
]
