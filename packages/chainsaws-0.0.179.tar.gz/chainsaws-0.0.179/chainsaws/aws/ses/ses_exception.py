"""SES domain exceptions."""


class SESException(Exception):
    """Base exception for SES API operations."""


class SESValidationError(SESException):
    """Raised when SES input validation fails."""


class SESBatchError(SESException):
    """Raised for strict bulk-send failures."""


class SESThrottlingError(SESException):
    """Raised for SES throttling/rate-limit errors."""


class SESMessageRejectedError(SESException):
    """Raised when SES rejects a message payload or recipient policy."""


class SESNotFoundError(SESException):
    """Raised when an SES resource is not found."""


class SESTemplateNotFoundError(SESNotFoundError):
    """Raised when an SES template is not found."""


class SESIdentityNotFoundError(SESNotFoundError):
    """Raised when an SES identity is not found."""


class SESAlreadyExistsError(SESException):
    """Raised when creating a resource that already exists."""


class SESLimitExceededError(SESException):
    """Raised when an SES operation exceeds service/account limits."""


# Backward compatibility alias.
SESError = SESException
