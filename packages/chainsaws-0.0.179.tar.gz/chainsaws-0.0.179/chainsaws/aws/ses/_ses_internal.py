"""Internal implementation of AWS SES client using SESv2 APIs."""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from typing import NoReturn, cast

import boto3
from botocore.exceptions import ClientError

from chainsaws.aws.ses.response import (
    GetSendQuotaResponse,
    ListTemplatesResponse,
    SendEmailResponse,
    SendTemplatedEmailResponse,
    TemplateMetadata,
)
from chainsaws.aws.ses.ses_exception import (
    SESAlreadyExistsError,
    SESException,
    SESIdentityNotFoundError,
    SESLimitExceededError,
    SESMessageRejectedError,
    SESNotFoundError,
    SESTemplateNotFoundError,
    SESThrottlingError,
)
from chainsaws.aws.ses.ses_models import (
    BulkEmailConfig,
    BulkEmailResult,
    EmailAddress,
    EmailContent,
    EmailIdentityDetails,
    ListManagementOptions,
    SESAPIConfig,
    SESIdentityType,
    SuppressedDestinationSummary,
    SuppressionReason,
    SendEmailConfig,
    SendRawEmailConfig,
    SendTemplateConfig,
    TemplateContent,
)

logger = logging.getLogger(__name__)

_MAX_RETRY_ATTEMPTS = 3
_RETRY_BASE_DELAY_SECONDS = 0.2
_MAX_BULK_EMAIL_ENTRIES = 50
_RETRYABLE_ERROR_CODES = frozenset(
    {
        "Throttled",
        "Throttling",
        "ThrottlingException",
        "TooManyRequestsException",
        "InternalError",
        "InternalFailure",
        "ServiceUnavailable",
        "ServiceUnavailableException",
        "RequestTimeout",
        "RequestTimeoutException",
    },
)

RequestMap = dict[str, object]
ResponseMap = dict[str, object]


def _is_retryable_client_error(error: ClientError) -> bool:
    code = str(error.response.get("Error", {}).get("Code", ""))
    return code in _RETRYABLE_ERROR_CODES


def _stringify_addresses(addresses: list[EmailAddress] | None) -> list[str]:
    if addresses is None:
        return []
    return [str(address) for address in addresses]


def _build_destination(
    recipients: list[EmailAddress],
    cc: list[EmailAddress] | None,
    bcc: list[EmailAddress] | None,
) -> RequestMap:
    destination: RequestMap = {"ToAddresses": _stringify_addresses(recipients)}
    cc_addresses = _stringify_addresses(cc)
    bcc_addresses = _stringify_addresses(bcc)
    if cc_addresses:
        destination["CcAddresses"] = cc_addresses
    if bcc_addresses:
        destination["BccAddresses"] = bcc_addresses
    return destination


def _build_simple_content(content: EmailContent) -> RequestMap:
    body: RequestMap = {}
    charset = content.get("charset") or "UTF-8"

    body_text = content.get("body_text")
    if body_text:
        body["Text"] = {
            "Data": body_text,
            "Charset": charset,
        }

    body_html = content.get("body_html")
    if body_html:
        body["Html"] = {
            "Data": body_html,
            "Charset": charset,
        }

    return {
        "Subject": {
            "Data": content["subject"],
            "Charset": charset,
        },
        "Body": body,
    }


def _build_template_content(content: TemplateContent | EmailContent) -> RequestMap:
    template: RequestMap = {"Subject": content["subject"]}

    text = content.get("text") if "text" in content else content.get("body_text")
    html = content.get("html") if "html" in content else content.get("body_html")

    if isinstance(text, str) and text != "":
        template["Text"] = text
    if isinstance(html, str) and html != "":
        template["Html"] = html

    return template


def _to_email_tags(tags: dict[str, str] | None) -> list[RequestMap]:
    if not tags:
        return []
    return [{"Name": key, "Value": value} for key, value in tags.items()]


def _to_list_management_options(
    options: ListManagementOptions | None,
) -> RequestMap | None:
    if options is None:
        return None

    payload: RequestMap = {"ContactListName": options["contact_list_name"]}
    topic_name = options.get("topic_name")
    if topic_name:
        payload["TopicName"] = topic_name
    return payload


def _to_float(value: object, field_name: str) -> float:
    if isinstance(value, bool):
        msg = f"Invalid numeric value for {field_name}: {value!r}"
        raise SESException(msg)
    if isinstance(value, int | float):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError as error:
            msg = f"Invalid numeric value for {field_name}: {value!r}"
            raise SESException(msg) from error

    msg = f"Invalid numeric value type for {field_name}: {type(value).__name__}"
    raise SESException(msg)


def _error_message(error: ClientError, operation: str) -> str:
    code = str(error.response.get("Error", {}).get("Code", "Unknown"))
    message = str(error.response.get("Error", {}).get("Message", ""))
    return f"SES {operation} failed ({code}): {message}" if message else f"SES {operation} failed ({code})"


def _raise_mapped_client_error(
    *,
    operation: str,
    error: ClientError,
    resource_type: str | None = None,
) -> NoReturn:
    code = str(error.response.get("Error", {}).get("Code", ""))
    message = _error_message(error, operation)

    if code in _RETRYABLE_ERROR_CODES:
        raise SESThrottlingError(message) from error
    if code in {"MessageRejected", "MailFromDomainNotVerifiedException"}:
        raise SESMessageRejectedError(message) from error
    if code in {"AlreadyExistsException"}:
        raise SESAlreadyExistsError(message) from error
    if code in {"LimitExceededException", "AccountSuspendedException"}:
        raise SESLimitExceededError(message) from error
    if code in {"NotFoundException", "TemplateDoesNotExist", "ResourceNotFoundException"}:
        if resource_type == "template":
            raise SESTemplateNotFoundError(message) from error
        if resource_type == "identity":
            raise SESIdentityNotFoundError(message) from error
        raise SESNotFoundError(message) from error

    raise SESException(message) from error


def _chunk_recipients(
    recipients: list[object],
    chunk_size: int,
) -> list[list[object]]:
    return [
        recipients[index:index + chunk_size]
        for index in range(0, len(recipients), chunk_size)
    ]


class SES:
    """Low-level SES client wrapper."""

    def __init__(
        self,
        boto3_session: boto3.Session,
        config: SESAPIConfig | None = None,
    ) -> None:
        self.config = config or SESAPIConfig()
        self.client = boto3_session.client(
            "sesv2",
            region_name=self.config.region,
        )

    def _call_with_retries(self, method_name: str, **kwargs: object) -> ResponseMap:
        method = getattr(self.client, method_name)
        last_error: ClientError | None = None

        for attempt in range(_MAX_RETRY_ATTEMPTS):
            try:
                return cast(ResponseMap, method(**kwargs))
            except ClientError as error:
                last_error = error
                if not _is_retryable_client_error(error):
                    raise
                if attempt == _MAX_RETRY_ATTEMPTS - 1:
                    break
                time.sleep(_RETRY_BASE_DELAY_SECONDS * (2**attempt))

        assert last_error is not None
        raise last_error

    def send_email(self, config: SendEmailConfig) -> SendEmailResponse:
        try:
            request: RequestMap = {
                "FromEmailAddress": str(config["sender"]),
                "Destination": _build_destination(
                    recipients=config["recipients"],
                    cc=config.get("cc"),
                    bcc=config.get("bcc"),
                ),
                "Content": {
                    "Simple": _build_simple_content(config["content"]),
                },
            }

            reply_to = _stringify_addresses(config.get("reply_to"))
            if reply_to:
                request["ReplyToAddresses"] = reply_to

            email_tags = _to_email_tags(config.get("tags"))
            if email_tags:
                request["EmailTags"] = email_tags
            if config.get("configuration_set_name"):
                request["ConfigurationSetName"] = config["configuration_set_name"]

            list_management_options = _to_list_management_options(
                config.get("list_management_options"),
            )
            if list_management_options:
                request["ListManagementOptions"] = list_management_options

            response = self._call_with_retries("send_email", **request)
            return cast(SendEmailResponse, response)
        except ClientError as error:
            logger.exception("Failed to send SES email")
            _raise_mapped_client_error(operation="send_email", error=error)

    def send_raw_email(self, config: SendRawEmailConfig) -> SendEmailResponse:
        try:
            request: RequestMap = {
                "FromEmailAddress": str(config["sender"]),
                "Destination": _build_destination(
                    recipients=config["recipients"],
                    cc=config.get("cc"),
                    bcc=config.get("bcc"),
                ),
                "Content": {
                    "Raw": {"Data": config["raw_data"]},
                },
            }

            reply_to = _stringify_addresses(config.get("reply_to"))
            if reply_to:
                request["ReplyToAddresses"] = reply_to

            email_tags = _to_email_tags(config.get("tags"))
            if email_tags:
                request["EmailTags"] = email_tags
            if config.get("configuration_set_name"):
                request["ConfigurationSetName"] = config["configuration_set_name"]

            list_management_options = _to_list_management_options(
                config.get("list_management_options"),
            )
            if list_management_options:
                request["ListManagementOptions"] = list_management_options

            response = self._call_with_retries("send_email", **request)
            return cast(SendEmailResponse, response)
        except ClientError as error:
            logger.exception("Failed to send SES raw email")
            _raise_mapped_client_error(operation="send_raw_email", error=error)

    def send_templated_email(self, config: SendTemplateConfig) -> SendTemplatedEmailResponse:
        try:
            request: RequestMap = {
                "FromEmailAddress": str(config["sender"]),
                "Destination": _build_destination(
                    recipients=config["recipients"],
                    cc=config.get("cc"),
                    bcc=config.get("bcc"),
                ),
                "Content": {
                    "Template": {
                        "TemplateName": config["template_name"],
                        "TemplateData": json.dumps(
                            config["template_data"],
                            ensure_ascii=False,
                            separators=(",", ":"),
                        ),
                    },
                },
            }

            email_tags = _to_email_tags(config.get("tags"))
            if email_tags:
                request["EmailTags"] = email_tags
            if config.get("configuration_set_name"):
                request["ConfigurationSetName"] = config["configuration_set_name"]

            list_management_options = _to_list_management_options(
                config.get("list_management_options"),
            )
            if list_management_options:
                request["ListManagementOptions"] = list_management_options

            response = self._call_with_retries("send_email", **request)
            return cast(SendTemplatedEmailResponse, response)
        except ClientError as error:
            logger.exception("Failed to send SES templated email")
            _raise_mapped_client_error(operation="send_templated_email", error=error)

    def send_bulk_email(self, config: BulkEmailConfig) -> list[BulkEmailResult]:
        template_name = config.get("template_name")
        content = config.get("content")

        if template_name is None and content is None:
            msg = "Bulk send requires template_name or content"
            raise SESException(msg)

        template_payload: RequestMap
        if template_name is not None:
            template_payload = {
                "TemplateName": template_name,
                "TemplateData": "{}",
            }
        else:
            assert content is not None
            template_payload = {
                "TemplateData": "{}",
                "TemplateContent": _build_template_content(content),
            }

        all_results: list[BulkEmailResult] = []
        raw_recipients: list[object] = list(config["recipients"])
        requested_batch_size = config.get("batch_size", _MAX_BULK_EMAIL_ENTRIES)
        chunk_size = max(1, min(requested_batch_size, _MAX_BULK_EMAIL_ENTRIES))

        for raw_batch in _chunk_recipients(raw_recipients, chunk_size):
            batch = cast(list[dict[str, object]], raw_batch)
            entries: list[RequestMap] = []

            for recipient in batch:
                email = cast(EmailAddress, recipient["email"])
                entry: RequestMap = {
                    "Destination": {
                        "ToAddresses": [str(email)],
                    },
                }

                replacement_tags = _to_email_tags(cast(dict[str, str] | None, recipient.get("tags")))
                if replacement_tags:
                    entry["ReplacementTags"] = replacement_tags

                template_data = recipient.get("template_data")
                if isinstance(template_data, dict):
                    entry["ReplacementEmailContent"] = {
                        "ReplacementTemplate": {
                            "ReplacementTemplateData": json.dumps(
                                template_data,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            ),
                        },
                    }

                entries.append(entry)

            request: RequestMap = {
                "FromEmailAddress": str(config["sender"]),
                "DefaultContent": {
                    "Template": template_payload,
                },
                "BulkEmailEntries": entries,
            }
            default_tags = _to_email_tags(config.get("default_tags"))
            if default_tags:
                request["DefaultEmailTags"] = default_tags

            if config.get("configuration_set_name"):
                request["ConfigurationSetName"] = config["configuration_set_name"]

            list_management_options = _to_list_management_options(
                config.get("list_management_options"),
            )
            if list_management_options:
                request["ListManagementOptions"] = list_management_options

            try:
                response = self._call_with_retries("send_bulk_email", **request)
            except ClientError as error:
                logger.exception("Failed to send SES bulk email")
                _raise_mapped_client_error(operation="send_bulk_email", error=error)

            raw_entry_results = response.get("BulkEmailEntryResults", [])
            entry_results: list[dict[str, object]]
            if isinstance(raw_entry_results, list):
                entry_results = [
                    item for item in raw_entry_results
                    if isinstance(item, dict)
                ]
            else:
                entry_results = []

            for index, recipient in enumerate(batch):
                email = cast(EmailAddress, recipient["email"]).email
                result = entry_results[index] if index < len(entry_results) else {}
                status = result.get("Status")
                message_id = result.get("MessageId")

                if status in {"SUCCESS", "Success"}:
                    all_results.append(
                        {
                            "email": email,
                            "status": "success",
                            "message_id": cast(str | None, message_id if isinstance(message_id, str) else None),
                            "error": None,
                        },
                    )
                    continue

                error_text: str
                raw_error = result.get("Error")
                if isinstance(raw_error, str) and raw_error != "":
                    error_text = raw_error
                elif isinstance(raw_error, dict):
                    error_code = raw_error.get("Code")
                    error_message = raw_error.get("Message")
                    if isinstance(error_code, str) and isinstance(error_message, str):
                        error_text = f"{error_code}: {error_message}"
                    elif isinstance(error_message, str):
                        error_text = error_message
                    else:
                        error_text = "Unknown bulk send failure"
                else:
                    error_text = "Unknown bulk send failure"

                all_results.append(
                    {
                        "email": email,
                        "status": "error",
                        "message_id": None,
                        "error": error_text,
                    },
                )

        return all_results

    def get_template(self, name: str) -> TemplateContent:
        try:
            response = self._call_with_retries("get_email_template", TemplateName=name)
            raw_template = response.get("TemplateContent")
            if not isinstance(raw_template, dict):
                msg = f"Template content is missing for template: {name}"
                raise SESException(msg)

            subject = raw_template.get("Subject")
            if not isinstance(subject, str) or subject == "":
                msg = f"Template subject is missing for template: {name}"
                raise SESException(msg)

            template: TemplateContent = {"subject": subject}
            text = raw_template.get("Text")
            html = raw_template.get("Html")
            if isinstance(text, str):
                template["text"] = text
            if isinstance(html, str):
                template["html"] = html
            return template
        except ClientError as error:
            logger.exception("Failed to get SES template: %s", name)
            _raise_mapped_client_error(
                operation="get_template",
                error=error,
                resource_type="template",
            )

    def create_template(self, name: str, content: TemplateContent) -> None:
        try:
            self._call_with_retries(
                "create_email_template",
                TemplateName=name,
                TemplateContent=_build_template_content(content),
            )
        except ClientError as error:
            logger.exception("Failed to create SES template: %s", name)
            _raise_mapped_client_error(
                operation="create_template",
                error=error,
                resource_type="template",
            )

    def update_template(self, name: str, content: TemplateContent) -> None:
        try:
            self._call_with_retries(
                "update_email_template",
                TemplateName=name,
                TemplateContent=_build_template_content(content),
            )
        except ClientError as error:
            logger.exception("Failed to update SES template: %s", name)
            _raise_mapped_client_error(
                operation="update_template",
                error=error,
                resource_type="template",
            )

    def delete_template(self, name: str) -> None:
        try:
            self._call_with_retries("delete_email_template", TemplateName=name)
        except ClientError as error:
            logger.exception("Failed to delete SES template: %s", name)
            _raise_mapped_client_error(
                operation="delete_template",
                error=error,
                resource_type="template",
            )

    def list_templates(self) -> ListTemplatesResponse:
        templates: list[TemplateMetadata] = []
        next_token: str | None = None
        response_metadata: object = {}

        try:
            while True:
                params: RequestMap = {}
                if next_token is not None:
                    params["NextToken"] = next_token
                response = self._call_with_retries("list_email_templates", **params)
                response_metadata = response.get("ResponseMetadata", response_metadata)

                raw_metadata = response.get("TemplatesMetadata", [])
                if isinstance(raw_metadata, list):
                    for item in raw_metadata:
                        if not isinstance(item, dict):
                            continue
                        name = item.get("TemplateName")
                        if not isinstance(name, str):
                            continue

                        metadata: TemplateMetadata = {"TemplateName": name}
                        created = item.get("CreatedTimestamp")
                        if isinstance(created, datetime):
                            metadata["CreatedTimestamp"] = created
                        templates.append(metadata)

                token_value = response.get("NextToken")
                if isinstance(token_value, str) and token_value != "":
                    next_token = token_value
                else:
                    break

            return {
                "TemplatesMetadata": templates,
                "ResponseMetadata": cast(dict[str, object], response_metadata),
            }
        except ClientError as error:
            logger.exception("Failed to list SES templates")
            _raise_mapped_client_error(
                operation="list_templates",
                error=error,
                resource_type="template",
            )

    def verify_email_identity(self, email: str) -> None:
        try:
            self._call_with_retries("create_email_identity", EmailIdentity=email)
        except ClientError as error:
            logger.exception("Failed to verify SES email identity: %s", email)
            _raise_mapped_client_error(
                operation="verify_email_identity",
                error=error,
                resource_type="identity",
            )

    def get_email_identity(self, identity_name: str) -> EmailIdentityDetails:
        try:
            response = self._call_with_retries(
                "get_email_identity",
                EmailIdentity=identity_name,
            )

            result: EmailIdentityDetails = {"identity_name": identity_name}
            identity_type = response.get("IdentityType")
            if isinstance(identity_type, str):
                result["identity_type"] = identity_type

            verified = response.get("VerifiedForSendingStatus")
            if isinstance(verified, bool):
                result["verified_for_sending_status"] = verified

            sending_enabled = response.get("SendingEnabledForConfigurationSet")
            if isinstance(sending_enabled, bool):
                result["sending_enabled_for_configuration_set"] = sending_enabled

            configuration_set_name = response.get("ConfigurationSetName")
            if isinstance(configuration_set_name, str):
                result["configuration_set_name"] = configuration_set_name

            return result
        except ClientError as error:
            logger.exception("Failed to get SES email identity: %s", identity_name)
            _raise_mapped_client_error(
                operation="get_email_identity",
                error=error,
                resource_type="identity",
            )

    def delete_email_identity(self, identity_name: str) -> None:
        try:
            self._call_with_retries("delete_email_identity", EmailIdentity=identity_name)
        except ClientError as error:
            logger.exception("Failed to delete SES email identity: %s", identity_name)
            _raise_mapped_client_error(
                operation="delete_email_identity",
                error=error,
                resource_type="identity",
            )

    def put_suppressed_destination(
        self,
        email_address: str,
        reason: SuppressionReason,
    ) -> None:
        try:
            self._call_with_retries(
                "put_suppressed_destination",
                EmailAddress=email_address,
                Reason=reason,
            )
        except ClientError as error:
            logger.exception("Failed to suppress SES destination: %s", email_address)
            _raise_mapped_client_error(
                operation="put_suppressed_destination",
                error=error,
            )

    def delete_suppressed_destination(self, email_address: str) -> None:
        try:
            self._call_with_retries(
                "delete_suppressed_destination",
                EmailAddress=email_address,
            )
        except ClientError as error:
            logger.exception("Failed to unsuppress SES destination: %s", email_address)
            _raise_mapped_client_error(
                operation="delete_suppressed_destination",
                error=error,
            )

    def list_suppressed_destinations(
        self,
        *,
        reasons: list[SuppressionReason] | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> list[SuppressedDestinationSummary]:
        summaries: list[SuppressedDestinationSummary] = []
        next_token: str | None = None

        try:
            while True:
                params: RequestMap = {}
                if reasons:
                    params["Reasons"] = reasons
                if start_date is not None:
                    params["StartDate"] = start_date
                if end_date is not None:
                    params["EndDate"] = end_date
                if next_token is not None:
                    params["NextToken"] = next_token

                response = self._call_with_retries("list_suppressed_destinations", **params)
                raw_items = response.get("SuppressedDestinationSummaries", [])
                if isinstance(raw_items, list):
                    for item in raw_items:
                        if not isinstance(item, dict):
                            continue

                        email_address = item.get("EmailAddress")
                        if not isinstance(email_address, str) or email_address == "":
                            continue

                        summary: SuppressedDestinationSummary = {
                            "email_address": email_address,
                        }

                        reason = item.get("Reason")
                        if reason in {"BOUNCE", "COMPLAINT"}:
                            summary["reason"] = reason

                        last_update_time = item.get("LastUpdateTime")
                        if isinstance(last_update_time, datetime):
                            summary["last_update_time"] = last_update_time

                        summaries.append(summary)

                token_value = response.get("NextToken")
                if isinstance(token_value, str) and token_value != "":
                    next_token = token_value
                else:
                    break

            return summaries
        except ClientError as error:
            logger.exception("Failed to list SES suppressed destinations")
            _raise_mapped_client_error(
                operation="list_suppressed_destinations",
                error=error,
            )

    def list_identities(
        self,
        *,
        identity_types: list[SESIdentityType] | None = None,
    ) -> list[str]:
        identities: list[str] = []
        next_token: str | None = None

        try:
            allowed_types: set[str] | None = (
                set(identity_types)
                if identity_types is not None
                else None
            )
            while True:
                params: RequestMap = {}
                if next_token is not None:
                    params["NextToken"] = next_token

                response = self._call_with_retries("list_email_identities", **params)
                raw_identities = response.get("EmailIdentities", [])
                if isinstance(raw_identities, list):
                    for item in raw_identities:
                        if not isinstance(item, dict):
                            continue
                        identity_name = item.get("IdentityName")
                        identity_type = item.get("IdentityType")

                        if not isinstance(identity_name, str):
                            continue
                        if not isinstance(identity_type, str):
                            continue
                        if allowed_types is None or identity_type in allowed_types:
                            identities.append(identity_name)

                token_value = response.get("NextToken")
                if isinstance(token_value, str) and token_value != "":
                    next_token = token_value
                else:
                    break

            return identities
        except ClientError as error:
            logger.exception("Failed to list SES identities")
            _raise_mapped_client_error(
                operation="list_identities",
                error=error,
                resource_type="identity",
            )

    def get_send_quota(self) -> GetSendQuotaResponse:
        try:
            response = self._call_with_retries("get_account")
            send_quota = response.get("SendQuota")
            if not isinstance(send_quota, dict):
                msg = "SESv2 get_account response missing SendQuota"
                raise SESException(msg)

            response_metadata = response.get("ResponseMetadata", {})
            if not isinstance(response_metadata, dict):
                response_metadata = {}

            return {
                "Max24HourSend": _to_float(send_quota.get("Max24HourSend"), "Max24HourSend"),
                "MaxSendRate": _to_float(send_quota.get("MaxSendRate"), "MaxSendRate"),
                "SentLast24Hours": _to_float(
                    send_quota.get("SentLast24Hours"),
                    "SentLast24Hours",
                ),
                "ResponseMetadata": cast(dict[str, object], response_metadata),
            }
        except ClientError as error:
            logger.exception("Failed to get SES send quota")
            _raise_mapped_client_error(operation="get_send_quota", error=error)
