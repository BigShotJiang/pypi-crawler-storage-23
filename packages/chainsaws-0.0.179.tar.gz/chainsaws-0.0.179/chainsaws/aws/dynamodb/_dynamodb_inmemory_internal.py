from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
from typing import cast

from chainsaws.aws.dynamodb._dynamodb_utils import decode_dict
from chainsaws.aws.dynamodb.dynamodb_exception import DynamoDBError
from chainsaws.aws.dynamodb.dynamodb_models import (
    DynamoItem,
    DynamoKey,
    FilterDict,
    QueryPage,
    RecursiveFilterBase,
    RecursiveFilterNode,
)


class InMemoryDynamoDBInternal:
    """In-memory DynamoDB internal adapter for tests."""

    __slots__ = ("table_name", "_items")

    def __init__(self, table_name: str = "in-memory-table") -> None:
        self.table_name = table_name
        self._items: dict[tuple[str, str], DynamoItem] = {}

    def init_db_table(self) -> None:
        return None

    def create_db_table(self) -> dict[str, object]:
        return {}

    def enable_ttl(self) -> dict[str, object]:
        return {}

    def create_db_partition_index(
        self,
        index_name: str,
        pk_name: str,
        sk_name: str,
    ) -> dict[str, object]:
        return {
            "IndexName": index_name,
            "KeySchema": [pk_name, sk_name],
        }

    def delete_db_partition_index(self, index_name: str) -> dict[str, object]:
        return {
            "IndexName": index_name,
            "Status": "DELETED",
        }

    def delete_db_table(self) -> dict[str, object]:
        self._items.clear()
        return {}

    def get_item(
        self,
        pk: str,
        sk: str | None = None,
        consistent_read: bool = False,
    ) -> DynamoItem | None:
        del consistent_read
        if sk is None:
            return None
        item = self._items.get((pk, sk))
        return deepcopy(item) if item else None

    def get_items(
        self,
        pk_sk_pairs: list[tuple[str, str]],
        consistent_read: bool = False,
    ) -> list[DynamoItem | None]:
        del consistent_read
        result: list[DynamoItem | None] = []
        for pk, sk in pk_sk_pairs:
            item = self._items.get((pk, sk))
            result.append(deepcopy(item) if item else None)
        return result

    def put_item(
        self,
        item: DynamoItem,
        can_overwrite: bool = True,
    ) -> dict[str, object]:
        if "_pk" not in item or "_sk" not in item:
            raise DynamoDBError("Item must contain '_pk' and '_sk'")

        key = (str(item["_pk"]), str(item["_sk"]))
        if not can_overwrite and key in self._items:
            raise DynamoDBError(
                f"Item already exists with _pk='{key[0]}' and _sk='{key[1]}'",
            )

        normalized_item = cast(DynamoItem, decode_dict(deepcopy(item)))
        self._items[key] = normalized_item
        return {"Attributes": deepcopy(normalized_item)}

    def update_item(self, pk: str, sk: str, item: DynamoItem) -> dict[str, object]:
        if not item:
            raise DynamoDBError("No fields to update")

        key = (pk, sk)
        if key not in self._items:
            raise DynamoDBError(f"Cannot find item with given keys: _pk='{pk}', _sk='{sk}'")

        normalized_item = cast(DynamoItem, decode_dict(deepcopy(item)))
        updated = deepcopy(self._items[key])
        updated.update(normalized_item)
        self._items[key] = updated
        return {"Attributes": deepcopy(updated)}

    def batch_put(
        self,
        items: list[DynamoItem],
        can_overwrite: bool = False,
    ) -> bool:
        for item in items:
            self.put_item(item=item, can_overwrite=can_overwrite)
        return True

    def delete_item(self, pk: str, sk: str) -> dict[str, object]:
        key = (pk, sk)
        if key not in self._items:
            raise DynamoDBError(f"Cannot find item with given keys: _pk='{pk}', _sk='{sk}'")
        deleted = self._items.pop(key)
        return {"Attributes": deepcopy(deleted)}

    def batch_delete(self, pk_sk_pairs: list[tuple[str, str]]) -> bool:
        for pk, sk in pk_sk_pairs:
            self._items.pop((pk, sk), None)
        return True

    @staticmethod
    def _as_decimal_if_float(value: object) -> object:
        if isinstance(value, float):
            return Decimal(str(value))
        if isinstance(value, list):
            return [InMemoryDynamoDBInternal._as_decimal_if_float(it) for it in value]
        return value

    @classmethod
    def _match_condition(
        cls,
        item_value: object,
        condition: str,
        value: object,
        second_value: object | None,
    ) -> bool:
        value = cls._as_decimal_if_float(value)
        second_value = cls._as_decimal_if_float(second_value)

        if condition == "eq":
            return item_value == value
        if condition == "neq":
            return item_value != value
        if condition == "lte":
            return item_value <= value
        if condition == "lt":
            return item_value < value
        if condition == "gte":
            return item_value >= value
        if condition == "gt":
            return item_value > value
        if condition == "btw":
            return second_value is not None and value <= item_value <= second_value
        if condition == "not_btw":
            return second_value is not None and not (value <= item_value <= second_value)
        if condition == "stw":
            return str(item_value).startswith(str(value))
        if condition == "not_stw":
            return not str(item_value).startswith(str(value))
        if condition == "is_in":
            return isinstance(value, list) and item_value in value
        if condition == "is_not_in":
            return isinstance(value, list) and item_value not in value
        if condition == "contains":
            if isinstance(item_value, (list, str)):
                return value in item_value
            return False
        if condition == "not_contains":
            if isinstance(item_value, (list, str)):
                return value not in item_value
            return True
        if condition == "exist":
            return item_value is not None
        if condition == "not_exist":
            return item_value is None
        raise ValueError(f"Invalid filter condition: {condition}")

    @classmethod
    def _matches_filter(
        cls,
        item: DynamoItem,
        filter_dict: FilterDict | RecursiveFilterBase,
    ) -> bool:
        field = filter_dict["field"]
        condition = filter_dict["condition"]
        value = filter_dict.get("value")
        second_value = filter_dict.get("second_value")
        item_value = item.get(field)
        return cls._match_condition(item_value, condition, value, second_value)

    @classmethod
    def _matches_recursive_filter(
        cls,
        item: DynamoItem,
        recursive_filters: RecursiveFilterNode | RecursiveFilterBase,
    ) -> bool:
        if "field" in recursive_filters:
            return cls._matches_filter(item, cast(RecursiveFilterBase, recursive_filters))

        node_obj = cast(dict[str, object], recursive_filters)
        left_node = node_obj.get("left")
        right_node = node_obj.get("right")
        operation = node_obj.get("operation")
        if left_node is None or right_node is None or operation not in {"and", "or"}:
            raise ValueError("Invalid recursive filter format")

        left_result = cls._matches_recursive_filter(
            item,
            cast(RecursiveFilterNode | RecursiveFilterBase, left_node),
        )
        right_result = cls._matches_recursive_filter(
            item,
            cast(RecursiveFilterNode | RecursiveFilterBase, right_node),
        )
        if operation == "and":
            return left_result and right_result
        return left_result or right_result

    @staticmethod
    def _matches_sort_condition(
        value: object,
        condition: str | None,
        target: object,
        second_target: object | None,
    ) -> bool:
        if condition is None:
            return True
        if condition == "eq":
            return value == target
        if condition == "lte":
            return value <= target
        if condition == "lt":
            return value < target
        if condition == "gte":
            return value >= target
        if condition == "gt":
            return value > target
        if condition == "btw":
            return second_target is not None and target <= value <= second_target
        if condition == "stw":
            return str(value).startswith(str(target))
        return True

    @staticmethod
    def _project_item(
        item: DynamoItem,
        projection_fields: list[str] | None,
    ) -> DynamoItem:
        if not projection_fields:
            return deepcopy(item)

        required = ["_pk", "_sk", "_ptn"]
        allowed = []
        seen = set()
        for name in required + projection_fields:
            if name not in seen:
                allowed.append(name)
                seen.add(name)

        return {key: deepcopy(item[key]) for key in allowed if key in item}

    @staticmethod
    def _apply_start_key(
        items: list[DynamoItem],
        start_key: DynamoKey | None,
    ) -> list[DynamoItem]:
        if not start_key:
            return items

        start_pk = start_key.get("_pk")
        start_sk = start_key.get("_sk")
        if start_pk is None or start_sk is None:
            return items

        for idx, item in enumerate(items):
            if item.get("_pk") == start_pk and item.get("_sk") == start_sk:
                return items[idx + 1:]
        return items

    @staticmethod
    def _build_dynamo_key(item: DynamoItem) -> DynamoKey | None:
        pk = item.get("_pk")
        sk = item.get("_sk")
        if isinstance(pk, str) and isinstance(sk, str):
            return {"_pk": pk, "_sk": sk}
        return None

    def query_items(
        self,
        partition_key_name: str,
        partition_key_value: str,
        sort_condition: str | None = None,
        sort_key_name: str | None = None,
        sort_key_value: object | None = None,
        sort_key_second_value: object | None = None,
        filters: list[FilterDict] | None = None,
        start_key: DynamoKey | None = None,
        reverse: bool = False,
        limit: int = 100,
        consistent_read: bool = False,
        index_name: str | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage:
        del consistent_read, index_name

        candidates = [
            item
            for item in self._items.values()
            if item.get(partition_key_name) == partition_key_value
        ]

        if sort_key_name:
            candidates = [
                item
                for item in candidates
                if self._matches_sort_condition(
                    value=item.get(sort_key_name),
                    condition=sort_condition,
                    target=sort_key_value,
                    second_target=sort_key_second_value,
                )
            ]

        if filters:
            candidates = [
                item for item in candidates
                if all(self._matches_filter(item, ft) for ft in filters)
            ]

        if recursive_filters:
            candidates = [
                item for item in candidates
                if self._matches_recursive_filter(item, recursive_filters)
            ]

        sort_field = sort_key_name or "_sk"
        candidates = sorted(
            candidates,
            key=lambda item: str(item.get(sort_field, "")),
            reverse=reverse,
        )
        candidates = self._apply_start_key(candidates, start_key)

        limited_items = candidates[:limit]
        projected_items = [
            self._project_item(item, projection_fields)
            for item in limited_items
        ]

        last_evaluated_key: DynamoKey | None = None
        if len(candidates) > limit and limited_items:
            last_evaluated_key = self._build_dynamo_key(limited_items[-1])

        return {
            "Items": projected_items,
            "LastEvaluatedKey": last_evaluated_key,
        }

    def scan_table(
        self,
        filters: list[FilterDict] | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        start_key: DynamoKey | None = None,
        limit: int | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage:
        items = list(self._items.values())

        if filters:
            items = [
                item for item in items
                if all(self._matches_filter(item, ft) for ft in filters)
            ]

        if recursive_filters:
            items = [
                item for item in items
                if self._matches_recursive_filter(item, recursive_filters)
            ]

        items = sorted(
            items,
            key=lambda item: (
                str(item.get("_pk", "")),
                str(item.get("_sk", "")),
            ),
        )
        items = self._apply_start_key(items, start_key)

        page_size = limit if limit is not None else len(items)
        limited_items = items[:page_size]
        projected_items = [
            self._project_item(item, projection_fields)
            for item in limited_items
        ]

        last_evaluated_key: DynamoKey | None = None
        if len(items) > page_size and limited_items:
            last_evaluated_key = self._build_dynamo_key(limited_items[-1])

        return {
            "Items": projected_items,
            "LastEvaluatedKey": last_evaluated_key,
        }
