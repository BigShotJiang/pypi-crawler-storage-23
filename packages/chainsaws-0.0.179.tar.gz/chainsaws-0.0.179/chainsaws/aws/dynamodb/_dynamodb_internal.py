import logging
import time
from decimal import Decimal
from typing import Callable, Final, Optional, TypeVar, cast

from boto3 import Session
from boto3.dynamodb.conditions import Attr, ConditionBase, ConditionExpressionBuilder, Key
from boto3.dynamodb.types import Binary, DYNAMODB_CONTEXT, TypeDeserializer
from botocore import client
from botocore.waiter import WaiterError

from chainsaws.aws.dynamodb.dynamodb_models import (
    DynamoDBAPIConfig,
    DynamoItem,
    DynamoKey,
    FilterDict,
    QueryPage,
    RecursiveFilterBase,
    RecursiveFilterNode,
)
from chainsaws.aws.dynamodb.dynamodb_exception import DynamoDBError

logger = logging.getLogger(__name__)
type_deserializer = TypeDeserializer()
MAX_UNPROCESSED_RETRIES: Final[int] = 5

RustDeserializeItemsImpl = Callable[[object, object, object, object], None]
RustNormalizePairsImpl = Callable[[object], object]
RustUpdateExprImpl = Callable[[object], tuple[str, object, object]]
RustProjectionExprImpl = Callable[[object, object, bool], tuple[object, object]]
RustSdkGetItemImpl = Callable[..., object]
RustSdkBatchGetItemsImpl = Callable[..., object]
RustSdkBatchGetItemsOrderedImpl = Callable[..., object]
RustSdkPutItemImpl = Callable[..., object]
RustSdkUpdateItemImpl = Callable[..., object]
RustSdkDeleteItemImpl = Callable[..., object]
RustSdkBatchWriteImpl = Callable[..., bool]
RustSdkQueryItemsImpl = Callable[..., object]
RustSdkScanItemsImpl = Callable[..., object]
ImplT = TypeVar("ImplT")

try:
    from chainsaws_pyo3 import deserialize_items as _deserialize_items_rust_impl
    from chainsaws_pyo3 import normalize_pk_sk_pairs as _normalize_pk_sk_pairs_rust_impl
    from chainsaws_pyo3 import get_update_expression_attrs_pair as _get_update_expression_attrs_pair_rust_impl
    from chainsaws_pyo3 import build_projection_expression as _build_projection_expression_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_get_item as _dynamodb_sdk_get_item_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_batch_get_items as _dynamodb_sdk_batch_get_items_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_batch_get_items_ordered as _dynamodb_sdk_batch_get_items_ordered_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_put_item as _dynamodb_sdk_put_item_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_update_item as _dynamodb_sdk_update_item_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_delete_item as _dynamodb_sdk_delete_item_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_batch_write as _dynamodb_sdk_batch_write_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_query_items as _dynamodb_sdk_query_items_rust_impl
    from chainsaws_pyo3 import dynamodb_sdk_scan_items as _dynamodb_sdk_scan_items_rust_impl
except Exception:
    _deserialize_items_rust_impl: RustDeserializeItemsImpl | None = None
    _normalize_pk_sk_pairs_rust_impl: RustNormalizePairsImpl | None = None
    _get_update_expression_attrs_pair_rust_impl: RustUpdateExprImpl | None = None
    _build_projection_expression_rust_impl: RustProjectionExprImpl | None = None
    _dynamodb_sdk_get_item_rust_impl: RustSdkGetItemImpl | None = None
    _dynamodb_sdk_batch_get_items_rust_impl: RustSdkBatchGetItemsImpl | None = None
    _dynamodb_sdk_batch_get_items_ordered_rust_impl: RustSdkBatchGetItemsOrderedImpl | None = None
    _dynamodb_sdk_put_item_rust_impl: RustSdkPutItemImpl | None = None
    _dynamodb_sdk_update_item_rust_impl: RustSdkUpdateItemImpl | None = None
    _dynamodb_sdk_delete_item_rust_impl: RustSdkDeleteItemImpl | None = None
    _dynamodb_sdk_batch_write_rust_impl: RustSdkBatchWriteImpl | None = None
    _dynamodb_sdk_query_items_rust_impl: RustSdkQueryItemsImpl | None = None
    _dynamodb_sdk_scan_items_rust_impl: RustSdkScanItemsImpl | None = None

_USE_RUST_DESERIALIZER = True
_USE_RUST_NORMALIZE_PAIRS = True
_USE_RUST_UPDATE_EXPRESSION = True


def _require_rust_impl(name: str, impl: ImplT | None) -> ImplT:
    if impl is None:
        msg = (
            f"Rust DynamoDB internal path is enabled for '{name}', "
            "but chainsaws_pyo3 implementation is unavailable."
        )
        raise RuntimeError(msg)
    return impl


_require_rust_impl("deserialize_items", _deserialize_items_rust_impl)
_require_rust_impl("normalize_pk_sk_pairs", _normalize_pk_sk_pairs_rust_impl)
_require_rust_impl("get_update_expression_attrs_pair", _get_update_expression_attrs_pair_rust_impl)
_require_rust_impl("build_projection_expression", _build_projection_expression_rust_impl)
_require_rust_impl("dynamodb_sdk_get_item", _dynamodb_sdk_get_item_rust_impl)
_require_rust_impl("dynamodb_sdk_batch_get_items", _dynamodb_sdk_batch_get_items_rust_impl)
_require_rust_impl("dynamodb_sdk_batch_get_items_ordered", _dynamodb_sdk_batch_get_items_ordered_rust_impl)
_require_rust_impl("dynamodb_sdk_put_item", _dynamodb_sdk_put_item_rust_impl)
_require_rust_impl("dynamodb_sdk_update_item", _dynamodb_sdk_update_item_rust_impl)
_require_rust_impl("dynamodb_sdk_delete_item", _dynamodb_sdk_delete_item_rust_impl)
_require_rust_impl("dynamodb_sdk_batch_write", _dynamodb_sdk_batch_write_rust_impl)
_require_rust_impl("dynamodb_sdk_query_items", _dynamodb_sdk_query_items_rust_impl)
_require_rust_impl("dynamodb_sdk_scan_items", _dynamodb_sdk_scan_items_rust_impl)

class DynamoDB:
    """DynamoDB client wrapper for simplified table operations."""

    __slots__ = (
        'client',
        'resource',
        'table_cache',
        'table_name',
        '_rust_region',
        '_rust_endpoint_url',
        '_rust_profile_name',
        '_rust_access_key_id',
        '_rust_secret_access_key',
        '_rust_session_token',
        '_rust_sdk_auth_kwargs',
    )

    def __init__(self, boto3_session: Session, table_name: str, config: Optional[DynamoDBAPIConfig] = None) -> None:
        """Initialize DynamoDB client."""
        dynamo_config = client.Config(
            max_pool_connections=config.max_pool_connections if config else None,
        )
        self.client = boto3_session.client(
            service_name="dynamodb",
            config=dynamo_config,
            endpoint_url=config.endpoint_url if config else None,
            region_name=config.region if config else None,
        )

        self.resource = boto3_session.resource(
            service_name="dynamodb",
            config=dynamo_config,
            endpoint_url=config.endpoint_url if config else None,
            region_name=config.region if config else None,
        )
        self.table_cache = {}
        self.table_name = table_name
        credentials = config.credentials if config else None
        self._rust_region = config.region if config else None
        self._rust_endpoint_url = config.endpoint_url if config else None
        self._rust_profile_name = getattr(credentials, "profile_name", None)
        self._rust_access_key_id = getattr(credentials, "aws_access_key_id", None)
        self._rust_secret_access_key = getattr(credentials, "aws_secret_access_key", None)
        self._rust_session_token = getattr(credentials, "aws_session_token", None)
        self._rust_sdk_auth_kwargs = {
            "region": self._rust_region,
            "endpoint_url": self._rust_endpoint_url,
            "profile_name": self._rust_profile_name,
            "access_key_id": self._rust_access_key_id,
            "secret_access_key": self._rust_secret_access_key,
            "session_token": self._rust_session_token,
        }

    def _sdk_auth_kwargs(self) -> dict[str, str | None]:
        sdk_auth = getattr(self, "_rust_sdk_auth_kwargs", None)
        if sdk_auth is not None:
            return cast(dict[str, str | None], sdk_auth)
        return {
            "region": getattr(self, "_rust_region", None),
            "endpoint_url": getattr(self, "_rust_endpoint_url", None),
            "profile_name": getattr(self, "_rust_profile_name", None),
            "access_key_id": getattr(self, "_rust_access_key_id", None),
            "secret_access_key": getattr(self, "_rust_secret_access_key", None),
            "session_token": getattr(self, "_rust_session_token", None),
        }

    @classmethod
    def _deserialize_wire_items(
        cls,
        wire_items: list[dict[str, object]],
    ) -> list[DynamoItem]:
        deserialize_impl = _require_rust_impl(
            "deserialize_items",
            _deserialize_items_rust_impl,
        )
        deserialize_impl(
            wire_items,
            DYNAMODB_CONTEXT,
            Binary,
            type_deserializer,
        )
        return cast(list[DynamoItem], wire_items)

    @staticmethod
    def _deserialize_wire_key(
        wire_key: dict[str, object] | None,
    ) -> DynamoKey | None:
        if wire_key is None:
            return None
        return cast(
            DynamoKey,
            {
                key: type_deserializer.deserialize(value)
                for key, value in wire_key.items()
            },
        )

    def init_db_table(self) -> None:
        """Initialize DynamoDB table."""
        self.create_db_table()
        self.enable_ttl()

    def create_db_table(self) -> dict[str, object]:
        """Create a new DynamoDB table."""
        table_name = self.table_name

        try:
            existing_tables = self.client.list_tables()["TableNames"]
            if table_name in existing_tables:
                logger.info(
                    f"Table {table_name} already exists, skipping creation.")
                return {}

            logger.info(f"Creating DynamoDB table: {table_name}...")
            response = self.client.create_table(
                AttributeDefinitions=[
                    {
                        "AttributeName": "_pk",
                        "AttributeType": "S",
                    },
                    {
                        "AttributeName": "_sk",
                        "AttributeType": "S",
                    },
                ],
                TableName=table_name,
                KeySchema=[
                    {
                        "AttributeName": "_pk",
                        "KeyType": "HASH",
                    },
                    {
                        "AttributeName": "_sk",
                        "KeyType": "RANGE",
                    },
                ],
                BillingMode="PAY_PER_REQUEST",
                # StreamSpecification={
                #     "StreamEnabled": True,
                #     "StreamViewType": "NEW_AND_OLD_IMAGES",
                # },
            )
            self.client.get_waiter("table_exists").wait(TableName=table_name)
            logger.info(f"Table {table_name} created successfully!")
            return response
        except Exception as ex:
            logger.exception(f"Failed to create table: {ex!s}")
            raise

    def enable_ttl(self) -> dict[str, object]:
        """Enable TTL for the table."""
        try:
            logger.info(f"Checking TTL status for table: {self.table_name}...")

            # First check if TTL is already enabled
            ttl_status = self.client.describe_time_to_live(
                TableName=self.table_name
            )

            current_status = ttl_status.get(
                'TimeToLiveDescription', {}).get('TimeToLiveStatus')

            # If TTL is already ENABLED, return without trying to enable again
            if current_status == 'ENABLED':
                logger.info(f"TTL is already enabled for table: {
                            self.table_name}")
                return ttl_status

            logger.info(f"Enabling TTL for table: {self.table_name}...")
            response = self.client.update_time_to_live(
                TableName=self.table_name,
                TimeToLiveSpecification={
                    "Enabled": True,
                    "AttributeName": "_ttl",
                },
            )

            logger.info(f"TTL enabled for table: {self.table_name}")
            return response
        except Exception as ex:
            logger.exception(f"Failed to enable TTL for table: {ex!s}")
            raise

    def create_db_partition_index(
        self,
        index_name: str,
        pk_name: str,
        sk_name: str,
    ) -> dict[str, object]:
        """Create a global secondary index and wait for it to be active.

        Args:
            index_name: Name of the index to create
            pk_name: Partition key attribute name
            sk_name: Sort key attribute name
            wait_timeout: Maximum time to wait for index creation (seconds)
            wait_interval: Time between status checks (seconds)

        Returns:
            AWS response payload

        Raises:
            WaiterError: If index creation times out
            Exception: If index creation fails

        """
        try:
            response = self.client.update_table(
                AttributeDefinitions=[
                    {
                        "AttributeName": pk_name,
                        "AttributeType": "S",
                    },
                    {
                        "AttributeName": sk_name,
                        "AttributeType": "S",
                    },
                ],
                TableName=self.table_name,
                GlobalSecondaryIndexUpdates=[
                    {
                        "Create": {
                            "IndexName": index_name,
                            "KeySchema": [
                                {
                                    "AttributeName": pk_name,
                                    "KeyType": "HASH",
                                },
                                {
                                    "AttributeName": sk_name,
                                    "KeyType": "RANGE",
                                },
                            ],
                            "Projection": {
                                "ProjectionType": "ALL",
                            },
                        },
                    },
                ],
            )

            logger.info(f"Creating GSI {index_name} on table {
                        self.table_name}...")

            # Wait for index to become active
            self.client.get_waiter("table_exists")
            start_time = time.time()

            # 420 seconds is the maximum time for index creation
            # This is probably enough time for any index to be created
            wait_timeout, wait_interval = 420, 5

            while time.time() - start_time < wait_timeout:
                try:
                    # Check table description
                    table_desc = self.client.describe_table(
                        TableName=self.table_name)
                    indexes = table_desc.get("Table", {}).get(
                        "GlobalSecondaryIndexes", [])

                    # Find our index
                    target_index = next(
                        (idx for idx in indexes if idx["IndexName"]
                         == index_name),
                        None,
                    )

                    if target_index:
                        status = target_index["IndexStatus"]
                        if status == "ACTIVE":
                            logger.info(f"GSI {index_name} is now active")
                            return response
                        if status == "CREATING":
                            logger.debug(
                                f"GSI {index_name} is still being created...")
                        else:
                            msg = f"Unexpected index status: {status}"
                            raise Exception(
                                msg)

                    time.sleep(wait_interval)

                except self.client.exceptions.ResourceNotFoundException:
                    logger.debug("Table description not available yet...")
                    time.sleep(wait_interval)

            raise WaiterError(
                name="table_exists",
                reason=f"GSI {index_name} creation timed out after {
                    wait_timeout} seconds",
                last_response=response,
            )

        except Exception as ex:
            logger.exception(
                f"Failed to create index: {ex!s}\n"
                f"pk:{pk_name}, sk:{sk_name}",
            )
            raise

    def delete_db_partition_index(
        self,
        index_name: str,
    ) -> dict[str, object]:
        """Delete a global secondary index and wait until removal is complete."""
        try:
            response = self.client.update_table(
                TableName=self.table_name,
                GlobalSecondaryIndexUpdates=[
                    {
                        "Delete": {
                            "IndexName": index_name,
                        },
                    },
                ],
            )

            logger.info(f"Deleting GSI {index_name} on table {self.table_name}...")
            start_time = time.time()
            wait_timeout, wait_interval = 420, 5

            while time.time() - start_time < wait_timeout:
                table_desc = self.client.describe_table(TableName=self.table_name)
                indexes = table_desc.get("Table", {}).get("GlobalSecondaryIndexes", [])

                if not any(idx.get("IndexName") == index_name for idx in indexes):
                    logger.info(f"GSI {index_name} deleted successfully")
                    return response

                time.sleep(wait_interval)

            raise WaiterError(
                name="table_exists",
                reason=f"GSI {index_name} deletion timed out after {wait_timeout} seconds",
                last_response=response,
            )
        except Exception as ex:
            msg = str(ex).lower()
            if (
                "not found" in msg
                or "does not exist" in msg
                or "non-existent" in msg
            ):
                logger.info(f"GSI {index_name} is already absent on table {self.table_name}")
                return {}
            logger.exception(f"Failed to delete index {index_name}: {ex!s}")
            raise

    def get_table(self, table_name: str):
        """Get cached table resource.

        This method returns a DynamoDB table resource, using a cache to avoid
        recreating the resource for the same table multiple times.

        Args:
            table_name: Name of the DynamoDB table

        Returns:
            boto3.resource.Table: The DynamoDB table resource

        """
        if table_name in self.table_cache:
            return self.table_cache[table_name]
        table = self.resource.Table(table_name)
        self.table_cache[table_name] = table
        return table

    def delete_db_table(self) -> dict[str, object] | None:
        """Delete the DynamoDB table.

        Attempts to delete the DynamoDB table specified by self.table_name.

        Returns:
            Response from delete_table API call if successful, None if deletion fails

        Logs:
            Error message if table deletion fails

        """
        try:
            return self.client.delete_table(
                TableName=self.table_name,
            )
        except BaseException as ex:
            logger.exception(f"Failed to delete table: {ex!s}")
            return None

    def get_item(
        self,
        pk: str,
        sk: str | None = None,
        consistent_read: bool = False,
    ) -> DynamoItem | None:
        """Retrieve a single item from DynamoDB by primary key.

        Gets an item from DynamoDB using partition key and optional sort key.
        Uses the table's primary key schema.

        Args:
            pk: Partition key value
            sk: Sort key value (optional)
            consistent_read: Whether to use strongly consistent reads (default False)

        Returns:
            The item if found, None if not found

        Notes:
            The returned item is in raw DynamoDB format with attributes like
            '_pk' and '_sk' included

        """
        if sk is None:
            return None

        get_item_impl = _require_rust_impl(
            "dynamodb_sdk_get_item",
            _dynamodb_sdk_get_item_rust_impl,
        )
        wire_item = get_item_impl(
            table_name=self.table_name,
            pk=pk,
            sk=sk,
            consistent_read=consistent_read,
            decimal_context=DYNAMODB_CONTEXT,
            binary_type=Binary,
            fallback_deserializer=type_deserializer,
            **self._sdk_auth_kwargs(),
        )
        return cast(DynamoItem | None, wire_item)

    def _get_items(
        self,
        pk_sk_pairs: list[tuple[str, str] | DynamoKey | dict[str, dict[str, str]]],
        consistent_read: bool = False,
        retry_attempt: int = 0,
    ) -> list[DynamoItem]:
        """Helper method to get items in batches with retry logic.

        Args:
            pk_sk_pairs: Iterable of keys. Each element can be one of:
                - tuple/list: (pk, sk)
                - dict with string values: {"_pk": "...", "_sk": "..."}
                - dict in DynamoDB wire format: {"_pk": {"S": "..."}, "_sk": {"S": "..."}}
            consistent_read: Whether to use strongly consistent reads
            retry_attempt: Number of retry attempts made so far

        Returns:
            List of successfully retrieved items (deserialized)

        """
        normalize_impl = _require_rust_impl(
            "normalize_pk_sk_pairs",
            _normalize_pk_sk_pairs_rust_impl,
        )
        keys = cast(
            list[dict[str, dict[str, str]]],
            normalize_impl(pk_sk_pairs or []),
        )
        if not keys:
            return []

        batch_get_impl = _require_rust_impl(
            "dynamodb_sdk_batch_get_items",
            _dynamodb_sdk_batch_get_items_rust_impl,
        )
        max_retries = max(0, MAX_UNPROCESSED_RETRIES - retry_attempt)
        try:
            wire_items = cast(
                list[dict[str, object]],
                batch_get_impl(
                    table_name=self.table_name,
                    keys=keys,
                    consistent_read=consistent_read,
                    max_unprocessed_retries=max_retries,
                    decimal_context=DYNAMODB_CONTEXT,
                    binary_type=Binary,
                    fallback_deserializer=type_deserializer,
                    **self._sdk_auth_kwargs(),
                ),
            )
        except Exception as e:
            if "Unprocessed keys remained after retries" in str(e):
                raise DynamoDBError(str(e)) from e
            raise
        return cast(list[DynamoItem], wire_items)

    def get_items(
        self,
        pk_sk_pairs: list[tuple[str, str]],
        consistent_read: bool = False,
    ) -> list[DynamoItem | None]:
        """Get multiple items from DynamoDB in parallel batches.

        Args:
            pk_sk_pairs: List of partition key and sort key pairs to retrieve
            consistent_read: Whether to use strongly consistent reads

        Returns:
            List of items in the same order as the input pk_sk_pairs

        """
        if not pk_sk_pairs:
            return []

        batch_get_ordered_impl = _require_rust_impl(
            "dynamodb_sdk_batch_get_items_ordered",
            _dynamodb_sdk_batch_get_items_ordered_rust_impl,
        )
        items_ordered = cast(
            list[DynamoItem | None],
            batch_get_ordered_impl(
                table_name=self.table_name,
                pk_sk_pairs=pk_sk_pairs,
                consistent_read=consistent_read,
                max_unprocessed_retries=MAX_UNPROCESSED_RETRIES,
                decimal_context=DYNAMODB_CONTEXT,
                binary_type=Binary,
                fallback_deserializer=type_deserializer,
                **self._sdk_auth_kwargs(),
            ),
        )
        return items_ordered

    def put_item(
        self,
        item: DynamoItem,
        can_overwrite: bool = True,
    ) -> dict[str, object]:
        put_item_impl = _require_rust_impl(
            "dynamodb_sdk_put_item",
            _dynamodb_sdk_put_item_rust_impl,
        )
        try:
            put_item_impl(
                table_name=self.table_name,
                item=item,
                can_overwrite=can_overwrite,
                **self._sdk_auth_kwargs(),
            )
            return {}
        except Exception as e:
            if (not can_overwrite) and "ConditionalCheckFailedException" in str(e):
                pk = item["_pk"]
                sk = item["_sk"]
                raise DynamoDBError(
                    message=(
                        f"Item already exists with _pk='{pk}' and _sk='{sk}'. "
                        "Check your partition key, sort key, and unique key fields."
                    ),
                ) from e
            raise

    @classmethod
    def get_update_expression_attrs_pair(
        cls,
        item: DynamoItem,
    ) -> tuple[str, dict[str, str], dict[str, object]]:
        """Generates DynamoDB update expression and attribute maps from an item dictionary.

        Args:
            item: Dictionary containing the fields and values to update.

        Returns:
            A tuple containing:
                - Update expression string starting with "set"
                - Dictionary mapping attribute name placeholders to actual names
                - Dictionary mapping attribute value placeholders to actual values

        Example:
            For item {"name": "John", "age": 30}, returns:
            ("set #key0=:val0, #key1=:val1",
             {"#key0": "name", "#key1": "age"},
             {":val0": "John", ":val1": 30})
        """
        update_expression_impl = _require_rust_impl(
            "get_update_expression_attrs_pair",
            _get_update_expression_attrs_pair_rust_impl,
        )
        expression, attr_names, attr_values = update_expression_impl(item)
        return (
            cast(str, expression),
            cast(dict[str, str], attr_names),
            cast(dict[str, object], attr_values),
        )

    @classmethod
    def _build_projection_expression(
        cls,
        projection_fields: list[str] | None,
        required_fields: list[str],
        required_first: bool,
    ) -> tuple[str | None, dict[str, str]]:
        projection_impl = _require_rust_impl(
            "build_projection_expression",
            _build_projection_expression_rust_impl,
        )
        projection_expression, expression_names = projection_impl(
            projection_fields,
            required_fields,
            required_first,
        )
        return (
            cast(str | None, projection_expression),
            cast(dict[str, str], expression_names),
        )

    def update_item(self, pk: str, sk: str, item: DynamoItem) -> dict[str, object]:
        """Update an item.
        If the item to update does not exist in the DB, an error will occur.
        :param pk:
        :param sk:
        :param item:
        :return:
        """
        if not item:
            raise DynamoDBError("No fields to update")

        expression, attr_names, attr_values = self.get_update_expression_attrs_pair(
            item)

        attr_names["#pk"] = "_pk"
        attr_names["#sk"] = "_sk"
        condition_expression = "attribute_exists(#pk) AND attribute_exists(#sk)"
        update_item_impl = _require_rust_impl(
            "dynamodb_sdk_update_item",
            _dynamodb_sdk_update_item_rust_impl,
        )

        try:
            wire_attributes = update_item_impl(
                table_name=self.table_name,
                pk=pk,
                sk=sk,
                update_expression=expression,
                expression_attribute_values=attr_values,
                expression_attribute_names=attr_names,
                condition_expression=condition_expression,
                decimal_context=DYNAMODB_CONTEXT,
                binary_type=Binary,
                fallback_deserializer=type_deserializer,
                **self._sdk_auth_kwargs(),
            )
        except Exception as e:
            if "ConditionalCheckFailedException" in str(e):
                msg = f"Cannot find item with given keys: _pk='{pk}', _sk='{sk}'"
                raise DynamoDBError(msg) from e
            msg = f"Failed to update item with keys _pk='{pk}', _sk='{sk}': {e!s}"
            raise DynamoDBError(msg) from e

        attributes = cast(dict[str, object], wire_attributes if wire_attributes is not None else {})
        return {"Attributes": attributes}

    def batch_put(
        self,
        items: list[DynamoItem],
        can_overwrite: bool = False,
    ) -> bool:
        if not can_overwrite:
            for item in items:
                self.put_item(item=item, can_overwrite=False)
            return True

        batch_write_impl = _require_rust_impl(
            "dynamodb_sdk_batch_write",
            _dynamodb_sdk_batch_write_rust_impl,
        )
        return bool(
            batch_write_impl(
                table_name=self.table_name,
                put_items=items,
                delete_keys=[],
                max_unprocessed_retries=MAX_UNPROCESSED_RETRIES,
                **self._sdk_auth_kwargs(),
            ),
        )

    def delete_item(
        self,
        pk: str,
        sk: str,
    ) -> dict[str, object]:
        """Delete single item.

        Args:
            pk: Partition key value
            sk: Sort key value

        Returns:
            Dict containing the deleted item attributes

        Raises:
            DynamoDBError: If the item does not exist
        """
        delete_item_impl = _require_rust_impl(
            "dynamodb_sdk_delete_item",
            _dynamodb_sdk_delete_item_rust_impl,
        )
        wire_attributes = delete_item_impl(
            table_name=self.table_name,
            pk=pk,
            sk=sk,
            decimal_context=DYNAMODB_CONTEXT,
            binary_type=Binary,
            fallback_deserializer=type_deserializer,
            **self._sdk_auth_kwargs(),
        )
        if wire_attributes is None:
            msg = f"Cannot find item with given keys: _pk='{pk}', _sk='{sk}'"
            raise DynamoDBError(msg)

        attributes = cast(dict[str, object], wire_attributes)
        return {"Attributes": attributes}

    def batch_delete(self, pk_sk_pairs: list[tuple[str, str]]) -> bool:
        """Delete multiple items from DynamoDB in a batch operation.

        This method efficiently deletes multiple items in parallel using DynamoDB's batch writer.
        The batch writer automatically handles throttling, retries, and batching of requests.

        Args:
            pk_sk_pairs: List of dictionaries containing partition key and sort key pairs.
                Each dictionary should have the format:
                {
                    '_pk': 'partition_key_value',
                    '_sk': 'sort_key_value'
                }

        Returns:
            bool: True if all deletions were successful

        Note:
            DynamoDB has a limit of 25 items per batch write operation.
            The batch_writer handles splitting larger batches automatically.

        """
        normalize_impl = _require_rust_impl(
            "normalize_pk_sk_pairs",
            _normalize_pk_sk_pairs_rust_impl,
        )
        delete_keys = cast(
            list[dict[str, dict[str, str]]],
            normalize_impl(pk_sk_pairs),
        )
        batch_write_impl = _require_rust_impl(
            "dynamodb_sdk_batch_write",
            _dynamodb_sdk_batch_write_rust_impl,
        )
        return bool(
            batch_write_impl(
                table_name=self.table_name,
                put_items=[],
                delete_keys=delete_keys,
                max_unprocessed_retries=MAX_UNPROCESSED_RETRIES,
                **self._sdk_auth_kwargs(),
            ),
        )

    def query_items(
        self,
        partition_key_name: str,
        partition_key_value: str,
        sort_condition: str | None = None,
        sort_key_name: str | None = None,
        sort_key_value: object | None = None,
        sort_key_second_value: object | None = None,
        filters: list[FilterDict] | None = None,
        start_key: DynamoKey | None = None,
        reverse: bool = False,
        limit: int = 100,
        consistent_read: bool = False,
        index_name: str | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage:
        """Query items with complex filtering."""
        # Build key condition expression
        if isinstance(partition_key_value, float):
            partition_key_value = Decimal(str(partition_key_value))

        key_expression = Key(name=partition_key_name).eq(
            value=partition_key_value)

        if sort_condition and sort_key_name and sort_key_value is not None:
            # Convert float values to Decimal for DynamoDB compatibility
            if isinstance(sort_key_value, float):
                sort_key_value = Decimal.from_float(sort_key_value)
            if isinstance(sort_key_second_value, float):
                sort_key_second_value = Decimal.from_float(sort_key_second_value)

            if sort_condition == "eq":
                key_expression &= Key(name=sort_key_name).eq(
                    value=sort_key_value)
            elif sort_condition == "lte":
                key_expression &= Key(name=sort_key_name).lte(
                    value=sort_key_value)
            elif sort_condition == "lt":
                key_expression &= Key(name=sort_key_name).lt(
                    value=sort_key_value)
            elif sort_condition == "gte":
                key_expression &= Key(name=sort_key_name).gte(
                    value=sort_key_value)
            elif sort_condition == "gt":
                key_expression &= Key(name=sort_key_name).gt(
                    value=sort_key_value)
            elif sort_condition == "btw":
                key_expression &= Key(name=sort_key_name).between(
                    low_value=sort_key_value,
                    high_value=sort_key_second_value,
                )
            elif sort_condition == "stw":
                key_expression &= Key(
                    name=sort_key_name).begins_with(value=sort_key_value)

        # Build filter expression
        filter_expression = None

        # Process simple filters first
        if filters:
            for ft in filters:
                attr_expr = self._get_filter_expression(filter_dict=ft)
                if filter_expression:
                    filter_expression &= attr_expr
                else:
                    filter_expression = attr_expr

        # Process recursive filters and combine with simple filters
        if recursive_filters:
            recursive_expr = self._get_recursive_filter_expression(
                recursive_filters=recursive_filters)
            if filter_expression:
                # Combine filters and recursive_filters with AND
                filter_expression &= recursive_expr
            else:
                filter_expression = recursive_expr

        expression_builder = ConditionExpressionBuilder()
        key_built = expression_builder.build_expression(
            key_expression,
            is_key_condition=True,
        )
        expression_attribute_names = dict(key_built.attribute_name_placeholders)
        expression_attribute_values = dict(key_built.attribute_value_placeholders)

        filter_expression_string: str | None = None
        if filter_expression:
            filter_built = expression_builder.build_expression(filter_expression)
            filter_expression_string = filter_built.condition_expression
            expression_attribute_names.update(filter_built.attribute_name_placeholders)
            expression_attribute_values.update(filter_built.attribute_value_placeholders)

        projection_expression: str | None = None
        if projection_fields:
            projection_expression, projection_names = self._build_projection_expression(
                projection_fields=projection_fields,
                required_fields=["_pk", "_sk", "_ptn"],
                required_first=True,
            )
            expression_attribute_names.update(projection_names)

        query_impl = _require_rust_impl(
            "dynamodb_sdk_query_items",
            _dynamodb_sdk_query_items_rust_impl,
        )
        query_expression_values = cast(
            dict[str, object] | None,
            expression_attribute_values or None,
        )
        query_start_key = cast(
            dict[str, object] | None,
            start_key,
        )

        wire_response = cast(
            dict[str, object],
            query_impl(
                table_name=self.table_name,
                key_condition_expression=key_built.condition_expression,
                expression_attribute_names=expression_attribute_names or None,
                expression_attribute_values=query_expression_values,
                filter_expression=filter_expression_string,
                index_name=index_name,
                exclusive_start_key=query_start_key,
                limit=limit,
                consistent_read=(False if index_name else consistent_read),
                scan_index_forward=not reverse,
                projection_expression=projection_expression,
                decimal_context=DYNAMODB_CONTEXT,
                binary_type=Binary,
                fallback_deserializer=type_deserializer,
                **self._sdk_auth_kwargs(),
            ),
        )
        items = cast(list[DynamoItem], wire_response.get("Items", []))
        last_key = cast(DynamoKey | None, wire_response.get("LastEvaluatedKey"))

        return {
            "Items": cast(list[DynamoItem], items),
            "LastEvaluatedKey": cast(DynamoKey | None, last_key),
        }

    def _get_filter_expression(
        self,
        filter_dict: FilterDict | RecursiveFilterBase,
    ) -> ConditionBase:
        """Convert filter dict to DynamoDB filter expression."""
        field = filter_dict["field"]
        value = filter_dict.get("value")
        condition = filter_dict["condition"]
        second_value = filter_dict.get("second_value")

        if isinstance(value, float):
            value = Decimal(str(value))
        if isinstance(second_value, float):
            second_value = Decimal(str(second_value))

        attr = Attr(field)

        if condition == "eq":
            return attr.eq(value)
        if condition == "neq":
            return attr.ne(value)
        if condition == "lte":
            return attr.lte(value)
        if condition == "lt":
            return attr.lt(value)
        if condition == "gte":
            return attr.gte(value)
        if condition == "gt":
            return attr.gt(value)
        if condition == "btw":
            if second_value is None:
                raise ValueError("second_value is required for 'btw' condition")
            return attr.between(value, second_value)
        if condition == "not_btw":
            if second_value is None:
                raise ValueError("second_value is required for 'not_btw' condition")
            return ~attr.between(value, second_value)
        if condition == "stw":
            return attr.begins_with(value)
        if condition == "not_stw":
            return ~attr.begins_with(value)
        if condition == "is_in":
            return attr.is_in(value)
        if condition == "is_not_in":
            return ~attr.is_in(value)
        if condition == "contains":
            return attr.contains(value)
        if condition == "not_contains":
            return ~attr.contains(value)
        if condition == "exist":
            return attr.exists()
        if condition == "not_exist":
            return attr.not_exists()
        msg = f"Invalid filter condition: {condition}"
        raise ValueError(msg)

    def _get_recursive_filter_expression(
        self,
        recursive_filters: RecursiveFilterNode | RecursiveFilterBase,
    ) -> ConditionBase:
        """Convert recursive filter dict to DynamoDB filter expression."""
        if "field" in recursive_filters:
            return self._get_filter_expression(cast(RecursiveFilterBase, recursive_filters))

        node_obj = cast(dict[str, object], recursive_filters)
        left_node = node_obj.get("left")
        right_node = node_obj.get("right")
        operation = node_obj.get("operation")
        if left_node is None or right_node is None or operation not in {"and", "or"}:
            raise ValueError("Invalid recursive filter format")

        left = self._get_recursive_filter_expression(cast(RecursiveFilterNode | RecursiveFilterBase, left_node))
        right = self._get_recursive_filter_expression(cast(RecursiveFilterNode | RecursiveFilterBase, right_node))
        if operation == "and":
            return left & right
        if operation == "or":
            return left | right
        raise ValueError("Invalid recursive filter format")

    def scan_table(
        self,
        filters: list[FilterDict] | None = None,
        recursive_filters: RecursiveFilterNode | None = None,
        start_key: DynamoKey | None = None,
        limit: int | None = None,
        projection_fields: list[str] | None = None,
    ) -> QueryPage:
        """Scan table with optional filtering.

        Args:
            table_name: Name of the DynamoDB table to scan
            filters: List of filter conditions to apply. Each filter is a dict with:
                - field: Name of the attribute to filter on
                - condition: Filter condition (eq, lt, gt etc)
                - value: Value to compare against
            recursive_filters: Nested filter conditions with AND/OR operations
            start_key: Key to start scan from for pagination
            limit: Maximum number of items to return

        Returns:
            Dict containing scan results with Items and LastEvaluatedKey

        """
        # Build filter expression from conditions
        filter_expression = None

        # Process simple filters first
        if filters:
            # Combine multiple filter conditions with AND
            for ft in filters:
                attr_to_add = self._get_filter_expression(ft)
                if filter_expression:
                    filter_expression &= attr_to_add
                else:
                    filter_expression = attr_to_add

        # Process recursive filters and combine with simple filters
        if recursive_filters:
            # Handle nested filter conditions with AND/OR operations
            recursive_expr = self._get_recursive_filter_expression(
                recursive_filters)
            if filter_expression:
                # Combine filters and recursive_filters with AND
                filter_expression &= recursive_expr
            else:
                filter_expression = recursive_expr

        expression_attribute_names: dict[str, str] = {}
        expression_attribute_values: dict[str, object] = {}
        filter_expression_string: str | None = None
        if filter_expression:
            built_filter = ConditionExpressionBuilder().build_expression(
                filter_expression,
            )
            filter_expression_string = built_filter.condition_expression
            expression_attribute_names.update(built_filter.attribute_name_placeholders)
            expression_attribute_values.update(built_filter.attribute_value_placeholders)

        # Build projection expression if requested
        projection_expression: str | None = None
        if projection_fields:
            projection_expression, projection_names = self._build_projection_expression(
                projection_fields=projection_fields,
                required_fields=["_pk", "_sk", "_ptn"],
                required_first=False,
            )
            expression_attribute_names.update(projection_names)

        scan_impl = _require_rust_impl(
            "dynamodb_sdk_scan_items",
            _dynamodb_sdk_scan_items_rust_impl,
        )
        scan_expression_values = cast(
            dict[str, object] | None,
            expression_attribute_values or None,
        )
        scan_start_key = cast(
            dict[str, object] | None,
            start_key,
        )
        wire_response = cast(
            dict[str, object],
            scan_impl(
                table_name=self.table_name,
                expression_attribute_names=expression_attribute_names or None,
                expression_attribute_values=scan_expression_values,
                filter_expression=filter_expression_string,
                exclusive_start_key=scan_start_key,
                limit=limit,
                projection_expression=projection_expression,
                decimal_context=DYNAMODB_CONTEXT,
                binary_type=Binary,
                fallback_deserializer=type_deserializer,
                **self._sdk_auth_kwargs(),
            ),
        )
        items = cast(list[DynamoItem], wire_response.get("Items", []))
        last_key = cast(DynamoKey | None, wire_response.get("LastEvaluatedKey"))

        return {
            "Items": cast(list[DynamoItem], items),
            "LastEvaluatedKey": cast(DynamoKey | None, last_key),
        }
