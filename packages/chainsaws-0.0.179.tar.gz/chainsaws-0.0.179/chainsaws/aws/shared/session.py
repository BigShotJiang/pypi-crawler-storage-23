"""Functions for common AWS services usage, such as boto3 Session management."""
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping, Optional, TypedDict

import boto3


class AWSCredentialsDict(TypedDict, total=False):
    """Dictionary-shaped AWS credential input."""

    aws_access_key_id: str
    aws_secret_access_key: str
    aws_session_token: str
    region_name: str
    profile_name: str
    access_key_id: str
    secret_access_key: str
    session_token: str
    AccessKeyId: str
    SecretAccessKey: str
    SessionToken: str


@dataclass
class AWSCredentials:
    """AWS credentials configuration."""

    aws_access_key_id: Optional[str] = None  # AWS access key ID
    aws_secret_access_key: Optional[str] = None  # AWS secret access key
    aws_session_token: Optional[str] = None  # AWS session token
    region_name: Optional[str] = field(
        default="ap-northeast-2")  # AWS region name
    profile_name: Optional[str] = None  # AWS profile name

    def to_dict(self, exclude_none: bool = False) -> dict[str, Any]:
        """Convert the model to a dictionary.

        Args:
            exclude_none (bool): Whether to exclude None values from the output

        Returns:
            dict[str, Any]: The model as a dictionary
        """
        result = asdict(self)
        if exclude_none:
            return {k: v for k, v in result.items() if v is not None}
        return result


type AWSCredentialsInput = AWSCredentials | AWSCredentialsDict | Mapping[str, str]


def _normalize_credentials(credentials: AWSCredentialsInput) -> AWSCredentials:
    """Normalize various credential inputs to AWSCredentials."""
    if isinstance(credentials, AWSCredentials):
        return credentials

    return AWSCredentials(
        aws_access_key_id=(
            credentials.get("aws_access_key_id")
            or credentials.get("access_key_id")
            or credentials.get("AccessKeyId")
        ),
        aws_secret_access_key=(
            credentials.get("aws_secret_access_key")
            or credentials.get("secret_access_key")
            or credentials.get("SecretAccessKey")
        ),
        aws_session_token=(
            credentials.get("aws_session_token")
            or credentials.get("session_token")
            or credentials.get("SessionToken")
        ),
        region_name=credentials.get("region_name"),
        profile_name=credentials.get("profile_name"),
    )


def get_boto_session(credentials: Optional[AWSCredentialsInput] = None) -> boto3.Session:
    """Returns a boto3 session. This function is wrapped to allow for future customization.

    Args:
        credentials (Optional[AWSCredentialsInput]): Validated AWS credentials

    Returns:
        boto3.Session: Configured AWS session

    Warning:
        Using hardcoded credentials is not recommended for security reasons.
        Please use AWS IAM environment profiles instead.

    """
    if credentials:
        normalized = _normalize_credentials(credentials)
        return boto3.Session(**normalized.to_dict(exclude_none=True))

    return boto3.Session()
