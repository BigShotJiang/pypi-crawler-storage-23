from typing import TypedDict, NotRequired


class SelectRecordsEvent(TypedDict):
    """Records event in SelectObjectContent payload."""

    Payload: bytes


class SelectObjectContentPayloadEvent(TypedDict, total=False):
    """Single payload event in SelectObjectContent response."""

    Records: SelectRecordsEvent
    Stats: NotRequired[dict[str, object]]
    Progress: NotRequired[dict[str, object]]
    Continuation: NotRequired[dict[str, object]]
    End: NotRequired[dict[str, object]]


class SelectObjectContentResponse(TypedDict):
    """Response shape for S3 SelectObjectContent."""

    Payload: list[SelectObjectContentPayloadEvent]
