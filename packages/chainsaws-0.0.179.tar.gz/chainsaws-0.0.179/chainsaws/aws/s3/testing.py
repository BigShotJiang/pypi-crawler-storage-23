"""Reusable test helpers for S3 API.

These helpers are intended for both this repository and external projects.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Optional

from chainsaws.aws.s3._s3_inmemory_internal import InMemoryS3Internal
from chainsaws.aws.s3.s3 import S3API
from chainsaws.aws.s3.s3_models import S3APIConfig, create_s3_api_config


def create_inmemory_s3_api(
    bucket_name: str = "test-bucket",
    config: Optional[S3APIConfig] = None,
) -> S3API:
    """Create an S3API instance backed by in-memory internal storage."""
    config_obj = config or create_s3_api_config()
    internal = InMemoryS3Internal(bucket_name=bucket_name, config=config_obj)
    return S3API(bucket_name=bucket_name, config=config_obj, internal=internal)


def seed_s3_object(
    api: S3API,
    object_key: str,
    data: bytes | str,
    *,
    content_type: str | None = None,
    tags: Optional[dict[str, str]] = None,
) -> None:
    """Seed an object into the in-memory S3 backend for tests."""
    object_data = data.encode("utf-8") if isinstance(data, str) else data
    api.s3.upload_file(
        {"bucket_name": api.bucket_name, "file_name": object_key, "content_type": content_type},
        object_data,
    )
    if tags:
        api.s3.put_object_tags(object_key=object_key, tags=deepcopy(tags))


__all__ = [
    "InMemoryS3Internal",
    "create_inmemory_s3_api",
    "seed_s3_object",
]
