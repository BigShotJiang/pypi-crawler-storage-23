from __future__ import annotations

import hashlib
import io
import uuid
from copy import deepcopy
from pathlib import Path
from typing import BinaryIO, Callable, Optional, Union
import orjson

from chainsaws.aws.s3.s3_models import (
    BucketACL,
    ContentType,
    FileUploadConfig,
    MetadataDirective,
    ObjectListConfig,
    PresignedUrlConfig,
    S3APIConfig,
    S3ServerSideEncryption,
    S3StorageClass,
)


class InMemoryS3Internal:
    """In-memory S3 internal adapter for tests."""

    __slots__ = (
        "bucket_name",
        "config",
        "region",
        "_objects",
        "_content_types",
        "_tags",
        "_multipart_uploads",
        "_bucket_policy",
        "_bucket_notification_config",
        "_accelerate_status",
        "_website_config",
    )

    def __init__(self, bucket_name: str, config: Optional[S3APIConfig] = None) -> None:
        self.bucket_name = bucket_name
        self.config = config or S3APIConfig()
        self.region = self.config.region

        self._objects: dict[str, bytes] = {}
        self._content_types: dict[str, str] = {}
        self._tags: dict[str, dict[str, str]] = {}
        self._multipart_uploads: dict[str, dict[str, object]] = {}
        self._bucket_policy: str | None = None
        self._bucket_notification_config: dict[str, object] = {
            "LambdaFunctionConfigurations": []
        }
        self._accelerate_status = "Suspended"
        self._website_config: dict[str, object] = {}

    @staticmethod
    def _read_bytes(data: Union[bytes, BinaryIO]) -> bytes:
        if isinstance(data, bytes):
            return data
        return data.read()

    @staticmethod
    def _etag_for(data: bytes) -> str:
        return f"\"{hashlib.md5(data).hexdigest()}\""

    def init_bucket(self, config: dict[str, object]) -> None:
        del config
        return None

    def upload_binary(self, file_name: str, binary: bytes) -> None:
        self._objects[file_name] = binary

    def delete_binary(self, file_name: str) -> dict[str, object]:
        self._objects.pop(file_name, None)
        self._content_types.pop(file_name, None)
        self._tags.pop(file_name, None)
        return {"DeleteMarker": True}

    def download_binary(self, file_name: str) -> bytes:
        return self._objects[file_name]

    def upload_file(
        self,
        config: FileUploadConfig,
        file_bytes: Union[bytes, BinaryIO],
    ) -> dict[str, object]:
        data = self._read_bytes(file_bytes)
        key = config["file_name"]
        self._objects[key] = data
        content_type = config.get("content_type")
        if content_type:
            self._content_types[key] = content_type
        return {"ETag": self._etag_for(data)}

    def list_objects_v2(self, config: ObjectListConfig) -> dict[str, object]:
        prefix = config.get("prefix") or ""
        limit = int(config.get("limit", 1000))
        continuation_token = config.get("continuation_token")
        start_after = config.get("start_after")

        keys = sorted(key for key in self._objects if key.startswith(prefix))
        if start_after and not continuation_token:
            keys = [key for key in keys if key > start_after]

        start_idx = int(continuation_token) if continuation_token else 0
        start_idx = max(0, min(start_idx, len(keys)))
        selected_keys = keys[start_idx:start_idx + limit]
        next_idx = start_idx + len(selected_keys)
        next_token = str(next_idx) if next_idx < len(keys) else None

        contents = [
            {
                "Key": key,
                "Size": len(self._objects[key]),
                "ETag": self._etag_for(self._objects[key]),
            }
            for key in selected_keys
        ]

        response: dict[str, object] = {
            "Contents": contents,
            "IsTruncated": next_token is not None,
        }
        if next_token is not None:
            response["NextContinuationToken"] = next_token
        return response

    def create_presigned_url(self, config: PresignedUrlConfig) -> str:
        method = config["client_method"]
        key = config["object_name"]
        expires = config.get("expiration", 3600)
        return f"https://inmemory-s3.local/{self.bucket_name}/{key}?method={method}&expires={expires}"

    def head_object(self, key: str) -> Optional[dict[str, object]]:
        if key not in self._objects:
            return None
        return {
            "ContentLength": len(self._objects[key]),
            "ContentType": self._content_types.get(key, "application/octet-stream"),
            "ETag": self._etag_for(self._objects[key]),
        }

    def get_object_tags(self, object_key: str) -> dict[str, object]:
        tags = self._tags.get(object_key, {})
        return {"TagSet": [{"Key": key, "Value": value} for key, value in tags.items()]}

    def put_object_tags(self, object_key: str, tags: dict[str, str]) -> dict[str, object]:
        self._tags[object_key] = dict(tags)
        return {"VersionId": "1"}

    def copy_object(
        self,
        source_key: str,
        dest_key: str,
        dest_bucket: Optional[str] = None,
        acl: BucketACL = "private",
        metadata_directive: Optional[MetadataDirective] = None,
        metadata: Optional[dict[str, str]] = None,
        content_type: Optional[ContentType] = None,
        cache_control: Optional[str] = None,
        content_disposition: Optional[str] = None,
        content_encoding: Optional[str] = None,
        storage_class: Optional[S3StorageClass] = None,
        server_side_encryption: Optional[S3ServerSideEncryption] = None,
        ssekms_key_id: Optional[str] = None,
    ) -> dict[str, object]:
        del (
            dest_bucket,
            acl,
            metadata_directive,
            metadata,
            content_type,
            cache_control,
            content_disposition,
            content_encoding,
            storage_class,
            server_side_encryption,
            ssekms_key_id,
        )
        self._objects[dest_key] = self._objects[source_key]
        if source_key in self._content_types:
            self._content_types[dest_key] = self._content_types[source_key]
        return {"CopyObjectResult": {"ETag": self._etag_for(self._objects[dest_key])}}

    def get_object_metadata(
        self,
        object_key: str,
        version_id: Optional[str] = None,
    ) -> dict[str, object]:
        del version_id
        head = self.head_object(object_key)
        if head is None:
            raise FileNotFoundError(object_key)
        return head

    def create_multipart_upload(
        self,
        object_key: str,
        content_type: Optional[ContentType] = None,
        acl: Optional[BucketACL] = None,
        metadata: Optional[dict[str, str]] = None,
        cache_control: Optional[str] = None,
        content_disposition: Optional[str] = None,
        content_encoding: Optional[str] = None,
        storage_class: Optional[S3StorageClass] = None,
        server_side_encryption: Optional[S3ServerSideEncryption] = None,
        ssekms_key_id: Optional[str] = None,
    ) -> dict[str, object]:
        del (
            acl,
            metadata,
            cache_control,
            content_disposition,
            content_encoding,
            storage_class,
            server_side_encryption,
            ssekms_key_id,
        )
        upload_id = uuid.uuid4().hex
        self._multipart_uploads[upload_id] = {
            "object_key": object_key,
            "content_type": content_type,
            "parts": {},
        }
        return {"UploadId": upload_id}

    def upload_part(
        self,
        object_key: str,
        upload_id: str,
        part_number: int,
        body: Union[bytes, BinaryIO],
    ) -> dict[str, object]:
        upload = self._multipart_uploads[upload_id]
        if upload["object_key"] != object_key:
            raise ValueError("object_key does not match multipart upload")
        parts = upload["parts"]
        assert isinstance(parts, dict)
        part_data = self._read_bytes(body)
        parts[part_number] = part_data
        return {"ETag": self._etag_for(part_data)}

    def complete_multipart_upload(
        self,
        object_key: str,
        upload_id: str,
        parts: list[dict[str, object]],
    ) -> dict[str, object]:
        upload = self._multipart_uploads[upload_id]
        if upload["object_key"] != object_key:
            raise ValueError("object_key does not match multipart upload")
        part_store = upload["parts"]
        assert isinstance(part_store, dict)
        ordered_numbers = [int(part["PartNumber"]) for part in sorted(parts, key=lambda it: int(it["PartNumber"]))]
        combined = b"".join(part_store[num] for num in ordered_numbers)
        self._objects[object_key] = combined
        content_type = upload.get("content_type")
        if isinstance(content_type, str) and content_type:
            self._content_types[object_key] = content_type
        self._multipart_uploads.pop(upload_id, None)
        return {"ETag": self._etag_for(combined)}

    def abort_multipart_upload(
        self,
        object_key: str,
        upload_id: str,
    ) -> None:
        del object_key
        self._multipart_uploads.pop(upload_id, None)

    def put_bucket_policy(self, policy: str) -> dict[str, object]:
        self._bucket_policy = policy
        return {}

    def get_bucket_policy(self) -> dict[str, str]:
        return {"Policy": self._bucket_policy or "{}"}

    def update_bucket_policy(self, policy: Union[str, dict[str, object]]) -> None:
        self._bucket_policy = policy if isinstance(policy, str) else str(policy)

    def delete_bucket_policy(self) -> None:
        self._bucket_policy = None

    def put_bucket_notification_configuration(self, config: dict[str, object]) -> None:
        self._bucket_notification_config = deepcopy(config)

    def get_bucket_notification_configuration(self) -> dict[str, object]:
        return deepcopy(self._bucket_notification_config)

    def put_public_access_block(
        self,
        public_access_block_configuration: dict[str, bool],
    ) -> None:
        del public_access_block_configuration
        return None

    def wait_for_public_access_block_configuration(
        self,
        max_attempts: int = 10,
        delay: float = 0.5,
    ) -> None:
        del max_attempts, delay
        return None

    def get_bucket_accelerate_configuration(self) -> dict[str, str]:
        return {"Status": self._accelerate_status}

    def put_bucket_accelerate_configuration(self, status: str) -> None:
        self._accelerate_status = status

    def download_file(
        self,
        object_key: str,
        file_path: Union[str, Path],
        max_retries: int = 3,
        retry_delay: float = 1.0,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        chunk_size: int = 8 * 1024 * 1024,
    ) -> None:
        del max_retries, retry_delay
        data = self._objects[object_key]
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        downloaded = 0
        with path.open("wb") as file_obj:
            for idx in range(0, len(data), chunk_size):
                chunk = data[idx:idx + chunk_size]
                file_obj.write(chunk)
                downloaded += len(chunk)
                if progress_callback:
                    progress_callback(downloaded, len(data))

    def get_object(self, object_key: str) -> dict[str, object]:
        if object_key not in self._objects:
            raise FileNotFoundError(object_key)
        data = self._objects[object_key]
        return {
            "Body": io.BytesIO(data),
            "ContentLength": len(data),
            "ContentType": self._content_types.get(object_key, "application/octet-stream"),
            "ETag": self._etag_for(data),
        }

    def select_object_content(self, config: dict[str, object]) -> list[dict[str, object]]:
        object_key = str(config["object_key"])
        raw_data = self._objects.get(object_key, b"")
        records: list[dict[str, object]] = []
        for line in raw_data.decode("utf-8").splitlines():
            line = line.strip()
            if line:
                records.append(orjson.loads(line))
        return records

    def check_key_exists(self, object_key: str) -> bool:
        return object_key in self._objects

    def get_bucket_website(self) -> dict[str, object]:
        return deepcopy(self._website_config)

    def put_bucket_website(self, website_config: dict[str, object]) -> None:
        self._website_config = deepcopy(website_config)

    def delete_bucket_website(self) -> None:
        self._website_config = {}

    def delete_object(self, object_key: str) -> bool:
        existed = object_key in self._objects
        self._objects.pop(object_key, None)
        self._content_types.pop(object_key, None)
        self._tags.pop(object_key, None)
        return existed

    def delete_objects(self, object_keys: list[str]) -> dict[str, object]:
        deleted: list[dict[str, str]] = []
        errors: list[dict[str, str]] = []
        for key in object_keys:
            if self.delete_object(key):
                deleted.append({"Key": key})
            else:
                errors.append({"Key": key, "Message": "NotFound"})
        response: dict[str, object] = {"Deleted": deleted}
        if errors:
            response["Errors"] = errors
        return response
