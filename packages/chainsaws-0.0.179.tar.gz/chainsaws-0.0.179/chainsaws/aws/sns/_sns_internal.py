"""Internal implementation of AWS SNS client."""

import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import boto3
from botocore.exceptions import ClientError

from chainsaws.aws.sns.sns_exception import SNSException
from chainsaws.aws.sns.sns_models import SNSMessageAttributeValueDict, SNSPublishMessageDict

logger = logging.getLogger(__name__)
_MAX_PUBLISH_BATCH_SIZE = 10
_MAX_BATCH_WORKERS = 8
_MAX_RETRY_ATTEMPTS = 3
_RETRY_BASE_DELAY_SECONDS = 0.2
_RETRYABLE_ERROR_CODES = frozenset(
    {
        "Throttled",
        "Throttling",
        "ThrottlingException",
        "TooManyRequestsException",
        "InternalErrorException",
        "RequestTimeout",
        "RequestTimeoutException",
        "ServiceUnavailable",
        "InternalFailure",
    },
)


def _thread_worker_count(items_count: int) -> int:
    return min(_MAX_BATCH_WORKERS, max(1, items_count))


def _is_retryable_client_error(error: ClientError) -> bool:
    code = str(error.response.get("Error", {}).get("Code", ""))
    return code in _RETRYABLE_ERROR_CODES


class SNS:
    """Internal SNS client implementation."""

    def __init__(
        self,
        boto3_session: boto3.Session | None = None,
        region_name: str | None = None,
    ) -> None:
        self.session = boto3_session or boto3.Session()
        self.client = self.session.client("sns", region_name=region_name)

    def _call_with_retries(self, method_name: str, **kwargs: Any) -> dict[str, Any]:
        """Call SNS client method with basic exponential backoff."""
        method = getattr(self.client, method_name)
        last_error: ClientError | None = None
        for attempt in range(_MAX_RETRY_ATTEMPTS):
            try:
                return method(**kwargs)
            except ClientError as error:
                last_error = error
                if not _is_retryable_client_error(error):
                    raise
                if attempt == _MAX_RETRY_ATTEMPTS - 1:
                    break
                time.sleep(_RETRY_BASE_DELAY_SECONDS * (2**attempt))

        assert last_error is not None
        raise last_error

    def create_topic(
        self,
        name: str,
        attributes: dict[str, str] | None = None,
        tags: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Create an SNS topic."""
        try:
            kwargs: dict[str, Any] = {"Name": name}
            if attributes:
                kwargs["Attributes"] = attributes
            if tags:
                kwargs["Tags"] = [{"Key": k, "Value": v} for k, v in tags.items()]

            response = self._call_with_retries("create_topic", **kwargs)
            topic_arn = response["TopicArn"]
            attrs = self._call_with_retries("get_topic_attributes", TopicArn=topic_arn)
            return attrs["Attributes"]

        except ClientError as e:
            logger.exception("Failed to create SNS topic: %s", name)
            raise SNSException(f"Failed to create SNS topic: {str(e)}") from e

    def delete_topic(self, topic_arn: str) -> None:
        """Delete an SNS topic."""
        try:
            self._call_with_retries("delete_topic", TopicArn=topic_arn)
        except ClientError as e:
            logger.exception("Failed to delete SNS topic: %s", topic_arn)
            raise SNSException(f"Failed to delete SNS topic: {str(e)}") from e

    def publish(
        self,
        topic_arn: str | None,
        message: str,
        subject: str | None = None,
        message_attributes: dict[str, SNSMessageAttributeValueDict] | None = None,
        message_structure: str | None = None,
        message_group_id: str | None = None,
        message_deduplication_id: str | None = None,
        target_arn: str | None = None,
        phone_number: str | None = None,
    ) -> str:
        """Publish a message to SNS destination."""
        try:
            destinations = [topic_arn, target_arn, phone_number]
            if sum(value is not None for value in destinations) != 1:
                msg = (
                    "Exactly one destination must be set: "
                    "topic_arn, target_arn, or phone_number"
                )
                raise SNSException(msg)

            kwargs: dict[str, Any] = {"Message": message}
            if topic_arn is not None:
                kwargs["TopicArn"] = topic_arn
            if target_arn is not None:
                kwargs["TargetArn"] = target_arn
            if phone_number is not None:
                kwargs["PhoneNumber"] = phone_number
            if subject is not None:
                kwargs["Subject"] = subject
            if message_attributes is not None:
                kwargs["MessageAttributes"] = message_attributes
            if message_structure is not None:
                kwargs["MessageStructure"] = message_structure
            if message_group_id is not None:
                kwargs["MessageGroupId"] = message_group_id
            if message_deduplication_id is not None:
                kwargs["MessageDeduplicationId"] = message_deduplication_id

            response = self._call_with_retries("publish", **kwargs)
            return response["MessageId"]

        except ClientError as e:
            logger.exception("Failed to publish message via SNS destination")
            raise SNSException(f"Failed to publish message: {str(e)}") from e

    def subscribe(
        self,
        topic_arn: str,
        protocol: str,
        endpoint: str,
        attributes: dict[str, str] | None = None,
    ) -> str:
        """Subscribe an endpoint to an SNS topic."""
        try:
            kwargs: dict[str, Any] = {
                "TopicArn": topic_arn,
                "Protocol": protocol,
                "Endpoint": endpoint,
            }
            if attributes:
                kwargs["Attributes"] = attributes

            response = self._call_with_retries("subscribe", **kwargs)
            return response["SubscriptionArn"]

        except ClientError as e:
            logger.exception(
                "Failed to subscribe %s to SNS topic: %s",
                endpoint,
                topic_arn,
            )
            raise SNSException(f"Failed to create subscription: {str(e)}") from e

    def unsubscribe(self, subscription_arn: str) -> None:
        """Unsubscribe from an SNS topic."""
        try:
            self._call_with_retries("unsubscribe", SubscriptionArn=subscription_arn)
        except ClientError as e:
            logger.exception(
                "Failed to unsubscribe from subscription: %s",
                subscription_arn,
            )
            raise SNSException(f"Failed to unsubscribe: {str(e)}") from e

    def list_topics(
        self,
        next_token: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """List SNS topics."""
        try:
            kwargs: dict[str, Any] = {}
            if next_token:
                kwargs["NextToken"] = next_token

            response = self._call_with_retries("list_topics", **kwargs)
            return response["Topics"], response.get("NextToken")

        except ClientError as e:
            logger.exception("Failed to list SNS topics")
            raise SNSException(f"Failed to list topics: {str(e)}") from e

    def list_subscriptions_by_topic(
        self,
        topic_arn: str,
        next_token: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """List subscriptions for a specific topic."""
        try:
            kwargs: dict[str, Any] = {"TopicArn": topic_arn}
            if next_token:
                kwargs["NextToken"] = next_token

            response = self._call_with_retries("list_subscriptions_by_topic", **kwargs)
            return response["Subscriptions"], response.get("NextToken")

        except ClientError as e:
            logger.exception(
                "Failed to list subscriptions for topic: %s",
                topic_arn,
            )
            raise SNSException(f"Failed to list subscriptions: {str(e)}") from e

    def list_subscriptions(
        self,
        next_token: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """List all subscriptions."""
        try:
            kwargs: dict[str, Any] = {}
            if next_token:
                kwargs["NextToken"] = next_token

            response = self._call_with_retries("list_subscriptions", **kwargs)
            return response["Subscriptions"], response.get("NextToken")
        except ClientError as e:
            logger.exception("Failed to list SNS subscriptions")
            raise SNSException(f"Failed to list subscriptions: {str(e)}") from e

    def get_topic_attributes(self, topic_arn: str) -> dict[str, str]:
        """Get topic attributes."""
        try:
            response = self._call_with_retries("get_topic_attributes", TopicArn=topic_arn)
            return response["Attributes"]
        except ClientError as e:
            logger.exception("Failed to get topic attributes: %s", topic_arn)
            raise SNSException(f"Failed to get topic attributes: {str(e)}") from e

    def set_topic_attributes(
        self,
        topic_arn: str,
        attribute_name: str,
        attribute_value: str,
    ) -> None:
        """Set one topic attribute."""
        try:
            self._call_with_retries(
                "set_topic_attributes",
                TopicArn=topic_arn,
                AttributeName=attribute_name,
                AttributeValue=attribute_value,
            )
        except ClientError as e:
            logger.exception("Failed to set topic attributes: %s", topic_arn)
            raise SNSException(f"Failed to set topic attributes: {str(e)}") from e

    def get_subscription_attributes(self, subscription_arn: str) -> dict[str, str]:
        """Get subscription attributes."""
        try:
            response = self._call_with_retries(
                "get_subscription_attributes",
                SubscriptionArn=subscription_arn,
            )
            return response["Attributes"]
        except ClientError as e:
            logger.exception(
                "Failed to get subscription attributes: %s",
                subscription_arn,
            )
            raise SNSException(
                f"Failed to get subscription attributes: {str(e)}",
            ) from e

    def set_subscription_attributes(
        self,
        subscription_arn: str,
        attribute_name: str,
        attribute_value: str,
    ) -> None:
        """Set one subscription attribute."""
        try:
            self._call_with_retries(
                "set_subscription_attributes",
                SubscriptionArn=subscription_arn,
                AttributeName=attribute_name,
                AttributeValue=attribute_value,
            )
        except ClientError as e:
            logger.exception(
                "Failed to set subscription attributes: %s",
                subscription_arn,
            )
            raise SNSException(
                f"Failed to set subscription attributes: {str(e)}",
            ) from e

    def confirm_subscription(
        self,
        topic_arn: str,
        token: str,
        authenticate_on_unsubscribe: bool | None = None,
    ) -> str:
        """Confirm a pending subscription."""
        try:
            kwargs: dict[str, Any] = {"TopicArn": topic_arn, "Token": token}
            if authenticate_on_unsubscribe is not None:
                kwargs["AuthenticateOnUnsubscribe"] = str(
                    authenticate_on_unsubscribe,
                ).lower()
            response = self._call_with_retries("confirm_subscription", **kwargs)
            return response["SubscriptionArn"]
        except ClientError as e:
            logger.exception("Failed to confirm subscription for %s", topic_arn)
            raise SNSException(f"Failed to confirm subscription: {str(e)}") from e

    @staticmethod
    def _chunk_messages(
        messages: list[SNSPublishMessageDict],
    ) -> list[list[SNSPublishMessageDict]]:
        return [
            messages[i:i + _MAX_PUBLISH_BATCH_SIZE]
            for i in range(0, len(messages), _MAX_PUBLISH_BATCH_SIZE)
        ]

    def batch_publish(
        self,
        topic_arn: str,
        messages: list[SNSPublishMessageDict],
    ) -> list[tuple[bool, str, str | None]]:
        """Publish messages using SNS PublishBatch API."""
        results: list[tuple[bool, str, str | None]] = []
        for chunk_idx, chunk in enumerate(self._chunk_messages(messages)):
            chunk_base_index = chunk_idx * _MAX_PUBLISH_BATCH_SIZE
            entries: list[dict[str, Any]] = []
            for index, message in enumerate(chunk):
                entry_id = str(chunk_base_index + index)
                entry: dict[str, Any] = {
                    "Id": entry_id,
                    "Message": message["message"],
                }
                if message.get("subject") is not None:
                    entry["Subject"] = message["subject"]
                if message.get("message_attributes") is not None:
                    entry["MessageAttributes"] = message["message_attributes"]
                if message.get("message_structure") is not None:
                    entry["MessageStructure"] = message["message_structure"]
                if message.get("message_group_id") is not None:
                    entry["MessageGroupId"] = message["message_group_id"]
                if message.get("message_deduplication_id") is not None:
                    entry["MessageDeduplicationId"] = message["message_deduplication_id"]
                entries.append(entry)

            try:
                response = self._call_with_retries(
                    "publish_batch",
                    TopicArn=topic_arn,
                    PublishBatchRequestEntries=entries,
                )
            except ClientError as e:
                error_message = str(e)
                results.extend((False, entry["Id"], error_message) for entry in entries)
                continue

            success_map = {
                item["Id"]: item["MessageId"]
                for item in response.get("Successful", [])
            }
            failure_map = {
                item["Id"]: f'{item.get("Code", "Error")}: {item.get("Message", "Unknown error")}'
                for item in response.get("Failed", [])
            }

            for entry in entries:
                entry_id = entry["Id"]
                if entry_id in success_map:
                    results.append((True, success_map[entry_id], None))
                else:
                    results.append(
                        (False, entry_id, failure_map.get(entry_id, "Unknown error")),
                    )

        return results

    def batch_subscribe(
        self,
        topic_arn: str,
        subscriptions: list[dict[str, Any]],
    ) -> list[tuple[bool, str, str | None]]:
        """Subscribe multiple endpoints in parallel."""
        results: list[tuple[bool, str, str | None]] = []

        def subscribe_single(subscription: dict[str, Any]) -> tuple[bool, str, str | None]:
            try:
                subscription_arn = self.subscribe(
                    topic_arn=topic_arn,
                    protocol=subscription["protocol"],
                    endpoint=subscription["endpoint"],
                    attributes=subscription.get("attributes"),
                )
                return True, subscription_arn, None
            except Exception as e:
                logger.exception(
                    "Failed to subscribe %s to SNS topic: %s",
                    subscription["endpoint"],
                    topic_arn,
                )
                return False, str(subscription.get("endpoint", "")), str(e)

        with ThreadPoolExecutor(
            max_workers=_thread_worker_count(len(subscriptions)),
        ) as executor:
            results.extend(executor.map(subscribe_single, subscriptions))

        return results

    def batch_unsubscribe(
        self,
        subscription_arns: list[str],
    ) -> list[tuple[bool, str, str | None]]:
        """Unsubscribe multiple subscriptions in parallel."""
        results: list[tuple[bool, str, str | None]] = []

        def unsubscribe_single(arn: str) -> tuple[bool, str, str | None]:
            try:
                self.unsubscribe(subscription_arn=arn)
                return True, arn, None
            except Exception as e:
                logger.exception(
                    "Failed to unsubscribe from subscription: %s",
                    arn,
                )
                return False, arn, str(e)

        with ThreadPoolExecutor(
            max_workers=_thread_worker_count(len(subscription_arns)),
        ) as executor:
            results.extend(executor.map(unsubscribe_single, subscription_arns))

        return results
