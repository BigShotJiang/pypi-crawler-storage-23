"""AWS SNS (Simple Notification Service) client for chainsaws.

This module provides a high-level interface for working with AWS SNS,
making it easier to manage topics, subscriptions, and message publishing.

Example:
    ```python
    from chainsaws.aws.sns import SNSClient
    
    # Initialize the client
    sns = SNSClient()
    
    # Create a topic
    topic_arn = sns.create_topic("my-topic")
    
    # Publish a message
    sns.publish(topic_arn, "Hello from chainsaws!")
    ```
"""

from chainsaws.aws.sns.sns import SNSAPI, SNSClient
from chainsaws.aws.sns.sns_exception import SNSException
from chainsaws.aws.sns.sns_models import (
    BatchPublishResult,
    BatchSubscribeResult,
    JSONPrimitive,
    JSONValue,
    SNSAPIConfig,
    SNSAttributeDataType,
    SNSBatchSubscriptionRequest,
    SNSBatchFailureDetail,
    SNSMessageStructure,
    SNSMessage,
    SNSMessageAttributeValueDict,
    SNSPublishMessageDict,
    SNSProtocol,
    SNSMessageAttributes,
    SNSSubscription,
    SNSTopic,
)

__all__ = [
    "SNSClient",
    "SNSAPI",
    "SNSException",
    "SNSAPIConfig",
    "JSONPrimitive",
    "JSONValue",
    "SNSAttributeDataType",
    "SNSMessage",
    "SNSMessageStructure",
    "SNSMessageAttributeValueDict",
    "SNSMessageAttributes",
    "SNSPublishMessageDict",
    "SNSProtocol",
    "SNSBatchSubscriptionRequest",
    "SNSBatchFailureDetail",
    "BatchPublishResult",
    "BatchSubscribeResult",
    "SNSSubscription",
    "SNSTopic",
]
