"""Models for AWS SNS service."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, Required, TypeAlias, TypedDict

from chainsaws.aws.shared.config import APIConfig

JSONPrimitive = str | int | float | bool | None
JSONValue: TypeAlias = JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"]
SNSProtocol = Literal[
    "http",
    "https",
    "email",
    "email-json",
    "sms",
    "sqs",
    "application",
    "lambda",
    "firehose",
]
SNSAttributeDataType = Literal["String", "String.Array", "Number", "Binary"]
SNSMessageStructure = Literal["json"]


class SNSMessageAttributeValueDict(TypedDict, total=False):
    """SNS message attribute payload."""

    StringValue: str
    BinaryValue: bytes
    DataType: str


class SNSPublishMessageDict(TypedDict, total=False):
    """Normalized publish payload for SNS internals."""

    message: str
    subject: str
    message_attributes: dict[str, SNSMessageAttributeValueDict]
    message_structure: str
    message_deduplication_id: str
    message_group_id: str


class SNSBatchSubscriptionRequest(TypedDict, total=False):
    """Subscription payload for batch subscribe API."""

    protocol: Required[SNSProtocol | str]
    endpoint: Required[str]
    raw_message_delivery: bool
    filter_policy: dict[str, JSONValue]


class SNSBatchFailureDetail(TypedDict):
    """Normalized failure detail for batch results."""

    Identifier: str
    Error: str


@dataclass
class SNSAPIConfig(APIConfig):
    """Configuration for SNS API."""

    pass


@dataclass
class SNSMessageAttributes:
    """Message attributes for SNS messages."""

    string_value: str | None = None
    binary_value: bytes | None = None
    data_type: SNSAttributeDataType | str = "String"

    def __post_init__(self) -> None:
        """Validate mutually-exclusive attribute value fields."""
        if self.string_value is not None and self.binary_value is not None:
            msg = "Exactly one of string_value or binary_value must be set"
            raise ValueError(msg)

    def to_dict(self) -> SNSMessageAttributeValueDict:
        """Convert to dictionary format expected by AWS API."""
        result: SNSMessageAttributeValueDict = {"DataType": self.data_type}
        if self.string_value is not None:
            result["StringValue"] = self.string_value
        if self.binary_value is not None:
            result["BinaryValue"] = self.binary_value
        return result


@dataclass
class SNSMessage:
    """Model representing an SNS message."""

    message: str
    subject: str | None = None
    message_attributes: dict[str, SNSMessageAttributes] | None = None
    message_structure: SNSMessageStructure | str | None = None
    message_deduplication_id: str | None = None
    message_group_id: str | None = None

    def to_dict(self) -> SNSPublishMessageDict:
        """Convert to dictionary format expected by AWS API."""
        result: SNSPublishMessageDict = {
            "message": self.message,
        }
        if self.subject:
            result["subject"] = self.subject
        if self.message_attributes:
            result["message_attributes"] = {
                k: v.to_dict() for k, v in self.message_attributes.items()
            }
        if self.message_structure:
            result["message_structure"] = self.message_structure
        if self.message_deduplication_id:
            result["message_deduplication_id"] = self.message_deduplication_id
        if self.message_group_id:
            result["message_group_id"] = self.message_group_id
        return result


@dataclass
class SNSTopic:
    """Model representing an SNS topic."""

    topic_arn: str
    topic_name: str
    display_name: str | None = None
    policy: dict[str, JSONValue] | None = None
    delivery_policy: dict[str, JSONValue] | None = None
    tags: dict[str, str] | None = None
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, JSONValue]:
        """Convert to dictionary format expected by AWS API."""
        result: dict[str, JSONValue] = {
            "TopicArn": self.topic_arn,
            "TopicName": self.topic_name,
        }
        if self.display_name:
            result["DisplayName"] = self.display_name
        if self.policy:
            result["Policy"] = self.policy
        if self.delivery_policy:
            result["DeliveryPolicy"] = self.delivery_policy
        if self.tags:
            result["Tags"] = self.tags
        if self.created_at:
            result["CreatedAt"] = self.created_at.isoformat()
        return result


@dataclass
class SNSSubscription:
    """Model representing an SNS subscription."""

    subscription_arn: str
    topic_arn: str
    protocol: SNSProtocol | str
    endpoint: str
    raw_message_delivery: bool = False
    filter_policy: dict[str, JSONValue] | None = None
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, JSONValue]:
        """Convert to dictionary format expected by AWS API."""
        result: dict[str, JSONValue] = {
            "SubscriptionArn": self.subscription_arn,
            "TopicArn": self.topic_arn,
            "Protocol": self.protocol,
            "Endpoint": self.endpoint,
            "RawMessageDelivery": str(self.raw_message_delivery).lower(),
        }
        if self.filter_policy:
            result["FilterPolicy"] = self.filter_policy
        if self.created_at:
            result["CreatedAt"] = self.created_at.isoformat()
        return result


@dataclass
class BatchPublishResult:
    """Result of a batch publish operation."""

    successful: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)

    def __init__(self, results: list[tuple[bool, str, str | None]]) -> None:
        self.successful = []
        self.failed = []

        for success, identifier, error in results:
            if success:
                self.successful.append(identifier)
            else:
                self.failed.append((identifier, error or "Unknown error"))

    @property
    def success_count(self) -> int:
        """Number of successfully published messages."""
        return len(self.successful)

    @property
    def failure_count(self) -> int:
        """Number of failed messages."""
        return len(self.failed)

    @property
    def failed_identifiers(self) -> list[str]:
        """Failed message identifiers (publish batch entry ids)."""
        return [identifier for identifier, _ in self.failed]

    @property
    def failed_indices(self) -> list[int]:
        """Failed message indices when identifiers are numeric."""
        indices: list[int] = []
        for identifier, _ in self.failed:
            if identifier.isdigit():
                indices.append(int(identifier))
        return indices

    def to_dict(self) -> dict[str, JSONValue]:
        """Convert to dictionary format expected by AWS API."""
        failed_payload: list[SNSBatchFailureDetail] = [
            {"Identifier": identifier, "Error": error}
            for identifier, error in self.failed
        ]
        return {
            "Successful": self.successful,
            "Failed": failed_payload,
            "SuccessCount": self.success_count,
            "FailureCount": self.failure_count,
        }


@dataclass
class BatchSubscribeResult:
    """Result of a batch subscribe operation."""

    successful: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)

    def __init__(self, results: list[tuple[bool, str, str | None]]) -> None:
        self.successful = []
        self.failed = []

        for success, sub_arn, error in results:
            if success:
                self.successful.append(sub_arn)
            else:
                self.failed.append((sub_arn, error or "Unknown error"))

    @property
    def success_count(self) -> int:
        """Number of successful subscriptions."""
        return len(self.successful)

    @property
    def failure_count(self) -> int:
        """Number of failed subscriptions."""
        return len(self.failed)

    @property
    def failed_identifiers(self) -> list[str]:
        """Failed subscription identifiers (usually endpoint or ARN)."""
        return [identifier for identifier, _ in self.failed]

    def to_dict(self) -> dict[str, JSONValue]:
        """Convert to dictionary format expected by AWS API."""
        failed_payload: list[SNSBatchFailureDetail] = [
            {"Identifier": identifier, "Error": error}
            for identifier, error in self.failed
        ]
        return {
            "Successful": self.successful,
            "Failed": failed_payload,
            "SuccessCount": self.success_count,
            "FailureCount": self.failure_count,
        }
