"""SES (Simple Email Service) event types for AWS Lambda."""

from typing import Literal, TypedDict, TypeAlias, cast

from chainsaws.aws.lambda_client.lambda_models import InvocationType


class SESMailHeader(TypedDict):
    """Email header information."""

    name: str
    value: str


class SESMailCommonHeaders(TypedDict, total=False):
    """Common email headers."""

    returnPath: str
    from_: list[str]  # alias="from"
    date: str
    to: list[str]
    cc: list[str]
    bcc: list[str]
    sender: list[str]
    replyTo: list[str]
    messageId: str
    subject: str


class SESMail(TypedDict):
    """Information about the email message."""

    timestamp: str
    source: str
    messageId: str
    destination: list[str]
    headersTruncated: bool
    headers: list[SESMailHeader]
    commonHeaders: SESMailCommonHeaders


class SESReceiptStatus(TypedDict):
    """Status of an email verification check."""

    status: Literal["PASS", "FAIL", "GRAY"]


class SESReceiptS3Action(TypedDict, total=False):
    """Action to save email to S3."""

    type: Literal["S3"]
    topicArn: str
    bucketName: str
    objectKey: str


class SESReceiptSnsAction(TypedDict):
    """Action to publish to SNS."""

    type: Literal["SNS"]
    topicArn: str


class SESReceiptBounceAction(TypedDict, total=False):
    """Action to bounce the email."""

    type: Literal["Bounce"]
    topicArn: str
    smtpReplyCode: str
    statusCode: str
    message: str
    sender: str


class SESReceiptLambdaAction(TypedDict, total=False):
    """Action to invoke a Lambda function."""

    type: Literal["Lambda"]
    topicArn: str
    functionArn: str
    invocationType: InvocationType


class SESReceiptStopAction(TypedDict, total=False):
    """Action to stop processing rules."""

    type: Literal["Stop"]
    topicArn: str


class SESReceiptWorkMailAction(TypedDict, total=False):
    """Action to send to WorkMail."""

    type: Literal["WorkMail"]
    topicArn: str
    organizationArn: str


UnknownSESReceiptAction: TypeAlias = dict[str, object]


class SESReceipt(TypedDict):
    """Information about the email receipt and processing."""

    recipients: list[str]
    timestamp: str
    spamVerdict: SESReceiptStatus
    dkimVerdict: SESReceiptStatus
    processingTimeMillis: int
    action: (
        SESReceiptS3Action
        | SESReceiptSnsAction
        | SESReceiptBounceAction
        | SESReceiptLambdaAction
        | SESReceiptStopAction
        | SESReceiptWorkMailAction
        | UnknownSESReceiptAction
    )
    spfVerdict: SESReceiptStatus
    virusVerdict: SESReceiptStatus
    dmarcVerdict: SESReceiptStatus
    dmarcPolicy: Literal["none", "quarantine", "reject"]


class SESMessage(TypedDict):
    """Complete information about an email message."""

    mail: SESMail
    receipt: SESReceipt


class SESEventRecord(TypedDict):
    """Individual SES event record."""

    eventVersion: str
    ses: SESMessage
    eventSource: str


class SESEvent(TypedDict):
    """Event sent by SES to Lambda."""

    Records: list[SESEventRecord]


def is_ses_event(event: object) -> bool:
    """Lightweight runtime check for SES Lambda event shape."""

    if not isinstance(event, dict):
        return False

    raw_records = event.get("Records")
    if not isinstance(raw_records, list):
        return False

    for record in raw_records:
        if not isinstance(record, dict):
            return False
        source = record.get("eventSource")
        if source is not None and source != "aws:ses":
            return False
        if "ses" not in record:
            return False

    return True


def parse_ses_event(event: object) -> SESEvent:
    """Parse and type-cast a runtime event into `SESEvent`."""

    if not is_ses_event(event):
        msg = "Invalid SES event payload"
        raise TypeError(msg)
    return cast(SESEvent, event)
