use std::collections::HashSet;

use pyo3::exceptions::PyTypeError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList, PyTuple};

type PyObject = pyo3::Py<pyo3::PyAny>;

fn build_wire_key(
    py: Python<'_>,
    pk_value: &Bound<'_, PyAny>,
    sk_value: &Bound<'_, PyAny>,
) -> PyResult<PyObject> {
    let key_dict = PyDict::new(py);
    let pk_dict = PyDict::new(py);
    pk_dict.set_item("S", pk_value)?;
    let sk_dict = PyDict::new(py);
    sk_dict.set_item("S", sk_value)?;
    key_dict.set_item("_pk", pk_dict)?;
    key_dict.set_item("_sk", sk_dict)?;
    Ok(key_dict.into_pyobject(py)?.unbind().into())
}

#[pyfunction]
pub(crate) fn normalize_pk_sk_pairs(pk_sk_pairs: PyObject) -> PyResult<PyObject> {
    Python::attach(|py| {
        let pairs = pk_sk_pairs.bind(py);
        let output = PyList::empty(py);

        if pairs.is_none() {
            return Ok(output.into_pyobject(py)?.unbind().into());
        }

        for pair_any in pairs.try_iter()? {
            let pair = pair_any?;
            if !pair.is_truthy()? {
                continue;
            }

            if let Ok(pair_list) = pair.downcast::<PyList>() {
                if pair_list.len() >= 2 {
                    let pk_value = pair_list.get_item(0)?;
                    let sk_value = pair_list.get_item(1)?;
                    output.append(build_wire_key(py, &pk_value, &sk_value)?)?;
                    continue;
                }
            }

            if let Ok(pair_tuple) = pair.downcast::<PyTuple>() {
                if pair_tuple.len() >= 2 {
                    let pk_value = pair_tuple.get_item(0)?;
                    let sk_value = pair_tuple.get_item(1)?;
                    output.append(build_wire_key(py, &pk_value, &sk_value)?)?;
                    continue;
                }
            }

            if let Ok(pair_dict) = pair.downcast::<PyDict>() {
                let pk_value = pair_dict.get_item("_pk")?;
                let sk_value = pair_dict.get_item("_sk")?;
                if let (Some(pk_inner), Some(sk_inner)) = (pk_value, sk_value) {
                    if pk_inner.is_instance_of::<PyDict>() && sk_inner.is_instance_of::<PyDict>() {
                        output.append(pair)?;
                        continue;
                    }

                    output.append(build_wire_key(py, &pk_inner, &sk_inner)?)?;
                }
            }
        }

        Ok(output.into_pyobject(py)?.unbind().into())
    })
}

#[pyfunction]
pub(crate) fn get_update_expression_attrs_pair(
    item: PyObject,
) -> PyResult<(String, PyObject, PyObject)> {
    Python::attach(|py| {
        let bound_item = item.bind(py);
        let item_dict = bound_item
            .downcast::<PyDict>()
            .map_err(|_| PyTypeError::new_err("item must be a dict"))?;

        let attr_names = PyDict::new(py);
        let attr_values = PyDict::new(py);
        if item_dict.is_empty() {
            return Ok((
                "set".to_string(),
                attr_names.into_pyobject(py)?.unbind().into(),
                attr_values.into_pyobject(py)?.unbind().into(),
            ));
        }

        let mut expression_parts: Vec<String> = Vec::with_capacity(item_dict.len());
        for (idx, (key, value)) in item_dict.iter().enumerate() {
            let attr_key = format!("#key{idx}");
            let attr_value = format!(":val{idx}");
            expression_parts.push(format!("{attr_key}={attr_value}"));
            attr_names.set_item(attr_key, key)?;
            attr_values.set_item(attr_value, value)?;
        }

        let expression = format!("set {}", expression_parts.join(", "));
        Ok((
            expression,
            attr_names.into_pyobject(py)?.unbind().into(),
            attr_values.into_pyobject(py)?.unbind().into(),
        ))
    })
}

fn py_optional_string_list(values: Option<PyObject>, py: Python<'_>) -> PyResult<Vec<String>> {
    let Some(values_obj) = values else {
        return Ok(Vec::new());
    };
    let values_list = values_obj
        .bind(py)
        .downcast::<PyList>()
        .map_err(|_| PyTypeError::new_err("value must be a list"))?;
    let mut out: Vec<String> = Vec::with_capacity(values_list.len());
    for entry in values_list.iter() {
        out.push(entry.extract::<String>()?);
    }
    Ok(out)
}

#[pyfunction(signature = (projection_fields=None, required_fields=None, required_first=true))]
pub(crate) fn build_projection_expression(
    projection_fields: Option<PyObject>,
    required_fields: Option<PyObject>,
    required_first: bool,
) -> PyResult<(Option<String>, PyObject)> {
    Python::attach(|py| {
        let projection = py_optional_string_list(projection_fields, py)?;
        let required = py_optional_string_list(required_fields, py)?;

        if projection.is_empty() {
            return Ok((None, PyDict::new(py).into_pyobject(py)?.unbind().into()));
        }

        let mut ordered: Vec<String> = Vec::with_capacity(projection.len() + required.len());
        let mut seen: HashSet<String> = HashSet::with_capacity(projection.len() + required.len());

        let mut push_unique = |value: &str| {
            if seen.insert(value.to_string()) {
                ordered.push(value.to_string());
            }
        };

        if required_first {
            for field in required {
                push_unique(&field);
            }
            for field in projection {
                push_unique(&field);
            }
        } else {
            for field in projection {
                push_unique(&field);
            }
            for field in required {
                push_unique(&field);
            }
        }

        let expr_names = PyDict::new(py);
        let mut placeholders: Vec<String> = Vec::with_capacity(ordered.len());
        for (idx, field_name) in ordered.iter().enumerate() {
            let placeholder = format!("#pe{idx}");
            expr_names.set_item(&placeholder, field_name)?;
            placeholders.push(placeholder);
        }

        let projection_expression = placeholders.join(",");
        Ok((
            Some(projection_expression),
            expr_names.into_pyobject(py)?.unbind().into(),
        ))
    })
}

pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(normalize_pk_sk_pairs, m)?)?;
    m.add_function(wrap_pyfunction!(get_update_expression_attrs_pair, m)?)?;
    m.add_function(wrap_pyfunction!(build_projection_expression, m)?)?;
    Ok(())
}
