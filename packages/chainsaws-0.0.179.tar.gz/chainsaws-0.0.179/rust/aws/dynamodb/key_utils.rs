use std::collections::HashMap;

use pyo3::exceptions::{PyKeyError, PyValueError};
use pyo3::prelude::*;

#[pyfunction]
pub(crate) fn convert_int_to_custom_base64(number: i128, base64_charset: &str) -> PyResult<String> {
    if base64_charset.len() != 64 {
        return Err(PyValueError::new_err("base64_charset length must be 64"));
    }
    let chars: Vec<char> = base64_charset.chars().collect();
    if number == 0 {
        return Ok(chars[0].to_string());
    }
    if number < 0 {
        return Ok(String::new());
    }

    let mut value = number;
    let mut encoded_chars: Vec<char> = Vec::new();
    while value > 0 {
        let index = (value % 64) as usize;
        encoded_chars.push(chars[index]);
        value /= 64;
    }
    encoded_chars.reverse();
    Ok(encoded_chars.iter().collect())
}

#[pyfunction]
pub(crate) fn convert_custom_base64_to_int(
    custom_base64: &str,
    base64_charset: &str,
) -> PyResult<i128> {
    if base64_charset.len() != 64 {
        return Err(PyValueError::new_err("base64_charset length must be 64"));
    }

    let mut char_to_index: HashMap<char, i128> = HashMap::with_capacity(64);
    for (index, ch) in base64_charset.chars().enumerate() {
        char_to_index.insert(ch, index as i128);
    }

    let mut result: i128 = 0;
    for (power, ch) in custom_base64.chars().rev().enumerate() {
        let idx = char_to_index
            .get(&ch)
            .ok_or_else(|| PyKeyError::new_err(format!("Invalid base64 character: {ch}")))?;
        let power_u32 =
            u32::try_from(power).map_err(|_| PyValueError::new_err("custom_base64 is too long"))?;
        let factor = 64_i128
            .checked_pow(power_u32)
            .ok_or_else(|| PyValueError::new_err("custom_base64 is too long"))?;
        result = result
            .checked_add(
                idx.checked_mul(factor)
                    .ok_or_else(|| PyValueError::new_err("custom_base64 is too long"))?,
            )
            .ok_or_else(|| PyValueError::new_err("custom_base64 is too long"))?;
    }

    Ok(result)
}

#[pyfunction]
pub(crate) fn merge_pk_sk(partition_key: &str, sort_key: &str) -> String {
    let escaped_pk = partition_key.replace("&", "-&");
    let escaped_sk = sort_key.replace("&", "-&");
    format!("{escaped_pk}&{escaped_sk}")
}

#[pyfunction]
pub(crate) fn split_pk_sk(merged_id: &str) -> PyResult<(String, String)> {
    if !merged_id.contains('&') {
        let msg = format!(
            "Invalid item_id format: '{merged_id}'. Expected '<partition_key>&<sort_key>'."
        );
        return Err(PyValueError::new_err(msg));
    }

    let mut parts: Vec<String> = Vec::new();
    let mut prev_char: Option<char> = None;
    let mut buffer = String::new();

    for ch in merged_id.chars() {
        if ch == '&' && prev_char != Some('-') {
            parts.push(buffer.replace("-&", "&"));
            buffer.clear();
        } else {
            buffer.push(ch);
        }
        prev_char = Some(ch);
    }

    if !buffer.is_empty() {
        parts.push(buffer.replace("-&", "&"));
    }

    if parts.len() != 2 {
        let msg = format!(
            "Invalid item_id format: '{merged_id}'. Expected '<partition_key>&<sort_key>'."
        );
        return Err(PyValueError::new_err(msg));
    }

    Ok((parts[0].clone(), parts[1].clone()))
}

pub(crate) fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(convert_int_to_custom_base64, m)?)?;
    m.add_function(wrap_pyfunction!(convert_custom_base64_to_int, m)?)?;
    m.add_function(wrap_pyfunction!(merge_pk_sk, m)?)?;
    m.add_function(wrap_pyfunction!(split_pk_sk, m)?)?;
    Ok(())
}
