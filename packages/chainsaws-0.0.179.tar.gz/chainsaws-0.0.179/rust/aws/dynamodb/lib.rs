use pyo3::prelude::*;

mod codec;
mod key_utils;
mod operation_helpers;
mod sdk_client;
mod sdk_wire;
mod sort_key;

pub(crate) fn register_dynamodb_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    codec::register(m)?;
    sort_key::register(m)?;
    key_utils::register(m)?;
    operation_helpers::register(m)?;
    sdk_client::register(m)?;
    Ok(())
}
