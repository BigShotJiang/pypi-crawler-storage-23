use std::collections::HashMap;

use aws_sdk_dynamodb::primitives::Blob;
use aws_sdk_dynamodb::types::AttributeValue;
use pyo3::exceptions::{PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{
    PyBool, PyByteArray, PyBytes, PyDict, PyFloat, PyFrozenSet, PyInt, PyList, PySet, PyTuple,
};

pub(crate) type AttributeMap = HashMap<String, AttributeValue>;
type PyObject = pyo3::Py<pyo3::PyAny>;

pub(crate) fn py_wire_value_to_attr(value: &Bound<'_, PyAny>) -> PyResult<AttributeValue> {
    let attr_dict = value
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("attribute value must be a dict"))?;

    if attr_dict.len() != 1 {
        return Err(PyValueError::new_err(
            "attribute value dict must contain exactly one type key",
        ));
    }

    let (type_key, raw_value) = attr_dict
        .iter()
        .next()
        .ok_or_else(|| PyValueError::new_err("attribute value dict cannot be empty"))?;
    let kind = type_key.extract::<&str>()?;

    match kind {
        "S" => Ok(AttributeValue::S(raw_value.extract::<String>()?)),
        "N" => Ok(AttributeValue::N(raw_value.extract::<String>()?)),
        "B" => {
            let bytes = raw_value
                .downcast::<PyBytes>()
                .map_err(|_| PyTypeError::new_err("B value must be bytes"))?;
            Ok(AttributeValue::B(Blob::new(bytes.as_bytes())))
        }
        "BOOL" => Ok(AttributeValue::Bool(raw_value.extract::<bool>()?)),
        "NULL" => Ok(AttributeValue::Null(raw_value.extract::<bool>()?)),
        "L" => {
            let py_list = raw_value
                .downcast::<PyList>()
                .map_err(|_| PyTypeError::new_err("L value must be a list"))?;
            let mut out = Vec::with_capacity(py_list.len());
            for item in py_list.iter() {
                out.push(py_wire_value_to_attr(&item)?);
            }
            Ok(AttributeValue::L(out))
        }
        "M" => {
            let py_map = raw_value
                .downcast::<PyDict>()
                .map_err(|_| PyTypeError::new_err("M value must be a dict"))?;
            let mut out: AttributeMap = HashMap::with_capacity(py_map.len());
            for (map_key, map_value) in py_map.iter() {
                let key = map_key.extract::<String>()?;
                out.insert(key, py_wire_value_to_attr(&map_value)?);
            }
            Ok(AttributeValue::M(out))
        }
        "SS" => {
            let py_list = raw_value
                .downcast::<PyList>()
                .map_err(|_| PyTypeError::new_err("SS value must be a list"))?;
            let mut out = Vec::with_capacity(py_list.len());
            for item in py_list.iter() {
                out.push(item.extract::<String>()?);
            }
            Ok(AttributeValue::Ss(out))
        }
        "NS" => {
            let py_list = raw_value
                .downcast::<PyList>()
                .map_err(|_| PyTypeError::new_err("NS value must be a list"))?;
            let mut out = Vec::with_capacity(py_list.len());
            for item in py_list.iter() {
                out.push(item.extract::<String>()?);
            }
            Ok(AttributeValue::Ns(out))
        }
        "BS" => {
            let py_list = raw_value
                .downcast::<PyList>()
                .map_err(|_| PyTypeError::new_err("BS value must be a list"))?;
            let mut out = Vec::with_capacity(py_list.len());
            for item in py_list.iter() {
                let bytes = item
                    .downcast::<PyBytes>()
                    .map_err(|_| PyTypeError::new_err("BS entries must be bytes"))?;
                out.push(Blob::new(bytes.as_bytes()));
            }
            Ok(AttributeValue::Bs(out))
        }
        _ => Err(PyValueError::new_err(format!(
            "unsupported DynamoDB attribute type: {kind}"
        ))),
    }
}

pub(crate) fn py_wire_item_to_attr_map(item: &Bound<'_, PyAny>) -> PyResult<AttributeMap> {
    let py_dict = item
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("item must be a dict"))?;
    let mut out: AttributeMap = HashMap::with_capacity(py_dict.len());
    for (key_obj, value_obj) in py_dict.iter() {
        let key = key_obj.extract::<String>()?;
        out.insert(key, py_wire_value_to_attr(&value_obj)?);
    }
    Ok(out)
}

pub(crate) fn py_wire_items_to_attr_maps(items: &Bound<'_, PyAny>) -> PyResult<Vec<AttributeMap>> {
    let py_list = items
        .downcast::<PyList>()
        .map_err(|_| PyTypeError::new_err("items must be a list"))?;
    let mut out = Vec::with_capacity(py_list.len());
    for item in py_list.iter() {
        out.push(py_wire_item_to_attr_map(&item)?);
    }
    Ok(out)
}

fn is_decimal_instance(value: &Bound<'_, PyAny>) -> PyResult<bool> {
    let py_type = value.get_type();
    let type_name = py_type.name()?.extract::<String>()?;
    if type_name != "Decimal" {
        return Ok(false);
    }
    let module_name = py_type.module()?.extract::<String>()?;
    Ok(module_name == "decimal")
}

fn float_not_supported_error() -> PyErr {
    PyTypeError::new_err("Float types are not supported. Use Decimal types instead.")
}

fn extract_binary_bytes(value: &Bound<'_, PyAny>) -> PyResult<Option<Vec<u8>>> {
    if let Ok(bytes) = value.downcast::<PyBytes>() {
        return Ok(Some(bytes.as_bytes().to_vec()));
    }

    if value.is_instance_of::<PyByteArray>() {
        let as_bytes_obj = value.call_method0("__bytes__")?;
        let as_bytes = as_bytes_obj
            .downcast::<PyBytes>()
            .map_err(|_| PyTypeError::new_err("bytearray conversion to bytes failed"))?;
        return Ok(Some(as_bytes.as_bytes().to_vec()));
    }

    let type_name = value.get_type().name()?.extract::<String>()?;
    if type_name == "Binary" {
        let raw_value = value.getattr("value")?;
        if let Ok(bytes) = raw_value.downcast::<PyBytes>() {
            return Ok(Some(bytes.as_bytes().to_vec()));
        }
        if raw_value.is_instance_of::<PyByteArray>() {
            let as_bytes_obj = raw_value.call_method0("__bytes__")?;
            let as_bytes = as_bytes_obj
                .downcast::<PyBytes>()
                .map_err(|_| PyTypeError::new_err("Binary.value conversion to bytes failed"))?;
            return Ok(Some(as_bytes.as_bytes().to_vec()));
        }
        return Err(PyTypeError::new_err("Binary.value must be bytes-like"));
    }

    Ok(None)
}

fn py_number_to_string(value: &Bound<'_, PyAny>) -> PyResult<String> {
    if value.is_instance_of::<PyBool>() {
        return Err(PyTypeError::new_err(
            "bool is not a valid number type for DynamoDB N",
        ));
    }

    if value.downcast::<PyInt>().is_ok() || is_decimal_instance(value)? {
        return Ok(value.str()?.to_string());
    }

    if value.is_instance_of::<PyFloat>() {
        return Err(float_not_supported_error());
    }

    Err(PyTypeError::new_err(
        "number type for DynamoDB N must be int or Decimal",
    ))
}

#[derive(Copy, Clone)]
enum SetValueKind {
    String,
    Number,
    Binary,
}

fn classify_set_value_kind(value: &Bound<'_, PyAny>) -> PyResult<SetValueKind> {
    if value.extract::<String>().is_ok() {
        return Ok(SetValueKind::String);
    }

    if value.is_instance_of::<PyFloat>() {
        return Err(float_not_supported_error());
    }

    if value.downcast::<PyInt>().is_ok() || is_decimal_instance(value)? {
        return Ok(SetValueKind::Number);
    }

    if extract_binary_bytes(value)?.is_some() {
        return Ok(SetValueKind::Binary);
    }

    Err(PyTypeError::new_err(
        "set elements must be all str, all int/Decimal, or all binary",
    ))
}

pub(crate) fn py_object_value_to_attr(value: &Bound<'_, PyAny>) -> PyResult<AttributeValue> {
    if value.is_none() {
        return Ok(AttributeValue::Null(true));
    }

    if value.is_instance_of::<PyBool>() {
        return Ok(AttributeValue::Bool(value.extract::<bool>()?));
    }

    if let Some(bytes) = extract_binary_bytes(value)? {
        return Ok(AttributeValue::B(Blob::new(bytes)));
    }

    if let Ok(as_string) = value.extract::<String>() {
        return Ok(AttributeValue::S(as_string));
    }

    if value.is_instance_of::<PyFloat>() {
        return Err(float_not_supported_error());
    }

    if value.downcast::<PyInt>().is_ok() || is_decimal_instance(value)? {
        return Ok(AttributeValue::N(py_number_to_string(value)?));
    }

    if let Ok(py_list) = value.downcast::<PyList>() {
        let mut out = Vec::with_capacity(py_list.len());
        for item in py_list.iter() {
            out.push(py_object_value_to_attr(&item)?);
        }
        return Ok(AttributeValue::L(out));
    }

    if let Ok(py_tuple) = value.downcast::<PyTuple>() {
        let mut out = Vec::with_capacity(py_tuple.len());
        for item in py_tuple.iter() {
            out.push(py_object_value_to_attr(&item)?);
        }
        return Ok(AttributeValue::L(out));
    }

    if value.is_instance_of::<PySet>() || value.is_instance_of::<PyFrozenSet>() {
        let mut kind: Option<SetValueKind> = None;
        let mut ss: Vec<String> = Vec::new();
        let mut ns: Vec<String> = Vec::new();
        let mut bs: Vec<Blob> = Vec::new();

        for item_result in value.try_iter()? {
            let item = item_result?;
            let current_kind = match kind {
                Some(existing_kind) => existing_kind,
                None => {
                    let inferred = classify_set_value_kind(&item)?;
                    kind = Some(inferred);
                    inferred
                }
            };

            match current_kind {
                SetValueKind::String => {
                    let entry = item
                        .extract::<String>()
                        .map_err(|_| PyTypeError::new_err("all set elements must be str for SS"))?;
                    ss.push(entry);
                }
                SetValueKind::Number => {
                    let entry = py_number_to_string(&item).map_err(|_| {
                        PyTypeError::new_err("all set elements must be int or Decimal for NS")
                    })?;
                    ns.push(entry);
                }
                SetValueKind::Binary => {
                    let entry = extract_binary_bytes(&item)
                        .map_err(|_| {
                            PyTypeError::new_err("all set elements must be binary for BS")
                        })?
                        .ok_or_else(|| {
                            PyTypeError::new_err("all set elements must be binary for BS")
                        })?;
                    bs.push(Blob::new(entry));
                }
            }
        }

        return match kind {
            Some(SetValueKind::String) => Ok(AttributeValue::Ss(ss)),
            Some(SetValueKind::Number) => Ok(AttributeValue::Ns(ns)),
            Some(SetValueKind::Binary) => Ok(AttributeValue::Bs(bs)),
            None => Err(PyTypeError::new_err("empty sets are not supported")),
        };
    }

    if let Ok(py_map) = value.downcast::<PyDict>() {
        let mut out: AttributeMap = HashMap::with_capacity(py_map.len());
        for (map_key, map_value) in py_map.iter() {
            let key = map_key
                .extract::<String>()
                .map_err(|_| PyTypeError::new_err("map keys must be strings"))?;
            out.insert(key, py_object_value_to_attr(&map_value)?);
        }
        return Ok(AttributeValue::M(out));
    }

    Err(PyTypeError::new_err(format!(
        "unsupported Python type for DynamoDB serialization: {}",
        value.get_type().name()?.extract::<String>()?
    )))
}

pub(crate) fn py_object_item_to_attr_map(item: &Bound<'_, PyAny>) -> PyResult<AttributeMap> {
    let py_dict = item
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("item must be a dict"))?;
    let mut out: AttributeMap = HashMap::with_capacity(py_dict.len());
    for (key_obj, value_obj) in py_dict.iter() {
        let key = key_obj.extract::<String>()?;
        out.insert(key, py_object_value_to_attr(&value_obj)?);
    }
    Ok(out)
}

pub(crate) fn py_object_items_to_attr_maps(
    items: &Bound<'_, PyAny>,
) -> PyResult<Vec<AttributeMap>> {
    let py_list = items
        .downcast::<PyList>()
        .map_err(|_| PyTypeError::new_err("items must be a list"))?;
    let mut out = Vec::with_capacity(py_list.len());
    for item in py_list.iter() {
        out.push(py_object_item_to_attr_map(&item)?);
    }
    Ok(out)
}

pub(crate) fn py_object_expr_values_to_attr_map(
    values: &Bound<'_, PyAny>,
) -> PyResult<AttributeMap> {
    let py_dict = values
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("expression values must be a dict"))?;
    let mut out: AttributeMap = HashMap::with_capacity(py_dict.len());
    for (key_obj, value_obj) in py_dict.iter() {
        let key = key_obj.extract::<String>()?;
        out.insert(key, py_object_value_to_attr(&value_obj)?);
    }
    Ok(out)
}

pub(crate) fn py_string_map_to_hash_map(
    values: &Bound<'_, PyAny>,
) -> PyResult<HashMap<String, String>> {
    let py_dict = values
        .downcast::<PyDict>()
        .map_err(|_| PyTypeError::new_err("expression names must be a dict"))?;
    let mut out: HashMap<String, String> = HashMap::with_capacity(py_dict.len());
    for (key_obj, value_obj) in py_dict.iter() {
        let key = key_obj.extract::<String>()?;
        let value = value_obj.extract::<String>()?;
        out.insert(key, value);
    }
    Ok(out)
}

fn attr_to_py_wire_value(py: Python<'_>, value: &AttributeValue) -> PyResult<PyObject> {
    let out = PyDict::new(py);

    match value {
        AttributeValue::S(v) => out.set_item("S", v)?,
        AttributeValue::N(v) => out.set_item("N", v)?,
        AttributeValue::Bool(v) => out.set_item("BOOL", *v)?,
        AttributeValue::Null(v) => out.set_item("NULL", *v)?,
        AttributeValue::B(v) => out.set_item("B", PyBytes::new(py, v.as_ref()))?,
        AttributeValue::L(vs) => {
            let py_list = PyList::empty(py);
            for item in vs {
                py_list.append(attr_to_py_wire_value(py, item)?)?;
            }
            out.set_item("L", py_list)?;
        }
        AttributeValue::M(map) => {
            let py_map = PyDict::new(py);
            for (map_key, map_value) in map {
                py_map.set_item(map_key, attr_to_py_wire_value(py, map_value)?)?;
            }
            out.set_item("M", py_map)?;
        }
        AttributeValue::Ss(vs) => {
            let py_list = PyList::empty(py);
            for item in vs {
                py_list.append(item)?;
            }
            out.set_item("SS", py_list)?;
        }
        AttributeValue::Ns(vs) => {
            let py_list = PyList::empty(py);
            for item in vs {
                py_list.append(item)?;
            }
            out.set_item("NS", py_list)?;
        }
        AttributeValue::Bs(vs) => {
            let py_list = PyList::empty(py);
            for item in vs {
                py_list.append(PyBytes::new(py, item.as_ref()))?;
            }
            out.set_item("BS", py_list)?;
        }
        _ => {
            return Err(PyValueError::new_err(
                "unsupported DynamoDB attribute type in response",
            ))
        }
    }

    Ok(out.into_pyobject(py)?.unbind().into())
}

pub(crate) fn attr_map_to_py_wire_item(py: Python<'_>, item: &AttributeMap) -> PyResult<PyObject> {
    let py_dict = PyDict::new(py);
    for (key, value) in item {
        py_dict.set_item(key, attr_to_py_wire_value(py, value)?)?;
    }
    Ok(py_dict.into_pyobject(py)?.unbind().into())
}

pub(crate) fn attr_maps_to_py_wire_items(
    py: Python<'_>,
    items: &[AttributeMap],
) -> PyResult<PyObject> {
    let py_list = PyList::empty(py);
    for item in items {
        py_list.append(attr_map_to_py_wire_item(py, item)?)?;
    }
    Ok(py_list.into_pyobject(py)?.unbind().into())
}

pub(crate) fn optional_attr_map_to_py_wire_item(
    py: Python<'_>,
    item: Option<&AttributeMap>,
) -> PyResult<Option<PyObject>> {
    item.map(|entry| attr_map_to_py_wire_item(py, entry))
        .transpose()
}
