"""Provider enum for type-safe provider identifiers."""
