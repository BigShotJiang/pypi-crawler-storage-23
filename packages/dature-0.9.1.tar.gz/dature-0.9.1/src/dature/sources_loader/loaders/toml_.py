from datetime import time


def time_passthrough(value: time) -> time:
    return value
