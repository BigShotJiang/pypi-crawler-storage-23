# SimpleServer

A simple solution to create simples http(s) servers.
