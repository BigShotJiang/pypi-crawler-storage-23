from sys import argv
from http import HTTPMethod

from simpserver.handler import serve_api
from simpserver.router import route
import routes

"""
TODO:
    1. Get request body data. DONE.
    2. Create ensure body keys decorator. DONE.
    3. Get request params in url (GET Method). And decoding. DONE.
    4. Handle exceptions to return hints of errors and properly status code. DONE.
    5. Create middleware decorator. DONE.
    6. Add user info param injection. DONE.
    7. Handle json.loads to raise bad request error.
    8. Create ensure exists in db. DONE.
"""

@route("/test/<name:str>", HTTPMethod.GET)
def test(path_params: dict) -> dict:
    return path_params

if len(argv) < 3 or not argv[2].isnumeric():
    print("WRONG USAGE!")
    print("python3 <file> ip port")
    exit(1)

serve_api(argv[1], int(argv[2]))
