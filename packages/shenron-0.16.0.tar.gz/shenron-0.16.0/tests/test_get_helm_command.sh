#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmpdir="$(mktemp -d)"
asset_dir="$tmpdir/assets"
work_dir="$tmpdir/work"
version="$(python3 -c 'import importlib.metadata; print(importlib.metadata.version("shenron"))')"
chart_pkg="shenron-${version}.tgz"

mkdir -p "$asset_dir" "$work_dir"
mkdir -p "$asset_dir/chart-root/shenron"
cp -R "$ROOT_DIR/helm/." "$asset_dir/chart-root/shenron/"
tar -czf "$asset_dir/$chart_pkg" -C "$asset_dir/chart-root" shenron
cat > "$asset_dir/index.yaml" <<EOF
apiVersion: v1
entries:
  shenron:
    - version: ${version}
      urls:
        - https://example.invalid/${chart_pkg}
generated: "2026-01-01T00:00:00Z"
EOF

shenron get \
  --helm \
  --release "$version" \
  --index-url "file://$asset_dir/index.yaml" \
  --base-url "file://$asset_dir/" \
  --dir "$work_dir/shenron-helm"

required=(
  "$work_dir/shenron-helm/Chart.yaml"
  "$work_dir/shenron-helm/values.yaml"
  "$work_dir/shenron-helm/models.yaml"
  "$work_dir/shenron-helm/templates/_helpers.tpl"
  "$work_dir/shenron-helm/templates/model-deployments.yaml"
  "$work_dir/shenron-helm/templates/model-services.yaml"
  "$work_dir/shenron-helm/templates/onwards-configmap.yaml"
  "$work_dir/shenron-helm/templates/onwards-deployment.yaml"
  "$work_dir/shenron-helm/templates/onwards-service.yaml"
)

for f in "${required[@]}"; do
  if [ ! -f "$f" ]; then
    echo "expected file not found after shenron get --helm: $f" >&2
    exit 1
  fi
done

echo "shenron get --helm downloaded and unpacked expected chart files"
