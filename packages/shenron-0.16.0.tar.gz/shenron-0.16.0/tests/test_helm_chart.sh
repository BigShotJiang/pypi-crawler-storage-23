#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm not available, skipping chart lint/render test"
  exit 0
fi

helm lint "$ROOT_DIR/helm"
helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/models.yaml" >/dev/null

echo "helm chart lint/template succeeded"
