"""claude-relay: OpenAI-compatible API server that routes through Claude Code."""

__version__ = "0.1.0"
