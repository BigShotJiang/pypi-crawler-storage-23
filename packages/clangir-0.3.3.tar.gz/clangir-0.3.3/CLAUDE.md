Follow the instructions in @AGENTS.md

## Communication

When I ask a question, answer the question. Do not take action unless I explicitly ask you to do something. Questions are for gathering information; instructions are for taking action.
