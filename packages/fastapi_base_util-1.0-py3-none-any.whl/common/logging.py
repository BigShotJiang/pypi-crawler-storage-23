import os
import sys
import logging
import traceback


def logging_config(app_name: str):
    # 日志目录
    log_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../log"))
    if not os.path.exists(log_dir):
        os.mkdir(log_dir)
    file_path = log_dir + '/' + app_name + '.log'

    return {
        "version": 1,
        # disable_existing_loggers 表示弃用已经存在的日志，True表示弃用，False表示不弃用。
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "()": "uvicorn.logging.DefaultFormatter",
                "fmt": "%(asctime)s %(levelname)s %(message)s",
                "use_colors": None
            },
            "access": {
                "()": "uvicorn.logging.AccessFormatter",
                "fmt": "%(asctime)s %(levelname)s %(client_addr)s - \"%(request_line)s\" %(status_code)s"
            },
            'standard': {
                'format': '%(asctime)s %(levelname)s %(message)s'
            },
        },
        "handlers": {
            "default": {
                "formatter": "default",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stderr",
            },
            "access": {
                "formatter": "access",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
            },
            "logfile": {
                "level": "INFO",
                "class": "logging.handlers.TimedRotatingFileHandler",  # 保存到文件，自动切
                "filename": file_path,  # 日志文件的位置
                "when": "midnight",  # 间间隔的类型
                "interval": 1,  # 时间间隔
                "backupCount": 60,  # 能留几个日志文件
                "formatter": "standard",  # 使用哪种日志格式
                "encoding": "utf-8",  # 保存的格式
            }
        },
        "loggers": {
            "uvicorn": {
                "handlers": ["default", "logfile"],
                "level": "INFO",
                "propagate": False  # 向不向更高级别的logger传递
            },
            "uvicorn.error": {
                "level": "INFO"
            },
            "uvicorn.access": {
                # 隐藏该日志，防止和自定义的access日志冲突
                # "handlers": ["access", "logfile"],
                "level": "INFO",
                "propagate": False
            },
            "fastapi": {
                "handlers": ["default", "logfile"],
                "level": "INFO",
                "propagate": False
            }
        }
    }


def log_exc(e):
    typ, value, tb = sys.exc_info()
    logger.error(f"Uncaught exception {repr(value)}\nTraceback:{''.join(traceback.format_tb(tb))}")


logger = logging.getLogger('fastapi')

