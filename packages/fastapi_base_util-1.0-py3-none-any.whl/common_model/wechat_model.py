from tortoise import fields
from enum import Enum
from common_model.base_model import CreateModel

class AppTypeEnum(str, Enum):
    MINI_PROGRAM = "mini_program"
    OFFICIAL_ACCOUNT = "official_account"


class WechatApp(CreateModel):
    """
    微信应用配置表
    """
    id = fields.IntField(pk=True, description="主键")
    app_name = fields.CharField(max_length=50, description="应用名称")
    app_id = fields.CharField(max_length=50, description="微信AppID")
    app_secret = fields.CharField(max_length=100, description="微信AppSecret")
    token = fields.CharField(max_length=32, null=True, description="消息校验Token")
    msg_secret = fields.CharField(max_length=43, null=True, description="消息加解密Key")
    app_type = fields.CharEnumField(AppTypeEnum, description="应用类型")

    class Meta:
        table = "wechat_app"
        table_description = "微信应用配置表"


class WechatUser(CreateModel):
    """
    微信用户关联表
    """
    id = fields.IntField(pk=True, description="主键")
    user = fields.ForeignKeyField("main.User", related_name="wechat_users", description="关联用户")
    wechat_app = fields.ForeignKeyField("main.WechatApp", related_name="wechat_users", description="关联微信应用")
    openid = fields.CharField(max_length=64, index=True, description="微信OpenID")
    unionid = fields.CharField(max_length=64, null=True, index=True, description="微信UnionID")
    session_key = fields.CharField(max_length=128, null=True, description="会话密钥(仅小程序)")
    nickname = fields.CharField(max_length=64, null=True, description="微信昵称")
    avatar = fields.CharField(max_length=255, null=True, description="微信头像")

    class Meta:
        table = "wechat_user"
        table_description = "微信用户关联表"
        unique_together = (("openid", "wechat_app"),)
