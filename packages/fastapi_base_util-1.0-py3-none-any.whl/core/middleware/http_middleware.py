import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.types import ASGIApp
from starlette.responses import Response
from common.logging import logger

class RequestHttpMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers['X-Process-Time'] = str(process_time)
        self.write_request_log(request, response)
        return response

    @staticmethod
    def write_request_log(request: Request, response: Response) -> None:
        http_version = f"http/{request.scope['http_version']}"
        process_time = response.headers["X-Process-Time"]
        # 获取客户端IP和端口
        client_host = request.client.host if request.client else "unknown"
        client_port = request.client.port if request.client else "unknown"
        content = f"{client_host}:{client_port} - {request.method} {request.url} {http_version} {response.status_code} {round(float(process_time), 2)}ms"
        logger.info(content)
