import time
import asyncio
from contextlib import asynccontextmanager
from typing import Optional, Union, Callable, Mapping
from redis.asyncio import Redis
from redis import asyncio as aioredis
from redis.typing import KeyT, EncodableT, ExpiryT, ZScoreBoundT, AnyKeyT
from common.logging import log_exc
from core.base_config import base_config


class AioRedis:
    """异步 Redis 客户端封装"""

    __redis_pool: Redis | None = None
    __connection_lock: asyncio.Lock = asyncio.Lock()  # 确保连接池初始化线程安全

    @classmethod
    async def connect(cls) -> Redis:
        """获取 Redis 连接（单例连接池）"""
        if cls.__redis_pool:
            return cls.__redis_pool

        # 使用锁确保连接池初始化的线程安全
        async with cls.__connection_lock:
            if not cls.__redis_pool:  # 双重检查
                try:
                    pool = aioredis.ConnectionPool.from_url(
                        base_config.redis_url,
                        encoding='utf-8',
                        decode_responses=True,
                        retry_on_timeout=True  # 增加超时重试
                    )
                    cls.__redis_pool = Redis(connection_pool=pool)
                    # 测试连接是否有效
                    cls.__redis_pool.ping()
                except Exception as e:
                    log_exc(e)
                    raise
        return cls.__redis_pool

    @classmethod
    async def close(cls) -> None:
        """关闭 Redis 连接池"""
        if cls.__redis_pool:
            # 安全关闭连接池
            try:
                await cls.__redis_pool.connection_pool.disconnect()
            except Exception as e:
                log_exc(e)
            finally:
                cls.__redis_pool = None

    @classmethod
    @asynccontextmanager
    async def session(cls):
        """上下文管理器，自动管理连接生命周期"""
        try:
            redis = await cls.connect()
            yield redis
        finally:
            # 连接池模式下不需要每次关闭，由外部统一管理
            pass

    @classmethod
    async def get(cls, name: KeyT) -> Optional[bytes]:
        redis = await cls.connect()
        result = await redis.get(name)
        return result

    @classmethod
    async def set(
            cls,
            name: KeyT,
            value: EncodableT,
            ex: Union[ExpiryT, None] = None,  # 超时秒数
            px: Union[ExpiryT, None] = None,  # 超时毫秒
            nx: bool = False,
            xx: bool = False
    ) -> Optional[bool]:
        redis = await cls.connect()
        result = await redis.set(name, value, ex=ex, px=px, nx=nx, xx=xx)
        return result

    @classmethod
    async def exists(
        cls,
        *names: KeyT
    ) -> Optional[bool]:
        redis = await cls.connect()
        result = await redis.exists(*names)
        return result

    @classmethod
    async def zadd(
            cls,
            name: KeyT,
            mapping: Mapping[AnyKeyT, EncodableT],
            nx: bool = False,
            xx: bool = False,
            ch: bool = False,
            incr: bool = False,
            gt: bool = False,
            lt: bool = False
    ) -> Union[int, float]:
        redis = await cls.connect()
        result = await redis.zadd(name, mapping, nx, xx, ch, incr, gt, lt)
        return result

    @classmethod
    async def zrem(cls, name: KeyT, values) -> int:
        redis = await cls.connect()
        result = await redis.zrem(name, values)
        return result

    @classmethod
    async def zscore(
            cls,
            name: KeyT,
            value: EncodableT
    ) -> Optional[float]:
        redis = await cls.connect()
        result = await redis.zscore(name, value)
        return result

    @classmethod
    async def zcard(cls, name: KeyT) -> int:
        redis = await cls.connect()
        result = await redis.zcard(name)
        return result

    @classmethod
    async def zrevrangebyscore(
            cls,
            name: KeyT,
            max: ZScoreBoundT,
            min: ZScoreBoundT,
            start: Union[int, None] = None,
            num: Union[int, None] = None,
            withscores: bool = False,
            score_cast_func: Union[type, Callable] = float,
    ):
        redis = await cls.connect()
        result = await redis.zrevrangebyscore(name, max, min, start, num, withscores, score_cast_func)
        return result

    @classmethod
    async def zremrangebyscore(
            cls,
            name: KeyT,
            min: ZScoreBoundT,
            max: ZScoreBoundT
    ) -> int:
        redis = await cls.connect()
        result = await redis.zremrangebyscore(name, min, max)
        return result

    @classmethod
    async def delete(cls, *names: KeyT) -> int:
        redis = await cls.connect()
        result = await redis.delete(*names)
        return result

    @classmethod
    async def ttl(cls, name: KeyT) -> int:
        redis = await cls.connect()
        result = await redis.ttl(name)
        return result

    @classmethod
    async def expire(cls, name: KeyT, expire: ExpiryT) -> int:
        redis = await cls.connect()
        return await redis.expire(name, expire)

    @classmethod
    async def incrby(cls, name: KeyT, amount: int = 1) -> int:
        redis = await cls.connect()
        return await redis.incrby(name, amount)

    @classmethod
    async def decrby(cls, name: KeyT, amount: int = 1) -> int:
        redis = await cls.connect()
        return await redis.decrby(name, amount)

    # 分布式锁实现优化
    @classmethod
    @asynccontextmanager
    async def lock(
        cls,
        name: str,
        value: EncodableT = 1,
        timeout: int = 3,  # 等待锁的时间（秒）
        expire: int = 3    # 锁的有效期（秒）
    ):
        if isinstance(value, int):
            value = str(value)
        
        lock_key = f"lock:{name}"
        acquired = False
        renewal_task: asyncio.Task | None = None
        
        try:
            # 获取锁
            timeout_at = time.time() + timeout
            while time.time() < timeout_at:
                # 使用 set 命令的 nx 和 ex 参数原子性获取锁
                result = await cls.set(lock_key, value, nx=True, ex=expire)
                if result:
                    acquired = True
                    break
                await asyncio.sleep(0.1)  # 短暂等待后重试
            
            if not acquired:
                raise Exception(f'获取分布式锁失败：{name}')
            
            # 启动锁续期任务（只在需要时启动）
            async def renewal():
                # 续期间隔设为锁有效期的 1/3，确保在锁过期前完成续期
                renewal_interval = max(0.1, expire / 3)
                while acquired:
                    # 检查剩余时间，不足 1 秒时续期
                    if await cls.ttl(lock_key) < 1:
                        await cls.expire(lock_key, expire)
                    await asyncio.sleep(renewal_interval)
            
            renewal_task = asyncio.create_task(renewal())
            yield acquired
        
        except Exception as e:
            log_exc(e)
            raise
        finally:
            # 清理工作
            acquired = False  # 停止续期任务
            if renewal_task:
                # 等待续期任务结束
                renewal_task.cancel()
                try:
                    await renewal_task
                except asyncio.CancelledError:
                    pass
            
            # 只删除自己持有的锁
            if await cls.get(lock_key) == value:
                await cls.delete(lock_key)

    @classmethod
    async def pass_fix_window(cls, name: str, limit: int, expire: int) -> bool:
        """固定窗口限流算法"""
        key = f"ratelimit:fixed:{name}"
        async with cls.lock(name):
            # 使用 incr 原子操作替代 get + set，减少 Redis 调用
            count = await cls.incrby(key, 1)
            # 首次设置过期时间
            if count == 1:
                await cls.expire(key, expire)
            # 将 count 转换为整数后再进行比较
            return count <= limit


    @classmethod
    async def pass_slide_window(cls, name, limit, expire):
        """限流：滑动窗口"""
        key = f"slidelimit:fixed:{name}"
        async with cls.lock(name):
            count = await cls.zcard(key)
            if not count or count < limit:
                now_timestamp = int(time.time() * 1000)
                old_timestamp = now_timestamp - expire * 1000
                await cls.zadd(key, {str(now_timestamp): now_timestamp})
                await cls.zremrangebyscore(key, 0, old_timestamp)
                await cls.expire(key, expire)
                return True
            else:
                now_timestamp = int(time.time() * 1000)
                old_timestamp = now_timestamp - expire * 1000
                await cls.zremrangebyscore(key, 0, old_timestamp)

            return False