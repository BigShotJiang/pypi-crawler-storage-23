import os
from typing import Any, AsyncGenerator
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError, ResponseValidationError
from starlette.middleware.cors import CORSMiddleware
from starlette.staticfiles import StaticFiles
from common.exception import AllExceptionHandler, CustomException, CustomExceptionHandler, HttpExceptionHandler, RequestValidationHandle, ResponseValidationHandle, ValueExceptionHandler
from common.logging import logger
from core.base_config import BaseConfig, base_config
from core.databases.aiodb import AioDb
from core.middleware.http_middleware import RequestHttpMiddleware


def start_server(config: BaseConfig):

    app = FastAPI(
        debug=config.app_debug,
        title=config.app_title,
        openapi_url=f'/docs/{config.app_name}/openapi.json' if config.app_debug else None,
        docs_url=f'/docs/{config.app_name}' if config.app_debug else None,
        redoc_url=f'/redoc/{config.app_name}' if config.app_debug else None,
        lifespan=lifespan
    )

    # 设置配置属性
    app.state.config = config

    # 注册异常处理
    register_exceptoin(app)
    # 注册中间件
    register_middlewares(app)
    # 注册静态文件
    register_files(app)

    return app


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[Any, Any]:
    """
    自定义生命周期
    """
    config: BaseConfig = app.state.config
    tortoise = await AioDb.register_db(app)
    try:
        # 初始化数据库
        await tortoise.init_orm()
        logger.info(f'【{config.app_title}】服务成功启动...')
    except Exception as e:
        logger.error(f'【{config.app_title}】服务启动失败: {str(e)}')
        raise e

    yield

    await tortoise.close_orm()
    logger.info(f'【{config.app_title} 】服务关闭...')


def register_exceptoin(app: FastAPI):
    """
    注册异常处理
    """
    app.add_exception_handler(CustomException, CustomExceptionHandler)  # pyright: ignore[reportArgumentType]
    app.add_exception_handler(HTTPException, HttpExceptionHandler)  # pyright: ignore[reportArgumentType]
    app.add_exception_handler(RequestValidationError, RequestValidationHandle)  # pyright: ignore[reportArgumentType]
    app.add_exception_handler(ResponseValidationError, ResponseValidationHandle)  # pyright: ignore[reportArgumentType]
    app.add_exception_handler(ValueError, ValueExceptionHandler)  # pyright: ignore[reportArgumentType]
    app.add_exception_handler(Exception, AllExceptionHandler) # pyright: ignore[reportArgumentType]


def register_middlewares(app: FastAPI) -> None:
    """
    注册中间件
    """
    app.add_middleware(RequestHttpMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=base_config.cors_origins,
        allow_credentials=base_config.cors_allow_credentials,
        allow_methods=base_config.cors_allow_methods,
        allow_headers=base_config.cors_allow_headers
    )


def register_files(app: FastAPI) -> None:
    """
    注册文件相关配置
    """
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../static"))
    if not os.path.exists(static_dir):
        os.mkdir(static_dir)
    app.mount('/static', StaticFiles(directory=static_dir))
