"""Storage utilities for vocal-core"""

__all__ = []
