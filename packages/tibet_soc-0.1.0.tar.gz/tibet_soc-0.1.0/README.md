# tibet-soc — Security Operations Center with TIBET Provenance

Unified threat detection, event correlation, and incident response for the
TIBET ecosystem. Every SOC decision is recorded as a TIBET token — an audit
trail for the auditor.

## What It Does

tibet-soc is the central nervous system of TIBET security. It aggregates
signals from every TIBET tool and correlates them into actionable alerts:

| Source             | Signal Type                       |
|--------------------|-----------------------------------|
| **tibet-audit**    | Compliance violations, policy     |
| **tibet-db**       | Data access anomalies, tampering  |
| **tibet-edge**     | Boundary crossings, perimeter     |
| **tibet-mirror**   | Supply chain integrity failures   |
| **tibet-snap**     | State deviations, rollback events |
| **tibet-nis2**     | NIS2 compliance incidents         |
| **inject-bender**  | Injection attacks, exploit probes |

### Event Correlation

Multiple low-severity events can indicate a high-severity attack:

- **Brute Force** — 3+ auth failures from same source in 5 minutes
- **APT Attack** — data breach combined with privilege escalation
- **Supply Chain Compromise** — supply chain event from tibet-mirror
- **Insider Threat** — anomaly + policy violation from same asset

### Playbook-Driven Response

Automated response actions based on threat type:

- `isolate_asset` — quarantine the compromised asset
- `snapshot_state` — capture state via tibet-snap for forensics
- `block_source` — block the offending source at the perimeter
- `notify_team` — alert the security team
- `escalate_nis2` — trigger NIS2 incident reporting workflow

### TIBET Provenance

Every SOC decision produces a TIBET token:

- **ERIN:** event/alert/decision details
- **ERAAN:** correlated events, source tools, `jis:` identity
- **EROMHEEN:** SOC node, analyst, timestamp
- **ERACHTER:** correlation pattern or playbook execution context

## Installation

```bash
pip install tibet-soc
```

With optional integrations:

```bash
pip install tibet-soc[full]  # rich CLI + tibet-nis2/snap/db
```

## CLI

```bash
tibet-soc info         # Concept overview
tibet-soc demo         # Full demo: ingest, correlate, detect, respond
tibet-soc playbooks    # List default playbooks
tibet-soc status       # SOC dashboard stats
```

## Python API

```python
from tibet_soc import SOCEngine, SecurityEvent, Playbook

# Create SOC engine
soc = SOCEngine()

# Ingest events from multiple sources
soc.ingest(SecurityEvent(
    source="inject-bender",
    severity="HIGH",
    event_type="intrusion",
    description="SQL injection attempt blocked",
    asset_id="web-server-01",
))

soc.ingest(SecurityEvent(
    source="tibet-db",
    severity="CRITICAL",
    event_type="data_breach",
    description="Unauthorized bulk data export",
    asset_id="db-primary",
))

# Correlate events and detect patterns
alerts = soc.correlate()
for alert in alerts:
    print(f"[{alert.severity}] {alert.title}")

# Execute playbook for alert
soc.execute_playbook(alerts[0])

# Dashboard stats
print(soc.stats())
```

## License

MIT — Humotica / J. van de Meent
