"""
tibet-soc — Security Operations Center with TIBET Provenance
=============================================================

Unified threat detection, event correlation, and incident response.
Aggregates signals from all TIBET tools. Correlates low-severity events
into high-severity alerts. Responds with playbook-driven automation.

Every SOC decision = TIBET token. An audit trail for the auditor.

Usage::

    from tibet_soc import SOCEngine, SecurityEvent, Playbook

    soc = SOCEngine()
    soc.ingest(SecurityEvent(
        source="inject-bender",
        severity="HIGH",
        event_type="intrusion",
        description="SQL injection blocked",
        asset_id="web-01",
    ))

    alerts = soc.correlate()
    for alert in alerts:
        soc.execute_playbook(alert)

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica 2025
"""

from .engine import SOCEngine, SecurityEvent, Alert, Playbook
from .provenance import SOCProvenance

__version__ = "0.1.0"

__all__ = [
    "SOCEngine",
    "SecurityEvent",
    "Alert",
    "Playbook",
    "SOCProvenance",
]
