"""
tibet-soc CLI — Security Operations Center.

Usage::

    tibet-soc info         Concept overview
    tibet-soc demo         Full demo: ingest, correlate, detect, respond
    tibet-soc playbooks    List default playbooks
    tibet-soc status       SOC dashboard stats
"""

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta

from .engine import SOCEngine, SecurityEvent, Alert, Playbook


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  TIBET-SOC — Security Operations Center")
    print("=" * 64)
    print()
    print("  The Problem: Isolated Alerts, Missed Attacks")
    print("    Each security tool sees its own slice.")
    print("    An auth failure here, a policy violation there,")
    print("    a supply chain anomaly somewhere else.")
    print("    Alone: noise. Together: an APT attack in progress.")
    print()
    print("  How tibet-soc works:")
    print("    1. INGEST events from all TIBET tools")
    print("    2. CORRELATE across sources and time windows")
    print("    3. DETECT attack patterns (brute force, APT, insider)")
    print("    4. RESPOND with automated playbooks")
    print("    5. PROVE every decision with TIBET tokens")
    print()
    print("  Event Sources:")
    print("    tibet-audit ........ compliance violations, policy")
    print("    tibet-db ........... data access anomalies, tampering")
    print("    tibet-edge ......... boundary crossings, perimeter")
    print("    tibet-mirror ....... supply chain integrity failures")
    print("    tibet-snap ......... state deviations, rollback events")
    print("    tibet-nis2 ......... NIS2 compliance incidents")
    print("    inject-bender ...... injection attacks, exploit probes")
    print()
    print("  Correlation Rules:")
    print("    3+ auth_failures same source (5 min)  -> Brute Force")
    print("    data_breach + privilege_escalation     -> APT Attack")
    print("    supply_chain from tibet-mirror         -> Supply Chain")
    print("    anomaly + policy_violation same asset  -> Insider Threat")
    print()
    print("  Playbooks:")
    print("    isolate_asset ..... quarantine compromised asset")
    print("    snapshot_state .... forensic capture via tibet-snap")
    print("    block_source ...... block at perimeter via tibet-edge")
    print("    notify_team ....... alert security team")
    print("    escalate_nis2 ..... NIS2 incident reporting workflow")
    print()
    print("  Provenance (TIBET Token per decision):")
    print("    ERIN:      event/alert/decision details")
    print("    ERAAN:     correlated events, source tools, jis: URI")
    print("    EROMHEEN:  SOC node, analyst, timestamp")
    print("    ERACHTER:  correlation pattern or playbook context")
    print()
    print("=" * 64)
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  TIBET-SOC Demo: Multi-Source Attack Detection")
    print("=" * 64)

    soc = SOCEngine()
    now = datetime.now(timezone.utc)

    # ---------------------------------------------------------------
    # Phase 1: Ingest events from multiple sources
    # ---------------------------------------------------------------
    print("\n  Phase 1: Ingesting Events")
    print("  " + "-" * 40)

    events = [
        SecurityEvent(
            source="inject-bender",
            severity="MEDIUM",
            event_type="auth_failure",
            description="Failed login attempt from 10.0.0.50",
            asset_id="web-server-01",
            timestamp=(now - timedelta(minutes=4)).isoformat(),
            metadata={"source_ip": "10.0.0.50", "username": "admin"},
        ),
        SecurityEvent(
            source="inject-bender",
            severity="MEDIUM",
            event_type="auth_failure",
            description="Failed login attempt from 10.0.0.50",
            asset_id="web-server-01",
            timestamp=(now - timedelta(minutes=3)).isoformat(),
            metadata={"source_ip": "10.0.0.50", "username": "root"},
        ),
        SecurityEvent(
            source="inject-bender",
            severity="MEDIUM",
            event_type="auth_failure",
            description="Failed login attempt from 10.0.0.50",
            asset_id="web-server-01",
            timestamp=(now - timedelta(minutes=2)).isoformat(),
            metadata={"source_ip": "10.0.0.50", "username": "administrator"},
        ),
        SecurityEvent(
            source="tibet-db",
            severity="CRITICAL",
            event_type="data_breach",
            description="Unauthorized bulk data export from customer_db",
            asset_id="db-primary",
            timestamp=(now - timedelta(minutes=1)).isoformat(),
            metadata={"table": "customers", "rows_exported": 50000},
        ),
        SecurityEvent(
            source="tibet-audit",
            severity="HIGH",
            event_type="privilege_escalation",
            description="User escalated to admin without approval",
            asset_id="db-primary",
            timestamp=(now - timedelta(seconds=30)).isoformat(),
            metadata={"user": "svc_backup", "from_role": "reader", "to_role": "admin"},
        ),
        SecurityEvent(
            source="tibet-mirror",
            severity="CRITICAL",
            event_type="supply_chain",
            description="Dependency checksum mismatch: libcrypto v3.1.2",
            asset_id="build-pipeline-01",
            timestamp=now.isoformat(),
            metadata={"package": "libcrypto", "version": "3.1.2", "expected_hash": "abc123", "actual_hash": "def456"},
        ),
        SecurityEvent(
            source="tibet-edge",
            severity="MEDIUM",
            event_type="anomaly",
            description="Unusual outbound traffic pattern detected",
            asset_id="workstation-42",
            timestamp=(now - timedelta(minutes=2)).isoformat(),
            metadata={"bytes_out": 500_000_000, "destination": "external"},
        ),
        SecurityEvent(
            source="tibet-audit",
            severity="MEDIUM",
            event_type="policy_violation",
            description="USB storage device connected in restricted zone",
            asset_id="workstation-42",
            timestamp=(now - timedelta(minutes=1)).isoformat(),
            metadata={"device_type": "usb_storage", "zone": "restricted"},
        ),
    ]

    for event in events:
        soc.ingest(event)
        severity_marker = {
            "CRITICAL": "[!!]",
            "HIGH": "[! ]",
            "MEDIUM": "[ .]",
            "LOW": "[  ]",
            "INFO": "[  ]",
        }.get(event.severity, "[  ]")
        print(f"    {severity_marker} {event.source:<16} {event.event_type:<24} {event.description[:40]}")

    print(f"\n    Total events ingested: {len(events)}")

    # ---------------------------------------------------------------
    # Phase 2: Correlate and detect
    # ---------------------------------------------------------------
    print("\n  Phase 2: Correlation & Detection")
    print("  " + "-" * 40)

    alerts = soc.correlate()

    if not alerts:
        print("    No alerts generated.")
    else:
        for alert in alerts:
            status_icon = {
                "CRITICAL": "[CRITICAL]",
                "HIGH": "[HIGH]    ",
                "MEDIUM": "[MEDIUM]  ",
            }.get(alert.severity, "[INFO]    ")
            print(f"    {status_icon} {alert.title}")
            print(f"               {alert.description}")
            print(f"               Events: {len(alert.events)} | "
                  f"Playbook: {alert.playbook_id} | "
                  f"Status: {alert.status}")
            print()

    # ---------------------------------------------------------------
    # Phase 3: Playbook execution results
    # ---------------------------------------------------------------
    print("  Phase 3: Playbook Response")
    print("  " + "-" * 40)

    stats = soc.stats()
    if stats["total_playbook_executions"] > 0:
        print(f"    Playbooks auto-executed: {stats['total_playbook_executions']}")
        for execution in soc._executed:
            alert_match = next((a for a in alerts if a.id == execution["alert_id"]), None)
            alert_title = alert_match.title if alert_match else execution["alert_id"]
            print(f"\n    Playbook: {execution['playbook']}")
            print(f"    Alert:    {alert_title}")
            for action in execution["actions"]:
                print(f"      -> {action['action']}: {action['target']} "
                      f"{action.get('params', {})}")
    else:
        print("    No playbooks executed.")

    # ---------------------------------------------------------------
    # Phase 4: Timeline
    # ---------------------------------------------------------------
    print("\n  Phase 4: Event Timeline")
    print("  " + "-" * 40)

    timeline = soc.timeline()
    for entry in timeline:
        ts = entry["timestamp"][-15:-6] if len(entry["timestamp"]) > 15 else entry["timestamp"]
        kind = entry["type"].upper()[:5]
        sev = entry["severity"][:4]
        desc = entry["description"][:48]
        print(f"    {ts}  [{kind}] [{sev}] {desc}")

    # ---------------------------------------------------------------
    # Phase 5: Dashboard
    # ---------------------------------------------------------------
    print("\n  Phase 5: SOC Dashboard")
    print("  " + "-" * 40)

    st = soc.stats()
    print(f"    Events ingested:     {st['total_events']}")
    print(f"    Alerts generated:    {st['total_alerts']}")
    print(f"    Playbooks executed:  {st['total_playbook_executions']}")
    print(f"    TIBET tokens:        {st['total_tibet_tokens']}")
    print(f"    Playbooks loaded:    {st['playbooks_loaded']}")

    print(f"\n    Alerts by severity:")
    for sev, count in sorted(st["alerts_by_severity"].items()):
        print(f"      {sev:<12} {count}")

    print(f"\n    Events by source:")
    for source, count in sorted(st["events_by_source"].items()):
        print(f"      {source:<16} {count}")

    # ---------------------------------------------------------------
    # Phase 6: Provenance chain
    # ---------------------------------------------------------------
    print("\n  Phase 6: TIBET Provenance Chain")
    print("  " + "-" * 40)

    chain = soc.provenance.chain()
    for token in chain[:6]:  # Show first 6 tokens
        print(f"    Token: {token['token_id']}")
        print(f"      Action:  {token['action']}")
        print(f"      Intent:  {token['erachter'].get('intent', '')[:55]}")
        print(f"      JIS:     {token['eraan'].get('event_jis', '')}")
        print(f"      Parent:  {token['parent_id'] or '(root)'}")
        print()

    if len(chain) > 6:
        print(f"    ... and {len(chain) - 6} more tokens in chain.")

    print("=" * 64)
    print()
    return 0


def cmd_playbooks(args: argparse.Namespace) -> int:
    soc = SOCEngine()
    playbooks = soc.list_playbooks()

    if args.json:
        data = [pb.to_dict() for pb in playbooks]
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"  {'Playbook':<22} {'Trigger':<26} {'Sev':<10} {'Auto':<6} Description")
        print("  " + "-" * 100)
        for pb in playbooks:
            auto = "YES" if pb.auto_execute else "no"
            desc = pb.description[:42]
            print(
                f"  {pb.name:<22} {pb.trigger_type:<26} {pb.trigger_severity:<10} "
                f"{auto:<6} {desc}"
            )
        print()
        print(f"  Total: {len(playbooks)} playbooks loaded.")
        print()

    return 0


def cmd_status(args: argparse.Namespace) -> int:
    soc = SOCEngine()

    if args.json:
        print(json.dumps(soc.stats(), indent=2))
    else:
        print()
        print("=" * 48)
        print("  TIBET-SOC Dashboard")
        print("=" * 48)
        st = soc.stats()
        print(f"\n  Events ingested:       {st['total_events']}")
        print(f"  Alerts generated:      {st['total_alerts']}")
        print(f"  Playbooks executed:    {st['total_playbook_executions']}")
        print(f"  TIBET tokens:          {st['total_tibet_tokens']}")
        print(f"  Playbooks loaded:      {st['playbooks_loaded']}")
        print()
        print("  (Ingest events to see activity. Try: tibet-soc demo)")
        print()

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-soc",
        description="Security Operations Center with TIBET Provenance",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="Concept overview")
    sub.add_parser("demo", help="Full demo: ingest, correlate, detect, respond")

    p_pb = sub.add_parser("playbooks", help="List default playbooks")
    p_pb.add_argument("-j", "--json", action="store_true")

    p_st = sub.add_parser("status", help="SOC dashboard stats")
    p_st.add_argument("-j", "--json", action="store_true")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "demo": cmd_demo,
        "playbooks": cmd_playbooks,
        "status": cmd_status,
    }
    sys.exit(commands[args.command](args))
