"""
Core SOC engine — ingest, correlate, detect, respond.

Every event from every TIBET tool flows through here. The engine
correlates them into alerts and drives automated response.
"""

import hashlib
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

from .provenance import SOCProvenance


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
EVENT_TYPES = (
    "intrusion",
    "data_breach",
    "policy_violation",
    "anomaly",
    "supply_chain",
    "auth_failure",
    "privilege_escalation",
)
ALERT_STATUSES = ("NEW", "INVESTIGATING", "MITIGATING", "RESOLVED", "FALSE_POSITIVE")
SOURCES = (
    "tibet-audit",
    "tibet-db",
    "tibet-edge",
    "tibet-mirror",
    "tibet-snap",
    "tibet-nis2",
    "inject-bender",
)


def _new_id(prefix: str = "evt") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class SecurityEvent:
    """A single security event from any TIBET tool."""

    source: str  # tibet-audit, tibet-db, inject-bender, ...
    severity: str  # CRITICAL / HIGH / MEDIUM / LOW / INFO
    event_type: str  # intrusion, data_breach, policy_violation, ...
    description: str
    asset_id: str = ""
    id: str = ""
    timestamp: str = ""
    metadata: dict = field(default_factory=dict)
    tibet_token_id: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            self.id = _new_id("evt")
        if not self.timestamp:
            self.timestamp = _now_iso()

    @property
    def timestamp_dt(self) -> datetime:
        return datetime.fromisoformat(self.timestamp)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "source": self.source,
            "severity": self.severity,
            "event_type": self.event_type,
            "description": self.description,
            "asset_id": self.asset_id,
            "metadata": self.metadata,
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class Alert:
    """A correlated alert derived from one or more events."""

    severity: str
    title: str
    description: str
    events: list[str] = field(default_factory=list)  # event IDs
    id: str = ""
    timestamp: str = ""
    playbook_id: str = ""
    status: str = "NEW"
    assigned_to: str = ""
    tibet_token_id: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            self.id = _new_id("alrt")
        if not self.timestamp:
            self.timestamp = _now_iso()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "events": self.events,
            "playbook_id": self.playbook_id,
            "status": self.status,
            "assigned_to": self.assigned_to,
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class Playbook:
    """An automated response playbook triggered by alert type."""

    name: str
    trigger_type: str  # event_type or alert pattern
    trigger_severity: str  # minimum severity to trigger
    actions: list[dict] = field(default_factory=list)
    id: str = ""
    description: str = ""
    auto_execute: bool = False

    def __post_init__(self) -> None:
        if not self.id:
            self.id = _new_id("pb")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "trigger_type": self.trigger_type,
            "trigger_severity": self.trigger_severity,
            "actions": self.actions,
            "description": self.description,
            "auto_execute": self.auto_execute,
        }


# ---------------------------------------------------------------------------
# Default playbooks
# ---------------------------------------------------------------------------

def _default_playbooks() -> list[Playbook]:
    return [
        Playbook(
            id="pb-isolate",
            name="isolate_asset",
            trigger_type="brute_force",
            trigger_severity="HIGH",
            description="Quarantine the compromised asset from the network.",
            auto_execute=True,
            actions=[
                {"action": "isolate", "target": "{{asset_id}}", "params": {"method": "network_block"}},
                {"action": "log", "target": "soc", "params": {"message": "Asset isolated"}},
                {"action": "notify", "target": "security_team", "params": {"channel": "alert"}},
            ],
        ),
        Playbook(
            id="pb-snapshot",
            name="snapshot_state",
            trigger_type="apt_attack",
            trigger_severity="CRITICAL",
            description="Capture forensic state snapshot via tibet-snap.",
            auto_execute=True,
            actions=[
                {"action": "snapshot", "target": "{{asset_id}}", "params": {"tool": "tibet-snap", "full": True}},
                {"action": "isolate", "target": "{{asset_id}}", "params": {"method": "network_block"}},
                {"action": "escalate", "target": "incident_commander", "params": {"priority": "P1"}},
            ],
        ),
        Playbook(
            id="pb-block",
            name="block_source",
            trigger_type="intrusion",
            trigger_severity="HIGH",
            description="Block the offending source at the perimeter.",
            auto_execute=True,
            actions=[
                {"action": "block", "target": "{{source_ip}}", "params": {"tool": "tibet-edge", "duration": "24h"}},
                {"action": "log", "target": "soc", "params": {"message": "Source blocked at perimeter"}},
            ],
        ),
        Playbook(
            id="pb-notify",
            name="notify_team",
            trigger_type="insider_threat",
            trigger_severity="MEDIUM",
            description="Alert the security team for manual investigation.",
            auto_execute=False,
            actions=[
                {"action": "notify", "target": "security_team", "params": {"channel": "alert"}},
                {"action": "notify", "target": "hr_team", "params": {"channel": "confidential"}},
                {"action": "log", "target": "soc", "params": {"message": "Insider threat flagged for review"}},
            ],
        ),
        Playbook(
            id="pb-nis2",
            name="escalate_nis2",
            trigger_type="supply_chain_compromise",
            trigger_severity="CRITICAL",
            description="Trigger NIS2 incident reporting workflow.",
            auto_execute=True,
            actions=[
                {"action": "escalate", "target": "nis2_reporting", "params": {"tool": "tibet-nis2", "deadline_hours": 24}},
                {"action": "snapshot", "target": "{{asset_id}}", "params": {"tool": "tibet-snap", "full": True}},
                {"action": "notify", "target": "management", "params": {"channel": "critical"}},
                {"action": "log", "target": "soc", "params": {"message": "NIS2 incident report initiated"}},
            ],
        ),
    ]


# ---------------------------------------------------------------------------
# Severity helpers
# ---------------------------------------------------------------------------

_SEVERITY_RANK = {s: i for i, s in enumerate(SEVERITIES)}


def _severity_gte(a: str, b: str) -> bool:
    """Return True if severity *a* is >= severity *b*."""
    return _SEVERITY_RANK.get(a, 99) <= _SEVERITY_RANK.get(b, 99)


# ---------------------------------------------------------------------------
# SOCEngine
# ---------------------------------------------------------------------------

class SOCEngine:
    """
    Central SOC engine.

    Ingests events from all TIBET tools, correlates them into
    alerts, and drives playbook-based automated response.
    """

    def __init__(self, actor: str = "tibet-soc") -> None:
        self.actor = actor
        self.provenance = SOCProvenance(actor=actor)
        self._events: list[SecurityEvent] = []
        self._alerts: list[Alert] = []
        self._playbooks: dict[str, Playbook] = {}
        self._executed: list[dict] = []

        # Load default playbooks
        for pb in _default_playbooks():
            self._playbooks[pb.id] = pb

    # -- Ingest -------------------------------------------------------------

    def ingest(self, event: SecurityEvent) -> SecurityEvent:
        """Ingest a security event from any source."""
        token = self.provenance.create_token(
            action="ingest",
            event_id=event.id,
            details={
                "source": event.source,
                "severity": event.severity,
                "event_type": event.event_type,
                "asset_id": event.asset_id,
            },
        )
        event.tibet_token_id = token.token_id
        self._events.append(event)
        return event

    # -- Correlate ----------------------------------------------------------

    def correlate(self) -> list[Alert]:
        """
        Correlate recent events and detect attack patterns.

        Correlation rules:
        - 3+ auth_failures from same source in 5 min -> brute_force
        - data_breach + privilege_escalation -> apt_attack
        - supply_chain from tibet-mirror -> supply_chain_compromise
        - anomaly + policy_violation from same asset -> insider_threat
        """
        new_alerts: list[Alert] = []
        now = datetime.now(timezone.utc)
        window = timedelta(minutes=5)

        recent = [e for e in self._events if (now - e.timestamp_dt) < window]
        seen_event_ids: set[str] = set()

        # Rule 1: Brute force (3+ auth_failures from same source in 5 min)
        source_auth_failures: dict[str, list[SecurityEvent]] = defaultdict(list)
        for e in recent:
            if e.event_type == "auth_failure":
                key = e.metadata.get("source_ip", e.asset_id or e.source)
                source_auth_failures[key].append(e)

        for source_key, events in source_auth_failures.items():
            if len(events) >= 3:
                event_ids = [e.id for e in events]
                if not self._alert_exists_for_events(event_ids):
                    alert = Alert(
                        severity="HIGH",
                        title=f"Brute Force Attack from {source_key}",
                        description=(
                            f"{len(events)} auth failures from {source_key} "
                            f"in {int(window.total_seconds() / 60)} minutes."
                        ),
                        events=event_ids,
                    )
                    alert.playbook_id = "pb-isolate"
                    token = self.provenance.create_token(
                        action="correlate",
                        event_id=alert.id,
                        details={"pattern": "brute_force", "source": source_key, "count": len(events)},
                    )
                    alert.tibet_token_id = token.token_id
                    new_alerts.append(alert)
                    seen_event_ids.update(event_ids)

        # Rule 2: APT attack (data_breach + privilege_escalation)
        breaches = [e for e in recent if e.event_type == "data_breach" and e.id not in seen_event_ids]
        escalations = [e for e in recent if e.event_type == "privilege_escalation" and e.id not in seen_event_ids]

        if breaches and escalations:
            event_ids = [e.id for e in breaches + escalations]
            if not self._alert_exists_for_events(event_ids):
                alert = Alert(
                    severity="CRITICAL",
                    title="APT Attack Detected",
                    description=(
                        f"Data breach combined with privilege escalation. "
                        f"{len(breaches)} breach(es) + {len(escalations)} escalation(s)."
                    ),
                    events=event_ids,
                )
                alert.playbook_id = "pb-snapshot"
                token = self.provenance.create_token(
                    action="correlate",
                    event_id=alert.id,
                    details={"pattern": "apt_attack", "breaches": len(breaches), "escalations": len(escalations)},
                )
                alert.tibet_token_id = token.token_id
                new_alerts.append(alert)
                seen_event_ids.update(event_ids)

        # Rule 3: Supply chain compromise (supply_chain from tibet-mirror)
        sc_events = [
            e for e in recent
            if e.event_type == "supply_chain" and e.source == "tibet-mirror" and e.id not in seen_event_ids
        ]
        for e in sc_events:
            event_ids = [e.id]
            if not self._alert_exists_for_events(event_ids):
                alert = Alert(
                    severity="CRITICAL",
                    title=f"Supply Chain Compromise: {e.asset_id or 'unknown'}",
                    description=f"Supply chain integrity failure detected by tibet-mirror. {e.description}",
                    events=event_ids,
                )
                alert.playbook_id = "pb-nis2"
                token = self.provenance.create_token(
                    action="correlate",
                    event_id=alert.id,
                    details={"pattern": "supply_chain_compromise", "asset": e.asset_id},
                )
                alert.tibet_token_id = token.token_id
                new_alerts.append(alert)
                seen_event_ids.update(event_ids)

        # Rule 4: Insider threat (anomaly + policy_violation from same asset)
        anomalies_by_asset: dict[str, list[SecurityEvent]] = defaultdict(list)
        violations_by_asset: dict[str, list[SecurityEvent]] = defaultdict(list)

        for e in recent:
            if e.id in seen_event_ids:
                continue
            if e.event_type == "anomaly" and e.asset_id:
                anomalies_by_asset[e.asset_id].append(e)
            elif e.event_type == "policy_violation" and e.asset_id:
                violations_by_asset[e.asset_id].append(e)

        for asset_id in set(anomalies_by_asset) & set(violations_by_asset):
            combined = anomalies_by_asset[asset_id] + violations_by_asset[asset_id]
            event_ids = [e.id for e in combined]
            if not self._alert_exists_for_events(event_ids):
                alert = Alert(
                    severity="HIGH",
                    title=f"Insider Threat on {asset_id}",
                    description=(
                        f"Anomaly + policy violation from the same asset ({asset_id}). "
                        f"Potential insider threat."
                    ),
                    events=event_ids,
                )
                alert.playbook_id = "pb-notify"
                token = self.provenance.create_token(
                    action="correlate",
                    event_id=alert.id,
                    details={"pattern": "insider_threat", "asset": asset_id},
                )
                alert.tibet_token_id = token.token_id
                new_alerts.append(alert)

        # Auto-execute playbooks for new alerts
        for alert in new_alerts:
            self._alerts.append(alert)
            if alert.playbook_id and alert.playbook_id in self._playbooks:
                pb = self._playbooks[alert.playbook_id]
                if pb.auto_execute:
                    self.execute_playbook(alert)

        return new_alerts

    # -- Playbooks ----------------------------------------------------------

    def add_playbook(self, playbook: Playbook) -> None:
        """Add or replace an automated response playbook."""
        self._playbooks[playbook.id] = playbook

    def execute_playbook(self, alert: Alert) -> dict:
        """
        Execute the matching playbook for an alert.

        Returns a summary dict of the execution result.
        """
        pb_id = alert.playbook_id
        if not pb_id or pb_id not in self._playbooks:
            return {"status": "no_playbook", "alert_id": alert.id}

        pb = self._playbooks[pb_id]
        alert.status = "MITIGATING"

        # Gather asset and source info from correlated events
        asset_ids = set()
        source_ips = set()
        for eid in alert.events:
            for evt in self._events:
                if evt.id == eid:
                    if evt.asset_id:
                        asset_ids.add(evt.asset_id)
                    if "source_ip" in evt.metadata:
                        source_ips.add(evt.metadata["source_ip"])

        resolve_asset = next(iter(asset_ids), "unknown")
        resolve_source = next(iter(source_ips), "unknown")

        executed_actions = []
        for action_def in pb.actions:
            action_name = action_def.get("action", "unknown")
            target = action_def.get("target", "")
            params = action_def.get("params", {})

            # Resolve template variables
            target = target.replace("{{asset_id}}", resolve_asset)
            target = target.replace("{{source_ip}}", resolve_source)

            executed_actions.append({
                "action": action_name,
                "target": target,
                "params": params,
                "status": "executed",
                "timestamp": _now_iso(),
            })

        token = self.provenance.create_token(
            action="execute_playbook",
            event_id=alert.id,
            details={
                "playbook": pb.name,
                "actions_count": len(executed_actions),
                "alert_severity": alert.severity,
            },
        )

        result = {
            "status": "executed",
            "alert_id": alert.id,
            "playbook": pb.name,
            "actions": executed_actions,
            "tibet_token_id": token.token_id,
        }
        self._executed.append(result)

        alert.status = "MITIGATING"
        return result

    # -- Query --------------------------------------------------------------

    def alerts(
        self,
        severity: str | None = None,
        since: datetime | None = None,
    ) -> list[Alert]:
        """List alerts, optionally filtered by severity and/or time."""
        result = list(self._alerts)
        if severity:
            result = [a for a in result if a.severity == severity]
        if since:
            result = [a for a in result if a.timestamp_dt >= since]
        return result

    def timeline(
        self,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> list[dict]:
        """
        Combined event + alert timeline, sorted chronologically.

        Returns dicts with type, id, timestamp, severity, description.
        """
        entries: list[dict] = []

        for e in self._events:
            ts = e.timestamp_dt
            if since and ts < since:
                continue
            if until and ts > until:
                continue
            entries.append({
                "type": "event",
                "id": e.id,
                "timestamp": e.timestamp,
                "severity": e.severity,
                "source": e.source,
                "event_type": e.event_type,
                "description": e.description,
                "asset_id": e.asset_id,
            })

        for a in self._alerts:
            ts = datetime.fromisoformat(a.timestamp)
            if since and ts < since:
                continue
            if until and ts > until:
                continue
            entries.append({
                "type": "alert",
                "id": a.id,
                "timestamp": a.timestamp,
                "severity": a.severity,
                "source": "soc-correlation",
                "event_type": a.title,
                "description": a.description,
                "asset_id": "",
            })

        entries.sort(key=lambda x: x["timestamp"])
        return entries

    def stats(self) -> dict:
        """SOC dashboard statistics."""
        severity_counts = defaultdict(int)
        for a in self._alerts:
            severity_counts[a.severity] += 1

        status_counts = defaultdict(int)
        for a in self._alerts:
            status_counts[a.status] += 1

        source_counts = defaultdict(int)
        for e in self._events:
            source_counts[e.source] += 1

        return {
            "total_events": len(self._events),
            "total_alerts": len(self._alerts),
            "total_playbook_executions": len(self._executed),
            "total_tibet_tokens": len(self.provenance.tokens),
            "alerts_by_severity": dict(severity_counts),
            "alerts_by_status": dict(status_counts),
            "events_by_source": dict(source_counts),
            "playbooks_loaded": len(self._playbooks),
        }

    def list_playbooks(self) -> list[Playbook]:
        """Return all registered playbooks."""
        return list(self._playbooks.values())

    # -- Internal -----------------------------------------------------------

    def _alert_exists_for_events(self, event_ids: list[str]) -> bool:
        """Check if an alert already covers these events."""
        event_set = set(event_ids)
        for alert in self._alerts:
            if event_set.issubset(set(alert.events)):
                return True
        return False
