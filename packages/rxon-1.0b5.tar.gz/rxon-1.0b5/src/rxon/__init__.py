# Copyright (c) 2025-2026 Dmitrii Gagarin aka madgagarin
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

from importlib.metadata import PackageNotFoundError, version

from .blob import RXON_BLOB_SCHEME, calculate_config_hash, parse_uri
from .constants import (
    AUTH_HEADER_CLIENT,
    AUTH_HEADER_WORKER,
    COMMAND_CANCEL_TASK,
    ENDPOINT_TASK_NEXT,
    ENDPOINT_TASK_RESULT,
    ENDPOINT_WORKER_HEARTBEAT,
    ENDPOINT_WORKER_REGISTER,
    ERROR_CODE_CONTRACT_VIOLATION,
    ERROR_CODE_DEPENDENCY,
    ERROR_CODE_DEPENDENCY_MISSING,
    ERROR_CODE_INTEGRITY_MISMATCH,
    ERROR_CODE_INTERNAL,
    ERROR_CODE_INVALID_INPUT,
    ERROR_CODE_LIMIT_EXCEEDED,
    ERROR_CODE_PERMANENT,
    ERROR_CODE_RESOURCE_EXHAUSTED,
    ERROR_CODE_SECURITY,
    ERROR_CODE_TIMEOUT,
    ERROR_CODE_TRANSIENT,
    EVENT_TYPE_PROGRESS,
    HB_RESP_CANCEL_TASKS,
    HB_RESP_REQUIRE_FULL_SYNC,
    JOB_STATUS_CANCELLED,
    JOB_STATUS_ERROR,
    JOB_STATUS_FAILED,
    JOB_STATUS_FINISHED,
    JOB_STATUS_PENDING,
    JOB_STATUS_QUARANTINED,
    JOB_STATUS_RUNNING,
    JOB_STATUS_WAITING_FOR_HUMAN,
    JOB_STATUS_WAITING_FOR_PARALLEL,
    JOB_STATUS_WAITING_FOR_WORKER,
    PROTOCOL_VERSION,
    STS_TOKEN_ENDPOINT,
    TASK_STATUS_CANCELLED,
    TASK_STATUS_FAILURE,
    TASK_STATUS_SUCCESS,
    WORKER_API_PREFIX,
    WS_ENDPOINT,
)
from .exceptions import (
    IntegrityError,
    ParamValidationError,
    RxonAuthError,
    RxonError,
    RxonNetworkError,
    RxonProtocolError,
    S3ConfigMismatchError,
)
from .models import (
    DeviceUsage,
    FileMetadata,
    HardwareDevice,
    Heartbeat,
    InstalledArtifact,
    Resources,
    ResourcesUsage,
    SkillInfo,
    TaskError,
    TaskPayload,
    TaskResult,
    TokenResponse,
    WorkerCapabilities,
    WorkerCommand,
    WorkerEventPayload,
    WorkerRegistration,
)
from .security import (
    create_client_ssl_context,
    create_server_ssl_context,
    extract_cert_identity,
)
from .transports.base import Listener, Transport
from .transports.factory import create_transport
from .transports.http import HttpTransport
from .transports.http_server import HttpListener
from .utils import to_dict
from .validators import is_valid_identifier, validate_identifier

__all__ = [
    # Blob
    "RXON_BLOB_SCHEME",
    "calculate_config_hash",
    "parse_uri",
    # Constants
    "AUTH_HEADER_CLIENT",
    "AUTH_HEADER_WORKER",
    "COMMAND_CANCEL_TASK",
    "ENDPOINT_TASK_NEXT",
    "ENDPOINT_TASK_RESULT",
    "ENDPOINT_WORKER_HEARTBEAT",
    "ENDPOINT_WORKER_REGISTER",
    "ERROR_CODE_CONTRACT_VIOLATION",
    "ERROR_CODE_DEPENDENCY",
    "ERROR_CODE_DEPENDENCY_MISSING",
    "ERROR_CODE_INTEGRITY_MISMATCH",
    "ERROR_CODE_INTERNAL",
    "ERROR_CODE_INVALID_INPUT",
    "ERROR_CODE_LIMIT_EXCEEDED",
    "ERROR_CODE_PERMANENT",
    "ERROR_CODE_RESOURCE_EXHAUSTED",
    "ERROR_CODE_SECURITY",
    "ERROR_CODE_TIMEOUT",
    "ERROR_CODE_TRANSIENT",
    "HB_RESP_REQUIRE_FULL_SYNC",
    "HB_RESP_CANCEL_TASKS",
    "JOB_STATUS_CANCELLED",
    "JOB_STATUS_ERROR",
    "JOB_STATUS_FAILED",
    "JOB_STATUS_FINISHED",
    "JOB_STATUS_PENDING",
    "JOB_STATUS_QUARANTINED",
    "JOB_STATUS_RUNNING",
    "JOB_STATUS_WAITING_FOR_HUMAN",
    "JOB_STATUS_WAITING_FOR_PARALLEL",
    "JOB_STATUS_WAITING_FOR_WORKER",
    "EVENT_TYPE_PROGRESS",
    "PROTOCOL_VERSION",
    "STS_TOKEN_ENDPOINT",
    "TASK_STATUS_CANCELLED",
    "TASK_STATUS_FAILURE",
    "TASK_STATUS_SUCCESS",
    "WORKER_API_PREFIX",
    "WS_ENDPOINT",
    # Exceptions
    "RxonError",
    "RxonNetworkError",
    "RxonAuthError",
    "RxonProtocolError",
    "IntegrityError",
    "ParamValidationError",
    "S3ConfigMismatchError",
    # Models
    "DeviceUsage",
    "FileMetadata",
    "HardwareDevice",
    "Heartbeat",
    "InstalledArtifact",
    "Resources",
    "ResourcesUsage",
    "SkillInfo",
    "TaskError",
    "TaskPayload",
    "TaskResult",
    "TokenResponse",
    "WorkerCapabilities",
    "WorkerCommand",
    "WorkerEventPayload",
    "WorkerRegistration",
    # Security
    "create_client_ssl_context",
    "create_server_ssl_context",
    "extract_cert_identity",
    # Transports
    "Listener",
    "Transport",
    "create_transport",
    "HttpTransport",
    "HttpListener",
    # Utils
    "to_dict",
    # Validators
    "is_valid_identifier",
    "validate_identifier",
]

try:
    __version__ = version("rxon")
except PackageNotFoundError:
    __version__ = "unknown"
