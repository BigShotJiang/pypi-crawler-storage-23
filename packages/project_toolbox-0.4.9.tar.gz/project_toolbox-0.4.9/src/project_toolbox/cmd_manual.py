import click


@click.group("manual")
def main():
    """ Manuals for the toolboxes
    (TODO)
    """
    pass
