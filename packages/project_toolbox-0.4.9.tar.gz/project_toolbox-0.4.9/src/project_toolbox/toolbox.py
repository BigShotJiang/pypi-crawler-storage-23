import os
import sys
import importlib.metadata
import logging

import click

from . import runners


FINDERS = (runners.find_py, runners.find_venv, runners.find_uv)


class ToolboxGroup(click.Group):
    def __init__(self, name=None, finders=(), **kwds):
        super().__init__(name=name, **kwds)
        self.finders = finders
        self._tools = None

    def _load_tools(self, ctx):
        if self._tools is not None:
            return
        match ctx.params.get("verbose", 0):
            case 0:
                logging.basicConfig(level=logging.ERROR)
            case 1:
                logging.basicConfig(level=logging.WARNING)
            case 2:
                logging.basicConfig(level=logging.INFO)
            case _:
                logging.basicConfig(level=logging.DEBUG)
        #
        self._tools = {}
        interpreters = runners.resolve_runners(self.finders)
        os.environ["_TOOLBOX_MAIN_RUNNER"] = sys.executable
        os.environ["_TOOLBOX_RUNNERS"] = ":".join(map(str, interpreters))
        for python in interpreters:
            pyexec = runners.build_pyexec(python)
            for cmd in iter_commands(pyexec):
                if cmd.name in self._tools:
                    logging.warning(f"duplicated command name '{cmd.name}'")
                self._tools[cmd.name] = cmd
                logging.info(f"loaded from {python} : {cmd.name}")

    def list_commands(self, ctx):
        self._load_tools(ctx)
        return self._tools.keys()

    def get_command(self, ctx, name):
        self._load_tools(ctx)
        return self._tools.get(name)


def build_cli(python_finders=FINDERS):

    @click.group(
        cls=ToolboxGroup,
        finders=python_finders,
        add_help_option=False,
        no_args_is_help=True,
    )
    @click.option('-v', '--verbose', count=True)
    def cli(verbose):
        """ project-toolbox - the toolbox for managing your project
        """
        pass

    return cli


def iter_commands(pyexec):
    codes, helps = get_codes(pyexec)
    for name, instr in codes.items():
        cmd = build_command(name, instr, helps[name], pyexec, complete_args(pyexec, codes))
        if cmd is not None:
            yield cmd
        else:
            logging.warning(f"unable to build command '{name}'")


def get_entry_points(pyexec):
    code = (
        "import importlib.metadata as im;"
        "print(*("
        "  f'{ep.name}={ep.module}:{ep.attr}{ep.extras}'"
        "  for ep in im.entry_points(group='project_toolbox')"
        "), sep=';')"
    )
    result = pyexec(code)
    eps = [
        importlib.metadata.EntryPoint(value=g[1], name=g[0], group='project_toolbox')
        for line in (result.split(';') if result else [])
        if len(g:=line.split('=', 1)) == 2
    ]
    return [(ep.name, ep.module, ep.attr) for ep in eps]


def get_codes(pyexec):
    eps = get_entry_points(pyexec)
    codes = {}
    help_codes = {}
    for name, module, attr in eps:
        if name in codes:
            logging.warning(f"duplicated command name '{name}'")
        codes[name] = (
            "import sys;"
            f"from {module} import {attr.split('.')[0]};"
            f"sys.argv[0]={name!r};"
            f"sys.exit({attr}());"
        )
        help_codes[name] = (
            f"from {module} import {attr.split('.')[0]};"
            f"lines = {attr}.__doc__.splitlines();"
            f"print(lines[0] if lines else '');"
        )

    # execute all help codes in one call to reduce overhead
    help_lines = pyexec(''.join(code for code in help_codes.values())).splitlines()
    helps = dict(zip(help_codes, help_lines))

    return codes, helps


def build_command(name, instr, help, pyexec, shell_complete):

    def rename(func):
        func.__name__ = name
        return func

    @click.command(
        context_settings=dict(ignore_unknown_options=True),
        help=help,
        add_help_option=False,
    )
    @click.argument("args", nargs=-1, type=click.UNPROCESSED, shell_complete=shell_complete)
    @rename
    def _subcommand(args):
        pyexec(instr, args, capture=False)

    return _subcommand


def complete_args(pyexec, codes):
    def func(ctx, param, incomplete):
        complete_varname = lambda n: f"_{n}_COMPLETE".upper().replace('-', '_')
        shell_complete_mode = os.environ.get(complete_varname(ctx.parent.info_name))
        env = {**os.environ, complete_varname(ctx.info_name) : shell_complete_mode}
        pyexec(codes[ctx.command.name], env=env, capture=False)
        # return empty but command above already emitted data to system
        return []
    return func
