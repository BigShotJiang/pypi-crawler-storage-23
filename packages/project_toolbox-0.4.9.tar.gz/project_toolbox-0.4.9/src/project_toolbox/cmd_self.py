import os
import subprocess
import click

from .toolbox import get_entry_points
from .runners import build_pyexec


@click.group("self")
def main():
    """ A set of commands for managing the toolbox itself.
    """
    pass


@main.command()
@click.argument("name", default="default")
def add(name):
    """ add or upgrade a toolbox to the project
    """
    name = f"project-toolbox-{name}"
    out = subprocess.run(["uv", "add", "--quiet", "--dev", name])
    if out.returncode != 0:
        exit(out.returncode)
    subprocess.run(["uv", "remove", "--quiet", "--dev", name])
    subprocess.run(["uv", "add", "--dev", name])


@main.command()
def version():
    """ show version of toolbox and plugins
    """
    ...


@main.command()
def env():
    """ show the project environment
    """
    main_runner = os.environ.get("_TOOLBOX_MAIN_RUNNER", "")
    click.echo(f"* toolbox running with {main_runner}")
    runners = os.environ.get("_TOOLBOX_RUNNERS", "").split(':')
    click.echo(f"* plugin runners detected:")
    if not runners:
        click.echo(f"{header} none")
        return
    for runner in runners:
        click.echo(f"  - {runner}")
        tools = get_entry_points(build_pyexec(runner))
        click.echo(f"    tools: {", ".join(name for name, _, _ in tools)}")


@main.command()
def completion():
    """ add completion to shell
    """
    ...
