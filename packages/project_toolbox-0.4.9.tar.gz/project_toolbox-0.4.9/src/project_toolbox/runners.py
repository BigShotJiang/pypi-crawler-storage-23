import sys
import subprocess
import logging
import pathlib


def find_py(cwd=None):
    runners = [pathlib.Path(sys.executable)]
    logging.info(f"[py] runners found: {runners}")
    return runners


def find_uv(cwd=None):
    cmd = ["uv", "run", "python", "-c", "print(__import__('sys').executable)"]
    logging.debug(f"subprocess.run({cmd}, {cwd=})")
    res = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    path = res.stdout.strip()
    runners = [pathlib.Path(path)] if path else []
    logging.info(f"[uv] runners found: {runners}")
    return runners


def find_venv(cwd=None, venv_file='.venv/pyvenv.cfg'):
    directory = pathlib.Path('' if cwd is  None else cwd).resolve()
    if not directory.exists():
        return
    runners = []
    child = None
    while directory != child:
        file = directory / venv_file
        if file.exists():
            python = file.parent / "bin/python"
            runners.append(python.absolute())
        child, directory = directory, directory.parent
    logging.info(f"[venv] runners found: {runners}")
    return runners


def resolve_runners(finders):
    result = []
    hist = set()
    for find in finders:
        for python in find():
            value = python.absolute()
            ref = pathlib.Path(value).parent
            if ref not in hist:
                result.append(value)
                hist.add(ref)
    return result


def build_pyexec(python):
    def pyexec(code, args=(), *, capture=True, env=None):
        logging.debug(f"pyexec({code!r}, {args=}, {capture=}, {env=}) [{python=}]")
        cmd = [python, "-c", code, *args]
        if not capture:
            subprocess.run(cmd, env=env)
            return
        result = subprocess.run(cmd, env=env, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.strip()
        raise Exception(result)
    pyexec.__name__ = f"<pyexec({python})>"
    return pyexec
