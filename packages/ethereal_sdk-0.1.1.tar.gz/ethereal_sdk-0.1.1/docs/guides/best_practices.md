# Best Practices

This guide covers recommended practices when using the Ethereal Python SDK.

## Configuration management

Keep sensitive data like private keys secure. Loading from a `.env` file is only recommended for development:

```python
import os
import asyncio
from ethereal import AsyncRESTClient

async def main():

    private_key = os.getenv("PRIVATE_KEY")
    base_url = os.getenv("BASE_URL", "https://api.ethereal.trade")
    rpc_url = os.getenv("RPC_URL", "https://rpc.ethereal.trade")

    client = await AsyncRESTClient.create({
        "base_url": base_url,
        "chain_config": {
            "rpc_url": rpc_url,
            "private_key": private_key,
        }
    })

    # Your code here

    await client.close()

asyncio.run(main())
```

## Logging

The client has built-in logging support:

```python
# Log something
client.logger.debug("This is a debug message")

# Change log level
client.logger.setLevel(logging.DEBUG)
```
