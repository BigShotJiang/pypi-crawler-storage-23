# Installation

## Requirements

- Python 3.8 or higher
- pip package manager or uv (recommended)

## Install with uv (Recommended)

[uv](https://github.com/astral-sh/uv) is a fast Python package installer and resolver:

```bash
# Install uv if you don't have it
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install the SDK
uv pip install ethereal-sdk
```

## Install with pip

```bash
pip install ethereal-sdk
```

## Install from source

```bash
# Clone the repository
git clone git@github.com:meridianxyz/ethereal-py-sdk.git
cd ethereal-py-sdk

# Using uv (recommended)
uv add --editable .

# Or using pip
pip install -e .
```

## Verify installation

Verify your installation by importing the package:

```python
import ethereal
print(ethereal.__version__)
```

## Development setup

For development, use uv to set up the environment:

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest

# Run the linter
uv run ruff check --fix
```
