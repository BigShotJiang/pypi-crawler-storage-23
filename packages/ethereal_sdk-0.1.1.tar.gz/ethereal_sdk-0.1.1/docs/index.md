# Ethereal Python SDK

[![PyPI version](https://img.shields.io/pypi/v/ethereal-sdk.svg)](https://pypi.org/project/ethereal-sdk/)
[![Python versions](https://img.shields.io/pypi/pyversions/ethereal-sdk.svg)](https://pypi.org/project/ethereal-sdk/)
[![Downloads](https://pepy.tech/badge/ethereal-sdk)](https://pypi.org/project/ethereal-sdk/)

A Python SDK for interacting with the Ethereal DEX.

## Overview

The Ethereal Python SDK provides a simple interface for trading, accessing market data, and managing accounts on the Ethereal DEX. This SDK supports both REST API and WebSocket connections.

## Installation

We recommend using [uv](https://github.com/astral-sh/uv) to manage your environment:

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install the SDK
uv add ethereal-sdk
```

Alternatively, you can use pip:

```bash
pip install ethereal-sdk
```

View the source code on [PyPI](https://pypi.org/project/ethereal-sdk/).

## Quick Start

The SDK provides two client types:

**AsyncRESTClient** (recommended):

```python
import asyncio
from ethereal import AsyncRESTClient

async def main():
    client = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
        "chain_config": {
            "rpc_url": "https://rpc.ethereal.trade",
            "private_key": "your_private_key",  # optional - required for trading
        }
    })

    # Get market data
    products = await client.list_products()
    tokens = await client.list_tokens()

    await client.close()

asyncio.run(main())
```

**RESTClient** (Synchronous):

```python
from ethereal import RESTClient

client = RESTClient({
    "base_url": "https://api.ethereal.trade",
    "chain_config": {
        "rpc_url": "https://rpc.ethereal.trade",
        "private_key": "your_private_key",  # optional - required for trading
    }
})

# Get market data
products = client.list_products()
tokens = client.list_tokens()
```

See the [quickstart guide](./guides/quickstart.md) for more examples.

## Key Features

- **Market Data**: Access products, prices, and order book information
- **Trading**: Place and manage orders
- **Account Management**: Manage subaccounts and positions
- **Real-time Updates**: Websocket support for live order book and fill updates
