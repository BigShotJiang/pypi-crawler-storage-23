# Account Management Examples

This page provides examples of account management operations with the Ethereal Python SDK.

## Setup

All examples on this page use the `AsyncRESTClient` with a private key for authentication. Here's the basic pattern:

```python
import asyncio
from ethereal import AsyncRESTClient

async def main():
    # Initialize client with your private key
    client = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
        "chain_config": {
            "rpc_url": "https://rpc.ethereal.trade",
            "private_key": "your_private_key"
        }
    })

    # Your code here

    await client.close()

asyncio.run(main())
```

The examples below show the code that goes in the "Your code here" section. For a complete standalone example, see [Managing subaccounts](#managing-subaccounts).

## Managing subaccounts

This complete example shows the full pattern including imports, initialization, and cleanup:

```python
import asyncio
from ethereal import AsyncRESTClient

async def manage_subaccounts():
    # Initialize client with your private key
    client = await AsyncRESTClient.create({
        "base_url": "https://api.ethereal.trade",
        "chain_config": {
            "rpc_url": "https://rpc.ethereal.trade",
            "private_key": "your_private_key"
        }
    })

    # Subaccounts are fetched from the API
    subaccounts = await client.subaccounts()

    for subaccount in subaccounts:
        print(subaccount.model_dump())

    # Get a specific subaccount
    if subaccounts:
        subaccount_id = subaccounts[0].id
        subaccount = await client.get_subaccount(id=subaccount_id)
        print(subaccount.model_dump())

    await client.close()

asyncio.run(manage_subaccounts())
```

## Creating Accounts

Subaccounts are created when a token is deposited. A private key is required for this operation.

### Creating a new subaccount

```python
# Deposit USDe to create a new subaccount
deposit_tx_hash = client.chain.deposit_usde(
    amount=100,
    account_name='trading',
    submit=True
)
print(f"Deposit transaction hash: {deposit_tx_hash}")
```

### Depositing to an existing subaccount

```python
# Deposit using the bytes name from an existing subaccount
subaccounts = await client.subaccounts()
subaccount = subaccounts[0]

deposit_tx_hash = client.chain.deposit_usde(
    amount=100,
    account_name=subaccount.name,
    submit=True
)
print(f"Deposit transaction hash: {deposit_tx_hash}")
```

## Checking balances

```python
# Get balances for a subaccount
subaccounts = await client.subaccounts()
subaccount_id = subaccounts[0].id
balances = await client.get_subaccount_balances(subaccount_id=subaccount_id)

for balance in balances:
    print(balance.model_dump())
```

## Managing positions

```python
# Get all positions
subaccounts = await client.subaccounts()
subaccount_id = subaccounts[0].id
positions = await client.list_positions(subaccount_id=subaccount_id)

for position in positions:
    print(position.model_dump())

# Get a specific position
if positions:
    position_id = positions[0].id
    position = await client.get_position(id=position_id)
    print(position.model_dump())
```

## Token operations

```python
# List all tokens
tokens = await client.list_tokens()

for token in tokens:
    print(token.model_dump())

# List token withdrawals
subaccounts = await client.subaccounts()
subaccount_id = subaccounts[0].id
withdrawals = await client.list_token_withdraws(subaccount_id=subaccount_id)
for withdrawal in withdrawals:
    print(withdrawal.model_dump())

# List token transfers
transfers = await client.list_token_transfers(subaccount_id=subaccount_id)
for transfer in transfers:
    print(transfer.model_dump())
```

## Withdrawals

```python
subaccounts = await client.subaccounts()
subaccount = subaccounts[0]
usde_address = client.chain.usde.address

# Get the USDe token id
tokens = await client.list_tokens(withdraw_enabled=True)
usde_token = next((token for token in tokens if token.address == usde_address), None)

# Submit a withdrawal request
withdrawal = await client.withdraw_token(
    subaccount=subaccount.name,
    token_id=usde_token.id,
    token=usde_token.address,
    amount=100,
    account=client.chain.address,
)
```
