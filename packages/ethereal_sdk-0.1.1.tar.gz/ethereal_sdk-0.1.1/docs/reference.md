# API Reference

This reference documents the main classes and methods in the Ethereal Python SDK.

## Client Classes

### AsyncRESTClient

The primary asynchronous client for interacting with the Ethereal API via REST endpoints. Recommended for all new applications.

```python
from ethereal import AsyncRESTClient

# Create async client (use within async function)
client = await AsyncRESTClient.create({
    "base_url": "https://api.ethereal.trade",
    "chain_config": {
        "rpc_url": "https://rpc.ethereal.trade",
        "private_key": "your_private_key",  # optional, required for signing
    }
})

# Use the client
products = await client.products()
subaccounts = await client.subaccounts()

# Remember to close when done
await client.close()
```

::: ethereal.async_rest_client.AsyncRESTClient

### RESTClient

Synchronous wrapper around AsyncRESTClient for backward compatibility. Use AsyncRESTClient for new applications.

```python
from ethereal import RESTClient

client = RESTClient({
    "base_url": "https://api.ethereal.trade",
    "chain_config": {
        "rpc_url": "https://rpc.ethereal.trade",
        "private_key": "your_private_key",  # optional
    }
})

# Property access works for convenience
products = client.products
subaccounts = client.subaccounts

# Remember to close when done
client.close()
```

::: ethereal.rest.rpc
::: ethereal.rest.subaccount
::: ethereal.rest.product
::: ethereal.rest.position
::: ethereal.rest.order
::: ethereal.rest.funding
::: ethereal.rest.linked_signer
::: ethereal.rest.token
::: ethereal.rest.util
::: ethereal.async_ws_client.AsyncWSClient
::: ethereal.ws_client.WSClient
::: ethereal.chain_client.ChainClient
::: ethereal.rest.http_client.HTTPClient
