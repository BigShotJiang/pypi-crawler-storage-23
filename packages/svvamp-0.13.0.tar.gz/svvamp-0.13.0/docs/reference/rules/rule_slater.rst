RuleSlater
==========

.. autoclass:: svvamp.RuleSlater
   :members: scores_, candidates_by_scores_best_to_worst_, w_
