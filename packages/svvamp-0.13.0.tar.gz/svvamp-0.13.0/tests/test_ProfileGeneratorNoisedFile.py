from svvamp import GeneratorProfileNoisedFile
import os


def test():
    file = os.path.join(os.path.dirname(__file__), "example_ballots.t.csv")
    profile = GeneratorProfileNoisedFile(file_name=file, relative_noise=0.01, absolute_noise=0.01)()
    assert profile.preferences_ut.shape == (86, 11)
    assert len(profile.labels_candidates) == 11
