# -*- coding: utf-8 -*-
"""
Created on 10 dec. 2018, 13:34
Copyright François Durand 2014-2018
fradurand@gmail.com

This file is part of SVVAMP.

    SVVAMP is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    SVVAMP is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SVVAMP.  If not, see <http://www.gnu.org/licenses/>.
"""

import numpy as np
from svvamp.rules.rule import Rule
from svvamp.utils.util_cache import cached_property
from svvamp.preferences.profile import Profile


class RuleKimRoush(Rule):
    """Kim-Roush method.

    Options
    -------
        >>> RuleKimRoush.print_options_parameters()
        cm_option: ['lazy', 'exact']. Default: 'lazy'.
        icm_option: ['lazy']. Default: 'lazy'.
        iia_subset_maximum_size: is_number. Default: 2.
        im_option: ['lazy', 'exact']. Default: 'lazy'.
        precheck_heuristic: is_bool. Default: True.
        tm_option: ['lazy', 'exact']. Default: 'exact'.
        um_option: ['lazy', 'exact']. Default: 'lazy'.

    Notes
    -----
    At each round, all candidates with a Veto score strictly lower than average are simultaneously eliminated. When
    all remaining candidates have the same Veto score, the candidate with lowest index is declared the winner.

    Kim-Roush method does not meets InfMC.

    * :meth:`is_cm_`: Non-polynomial or non-exact algorithms from superclass :class:`Rule`.
    * :meth:`is_icm_`: Non-exact algorithm from superclass :class:`Rule`.
    * :meth:`is_im_`: Non-polynomial or non-exact algorithms from superclass :class:`Rule`.
    * :meth:`is_iia`: Non-polynomial or non-exact algorithms from superclass :class:`Rule`.
    * :meth:`is_tm_`: Exact in polynomial time.
    * :meth:`is_um_`: Non-polynomial or non-exact algorithms from superclass :class:`Rule`.

    References
    ----------
    'Statistical Manipulability of Social Choice Functions', K.H. Kim and F.W. Roush, 1996.

    Examples
    --------
        >>> profile = Profile(preferences_ut=[
        ...     [ 0. , -0.5, -1. ],
        ...     [ 1. , -1. ,  0.5],
        ...     [ 0.5,  0.5, -0.5],
        ...     [ 0.5,  0. ,  1. ],
        ...     [-1. , -1. ,  1. ],
        ... ], preferences_rk=[
        ...     [0, 1, 2],
        ...     [0, 2, 1],
        ...     [1, 0, 2],
        ...     [2, 0, 1],
        ...     [2, 1, 0],
        ... ])
        >>> rule = RuleKimRoush()(profile)
        >>> rule.demo_results_(log_depth=0)  # doctest: +NORMALIZE_WHITESPACE
        <BLANKLINE>
        ************************
        *                      *
        *   Election Results   *
        *                      *
        ************************
        <BLANKLINE>
        ***************
        *   Results   *
        ***************
        profile_.preferences_ut (reminder) =
        [[ 0.  -0.5 -1. ]
         [ 1.  -1.   0.5]
         [ 0.5  0.5 -0.5]
         [ 0.5  0.   1. ]
         [-1.  -1.   1. ]]
        profile_.preferences_rk (reminder) =
        [[0 1 2]
         [0 2 1]
         [1 0 2]
         [2 0 1]
         [2 1 0]]
        ballots =
        [[0 1 2]
         [0 2 1]
         [1 0 2]
         [2 0 1]
         [2 1 0]]
        scores =
        [[-1. -2. -2.]
         [-5. inf inf]]
        candidates_by_scores_best_to_worst
        [0 1 2]
        scores_best_to_worst
        [[-1. -2. -2.]
         [-5. inf inf]]
        w = 0
        score_w = [-1. -5.]
        total_utility_w = 1.0
        <BLANKLINE>
        *********************************
        *   Condorcet efficiency (rk)   *
        *********************************
        w (reminder) = 0
        <BLANKLINE>
        condorcet_winner_rk_ctb = 0
        w_is_condorcet_winner_rk_ctb = True
        w_is_not_condorcet_winner_rk_ctb = False
        w_missed_condorcet_winner_rk_ctb = False
        <BLANKLINE>
        condorcet_winner_rk = 0
        w_is_condorcet_winner_rk = True
        w_is_not_condorcet_winner_rk = False
        w_missed_condorcet_winner_rk = False
        <BLANKLINE>
        ***************************************
        *   Condorcet efficiency (relative)   *
        ***************************************
        w (reminder) = 0
        <BLANKLINE>
        condorcet_winner_ut_rel_ctb = 0
        w_is_condorcet_winner_ut_rel_ctb = True
        w_is_not_condorcet_winner_ut_rel_ctb = False
        w_missed_condorcet_winner_ut_rel_ctb = False
        <BLANKLINE>
        condorcet_winner_ut_rel = 0
        w_is_condorcet_winner_ut_rel = True
        w_is_not_condorcet_winner_ut_rel = False
        w_missed_condorcet_winner_ut_rel = False
        <BLANKLINE>
        ***************************************
        *   Condorcet efficiency (absolute)   *
        ***************************************
        w (reminder) = 0
        <BLANKLINE>
        condorcet_admissible_candidates =
        [ True False False]
        w_is_condorcet_admissible = True
        w_is_not_condorcet_admissible = False
        w_missed_condorcet_admissible = False
        <BLANKLINE>
        weak_condorcet_winners =
        [ True False False]
        w_is_weak_condorcet_winner = True
        w_is_not_weak_condorcet_winner = False
        w_missed_weak_condorcet_winner = False
        <BLANKLINE>
        condorcet_winner_ut_abs_ctb = 0
        w_is_condorcet_winner_ut_abs_ctb = True
        w_is_not_condorcet_winner_ut_abs_ctb = False
        w_missed_condorcet_winner_ut_abs_ctb = False
        <BLANKLINE>
        condorcet_winner_ut_abs = 0
        w_is_condorcet_winner_ut_abs = True
        w_is_not_condorcet_winner_ut_abs = False
        w_missed_condorcet_winner_ut_abs = False
        <BLANKLINE>
        resistant_condorcet_winner = nan
        w_is_resistant_condorcet_winner = False
        w_is_not_resistant_condorcet_winner = True
        w_missed_resistant_condorcet_winner = False
        >>> rule.demo_manipulation_(log_depth=0)  # doctest: +NORMALIZE_WHITESPACE
        <BLANKLINE>
        *****************************
        *                           *
        *   Election Manipulation   *
        *                           *
        *****************************
        <BLANKLINE>
        *********************************************
        *   Basic properties of the voting system   *
        *********************************************
        with_two_candidates_reduces_to_plurality =  True
        is_based_on_rk =  True
        is_based_on_ut_minus1_1 =  False
        meets_iia =  False
        <BLANKLINE>
        ****************************************************
        *   Manipulation properties of the voting system   *
        ****************************************************
        Condorcet_c_ut_rel_ctb (False)     ==>     Condorcet_c_ut_rel (False)
         ||                                                               ||
         ||     Condorcet_c_rk_ctb (False) ==> Condorcet_c_rk (False)     ||
         ||           ||               ||       ||             ||         ||
         V            V                ||       ||             V          V
        Condorcet_c_ut_abs_ctb (False)     ==>     Condorcet_ut_abs_c (False)
         ||                            ||       ||                        ||
         ||                            V        V                         ||
         ||       maj_fav_c_rk_ctb (False) ==> maj_fav_c_rk (False)       ||
         ||           ||                                       ||         ||
         V            V                                        V          V
        majority_favorite_c_ut_ctb (False) ==> majority_favorite_c_ut (False)
         ||                                                               ||
         V                                                                V
        IgnMC_c_ctb (False)                ==>                IgnMC_c (False)
         ||                                                               ||
         V                                                                V
        InfMC_c_ctb (False)                ==>                InfMC_c (False)
        <BLANKLINE>
        *****************************************************
        *   Independence of Irrelevant Alternatives (IIA)   *
        *****************************************************
        w (reminder) = 0
        is_iia = True
        log_iia: iia_subset_maximum_size = 2.0
        example_winner_iia = nan
        example_subset_iia = nan
        <BLANKLINE>
        **********************
        *   c-Manipulators   *
        **********************
        w (reminder) = 0
        preferences_ut (reminder) =
        [[ 0.  -0.5 -1. ]
         [ 1.  -1.   0.5]
         [ 0.5  0.5 -0.5]
         [ 0.5  0.   1. ]
         [-1.  -1.   1. ]]
        v_wants_to_help_c =
        [[False False False]
         [False False False]
         [False False False]
         [False False  True]
         [False False  True]]
        <BLANKLINE>
        ************************************
        *   Individual Manipulation (IM)   *
        ************************************
        is_im = nan
        log_im: im_option = lazy
        candidates_im =
        [ 0.  0. nan]
        <BLANKLINE>
        *********************************
        *   Trivial Manipulation (TM)   *
        *********************************
        is_tm = False
        log_tm: tm_option = exact
        candidates_tm =
        [0. 0. 0.]
        <BLANKLINE>
        ********************************
        *   Unison Manipulation (UM)   *
        ********************************
        is_um = nan
        log_um: um_option = lazy
        candidates_um =
        [ 0.  0. nan]
        <BLANKLINE>
        *********************************************
        *   Ignorant-Coalition Manipulation (ICM)   *
        *********************************************
        is_icm = nan
        log_icm: icm_option = lazy
        candidates_icm =
        [ 0.  0. nan]
        necessary_coalition_size_icm =
        [0. 0. 0.]
        sufficient_coalition_size_icm =
        [ 0. inf inf]
        <BLANKLINE>
        ***********************************
        *   Coalition Manipulation (CM)   *
        ***********************************
        is_cm = False
        log_cm: cm_option = lazy, um_option = lazy, icm_option = lazy, tm_option = exact
        candidates_cm =
        [0. 0. 0.]
        necessary_coalition_size_cm =
        [0. 1. 3.]
        sufficient_coalition_size_cm =
        [0. 2. 3.]
    """

    full_name = "Kim-Roush"
    abbreviation = "KR"

    options_parameters = Rule.options_parameters.copy()

    def __init__(self, **kwargs):
        super().__init__(
            with_two_candidates_reduces_to_plurality=True, is_based_on_rk=True, log_identity="KIM-ROUSH", **kwargs
        )

    @cached_property
    def _count_ballots_(self):
        """
        Case where all the candidates have the same score:

            >>> profile = Profile(preferences_rk=[[0, 1], [1, 0]])
            >>> rule = RuleKimRoush()(profile)
            >>> rule.w_
            0
        """
        self.mylog("Count ballots", 1)
        scores = []
        candidates_worst_to_best = []
        one_v_might_be_pivotal = False
        # score_temp[c] = - number of vetos
        # score_temp[c] will be inf when c is eliminated
        score_temp = np.array(
            -np.bincount(self.profile_.preferences_rk[:, self.profile_.n_c - 1], minlength=self.profile_.n_c).astype(
                float
            )
        )
        score_average = -self.profile_.n_v / self.profile_.n_c
        candidates = np.array(range(self.profile_.n_c))
        is_alive = np.ones(self.profile_.n_c, dtype=bool)
        while True:  # This is a round
            scores.append(np.copy(score_temp))
            least_score = np.min(score_temp)
            self.mylogv("scores =", scores, 2)
            # self.mylogv("least_score =", least_score, 2)
            self.mylogv("score_average =", score_average, 2)
            if least_score == score_average:
                # Then all candidates have the average. This also includes the case where only one candidate is
                # remaining. We eliminate them by decreasing order of index (highest indexes first).
                losing_candidates = np.where(np.isfinite(score_temp))[0]
                candidates_worst_to_best.extend(losing_candidates[::-1])
                if len(losing_candidates) > 1:
                    one_v_might_be_pivotal = True
                    self.mylog("One voter might be pivotal", 2)
                self.mylogv("losing_candidates[::-1] =", losing_candidates[::-1], 2)
                break
            # Remove all candidates with score < average. Lowest score first, highest indexes first.
            while least_score < score_average:
                if least_score + 1 >= score_average:
                    one_v_might_be_pivotal = True
                    self.mylog("One voter might be pivotal", 2)
                losing_candidates = np.where(score_temp == least_score)[0]
                candidates_worst_to_best.extend(losing_candidates[::-1])
                self.mylogv("losing_candidates[::-1] =", losing_candidates[::-1], 2)
                is_alive[losing_candidates] = False
                score_temp[losing_candidates] = np.inf
                least_score = np.min(score_temp)
            if least_score - 1 < score_average:
                one_v_might_be_pivotal = True
                self.mylog("One voter might be pivotal", 2)
            candidates_alive = candidates[is_alive]
            score_temp = np.array(
                -np.bincount(
                    candidates_alive[np.argmin(self.profile_.preferences_borda_rk[:, is_alive], 1)],
                    minlength=self.profile_.n_c,
                ).astype(float)
            )
            score_temp[np.logical_not(is_alive)] = np.inf
            score_average = -self.profile_.n_v / np.sum(is_alive)
        candidates_by_scores_best_to_worst = np.array([int(c) for c in candidates_worst_to_best[::-1]])
        w = int(candidates_by_scores_best_to_worst[0])
        scores = np.array(scores)
        return {
            "scores": scores,
            "w": w,
            "one_v_might_be_pivotal": one_v_might_be_pivotal,
            "candidates_by_scores_best_to_worst": candidates_by_scores_best_to_worst,
        }

    @cached_property
    def scores_(self):
        """2d array of integers. ``scores[r, c]`` is minus the Veto score of candidate ``c`` at elimination round ``r``.

        By convention, if candidate ``c`` does not participate to round ``r``, then ``scores[r, c] = numpy.inf``.
        """
        return self._count_ballots_["scores"]

    @cached_property
    def w_(self):
        return self._count_ballots_["w"]

    @cached_property
    def candidates_by_scores_best_to_worst_(self):
        """1d array of integers. Candidates are sorted according to their order of elimination. When several
        candidates are eliminated during the same round, they are sorted by Veto score at that round (more vetos are
        eliminated first) and, in case of a tie, by their index ( highest indexes are eliminated first).
        """
        return self._count_ballots_["candidates_by_scores_best_to_worst"]

    @cached_property
    def v_might_im_for_c_(self):
        return np.full((self.profile_.n_v, self.profile_.n_c), self._count_ballots_["one_v_might_be_pivotal"])

    # %% CM

    def _cm_preliminary_checks_c_subclass_(self, c, optimize_bounds):
        """
        >>> profile = Profile(preferences_rk=[
        ...     [1, 2, 0],
        ...     [1, 0, 2],
        ...     [2, 1, 0],
        ...     [2, 0, 1],
        ... ])
        >>> rule = RuleKimRoush()(profile)
        >>> rule.sufficient_coalition_size_cm_
        array([3., 0., 2.])

        >>> profile = Profile(preferences_rk=[
        ...     [2, 1, 0],
        ...     [2, 0, 1],
        ...     [2, 0, 1],
        ...     [1, 2, 0],
        ... ])
        >>> rule = RuleKimRoush()(profile)
        >>> rule.necessary_coalition_size_cm_
        array([2., 3., 0.])
        """
        n_c = self.profile_.n_c
        n_m = self.profile_.matrix_duels_ut[c, self.w_]
        n_s = self.profile_.n_v - n_m
        self._update_sufficient(
            self._sufficient_coalition_size_cm,
            c,
            (n_s + 1) * (n_c - 1),
            "CM: Obvious bound => sufficient_coalition_size_cm[c] = ",
        )
        # c must not be eliminated during the first round
        self._update_necessary(
            self._necessary_coalition_size_cm,
            c,
            -self.scores_[0, c] * n_c - n_s,
            "CM: Obvious bound => necessary_coalition_size_cm[c] = ",
        )
        # We need to make `w` lose. Two options:
        # * Have more than `n_v / k` vetos. But as long as `c` is here, the only sincere voters who can cast a
        #   veto against `w` are those who rank `c` before `w` (which is possible only if they have the same
        #   utility for `w` and `c`). So there must exist a `k` such that
        #   `(n_s + n_m) / k < can_veto_w + n_m`. In particular it must hold that
        #   `(n_s + n_m) / n_c < can_veto_w + n_m`, which leads to
        #   `n_m > (n_s - n_c * can_veto_w) / (n_c - 1)`.
        preferences_borda_rk_s = self.profile_.preferences_borda_rk[np.logical_not(self.v_wants_to_help_c_[:, c]), :]
        can_veto_w = preferences_borda_rk_s[:, self.w_] < preferences_borda_rk_s[:, c]
        n_m_necessary = 1 + np.floor((n_s - n_c * np.sum(can_veto_w)) / (n_c - 1))
        # * Have exactly `n_v / k` vetos, and that any other candidate has the same number of vetos. Similarly
        #   to the previous case, it implies that `n_m >= (n_s - n_c * can_veto_w) / (n_c - 1)`. Since the `>` case
        #   is already covered by the previous bullet point, focus on the `==` case. Then
        #   `(n_s + n_m) / n_c == can_veto_w + n_m`, i.e. if `w` is eliminated, it must be at first round and with
        #   all manipulators voting against her. But it needs that all candidates have the same score, and that
        #   `c == 0` to benefit from the tie-breaking rule.
        if c == 0:
            n_vetos_s = np.sum(preferences_borda_rk_s == 0, axis=0)
            min_vetos_except_w = min(n_vetos_s[np.arange(n_c) != self.w_])
            max_vetos_except_w = max(n_vetos_s[np.arange(n_c) != self.w_])
            if min_vetos_except_w == max_vetos_except_w:
                n_m_necessary = n_vetos_s[c] - n_vetos_s[self.w_]
        self._update_necessary(
            self._necessary_coalition_size_cm, c, n_m_necessary, "CM: w must lose => necessary_coalition_size_cm[c] = "
        )

    @cached_property
    def theta_critical_(self):
        """
        >>> profile = Profile(preferences_rk=[[0, 1, 2, 3]])
        >>> rule = RuleKimRoush()(profile)
        >>> rule.theta_critical_
        0.5
        """
        n_c = self.profile_.n_c
        return (n_c - 2) / n_c
