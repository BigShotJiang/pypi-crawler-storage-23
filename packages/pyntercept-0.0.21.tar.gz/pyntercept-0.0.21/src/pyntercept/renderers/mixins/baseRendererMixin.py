from typing import TextIO
import sys

from ..abstractRenderer import AbstractRenderer

class BaseRendererMixin(AbstractRenderer):
    src: TextIO
    dest: TextIO
    err: TextIO
    
    _is_alt_scr: bool 
    _src_raw: bool
    _dest_raw: bool
    _echo_src: bool
        
    def __init__(
        self,
        
        enable_alt_scr: bool,
        src_raw:        bool,
        dest_raw:       bool,
        echo_src:       bool,           # rename it to disable echo
        
        src: TextIO  | None = None, 
        dest: TextIO | None = None,
        err: TextIO  | None = None,
    ):
        super().__init__()
        self.src  = src   or sys.stdin
        self.dest = dest  or sys.stdout
        self.err  = err   or sys.stderr
        
        self._is_alt_scr = enable_alt_scr or False
        self._src_raw    = src_raw           or True
        self._dest_raw   = dest_raw         or False
        self._echo_src   = echo_src         or True

     
    def init(self):
        # to not produce ANSI codes or other calls, which could break some apps!
        if self._echo_src == False: 
            self.set_echo(False, self.src)
        
        if self._is_alt_scr:
            self.alt_scr(True, self.dest)
        
        if self._dest_raw:
            self.set_raw(True, self.dest)
        
        if self._src_raw:
            self.set_raw(True, self.src)
    
    
    def post_init(self, data: bytes):
        self.update(data)
        self.render()
    
    
    def exit(self):
        # return changed values back!
        if self._echo_src == False: 
            self.set_echo(True, self.src)
        
        if self._is_alt_scr:
            self.alt_scr(False, self.dest)
        
        if self._dest_raw:
            self.set_raw(False, self.dest)
        
        if self._src_raw:
            self.set_raw(False, self.src)