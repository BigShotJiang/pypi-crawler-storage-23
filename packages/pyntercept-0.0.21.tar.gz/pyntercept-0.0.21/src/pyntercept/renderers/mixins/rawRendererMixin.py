from typing import TextIO

from .baseRendererMixin import BaseRendererMixin

class RawRendererMixin(BaseRendererMixin):
    
    # __slots__ = ('render_data')
    
    render_data: bytes
    
    def __init__(
        self,
        
        src: TextIO | None = None, 
        dest: TextIO | None = None,
        err: TextIO | None = None,
        
        enable_alt_scr: bool | None = None,
        src_raw:        bool | None = None,
        dest_raw:       bool | None = None,
        echo_src:       bool | None = None,
    ):
        super().__init__(
            src  = src, 
            dest = dest, 
            err  = err,
            
            enable_alt_scr = enable_alt_scr, 
            src_raw  = src_raw, 
            dest_raw = dest_raw, 
            echo_src = echo_src
        )
        self.render_data = b''
    
    def update(self, data: bytes):
        self.render_data = data
    
    
    def render(self):
        self.dest.buffer.write(self.render_data)
        self.dest.buffer.flush()
    