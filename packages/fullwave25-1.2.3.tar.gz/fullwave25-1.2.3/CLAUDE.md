# CLAUDE.md

This file onboards Claude Code to the `fullwave25` project.

You are assisting with a **Python wrapper around a CUDA/C++ ultrasound FDTD simulator** (Fullwave 2.5). The key goals are:

- Make it easy to write, run, and debug ultrasound wave propagation simulations from Python.
- Keep the Python API high level and "k-Wave-like", while delegating heavy computation to a GPU backend.
- Preserve physical correctness (FDTD, power‑law attenuation) and performance (multi‑GPU, memory aware).

---

## 1. High‑level overview

### 1.1 What this project does

- Simulates 2D and 3D ultrasound wave propagation using a staggered‑grid FDTD scheme (8th order in space, 4th order in time).
- Models attenuation using heterogeneous power‑law attenuation, \(\alpha = \alpha_0 f^\gamma\), where both \(\alpha_0\) and \(\gamma\) can vary spatially.
- Provides a Python interface that:
  - Builds computational grids and heterogeneous media.
  - Configures acoustic sources (e.g., plane wave, linear/convex transducers).
  - Configures sensors/receivers.
  - Launches CUDA/C simulations on one or more NVIDIA GPUs.
  - Handles basic visualization and movie export for wavefields and fields of view.
- The Python package is published as `fullwave25` on PyPI (`pip install fullwave25`).

The core numerical engine (FDTD + attenuation, domain decomposition, multi‑GPU scheduling) is implemented in CUDA/C and exposed via a Python wrapper.

### 1.2 Intended users and workflows

Typical users are ultrasound researchers and engineers who:

- Want high‑fidelity ultrasound simulations in 2D or 3D.
- Need heterogeneous, frequency‑dependent attenuation (e.g., abdominal wall, air inclusions, layered tissues).
- Run experiments such as:
  - Plane wave imaging and compounding.
  - Linear and convex array imaging (including abdominal wall).
  - 3D propagation examples with and without air inclusions.
  - Medium design via simple geometric primitives ("medium builder").

Common workflows:

1. Install with `pip install fullwave25` (or from source for development).
2. Start from a tutorial notebook (e.g., `examples/simple_plane_wave/example_simple_plane_wave.ipynb`) or Colab link.
3. Define:
   - Computational grid.
   - Medium (density, sound speed, attenuation \(\alpha_0\), exponent \(\gamma\)).
   - Source (transducer geometry, waveform).
   - Sensor configuration.
4. Run the simulation and visualize results (2D, 3D slices, movies).
5. Iterate on parameters, medium structure, or transmit schemes (plane waves, focused beams, compounding, synthetic aperture).

---

## 2. Architecture and key components

You should treat this project as:

- A **Python front‑end** for configuration, I/O, plotting, and utilities.
- A **CUDA/C backend** that runs the numerical solver.

At a high level:

- **Python layer**:
  - Defines grid and medium structures.
  - Sets up boundary conditions, attenuation parameters, and sources/sensors.
  - Marshals data to/from GPU memory through C/CUDA bindings.
  - Provides example scripts and notebooks that serve as templates for new simulations.
  - Includes a "medium builder" utility to programmatically construct heterogeneous media.

- **CUDA/C layer**:
  - Implements the staggered‑grid FDTD solver with multiple relaxation processes.
  - Implements stretched‑coordinate spatial derivatives (\(\nabla_1\), \(\nabla_2\)) for power‑law attenuation and dispersion.
  - Handles multi‑GPU domain decomposition along depth (x) and coordinating MPI/CUDA or similar primitives.
  - Manages memory layout with the convention (x, y, z) = (depth, lateral, elevational) for efficiency.

When modifying code:

- Assume the Python API should remain stable and user friendly; breaking changes should be deliberate and documented.
- Keep in mind that cuda kernel is stored as a binary.

### Claude usage

- When changing logic, only edit:
  - fullwave/\*
  - tests/\*
- Prefer plans first, then code.
- Write small test drivers for new patterns

---

## 3. Conventions and gotchas

### 3.1 Coordinate conventions

- The simulation grid is ordered as:
  - \(x\): depth
  - \(y\): lateral
  - \(z\): elevational
- Domain decomposition for multi‑GPU execution happens in the **depth** dimension.
- Internally, indices are in **C‑array order** (row‑major) regardless of how the user conceptualizes coordinates. This is a frequent source of confusion when placing sources and receivers.

When writing helper code, comments, or new APIs, be explicit about:

- Physical coordinates vs array indices.
- The order (x, y, z) and how it maps to numpy arrays, C arrays, and GPU memory.

### 3.2 GPU and system requirements

- Linux environment is assumed. For Windows users, WSL2 is recommended.
- NVIDIA GPU is required; multiple GPUs are recommended for realistic 3D runs.
- GPU memory can be a hard constraint in 3D:
  - Prefer down‑scaling grid sizes or enabling multi‑GPU.
  - Encourage users to inspect usage via `nvidia-smi` or `nvtop`.

When generating new examples or tests, keep GPU memory and runtime reasonable.

### 3.3 Dependencies and system tools

- Python package: `fullwave25` (PyPI).
- Development environment uses `uv` for environment and dependency management.
- Some plotting/animation functions depend on:
  - `ffmpeg` for video encoding.
  - `opencv-python` (`cv2`) for certain video writers.

If code you write uses video output:

- Make it fail gracefully if `ffmpeg` or `cv2` is missing.
- Keep error messages explicit (e.g. "Install ffmpeg via `sudo apt install ffmpeg` on Ubuntu").

---

## 4. How to run and test

### 4.1 User installation

For typical users:

```bash
pip install fullwave25
```

If they need plotting video support:

```bash
# Ubuntu/Debian
sudo apt install ffmpeg
sudo apt install python3-opencv   # or: pip install opencv-python
```

Encourage users to start from the basic examples:

- `examples/simple_plane_wave/example_simple_plane_wave.ipynb`
- Or the provided Google Colab notebook.

### 4.2 Development setup

Assume the developer has Git, Python, and an NVIDIA GPU.

Recommended steps:

```bash
# Clone via SSH (preferred for frequent contributors)
git clone git@github.com:pinton-lab/fullwave25.git
cd fullwave25

# Install uv if missing
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install dev environment
make install-all-extras    # full environment for running examples
# or
make install               # core library only

# Verify everything
make test
```

If adding new tests, hook them into the existing test runner so `make test` remains a single entry point.

---

## 5. Example‑driven usage patterns

The examples directory is the main guide to intended usage. When in doubt, follow their structure.

### 5.1 2D simulations

Examples include:

- Simple plane wave.
- Plane wave with air inclusion.
- Linear transducer (standard plane wave, focused transmit, abdominal wall).
- Plane wave compounding and full synthetic aperture (via Colab scripts).
- Convex transducer with abdominal wall.

Patterns to preserve:

- A clear sequence:
  1. Define grid.
  2. Define medium (including attenuation maps).
  3. Define transducer/source.
  4. Define receivers.
  5. Run simulation.
  6. Save/visualize outputs.

### 5.2 3D simulations

Examples include:

- Simple 3D plane wave.
- 3D plane wave with air inclusion.
- 3D medium builder usage.

In 3D:

- Some plotting utilities from 2D are not available or are adapted to slice views (x–y, x–z slices).
- Simulations are more expensive; any new 3D examples should keep domain sizes and timesteps moderate.

### 5.3 Medium builder

The medium builder provides a simple API for creating heterogeneous media via geometric compositions.

When writing code that interacts with medium builder:

- Treat it as the standard way to define complex heterogeneous media (e.g., abdominal wall, air pockets).
- Keep the API compositional and declarative (define shapes, positions, and property maps rather than manually editing arrays).

---

## 6. How to ask Claude for help

When using Claude Code on this repo, prefer **concrete** and **scoped** requests. Some useful patterns:

- "Open `examples/simple_plane_wave/simple_plane_wave.py` and explain, in comments, how the grid, medium, and source are defined. Do not change any logic."
- "I want to add a new example of a focused linear array in 3D with a heterogeneous abdominal wall. Starting from `examples/wave_3d/simple_plane_wave_3d.py`, propose the minimal modifications and file structure, then implement them."
- "Given the coordinate convention (x=depth, y=lateral, z=elevational) and C‑array indexing, help me write a helper function that converts a physical coordinate (x_mm, y_mm, z_mm) into an index triple compatible with the solver."
- "I'm running out of GPU memory in a 3D example. Suggest code changes (grid size, time steps, number of GPUs) that reduce memory usage but preserve physical fidelity as much as possible."
- "Help refactor the medium builder so that it can load a 3D segmentation mask and assign per‑label attenuation parameters (\(\alpha_0\), \(\gamma\))."

When you ask Claude to modify code:

- Specify the target file(s) and functions.
- State clearly whether public APIs may change.
- Ask for minimal, well‑documented diffs.

---

## 7. Coding guidelines and constraints

- **Numerical correctness first**: Do not change discretization, CFL conditions, or attenuation formulations without explicit intent and justification.
- **Performance aware**:
  - Avoid Python loops in inner loops; push heavy work into vectorized operations or existing CUDA kernels.
  - Be careful with host–device copies; they are often the bottleneck.
- **API design**:
  - Favor explicit, keyword‑driven configuration over "magic" defaults, especially for physical parameters (e.g., attenuation, relaxation parameters).
  - Maintain backward compatibility for documented examples where possible.

---

## 8. Things Claude should NOT do

- Do not:
  - Rewrite numerical schemes unless explicitly requested and scoped.
  - Change coordinate conventions or index ordering.
  - Introduce breaking changes to the Python API without a clear migration path.
  - Add heavy dependencies just for convenience (especially in the core library).
  - you don't need to run a test. Ask user to run the test.

- Be cautious when:
  - Changing I/O formats or directory structures that examples depend on.
  - Touching anything related to the attenuation model or relaxation parameters.

---

## 9. Quick mental model

You can think of `fullwave25` as:

> "A Python‑driven, CUDA‑accelerated FDTD ultrasound simulator that handles realistic, heterogeneous attenuation for 2D/3D wave propagation, with examples mirroring k‑Wave‑style workflows."

All code changes and suggestions should support this purpose: **high‑fidelity ultrasound simulations that remain practical and usable for researchers.**

## 10. coding style

follow ruff.toml
