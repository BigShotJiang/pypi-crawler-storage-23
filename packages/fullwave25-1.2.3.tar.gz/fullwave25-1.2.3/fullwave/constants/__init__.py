"""constants."""

from .material_properties import MaterialProperties

__all__ = ["MaterialProperties"]
