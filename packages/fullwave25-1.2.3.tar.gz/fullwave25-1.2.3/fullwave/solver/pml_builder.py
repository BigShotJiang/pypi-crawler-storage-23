"""Perfectly Matched Layer (PML) setup for Fullwave."""

import concurrent.futures
import logging
from collections import OrderedDict
from dataclasses import dataclass, field
from functools import cached_property
from itertools import starmap
from pathlib import Path

import matplotlib.pyplot as plt
import numexpr as ne
import numpy as np
from joblib import Parallel, delayed
from numpy.typing import NDArray

import fullwave
from fullwave.solver.utils import initialize_relaxation_param_dict
from fullwave.utils import check_functions, plot_utils

logger = logging.getLogger("__main__." + __name__)


def _smooth_transition_function_part(x: NDArray[np.float64]) -> NDArray[np.float64]:
    return np.where(x > 0, np.exp(-1 / (x + 1e-20)), 0)


def _smooth_transition_function(x: NDArray[np.float64]) -> NDArray[np.float64]:
    return _smooth_transition_function_part(x) / (
        _smooth_transition_function_part(x) + _smooth_transition_function_part(1 - x)
    )


def _linear_transition_function(x: NDArray[np.float64]) -> NDArray[np.float64]:
    return x


def _n_th_deg_polynomial_function(x: NDArray[np.float64], n: int = 2) -> NDArray[np.float64]:
    return x**n


def _cosine_transition_function(x: NDArray[np.float64]) -> NDArray[np.float64]:
    return 0.5 * (1 - np.cos(np.pi * x))


def _obtain_relax_var_rename_dict(
    n_relaxation_mechanisms: int,
    *,
    is_3d: bool = False,
    use_isotropic_relaxation: bool = False,
) -> dict:
    if use_isotropic_relaxation:
        rename_dict = {
            "kappa_x": "kappa_x2",
            "kappa_u": "kappa_x1",
        }

        for nu in range(1, n_relaxation_mechanisms + 1):
            rename_dict[f"d_u_nu{nu}"] = f"d_x1_nu{nu}"
            rename_dict[f"d_x_nu{nu}"] = f"d_x2_nu{nu}"

            rename_dict[f"alpha_u_nu{nu}"] = f"alpha_x1_nu{nu}"
            rename_dict[f"alpha_x_nu{nu}"] = f"alpha_x2_nu{nu}"
    else:
        rename_dict = {
            "kappa_x": "kappa_x2",
            "kappa_y": "kappa_x2",
            "kappa_u": "kappa_x1",
            "kappa_w": "kappa_x1",
        }
        if is_3d:
            rename_dict.update(
                {
                    "kappa_z": "kappa_x2",
                    "kappa_v": "kappa_x1",
                },
            )
        for nu in range(1, n_relaxation_mechanisms + 1):
            rename_dict[f"d_u_nu{nu}"] = f"d_x1_nu{nu}"
            rename_dict[f"d_w_nu{nu}"] = f"d_x1_nu{nu}"
            rename_dict[f"d_x_nu{nu}"] = f"d_x2_nu{nu}"
            rename_dict[f"d_y_nu{nu}"] = f"d_x2_nu{nu}"

            rename_dict[f"alpha_u_nu{nu}"] = f"alpha_x1_nu{nu}"
            rename_dict[f"alpha_w_nu{nu}"] = f"alpha_x1_nu{nu}"
            rename_dict[f"alpha_x_nu{nu}"] = f"alpha_x2_nu{nu}"
            rename_dict[f"alpha_y_nu{nu}"] = f"alpha_x2_nu{nu}"
            if is_3d:
                rename_dict[f"d_v_nu{nu}"] = f"d_x1_nu{nu}"
                rename_dict[f"d_z_nu{nu}"] = f"d_x2_nu{nu}"
                rename_dict[f"alpha_v_nu{nu}"] = f"alpha_x1_nu{nu}"
                rename_dict[f"alpha_z_nu{nu}"] = f"alpha_x2_nu{nu}"

    return rename_dict


@dataclass
class PMLBuilder:
    """Setup for Perfectly Matched Layers (PML) in fullwave simulations."""

    medium_org: fullwave.Medium
    source_org: fullwave.Source
    sensor_org: fullwave.Sensor

    m_spatial_order: int
    n_pml_layer: int
    n_relaxation: int
    n_transition_layer: int

    extended_grid: fullwave.Grid = field(init=False)
    extended_medium: fullwave.Medium | fullwave.MediumRelaxationMaps = field(init=False)
    extended_source: fullwave.Source = field(init=False)
    extended_sensor: fullwave.Sensor = field(init=False)

    pml_mask_x: NDArray[np.float64] = field(init=False)
    pml_mask_y: NDArray[np.float64] = field(init=False)

    def __init__(  # noqa: PLR0915
        self,
        grid: fullwave.Grid,
        medium: fullwave.Medium,
        source: fullwave.Source,
        sensor: fullwave.Sensor,
        *,
        m_spatial_order: int = 8,
        n_pml_layer: int = 40,
        n_transition_layer: int = 40,
        use_isotropic_relaxation: bool = False,
        # pml_alpha_target: float = 1.1,
        # pml_alpha_power_target: float = 1.6,
        # pml_strength_factor: float = 2.0,
        # use_2_relax_mechanisms: bool = False,
    ) -> None:
        """Initialize the PMLSetup with the given medium, source, sensor, and PML parameters.

        Parameters
        ----------
        grid: fullwave.Grid
            The grid configuration.
        medium : fullwave.Medium)
            The medium relaxation maps.
        source : fullwave.Source
            The source configuration.
        sensor : fullwave.Sensor
            The sensor configuration.
        m_spatial_order : int, optional
            fullwave simulation's spatial order (default is 8).
            It depends on the fullwave simulation binary version.
            Fullwave simulation has 2M th order spatial accuracy and fourth order accuracy in time.
            see Pinton, G. (2021) http://arxiv.org/abs/2106.11476 for more detail.
        n_pml_layer : int, optional
            PML layer thickness (default is 40).
        n_transition_layer : int, optional
            Number of transition layers (default is 40).
        use_isotropic_relaxation : bool, optional
            Whether to use isotropic relaxation mechanisms for attenuation modeling
            to reduce memory usage while retaining accuracy.
            For 2D it will reduce the memory usage by approximately 15%.
            For 3D it will reduce the memory usage by approximately 25%.
            This option omits the anisotropic relaxation mechanisms to model the attenuation.
            We usually recommend using isotropic relaxation mechanisms
            unless the anisotropic attenuation is required for the simulation.

        """
        check_functions.check_instance(
            grid,
            fullwave.Grid,
        )
        check_functions.check_instance(
            medium,
            [fullwave.Medium, fullwave.MediumRelaxationMaps],
        )
        check_functions.check_instance(
            source,
            fullwave.Source,
        )
        check_functions.check_instance(
            sensor,
            fullwave.Sensor,
        )

        self.grid_org = grid
        self.medium_org = medium
        self.source_org = source
        self.sensor_org = sensor
        self.is_3d = grid.is_3d
        self.use_isotropic_relaxation = use_isotropic_relaxation

        self.m_spatial_order = m_spatial_order
        self.n_pml_layer = n_pml_layer
        self.n_transition_layer = n_transition_layer

        domain_size: tuple[float, ...]
        if self.is_3d:
            domain_size = (
                (self.medium_org.sound_speed.shape[0] + 2 * self.num_boundary_points)
                * self.grid_org.dx,
                (self.medium_org.sound_speed.shape[1] + 2 * self.num_boundary_points)
                * self.grid_org.dy,
                (self.medium_org.sound_speed.shape[2] + 2 * self.num_boundary_points)
                * self.grid_org.dz,
            )
        else:
            domain_size = (
                (self.medium_org.sound_speed.shape[0] + 2 * self.num_boundary_points)
                * self.grid_org.dx,
                (self.medium_org.sound_speed.shape[1] + 2 * self.num_boundary_points)
                * self.grid_org.dy,
            )

        logger.debug("building extended grid for pml...")
        self.extended_grid = fullwave.Grid(
            domain_size=domain_size,
            f0=self.grid_org.f0,
            duration=self.grid_org.duration,
            c0=self.grid_org.c0,
            ppw=self.grid_org.ppw,
            cfl=self.grid_org.cfl,
        )
        logger.debug("building extended grid for pml...done")

        logger.debug("building extended medium for pml...")
        if isinstance(self.medium_org, fullwave.MediumRelaxationMaps):
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future_sound_speed = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.sound_speed,
                )
                future_density = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.density,
                )
                future_beta = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.beta,
                )
                future_alpha_coeff = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.alpha_coeff,
                )
                future_alpha_power = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.alpha_power,
                )
                future_relaxation_param_dict = {
                    key: executor.submit(self._extend_map_for_pml, value)
                    for key, value in self.medium_org.relaxation_param_dict.items()
                }

                extended_sound_speed = future_sound_speed.result()
                extended_density = future_density.result()
                extended_beta = future_beta.result()
                extended_alpha_coeff = future_alpha_coeff.result()
                extended_alpha_power = future_alpha_power.result()
                extended_relaxation_param_dict = {
                    key: future.result() for key, future in future_relaxation_param_dict.items()
                }

            self.extended_medium = fullwave.MediumRelaxationMaps(
                grid=self.extended_grid,
                sound_speed=extended_sound_speed,
                density=extended_density,
                beta=extended_beta,
                alpha_coeff=extended_alpha_coeff,
                alpha_power=extended_alpha_power,
                relaxation_param_dict=extended_relaxation_param_dict,
                air_coords=self.medium_org.air_coords + self.num_boundary_points,
                n_relaxation_mechanisms=self.medium_org.n_relaxation_mechanisms,
                n_jobs=self.medium_org.n_jobs,
                dtype=getattr(self.medium_org, "dtype", np.float64),
            )
        else:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future_sound_speed = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.sound_speed,
                )
                future_density = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.density,
                )
                future_beta = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.beta,
                )
                future_alpha_coeff = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.alpha_coeff,
                )
                future_alpha_power = executor.submit(
                    self._extend_map_for_pml,
                    self.medium_org.alpha_power,
                )

                extended_sound_speed = future_sound_speed.result()
                extended_density = future_density.result()
                extended_beta = future_beta.result()
                extended_alpha_coeff = future_alpha_coeff.result()
                extended_alpha_power = future_alpha_power.result()
            self.extended_medium = fullwave.Medium(
                grid=self.extended_grid,
                sound_speed=extended_sound_speed,
                density=extended_density,
                beta=extended_beta,
                alpha_coeff=extended_alpha_coeff,
                alpha_power=extended_alpha_power,
                air_coords=self.medium_org.air_coords + self.num_boundary_points,
                n_relaxation_mechanisms=self.medium_org.n_relaxation_mechanisms,
                path_relaxation_parameters_database=self.medium_org.path_relaxation_parameters_database,
                attenuation_builder=self.medium_org.attenuation_builder,
                n_jobs=self.medium_org.n_jobs,
                dtype=getattr(self.medium_org, "dtype", np.float64),
            )
        logger.debug("building extended medium for pml...done")

        logger.debug("building extended source for pml...")
        extended_grid_shape = tuple(
            s + 2 * self.num_boundary_points for s in self.source_org.grid_shape
        )
        incoords_add_ext = (
            self.source_org.incoords_add + self.num_boundary_points
            if getattr(self.source_org, "incoords_add", None) is not None
            else None
        )
        self.extended_source = fullwave.Source(
            p0=self.source_org.p0,
            coords=self.source_org.incoords + self.num_boundary_points,
            grid_shape=extended_grid_shape,
            p0_additive=self.source_org.p0_additive,
            coords_additive=incoords_add_ext,
        )
        logger.debug("building extended source for pml...done")

        logger.debug("building extended sensor for pml...")
        extended_sensor_grid_shape = tuple(
            s + 2 * self.num_boundary_points for s in self.sensor_org.grid_shape
        )
        self.extended_sensor = fullwave.Sensor(
            coords=self.sensor_org.outcoords + self.num_boundary_points,
            grid_shape=extended_sensor_grid_shape,
            sampling_modulus_time=self.sensor_org.sampling_modulus_time,
        )
        logger.debug("building extended sensor for pml...done")
        if self.is_3d:
            self.pml_mask_x, self.pml_mask_y, self.pml_mask_z = self._localize_pml_region()
        else:
            self.pml_mask_x, self.pml_mask_y = self._localize_pml_region()

        self.pml_layer_m = self.extended_grid.dx * self.n_pml_layer
        self.transition_layer_m = self.extended_grid.dx * self.n_transition_layer

        self.n_polynomial = 2
        self.theoritical_reflection_coefficient = 10 ** (-30)

        if self.n_pml_layer == 0:
            self.n_transition_layer = 0

    # ---
    @cached_property
    def num_boundary_points(self) -> int:
        """Returns the number of the boundary points.

        Number of PML layer and ghost cells.
        """
        return self.n_transition_layer + self.n_pml_layer + self.m_spatial_order

    @cached_property
    def nx(self) -> int:
        """Returns the number of grid points in x-direction."""
        return self.extended_grid.nx

    @cached_property
    def ny(self) -> int:
        """Returns the number of grid points in y-direction."""
        return self.extended_grid.ny

    @cached_property
    def nz(self) -> int:
        """Returns the number of grid points in y-direction."""
        return self.extended_grid.nz

    @cached_property
    def nt(self) -> int:
        """Returns the number of time steps."""
        return self.extended_grid.nt

    @cached_property
    def n_sources(self) -> int:
        """Return the number of sources."""
        return self.extended_source.n_sources

    @cached_property
    def n_sensors(self) -> int:
        """Return the number of sources."""
        return self.extended_sensor.n_sensors

    @cached_property
    def n_air(self) -> int:
        """Return the number of air coordinates."""
        return self.extended_medium.n_air

    @cached_property
    def n_coords_zero(self) -> int:
        """Return the number of air coordinates.

        (alias for self.n_air)
        """
        return self.n_air

    # def _extend_map_for_pml(
    #     self,
    #     input_map: NDArray[np.float64 | np.int64 | np.bool],
    #     *,
    #     fill_edge: bool = True,
    # ) -> NDArray[np.float64 | np.int64 | np.bool]:
    #     kwargs = {} if fill_edge else {"constant_values": 0}
    #     return np.pad(
    #         input_map,
    #         pad_width=self.num_boundary_points,
    #         mode="edge" if fill_edge else "constant",
    #         **kwargs,
    #     )

    def _extend_map_for_pml(
        self,
        input_map: NDArray[np.float64 | np.int64 | np.bool_],
        *,
        fill_edge: bool = True,
    ) -> NDArray[np.float64 | np.int64 | np.bool_]:
        """Fast version using pre-allocation and direct assignment instead of np.pad."""
        pad = self.num_boundary_points

        # Pre-allocate output array with correct dtype
        if self.is_3d:
            nx, ny, nz = input_map.shape
            output = np.empty((nx + 2 * pad, ny + 2 * pad, nz + 2 * pad), dtype=input_map.dtype)

            # Fill center with original data (single copy)
            output[pad : pad + nx, pad : pad + ny, pad : pad + nz] = input_map

            if fill_edge:
                # Fill edges efficiently using broadcasting
                # X boundaries
                output[:pad, pad : pad + ny, pad : pad + nz] = input_map[0:1, :, :]
                output[pad + nx :, pad : pad + ny, pad : pad + nz] = input_map[-1:, :, :]

                # Y boundaries (now includes X corners)
                output[:, :pad, pad : pad + nz] = output[:, pad : pad + 1, pad : pad + nz]
                output[:, pad + ny :, pad : pad + nz] = output[
                    :,
                    pad + ny - 1 : pad + ny,
                    pad : pad + nz,
                ]

                # Z boundaries (now includes all corners)
                output[:, :, :pad] = output[:, :, pad : pad + 1]
                output[:, :, pad + nz :] = output[:, :, pad + nz - 1 : pad + nz]
            else:
                # Fill with zeros
                output[:pad, :, :] = 0
                output[pad + nx :, :, :] = 0
                output[:, :pad, :] = 0
                output[:, pad + ny :, :] = 0
                output[:, :, :pad] = 0
                output[:, :, pad + nz :] = 0
        else:  # 2D case
            nx, ny = input_map.shape
            output = np.empty((nx + 2 * pad, ny + 2 * pad), dtype=input_map.dtype)

            # Fill center
            output[pad : pad + nx, pad : pad + ny] = input_map

            if fill_edge:
                # Fill edges
                output[:pad, pad : pad + ny] = input_map[0:1, :]
                output[pad + nx :, pad : pad + ny] = input_map[-1:, :]
                output[:, :pad] = output[:, pad : pad + 1]
                output[:, pad + ny :] = output[:, pad + ny - 1 : pad + ny]
            else:
                output[:pad, :] = 0
                output[pad + nx :, :] = 0
                output[:, :pad] = 0
                output[:, pad + ny :] = 0

        return output

    def _localize_pml_region(self) -> tuple[NDArray[np.float64], ...]:
        if self.is_3d:
            n_x_extended, n_y_extended, n_z_extended = self.extended_medium.sound_speed.shape

            # Store 1D profiles instead of full 3D arrays to save memory.
            # Each mask is separable: pml_mask_x[i,j,k] only depends on i.
            pml_mask_x = np.zeros(n_x_extended, dtype=np.float64)
            pml_mask_y = np.zeros(n_y_extended, dtype=np.float64)
            pml_mask_z = np.zeros(n_z_extended, dtype=np.float64)

            # PML indices and values
            i = np.arange(self.n_pml_layer, dtype=np.int64)
            vals = i.astype(np.float64) / self.n_pml_layer

            ix1 = i + (n_x_extended - self.m_spatial_order - self.n_pml_layer)
            ix2 = self.m_spatial_order + self.n_pml_layer - i - 1

            iy1 = i + (n_y_extended - self.m_spatial_order - self.n_pml_layer)
            iy2 = self.m_spatial_order + self.n_pml_layer - i - 1

            iz1 = i + (n_z_extended - self.m_spatial_order - self.n_pml_layer)
            iz2 = self.m_spatial_order + self.n_pml_layer - i - 1

            # Fill PML ramps
            pml_mask_x[ix1] = vals
            pml_mask_x[ix2] = vals

            pml_mask_y[iy1] = vals
            pml_mask_y[iy2] = vals

            pml_mask_z[iz1] = vals
            pml_mask_z[iz2] = vals

            # Inner "hard" PML region
            pml_mask_x[0 : self.m_spatial_order] = 1.0
            pml_mask_x[n_x_extended - self.m_spatial_order : n_x_extended] = 1.0

            pml_mask_y[0 : self.m_spatial_order] = 1.0
            pml_mask_y[n_y_extended - self.m_spatial_order : n_y_extended] = 1.0

            pml_mask_z[0 : self.m_spatial_order] = 1.0
            pml_mask_z[n_z_extended - self.m_spatial_order : n_z_extended] = 1.0

            return pml_mask_x, pml_mask_y, pml_mask_z

        # 2D case — store 1D profiles instead of full 2D arrays
        n_x_extended, n_y_extended = self.extended_medium.sound_speed.shape

        pml_mask_x = np.zeros(n_x_extended, dtype=np.float64)
        pml_mask_y = np.zeros(n_y_extended, dtype=np.float64)

        i = np.arange(self.n_pml_layer, dtype=np.int64)
        vals = i.astype(np.float64) / self.n_pml_layer

        ix1 = i + (n_x_extended - self.m_spatial_order - self.n_pml_layer)
        ix2 = self.m_spatial_order + self.n_pml_layer - i - 1

        iy1 = i + (n_y_extended - self.m_spatial_order - self.n_pml_layer)
        iy2 = self.m_spatial_order + self.n_pml_layer - i - 1

        pml_mask_x[ix1] = vals
        pml_mask_x[ix2] = vals

        pml_mask_y[iy1] = vals
        pml_mask_y[iy2] = vals

        pml_mask_x[0 : self.m_spatial_order] = 1.0
        pml_mask_x[n_x_extended - self.m_spatial_order : n_x_extended] = 1.0

        pml_mask_y[0 : self.m_spatial_order] = 1.0
        pml_mask_y[n_y_extended - self.m_spatial_order : n_y_extended] = 1.0

        return pml_mask_x, pml_mask_y

    @staticmethod
    def _calc_a_and_b(
        d_x: float | NDArray[np.float64],
        kappa_x: float | NDArray[np.float64],
        alpha_x: float | NDArray[np.float64],
        dt: float | NDArray[np.float64],
        output_dtype: np.dtype | None = None,
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        d_x = np.asarray(d_x, dtype=np.float64)
        kappa_x = np.asarray(kappa_x, dtype=np.float64)
        alpha_x = np.asarray(alpha_x, dtype=np.float64)
        dt = np.asarray(dt, dtype=np.float64)

        eps = np.finfo(np.float64).eps  # noqa: F841

        # b = exp(-(dx/kappa_x + alpha_x) * dt)
        b = ne.evaluate("exp(-(d_x/kappa_x + alpha_x) * dt)")

        # denom = kappa_x*(dx + kappa_x*alpha_x) + eps
        denom = ne.evaluate("kappa_x*(d_x + kappa_x*alpha_x) + eps")  # noqa: F841

        # a = dx/denom*(b - 1)
        a = ne.evaluate("d_x/denom*(b - 1)")

        if output_dtype is not None and output_dtype != np.float64:
            a = a.astype(output_dtype, copy=False)
            b = b.astype(output_dtype, copy=False)

        return a, b

    def run(self, *, use_pml: bool = True) -> fullwave.MediumRelaxationMaps:
        """Generate perfect matched layer (PML) relaxation parameters.

        It generates the relaxation parameters
        for the PML region considering the given medium and PML parameters.

        Returns
        -------
        Medium
            A Medium instance with the constructed domain properties.

        """
        logger.debug("Running PML builder...")
        if use_pml:
            extended_medium: fullwave.MediumRelaxationMaps = self.extended_medium.build()
            if self.is_3d:
                return self._apply_pml_3d(
                    extended_medium=extended_medium,
                    theoritical_reflection_coefficient=self.theoritical_reflection_coefficient,
                    n_polynomial=self.n_polynomial,
                )

            return self._apply_pml_2d(
                extended_medium=extended_medium,
                theoritical_reflection_coefficient=self.theoritical_reflection_coefficient,
                n_polynomial=self.n_polynomial,
            )

        extended_medium: fullwave.MediumRelaxationMaps = self.extended_medium.build()
        return extended_medium

    def _apply_pml_2d(
        self,
        extended_medium: fullwave.MediumRelaxationMaps,
        theoritical_reflection_coefficient: float,
        n_polynomial: float,
    ) -> fullwave.MediumRelaxationMaps:
        """Apply PML to the extended medium relaxation parameters.

        ref: Komatitsch, D., & Martin, R. (2007).
        An unsplit convolutional perfectly matched layer improved
        at grazing incidence for the seismic wave equation.
        Geophysics, 72(5), SM155-SM167. https://doi.org/10.1190/1.2757586

        Parameters
        ----------
        extended_medium : fullwave.MediumRelaxationMaps
            The extended medium relaxation parameters.
        n_polynomial : float
            The polynomial order for the PML damping parameter.
            it changes the transition function shape from the medium to the PML.
        theoritical_reflection_coefficient : float
            The theoretical reflection coefficient for the PML.
            it changes the PML strength. it gets unstable if it is too low.

        Returns
        -------
        fullwave.MediumRelaxationMaps
            The extended medium relaxation parameters with PML applied.

        """
        logger.debug("Applying 2D PML...")
        # alpha=0 and d=0 will make a and b in the PML be 0
        # this procedure shrinks the multiple relaxation mechanisms to a single one
        alpha_target_pml = 0
        alpha_target_higher_nu = 0
        d_target_higher_nu = 0

        # see Komatitsch, D., & Martin, R. (2007), SM160
        d_target_pml = (
            -(n_polynomial + 1)
            * self.extended_grid.c0
            * np.log(theoritical_reflection_coefficient)
            / (2 * (self.pml_layer_m + self.transition_layer_m))
            # / (2 * (self.pml_layer_m))
        )
        # alpha_pml_entrance = np.pi * self.extended_grid.f0

        out_dict = {}
        relaxation_param_dict = extended_medium.relaxation_param_dict
        rename_dict = _obtain_relax_var_rename_dict(
            n_relaxation_mechanisms=self.extended_medium.n_relaxation_mechanisms,
            is_3d=self.is_3d,
            use_isotropic_relaxation=self.use_isotropic_relaxation,
        )

        def _compute_one(
            key_fw2: str,
            key_py: str,
            relaxation_param_dict: dict[str, NDArray[np.float64]],
            alpha_target_higher_nu: float,
            d_target_higher_nu: float,
            alpha_target_pml: float,
            d_target_pml: float,
            n_polynomial: float,
            is_3d: bool,  # noqa: FBT001
            apply_transition_and_pml_fn: callable,
        ) -> tuple[str, NDArray[np.float64]]:
            """Return (key_fw2, computed_array). No side effects."""
            arr = relaxation_param_dict[key_py]

            if key_fw2 in ["kappa_x", "kappa_u", "kappa_y", "kappa_w"]:
                return key_fw2, arr

            # helper predicates
            is_alpha = (
                ("alpha_u_nu" in key_fw2)
                or ("alpha_x_nu" in key_fw2)
                or ("alpha_w_nu" in key_fw2)
                or ("alpha_y_nu" in key_fw2)
            )
            is_d = (
                ("d_u_nu" in key_fw2)
                or ("d_x_nu" in key_fw2)
                or ("d_w_nu" in key_fw2)
                or ("d_y_nu" in key_fw2)
            )
            has_nu1 = "nu1" in key_fw2

            if is_alpha and (not has_nu1):
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=alpha_target_higher_nu,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_higher_nu,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                return key_fw2, out

            if is_d and (not has_nu1):
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=d_target_higher_nu,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_higher_nu,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                return key_fw2, out

            if is_alpha and has_nu1:
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=alpha_target_pml,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="linear",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_pml,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="linear",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                return key_fw2, out

            if is_d and has_nu1:
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=d_target_pml,
                    array_shape=arr.shape,
                    axis=0,
                    n_polynomial=n_polynomial,
                    transition_type="polynomial",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_pml,
                    array_shape=arr.shape,
                    axis=1,
                    n_polynomial=n_polynomial,
                    transition_type="polynomial",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                return key_fw2, out

            error_msg = f"Unhandled key_fw2 pattern: {key_fw2}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        items = list(rename_dict.items())

        results = Parallel(n_jobs=self.medium_org.n_jobs, backend="threading")(
            delayed(_compute_one)(
                key_fw2,
                key_py,
                relaxation_param_dict,
                alpha_target_higher_nu,
                d_target_higher_nu,
                alpha_target_pml,
                d_target_pml,
                n_polynomial,
                self.is_3d,
                self._apply_transition_and_pml,
            )
            for key_fw2, key_py in items
        )
        out_dict = dict(results)

        logger.debug("Calculating PML a and b coefficients...")
        axis_list = ["u", "x"] if self.use_isotropic_relaxation else ["u", "w", "x", "y"]
        # Build independent tasks (flatten nested loops)
        tasks = [
            (nu, axis)
            for nu in range(1, extended_medium.n_relaxation_mechanisms + 1)
            for axis in axis_list
        ]

        medium_dtype = getattr(extended_medium, "dtype", None)

        def _worker(
            nu: int,
            axis: str,
        ) -> tuple[str, NDArray[np.float64], str, NDArray[np.float64]]:
            a, b = self._calc_a_and_b(
                d_x=out_dict[f"d_{axis}_nu{nu}"],
                kappa_x=out_dict[f"kappa_{axis}"],
                alpha_x=out_dict[f"alpha_{axis}_nu{nu}"],
                dt=extended_medium.grid.dt,
                output_dtype=medium_dtype,
            )
            # Return keys + values so parent can update dict safely
            return (f"a_pml_{axis}{nu}", a, f"b_pml_{axis}{nu}", b)

        results = Parallel(
            n_jobs=self.medium_org.n_jobs,  # use all cores
            backend="loky",  # process-based; safe default for Python code
            prefer="processes",
        )(
            starmap(delayed(_worker), tasks),
        )

        for a_key, a_val, b_key, b_val in results:
            out_dict[a_key] = a_val
            out_dict[b_key] = b_val

        logger.debug("PML a and b coefficients calculation completed.")

        logger.debug("Updating extended medium relaxation parameters...")
        extended_medium.relaxation_param_dict_for_fw2.update(
            out_dict,
        )
        logger.debug("PML application completed.")

        return extended_medium

    def _apply_pml_3d(  # noqa: PLR0915
        self,
        extended_medium: fullwave.MediumRelaxationMaps,
        theoritical_reflection_coefficient: float,
        n_polynomial: float,
    ) -> fullwave.MediumRelaxationMaps:
        """Apply PML to the extended medium relaxation parameters.

        ref: Komatitsch, D., & Martin, R. (2007).
        An unsplit convolutional perfectly matched layer improved
        at grazing incidence for the seismic wave equation.
        Geophysics, 72(5), SM155-SM167. https://doi.org/10.1190/1.2757586

        Parameters
        ----------
        extended_medium : fullwave.MediumRelaxationMaps
            The extended medium relaxation parameters.
        n_polynomial : float
            The polynomial order for the PML damping parameter.
            it changes the transition function shape from the medium to the PML.
        theoritical_reflection_coefficient : float
            The theoretical reflection coefficient for the PML.
            it changes the PML strength. it gets unstable if it is too low.

        Returns
        -------
        fullwave.MediumRelaxationMaps
            The extended medium relaxation parameters with PML applied.

        """
        logger.debug("Applying 3D PML...")
        # alpha=0 and d=0 will make a and b in the PML be 0
        # this procedure shrinks the multiple relaxation mechanisms to a single one
        alpha_target_pml = 0
        alpha_target_higher_nu = 0
        d_target_higher_nu = 0

        # see Komatitsch, D., & Martin, R. (2007), SM160
        d_target_pml = (
            -(n_polynomial + 1)
            * self.extended_grid.c0
            * np.log(theoritical_reflection_coefficient)
            / (2 * (self.pml_layer_m + self.transition_layer_m))
            # / (2 * self.pml_layer_m)
        )

        out_dict = {}
        relaxation_param_dict = extended_medium.relaxation_param_dict
        rename_dict = _obtain_relax_var_rename_dict(
            n_relaxation_mechanisms=self.extended_medium.n_relaxation_mechanisms,
            is_3d=self.is_3d,
            use_isotropic_relaxation=self.use_isotropic_relaxation,
        )

        def _compute_one(
            key_fw2: str,
            key_py: str,
            relaxation_param_dict: dict[str, NDArray[np.float64]],
            alpha_target_higher_nu: float,
            d_target_higher_nu: float,
            alpha_target_pml: float,
            d_target_pml: float,
            n_polynomial: float,
            is_3d: bool,  # noqa: FBT001
            apply_transition_and_pml_fn: callable,
        ) -> tuple[str, NDArray[np.float64]]:
            """Return (key_fw2, computed_array). No side effects."""
            arr = relaxation_param_dict[key_py]

            if key_fw2 in ["kappa_x", "kappa_u", "kappa_y", "kappa_v", "kappa_z", "kappa_w"]:
                return key_fw2, arr

            # helper predicates
            is_alpha = (
                ("alpha_u_nu" in key_fw2)
                or ("alpha_v_nu" in key_fw2)
                or ("alpha_w_nu" in key_fw2)
                or ("alpha_x_nu" in key_fw2)
                or ("alpha_y_nu" in key_fw2)
                or ("alpha_z_nu" in key_fw2)
            )
            is_d = (
                ("d_u_nu" in key_fw2)
                or ("d_v_nu" in key_fw2)
                or ("d_w_nu" in key_fw2)
                or ("d_x_nu" in key_fw2)
                or ("d_y_nu" in key_fw2)
                or ("d_z_nu" in key_fw2)
            )
            has_nu1 = "nu1" in key_fw2

            if is_alpha and (not has_nu1):
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=alpha_target_higher_nu,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_higher_nu,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_higher_nu,
                    array_shape=arr.shape,
                    axis=2,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                return key_fw2, out
            if is_d and (not has_nu1):
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=d_target_higher_nu,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_higher_nu,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_higher_nu,
                    array_shape=arr.shape,
                    axis=2,
                    transition_type="cosine",
                    transit_within_transition_layer=True,
                    is_3d=is_3d,
                )
                return key_fw2, out
            if is_alpha and has_nu1:
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=alpha_target_pml,
                    array_shape=arr.shape,
                    axis=0,
                    transition_type="linear",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_pml,
                    array_shape=arr.shape,
                    axis=1,
                    transition_type="linear",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=alpha_target_pml,
                    array_shape=arr.shape,
                    axis=2,
                    transition_type="linear",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                return key_fw2, out
            if is_d and has_nu1:
                out = apply_transition_and_pml_fn(
                    arr,
                    value_target=d_target_pml,
                    array_shape=arr.shape,
                    axis=0,
                    n_polynomial=n_polynomial,
                    transition_type="polynomial",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_pml,
                    array_shape=arr.shape,
                    axis=1,
                    n_polynomial=n_polynomial,
                    transition_type="polynomial",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                out = apply_transition_and_pml_fn(
                    out,
                    value_target=d_target_pml,
                    array_shape=arr.shape,
                    axis=2,
                    n_polynomial=n_polynomial,
                    transition_type="polynomial",
                    transit_within_transition_layer=False,
                    transit_within_pml_layer=False,
                    is_3d=is_3d,
                )
                return key_fw2, out
            error_msg = f"Unhandled key_fw2 pattern: {key_fw2}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        items = list(rename_dict.items())
        results = Parallel(n_jobs=self.medium_org.n_jobs, backend="threading")(
            delayed(_compute_one)(
                key_fw2,
                key_py,
                relaxation_param_dict,
                alpha_target_higher_nu,
                d_target_higher_nu,
                alpha_target_pml,
                d_target_pml,
                n_polynomial,
                self.is_3d,
                self._apply_transition_and_pml,
            )
            for key_fw2, key_py in items
        )
        out_dict = dict(results)

        logger.debug("Calculating PML a and b coefficients...")
        axis_list = ["u", "x"] if self.use_isotropic_relaxation else ["u", "v", "w", "x", "y", "z"]

        # Build independent tasks (flatten nested loops)
        tasks = [
            (nu, axis)
            for nu in range(1, extended_medium.n_relaxation_mechanisms + 1)
            for axis in axis_list
        ]

        medium_dtype = getattr(extended_medium, "dtype", None)

        def _worker(
            nu: int,
            axis: str,
        ) -> tuple[str, NDArray[np.float64], str, NDArray[np.float64]]:
            a, b = self._calc_a_and_b(
                d_x=out_dict[f"d_{axis}_nu{nu}"],
                kappa_x=out_dict[f"kappa_{axis}"],
                alpha_x=out_dict[f"alpha_{axis}_nu{nu}"],
                dt=extended_medium.grid.dt,
                output_dtype=medium_dtype,
            )
            # Return keys + values so parent can update dict safely
            return (f"a_pml_{axis}{nu}", a, f"b_pml_{axis}{nu}", b)

        results = Parallel(
            n_jobs=self.medium_org.n_jobs,  # use all cores
            backend="loky",  # process-based; safe default for Python code
            prefer="processes",
        )(
            starmap(delayed(_worker), tasks),
        )

        for a_key, a_val, b_key, b_val in results:
            out_dict[a_key] = a_val
            out_dict[b_key] = b_val

        logger.debug("PML a and b coefficients calculation completed.")

        logger.debug("Updating extended medium relaxation parameters...")
        extended_medium.relaxation_param_dict_for_fw2.update(
            out_dict,
        )
        logger.debug("PML application completed.")

        return extended_medium

    def _apply_transition_and_pml(  # noqa: C901, PLR0912, PLR0915
        self,
        input_array: NDArray[np.float64],
        value_target: float,
        array_shape: tuple[int, ...],
        axis: int = 0,
        *,
        transition_type: str = "smooth",
        n_polynomial: float = 2,
        transit_within_transition_layer: bool = False,
        transit_within_pml_layer: bool = False,
        disable_the_transition_and_pml: bool = False,
        is_3d: bool = False,
    ) -> NDArray[np.float64]:
        if transit_within_transition_layer and transit_within_pml_layer:
            error_msg = (
                "Both transit_within_transition_layer and transit_within_pml_layer "
                "cannot be True at the same time."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        if disable_the_transition_and_pml:
            return input_array

        if transit_within_transition_layer and self.n_transition_layer == 0:
            error_msg = (
                "Transition layer is not defined. "
                "Set transit_within_transition_layer to False or define n_transition_layer."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Input validation
        if axis not in {0, 1, 2}:
            error_msg = f"Invalid axis value. Expected 0, 1, 2, but got {axis}."
            logger.error(error_msg)
            raise ValueError(error_msg)
        if axis == 2 and not is_3d:
            error_msg = (
                "axis=2 is only valid for 3D cases. Set is_3d=True if you are working with 3D data."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Compute layer parameters
        if transit_within_transition_layer:
            layer_thickness = self.n_transition_layer
            layer_offset = self.n_pml_layer
        elif transit_within_pml_layer:
            layer_thickness = self.n_pml_layer
            layer_offset = 0
        else:
            layer_thickness = self.n_pml_layer + self.n_transition_layer
            layer_offset = 0

        # Compute transition function once
        transition_linspace = np.linspace(0, 1, layer_thickness + 1)
        transition_map = {
            "smooth": _smooth_transition_function,
            "linear": _linear_transition_function,
            "polynomial": _n_th_deg_polynomial_function,
            "cosine": _cosine_transition_function,
        }

        if transition_type not in transition_map:
            error_msg = f"Invalid transition type: {transition_type}."
            logger.error(error_msg)
            raise ValueError(
                error_msg,
            )

        if transition_type == "polynomial":
            transition_function = transition_map[transition_type](
                transition_linspace,
                n=n_polynomial,
            )
        else:
            transition_function = transition_map[transition_type](transition_linspace)

        n_axis_extended = array_shape[axis]
        m_offset = self.m_spatial_order + layer_offset

        # Pre-compute indices (used multiple times)
        up_end = m_offset + layer_thickness
        down_start = n_axis_extended - m_offset - layer_thickness - 1

        # Move axis to 0 for uniform processing
        working_array = np.moveaxis(input_array, axis, 0)
        # make working_array writeable
        working_array.setflags(write=True)

        # Apply boundary conditions
        working_array[: m_offset + layer_thickness] = value_target
        working_array[n_axis_extended - m_offset - layer_thickness :] = value_target

        # Apply transitions (axis-agnostic)
        up_start = m_offset - 1
        down_end = n_axis_extended - m_offset

        # Fetch boundary values
        up_vals = working_array[up_end]
        down_vals = working_array[down_start]

        # Reshape for broadcasting based on dimensionality
        if is_3d:
            # For 3D: shape is (L, H, W) after moveaxis
            up_vals = up_vals[None, :, :]
            down_vals = down_vals[None, :, :]
            trans_up = transition_function[::-1][:, None, None]
            trans_down = transition_function[:, None, None]
        else:
            # For 2D: shape is (L, W) after moveaxis
            up_vals = up_vals[None, :]
            down_vals = down_vals[None, :]
            trans_up = transition_function[::-1][:, None]
            trans_down = transition_function[:, None]

        # Apply transitions
        working_array[up_start:up_end] = up_vals - trans_up * (up_vals - value_target)
        working_array[down_start:down_end] = down_vals - trans_down * (down_vals - value_target)

        # Move axis back
        return np.moveaxis(working_array, 0, axis)

    @staticmethod
    def _calc_time_constants(
        dx: NDArray[np.float64],
        kappa: NDArray[np.float64],
        alpha: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        return dx / kappa + alpha

    def _sort_relaxation_param_dict(
        self,
        relaxation_param_dict: dict[str, NDArray[np.float64]],
        relaxation_param_updates: dict[str, NDArray[np.float64]],
        n_relaxation_mechanisms: int,
    ) -> dict:
        kappa_x1 = relaxation_param_updates["kappa_x1"]
        kappa_x2 = relaxation_param_updates["kappa_x2"]

        d_x1 = []
        alpha_x1 = []
        d_x2 = []
        alpha_x2 = []
        time_const_x1 = []
        time_const_x2 = []
        for nu in range(1, n_relaxation_mechanisms + 1):
            d_x1_nu = relaxation_param_updates[f"d_x1_nu{nu}"]
            alpha_x1_nu = relaxation_param_updates[f"alpha_x1_nu{nu}"]
            d_x2_nu = relaxation_param_updates[f"d_x2_nu{nu}"]
            alpha_x2_nu = relaxation_param_updates[f"alpha_x2_nu{nu}"]

            d_x1.append(d_x1_nu)
            alpha_x1.append(alpha_x1_nu)
            d_x2.append(d_x2_nu)
            alpha_x2.append(alpha_x2_nu)

            time_const_x1_nu = self._calc_time_constants(
                dx=d_x1_nu,
                kappa=kappa_x1,
                alpha=alpha_x1_nu,
            )
            time_const_x2_nu = self._calc_time_constants(
                dx=d_x2_nu,
                kappa=kappa_x2,
                alpha=alpha_x2_nu,
            )
            time_const_x1.append(time_const_x1_nu)
            time_const_x2.append(time_const_x2_nu)

        time_const_x1 = np.stack(time_const_x1, axis=-1)
        time_const_x2 = np.stack(time_const_x2, axis=-1)
        d_x1 = np.stack(d_x1, axis=-1)
        alpha_x1 = np.stack(alpha_x1, axis=-1)
        d_x2 = np.stack(d_x2, axis=-1)
        alpha_x2 = np.stack(alpha_x2, axis=-1)

        # sort the nu values based on the time constants
        sorted_indices_x1 = np.argsort(time_const_x1, axis=-1)
        sorted_indices_x2 = np.argsort(time_const_x2, axis=-1)
        relaxation_param_dict["kappa_x1"] = np.atleast_2d(kappa_x1)
        relaxation_param_dict["kappa_x2"] = np.atleast_2d(kappa_x2)

        for nu in range(1, n_relaxation_mechanisms + 1):
            relaxation_param_dict[f"d_x1_nu{nu}"] = np.atleast_2d(
                np.take_along_axis(
                    d_x1,
                    np.expand_dims(sorted_indices_x1[..., nu - 1], axis=-1),
                    axis=-1,
                ).squeeze(-1),
            )
            relaxation_param_dict[f"alpha_x1_nu{nu}"] = np.atleast_2d(
                np.take_along_axis(
                    alpha_x1,
                    np.expand_dims(sorted_indices_x1[..., nu - 1], axis=-1),
                    axis=-1,
                ).squeeze(-1),
            )
            relaxation_param_dict[f"d_x2_nu{nu}"] = np.atleast_2d(
                np.take_along_axis(
                    d_x2,
                    np.expand_dims(sorted_indices_x2[..., nu - 1], axis=-1),
                    axis=-1,
                ).squeeze(-1),
            )
            relaxation_param_dict[f"alpha_x2_nu{nu}"] = np.atleast_2d(
                np.take_along_axis(
                    alpha_x2,
                    np.expand_dims(sorted_indices_x2[..., nu - 1], axis=-1),
                    axis=-1,
                ).squeeze(-1),
            )
        return relaxation_param_dict

    def plot(
        self,
        export_path: Path | str | None = Path("./temp/temp.png"),
        *,
        show: bool = False,
    ) -> None:
        """Plot the medium fields using matplotlib."""
        relaxation_param_dict_keys = initialize_relaxation_param_dict().keys()

        target_map_dict: OrderedDict = OrderedDict(
            [
                ("Sound speed", self.extended_medium.sound_speed),
                ("Density", self.extended_medium.density),
                ("Beta", self.extended_medium.beta),
                ("Air map", self.extended_medium.air_map),
            ],
        )
        for key in relaxation_param_dict_keys:
            target_map_dict[key] = self.extended_medium.relaxation_param_dict[key]

        target_map_dict.update(
            [
                ("PML mask x", self.pml_mask_x[:, None] * np.ones(self.extended_grid.ny)),
                ("PML mask y", np.ones(self.extended_grid.nx)[:, None] * self.pml_mask_y[None, :]),
                ("Source mask", self.extended_source.mask),
                ("Sensor mask", self.extended_sensor.mask),
            ],
        )

        num_plots = len(target_map_dict)
        # calculate subplot shape to make a square
        n_rows = int(np.sqrt(num_plots))
        n_cols = int(np.ceil(num_plots / n_rows))
        # adjust the fig size
        fig_size = (n_cols * 5, n_rows * 5)

        plt.close("all")
        _, axes = plt.subplots(n_rows, n_cols, figsize=fig_size)

        for ax, (title, map_data) in zip(
            axes.flatten(),
            target_map_dict.items(),
            strict=False,
        ):
            plot_utils.plot_array_on_ax(
                ax,
                map_data,
                title=title,
                xlim=(-5, self.extended_grid.ny + 5),
                ylim=(-5, self.extended_grid.nx + 5),
                reverse_y_axis=True,
            )
        plt.tight_layout()

        if export_path is not None:
            plt.savefig(export_path, dpi=300)
        if show:
            plt.show()
        plt.close("all")


@dataclass
class PMLBuilderExponentialAttenuation(PMLBuilder):
    """A class to set up PML for exponential attenuation media."""

    def __init__(
        self,
        grid: fullwave.Grid,
        medium: fullwave.Medium,
        source: fullwave.Source,
        sensor: fullwave.Sensor,
        *,
        m_spatial_order: int = 8,
        n_pml_layer: int = 40,
        # n_transition_layer: int = 40,
        # pml_alpha_target: float = 1.1,
        # pml_alpha_power_target: float = 1.6,
        # pml_strength_factor: float = 2.0,
        # use_2_relax_mechanisms: bool = False,
    ) -> None:
        """Initialize the PMLSetup with the given medium, source, sensor, and PML parameters.

        Parameters
        ----------
        grid: fullwave.Grid
            The grid configuration.
        medium : fullwave.Medium)
            The medium relaxation maps.
        source : fullwave.Source
            The source configuration.
        sensor : fullwave.Sensor
            The sensor configuration.
        m_spatial_order : int, optional
            fullwave simulation's spatial order (default is 8).
            It depends on the fullwave simulation binary version.
            Fullwave simulation has 2M th order spatial accuracy and fourth order accuracy in time.
            see Pinton, G. (2021) http://arxiv.org/abs/2106.11476 for more detail.
        n_pml_layer : int, optional
            PML layer thickness (default is 40).
        n_transition_layer : int, optional
            Number of transition layers (default is 40).
        pml_alpha_target : float, optional
            Target alpha value for PML (default is 0.5).
            This value is used to calculate the transition layer values.
        pml_alpha_power_target : float, optional
            Target alpha power value for PML (default is 1.0).
            This value is used to calculate the transition layer values.
        pml_strength_factor : float, optional
            Strength factor for PML (default is 2.0).
            This value is used to calculate the PML target values.
        use_2_relax_mechanisms : bool, optional
            If True, use 2 relaxation mechanisms for PML for stability (default is False).
            if True, pml_alpha_target, pml_alpha_power_target, and pml_strength_factor are ignored.

        """
        check_functions.check_instance(
            grid,
            fullwave.Grid,
        )
        check_functions.check_instance(
            medium,
            fullwave.Medium,
        )
        check_functions.check_instance(
            source,
            fullwave.Source,
        )
        check_functions.check_instance(
            sensor,
            fullwave.Sensor,
        )

        self.grid_org = grid
        self.medium_org = medium
        self.source_org = source
        self.sensor_org = sensor
        self.is_3d = grid.is_3d

        self.m_spatial_order = m_spatial_order
        self.n_pml_layer = n_pml_layer
        # self.n_transition_layer = n_transition_layer
        # self.pml_alpha_target = pml_alpha_target
        # self.pml_alpha_power_target = pml_alpha_power_target
        # self.pml_strength_factor = pml_strength_factor
        # self.use_2_relax_mechanisms = use_2_relax_mechanisms

        domain_size: tuple[float, ...]
        if self.is_3d:
            domain_size = (
                (self.medium_org.sound_speed.shape[0] + 2 * self.num_boundary_points)
                * self.grid_org.dx,
                (self.medium_org.sound_speed.shape[1] + 2 * self.num_boundary_points)
                * self.grid_org.dy,
                (self.medium_org.sound_speed.shape[2] + 2 * self.num_boundary_points)
                * self.grid_org.dz,
            )
        else:
            domain_size = (
                (self.medium_org.sound_speed.shape[0] + 2 * self.num_boundary_points)
                * self.grid_org.dx,
                (self.medium_org.sound_speed.shape[1] + 2 * self.num_boundary_points)
                * self.grid_org.dy,
            )
        self.extended_grid = fullwave.Grid(
            domain_size=domain_size,
            f0=self.grid_org.f0,
            duration=self.grid_org.duration,
            c0=self.grid_org.c0,
            ppw=self.grid_org.ppw,
            cfl=self.grid_org.cfl,
        )

        logger.debug("building extended medium for pml...")
        # run _extend_map_for_pml in parallel for all medium properties since it is a bottleneck
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future_sound_speed = executor.submit(
                self._extend_map_for_pml,
                self.medium_org.sound_speed,
            )
            future_density = executor.submit(
                self._extend_map_for_pml,
                self.medium_org.density,
            )
            future_beta = executor.submit(
                self._extend_map_for_pml,
                self.medium_org.beta,
            )
            future_alpha_coeff = executor.submit(
                self._extend_map_for_pml,
                self.medium_org.alpha_coeff,
            )
            future_alpha_power = executor.submit(
                self._extend_map_for_pml,
                self.medium_org.alpha_power,
            )

            extended_sound_speed = future_sound_speed.result()
            extended_density = future_density.result()
            extended_beta = future_beta.result()
            extended_alpha_coeff = future_alpha_coeff.result()
            extended_alpha_power = future_alpha_power.result()

        self.extended_medium = fullwave.Medium(
            grid=self.extended_grid,
            sound_speed=extended_sound_speed,
            density=extended_density,
            beta=extended_beta,
            alpha_coeff=extended_alpha_coeff,
            alpha_power=extended_alpha_power,
            air_coords=self.medium_org.air_coords + self.num_boundary_points,
            n_relaxation_mechanisms=self.medium_org.n_relaxation_mechanisms,
            path_relaxation_parameters_database=self.medium_org.path_relaxation_parameters_database,
            attenuation_builder=self.medium_org.attenuation_builder,
            dtype=getattr(self.medium_org, "dtype", np.float64),
        )
        logger.debug("Extended medium for PML built successfully.")

        extended_grid_shape = tuple(
            s + 2 * self.num_boundary_points for s in self.source_org.grid_shape
        )
        incoords_add_ext = (
            self.source_org.incoords_add + self.num_boundary_points
            if getattr(self.source_org, "incoords_add", None) is not None
            else None
        )
        self.extended_source = fullwave.Source(
            p0=self.source_org.p0,
            coords=self.source_org.incoords + self.num_boundary_points,
            grid_shape=extended_grid_shape,
            p0_additive=self.source_org.p0_additive,
            coords_additive=incoords_add_ext,
        )
        extended_sensor_grid_shape = tuple(
            s + 2 * self.num_boundary_points for s in self.sensor_org.grid_shape
        )
        self.extended_sensor = fullwave.Sensor(
            coords=self.sensor_org.outcoords + self.num_boundary_points,
            grid_shape=extended_sensor_grid_shape,
            sampling_modulus_time=self.sensor_org.sampling_modulus_time,
        )
        logger.debug("Extended source and sensor for PML built successfully.")

        logger.debug("Localizing PML region...")
        if self.is_3d:
            self.pml_mask_x, self.pml_mask_y, self.pml_mask_z = self._localize_pml_region()
        else:
            self.pml_mask_x, self.pml_mask_y = self._localize_pml_region()
        logger.debug("PML region localized successfully.")

        self.pml_layer_m = self.extended_grid.dx * self.n_pml_layer
        # self.transition_layer_m = self.extended_grid.dx * self.n_transition_layer

        self.n_polynomial = 2
        self.theoritical_reflection_coefficient = 10 ** (-30)

        if self.n_pml_layer == 0:
            self.n_transition_layer = 0

    @cached_property
    def num_boundary_points(self) -> int:
        """Returns the number of the boundary points.

        Number of PML layer and ghost cells.
        """
        return self.n_pml_layer + self.m_spatial_order

    def run(self, *, use_pml: bool = True) -> fullwave.MediumExponentialAttenuation:
        """Generate perfect matched layer (PML) relaxation parameters.

        It generates the relaxation parameters
        for the PML region considering the given medium and PML parameters.

        Returns
        -------
        Medium
            A Medium instance with the constructed domain properties.

        """
        if use_pml:
            logger.debug("Building extended medium for PML...")
            extended_medium: fullwave.MediumExponentialAttenuation = (
                self.extended_medium.build_exponential()
            )
            logger.debug("Extended medium for PML built successfully.")
            if self.is_3d:
                logger.debug("Applying 3D PML to the extended medium...")
                return self._apply_pml_3d(
                    extended_medium=extended_medium,
                )

            logger.debug("Applying 2D PML to the extended medium...")
            return self._apply_pml_2d(
                extended_medium=extended_medium,
            )

        logger.debug("PML is disabled. Building extended medium without applying PML...")
        extended_medium: fullwave.MediumExponentialAttenuation = (
            self.extended_medium.build_exponential()
        )
        logger.debug("Extended medium built successfully without applying PML.")
        return extended_medium

    @staticmethod
    def _mask_body_2d(nx: int, ny: int, n_body: int) -> NDArray[np.float32]:
        """Create a mask for the PML region.

        Parameters
        ----------
        nx : int
            Number of grid points in the x-direction.
        ny : int
            Number of grid points in the y-direction.
        n_body : int
            Thickness of the body region (non-PML region).

        Returns
        -------
        NDArray[np.float32]
            A 2D numpy array representing the PML mask.
            Interior (body) region is 1, PML boundary approaches 0.

        """

        def edge_distance_1d(n: int, n_body: int) -> NDArray[np.float32]:
            d = np.zeros(n, dtype=np.float32)
            if n_body <= 0:
                return d
            d[:n_body] = np.arange(n_body, 0, -1, dtype=np.float32)
            d[-n_body:] = np.arange(1, n_body + 1, dtype=np.float32)
            return d

        rx = edge_distance_1d(nx, n_body)[:, None]  # noqa: F841
        ry = edge_distance_1d(ny, n_body)[None, :]  # noqa: F841

        mask_sq = ne.evaluate("rx*rx + ry*ry")

        mmax = float(np.sqrt(mask_sq.max()))
        if mmax > 0.0:
            mask_sq = ne.evaluate("mask_sq / (mmax*mmax)")

        return ne.evaluate("1 - sqrt(mask_sq)")

    @staticmethod
    def _mask_body_3d(nx: int, ny: int, nz: int, n_body: int) -> NDArray[np.float32]:
        """Create a mask for the PML region.

        Parameters
        ----------
        nx : int
            Number of grid points in the x-direction.
        ny : int
            Number of grid points in the y-direction.
        nz : int
            Number of grid points in the z-direction.
        n_body : int
            Thickness of the body region (non-PML region).

        Returns
        -------
        NDArray[np.float64]
            A 3D numpy array representing the PML mask.

        """

        def edge_distance_1d(n: int, n_body: int) -> NDArray[np.float32]:
            d = np.zeros(n, dtype=np.float32)
            if n_body <= 0:
                return d
            d[:n_body] = np.arange(n_body, 0, -1, dtype=np.float32)
            d[-n_body:] = np.arange(1, n_body + 1, dtype=np.float32)
            return d

        rx = edge_distance_1d(nx, n_body)[:, None, None]  # noqa: F841
        ry = edge_distance_1d(ny, n_body)[None, :, None]  # noqa: F841
        rz = edge_distance_1d(nz, n_body)[None, None, :]  # noqa: F841

        # 1) compute squared distance with numexpr (no reduction here)
        mask_sq = ne.evaluate("rx*rx + ry*ry + rz*rz")  # shape (nx, ny, nz), float32

        # 2) reduction done by NumPy, then scalar sqrt
        mmax = float(np.sqrt(mask_sq.max()))
        if mmax > 0.0:
            # 3) normalize in squared space (still via numexpr, elementwise only)
            mask_sq = ne.evaluate("mask_sq / (mmax*mmax)")

        # 4) final sqrt elementwise
        return ne.evaluate("1 - sqrt(mask_sq)")

    def _apply_pml_3d(
        self,
        extended_medium: fullwave.MediumExponentialAttenuation,
    ) -> fullwave.MediumExponentialAttenuation:
        a_mask = self._mask_body_3d(
            nx=extended_medium.alpha_exp.shape[0],
            ny=extended_medium.alpha_exp.shape[1],
            nz=extended_medium.alpha_exp.shape[2],
            n_body=self.num_boundary_points,
        )
        extended_medium.alpha_exp *= a_mask
        return extended_medium

    def _apply_pml_2d(
        self,
        extended_medium: fullwave.MediumExponentialAttenuation,
    ) -> fullwave.MediumExponentialAttenuation:
        a_mask = self._mask_body_2d(
            nx=extended_medium.alpha_exp.shape[0],
            ny=extended_medium.alpha_exp.shape[1],
            n_body=self.num_boundary_points,
        )
        extended_medium.alpha_exp *= a_mask
        return extended_medium
