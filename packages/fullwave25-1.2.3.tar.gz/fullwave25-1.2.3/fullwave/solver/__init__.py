"""fullwave solver module."""
