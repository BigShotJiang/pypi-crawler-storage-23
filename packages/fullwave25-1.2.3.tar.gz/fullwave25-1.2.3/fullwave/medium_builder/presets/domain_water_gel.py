"""water gel domain."""
