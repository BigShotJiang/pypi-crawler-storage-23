"""
setup.py — The Hat Protocol Python Package
pip install the-hat-protocol
"""

from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="the-hat-protocol",
    version="2.0.2",
    author="The Hat Protocol / Mr. C",
    author_email="contact@thehatprotocol.com",
    description="AI Governance Middleware — We don't make AI, we make AI behave.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/thehatprotocol/thp",
    packages=find_packages(),
    package_data={"thp": ["../config/*.json"]},
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[],  # Zero external dependencies by design
    extras_require={
        "dev": ["pytest>=7.0", "pytest-cov"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="AI governance, AI safety, human sovereignty, HUXmesh, AIAIOH, THP",
    entry_points={
        "console_scripts": [
            "thp=thp.__main__:main",
        ],
    },
)
