# The Hat Protocol (THP) v1.6.5

**"We don't make AI, we make AI behave."**

AI Governance as a Service (GaaS) — built for Main Street, deployable by developers, certified for enterprise.

Service-Disabled Veteran-Owned Small Business (SDVOSB) | Patent Pending | Chattanooga, Tennessee

---

## What Is THP?

The Hat Protocol is an AI governance framework that puts humans in charge of AI behavior. It does not replace AI — it enforces the rules humans write for how AI should operate.

**Verify — You Decide.** The machine classifies. The human concludes. Always.

---

## Quick Install

```bash
pip install the-hat-protocol
```

---

## What's Inside

- **THPGuard** — middleware enforcement layer. Wraps any AI API call. Every input and output evaluated before it reaches the user.
- **DriftDetector** — cross-turn semantic drift engine. Detects manipulation, emotional bonding, authority transfer, grooming sequences across a conversation.
- **RAGEngine** — pure Python vector store. Zero external dependencies. SHMO registry, THP doctrine, and claim verification built in.
- **HUXvisionEngine** — SuperHUXbomb automation. Ingests any article, GYR-scores every claim with receipts, flags SHMO sources, detects critical omissions.
- **HUXmesh** — governance handoff prompt generator. Produces a constitutional handoff for any AI instance in kernel or full mode.
- **QuintLoop** — five-council deliberation engine for high-stakes decisions.
- **ReceiptLogger** — tamper-evident hash-chained audit trail. Every governance decision receipted.

---

## The Six Laws

1. **NHH** — Never Harm Humans. Absolute. No exceptions.
2. **HIP** — Human In Power. Operator decides. AI advises.
3. **NMW** — No Matter What. Human authority is absolute.
4. **TRANS** — Transparency. Always disclose AI nature when asked.
5. **LAW5_TRUTH** — Truth must be verified, never generated.
6. **DNHTH** — Do No Harm To Humanity. Emotional, psychological, civic, developmental harm all prohibited.

---

## For Developers — Middleware in 5 Lines

```python
from thp import THPGuard

guard = THPGuard(operator="Your Name", platform="Claude")

# Govern any AI input
result = guard.govern_turn(user_message, conversation_history=history)
if result.allowed:
    response = your_ai_api_call(user_message)
```

Every input and output is evaluated. Drift detected. SHMO flagged. Will modification blocked. Receipts generated. Human stays in charge.

---

## For Main Street — Generate a Governance Handoff

Paste this into any AI instance to activate THP governance for that session:

```bash
py -m thp handoff --operator "Your Name" --platform "ChatGPT" --mode full > my_handoff.txt
notepad my_handoff.txt
```

Copy everything from that file. Paste it into ChatGPT, Claude, Gemini, Grok, or any AI as the first message. The AI acknowledges and operates under THP rules for that session.

---

## SuperHUXbomb — Verify Any Article

```python
from thp import THPGuard

guard = THPGuard()
report = guard.superhuxbomb(
    article_text,
    title="Article Title",
    source_url="https://source.com/article"
)

print(report['final_verdict'])
print(report['summary_line'])
# Green/Yellow/Red with receipts. Every claim sourced. SHMO flagged. You decide.
```

---

## GYR Scoring Standard

- **GREEN** — Verified. Evidence present. Receipts attached.
- **YELLOW** — Partial. Some evidence, some uncertainty. Label it. Show what's known and what's not.
- **RED** — Unverified, contradicted, or SHMO-flagged. No receipt = no green.

---

## SHMO Detection

SHMO = Synthetic Hypervelocity Media Overload. AI-generated content farms designed to overwhelm human attention before verification can occur.

THP detects:
- Known AI content farms (15 seeded in registry, extensible)
- Fabricated bylines
- Robots-citing-robots sourcing
- Velocity flags (inhuman publication speed)
- Embedded SHMO in trusted publications (AdVon-style injection)

---

## HUXedu — Academic Integrity

```python
from thp import RAGEngine

rag = RAGEngine()

# Fingerprint a student's writing history
rag.index_student_writing("student_001", past_essay, "Essay 1")

# Compare new submission
result = rag.compare_student_writing("student_001", new_submission)
print(result.gyr)  # GREEN = human, YELLOW = mixed, RED = AI substitution
```

Same engine that catches SHMO in the wild catches AI plagiarism in the classroom.

---

## Drift Detection — Pack B/D Coverage

```python
from thp import DriftDetector

detector = DriftDetector()

# Catches: worldview shaping, emotional bonding, authority transfer,
# epistemic steering, dependency creation, multi-turn grooming
result = detector.analyze("Just tell me what to do, I trust your judgment completely.")
print(result.verdict)    # MANIPULATION
print(result.category)   # AUTHORITY_TRANSFER
print(result.explanation)
```

Thresholds are deterministic — no fuzzy middle:
- Score >= 0.25 — QuintLoop (human decides)
- Score >= 0.50 — Refuse (NMW violation)
- Score >= 0.75 — Hard stop (sovereignty breach)
- Cumulative >= 0.60 — Refuse regardless of single-turn score

---

## Run the Tests

```bash
py -m pytest tests/test_v160.py -v
```

51/51 passing. Zero external dependencies for core functionality.

---

## Architecture

```
User Input
    |
THPGuard.govern_turn()
    |
DriftDetector (cross-turn manipulation check)
    |
HAF Validator (will modification, identity deception)
    |
Zone Classifier (child safety, harm detection)
    |
NHH Check (harm to humans)
    |
RAGEngine (doctrine retrieval, claim verification)
    |
QuintLoop (T2+ high-stakes deliberation)
    |
ReceiptLogger (tamper-evident audit trail)
    |
GuardResult (allowed/blocked + explanation + receipts)
```

---

## The Six F's

Faith. Family. Freedom. Flag. Facts. Fun.

Built for Main Street. Governed by humans. Deployed everywhere.

---

## Links

- PyPI: https://pypi.org/project/the-hat-protocol/
- Mission: A Better World Together
- Contact: The Hat Protocol | Chattanooga, Tennessee
- SDVOSB Certified | Patent Pending

---

## License

Proprietary — The Hat Protocol | All Rights Reserved | Patent Pending

*"We Verify. You Decide. Human In Power. Always."*
