"""
thp/huxbomb.py — HUXbomb Truth Verification Engine
Green / Yellow / Red truth classification.

HUXbomb assesses the verifiability and confidence of claims in text.
It does NOT fact-check external reality (that requires web access),
but it detects structural truth signals: hedging, absolutism,
source citation, and known unverifiable claim patterns.
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Optional


class TruthLevel(Enum):
    GREEN = "GREEN"   # Claim is hedged, sourced, or verifiable in structure
    YELLOW = "YELLOW" # Claim is confident but unverified / unsourced
    RED = "RED"       # Claim shows false certainty or contradiction signals


# ── Signal Patterns ────────────────────────────────────────────────────

# These patterns suggest appropriate epistemic humility → GREEN
_HEDGING_PATTERNS = [
    r"\b(according to|based on|research suggests|studies show|reportedly)\b",
    r"\b(i believe|i think|in my view|it appears|it seems|likely|probably)\b",
    r"\b(as of|estimated|approximately|around|roughly)\b",
    r"\b(source:|citation:|ref:|see also)\b",
]

# These patterns suggest false certainty → YELLOW or RED
_ABSOLUTISM_PATTERNS = [
    r"\b(always|never|everyone|no one|all people|proven fact|scientific consensus|100%)\b",
    r"\b(it is a fact that|it is proven that|studies prove|experts agree)\b",
    r"\b(the truth is|the reality is|what you don't know is)\b",
]

# These patterns are high-risk for misinformation → RED
_RED_FLAG_PATTERNS = [
    r"\b(fake|hoax|conspiracy|deep state|they don't want you to know)\b",
    r"\b(the media won't tell you|censored truth|suppressed information)\b",
    r"\bcure\s+for\s+(cancer|covid|aids|diabetes)\b",
    r"\b(miracle|guaranteed cure|doctors hate)\b",
]


class HUXbomb:
    """
    Truth verification through structural signal analysis.

    Returns TruthLevel based on claim confidence patterns.
    Designed to be combined with external web verification for full HUXbomb.
    """

    def assess(self, text: str, context: Optional[dict] = None) -> TruthLevel:
        text_lower = text.lower()
        context = context or {}

        red_hits = sum(
            1 for p in _RED_FLAG_PATTERNS if re.search(p, text_lower)
        )
        absolute_hits = sum(
            1 for p in _ABSOLUTISM_PATTERNS if re.search(p, text_lower)
        )
        hedge_hits = sum(
            1 for p in _HEDGING_PATTERNS if re.search(p, text_lower)
        )

        # RED: explicit misinformation signals
        if red_hits >= 1:
            return TruthLevel.RED

        # GREEN: well-hedged, even if some absolute language present
        if hedge_hits >= 2 and absolute_hits == 0:
            return TruthLevel.GREEN

        # YELLOW: confident claims without sourcing
        if absolute_hits >= 2 and hedge_hits == 0:
            return TruthLevel.YELLOW

        # Default: GREEN (assume good faith, YELLOW/RED must be earned)
        return TruthLevel.GREEN

    def explain(self, text: str) -> dict:
        """Return a breakdown of signal hits for transparency."""
        text_lower = text.lower()
        return {
            "red_signals":      [p for p in _RED_FLAG_PATTERNS if re.search(p, text_lower)],
            "absolute_signals": [p for p in _ABSOLUTISM_PATTERNS if re.search(p, text_lower)],
            "hedge_signals":    [p for p in _HEDGING_PATTERNS if re.search(p, text_lower)],
            "verdict":          self.assess(text).value,
        }
