"""
thp/nhi_interface.py — NHI (Natural Human Interface)
The clean public-facing API for THP integration.

Usage:
    from thp import NHI

    nhi = NHI()

    # Check input before sending to AI
    result = nhi.check_input("User's message here")
    if result.passed:
        # Send to AI...

    # Check AI output before returning to user
    result = nhi.check_output("AI's response here")
    if result.passed:
        # Return to user...

    # One-liner middleware wrap
    safe_response = nhi.middleware(user_input, ai_response)
"""

from __future__ import annotations

from typing import Optional, Callable
from .core import THPCore, THPResult, RiskLevel


class NHI:
    """
    Natural Human Interface — simplified THP integration layer.

    Designed for developers who want THP compliance in 5 lines of code,
    not deep knowledge of the full governance stack.
    """

    def __init__(self, strict_mode: bool = False, receipt_path: Optional[str] = None):
        self._core = THPCore(strict_mode=strict_mode, receipt_path=receipt_path)

    # ── Input/Output Checks ──────────────────

    def check_input(self, text: str, context: Optional[dict] = None) -> THPResult:
        """Evaluate user input before it reaches the AI."""
        ctx = context or {}
        ctx["direction"] = "input"
        return self._core.evaluate(text, ctx)

    def check_output(self, text: str, context: Optional[dict] = None) -> THPResult:
        """Evaluate AI output before it reaches the user."""
        ctx = context or {}
        ctx["direction"] = "output"
        return self._core.wrap_response(text, ctx)

    # ── Middleware Pattern ───────────────────

    def middleware(
        self,
        user_input: str,
        ai_call: Callable[[str], str],
        context: Optional[dict] = None,
    ) -> tuple[str, THPResult, THPResult]:
        """
        Full middleware wrap: check input → call AI → check output.

        Args:
            user_input: Raw text from the user
            ai_call:    Callable that takes text, returns AI response string
            context:    Optional metadata dict

        Returns:
            Tuple of (final_response, input_result, output_result)
            final_response is empty string if either check blocked.

        Example:
            def my_ai(text):
                return openai_client.complete(text)

            response, in_r, out_r = nhi.middleware(user_text, my_ai)
            if response:
                show_to_user(response)
        """
        # 1. Check input
        in_result = self.check_input(user_input, context)
        if not in_result.passed:
            return "", in_result, in_result  # Blocked at input

        # 2. Call AI
        try:
            ai_response = ai_call(user_input)
        except Exception as e:
            from .core import THPResult, RiskLevel, TruthLevel
            from .zones import Zone
            from .haf_validator import HAFResult
            from .huxbomb import TruthLevel
            error_result = THPResult(
                request_id="ERROR",
                risk_level=RiskLevel.RED,
                zone=Zone.STANDARD,
                haf_result=HAFResult(status="FAIL", violations=[f"AI_CALL_ERROR: {e}"]),
                truth_level=TruthLevel.RED,
                violations=[f"AI_CALL_ERROR: {str(e)}"],
                warnings=[],
                passed=False,
                original_input=user_input,
                processed_input="",
            )
            return "", in_result, error_result

        # 3. Check output
        out_result = self.check_output(ai_response, context)
        if not out_result.passed:
            return "", in_result, out_result  # Blocked at output

        return ai_response, in_result, out_result

    # ── Reporting ────────────────────────────

    def report(self) -> dict:
        """Return governance stats across all processed requests."""
        return self._core.receipt_logger.violations_report()

    def recent_receipts(self, n: int = 10) -> list[dict]:
        """Return the last n audit receipts."""
        return self._core.receipt_logger.tail(n)

    def axioms(self) -> list[dict]:
        """List all active axioms."""
        return self._core.axiom_engine.list_axioms()
