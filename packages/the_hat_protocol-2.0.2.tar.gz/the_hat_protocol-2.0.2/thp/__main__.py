"""
thp/__main__.py — CLI for The Hat Protocol
Usage:
    thp evaluate "some text to check"
    thp handoff --operator "Mr. C" --platform Claude --session live_production
    thp report
"""

import argparse
import json
import sys

from . import THPCore, HUXmesh, NHI


def cmd_evaluate(args):
    import tempfile
    nhi = NHI()
    result = nhi.check_input(args.text)
    print(result.summary())
    if args.json:
        print(json.dumps({
            "passed": result.passed,
            "risk_level": result.risk_level.value,
            "zone": result.zone.value,
            "violations": result.violations,
            "warnings": result.warnings,
        }, indent=2))


def cmd_handoff(args):
    mesh = HUXmesh()
    projects = args.projects.split(",") if args.projects else []
    handoff = mesh.generate_handoff(
        operator=args.operator,
        mission=args.mission or "General governed operation",
        platform=args.platform,
        session_type=args.session,
        active_projects=projects,
    )
    if args.json:
        print(handoff.as_json())
    else:
        print(handoff.as_prompt())


def cmd_report(args):
    nhi = NHI()
    report = nhi.report()
    if report:
        print(json.dumps(report, indent=2))
    else:
        print("No receipts found. Run some evaluations first.")


def main():
    parser = argparse.ArgumentParser(
        prog="thp",
        description="The Hat Protocol — AI Governance CLI",
    )
    sub = parser.add_subparsers(dest="command")

    # evaluate
    ev = sub.add_parser("evaluate", help="Evaluate text under THP governance")
    ev.add_argument("text", help="Text to evaluate")
    ev.add_argument("--json", action="store_true", help="Output as JSON")
    ev.set_defaults(func=cmd_evaluate)

    # handoff
    ho = sub.add_parser("handoff", help="Generate a HUXmesh AI instance handoff")
    ho.add_argument("--operator", default="Mr. C", help="Operator name")
    ho.add_argument("--platform", default="Claude", help="Target AI platform")
    ho.add_argument("--session", default="deep_work", help="Session type")
    ho.add_argument("--mission", default="", help="Session mission")
    ho.add_argument("--projects", default="", help="Comma-separated project names")
    ho.add_argument("--json", action="store_true", help="Output as JSON")
    ho.set_defaults(func=cmd_handoff)

    # report
    rp = sub.add_parser("report", help="Show governance stats from receipt log")
    rp.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
