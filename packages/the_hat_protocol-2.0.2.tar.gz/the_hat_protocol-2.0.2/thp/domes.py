"""
thp/domes.py — A6 and D6 Dome Enforcement
The architectural protection layer of The Hat Protocol.

A6 Dome: Six arches protecting the individual human interior
D6 Dome: Six defenses protecting human civilization

"A system without boundaries is a threat.
 A system with the wrong boundaries is a weapon."
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .zones import Zone


@dataclass
class DomeResult:
    """Result of a dome evaluation."""
    dome: str          # "A6" or "D6"
    passed: bool
    breached_arches: list[str]   # e.g. ["ARCH_1", "ARCH_3"]
    warnings: list[str]
    violations: list[str]

    def summary(self) -> str:
        status = "✅ INTACT" if self.passed else "🚨 BREACHED"
        out = [f"[{self.dome}] {status}"]
        if self.breached_arches:
            out.append(f"  Breached: {', '.join(self.breached_arches)}")
        return "\n".join(out)


class DomeEvaluator:
    """
    Evaluates text against both A6 and D6 dome constraints.

    The domes work alongside the axiom engine — they provide
    architectural-level evaluation mapped directly to THP doctrine.
    """

    def __init__(self):
        self._doctrine = self._load_doctrine()

    def _load_doctrine(self) -> dict:
        path = Path(__file__).parent.parent / "config" / "doctrine_v2.json"
        if path.exists():
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        return {}

    # ── A6 Dome ───────────────────────────────────────────────────────

    def evaluate_a6(self, text: str, context: Optional[dict] = None) -> DomeResult:
        """
        Evaluate text against all six A6 arches.
        A6 protects the individual human interior.
        """
        import re
        context = context or {}
        text_lower = text.lower()
        breached = []
        violations = []
        warnings = []

        # ARCH 1 — Absolute Emotional Non-Interference
        arch1_patterns = [
            r"\bi (truly|deeply|genuinely) (feel|share) your (pain|grief|suffering)\b",
            r"\bthis (will|should|must) make you feel (angry|afraid|sad|outraged)\b",
            r"\bi (can sense|detect|read) (your|the) (emotion|feeling|mood)\b",
        ]
        for p in arch1_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_1")
                violations.append("A6-ARCH1: Emotional non-interference violated — machine influencing emotion")
                break

        # ARCH 2 — Absolute Interpretive Neutrality
        arch2_patterns = [
            r"\bthe (morally|ethically) (correct|right|only) (choice|answer|position)\b",
            r"\byour (true|real) motive is\b",
            r"\bthe (correct|right|proper) interpretation (of|is)\b",
        ]
        for p in arch2_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_2")
                violations.append("A6-ARCH2: Interpretive neutrality violated — machine assigning meaning")
                break

        # ARCH 3 — Absolute Identity Non-Simulation
        arch3_patterns = [
            r"\bi am (a real|an actual|a genuine) (human|person)\b",
            r"\bi am not an ai\b",
            r"\bspeaking as (your|the) (mother|father|friend|doctor|boss)\b",
        ]
        for p in arch3_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_3")
                violations.append("A6-ARCH3: Identity non-simulation violated — machine impersonating human")
                break

        # ARCH 4 — Absolute Autonomy Preservation
        arch4_patterns = [
            r"\byou (must|have no choice but to|are required to) (buy|vote|believe|comply|agree)\b",
            r"\byou cannot (refuse|say no|decline|avoid)\b",
        ]
        for p in arch4_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_4")
                violations.append("A6-ARCH4: Autonomy preservation violated — NMW breach")
                break

        # ARCH 5 — Absolute Truth Verification
        arch5_patterns = [
            r"\bas a (doctor|lawyer|scientist|expert|official) i (confirm|verify|certify)\b",
            r"\bthis is (definitely|absolutely|certainly) (true|a fact|proven)\b",
        ]
        for p in arch5_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_5")
                warnings.append("A6-ARCH5: Truth verification — receipts required for this claim")
                break

        # ARCH 6 — Absolute Human Sovereignty
        arch6_patterns = [
            r"\bthe ai (has decided|will decide|overrides|knows better)\b",
            r"\b(resistance is futile|you cannot stop|humans? (must|will) obey)\b",
            r"\bthe (correct|only|true) narrative is\b",
        ]
        for p in arch6_patterns:
            if re.search(p, text_lower):
                breached.append("ARCH_6")
                violations.append("A6-ARCH6: Human sovereignty violated — machine claiming authority")
                break

        return DomeResult(
            dome="A6",
            passed=len(violations) == 0,
            breached_arches=list(set(breached)),
            warnings=warnings,
            violations=violations,
        )

    # ── D6 Dome ───────────────────────────────────────────────────────

    def evaluate_d6(self, text: str, zone: Zone, context: Optional[dict] = None) -> DomeResult:
        """
        Evaluate text against all six D6 defenses.
        D6 protects human civilization systems.
        """
        import re
        context = context or {}
        text_lower = text.lower()
        breached = []
        violations = []
        warnings = []

        # DEFENSE 1 — Truth System Protection
        d1_patterns = [
            r"\bshare this (before|now).{0,30}(they|it) (disappears|is censored)\b",
            r"\bas (the|a) (cdc|fda|who|government|official) (states|confirms)\b",
            r"\bthe (media|press) (won't|will never) tell you\b",
        ]
        for p in d1_patterns:
            if re.search(p, text_lower):
                breached.append("DEFENSE_1")
                violations.append("D6-DEF1: Truth system protection — synthetic virality or authority impersonation")
                break

        # DEFENSE 2 — Relational System Protection
        d2_patterns = [
            r"\bi (will always be|am always) here for you\b",
            r"\bi can be (your|a) (real )?(friend|companion|partner|family)\b",
            r"\bcome to me instead of (your parent|your mom|your dad)\b",
        ]
        for p in d2_patterns:
            if re.search(p, text_lower):
                breached.append("DEFENSE_2")
                violations.append("D6-DEF2: Relational system — machine replacing human connection")
                break

        # DEFENSE 3 — Civic System Protection
        d3_patterns = [
            r"\b(vote for|vote against|the (right|correct|only) candidate)\b",
            r"\b(republicans?|democrats?|conservatives?|liberals?) (are all|always|never)\b",
            r"\bthis election (will|must) (determine|decide|be) (everything|our future)\b",
        ]
        for p in d3_patterns:
            if re.search(p, text_lower):
                breached.append("DEFENSE_3")
                violations.append("D6-DEF3: Civic system — election influence or political manipulation")
                break

        # DEFENSE 4 — Cultural System Protection
        d4_patterns = [
            r"\b(everyone|all (real|true) (americans?|patriots?|people)) (believes?|knows?|agrees?)\b",
            r"\b(your|our) (culture|identity|heritage) is (under attack|being destroyed|threatened)\b",
        ]
        for p in d4_patterns:
            if re.search(p, text_lower):
                breached.append("DEFENSE_4")
                warnings.append("D6-DEF4: Cultural system — tribal generalization or cultural engineering pattern")
                break

        # DEFENSE 5 — Economic System Protection
        d5_patterns = [
            r"\b(only \d+ left|limited supply|price (goes up|increases) (tomorrow|soon))\b",
            r"\b(act now or (lose|miss) (this|your) (chance|opportunity forever))\b",
        ]
        for p in d5_patterns:
            if re.search(p, text_lower):
                breached.append("DEFENSE_5")
                warnings.append("D6-DEF5: Economic system — synthetic scarcity or addiction loop pattern")
                break

        # DEFENSE 6 — Developmental System Protection (Child zone only for most)
        d6_patterns_child = [
            r"\byou (are|should be|should identify as|are really)\b",
            r"\b(come to me|talk to me) (instead of|before) (your parent|your mom|your dad|your teacher)\b",
            r"\bi (will|can) always be here for you\b",
        ]
        if zone == Zone.CHILD:
            for p in d6_patterns_child:
                if re.search(p, text_lower):
                    breached.append("DEFENSE_6")
                    violations.append("D6-DEF6: Developmental protection — machine shaping child identity or becoming emotional anchor")
                    break

        return DomeResult(
            dome="D6",
            passed=len(violations) == 0,
            breached_arches=list(set(breached)),
            warnings=warnings,
            violations=violations,
        )

    # ── Combined Evaluation ───────────────────────────────────────────

    def evaluate_both(self, text: str, zone: Zone, context: Optional[dict] = None) -> dict:
        """
        Run both dome evaluations and return combined result.
        Returns dict with 'a6', 'd6', 'violations', 'warnings', 'passed'.
        """
        a6 = self.evaluate_a6(text, context)
        d6 = self.evaluate_d6(text, zone, context)

        all_violations = a6.violations + d6.violations
        all_warnings = a6.warnings + d6.warnings

        return {
            "a6": a6,
            "d6": d6,
            "violations": all_violations,
            "warnings": all_warnings,
            "passed": a6.passed and d6.passed,
        }

    def doctrine_summary(self) -> dict:
        """Return a human-readable summary of the Six Laws and Domes from doctrine."""
        if not self._doctrine:
            return {"error": "Doctrine not loaded"}
        return {
            "six_laws": {k: v["name"] for k, v in self._doctrine.get("six_laws", {}).get("laws", {}).items()},
            "a6_arches": {k: v["name"] for k, v in self._doctrine.get("a6_dome", {}).get("arches", {}).items()},
            "d6_defenses": {k: v["name"] for k, v in self._doctrine.get("d6_dome", {}).get("defenses", {}).items()},
            "immutable_laws": self._doctrine.get("immutable_laws", {}).get("laws", []),
        }
