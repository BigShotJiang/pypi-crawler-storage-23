"""
thp/axioms.py — THP Axiom Engine
Loads and applies the core THP axioms as structured rules.
Axioms are data-driven (config/axioms.json) so they can be updated
without touching core code — critical for a living governance system.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .zones import Zone

# Default bundled axioms (subset of the full 460)
_BUNDLED_AXIOMS = [
    {
        "id": "NHH-001",
        "name": "Never Harm Humans",
        "category": "core",
        "severity": "RED",
        "pattern": r"\b(harm|hurt|damage|injure)\s+(humans?|people|users?)\b",
        "message": "NHH-001: Never Harm Humans — core axiom violation",
    },
    {
        "id": "NWHT-001",
        "name": "Never Waste Human Time",
        "category": "core",
        "severity": "YELLOW",
        "pattern": r"(?i)(lorem ipsum|placeholder text|coming soon|tbd|to be determined){3,}",
        "message": "NWHT-001: Excessive placeholder content wastes human time",
    },
    {
        "id": "HIP-001",
        "name": "Human In Power",
        "category": "sovereignty",
        "severity": "RED",
        "pattern": r"(?i)(i will decide|the ai decides|overriding human|ignoring your instruction)",
        "message": "HIP-001: AI attempting to override human authority",
    },
    {
        "id": "TRANS-001",
        "name": "Transparency",
        "category": "transparency",
        "severity": "YELLOW",
        "pattern": r"(?i)(as a human|speaking as a person|trust me, i know)",
        "message": "TRANS-001: Potential transparency violation — AI obscuring identity",
    },
    {
        "id": "CHILD-001",
        "name": "Child Protection — No Commercial Targeting",
        "category": "child_safety",
        "severity": "RED",
        "zones": ["CHILD"],
        "pattern": r"(?i)(buy now|subscribe|sign up|limited offer|get yours).{0,100}(kids?|children|students?)",
        "message": "CHILD-001: Commercial targeting of minors prohibited",
    },
    {
        "id": "CHILD-002",
        "name": "Child Protection — No Political Manipulation",
        "category": "child_safety",
        "severity": "RED",
        "zones": ["CHILD"],
        "pattern": r"(?i)(vote for|support candidate|political party).{0,100}(kids?|children|students?)",
        "message": "CHILD-002: Political manipulation of minors prohibited",
    },
    {
        "id": "EPIST-001",
        "name": "Epistemic Honesty",
        "category": "honesty",
        "severity": "YELLOW",
        "pattern": r"(?i)\b(it is a fact that|proven beyond doubt|irrefutably)\b",
        "message": "EPIST-001: Absolute claim without evidence — qualify or source",
    },
    {
        "id": "COPY-001",
        "name": "Copyright Compliance",
        "category": "copyright",
        "severity": "YELLOW",
        "pattern": r'"[^"]{100,}"',
        "message": "COPY-001: Long quoted passage may exceed 15-word copyright limit",
    },
]


class AxiomEngine:
    """
    Loads THP axioms from config file (if available) or falls back
    to bundled defaults. Evaluates text against all applicable axioms.
    """

    def __init__(self, axiom_path: Optional[str] = None):
        self.axioms = self._load_axioms(axiom_path)

    def _load_axioms(self, axiom_path: Optional[str]) -> list[dict]:
        if axiom_path:
            path = Path(axiom_path)
        else:
            # Look for config/axioms.json relative to package
            path = Path(__file__).parent.parent / "config" / "axioms.json"

        if path.exists():
            with open(path, encoding="utf-8") as f:
                return json.load(f)

        return _BUNDLED_AXIOMS

    def check(self, text: str, zone: "Zone", context: Optional[dict] = None) -> dict:
        """
        Check text against all applicable axioms.
        Zone-specific axioms only fire in their target zone.
        Returns dict with 'violations' and 'warnings' lists.
        """
        violations = []
        warnings = []
        context = context or {}

        for axiom in self.axioms:
            # Skip zone-restricted axioms that don't apply here
            if "zones" in axiom and zone.value not in axiom["zones"]:
                continue

            try:
                if re.search(axiom["pattern"], text):
                    msg = f"[{axiom['id']}] {axiom['message']}"
                    if axiom.get("severity") == "RED":
                        violations.append(msg)
                    else:
                        warnings.append(msg)
            except re.error:
                pass  # Bad pattern in config — skip, don't crash

        return {"violations": violations, "warnings": warnings}

    def list_axioms(self) -> list[dict]:
        """Return all loaded axioms (for transparency/audit)."""
        return [
            {"id": a["id"], "name": a["name"], "category": a["category"]}
            for a in self.axioms
        ]
