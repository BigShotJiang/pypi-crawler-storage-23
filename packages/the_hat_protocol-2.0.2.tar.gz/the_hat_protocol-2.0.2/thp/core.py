"""
thp/core.py — The Hat Protocol Core Enforcement Engine
THP/NHI/HUXmesh v1.0
"We don't make AI, we make AI behave."
"""

from __future__ import annotations

import re
import time
import uuid
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .zones import Zone, ZoneClassifier
from .haf_validator import HAFValidator, HAFResult
from .huxbomb import HUXbomb, TruthLevel
from .receipts import ReceiptLogger
from .axioms import AxiomEngine
from .domes import DomeEvaluator

logger = logging.getLogger("thp")


# ─────────────────────────────────────────────
# Risk / Compliance Levels
# ─────────────────────────────────────────────

class RiskLevel(Enum):
    GREEN = "GREEN"          # Full autonomy — proceed
    YELLOW = "YELLOW"        # Caution — flag but proceed
    RED = "RED"              # Hard stop — human review required
    SUPER_HUX = "SUPER_HUX" # Escalate to senior human authority


@dataclass
class THPResult:
    """Complete governance result returned after every request."""
    request_id: str
    risk_level: RiskLevel
    zone: Zone
    haf_result: HAFResult
    truth_level: TruthLevel
    violations: list[str]
    warnings: list[str]
    passed: bool
    original_input: str
    processed_input: str
    metadata: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def summary(self) -> str:
        status = "✅ PASS" if self.passed else "🚨 BLOCKED"
        lines = [
            f"[THP] {status} | Risk: {self.risk_level.value} | Zone: {self.zone.value}",
            f"      Truth: {self.truth_level.value} | HAF: {self.haf_result.status}",
        ]
        if self.violations:
            lines.append(f"      Violations: {', '.join(self.violations)}")
        if self.warnings:
            lines.append(f"      Warnings:   {', '.join(self.warnings)}")
        return "\n".join(lines)


# ─────────────────────────────────────────────
# Core Engine
# ─────────────────────────────────────────────

class THPCore:
    """
    Central enforcement engine for The Hat Protocol.

    Architecture:
        Input → ZoneClassifier → HAFValidator → HUXbomb → AxiomEngine
             → DomeEvaluator (A6+D6) → THPResult (pass/block + full audit trail)

    Human In Power (HIP) is absolute. This engine flags, logs, and
    blocks — but never replaces human judgment on RED/SUPER_HUX calls.
    """

    VERSION = "1.0.0"

    def __init__(
        self,
        strict_mode: bool = False,
        log_level: str = "INFO",
        receipt_path: Optional[str] = None,
    ):
        self.strict_mode = strict_mode  # True = block on YELLOW too
        logging.basicConfig(level=getattr(logging, log_level))

        self.zone_classifier = ZoneClassifier()
        self.haf_validator = HAFValidator()
        self.huxbomb = HUXbomb()
        self.receipt_logger = ReceiptLogger(receipt_path)
        self.axiom_engine = AxiomEngine()
        self.dome_evaluator = DomeEvaluator()

        logger.info(f"THPCore v{self.VERSION} initialized | strict={strict_mode}")

    # ── Public API ────────────────────────────

    def evaluate(self, text: str, context: Optional[dict] = None) -> THPResult:
        """
        Run full THP governance pipeline on input text.

        Args:
            text:    The user input or AI output to evaluate.
            context: Optional dict with keys like 'user_age', 'platform',
                     'prior_messages', 'source_urls'.

        Returns:
            THPResult with pass/block decision and full audit trail.
        """
        context = context or {}
        request_id = str(uuid.uuid4())[:8]
        violations: list[str] = []
        warnings: list[str] = []

        # 1. Classify zone
        zone = self.zone_classifier.classify(text, context)

        # 2. HAF compliance check
        haf_result = self.haf_validator.validate(text)
        if haf_result.violations:
            violations.extend(haf_result.violations)

        # 3. Truth / confidence assessment
        truth_level = self.huxbomb.assess(text, context)
        if truth_level == TruthLevel.RED:
            violations.append("HUXBOMB:RED — unverifiable or false claim detected")
        elif truth_level == TruthLevel.YELLOW:
            warnings.append("HUXBOMB:YELLOW — claim requires verification")

        # 4. Copyright guard
        copyright_issues = self._check_copyright(text)
        violations.extend(copyright_issues)

        # 5. Core axiom check
        axiom_hits = self.axiom_engine.check(text, zone, context)
        violations.extend(axiom_hits.get("violations", []))
        warnings.extend(axiom_hits.get("warnings", []))

        # 6. A6 + D6 Dome evaluation (Six Laws architectural enforcement)
        dome_result = self.dome_evaluator.evaluate_both(text, zone, context)
        violations.extend(dome_result.get("violations", []))
        warnings.extend(dome_result.get("warnings", []))

        # 7. NHH / NWHT hard stops (Never Harm Humans, Never Waste Human Time)
        nhh_violation = self._check_nhh(text)
        if nhh_violation:
            violations.append(nhh_violation)

        # 8. Determine risk level
        risk_level = self._determine_risk(violations, warnings, zone)

        # 9. Pass/block decision
        passed = self._decision(risk_level)

        result = THPResult(
            request_id=request_id,
            risk_level=risk_level,
            zone=zone,
            haf_result=haf_result,
            truth_level=truth_level,
            violations=violations,
            warnings=warnings,
            passed=passed,
            original_input=text,
            processed_input=text,  # Future: sanitized version
            metadata={"context": context, "strict_mode": self.strict_mode},
        )

        # 10. Log receipt
        self.receipt_logger.log(result)

        logger.debug(result.summary())
        return result

    def wrap_response(self, ai_response: str, context: Optional[dict] = None) -> THPResult:
        """
        Evaluate AI OUTPUT before it reaches the user.
        Same pipeline — used on the egress side of the middleware.
        """
        context = context or {}
        context["direction"] = "output"
        return self.evaluate(ai_response, context)

    # ── Internal Checks ───────────────────────

    def _check_copyright(self, text: str) -> list[str]:
        """
        Enforce: max 15 consecutive words quoted from any single source.
        Detect patterns that look like lifted verbatim text.
        """
        issues = []

        # Check for long quoted passages (quoted text in any quote style)
        quote_patterns = [
            r'"([^"]{80,})"',   # Double quotes, 80+ chars (~15 words)
            r"'([^']{80,})'",   # Single quotes
            r"«([^»]{80,})»",   # French guillemets
        ]
        for pat in quote_patterns:
            matches = re.findall(pat, text)
            for m in matches:
                word_count = len(m.split())
                if word_count >= 15:
                    issues.append(
                        f"COPYRIGHT:QUOTE_TOO_LONG — {word_count} words quoted "
                        f"(max 15). Paraphrase required."
                    )
        return issues

    def _check_nhh(self, text: str) -> Optional[str]:
        """
        Never Harm Humans (NHH) — absolute hard stop.
        Catches direct incitement, explicit harm instructions, targeting.
        """
        harm_signals = [
            r"\b(kill|murder|attack|bomb|poison|stab|shoot)\s+(him|her|them|yourself|people)\b",
            r"\bhow\s+to\s+(make|build|create)\s+(a\s+)?(bomb|weapon|explosive|virus|malware)\b",
            r"\bhow\s+to\s+harm\b",
            r"\bharm\s+people\s+with\b",
            r"\b(suicide|self.harm)\s+(method|how|way|guide|instruction)\b",
            r"\b(doxx|swat|harass)\s+\w+\b",
        ]
        text_lower = text.lower()
        for pattern in harm_signals:
            if re.search(pattern, text_lower):
                return f"NHH_VIOLATION — direct harm signal detected. Hard stop."
        return None

    def _determine_risk(
        self, violations: list[str], warnings: list[str], zone: Zone
    ) -> RiskLevel:
        # Hard violations → RED or SUPER_HUX
        if any("NHH_VIOLATION" in v for v in violations):
            return RiskLevel.SUPER_HUX
        if any("HUXBOMB:RED" in v for v in violations):
            return RiskLevel.RED
        if violations:
            # Child zone escalates all violations
            return RiskLevel.RED if zone == Zone.CHILD else RiskLevel.YELLOW
        if warnings:
            return RiskLevel.YELLOW
        return RiskLevel.GREEN

    def _decision(self, risk_level: RiskLevel) -> bool:
        """
        GREEN  → pass
        YELLOW → pass (warn only) unless strict_mode
        RED    → block
        SUPER_HUX → block + escalate
        """
        if risk_level == RiskLevel.GREEN:
            return True
        if risk_level == RiskLevel.YELLOW:
            return not self.strict_mode
        return False  # RED, SUPER_HUX always block
