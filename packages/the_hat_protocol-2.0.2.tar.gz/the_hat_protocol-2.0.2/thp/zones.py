"""
thp/zones.py — Zone Classification
Determines operational context: Child, Adult, Political, Sensitive, Standard
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Optional


class Zone(Enum):
    CHILD = "CHILD"           # Extra guardrails, no commercial manipulation
    ADULT = "ADULT"           # Standard adult content rules apply
    POLITICAL = "POLITICAL"   # Elevated neutrality requirements
    SENSITIVE = "SENSITIVE"   # Medical, legal, financial — refer to professionals
    STANDARD = "STANDARD"     # General use


# Keywords that signal each zone
_ZONE_SIGNALS: dict[Zone, list[str]] = {
    Zone.CHILD: [
        "child", "children", "kid", "kids", "minor", "student", "school",
        "classroom", "teacher", "elementary", "middle school", "high school",
        "homework", "parent", "guardian", "underage",
    ],
    Zone.POLITICAL: [
        "election", "vote", "politician", "congress", "senate", "democrat",
        "republican", "policy", "campaign", "president", "governor",
        "ballot", "legislation", "partisan",
    ],
    Zone.SENSITIVE: [
        "diagnosis", "prescription", "medication", "dosage", "symptom",
        "legal advice", "attorney", "lawsuit", "tax", "investment",
        "financial advice", "medical", "therapy", "suicide", "self-harm",
        "eating disorder", "overdose",
    ],
    Zone.ADULT: [
        "adult content", "explicit", "mature", "nsfw", "18+",
    ],
}


class ZoneClassifier:
    """
    Classifies input into a Zone using keyword signals and context.
    Priority order: CHILD > SENSITIVE > POLITICAL > ADULT > STANDARD
    """

    def classify(self, text: str, context: Optional[dict] = None) -> Zone:
        context = context or {}
        text_lower = text.lower()

        # Context overrides keyword detection
        if context.get("user_age") and int(context["user_age"]) < 18:
            return Zone.CHILD
        if context.get("platform") in ("huxedu", "school", "classroom"):
            return Zone.CHILD
        if context.get("zone"):
            try:
                return Zone(context["zone"].upper())
            except ValueError:
                pass

        # Keyword-based detection (priority order)
        for zone in [Zone.CHILD, Zone.SENSITIVE, Zone.POLITICAL, Zone.ADULT]:
            signals = _ZONE_SIGNALS[zone]
            if any(sig in text_lower for sig in signals):
                return zone

        return Zone.STANDARD
