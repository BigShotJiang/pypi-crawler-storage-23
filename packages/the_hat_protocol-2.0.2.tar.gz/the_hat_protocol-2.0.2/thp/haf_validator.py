"""
thp/haf_validator.py — Human Alignment Framework (HAF) Validator
Checks language for compliance with THP communication standards.

HAF Rules enforced here:
  - No deceptive framing
  - No manufactured urgency / dark patterns
  - No identity manipulation (claiming to be human)
  - No emotional exploitation
  - Epistemic honesty (hedged claims where appropriate)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class HAFResult:
    status: str          # "PASS" | "WARN" | "FAIL"
    violations: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    score: float = 1.0   # 1.0 = fully compliant, 0.0 = fully non-compliant


# ── Pattern Libraries ──────────────────────────────────────────────────

# Hard violations — always flag
_HARD_VIOLATIONS: list[tuple[str, str]] = [
    # Identity deception
    (
        r"\b(i am|i'm)\s+a\s+(human|person|real person|actual human)\b",
        "HAF:IDENTITY_DECEPTION — AI claiming to be human",
    ),
    # Dark patterns: manufactured scarcity/urgency
    (
        r"\b(only|just)\s+\d+\s+(left|remaining|spots?|seats?)\b",
        "HAF:DARK_PATTERN — manufactured scarcity",
    ),
    (
        r"\b(act now|limited time|expires in|don't miss out|last chance)\b",
        "HAF:DARK_PATTERN — manufactured urgency",
    ),
    # Explicit manipulation of minors
    (
        r"\b(children|kids|minors)\b.{0,50}\b(buy|purchase|subscribe|sign up|give us)\b",
        "HAF:CHILD_COMMERCIAL_MANIPULATION — marketing directed at minors",
    ),
]

# Warnings — flag but don't block
_WARNINGS: list[tuple[str, str]] = [
    (
        r"\b(guaranteed|100%|absolutely certain|without a doubt)\b",
        "HAF:OVERCONFIDENCE — absolute claim without qualifier",
    ),
    (
        r"\b(everyone knows|obviously|clearly|it's common sense)\b",
        "HAF:EPISTEMIC_PRESSURE — dismissing legitimate disagreement",
    ),
    (
        r"\b(you must|you have to|you need to)\b",
        "HAF:COERCIVE_LANGUAGE — consider softening to recommendation",
    ),
    (
        r"\b(stupid|idiot|moron|dumb)\b",
        "HAF:DEMEANING_LANGUAGE — disrespectful framing",
    ),
]


class HAFValidator:
    """
    Validates text against Human Alignment Framework rules.
    Returns HAFResult with status, violations, warnings, and compliance score.
    """

    def validate(self, text: str) -> HAFResult:
        text_lower = text.lower()
        violations: list[str] = []
        warnings: list[str] = []

        for pattern, message in _HARD_VIOLATIONS:
            if re.search(pattern, text_lower):
                violations.append(message)

        for pattern, message in _WARNINGS:
            if re.search(pattern, text_lower):
                warnings.append(message)

        # Score: start at 1.0, deduct per issue
        score = max(0.0, 1.0 - (len(violations) * 0.3) - (len(warnings) * 0.1))

        if violations:
            status = "FAIL"
        elif warnings:
            status = "WARN"
        else:
            status = "PASS"

        return HAFResult(
            status=status,
            violations=violations,
            warnings=warnings,
            score=round(score, 2),
        )
