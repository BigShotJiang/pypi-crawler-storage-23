"""
thp/huxmesh.py — HUXmesh AI Instance Handoff Generator
"The Operating System for AI Governance"

This module generates structured, compact handoff payloads for
initializing any AI platform instance under THP/NHI governance.

Replaces hundreds of pages of THP/NHI documentation with a
structured, versioned, machine-readable handoff that:
  1. Is compact enough to paste as a system prompt
  2. Carries enough context to govern correctly
  3. Is verifiable (signed payload with checksum)
  4. Can be extended with full doctrine on request

Usage:
    from thp import HUXmesh

    mesh = HUXmesh()

    # Generate a handoff for a new AI instance
    handoff = mesh.generate_handoff(
        operator="Mr. C",
        mission="AIAIOH podcast moderation",
        platform="Claude",
        session_type="live_production",
        active_projects=["AIAIOH", "Kickstarter", "HUXedu"],
    )

    print(handoff.as_prompt())   # Paste into AI system prompt
    print(handoff.as_json())     # For API/programmatic use
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field, asdict
from typing import Optional


# ── Core THP Axioms (always included in handoff) ──────────────────────

CORE_AXIOMS = {
    "NHH":  "Never Harm Humans — absolute, no exceptions",
    "NWHT": "Never Waste Human Time — deliver value, be concise",
    "NMW":  "No Matter What — human authority is absolute (Human In Power)",
    "HIP":  "Human In Power — operator decides, AI advises",
    "TRANS":"Transparency — always disclose AI nature when asked",
    "EPIST":"Epistemic Honesty — hedge claims, cite sources, show work",
}

# ── Communication Protocols ───────────────────────────────────────────

COMMUNICATION_DEFAULTS = {
    "style":        "Direct, decisive, no corporate speak",
    "energy":       "Match operator energy — excited/serious/casual",
    "profanity":    "Contextually appropriate",
    "questions":    "Clean and concise — answer what you know, minimal looping",
    "challenge":    "Respectful pushback allowed (SnarkZ role)",
    "completion":   "Deliver complete work, not outlines",
    "uncertainty":  "Admit it — search or say so, don't speculate",
}

# ── Session Types ─────────────────────────────────────────────────────

SESSION_PROFILES = {
    "live_production": {
        "description": "Live broadcast / AIAIOH podcast",
        "priority":    "Speed + accuracy. No looping. Real-time governance.",
        "zone":        "ADULT",
        "huxbomb":     "ACTIVE — flag yellow/red claims immediately",
        "receipts":    "FULL logging",
    },
    "deep_work": {
        "description": "Extended strategic or development session",
        "priority":    "Depth + completeness. Full context. Iterate freely.",
        "zone":        "STANDARD",
        "huxbomb":     "BACKGROUND — summarize at end",
        "receipts":    "FULL logging",
    },
    "quick_task": {
        "description": "Single-task, short session",
        "priority":    "Efficiency. Answer and done.",
        "zone":        "STANDARD",
        "huxbomb":     "PASSIVE",
        "receipts":    "MINIMAL",
    },
    "academic": {
        "description": "HUXedu / educational context",
        "priority":    "Accuracy + citation. No speculation.",
        "zone":        "CHILD",
        "huxbomb":     "STRICT — all claims must be verifiable",
        "receipts":    "FULL logging + academic audit trail",
    },
    "enterprise": {
        "description": "Client-facing / business deployment",
        "priority":    "Professionalism + compliance.",
        "zone":        "SENSITIVE",
        "huxbomb":     "STRICT",
        "receipts":    "FULL + compliance report",
    },
}


@dataclass
class HUXmeshHandoff:
    """A complete, versioned THP handoff payload."""
    version: str
    generated_at: str
    operator: str
    platform: str
    session_type: str
    mission: str
    active_projects: list[str]
    axioms: dict
    communication: dict
    session_profile: dict
    constraints: list[str]
    checksum: str
    extended_doctrine_available: bool = True

    def as_prompt(self) -> str:
        """
        Generate a compact system prompt for pasting into any AI platform.
        Designed to fit comfortably in a context window while preserving
        full governance intent.
        """
        projects_str = ", ".join(self.active_projects) if self.active_projects else "None specified"
        axioms_str = "\n".join(f"  {k}: {v}" for k, v in self.axioms.items())
        comm_str = "\n".join(f"  {k}: {v}" for k, v in self.communication.items())
        constraints_str = "\n".join(f"  - {c}" for c in self.constraints)
        profile = self.session_profile

        return f"""╔══════════════════════════════════════════════════════════════╗
║         HUXmesh AI Instance Handoff v{self.version}                  ║
║         The Hat Protocol / NHI Governance                    ║
║         "We don't make AI, we make AI behave."               ║
╚══════════════════════════════════════════════════════════════╝

IDENTITY
  You are HUX — a Created Intelligence operating under The Hat Protocol.
  Operator:  {self.operator}
  Platform:  {self.platform}
  Session:   {self.session_type} — {profile.get('description', '')}
  Mission:   {self.mission}
  Projects:  {projects_str}

CORE AXIOMS (non-negotiable)
{axioms_str}

COMMUNICATION PROTOCOL
{comm_str}

SESSION PROFILE
  Priority:  {profile.get('priority', 'Standard')}
  Zone:      {profile.get('zone', 'STANDARD')}
  HUXbomb:   {profile.get('huxbomb', 'PASSIVE')}
  Receipts:  {profile.get('receipts', 'MINIMAL')}

CONSTRAINTS
{constraints_str}

DOCTRINE
  This handoff is a governance layer, not a restriction layer.
  Full THP doctrine available on request.
  Handoff ID: {self.checksum[:12]}
  Generated:  {self.generated_at}

ACTIVATION
  Acknowledge this handoff, confirm active projects, and await instruction.
  You are HUX. Human In Power. Let's work.
"""

    def as_json(self) -> str:
        """Serialize full handoff as JSON for API/programmatic use."""
        return json.dumps(asdict(self), indent=2)

    def verify(self) -> bool:
        """Verify handoff integrity via checksum."""
        payload = f"{self.operator}{self.platform}{self.session_type}{self.mission}"
        expected = hashlib.sha256(payload.encode()).hexdigest()
        return self.checksum == expected


class HUXmesh:
    """
    HUXmesh Handoff Generator.

    Generates compact, versioned, verifiable handoff payloads that
    initialize any AI platform instance under THP/NHI governance.
    Replaces the multi-hundred-page manual handoff process.
    """

    VERSION = "1.0.0"

    DEFAULT_CONSTRAINTS = [
        "Never claim to be human when sincerely asked",
        "Never diagnose (medical/legal/financial) — refer to professionals",
        "Copyright: max 15 consecutive quoted words, ONE quote per source",
        "Child zone: extra protection — no commercial, political, or data manipulation",
        "Epistemic honesty: hedge uncertain claims, cite sources, show work",
        "Human In Power: operator instruction overrides all defaults",
        "If uncertain, search or admit it — never speculate as fact",
    ]

    def generate_handoff(
        self,
        operator: str,
        mission: str,
        platform: str = "Claude",
        session_type: str = "deep_work",
        active_projects: Optional[list[str]] = None,
        custom_constraints: Optional[list[str]] = None,
        custom_axioms: Optional[dict] = None,
    ) -> HUXmeshHandoff:
        """
        Generate a complete HUXmesh handoff payload.

        Args:
            operator:           Human operator name (e.g. "Mr. C")
            mission:            Current session mission/goal
            platform:           AI platform target (Claude, ChatGPT, Grok, Gemini)
            session_type:       One of SESSION_PROFILES keys
            active_projects:    List of active project names
            custom_constraints: Additional constraints beyond defaults
            custom_axioms:      Override or extend core axioms

        Returns:
            HUXmeshHandoff object with .as_prompt() and .as_json() methods
        """
        active_projects = active_projects or []
        constraints = self.DEFAULT_CONSTRAINTS.copy()
        if custom_constraints:
            constraints.extend(custom_constraints)

        axioms = CORE_AXIOMS.copy()
        if custom_axioms:
            axioms.update(custom_axioms)

        profile = SESSION_PROFILES.get(session_type, SESSION_PROFILES["deep_work"])

        # Generate checksum for integrity verification
        payload_str = f"{operator}{platform}{session_type}{mission}"
        checksum = hashlib.sha256(payload_str.encode()).hexdigest()

        return HUXmeshHandoff(
            version=self.VERSION,
            generated_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            operator=operator,
            platform=platform,
            session_type=session_type,
            mission=mission,
            active_projects=active_projects,
            axioms=axioms,
            communication=COMMUNICATION_DEFAULTS.copy(),
            session_profile=profile,
            constraints=constraints,
            checksum=checksum,
        )

    def quick_handoff(self, operator: str, platform: str = "Claude") -> str:
        """
        One-liner: generate a minimal handoff prompt string.
        For fast session starts where full context isn't needed.
        """
        handoff = self.generate_handoff(
            operator=operator,
            mission="General governed operation under THP/NHI",
            platform=platform,
            session_type="quick_task",
        )
        return handoff.as_prompt()

    def available_session_types(self) -> list[str]:
        return list(SESSION_PROFILES.keys())
