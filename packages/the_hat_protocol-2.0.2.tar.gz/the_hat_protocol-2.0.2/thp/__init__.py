"""
The Hat Protocol (THP) — AI Governance Middleware
"We don't make AI, we make AI behave."

Core imports:
    from thp import THPCore      # Full engine
    from thp import NHI          # Simplified interface
    from thp import RiskLevel    # GREEN/YELLOW/RED/SUPER_HUX
    from thp import Zone         # CHILD/ADULT/POLITICAL/SENSITIVE/STANDARD
"""

from .core import THPCore, THPResult, RiskLevel
from .nhi_interface import NHI
from .zones import Zone
from .huxbomb import HUXbomb, TruthLevel
from .haf_validator import HAFValidator, HAFResult
from .receipts import ReceiptLogger
from .axioms import AxiomEngine
from .huxmesh import HUXmesh, HUXmeshHandoff
from .domes import DomeEvaluator, DomeResult
from .quintloop import QuintLoop, QuintLoopDecision, ElementVerdict

__version__ = "1.2.0"
__author__ = "The Hat Protocol / Mr. C — SDVOSB"
__all__ = [
    "THPCore", "THPResult", "RiskLevel",
    "NHI",
    "Zone",
    "HUXbomb", "TruthLevel",
    "HAFValidator", "HAFResult",
    "ReceiptLogger",
    "AxiomEngine",
    "HUXmesh", "HUXmeshHandoff",
    "DomeEvaluator", "DomeResult",
    "QuintLoop", "QuintLoopDecision", "ElementVerdict",
]
