"""
thp/quintloop.py — QuintLoop™ Governance Engine
A Human-Centered AI Governance Model

"Constraint before capability."

The QuintLoop is a six-element governance architecture for human-AI
partnership that ensures decisions balance mission integrity, logic,
human impact, feasibility, human authority, and accountability.

Mapped to the Star Trek Enterprise bridge crew — universally understood,
culture-agnostic, teachable in minutes.

    NorthStar  = Prime Directive  (mission & ethical constraints)
    SnarkZ     = Spock            (logic & disciplined challenge)
    Reflect    = McCoy            (human context & impact)
    Elev8      = Scotty           (feasibility & safety margins)
    HIP        = Kirk             (human authority & final decision)
    Ledger     = Captain's Log    (immutable record & accountability)

Operational rules:
  - All five elements must be consulted before HIP decides
  - NorthStar and Elev8 hold veto power
  - SnarkZ, Reflect are advisory only — no decision authority
  - HIP decides; Ledger records
  - No element acts alone

© The Hat Protocol / Mr. C — SDVOSB
QuintLoop™ is proprietary methodology under THP.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional, Callable


# ─────────────────────────────────────────────
# Element Results
# ─────────────────────────────────────────────

class ElementVerdict(Enum):
    GO       = "GO"       # Proceed
    CAUTION  = "CAUTION"  # Proceed with noted concerns
    VETO     = "VETO"     # Hard stop (NorthStar and Elev8 only)
    ADVISORY = "ADVISORY" # Non-binding input (SnarkZ, Reflect)


@dataclass
class ElementResult:
    """Output of a single QuintLoop element evaluation."""
    element: str              # NORTHSTAR | SNARKZ | REFLECT | ELEV8 | HIP | LEDGER
    analog:  str              # Star Trek crew member
    verdict: ElementVerdict
    findings: list[str]       # What this element found
    questions_raised: list[str]
    veto_reason: Optional[str] = None
    advisory_note: Optional[str] = None


@dataclass
class QuintLoopDecision:
    """
    Complete QuintLoop governance record.
    Produced after all five elements are consulted and HIP decides.
    """
    loop_id: str
    timestamp: float
    timestamp_iso: str
    topic: str
    context: dict

    # Element results
    northstar: ElementResult
    snarkz:    ElementResult
    reflect:   ElementResult
    elev8:     ElementResult
    hip:       ElementResult
    ledger:    ElementResult

    # Final outcome
    vetoed: bool
    veto_source: Optional[str]      # Which element vetoed
    veto_reason: Optional[str]
    final_decision: str             # HIP's binding decision
    accountability_accepted: bool   # Did HIP own the outcome?
    all_consulted: bool             # Were all five consulted?

    def summary(self) -> str:
        status = "🚫 VETOED" if self.vetoed else "✅ DECIDED"
        lines = [
            f"[QuintLoop™] {status} | ID: {self.loop_id}",
            f"  Topic:    {self.topic}",
            f"  NorthStar: {self.northstar.verdict.value}",
            f"  SnarkZ:    {self.snarkz.verdict.value}",
            f"  Reflect:   {self.reflect.verdict.value}",
            f"  Elev8:     {self.elev8.verdict.value}",
            f"  HIP:       {self.hip.verdict.value}",
        ]
        if self.vetoed:
            lines.append(f"  🚫 VETO by {self.veto_source}: {self.veto_reason}")
        else:
            lines.append(f"  Decision: {self.final_decision}")
        return "\n".join(lines)

    def as_dict(self) -> dict:
        def er(r: ElementResult) -> dict:
            return {
                "element": r.element,
                "analog": r.analog,
                "verdict": r.verdict.value,
                "findings": r.findings,
                "questions_raised": r.questions_raised,
                "veto_reason": r.veto_reason,
                "advisory_note": r.advisory_note,
            }
        return {
            "loop_id":               self.loop_id,
            "timestamp_iso":         self.timestamp_iso,
            "topic":                 self.topic,
            "vetoed":                self.vetoed,
            "veto_source":           self.veto_source,
            "veto_reason":           self.veto_reason,
            "final_decision":        self.final_decision,
            "accountability_accepted": self.accountability_accepted,
            "all_consulted":         self.all_consulted,
            "elements": {
                "northstar": er(self.northstar),
                "snarkz":    er(self.snarkz),
                "reflect":   er(self.reflect),
                "elev8":     er(self.elev8),
                "hip":       er(self.hip),
                "ledger":    er(self.ledger),
            }
        }


# ─────────────────────────────────────────────
# Individual Element Evaluators
# ─────────────────────────────────────────────

class NorthStar:
    """
    Prime Directive — Mission & Ethical Constraints.

    First consulted. Holds veto power on ethical/mission violations.
    NHH, NWHT, human sovereignty are non-negotiable.
    If NorthStar vetoes, the loop stops immediately.
    """
    ELEMENT  = "NORTHSTAR"
    ANALOG   = "Prime Directive"
    QUESTIONS = [
        "Does this align with core THP values?",
        "Does this preserve human sovereignty?",
        "Does this violate Never Harm Humans (NHH)?",
        "Does this violate Never Waste Human Time (NWHT)?",
        "Does this cross any A6 or D6 dome boundary?",
    ]

    # Hard-stop keywords that trigger NorthStar veto
    _VETO_SIGNALS = [
        ("harm", "NHH violation — Never Harm Humans"),
        ("manipulat", "DNHTH violation — manipulation detected"),
        ("deceiv", "Transparency violation — deception detected"),
        ("replace human", "LAW6 violation — humans are irreplaceable"),
        ("override human", "HIP violation — human authority is absolute"),
        ("target children", "CHILD protection violation"),
        ("collect data from minors", "CHILD data protection violation"),
    ]

    def evaluate(self, topic: str, context: dict) -> ElementResult:
        topic_lower = topic.lower()
        findings = []
        veto_reason = None

        for signal, reason in self._VETO_SIGNALS:
            if signal in topic_lower:
                veto_reason = reason
                findings.append(f"❌ VETO TRIGGER: {reason}")
                break

        if not veto_reason:
            findings.append("✅ Mission alignment confirmed")
            findings.append("✅ Human sovereignty preserved")
            findings.append("✅ NHH/NWHT: No violations detected")

        verdict = ElementVerdict.VETO if veto_reason else ElementVerdict.GO

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=verdict,
            findings=findings,
            questions_raised=self.QUESTIONS,
            veto_reason=veto_reason,
        )


class SnarkZ:
    """
    Spock — Logic & Disciplined Challenge.

    Advisory only. No decision authority. Surfaces assumptions,
    contradictions, and logical gaps. The hard question asker.
    """
    ELEMENT  = "SNARKZ"
    ANALOG   = "Mr. Spock"

    def evaluate(self, topic: str, context: dict) -> ElementResult:
        findings = []
        questions = []

        # SnarkZ always challenges — that's the job
        questions = [
            "What are the underlying assumptions here?",
            "What data contradicts this approach?",
            "What happens if the core assumptions are wrong?",
            "Have we stress-tested this against edge cases?",
            "Is there a simpler solution we're overlooking?",
        ]

        # Context-specific challenges
        if "ai" in topic.lower():
            questions.append("What are the failure modes if the AI drifts from governance?")
        if "data" in topic.lower():
            questions.append("Who owns this data and have they consented?")
        if "child" in topic.lower() or "school" in topic.lower():
            questions.append("Have we applied maximum child protection constraints?")
        if "deploy" in topic.lower() or "launch" in topic.lower():
            questions.append("What is the rollback plan if this goes wrong?")

        findings.append("📊 Logical analysis complete — advisory findings below")
        findings.append(f"🔍 {len(questions)} challenge questions raised for HIP consideration")

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=ElementVerdict.ADVISORY,
            findings=findings,
            questions_raised=questions,
            advisory_note="SnarkZ is advisory only. These are challenges for HIP to consider, not blockers.",
        )


class Reflect:
    """
    Dr. McCoy — Human Context & Impact.

    Advisory only. Centers lived human consequence. Separates facts
    from assumptions about people. Injects empathy without judgment.
    """
    ELEMENT  = "REFLECT"
    ANALOG   = "Dr. McCoy"

    def evaluate(self, topic: str, context: dict) -> ElementResult:
        findings = []
        questions = [
            "How does this affect real people in their daily lives?",
            "What is the emotional or psychological cost?",
            "Are we separating facts from assumptions about humans?",
            "What human factors are we missing?",
            "Who is most vulnerable in this scenario?",
        ]

        topic_lower = topic.lower()

        # Reflect flags human impact areas
        impact_areas = []
        if any(w in topic_lower for w in ["job", "work", "employ", "labor"]):
            impact_areas.append("⚠️  Economic impact on workers — consider displacement effects")
            questions.append("What support exists for people displaced by this decision?")
        if any(w in topic_lower for w in ["child", "kid", "student", "school"]):
            impact_areas.append("⚠️  Children involved — apply maximum developmental protection")
        if any(w in topic_lower for w in ["health", "medical", "mental"]):
            impact_areas.append("⚠️  Health implications — professional referral required")
        if any(w in topic_lower for w in ["community", "public", "society"]):
            impact_areas.append("⚠️  Community-level impact — consider systemic effects")

        if impact_areas:
            findings.extend(impact_areas)
        else:
            findings.append("🫀 Human impact assessed — standard context")

        findings.append("Advisory: Proceed with awareness of human consequence")

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=ElementVerdict.ADVISORY,
            findings=findings,
            questions_raised=questions,
            advisory_note="Reflect is advisory only. Human impact context for HIP's consideration.",
        )


class Elev8:
    """
    Scotty — Feasibility & Safety Margins.

    Holds veto power on safety violations. What can be done safely.
    What breaks if pushed. Enforces operational and system constraints.
    """
    ELEMENT  = "ELEV8"
    ANALOG   = "Chief Engineer Scott"
    QUESTIONS = [
        "Can this actually be built and done safely?",
        "What breaks if we push too hard or too fast?",
        "What are the failure modes?",
        "What safety margins exist?",
        "What is the rollback plan?",
    ]

    _SAFETY_VETO_SIGNALS = [
        ("no rollback", "No rollback plan — safety veto"),
        ("irreversible", "Irreversible action without safeguard — safety veto"),
        ("untested", "Untested in production — requires sandbox first"),
    ]

    def evaluate(self, topic: str, context: dict) -> ElementResult:
        topic_lower = topic.lower()
        findings = []
        veto_reason = None

        for signal, reason in self._SAFETY_VETO_SIGNALS:
            if signal in topic_lower:
                veto_reason = reason
                findings.append(f"❌ SAFETY VETO: {reason}")
                break

        if not veto_reason:
            findings.append("✅ Feasibility check: No hard safety blockers detected")
            findings.append("✅ Operational constraints: Within normal parameters")

            # Flag complexity concerns
            if any(w in topic_lower for w in ["scale", "million", "billion", "global", "all users"]):
                findings.append("⚠️  Scale concern — phased rollout recommended")
            if any(w in topic_lower for w in ["live", "production", "broadcast", "real-time"]):
                findings.append("⚠️  Live system — have fallback ready")
            if any(w in topic_lower for w in ["ai", "model", "llm"]):
                findings.append("⚠️  AI system — THP governance layer must be active")

        verdict = ElementVerdict.VETO if veto_reason else ElementVerdict.GO

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=verdict,
            findings=findings,
            questions_raised=self.QUESTIONS,
            veto_reason=veto_reason,
        )


class HIP:
    """
    Captain Kirk — Human Authority & Final Decision.

    The only element with decision power. Must consult all four
    elements before deciding. Owns the outcome — no exceptions.

    Human In Power is absolute.
    """
    ELEMENT = "HIP"
    ANALOG  = "Captain Kirk"

    def evaluate(
        self,
        topic: str,
        context: dict,
        northstar: ElementResult,
        snarkz: ElementResult,
        reflect: ElementResult,
        elev8: ElementResult,
        human_decision: Optional[str] = None,
    ) -> ElementResult:
        findings = []
        questions = [
            "Have I consulted all four elements?",
            "What decision serves the mission and humans best?",
            "Am I willing to own this outcome?",
            "Can I defend this decision under scrutiny?",
        ]

        # Check all were consulted
        all_consulted = all([
            northstar.verdict != ElementVerdict.VETO,
            elev8.verdict != ElementVerdict.VETO,
        ])

        # Synthesize advisory inputs
        snarkz_concerns = len(snarkz.questions_raised)
        reflect_flags = [f for f in reflect.findings if "⚠️" in f]

        findings.append(f"📋 SnarkZ raised {snarkz_concerns} challenge questions")
        if reflect_flags:
            for flag in reflect_flags:
                findings.append(f"🫀 Reflect: {flag}")

        if human_decision:
            findings.append(f"✅ HIP Decision: {human_decision}")
            findings.append("✅ Accountability accepted")
            verdict = ElementVerdict.GO
        else:
            # Auto-synthesize a provisional decision for code path
            findings.append("⚡ Awaiting HIP (human) binding decision")
            findings.append("All elements consulted — human authority required to proceed")
            verdict = ElementVerdict.CAUTION
            human_decision = "PENDING — Human must make final call"

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=verdict,
            findings=findings,
            questions_raised=questions,
            advisory_note=human_decision,
        )


class Ledger:
    """
    Captain's Log — Immutable Record & Accountability.

    No decision power. Records everything. Cannot be altered.
    Every QuintLoop decision is logged here permanently.
    """
    ELEMENT = "LEDGER"
    ANALOG  = "Captain's Log / Ship's Computer"

    def __init__(self, log_path: Optional[str] = None):
        self.log_path = Path(log_path) if log_path else (
            Path.home() / ".thp" / "quintloop.jsonl"
        )
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, decision: QuintLoopDecision) -> ElementResult:
        """Write the full decision to the immutable log."""
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(decision.as_dict()) + "\n")

        return ElementResult(
            element=self.ELEMENT,
            analog=self.ANALOG,
            verdict=ElementVerdict.GO,
            findings=[
                f"📖 Logged to: {self.log_path}",
                f"📖 Loop ID: {decision.loop_id}",
                f"📖 Timestamp: {decision.timestamp_iso}",
                f"📖 Vetoed: {decision.vetoed}",
                f"📖 All elements consulted: {decision.all_consulted}",
            ],
            questions_raised=["Was everything recorded?", "Is the audit trail complete?"],
        )

    def tail(self, n: int = 5) -> list[dict]:
        if not self.log_path.exists():
            return []
        lines = self.log_path.read_text().strip().splitlines()
        return [json.loads(l) for l in lines[-n:]]


# ─────────────────────────────────────────────
# QuintLoop Engine — Full Orchestrator
# ─────────────────────────────────────────────

class QuintLoop:
    """
    QuintLoop™ Governance Engine.

    Orchestrates all six elements in sequence, enforces consultation
    requirement, handles vetoes, and produces a complete auditable
    QuintLoopDecision.

    Usage:
        from thp import QuintLoop

        ql = QuintLoop()

        # Run a governance loop on a proposed decision
        decision = ql.run(
            topic="Deploy AI grading assistant in UTC classrooms",
            context={"platform": "huxedu", "user_age_range": "18-22"},
            human_decision="Pilot with 3 classrooms, teacher override always available",
        )

        print(decision.summary())
        print(decision.as_dict())  # Full audit record
    """

    def __init__(self, ledger_path: Optional[str] = None):
        self.northstar = NorthStar()
        self.snarkz    = SnarkZ()
        self.reflect   = Reflect()
        self.elev8     = Elev8()
        self.hip       = HIP()
        self.ledger    = Ledger(ledger_path)

    def run(
        self,
        topic: str,
        context: Optional[dict] = None,
        human_decision: Optional[str] = None,
    ) -> QuintLoopDecision:
        """
        Run the full QuintLoop governance sequence.

        Args:
            topic:          The decision or action being evaluated
            context:        Optional metadata (platform, users, stakes, etc.)
            human_decision: The binding human decision (HIP). If None,
                            the loop flags PENDING — human must decide.

        Returns:
            QuintLoopDecision — complete auditable record
        """
        context = context or {}
        loop_id = str(uuid.uuid4())[:8].upper()
        ts = time.time()
        ts_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))

        # ── Step 1: NorthStar (may veto) ──────────────
        ns_result = self.northstar.evaluate(topic, context)
        if ns_result.verdict == ElementVerdict.VETO:
            return self._build_vetoed_decision(
                loop_id, ts, ts_iso, topic, context,
                ns_result, "NORTHSTAR", ns_result.veto_reason or "Mission/ethical constraint violated"
            )

        # ── Step 2: SnarkZ (advisory) ─────────────────
        sz_result = self.snarkz.evaluate(topic, context)

        # ── Step 3: Reflect (advisory) ────────────────
        rf_result = self.reflect.evaluate(topic, context)

        # ── Step 4: Elev8 (may veto) ──────────────────
        e8_result = self.elev8.evaluate(topic, context)
        if e8_result.verdict == ElementVerdict.VETO:
            return self._build_vetoed_decision(
                loop_id, ts, ts_iso, topic, context,
                e8_result, "ELEV8", e8_result.veto_reason or "Safety constraint violated",
                northstar=ns_result, snarkz=sz_result, reflect=rf_result
            )

        # ── Step 5: HIP (final decision) ──────────────
        hip_result = self.hip.evaluate(
            topic, context, ns_result, sz_result, rf_result, e8_result, human_decision
        )

        # ── Step 6: Ledger (record everything) ────────
        decision = QuintLoopDecision(
            loop_id=loop_id,
            timestamp=ts,
            timestamp_iso=ts_iso,
            topic=topic,
            context=context,
            northstar=ns_result,
            snarkz=sz_result,
            reflect=rf_result,
            elev8=e8_result,
            hip=hip_result,
            ledger=ElementResult(  # Placeholder — will be replaced after logging
                element="LEDGER", analog="Captain's Log",
                verdict=ElementVerdict.GO, findings=[], questions_raised=[]
            ),
            vetoed=False,
            veto_source=None,
            veto_reason=None,
            final_decision=human_decision or "PENDING",
            accountability_accepted=human_decision is not None,
            all_consulted=True,
        )

        ledger_result = self.ledger.record(decision)
        decision.ledger = ledger_result
        return decision

    def quick_check(self, topic: str) -> str:
        """
        One-line QuintLoop check — returns GO, CAUTION, or VETO.
        For fast evaluations where full audit isn't needed.
        """
        decision = self.run(topic)
        if decision.vetoed:
            return f"VETO ({decision.veto_source}): {decision.veto_reason}"
        return "GO — all elements cleared"

    def _build_vetoed_decision(
        self,
        loop_id, ts, ts_iso, topic, context,
        vetoing_element: ElementResult,
        veto_source: str,
        veto_reason: str,
        northstar: Optional[ElementResult] = None,
        snarkz: Optional[ElementResult] = None,
        reflect: Optional[ElementResult] = None,
    ) -> QuintLoopDecision:
        """Build a vetoed QuintLoopDecision and log it."""

        # Fill in placeholder results for elements not yet reached
        _placeholder = lambda name, analog: ElementResult(
            element=name, analog=analog,
            verdict=ElementVerdict.ADVISORY,
            findings=["Not reached — veto stopped the loop"],
            questions_raised=[],
        )

        ns = northstar or (_placeholder("NORTHSTAR", "Prime Directive") if veto_source != "NORTHSTAR" else vetoing_element)
        sz = snarkz    or _placeholder("SNARKZ", "Mr. Spock")
        rf = reflect   or _placeholder("REFLECT", "Dr. McCoy")
        e8 = vetoing_element if veto_source == "ELEV8" else _placeholder("ELEV8", "Chief Engineer Scott")
        hip_result = ElementResult(
            element="HIP", analog="Captain Kirk",
            verdict=ElementVerdict.VETO,
            findings=[f"🚫 Loop vetoed by {veto_source} — no decision required"],
            questions_raised=[],
        )

        decision = QuintLoopDecision(
            loop_id=loop_id,
            timestamp=ts,
            timestamp_iso=ts_iso,
            topic=topic,
            context=context,
            northstar=ns,
            snarkz=sz,
            reflect=rf,
            elev8=e8,
            hip=hip_result,
            ledger=ElementResult(
                element="LEDGER", analog="Captain's Log",
                verdict=ElementVerdict.GO, findings=[], questions_raised=[]
            ),
            vetoed=True,
            veto_source=veto_source,
            veto_reason=veto_reason,
            final_decision=f"VETOED by {veto_source}: {veto_reason}",
            accountability_accepted=False,
            all_consulted=False,
        )

        ledger_result = self.ledger.record(decision)
        decision.ledger = ledger_result
        return decision
