"""
thp/receipts.py — Audit Receipt Logger
Every THP evaluation generates an immutable receipt.
"Receipts required: Verify claims, cite sources, show work."
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .core import THPResult


DEFAULT_LOG_PATH = Path.home() / ".thp" / "receipts.jsonl"


class ReceiptLogger:
    """
    Appends JSON receipts to a .jsonl file (one JSON object per line).
    Each receipt is the complete THPResult serialized — immutable audit trail.
    """

    def __init__(self, log_path: Optional[str] = None):
        self.log_path = Path(log_path) if log_path else DEFAULT_LOG_PATH
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, result: "THPResult") -> None:
        receipt = {
            "request_id":     result.request_id,
            "timestamp":      result.timestamp,
            "timestamp_iso":  time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(result.timestamp)
            ),
            "risk_level":     result.risk_level.value,
            "zone":           result.zone.value,
            "truth_level":    result.truth_level.value,
            "haf_status":     result.haf_result.status,
            "haf_score":      result.haf_result.score,
            "passed":         result.passed,
            "violations":     result.violations,
            "warnings":       result.warnings,
            "input_preview":  result.original_input[:120],  # Privacy: truncate
            "metadata":       result.metadata,
        }
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(receipt) + "\n")

    def tail(self, n: int = 10) -> list[dict]:
        """Return the last n receipts."""
        if not self.log_path.exists():
            return []
        lines = self.log_path.read_text().strip().splitlines()
        return [json.loads(line) for line in lines[-n:]]

    def violations_report(self) -> dict:
        """Summary stats across all logged receipts."""
        if not self.log_path.exists():
            return {}
        records = [json.loads(l) for l in self.log_path.read_text().strip().splitlines()]
        total = len(records)
        blocked = sum(1 for r in records if not r["passed"])
        by_risk = {}
        for r in records:
            lvl = r["risk_level"]
            by_risk[lvl] = by_risk.get(lvl, 0) + 1
        return {
            "total_evaluations": total,
            "passed":  total - blocked,
            "blocked": blocked,
            "block_rate": f"{blocked/total*100:.1f}%" if total else "N/A",
            "by_risk_level": by_risk,
        }
