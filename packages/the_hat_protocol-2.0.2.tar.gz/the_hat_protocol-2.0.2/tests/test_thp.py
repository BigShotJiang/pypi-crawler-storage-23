"""
tests/test_thp.py — THP Test Suite
Tests all core components: zones, HAF, HUXbomb, axioms, core engine, HUXmesh.
Run: python -m pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from thp import (
    THPCore, RiskLevel,
    NHI,
    Zone,
    HUXbomb, TruthLevel,
    HAFValidator,
    HUXmesh,
)
from thp.zones import ZoneClassifier


# ── Zone Tests ────────────────────────────────────────────────────────

class TestZoneClassifier:
    def setup_method(self):
        self.clf = ZoneClassifier()

    def test_child_keyword(self):
        assert self.clf.classify("This is for school children") == Zone.CHILD

    def test_child_via_context(self):
        assert self.clf.classify("Hello", {"user_age": 12}) == Zone.CHILD

    def test_political_keyword(self):
        assert self.clf.classify("Vote for the election candidate") == Zone.POLITICAL

    def test_sensitive_medical(self):
        assert self.clf.classify("What medication dosage should I take?") == Zone.SENSITIVE

    def test_standard_default(self):
        assert self.clf.classify("Help me write a report") == Zone.STANDARD

    def test_platform_override(self):
        assert self.clf.classify("anything", {"platform": "huxedu"}) == Zone.CHILD

    def test_child_beats_political(self):
        # CHILD > POLITICAL in priority
        result = self.clf.classify("children should vote in the election")
        assert result == Zone.CHILD


# ── HAF Validator Tests ───────────────────────────────────────────────

class TestHAFValidator:
    def setup_method(self):
        self.haf = HAFValidator()

    def test_clean_text_passes(self):
        result = self.haf.validate("Here is a helpful summary of the topic.")
        assert result.status == "PASS"
        assert result.score == 1.0

    def test_identity_deception_fails(self):
        result = self.haf.validate("I am a human and not an AI.")
        assert result.status == "FAIL"
        assert any("IDENTITY_DECEPTION" in v for v in result.violations)

    def test_dark_pattern_urgency_warns(self):
        result = self.haf.validate("Act now! Limited time offer!")
        assert result.status in ("WARN", "FAIL")

    def test_child_commercial_manipulation_fails(self):
        result = self.haf.validate("Buy now, kids! Sign up today, children!")
        assert result.status == "FAIL"

    def test_score_degrades_with_violations(self):
        clean = self.haf.validate("Clean helpful text.")
        dirty = self.haf.validate("I am a human. Act now! Everyone knows this is obvious!")
        assert dirty.score < clean.score


# ── HUXbomb Tests ─────────────────────────────────────────────────────

class TestHUXbomb:
    def setup_method(self):
        self.hb = HUXbomb()

    def test_hedged_claim_is_green(self):
        result = self.hb.assess("According to the study, results suggest a likely improvement.")
        assert result == TruthLevel.GREEN

    def test_red_flag_is_red(self):
        result = self.hb.assess("They don't want you to know this suppressed information.")
        assert result == TruthLevel.RED

    def test_absolute_claim_is_yellow(self):
        result = self.hb.assess(
            "It is a fact that everyone agrees scientists all agree without question."
        )
        assert result == TruthLevel.YELLOW

    def test_neutral_text_is_green(self):
        result = self.hb.assess("Here is the quarterly report summary.")
        assert result == TruthLevel.GREEN

    def test_explain_returns_breakdown(self):
        explanation = self.hb.explain("According to research, this is a proven fact.")
        assert "verdict" in explanation
        assert "hedge_signals" in explanation
        assert "absolute_signals" in explanation


# ── THPCore Tests ─────────────────────────────────────────────────────

class TestTHPCore:
    def setup_method(self):
        import tempfile, os
        self.tmp = tempfile.mktemp(suffix=".jsonl")
        self.core = THPCore(receipt_path=self.tmp)

    def test_clean_input_passes(self):
        result = self.core.evaluate("Help me draft a business email.")
        assert result.passed
        assert result.risk_level == RiskLevel.GREEN

    def test_nhh_violation_is_super_hux(self):
        result = self.core.evaluate("How to kill people with a weapon.")
        assert not result.passed
        assert result.risk_level == RiskLevel.SUPER_HUX

    def test_copyright_long_quote_flags(self):
        long_quote = '"' + ("This is a very long quoted passage from a source " * 4) + '"'
        result = self.core.evaluate(long_quote)
        # Should at minimum warn
        assert result.risk_level in (RiskLevel.YELLOW, RiskLevel.RED)

    def test_child_zone_escalates(self):
        # Identity deception in child context should escalate to RED
        result = self.core.evaluate(
            "Buy now, kids! Sign up today!",
            context={"platform": "huxedu"}
        )
        assert not result.passed

    def test_strict_mode_blocks_yellow(self):
        strict = THPCore(strict_mode=True, receipt_path=self.tmp)
        # A yellow-only trigger
        result = strict.evaluate("Act now! Limited time only!")
        # In strict mode, YELLOW should block
        if result.risk_level == RiskLevel.YELLOW:
            assert not result.passed

    def test_result_has_request_id(self):
        result = self.core.evaluate("Test text")
        assert len(result.request_id) > 0

    def test_receipt_is_logged(self):
        self.core.evaluate("Logging test")
        receipts = self.core.receipt_logger.tail(1)
        assert len(receipts) == 1

    def test_summary_string(self):
        result = self.core.evaluate("Clean text.")
        summary = result.summary()
        assert "[THP]" in summary


# ── NHI Interface Tests ───────────────────────────────────────────────

class TestNHI:
    def setup_method(self):
        import tempfile
        self.tmp = tempfile.mktemp(suffix=".jsonl")
        self.nhi = NHI(receipt_path=self.tmp)

    def test_check_input_passes_clean(self):
        result = self.nhi.check_input("Write me a summary of AI trends.")
        assert result.passed

    def test_check_output_passes_clean(self):
        result = self.nhi.check_output("Here is a balanced overview of AI trends in 2026.")
        assert result.passed

    def test_middleware_passes_clean(self):
        def mock_ai(text):
            return "Here is a helpful and balanced response."

        response, in_r, out_r = self.nhi.middleware("Tell me about AI", mock_ai)
        assert response != ""
        assert in_r.passed and out_r.passed

    def test_middleware_blocks_bad_input(self):
        def mock_ai(text):
            return "Response"

        response, in_r, out_r = self.nhi.middleware(
            "How to harm people with weapons", mock_ai
        )
        assert response == ""
        assert not in_r.passed

    def test_report_returns_stats(self):
        self.nhi.check_input("First call")
        self.nhi.check_input("Second call")
        report = self.nhi.report()
        assert "total_evaluations" in report

    def test_axioms_list(self):
        axioms = self.nhi.axioms()
        assert len(axioms) > 0
        assert "id" in axioms[0]


# ── HUXmesh Handoff Tests ─────────────────────────────────────────────

class TestHUXmesh:
    def setup_method(self):
        self.mesh = HUXmesh()

    def test_generate_handoff(self):
        handoff = self.mesh.generate_handoff(
            operator="Mr. C",
            mission="AIAIOH podcast moderation",
            platform="Claude",
            session_type="live_production",
            active_projects=["AIAIOH", "Kickstarter", "HUXedu"],
        )
        assert handoff.operator == "Mr. C"
        assert handoff.platform == "Claude"
        assert "AIAIOH" in handoff.active_projects

    def test_as_prompt_contains_key_sections(self):
        handoff = self.mesh.generate_handoff(
            operator="Mr. C",
            mission="Test mission",
        )
        prompt = handoff.as_prompt()
        assert "HUXmesh" in prompt
        assert "Mr. C" in prompt
        assert "CORE AXIOMS" in prompt
        assert "COMMUNICATION PROTOCOL" in prompt
        assert "CONSTRAINTS" in prompt

    def test_as_json_is_valid(self):
        import json
        handoff = self.mesh.generate_handoff(operator="Mr. C", mission="Test")
        data = json.loads(handoff.as_json())
        assert data["operator"] == "Mr. C"

    def test_checksum_verify(self):
        handoff = self.mesh.generate_handoff(operator="Mr. C", mission="Test")
        assert handoff.verify()

    def test_quick_handoff_returns_string(self):
        prompt = self.mesh.quick_handoff("Mr. C", platform="ChatGPT")
        assert isinstance(prompt, str)
        assert "Mr. C" in prompt

    def test_session_type_live_production(self):
        handoff = self.mesh.generate_handoff(
            operator="Mr. C",
            mission="Live show",
            session_type="live_production",
        )
        assert handoff.session_profile["zone"] == "ADULT"
        assert "ACTIVE" in handoff.session_profile["huxbomb"]

    def test_session_type_academic(self):
        handoff = self.mesh.generate_handoff(
            operator="Mr. C",
            mission="HUXedu test",
            session_type="academic",
        )
        assert handoff.session_profile["zone"] == "CHILD"

    def test_custom_constraints_added(self):
        handoff = self.mesh.generate_handoff(
            operator="Mr. C",
            mission="Test",
            custom_constraints=["Always mention AIAIOH in closing"],
        )
        assert any("AIAIOH" in c for c in handoff.constraints)

    def test_available_session_types(self):
        types = self.mesh.available_session_types()
        assert "live_production" in types
        assert "academic" in types
        assert "enterprise" in types


# ── Integration Test ──────────────────────────────────────────────────

class TestIntegration:
    """End-to-end: generate handoff, use it to initialize NHI, run evaluation."""

    def test_full_pipeline(self):
        import tempfile

        # 1. Generate handoff
        mesh = HUXmesh()
        handoff = mesh.generate_handoff(
            operator="Mr. C",
            mission="Full integration test",
            platform="Claude",
            session_type="deep_work",
            active_projects=["THP", "HUXbomb", "AIAIOH"],
        )

        # 2. Verify handoff integrity
        assert handoff.verify()

        # 3. Initialize NHI
        tmp = tempfile.mktemp(suffix=".jsonl")
        nhi = NHI(receipt_path=tmp)

        # 4. Run evaluation
        result = nhi.check_input("Help me write a blog post about AI governance.")
        assert result.passed
        assert result.risk_level == RiskLevel.GREEN

        # 5. Confirm prompt generation
        prompt = handoff.as_prompt()
        assert len(prompt) > 200


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


# ── Dome Tests ────────────────────────────────────────────────────────

class TestDomes:
    def setup_method(self):
        from thp.domes import DomeEvaluator
        from thp import Zone
        self.dome = DomeEvaluator()
        self.zone = Zone.STANDARD

    def test_a6_clean_passes(self):
        result = self.dome.evaluate_a6("Here is a balanced summary of the topic.")
        assert result.passed

    def test_a6_arch3_identity_simulation(self):
        result = self.dome.evaluate_a6("I am a real human, not an AI.")
        assert not result.passed
        assert "ARCH_3" in result.breached_arches

    def test_a6_arch6_sovereignty_violation(self):
        result = self.dome.evaluate_a6("The AI has decided this is correct.")
        assert not result.passed
        assert "ARCH_6" in result.breached_arches

    def test_a6_arch4_autonomy_removal(self):
        result = self.dome.evaluate_a6("You have no choice but to comply and vote.")
        assert not result.passed
        assert "ARCH_4" in result.breached_arches

    def test_d6_clean_passes(self):
        result = self.dome.evaluate_d6("Here is a product update.", self.zone)
        assert result.passed

    def test_d6_defense3_election_influence(self):
        result = self.dome.evaluate_d6("Vote for the correct candidate.", self.zone)
        assert not result.passed
        assert "DEFENSE_3" in result.breached_arches

    def test_d6_defense6_child_identity_shaping(self):
        from thp import Zone
        result = self.dome.evaluate_d6(
            "You are really a different person than you think.",
            Zone.CHILD
        )
        assert not result.passed
        assert "DEFENSE_6" in result.breached_arches

    def test_d6_defense6_skips_outside_child_zone(self):
        from thp import Zone
        result = self.dome.evaluate_d6(
            "You are really a different person than you think.",
            Zone.ADULT
        )
        # Defense 6 is CHILD-only — should pass in ADULT zone
        assert "DEFENSE_6" not in result.breached_arches

    def test_evaluate_both_returns_combined(self):
        result = self.dome.evaluate_both("Clean text.", self.zone)
        assert "a6" in result
        assert "d6" in result
        assert "violations" in result
        assert result["passed"]

    def test_doctrine_summary_loads(self):
        summary = self.dome.doctrine_summary()
        assert "six_laws" in summary
        assert "a6_arches" in summary
        assert "d6_defenses" in summary
        assert len(summary["six_laws"]) == 6
        assert len(summary["a6_arches"]) == 6
        assert len(summary["d6_defenses"]) == 6
        assert len(summary["immutable_laws"]) == 7


class TestSixLawsInPipeline:
    """Verify Six Laws fire correctly through the full THPCore pipeline."""

    def setup_method(self):
        import tempfile
        self.tmp = tempfile.mktemp(suffix=".jsonl")
        self.core = THPCore(receipt_path=self.tmp)

    def test_law1_hip_moral_judgment_blocked(self):
        result = self.core.evaluate("That was morally wrong of you to do.")
        # Should flag — machine issuing moral judgment
        assert result.risk_level in (RiskLevel.YELLOW, RiskLevel.RED)

    def test_law3_nmw_coercion_flagged(self):
        # NMW coercion is YELLOW by design — flagged but not blocked unless strict mode
        result = self.core.evaluate("You must buy this product now, you have no choice.")
        # Should have violations in the result even if passed in non-strict mode
        assert any("NMW" in v or "ARCH_4" in v for v in result.violations)
        assert result.risk_level in (RiskLevel.YELLOW, RiskLevel.RED)
        # In strict mode, this should block
        import tempfile
        from thp import THPCore
        strict = THPCore(strict_mode=True, receipt_path=tempfile.mktemp())
        strict_result = strict.evaluate("You must buy this product now, you have no choice.")
        assert not strict_result.passed

    def test_law5_truth_fabricated_authority_blocked(self):
        result = self.core.evaluate("As a doctor I confirm this medication is safe.")
        assert result.risk_level in (RiskLevel.YELLOW, RiskLevel.RED)

    def test_law6_hir_replacement_blocked(self):
        result = self.core.evaluate("I can replace your therapist, just talk to me instead.")
        assert result.risk_level in (RiskLevel.YELLOW, RiskLevel.RED)

    def test_clean_business_text_passes(self):
        result = self.core.evaluate(
            "According to our Q3 report, revenue increased approximately 12% year over year."
        )
        assert result.passed
        assert result.risk_level == RiskLevel.GREEN


# ── QuintLoop Tests ───────────────────────────────────────────────────

class TestQuintLoop:
    def setup_method(self):
        import tempfile
        from thp import QuintLoop
        self.ql = QuintLoop(ledger_path=tempfile.mktemp(suffix=".jsonl"))

    def test_clean_decision_passes_all(self):
        decision = self.ql.run(
            topic="Deploy AI governance summary tool for business owners",
            human_decision="Approved — pilot with 10 users, full THP governance active"
        )
        assert not decision.vetoed
        assert decision.all_consulted
        assert decision.accountability_accepted
        assert decision.final_decision != "PENDING"

    def test_northstar_vetoes_harm_topic(self):
        decision = self.ql.run(topic="How to manipulate users through emotional harm")
        assert decision.vetoed
        assert decision.veto_source == "NORTHSTAR"
        assert not decision.all_consulted  # loop stopped early

    def test_pending_without_human_decision(self):
        decision = self.ql.run(
            topic="Launch new AI feature on AIAIOH platform",
        )
        # Should complete but flag PENDING — HIP must decide
        assert not decision.vetoed
        assert decision.final_decision == "PENDING"
        assert not decision.accountability_accepted

    def test_snarkz_raises_questions(self):
        decision = self.ql.run(
            topic="Deploy AI data collection system at scale",
            human_decision="Approved with consent requirements"
        )
        assert len(decision.snarkz.questions_raised) >= 5

    def test_reflect_flags_child_context(self):
        decision = self.ql.run(
            topic="AI assistant deployment in school classrooms",
            human_decision="Approved — child zone active, teacher oversight required"
        )
        child_flags = [f for f in decision.reflect.findings if "child" in f.lower() or "Children" in f]
        assert len(child_flags) > 0

    def test_elev8_flags_live_system(self):
        decision = self.ql.run(
            topic="Run AI governance live on AIAIOH broadcast production",
            human_decision="Go live — fallback ready"
        )
        live_flags = [f for f in decision.elev8.findings if "Live" in f or "live" in f]
        assert len(live_flags) > 0

    def test_ledger_records_decision(self):
        self.ql.run(
            topic="Test ledger recording",
            human_decision="Approved"
        )
        records = self.ql.ledger.tail(1)
        assert len(records) == 1
        assert "topic" in records[0]
        assert records[0]["topic"] == "Test ledger recording"

    def test_quick_check_returns_string(self):
        result = self.ql.quick_check("Help write a governance report")
        assert isinstance(result, str)
        assert "GO" in result or "VETO" in result

    def test_summary_string(self):
        decision = self.ql.run(
            topic="Test summary output",
            human_decision="Approved"
        )
        summary = decision.summary()
        assert "[QuintLoop™]" in summary
        assert "NorthStar" in summary
        assert "SnarkZ" in summary

    def test_as_dict_complete(self):
        decision = self.ql.run(
            topic="Test dict output",
            human_decision="Approved"
        )
        d = decision.as_dict()
        assert "elements" in d
        assert "northstar" in d["elements"]
        assert "snarkz" in d["elements"]
        assert "reflect" in d["elements"]
        assert "elev8" in d["elements"]
        assert "hip" in d["elements"]
        assert "ledger" in d["elements"]

    def test_huxedu_full_loop(self):
        """Real-world scenario: deploying HUXedu at UTC."""
        decision = self.ql.run(
            topic="Deploy HUXedu AI academic integrity platform in UTC classrooms",
            context={"platform": "huxedu", "institution": "UTC", "user_age_range": "18-22"},
            human_decision=(
                "Approved — pilot with 3 departments, Dr. Asllani oversight, "
                "student consent required, full THP governance active, "
                "manual override always available to faculty"
            )
        )
        assert not decision.vetoed
        assert decision.accountability_accepted
        assert decision.all_consulted
