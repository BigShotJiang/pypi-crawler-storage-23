"""Storage provider factory with auto-registration of built-in providers.

Usage::

    from core_lib_storage import StorageProviderFactory

    # The factory auto-registers s3, sftp, and gdrive providers on import.
    provider = StorageProviderFactory.create("s3", credentials)
"""

import logging
from typing import Any, Dict, Type

from core_lib.core_lib_auth.credentials_service import Credential
from .base_storage import BaseStorage

logger = logging.getLogger(__name__)


class StorageProviderFactory:
    """Registry-based factory for storage providers.

    Built-in providers (``s3``, ``sftp``, ``gdrive``) are auto-registered
    when this module is first imported.  Additional providers can be
    registered at runtime via :meth:`register_provider`.
    """

    _providers: Dict[str, Type[BaseStorage]] = {}

    @classmethod
    def register_provider(cls, provider_type: str, provider_class: Type[BaseStorage]) -> None:
        """Register a storage provider class under *provider_type*."""
        cls._providers[provider_type.lower()] = provider_class
        logger.debug("Registered storage provider: %s -> %s", provider_type, provider_class.__name__)

    @classmethod
    def create(cls, provider_type: str, credentials: Credential) -> BaseStorage:
        """Instantiate a registered storage provider.

        Args:
            provider_type: Key such as ``'s3'``, ``'sftp'``, ``'gdrive'``.
            credentials: A :class:`Credential` namedtuple with the
                fields expected by the chosen provider.

        Returns:
            An initialised :class:`BaseStorage` subclass.

        Raises:
            ValueError: If *provider_type* has not been registered.
        """
        key = provider_type.lower()
        provider_class = cls._providers.get(key)
        if not provider_class:
            registered = ", ".join(sorted(cls._providers.keys())) or "(none)"
            raise ValueError(
                f"Unsupported storage provider type: '{provider_type}'. "
                f"Registered types: {registered}"
            )

        logger.info("Creating storage provider: %s", key)
        return cls._build(key, provider_class, credentials)

    @classmethod
    def list_providers(cls) -> list[str]:
        """Return the list of registered provider type keys."""
        return sorted(cls._providers.keys())

    # ------------------------------------------------------------------
    # Internal builder — maps Credential fields to provider constructors
    # ------------------------------------------------------------------

    @classmethod
    def _build(cls, key: str, provider_class: Type[BaseStorage], cred: Credential) -> BaseStorage:
        if key == "s3":
            from .s3_storage import S3Storage  # noqa: avoid circular
            return S3Storage(
                access_key=cred.access_key or "",
                secret_key=cred.secret_key or "",
            )
        if key == "sftp":
            from .sftp_storage import SFTPStorage
            return SFTPStorage(
                hostname=cred.username.split("@")[-1] if cred.username and "@" in cred.username else "localhost",
                username=cred.username.split("@")[0] if cred.username and "@" in cred.username else (cred.username or ""),
                password=cred.password,
                private_key=cred.private_key,
            )
        if key == "gdrive":
            from .gdrive_storage import GoogleDriveStorage
            return GoogleDriveStorage(
                access_token=cred.access_token or "",
                refresh_token=cred.refresh_token,
                client_id=(cred.token or {}).get("client_id"),
                client_secret=(cred.token or {}).get("client_secret"),
            )
        # Generic fallback — try to pass credentials directly
        return provider_class(cred)


# ------------------------------------------------------------------
# Auto-register built-in providers on module import
# ------------------------------------------------------------------

def _auto_register() -> None:
    """Import and register the three built-in storage providers."""
    try:
        from .s3_storage import S3Storage
        StorageProviderFactory.register_provider("s3", S3Storage)
    except ImportError as exc:
        logger.warning("S3Storage not available: %s", exc)

    try:
        from .sftp_storage import SFTPStorage
        StorageProviderFactory.register_provider("sftp", SFTPStorage)
    except ImportError as exc:
        logger.warning("SFTPStorage not available: %s", exc)

    try:
        from .gdrive_storage import GoogleDriveStorage
        StorageProviderFactory.register_provider("gdrive", GoogleDriveStorage)
    except ImportError as exc:
        logger.warning("GoogleDriveStorage not available: %s", exc)


_auto_register()