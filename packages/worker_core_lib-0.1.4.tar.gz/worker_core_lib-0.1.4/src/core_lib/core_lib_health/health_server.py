"""
Lightweight HTTP health server for Kubernetes liveness and readiness probes.

Runs in a daemon thread so it doesn't block the main worker event loop.
Designed to be started once during worker initialization.
"""

import json
import logging
import os
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import List, Optional

from .checks import HealthCheck, HealthCheckResult

logger = logging.getLogger(__name__)

# Default port for health server (configurable via HEALTH_PORT env var)
DEFAULT_HEALTH_PORT = 8080


class _HealthHandler(BaseHTTPRequestHandler):
    """
    HTTP handler for health check endpoints.

    Endpoints:
        GET /health  — Liveness probe (always 200 if server is running)
        GET /ready   — Readiness probe (200 only if all dependency checks pass)
        GET /healthz — Alias for /ready (common K8s convention)
    """

    # Reference to the HealthServer instance, set by the server
    health_server: Optional["HealthServer"] = None

    def do_GET(self) -> None:
        if self.path == "/health":
            self._respond_liveness()
        elif self.path in ("/ready", "/healthz"):
            self._respond_readiness()
        else:
            self.send_response(404)
            self.end_headers()

    def _respond_liveness(self) -> None:
        """Liveness probe — always 200 if process is running."""
        body = json.dumps({"status": "ok", "probe": "liveness"})
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body.encode())

    def _respond_readiness(self) -> None:
        """Readiness probe — runs all registered health checks."""
        if not self.health_server or not self.health_server._checks:
            # No checks registered — consider ready
            body = json.dumps({"status": "ok", "probe": "readiness", "checks": {}})
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body.encode())
            return

        results: List[HealthCheckResult] = []
        for check in self.health_server._checks:
            try:
                result = check.check()
                results.append(result)
            except Exception as e:
                results.append(HealthCheckResult(
                    name=check.name,
                    healthy=False,
                    message=f"Check threw exception: {e}",
                ))

        all_healthy = all(r.healthy for r in results)
        checks_dict = {}
        for r in results:
            entry = {"healthy": r.healthy, "message": r.message}
            if r.latency_ms is not None:
                entry["latency_ms"] = r.latency_ms
            checks_dict[r.name] = entry

        body = json.dumps({
            "status": "ok" if all_healthy else "degraded",
            "probe": "readiness",
            "checks": checks_dict,
        })

        self.send_response(200 if all_healthy else 503)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body.encode())

    def log_message(self, format: str, *args: object) -> None:
        """Suppress default stderr logging for health probes."""
        pass


class HealthServer:
    """
    Manages health check endpoints in a background daemon thread.

    Usage:
        server = HealthServer(port=8080)
        server.add_check(RedisHealthCheck())
        server.add_check(DatabaseHealthCheck())
        server.start()

    Or use the factory method to auto-discover checks from environment:
        server = HealthServer.from_environment()
        server.start()
    """

    def __init__(self, port: Optional[int] = None):
        self._port = port or int(os.getenv("HEALTH_PORT", str(DEFAULT_HEALTH_PORT)))
        self._checks: List[HealthCheck] = []
        self._thread: Optional[threading.Thread] = None
        self._server: Optional[HTTPServer] = None

    def add_check(self, check: HealthCheck) -> "HealthServer":
        """Register a health check. Returns self for chaining."""
        self._checks.append(check)
        logger.debug(f"Registered health check: {check.name}")
        return self

    def start(self) -> threading.Thread:
        """
        Start the health server in a daemon thread.

        Returns:
            The running daemon thread.

        Raises:
            RuntimeError: If the server is already running.
        """
        if self._port == 0:
            logger.info("Health server disabled (HEALTH_PORT=0)")
            return threading.current_thread()  # Noop

        if self._thread and self._thread.is_alive():
            logger.warning("Health server is already running")
            return self._thread

        # Create a custom handler class with reference to this server
        server_ref = self

        class BoundHealthHandler(_HealthHandler):
            health_server = server_ref

        self._server = HTTPServer(("0.0.0.0", self._port), BoundHealthHandler)

        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="health-check-server",
            daemon=True,
        )
        self._thread.start()

        check_names = [c.name for c in self._checks] if self._checks else ["none"]
        logger.info(
            f"Health server started on port {self._port} "
            f"(checks: {', '.join(check_names)})"
        )
        return self._thread

    def stop(self) -> None:
        """Stop the health server gracefully."""
        if self._server:
            self._server.shutdown()
            logger.info("Health server stopped")

    @classmethod
    def from_environment(cls, port: Optional[int] = None) -> "HealthServer":
        """
        Factory method that auto-discovers available dependencies from
        environment variables and registers appropriate health checks.

        Checks registered based on environment:
            - Redis: Always (REDIS_HOST is required by CoreSettings)
            - Database: If DB_HOST is set
            - S3: If S3_ENDPOINT_URL is set
        """
        from .checks import RedisHealthCheck, DatabaseHealthCheck, S3HealthCheck

        server = cls(port=port)

        # Redis is always available for BullMQ workers
        if os.getenv("REDIS_HOST"):
            server.add_check(RedisHealthCheck())

        # Database check if DB is configured
        if os.getenv("DB_HOST"):
            server.add_check(DatabaseHealthCheck())

        # S3 check if storage is fully configured (endpoint + credentials)
        if (os.getenv("S3_ENDPOINT_URL")
                and os.getenv("S3_ACCESS_KEY_ID")
                and os.getenv("S3_SECRET_ACCESS_KEY")
                and os.getenv("S3_BUCKET")):
            server.add_check(S3HealthCheck())

        return server
