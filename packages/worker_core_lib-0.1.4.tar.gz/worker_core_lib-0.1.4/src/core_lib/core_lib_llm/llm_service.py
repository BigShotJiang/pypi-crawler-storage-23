"""LLM metadata service — Ollama-compatible adapter implementing LLMPort.

This module provides a higher-level service that wraps the raw Ollama
``/api/generate`` endpoint and exposes both the :class:`LLMPort` interface
(``generate_text``) and a convenience ``generate_metadata`` method that
returns the full JSON response.

Prefer :class:`OllamaAdapter` for new code unless you need the raw JSON
response payload.
"""

import logging
import warnings
from typing import Any, Dict

import httpx

from .llm_port import LLMPort

logger = logging.getLogger(__name__)


class LLMMetadataService(LLMPort):
    """Ollama-based LLM service that implements :class:`LLMPort`.

    Args:
        base_url: Base URL of the Ollama service (e.g. ``http://ollama:11434``).
        model_name: Model to use for generation (e.g. ``llama3``).
        timeout: Request timeout in seconds.
    """

    def __init__(self, base_url: str, model_name: str, timeout: float = 60.0):
        self.base_url = base_url.rstrip("/")
        self.model_name = model_name
        self.timeout = timeout

    # ------------------------------------------------------------------
    # LLMPort implementation
    # ------------------------------------------------------------------

    async def generate_text(
        self, prompt: str, max_tokens: int = 2048, temperature: float = 0.7
    ) -> str:
        """Generate text from a prompt.

        Satisfies :class:`LLMPort` contract.
        """
        payload: Dict[str, Any] = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": max_tokens,
                "temperature": temperature,
            },
        }

        data = await self._post(payload)
        return data.get("response", "").strip()

    # ------------------------------------------------------------------
    # Legacy convenience method
    # ------------------------------------------------------------------

    async def generate_metadata(self, prompt: str) -> Dict[str, Any]:
        """Generate metadata and return the **full** Ollama JSON response.

        .. deprecated::
            Use :meth:`generate_text` or :class:`OllamaAdapter` instead.
        """
        warnings.warn(
            "LLMMetadataService.generate_metadata() is deprecated — "
            "use generate_text() or OllamaAdapter instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        payload: Dict[str, Any] = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
        }
        return await self._post(payload)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Send a POST to the Ollama generate endpoint."""
        api_url = f"{self.base_url}/api/generate"

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    api_url, json=payload, timeout=self.timeout
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as exc:
                logger.error(
                    "LLM HTTP error",
                    extra={
                        "status_code": exc.response.status_code,
                        "url": api_url,
                        "model": self.model_name,
                    },
                )
                raise
            except httpx.RequestError as exc:
                logger.error(
                    "LLM request error",
                    extra={"url": str(exc.request.url), "model": self.model_name},
                )
                raise