"""
tibet-overlay — Decentralized Identity Overlay
================================================

Cryptographic device identity over broken IPv4/CGNAT networks.
Identity belongs to the device (DID), not the network (IP).
TIBET provides verifiable transition history. JIS provides the identity.

Usage::

    from tibet_overlay import IdentityOverlay, DeviceIdentity

    overlay = IdentityOverlay()
    identity = overlay.register("sensor-42", capabilities=["mqtt", "coap"])
    verified = overlay.verify("jis:sensor-42")
    print(verified.trust_score)  # 0.95

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .overlay import IdentityOverlay, OverlayNode
from .identity import DeviceIdentity, IdentityProof
from .resolver import OverlayResolver
from .provenance import OverlayProvenance

__version__ = "0.1.0"

__all__ = [
    "IdentityOverlay",
    "OverlayNode",
    "DeviceIdentity",
    "IdentityProof",
    "OverlayResolver",
    "OverlayProvenance",
]
