"""
Overlay Resolver — resolve JIS DIDs to endpoints.

Like DNS resolves domain names to IP addresses,
the OverlayResolver resolves JIS DIDs to reachable endpoints.
But unlike DNS, identity is verified cryptographically.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class ResolveResult:
    """Result of resolving a DID."""
    did: str
    resolved: bool
    endpoint: str = ""
    trust_score: float = 0.0
    method: str = ""  # "local", "cache", "network", "fallback"
    ttl: int = 300  # seconds
    resolved_at: str = ""

    def to_dict(self) -> dict:
        return {
            "did": self.did,
            "resolved": self.resolved,
            "endpoint": self.endpoint,
            "trust_score": self.trust_score,
            "method": self.method,
            "ttl": self.ttl,
            "resolved_at": self.resolved_at,
        }


class OverlayResolver:
    """
    DID-to-endpoint resolver.

    Resolution order:
    1. Local registry (instant)
    2. Cache (if TTL not expired)
    3. Network query (peer-to-peer)
    4. Fallback to last known endpoint

    Unlike DNS:
    - Identity is cryptographic, not trust-on-first-use
    - Works behind CGNAT (endpoint != identity)
    - Verifiable via TIBET history
    """

    def __init__(self):
        self._cache: dict[str, ResolveResult] = {}
        self._local: dict[str, str] = {}  # did → endpoint

    def register_local(self, did: str, endpoint: str) -> None:
        """Register a local DID-to-endpoint mapping."""
        self._local[did] = endpoint

    def resolve(self, did: str) -> ResolveResult:
        """Resolve a DID to an endpoint."""
        now = datetime.now(timezone.utc).isoformat()

        # 1. Local registry
        if did in self._local:
            result = ResolveResult(
                did=did,
                resolved=True,
                endpoint=self._local[did],
                trust_score=1.0,
                method="local",
                resolved_at=now,
            )
            self._cache[did] = result
            return result

        # 2. Cache
        if did in self._cache:
            cached = self._cache[did]
            if cached.resolved:
                cached.method = "cache"
                return cached

        # 3. Network query would go here in production
        # 4. Fallback
        return ResolveResult(
            did=did,
            resolved=False,
            method="unresolved",
            resolved_at=now,
        )

    def invalidate(self, did: str) -> None:
        """Invalidate cached resolution for a DID."""
        self._cache.pop(did, None)

    def cache_stats(self) -> dict:
        return {
            "local_entries": len(self._local),
            "cached_entries": len(self._cache),
        }
