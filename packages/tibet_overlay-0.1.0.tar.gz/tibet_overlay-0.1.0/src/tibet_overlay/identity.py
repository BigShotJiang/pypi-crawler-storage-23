"""
Device identity layer — cryptographic identity independent of IP address.

A device proves who it is via its JIS DID and TIBET history,
not via its IP address. This makes CGNAT, NAT traversal,
and IP spoofing irrelevant for identity.
"""

import hashlib
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class DeviceIdentity:
    """
    A cryptographic device identity.

    Independent of network topology (IP address).
    Based on JIS (Jasper Identity Standard) DIDs.
    """
    device_id: str
    did: str  # did:jis:<device_id>
    public_key_hash: str
    capabilities: list[str] = field(default_factory=list)
    created_at: str = ""
    last_seen: str = ""
    trust_score: float = 0.5
    metadata: dict = field(default_factory=dict)

    # Network info (informational, NOT used for identity)
    last_known_ip: str = ""
    last_known_port: int = 0
    behind_nat: bool = False

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "did": self.did,
            "public_key_hash": self.public_key_hash,
            "capabilities": self.capabilities,
            "created_at": self.created_at,
            "last_seen": self.last_seen,
            "trust_score": self.trust_score,
            "network": {
                "last_known_ip": self.last_known_ip,
                "last_known_port": self.last_known_port,
                "behind_nat": self.behind_nat,
            },
            "metadata": self.metadata,
        }


@dataclass
class IdentityProof:
    """
    Proof that a device is who it claims to be.

    Contains the JIS DID, a challenge-response hash,
    and the TIBET provenance of previous interactions.
    """
    did: str
    challenge: str
    response_hash: str
    timestamp: str
    verified: bool = False
    trust_score: float = 0.0
    tibet_history_length: int = 0

    def to_dict(self) -> dict:
        return {
            "did": self.did,
            "challenge": self.challenge,
            "response_hash": self.response_hash,
            "timestamp": self.timestamp,
            "verified": self.verified,
            "trust_score": self.trust_score,
            "tibet_history_length": self.tibet_history_length,
        }


class IdentityRegistry:
    """
    Registry of known device identities.

    Devices register with their JIS DID and public key.
    The registry tracks trust scores based on TIBET history.
    """

    def __init__(self):
        self.identities: dict[str, DeviceIdentity] = {}

    def register(
        self,
        device_id: str,
        capabilities: list[str] | None = None,
        public_key: bytes | None = None,
        metadata: dict | None = None,
    ) -> DeviceIdentity:
        """Register a new device identity."""
        now = datetime.now(timezone.utc).isoformat()

        # Generate DID
        did = f"jis:{device_id}"

        # Hash the public key (or generate a placeholder)
        if public_key:
            pk_hash = hashlib.sha256(public_key).hexdigest()[:32]
        else:
            pk_hash = hashlib.sha256(
                f"{device_id}:{now}:{os.urandom(16).hex()}".encode()
            ).hexdigest()[:32]

        identity = DeviceIdentity(
            device_id=device_id,
            did=did,
            public_key_hash=pk_hash,
            capabilities=capabilities or [],
            created_at=now,
            last_seen=now,
            trust_score=0.5,  # Start neutral
            metadata=metadata or {},
        )

        self.identities[did] = identity
        return identity

    def verify(self, did: str, challenge: str | None = None) -> IdentityProof:
        """
        Verify a device identity.

        In production, this would involve a cryptographic challenge-response.
        Here we verify the DID is registered and return its trust score.
        """
        now = datetime.now(timezone.utc).isoformat()
        challenge = challenge or hashlib.sha256(os.urandom(32)).hexdigest()[:16]

        if did not in self.identities:
            return IdentityProof(
                did=did,
                challenge=challenge,
                response_hash="",
                timestamp=now,
                verified=False,
                trust_score=0.0,
            )

        identity = self.identities[did]
        identity.last_seen = now

        # Simulate challenge-response
        response = hashlib.sha256(
            f"{did}:{challenge}:{identity.public_key_hash}".encode()
        ).hexdigest()[:32]

        return IdentityProof(
            did=did,
            challenge=challenge,
            response_hash=response,
            timestamp=now,
            verified=True,
            trust_score=identity.trust_score,
            tibet_history_length=0,  # Would be populated from TIBET chain
        )

    def update_trust(self, did: str, delta: float) -> float:
        """Update trust score for a device."""
        if did in self.identities:
            identity = self.identities[did]
            identity.trust_score = max(0.0, min(1.0, identity.trust_score + delta))
            return identity.trust_score
        return 0.0

    def update_network(self, did: str, ip: str, port: int, behind_nat: bool = False) -> None:
        """Update network information (informational only, not identity)."""
        if did in self.identities:
            identity = self.identities[did]
            identity.last_known_ip = ip
            identity.last_known_port = port
            identity.behind_nat = behind_nat
            identity.last_seen = datetime.now(timezone.utc).isoformat()

    def by_capability(self, capability: str) -> list[DeviceIdentity]:
        """Find devices with a specific capability."""
        return [
            d for d in self.identities.values()
            if capability in d.capabilities
        ]

    def stats(self) -> dict:
        total = len(self.identities)
        behind_nat = sum(1 for d in self.identities.values() if d.behind_nat)
        avg_trust = (
            sum(d.trust_score for d in self.identities.values()) / total
            if total > 0 else 0.0
        )
        return {
            "total_devices": total,
            "behind_nat": behind_nat,
            "average_trust": round(avg_trust, 3),
        }
