"""
tibet-overlay CLI — Decentralized Identity Overlay.

Usage::

    tibet-overlay info        Show overlay concept
    tibet-overlay demo        Interactive demo with CGNAT scenario
    tibet-overlay status      Show overlay network status
"""

import argparse
import json
import sys

from .overlay import IdentityOverlay


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 60)
    print("🌐 TIBET-OVERLAY — Decentralized Identity Overlay")
    print("=" * 60)
    print()
    print("The Problem: IPv4 exhaustion + CGNAT")
    print("  Millions of devices share the same public IP.")
    print("  Point-to-point connections break.")
    print("  Zero-trust is impossible when you can't tell who is who.")
    print()
    print("The Insight: Identity ≠ IP address")
    print("  Identity belongs to the DEVICE (cryptographic DID),")
    print("  not to the NETWORK (IP address).")
    print()
    print("How tibet-overlay works:")
    print()
    print("  [Device A: 10.0.0.x]  ---JIS DID-→  [Overlay]  ←--JIS DID---  [Device B: 10.0.0.y]")
    print("    behind CGNAT          identity =                behind CGNAT")
    print("    IP irrelevant          crypto                   IP irrelevant")
    print()
    print("  • Devices register with JIS DID (cryptographic)")
    print("  • Routing by identity, not by IP")
    print("  • TIBET tracks every identity event")
    print("  • Works across IPv4, IPv6, CGNAT, VPN, anything")
    print()
    print("Use cases:")
    print("  • IoT behind CGNAT (millions of devices, shared IPs)")
    print("  • VoIP NAT traversal (SIP + NAT = 25 years of pain)")
    print("  • Industrial networks (isolated subnets, same IP ranges)")
    print("  • Mobile devices (IP changes constantly)")
    print()
    print("=" * 60)
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print("\n🌐 tibet-overlay Demo: IoT behind CGNAT\n")

    overlay = IdentityOverlay()

    # Simulate devices behind same CGNAT
    devices = [
        ("sensor-temp-01", "203.0.113.1", 44321, ["mqtt", "coap"]),
        ("sensor-humid-02", "203.0.113.1", 44322, ["mqtt"]),
        ("camera-03", "203.0.113.1", 44323, ["rtsp", "mqtt"]),
        ("gateway-04", "198.51.100.5", 8883, ["mqtt", "http"]),
    ]

    print("  Registering devices (same public IP = CGNAT):\n")
    for dev_id, ip, port, caps in devices:
        identity = overlay.register(
            dev_id, endpoint=f"{ip}:{port}",
            capabilities=caps, ip=ip, port=port,
            behind_nat=(ip == "203.0.113.1"),
        )
        nat_label = " (behind CGNAT)" if ip == "203.0.113.1" else ""
        print(f"  📡 {dev_id}: {identity.did}{nat_label}")
        print(f"     IP: {ip}:{port} — but identity is CRYPTO, not IP")

    print("\n  Verifying identities (IP-independent):\n")
    for dev_id, _, _, _ in devices:
        did = f"jis:{dev_id}"
        proof = overlay.verify(did)
        print(f"  ✅ {did}: verified={proof.verified}, trust={proof.trust_score}")

    print("\n  Resolving endpoints by DID:\n")
    for dev_id, _, _, _ in devices:
        did = f"jis:{dev_id}"
        route = overlay.resolve(did)
        print(f"  🔗 {did} → {route.endpoint}")

    print(f"\n  Finding MQTT-capable devices:")
    mqtt_nodes = overlay.find_by_capability("mqtt")
    for n in mqtt_nodes:
        print(f"    • {n.did} ({n.endpoint})")

    status = overlay.status()
    print(f"\n  Network: {status['total_nodes']} nodes, "
          f"{status['behind_nat']} behind NAT ({status['nat_percentage']}%)")
    print(f"  TIBET tokens: {status['tibet_tokens']}")
    print()
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-overlay",
        description="Decentralized Identity Overlay Network",
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("info", help="Overlay concept overview")
    sub.add_parser("demo", help="Interactive CGNAT demo")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {"info": cmd_info, "demo": cmd_demo}
    sys.exit(commands[args.command](args))
