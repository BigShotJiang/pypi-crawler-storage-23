import logging
import sys

class CustomLogger:
    def __init__(self):
        self.logger = logging.getLogger("py_create")
        self.logger.setLevel(logging.DEBUG)

        # Prevent double logging if logger is already initialized
        if not self.logger.handlers:
            # ⚡ CONSOLE ONLY: No file creation, no LOG_DIR
            console_formatter = logging.Formatter('  %(levelname)s: %(message)s')
            console_handler = logging.StreamHandler(sys.stdout)
            
            # Set to INFO for clean UI, or DEBUG for development
            console_handler.setLevel(logging.INFO) 
            console_handler.setFormatter(console_formatter)

            self.logger.addHandler(console_handler)

    def get_logger(self):
        return self.logger

# Global Instance
logger = CustomLogger().get_logger()