"""Docstring"""
import zlib
import json
import base64
import hashlib
import tempfile
import mimetypes
from io import BytesIO
from pathlib import Path
from fastapi import UploadFile
from PIL import Image, ImageOps #type: ignore
from secrets import token_urlsafe, token_bytes
from typing import Optional, Union, Tuple
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .hyc import HybridCache
from .s3c import S3Cloud

__all__ = ["ImgHandler"]

class FileMediaProcessor:
    """Unified processor for file, media, and image operations."""

    def __init__(self, base_dir: Optional[Union[str, Path]] = None):
        self.base_dir = Path(base_dir or ".")

    # ----------------------------
    # Data utilities
    # ----------------------------
    @staticmethod
    def b64url_encode(data: bytes) -> bytes:
        return base64.urlsafe_b64encode(data).rstrip(b'=')

    @staticmethod
    def b64url_decode(data: bytes) -> bytes:
        return base64.urlsafe_b64decode(data + b'=' * (-len(data) % 4))

    @staticmethod
    def to_bytes(data: Union[str, bytes, bytearray, memoryview]) -> bytes:
        if isinstance(data, bytes):
            return data
        elif isinstance(data, str):
            return data.encode("utf-8")
        elif isinstance(data, (bytearray, memoryview)):
            return bytes(data)
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
        
    @staticmethod
    def to_str(data: Union[str, bytes, bytearray, memoryview]) -> str:
        if isinstance(data, str):
            return data
        elif isinstance(data, (bytes, bytearray, memoryview)):
            return bytes(data).decode("utf-8")
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
        
    @staticmethod
    def compressed_bytes(data: bytes) -> bytes:
        """Compress bytes using zlib."""
        return zlib.compress(data)

    @staticmethod
    def decompressed_bytes(data: bytes) -> bytes:
        """Decompress bytes using zlib."""
        return zlib.decompress(data)

    # ----------------------------
    # File/media path utilities
    # ----------------------------
    def get_file_path(self, media_type: str) -> Path:
        """Return a file path based on media type."""
        mapping = {
            "image": "image",
            "audio": "audio",
            "video": "video",
            "pdfdc": "pdfdc",
            "msexl": "msexl",
            "csvxl": "csvxl",
        }
        subdir = mapping.get(media_type, "other")
        return self.base_dir / "files" / subdir

    def get_fhdr_path(self, hdr_bname: str) -> Path:
        """Return header file path."""
        return self.base_dir / "hdrs" / f"hdf-{hdr_bname}"

    def get_temp_path(self) -> Path:
        """Return a temporary file path inside base_dir/temp."""
        temp_dir = self.base_dir / "temp"
        temp_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=temp_dir, delete=True) as temp_file:
            return Path(temp_file.name)

    @staticmethod
    def encfile_key_iv():
        """Generate random encryption key and IV."""
        return token_bytes(32), token_bytes(16)

    @staticmethod
    def write_bytes_file(file_path: Union[str, Path], content_bytes: bytes):
        """Write bytes to a file."""
        Path(file_path).write_bytes(content_bytes)

    @staticmethod
    def read_file_bytes(file_path: Union[str, Path]) -> bytes:
        """Read bytes from a file."""
        return Path(file_path).read_bytes()
    
    # ----------------------------
    # Image processing utilities
    # ----------------------------
    def process_img_file(
        self,
        file_result: dict,
        resize: bool = False,
        img_type: Optional[str] = None,
        w: int = 200,
        h: int = 200,
        q: int = 100,
    ) -> Path:
        """Process image file with optional resizing."""

        def get_resize_img(img_type, size, im):
            if img_type == "contain":
                return ImageOps.contain(im, size)
            if img_type == "cover":
                return ImageOps.cover(im, size)
            if img_type == "fit":
                return ImageOps.fit(im, size)
            if img_type == "pad":
                return ImageOps.pad(im, size, color="#f00")
            im_copy = im.copy()
            im_copy.thumbnail(size)
            return im_copy

        resize_file_path = self.get_temp_path()

        if resize:
            size = (w, h)
            im = Image.open(file_result["file"])
            resize_img = get_resize_img(img_type or "thumbnail", size, im).convert("RGB")
            resize_img.save(resize_file_path, format="JPEG", optimize=True, quality=q)
        else:
            self.write_bytes_file(resize_file_path, file_result["content_bytes"])
        return resize_file_path

    
    @staticmethod
    def encrypt(_plaintext, _key, _nonce, _tag_length=16):
        cipher = Cipher(
            algorithms.AES(_key),
            modes.GCM(_nonce, min_tag_length=_tag_length),
            backend=default_backend(),
        )
        encryptor = cipher.encryptor()
        _ciphertext = encryptor.update(_plaintext) + encryptor.finalize()
        _tag = encryptor.tag
        return _ciphertext, _tag

    @staticmethod
    def decrypt(_ciphertext, _key, _nonce, _tag):
        cipher = Cipher(
            algorithms.AES(_key), modes.GCM(_nonce, _tag), backend=default_backend()
        )
        decryptor = cipher.decryptor()
        _plaintext = decryptor.update(_ciphertext) + decryptor.finalize()
        return _plaintext

class ImgHandler:
    def __init__(
            self, 
            cache: HybridCache,
            base_dir: Optional[Union[str, Path]] = None,
            s3_cloud: Optional[S3Cloud] = None
        ):
        self.cache = cache
        self.fmp = FileMediaProcessor(base_dir)
        self.s3_cloud = s3_cloud

    def _is_img_file(self, file: UploadFile) -> bool:
        filename = file.filename
        if not filename:
            return False

        # 1. Extension check (common image formats)
        valid_extensions = (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp")
        if not filename.lower().endswith(valid_extensions):
            return False

        # 2. MIME type check
        mime_type, _ = mimetypes.guess_type(filename)
        if not mime_type or not mime_type.startswith("image/"):
            return False

        # 3. Try opening with PIL (content validation)
        try:
            file.file.seek(0)
            Image.open(file.file).verify()  # verify() checks integrity
            file.file.seek(0)  # reset again for later use
            return True
        except Exception:
            return False

    def _hdr_bname(self, file_sname):
        h = hashlib.sha256(file_sname.encode()).digest()
        return base64.urlsafe_b64encode(h[:16]).rstrip(b'=').decode()
    
    def _file_path(self, header: dict, op_file: bool = False):
        file_mtype = header["filemtype"]
        base = self.fmp.get_file_path(file_mtype)
        subdir = "enfile" if header.get("encflag") else "uefile"
        if op_file and file_mtype =="image":
            subdir = "thfile"
        return f"{base}/{subdir}/{header['filebname']}"
    
    def _write_file(self, path, content):
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self.fmp.write_bytes_file(path, content)
            return True
        except Exception:
            return False
    
    def _read_header(self, hdr_bname: str):
        path = self.fmp.get_fhdr_path(hdr_bname)
        content = self._read_file(path)
        string = self.fmp.to_str(content)
        header = json.loads(string)
        return header
    
    def _save_header(self, header, hdr_bname):
        path = self.fmp.get_fhdr_path(hdr_bname)
        print(header)
        print(path)
        content = json.dumps(header, indent=2, separators=(",", ":"), sort_keys=True)
        binary = self.fmp.to_bytes(content)
        compressed = self.fmp.compressed_bytes(binary)
        urlsafe = self.fmp.b64url_encode(compressed)
        return self._write_file(path, urlsafe)
    
    def _delete_header(self, hdr_bname):
        header_path = self.fmp.get_fhdr_path(hdr_bname)
        header_to_delete = Path(header_path)
        try:
            header_to_delete.unlink()
            return True
        except Exception as exc:
            raise Exception from exc

    def _read_file(self, file_path: Union[str, Path]):
        try:
            urlsafe = self.fmp.read_file_bytes(file_path)
            compressed = self.fmp.b64url_decode(self.fmp.to_bytes(urlsafe))
            content = self.fmp.decompressed_bytes(compressed)
            return content
        except Exception as exc:
            raise Exception("File error: File not found.") from exc
        
    def _save_file(self, content, file_bname, file_base_path, encrypt):
        subdir = "enfile" if encrypt else "uefile"
        path = f"{file_base_path}/{subdir}/{file_bname}"
        binary = self.fmp.to_bytes(content)
        compressed = self.fmp.compressed_bytes(binary)
        urlsafe = self.fmp.b64url_encode(compressed)
        return self._write_file(path, urlsafe)
        
    def _delete_file(self, file_path):
        file_to_delete = Path(file_path)
        try:
            file_to_delete.unlink()
            return True
        except Exception as exc:
            raise Exception(f"File error: File not found {exc}")
        
    def _save_optional(
            self, 
            content: Optional[bytes], 
            file_bname, 
            file_base_path, 
            subdir
        ):
        if content:
            path = f"{file_base_path}/{subdir}/{file_bname}"
            binary = self.fmp.to_bytes(content)
            compressed = self.fmp.compressed_bytes(binary)
            urlsafe = self.fmp.b64url_encode(compressed)
            return self._write_file(path, urlsafe)
        return False
    
    def _encrypt_content(
            self, 
            content: bytes,
            key_iv: Optional[Tuple[bytes, bytes]] = None
        ):
        if not key_iv:
            key, iv = self.fmp.encfile_key_iv()
        else:
            key, iv = key_iv
        compressed = self.fmp.compressed_bytes(content)
        cipher_content, tag = self.fmp.encrypt(compressed, key, iv)
        return cipher_content, tag, (key, iv)
    
    def _decrypt_content(self, cipher_content: bytes, key_dict: dict, op_prefix: str = ""):
        key = self.fmp.b64url_decode(self.fmp.to_bytes(key_dict["key"]))
        iv = self.fmp.b64url_decode(self.fmp.to_bytes(key_dict["iv"]))
        tag = self.fmp.b64url_decode(self.fmp.to_bytes(key_dict[f"{op_prefix}tag"]))
        compressed = self.fmp.decrypt(cipher_content, key, iv, tag)
        content = self.fmp.decompressed_bytes(compressed)
        return content
    
    def _optional_content(self, file_mtype, content):
        op_content: Optional[bytes] = None
        op_prefix = ""
        if file_mtype == "image":
            op_prefix = "th"
            file_obj = BytesIO(content)
            processed_path = self.fmp.process_img_file(
                {"file": file_obj, "content_bytes": content}, 
                True
            )
            op_content = self.fmp.read_file_bytes(processed_path)
            Path(processed_path).unlink(missing_ok=True)
        return op_content, op_prefix


    @property
    def file_content(self):
        @self.cache.cache(expire = 300, is_redis=False)
        def _file_content(file_path):
            return self._read_file(file_path)
        return _file_content
    
    @property
    def file_content_op(self):
        @self.cache.cache(expire = 300, is_redis=True)
        def _file_content_op(file_path):
            return self._read_file(file_path)
        return _file_content_op
    
    def common_result(
            self,
            file_result,
            resp_type = None
        ) -> list:
        """Doc String"""
        content_bytes = file_result["content_bytes"]
        temp_file_path = self.fmp.get_temp_path()
        self.fmp.write_bytes_file(temp_file_path, content_bytes,)
        # Return a FileResponse
        media_type = (
            "application/octet-stream"
            if resp_type == "stream"
            else file_result["content_type"]
        )
        file_name = file_result["file_name"] if resp_type == "stream" else None
        return [
            temp_file_path,
            media_type,
            file_name,
        ]

    def upload_img(
        self,
        user_id: str,
        file: UploadFile,
        given_name: str,
        encrypt: bool = False,
        old_url: Optional[str] = None,
    ):
        if not self._is_img_file(file):
            raise Exception(f"File upload failed")
        file_oname = file.filename or "unknown"
        file_bname = token_urlsafe(8)
        file_sname = f"{given_name}.{user_id}" 
        file_ctype = file.content_type
        file_mtype = "image"

        file_base_path = self.fmp.get_file_path(file_mtype)
        content = file.file.read()

        hdr_bname = self._hdr_bname(file_sname)
        # Process media if needed
        op_content, op_prefix = self._optional_content(file_mtype, content)
        b64_str_op = base64.b64encode(op_content).decode("utf-8") if op_content else None
        # Encryption
        header = {
            "fileoname": file_oname,
            "filesname": file_sname,
            "filebname": file_bname,
            "filemtype": file_mtype,
            "filectype": file_ctype,
            "basepath": str(file_base_path),
            "encflag": encrypt,
            "opprefix": op_prefix,
            "keydict": {},
        }
        if encrypt:
            content, tag, key_iv = self._encrypt_content(content)
            key, iv = key_iv
            key_dict = {
            "key": self.fmp.to_str(self.fmp.b64url_encode(key)), 
            "iv": self.fmp.to_str(self.fmp.b64url_encode(iv))
            }
            key_dict["tag"] = self.fmp.to_str(self.fmp.b64url_encode(tag))
            if op_content:
                op_content, op_tag, _ = self._encrypt_content(op_content, key_iv)
                key_dict[f"{op_prefix}tag"] = self.fmp.to_str(self.fmp.b64url_encode(op_tag))
            header["keydict"] = key_dict
        
        if self._save_header(header, hdr_bname):
            if self._save_file(content, file_bname, file_base_path, encrypt):
                
                if self._save_optional(op_content, file_bname, file_base_path, f"{op_prefix}file"):
                    print("*****************************************")
                    if b64_str_op and self.s3_cloud:
                        if old_url:
                            img_url = self.s3_cloud.update_image(old_url, b64_str_op)
                            return {"img_name": given_name, "img_url": img_url}
                        img_url = self.s3_cloud.upload_image(b64_str_op)
                        return {"img_name": given_name, "img_url": img_url}
                    return {"img_name": given_name, "img_url": None}
                file_path = self._file_path(header)
                self._delete_file(file_path)
            self._delete_header(hdr_bname)
        raise Exception("File upload failed")
    
    
    def load_img(
            self,
            user_id: str,
            given_name: str,
            op_file: bool = False
        ):
        file_sname = f"{given_name}.{user_id}" 
        hdr_bname = self._hdr_bname(file_sname)
        header = self._read_header(hdr_bname)
        file_path = self._file_path(header, op_file)
        content = self.file_content_op(file_path) if op_file else self.file_content(file_path)
        op_prefix = header.pop("opprefix") if op_file else ""
        if header.get("encflag"):
            content = self._decrypt_content(content, header.pop("keydict"), op_prefix)
        return {
            "file_type": header["filemtype"],
            "file_name": header["fileoname"],
            "content_type": header["filectype"],
            "content_bytes": content,
            "file": BytesIO(content),
        }
        
    def delete_img(
            self,
            user_id: str,
            given_name: str,
            img_url: Optional[str] = None
        ) -> bool:
        file_sname = f"{given_name}.{user_id}" 
        hdr_bname = self._hdr_bname(file_sname)
        header = self._read_header(hdr_bname)
        file_path = self._file_path(header)
        delete_file = self._delete_file(file_path)
        
        if not delete_file:
            return False
        if header.get("opprefix")=="th":
            file_op_path = self._file_path(header, op_file=True)
            self._delete_file(file_op_path)
        delete_header = self._delete_header(hdr_bname)
        if not delete_header:
            return False
        if img_url and self.s3_cloud:
            self.s3_cloud.delete_image(img_url)
        return True