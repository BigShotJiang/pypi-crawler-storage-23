"""Docstring"""
from typing import List, Optional, Optional

from .aus import JtiCore

__all__ = ["UsrAuth"]

class UsrAuth:
    def __init__(
            self,  
            jtis: Optional[JtiCore] = None,
        ):
        self.jtis = jtis or JtiCore()
        
    def active_user(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.jtis.verify_token(
            access_token, required_roles, required_scopes, required_permissions
        )