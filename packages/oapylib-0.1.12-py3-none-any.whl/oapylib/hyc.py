"""Docstring"""
import json
import pickle
import hashlib
import inspect
from pathlib import Path
from functools import wraps
from typing import Optional, Union, Any
from joblib import Memory

__all__ = ["HybridCache"]

class HybridCache:
    def __init__(self, redis: Optional[Any] = None, cache_dir: Optional[Union[str, Path]] = None):
        self.redis = redis.client if redis else None
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.memory = Memory(location=str(self.cache_dir), verbose=0) if self.cache_dir else None

        try:
            if self.redis is not None:
                self.redis.ping()
        except Exception:
            self.redis = None

    def _make_key(self, func, args, kwargs):
        raw = {"func": func.__name__, "args": args, "kwargs": kwargs}
        raw_str = json.dumps(raw, sort_keys=True, default=str)
        return hashlib.sha256(raw_str.encode()).hexdigest()

    def set(self, key, value, expire=None, is_redis=False):
        if self.redis and is_redis:
            self.redis.set(key, pickle.dumps(value), ex=expire)
        elif self.memory and self.cache_dir is not None:
            file_path = self.cache_dir / f"{key}.pkl"
            with file_path.open("wb") as f:
                pickle.dump(value, f)

    def get(self, key, is_redis=False):
        if not is_redis:
            return self.get_pkl(key)
        data = self.get_red(key)
        return data if data is not None else self.get_pkl(key)

    
    def get_red(self, key):
        if not self.redis:
            return None
        data = self.redis.get(key)
        return pickle.loads(data) if data is not None else None

    
    def get_pkl(self, key):
        if not self.memory or self.cache_dir is None:
            return None
        file_path = self.cache_dir / f"{key}.pkl"
        if not file_path.exists():
            return None
        with file_path.open("rb") as f:
            return pickle.load(f)

    def clear(self):
        if self.redis:
            self.redis.flushdb()
        elif self.memory and self.cache_dir is not None:
            self.memory.clear(warn=False)
            for f in self.cache_dir.glob("*.pkl"):
                f.unlink()


    def cache(self, expire=None, is_redis=False):
        def decorator(func):
            if inspect.iscoroutinefunction(func):
                @wraps(func)
                async def async_wrapper(*args, **kwargs):
                    key = self._make_key(func, args, kwargs)
                    result = self.get(key, is_redis=is_redis)
                    if result is not None:
                        return result
                    result = await func(*args, **kwargs)
                    self.set(key, result, expire=expire, is_redis=is_redis)
                    return result
                return async_wrapper
            else:
                @wraps(func)
                def sync_wrapper(*args, **kwargs):
                    key = self._make_key(func, args, kwargs)
                    result = self.get(key, is_redis=is_redis)
                    if result is not None:
                        return result
                    result = func(*args, **kwargs)
                    self.set(key, result, expire=expire, is_redis=is_redis)
                    return result
                return sync_wrapper
        return decorator

