"""Docstring"""
from enum import Enum
from pathlib import Path
from functools import lru_cache
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import  APIRouter, Depends, Request, HTTPException, status, Query
from sqlmodel import SQLModel, Session, Field, MetaData, Column, TEXT, ARRAY, func

import base64
from time import time
from datetime import datetime, timezone
from secrets import token_urlsafe, choice, randbelow
from typing import List, Dict, Any, Annotated, Optional, Union, Tuple

from hashlib import sha256
from base64 import urlsafe_b64encode
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from pydantic_settings import BaseSettings, SettingsConfigDict

from .jwt import JWT
from .aus import JtiCore
from .ous import SesCode
from .dbs import DbsMsvc

__all__ = ["AORS"]

class OidConf:
    class Base(BaseSettings):
        issuer: Optional[str] = None

        authorization_endpoint: Optional[str] = None
        token_endpoint: Optional[str] = None
        userinfo_endpoint: Optional[str] = None
        revocation_endpoint: Optional[str] = None
        jwks_uri: Optional[str] = None
        cert_uri: Optional[str] = None

        scopes_supported: List[str] = Field(default_factory=lambda: ["openid", "email", "profile"])
        response_types_supported: List[str] = Field(default_factory=lambda: ["code", "token", "id_token", "none"])
        subject_types_supported: List[str] = Field(default_factory=lambda: ["public"])
        id_token_signing_alg_values_supported: List[str] = Field(default_factory=lambda: ["RS256"])
        claims_supported: List[str] = Field(
            default_factory=lambda: ["aud", "email", "email_verified", "exp", "family_name", "given_name", "iat", "iss", "name", "picture", "sub"]
        )
        code_challenge_methods_supported: List[str] = Field(default_factory=lambda: ["plain", "S256"])
        grant_types_supported: List[str] = Field(default_factory=lambda: ["authorization_code"])

    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        oid_env: Optional[Union[str, Path]] = None,
    ):
        class Deploy(BaseSettings):
            oid_env: str = ".env.oawe"

            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        self.env_path = self.resolve_path(oid_env, Deploy().oid_env)

    @property
    def config(self):
        return self.get_config(self.env_path)

    @classmethod
    @lru_cache
    def get_config(
        cls,
        oid_env: Optional[Union[str, Path]] = None,
    ):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(oid_env, ".env.oawe"),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        return Config()

    @staticmethod
    def resolve_path(
        path: Optional[Union[str, Path]] = None,
        default: Optional[str] = None,
    ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default

class OuthSchemas:
    class BaseMeta(SQLModel):
        @staticmethod
        def utc_now() -> datetime:
            """Returns current UTC time."""
            return datetime.now(timezone.utc)
        created_at: datetime = Field(default_factory=utc_now)
        updated_at: datetime = Field(
            default_factory=utc_now,
            sa_column_kwargs={"onupdate": func.now()}
        )

    class OuthCode(SQLModel):
        client_id: str = Field()
        redirect_uri: str = Field()
        response_type: str = Field(default="code")
        scope: str = Field()
        access_type: str = Field(default="online")
        nonce: Optional[str] = Field(default=None)

    class OuthToken(SQLModel):
        code: str = Field()
        grant_type: str = Field(default="authorization_code")
        client_id: str = Field()
        client_secret: str = Field()
        redirect_uri: str = Field()

    class TokenUser(SQLModel):
        id_token: str = Field()

    class ClientBase(SQLModel):
        cltype: str = Field(nullable=False, default="webapp")
        scopes: List[str] = Field(
            default_factory=lambda: ["openid", "email", "profile"],
            sa_column=Column(ARRAY(TEXT))
        )
        redirect_uris: List[str] = Field(
            default_factory=list,
            sa_column=Column(ARRAY(TEXT))
        )

    class ClientPrivate(ClientBase):
        id: str = Field()
        name: str = Field()
        owner: str = Field()
        issuer: Optional[str] = Field(default=None)
        client_id: Optional[str] = Field(default=None)
        client_secret: Optional[str] = Field(default=None)

    class ClientRegister(ClientBase):
        name: str = Field()
        owner: str = Field()

    class ClientCreate(ClientBase):
        name: str = Field()
        owner: str = Field()
        secret: Optional[str] = Field(default=None)
        crypted: Optional[str] = Field(default=None)

    class ClientQuery(SQLModel):
        cltype: str = Field()
        owner: str = Field()
        name: Optional[str] = Field(default=None)

    class ClientUpdate(SQLModel):
        name: Optional[str] = Field(default=None)
        redirect_uris: Optional[List[str]] = Field(default=None)
        scopes: Optional[List[str]] = Field(default=None)
        is_enabled: Optional[bool] = Field(default=None)

    def __init__(self, basemeta: MetaData):
        class Client(self.ClientBase, self.BaseMeta, table = True):
            metadata = basemeta
            @staticmethod
            def uniq_id():
                """Doc String"""
                random_number = randbelow(10**12 - 10**11) + 10**11
                random_string = token_urlsafe(24)
                client_id = f"{random_number}-{random_string}"
                return client_id
            
            id: str = Field(default_factory=uniq_id, index=True, primary_key=True)
            name: str = Field(nullable=False, unique=True, index=True)
            owner: str = Field(nullable=False, index=True)
            secret: str = Field()
            crypted: str = Field()
            is_enabled: bool = Field(default=False)

            def verify(self, secret: str):
                return self.secret == self.hashed(secret)
            
            @staticmethod
            def hashed(secret: Optional[str] = None):
                if secret is not None:
                    h = sha256(str(secret).encode()).digest()
                    return urlsafe_b64encode(h).rstrip(b'=').decode()
                return token_urlsafe(32)
        self.Client = Client

class OuthCore:

    def __init__(
            self,
            client_key: rsa.RSAPrivateKey,
            outhid_keys: Dict[str, rsa.RSAPrivateKey],
            outhid_jwks: List[Any],
            outhid_cert: Dict[str, Any],
            outhid_algo: str = "RS256",
            jtis: Optional[JtiCore] = None,
            scod: Optional[SesCode] = None,
            outhid_oidc: Optional[Any] = None,
        ):
        self.jtis = jtis or JtiCore()
        self.scod = scod or SesCode()
        self.client_key = client_key
        self.outhid_kid = choice(list(outhid_keys.keys()))
        self.outhid_key = outhid_keys[self.outhid_kid]
        self.outhid_algo = outhid_algo
        self.outhid_jwks = outhid_jwks
        self.outhid_cert = outhid_cert
        self.outh_oidc = outhid_oidc or OidConf().config

    @property
    def public_oidc(
        self,
    ) -> Dict[str, Any]:
        if not self.outh_oidc:
            return {}
        return self.outh_oidc.model_dump(exclude_none=True)
    
    @property
    def public_jwks(self):
        return {"keys": self.outhid_jwks}

    @property
    def public_cert(self):
        return self.outhid_cert
    
    def active_user(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.jtis.verify_token(
            access_token, required_roles, required_scopes, required_permissions
        )
    
    def encrypt_secret(
            self, 
            uniq_secret: str, 
            key: Optional[rsa.RSAPublicKey] = None,
        ) -> str:
        
        key = key or self.client_key.public_key()
        hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
        secret_bytes = uniq_secret.encode("utf-8")
        cipher_bytes = key.encrypt(
            secret_bytes,
            padding.OAEP(
                mgf=padding.MGF1(hash_algo()),
                algorithm=hash_algo(),
                label=b"secure_secret",
            ),
        )
        return urlsafe_b64encode(cipher_bytes).decode("utf-8")

    def decrypt_secret(
            self, 
            ciphersecret: str, 
            key: Optional[rsa.RSAPrivateKey] = None
        ) -> str:
        key = key or self.client_key
        hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
        cipher_bytes = base64.urlsafe_b64decode(ciphersecret.encode("utf-8"))
        cek_bytes = key.decrypt(
            cipher_bytes,
            padding.OAEP(
                mgf=padding.MGF1(hash_algo()),
                algorithm=hash_algo(),
                label=b"secure_secret",
            ),
        )
        return cek_bytes.decode("utf-8")
    
    def outh_code(
            self,
            user_id: str, 
            scope: Optional[str] = None,
            nonce: Optional[str] = None
        ) -> str:
        return self.scod.create_session(user_id, scope, nonce)
    
    def verify_code(
            self,
            user_id: str,
            code: str, 
            delete_session: bool=False
        ) -> Tuple[bool, Optional[str], Optional[str]]:
        return self.scod.verify_code(user_id, code, delete_session)
    
    def outh_token(
            self, 
            payload: dict,
        ):
        now = int(time())
        exp = now + 3600
        payload.update({
            "iat": now,
            "nbf": now,
            "exp": exp,
        })
        headers = {"kid": self.outhid_kid} if self.outhid_kid else None
        return {"id_token": JWT.encode(
            payload, 
            key=self.outhid_key, 
            algorithm=self.outhid_algo,
            headers=headers,
            is_pkcs=True
        )}

# --- Custom Exceptions ---
class ServiceError(Exception): pass
class UserNotFoundError(ServiceError): pass
class UnauthorizedClientError(ServiceError): pass
class ClientConflictError(ServiceError): pass
class ClientNotFoundError(ServiceError): pass
class ClientDisabledError(ServiceError): pass
class InvalidResponseTypeError(ServiceError): pass
class InvalidAccessTypeError(ServiceError): pass
class InvalidRedirectUriError(ServiceError): pass
class InvalidGrantTypeError(ServiceError): pass
class InvalidAuthCodeError(ServiceError): pass
class ClientVerificationError(ServiceError): pass
class ClientPromotionError(ServiceError): pass
class InsufficientPriviledgeError(ServiceError): pass


class AorSrvc:
   
    def __init__(
        self,
        outh_obj: OuthCore,
        crud_user_obj: DbsMsvc,
        crud_client_obj: DbsMsvc,
        issuer: Optional[str] = None,
    ):
        self.crud_user = crud_user_obj
        self.crud_client = crud_client_obj
        self.outh = outh_obj
        self.issuer = issuer or self.outh.outh_oidc.issuer

    # --- Private Helpers ---
    async def _ensure_authorized(self, session: Session, sub: str) -> Any:
        agent = await self.crud_user.read_byid(session=session, id=sub)
        if not(agent and agent.id == sub and (agent.is_super or agent.is_admin)):
            raise InsufficientPriviledgeError("User do not have enough priviledge")
        return agent

    def _to_private(self, client: Any) -> OuthSchemas.ClientPrivate:
        """Convert client model to private schema with decrypted secret."""
        client_private = OuthSchemas.ClientPrivate.model_validate(client)
        client_private.issuer = self.issuer
        client_private.client_id = f"{str(client.id)}-{self.issuer}"
        client_private.client_secret = self.outh.decrypt_secret(client.crypted)
        return client_private

    # --- Private Helpers ---
    async def _get_user(
            self, 
            session: Session, 
            sub: str
        ) -> Any:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not (user and user.id == sub):
            raise UserNotFoundError("Logged in user does not exist")
        return user

    async def _get_client(
            self, 
            session: Session,
            client_id: str, 
            redirect_uri: str
        ) -> Any:
        parts = client_id.rsplit("-", 1)
        if len(parts) != 2 or parts[-1] != self.issuer:
             raise ClientNotFoundError("Auth client does not exist")
        id = parts[0]
        client = await self.crud_client.read_byid(session=session, id=id)
        if not (client and client.id == id):
            raise ClientNotFoundError("Auth client does not exist")
        if not client.is_enabled:
            raise ClientDisabledError("Auth client is disabled")
        owner = await self.crud_user.read_byid(session=session, id=client.owner)
        if not (owner and owner.id == client.owner and owner.is_client):
            raise UnauthorizedClientError("Client owner does not exists")
        if not (owner.is_active and owner.is_enabled):
            raise UnauthorizedClientError("Client owner is not active or enabled")
        if redirect_uri not in client.redirect_uris:
            raise InvalidRedirectUriError("Invalid redirect URI")
        return client

    def _build_payload(
        self,
        scope: Optional[str],
        user: Any,
        client_id: str,
        issuer: Optional[str] = None,
        nonce: Optional[str] = None,
    ) -> dict:
        payload: dict = {"aud": client_id}
        scope = scope or "openid"
        scopes = scope.split()

        if "email" in scopes:
            payload["email"] = user.email
            payload["email_verified"] = user.email_verified
        if "openid" in scopes:
            payload["sub"] = user.id
        if "profile" in scopes:
            payload.update({
                "name": user.name,
                "family_name": user.family_name,
                "given_name": user.given_name,
                "picture": user.picture,
            })
        if issuer:
            payload["iss"] = issuer
        if nonce:
            payload["nonce"] = nonce
        return payload

    # --- Public Methods ---
    async def useractive(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.outh.active_user(
            access_token, required_roles, required_scopes, required_permissions
        )
    
    async def outh_code(
        self,
        session: Session,
        sub: str,
        data: OuthSchemas.OuthCode
    ) -> str:
        user = await self._get_user(session, sub)
        data = OuthSchemas.OuthCode.model_validate(data)
        if data.response_type != "code":
            raise InvalidResponseTypeError("Invalid requested response type")
        elif data.access_type not in ["online", "offline"]:
            raise InvalidAccessTypeError("Invalid requested response type")
        client = await self._get_client(
                session, 
                data.client_id, 
                data.redirect_uri
            )
        # Intersect requested scopes with client scopes
        requested_scopes = set(data.scope.split())
        allowed_scopes = requested_scopes & set(client.scopes)
        scope = " ".join(allowed_scopes)
        return self.outh.outh_code(user.id, scope, data.nonce) 

    async def outh_token(
        self,
        session: Session,
        sub: str,
        data: OuthSchemas.OuthToken,
    ) -> OuthSchemas.TokenUser:
        user = await self._get_user(session, sub)
        data = OuthSchemas.OuthToken.model_validate(data)
        if data.grant_type != "authorization_code":
            raise InvalidGrantTypeError("Invalid requested response type")
        client = await self._get_client(
                session, 
                data.client_id, 
                data.redirect_uri
            )
        verify_code, scope, nonce = self.outh.verify_code(
                user.id,
                data.code, 
                True
            )
        if not verify_code:
            raise InvalidAuthCodeError("Invalid authorization code")
        
        if not client.verify(data.client_secret):
            raise ClientVerificationError("Client verification failed")
        payload = self._build_payload(
                scope, 
                user, 
                data.client_id,  
                self.issuer, 
                nonce
            )
        user_token = self.outh.outh_token(payload)
        return OuthSchemas.TokenUser.model_validate(user_token)
    
    # --- Public Methods ---
    async def create_client(
        self,
        session: Session,
        sub: str,
        data: OuthSchemas.ClientCreate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_uniq(
            session=session, 
            field="name", 
            value=data.name
        )
        if client:
            raise ClientConflictError("Client already exists")
        data = OuthSchemas.ClientCreate.model_validate(data)
        user = await self.crud_user.read_byid(session=session, id=data.owner)
        if user is None:
            raise UnauthorizedClientError("Client owner does not exist")
        if not (user.is_active and user.is_enabled):
            raise UnauthorizedClientError("Client owner is not active or enabled")
        if not user.is_client:
            user = await self.crud_user.update(
                session=session,
                id=data.owner,
                data={"is_client": True}
            )
            if not (user and user.is_client):
                raise ClientPromotionError("Failed to promote user to client")
        secret = self.crud_client.model.hashed()
        data.secret = self.crud_client.model.hashed(secret)
        data.crypted = self.outh.encrypt_secret(secret)
        data = OuthSchemas.ClientCreate.model_validate(data)
        client = await self.crud_client.create(session=session, data=data)
        return self._to_private(client)

    async def read_client(
        self,
        session: Session,
        sub: str,
        query: Optional[OuthSchemas.ClientQuery] = None,
        offset: int = 0,
        limit: int = 100,
        query_type: Optional[str] = None,
    ) -> List[OuthSchemas.ClientPrivate]:
        await self._ensure_authorized(session, sub)
        query_dict = query.model_dump(exclude_unset=True, exclude_none=True) if query else {}
        query = OuthSchemas.ClientQuery.model_validate(query_dict)
        results = await self.crud_client.read(
            session=session,
            offset=offset,
            limit=limit,
            query=query,
            query_type=query_type,
        )
        return [self._to_private(client) for client in results]

    async def read_client_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        return self._to_private(client)
    
    async def read_client_byname(
        self,
        session: Session,
        sub: str,
        name: str,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_uniq(
            session=session, field="name", value=name
        )
        if not client:
            raise ClientNotFoundError("Client not found")
        return self._to_private(client)
    
    async def replace_client(
        self,
        session: Session,
        sub: str,
        id: str,
        data: OuthSchemas.ClientCreate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        data = OuthSchemas.ClientCreate.model_validate(data)
        secret = self.crud_client.model.hashed()
        data.secret = self.crud_client.model.hashed(secret)
        data.crypted = self.outh.encrypt_secret(secret)
        data = OuthSchemas.ClientCreate.model_validate(data)
        data = OuthSchemas.ClientCreate.model_validate(data)
        updated = await self.crud_client.update(session=session, id=id, data=data) or client
        return self._to_private(updated)

    async def update_client(
        self,
        session: Session,
        sub: str,
        id: str,
        data: OuthSchemas.ClientUpdate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        data = OuthSchemas.ClientUpdate.model_validate(data)
        updated = await self.crud_client.update(session=session, id=id, data=data) or client
        return self._to_private(updated)

    async def delete_client_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> bool:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        return await self.crud_client.delete_byid(session=session, id=id)
    
    async def outh_jwks(self) -> Dict[str, Any]:
        return self.outh.public_jwks
    
    async def outh_cert(self) -> Dict[str, Any]:
        return self.outh.public_cert
    
    async def outh_oidc(self) -> Dict[str, Any]:
        return self.outh.public_oidc


class AorResp:
    DEFAULT_CRUD_ROLES = {
        "auth_user": ["guest", "user", "admin"],
        "outh_user": ["user", "admin"],
        "outh_admin": ["admin"],
    }

    DEFAULT_CRUD_SCOPES = {
        "auth_user": ["outh"],
        "outh_user": ["outh"],
        "outh_admin": ["outh"],
    }

    DEFAULT_CRUD_PERMISSIONS = {
        "auth_user": ["read", "write"],
        "outh_user": ["read", "write"],
        "outh_admin": ["read", "write"]
    }

    DEFAULT_IS_PROTECTED = {
        "auth_user": False,
        "outh_user": True,
        "outh_admin": True,
    }
    def __init__(
        self,
        service_obj: AorSrvc,
        crud_roles: Optional[Dict[str, List[str]]] = None,
        crud_scopes: Optional[Dict[str, List[str]]] = None,
        crud_permissions: Optional[Dict[str, List[str]]] = None,
        is_protected: Optional[Dict[str, bool]] = None
    ):
        self.service = service_obj
        self.security = HTTPBearer(auto_error=False)
        self.crud_roles = crud_roles or self.DEFAULT_CRUD_ROLES
        self.crud_scopes = crud_scopes or self.DEFAULT_CRUD_SCOPES
        self.crud_permissions = crud_permissions or self.DEFAULT_CRUD_PERMISSIONS
        self.is_protected = is_protected or self.DEFAULT_IS_PROTECTED

    
    def user(self, method: Optional[str] = None):
        if method is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Error: user not authorised",
            )
        is_protected = self.is_protected.get(method, False)
        required_roles = self.crud_roles.get(method)
        required_scopes= self.crud_scopes.get(method)
        required_permissions = self.crud_permissions.get(method)
        async def loginuser(creds: HTTPAuthorizationCredentials = Depends(self.security)):
            try:
                if not is_protected:
                        return "public"
                elif creds is None:
                    raise HTTPException(status_code=401, detail="Missing credentials")
                access_token = creds.credentials
                sub = await self.service.useractive(access_token, required_roles, required_scopes, required_permissions)
                return sub
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Error: User not Found {exc}",
                ) from exc
        return loginuser
    
    @property
    def post_code(self):
        async def outh_code(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_user"))],
            data: Annotated[OuthSchemas.OuthCode, Depends()]
        ) -> str:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.outh_code(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid request: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return outh_code

    @property
    def post_token(self):
        async def outh_token(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_user"))],
            data: Annotated[OuthSchemas.OuthToken, Depends()]
        ) -> OuthSchemas.TokenUser:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.outh_token(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=f"Invalid request: {exc}")
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return outh_token
    
    @property
    def get_oidc(self):
        async def outh_oidc(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
        ) -> Dict[str, Any]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                return await self.service.outh_oidc()
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return outh_oidc

    @property
    def get_jwks(self):
        async def outh_jwks(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
        ) -> Dict[str, Any]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                return await self.service.outh_jwks()
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return outh_jwks

    @property
    def get_cert(self):
        async def outh_cert(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
        ) -> Dict[str, Any]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                return await self.service.outh_cert()
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return outh_cert

    @property
    def post_client(self):
        async def create_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            data: Annotated[OuthSchemas.ClientCreate, Depends()]
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.create_client(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid client data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return create_client

    @property
    def get_client(self):
        async def read_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            query: Annotated[Optional[OuthSchemas.ClientQuery], Depends(OuthSchemas.ClientQuery)] = None,
            offset: int = 0,
            limit: Annotated[int, Query(le=100)] = 100,
            query_type: Optional[str] = None,
        ) -> List[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.read_client(
                    session=db_session, sub=user,
                    offset=offset, limit=limit,
                    query=query, query_type=query_type
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client

    @property
    def get_client_byid(self):
        async def read_client_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_client_byid(session=db_session, sub=user, id=id)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client_byid
    
    @property
    def get_client_byname(self):
        async def read_client_byname(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            name: str,
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_client_byname(session=db_session, sub=user, name=name)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client_byname

    @property
    def put_client(self):
        async def replace_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
            data: Annotated[OuthSchemas.ClientCreate, Depends()],
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.replace_client(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid client data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return replace_client

    @property
    def patch_client(self):
        async def update_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
            data: Annotated[OuthSchemas.ClientUpdate, Depends()],
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.update_client(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid client update: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return update_client

    @property
    def delete_client(self):
        async def delete_client_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
        ) -> JSONResponse:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                deleted = await self.service.delete_client_byid(session=db_session, sub=user, id=id)
                if not deleted:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return JSONResponse(content={"removed": True}, status_code=200)
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return delete_client_byid

        
class AorMsvc:
    def __init__(
        self,
        response_obj: "AorResp",
        prefix: Optional[str] = None,
        tags: List[Union[str, Enum]] | None = None,
    ):
        self.router = APIRouter(
            prefix=prefix or "",
            tags=tags,
            responses={404: {"description": "Not found"}},
            dependencies=[Depends(response_obj.security)]
        )
        self.response = response_obj
        self.register_routes()

    def register_routes(self):
        # OAuth routes
        @self.router.post("/outh/auth")
        async def post_code(_resp=Depends(self.response.post_code)):
            return _resp

        @self.router.post("/outh/token")
        async def post_token(_resp=Depends(self.response.post_token)):
            return _resp
        
        @self.router.get("/outh/oidc")
        async def get_oidc(_resp=Depends(self.response.get_oidc)):
            return _resp

        @self.router.get("/outh/jwks")
        async def get_jwks(_resp=Depends(self.response.get_jwks)):
            return _resp

        @self.router.get("/outh/cert")
        async def get_cert(_resp=Depends(self.response.get_cert)):
            return _resp

        # Admin client routes
        @self.router.post("/admin/client")
        async def post_client(_resp=Depends(self.response.post_client)):
            return _resp

        @self.router.get("/admin/client")
        async def get_client(_resp=Depends(self.response.get_client)):
            return _resp

        @self.router.get("/admin/client/id/{id}")
        async def get_client_byid(_resp=Depends(self.response.get_client_byid)):
            return _resp
        
        @self.router.get("/admin/client/name/{name}")
        async def get_client_byname(_resp=Depends(self.response.get_client_byname)):
            return _resp

        @self.router.put("/admin/client/{id}")
        async def put_client(_resp=Depends(self.response.put_client)):
            return _resp

        @self.router.patch("/admin/client/{id}")
        async def patch_client(_resp=Depends(self.response.patch_client)):
            return _resp

        @self.router.delete("/admin/client/{id}")
        async def delete_client(_resp=Depends(self.response.delete_client)):
            return _resp
        
class AORS:
    AorSrvc = AorSrvc
    AorResp = AorResp
    AorMsvc = AorMsvc
    OidConf = OidConf
    OuthCore = OuthCore
    OuthSchemas = OuthSchemas