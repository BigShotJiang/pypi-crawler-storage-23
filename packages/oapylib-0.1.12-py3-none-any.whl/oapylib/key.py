"""Docstring"""
import json
import math
import base64
import secrets
import hashlib
from enum import Enum
from pathlib import Path
from functools import lru_cache
from dataclasses import dataclass
from typing import Any, Optional, Union, Dict
from datetime import datetime, timezone, timedelta
from pydantic_settings import BaseSettings, SettingsConfigDict

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.utils import int_to_bytes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization, hmac
from cryptography.hazmat.primitives.asymmetric import padding, rsa, ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature

__all__ = ["KEY"]

class KeyConf:
    class Base(BaseSettings):
        # Base config for JWT keys
        jwt_access_key: Optional[str] = None
        jwt_access_pass: Optional[str] = None
        jwt_refresh_key: Optional[str] = None
        jwt_refresh_pass: Optional[str] = None

        jwt_signing_key0: Optional[str] = None
        jwt_passkey_key0: Optional[str] = None
        jwt_signing_key1: Optional[str] = None
        jwt_passkey_key1: Optional[str] = None
        
        cln_encrypt_key: Optional[str] = None
        cln_encrypt_pass: Optional[str] = None
        
    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        key_env: Optional[Union[str, Path]] = None,
        key_secrets: Optional[Union[str, Path]] = None,
    ):

        class Deploy(BaseSettings):
            key_env: str = ".env.kepa"
            key_secrets: str = "."
            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env, ".env.dep"),
                env_file_encoding="utf-8",
                extra="ignore",
            )
        self.env_path = self.resolve_path(key_env, Deploy().key_env)
        self.secrets_path = self.resolve_path(key_secrets, Deploy().key_secrets)

    @property
    def config(self):
        return self.get_config(self.env_path, self.secrets_path)

    @classmethod
    @lru_cache
    def get_config(
        cls, 
        key_env: Optional[Union[str, Path]] = None, 
        key_secrets: Optional[Union[str, Path]] = None,
    ):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(key_env, ".env.kepa"),
                env_file_encoding="utf-8",
                extra="ignore",
                secrets_dir=cls.resolve_path(key_secrets, ".")
            )
        return Config()

    @staticmethod
    def resolve_path(
        path: Optional[Union[str, Path]] = None,
        default: Optional[str] = None,
    ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default

@dataclass
class SymKeys:
    class KeySize(Enum):
        KEY16 = 16
        KEY32 = 32
        KEY64 = 64
        KEY128 = 128
        KEY256 = 256

    keygen : Any
    keytyp : str
    length : int

    def write(self, file_name, file_path):
        file_path = Path(file_path)
        key_type = self.keytyp
        file_path = file_path / f"{file_name}"

        header = f"-----BEGIN {key_type.upper()} KEYS-----\n"
        footer = f"-----END {key_type.upper()} KEYS-----"

        lines = [header]
        for i, key in enumerate(self.keygen, start=1):
            if key_type == "byte":
                encoded = base64.b64encode(key).decode("utf-8").rstrip("=\n")
            else:
                encoded = key
            lines.append(f"{key_type}-key-{i}  {encoded}\n")
        lines.append(footer)

        file_path.write_text("".join(lines), encoding="utf-8")
        return str(file_path)
    
    @classmethod
    def byte(cls, key_size=KeySize.KEY128, num_key=1):
        key_gen = (secrets.token_bytes(key_size.value) for _ in range(num_key))
        return cls(key_gen, "byte", num_key)
    
    @classmethod
    def hex(cls, key_size = KeySize.KEY128, num_key=1):
        key_gen = (secrets.token_hex(key_size.value) for _ in range(num_key))
        return cls(key_gen, "hex", num_key)

    @classmethod
    def urlsafe(cls, key_size = KeySize.KEY128, num_key=1):
        key_gen = (secrets.token_urlsafe(key_size.value) for _ in range(num_key))
        return cls(key_gen, "urlsafe", num_key)
    
    @classmethod
    def file(cls, file_path, file_name):
        def _padding(s):
            return s + "=" * (-len(s) % 4)

        file_path = Path(file_path) / file_name
        lines = file_path.read_text(encoding="utf-8").strip().splitlines()

        key_type = lines[0].split()[1].lower()
        keys_raw = [line.split()[1].strip() for line in lines[1:-1]]

        if key_type == "byte":
            key_gen = (
                base64.b64decode(_padding(k)) for k in keys_raw
            )
        else:
            key_gen = (k.encode("utf-8") for k in keys_raw)

        return cls(key_gen, key_type, len(keys_raw))
    
class KEY:
    class KeyUse(Enum):
        SIGN = "sig"
        CIPH = "enc"

    class KidSize(Enum):
        KID08 = 8
        KID16 = 16
        KID32 = 32
        KID64 = 64

    class HSKSize(Enum):
        HS256 = 32 
        HS384 = 48
        HS512 = 64

    class RSKSize(Enum):
        RSA2048 = 2048
        RSA3072 = 3072
        RSA4096 = 4096

    class ECCurve(Enum):
        SECP256R1 = ec.SECP256R1
        SECP384R1 = ec.SECP384R1
        SECP521R1 = ec.SECP521R1
        SECP256K1 = ec.SECP256K1
        
    SymKeys = SymKeys
    KeyConf = KeyConf
    
    def __init__(self, key, kid=None, use=None):
        self.key = key
        self.kid = kid
        self.use = use

    def __repr__(self):
        if hasattr(self.key, "private_bytes"):
            type = "private"
        elif hasattr(self.key, "public_bytes"):
            type = "public"
        else:
            type = "hmackey"
        return f"Key(type='{type}', kid='{self.kid}', use= '{self.use}')"
    
    @property
    def key_type(self):
        if hasattr(self.key, "private_bytes"):
            type = "private"
        elif hasattr(self.key, "public_bytes"):
            type = "public"
        elif isinstance(self.key, (str, bytes, bytearray, memoryview)):
            type = "hmackey"
        else:
            type = "unknown"
        return type
    
    @property
    def public(self):
        if self.key_type=="private" and hasattr(self.key, "public_key"):
            return self.key.public_key()
        elif self.key_type == "public":
            return self.key  # Already a public key
        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")
            
        
    def to_pem(
            self, 
            passphrase=None, 
            public=False
        ) -> bytes:
        passphrase = CMNUtils.to_bytes(passphrase) if passphrase else None
        if self.key_type == "private" and not public:
            encryption = (
                serialization.BestAvailableEncryption(passphrase)
                if passphrase else serialization.NoEncryption()
            )
            return self.key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=encryption
            )
        elif public and self.key_type in ["private", "public"]:
            return self.public.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")
        
    def to_der(
            self, 
            passphrase=None, 
            public=False
        ) -> bytes:
        passphrase = CMNUtils.to_bytes(passphrase) if passphrase else None
        if self.key_type == "private" and not public:
            encryption = (
                serialization.BestAvailableEncryption(passphrase)
                if passphrase else serialization.NoEncryption()
            )
            return self.key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=encryption
            )
        elif public and self.key_type in ["private", "public"]:
            return self.public.public_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")
    
    def to_cert(
            self, 
            common_name="selfsigned", 
            days_valid=365,
            format = "pem"
        ):
        
        if self.key_type == "private":
            subject = issuer = x509.Name([
                x509.NameAttribute(NameOID.COUNTRY_NAME, u"IN"),
                x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"DL"),
                x509.NameAttribute(NameOID.LOCALITY_NAME, u"DL"),
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"SELF"),
                x509.NameAttribute(NameOID.COMMON_NAME, common_name),
            ])
            hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(self.key.key_size, hashes.SHA256)
            cert = (
                x509.CertificateBuilder()
                .subject_name(subject)
                .issuer_name(issuer)
                .public_key(self.key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(datetime.now(timezone.utc))
                .not_valid_after(datetime.now(timezone.utc) + timedelta(days=days_valid))
                .add_extension(
                    x509.SubjectAlternativeName([x509.DNSName(common_name)]),
                    critical=False,
                )
                .sign(self.key, hash_algo())
            )
            if format == "der":
                return cert.public_bytes(serialization.Encoding.DER)
            return cert.public_bytes(serialization.Encoding.PEM)
        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")
        
    def to_csr(
            self, 
            common_name="selfsigned",
            format = "pem"
        ):
        if self.key_type == "private":
            # Subject details
            subject = x509.Name([
                x509.NameAttribute(NameOID.COUNTRY_NAME, u"IN"),
                x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"DL"),
                x509.NameAttribute(NameOID.LOCALITY_NAME, u"DL"),
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"SELF"),
                x509.NameAttribute(NameOID.COMMON_NAME, common_name),
            ])
            hash_algo = {
                    4096: hashes.SHA512,
                    3072: hashes.SHA384,
                    2048: hashes.SHA256
                }.get(self.key.key_size, hashes.SHA256)
            # Build CSR
            csr = (
                x509.CertificateSigningRequestBuilder()
                .subject_name(subject)
                .add_extension(
                    x509.SubjectAlternativeName([x509.DNSName(common_name)]),
                    critical=False,
                )
                .sign(self.key, hash_algo())
            )
            if format == "der":
                return csr.public_bytes(serialization.Encoding.DER)
            return csr.public_bytes(serialization.Encoding.PEM)
        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")

    def to_jwk(
            self, 
            public=False, 
            use = KeyUse.SIGN, 
            kid_size = KidSize.KID16
        ):
        if isinstance(self.public, rsa.RSAPublicKey):
            numbers = self.public.public_numbers()
            key_size = self.public.key_size
            alg = "RS512" if key_size >= 4096 else "RS384" if key_size >= 3072 else "RS256"

            jwk = {
                "kty": "RSA",
                "n": CMNUtils.int_to_b64(numbers.n),
                "e": CMNUtils.int_to_b64(numbers.e),
                "alg": alg
            }
            kid = self.kid or self.make_kid(jwk, kid_size.value)
            if not public and isinstance(self.key, rsa.RSAPrivateKey):
                priv = self.key.private_numbers()
                jwk.update({
                    "d": CMNUtils.int_to_b64(priv.d),
                    "p": CMNUtils.int_to_b64(priv.p),
                    "q": CMNUtils.int_to_b64(priv.q),
                    "dp": CMNUtils.int_to_b64(priv.dmp1),
                    "dq": CMNUtils.int_to_b64(priv.dmq1),
                    "qi": CMNUtils.int_to_b64(priv.iqmp)
                })

        elif isinstance(self.public, ec.EllipticCurvePublicKey):
            numbers = self.public.public_numbers()
            crv, alg = {
                "secp256r1": ("P-256", "ES256"),
                "secp384r1": ("P-384", "ES384"),
                "secp521r1": ("P-521", "ES512"),
                "secp256k1": ("secp256k1", "ES256K")
            }.get(self.public.curve.name, ("P-256", "ES256"))
            jwk = {
                "kty": "EC",
                "crv": crv,
                "x": CMNUtils.int_to_b64(numbers.x),
                "y": CMNUtils.int_to_b64(numbers.y),
                "alg": alg
            }
            kid = self.kid or self.make_kid(jwk, kid_size.value)
            # Add private field if requested and available
            if not public and isinstance(self.key, ec.EllipticCurvePrivateKey):
                priv = self.key.private_numbers()
                jwk["d"] = CMNUtils.int_to_b64(priv.private_value)

        else:
            raise ValueError(f"Error: Unsupported key type {type(self.key)}")
        
        jwk["kid"] = kid
        jwk["use"] = self.use or use.value
        #jwk_json = json.dumps(jwk, indent=2)
        return jwk
        
    def to_file(
            self, 
            key_name, 
            key_path, 
            passphrase=None, 
            is_public=False,
            out_type = "key",
            out_format = "pem"
        ):
        key_path = Path(key_path)
        if self.key_type == "private" and not is_public:
            key_name = key_name
        elif self.key_type == "hmackey" and not is_public:
            key_name = key_name
        elif is_public and self.key_type in ["private", "public"]:
            key_name = f"{key_name}.pub"
        else:
            key_name = f"{key_name}.txt"
        file_path = key_path / key_name
        if self.key_type == "private":
            if is_public:
                if out_type == "cert":
                    key_name = f"{key_name}.{out_format}"
                    key_data = self.to_cert(format = out_format)
                elif out_type == "csr":
                    out_format = out_type if out_format == "pem" else out_format
                    key_name = f"{key_name}.{out_format}"
                    key_data = self.to_csr(format = out_format)
                else:
                    out_format = "pub" if out_format == "pem" else out_format
                    key_name = f"{key_name}.{out_format}"
                    key_data = self.to_pem(passphrase, True) if out_format == "pem" else self.to_der(passphrase, True)
            else:
                key_name = key_name
                key_data = self.to_pem(passphrase) if out_format == "pem" else self.to_der(passphrase)
        elif self.key_type == "public":
            key_name = f"{key_name}.pub"
            key_data = self.to_pem(passphrase, True) if out_format == "pem" else self.to_der(passphrase, True)
        
        elif self.key_type == "hmackey":
            key_name = key_name
            key_data = CMNUtils.to_bytes(self.key)
        else:
            out_format = "txt"
            key_name = f"{key_name}.{out_format}"
            key_data = CMNUtils.to_bytes(self.key)
        file_path = key_path / key_name
        file_path.write_bytes(key_data)
        return str(file_path)
    
    def sign(
        self,
        signing_input: Union[str, bytes],
        is_pkcs: bool = False,
        algorithm: Optional[str] = None
        ) -> str:

        if self.key_type == "private" or self.key_type =="hmackey":
            return JWS.sign(self.key, signing_input, is_pkcs, algorithm)
        else:
            raise ValueError(f"Unsupported key type for signature: {type(self.key)}")
    
    def verify(
            self,
            signature_b64: Union[str, bytes], 
            signing_input: Union[str, bytes],
            is_pkcs: bool = False,
            algorithm: Optional[str] = None,
        ) -> None:
        key = self. public if self.key_type != "hmackey" else self.key
        if self.key_type == "private" or self.key_type =="public" or self.key_type =="hmackey":
            JWS.verify(key, signature_b64, signing_input, is_pkcs, algorithm)
        raise ValueError(f"Signature verification failed for key type {type(self.key)}")
        
    def wrap(self, plain_cek: Union[str, bytes]) -> str:
        key = self.public if self.key_type != "hmackey" else None
        if key and CMNUtils.is_rsa_key(key):
            hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
            cek_bytes = CMNUtils.to_bytes(plain_cek)
            cipher_bytes = key.encrypt(
                cek_bytes,
                padding.OAEP(
                    mgf=padding.MGF1(hash_algo()),
                    algorithm=hash_algo(),
                    label=b"secure_key",
                ),
            )
            urlsafe_ciphercek = base64.urlsafe_b64encode(cipher_bytes)
            return CMNUtils.to_str(urlsafe_ciphercek)
        raise ValueError(f"Unsupported key type for wrap: {type(self.key)}")
    
    def unwrap(self, urlsafe_ciphercek: Union[str, bytes]) -> str:
        key = self.key if self.key_type == "private" else None
        if key and CMNUtils.is_rsa_key(key):
            hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
            cipher_bytes = base64.urlsafe_b64decode(CMNUtils.to_bytes(urlsafe_ciphercek))
            cek_bytes = key.decrypt(
                cipher_bytes,
                padding.OAEP(
                    mgf=padding.MGF1(hash_algo()),
                    algorithm=hash_algo(),
                    label=b"secure_key",
                ),
            )
            return CMNUtils.to_str(cek_bytes)
        raise ValueError(f"Unsupported key type for unwrap: {type(self.key)}")

    
    @classmethod
    def from_ecc(
            cls, 
            ec_curve=ECCurve.SECP521R1,
            kid=None,
            use = KeyUse.SIGN
        ):
        # Generate an ECC key pair
        curve = ec_curve.value
        key = ec.generate_private_key(
            curve(),
            backend=default_backend(),
        )
        return cls(key, kid, use.value)

    @classmethod
    def from_rsa(
            cls, 
            key_size=RSKSize.RSA4096,
            kid=None,
            use = KeyUse.SIGN
        ):
        key_size = key_size.value
        key = rsa.generate_private_key(
            public_exponent=65537, key_size=key_size, backend=default_backend()
        )
        return cls(key, kid, use.value)
    
    @classmethod
    def from_hmac(
            cls, 
            key_size=HSKSize.HS256,
            kid=None,
            use = KeyUse.SIGN
        ):
        key = secrets.token_urlsafe(key_size.value)
        return cls(key, kid, use.value)

    
    @classmethod
    def from_pem(
            cls, 
            pem_data, 
            passphrase=None,
            kid=None,
            use = KeyUse.SIGN
        ):
        pem_data = CMNUtils.to_bytes(pem_data)
        passphrase = CMNUtils.to_bytes(passphrase) if passphrase else None
        try:  
            key = serialization.load_pem_private_key(pem_data, password=passphrase, backend=default_backend())
            return cls(key, kid, use.value)
        except Exception:
            pass
        try:
            key = serialization.load_pem_public_key(pem_data, backend=default_backend())
            return cls(key, kid, use.value)
        except Exception:
            pass
        try:
            cert = x509.load_pem_x509_certificate(pem_data, default_backend())
            return cls(cert.public_key(), kid, use.value)
        except Exception:
            pass
        try:
            csr = x509.load_pem_x509_csr(pem_data)
            return cls(csr.public_key(), kid, use.value)
        except Exception:
            pass
        raise ValueError("Unsupported or unknown PEM data type")
    
    @classmethod
    def from_der(
            cls,
            der_data,
            passphrase=None,
            kid=None,
            use=KeyUse.SIGN
        ):
        passphrase = CMNUtils.to_bytes(passphrase) if passphrase else None

        # Try private key
        try:
            key = serialization.load_der_private_key(
                der_data, password=passphrase, backend=default_backend()
            )
            return cls(key, kid, use.value)
        except Exception:
            pass

        # Try public key
        try:
            key = serialization.load_der_public_key(
                der_data, backend=default_backend()
            )
            return cls(key, kid, use.value)
        except Exception:
            pass

        # Try certificate → extract public key
        try:
            cert = x509.load_der_x509_certificate(der_data, default_backend())
            return cls(cert.public_key(), kid, use.value)
        except Exception:
            pass

        # Try CSR → extract public key
        try:
            csr = x509.load_der_x509_csr(der_data)
            return cls(csr.public_key(), kid, use.value)
        except Exception:
            pass

        raise ValueError("Unsupported or unknown DER data type")
    

    @classmethod
    def from_file(
            cls, 
            key_path, 
            file_name, 
            passphrase=None, 
            kid=None,
            use = KeyUse.SIGN, 
        ):
        key_path = Path(key_path)
        file_path = key_path / file_name
        key_data = file_path.read_bytes()
        try:
            return cls.from_pem(key_data, kid, use)
        except Exception:
            pass
        try:
            return cls.from_der(key_data, passphrase, kid, use)
        except Exception:
            pass
        return cls(key_data, kid, use.value)

    @classmethod
    def from_jwk(cls, jwk):
        jwk_dict = jwk if isinstance(jwk, dict) else json.loads(jwk)
        kid = jwk_dict.get("kid")
        use = jwk_dict.get("use")
        if jwk_dict["kty"] == "RSA":
            pub = rsa.RSAPublicNumbers(
                e=CMNUtils.b64_to_int(jwk_dict["e"]),
                n=CMNUtils.b64_to_int(jwk_dict["n"])
            )
            if "d" in jwk_dict:
                priv = rsa.RSAPrivateNumbers(
                    p=CMNUtils.b64_to_int(jwk_dict["p"]),
                    q=CMNUtils.b64_to_int(jwk_dict["q"]),
                    d=CMNUtils.b64_to_int(jwk_dict["d"]),
                    dmp1=CMNUtils.b64_to_int(jwk_dict["dp"]),
                    dmq1=CMNUtils.b64_to_int(jwk_dict["dq"]),
                    iqmp=CMNUtils.b64_to_int(jwk_dict["qi"]),
                    public_numbers=pub
                )
                return cls(priv.private_key(), kid, use)
            else:
                return cls(pub.public_key(), kid, use)

        elif jwk_dict["kty"] == "EC":
            curve = {
                "P-256": ec.SECP256R1,
                "P-384": ec.SECP384R1,
                "P-521": ec.SECP521R1,
                "secp256k1": ec.SECP256K1
            }.get(jwk_dict["crv"], ec.SECP256R1)
            pub = ec.EllipticCurvePublicNumbers(
                x=CMNUtils.b64_to_int(jwk_dict["x"]),
                y=CMNUtils.b64_to_int(jwk_dict["y"]),
                curve=curve()
            )
            if "d" in jwk_dict:
                priv = ec.EllipticCurvePrivateNumbers(
                    private_value=CMNUtils.b64_to_int(jwk_dict["d"]),
                    public_numbers=pub
                )
                return cls(priv.private_key(), kid, use)
            else:
                return cls(pub.public_key(), kid, use)

        else:
            raise ValueError("Unsupported key type")
        
    def get_kid(self, kid_size = KidSize.KID16) -> str:
        jwk= self.to_jwk(public=True, kid_size=kid_size)
        jwk_dict = jwk if isinstance(jwk, dict) else json.loads(jwk)
        return jwk_dict["kid"]
    
    @staticmethod
    def jwk_set(jwk_list) -> Dict[str, Any]:
        return {"keys": jwk_list}
    
    @staticmethod
    def make_kid(jwk_dict, kid_size: int) -> str:
        jwk_json = json.dumps(jwk_dict, sort_keys=True)
        thumbprint = hashlib.sha256(CMNUtils.to_bytes(jwk_json)).digest()
        kid = base64.urlsafe_b64encode(thumbprint[:kid_size]).rstrip(b"=")
        return  CMNUtils.to_str(kid)
    
    @staticmethod
    def shared(private_key, peer_key):
        return private_key.exchange(ec.ECDH(), peer_key)
    
class JWS:
    HASHES = {
        "HS256": hashes.SHA256, 
        "HS384": hashes.SHA384, 
        "HS512": hashes.SHA512,
        "RS256": hashes.SHA256,
        "RS384": hashes.SHA384,
        "RS512": hashes.SHA512,
        "PS256": hashes.SHA256,
        "PS384": hashes.SHA384,
        "PS512": hashes.SHA512,
        "ES256": hashes.SHA256,
        "ES384": hashes.SHA384,
        "ES512": hashes.SHA512,
        "ES256K": hashes.SHA256,
        2048: hashes.SHA256,
        3072: hashes.SHA384,
        4096: hashes.SHA512,
        "secp256r1": hashes.SHA256,
        "secp384r1": hashes.SHA384,
        "secp521r1": hashes.SHA512,
        "secp256k1": hashes.SHA256
    }
    
    @classmethod
    def sign(
        cls,
        private_key, 
        signing_input: Union[str, bytes],
        is_pkcs: bool = False,
        algorithm: Optional[str] = None
        ) -> str:
        data = CMNUtils.to_bytes(signing_input)
        hash_algo = cls.select_hash(private_key, algorithm)

        if CMNUtils.is_rsa_key(private_key):
            signature = private_key.sign(
                data,
                padding.PKCS1v15() if is_pkcs else padding.PSS(
                    mgf=padding.MGF1(hash_algo()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hash_algo
            )
        elif CMNUtils.is_ec_key(private_key):
            if hash_algo().digest_size * 8 > private_key.curve.key_size:
                raise TypeError(
                    "this curve (%s) is too short "
                    "for your digest (%d)" % (private_key.curve.name, 8 * hash_algo().digest_size * 8)
                )
            der = private_key.sign(data, ec.ECDSA(hash_algo()))
            signature = CMNUtils.der_toraw(der, private_key)
        elif CMNUtils.is_hmac_key(private_key):
            h = hmac.HMAC(private_key, hash_algo() , backend=default_backend())
            h.update(data)
            signature = h.finalize()
        else:
            raise ValueError(f"Unsupported key type for signature: {type(private_key)}")
        return CMNUtils.to_str(CMNUtils.b64url_encode(signature))

    @classmethod
    def verify(
            cls,
            public_key, 
            signature_b64: Union[str, bytes], 
            signing_input: Union[str, bytes],
            is_pkcs: bool = False,
            algorithm: Optional[str] = None,
        ) -> None:
        data = CMNUtils.to_bytes(signing_input)
        signature = CMNUtils.b64url_decode(CMNUtils.to_bytes(signature_b64))
        hash_algo = cls.select_hash(public_key, algorithm)
        try:
            if CMNUtils.is_rsa_key(public_key):
                public_key.verify(
                    signature,
                    data,
                    padding.PKCS1v15() if is_pkcs else padding.PSS(
                        mgf=padding.MGF1(hash_algo()),
                        salt_length=padding.PSS.MAX_LENGTH
                    ),
                    hash_algo
                )
            elif CMNUtils.is_ec_key(public_key):
                signature = CMNUtils.raw_toder(signature, public_key)
                public_key.verify(signature, data, ec.ECDSA(hash_algo()))
            
            elif CMNUtils.is_hmac_key(public_key):
                h = hmac.HMAC(public_key, hash_algo(), backend=default_backend())
                h.update(data)
                h.verify(signature)
            else:
                raise ValueError(f"Unsupported key type for verification: {type(public_key)}")
        except Exception as exc:
            raise ValueError(f"Signature verification failed for key type {type(public_key)}") from exc
    
    @classmethod
    def select_hash(cls, key, algorithm: Optional[str] = None) -> type[hashes.HashAlgorithm]:
        if CMNUtils.is_rsa_key(key):
            size = key.key_size
            hash_size = cls.HASHES.get(size)
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_size or hash_algo or hashes.SHA256
        elif CMNUtils.is_ec_key(key):
            size = key.key_size
            name = key.curve.name
            hash_size = cls.HASHES.get(size)
            hash_curve = cls.HASHES.get(name)
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_curve or hash_size or hash_algo or hashes.SHA256
        
        elif CMNUtils.is_hmac_key(key):
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_algo or hashes.SHA256
        
        else:
            raise ValueError(f"Unsupported key type for hash selection: {type(key)}")
    
class CMNUtils:
    @staticmethod
    def b64_to_int(val):
        return int.from_bytes(base64.urlsafe_b64decode(val + '=' * (-len(val) % 4)), 'big')
    
    @staticmethod
    def int_to_b64(val):
        return base64.urlsafe_b64encode(val.to_bytes((val.bit_length() + 7) // 8, 'big')).rstrip(b'=').decode("utf-8")
    
    @staticmethod
    def b64url_encode(data: bytes) -> bytes:
        return base64.urlsafe_b64encode(data).rstrip(b'=')

    @staticmethod
    def b64url_decode(data: bytes) -> bytes:
        return base64.urlsafe_b64decode(data + b'=' * (-len(data) % 4))

    @staticmethod
    def to_bytes(data: Union[str, bytes, bytearray, memoryview]) -> bytes:
        if isinstance(data, bytes):
            return data
        elif isinstance(data, str):
            return data.encode("utf-8")
        elif isinstance(data, (bytearray, memoryview)):
            return bytes(data)
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
        
    @staticmethod
    def to_str(data: Union[str, bytes, bytearray, memoryview]) -> str:
        if isinstance(data, str):
            return data
        elif isinstance(data, (bytes, bytearray, memoryview)):
            return bytes(data).decode("utf-8")
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
        
    @staticmethod
    def is_rsa_key(key) -> bool:
        return isinstance(key, (rsa.RSAPublicKey, rsa.RSAPrivateKey))

    @staticmethod
    def is_ec_key(key) -> bool:
        return isinstance(key, (ec.EllipticCurvePublicKey, ec.EllipticCurvePrivateKey))
    
    @staticmethod
    def is_hmac_key(key) -> bool:
        return isinstance(key, (str, bytes, bytearray, memoryview))
    
    @staticmethod
    def sig_length(key):
        return int(math.ceil(key.key_size / 8.0))

    @classmethod
    def der_toraw(cls, der, key):
        r, s = decode_dss_signature(der)
        length = cls.sig_length(key)
        return int_to_bytes(r, length) + int_to_bytes(s, length)

    @classmethod
    def raw_toder(cls, raw, key):
        length = cls.sig_length(key)
        if len(raw) != int(2 * length):
            raise ValueError("Invalid signature")

        r_bytes = raw[:length]
        s_bytes = raw[length:]
        r = int.from_bytes(r_bytes, "big")
        s = int.from_bytes(s_bytes, "big")
        return encode_dss_signature(r, s)