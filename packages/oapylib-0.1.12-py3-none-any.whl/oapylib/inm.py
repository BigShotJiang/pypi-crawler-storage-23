"""Docstring"""
from time import time
from pydantic import BaseModel
from abc import ABC, abstractmethod
from typing import TypeVar, Generic, Dict, Optional

__all__=["InmSess"]

ID = TypeVar("ID")
SessionModel = TypeVar("SessionModel", bound=BaseModel)


class BackendError(Exception): pass

class SessionBackend(ABC, Generic[ID, SessionModel]):
    @abstractmethod
    def create(self, session_id: ID, data: SessionModel) -> None: raise NotImplementedError()

    @abstractmethod
    def read(self, session_id: ID) -> Optional[SessionModel]: raise NotImplementedError()

    @abstractmethod
    def update(self, session_id: ID, data: SessionModel) -> None: raise NotImplementedError()

    @abstractmethod
    def delete(self, session_id: ID) -> None: raise NotImplementedError()



class InmSess(
        Generic[ID, SessionModel], 
        SessionBackend[ID, SessionModel]
    ):
    def __init__(self) -> None:
        self.data: Dict[ID, SessionModel] = {}

    def create(self, session_id: ID, data: SessionModel):
        if self.data.get(session_id):
            raise BackendError("create can't overwrite an existing session")
        self.data[session_id] = data.model_copy(deep=True)

    def read(self, session_id: ID):
        data = self.data.get(session_id)
        if not data: return None
        return data.model_copy(deep=True)

    def update(self, session_id: ID, data: SessionModel) -> None:
        if self.data.get(session_id): self.data[session_id] = data
        else: raise BackendError("session does not exist, cannot update")

    def delete(self, session_id: ID) -> None: del self.data[session_id]

    def verify(self, session_id: ID) -> Optional[str]:
        data = self.data.get(session_id)
        if not data: return
        data_dict = data.model_dump()
        exp = data_dict.get("exp")      
        if exp and exp > time():
            self.delete(session_id)
            return
        return data_dict.get("id")