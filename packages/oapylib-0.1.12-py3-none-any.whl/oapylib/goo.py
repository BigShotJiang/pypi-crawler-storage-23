"""Docstring"""
import urllib.parse
from pathlib import Path
from httpx import Client
from httpx import AsyncClient
from functools import lru_cache
from sqlmodel import SQLModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Dict, Optional, Any, Union

from .key import KEY
from .jwt import JWT
from .cus import SesState

__all__ = ["GooAuth"]

class GooConf:
    class Base(BaseSettings):
        project_id: Optional[str] = None
        client_id: Optional[str] = None
        client_secret: Optional[str] = None
        redirect_uri: Optional[str] = None
        auth_uri: str = "https://accounts.google.com/o/oauth2/v2/auth"
        token_uri: str = "https://oauth2.googleapis.com/token"
        user_uri: str = "https://openidconnect.googleapis.com/v1/userinfo"
        revoke_uri: str = "https://oauth2.googleapis.com/revoke"
        jwks_uri: str = "https://www.googleapis.com/oauth2/v3/certs"
        cert_uri: str = "https://www.googleapis.com/oauth2/v1/certs"
        issuer: str = "https://accounts.google.com"
        scope: str = "openid email profile"

    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        goo_env: Optional[Union[str, Path]] = None,
        goo_secrets: Optional[Union[str, Path]] = None,
        well_known: Optional[str] = None,
    ):
        self.well_known = well_known or "https://accounts.google.com/.well-known/openid-configuration"

        class Deploy(BaseSettings):
            goo_env: str = ".env.goau"
            goo_secrets: str = "."
            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        deploy = Deploy()
        self.env_path = self.resolve_path(goo_env, deploy.goo_env)
        self.secrets_path = self.resolve_path(goo_secrets, deploy.goo_secrets)

    @property
    def config(self):
        return self.get_config(self.well_known, self.env_path, self.secrets_path)

    @classmethod
    @lru_cache(maxsize=1)
    def get_config(
        cls,
        well_known: Optional[str] = None,
        goo_env: Optional[Union[str, Path]] = None,
        goo_secrets: Optional[Union[str, Path]] = None,
    ):
        well_known = well_known or "https://accounts.google.com/.well-known/openid-configuration"

        # Load secrets (client_id, client_secret, redirect_uri)
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(goo_env, ".env.goau"),
                env_file_encoding="utf-8",
                extra="ignore",
                secrets_dir=cls.resolve_path(goo_secrets, ".")
            )

        config = Config()

        # Try fetching from well-known
        try:
            with Client() as client:
                response = client.get(well_known)
                response.raise_for_status()
                data = response.json()
                scope = data.get("scopes_supported", None)
                config.auth_uri = data.get("authorization_endpoint", config.auth_uri)
                config.token_uri = data.get("token_endpoint", config.token_uri)
                config.user_uri = data.get("userinfo_endpoint", config.user_uri)
                config.revoke_uri = data.get("revocation_endpoint", config.revoke_uri)
                config.jwks_uri = data.get("jwks_uri", config.jwks_uri)
                config.issuer = data.get("issuer", config.issuer)       
                config.scope = " ".join(scope) if scope else config.scope
        except Exception as exc:
            print(f"Error fetching well-known config: {exc}")
        return config
    
    @staticmethod
    def resolve_path(path: Optional[Union[str, Path]], default: Optional[str] = None) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default

class GooAuth:
    class User(SQLModel):
        sub: str = Field(alias="id")
        email: str = Field()
        email_verified: Optional[bool] = Field(default=None)
        name: Optional[str] = Field(default=None)
        given_name: Optional[str] = Field(default=None)
        family_name: Optional[str] = Field(default=None)
        picture: Optional[str] = Field(default=None)

    class Token(SQLModel):
        access_token: str = Field()
        token_type: str = Field()
        expires_in: int = Field()
        refresh_token: Optional[str] = Field(default=None)
        issued_at: Optional[int] = Field(default=None)
        expired_by: Optional[int] = Field(default=None)
    
    GooConf = GooConf

    def __init__(
            self,
            client_id: str, 
            redirect_uri: str,
            client_secret: str,
            auth_uri: str = "https://accounts.google.com/o/oauth2/v2/auth",
            token_uri: str = "https://oauth2.googleapis.com/token",
            user_uri: str = "https://openidconnect.googleapis.com/v1/userinfo",
            revoke_uri: str = "https://oauth2.googleapis.com/revoke",
            jwks_uri: str = "https://www.googleapis.com/oauth2/v3/certs",
            cert_uri: str = "https://www.googleapis.com/oauth2/v1/certs",
            issuer:  str = "https://accounts.google.com",
            scope:  str = "openid email profile",
            stas: Optional[SesState] = None,
            is_authorize: bool = False,
            
        ):
        
        self.client_id = client_id
        self.redirect_uri = redirect_uri
        self.client_secret = client_secret
        self.auth_uri = auth_uri
        self.token_uri = token_uri
        self.user_uri = user_uri
        self.revoke_uri = revoke_uri
        self.jwks_uri = jwks_uri
        self.cert_uri = cert_uri
        self.issuer = issuer
        self.scope = scope

        self.stas: SesState = stas or SesState()
        self.is_authorize: bool = is_authorize

    @classmethod
    def from_config(cls, config: Any, stas: Optional[SesState] = None, is_authorize: bool = False) -> Optional["GooAuth"]:
        config_dict = config.model_dump(exclude = {"project_id"}, exclude_none=True)
        try:
            goo_auth = cls(**config_dict, stas=stas, is_authorize=is_authorize)
            return goo_auth
        except Exception as exc:
            print(f"Error initializing GooAuth: {exc}")
            return None
    
    async def auth_url(self, access: str = "online", prompt: str = "consent") -> str:
        state, nonce = self.stas.create_session()
        prompt = f"{prompt} select_account" if prompt in ["consent", "login"] else prompt
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": self.scope,
            "access_type": access,
            "prompt": prompt,
            "state": state,
            "nonce": nonce,
        }
        return f"{self.auth_uri}?{urllib.parse.urlencode(params)}"

    async def create(self, code : str):
        async with AsyncClient() as client:
            response = await client.post(self.token_uri, data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": self.redirect_uri,
            })
            return response.json()

    async def refresh(self, refresh_token):
        async with AsyncClient() as client:
            response = await client.post(self.token_uri, data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
                "redirect_uri": self.redirect_uri,
            })
            return response.json()

    async def revoke(self, access_token):
        async with AsyncClient() as client:
            response = await client.post(self.revoke_uri, data={"token": access_token})
        return response.json()
    
    async def userinfo(self, access_token, token_type="Bearer"):
        async with AsyncClient() as client:
            response = await client.get(
                self.user_uri,
                headers={"Authorization": f"{token_type} {access_token}"}
            )
        return response.json()
    
    async def keyalg(self, header):
        async with AsyncClient() as client:
            if self.jwks_uri:
                jwks = (await client.get(self.jwks_uri)).json()
                key = next((k for k in jwks["keys"] if k["kid"] == header["kid"]), None)
                key = KEY.from_jwk(key).key if key else None
            else:
                certs = (await client.get(self.cert_uri)).json()
                cert = next((key for kid, key in certs.items() if kid == header["kid"]), None)
                key = KEY.from_der(cert.encode()).key if cert else None

        if not key:
            raise ValueError("No matching key found")
        return key, header["alg"]

    async def verify(self, id_token, access_token):
        try:
            header = JWT.header(id_token)
            key, alg = await self.keyalg(header)
            return JWT.decode(
                token=id_token,
                key=key,
                algorithms=[alg],
                options = {"require": ["nbf", "iat", "exp", "iss", "sub"]},
                audience=self.client_id,
                issuer=self.issuer,
                access_token=access_token,
                is_pkcs=True
            )
        except Exception as e:
            print(f"Verification failed: {e}")
            return None

    async def token(self, state : str, code : str) -> Dict[str, Any]:
        response: Dict[str, Any] = {
                "status_code": None, 
                "detail": None,
                "userid": None,
            }
        if self.is_authorize:
            response.update(
                    {
                        "token": None,
                        "userin": None,
                    }
                ) 
        if not self.stas.verify_state(state):   
            response.update(
                {
                    "status_code": 400, 
                    "detail": "Invalid Token State",
                }
            )
            return response
        token_data = await self.create(code)
        if "error" in token_data:
            response.update(
                {
                    "status_code": 400, 
                    "detail": "Error Token Response", 
                }
            )
            return response
        id_token = token_data["id_token"]
        access_token = token_data["access_token"]
        token_type = token_data["token_type"]
        payload = await self.verify(id_token, access_token)
        if not payload:
            response.update(
                {
                    "status_code": 400, 
                    "detail": "Invalid Id Token ",    
                }
            )
            return response
        if not self.stas.verify_nonce(state, payload.get("nonce")):
            response.update(
                {
                    "status_code": 400, 
                    "detail": "Invalid Id Token ",    
                }
            )
            return response
        response.update(
                {
                    "status_code": 200, 
                    "detail": "Authentication successful", 
                    "userid": self.User.model_validate(payload), 
                }
            )
        
        if self.is_authorize:
            dict_map = {"iss": "issued_by", "iat": "issued_at", "exp": "expired_by"}
            time_data = {v: payload[k] for k, v in dict_map.items() if k in payload}
            token_data.update(time_data)
            response.update(
                    { 
                        "token": self.Token.model_validate(token_data),
                    }
                )
            userinfo = await self.userinfo(access_token, token_type)
            if "error" in userinfo:
                response.update(
                    {
                        "detail": "Authentication successful, Error Userinfo Response",
                    }
                )
                return response
            response.update(
                    { 
                        "userin": self.User.model_validate(userinfo)
                    }
                )  
        return response

    async def user(self, token, token_type, is_refresh=False):
        if not is_refresh:
            userinfo = await self.userinfo(token, token_type)
            if "error" in userinfo:
                return {
                    "status_code": 400, 
                    "detail": "Error Userinfo Response", 
                    "token": None,
                    "userid": None,
                    "userin": None,
                }
            return {
            "status_code": 200,
            "detail": "UserInfo Successful ",
            "token": None,
            "userid": None,
            "userin": self.User.model_validate(userinfo),
        }
        
        token_data = await self.refresh(token)
        if "error" in token_data:
            return {
                "status_code": 400, 
                "detail": "Error Token Response", 
                "token": None, 
                "userid": None, 
                "userin": None
            }
        id_token = token_data["id_token"]
        access_token = token_data["access_token"]
        token_type = token_data["token_type"]
        payload = await self.verify(id_token, access_token)
        if not payload:
           return {
                "status_code": 400, 
                "detail": "Invalid Id Token ", 
                "token": None, 
                "userid": None, 
                "userin": None,
            }
        dict_map = {"iss": "issued_by", "iat": "issued_at", "exp": "expired_by"}
        time_data = {v: payload[k] for k, v in dict_map.items() if k in payload}
        token_data.update(time_data)
        userinfo = await self.userinfo(access_token, token_type)
        if "error" in userinfo:
            return {
            "status_code": 200, 
            "detail": "Refresh successful, Error Userinfo Response", 
            "token": self.Token.model_validate(token_data),
            "userid": self.User.model_validate(payload), 
            "userin": None,
            }

        return {
            "status_code": 200,
            "detail": "Refresh successful, UserInfo Successful ",
            "token": self.Token.model_validate(token_data),
            "userid": self.User.model_validate(payload),
            "userin": self.User.model_validate(userinfo),
        }