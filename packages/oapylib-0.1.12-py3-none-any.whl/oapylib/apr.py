"""Docstring"""
from enum import Enum
from sqlmodel import SQLModel, Session
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import  APIRouter, Depends, Request, HTTPException, status, Query
from typing import TypeVar, Generic, Type, List, Dict, Any, Annotated, Optional, Union

from .usr import UsrAuth
from .dbs import DbsMsvc, CreateType, UpdateType, QueryType

__all__ = ["APRS"]

# Define type variables
PublicType = TypeVar("PublicType", bound=SQLModel)

class AprSrvc(
    Generic[
            PublicType,
            CreateType, 
            UpdateType, 
            QueryType
        ]
    ):
    def __init__(
        self,
        auth_obj: UsrAuth,
        crud_obj: DbsMsvc,
        public_schema: Type[PublicType], 
    ):
        self.auth = auth_obj
        self.crud = crud_obj
        self.public_schema = public_schema

    async def useractive(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.auth.active_user(
            access_token, required_roles, required_scopes, required_permissions
        )
        
    async def create(
        self,
        session: Session,
        data: CreateType,
    ) -> PublicType:
        obj = await self.crud.create(session=session, data=data)
        return self.public_schema.model_validate(obj)

    async def read(
        self,
        session: Session,
        query: Optional[QueryType] = None,
        offset: int = 0,
        limit: int = 100,
        query_type: Optional[str] = None,
    ) -> List[PublicType]:
        results = await self.crud.read(
            session=session,
            offset=offset,
            limit=limit,
            query=query,
            query_type = query_type,
        )
        return [self.public_schema.model_validate(obj) for obj in results]

    async def read_byid(
        self,
        session: Session,
        id: Union[int, str],
    ) -> Optional[PublicType]:
        obj = await self.crud.read_byid(session=session, id=id)
        return self.public_schema.model_validate(obj) if obj else None

    async def replace(
        self,
        session: Session,
        id: Union[int, str],
        data: CreateType,
    ) -> PublicType:
        existing = await self.crud.read_byid(session=session, id=id)
        if not existing or existing.id != id:
            created = await self.crud.create(session=session, data=data)
            return self.public_schema.model_validate(created)
        updated = await self.crud.update(session=session, id=id, data=data)
        return self.public_schema.model_validate(updated)

    async def update(
        self,
        session: Session,
        id: Union[int, str],
        data: UpdateType,
    ) -> Optional[PublicType]:
        existing = await self.crud.read_byid(session=session, id=id)
        if existing and existing.id == id:
            updated = await self.crud.update(session=session, id=id, data=data)
            return self.public_schema.model_validate(updated)
        return None

    async def delete_byid(
        self,
        session: Session,
        id: Union[int, str],
    ) -> None:
        existing = await self.crud.read_byid(session=session, id=id)
        if existing and existing.id == id:
            await self.crud.delete_byid(session=session, id=id)
        
class AprResp(Generic[PublicType, CreateType, UpdateType, QueryType]):
    def __init__(
        self,
        service_obj: AprSrvc,
        create_schema: Type[CreateType],
        update_schema: Type[UpdateType],
        query_schema: Type[QueryType],
        crud_roles: Optional[Dict[str, List[str]]] = None,
        crud_scopes: Optional[Dict[str, List[str]]] = None,
        crud_permissions: Optional[Dict[str, List[str]]] = None,
        is_protected: Optional[Dict[str, bool]] = None
    ):
        self.service = service_obj
        self.security = HTTPBearer(auto_error=False)
        self.create_schema = create_schema
        self.update_schema = update_schema
        self.query_schema = query_schema
        self.crud_roles = crud_roles or {}
        self.crud_scopes = crud_scopes or {}
        self.crud_permissions = crud_permissions or {}
        self.is_protected = is_protected or {}

    
    def user(self, method):
        is_protected = self.is_protected.get(method, False)
        required_roles = self.crud_roles.get(method)
        required_scopes= self.crud_scopes.get(method)
        required_permissions = self.crud_permissions.get(method)
        async def user(creds: HTTPAuthorizationCredentials = Depends(self.security)):
            try:
                if not is_protected:
                    return "public"
                access_token = creds.credentials
                sub = await self.service.useractive(access_token, required_roles, required_scopes, required_permissions)
                return sub
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Error: User not Found {exc}",
                ) from exc
        return user
    
    @property
    def post(self):
        async def create(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("create"))],
            data: Annotated[CreateType, Depends(self.create_schema)]
        ) -> Optional[PublicType]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.create(session=db_session, data=data)
            except ValueError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=f"Invalid input: {exc}")
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return create

    @property
    def get(self):
        async def read(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("read"))],
            query: Annotated[Optional[QueryType], Depends(self.query_schema)] = None,
            offset: int = 0,
            limit: Annotated[int, Query(le=100)] = 100,
            query_type: Optional[str] = None,
        ) -> List[PublicType]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.read(
                    session=db_session,
                    offset=offset,
                    limit=limit,
                    query=query,
                    query_type=query_type
                )
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return read

    @property
    def get_byid(self):
        async def read_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("read"))],
            id: Union[int, str],
        ) -> Optional[PublicType]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_byid(session=db_session, id=id)
                if not result:
                    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                                        detail="Resource not found")
                return result
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return read_byid

    @property
    def put(self):
        async def replace(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("replace"))],
            id: Union[int, str],
            data: Annotated[CreateType, Depends(self.create_schema)],
        ) -> Optional[PublicType]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.replace(session=db_session, id=id, data=data)
                if not result:
                    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                                        detail="Resource not found")
                return result
            except ValueError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=f"Invalid input: {exc}")
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return replace

    @property
    def patch(self):
        async def update(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("update"))],
            id: Union[int, str],
            data: Annotated[UpdateType, Depends(self.update_schema)],
        ) -> Optional[PublicType]:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.update(session=db_session, id=id, data=data)
                if not result:
                    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                                        detail="Resource not found")
                return result
            except ValueError as exc:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=f"Invalid update data: {exc}")
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return update

    @property
    def delete(self):
        async def delete_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("delete"))],
            id: Union[int, str],
        ) -> JSONResponse:
            if not user:
                raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                    detail="User not found, login and try again")
            try:
                db_session = request.scope["db"]["pgsql"]
                deleted = await self.service.delete_byid(session=db_session, id=id)
                if not deleted:
                    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                                        detail="Resource not found")
                return JSONResponse(content={"removed": True}, status_code=200)
            except Exception as exc:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                    detail=f"Unexpected error: {exc}")
        return delete_byid
        
class AprMsvc:
    def __init__(
        self,
        prefix: str = "",
        tags: Optional[List[Union[str, Enum]]] = None,
        resp_map: Optional[Dict[str, Any]] = None,
    ):
        security = HTTPBearer(auto_error=False)
        self.router = APIRouter(
            prefix=prefix,
            tags=tags,
            responses={404: {"description": "Not found"}},
            dependencies=[Depends(security)]
        )
        if resp_map is not None:
            self._register_routes(resp_map)

    def _register_routes(self, resp_map):
        for name, resp in resp_map.items():
            self._add_routes(name, resp)

    def _add_routes(self, name: str, resp: Any):
        # POST /<name>
        @self.router.post(f"/{name}")
        async def create(_response=Depends(resp.create)):
            """Create item"""
            return _response

        # GET /<name>
        @self.router.get(f"/{name}")
        async def get(_response=Depends(resp.get)):
            """Get list of items"""
            return _response

        # GET /<name>/{id}
        @self.router.get(f"/{name}/{{id}}")
        async def get_byid(_response=Depends(resp.get_byid)):
            """Get item by ID"""
            return _response

        # PUT /<name>/{id}
        @self.router.put(f"/{name}/{{id}}")
        async def replace(_response=Depends(resp.replace)):
            """Replace item"""
            return _response

        # PATCH /<name>/{id}
        @self.router.patch(f"/{name}/{{id}}")
        async def update(_response=Depends(resp.update)):
            """Update item"""
            return _response

        # DELETE /<name>/{id}
        @self.router.delete(f"/{name}/{{id}}")
        async def delete(_response=Depends(resp.delete)):
            """Delete item"""
            return _response
        
        
class APRS:
    AprMsvc = AprMsvc
    AprResp = AprResp
    AprSrvc = AprSrvc