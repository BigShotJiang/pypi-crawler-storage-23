"""Docstring"""
import boto3 #type: ignore
from pathlib import Path
from sqlalchemy import URL
from functools import lru_cache
from fastapi import Request, Depends
from sqlmodel import create_engine, Session
from botocore.exceptions import ClientError #type: ignore
from typing import Annotated, Optional, Union, Any
from redis import Redis, ConnectionPool, Sentinel
from pydantic_settings import BaseSettings, SettingsConfigDict

__all__ = ["PgsCore", "RedCore", "S3Core"]

class PgsConf:
    class Base(BaseSettings):
        postgres_host: str = "0.0.0.0"
        postgres_port: int = 5432
        postgres_database: str = "sqlapp"
        postgres_username: str = "usr"
        postgres_password: str = "pwd"
        postgres_admin_username: str = "adminusr"
        postgres_admin_password: str = "adminpwd"

    def __init__(
            self, 
            dep_env: Optional[Union[str, Path]] = None, 
            pgs_env: Optional[Union[str, Path]] = None,
            pgs_secrets: Optional[Union[str, Path]] = None,
        ):
        class Deploy(BaseSettings):
            pgs_env: str = ".env.pgs"
            pgs_secrets: str = "."

            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )
        self.env_path = self.resolve_path(pgs_env, Deploy().pgs_env)
        self.secrets_path = self.resolve_path(pgs_secrets, Deploy().pgs_secrets)

    @property
    def pgaurl(self):
        return self.get_pgurl(self.env_path, self.secrets_path, True)
    
    @property
    def pguurl(self):
        return self.get_pgurl(self.env_path, self.secrets_path, False)

    @classmethod
    @lru_cache
    def get_config(
        cls, 
        pgs_env : Optional[Union[str, Path]] = None, 
        pgs_secrets : Optional[Union[str, Path]] = None,
    ):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(pgs_env, ".env.pgs"),
                env_file_encoding="utf-8",
                extra="ignore",
                secrets_dir=cls.resolve_path(pgs_secrets, ".")
            )
        return Config()
    
    @classmethod
    def get_pgurl(
        cls, 
        pgs_env : Optional[Union[str, Path]] = None, 
        pgs_secrets : Optional[Union[str, Path]] = None, 
        is_admin: bool = False
        ):
        env_path = cls.resolve_path(pgs_env, ".env.pgs")
        secrets_path = cls.resolve_path(pgs_secrets, ".")
        cfg = cls.get_config(env_path, secrets_path)
        return (
                "postgresql://{username}:{password}@{host}:{port}/{db_name}".format(
                    host=cfg.postgres_host,
                    port=cfg.postgres_port,
                    db_name=cfg.postgres_database,
                    username=cfg.postgres_admin_username if is_admin else cfg.postgres_username,
                    password=cfg.postgres_admin_password if is_admin else cfg.postgres_password,
                )
            )
    
    @staticmethod
    def resolve_path(
            path: Optional[Union[str, Path]] = None, 
            default: Optional[str] = None
        ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default

class PgsCore:
    PgsConf = PgsConf
    def __init__(
            self, 
           pgsurl: Union[str, URL]
        ):
        self.pgsurl = pgsurl
        
    def engine(self):
        return self.get_engine(self.pgsurl)
        
    def session(self):
        return Session(autocommit=False, autoflush=False, bind=self.engine())

    def sessdep(self):
        db = self.session()
        try:
            yield db
        finally:
            db.close()

    def sesspgs(self):
        def _sesspgs(
            request: Request, 
            sess_pgs: Annotated[Session, Depends(self.sessdep)]
        ):
            """Injects session into request scope."""
            request.scope["db"] = {"pgsql": sess_pgs}
        return _sesspgs

    
    @classmethod
    @lru_cache
    def get_engine(
        cls, 
        pgsurl: Union[str, URL]
        ):
        return create_engine(pgsurl, echo=True, future=True) 
    
class RedConf:
    class Base(BaseSettings):
        redis_host: str = "localhost"
        redis_port: int = 6379
        redis_db: int = 0
        redis_name: Optional[str] = None
        redis_username: Optional[str] = None
        redis_password: Optional[str] = None
        redis_admin_username: Optional[str] = None
        redis_admin_password: Optional[str] = None

        # Sentinel support
        redis_sentinel_hosts: Optional[str] = None
        redis_sentinel_service: Optional[str] = None

        # TLS flag (optional override)
        redis_use_tls: Optional[bool] = None

        # Pooling
        redis_max_connections: int = 10

    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        red_env: Optional[Union[str, Path]] = None,
        red_secrets: Optional[Union[str, Path]] = None,
        is_admin: bool = False
    ):
        class Deploy(BaseSettings):
            red_env: str = ".env.redb"
            red_secrets: str = "."

            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        self.env_path = self.resolve_path(red_env, Deploy().red_env)
        self.secrets_path = self.resolve_path(red_secrets, Deploy().red_secrets)
        self.is_admin = is_admin
    
    @property
    def config(self):
        return self.get_config(self.env_path, self.secrets_path, self.is_admin)

    @classmethod
    @lru_cache
    def get_config(
        cls,
        red_env: Optional[Union[str, Path]] = None,
        red_secrets: Optional[Union[str, Path]] = None,
        red_admin: bool = False
    ):
        class Config(cls.Base):
            is_admin: bool = red_admin
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(red_env, ".env.redb"),
                env_file_encoding="utf-8",
                extra="ignore",
                frozen=True,
                secrets_dir=cls.resolve_path(red_secrets, ".")
            )
        return Config()

    @staticmethod
    def resolve_path(
        path: Optional[Union[str, Path]] = None,
        default: Optional[str] = None
    ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default
    
class RedCore:
    RedConf = RedConf
    def __init__(
        self,
        config: Optional[Any] = None,
    ):
        self.config = config

    @property
    def client(self):
        return self.get_client(self.config)

    @classmethod
    @lru_cache
    def get_client(
        cls,
        config: Any,
        is_admin: bool = False
    ) -> Redis:
        is_admin = is_admin or getattr(config, "is_admin", False)
        username = config.redis_admin_username if is_admin else config.redis_username
        password = config.redis_admin_password if is_admin else config.redis_password

        # --- Sentinel mode ---
        if config.redis_sentinel_hosts and config.redis_sentinel_service:
            sentinel_hosts = [
                tuple(host.split(":")) for host in config.redis_sentinel_hosts.split(",")
            ]
            sentinel = Sentinel(sentinel_hosts, socket_timeout=2, password=password)
            return sentinel.master_for(
                config.redis_sentinel_service,
                db=config.redis_db,
                username=username,
                password=password,
                max_connections=config.redis_max_connections,
                decode_responses=False
            )

        # --- Standard Redis connection ---
        # Auto-detect TLS: if port is not 6379, assume TLS unless explicitly overridden
        use_tls = config.redis_use_tls if config.redis_use_tls is not None else (config.redis_port != 6379)
        scheme = "rediss" if use_tls else "redis"

        auth = f"{username}:{password}@" if username and password else ""
        url = f"{scheme}://{auth}{config.redis_host}:{config.redis_port}/{config.redis_db}"
        pool = ConnectionPool.from_url(url, max_connections=config.redis_max_connections, decode_responses=False)
        return Redis(connection_pool=pool)
    
class S3Conf:
    class Base(BaseSettings):
        # --- Core credentials ---
        s3_endpoint: Optional[str] = None
        s3_access_key: Optional[str] = None
        s3_secret_key: Optional[str] = None

        # --- Bucket / region ---
        s3_bucket: Optional[str] = None
        s3_region: Optional[str] = None

        # --- Public access ---
        s3_public_url: Optional[str] = None

        # --- Client tuning ---
        s3_use_ssl: bool = True
        s3_verify_ssl: bool = True

    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        s3c_env: Optional[Union[str, Path]] = None,
        s3c_secrets: Optional[Union[str, Path]] = None,
    ):
        class Deploy(BaseSettings):
            s3c_env: str = ".env.cfos"
            s3c_secrets: str = "."

            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        self.env_path = self.resolve_path(s3c_env, Deploy().s3c_env)
        self.secrets_path = self.resolve_path(s3c_secrets, Deploy().s3c_secrets)

    @property
    def config(self):
        return self.get_config(self.env_path, self.secrets_path)

    @classmethod
    @lru_cache
    def get_config(
        cls,
        s3c_env: Optional[Union[str, Path]] = None,
        s3c_secrets: Optional[Union[str, Path]] = None,
    ):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(s3c_env, ".env.cfos"),
                env_file_encoding="utf-8",
                extra="ignore",
                frozen=True,
                secrets_dir=cls.resolve_path(s3c_secrets, "."),
            )
        return Config()

    @staticmethod
    def resolve_path(
        path: Optional[Union[str, Path]] = None,
        default: Optional[str] = None,
    ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default
    
class S3Core:
    S3Conf = S3Conf
    
    def __init__(
        self,
        config: Optional[Any] = None,
    ):
        self.config = config

    @property
    def ping(self) -> bool:
        if not self.config:
            return False
        s3 = self.client
        bucket = self.config.s3_bucket
        try:
            s3.head_bucket(Bucket=bucket)
            return True
        except ClientError as err:
            print(f"S3 Cloud Error: {err}")
            return False
        except Exception as exc:
            print(f"S3 Cloud Exception: {exc}")
            return False
        
    @property
    def bucket(self) -> Optional[str]:
        if not self.config:
            return
        return self.config.s3_bucket
    
    @property
    def puburl(self) -> Optional[str]:
        if not self.config:
            return
        return self.config.s3_public_url

    @property
    def client(self):
        return self.get_client(self.config)

    @classmethod
    @lru_cache
    def get_client(cls, config: Any):
        return boto3.client(
            "s3",
            endpoint_url=config.s3_endpoint,
            aws_access_key_id=config.s3_access_key,
            aws_secret_access_key=config.s3_secret_key,
            region_name=config.s3_region,
            use_ssl=config.s3_use_ssl,
            verify=config.s3_verify_ssl,
        )