"""Docstring"""
import secrets
from sqlmodel import MetaData, Session
from contextlib import asynccontextmanager
from typing import List, Annotated, Optional
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
from fastapi import FastAPI, APIRouter, Request, Depends, HTTPException, status
from fastapi.responses import JSONResponse


__all__ = ["SAPS"]

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except HTTPException as exc:
            return JSONResponse(
                status_code=exc.status_code,
                content={"error": exc.detail, "code": exc.status_code},
            )
        except ValueError as exc:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={"error": str(exc), "code": 400},
            )
        except PermissionError as exc:
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={"error": str(exc), "code": 403},
            )
        except Exception as exc:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"error": f"Internal server error: {exc}", "code": 500},
            )

class Middleware:
    def __init__(self, app: FastAPI):
        self.app = app

    def _session_secret(self, length: int = 16) -> str:
        return secrets.token_urlsafe(length)
    
    def add_httperror(self):
        self.app.add_middleware(ErrorHandlingMiddleware)

    def add_httpsredir(self):
        self.app.add_middleware(HTTPSRedirectMiddleware)

    def add_gzipcompres(self):  
        self.app.add_middleware(GZipMiddleware, minimum_size=1000, compresslevel=5)

    def add_session(self, session_secret: Optional[str] = None):
        if not session_secret:
            session_secret = self._session_secret()
        self.app.add_middleware(SessionMiddleware, secret_key=session_secret)

    def add_hosts(self, allowed_hosts: Optional[List[str]] = None):
        if allowed_hosts is None or not isinstance(allowed_hosts, List):
            # Local dev fallback only
            self.app.add_middleware(
                TrustedHostMiddleware,
                allowed_hosts=["localhost", "127.0.0.1"],
            )
        else:
            self.app.add_middleware(
                TrustedHostMiddleware,
                allowed_hosts=allowed_hosts,
            )
    
    def add_origins(self, allowed_orgins: Optional[List[str]] = None):
        if allowed_orgins is None or not isinstance(allowed_orgins, List):
            # Local dev fallback only
            self.app.add_middleware(
                CORSMiddleware,
                allow_origins=["http://localhost:3000", "http://localhost:8080"],
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )
        else:
            self.app.add_middleware(
                CORSMiddleware,
                allow_origins=allowed_orgins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )

class SapMeta:
    def __init__(self, schema: str = "public"):
        self.schema = schema.lower()
        self.metadata = MetaData(schema=self.schema)

class SapSpan:
    def __init__(self, engine, session):
        self.engine = engine
        self.state = {
            "engine": {"pgsql": engine},
            "session": {"pgsql": session},
        }
        
    @asynccontextmanager
    async def lifespan(self, _app: FastAPI):
        _app.state.db = self.state
        yield


class SapMsvc:
    def __init__(
                self, 
                name: str, 
                routers: List[APIRouter], 
                https_redir: bool = False,
                session_secret: Optional[str] = None,
                allowed_hosts: Optional[List[str]] = None,
                allowed_origins: Optional[List[str]] = None
            ):
        self.name = name.lower()
        self.app = FastAPI(dependencies=[Depends(self.sesspgs)])
        self.middleware = Middleware(self.app)
        self.middleware.add_httperror()
        if https_redir:
            self.middleware.add_httpsredir()
        self.middleware.add_gzipcompres()
        self.middleware.add_session(session_secret=session_secret)
        self.middleware.add_hosts(allowed_hosts=allowed_hosts)
        self.middleware.add_origins(allowed_orgins=allowed_origins)
        
        for router in routers:
            self.app.include_router(router)
        @self.app.get("/")
        async def root():
            return {"message": f"Hello {name.capitalize()} Microservice!"}
        
    @property
    def sesspgs(self):
        def sesspgs(
            request: Request, 
            sess_pgs: Annotated[Session, Depends(self.sessdep)]
        ):
            """Injects session into request scope."""
            request.scope["db"] = {"pgsql": sess_pgs}
        return sesspgs

    

    @classmethod
    def sessdep(cls, request: Request):
        db = cls.session(request)
        try:
            yield db
        finally:
            db.close()

    @staticmethod
    def session(request: Request):
        session = request.app.state.db["session"]["pgsql"]
        engine = request.app.state.db["engine"]["pgsql"]
        if session:
            return session()
        else:
            return Session(
                autocommit=False, 
                autoflush=False, 
                bind=engine()
            )
        
class SAPS:
    SapSpan = SapSpan
    SapMeta = SapMeta
    SapMsvc = SapMsvc