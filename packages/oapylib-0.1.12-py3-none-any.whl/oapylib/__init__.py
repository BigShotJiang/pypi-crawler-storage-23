"""Docstring"""
from .key import KEY
from .jwt import JWT
from .aur import AURS
from .adr import ADRS
from .aor import AORS
from .app import APPS
from .sap import SAPS
from .apr import APRS
from .dbs import DBSV

from .usr import UsrAuth
from .goo import GooAuth
from .uai import UaiAuth
from .inm import InmSess

from .s3c import S3Cloud
from .utl import RelDirs
from .img import ImgHandler
from .hyc import HybridCache

from .aus import JtiCore
from .ous import SesCode
from .cus import SesState
from .dbc import PgsCore, RedCore, S3Core

__all__ = ["OAUTH"]

class OAUTH:
    KEY = KEY
    JWT = JWT
    AURS = AURS
    ADRS = ADRS
    AORS = AORS
    APPS = APPS
    SAPS = SAPS
    APRS = APRS
    DBSV = DBSV

    S3Core = S3Core
    PgsCore = PgsCore
    RedCore = RedCore
    JtiCore = JtiCore
    SesCode = SesCode
    SesState = SesState

    RelDirs = RelDirs
    
    S3Cloud = S3Cloud
    UsrAuth = UsrAuth
    GooAuth = GooAuth
    UaiAuth = UaiAuth
    InmSess = InmSess
    ImgHandler = ImgHandler
    HybridCache = HybridCache