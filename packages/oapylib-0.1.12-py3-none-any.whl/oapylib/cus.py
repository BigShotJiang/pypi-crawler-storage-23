"""Docstring"""
import json
import base64
from hashlib import sha256
from secrets import token_urlsafe
from sqlmodel import SQLModel, Field
from typing import Optional, Any, Tuple

from .inm import InmSess

__all__ = ["SesState"]

class SesState:
    class SessionData(SQLModel):
        secure_nonce: str = Field()
        session_state: str = Field()

    def __init__(
            self,  
            redis: Optional[Any] = None,
            backend_outh_client: Optional[InmSess] = None,
        ):
        
        self.redis = redis.client if redis else None
        self.backend_outh_client = backend_outh_client or InmSess[str, self.SessionData]()
        
    def create_session(self) -> Tuple[str, str]:
        nonce = token_urlsafe(12)
        session_state = token_urlsafe(32)
        session_data = self.SessionData(
                secure_nonce=nonce, 
                session_state=session_state
            )
        auth_state = self.create_session_red(session_state, session_data)
        if not auth_state:
            auth_state = self.create_session_inm(session_state, session_data)
            if not auth_state:
                raise Exception("Session Service Not Working")
        return auth_state, nonce
        
    def create_session_red(self, session_state, session_data):
        if not self.redis:
            return None
        try:
            auth_state = self.auth_state(session_state, True)
            session_id = self.session_id(auth_state)
            json_data = json.dumps(
                session_data.model_dump(
                    exclude_none=True
                )
            )
            self.redis.set(session_id, json_data, ex=90)
            return auth_state
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return None
        
    def create_session_inm(self, session_code, session_data):
        if not self.backend_outh_client:
            return False
        auth_state = self.auth_state(session_code, False)
        session_id = self.session_id(auth_state)
        self.backend_outh_client.create(session_id, session_data)
        return auth_state
        
    def read_session(self, session_id):
        state_sdb = session_id.split("-", 1)[0]
        if int(state_sdb) == 1:
            return self.read_session_red(session_id)
        elif int(state_sdb) == 0:
            return self.read_session_inm(session_id)
        else: return None
        
    def read_session_red(self, session_id) -> Optional[SessionData]:
        if not self.redis:
            return None
        try:
            data = self.redis.get(session_id)
            if data is None:
                return None
            data = data.decode("utf-8")
            session_data = self.SessionData.model_validate(json.loads(data))
            return session_data
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return None
    
    def read_session_inm(self, session_id) -> Optional[SessionData]:
        if not self.backend_outh_client:
            return None
        session_data = self.backend_outh_client.read(session_id)
        return session_data

    def delete_session(self, session_id):
        state_sdb = session_id.split("-", 1)[0]
        if int(state_sdb) == 1:
            return self.delete_session_red(session_id)
        elif int(state_sdb) == 0:
            return self.delete_session_inm(session_id)
        else: return False

    def delete_session_red(self, session_id):
        if not self.redis:
            return False
        try:
            self.redis.delete(session_id)
            return True
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return False
        
    def delete_session_inm(self, session_id):
        if not self.backend_outh_client:
            return False
        self.backend_outh_client.delete(session_id)
        return True
    
    def verify_state(self, state, delete_session=False) -> bool:
        session_id = self.session_id(state)
        session_data = self.read_session(session_id)
        if not session_data:
            return False
        if delete_session:
            self.delete_session(session_id)
        state_sdb = session_id.split("-", 1)[0]
        is_redis = int(state_sdb) == 1
        verify = self.auth_state(session_data.session_state, is_redis) == state
        if not verify:
            self.delete_session(session_id)
        return verify
    
    def verify_nonce(self, state, nonce, delete_session=True) -> bool:
        session_id = self.session_id(state)
        session_data = self.read_session(session_id)
        if not session_data:
            return False
        if delete_session:
            self.delete_session(session_id)
        verify = session_data.secure_nonce == nonce
        if not verify:
            self.delete_session(session_id)
        return verify
       
    @staticmethod
    def auth_state(session_state: str, is_redis: bool = False) -> str:
        sdb = 1 if is_redis else 0
        digest = sha256(session_state.encode()).digest()
        state = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
        return f"{sdb}-{state}"

    @staticmethod
    def session_id(auth_state: str) -> str:
        parts = auth_state.split("-", 1)
        sdb = parts[0]
        padding = b"=" * (-len(parts[1].encode()) % 4)
        digest = base64.urlsafe_b64decode(parts[1].encode() + padding)
        sid = base64.urlsafe_b64encode(digest[:16]).rstrip(b"=").decode()
        return f"{sdb}-{sid}"