"""Docstring"""
from enum import Enum
from base64 import urlsafe_b64encode, urlsafe_b64decode
from typing import List, Dict, Any, Annotated, Optional, Union

from sqlmodel import Session
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import  APIRouter, Depends, Request, HTTPException, status, Query

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from .aus import JtiCore
from .dbs import DbsMsvc
from .aor import OuthSchemas
from .aur import AuthSchemas
        
__all__ = ["ADRS"]

class AdminCore:

    def __init__(
            self,
            client_key: rsa.RSAPrivateKey,
            jtis: Optional[JtiCore] = None,
        ):
        self.client_key = client_key
        self.jtis = jtis or JtiCore()

    def active_user(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.jtis.verify_token(
            access_token, required_roles, required_scopes, required_permissions
        )

    def revoke_user(
            self, 
            user_id
        ) -> str:
        revoke_access = self.jtis.revoke_usr(str(user_id))
        revok_refresh = self.jtis.revoke_usr(str(user_id), True)
        if not (revoke_access and revok_refresh):
            raise Exception("Failed to revoke user tokens")
        return user_id

    def encrypt_secret(
            self, 
            uniq_secret: str, 
            key: Optional[rsa.RSAPublicKey] = None,
        ) -> str:
        
        key = key or self.client_key.public_key()
        hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
        secret_bytes = uniq_secret.encode("utf-8")
        cipher_bytes = key.encrypt(
            secret_bytes,
            padding.OAEP(
                mgf=padding.MGF1(hash_algo()),
                algorithm=hash_algo(),
                label=b"secure_secret",
            ),
        )
        return urlsafe_b64encode(cipher_bytes).decode("utf-8")

    def decrypt_secret(
            self, 
            ciphersecret: str, 
            key: Optional[rsa.RSAPrivateKey] = None
        ) -> str:
        key = key or self.client_key
        hash_algo = {
                4096: hashes.SHA512,
                3072: hashes.SHA384,
                2048: hashes.SHA256
            }.get(key.key_size, hashes.SHA256)
        cipher_bytes = urlsafe_b64decode(ciphersecret.encode("utf-8"))
        cek_bytes = key.decrypt(
            cipher_bytes,
            padding.OAEP(
                mgf=padding.MGF1(hash_algo()),
                algorithm=hash_algo(),
                label=b"secure_secret",
            ),
        )
        return cek_bytes.decode("utf-8")
    

class ServiceError(Exception): pass
class UnauthorizedClientError(ServiceError): pass
class ClientConflictError(ServiceError): pass
class ClientNotFoundError(ServiceError): pass
class ClientPromotionError(ServiceError): pass
class InsufficientPriviledgeError(ServiceError): pass



class AdrSrvc:
    def __init__(
        self,
        admin_obj: AdminCore,
        crud_admin_obj: DbsMsvc,
        crud_client_obj: DbsMsvc,
        issuer: Optional[str] = None,
    ):
        self.admin = admin_obj
        self.crud_admin = crud_admin_obj
        self.crud_client = crud_client_obj
        self.issuer = issuer or ""

    # --- Private Helpers ---
    async def _ensure_authorized(self, session: Session, sub: str) -> Any:
        agent = await self.crud_admin.read_byid(session=session, id=sub)
        if not(agent and agent.id == sub and (agent.is_super or agent.is_admin)):
            raise InsufficientPriviledgeError("User do not have enough priviledge")
        return agent

    def _to_private(self, client: Any) -> OuthSchemas.ClientPrivate:
        """Convert client model to private schema with decrypted secret."""
        client_private = OuthSchemas.ClientPrivate.model_validate(client)
        client_private.issuer = self.issuer
        client_private.client_id = f"{str(client.id)}-{self.issuer}"
        client_private.client_secret = self.admin.decrypt_secret(client.crypted)
        return client_private
    
    async def useractive(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.admin.active_user(
            access_token, required_roles, required_scopes, required_permissions
        )

    async def create_user(
        self,
        session: Session,
        sub: str,
        data: AuthSchemas.UserCreate
    ) -> Optional[AuthSchemas.UserPrivate]:
        await self._ensure_authorized(session=session, sub=sub)
        data_dict = data.model_dump(exclude_unset=True, exclude_none=True)
        email = data_dict.get("email")
        if not email:
            return None
        query = AuthSchemas.UserQuery(email=email)
        user = await self.crud_admin.read(session=session, query=query)
        if not user:
            if "password" in data_dict:
                data_dict["password"] = self.crud_admin.model.hashed(data_dict.pop("password"))
            create = AuthSchemas.UserCreate.model_validate(data_dict)
            user = await self.crud_admin.create(session=session, data=create)
        return AuthSchemas.UserPrivate.model_validate(user)

    async def read_user(
        self,
        session: Session,
        sub: str,
        query: Optional[AuthSchemas.UserQuery] = None,
        offset: int = 0,
        limit: int = 100,
        query_type: Optional[str] = None,
    ) -> List[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        query_dict = query.model_dump() if query else {}
        query = AuthSchemas.UserQuery.model_validate(query_dict)
        if not agent.is_super:
            query.is_admin = False
            query.is_super = False

        results = await self.crud_admin.read(
            session=session,
            offset=offset,
            limit=limit,
            query=query,
            query_type=query_type,
        )
        return [AuthSchemas.UserPrivate.model_validate(obj) for obj in results]

    async def read_user_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)
        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return
        return AuthSchemas.UserPrivate.model_validate(user)
    
    async def read_user_byemail(
        self,
        session: Session,
        sub: str,
        email: str,
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_uniq(session=session, field="email", value=email)
        if not(user and user.email==email):
            return
        if not agent.is_super and user.is_super:
            return
        return AuthSchemas.UserPrivate.model_validate(user)

    async def replace_user(
        self,
        session: Session,
        sub: str,
        id: str,
        data: AuthSchemas.UserCreate
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return

        # Role-based exclusions
        if agent.is_super:
            excludes = {"is_admin", "email"} if user.is_super else set()
        else:
            excludes = {"is_admin", "email"} if not user.is_admin else {
                "is_admin", "email", "roles", "scopes", "permissions", "email_verified"
            }

        data_dict = data.model_dump(exclude=excludes, exclude_unset=True, exclude_none=True)
        if "password" in data_dict:
            data_dict["password"] = self.crud_admin.model.hashed(data_dict.pop("password"))
        update = AuthSchemas.UserPrivate.model_validate(data_dict)
        updated = await self.crud_admin.update(session=session, id=id, data=update)
        if not updated:
            return
        return AuthSchemas.UserPrivate.model_validate(updated)
    
    async def update_user(
        self,
        session: Session,
        sub: str,
        id: str,
        data: AuthSchemas.AdminUpdate
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return

        # Role-based exclusions
        if agent.is_super:
            excludes = {"is_admin", "email"} if user.is_super else set()
        else:
            excludes = {"is_admin", "email"} if not user.is_admin else {
                "is_admin", "email", "roles", "scopes", "permissions", "email_verified"
            }

        data_dict = data.model_dump(exclude=excludes, exclude_unset=True, exclude_none=True)
        update = AuthSchemas.AdminUpdate.model_validate(data_dict)
        updated = await self.crud_admin.update(session=session, id=id, data=update)
        if not updated:
            return
        return AuthSchemas.UserPrivate.model_validate(updated)

    async def delete_user_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> bool:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return False
        if not agent.is_super and user.is_super:
            return False
        return await self.crud_admin.delete_byid(session=session, id=id)
        

    async def revoke_user(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> dict:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return {"revoked": False, "id": id}
        if not agent.is_super and user.is_super:
            return {"revoked": False, "id": id}
        
        self.admin.revoke_user(str(id))
        return {"revoked": True, "id": id}
    
    # --- Public Methods ---
    async def create_client(
        self,
        session: Session,
        sub: str,
        data: OuthSchemas.ClientCreate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)
        client = await self.crud_client.read_uniq(
            session=session, 
            field="name", 
            value=data.name
        )
        if client:
            raise ClientConflictError("Client already exists")
        data = OuthSchemas.ClientCreate.model_validate(data)
        user = await self.crud_admin.read_byid(session=session, id=data.owner)
        if user is None:
            raise UnauthorizedClientError("Client owner does not exist")
        if not (user.is_active and user.is_enabled):
            raise UnauthorizedClientError("Client owner is not active or enabled")
        if not user.is_client:
            user = await self.crud_admin.update(
                session=session,
                id=data.owner,
                data={"is_client": True}
            )
            if not (user and user.is_client):
                raise ClientPromotionError("Failed to promote user to client")
        secret = self.crud_client.model.hashed()
        data.secret = self.crud_client.model.hashed(secret)
        data.crypted = self.admin.encrypt_secret(secret)
        data = OuthSchemas.ClientCreate.model_validate(data)
        client = await self.crud_client.create(session=session, data=data)
        return self._to_private(client)

    async def read_client(
        self,
        session: Session,
        sub: str,
        query: Optional[OuthSchemas.ClientQuery] = None,
        offset: int = 0,
        limit: int = 100,
        query_type: Optional[str] = None,
    ) -> List[OuthSchemas.ClientPrivate]:
        await self._ensure_authorized(session, sub)

        query_dict = query.model_dump(exclude_unset=True, exclude_none=True) if query else {}
        query = OuthSchemas.ClientQuery.model_validate(query_dict)

        results = await self.crud_client.read(
            session=session,
            offset=offset,
            limit=limit,
            query=query,
            query_type=query_type,
        )
        return [self._to_private(client) for client in results]

    async def read_client_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)

        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")

        return self._to_private(client)
    
    async def read_client_byname(
        self,
        session: Session,
        sub: str,
        name: str,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)

        client = await self.crud_client.read_uniq(
            session=session, field="name", value=name
        )
        if not client:
            raise ClientNotFoundError("Client not found")
        
        return self._to_private(client)
    
    async def replace_client(
        self,
        session: Session,
        sub: str,
        id: str,
        data: OuthSchemas.ClientCreate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)

        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        secret = self.crud_client.model.hashed()
        data.secret = self.crud_client.model.hashed(secret)
        data.crypted = self.admin.encrypt_secret(secret)
        data = OuthSchemas.ClientCreate.model_validate(data)
        data = OuthSchemas.ClientCreate.model_validate(data)
        updated = await self.crud_client.update(session=session, id=id, data=data) or client
        return self._to_private(updated)

    async def update_client(
        self,
        session: Session,
        sub: str,
        id: str,
        data: OuthSchemas.ClientUpdate,
    ) -> OuthSchemas.ClientPrivate:
        await self._ensure_authorized(session, sub)

        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        data = OuthSchemas.ClientUpdate.model_validate(data)
        updated = await self.crud_client.update(session=session, id=id, data=data) or client
        return self._to_private(updated)

    async def delete_client_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> bool:
        await self._ensure_authorized(session, sub)

        client = await self.crud_client.read_byid(session=session, id=id)
        if not client or client.id != id:
            raise ClientNotFoundError("Client not found")
        return await self.crud_client.delete_byid(session=session, id=id)

class AdrResp:
    DEFAULT_CRUD_ROLES = {
        "auth_admin": ["admin"],
        "outh_admin": ["admin"],
    }

    DEFAULT_CRUD_SCOPES = {
        "auth_admin": ["auth"],
        "outh_admin": ["outh"],
    }

    DEFAULT_CRUD_PERMISSIONS = {
        "auth_admin": ["read", "write"],
        "outh_admin": ["read", "write"]
    }

    DEFAULT_IS_PROTECTED = {
        "auth_admin": True,
        "outh_admin": True,
    }
    def __init__(
        self,
        service_obj: AdrSrvc,
        crud_roles: Optional[Dict[str, List[str]]] = None,
        crud_scopes: Optional[Dict[str, List[str]]] = None,
        crud_permissions: Optional[Dict[str, List[str]]] = None,
        is_protected: Optional[Dict[str, bool]] = None
    ):
        self.service = service_obj
        self.security = HTTPBearer(auto_error=False)
        self.crud_roles = crud_roles or self.DEFAULT_CRUD_ROLES
        self.crud_scopes = crud_scopes or self.DEFAULT_CRUD_SCOPES
        self.crud_permissions = crud_permissions or self.DEFAULT_CRUD_PERMISSIONS
        self.is_protected = is_protected or self.DEFAULT_IS_PROTECTED
    
    def user(self, method: Optional[str] = None):
        if method is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Error: user not authorised",
            )
        is_protected = self.is_protected.get(method, False)
        required_roles = self.crud_roles.get(method)
        required_scopes= self.crud_scopes.get(method)
        required_permissions = self.crud_permissions.get(method)
        async def loginuser(creds: HTTPAuthorizationCredentials = Depends(self.security)):
            try:
                if not is_protected:
                    return "public"
                access_token = creds.credentials
                sub = await self.service.useractive(access_token, required_roles, required_scopes, required_permissions)
                return sub
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Error: User not Found {exc}",
                ) from exc
        return loginuser
    
    @property
    def post_user(self):
        async def create_user(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            data: Annotated[AuthSchemas.UserCreate, Depends()]
        ) -> Optional[AuthSchemas.UserPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.create_user(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid user data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return create_user

    @property
    def get_user(self):
        async def read_user(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            query: Annotated[Optional[AuthSchemas.UserQuery], Depends(AuthSchemas.UserQuery)] = None,
            offset: int = 0,
            limit: Annotated[int, Query(le=100)] = 100,
            query_type: Optional[str] = None,
        ) -> List[AuthSchemas.UserPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.read_user(
                    session=db_session, sub=user,
                    offset=offset, limit=limit,
                    query=query, query_type=query_type
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_user

    @property
    def get_user_byid(self):
        async def read_user_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> Optional[AuthSchemas.UserPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_user_byid(session=db_session, sub=user, id=id)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_user_byid
    
    @property
    def get_user_byemail(self):
        async def read_user_byemail(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            email: str,
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_user_byemail(session=db_session, sub=user, email=email)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"User with email {email} not found"
                    )
                return result
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"User read by email failed: {exc}"
                ) from exc
        return read_user_byemail

    @property
    def get_revoke(self):
        async def get_revoke(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> JSONResponse:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin privileges required"
                    )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.revoke_user(session=db_session, sub=user, id=id)

                if not result.get("revoked", False):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Revocation failed for user id {id}"
                    )

                return JSONResponse(content=result, status_code=status.HTTP_200_OK)
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin revoke failed: {exc}"
                )
        return get_revoke

    @property
    def put_user(self):
        async def replace_user(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
            data: Annotated[AuthSchemas.UserCreate, Depends()],
        ) -> Optional[AuthSchemas.UserPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.replace_user(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid user data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return replace_user

    @property
    def patch_user(self):
        async def update_user(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
            data: Annotated[AuthSchemas.AdminUpdate, Depends()],
        ) -> Optional[AuthSchemas.UserPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.update_user(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid update data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return update_user

    @property
    def delete_user(self):
        async def delete_user_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> JSONResponse:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                deleted = await self.service.delete_user_byid(session=db_session, sub=user, id=id)
                if not deleted:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )
                return JSONResponse(content={"removed": True}, status_code=200)
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return delete_user_byid
    
    @property
    def post_client(self):
        async def create_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            data: Annotated[OuthSchemas.ClientCreate, Depends()]
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.create_client(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid client data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return create_client

    @property
    def get_client(self):
        async def read_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            query: Annotated[Optional[OuthSchemas.ClientQuery], Depends(OuthSchemas.ClientQuery)] = None,
            offset: int = 0,
            limit: Annotated[int, Query(le=100)] = 100,
            query_type: Optional[str] = None,
        ) -> List[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                return await self.service.read_client(
                    session=db_session, sub=user,
                    offset=offset, limit=limit,
                    query=query, query_type=query_type
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client

    @property
    def get_client_byid(self):
        async def read_client_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_client_byid(session=db_session, sub=user, id=id)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client_byid
    
    @property
    def get_client_byname(self):
        async def read_client_byname(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            name: str,
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.read_client_byname(session=db_session, sub=user, name=name)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return read_client_byname

    @property
    def put_client(self):
        async def replace_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
            data: Annotated[OuthSchemas.ClientCreate, Depends()],
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.replace_client(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid client data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return replace_client

    @property
    def patch_client(self):
        async def update_client(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
            data: Annotated[OuthSchemas.ClientUpdate, Depends()],
        ) -> Optional[OuthSchemas.ClientPrivate]:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.update_client(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid update data: {exc}"
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return update_client

    @property
    def delete_client(self):
        async def delete_client_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("outh_admin"))],
            id: str,
        ) -> JSONResponse:
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found, login and try again"
                )
            try:
                db_session = request.scope["db"]["pgsql"]
                deleted = await self.service.delete_client_byid(session=db_session, sub=user, id=id)
                if not deleted:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="Client not found"
                    )
                return JSONResponse(content={"removed": True}, status_code=200)
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Unexpected error: {exc}"
                )
        return delete_client_byid

class AdrMsvc:
    def __init__(
        self,
        response_obj: "AdrResp",
        prefix: Optional[str] = None,
        tags: List[Union[str, Enum]] | None = None,
    ):
        self.router = APIRouter(
            prefix=prefix or "",
            tags=tags,
            responses={404: {"description": "Not found"}},
            dependencies=[Depends(response_obj.security)]
        )
        self.response = response_obj
        self.register_routes()

    def register_routes(self):
        # --- Admin User Routes ---
        @self.router.post("/admin/user")
        async def create_user(_resp=Depends(self.response.post_user)):
            return _resp

        @self.router.get("/admin/user")
        async def list_users(_resp=Depends(self.response.get_user)):
            return _resp

        @self.router.get("/admin/user/id/{id}")
        async def get_user_by_id(_resp=Depends(self.response.get_user_byid)):
            return _resp
        
        @self.router.get("/admin/user/email/{email}")
        async def get_user_by_email(_resp=Depends(self.response.get_user_byemail)):
            return _resp

        @self.router.get("/admin/revoke/{id}")
        async def revoke_user(_resp=Depends(self.response.get_revoke)):
            return _resp

        @self.router.put("/admin/user/{id}")
        async def replace_user(_resp=Depends(self.response.put_user)):
            return _resp

        @self.router.patch("/admin/user/{id}")
        async def update_user(_resp=Depends(self.response.patch_user)):
            return _resp

        @self.router.delete("/admin/user/{id}")
        async def delete_user(_resp=Depends(self.response.delete_user)):
            return _resp

        # --- Admin Client Routes ---
        @self.router.post("/admin/client")
        async def create_client(_resp=Depends(self.response.post_client)):
            return _resp

        @self.router.get("/admin/client")
        async def list_clients(_resp=Depends(self.response.get_client)):
            return _resp

        @self.router.get("/admin/client/id/{id}")
        async def get_client_by_id(_resp=Depends(self.response.get_client_byid)):
            return _resp
        
        @self.router.get("/admin/client/name/{name}")
        async def get_client_by_name(_resp=Depends(self.response.get_client_byname)):
            return _resp

        @self.router.put("/admin/client/{id}")
        async def replace_client(_resp=Depends(self.response.put_client)):
            return _resp

        @self.router.patch("/admin/client/{id}")
        async def update_client(_resp=Depends(self.response.patch_client)):
            return _resp

        @self.router.delete("/admin/client/{id}")
        async def delete_client(_resp=Depends(self.response.delete_client)):
            return _resp

class ADRS:
    AdrSrvc = AdrSrvc
    AdrResp = AdrResp
    AdrMsvc = AdrMsvc
    AdminCore = AdminCore