"""Docstring"""
from time import time
from hashlib import sha256
from secrets import token_urlsafe
from base64 import urlsafe_b64encode
from sqlmodel import SQLModel, Field
from typing import Optional, Any, List

from .jwt import JWT
from .inm import InmSess

__all__ = ["JtiCore"]

class JtiCore:
    class SessionUser(SQLModel):
        exp: int = Field()
        id: Optional[str] = Field(default=None)
        jtis: set = Field()

    class SessionData(SQLModel):
        exp: int = Field()
        id: str = Field()

    def __init__(
            self,
            verify_key: Optional[Any] = None,
            verify_algo: str  = "HS256",
            redis: Optional[Any] = None,
            backend_auth_user: Optional[InmSess] = None,
            backend_auth_jtis: Optional[InmSess] = None,
        ):
        self.verify_key = verify_key or "secret_key"
        self.verify_algo = verify_algo
        self.redis = redis.client if redis else None
        self.backend_auth_user = backend_auth_user or InmSess[str, self.SessionUser]()
        self.backend_auth_jtis = backend_auth_jtis or InmSess[str, self.SessionData]()
        


    def revoke_usr(self, user_id: str, is_refresh: bool = False):
        h = sha256(str(user_id).encode()).digest()
        user_id = urlsafe_b64encode(h[:16]).rstrip(b'=').decode()
        prefix = "refresh" if is_refresh else "access"
        set_key = f"{prefix}_usr:{user_id}"
        is_revoke_red = self.revoke_usr_red(set_key, prefix)
        is_revoke_inm = self.revoke_usr_inm(set_key, prefix)
        return is_revoke_red and is_revoke_inm

    def revoke_usr_inm(self, set_key: str, prefix: str) -> bool:
        if not (self.backend_auth_user and self.backend_auth_jtis):
            return False
        session_user = self.backend_auth_user.read(set_key)
        if not session_user:
            return False
        for j in session_user.jtis:
            jti_key = f"{prefix}_jti:{j}"
            self.backend_auth_jtis.delete(jti_key)
            session_user.jtis.discard(j)
            self.backend_auth_user.update(set_key, session_user)
        self.backend_auth_user.delete(set_key)
        return True
    
    def revoke_usr_red(self, set_key: str, prefix: str) -> bool:
        if not self.redis:
            return False
        try:
            members = self.redis.smembers(set_key) or []
            pipe = self.redis.pipeline()
            for j in members:
                jti_key = f"{prefix}_jti:{j}"
                pipe.delete(jti_key)
                pipe.srem(set_key, j)
            pipe.delete(set_key)
            pipe.execute()
            return True
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return False 
    
    def store_jti(self, jti: str, exp: int, is_refresh: bool = False) -> str:
        prefix = "refresh" if is_refresh else "access"
        jtis = self.store_jti_red(prefix, jti, exp)
        if not jtis:
            jtis= self.store_jti_inm(prefix, jti, exp)
            if not jtis:
                raise Exception("Session Service Not Working")
        return jtis

    def store_jti_red(self, prefix: str, jti: str, exp: int) -> Optional[str]:
        ttl_seconds = max(0, exp - int(time()))
        if not self.redis or ttl_seconds <= 0:
            return None
        try:
            hjti = self.hashed_jti(jti)
            user_id = hjti.rsplit("-", 1)[-1]
            set_key = f"{prefix}_usr:{user_id}"
            jti_key = f"{prefix}_jti:{hjti}"
            pipe = self.redis.pipeline()
            sjti = self.session_jti(hjti, is_redis=True)
            pipe.sadd(set_key, sjti)
            pipe.expire(set_key, ttl_seconds + 60)
            pipe.set(jti_key, user_id, ex=ttl_seconds)
            pipe.execute()
            sdb = sjti.split("-", 1)[0]
            return f"{sdb}-{jti}"
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return None
        
    def store_jti_inm(self, prefix: str, jti: str, exp: int) -> Optional[str]:
        if not (self.backend_auth_user and self.backend_auth_jtis):
            return None
        hjti = self.hashed_jti(jti)
        user_id = hjti.rsplit("-", 1)[-1]
        set_key = f"{prefix}_usr:{user_id}"
        jti_key = f"{prefix}_jti:{hjti}"
        sjti = self.session_jti(hjti, is_redis=False)
        session_user = self.backend_auth_user.read(set_key)
        if session_user:
            session_user.exp = exp
            session_user.jtis.add(sjti)  
            self.backend_auth_user.update(set_key, session_user)
        
        else:
            jtis = {sjti}
            session_user = self.SessionUser(exp = exp, jtis=jtis)
            self.backend_auth_user.create(set_key, session_user)
        session_data = self.SessionData(exp = exp, id=user_id)
        self.backend_auth_jtis.create(jti_key, session_data)
        sdb = sjti.split("-", 1)[0]
        return f"{sdb}-{jti}"

    def verify_jti(self, jti: str, is_refresh: bool = False) -> bool:
        jti_parts = jti.split("-", 1)
        jti_sdb = jti_parts[0]
        jti = self.hashed_jti(jti_parts[-1])
        sub = jti.rsplit("-", 1)[1]
        prefix = "refresh" if is_refresh else "access"
        jti_key = f"{prefix}_jti:{jti}"
        if int(jti_sdb) == 1:
            return self.verify_jti_red(jti_key, sub)
        elif int(jti_sdb) == 0:
            return self.verify_jti_inm(jti_key, sub)
        else: return False

    def verify_jti_red(self, jti_key: str, sub: str) -> bool:
        if not self.redis:
            return False
        try:
            id = self.redis.get(jti_key)
            if id is  None:
                return False
            id = id.decode("utf-8")
            return id == sub
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return False
            
    def verify_jti_inm(self, jti_key: str, sub: str) -> bool:
        if not self.backend_auth_jtis: 
            return False
        id = self.backend_auth_jtis.verify(jti_key)
        return id == sub
    
    def revoke_jti(self, jti: str, is_refresh: bool = False) -> bool:
        jti_parts = jti.split("-", 1)
        jti_sdb = jti_parts[0]
        jti = self.hashed_jti(jti_parts[-1])
        user_id = jti.rsplit("-", 1)[-1]
        prefix = "refresh" if is_refresh else "access"
        set_key = f"{prefix}_usr:{user_id}"
        jti_key = f"{prefix}_jti:{jti}"
        if int(jti_sdb) == 1:
            return self.revoke_jti_red(set_key, jti_key, jti)
        elif int(jti_sdb) == 0:
            return self.revoke_jti_inm(set_key, jti_key, jti)
        else: return False

    def revoke_jti_red(self, set_key: str, jti_key: str, jti: str) -> bool:
        if not self.redis:
            return False
        try:
            pipe = self.redis.pipeline()
            pipe.delete(jti_key)
            pipe.srem(set_key, jti)
            pipe.execute()
            return True
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return False
        

    def revoke_jti_inm(self, set_key: str, jti_key: str, jti: str) -> bool:
        if not (self.backend_auth_user and self.backend_auth_jtis):
            return False
        session_user = self.backend_auth_user.read(set_key)
        if not session_user:
            return False
        self.backend_auth_jtis.delete(jti_key)
        session_user.jtis.discard(jti)  
        self.backend_auth_user.update(set_key, session_user)
        return True
    
    def verify_token(
            self, 
            token,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ):
        header = JWT.header(token)
        try:
            payload = JWT.decode(
                token,
                self.verify_key,
                algorithms=[self.verify_algo, header["alg"]]
            )
        except JWT.JWTError as exc:
            raise Exception from exc

        jti = payload.get("jti")
        sub = payload.get("sub")
        if not jti:
            raise Exception("Missing JTI")
        elif not sub:
            raise Exception("Missing SUB")
    
        is_verify = self.verify_jti(jti) and self.verify_sub(jti, sub)
        if not is_verify:
            raise Exception("Invalid JTI")

        user_roles = set(payload.get("roles", []))
        if required_roles:
            if not user_roles.intersection(required_roles):
                raise Exception( "Insufficient role privileges")
            
        user_scopes = set(payload.get("scopes", []))
        if required_scopes:
            if not user_scopes.issuperset(set(required_scopes)):
                raise Exception("Missing required scopes")

        user_permissions = set(payload.get("permissions", []))
        if required_permissions:
            if not user_permissions.issuperset(set(required_permissions)):
                raise Exception("Missing required permissions")

        # Everything ok → return payload to endpoint
        return sub
    
    @staticmethod
    def session_jti(jti: str, is_redis: bool = False) -> str:
        sdb = 1 if is_redis else 0
        return f"{sdb}-{jti}"
    
    @staticmethod
    def generate_jti(user_id: str) -> str:
        ts = int(time() * 1000)  # timestamp in ms
        rand = token_urlsafe(16)  # random string
        return f"{ts}-{rand}-{user_id}"
    
    @staticmethod
    def hashed_jti(jti: str) -> str:
        prefix, user_id = jti.rsplit("-", 1)
        h = sha256(str(user_id).encode()).digest()
        user_hash = urlsafe_b64encode(h[:16]).rstrip(b'=').decode()
        return f"{prefix}-{user_hash}"
    
    @staticmethod
    def verify_sub(jti: str, sub:str):
        return sub == jti.rsplit("-", 1)[-1]