"""Docstring"""
import json
import base64
from hashlib import sha256
from secrets import token_urlsafe
from base64 import urlsafe_b64encode
from sqlmodel import SQLModel, Field
from typing import Optional, Any, Tuple

from .inm import InmSess

__all__ = ["SesCode"]

class SesCode:
    class SessionData(SQLModel):
        session_code: str = Field()
        auth_scope: Optional[str] = Field(default=None)
        secure_nonce: Optional[str] = Field(default=None)
        user_hash: Optional[str] = Field(default=None)

    def __init__(
            self,  
            redis: Optional[Any] = None,
            backend_outh_user: Optional[InmSess] = None,
        ):
        
        self.redis = redis.client if redis else None
        self.backend_outh_user = backend_outh_user or InmSess[str, self.SessionData]()

    def create_session(
            self,
            user_id: str,
            scope: Optional[str] = None, 
            nonce: Optional[str] = None
        ) -> str:
        h = sha256(str(user_id).encode()).digest()
        user_hash = urlsafe_b64encode(h[:16]).rstrip(b'=').decode()
        session_code = token_urlsafe(32)
        session_data = self.SessionData(
            session_code=session_code,
            auth_scope = scope,
            secure_nonce=nonce,
            user_hash=user_hash,
        )
        auth_code = self.create_session_red(session_code, session_data)
        if not auth_code:
            auth_code = self.create_session_inm(session_code, session_data)
            if not auth_code:
                raise Exception("Session Service Not Working")
        return auth_code
        
    def create_session_red(self, session_code, session_data):
        if not self.redis:
            return None
        try:
            auth_code = self.auth_code(session_code, True)
            session_id = self.session_id(auth_code)
            json_data = json.dumps(
                session_data.model_dump(
                    exclude_none=True
                )
            )
            self.redis.set(session_id, json_data, ex=60)
            return auth_code
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return None
        
    def create_session_inm(self, session_code, session_data):
        if not self.backend_outh_user:
            return False
        auth_code = self.auth_code(session_code, False)
        session_id = self.session_id(auth_code)
        self.backend_outh_user.create(session_id, session_data)
        return auth_code
    
    def read_session(self, session_id):
        code_sdb = session_id.split("-", 1)[0]
        if int(code_sdb) == 1:
            return self.read_session_red(session_id)
        elif int(code_sdb) == 0:
            return self.read_session_inm(session_id)
        else: return None
        
    def read_session_red(self, session_id) -> Optional[SessionData]:
        if not self.redis:
            return None
        try:
            data = self.redis.get(session_id)
            if data is None:
                return None
            data = data.decode("utf-8")
            session_data = self.SessionData.model_validate(json.loads(data))
            return session_data
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return None
    
    def read_session_inm(self, session_id) -> Optional[SessionData]:
        if not self.backend_outh_user:
            return None
        session_data = self.backend_outh_user.read(session_id)
        return session_data
    
    def delete_session(self, session_id):
        code_sdb = session_id.split("-", 1)[0]
        if int(code_sdb) == 1:
            return self.delete_session_red(session_id)
        elif int(code_sdb) == 0:
            return self.delete_session_inm(session_id)
        else: return False

    def delete_session_red(self, session_id):
        if not self.redis:
            return False
        try:
            self.redis.delete(session_id)
            return True
        except Exception as exe:
            print(f"Redis Error: {exe}")
            return False
        
    def delete_session_inm(self, session_id):
        if not self.backend_outh_user:
            return False
        self.backend_outh_user.delete(session_id)
        return True
    
    def verify_code(
            self,
            user_id: str,
            code: str, 
            delete_session: bool=False
        ) -> Tuple[bool, Optional[str], Optional[str]]:
        session_id = self.session_id(code)
        session_data = self.read_session(session_id)
        if not session_data:
            return False, None, None
        h = sha256(str(user_id).encode()).digest()
        user_hash = urlsafe_b64encode(h[:16]).rstrip(b'=').decode()
        if session_data.user_hash != user_hash:
            return False, None, None
        if delete_session:
            self.delete_session(session_id)
        code_sdb = session_id.split("-", 1)[0]
        is_redis = int(code_sdb) == 1
        return (
            self.auth_code(session_data.session_code, is_redis) == code,
            session_data.auth_scope, 
            session_data.secure_nonce
        )
       
    @staticmethod
    def auth_code(session_code: str, is_redis: bool = False) -> str:
        sdb = 1 if is_redis else 0
        digest = sha256(session_code.encode()).digest()
        code = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
        return f"{sdb}-{code}"

    @staticmethod
    def session_id(auth_code: str) -> str:
        parts = auth_code.split("-", 1)
        sdb = parts[0]
        padding = b"=" * (-len(parts[1].encode()) % 4)
        digest = base64.urlsafe_b64decode(parts[1].encode() + padding)
        sid = base64.urlsafe_b64encode(digest[:16]).rstrip(b"=").decode()
        return f"{sdb}-{sid}"