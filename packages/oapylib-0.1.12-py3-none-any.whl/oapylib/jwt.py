"""Docstring"""
import math
import json
import base64
import hashlib
from time import time
from secrets import token_urlsafe
from datetime import datetime, timedelta
from typing import Mapping, Optional, Any, Dict, Union

from cryptography.utils import int_to_bytes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.asymmetric import padding, rsa, ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature

__all__ = ["JWT"]

class CRYPTError(Exception):pass
class JWSError(CRYPTError):pass
class SignatureError(JWSError):pass
class JWTError(CRYPTError):pass
class JWTClaimsError(JWTError):pass
class ExpiredSignatureError(JWTError):pass
    
class JWT:
    JWTError = JWTError
    
    @classmethod
    def encode(
            cls, 
            claims: dict, 
            key, 
            algorithm="HS256", 
            headers: Optional[dict] = None,
            access_token=None, 
            is_pkcs = False,
            delta = 3600,
        ) -> str:
        headers = headers or {}
        if headers.get("alg") is None:
            headers["alg"] = cls.jwtalg(key, is_pkcs, algorithm)
        if headers.get("typ") is None:
            headers["typ"] = "JWT"
        claims_obj = ValidateClaims(claims=claims, algorithm=algorithm, access_token=access_token)
        claims_obj(encode = True, delta=delta)
        header_b64 = cls.encode_json(headers)
        payload_b64 = cls.encode_json(claims_obj.claims)
        signing_input = header_b64 + b"." + payload_b64
        signature = JWS.sign(key, signing_input)
        return CMNUtils.to_str(signing_input + b"." + CMNUtils.to_bytes(signature))

    @classmethod
    def decode(
            cls, 
            token: Union[str, bytes], 
            key,
            algorithms=None,
            options=None,
            audience = None, 
            issuer=None, 
            subject=None, 
            access_token=None, 
            is_pkcs=False,
        ) -> dict:
        options = options or {}
        defaults = {
            "verify": {
                "signature": True,
                "aud": True,
                "iat": True,
                "exp": True,
                "nbf": True,
                "iss": True,
                "sub": True,
                "jti": True,
                "at_hash": True,
            },
            "require": {
                "aud": False,
                "iat": False,
                "exp": False,
                "nbf": False,
                "iss": False,
                "sub": False,
                "jti": False,
                "at_hash": False,
            },
            "leeway": 0,
        }
        for section in ("verify", "required"):
            defaults.setdefault(section, {})
            for key in options.get(section, []):
                defaults[section][key] = True

        defaults["leeway"] = int(options.get("leeway", defaults.get("leeway", 0)))
        token = CMNUtils.to_bytes(token)
        parts = token.split(b'.')
        if len(parts) != 3:
            raise ValueError("Invalid JWT format: expected 3 parts")

        signing_input, signature = b'.'.join(parts[:2]), parts[2]
        header = cls.decode_json(parts[0])
        algorithm = header.get("alg")
        algorithms = [algorithms] if isinstance(algorithms, str) else algorithms
        if not algorithm:
            JWSError("No algorithm was specified in the JWS header.")
        elif algorithms is not None and algorithm not in algorithms:
            raise JWSError("The specified alg value is not allowed")
        elif algorithm != cls.jwtalg(key, is_pkcs, algorithm):
            raise JWSError("The specified alg value is not allowed")
        
        try:
            verify = defaults.get("verify", {}).get("signature", True)
            if verify:
                JWS.verify(key, signature, signing_input, is_pkcs, algorithm)
            payload = parts[1]
        except JWSError as e:
            raise JWTError(e)
        claims = cls.decode_json(payload)
        
        if not isinstance(claims, Mapping):
            raise JWTError("Invalid payload string: must be a json object")
        
        ValidateClaims(
            claims=claims,
            audience=audience,
            issuer=issuer,
            subject=subject,
            algorithm=algorithm,
            access_token=access_token,
            options=defaults,
            )()

        return claims
    
    @classmethod
    def header(cls, token):
        token = CMNUtils.to_bytes(token)
        parts = token.split(b'.')
        if len(parts) != 3:
            raise ValueError("Invalid JWT format: expected 3 parts")
        header = cls.decode_json(parts[0])
        return header
    
    @classmethod
    def jwtalg(cls, key, is_pkcs=False, algo: Optional[str] = None):
        if CMNUtils.is_rsa_key(key):
            size = key.key_size
            prefix = "RS" if is_pkcs else "PS"
            return f"{prefix}{512 if size >= 4096 else 384 if size >= 3072 else 256}"
        elif CMNUtils.is_ec_key(key):
            return {
                "secp256r1": "ES256",
                "secp384r1": "ES384",
                "secp521r1": "ES512",
                "secp256k1": "ES256K"
            } .get(key.curve.name, "ES256")
        elif CMNUtils.is_hmac_key(key) and algo in ["HS256", "HS384", "HS512"]:
            return algo
        else:
            raise ValueError("Unsupported key type")

    @classmethod
    def encode_json(cls, obj: dict) -> bytes:
        return CMNUtils.b64url_encode(
            json.dumps(obj, separators=(",", ":")).encode()
        )

    @classmethod
    def decode_json(cls, data: bytes) -> dict:
        return json.loads(CMNUtils.b64url_decode(data).decode())
    
    @staticmethod
    def build_claims(
            data: Optional[Dict[str, Any]] = None,
            iss: Optional[str]=None,
            sub: Optional[str]=None,
            aud: Optional[str]=None,
            jti: Optional[str]=None,
            iat: Optional[float] = None,
            nbf: Optional[float] = None,
            exp: Optional[float] = None
            
        ):
        def generate_jti(user_id: str) -> str:
            ts = int(time() * 1000)  # timestamp in ms
            rand = token_urlsafe(16)  # random string
            return f"{ts}-{rand}-{user_id}"
        
        data = data or {}
        iat = int(iat or data.get("iat") or time())
        subject = sub or data.get("subject", None) or data.get("sub", None) or "public"
        claims = {
        "sub": subject,
        "iat": iat,
        "nbf": int(nbf or data.get("nbf", iat)),
        "exp": int(exp or data.get("exp", iat + 3600)),
        "jti": jti or data.get("jti", generate_jti(subject)),
        "iss": iss or data.get("iss") or data.get("issuer"),
        "aud": aud or data.get("aud") or data.get("audience"),
        
        "roles": data.get("roles"),
        "scopes": data.get("scopes"),
        "permissions": data.get("permissions"),
        "name": data.get("name"),
        "email": data.get("email"),
        "email_verified": data.get("email_verified"),
        "picture": data.get("picture"),
        "given_name": data.get("given_name"),
        "family_name": data.get("family_name"),
        "locale": data.get("locale"),
        "org": data.get("org", ""),
        "custom": data.get("custom"),
        "auth_time": data.get("auth_time", iat),
        }
        return dict(filter(lambda item: item[1] is not None, claims.items()))
    
    
    
class JWS:
    HASHES = {
        "HS256": hashes.SHA256, 
        "HS384": hashes.SHA384, 
        "HS512": hashes.SHA512,
        "RS256": hashes.SHA256,
        "RS384": hashes.SHA384,
        "RS512": hashes.SHA512,
        "PS256": hashes.SHA256,
        "PS384": hashes.SHA384,
        "PS512": hashes.SHA512,
        "ES256": hashes.SHA256,
        "ES384": hashes.SHA384,
        "ES512": hashes.SHA512,
        "ES256K": hashes.SHA256,
        2048: hashes.SHA256,
        3072: hashes.SHA384,
        4096: hashes.SHA512,
        "secp256r1": hashes.SHA256,
        "secp384r1": hashes.SHA384,
        "secp521r1": hashes.SHA512,
        "secp256k1": hashes.SHA256
    }
    
    @classmethod
    def sign(
        cls,
        private_key, 
        signing_input: Union[str, bytes],
        is_pkcs: bool = False,
        algorithm: Optional[str] = None
        ) -> str:
        data = CMNUtils.to_bytes(signing_input)
        hash_algo = cls.select_hash(private_key, algorithm)

        if CMNUtils.is_rsa_key(private_key):
            signature = private_key.sign(
                data,
                padding.PKCS1v15() if is_pkcs else padding.PSS(
                    mgf=padding.MGF1(hash_algo()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hash_algo()
            )
        elif CMNUtils.is_ec_key(private_key):
            if hash_algo().digest_size * 8 > private_key.curve.key_size:
                raise TypeError(
                    "this curve (%s) is too short "
                    "for your digest (%d)" % (private_key.curve.name, 8 * hash_algo().digest_size * 8)
                )
            der = private_key.sign(data, ec.ECDSA(hash_algo()))
            signature = CMNUtils.der_toraw(der, private_key)
        elif CMNUtils.is_hmac_key(private_key):
            hmac_key = CMNUtils.to_bytes(private_key)
            h = hmac.HMAC(hmac_key, hash_algo() , backend=default_backend())
            h.update(data)
            signature = h.finalize()
        else:
            raise ValueError(f"Unsupported key type for signature: {type(private_key)}")
        return CMNUtils.to_str(CMNUtils.b64url_encode(signature))

    @classmethod
    def verify(
            cls,
            public_key, 
            signature_b64: Union[str, bytes], 
            signing_input: Union[str, bytes],
            is_pkcs: bool = False,
            algorithm: Optional[str] = None,
        ) -> None:
        data = CMNUtils.to_bytes(signing_input)
        signature = CMNUtils.b64url_decode(CMNUtils.to_bytes(signature_b64))
        hash_algo = cls.select_hash(public_key, algorithm)
        try:
            if CMNUtils.is_rsa_key(public_key):
                public_key.verify(
                    signature,
                    data,
                    padding.PKCS1v15() if is_pkcs else padding.PSS(
                        mgf=padding.MGF1(hash_algo()),
                        salt_length=padding.PSS.MAX_LENGTH
                    ),
                    hash_algo()
                )
            elif CMNUtils.is_ec_key(public_key):
                signature = CMNUtils.raw_toder(signature, public_key)
                public_key.verify(signature, data, ec.ECDSA(hash_algo()))
            
            elif CMNUtils.is_hmac_key(public_key):
                hmac_key = CMNUtils.to_bytes(public_key)
                h = hmac.HMAC(hmac_key, hash_algo(), backend=default_backend())
                h.update(data)
                h.verify(signature)
            else:
                raise ValueError(f"Unsupported key type for verification: {type(public_key)}")
        except Exception as exc:
            raise ValueError(f"Signature verification failed for key type {type(public_key)}") from exc
    
    @classmethod
    def select_hash(cls, key, algorithm: Optional[str] = None) -> type[hashes.HashAlgorithm]:
        if CMNUtils.is_rsa_key(key):
            size = key.key_size
            hash_size = cls.HASHES.get(size)
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_size or hash_algo or hashes.SHA256
        elif CMNUtils.is_ec_key(key):
            size = key.key_size
            name = key.curve.name
            hash_size = cls.HASHES.get(size)
            hash_curve = cls.HASHES.get(name)
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_curve or hash_size or hash_algo or hashes.SHA256
        
        elif CMNUtils.is_hmac_key(key):
            hash_algo = cls.HASHES.get(algorithm) if algorithm else None
            return hash_algo or hashes.SHA256
        
        else:
            raise ValueError(f"Unsupported key type for hash selection: {type(key)}")


class ValidateClaims:
    HASHES = {
        "HS256": hashlib.sha256,
        "HS384": hashlib.sha384,
        "HS512": hashlib.sha512,
        "RS256": hashlib.sha256,
        "RS384": hashlib.sha384,
        "RS512": hashlib.sha512,
        "PS256": hashlib.sha256,
        "PS384": hashlib.sha384,
        "PS512": hashlib.sha512,
        "ES256": hashlib.sha256,
        "ES384": hashlib.sha384,
        "ES512": hashlib.sha512,
        "ES256K": hashlib.sha256
    }
    def __init__(
            self, 
            claims, 
            audience = None, 
            issuer=None, 
            subject=None,
            algorithm = None,
            access_token=None, 
            options=None, 
        ):
        self.claims = claims
        self.audience = audience
        self.issuer = issuer
        self.subject = subject
        self.algorithm = algorithm or "HS256"
        self.access_token = access_token
        self.options = options or {}
        self.leeway = self.options.get("leeway", 0)
        if isinstance(self.leeway, timedelta):
            self.leeway = CMNUtils.timedelta_seconds(self.leeway)
        
    def validate_iat(self):
        if "iat" not in self.claims:
            return

        try:
            iat = int(self.claims["iat"])
        except ValueError:
            raise JWTClaimsError("Issued At claim (iat) must be an integer.")
        
        now = int(time())

        if iat > (now + self.leeway):
            raise JWTClaimsError("The token cant be issued in future invalid (iat)")


    def validate_nbf(self):

        if "nbf" not in self.claims:
            return

        try:
            nbf = int(self.claims["nbf"])
        except ValueError:
            raise JWTClaimsError("Not Before claim (nbf) must be an integer.")

        now = int(time())

        if nbf > (now + self.leeway):
            raise JWTClaimsError("The token is not yet valid (nbf)")

    def validate_exp(self):

        if "exp" not in self.claims:
            return

        try:
            exp = int(self.claims["exp"])
        except ValueError:
            raise JWTClaimsError("Expiration Time claim (exp) must be an integer.")

        now = int(time())

        if exp < (now - self.leeway):
            raise ExpiredSignatureError("Signature has expired.")

    def validate_aud(self):
        if "aud" not in self.claims:
            # if audience:
            #     raise JWTError('Audience claim expected, but not in claims')
            return

        audience_claims = self.claims["aud"]
        if isinstance(audience_claims, str):
            audience_claims = [audience_claims]
        if not isinstance(audience_claims, list):
            raise JWTClaimsError("Invalid claim format in token")
        if any(not isinstance(c, str) for c in audience_claims):
            raise JWTClaimsError("Invalid claim format in token")
        if self.audience not in audience_claims:
            raise JWTClaimsError("Invalid audience")

    def validate_iss(self):
        if self.issuer is not None:
            if isinstance(self.issuer, str):
                self.issuer = (self.issuer,)
            if self.claims.get("iss") not in self.issuer:
                raise JWTClaimsError("Invalid issuer")


    def validate_sub(self):

        if "sub" not in self.claims:
            return

        if not isinstance(self.claims["sub"], str):
            raise JWTClaimsError("Subject must be a string.")

        if self.subject is not None:
            if self.claims.get("sub") != self.subject:
                raise JWTClaimsError("Invalid subject")


    def validate_jti(self):
        if "jti" not in self.claims:
            return

        if not isinstance(self.claims["jti"], str):
            raise JWTClaimsError("JWT ID must be a string.")


    def validate_at_hash(self):
        if "at_hash" not in self.claims:
            return

        if not self.access_token:
            msg = "No access_token provided to compare against at_hash claim."
            raise JWTClaimsError(msg)
        hashalg = self.HASHES.get(self.algorithm, hashlib.sha256)
        try:
            expected_hash = CMNUtils.at_hash(self.access_token, hashalg)
        except (TypeError, ValueError):
            msg = "Unable to calculate at_hash to verify against token claims."
            raise JWTClaimsError(msg)

        if self.claims["at_hash"] != expected_hash:
            raise JWTClaimsError("at_hash claim does not match access_token.")


    def validate(self):
        required = self.options.get("require", {})
        verify = self.options.get("verify", {})
        for require_claim, value in required.items():
            if value:
                if require_claim not in self.claims:
                    raise JWTError('missing required key "%s" among claims' % require_claim)
                else:
                    verify[require_claim] = True
                
        if not isinstance(self.audience, ((str,), type(None))):
            raise JWTError("audience must be a string or None")

        for key, value in verify.items():
            if value and key not in ["signature"]:
                getattr(self, f"validate_{key}")()

    def __call__(self, encode=False, delta: int = 3600):
        return self.format(delta) if encode else self.validate()
    
    def format(self, delta: int = 3600):
        self.format_time(delta)
        self.format_at_hash()

    def format_time(self, delta: int = 3600):
        now = int(time())
        def to_timestamp(value: Optional[Union[datetime, float, int]]) -> Optional[int]:
            if isinstance(value, datetime):
                return int(value.timestamp())
            if isinstance(value, (float, int)):
                return int(value)
            return None
        # Handle "iat"
        iat = to_timestamp(self.claims.get("iat"))
        self.claims["iat"] = iat if iat is not None and iat <= now else now

        # Handle "nbf"
        nbf = to_timestamp(self.claims.get("nbf"))
        self.claims["nbf"] = nbf if nbf is not None and nbf > self.claims["iat"] else self.claims["iat"]

        # Handle "exp"
        exp = to_timestamp(self.claims.get("exp"))
        self.claims["exp"] = exp if exp is not None and exp > self.claims["nbf"] else self.claims["iat"] + delta

    def format_at_hash(self):
        if self.access_token:
            hashalg = self.HASHES.get(self.algorithm, hashlib.sha256)
            self.claims["at_hash"] = CMNUtils.at_hash(self.access_token, hashalg)
    
class CMNUtils:
    @classmethod
    def at_hash(cls, access_token, hash_alg):
        hash_digest = hash_alg(access_token.encode("utf-8")).digest()
        cut_at = int(len(hash_digest) / 2)
        truncated = hash_digest[:cut_at]
        at_hash = cls.b64url_encode(truncated)
        return at_hash.decode("utf-8")

    @staticmethod
    def b64url_encode(data: bytes) -> bytes:
        return base64.urlsafe_b64encode(data).rstrip(b'=')

    @staticmethod
    def b64url_decode(data: bytes) -> bytes:
        return base64.urlsafe_b64decode(data + b'=' * (-len(data) % 4))

    @staticmethod
    def to_bytes(data: Union[str, bytes, bytearray, memoryview]) -> bytes:
        if isinstance(data, bytes):
            return data
        elif isinstance(data, str):
            return data.encode("utf-8")
        elif isinstance(data, (bytearray, memoryview)):
            return bytes(data)
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
        
    @staticmethod
    def to_str(data: Union[str, bytes, bytearray, memoryview]) -> str:
        if isinstance(data, str):
            return data
        elif isinstance(data, (bytes, bytearray, memoryview)):
            return bytes(data).decode("utf-8")
        else:
            raise TypeError(f"Expected str, bytes, bytearray, or memoryview, got {type(data)}")
    
    @staticmethod
    def is_rsa_key(key):
        return isinstance(key, (rsa.RSAPublicKey, rsa.RSAPrivateKey))

    @staticmethod
    def is_ec_key(key):
        return isinstance(key, (ec.EllipticCurvePublicKey, ec.EllipticCurvePrivateKey))
    
    @staticmethod
    def is_hmac_key(key) -> bool:
        return isinstance(key, (str, bytes, bytearray, memoryview))
    
    @staticmethod
    def timedelta_seconds(delta):
        return delta.days * 24 * 60 * 60 + delta.seconds
    
    @staticmethod
    def sig_length(key):
        return int(math.ceil(key.key_size / 8.0))

    @classmethod
    def der_toraw(cls, der, key):
        r, s = decode_dss_signature(der)
        length = cls.sig_length(key)
        return int_to_bytes(r, length) + int_to_bytes(s, length)

    @classmethod
    def raw_toder(cls, raw, key):
        length = cls.sig_length(key)
        if len(raw) != int(2 * length):
            raise ValueError("Invalid signature")

        r_bytes = raw[:length]
        s_bytes = raw[length:]
        r = int.from_bytes(r_bytes, "big")
        s = int.from_bytes(s_bytes, "big")
        return encode_dss_signature(r, s)