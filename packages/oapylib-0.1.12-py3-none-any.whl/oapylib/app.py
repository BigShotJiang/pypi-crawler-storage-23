"""Docstring"""
from pathlib import Path
from functools import lru_cache
from sqlmodel import MetaData, Session
from fastapi import FastAPI, Request, Depends
from contextlib import asynccontextmanager, AsyncExitStack
from typing import Dict, Any, Annotated, Optional, List, Union
from pydantic_settings import BaseSettings, SettingsConfigDict

__all__ = ["APPS"]

class AppMeta:
    def __init__(self, metas: Dict[str, MetaData]):
        self.metalist = list(metas.values())
        self.schmlist = list(metas.keys())
        self.metadict = metas

class AppSpan:
        def __init__(
                self,
                amigs: Optional[List[Any]] = None,
                spans: Optional[Dict[FastAPI, Any]] = None,
            ):
            self.amig_list = amigs or []
            self.span_dict = spans or {} 

        @asynccontextmanager
        async def lifespan(self, app: FastAPI):
            app.state.appspan = True
            async with AsyncExitStack() as stack:
                # Manage the lifecycle of sub_app
                for subamig in self.amig_list:
                    await stack.enter_async_context(subamig())
                for subapp, subspan in self.span_dict.items():
                    await stack.enter_async_context(subspan(subapp))
                yield

class AppMsvc:
    def __init__(self, apps: Dict[str, FastAPI], lifespan, sessdep: Optional[Any] = None):
        depends = [Depends(self.session(sessdep))] if sessdep is not None else None
        self.app = FastAPI(dependencies= depends,  lifespan=lifespan)
        app_msg = {"message": "Hello Multi Micro Services API!"}
        for key, subapp in apps.items():
            self.app.mount(f"/{key}", subapp)
            app_msg[key] = f"{key.capitalize()} Service at '/{key}'"
        @self.app.get("/")
        async def root():
            return app_msg
        
    @staticmethod
    def session(sessdep):
        def _session(
            request: Request, 
            sess_pgs: Annotated[Session, Depends(sessdep)]
        ):
            """Injects session into request scope."""
            request.scope["db"] = {"pgsql": sess_pgs}
        return _session
        
class SrvConf:
    class Base(BaseSettings):
        host: str = "0.0.0.0"
        port: int = 8080
        reload: bool = False
        https_redir: bool = False
        session_secret: Optional[str] = None
        allowed_hosts: Optional[List[str]] = None
        allowed_origins: Optional[List[str]] = None

    def __init__(
            self, 
            dep_env: Optional[Union[str, Path]] = None, 
            srv_env: Optional[Union[str, Path]] = None
        ):

        class Deploy(BaseSettings):
            srv_env: str = ".env.srv"
            model_config = SettingsConfigDict(
                env_file= self.resolve_path(dep_env),
                env_file_encoding="utf-8",
                extra="ignore",
            )
        self.env_path = self.resolve_path(srv_env, Deploy().srv_env)
    
    @property
    def config(self):
        return self.get_config(self.env_path)
    
    @classmethod
    @lru_cache
    def get_config(cls, srv_env : Optional[Union[str, Path]] = None):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(srv_env, ".env.srv"),
                env_file_encoding="utf-8",
                extra="ignore",
            )     
        return Config()
    
    @staticmethod
    def resolve_path(
            path: Optional[Union[str, Path]] = None, 
            default: Optional[str] = None
        ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default        
    
class APPS:
    AppMeta = AppMeta
    AppSpan = AppSpan
    AppMsvc = AppMsvc
    SrvConf = SrvConf