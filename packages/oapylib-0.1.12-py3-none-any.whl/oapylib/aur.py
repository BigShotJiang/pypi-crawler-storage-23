"""Docstring"""
from enum import Enum
from pathlib import Path
from pydantic import BaseModel, EmailStr
from sqlmodel import Session, SQLModel, Field, Column, ARRAY, TEXT, MetaData, func, select

from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import  APIRouter, Depends, Request, HTTPException, status, Query, UploadFile, BackgroundTasks

from hashlib import sha256
from secrets import choice
from base64 import urlsafe_b64encode
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Annotated, Optional, Union, TypeVar, Generic, Type

from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict



from .jwt import JWT
from .aus import JtiCore
from .goo import GooAuth
from .uai import UaiAuth
from .dbs import DbsMsvc
from .img import ImgHandler

__all__ = ["AURS"]


class AdmConf:
    class Base(BaseSettings):
        # --- Admin user fields ---
        given_name: Optional[str] = None
        family_name: Optional[str] = None
        picture: Optional[str] = None
        # hashed password string only (no plaintext)
        password: Optional[str] = None
        is_active: Optional[bool] = None

        sub: Optional[str] = None
        email: Optional[EmailStr] = None
        email_verified: Optional[bool] = None
        roles: Optional[List[str]] = None
        scopes: Optional[List[str]] = None
        permissions: Optional[List[str]] = None
        is_enabled: Optional[bool] = None
        is_admin: Optional[bool] = None
        is_super: Optional[bool] = None
        is_guest: Optional[bool] = None

    def __init__(
        self,
        dep_env: Optional[Union[str, Path]] = None,
        adm_env: Optional[Union[str, Path]] = None,
        adm_secrets: Optional[Union[str, Path]] = None,
    ):
        class Deploy(BaseSettings):
            adm_env: str = ".env.auad"
            adm_secrets: str = "."
            model_config = SettingsConfigDict(
                env_file=self.resolve_path(dep_env, ".env.dep"),
                env_file_encoding="utf-8",
                extra="ignore",
            )

        self.env_path = self.resolve_path(adm_env, Deploy().adm_env)
        self.secrets_path = self.resolve_path(adm_secrets, Deploy().adm_secrets)

    @property
    def config(self):
        return self.get_config(self.env_path, self.secrets_path)

    @classmethod
    @lru_cache
    def get_config(
        cls,
        adm_env: Optional[Union[str, Path]] = None,
        adm_secrets: Optional[Union[str, Path]] = None,
    ):
        class Config(cls.Base):
            model_config = SettingsConfigDict(
                env_file=cls.resolve_path(adm_env, ".env.auad"),
                env_file_encoding="utf-8",
                extra="ignore",
                secrets_dir=cls.resolve_path(adm_secrets, "adm_secrets"),
            )    
        return Config()

    @staticmethod
    def resolve_path(
        path: Optional[Union[str, Path]] = None,
        default: Optional[str] = None,
    ) -> Optional[str]:
        return str(path) if path and Path(path).exists() else default

UserType = TypeVar("UserType", bound=SQLModel)

class AdminSeeder(Generic[UserType]):
    AdmConf = AdmConf
    def __init__(self,  user: Type[UserType],  db_session: Any, usr_config):
        self.user = user
        self.config = usr_config
        self.db_session = db_session

    def create_admin(self) -> None:
        """Insert admin user if not exists, using config values."""
        session = self.db_session()
        try:
            # Query by unique email
            column = getattr(self.user, "email", None)
            if column is None:
                raise ValueError(f"{self.user.__name__} has no 'email' column")
            statement = select(self.user).where(column == self.config.email)
            existing = session.exec(statement).first()
            if not existing:
                # Validate and construct User directly from config
                admin = self.user.model_validate(self.config)
                session.add(admin)
                session.commit()
                print("✅ Admin user created.")
            else:
                print("ℹ️ Admin user already exists.")
        finally:
            session.close()

    @staticmethod
    def hashed(password: str) -> str:
        """Return a URL-safe base64 encoded SHA256 digest."""
        h = sha256(str(password).encode()).digest()
        return urlsafe_b64encode(h).rstrip(b'=').decode()

class AuthSchemas:
    class BaseMeta(SQLModel):
        @staticmethod
        def utc_now() -> datetime:
            """Returns current UTC time."""
            return datetime.now(timezone.utc)
        created_at: datetime = Field(default_factory=utc_now)
        updated_at: datetime = Field(
            default_factory=utc_now,
            sa_column_kwargs={"onupdate": func.now()}
        )
    class UserBase(SQLModel):
        given_name: Optional[str] = Field(default=None)
        family_name: Optional[str] = Field(default=None)
        picture: Optional[str] = Field(default=None)

        @property
        def name(self) -> Optional[str]:
            """Returns full name if given_name or family_name exists."""
            if self.given_name:
                return f"{self.given_name} {self.family_name or ''}".strip()
            return None

    class UserPublic(UserBase):
        email: str = Field()
        is_super: bool = Field()
        is_admin: bool = Field()
        is_guest: bool = Field()
        is_client: bool = Field()

    class UserPrivate(UserPublic):
        id: Optional[str] = Field(default=None)
        roles: Optional[List[str]] = Field(default=None)
        scopes: Optional[List[str]] = Field(default=None)
        permissions: Optional[List[str]] = Field(default=None)

    class UserRegister(UserBase):
        email: EmailStr = Field()
        password: str = Field()
        
    class UserCreate(UserBase):
        email: EmailStr = Field()
        sub: Optional[str] = Field(default = None)
        password: Optional[str] = Field(default = None)

    class BaseQuery(SQLModel):
        email: Optional[str] = Field(default = None)
        given_name: Optional[str] = Field(default=None)
        family_name: Optional[str] = Field(default=None)
        query_type: str = Field(default="all")

    class UserQuery(BaseQuery):
        is_admin: Optional[bool] = Field(default=None)
        is_super: Optional[bool] = Field(default=None)
        query_type: str = Field(default="all")

    class UserUpdate(SQLModel):
        sub: Optional[str] = Field(default = None)
        given_name: Optional[str] = Field(default=None)
        family_name: Optional[str] = Field(default=None)
        picture: Optional[str] = Field(default=None)
        password: Optional[str] = Field(default = None)
        is_active: Optional[bool] = Field(default = None)

    class AdminUpdate(UserUpdate):
        email: Optional[EmailStr] = Field(default=None)
        email_verified: Optional[bool] = Field(default=None)
        roles: Optional[List[str]] = Field(default=None)
        scopes: Optional[List[str]] = Field(default=None)
        permissions: Optional[List[str]] = Field(default=None)
        is_enabled: Optional[bool] = Field(default = None)
        is_admin: Optional[bool] = Field(default=None)
        is_client: Optional[bool] = Field(default=None)

    class UserLogin(SQLModel):
        email: EmailStr = Field()
        password: str = Field()

    class AuthLogin(SQLModel):
        access: str = Field(default="online")
        prompt: str = Field(default="consent")
        target: str = Field(default="google")

    class AuthToken(SQLModel):
        state: str = Field()
        code: str = Field()
        target: str = Field(default="google")

    class TokenIssue(SQLModel):
        access_token: str = Field()
        refresh_token: Optional[str] = Field(default=None)
        token_type: str = "Bearer"
        refresh_cookie: bool = Field(default=False)

    def __init__(self, basemeta: MetaData):
        class User(self.UserBase, self.BaseMeta, table = True):
            metadata = basemeta
            @staticmethod
            def uniq_id():
                return ''.join(choice('0123456789') for _ in range(21))
            
            id: str = Field(default_factory=uniq_id, index=True, primary_key=True)
            sub: Optional[str] = Field(default=None)
            email: str = Field(index=True, unique=True)
            email_verified: bool = Field(default=False)
            password: Optional[str] = Field(default=None)
            is_guest: bool = Field(default = True)
            is_super: bool = Field(default=False)
            is_admin: bool = Field(default=False)
            is_client: bool = Field(default=False)
            is_active: bool = Field(default=True)
            is_enabled: bool = Field(default=True)
            
            roles: List[str] = Field(
                default_factory=list,
                sa_column=Column(ARRAY(TEXT))
            )
            scopes: List[str] = Field(
                default_factory=list,
                sa_column=Column(ARRAY(TEXT))
            )
            permissions: List[str] = Field(
                default_factory=list,
                sa_column=Column(ARRAY(TEXT))
            )
            
            def verify(self, password: str):
                return self.password == self.hashed(password) 
            
            @staticmethod
            def hashed(password):
                h = sha256(str(password).encode()).digest()
                return urlsafe_b64encode(h).rstrip(b'=').decode()
            
        self.User = User

    

class AuthCore:
    class TimeDelta(BaseModel):
        days: float = 0
        seconds: float = 0
        minutes: float = 0
        hours: float = 0
        weeks: float = 0

    def __init__(
            self,  
            refresh_key, 
            access_key,
            refresh_algo = "ES256",
            access_algo = "HS256",
            jtis: Optional[JtiCore] = None,
        ):
        
        self.jtis = jtis or JtiCore()
        self.refresh_key = refresh_key
        self.access_key = access_key
        self.refresh_algo = refresh_algo
        self.access_algo = access_algo
        self.verify_key = access_key.public_key() if hasattr(access_key, "public_key") else access_key

    def active_user(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.jtis.verify_token(
            access_token, required_roles, required_scopes, required_permissions
        )

    def access_token(
            self, 
            subject: str,
            roles: Optional[List[str]]=None, 
            scopes: Optional[List[str]]=None, 
            permissions: Optional[List[str]]=None,
            jti: Optional[str] = None,
            delta: TimeDelta = TimeDelta.model_validate({"minutes":10}),
        ):
        roles = roles or []
        scopes = scopes or []
        permissions = permissions or []
        now = datetime.now(timezone.utc)
        exp = now + timedelta(**delta.model_dump())
        jti = f"{jti}-{subject}" if jti is not None else JtiCore.generate_jti(subject)
        jtis = self.jtis.store_jti(jti=jti, exp=int(exp.timestamp()))
        payload = {
            "sub": subject,
            "jti": jtis,
            "roles": roles,
            "scopes": scopes,
            "permissions": permissions,
            "iat": now.timestamp(),
            "nbf": now.timestamp(),
            "exp": exp.timestamp(),
        }
        return JWT.encode(payload, key=self.access_key, algorithm=self.access_algo)

    def refresh_token(
            self, 
            subject: str, 
            jti: Optional[str] = None, 
            delta: TimeDelta = TimeDelta.model_validate({"hours":6})
        ):
        now = datetime.now(timezone.utc)
        exp = now + timedelta(**delta.model_dump())
        jti = f"{jti}-{subject}" if jti is not None else JtiCore.generate_jti(subject)
        jtis = self.jtis.store_jti(jti=jti, exp=int(exp.timestamp()), is_refresh=True)
        payload = {
            "sub": subject,
            "jti": jtis,
            "iat": now.timestamp(),
            "exp": exp.timestamp(),
        }
        return JWT.encode(payload, key=self.refresh_key, algorithm=self.refresh_algo)
    
    def revoke_user(
            self, 
            user_id
        ) -> str:
        revoke_access = self.jtis.revoke_usr(str(user_id))
        revok_refresh = self.jtis.revoke_usr(str(user_id), True)
        if not (revoke_access and revok_refresh):
            raise Exception("Failed to revoke user tokens")
        return user_id
    
    def revoke_access(
            self, 
            token
        ) -> str:
        header = JWT.header(token)
        try:
            payload = JWT.decode(
                token,
                self.verify_key,
                algorithms=[self.access_algo, header["alg"]],
            )
        except JWT.JWTError as exc:
            raise Exception from exc
        
        jti = payload.get("jti")
        sub = payload.get("sub")
        if not jti:
            raise Exception("Missing JTI")
        elif not sub:
            raise Exception("Missing SUB")
        
        is_verify = self.jtis.verify_jti(jti) and JtiCore.verify_sub(jti, sub)

        if not is_verify:
            raise Exception("Invalid JTI")
        is_revoked = self.jtis.revoke_jti(jti)
        if not is_revoked:
            raise Exception("Failed to revoke JTI")
        # Everything ok → return sub
        return sub

    def revoke_refresh(
            self, 
            token
        ) -> str:
        header = JWT.header(token)
        try:
            payload = JWT.decode(
                token,
                self.refresh_key.public_key(),
                algorithms=[self.refresh_algo, header["alg"]],
            )
        except JWT.JWTError as exc:
            raise Exception from exc
        
        jti = payload.get("jti")
        sub = payload.get("sub")
        if not jti:
            raise Exception("Missing JTI")
        elif not sub:
            raise Exception("Missing SUB")
        
        is_verify = self.jtis.verify_jti(jti, True) and JtiCore.verify_sub(jti, sub)

        if not is_verify:
            raise Exception("Invalid JTI")
        is_revoked = self.jtis.revoke_jti(jti, True)
        if not is_revoked:
            raise Exception("Failed to revoke JTI")
        # Everything ok → return sub
        return sub
    

# --- Custom Exceptions ---
class AuthError(Exception): pass
class InvalidCredentials(AuthError): pass
class InvalidProvider(AuthError): pass
class TokenError(AuthError): pass

class ServiceError(Exception): pass
class UserNotEnabledError(ServiceError): pass
class UserNotActiveError(ServiceError): pass
class InsufficientPriviledgeError(ServiceError): pass

class AurSrvc:
    def __init__(
            self,
            auth_obj: AuthCore,
            crud_user_obj: DbsMsvc,
            crud_admin_obj: DbsMsvc,
            img_handler_obj: ImgHandler,
            goo_auth_obj: Optional[GooAuth] = None,
            uai_auth_obj: Optional[UaiAuth] = None,
        ):
        
        self.auth = auth_obj
        self.goo_auth = goo_auth_obj
        self.uai_auth = uai_auth_obj
        self.crud_user = crud_user_obj
        self.crud_admin = crud_admin_obj
        self.img_handler = img_handler_obj

    # --- Private Helpers ---
    async def _ensure_authorized(self, session: Session, sub: str) -> Any:
        agent = await self.crud_user.read_byid(session=session, id=sub)
        if not(agent and agent.id == sub and (agent.is_super or agent.is_admin)):
            raise InsufficientPriviledgeError("User do not have enough priviledge")
        return agent

    # --- Private Helpers ---
    async def _generate_tokens(self, user) -> AuthSchemas.TokenIssue:
        """Generate access and refresh tokens for a user."""
        refresh_token = self.auth.refresh_token(subject=user.id)
        user_inputs = user.model_dump(
            include={"id", "roles", "scopes", "permissions"},
            exclude_none=True,
        )
        user_inputs["subject"] = user_inputs.pop("id")
        
        access_token = self.auth.access_token(**user_inputs)
        
        return AuthSchemas.TokenIssue(
            access_token = access_token,
            token_type = "Bearer",
            refresh_token= refresh_token,
        )

    async def _getuser_byemail(
            self, 
            session: Session, 
            email: str
        ) -> Optional[Any]:
        return await self.crud_user.read_uniq(session=session, field="email", value=email)

    # --- Public Methods ---
    async def useractive(
            self, 
            access_token: str,
            required_roles: Optional[List[str]] = None,
            required_scopes: Optional[List[str]] = None,
            required_permissions: Optional[List[str]] = None
        ) -> str:
        return self.auth.active_user(
            access_token, required_roles, required_scopes, required_permissions
        )
    
    async def userrefresh(
            self, 
            refresh_token: str,
        ) -> str:
        return self.auth.revoke_refresh(refresh_token)
    
    async def register(
            self, 
            session: Session, 
            data: AuthSchemas.UserRegister
        ) -> AuthSchemas.TokenIssue:
        data = AuthSchemas.UserRegister.model_validate(data)
        data.password = self.crud_user.model.hashed(data.password)
        user = await self._getuser_byemail(session, data.email)
        if user and user.password is None:
            update = AuthSchemas.UserUpdate.model_validate(data)
            user = await self.crud_user.update(session=session, id=user.id, data=update) or user
        else:
            create = AuthSchemas.UserCreate.model_validate(data)
            user = await self.crud_user.create(session=session, data=create)
        return await self._generate_tokens(user)

    async def userlogin(
            self, 
            session: Session, 
            data: AuthSchemas.UserLogin
        ) -> AuthSchemas.TokenIssue:
        data = AuthSchemas.UserLogin.model_validate(data)
        user = await self._getuser_byemail(session, data.email)
        if not (user and user.verify(data.password)):
            raise InvalidCredentials("Invalid credentials")
        elif not user.is_active:
            raise UserNotActiveError("User is not active contact admin")
        elif not user.is_enabled:
            raise UserNotEnabledError("User is not enabled contact admin")
        return await self._generate_tokens(user)

    async def authlogin(self, data: AuthSchemas.AuthLogin) -> str:
        data = AuthSchemas.AuthLogin.model_validate(data)
        if data.target == "google" and self.goo_auth is not None:
            return await self.goo_auth.auth_url(access=data.access or "online", prompt=data.prompt or "consent")
        elif data.target == "uaix" and self.uai_auth is not None:
            return await self.uai_auth.auth_url(access=data.access or "online", prompt=data.prompt or "consent")
        raise InvalidProvider("Unsupported Auth Provider")

    async def authtoken(
            self, 
            session: Session, 
            data: AuthSchemas.AuthToken
        ) -> AuthSchemas.TokenIssue:
        data = AuthSchemas.AuthToken.model_validate(data)
        if data.target == "google" and self.goo_auth is not None:
            token = await self.goo_auth.token(state=data.state, code=data.code)
        elif data.target == "uaix" and self.uai_auth is not None:
            token = await self.uai_auth.token(state=data.state, code=data.code)
        else: raise InvalidProvider("Unsupported Auth Provider")
        
        if token["status_code"] != 200:
            raise TokenError(token["detail"])
        user_data = token["userid"].model_dump(exclude_unset=True, exclude_none=True)
        user = await self._getuser_byemail(session, user_data["email"])
        if not user:
            create = AuthSchemas.UserCreate.model_validate(user_data)
            user = await self.crud_user.create(session=session, data=create)
        elif not user.is_active:
            raise UserNotActiveError("User is not active contact admin")
        elif not user.is_enabled:
            raise UserNotEnabledError("User is not enabled contact admin")
        else:
            if user.picture:
                user_data["picture"] = None  # Prevent overwriting existing picture
            update = AuthSchemas.UserUpdate.model_validate(user_data)
            user = await self.crud_user.update(session=session, id=user.id, data=update) or user
        return await self._generate_tokens(user)
    
    async def userupdate(
            self, 
            session: Session, 
            sub: str, 
            data: AuthSchemas.UserUpdate
        ) -> Optional[AuthSchemas.UserPublic]:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not user or user.id != sub:
            return None
        data.sub = None  # Ensure the update is for the correct user
        update = AuthSchemas.UserUpdate.model_validate(data)
        updated = await self.crud_user.update(session=session, id=sub, data=update) or user
        return AuthSchemas.UserPublic.model_validate(updated)
    
    async def imageupload(
            self, 
            session: Session, 
            sub: str, 
            file: UploadFile,
            enc: bool = False
        ) -> Optional[AuthSchemas.UserPublic]:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not user or user.id != id:
            return None
        upload_result = self.img_handler.upload_img(
            user_id=sub, file=file, given_name=user.given_name, encrypt=enc, old_url=user.picture
        )
        data_dict = {"picture": upload_result.get("img_url")}
        update = AuthSchemas.UserUpdate.model_validate(data_dict)
        updated = await self.crud_user.update(session=session, id=sub, data=update) or user
        return AuthSchemas.UserPublic.model_validate(updated)
    
    async def imageload(
            self, 
            session: Session, 
            sub: str,
            opfile: bool = False
        ) -> Optional[Dict[str, Any]]:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not user or user.id != id:
            return None
        load_result = self.img_handler.load_img(user_id=sub, given_name=user.given_name, op_file=opfile)
        return load_result
    
    async def common_result(
            self,
            file_result,
            resp_type = None
        ) -> list:
        """Doc String"""
        return self.img_handler.common_result(file_result, resp_type)

    async def authrefresh(
            self, 
            session: Session, 
            sub: str
        ) -> AuthSchemas.TokenIssue:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not user:
            raise TokenError("Invalid Refresh Token")
        elif not user.is_enabled:
            raise UserNotEnabledError("User is not enabled contact admin")
        return await self._generate_tokens(user)
    
    async def userprofile(
            self, 
            session: Session, 
            sub: str
        ) -> Optional[AuthSchemas.UserPublic]:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if user and user.id == sub:
            return AuthSchemas.UserPublic.model_validate(user)
        return None
    
    async def userdelete(
            self, 
            session: Session, 
            sub: str
        ) -> bool:
        user = await self.crud_user.read_byid(session=session, id=sub)
        if not user or user.id != id:
            return False
        data_dict = {"is_active": False}
        update = AuthSchemas.UserUpdate.model_validate(data_dict)
        updated = await self.crud_user.update(session=session, id=sub, data=update) or user
        return not updated.is_active
    
    async def userlogout(
            self, 
            session: Session, 
            access_token: str,
            refresh_token: Optional[str] = None,
        ) -> dict:
        
        id = self.auth.revoke_access(access_token)
        if not id:
            return {"logout": False, "id": id, "refresh": False}
        user = await self.crud_user.read_byid(session=session, id=id)
        if not (user and user.id == id):
            return {"logout": False, "id": id, "refresh": False}
        if not refresh_token:
            return {"logout": True, "id": id, "refresh": False}
        sub = self.auth.revoke_refresh(refresh_token)
        if not (sub and sub==id):
            return {"logout": False, "id": id, "refresh": False}
        return {"logout": True, "id": sub, "refresh": True}
    

    async def admincreate(
        self,
        session: Session,
        sub: str,
        data: AuthSchemas.UserCreate
    ) -> Optional[AuthSchemas.UserPrivate]:
        await self._ensure_authorized(session=session, sub=sub)
        data_dict = data.model_dump(exclude_unset=True, exclude_none=True)
        email = data_dict.get("email")
        if not email:
            return None
        user = await self.crud_admin.read_uniq(session=session, field="email", value=email)
        if not user:
            if "password" in data_dict:
                data_dict["password"] = self.crud_admin.model.hashed(data_dict.pop("password"))
            create = AuthSchemas.UserCreate.model_validate(data_dict)
            user = await self.crud_admin.create(session=session, data=create)
        return AuthSchemas.UserPrivate.model_validate(user)
    
    async def adminread(
        self,
        session: Session,
        sub: str,
        query: Optional[AuthSchemas.UserQuery] = None,
        offset: int = 0,
        limit: int = 100,
        query_type: Optional[str] = None,
    ) -> List[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        query_dict = query.model_dump() if query else {}
        query = AuthSchemas.UserQuery.model_validate(query_dict)
        if not agent.is_super:
            query.is_admin = False
            query.is_super = False

        results = await self.crud_admin.read(
            session=session,
            offset=offset,
            limit=limit,
            query=query,
            query_type=query_type,
        )
        return [AuthSchemas.UserPrivate.model_validate(obj) for obj in results]

    async def adminread_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)
        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return
        return AuthSchemas.UserPrivate.model_validate(user)

    async def adminread_byemail(
        self,
        session: Session,
        sub: str,
        email: str,
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_uniq(session=session, field="email", value=email)
        if not(user and user.email==email):
            return
        if not agent.is_super and user.is_super:
            return
        return AuthSchemas.UserPrivate.model_validate(user)
    
    async def adminreplace(
        self,
        session: Session,
        sub: str,
        id: str,
        data: AuthSchemas.UserCreate
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return

        # Role-based exclusions
        if agent.is_super:
            excludes = {"is_admin", "email"} if user.is_super else set()
        else:
            excludes = {"is_admin", "email"} if not user.is_admin else {
                "is_admin", "email", "roles", "scopes", "permissions", "email_verified"
            }

        data_dict = data.model_dump(exclude=excludes, exclude_unset=True, exclude_none=True)
        if "password" in data_dict:
            data_dict["password"] = self.crud_admin.model.hashed(data_dict.pop("password"))
        update = AuthSchemas.UserPrivate.model_validate(data_dict)
        updated = await self.crud_admin.update(session=session, id=id, data=update)
        if not updated:
            return
        return AuthSchemas.UserPrivate.model_validate(updated)
    

    async def adminupdate(
        self,
        session: Session,
        sub: str,
        id: str,
        data: AuthSchemas.AdminUpdate
    ) -> Optional[AuthSchemas.UserPrivate]:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return
        if not agent.is_super and user.is_super:
            return

        # Role-based exclusions
        if agent.is_super:
            excludes = {"is_admin", "email"} if user.is_super else set()
        else:
            excludes = {"is_admin", "email"} if not user.is_admin else {
                "is_admin", "email", "roles", "scopes", "permissions", "email_verified"
            }

        data_dict = data.model_dump(exclude=excludes, exclude_unset=True, exclude_none=True)
        update = AuthSchemas.AdminUpdate.model_validate(data_dict)
        updated = await self.crud_admin.update(session=session, id=id, data=update)
        if not updated:
            return
        return AuthSchemas.UserPrivate.model_validate(updated)
    
    async def admindelete_byid(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> bool:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return False
        if not agent.is_super and user.is_super:
            return False
        self.img_handler.delete_img(user_id=id, given_name=user.given_name, img_url=user.picture)
        return await self.crud_admin.delete_byid(session=session, id=id)
    
    async def adminrevoke(
        self,
        session: Session,
        sub: str,
        id: str,
    ) -> dict:
        agent = await self._ensure_authorized(session=session, sub=sub)
        user = await self.crud_admin.read_byid(session=session, id=id)

        if not(user and user.id==id):
            return {"revoked": False, "id": id}
        if not agent.is_super and user.is_super:
            return {"revoked": False, "id": id}
        
        self.auth.revoke_user(str(id))
        return {"revoked": True, "id": id}


class AurResp:
    DEFAULT_CRUD_ROLES = {
        "public_user": ["guest", "user", "admin"],
        "auth_user": ["guest", "user", "admin"],
        "auth_admin": ["admin"],
    }

    DEFAULT_CRUD_SCOPES = {
        "auth_user": ["auth"],
        "public_user": ["auth"],
        "auth_admin": ["auth"],
    }

    DEFAULT_CRUD_PERMISSIONS = {
        "public_user": ["read", "write"],
        "auth_user": ["read", "write"],
        "auth_admin": ["read", "write"]
    }

    DEFAULT_IS_PROTECTED = {
        "public_user": False,
        "auth_user": True,
        "auth_admin": True,
    }
    DEFAUTL_COOKIE_METHODS = ["authrefresh", "userlogout"]
    def __init__(
        self,
        service_obj: AurSrvc,
        crud_roles: Optional[Dict[str, List[str]]] = None,
        crud_scopes: Optional[Dict[str, List[str]]] = None,
        crud_permissions: Optional[Dict[str, List[str]]] = None,
        is_protected: Optional[Dict[str, bool]] = None,
        cookie_methods: Optional[List[str]] = None
    ):
        self.service = service_obj
        self.security = HTTPBearer(auto_error=False)
        self.crud_roles = crud_roles or self.DEFAULT_CRUD_ROLES
        self.crud_scopes = crud_scopes or self.DEFAULT_CRUD_SCOPES
        self.crud_permissions = crud_permissions or self.DEFAULT_CRUD_PERMISSIONS
        self.is_protected = is_protected or self.DEFAULT_IS_PROTECTED
        self.cookie_methods = cookie_methods or self.DEFAUTL_COOKIE_METHODS

    def cookie(self, request:Request, response: Response, key, value):
            try:
                for method in self.cookie_methods:
                    path = request.url_for(method).path
                    response.set_cookie(
                        key=key,
                        value=value,
                        httponly=True,
                        secure=True,
                        samesite="lax",
                        path=path,
                        max_age=7 * 24 * 3600
                    )
                return True
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Error: User not Found {exc}",
                ) from exc

    def user(self, method: Optional[str] = None, is_refresh=False):
        if is_refresh:
            async def refreshuser(request: Request):
                try:
                    refresh_token = request.cookies.get("refresh_token")
                    if not refresh_token:
                        raise HTTPException(
                            status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Missing refresh token"
                        )
                    sub = await self.service.userrefresh(refresh_token)
                    return sub
                except Exception as exc:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=f"Invalid refresh token: {exc}"
                    ) from exc
            return refreshuser
        else:
            if method is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not authorised"
                )
            is_protected = self.is_protected.get(method, False)
            required_roles = self.crud_roles.get(method)
            required_scopes = self.crud_scopes.get(method)
            required_permissions = self.crud_permissions.get(method)
            async def loginuser(creds: HTTPAuthorizationCredentials = Depends(self.security)):
                try:
                    if not is_protected:
                        return "public"
                    elif creds is None:
                        raise HTTPException(status_code=401, detail="Missing credentials")
                    access_token = creds.credentials
                    sub = await self.service.useractive(
                        access_token,
                        required_roles,
                        required_scopes,
                        required_permissions
                    )
                    return sub
                except PermissionError as exc:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Forbidden: {exc}"
                    ) from exc
                except Exception as exc:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=f"Invalid or expired access token: {exc}"
                    ) from exc
            return loginuser

    @property
    def logout(self):
        async def logoutuser(
            request: Request,
            creds: HTTPAuthorizationCredentials = Depends(self.security)
        ):
            try:
                if creds is None:
                    raise HTTPException(status_code=401, detail="Missing credentials")
                db_session = request.scope["db"]["pgsql"]
                access_token = creds.credentials
                refresh_token = request.cookies.get("refresh_token")
                logout = await self.service.userlogout(
                    session=db_session,
                    access_token=access_token,
                    refresh_token=refresh_token
                )
                return logout
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Logout failed: {exc}"
                ) from exc
        return logoutuser

    @property
    def post_register(self):
        async def register(
            request: Request,
            response: Response,
            user: Annotated[str, Depends(self.user("public_user"))],
            data: Annotated[AuthSchemas.UserRegister, Depends()]
        ) -> AuthSchemas.TokenIssue:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.register(
                    session=db_session,
                    data=data,
                )
                refresh_cookie = self.cookie(request, response, "refresh_token", result.refresh_token)
                result.refresh_cookie = refresh_cookie
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid registration data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Registration failed: {exc}"
                ) from exc
        return register
    
    @property
    def post_userlogin(self):
        async def userlogin(
            request: Request,
            response: Response,
            user: Annotated[Optional[str], Depends(self.user("public_user"))],
            data: Annotated[AuthSchemas.UserLogin, Depends()]
        ) -> AuthSchemas.TokenIssue:
            try:
                
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.userlogin(session=db_session, data=data)
                refresh_cookie = self.cookie(request, response, "refresh_token", result.refresh_token)
                result.refresh_cookie = refresh_cookie
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid login data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Login failed: {exc}"
                ) from exc
        return userlogin

    @property
    def post_authlogin(self):
        async def authlogin(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("public_user"))],
            data: Annotated[AuthSchemas.AuthLogin, Depends()]
        ) -> str:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                result = await self.service.authlogin(data=data)
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid auth login data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Auth login failed: {exc}"
                ) from exc
        return authlogin

    @property
    def post_authtoken(self):
        async def authtoken(
            request: Request,
            response: Response,
            user: Annotated[Optional[str], Depends(self.user("public_user"))],
            data: Annotated[AuthSchemas.AuthToken, Depends()]
        ) -> AuthSchemas.TokenIssue:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.authtoken(session=db_session, data=data)
                refresh_cookie = self.cookie(request, response, "refresh_token", result.refresh_token)
                result.refresh_cookie = refresh_cookie
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid auth token request: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Auth token issue failed: {exc}"
                ) from exc
        return authtoken
    
    @property
    def post_imgupload(self):
        async def imgupload(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
            file: UploadFile,
            enc: bool = False,
        ) -> Optional[AuthSchemas.UserPublic]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.imageupload(session=db_session, sub=user, file=file, enc=enc)
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid login data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Login failed: {exc}"
                ) from exc
        return imgupload
    
    @property
    def get_imgload(self):
        async def imgload(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
            tasks: BackgroundTasks,
            opfile: bool = True,
        ):
            async def del_temp_file(file_path):
                """Doc String"""
                file_to_delete = Path(file_path)
                file_to_delete.unlink()

            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                file_result = await self.service.imageload(session=db_session, sub=user, opfile=opfile)
                [
                    temp_file_path,
                    media_type,
                    file_name,
                ] = await self.service.common_result(
                    file_result
                )

                if not temp_file_path:
                    raise Exception("File error: File not found")
                tasks.add_task(del_temp_file, temp_file_path)
                response = FileResponse(
                    temp_file_path,
                    media_type=media_type,
                    filename=file_name,
                    background=tasks,
                )
                yield response
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid login data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Login failed: {exc}"
                ) from exc
        return imgload

    @property
    def get_authrefresh(self):
        async def authrefresh(
            request: Request,
            response: Response,
            user: Annotated[Optional[str], Depends(self.user("auth_user", True))],
            refresh_token: Optional[str] = None,
        ) -> AuthSchemas.TokenIssue:
            try:
                if not user:
                    if not refresh_token:
                        raise HTTPException(
                            status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="User not found, login and try again"
                        )
                    user = await self.service.userrefresh(refresh_token)
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.authrefresh(session=db_session, sub=user)
                refresh_cookie = self.cookie(request, response, "refresh_token", result.refresh_token)
                result.refresh_cookie = refresh_cookie
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid refresh request: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Auth refresh failed: {exc}"
                ) from exc
        return authrefresh

    @property
    def get_userprofile(self):
        async def userprofile(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
        ) -> Optional[AuthSchemas.UserPublic]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.userprofile(session=db_session, sub=user)
                return result
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Profile retrieval failed: {exc}"
                ) from exc
        return userprofile

    @property
    def get_userlogout(self):
        async def userlogout(
            request: Request,
            response: Response,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
            logout: Annotated[Dict[str, Any], Depends(self.logout)],
            refresh_token: Optional[str] = None,
        ) -> Dict[str, Any]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                if logout["logout"] and not logout["refresh"]:
                    if not refresh_token:
                        logout["logout"] = False
                    else:
                        sub = await self.service.userrefresh(refresh_token)
                        if sub != user:
                            logout["logout"] = False
                        else:
                            logout["refresh"] = True
                            self.cookie(request, response, "refresh_token", "")
                else:
                    self.cookie(request, response, "refresh_token", "")
                return logout
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Logout failed: {exc}"
                ) from exc
        return userlogout

    @property
    def patch_userupdate(self):
        async def userupdate(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
            data: Annotated[AuthSchemas.UserUpdate, Depends()]
        ) -> Optional[AuthSchemas.UserPublic]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.userupdate(session=db_session, sub=user, data=data)
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid update data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Update failed: {exc}"
                ) from exc
        return userupdate

    @property
    def delete_userdelete(self):
        async def userdelete(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_user"))],
        ) -> bool:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="User not found, login and try again"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.userdelete(session=db_session, sub=user)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail="User not found"
                    )
                return result
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Delete failed: {exc}"
                ) from exc
        return userdelete

    @property
    def post_admincreate(self):
        async def admincreate(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            data: Annotated[AuthSchemas.UserCreate, Depends()]
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                return await self.service.admincreate(session=db_session, sub=user, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid create data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin create failed: {exc}"
                ) from exc
        return admincreate

    @property
    def get_adminread(self):
        async def adminread(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            query: Annotated[Optional[AuthSchemas.UserQuery], Depends(AuthSchemas.UserQuery)] = None,
            offset: int = 0,
            limit: Annotated[int, Query(le=100)] = 100,
            query_type: Optional[str] = None,
        ) -> List[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                return await self.service.adminread(
                    session=db_session,
                    sub=user,
                    offset=offset,
                    limit=limit,
                    query=query,
                    query_type=query_type,
                )
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin read failed: {exc}"
                ) from exc
        return adminread

    @property
    def get_adminread_byid(self):
        async def adminread_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.adminread_byid(session=db_session, sub=user, id=id)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"User with id {id} not found"
                    )
                return result
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin read by id failed: {exc}"
                ) from exc
        return adminread_byid
    
    @property
    def get_adminread_byemail(self):
        async def adminread_byemail(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            email: str,
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.adminread_byemail(session=db_session, sub=user, email=email)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"User with email {email} not found"
                    )
                return result
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin read by email failed: {exc}"
                ) from exc
        return adminread_byemail
    
    @property
    def get_adminrevoke(self):
        async def adminrevoke(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> JSONResponse:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )

                db_session = request.scope["db"]["pgsql"]
                result = await self.service.adminrevoke(
                    session=db_session,
                    sub=user,
                    id=id,
                )

                # result is always a dict like {"revoked": bool, "id": id}
                if not result.get("revoked", False):
                    # If revoked is False, return 400 or 404 depending on semantics
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Revocation failed for user id {id}"
                    )

                return JSONResponse(content=result, status_code=status.HTTP_200_OK)

            except HTTPException:
                # re-raise known HTTP errors so they pass through unchanged
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin revoke failed: {exc}",
                ) from exc
        return adminrevoke

    @property
    def put_adminreplace(self):
        async def adminreplace(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
            data: Annotated[AuthSchemas.UserCreate, Depends()],
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                result = await self.service.adminreplace(session=db_session, sub=user, id=id, data=data)
                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"User with id {id} not found"
                    )
                return result
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid replace data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin replace failed: {exc}"
                ) from exc
        return adminreplace

    @property
    def patch_adminupdate(self):
        async def adminupdate(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
            data: Annotated[AuthSchemas.AdminUpdate, Depends()],
        ) -> Optional[AuthSchemas.UserPrivate]:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )
                db_session = request.scope["db"]["pgsql"]
                return await self.service.adminupdate(session=db_session, sub=user, id=id, data=data)
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid update data: {exc}"
                ) from exc
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin update failed: {exc}"
                ) from exc
        return adminupdate

    @property
    def delete_admindelete(self):
        async def admindelete_byid(
            request: Request,
            user: Annotated[Optional[str], Depends(self.user("auth_admin"))],
            id: str,
        ) -> JSONResponse:
            try:
                if not user:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Admin privileges required"
                    )

                db_session = request.scope["db"]["pgsql"]
                result = await self.service.admindelete_byid(
                    session=db_session,
                    sub=user,
                    id=id,
                )

                if not result:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"User with id {id} not found"
                    )

                return JSONResponse(content={"removed": True}, status_code=status.HTTP_200_OK)

            except HTTPException:
                # re-raise known HTTP errors so they pass through unchanged
                raise
            except Exception as exc:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Admin delete failed: {exc}",
                ) from exc

        return admindelete_byid

class AurMsvc:
    def __init__(
        self,
        response_obj: AurResp,
        prefix: Optional[str] = None,
        tags: List[Union[str, Enum]] | None = None,
        cookie_methods: Optional[List[str]] = None,
    ):
        self.router = APIRouter(
            prefix=prefix or "",
            tags=tags,
            responses={404: {"description": "Not found"}},
            dependencies=[Depends(response_obj.security)],
        )

        # ✅ Always ensure "authrefresh" is included in cookie_methods
        if not response_obj.cookie_methods:
            response_obj.cookie_methods = (cookie_methods or []) + ["authrefresh", "userlogout"]
        elif "authrefresh" not in response_obj.cookie_methods:
            response_obj.cookie_methods.append("authrefresh")

        self.response = response_obj
        self.register_routes()

    def register_routes(self):
        # --- Auth routes ---
        @self.router.post("/auth/token")
        async def authtoken(_response=Depends(self.response.post_authtoken)):
            return _response

        @self.router.post("/auth/login")
        async def authlogin(_response=Depends(self.response.post_authlogin)):
            return _response

        @self.router.get("/auth/refresh")
        async def authrefresh(_response=Depends(self.response.get_authrefresh)):
            return _response

        # --- User routes ---
        @self.router.post("/user/register")
        async def userregister(_response=Depends(self.response.post_register)):
            return _response
        
        @self.router.post("/user/imgupload")
        async def userimgupload(_response=Depends(self.response.post_imgupload)):
            return _response

        @self.router.post("/user/login")
        async def userlogin(_response=Depends(self.response.post_userlogin)):
            return _response

        @self.router.get("/user/profile")
        async def userprofile(_response=Depends(self.response.get_userprofile)):
            return _response
        
        @self.router.get("/user/imgload")
        async def userimgload(_response=Depends(self.response.get_imgload)):
            return _response

        @self.router.get("/user/logout")
        async def userlogout(_response=Depends(self.response.get_userlogout)):
            return _response

        @self.router.patch("/user/update")
        async def userupdate(_response=Depends(self.response.patch_userupdate)):
            return _response

        @self.router.delete("/user/delete")
        async def userdelete(_response=Depends(self.response.delete_userdelete)):
            return _response

        # --- Admin routes ---
        @self.router.post("/admin/create")
        async def admincreate(_response=Depends(self.response.post_admincreate)):
            return _response

        @self.router.get("/admin/read")
        async def adminread(_response=Depends(self.response.get_adminread)):
            return _response

        @self.router.get("/admin/read/id/{id}")
        async def adminread_byid(_response=Depends(self.response.get_adminread_byid)):
            return _response
        
        @self.router.get("/admin/read/email/{email}")
        async def adminread_byemail(_response=Depends(self.response.get_adminread_byemail)):
            return _response
        
        @self.router.get("/admin/revoke/{id}")
        async def adminrevoke(_response=Depends(self.response.get_adminrevoke)):
            return _response

        @self.router.put("/admin/update/{id}")
        async def adminreplace(_response=Depends(self.response.put_adminreplace)):
            return _response

        @self.router.patch("/admin/update/{id}")
        async def adminupdate(_response=Depends(self.response.patch_adminupdate)):
            return _response

        @self.router.delete("/admin/delete/{id}")
        async def admindelete(_response=Depends(self.response.delete_admindelete)):
            return _response   
        
class AURS:
    AurMsvc = AurMsvc
    AurResp = AurResp
    AurSrvc = AurSrvc
    AuthCore = AuthCore
    AuthSchemas = AuthSchemas
    AdminSeeder = AdminSeeder