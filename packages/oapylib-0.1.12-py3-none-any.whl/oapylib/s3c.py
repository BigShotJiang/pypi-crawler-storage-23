"""Docstring"""
import base64
from secrets import token_urlsafe
from typing import Optional, Any
from urllib.parse import urlparse

__all__ = ["S3Cloud"]

class S3Cloud:
    def __init__(self, s3: Optional[Any] = None):
        self.s3 = self._s3_client(s3)
        self.bucket = s3.bucket if s3 else None
        self.puburl = s3.puburl if s3 else None
       
    def upload_image(self, b64: str, prefix: str = "thums", ext: str = "jpeg") -> Optional[str]:
        if not (self.s3 and self.bucket):
            return
        image_bytes = base64.b64decode(b64)
        key = self._make_key(prefix=prefix, ext=ext)
        self.s3.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=image_bytes,
            ContentType="image/png"
        )
        return f"{self.puburl}/{key}"
    
    
    def update_image(self, old_url: str, new_b64: str) -> Optional[str]:
        parts = old_url.rsplit("/", 2)
        if not parts or len(parts) < 3 or parts[-3] != self.puburl:
            return
        file_name = parts[-1].lower()
        prefix = parts[-2].lower()
        ext = file_name.rsplit(".", 1)[-1].lower()
        new_url = self.upload_image(new_b64, prefix=prefix, ext=ext)
        if not new_url:
            return
        self.delete_image(old_url)
        return new_url
    
    def delete_image(self, url: str) -> None:
        if (self.s3 and self.bucket):
            key = self._get_key(url)
            self.s3.delete_object(
                Bucket=self.bucket,
                Key=key,
            )

    @staticmethod
    def _s3_client(s3: Optional[Any] = None):
        if not (s3 and s3.ping):
            return
        return s3.client
    
    @staticmethod
    def _make_key(prefix: str = "thums", ext: str = "jpeg") -> str:
        return f"{prefix}/{token_urlsafe(16)}.{ext}"
    
    @staticmethod
    def _get_key(url: str) -> str:
        """
        Extracts object key from public URL
        """
        path = urlparse(url).path.lstrip("/")
        return path


