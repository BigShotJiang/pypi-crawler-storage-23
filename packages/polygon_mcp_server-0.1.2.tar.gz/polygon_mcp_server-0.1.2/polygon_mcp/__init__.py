"""Polygon MCP server."""

from .server import mcp

__all__ = ["mcp"]
