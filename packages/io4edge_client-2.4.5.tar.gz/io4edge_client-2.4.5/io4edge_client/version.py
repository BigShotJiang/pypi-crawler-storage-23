# SPDX-License-Identifier: Apache-2.0
version = (2, 4, 5)
VERSION = "%d.%d.%d" % version
