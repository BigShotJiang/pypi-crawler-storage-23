from .eeprom import Client
import io4edge_client.api.eeprom.python.eeprom.v1alpha1.eeprom_pb2 as Pb

__all__ = ["Client", "Pb"]
