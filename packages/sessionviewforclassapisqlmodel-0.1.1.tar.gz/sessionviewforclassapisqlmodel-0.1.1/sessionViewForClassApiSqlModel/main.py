from classapi import BaseView
import fastapi as _fastapi
from sqlmodel import Session

def make_session_view(engine = None):
    class SessionView(BaseView):
        def __init__(self):
            super().__init__()
            self.session = None  # will be set in the endpoint wrapper

        def _add_route(self, app: _fastapi.FastAPI, path: str = "/", **kwargs):
            """Register handlers on `app` forwarding any FastAPI-compatible kwargs.

            `kwargs` are passed directly to `app.add_api_route`, so you can provide
            `response_model`, `dependencies`, `status_code`, etc.
            """
            # create FastAPI-compatible endpoint wrappers that preserve the
            # original method signature (excluding `self`) by setting
            # `__signature__` on the wrapper. FastAPI uses that for dependency
            # injection and parameter parsing.
            def _make_endpoint(method_name, http_methods):
                import inspect
                func = getattr(self, method_name)
                sig_func = inspect.signature(func)
                params_func = list(sig_func.parameters.values())
                if params_func and params_func[0].name == "self":
                    params_func = params_func[1:]
                # exclude *args and **kwargs from the public signature
                params_func = [p for p in params_func if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)]

                # gather pre handlers: specific pre_<method> and general pre_process
                pre_specific = getattr(self, f"pre_{method_name}", None)
                pre_general = getattr(self, "pre_process", None)

                params_pre_specific = []
                params_pre_general = []
                if pre_specific is not None:
                    sig_pre = inspect.signature(pre_specific)
                    params_pre_specific = list(sig_pre.parameters.values())
                    if params_pre_specific and params_pre_specific[0].name == "self":
                        params_pre_specific = params_pre_specific[1:]
                    # exclude *args and **kwargs from the public signature
                    params_pre_specific = [p for p in params_pre_specific if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)]
                    # also filter accidental plain 'args'/'kwargs' parameters
                    params_pre_specific = [p for p in params_pre_specific if p.name not in ("args", "kwargs")]
                if pre_general is not None:
                    sig_pre_g = inspect.signature(pre_general)
                    params_pre_general = list(sig_pre_g.parameters.values())
                    if params_pre_general and params_pre_general[0].name == "self":
                        params_pre_general = params_pre_general[1:]
                    # exclude *args and **kwargs from the public signature
                    params_pre_general = [p for p in params_pre_general if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)]
                    # also filter accidental plain 'args'/'kwargs' parameters
                    params_pre_general = [p for p in params_pre_general if p.name not in ("args", "kwargs")]

                # merge params: general pre, specific pre, then func params; skip duplicates by name
                seen = set()
                merged = []
                for p in params_pre_general + params_pre_specific + params_func:
                    if p.name not in seen:
                        merged.append(p)
                        seen.add(p.name)

                # Reorder merged params to satisfy Python's parameter ordering rules:
                # positional-only, positional-or-keyword, var-positional, keyword-only, var-keyword
                posonly = []
                pos_or_kw = []
                var_pos = None
                kw_only = []
                var_kw = None
                for p in merged:
                    if p.kind == inspect.Parameter.POSITIONAL_ONLY:
                        posonly.append(p)
                    elif p.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                        pos_or_kw.append(p)
                    elif p.kind == inspect.Parameter.VAR_POSITIONAL:
                        if var_pos is None:
                            var_pos = p
                    elif p.kind == inspect.Parameter.KEYWORD_ONLY:
                        kw_only.append(p)
                    elif p.kind == inspect.Parameter.VAR_KEYWORD:
                        if var_kw is None:
                            var_kw = p

                # Ensure parameters without defaults come before those with defaults
                def split_by_default(params):
                    no_def = [p for p in params if p.default is inspect._empty]
                    has_def = [p for p in params if p.default is not inspect._empty]
                    return no_def + has_def

                posonly = split_by_default(posonly)
                pos_or_kw = split_by_default(pos_or_kw)
                kw_only = split_by_default(kw_only)

                ordered = posonly + pos_or_kw
                if var_pos is not None:
                    ordered.append(var_pos)
                ordered += kw_only
                if var_kw is not None:
                    ordered.append(var_kw)

                # normalize parameters: if a parameter has no annotation but its default
                # is an `Annotated[T, metadata...]` object (commonly used incorrectly
                # as a default), extract the annotation and the first metadata item
                # (e.g. Header()) and set them on the parameter so FastAPI detects it.
                import typing
                normalized = []
                for p in ordered:
                    ann = p.annotation
                    default = p.default
                    if (ann is inspect._empty and default is not inspect._empty
                            and typing.get_origin(default) is typing.Annotated):
                        args = typing.get_args(default)
                        if args:
                            new_ann = args[0]
                            new_default = args[1] if len(args) > 1 else inspect._empty
                            p = inspect.Parameter(p.name, p.kind, default=new_default, annotation=new_ann)
                    normalized.append(p)

                new_sig = inspect.Signature(parameters=normalized)

                def endpoint(**kwargs):
                    if engine is None:
                        raise RuntimeError(
                            "SessionView has no engine configured. "
                            "Create it with make_session_view(engine=your_engine)."
                        )
                    with Session(engine) as session:
                        self.session = session  # make session available as an instance attribute for handlers and pre-processors
                        try:
                            # call general pre_process with its subset
                            if pre_general is not None:
                                pre_g_kwargs = {k: v for k, v in kwargs.items() if k in {p.name for p in params_pre_general}}
                                pre_general(**pre_g_kwargs)
                            # call specific pre_<method> with its subset
                            if pre_specific is not None:
                                pre_s_kwargs = {k: v for k, v in kwargs.items() if k in {p.name for p in params_pre_specific}}
                                pre_specific(**pre_s_kwargs)
                            # call actual handler with its subset
                            func_kwargs = {k: v for k, v in kwargs.items() if k in {p.name for p in params_func}}
                            return func(**func_kwargs)
                        finally:
                            self.session = None

                endpoint.__signature__ = new_sig
                endpoint.__name__ = f"{self.__class__.__name__}_{method_name}_endpoint"
                return endpoint

            if hasattr(self, "get") and ("GET" in self.methods or "get" in self.methods):
                app.add_api_route(path, _make_endpoint("get", ["GET"]), methods=["GET"], **kwargs)
            if hasattr(self, "post") and ("POST" in self.methods or "post" in self.methods):
                app.add_api_route(path, _make_endpoint("post", ["POST"]), methods=["POST"], **kwargs)
            if hasattr(self, "put") and ("PUT" in self.methods or "put" in self.methods):
                app.add_api_route(path, _make_endpoint("put", ["PUT"]), methods=["PUT"], **kwargs)
            if hasattr(self, "delete") and ("DELETE" in self.methods or "delete" in self.methods):
                app.add_api_route(path, _make_endpoint("delete", ["DELETE"]), methods=["DELETE"], **kwargs)
            if hasattr(self, "patch") and ("PATCH" in self.methods or "patch" in self.methods):
                app.add_api_route(path, _make_endpoint("patch", ["PATCH"]), methods=["PATCH"], **kwargs)
            
    return SessionView