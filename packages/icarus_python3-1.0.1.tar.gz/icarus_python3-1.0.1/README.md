# IcarusPython3

IcarusPython3 is the Python3 build system for first-party Python packages in Icarus Builder.

## Package documentation
[Read the Docs](file:///Users/carlogtt/Library/CloudStorage/Dropbox/SDE/Python/CarloCodes/_Projects/IcarusPython3/docs/html/index.html)
