# Built-in Jinja2 notification templates for LakeLogic.
# These are loaded automatically as defaults when no custom template is configured.
