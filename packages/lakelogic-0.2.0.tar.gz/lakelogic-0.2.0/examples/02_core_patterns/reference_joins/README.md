# Reference Joins

Enrich your data by joining with lookup/reference tables.

## What You'll Learn

1. Declare reference datasets
2. Join with SQL transformations
3. Validate referential integrity

## Files

reference_joins/
- contract.yaml
- playbook.ipynb
- data/customers.csv
- data/dim_geography.csv
- data/marketing_opt_outs.csv

## Run It

Open playbook.ipynb and run the cells.

## Use Cases

- Geography enrichment
- Compliance filtering
- Code lookups
- Referential integrity checks

## Next Steps

- ../bronze_quality_gate/ - Quality at ingestion
- ../dedup_survivorship/ - Handle duplicates
