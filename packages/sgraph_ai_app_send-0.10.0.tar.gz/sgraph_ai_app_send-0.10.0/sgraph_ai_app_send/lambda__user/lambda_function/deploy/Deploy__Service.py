from mgraph_ai_service_cache_client.schemas.consts.const__Fast_API import ENV_VAR__CACHE__SERVICE__BUCKET_NAME

import sgraph_ai_app_send__ui__user
from osbot_fast_api_serverless.deploy.Deploy__Serverless__Fast_API          import Deploy__Serverless__Fast_API
from osbot_utils.utils.Env                                                  import get_env
from sgraph_ai_app_send.lambda__user.user__config                           import APP__SEND__USER__LAMBDA_DEPENDENCIES, APP__SEND__USER__SERVICE_NAME
from sgraph_ai_app_send.lambda__user.user__config                           import ENV_VAR__SGRAPH_SEND__ADMIN__BASE_URL
from sgraph_ai_app_send.lambda__user.user__config                           import ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__NAME
from sgraph_ai_app_send.lambda__user.user__config                           import ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__VALUE
from sgraph_ai_app_send.lambda__user.lambda_function.lambda_handler__user   import run


class Deploy__Service(Deploy__Serverless__Fast_API):

    def deploy_lambda(self):
        with super().deploy_lambda() as _:
            _.add_folder(sgraph_ai_app_send__ui__user.path)
            _.set_env_variable(ENV_VAR__SGRAPH_SEND__ADMIN__BASE_URL      , get_env(ENV_VAR__SGRAPH_SEND__ADMIN__BASE_URL      ))
            _.set_env_variable(ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__NAME , get_env(ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__NAME  ))
            _.set_env_variable(ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__VALUE, get_env(ENV_VAR__SGRAPH_SEND__ADMIN__API_KEY__VALUE ))
            _.set_env_variable(ENV_VAR__CACHE__SERVICE__BUCKET_NAME       , get_env(ENV_VAR__CACHE__SERVICE__BUCKET_NAME        ))


            return _

    def handler(self):
        return run

    def lambda_dependencies(self):
        return APP__SEND__USER__LAMBDA_DEPENDENCIES

    def lambda_name(self):
        return APP__SEND__USER__SERVICE_NAME
