# mongo-oidc-human-callback

OIDC Human Callback for MongoDB Atlas authentication: OAuth 2.0 Authorization Code flow with PKCE (Azure AD and other OIDC providers).

**Single dependency**: `pymongo` (stdlib for the rest: `urllib`, `logging`, `http.server`, etc.).

## Installation

```bash
pip install mongo-oidc-human-callback
```

## Usage

```python
from pymongo import MongoClient
from mongo_oidc_human_callback import OIDCHumanCallback

# Connect with human callback (browser opens + PKCE)
client = MongoClient(
    "mongodb+srv://<cluster>.mongodb.net/",
    authMechanism="MONGODB-OIDC",
    authMechanismProperties={"OIDC_CALLBACK": OIDCHumanCallback()},
)
# First access: browser opens to sign in (e.g. Azure AD)
client.admin.command("ping")
```

### Callback options

```python
OIDCHumanCallback(
    redirect_path="redirect",  # or "callback" depending on Azure AD config
    port=27097,                # local callback server port
)
```

## Features

- **PKCE** (Proof Key for Code Exchange)
- **Token caching** to avoid re-authenticating on each connection
- **Local HTTP server** to receive the OAuth redirect
- **Automatic browser opening**
- **Azure AD compatibility** (endpoints `/oauth2/v2.0/authorize` and `/oauth2/v2.0/token`)

## Azure AD configuration

In the Azure portal, for your app registration:

1. **Authentication** → Redirect URI: `http://localhost:27097/redirect` (or the `port`/`redirect_path` you use).
2. **API permissions** → Microsoft Graph (or target API): e.g. `openid`, `profile`, `email`.
