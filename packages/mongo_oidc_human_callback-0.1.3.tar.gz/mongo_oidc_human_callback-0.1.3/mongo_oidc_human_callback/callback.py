"""
OIDC Human Callback implementation for MongoDB authentication.

OAuth 2.0 Authorization Code Flow with PKCE for MongoDB Atlas
(Azure AD and other OIDC providers).
"""
import base64
import hashlib
import http.server
import json
import logging
import os
import secrets
import socketserver
import stat
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from threading import Event, Thread
from typing import Any, Dict, Optional

from pymongo.auth_oidc import (
    OIDCCallback,
    OIDCCallbackContext,
    OIDCCallbackResult,
)

logger = logging.getLogger(__name__)

# Directory name inside the OS temp dir for persisted token cache
_CACHE_DIR_NAME = "mongo_oidc_human_callback"
_CACHE_FILE_NAME = "token_cache.json"

# Global in-memory cache for OIDC tokens to avoid re-authentication
_oidc_token_cache: Dict[str, Dict[str, Any]] = {}


def _get_cache_file_path() -> str:
    """Return the path to the token cache file in the OS temp directory."""
    cache_dir = os.path.join(tempfile.gettempdir(), _CACHE_DIR_NAME)
    os.makedirs(cache_dir, mode=0o700, exist_ok=True)
    return os.path.join(cache_dir, _CACHE_FILE_NAME)


def _load_cache_from_disk() -> Dict[str, Dict[str, Any]]:
    """Load the token cache from the temp directory file, if it exists."""
    path = _get_cache_file_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError, ValueError):
        pass
    return {}


def _save_cache_to_disk(cache: Dict[str, Dict[str, Any]]) -> None:
    """Persist the token cache to the temp directory file."""
    path = _get_cache_file_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cache, f)
        # Restrict permissions so only the owner can read/write the cache file
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError as e:
        logger.warning("Failed to persist token cache to disk: %s", e)


class OIDCHumanCallback(OIDCCallback):
    """
    OIDC Human Callback for browser-based authentication with PKCE.

    Implements OAuth 2.0 Authorization Code Flow with PKCE.

    Features:
    - PKCE (Proof Key for Code Exchange)
    - Token caching to avoid repeated authentication
    - Local HTTP server for callback handling
    - Browser auto-open
    - Azure AD endpoint compatibility
    """

    def __init__(self, redirect_path: str = "redirect", port: int = 27097):
        """
        Initialize the callback handler.

        Args:
            redirect_path: Path for the redirect URI (e.g. "redirect" or "callback").
            port: Port for the local callback server.
        """
        # Hydrate in-memory cache from disk on first load
        if not _oidc_token_cache:
            _oidc_token_cache.update(_load_cache_from_disk())
        self._token_cache = _oidc_token_cache
        self._redirect_path = redirect_path
        self._port = port

    def _get_cache_key(self, context: OIDCCallbackContext) -> str:
        """Generate a cache key from the context."""
        if context.idp_info:
            return (
                f"{context.idp_info.issuer}:"
                f"{context.idp_info.clientId}:"
                f"{context.username}"
            )
        return f"default:{context.username}"

    def _get_cached_token(self, cache_key: str) -> Optional[OIDCCallbackResult]:
        """Return a cached token if valid (with 60s buffer), else None."""
        if cache_key not in self._token_cache:
            return None

        cached = self._token_cache[cache_key]
        if cached.get("expires_at", 0) > time.time() + 60:
            logger.debug("Using cached OIDC token for %s", cache_key)
            return OIDCCallbackResult(
                access_token=cached["access_token"],
                expires_in_seconds=cached.get("expires_at", 0) - time.time(),
                refresh_token=cached.get("refresh_token"),
            )

        del self._token_cache[cache_key]
        _save_cache_to_disk(self._token_cache)
        return None

    def _cache_token(
        self,
        cache_key: str,
        token: str,
        expires_in: Optional[float],
        refresh_token: Optional[str],
    ) -> None:
        """Store a token with expiration (in-memory and on disk)."""
        self._token_cache[cache_key] = {
            "access_token": token,
            "expires_at": time.time() + (expires_in or 3600),
            "refresh_token": refresh_token,
        }
        _save_cache_to_disk(self._token_cache)

    def fetch(self, context: OIDCCallbackContext) -> OIDCCallbackResult:
        """
        Fetch OIDC token via browser (PKCE flow).

        1. Generate PKCE challenge
        2. Start local HTTP server for callback
        3. Open browser with authorization URL
        4. Wait for authorization code
        5. Exchange code for access token
        6. Cache token for future use
        """
        if not context.idp_info:
            raise RuntimeError(
                "Missing required IdP information in OIDC callback parameters"
            )
        if not context.idp_info.issuer or not context.idp_info.clientId:
            raise RuntimeError("Missing issuer or clientId in IdP information")

        cache_key = self._get_cache_key(context)
        cached_token = self._get_cached_token(cache_key)
        if cached_token:
            logger.info("Using cached OIDC token (avoiding re-authentication)")
            return cached_token

        logger.info("No cached token found, starting new authentication flow...")

        code_verifier = (
            base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("utf-8").rstrip("=")
        )
        code_challenge = (
            base64.urlsafe_b64encode(
                hashlib.sha256(code_verifier.encode("utf-8")).digest()
            )
            .decode("utf-8")
            .rstrip("=")
        )

        auth_response: Dict[str, Any] = {
            "code": None,
            "error": None,
            "error_description": None,
            "received": Event(),
        }

        redirect_uri = f"http://localhost:{self._port}/{self._redirect_path}"

        class OIDCCallbackHandler(http.server.BaseHTTPRequestHandler):
            """HTTP handler for OAuth callback."""

            def do_GET(self) -> None:
                parsed_path = urllib.parse.urlparse(self.path)
                params = urllib.parse.parse_qs(parsed_path.query)

                if "code" in params:
                    auth_response["code"] = params["code"][0]
                    self.send_response(200)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = _success_html()
                    self.wfile.write(html.encode("utf-8"))
                    auth_response["received"].set()
                elif "error" in params:
                    auth_response["error"] = params["error"][0]
                    auth_response["error_description"] = params.get(
                        "error_description", [params["error"][0]]
                    )[0]
                    self.send_response(400)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = _error_html(
                        auth_response["error"],
                        auth_response["error_description"],
                    )
                    self.wfile.write(html.encode("utf-8"))
                    auth_response["received"].set()
                else:
                    self.send_response(400)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.end_headers()
                    self.wfile.write(_invalid_html().encode("utf-8"))

            def log_message(self, format: str, *args: Any) -> None:
                pass

        server: Optional[socketserver.TCPServer] = None
        try:
            server = socketserver.TCPServer(
                ("localhost", self._port), OIDCCallbackHandler
            )
            server_thread = Thread(target=server.serve_forever)
            server_thread.daemon = True
            server_thread.start()

            logger.info("Local callback server started on port %s", self._port)

            issuer = context.idp_info.issuer
            client_id = context.idp_info.clientId
            scopes = context.idp_info.requestScopes or []

            if issuer.endswith("/v2.0"):
                base_issuer = issuer.rsplit("/v2.0", 1)[0]
                auth_url = f"{base_issuer}/oauth2/v2.0/authorize"
            else:
                auth_url = f"{issuer}/authorize"

            params = {
                "client_id": client_id,
                "response_type": "code",
                "redirect_uri": redirect_uri,
                "response_mode": "query",
                "scope": " ".join(scopes) if scopes else "openid profile email",
                "code_challenge": code_challenge,
                "code_challenge_method": "S256",
            }
            full_auth_url = f"{auth_url}?{urllib.parse.urlencode(params)}"

            logger.info("Opening browser for authentication...")
            webbrowser.open(full_auth_url)
            logger.info("Waiting for authentication to complete...")

            if not auth_response["received"].wait(timeout=context.timeout_seconds):
                raise RuntimeError("Authentication timeout - no response received")

            if auth_response["error"]:
                error_msg = auth_response.get("error_description") or auth_response[
                    "error"
                ]
                raise RuntimeError(f"Authentication failed: {error_msg}")

            if not auth_response["code"]:
                raise RuntimeError("No authorization code received")

            logger.info("Authorization code received")

            if issuer.endswith("/v2.0"):
                base_issuer = issuer.rsplit("/v2.0", 1)[0]
                token_url = f"{base_issuer}/oauth2/v2.0/token"
            else:
                token_url = f"{issuer}/token"

            token_data = urllib.parse.urlencode(
                {
                    "grant_type": "authorization_code",
                    "code": auth_response["code"],
                    "redirect_uri": redirect_uri,
                    "client_id": client_id,
                    "code_verifier": code_verifier,
                }
            ).encode("utf-8")

            logger.info("Exchanging authorization code for access token (PKCE)...")

            req = urllib.request.Request(
                token_url,
                data=token_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                token_response = json.loads(resp.read().decode("utf-8"))

            access_token = token_response.get("access_token")
            refresh_token = token_response.get("refresh_token")
            expires_in = token_response.get("expires_in")

            if not access_token:
                raise RuntimeError("No access token in response")

            logger.info("Access token obtained successfully")

            self._cache_token(
                cache_key,
                access_token,
                float(expires_in) if expires_in else None,
                refresh_token,
            )

            return OIDCCallbackResult(
                access_token=access_token,
                expires_in_seconds=float(expires_in) if expires_in else None,
                refresh_token=refresh_token or context.refresh_token,
            )

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            logger.error("Token exchange failed: %s - %s", e.code, body[:200])
            raise RuntimeError(f"Token exchange failed: {e.code} - {body[:200]}") from e
        except urllib.error.URLError as e:
            logger.error("Token exchange request failed: %s", e)
            raise RuntimeError(f"Token exchange failed: {e}") from e
        except json.JSONDecodeError as e:
            logger.error("Failed to parse token response: %s", e)
            raise RuntimeError("Invalid token response format") from e
        except Exception as e:
            logger.error("OIDC authentication failed: %s", e)
            raise
        finally:
            if server:
                server.shutdown()
                server.server_close()
                logger.debug("Callback server closed")


def _success_html() -> str:
    return """
    <html>
    <head>
        <title>Authentication Successful</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f0f0f0; }
            .container { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto; }
            h1 { color: #28a745; }
            .icon { font-size: 64px; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="icon">&#10003;</div>
            <h1>Authentication Successful!</h1>
            <p>You can close this window and return to your application.</p>
        </div>
    </body>
    </html>
    """


def _error_html(error: str, description: str) -> str:
    return f"""
    <html>
    <head>
        <title>Authentication Failed</title>
        <style>
            body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f0f0f0; }}
            .container {{ background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto; }}
            h1 {{ color: #dc3545; }}
            .icon {{ font-size: 64px; margin-bottom: 20px; }}
            .error {{ color: #666; margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="icon">&#10007;</div>
            <h1>Authentication Failed</h1>
            <div class="error">
                <strong>Error:</strong> {error}<br>
                <strong>Description:</strong> {description}
            </div>
            <p style="margin-top: 20px;">Please close this window and try again.</p>
        </div>
    </body>
    </html>
    """


def _invalid_html() -> str:
    return """
    <html>
    <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
        <h1>Invalid Request</h1>
        <p>Missing required parameters.</p>
    </body>
    </html>
    """
