"""
OIDC Human Callback for MongoDB authentication.

Browser-based OAuth 2.0 Authorization Code Flow with PKCE for MongoDB Atlas
(Azure AD and other OIDC providers).
"""

from mongo_oidc_human_callback.callback import OIDCHumanCallback

__all__ = ["OIDCHumanCallback"]
__version__ = "0.1.0"
