import pytest
from fastval import BaseModel, ValidationError
from typing import List

class User(BaseModel):
    name: str
    age: int = 25
    email: str

class Post(BaseModel):
    title: str
    content: str
    author: User

def test_basic_validation():
    data = {'name': 'John', 'email': 'john@example.com'}
    user = User(data)
    assert user.name == 'John'
    assert user.age == 25
    assert user.email == 'john@example.com'

def test_required_field_missing():
    data = {'name': 'John'}
    with pytest.raises(ValidationError):
        User(data)

def test_wrong_type():
    data = {'name': 123, 'email': 'john@example.com'}
    with pytest.raises(ValidationError):
        User(data)

def test_optional_field():
    data = {'name': 'John', 'email': 'john@example.com', 'age': 30}
    user = User(data)
    assert user.age == 30

def test_nested_model():
    data = {
        'title': 'Hello',
        'content': 'World',
        'author': {'name': 'John', 'email': 'john@example.com'}
    }
    post = Post(data)
    assert post.title == 'Hello'
    assert post.author.name == 'John'

def test_dict_method():
    data = {'name': 'John', 'email': 'john@example.com'}
    user = User(data)
    d = user.dict()
    assert d == {'name': 'John', 'age': 25, 'email': 'john@example.com'}

def test_json_method():
    data = {'name': 'John', 'email': 'john@example.com'}
    user = User(data)
    j = user.json()
    import json
    expected_dict = {'name': 'John', 'age': 25, 'email': 'john@example.com'}
    assert json.loads(j) == expected_dict
