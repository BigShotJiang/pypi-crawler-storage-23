import orjson

def to_json(data):
    return orjson.dumps(data).decode('utf-8')

def from_json(json_str):
    return orjson.loads(json_str)
