# FastVal

Ultra-fast Cython-based data validation library for Python, optimized for FastAPI. A faster alternative to Pydantic.

## Features

- Fast validation using Cython
- Nested model support
- Optional fields with defaults
- JSON serialization with orjson
- Drop-in compatible with FastAPI
- Pydantic-style annotations

## Installation

Clone the repo and build:

```bash
git clone https://github.com/youruser/fastval.git
cd fastval
pip install -e .
```

## Usage

Define models with annotations, just like Pydantic:

```python
from fastval import BaseModel
from typing import List

class User(BaseModel):
    name: str
    age: int = 25
    email: str

class Post(BaseModel):
    title: str
    content: str
    author: User
    tags: List[str] = []

# Validate data
user = User({'name': 'John', 'email': 'john@example.com'})
print(user.dict())  # {'name': 'John', 'age': 25, 'email': 'john@example.com'}
print(user.json())  # JSON string
```

For FastAPI:

```python
from fastapi import FastAPI

app = FastAPI()

@app.post("/users")
async def create_user(payload: dict):
    user = User(payload)
    return user.dict()
```

## Benchmarks

FastVal outperforms Pydantic in validation and JSON serialization:

- **10,000 users validation**: FastVal 2.61x faster (0.0042s vs 0.0109s)
- **JSON serialization**: FastVal 2.99x faster (0.0023s vs 0.0068s)
- **Nested models (1,000 posts)**: FastVal 1.44x faster (0.0009s vs 0.0013s)
- **Large payloads (100k users)**: FastVal 2.21x faster (0.0647s vs 0.1429s)

Run `python benchmark.py` to see live results.

## Tests

Run `pytest tests/`
