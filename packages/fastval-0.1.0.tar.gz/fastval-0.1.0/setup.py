# Setup script for FastVal, using Cython to compile extensions

from setuptools import setup, Extension
from Cython.Build import cythonize

extensions = [
    Extension("fastval.models", ["fastval/models.pyx"]),
    Extension("fastval.fields", ["fastval/fields.pyx"]),
]

setup(
    name="fastval",
    version="0.1.0",
    packages=["fastval"],
    ext_modules=cythonize(extensions),
    install_requires=[
        "orjson",
    ],
)
