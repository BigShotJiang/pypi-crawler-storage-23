# HW Maya Toolbox

Utilities for Autodesk Maya, focused on technical animation related tasks.

## Installation

Install using pip or your Python package manager of choice, in a location available to Maya.

### Add to you existing Python project/launcher using uv:

```bash
uv add hw-maya-toolbox
```

### Permanent installation in the Maya site-packages directory:

```bash
uv pip install --target <maya-user-dir>/<version>/scripts/site-packages hw-maya-toolbox
```

## Usage

To show the UI, run:

```python
from hw_maya_toolbox.ui import show_ui
show_ui()
```

This will open up a Qt toolbox, with tabs containing various utilities.

## Screenshots

![General Tab](resources/img/hw_toolbox_general_tab.png)

![Joint Tab](resources/img/hw_toolbox_joint_tab.png)

![Dev Tab](resources/img/hw_toolbox_dev_tab.png)
