# Copyright (C) 2026 Henrik Wilhelmsen
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at <https://mozilla.org/MPL/2.0/>.
LOCATOR_SCALE: tuple[int, int, int] = (15, 15, 15)
JOINT_RADIUS = 1.5
DEBUG_PORT = 5678
MODULE_RELOAD_NAMES: list[str] = ["hw_"]
