"""."""

import copy

from typing import Callable

import numpy as np

from kinematic_tracker.types import FMT, IVT


class ScoreCopy:
    def __init__(self, num_cls: int) -> None:
        self.num_cls = num_cls
        self.score_crt = np.empty(num_cls, dtype=object)
        self.creation_ids_ct = np.empty(num_cls, dtype=object)

    def set(self, cls: int, creation_ids: Callable[[int], IVT], score_rt: FMT) -> None:
        self.score_crt[cls] = score_rt.copy()
        self.creation_ids_ct[cls] = creation_ids(cls)

    def deep_copy(self) -> 'ScoreCopy':
        return copy.deepcopy(self)


class StubScoreCopy:
    def __repr__(self) -> str:
        return 'Stub for the ScoreCopy. NdKkfTracker(..., return_score=True) maybe?'

    def set(self, _cls: int, _creation_ids: Callable[[int], IVT], _score_rt: FMT) -> None: ...

    def deep_copy(self) -> 'StubScoreCopy':
        return self


def get_score_copy(return_score: bool, num_cls: int) -> ScoreCopy | StubScoreCopy:
    if return_score:
        return ScoreCopy(num_cls)
    return StubScoreCopy()
