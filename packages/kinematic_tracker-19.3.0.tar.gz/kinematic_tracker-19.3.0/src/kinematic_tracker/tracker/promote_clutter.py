from typing import Sequence

from kinematic_tracker.core.track_free_id import get_free_id

from .track import NdKkfTrack


def promote_clutter_eventually(tracks: Sequence[NdKkfTrack], num_det_min: int) -> None:
    """Promote clutter tracks to regular tracks if they meet the
    condition on the minimal number of consecutive associations.
    """
    for track in tracks:
        if track.id < 0 and track.num_det > num_det_min:
            track.id = get_free_id(tracks)
