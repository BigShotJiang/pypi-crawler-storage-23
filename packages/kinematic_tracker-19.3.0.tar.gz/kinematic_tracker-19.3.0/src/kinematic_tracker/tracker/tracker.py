"""NdKkfTracker class implementation.

This module defines the NdKkfTracker class. The tracker is responsible for managing
and updating a set of Kalman filter-based tracks to organize the multiple-object tracking.
It provides methods for associating detections with existing tracks, creating
new tracks, and removing stale tracks.

Classes:
    NdKkfTracker: A tracker that uses kinematic Kalman filters for multiple-object tracking.
"""

from typing import Sequence

import cv2
import numpy as np

from kinematic_tracker.association.association import Association, AssociationMethod
from kinematic_tracker.association.association_metric import AssociationMetric
from kinematic_tracker.core.creation_id import CreationIdManager
from kinematic_tracker.core.loose_items import get_loose_indices
from kinematic_tracker.nd.gen_kf import NdKkfGenKf
from kinematic_tracker.nd.shape import NdKkfShape
from kinematic_tracker.proc_noise.meta import ProcNoiseMeta
from kinematic_tracker.proc_noise.nd_kkf_proc_noise_factory import get_proc_noise
from kinematic_tracker.types import FMT, IVT

from .check import check_cls_r, check_cov_zz, check_det_rz, check_ids_r, check_stamp_type
from .kkf import NdKkf
from .promote_clutter import promote_clutter_eventually
from .score_copy import ScoreCopy, StubScoreCopy, get_score_copy
from .targets import correct_associated, upd_for_loose_tracks
from .track import NdKkfTrack


UNKNOWN_REPORT_ID = -1000


class NdKkfTracker:
    """NdKkfTracker class to manage the multiple-object tracking using the
       N-dimensional, mixed-order, kinematic Kalman filters.

    Attributes:
        shape: auxiliary object encoding the distribution of variables in N-dimensional,
               mixed-order, block-diagonal state vectors.
        gen_xz: A manager object to cope with the block-diagonal distribution of variables.
                Contains a shared buffer for the measurement model matrix (H).
        ini_der_vars: Initial variances for diagonal parts of the error covariances not defined
                      by the measurement covariances.
        pre: Precursor 1D matrices for Kalman filter prediction step (transition- and white-noise).
        pn_meta: Metadata (parameters) for the process-noise calculation.
        creation_id_manager: A generator of the globally unique track IDs.
        tracks_c: Array of lists of tracked targets, i.e. lists of tracks resolved in object classes.
        gen_kf: Kalman filter generator. Contains a shared buffer for transition matrices.
        association: Metadata (parameters) for association of detection reports and targets.
        metric_driver: Metric computation driver for association.
        match_driver: Match computation driver for association.
        cov_zz: Measurement covariance matrix. Initially None, must be set before use.
        num_misses_max: Maximum number of consecutive misses before target removal.
        num_det_min: Minimum number of consecutive detections required to confirm targets.
        last_ts_ns: Timestamp of the last prediction in nanoseconds.
    """

    def __init__(
        self,
        orders_x: Sequence[int],
        num_dims: Sequence[int],
        orders_z: Sequence[int] | None = None,
        return_score: bool = False,
        num_cls: int = 1,
    ) -> None:
        """Initialize the NdKkfTracker.

        Args:
            orders_x: Kinematic orders for each part of the ND, mixed-order states.
            num_dims: Number of dimensions for each part of the ND, mixed-order state.
            orders_z: Kinematic orders of the measurement variables. The argument is optional.
                      If not provided, it defaults to a sequence of ones of suitable length.
            num_cls: Number of object classes. The objects-target association happens
                     within the same class.
        """
        orders_z_seq = [1] * len(num_dims) if orders_z is None else orders_z
        self.score_copy = get_score_copy(return_score, num_cls)
        self.shape = NdKkfShape(orders_x, num_dims, orders_z_seq)
        self.gen_xz = self.shape.get_mat_gen_xz()
        self.ini_der_vars = 100.0 * np.ones(self.gen_xz.gen_x.num_d)
        self.pre = self.shape.get_precursors()
        self.pn_meta = ProcNoiseMeta()
        self.creation_id_manager = CreationIdManager()
        self.tracks_c = np.empty(num_cls, object)
        for cls in range(num_cls):
            self.tracks_c[cls] = []
        num_x = self.gen_xz.gen_x.num_x
        self.gen_kf = NdKkfGenKf(np.zeros((num_x, num_x)))
        num_z = self.gen_xz.num_z
        self.association = Association(num_x, num_z)
        self.metric_driver = self.association.get_metric_driver()
        self.match_driver = self.association.get_match_driver()
        self.cov_zz = np.zeros((num_z, num_z))
        np.fill_diagonal(self.cov_zz, np.nan)
        self.num_misses_max = 3
        self.num_det_min = 3
        self.last_ts_ns = 0
        num_reports_max = self.association.num_reports_max
        self.unknown_report_ids = UNKNOWN_REPORT_ID * np.ones(num_reports_max, dtype=int)
        self.buf_rz = np.zeros((num_reports_max, self.gen_xz.num_z))
        self.int_zeros_r = np.zeros(num_reports_max, dtype=int)

    def clear_tracks(self) -> None:
        for tracks in self.tracks_c:
            tracks.clear()

    def reset(self) -> None:
        """Start tracking without tracks."""
        self.last_ts_ns = 0
        self.clear_tracks()

    def set_association_method(self, method_name: str) -> None:
        """Set the association method for matching detections to tracks.

        Args:
            method_name: Name of the association method.
        """
        self.association.method = AssociationMethod(method_name)
        self.match_driver = self.association.get_match_driver()

    def set_association_metric(
        self,
        metric_name: str,
        mah_factor: float = 1.0,
        ind_pos_size: Sequence[int] = (0, 1, 2, -3, -2, -1),
    ) -> None:
        """Set the association metric for evaluating matches.

        Args:
            metric_name: name of the association metric.
            mah_factor: Mahalanobis distance pre-factor. Defaults to 1.0.
            ind_pos_size: indices for extracting positions and sizes from the measurement vectors.
                          For more details, see docstring of the method `set_ind_pos_size(...)`.
        """
        self.association.metric = AssociationMetric(metric_name)
        self.association.mah_pre_factor = mah_factor
        self.association.ind_pos_size = ind_pos_size
        self.metric_driver = self.association.get_metric_driver()

    def set_association_threshold(self, threshold: float) -> None:
        """Set the matching threshold for the association.

        The threshold is a guard against clutter detections.
        This setter is very simple. It exists to assure the library consumers.

        Args:
            threshold: new threshold value.
        """
        if not (0.0 < threshold < 1.0):
            raise ValueError(f'Threshold {threshold} seems to be out of range.')
        self.association.threshold = threshold

    def set_max_reports_and_targets(self, num_reports_max: int, num_targets_max: int) -> None:
        """Set the maximum number of reports (detected objects) and targets (tracked objects).

        Args:
            num_reports_max: maximum number of reports.
            num_targets_max: maximum number of targets.
        """
        self.association.num_reports_max = num_reports_max
        self.association.num_targets_max = num_targets_max
        self.unknown_report_ids = UNKNOWN_REPORT_ID * np.ones(num_reports_max, int)
        self.buf_rz = np.zeros((num_reports_max, self.gen_xz.num_z))
        self.int_zeros_r = np.zeros(num_reports_max, int)
        self.metric_driver = self.association.get_metric_driver()
        self.match_driver = self.association.get_match_driver()

    def set_ind_pos_size(self, ind_pos_size: Sequence[int]) -> None:
        """Set the distribution of variables in the measurement vector.

        This is relevant for GIoU metric because for this metric we treat the
        variables in a non-uniform way. Firstly, the measurement vector
        should contain the positions of the cuboids as well as their sizes (dimensions).
        Secondly, we should not mix up positions (vector with 3 variables)
        and sizes (another vector with 3 variables). Finally, the distribution
        of variables in the measurement vector could be arbitrary, so we
        need a permutation index in general. The argument `ind_pos_size` should be
        a sequence of integers pointing to the positions and sizes of the cuboids
        in the following convention:

           (pos_x, pos_y, pos_z, size_x, size_y, size_z)

        By default, the `ind_pos_size = (0, 1, 2, -3, -2, -1)`. This corresponds
        to the positions gathered at the start of the measurement vector and
        the sizes gathered at the end of the measurement vector. This choice of default
        value should be convenient for ASAM OpenLabel measurement vectors.
        The ASAM OpenLabel measurement vectors feature the following distribution of
        variables

            z^T = (px, py, pz, alpha, beta, gamma, sx, sy, sz)

        or

            z^T = (px, py, pz, a, b, c, d, sx, sy, sz)

        In both cases, the sizes of the cuboids locate at the end of the measurement vector.

        Args:
            ind_pos_size: the permutation pointer array.
        """
        self.clear_tracks()
        self.association.ind_pos_size = ind_pos_size
        self.metric_driver = self.association.get_metric_driver()

    def set_measurement_cov(self, cov_zz: np.ndarray) -> None:
        """Set (the whole) measurement covariance matrix.

        Args:
            cov_zz: Measurement covariance matrix.

        Raises:
            ValueError: If the shape of the covariance matrix is incorrect.
        """
        shape = self.cov_zz.shape
        if cov_zz.shape != shape:
            raise ValueError(f'Wrong shape of the measurement covariance. Expected {shape}.')
        self.cov_zz[:, :] = cov_zz

    def set_measurement_std_dev(self, part: int, std_dev: float, der_order: int = 0) -> None:
        """Set the standard deviation for a given part of the measurement vector.

        Args:
            part: Index of the measurement part.
            std_dev: Standard deviation value.
            der_order: Derivative order. Defaults to 0.

        Raises:
            ValueError: If no element is found for the given part and derivative order.
        """
        ind = 0
        variance = std_dev * std_dev
        is_set = False
        for cur_part, (o, nd) in enumerate(zip(self.gen_xz.orders_z, self.gen_xz.gen_x.num_dof)):
            for _ in range(nd):
                for cur_der_order in range(o):
                    if cur_der_order == der_order and cur_part == part:
                        self.cov_zz[ind, ind] = variance
                        is_set = True
                    ind += 1
        if not is_set:
            raise ValueError(f'No element found for part {part} and der_order {der_order}')

    def __repr__(self) -> str:
        """Return a string representation of the tracker.

        Returns:
            str: String representation of the tracker.
        """
        return (
            f'NdKkfTracker(\n'
            f'    {self.association}\n'
            f'    num_misses_max {self.num_misses_max}\n'
            f'    num_det_min {self.num_det_min})'
        )

    def get_track(self, vec_z: np.ndarray, ann_id: int) -> NdKkfTrack:
        """Create a new track for a given measurement vector, with corresponding annotation ID.

        Args:
            vec_z: Measurement (detection) vector.
            ann_id: Annotation ID of the detection report.

        Returns:
            NdKkfTrack: Newly created track.
        """
        check_cov_zz(self.cov_zz)
        kf = self.gen_kf.get_kf(self.gen_xz, vec_z, self.cov_zz, self.ini_der_vars)
        proc_noise = get_proc_noise(self.gen_xz.gen_x, self.pn_meta, kf.statePre[:, 0])
        nd_kkf = NdKkf(kf, proc_noise)
        track = NdKkfTrack(nd_kkf, ann_id)
        track.creation_id = self.creation_id_manager.get_next_id()
        return track

    def upd_for_loose_reports(
        self, tracks: list[NdKkfTrack], reports: IVT, det_rz: FMT, ids_r: IVT
    ) -> None:
        """Update the list of targets for loose detections (detections without association).

        Args:
            tracks: list of tracks to be eventually extended based on unmatched detections.
            reports: Indices of associated reports.
            det_rz: Detection vectors to eventually construct the states of new targets.
            ids_r: Annotation IDs to eventually assign in the new targets.
        """
        reports_wo_correspondence = get_loose_indices(reports, len(det_rz))
        for r in reports_wo_correspondence:
            tracks.append(self.get_track(det_rz[r], ids_r[r]))

    def get_kalman_filters(self, cls: int) -> list[cv2.KalmanFilter]:
        """Get the list of Kalman filters for all tracks.

        Args:
            cls: the class label (0:num_cls)

        Returns:
            list[cv2.KalmanFilter]: List of Kalman filters.
        """
        return [track.kkf.kalman_filter for track in self.tracks_c[cls]]

    def predict_all(self, time_stamp_ns: int | np.int64) -> None:
        """Predict the state of all tracks to the given timestamp.

        Args:
            time_stamp_ns: Timestamp in nanoseconds.
        """
        check_stamp_type(time_stamp_ns)
        dt = (time_stamp_ns - self.last_ts_ns) / 1e9
        assert dt >= 0.0
        self.last_ts_ns = time_stamp_ns
        self.pre.compute(dt)
        self.gen_xz.gen_x.fill_f_mat(self.pre, self.gen_kf.f_mat)
        for tracks in self.tracks_c:
            for track in tracks:
                track.kkf.predict(self.pre)

    def get_creation_ids(self, cls: int) -> IVT:
        tracks = self.tracks_c[cls]
        return np.fromiter((t.creation_id for t in tracks), dtype=int)

    def advance(
        self, stamp_ns: int, det_rz: FMT, ids_r: IVT = tuple(), *, cls_r: IVT = tuple()
    ) -> ScoreCopy | StubScoreCopy:
        """Advance tracks to the given timestamp with new detections.

        Args:
            stamp_ns: timestamp of the detections in nanoseconds.
            det_rz: detection vectors.
            ids_r: annotation IDs.
            cls_r: optional class labels (0:num_cls)

        Returns:
            ScoreCopy or MagicMock object.
        """
        check_det_rz(det_rz, self.gen_xz.num_z)
        self.predict_all(stamp_ns)
        num_reports = len(det_rz)
        cls_ind_r = self.int_zeros_r[:num_reports] if len(cls_r) == 0 else cls_r
        check_cls_r(cls_ind_r, num_reports, len(self.tracks_c))
        no_ids = len(ids_r) == 0
        if not no_ids:
            check_ids_r(ids_r, num_reports)
        for cls, tracks in enumerate(self.tracks_c):
            cls_mask_r = cls_ind_r == cls
            num_r_cls = np.sum(cls_mask_r)
            self.buf_rz[:num_r_cls] = det_rz[cls_mask_r]
            fdt_rz = self.buf_rz[:num_r_cls]
            score_rt = self.metric_driver.compute_metric(fdt_rz, self.get_kalman_filters(cls))
            self.score_copy.set(cls, self.get_creation_ids, score_rt)
            self.match_driver.compute_matches(score_rt, self.association.threshold)
            reports, targets = self.match_driver.get_reports_targets()
            report_ids = self.unknown_report_ids[:num_r_cls] if no_ids else ids_r[cls_mask_r]
            num_tracks_before = len(tracks)
            correct_associated(tracks, reports, targets, score_rt, fdt_rz, report_ids)
            self.upd_for_loose_reports(tracks, reports, fdt_rz, report_ids)
            promote_clutter_eventually(tracks, self.num_det_min)
            upd_for_loose_tracks(tracks, targets, num_tracks_before, self.num_misses_max)

        return self.score_copy.deep_copy()
