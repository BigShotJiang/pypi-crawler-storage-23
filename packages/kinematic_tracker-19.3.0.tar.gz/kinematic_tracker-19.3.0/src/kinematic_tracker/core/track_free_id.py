"""."""

from typing import Any, Sequence

from .free_id_builtin import get_free_id_builtin


def get_free_id(tracks: Sequence[Any]) -> int:
    return get_free_id_builtin([track.id for track in tracks])
