"""."""

from kinematic_tracker.core.creation_id import CreationIdManager


def test_creation_id() -> None:
    """."""
    driver = CreationIdManager()
    assert driver.get_next_id() == 0
    assert driver.get_next_id() == 1
    assert driver.get_next_id() == 2
