"""."""

from kinematic_tracker.core.free_id_builtin import get_free_id_builtin


def test_get_free_id() -> None:
    """."""
    assert get_free_id_builtin([-1, -1]) == 0
    assert get_free_id_builtin([-1, 1]) == 0
    assert get_free_id_builtin([-1, 0]) == 1
    assert get_free_id_builtin([1, 2]) == 0
    assert get_free_id_builtin([0, 1]) == 2
