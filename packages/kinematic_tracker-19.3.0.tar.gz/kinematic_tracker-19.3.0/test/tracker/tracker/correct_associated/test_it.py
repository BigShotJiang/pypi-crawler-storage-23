"""."""

import numpy as np

from kinematic_tracker.tracker.targets import correct_associated


def test_correct_associated() -> None:
    """."""
    r2z = np.ones((1, 6))
    r2id = np.array([567])
    score_rt = np.zeros((1, 0))
    tracks = []
    correct_associated(tracks, np.empty(0, int), np.empty(0, int), score_rt, r2z, r2id)
    assert tracks == []
