"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.score_copy import ScoreCopy


def test_with_score_copy(tracker1: NdKkfTracker) -> None:
    tracker1.score_copy = ScoreCopy(1)
    rv = tracker1.advance(2000_000_000, np.linspace(1.1, 6.1, num=6).reshape(1, 6))
    assert isinstance(rv, ScoreCopy)
    assert id(tracker1.score_copy) != id(rv)
    assert rv.score_crt[0] == pytest.approx(0.84785213)
    assert rv.score_crt[0].ndim == 2
    assert rv.creation_ids_ct[0] == pytest.approx([0])
