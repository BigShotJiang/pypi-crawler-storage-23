"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.score_copy import StubScoreCopy
from kinematic_tracker.tracker.tracker import UNKNOWN_REPORT_ID


def test_with_report_ids(tracker1: NdKkfTracker) -> None:
    """."""
    assert tracker1.last_ts_ns == 1234_000_000
    assert tracker1.pre.last_dt == pytest.approx(1.234)
    assert len(tracker1.tracks_c[0]) == 1
    track = tracker1.tracks_c[0][0]
    assert track.ann_id == 123
    assert track.upd_id == 123
    assert track.num_miss == 0
    assert track.num_det == 0
    vec_x_ref = [1, 0, 0, 2, 0, 0, 3, 0, 0, 4, 5, 6]
    assert track.kkf.kalman_filter.statePost[:, 0] == pytest.approx(vec_x_ref)


def test_without_report_ids(tracker: NdKkfTracker) -> None:
    """."""
    tracker.set_measurement_cov(0.01 * np.eye(6))
    rv = tracker.advance(1000_000_000, np.linspace(1.0, 6.0, num=6).reshape(1, 6))
    assert isinstance(rv, StubScoreCopy)
    assert len(tracker.tracks_c[0]) == 1
    track = tracker.tracks_c[0][0]
    assert track.ann_id == UNKNOWN_REPORT_ID
    assert track.upd_id == UNKNOWN_REPORT_ID
