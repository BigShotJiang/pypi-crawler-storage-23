"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.track import NdKkfTrack


def test_non_trivial(tc2: NdKkfTracker) -> None:
    r2z = np.linspace(1.0, 18.0, num=18).reshape(3, 6) + 1.0
    r2id = np.array([123, 234, 345])
    tc2.advance(2234_000_000, r2z, r2id, cls_r=np.array([1, 1, 1]))

    assert len(tc2.tracks_c) == 2
    assert len(tc2.tracks_c[0]) == 1
    assert len(tc2.tracks_c[1]) == 3

    track00: NdKkfTrack = tc2.tracks_c[0][0]
    assert track00.creation_id == 0
    assert track00.num_miss == 1
    assert track00.upd_id == -9999
    assert track00.kkf.kalman_filter.statePost[:, 0] == pytest.approx(
        [1, 0, 0, 2, 0, 0, 3, 0, 0, 4, 5, 6]
    )

    track10: NdKkfTrack = tc2.tracks_c[1][0]
    assert track10.creation_id == 1
    # fmt: off
    ref10 = [7.9980079681274905, 1.1952191235059761, 0.398406374501992, 8.99800796812749,
             1.1952191235059761, 0.398406374501992, 9.99800796812749, 1.1952191235059761,
             0.398406374501992, 10.5, 11.5, 12.5]
    # fmt: on
    assert track10.kkf.kalman_filter.statePost[:, 0] == pytest.approx(ref10)

    track11: NdKkfTrack = tc2.tracks_c[1][1]
    assert track11.creation_id == 2
    # fmt: off
    ref11 = [13.99800796812749, 1.1952191235059761, 0.398406374501992, 14.99800796812749,
             1.1952191235059761, 0.398406374501992, 15.99800796812749, 1.1952191235059761,
             0.398406374501992, 16.5, 17.5, 18.5]
    # fmt: on
    assert track11.kkf.kalman_filter.statePost[:, 0] == pytest.approx(ref11)

    track12: NdKkfTrack = tc2.tracks_c[1][2]
    assert track12.creation_id == 3
    assert track12.kkf.kalman_filter.statePost[:, 0] == pytest.approx(
        [2, 0, 0, 3, 0, 0, 4, 0, 0, 5, 6, 7]
    )
