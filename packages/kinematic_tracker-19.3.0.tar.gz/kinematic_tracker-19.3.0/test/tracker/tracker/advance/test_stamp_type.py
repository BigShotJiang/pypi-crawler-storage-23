"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker


def test_it(tracker: NdKkfTracker) -> None:
    with pytest.raises(TypeError) as err:
        tracker.advance(123.0, np.zeros((1, 6)))

    ref = "Time stamp (nanoseconds) should be an integer or np.int64, but got <class 'float'>"
    assert err.value.args[0] == ref
