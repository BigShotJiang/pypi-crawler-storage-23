"""."""

import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.track import NdKkfTrack


def test_step1(tc2: NdKkfTracker) -> None:
    assert len(tc2.tracks_c) == 2
    assert len(tc2.tracks_c[0]) == 1
    assert len(tc2.tracks_c[1]) == 2

    track00: NdKkfTrack = tc2.tracks_c[0][0]
    assert track00.creation_id == 0
    assert track00.kkf.kalman_filter.statePost[:, 0] == pytest.approx(
        [1, 0, 0, 2, 0, 0, 3, 0, 0, 4, 5, 6]
    )

    track10: NdKkfTrack = tc2.tracks_c[1][0]
    assert track10.creation_id == 1
    ref10 = 7, 0, 0, 8, 0, 0, 9, 0, 0, 10, 11, 12
    assert track10.kkf.kalman_filter.statePost[:, 0] == pytest.approx(ref10)

    track11: NdKkfTrack = tc2.tracks_c[1][1]
    assert track11.creation_id == 2
    ref11 = 13, 0, 0, 14, 0, 0, 15, 0, 0, 16, 17, 18
    assert track11.kkf.kalman_filter.statePost[:, 0] == pytest.approx(ref11)
