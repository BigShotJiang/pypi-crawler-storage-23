"""."""

from kinematic_tracker import NdKkfTracker


def test_nd_kkf_tracker_repr(tracker: NdKkfTracker) -> None:
    """."""
    ref = """NdKkfTracker(
    Association(greedy mahalanobis threshold 0.56 mah_pre_factor 1.32)
    num_misses_max 3
    num_det_min 2)"""
    assert repr(tracker) == ref
