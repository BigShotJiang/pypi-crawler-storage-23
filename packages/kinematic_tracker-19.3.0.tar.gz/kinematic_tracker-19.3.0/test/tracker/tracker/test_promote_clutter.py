"""."""

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.promote_clutter import promote_clutter_eventually


def test_promote_clutter() -> None:
    tracks = []
    promote_clutter_eventually(tracks, 3)
    assert len(tracks) == 0


def test_promote_clutter1(tracker1: NdKkfTracker) -> None:
    tracker1.tracks_c[0][0].num_det = 5
    promote_clutter_eventually(tracker1.tracks_c[0], tracker1.num_det_min)
    assert tracker1.tracks_c[0][0].id == 0
