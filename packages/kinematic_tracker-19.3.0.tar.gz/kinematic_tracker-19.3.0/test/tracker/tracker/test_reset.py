"""."""

from kinematic_tracker import NdKkfTracker


def test_reset1(tracker1: NdKkfTracker) -> None:
    tracker1.reset()
    assert tracker1.tracks_c.shape == (1,)
    assert len(tracker1.tracks_c[0]) == 0
    assert tracker1.last_ts_ns == 0


def test_reset2(tc2: NdKkfTracker) -> None:
    tc2.reset()
    assert tc2.tracks_c.shape == (2,)
    assert len(tc2.tracks_c[0]) == 0
    assert len(tc2.tracks_c[1]) == 0
