"""."""

import numpy as np

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.targets import upd_for_loose_tracks


def test_upd_for_loose_tracks1(tracker1: NdKkfTracker) -> None:
    upd_for_loose_tracks(tracker1.tracks_c[0], np.zeros(1, int), 1, tracker1.num_misses_max)
    assert len(tracker1.tracks_c[0]) == 1
    assert tracker1.tracks_c[0][0].num_miss == 0
