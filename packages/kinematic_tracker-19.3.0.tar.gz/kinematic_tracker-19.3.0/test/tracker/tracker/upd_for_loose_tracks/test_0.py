"""."""

import numpy as np

from kinematic_tracker.tracker.targets import upd_for_loose_tracks


def test_nd_kkf_tracker_upd_for_loose_tracks() -> None:
    tracks = []
    upd_for_loose_tracks(tracks, np.empty(0, int), 0, 3)
    assert tracks == []
