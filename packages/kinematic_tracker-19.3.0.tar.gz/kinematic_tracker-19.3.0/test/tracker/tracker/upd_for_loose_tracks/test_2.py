"""."""

import numpy as np

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.targets import upd_for_loose_tracks


def test_remove_track(tracker1: NdKkfTracker) -> None:
    """."""
    no_targets = np.empty(0, int)
    tracks = tracker1.tracks_c[0]
    upd_for_loose_tracks(tracks, no_targets, 1, tracker1.num_misses_max)
    assert len(tracks) == 1
    assert tracks[0].num_miss == 1

    upd_for_loose_tracks(tracks, no_targets, 1, tracker1.num_misses_max)
    assert len(tracks) == 1
    assert tracks[0].num_miss == 2

    upd_for_loose_tracks(tracks, no_targets, 1, tracker1.num_misses_max)
    assert len(tracks) == 1
    assert tracks[0].num_miss == 3

    upd_for_loose_tracks(tracks, no_targets, 1, tracker1.num_misses_max)
    assert len(tracks) == 0
