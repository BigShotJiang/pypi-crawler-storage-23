"""."""

from kinematic_tracker import NdKkfTracker


def test_single_class(tracker1: NdKkfTracker) -> None:
    tracker1.clear_tracks()
    assert tracker1.tracks_c[0] == []


def test_two_classes(tc2: NdKkfTracker) -> None:
    tc2.clear_tracks()
    assert tc2.tracks_c[0] == []
    assert tc2.tracks_c[1] == []
