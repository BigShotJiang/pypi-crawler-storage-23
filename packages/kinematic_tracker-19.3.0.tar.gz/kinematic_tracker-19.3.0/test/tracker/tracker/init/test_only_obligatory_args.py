"""."""

import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.association.match_hungarian import MatchDriverHungarian
from kinematic_tracker.association.metric_mahalanobis import MetricMahalanobis
from kinematic_tracker.tracker.score_copy import StubScoreCopy


def test_no_measurement_orders() -> None:
    tracker = NdKkfTracker([3, 1], [3, 3])
    assert len(tracker.tracks_c) == 1
    assert tracker.tracks_c[0] == []
    assert isinstance(tracker.score_copy, StubScoreCopy)
    assert isinstance(tracker.metric_driver, MetricMahalanobis)
    assert isinstance(tracker.match_driver, MatchDriverHungarian)
    assert tracker.gen_xz.orders_z == pytest.approx([1, 1])
    assert tracker.gen_xz.gen_x.num_x == 12
    assert tracker.gen_xz.num_z == 6
    assert tracker.buf_rz.shape == (100, 6)

    assert tracker.match_driver.num_reports_max == 100
    assert tracker.match_driver.num_targets_max == 500
    assert tracker.metric_driver.num_reports_max == 100
    assert tracker.metric_driver.num_targets_max == 500
