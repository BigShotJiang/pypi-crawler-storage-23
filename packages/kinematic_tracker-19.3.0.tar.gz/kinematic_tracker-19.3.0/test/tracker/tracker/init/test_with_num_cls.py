"""."""

from kinematic_tracker import NdKkfTracker


def test_with_num_cls() -> None:
    tracker = NdKkfTracker([3, 1], [3, 3], num_cls=12)
    assert len(tracker.tracks_c) == 12
    for tracks in tracker.tracks_c:
        assert tracks == []
