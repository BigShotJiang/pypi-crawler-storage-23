"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker


def test_with_measurement_orders() -> None:
    tracker = NdKkfTracker([3, 1], [3, 3], [2, 1])
    assert tracker.cov_zz.shape == (9, 9)
    cov_zz_copy = tracker.cov_zz.copy()
    np.fill_diagonal(cov_zz_copy, 0.0)
    assert cov_zz_copy == pytest.approx(0.0)
    assert np.all(np.isnan(tracker.cov_zz.diagonal()))
    assert tracker.gen_xz.orders_z == pytest.approx([2, 1])
    assert tracker.gen_xz.gen_x.num_x == 12
    assert tracker.gen_xz.num_z == 9
