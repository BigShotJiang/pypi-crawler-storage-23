"""."""

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.tracker.score_copy import ScoreCopy


def test_with_return_score() -> None:
    tracker = NdKkfTracker([3, 1], [3, 3], return_score=True)
    assert isinstance(tracker.score_copy, ScoreCopy)
