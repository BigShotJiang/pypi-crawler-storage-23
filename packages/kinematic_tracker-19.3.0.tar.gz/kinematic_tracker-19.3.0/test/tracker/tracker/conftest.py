"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker


@pytest.fixture
def tracker() -> NdKkfTracker:
    """."""
    tracker = NdKkfTracker([3, 1], [3, 3])
    tracker.association.threshold = 0.56
    tracker.set_association_metric('mahalanobis', 0.22 * 6)
    tracker.set_association_method('greedy')
    tracker.num_det_min = 2
    return tracker


@pytest.fixture
def tracker1(tracker: NdKkfTracker) -> NdKkfTracker:
    """."""
    tracker.set_measurement_cov(0.01 * np.eye(6))
    r2z = np.linspace(1.0, 6.0, num=6).reshape(1, 6)
    r2id = np.array([123])
    tracker.advance(1234_000_000, r2z, r2id)
    return tracker


@pytest.fixture
def tc2() -> NdKkfTracker:
    tracker = NdKkfTracker([3, 1], [3, 3], num_cls=2)
    tracker.set_measurement_cov(0.25 * np.eye(6))
    r2z = np.linspace(1.0, 18.0, num=18).reshape(3, 6)
    r2id = np.array([123, 234, 345])
    tracker.advance(1234_000_000, r2z, r2id, cls_r=np.array([0, 1, 1]))
    return tracker
