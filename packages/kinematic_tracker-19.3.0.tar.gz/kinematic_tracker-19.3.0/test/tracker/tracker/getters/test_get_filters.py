"""."""

from kinematic_tracker import NdKkfTracker


def test_get_filters(tracker1: NdKkfTracker) -> None:
    filters = tracker1.get_kalman_filters(0)
    assert len(filters) == 1


def test_multi_class(tc2: NdKkfTracker) -> None:
    filters0 = tc2.get_kalman_filters(0)
    assert len(filters0) == 1

    filters1 = tc2.get_kalman_filters(1)
    assert len(filters1) == 2
