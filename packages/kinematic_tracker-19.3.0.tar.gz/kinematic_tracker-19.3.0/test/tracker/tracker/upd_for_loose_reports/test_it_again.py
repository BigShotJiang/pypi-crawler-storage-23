"""."""

import numpy as np

from kinematic_tracker import NdKkfTracker


def test_upd_for_loose_reports1(tracker1: NdKkfTracker) -> None:
    """."""
    o2z = (0.1 + np.linspace(1.0, 6.0, num=6)).reshape(1, 6)
    o2id = np.array([124])
    tracker1.upd_for_loose_reports(tracker1.tracks_c[0], np.zeros(1, int), o2z, o2id)
    assert len(tracker1.tracks_c[0]) == 1
    assert tracker1.tracks_c[0][0].ann_id == 123
