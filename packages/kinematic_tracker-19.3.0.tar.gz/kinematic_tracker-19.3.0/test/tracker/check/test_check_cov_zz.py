"""."""

import numpy as np
import pytest

from kinematic_tracker.tracker.check import check_cov_zz


def test_undefined_cov_zz() -> None:
    check_cov_zz(np.full((5, 5), 1.0))
    with pytest.raises(ValueError):
        check_cov_zz(np.full((5, 5), np.nan))
