import numpy as np
import pytest

from kinematic_tracker.tracker.check import check_ids_r


def test_when_sizes_are_wrong() -> None:
    ids_r = np.linspace(0, 3, 4, dtype=int)
    with pytest.raises(ValueError) as err_size:
        check_ids_r(ids_r, 5)
    assert err_size.value.args[0] == 'I expect 5 ids, but I see 4.'

    with pytest.raises(ValueError) as err_dim:
        check_ids_r(ids_r.reshape(1, 4), 4)
    assert err_dim.value.args[0] == 'I expect one-dimensional vector, but I see 2.'


def test_when_data_type_is_wrong() -> None:
    with pytest.raises(TypeError) as err_dtype:
        check_ids_r(np.ones(4), 4)
    assert err_dtype.value.args[0] == 'I expect integer ids, but I see float64.'


def test_when_type_is_wrong() -> None:
    with pytest.raises(TypeError) as err_dtype:
        check_ids_r([0], 4)
    assert err_dtype.value.args[0] == "I expect NumPy array, but I see <class 'list'>."


def test_everything_ok() -> None:
    ids_r = np.linspace(0, 3, 4, dtype=int)
    check_ids_r(ids_r, 4)
    assert True
