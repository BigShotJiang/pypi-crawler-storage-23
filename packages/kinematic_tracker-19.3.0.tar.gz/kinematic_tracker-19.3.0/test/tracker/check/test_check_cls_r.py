import numpy as np
import pytest

from kinematic_tracker.tracker.check import check_cls_r


def test_when_sizes_are_wrong() -> None:
    cls_r = np.linspace(0, 3, 4, dtype=int)
    with pytest.raises(ValueError) as err_size:
        check_cls_r(cls_r, 5, 4)
    assert err_size.value.args[0] == 'Number of reports should be 5, but got 4.'

    with pytest.raises(ValueError) as err_max:
        check_cls_r(cls_r, 4, 3)
    assert err_max.value.args[0] == 'Class IDs should be less than 3, but I see 3.'


def test_when_negative_classes() -> None:
    cls_r = np.linspace(-4, 3, 8, dtype=int)
    with pytest.raises(ValueError) as err:
        check_cls_r(cls_r, 8, 4)
    assert err.value.args[0] == 'Class IDs should be greater or equal zero, but I see -4.'
