"""."""

import numpy as np
import pytest

from kinematic_tracker.tracker.check import check_det_rz


def test_is_np() -> None:
    with pytest.raises(TypeError) as err:
        check_det_rz([[]], 6)
    assert err.value.args[0] == "Expected (two-dimensional) NumPy array, got <class 'list'>"


def test_is_2d() -> None:
    with pytest.raises(ValueError) as err:
        check_det_rz(np.zeros(1), 6)

    assert err.value.args[0] == 'Expected two-dimensional NumPy array, got 1'


def test_is_num_z_ok() -> None:
    with pytest.raises(ValueError) as err:
        check_det_rz(np.zeros((1, 5)), 6)

    assert err.value.args[0] == 'Wrong size of the measurement vector 5. Expected 6'
