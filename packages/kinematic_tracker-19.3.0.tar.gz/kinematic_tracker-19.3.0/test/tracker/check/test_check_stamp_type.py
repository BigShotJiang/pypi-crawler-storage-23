"""."""

import pytest

from kinematic_tracker.tracker.check import check_stamp_type


def test_it() -> None:
    with pytest.raises(TypeError):
        check_stamp_type(1.0)
