"""."""

import numpy as np
import pytest

from kinematic_tracker.tracker.score_copy import ScoreCopy


class Holder:
    def __init__(self) -> None:
        self.cls = -1

    def get_creation_ids_t(self, cls: int) -> np.ndarray:
        self.cls = cls
        return np.linspace(1, 3, 3, dtype=int)


def test_set() -> None:
    sp = ScoreCopy(1)
    score_rt = np.linspace(1, 6, 6).reshape(2, 3)
    holder = Holder()
    sp.set(0, holder.get_creation_ids_t, score_rt)
    assert sp.score_crt[0] == pytest.approx(score_rt)
    assert sp.creation_ids_ct[0] == pytest.approx(holder.get_creation_ids_t(0))
    assert id(sp.score_crt[0]) != id(score_rt)
