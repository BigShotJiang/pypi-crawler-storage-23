"""."""

from kinematic_tracker.tracker.score_copy import ScoreCopy, StubScoreCopy, get_score_copy


def test_get_score_copy() -> None:
    assert isinstance(get_score_copy(False, 1), StubScoreCopy)
    assert isinstance(get_score_copy(True, 1), ScoreCopy)
