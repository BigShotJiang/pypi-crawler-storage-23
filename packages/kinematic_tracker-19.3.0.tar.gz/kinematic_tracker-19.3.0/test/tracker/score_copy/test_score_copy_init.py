"""."""

from kinematic_tracker.tracker.score_copy import ScoreCopy


def test_init() -> None:
    sp = ScoreCopy(1)
    assert sp.score_crt[0] is None
    assert sp.creation_ids_ct[0] is None
    assert sp.creation_ids_ct.ndim == 1
    assert sp.creation_ids_ct.shape[0] == 1
    assert sp.score_crt.ndim == 1
    assert sp.score_crt.shape[0] == 1
