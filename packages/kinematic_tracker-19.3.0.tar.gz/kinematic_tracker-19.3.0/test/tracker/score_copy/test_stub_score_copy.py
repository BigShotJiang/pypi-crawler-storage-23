"""."""

import numpy as np
import pytest

from kinematic_tracker.tracker.score_copy import StubScoreCopy


@pytest.fixture
def ssp() -> StubScoreCopy:
    return StubScoreCopy()


def test_init(ssp: StubScoreCopy) -> None:
    assert vars(ssp) == {}


def test_set(ssp: StubScoreCopy) -> None:
    ssp.set(1, lambda c: np.zeros(1, dtype=int), np.ones((1, 1)))
    assert vars(ssp) == {}


def test_deep_copy(ssp: StubScoreCopy) -> None:
    assert ssp.deep_copy() == ssp


def test_repr(ssp: StubScoreCopy) -> None:
    assert repr(ssp) == 'Stub for the ScoreCopy. NdKkfTracker(..., return_score=True) maybe?'
