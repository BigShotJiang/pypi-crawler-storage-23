"""."""

import numpy as np
import pytest

from kinematic_tracker.tracker.score_copy import ScoreCopy


def test_deep_copy() -> None:
    sp = ScoreCopy(1)
    sp.score_crt[0] = np.linspace(1, 6, 6).reshape(2, 3)
    sp.creation_ids_ct[0] = np.linspace(1, 3, 3, dtype=int)
    sp_cp = sp.deep_copy()
    assert isinstance(sp_cp, ScoreCopy)
    assert id(sp_cp) != id(sp)
    assert sp_cp.score_crt[0] == pytest.approx(sp.score_crt[0])
    assert sp_cp.creation_ids_ct[0] == pytest.approx(sp.creation_ids_ct[0])
    assert id(sp_cp.score_crt[0]) != id(sp.score_crt[0])
    assert id(sp_cp.creation_ids_ct[0]) != id(sp.creation_ids_ct[0])
