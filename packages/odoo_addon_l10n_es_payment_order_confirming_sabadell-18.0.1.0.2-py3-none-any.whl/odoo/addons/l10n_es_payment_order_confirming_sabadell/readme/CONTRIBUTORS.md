- Rubén Francés - Soluntec Proyectos y Soluciones TIC

- Nacho Torró - Soluntec Proyectos y Soluciones TIC

- César Fernández Domínguez

- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Víctor Martínez
  > - Carolina Fernandez
