Antes de generar un fichero bancario de Confirming, hay que definir un
modo de pago que use el tipo de pago "Confirming Sabadell". Para ello,
vaya a Contabilidad \> Configuración \> Varios \> Modos de pago, y
escoja el tipo de pago a realizar (Transferencia, cheque o Transferencia
extranjero).

Seleccione el tipo de envío información al Proveedor.

El nº de contrato de deberá ser configurado al crear el modo de pago.

Si es una Transferencia extranjero se debe de establecer el Código
Estadístico para Transferencia Internacional (6 carácteres) y la cuenta
bancaria del Proveedor debe ser con formato IBAN.

Nota: La exportación de fichero esta establecido a un código de divisa
fijo en Euros.
