import{w as s}from"./svelte-AtwXdSxM.js";const o=s(null);export{o as s};
