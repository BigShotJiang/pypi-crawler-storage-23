from user_scanner.core.helpers import get_random_user_agent
from user_scanner.core.orchestrator import generic_validate
from user_scanner.core.result import Result


def validate_hashnode(user):
    url = "https://hashnode.com/utility/ajax/check-username"
    show_url = "https://hashnode.com"

    payload = {"username": user, "name": "Dummy Dummy"}

    headers = {
        "User-Agent": get_random_user_agent(),
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": "https://hashnode.com",
        "Referer": "https://hashnode.com/signup",
    }

    def process(response):
        if response.status_code == 200:
            data = response.json()

            if "status" in data:
                if data["status"] == 1:
                    return Result.available()
                elif data["status"] == 0:
                    return Result.taken()

            return Result.error("Status not found")

        else:
            return Result.error("Invalid status code")

    return generic_validate(
        url,
        process,
        show_url=show_url,
        method="POST",
        json=payload,
        headers=headers,
        timeout=3.0,
    )
