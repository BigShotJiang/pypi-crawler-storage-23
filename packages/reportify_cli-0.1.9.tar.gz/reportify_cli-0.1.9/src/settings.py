"""Settings and configuration for Reportify API CLI."""

import os
import sys

# Try to load .env file if python-dotenv is available
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    # python-dotenv not installed, skip loading .env file
    pass


def get_api_key() -> str:
    """Get API key from environment variable.

    Returns:
        str: API key

    Raises:
        SystemExit: If API key is not found
    """
    api_key = os.getenv("REPORTIFY_API_KEY")
    if not api_key:
        print("Error: REPORTIFY_API_KEY environment variable is not set.", file=sys.stderr)
        print("Please set it with: export REPORTIFY_API_KEY='your-api-key'", file=sys.stderr)
        sys.exit(1)
    return api_key
