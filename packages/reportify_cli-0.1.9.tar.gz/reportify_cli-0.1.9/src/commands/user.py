"""User module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="User data", rich_markup_mode="rich")


@app.command(
    name="followed_companies",
    epilog=generate_epilog(
        params.USER_FOLLOWED_COMPANIES_PARAMS, ["reportify-cli user followed_companies"]
    ),
)
def followed_companies(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get all followed companies"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.user.followed_companies(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="follow_company",
    epilog=generate_epilog(
        params.USER_FOLLOW_COMPANY_PARAMS,
        [
            'reportify-cli user follow_company --input \'{"symbol": "US:AAPL"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "HK:00700"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "SH:600519"}\'',
            'reportify-cli user follow_company --input \'{"symbol": "SZ:000001"}\'',

        ],
    ),
)
def follow_company(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Follow a company (add to watchlist)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        symbol = params_dict.get("symbol")
        if not symbol:
            raise ValueError("symbol is required")
        result = client.user.follow_company(symbol)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="unfollow_company",
    epilog=generate_epilog(
        params.USER_UNFOLLOW_COMPANY_PARAMS,
        [
            'reportify-cli user unfollow_company --input \'{"symbol": "US:AAPL"}\'',
            'reportify-cli user unfollow_company --input \'{"symbol": "HK:00700"}\'',
        ],
    ),
)
def unfollow_company(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Unfollow a company (remove from watchlist)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        symbol = params_dict.get("symbol")
        if not symbol:
            raise ValueError("symbol is required")
        result = client.user.unfollow_company(symbol)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="create_follow_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user create_follow_group --input \'{"name": "My Stocks", "follow_values": [{"follow_type": 1, "follow_value": "US:AAPL"}]}\'',
        ],
    ),
)
def create_follow_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Create a follow group"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        name = params_dict.get("name")
        if not name:
            raise ValueError("name is required")
        follow_values = params_dict.get("follow_values", [])
        result = client.user.create_follow_group(name, follow_values)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_follow_groups",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user get_follow_groups',
        ],
    ),
)
def get_follow_groups(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get all follow groups"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.user.get_follow_groups()
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_follow_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user get_follow_group --input \'{"group_id": "123"}\'',
        ],
    ),
)
def get_follow_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get a follow group by ID (includes follow_values with follow_type and follow_value)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        result = client.user.get_follow_group(group_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="update_follow_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user update_follow_group --input \'{"group_id": "123", "name": "New Name"}\'',
        ],
    ),
)
def update_follow_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Update a follow group"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        name = params_dict.get("name")
        result = client.user.update_follow_group(group_id, name)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="delete_follow_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user delete_follow_group --input \'{"group_id": "123"}\'',
        ],
    ),
)
def delete_follow_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Delete a follow group"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        result = client.user.delete_follow_group(group_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="add_follows_to_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user add_follows_to_group --input \'{"group_id": "123", "follow_values": [{"follow_type": 1, "follow_value": "US:TSLA"}]}\'',
        ],
    ),
)
def add_follows_to_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Add follows to a group"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        follow_values = params_dict.get("follow_values", [])
        result = client.user.add_follows_to_group(group_id, follow_values)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="remove_follows_from_group",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user remove_follows_from_group --input \'{"group_id": "123", "follow_values": ["AAPL", "MSFT"]}\'',
        ],
    ),
)
def remove_follows_from_group(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Remove follows from a group by follow_values (e.g., stock symbols, channel IDs)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        follow_values = params_dict.get("follow_values", [])
        result = client.user.remove_follows_from_group(group_id, follow_values)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="set_group_follows",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user set_group_follows --input \'{"group_id": "123", "follow_values": [{"follow_type": 1, "follow_value": "US:AAPL"}]}\'',
        ],
    ),
)
def set_group_follows(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Set follows for a group (replace all)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        follow_values = params_dict.get("follow_values", [])
        result = client.user.set_group_follows(group_id, follow_values)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_follow_group_reports",
    epilog=generate_epilog(
        {},
        [
            'reportify-cli user get_follow_group_reports --input \'{"group_id": "123", "page_num": 1, "page_size": 20}\'',
        ],
    ),
)
def get_follow_group_reports(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get reports for a follow group"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        group_id = params_dict.get("group_id")
        if not group_id:
            raise ValueError("group_id is required")
        page_num = params_dict.get("page_num", 1)
        page_size = params_dict.get("page_size", 10)
        result = client.user.get_follow_group_reports(group_id, page_num, page_size)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
