# Publishing Guide

## Prerequisites

1. **PyPI Account**: Accounts on both [Test PyPI](https://test.pypi.org/) and [PyPI](https://pypi.org/)
2. **API Tokens**: Generate API tokens from your PyPI account settings
3. **UV**: The project uses `uv` for package management and publishing
4. **Git**: Clean git working directory

## API Token Setup

Set environment variable (recommended):

```bash
export UV_PUBLISH_TOKEN="pypi-YOUR_TOKEN_HERE"
```

Or use `~/.pypirc`:

```bash
cp .pypirc.example ~/.pypirc
# Edit ~/.pypirc with your tokens
```

## Scripts

### `bump_version.sh`

Bumps the version number in `pyproject.toml`.

```bash
./scripts/bump_version.sh [major|minor|patch]
```

Or use Makefile shortcuts:

```bash
make bump-patch   # 0.1.0 -> 0.1.1
make bump-minor   # 0.1.0 -> 0.2.0
make bump-major   # 0.1.0 -> 1.0.0
```

The script will:
1. Read current version from `pyproject.toml`
2. Increment version based on type
3. Update `pyproject.toml`
4. Show git diff
5. Optionally commit and push

### `publish.sh`

Publishes the package to PyPI.

```bash
./scripts/publish.sh [test|prod] [dry-run]
```

Or use Makefile shortcuts:

```bash
make publish-dry-run  # Dry run
make publish-test     # Publish to Test PyPI
make publish-prod     # Publish to Production PyPI
```

The script will:
1. Check for uncommitted changes
2. Run tests
3. Run linter
4. Clean previous builds
5. Build package
6. Check build artifacts
7. Publish to PyPI
8. Create git tag
9. Optionally push tag to remote

## Workflow

```bash
# 1. Commit your code changes
git add . && git commit -m "feat: your changes"

# 2. Bump version
make bump-patch

# 3. Dry run
make publish-dry-run

# 4. Publish to Test PyPI
make publish-test

# 5. Test installation
pip install -i https://test.pypi.org/simple/ reportify-cli

# 6. Publish to Production PyPI
make publish-prod
```

## Version Numbering

Follow [Semantic Versioning](https://semver.org/):

- **MAJOR** (X.0.0): Breaking changes
- **MINOR** (0.X.0): New features, backwards compatible
- **PATCH** (0.0.X): Bug fixes

## Troubleshooting

### "File already exists" error

Bump the version before publishing again:

```bash
make bump-patch
```

### Authentication failed

```bash
echo $UV_PUBLISH_TOKEN
```

### Tests failing

```bash
make test
```

### Linter issues

```bash
make fix
make lint
```

## Checklist

- [ ] All tests pass (`make test`)
- [ ] Linter is clean (`make lint`)
- [ ] Version is bumped (`make bump-*`)
- [ ] Changes are committed
- [ ] Tested on Test PyPI (`make publish-test`)
- [ ] Installation from Test PyPI works
