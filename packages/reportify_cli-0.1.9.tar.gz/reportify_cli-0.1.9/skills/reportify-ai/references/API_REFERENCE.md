# Reportify API Reference

## Common Parameters

### Symbol Format
Stock symbols must use `market:ticker` format:
- **Shanghai Exchange**: `SH:ticker` (e.g., `SH:600519` for Kweichow Moutai)
- **Shenzhen Exchange**: `SZ:ticker` (e.g., `SZ:000001` for Ping An Bank)
- **Hong Kong**: `HK:ticker` (e.g., `HK:00700` for Tencent)
- **US Market**: `US:ticker` (e.g., `US:AAPL` for Apple, `US:TSLA` for Tesla)

### Date/Time Format
- **Date**: `YYYY-MM-DD` (e.g., `2024-01-15`)
- **DateTime**: `YYYY-MM-DD HH:MM:SS` (e.g., `2024-01-15 09:30:00`)

### Output Formats
- `json` - JSON (default)
- `table` - Formatted table
- `csv` - CSV format
- `markdown` / `md` - Markdown table

---

## Search Module Parameters

### search query
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✓ | - | Search keywords |
| `num` | int | | 10 | Results count (max 100) |
| `categories` | list[str] | | - | Filter: news, reports, filings, transcripts, socials |
| `symbols` | list[str] | | - | Stock symbols in market:ticker format (e.g., US:AAPL, HK:00700) |
| `industries` | list[str] | | - | Industry filter |
| `channel_ids` | list[str] | | - | Channel ID filter |
| `start_datetime` | str | | - | Start time |
| `end_datetime` | str | | - | End time |

### search filings / conference_calls / earnings_pack
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | | - | Search keywords (optional, if not provided returns documents sorted by date desc; if provided, sorts by relevance) |
| `symbols` | list[str] | ✓ | - | Stock symbols in market:ticker format (required) |
| `num` | int | | 10 | Results count |
| `fiscal_year` | str | | - | Fiscal year (e.g., "2025") |
| `fiscal_quarter` | str | | - | Fiscal quarter (Q1-Q4) |

### search crawl
| Parameter | Type | Required | Default | Description                                                                 |
|-----------|------|----------|---------|-----------------------------------------------------------------------------|
| `urls` | list[str] | ✓ | - | List of URLs to crawl                                                       |
| `text` | bool/dict | | true | Extract full text content(set true), or pass dict for advanced options |
| `text.max_characters` | int | | - | Maximum characters to return per page                                       |
| `text.include_html_tags` | bool | | false | Whether to preserve HTML tags                                               |
| `text.verbosity` | string | | "full" | `compact` (removes boilerplate) or `full` (complete content)                |
| `highlights` | dict | | - | Extract query-relevant highlights                                           |
| `highlights.query` | string | | - | Query for extracting relevant highlights                                    |
| `highlights.max_characters` | int | | - | Max characters per highlight                                                |
| `highlights.num_sentences` | int | | 5 | Number of sentences per highlight                                           |
| `highlights.highlights_per_url` | int | | 1 | Number of highlights per URL                                                |
| `summary` | dict | | - | LLM-generated summary                                                       |
| `summary.query` | string | | - | Query instruction for summary                                               |
| `subpages` | int | | - | Max subpages to crawl per URL                                               |
| `subpage_target` | list[str] | | - | Keywords to prioritize when selecting subpages                              |
| `max_age_hours` | int | | - | Max age of cached content in hours                                          |
| `livecrawl_timeout` | int | | - | Timeout in ms for live crawling fallback                                    |

---

## Stock Module Parameters

### stock income_statement / balance_sheet / cashflow_statement
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | string | ✓ | - | Stock symbol |
| `period` | string | | annual | annual / quarterly |
| `limit` | int | | 8 | Number of periods |
| `start_date` | str | | - | Start date |
| `end_date` | str | | - | End date |
| `calendar` | str | | fiscal | calendar / fiscal |
| `fiscal_year` | str | | - | Specific fiscal year |
| `fiscal_quarter` | str | | - | Q1, Q2, Q3, Q4, FY, H1 |

---

## Quant Module Parameters

### quant indicators_compute / factors_compute
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbols` | list[str] | ✓ | - | Stock codes (e.g., 600519 for CN market) |
| `formula` | str | ✓ | - | Formula expression. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | cn / hk / us |
| `start_date` | str | | 3 months ago | Start date |
| `end_date` | str | | today | End date |

### quant backtest
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | str | ✓ | - | Stock symbol |
| `start_date` | str | ✓ | - | Backtest start |
| `end_date` | str | ✓ | - | Backtest end |
| `entry_formula` | str | ✓ | - | Entry signal formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `exit_formula` | str | | - | Exit signal formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | Market |
| `initial_cash` | float | | 100000 | Initial capital |
| `commission` | float | | 0 | Commission rate |
| `stop_loss` | float | | 0 | Stop loss % (0=disabled) |
| `sizer_percent` | int | | 99 | Position size % |

### quant factors_screen
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `formula` | str | ✓ | - | Screening formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | Market |
| `check_date` | str | | latest | Check date |
| `symbols` | list[str] | | - | Stock codes pool (None=all market) |

---

## KB Module Parameters

### kb search
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✓ | - | Search keywords |
| `folder_ids` | list[str] | | - | Folder IDs |
| `doc_ids` | list[str] | | - | Document IDs |
| `start_date` | str | | - | Start date |
| `end_date` | str | | - | End date |
| `num` | int | | 10 | Results count |

---

## User Module Parameters

### user follow_company / unfollow_company
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | string | ✓ | - | Stock symbol, format: market:ticker (e.g. US:AAPL, HK:00700, SH:600519) |
