# Reportify API CLI Commands Reference

## Search Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `query` | Search all document types | `query` |
| `news` | Search news articles | `query` |
| `reports` | Search research reports | `query` |
| `filings` | Search company filings | `symbols` |
| `conference_calls` | Search earnings conference call transcripts | `symbols` |
| `earnings_pack` | Search earnings-related exchange filings | `symbols` |
| `minutes` | Search conference calls and IR meetings | `query` |
| `socials` | Search social media posts | `query` |
| `webpages` | Search web pages | `query` |
| `crawl` | Crawl web content from URLs | `urls` |

## Docs Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `get` | Get document details | `doc_id` |
| `summary` | Get document summary | `doc_id` |
| `list_by_symbols` | List documents by stock symbol | `symbol` |
| `raw_content` | Get document raw content | `doc_id` |
| `list` | List documents with filters | (optional) |
| `search` | Search documents (v1) | `query` |
| `search_chunks` | Search document chunks | `query` |
| `create_folder` | Create folder | `name` |
| `delete_folder` | Delete folder and all its files | `folder_id` |
| `upload` | Upload documents | `folder_id`, `file_paths` |
| `upload_async` | Upload documents asynchronously | `folder_id`, `file_paths` |
| `get_upload_status` | Get document upload status | `task_id` |
| `delete` | Delete documents | `doc_ids` |

## Stock Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `overview` | Company overview | `symbols` or `names` |
| `shareholders` | Shareholder information | `symbol` |
| `income_statement` | Income statement | `symbol` |
| `balance_sheet` | Balance sheet | `symbol` |
| `cashflow_statement` | Cash flow statement | `symbol` |
| `revenue_breakdown` | Revenue breakdown | `symbol` |
| `quote` | Real-time quote | `symbol` |
| `index_constituents` | Index constituents | `symbol` |
| `index_tracking_funds` | Index tracking funds | `symbol` |
| `industry_constituents` | Industry constituents | `market`, `name` |
| `earnings_calendar` | Earnings calendar | `market` |
| `ipo_calendar_hk` | HK IPO calendar | (optional) |
| `index_quote` | Index quote data | `symbol` |

## Timeline Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `companies` | Company timeline | (optional) |
| `topics` | Topic timeline | (optional) |
| `institutes` | Institute timeline | (optional) |
| `public_media` | Public media timeline | (optional) |
| `social_media` | Social media timeline | (optional) |

## Channels Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search channels | `query` |
| `followings` | List followed channels | (optional) |
| `follow` | Follow a channel | `channel_id` |
| `unfollow` | Unfollow a channel | `channel_id` |
| `get_docs` | Get documents from followed channels | (optional) |

## KB Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search knowledge base | `query` |

## User Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `followed_companies` | Get followed companies | (none) |
| `follow_company` | Follow a company (add to watchlist) | `symbol` |
| `unfollow_company` | Unfollow a company (remove from watchlist) | `symbol` |

## Quant Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `indicators` | List available indicators | (none) |
| `indicators_compute` | Compute technical indicators | `symbols`, `formula` |
| `factors` | List available factors | (none) |
| `factors_compute` | Compute factors | `symbols`, `formula` |
| `factors_screen` | Stock screening | `formula` |
| `ohlcv` | Get OHLCV data | `symbol` |
| `ohlcv_batch` | Batch OHLCV data | `symbols` |
| `backtest` | Run backtest | `symbol`, `start_date`, `end_date`, `entry_formula` |

## Concepts Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `latest` | Latest concept dynamics | (optional) |
| `today` | Today's concepts | (none) |

