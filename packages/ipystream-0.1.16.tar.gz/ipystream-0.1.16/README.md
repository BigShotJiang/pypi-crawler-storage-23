# ipystream

Easy interactive Jupyter dashboards, flowing top to bottom like a stream

`python -m pytest`

`poetry run black .`

`poetry publish --build`

To see poetry-repository-pypi token, in terminal run: `seahorse`