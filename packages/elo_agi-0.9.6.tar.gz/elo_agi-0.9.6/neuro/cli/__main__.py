"""Entry point for python -m neuro.cli"""

from .main import main

if __name__ == "__main__":
    main()
