"""Skills system."""

from .loader import SkillsLoader, Skill

__all__ = ["SkillsLoader", "Skill"]
