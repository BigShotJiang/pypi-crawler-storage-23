"""CLI slash commands."""
