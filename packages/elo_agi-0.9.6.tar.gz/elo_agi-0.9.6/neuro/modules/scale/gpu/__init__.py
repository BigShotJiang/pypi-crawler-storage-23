# GPU acceleration components
