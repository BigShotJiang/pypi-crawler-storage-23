# Sensor components for real-world input
