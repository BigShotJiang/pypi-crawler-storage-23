# Actuator components for real-world output
