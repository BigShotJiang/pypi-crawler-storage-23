"""Neuro AGI Applications."""

from neuro.apps.research_assistant import ResearchAssistant

__all__ = ["ResearchAssistant"]
