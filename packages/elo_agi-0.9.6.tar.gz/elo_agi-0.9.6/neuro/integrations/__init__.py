"""
NEURO Integrations — adapters for third-party frameworks.

Available integrations:
    langchain   LangChain-compatible LLM wrapper (NeuroCognitiveLLM)
"""

__all__ = ["langchain"]
