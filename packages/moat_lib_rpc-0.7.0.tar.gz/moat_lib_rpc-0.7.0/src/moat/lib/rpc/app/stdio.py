"""
Console stdio access
"""

from __future__ import annotations

from moat.lib.micro import AC_use
from moat.lib.rpc.cmd.msg import BaseCmdMsg
from moat.lib.stream import FilenoBuf, serial_stack


class StdIO(BaseCmdMsg):
    """Sends/receives MoaT messages using stdin/stdout"""

    doc = dict(_c=dict(_d="link via stdandard i/o"))

    async def stream(self):  # noqa:D102
        cs = FilenoBuf(self.cfg, 0, 1)
        return await AC_use(self, serial_stack(cs, self.cfg))
