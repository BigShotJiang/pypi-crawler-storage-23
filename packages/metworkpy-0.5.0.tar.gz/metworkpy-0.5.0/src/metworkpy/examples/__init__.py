__all__ = ["get_example_model"]

from .example_model import get_example_model
