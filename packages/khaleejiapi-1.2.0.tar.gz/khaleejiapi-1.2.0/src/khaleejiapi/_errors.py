"""Exception classes for the KhaleejiAPI SDK."""

from __future__ import annotations


class KhaleejiAPIError(Exception):
    """Base exception for all KhaleejiAPI errors."""

    code: str
    message: str
    status_code: int
    retry_after: int | None

    def __init__(
        self,
        message: str,
        *,
        code: str = "UNKNOWN_ERROR",
        status_code: int = 0,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retry_after = retry_after

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(code={self.code!r}, "
            f"message={self.message!r}, status_code={self.status_code})"
        )


class AuthenticationError(KhaleejiAPIError):
    """Raised when an API key is missing or invalid (HTTP 401)."""


class ForbiddenError(KhaleejiAPIError):
    """Raised when the API key lacks the required scope (HTTP 403)."""


class ValidationError(KhaleejiAPIError):
    """Raised when request parameters are invalid (HTTP 400)."""


class NotFoundError(KhaleejiAPIError):
    """Raised when a requested resource is not found (HTTP 404)."""


class RateLimitError(KhaleejiAPIError):
    """Raised when the rate limit has been exceeded (HTTP 429)."""


class ConflictError(KhaleejiAPIError):
    """Raised when there is a resource conflict (HTTP 409)."""


class ServerError(KhaleejiAPIError):
    """Raised when the API returns an internal server error (HTTP 5xx)."""


_STATUS_TO_EXCEPTION: dict[int, type[KhaleejiAPIError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    429: RateLimitError,
}


def _error_from_response(
    status_code: int,
    code: str,
    message: str,
    retry_after: int | None = None,
) -> KhaleejiAPIError:
    """Create the appropriate exception from an HTTP status code."""
    if status_code >= 500:
        cls = ServerError
    else:
        cls = _STATUS_TO_EXCEPTION.get(status_code, KhaleejiAPIError)
    return cls(
        message,
        code=code,
        status_code=status_code,
        retry_after=retry_after,
    )
