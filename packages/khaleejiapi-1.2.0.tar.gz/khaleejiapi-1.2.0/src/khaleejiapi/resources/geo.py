"""Geo / location API resources."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import GeocodeResult, IpLookupResult, TimezoneResult, WeatherResult


class GeoResource:
    """Synchronous geolocation endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def lookup_ip(self, ip: Optional[str] = None) -> IpLookupResult:
        """Look up geolocation data for an IP address.

        Args:
            ip: IPv4 or IPv6 address. Omit to look up the caller's IP.

        Returns:
            Location, ISP, and connection information.
        """
        params: Dict[str, Any] = {}
        if ip is not None:
            params["ip"] = ip
        return self._client.get("/v1/ip/lookup", params=params)  # type: ignore[return-value]

    def get_timezone(
        self,
        location: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
    ) -> TimezoneResult:
        """Get timezone information by location name or coordinates.

        Args:
            location: City or region name (e.g. ``"Dubai"``).
            lat: Latitude (used together with *lon*).
            lon: Longitude (used together with *lat*).

        Returns:
            Timezone name, UTC offset, DST status, and local time.
        """
        params: Dict[str, Any] = {}
        if location is not None:
            params["location"] = location
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lon"] = lon
        return self._client.get("/v1/timezone", params=params)  # type: ignore[return-value]

    def geocode(
        self,
        address: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        country: Optional[str] = None,
        lang: Optional[str] = None,
    ) -> GeocodeResult:
        """Forward or reverse geocode an address/coordinates.

        Powered by OpenStreetMap Nominatim with MENA-focused Arabic enrichment.

        Args:
            address: Query string for forward geocoding (e.g. ``"Burj Khalifa, Dubai"``).
            lat: Latitude for reverse geocoding.
            lon: Longitude for reverse geocoding.
            country: ISO-3166-1 alpha-2 country code filter.
            lang: Language preference (``"en"`` or ``"ar"``).

        Returns:
            List of geocode results with Arabic names, addresses, and coordinates.
        """
        params: Dict[str, Any] = {}
        if address is not None:
            params["q"] = address
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lng"] = lon
        if country is not None:
            params["country"] = country
        if lang is not None:
            params["lang"] = lang
        return self._client.get("/v1/geocode", params=params)  # type: ignore[return-value]

    def get_weather(
        self,
        city: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
    ) -> WeatherResult:
        """Get current weather (and forecast) for a city or coordinates.

        Args:
            city: City name (e.g. ``"Dubai"``).
            lat: Latitude.
            lon: Longitude.

        Returns:
            Current conditions, temperature, humidity, etc.
        """
        params: Dict[str, Any] = {}
        if city is not None:
            params["city"] = city
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lon"] = lon
        return self._client.get("/v1/weather", params=params)  # type: ignore[return-value]


class AsyncGeoResource:
    """Asynchronous geolocation endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def lookup_ip(self, ip: Optional[str] = None) -> IpLookupResult:
        """Look up geolocation data for an IP address.

        Args:
            ip: IPv4 or IPv6 address. Omit to look up the caller's IP.

        Returns:
            Location, ISP, and connection information.
        """
        params: Dict[str, Any] = {}
        if ip is not None:
            params["ip"] = ip
        return await self._client.get("/v1/ip/lookup", params=params)  # type: ignore[return-value]

    async def get_timezone(
        self,
        location: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
    ) -> TimezoneResult:
        """Get timezone information by location name or coordinates.

        Args:
            location: City or region name (e.g. ``"Dubai"``).
            lat: Latitude (used together with *lon*).
            lon: Longitude (used together with *lat*).

        Returns:
            Timezone name, UTC offset, DST status, and local time.
        """
        params: Dict[str, Any] = {}
        if location is not None:
            params["location"] = location
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lon"] = lon
        return await self._client.get("/v1/timezone", params=params)  # type: ignore[return-value]

    async def geocode(
        self,
        address: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        country: Optional[str] = None,
        lang: Optional[str] = None,
    ) -> GeocodeResult:
        """Forward or reverse geocode an address/coordinates.

        Powered by OpenStreetMap Nominatim with MENA-focused Arabic enrichment.

        Args:
            address: Query string for forward geocoding (e.g. ``"Burj Khalifa, Dubai"``).
            lat: Latitude for reverse geocoding.
            lon: Longitude for reverse geocoding.
            country: ISO-3166-1 alpha-2 country code filter.
            lang: Language preference (``"en"`` or ``"ar"``).

        Returns:
            List of geocode results with Arabic names, addresses, and coordinates.
        """
        params: Dict[str, Any] = {}
        if address is not None:
            params["q"] = address
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lng"] = lon
        if country is not None:
            params["country"] = country
        if lang is not None:
            params["lang"] = lang
        return await self._client.get("/v1/geocode", params=params)  # type: ignore[return-value]

    async def get_weather(
        self,
        city: Optional[str] = None,
        *,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
    ) -> WeatherResult:
        """Get current weather (and forecast) for a city or coordinates.

        Args:
            city: City name (e.g. ``"Dubai"``).
            lat: Latitude.
            lon: Longitude.

        Returns:
            Current conditions, temperature, humidity, etc.
        """
        params: Dict[str, Any] = {}
        if city is not None:
            params["city"] = city
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lon"] = lon
        return await self._client.get("/v1/weather", params=params)  # type: ignore[return-value]
