"""Communication API resources (translation, URL shortener)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import AITranslationResult, TranslationResult, UrlShortenResult


class CommunicationResource:
    """Synchronous communication endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def translate(
        self,
        text: str,
        target: Optional[str] = None,
        source: Optional[str] = None,
    ) -> TranslationResult:
        """Translate text with Arabic and regional language support.

        Args:
            text: The text to translate.
            target: Target language code (e.g. ``"ar"``). If omitted the API
                auto-detects and translates to the other language.
            source: Source language code. Auto-detected if omitted.

        Returns:
            Translated text with detected language info.
        """
        params: Dict[str, Any] = {"text": text}
        if target is not None:
            params["to"] = target
        if source is not None:
            params["from"] = source
        return self._client.get("/v1/translate", params=params)  # type: ignore[return-value]

    def shorten_url(
        self,
        url: str,
        custom_alias: Optional[str] = None,
    ) -> UrlShortenResult:
        """Create a shortened URL.

        Args:
            url: The long URL to shorten.
            custom_alias: Optional custom short code.

        Returns:
            Short URL, code, and expiry info.
        """
        body: Dict[str, Any] = {"url": url}
        if custom_alias is not None:
            body["code"] = custom_alias
        return self._client.post("/v1/url/shorten", json=body)  # type: ignore[return-value]

    def translate_ai(
        self,
        text: str,
        *,
        target: Optional[str] = None,
        source: Optional[str] = None,
        formality: Optional[str] = None,
    ) -> AITranslationResult:
        """AI-powered translation using Google Gemini. Supports 22+ languages.

        Args:
            text: Text to translate (max 5,000 characters).
            target: Target language code (default ``"ar"``).
            source: Source language code (auto-detected if omitted).
            formality: ``"formal"`` or ``"informal"`` (default ``"formal"``).

        Returns:
            AI translation with confidence, transliteration, and caching info.
        """
        body: Dict[str, Any] = {"text": text}
        if target is not None:
            body["target"] = target
        if source is not None:
            body["source"] = source
        if formality is not None:
            body["formality"] = formality
        return self._client.post("/v1/translate", json=body)  # type: ignore[return-value]


class AsyncCommunicationResource:
    """Asynchronous communication endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def translate(
        self,
        text: str,
        target: Optional[str] = None,
        source: Optional[str] = None,
    ) -> TranslationResult:
        """Translate text with Arabic and regional language support.

        Args:
            text: The text to translate.
            target: Target language code (e.g. ``"ar"``). If omitted the API
                auto-detects and translates to the other language.
            source: Source language code. Auto-detected if omitted.

        Returns:
            Translated text with detected language info.
        """
        params: Dict[str, Any] = {"text": text}
        if target is not None:
            params["to"] = target
        if source is not None:
            params["from"] = source
        return await self._client.get("/v1/translate", params=params)  # type: ignore[return-value]

    async def shorten_url(
        self,
        url: str,
        custom_alias: Optional[str] = None,
    ) -> UrlShortenResult:
        """Create a shortened URL.

        Args:
            url: The long URL to shorten.
            custom_alias: Optional custom short code.

        Returns:
            Short URL, code, and expiry info.
        """
        body: Dict[str, Any] = {"url": url}
        if custom_alias is not None:
            body["code"] = custom_alias
        return await self._client.post("/v1/url/shorten", json=body)  # type: ignore[return-value]

    async def translate_ai(
        self,
        text: str,
        *,
        target: Optional[str] = None,
        source: Optional[str] = None,
        formality: Optional[str] = None,
    ) -> AITranslationResult:
        """AI-powered translation using Google Gemini. Supports 22+ languages.

        Args:
            text: Text to translate (max 5,000 characters).
            target: Target language code (default ``"ar"``).
            source: Source language code (auto-detected if omitted).
            formality: ``"formal"`` or ``"informal"`` (default ``"formal"``).

        Returns:
            AI translation with confidence, transliteration, and caching info.
        """
        body: Dict[str, Any] = {"text": text}
        if target is not None:
            body["target"] = target
        if source is not None:
            body["source"] = source
        if formality is not None:
            body["formality"] = formality
        return await self._client.post("/v1/translate", json=body)  # type: ignore[return-value]
