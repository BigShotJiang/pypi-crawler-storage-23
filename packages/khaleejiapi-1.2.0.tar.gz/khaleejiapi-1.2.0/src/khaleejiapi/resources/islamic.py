"""Islamic & Arabic API resources (Hijri calendar, prayer times, Arabic text)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import ArabicProcessResult, HijriConversionResult, PrayerTimesResult


class IslamicResource:
    """Synchronous Islamic & Arabic endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def convert_hijri(
        self,
        *,
        date: Optional[str] = None,
        hijri: Optional[str] = None,
        today: bool = False,
    ) -> HijriConversionResult:
        """Convert between Gregorian and Hijri calendar dates.

        Args:
            date: Gregorian date ``YYYY-MM-DD`` to convert to Hijri.
            hijri: Hijri date ``YYYY-MM-DD`` to convert to Gregorian.
            today: If ``True``, returns today's date conversion.

        Returns:
            Both Gregorian and Hijri date representations.
        """
        params: Dict[str, Any] = {}
        if date is not None:
            params["date"] = date
        if hijri is not None:
            params["hijri"] = hijri
        if today:
            params["today"] = "true"
        return self._client.get("/v1/hijri/convert", params=params)  # type: ignore[return-value]

    def get_prayer_times(
        self,
        *,
        city: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        date: Optional[str] = None,
        method: Optional[str] = None,
        school: Optional[str] = None,
    ) -> PrayerTimesResult:
        """Get prayer times and Qibla direction.

        Args:
            city: City name (e.g. ``"dubai"``, ``"riyadh"``).
            lat: Latitude (alternative to city).
            lng: Longitude (alternative to city).
            date: Date ``YYYY-MM-DD`` (default: today).
            method: Calculation method: ``mwl``, ``isna``, ``egypt``,
                ``makkah``, or ``karachi`` (default: ``mwl``).
            school: Juristic school: ``shafi`` or ``hanafi`` (default: ``shafi``).

        Returns:
            Prayer times, location info, and Qibla direction.
        """
        params: Dict[str, Any] = {}
        if city is not None:
            params["city"] = city
        if lat is not None:
            params["lat"] = lat
        if lng is not None:
            params["lng"] = lng
        if date is not None:
            params["date"] = date
        if method is not None:
            params["method"] = method
        if school is not None:
            params["school"] = school
        return self._client.get("/v1/prayer-times", params=params)  # type: ignore[return-value]

    def process_arabic(
        self,
        operation: str,
        text: str,
        *,
        direction: Optional[str] = None,
    ) -> ArabicProcessResult:
        """Process Arabic text with various operations.

        Args:
            operation: Operation to perform — ``remove_diacritics``,
                ``normalize``, ``transliterate``, ``detect_script``,
                ``convert_numbers``, ``word_count``, or ``sentiment``.
            text: The Arabic text to process (max 10,000 characters).
            direction: For ``convert_numbers`` — ``to_arabic`` or
                ``to_western``.

        Returns:
            Processing result (shape varies by operation).
        """
        body: Dict[str, Any] = {"operation": operation, "text": text}
        if direction is not None:
            body["options"] = {"direction": direction}
        return self._client.post("/v1/arabic/process", json=body)  # type: ignore[return-value]


class AsyncIslamicResource:
    """Asynchronous Islamic & Arabic endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def convert_hijri(
        self,
        *,
        date: Optional[str] = None,
        hijri: Optional[str] = None,
        today: bool = False,
    ) -> HijriConversionResult:
        """Convert between Gregorian and Hijri calendar dates.

        Args:
            date: Gregorian date ``YYYY-MM-DD`` to convert to Hijri.
            hijri: Hijri date ``YYYY-MM-DD`` to convert to Gregorian.
            today: If ``True``, returns today's date conversion.

        Returns:
            Both Gregorian and Hijri date representations.
        """
        params: Dict[str, Any] = {}
        if date is not None:
            params["date"] = date
        if hijri is not None:
            params["hijri"] = hijri
        if today:
            params["today"] = "true"
        return await self._client.get("/v1/hijri/convert", params=params)  # type: ignore[return-value]

    async def get_prayer_times(
        self,
        *,
        city: Optional[str] = None,
        lat: Optional[float] = None,
        lng: Optional[float] = None,
        date: Optional[str] = None,
        method: Optional[str] = None,
        school: Optional[str] = None,
    ) -> PrayerTimesResult:
        """Get prayer times and Qibla direction.

        Args:
            city: City name (e.g. ``"dubai"``, ``"riyadh"``).
            lat: Latitude (alternative to city).
            lng: Longitude (alternative to city).
            date: Date ``YYYY-MM-DD`` (default: today).
            method: Calculation method: ``mwl``, ``isna``, ``egypt``,
                ``makkah``, or ``karachi`` (default: ``mwl``).
            school: Juristic school: ``shafi`` or ``hanafi`` (default: ``shafi``).

        Returns:
            Prayer times, location info, and Qibla direction.
        """
        params: Dict[str, Any] = {}
        if city is not None:
            params["city"] = city
        if lat is not None:
            params["lat"] = lat
        if lng is not None:
            params["lng"] = lng
        if date is not None:
            params["date"] = date
        if method is not None:
            params["method"] = method
        if school is not None:
            params["school"] = school
        return await self._client.get("/v1/prayer-times", params=params)  # type: ignore[return-value]

    async def process_arabic(
        self,
        operation: str,
        text: str,
        *,
        direction: Optional[str] = None,
    ) -> ArabicProcessResult:
        """Process Arabic text with various operations.

        Args:
            operation: Operation to perform — ``remove_diacritics``,
                ``normalize``, ``transliterate``, ``detect_script``,
                ``convert_numbers``, ``word_count``, or ``sentiment``.
            text: The Arabic text to process (max 10,000 characters).
            direction: For ``convert_numbers`` — ``to_arabic`` or
                ``to_western``.

        Returns:
            Processing result (shape varies by operation).
        """
        body: Dict[str, Any] = {"operation": operation, "text": text}
        if direction is not None:
            body["options"] = {"direction": direction}
        return await self._client.post("/v1/arabic/process", json=body)  # type: ignore[return-value]
