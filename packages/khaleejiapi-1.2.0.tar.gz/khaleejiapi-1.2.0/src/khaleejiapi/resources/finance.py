"""Finance API resources."""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import BusinessDaysResult, ExchangeConvertResult, ExchangeRatesResult, HolidaysResult, VatCalculationResult


class FinanceResource:
    """Synchronous finance endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def get_exchange_rates(
        self,
        base: str = "AED",
        *,
        target: Optional[str] = None,
        amount: Optional[float] = None,
    ) -> Union[ExchangeRatesResult, ExchangeConvertResult]:
        """Get exchange rates or convert a specific amount.

        Args:
            base: Base currency code (default ``"AED"``).
            target: Target currency for conversion (optional).
            amount: Amount to convert (requires *target*).

        Returns:
            All rates relative to *base*, or a single conversion result.
        """
        params: Dict[str, Any] = {"base": base}
        if target is not None:
            params["target"] = target
        if amount is not None:
            params["amount"] = amount
        return self._client.get("/v1/exchange/rates", params=params)  # type: ignore[return-value]

    def calculate_vat(
        self,
        amount: float,
        country_code: str = "AE",
        *,
        inclusive: bool = False,
    ) -> VatCalculationResult:
        """Calculate VAT for a given amount.

        Args:
            amount: The monetary amount.
            country_code: ISO-3166-1 alpha-2 country code (default ``"AE"``).
            inclusive: Whether the amount already includes VAT.

        Returns:
            Breakdown of VAT amount, rate, and total.
        """
        params: Dict[str, Any] = {
            "amount": amount,
            "country": country_code,
            "inclusive": str(inclusive).lower(),
        }
        return self._client.get("/v1/vat/calculate", params=params)  # type: ignore[return-value]

    def get_holidays(
        self,
        country: str = "AE",
        *,
        year: Optional[int] = None,
    ) -> HolidaysResult:
        """List public holidays for a country.

        Args:
            country: ISO-3166-1 alpha-2 country code (default ``"AE"``).
            year: Calendar year (defaults to current year).

        Returns:
            List of holidays with names and dates.
        """
        params: Dict[str, Any] = {"country": country}
        if year is not None:
            params["year"] = year
        return self._client.get("/v1/holidays", params=params)  # type: ignore[return-value]

    def get_business_days(
        self,
        *,
        country: str = "AE",
        date: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        add: Optional[int] = None,
        weekend: Optional[str] = None,
    ) -> BusinessDaysResult:
        """Calculate business days for GCC countries.

        Supports three modes:
        - Single date check: provide ``date``
        - Count range: provide ``from_date`` and ``to_date``
        - Add business days: provide ``from_date`` and ``add``

        Args:
            country: ISO-3166-1 alpha-2 code (default ``"AE"``).
            date: Check if this date is a business day.
            from_date: Start date for range/add mode.
            to_date: End date for counting mode.
            add: Number of business days to add (1-365).
            weekend: Override weekend days (e.g. ``"fri,sat"``).

        Returns:
            Business days information based on the mode used.
        """
        params: Dict[str, Any] = {"country": country}
        if date is not None:
            params["date"] = date
        if from_date is not None:
            params["from"] = from_date
        if to_date is not None:
            params["to"] = to_date
        if add is not None:
            params["add"] = add
        if weekend is not None:
            params["weekend"] = weekend
        return self._client.get("/v1/business-days", params=params)  # type: ignore[return-value]


class AsyncFinanceResource:
    """Asynchronous finance endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def get_exchange_rates(
        self,
        base: str = "AED",
        *,
        target: Optional[str] = None,
        amount: Optional[float] = None,
    ) -> Union[ExchangeRatesResult, ExchangeConvertResult]:
        """Get exchange rates or convert a specific amount.

        Args:
            base: Base currency code (default ``"AED"``).
            target: Target currency for conversion (optional).
            amount: Amount to convert (requires *target*).

        Returns:
            All rates relative to *base*, or a single conversion result.
        """
        params: Dict[str, Any] = {"base": base}
        if target is not None:
            params["target"] = target
        if amount is not None:
            params["amount"] = amount
        return await self._client.get("/v1/exchange/rates", params=params)  # type: ignore[return-value]

    async def calculate_vat(
        self,
        amount: float,
        country_code: str = "AE",
        *,
        inclusive: bool = False,
    ) -> VatCalculationResult:
        """Calculate VAT for a given amount.

        Args:
            amount: The monetary amount.
            country_code: ISO-3166-1 alpha-2 country code (default ``"AE"``).
            inclusive: Whether the amount already includes VAT.

        Returns:
            Breakdown of VAT amount, rate, and total.
        """
        params: Dict[str, Any] = {
            "amount": amount,
            "country": country_code,
            "inclusive": str(inclusive).lower(),
        }
        return await self._client.get("/v1/vat/calculate", params=params)  # type: ignore[return-value]

    async def get_holidays(
        self,
        country: str = "AE",
        *,
        year: Optional[int] = None,
    ) -> HolidaysResult:
        """List public holidays for a country.

        Args:
            country: ISO-3166-1 alpha-2 country code (default ``"AE"``).
            year: Calendar year (defaults to current year).

        Returns:
            List of holidays with names and dates.
        """
        params: Dict[str, Any] = {"country": country}
        if year is not None:
            params["year"] = year
        return await self._client.get("/v1/holidays", params=params)  # type: ignore[return-value]

    async def get_business_days(
        self,
        *,
        country: str = "AE",
        date: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        add: Optional[int] = None,
        weekend: Optional[str] = None,
    ) -> BusinessDaysResult:
        """Calculate business days for GCC countries.

        Supports three modes:
        - Single date check: provide ``date``
        - Count range: provide ``from_date`` and ``to_date``
        - Add business days: provide ``from_date`` and ``add``

        Args:
            country: ISO-3166-1 alpha-2 code (default ``"AE"``).
            date: Check if this date is a business day.
            from_date: Start date for range/add mode.
            to_date: End date for counting mode.
            add: Number of business days to add (1-365).
            weekend: Override weekend days (e.g. ``"fri,sat"``).

        Returns:
            Business days information based on the mode used.
        """
        params: Dict[str, Any] = {"country": country}
        if date is not None:
            params["date"] = date
        if from_date is not None:
            params["from"] = from_date
        if to_date is not None:
            params["to"] = to_date
        if add is not None:
            params["add"] = add
        if weekend is not None:
            params["weekend"] = weekend
        return await self._client.get("/v1/business-days", params=params)  # type: ignore[return-value]
