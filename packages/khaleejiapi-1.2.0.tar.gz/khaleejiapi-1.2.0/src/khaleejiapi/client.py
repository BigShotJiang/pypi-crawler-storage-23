"""Synchronous KhaleejiAPI client."""

from __future__ import annotations

from typing import Optional

from ._client import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, MAX_RETRIES, SyncHTTPClient
from .resources.communication import CommunicationResource
from .resources.documents import DocumentsResource
from .resources.finance import FinanceResource
from .resources.geo import GeoResource
from .resources.utility import UtilityResource
from .resources.islamic import IslamicResource
from .resources.validation import ValidationResource


class KhaleejiAPI:
    """Synchronous client for the KhaleejiAPI platform.

    Example::

        from khaleejiapi import KhaleejiAPI

        client = KhaleejiAPI("kapi_live_...")
        result = client.validation.validate_email("user@example.com")
        print(result["valid"])
        client.close()

    The client can also be used as a context manager::

        with KhaleejiAPI("kapi_live_...") as client:
            ip = client.geo.lookup_ip("8.8.8.8")
    """

    validation: ValidationResource
    geo: GeoResource
    finance: FinanceResource
    documents: DocumentsResource
    communication: CommunicationResource
    utility: UtilityResource
    islamic: IslamicResource

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must be a non-empty string")
        self._http = SyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self.validation = ValidationResource(self._http)
        self.geo = GeoResource(self._http)
        self.finance = FinanceResource(self._http)
        self.documents = DocumentsResource(self._http)
        self.communication = CommunicationResource(self._http)
        self.utility = UtilityResource(self._http)
        self.islamic = IslamicResource(self._http)

    # -- context manager ----------------------------------------------------

    def __enter__(self) -> "KhaleejiAPI":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # -- lifecycle ----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    # -- helpers ------------------------------------------------------------

    @property
    def last_rate_limit(self) -> dict:  # type: ignore[type-arg]
        """Rate-limit headers from the most recent response."""
        return dict(self._http.last_rate_limit)
