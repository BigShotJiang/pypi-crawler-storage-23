"""Tests for the Validation resource."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from khaleejiapi import AsyncKhaleejiAPI, KhaleejiAPI


EMAIL_RESPONSE = {
    "data": {
        "email": "user@example.com",
        "valid": True,
        "reason": "Valid email address",
        "checks": {"syntax": True, "disposable": True, "mx": True, "role": False},
        "domain": "example.com",
        "localPart": "user",
    },
    "meta": {"timestamp": "2025-06-01T12:00:00Z"},
}

PHONE_RESPONSE = {
    "data": {
        "phone": "+971501234567",
        "valid": True,
        "e164": "+971501234567",
        "country": {"code": "AE", "name": "United Arab Emirates", "nameAr": "الإمارات العربية المتحدة", "prefix": "+971"},
        "type": "mobile",
        "nationalNumber": "501234567",
        "reason": "Valid phone number",
    },
    "meta": {"timestamp": "2025-06-01T12:00:00Z"},
}

IBAN_RESPONSE = {
    "data": {
        "iban": "AE070331234567890123456",
        "valid": True,
        "countryCode": "AE",
        "country": "United Arab Emirates",
        "bank": {"name": "Emirates NBD", "bic": "EABORUAEAAA"},
        "reason": "Valid IBAN",
    },
    "meta": {"timestamp": "2025-06-01T12:00:00Z"},
}

VAT_RESPONSE = {
    "data": {
        "trn": "100000000000003",
        "country": "AE",
        "countryName": "United Arab Emirates",
        "valid": True,
        "reason": "Valid UAE TRN",
    },
    "meta": {"timestamp": "2025-06-01T12:00:00Z"},
}

EMIRATES_ID_RESPONSE = {
    "data": {
        "emiratesId": "784-1990-1234567-1",
        "valid": True,
        "formatted": "784-1990-1234567-1",
        "components": {"year": "1990", "random": "1234567", "checkDigit": "1"},
    },
    "meta": {"timestamp": "2025-06-01T12:00:00Z"},
}


# ---------------------------------------------------------------------------
# Sync tests
# ---------------------------------------------------------------------------


class TestValidationSync:
    def test_validate_email(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=EMAIL_RESPONSE)
        with KhaleejiAPI("key", base_url="http://test") as client:
            result = client.validation.validate_email("user@example.com")
            assert result["valid"] is True
            assert result["email"] == "user@example.com"
            assert result["checks"]["syntax"] is True

    def test_validate_phone(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=PHONE_RESPONSE)
        with KhaleejiAPI("key", base_url="http://test") as client:
            result = client.validation.validate_phone("+971501234567")
            assert result["valid"] is True
            assert result["type"] == "mobile"
            assert result["country"]["code"] == "AE"

    def test_validate_iban(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=IBAN_RESPONSE)
        with KhaleejiAPI("key", base_url="http://test") as client:
            result = client.validation.validate_iban("AE070331234567890123456")
            assert result["valid"] is True
            assert result["countryCode"] == "AE"

    def test_validate_vat(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=VAT_RESPONSE)
        with KhaleejiAPI("key", base_url="http://test") as client:
            result = client.validation.validate_vat("100000000000003")
            assert result["valid"] is True
            assert result["country"] == "AE"

    def test_validate_emirates_id(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=EMIRATES_ID_RESPONSE)
        with KhaleejiAPI("key", base_url="http://test") as client:
            result = client.validation.validate_emirates_id("784-1990-1234567-1")
            assert result["valid"] is True
            assert result["components"]["year"] == "1990"


# ---------------------------------------------------------------------------
# Async tests
# ---------------------------------------------------------------------------


class TestValidationAsync:
    @pytest.mark.asyncio
    async def test_validate_email(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=EMAIL_RESPONSE)
        async with AsyncKhaleejiAPI("key", base_url="http://test") as client:
            result = await client.validation.validate_email("user@example.com")
            assert result["valid"] is True

    @pytest.mark.asyncio
    async def test_validate_phone(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=PHONE_RESPONSE)
        async with AsyncKhaleejiAPI("key", base_url="http://test") as client:
            result = await client.validation.validate_phone("+971501234567")
            assert result["valid"] is True

    @pytest.mark.asyncio
    async def test_validate_iban(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(status_code=200, json=IBAN_RESPONSE)
        async with AsyncKhaleejiAPI("key", base_url="http://test") as client:
            result = await client.validation.validate_iban("AE070331234567890123456")
            assert result["valid"] is True
