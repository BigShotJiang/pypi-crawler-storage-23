.. py:currentmodule:: rubin_nights

.. _intro:

Introduction
============

The basic tools in rubin_nights permit the querying of various data sources related to metadata about acquired visits. There are additional tools beyond these, supporting survey scheduling and evaluation of survey performance.  More examples can be found in the `notebooks` directory; it is recommended to start with the Demo notebook. 



.. toctree::
    :maxdepth: 1
