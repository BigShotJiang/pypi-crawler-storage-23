.. py:currentmodule:: rubin_nights

.. _rubin_nights_index:

###############
rubin_nights
###############

Query tools useful for survey progress tracking and evaluation.

.. toctree::
    :maxdepth: 2

    Introduction <intro>
    API <api>
