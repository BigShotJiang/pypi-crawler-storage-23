.. py:currentmodule:: rubin_nights

.. _addons_api:

Additional Data
================

Some additional data can be calculated (model slew times, etc).
Some additional data can be gathered by querying multiple sources.

.. toctree::
    :maxdepth: 2


.. automodule:: rubin_nights.augment_visits
    :imported-members:
    :members:
    :show-inheritance:

.. automodule:: rubin_nights.rubin_scheduler_addons
    :imported-members:
    :members:
    :show-inheritance:

.. automodule:: rubin_nights.rubin_sim_addons
    :imported-members:
    :members:
    :show-inheritance:

.. automodule:: rubin_nights.observatory_status
    :imported-members:
    :members:
    :show-inheritance:

.. automodule:: rubin_nights.targets_and_visits
    :imported-members:
    :members:
    :show-inheritance:

