.. py:currentmodule:: rubin_nights

.. _scriptqueue_api:

ScriptQueue Related
===================

Follow the script queue commands at the summit to gather the data.

.. toctree::
    :maxdepth: 2


.. automodule:: rubin_nights.scriptqueue
    :imported-members:
    :members:
    :show-inheritance:

.. automodule:: rubin_nights.scriptqueue_formatting
    :imported-members:
    :members:
    :show-inheritance:

