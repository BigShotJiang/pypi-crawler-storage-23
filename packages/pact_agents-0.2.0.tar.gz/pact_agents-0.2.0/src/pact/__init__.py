"""Pact — contract-first multi-agent software engineering."""

__version__ = "0.1.0"
