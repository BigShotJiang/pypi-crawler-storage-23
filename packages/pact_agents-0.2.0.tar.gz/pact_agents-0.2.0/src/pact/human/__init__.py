"""Human integration facade — Linear, Slack, Git."""
