"""Agent modules for pact architecture."""
