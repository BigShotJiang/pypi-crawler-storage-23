---
title: Sync `.mailmap`
---

### Description

Synchronizes the `.mailmap` file with the project's Git contributors. See the [`sync-mailmap` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
