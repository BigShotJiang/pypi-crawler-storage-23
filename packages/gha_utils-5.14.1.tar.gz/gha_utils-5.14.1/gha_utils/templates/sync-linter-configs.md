---
title: Sync linter configs
---

### Description

Syncs linter configuration files with the canonical references from [`kdeldycke/workflows`](https://github.com/kdeldycke/workflows/blob/main/gha_utils/data/zizmor.yml). See the [`sync-linter-configs` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
