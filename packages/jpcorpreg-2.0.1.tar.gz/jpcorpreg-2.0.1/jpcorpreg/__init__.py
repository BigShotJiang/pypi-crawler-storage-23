"""
Corporate Number Parser Library
~~~~~~~~~~~~~~~~~~~~~
jpcorpreg is a simple scraping library for Corporate Number Publication Site
"""
from jpcorpreg.client import CorporateRegistryClient

__version__ = "2.0.0"