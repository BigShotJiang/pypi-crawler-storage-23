"""
Resources of the API.
"""
