#!/usr/bin/env python3
"""
JSEye Setup Script
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

# Read version
version_path = Path(__file__).parent / "jseye" / "__init__.py"
version = "1.0.1"
if version_path.exists():
    for line in version_path.read_text().split('\n'):
        if line.startswith('__version__'):
            version = line.split('"')[1]
            break

setup(
    name="jseye",
    version=version,
    description="JavaScript Intelligence & Attack Surface Discovery Tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Lakshmikanthan K",
    author_email="letchupkt@github.com",
    url="https://github.com/letchupkt/jseye",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "jseye": ["data/*.yaml", "data/*.txt"]
    },
    entry_points={
        "console_scripts": [
            "jseye=jseye.cli:main",
        ],
    },
    install_requires=[
        "rich>=13.0.0",
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "urllib3>=1.26.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
        ]
    },
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Testing",
    ],
    keywords="security javascript reconnaissance bug-bounty pentesting",
    project_urls={
        "Homepage": "https://github.com/letchupkt/jseye",
        "Repository": "https://github.com/letchupkt/jseye",
        "Issues": "https://github.com/letchupkt/jseye/issues",
        "Documentation": "https://github.com/letchupkt/jseye#readme",
    },
)