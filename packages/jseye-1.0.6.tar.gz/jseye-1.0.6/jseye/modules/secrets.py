"""
Secrets Detection Module (Mantra Integration)
"""

from pathlib import Path
from typing import List, Dict

from ..utils.shell import run_command
from ..utils.logger import log_progress
from ..utils.fs import save_json

class SecretsDetector:
    """Detect secrets using Mantra tool"""
    
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
    
    def run_mantra(self, js_files: List[Dict]) -> List[Dict]:
        """Run Mantra on JavaScript files"""
        log_progress("Running secrets detection (mantra)")
        
        secrets = []
        
        for js_file in js_files:
            if js_file.get('status') != 'success' or not js_file.get('filepath'):
                continue
            
            try:
                # Run mantra on the file
                success, stdout, stderr = run_command([
                    "mantra", "-f", js_file['filepath']
                ])
                
                if success and stdout:
                    # Parse mantra output (JSON format expected)
                    try:
                        import json
                        mantra_results = json.loads(stdout)
                        
                        if isinstance(mantra_results, list):
                            for result in mantra_results:
                                secrets.append({
                                    'type': result.get('type', 'unknown'),
                                    'value': result.get('value', ''),
                                    'line': result.get('line', 0),
                                    'source_file': Path(js_file['filepath']).name,
                                    'tool': 'mantra',
                                    'confidence': result.get('confidence', 'medium')
                                })
                    except json.JSONDecodeError:
                        # Fallback to line-by-line parsing
                        for line in stdout.split('\n'):
                            line = line.strip()
                            if line and 'secret' in line.lower():
                                secrets.append({
                                    'type': 'generic',
                                    'value': line,
                                    'source_file': Path(js_file['filepath']).name,
                                    'tool': 'mantra',
                                    'confidence': 'low'
                                })
                
            except Exception as e:
                log_progress(f"Warning: Mantra failed for {js_file['filepath']} - {e}")
        
        # Save results
        save_json(secrets, self.output_dir / "secrets_results.json")
        
        log_progress(f"Found {len(secrets)} potential secrets")
        
        return secrets