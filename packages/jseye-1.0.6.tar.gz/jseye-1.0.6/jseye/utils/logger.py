"""
Logging utilities for JSEye
"""

import logging
from pathlib import Path
from rich.console import Console
from rich.logging import RichHandler

console = Console()

def setup_logger(name: str, output_dir: Path, level: int = logging.INFO) -> logging.Logger:
    """
    Setup logger with both file and console output
    
    Args:
        name: Logger name
        output_dir: Directory for log files
        level: Logging level
        
    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid duplicate handlers
    if logger.handlers:
        return logger
    
    # File handler
    log_file = output_dir / f"{name}.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(level)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    # Rich console handler
    console_handler = RichHandler(console=console, show_path=False)
    console_handler.setLevel(level)
    logger.addHandler(console_handler)
    
    return logger

def log_progress(message: str, style: str = "cyan"):
    """Log progress message to console"""
    console.print(f"[+] {message}", style=style)