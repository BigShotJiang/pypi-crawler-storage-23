"""
File system utilities
"""

import json
from pathlib import Path
from typing import List, Dict, Any

def save_json(data: Any, filepath: Path) -> bool:
    """
    Save data as JSON file
    
    Args:
        data: Data to save
        filepath: Output file path
        
    Returns:
        Success status
    """
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        return True
    except Exception:
        return False

def load_json(filepath: Path) -> Any:
    """
    Load JSON file
    
    Args:
        filepath: Input file path
        
    Returns:
        Loaded data or None if failed
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def save_lines(lines: List[str], filepath: Path) -> bool:
    """
    Save list of strings as text file (one per line)
    
    Args:
        lines: List of strings
        filepath: Output file path
        
    Returns:
        Success status
    """
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            for line in lines:
                f.write(f"{line}\n")
        
        return True
    except Exception:
        return False

def load_lines(filepath: Path) -> List[str]:
    """
    Load text file as list of lines
    
    Args:
        filepath: Input file path
        
    Returns:
        List of lines or empty list if failed
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except Exception:
        return []

def ensure_dir(dirpath: Path) -> bool:
    """
    Ensure directory exists
    
    Args:
        dirpath: Directory path
        
    Returns:
        Success status
    """
    try:
        dirpath.mkdir(parents=True, exist_ok=True)
        return True
    except Exception:
        return False