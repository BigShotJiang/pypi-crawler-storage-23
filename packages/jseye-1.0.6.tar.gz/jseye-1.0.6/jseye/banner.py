"""
JSEye Banner Display with Version Checking
"""

import requests
from rich.console import Console
from rich.text import Text
from rich.align import Align
from rich.panel import Panel
from . import __version__

console = Console()

def get_latest_pypi_version():
    """Get the latest version from PyPI"""
    try:
        response = requests.get("https://pypi.org/pypi/jseye/json", timeout=3)
        if response.status_code == 200:
            data = response.json()
            return data["info"]["version"]
    except:
        pass
    return None

def show_banner():
    """Display the enhanced JSEye banner"""
    # Add some top padding first
    console.print()
    
    # ASCII Art Banner - clean and properly aligned
    banner = """   ▄▄▄▄▄▄  ▄▄▄▄▄     ▄▄▄▄▄▄▄            
  █▀ ██   ██▀▀▀▀█▄  █▀██▀▀▀             
     ██   ▀██▄  ▄▀    ██                
     ██     ▀██▄▄     ████   ██ ██ ▄█▀█▄
     ██   ▄   ▀██▄    ██     ██▄██ ██▄█▀
     ██   ▀██████▀    ▀█████▄▄▀██▀ ▀██▄▄▄
 ▄   ██                        ██       
 ▀████▀                      ▀▀▀        """
    
    # Display banner in cyan
    banner_text = Text(banner, style="cyan bold")
    console.print(Align.center(banner_text))
    console.print()
    
    # Tagline centered
    tagline = Text("JavaScript Intelligence & Attack Surface Discovery", style="green bold")
    console.print(Align.center(tagline))
    
    # Version info with PyPI check
    current_version = f"v{__version__}"
    version_text = f"Current Version: {current_version}"
    
    # Check for latest version on PyPI
    latest_version = get_latest_pypi_version()
    if latest_version and latest_version != __version__:
        version_text += f" | Latest: v{latest_version} (Update available!)"
        version_style = "yellow bold"
    else:
        version_style = "green"
    
    version_info = Text(version_text, style=version_style)
    console.print(Align.center(version_info))
    
    # Author info
    author = Text("Author: Lakshmikanthan K (letchupkt)", style="purple")
    console.print(Align.center(author))
    
    console.print()

def show_performance_banner():
    """Show performance-focused banner for v1.0.6"""
    # Performance upgrade banner
    perf_banner = Panel.fit(
        "[bold cyan]>> JSEye v1.0.6 - Performance Revolution[/bold cyan]\n"
        "[green][+] Parallel Tool Execution (3-5x faster)[/green]\n"
        "[green][+] Smart JS Prioritization (60-70% time saved)[/green]\n"
        "[green][+] Tiered Analysis Engine[/green]\n"
        "[green][+] Comprehensive Caching System[/green]\n"
        "[green][+] Full CPU Utilization[/green]",
        style="cyan",
        title="[bold white]Performance Upgrades[/bold white]"
    )
    console.print(Align.center(perf_banner))
    console.print()