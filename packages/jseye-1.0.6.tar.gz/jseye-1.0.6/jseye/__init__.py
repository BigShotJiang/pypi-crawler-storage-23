"""
JSEye - JavaScript Intelligence & Attack Surface Discovery Tool
Author: Lakshmikanthan K (letchupkt)
License: MIT
"""

__version__ = "1.0.6"
__author__ = "Lakshmikanthan K (letchupkt)"
__email__ = "letchupkt.dev@gmail.com"