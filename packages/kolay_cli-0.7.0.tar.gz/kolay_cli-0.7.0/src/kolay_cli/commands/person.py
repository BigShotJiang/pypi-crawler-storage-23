import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, display_status, fmt_val, fmt_num, label,
    print_error, print_success, print_fetching, print_empty, kv_table
)

app = typer.Typer(help="Manage person/employee records in Kolay.")

@app.command(name="list")
def list_people(
    page: int = typer.Option(1, help="Page number"),
    status: str = typer.Option("active", help="Filter by status: active, inactive"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by name or email"),
    limit: int = typer.Option(20, help="Number of records to show")
):
    """
    List employees. Defaults to active employees.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching employees (page {page}, status: {status})…")
        payload = {"page": page, "status": status, "limit": limit}
        if search:
            payload["search"] = search
        response = client.post("v2/person/list", data=payload)

        data_resp = response.get("data", {})
        items = data_resp.get("items", data_resp) if isinstance(data_resp, dict) else data_resp
        total = data_resp.get("totalCount", len(items)) if isinstance(data_resp, dict) else len(items)

        if not items:
            print_empty(
                "employees",
                hint=f"Try '--status inactive' to find terminated employees." if status == "active" else None
            )
            return

        table = Table(title=f"Employees — {status.title()}", header_style="bold cyan", border_style="cyan")
        table.add_column("#", style="grey62", width=4, justify="right")
        table.add_column("Short ID", style="grey62", no_wrap=True)
        table.add_column("Name", style="bold white")
        table.add_column("Work Email", style="steel_blue1")
        table.add_column("Status", justify="center")

        for i, person in enumerate(items, start=(page - 1) * limit + 1):
            pid = str(person.get("id", ""))
            fname = person.get("firstName", "")
            lname = person.get("lastName", "")
            name = f"{fname} {lname}".strip() or person.get("name", "—")
            email = person.get("workEmail") or person.get("email") or "—"
            st = display_status(person.get("status", ""))
            table.add_row(str(i), short_id(pid), name, email, st)

        console.print(table)
        shown = min(page * limit, total)
        start = (page - 1) * limit + 1
        console.print(f"[grey62]  Page {page} · Showing {start}–{shown} of {total} employees[/grey62]\n")

    except APIError as e:
        print_error(str(e), hint="Check your API token with 'kolay auth status'.")
        raise typer.Exit(1)


@app.command(name="view")
def view_person(person_id: str = typer.Argument(..., help="ID of the person to view")):
    """
    View full profile of a specific employee.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching profile for {person_id}…")
        response = client.get(f"v2/person/view/{safe_id(person_id)}")

        data = response.get("data", {})
        person = data.get("person", data) if isinstance(data, dict) else data

        if not person:
            print_error(f"Person '{person_id}' not found.", hint="Run 'kolay person list' to find valid IDs.")
            return

        fname = person.get("firstName", "")
        lname = person.get("lastName", "")
        full_name = f"{fname} {lname}".strip()
        st = display_status(person.get("status", ""))

        console.print(f"\n[bold cyan]Employee Profile[/bold cyan]  [bold white]{full_name}[/bold white]  {st}\n")

        # Personal Info Panel
        personal = {
            "id": person.get("id"),
            "workEmail": person.get("workEmail") or person.get("email"),
            "mobilePhone": person.get("mobilePhone"),
            "birthday": person.get("birthday"),
            "gender": person.get("gender"),
            "idNumber": person.get("idNumber"),
        }
        personal_tbl = kv_table(personal)

        # Employment Panel
        emp_data = {"employmentStartDate": person.get("employmentStartDate")}
        units = person.get("unitList", [])
        active_unit = next((u for u in units if u.get("active") or u.get("default")), {})
        if active_unit:
            emp_data["employmentType"] = active_unit.get("employmentType")
            for item in active_unit.get("items", []):
                unit_name = item.get("unitName", "")
                emp_data[unit_name] = item.get("unitItemName")
        emp_tbl = kv_table(emp_data)

        console.print(Columns([
            Panel(personal_tbl, title="Personal", border_style="cyan", expand=True),
            Panel(emp_tbl, title="Employment", border_style="magenta", expand=True),
        ]))

        # Custom Fields
        custom_data = [f for f in person.get("dataList", []) if f.get("value")]
        if custom_data:
            c_tbl = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2, 0, 0))
            c_tbl.add_column("Field", style="grey85")
            c_tbl.add_column("Value")
            for field in custom_data:
                c_tbl.add_row(field.get("fieldToken", "—"), fmt_val(field.get("value")))
            console.print(Panel(c_tbl, title="Custom Fields", border_style="steel_blue1"))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="leave-status")
def view_leave_status(person_id: str = typer.Argument(..., help="ID of the person to view leave balances for")):
    """
    View leave balances for a specific employee.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching leave balances for {person_id}…")
        response = client.get(f"v2/person/leave-status/{safe_id(person_id)}")

        data = response.get("data", [])
        if not data:
            print_empty("leave balance data", hint="Make sure the person ID is correct.")
            return

        table = Table(title="Leave Balances", header_style="bold cyan", border_style="cyan")
        table.add_column("Leave Type", style="bold white")
        table.add_column("Paid?", justify="center")
        table.add_column("Total", justify="right", style="steel_blue1")
        table.add_column("Used", justify="right", style="grey62")
        table.add_column("Upcoming", justify="right", style="grey62")
        table.add_column("Remaining", justify="right", style="bold green")
        table.add_column("Next Accrual", justify="center", style="grey62")

        for leave in data:
            name = leave.get("name", "—")
            if leave.get("primary"):
                name = f"⭐ {name}"

            is_paid = "[green]Yes[/green]" if leave.get("isPaid") else "[red]No[/red]"
            total = fmt_num(leave.get("total", leave.get("dayLimit")))
            used = fmt_num(leave.get("used", 0))
            upcoming = fmt_num(leave.get("totalUpcoming", 0))
            unused = leave.get("unused")
            remaining = fmt_num(unused) if unused is not None else "∞"
            next_date = leave.get("nextAccrualDate") or "—"

            table.add_row(name, is_paid, total, used, upcoming, remaining, next_date)

        console.print(table)
        console.print("[grey62]  ⭐ = Primary leave type[/grey62]\n")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# SGK termination reason codes
REASON_CODES = {
    "01": "Resignation (deneme süreli fesh - işverence)",
    "03": "Voluntary resignation (istifa)",
    "04": "Termination without notice (haklı nedenle)",
    "10": "End of fixed-term contract",
    "11": "Retirement",
    "22": "Termination by employer (geçerli neden)",
    "23": "Death",
    "30": "Other",
}

@app.command(name="terminate")
def terminate_person(
    person_id: str = typer.Argument(..., help="ID of the person to terminate"),
    termination_date: Optional[str] = typer.Option(None, help="Termination date (YYYY-MM-DD or DD.MM.YYYY). Defaults to today."),
    reason: Optional[str] = typer.Option(None, help="Reason code (e.g. 01 for resignation). Leave blank to see options."),
):
    """
    Terminate employment of a specific employee.
    """
    import re
    from datetime import datetime

    try:
        client = KolayClient()

        # Pre-check: must be active
        print_fetching(f"Checking employee status…")
        resp = client.get(f"v2/person/view/{safe_id(person_id)}")
        data = resp.get("data", {})
        person = data.get("person", data) if isinstance(data, dict) else data
        fname = person.get("firstName", "")
        lname = person.get("lastName", "")
        current_status = person.get("status", "")

        if current_status != "active":
            print_error(
                f"{fname} {lname} is already '{current_status}' — cannot terminate.",
                hint="Only active employees can be terminated."
            )
            return

        # Date
        today = datetime.now().strftime("%Y-%m-%d")
        if not termination_date:
            termination_date = typer.prompt("Termination date", default=today)

        # Convert DD.MM.YYYY → YYYY-MM-DD
        if re.match(r"^\d{2}\.\d{2}\.\d{4}$", termination_date):
            dd, mm, yyyy = termination_date.split(".")
            termination_date = f"{yyyy}-{mm}-{dd}"

        # Reason code
        reason_code = reason
        details = ""
        if not reason_code:
            console.print("\n[bold cyan]SGK Termination Reason Codes:[/bold cyan]")
            rc_tbl = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2, 0, 0))
            rc_tbl.add_column("Code", style="bold white", width=6)
            rc_tbl.add_column("Description")
            for code, desc in REASON_CODES.items():
                rc_tbl.add_row(code, desc)
            console.print(rc_tbl)
            console.print()
            reason_code = typer.prompt("Reason Code", default="01")

        if reason_code not in REASON_CODES:
            console.print(f"[orange1]  → Unknown code '{reason_code}'. Proceeding anyway.[/orange1]")

        default_details = REASON_CODES.get(reason_code, "")
        details = typer.prompt("Details (optional)", default=default_details)

        payload = {
            "personId": person_id,
            "date": termination_date,
            "reasonCode": reason_code,
            "details": details
        }

        console.print(f"\n[grey62]Terminating {fname} {lname} on {termination_date} (code: {reason_code})…[/grey62]")
        client.post("v2/person/terminate", data=payload)
        FAREWELL_ART = """[dim red]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠒⠒⠢⢄⡀⠀⠀⢠⡏⠉⠉⠉⠑⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⠀⠀⠀⠀⠀⠙⢦⠀⡇⡇⠀⠀⠀⠀⠀⠀⠈⠱⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠊⠉⠉⠙⠒⢤⡀⠀⣼⠀⠀⢀⣶⣤⠀⠀⠀⢣⡇⡇⠀⠀⢴⣶⣦⠀⠀⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢀⣠⠤⢄⠀⠀⢰⡇⠀⠀⣠⣀⠀⠀⠈⢦⡿⡀⠀⠈⡟⣟⡇⠀⠀⢸⡇⡆⠀⠀⡼⢻⣠⠀⠀⠀⣸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⠖⠉⠀⠀⠀⣱⡀⡞⡇⠀⠀⣿⣿⢣⠀⠀⠈⣧⣣⠀⠀⠉⠋⠀⠀⠀⣸⡇⠇⠀⠀⠈⠉⠀⠀⠀⢀⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣠⠏⠀⠀⣴⢴⣿⣿⠗⢷⡹⡀⠀⠘⠾⠾⠀⠀⠀⣿⣿⣧⡀⠀⠀⠀⢀⣴⠇⣇⣆⣀⢀⣀⣀⣀⣀⣤⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⠀⠀⢸⢻⡞⠋⠀⠀⠀⢿⣷⣄⠀⠀⠀⠀⠀⣠⡇⠙⢿⣽⣷⣶⣶⣿⠋⢰⣿⣿⣿⣿⣿⣿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⡿⡄⠀⠈⢻⣝⣶⣶⠀⠀⠀⣿⣿⣱⣶⣶⣶⣾⡟⠀⠀⠀⢈⡉⠉⢩⡖⠒⠈⠉⡏⡴⡏⠉⠉⠉⠉⠉⠉⠉⠉⡇⠀⠀⢀⣴⠒⠢⠤⣀
⢣⣸⣆⡀⠀⠈⠉⠁⠀⠀⣠⣷⠈⠙⠛⠛⠛⠉⢀⣴⡊⠉⠁⠈⢢⣿⠀⠀⠀⢸⠡⠀⠁⠀⠀⠀⣠⣀⣀⣀⣀⡇⠀⢰⢁⡇⠀⠀⠀⢠
⠀⠻⣿⣟⢦⣤⡤⣤⣴⣾⡿⢃⡠⠔⠒⠉⠛⠢⣾⢿⣿⣦⡀⠀⠀⠉⠀⠀⢀⡇⢸⠀⠀⠀⠀⠀⠿⠿⠿⣿⡟⠀⢀⠇⢸⠀⠀⠀⠀⠘
⠀⠀⠈⠙⠛⠿⠿⠿⠛⠋⢰⡋⠀⠀⢠⣤⡄⠀⠈⡆⠙⢿⣿⣦⣀⠀⠀⠀⣜⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⢀⠃⠀⡸⠀⠇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢣⠀⠀⠈⠛⠁⠀⢴⠥⡀⠀⠙⢿⡿⡆⠀⠀⢸⠀⢸⢰⠀⠀⠀⢀⣿⣶⣶⡾⠀⢀⠇⣸⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⡀⢇⠀⠀⠀⢀⡀⠀⠀⠈⢢⠀⠀⢃⢱⠀⠀⠀⡇⢸⢸⠀⠀⠀⠈⠉⠉⠉⢱⠀⠼⣾⣿⣿⣷⣦⠴⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⠘⡄⠀⠀⢹⣿⡇⠀⠀⠈⡆⠀⢸⠈⡇⢀⣀⣵⢨⣸⣦⣤⣤⣄⣀⣀⣀⡞⠀⣠⡞⠉⠈⠉⢣⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢃⠘⡄⠀⠀⠉⠀⠀⣠⣾⠁⠀⠀⣧⣿⣿⡿⠃⠸⠿⣿⣿⣿⣿⣿⣿⠟⠁⣼⣾⠀⠀⠀⠀⢠⠇⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡄⠹⣀⣀⣤⣶⣿⡿⠃⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠁⠀⠀⢻⣿⣷⣦⣤⣤⠎⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣤⣿⡿⠟⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⠀⠀⠀⠀⠀[/dim red]"""
        console.print(FAREWELL_ART)
        print_success(f"{fname} {lname} has been terminated.")


    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_person(
    person_id: str = typer.Argument(..., help="ID of the person to update"),
    first_name: Optional[str] = typer.Option(None, "--first-name", help="Update first name"),
    last_name: Optional[str] = typer.Option(None, "--last-name", help="Update last name"),
    email: Optional[str] = typer.Option(None, "--email", help="Update work email address"),
    mobile_phone: Optional[str] = typer.Option(None, "--phone", help="Update mobile phone"),
    custom_field: Optional[list[str]] = typer.Option(None, "--custom", help="Custom field as key=value (e.g. --custom adres='Street 33/4')")
):
    """
    Update profile details of a specific employee.
    """
    try:
        client = KolayClient()
        person: dict = {"id": person_id}

        if first_name is not None:
            person["firstName"] = first_name
        if last_name is not None:
            person["lastName"] = last_name
        if email is not None:
            person["workEmail"] = email
        if mobile_phone is not None:
            person["mobilePhone"] = mobile_phone

        if custom_field:
            data_list = []
            for item in custom_field:
                if "=" in item:
                    k, v = item.split("=", 1)
                    data_list.append({"fieldToken": k, "value": v})
            if data_list:
                person["dataList"] = data_list

        if len(person) == 1 and not custom_field:
            print_error("No fields provided to update.", hint="Pass --first-name, --email, --phone, or --custom key=value.")
            return

        print_fetching(f"Updating profile for {person_id}…")
        client.put("v2/person/update", data={"person": person})
        print_success("Profile updated.")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="summary")
def view_summary(person_id: str = typer.Argument(..., help="ID of the person to view summary for")):
    """
    View summary of a specific employee.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching summary for {person_id}…")
        response = client.get(f"v2/person/view-summary/{safe_id(person_id)}")

        data = response.get("data", {})
        person = data.get("person", data) if isinstance(data, dict) else data

        if not person:
            print_error(f"Summary not found for '{person_id}'.", hint="Run 'kolay person list' to find valid IDs.")
            return

        fname = person.get("firstName", "")
        lname = person.get("lastName", "")
        full_name = f"{fname} {lname}".strip()
        st = display_status(person.get("status", ""))

        console.print(f"\n[bold cyan]Employee Summary[/bold cyan]  [bold white]{full_name}[/bold white]  {st}\n")

        tbl = kv_table(person, exclude=["firstName", "lastName", "status", "dataList"])
        console.print(Panel(tbl, title="Summary", border_style="cyan", expand=False))

        custom_data = [f for f in person.get("dataList", []) if f.get("value")]
        if custom_data:
            c_tbl = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2, 0, 0))
            c_tbl.add_column("Field", style="grey85")
            c_tbl.add_column("Value")
            for field in custom_data:
                c_tbl.add_row(field.get("fieldToken", "—"), fmt_val(field.get("value")))
            console.print(Panel(c_tbl, title="Custom Fields", border_style="steel_blue1"))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
