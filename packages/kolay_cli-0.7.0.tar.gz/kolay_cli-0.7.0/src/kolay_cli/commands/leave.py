import typer
from typing import Optional
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, display_status, fmt_val, label,
    print_error, print_success, print_fetching, print_empty, kv_table
)

app = typer.Typer(help="Manage leave records in Kolay.")


@app.command(name="list")
def list_leaves(
    status: str = typer.Option("approved", help="Filter by status: approved, waiting, rejected, cancelled"),
    start_date: Optional[str] = typer.Option(None, help="Start date (YYYY-MM-DD). Defaults to Jan 1 of this year."),
    end_date: Optional[str] = typer.Option(None, help="End date (YYYY-MM-DD). Defaults to Dec 31 of this year."),
    person_id: Optional[str] = typer.Option(None, help="Filter by person ID"),
    limit: int = typer.Option(50, help="Max number of records to return"),
    include_inactive: bool = typer.Option(False, help="Include inactive employees"),
):
    """
    List leave records. Filter by status, date range, or person.
    """
    try:
        client = KolayClient()

        now = datetime.now()
        sd = start_date or f"{now.year}-01-01 00:00:00"
        ed = end_date or f"{now.year}-12-31 23:59:59"

        params: dict = {
            "status": status,
            "startDate": sd,
            "endDate": ed,
            "limit": limit,
        }
        if include_inactive:
            params["include_inactive_employees"] = "true"
        if person_id:
            params["personId"] = person_id

        print_fetching(f"Fetching leave records ({status}, {sd[:10]} → {ed[:10]})…")
        response = client.get("v2/leave/list", params=params)

        data = response.get("data", [])
        if not data:
            hint = None
            if status == "approved":
                hint = "Try '--status waiting' to see pending requests."
            elif status == "waiting":
                hint = "No pending requests found."
            print_empty(f"{status} leave records", hint=hint)
            return

        table = Table(title=f"Leave Records — {status.title()}", header_style="bold cyan", border_style="cyan")
        table.add_column("#", style="grey62", width=4, justify="right")
        table.add_column("Short ID", style="grey62", no_wrap=True)
        table.add_column("Person", style="bold white")
        table.add_column("Type", style="steel_blue1")
        table.add_column("Start", style="grey62")
        table.add_column("End", style="grey62")
        table.add_column("Status", justify="center")

        for i, leave in enumerate(data, 1):
            lid = str(leave.get("id", ""))
            person = leave.get("person", {})
            person_name = person.get("name", "—") if isinstance(person, dict) else str(leave.get("personId", "—"))
            leave_type = leave.get("type", leave.get("leaveType", {}))
            type_name = leave_type.get("name", "—") if isinstance(leave_type, dict) else str(leave_type)
            start = (leave.get("startDate") or "—")[:10]
            end = (leave.get("endDate") or "—")[:10]
            st = display_status(leave.get("status", ""))
            table.add_row(str(i), short_id(lid), person_name, type_name, start, end, st)

        console.print(table)
        console.print(f"[grey62]  Showing {len(data)} records · {sd[:10]} → {ed[:10]}[/grey62]\n")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="view")
def view_leave(leave_id: str = typer.Argument(..., help="ID of the leave record to view")):
    """
    View details of a specific leave record.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching leave record {leave_id}…")
        response = client.get(f"v2/leave/view/{safe_id(leave_id)}")

        data = response.get("data", {})
        if not data:
            print_error(f"Leave record '{leave_id}' not found.", hint="Run 'kolay leave list' to find valid IDs.")
            return

        person = data.get("person", {})
        person_name = person.get("name", "—") if isinstance(person, dict) else "—"
        leave_type = data.get("type", data.get("leaveType", {}))
        type_name = leave_type.get("name", "—") if isinstance(leave_type, dict) else str(leave_type)
        st = display_status(data.get("status", ""))

        console.print(f"\n[bold cyan]Leave Record[/bold cyan]  [bold white]{type_name}[/bold white]  {st}")
        console.print(f"[grey62]  Employee: {person_name}[/grey62]\n")

        display = {k: v for k, v in data.items() if k not in ("person", "type", "leaveType", "status") and not isinstance(v, (dict, list))}
        tbl = kv_table(display)
        console.print(Panel(tbl, title="Details", border_style="cyan", expand=False))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_leave(
    person_id: Optional[str] = typer.Option(None, help="Person ID to create leave for"),
    leave_type_id: Optional[str] = typer.Option(None, help="Leave type ID (interactive picker if omitted)"),
    start_date: Optional[str] = typer.Option(None, help="Start date (YYYY-MM-DD HH:MM:SS)"),
    end_date: Optional[str] = typer.Option(None, help="End date (YYYY-MM-DD HH:MM:SS)"),
    comment: Optional[str] = typer.Option(None, help="Optional comment"),
):
    """
    Create a new leave request. Interactively picks the leave type.
    """
    try:
        client = KolayClient()

        if not person_id:
            person_id = typer.prompt("Person ID")

        if not leave_type_id:
            print_fetching(f"Fetching available leave types…")
            try:
                status_resp = client.get(f"v2/person/leave-status/{safe_id(person_id)}")
                leave_types = status_resp.get("data", [])
            except APIError:
                leave_types = []

            if leave_types:
                console.print()
                table = Table(title="Available Leave Types", header_style="bold cyan", border_style="cyan")
                table.add_column("#", style="grey62", width=4, justify="right")
                table.add_column("Name", style="bold white")
                table.add_column("Remaining", justify="right", style="bold green")
                table.add_column("Short ID", style="grey62")

                for i, lt in enumerate(leave_types, 1):
                    name = lt.get("name", "—")
                    if lt.get("primary"):
                        name = f"⭐ {name}"
                    unused = lt.get("unused")
                    remaining = str(unused) if unused is not None else "∞"
                    table.add_row(str(i), name, remaining, short_id(lt.get("id", "")))

                console.print(table)
                console.print()
                choice = typer.prompt("Pick a leave type (enter row # or full ID)")
                try:
                    idx = int(choice) - 1
                    leave_type_id = leave_types[idx].get("id") if 0 <= idx < len(leave_types) else choice
                except ValueError:
                    leave_type_id = choice
            else:
                leave_type_id = typer.prompt("Leave type ID")

        if not start_date:
            start_date = typer.prompt("Start date (YYYY-MM-DD HH:MM:SS)")
        if not end_date:
            end_date = typer.prompt("End date (YYYY-MM-DD HH:MM:SS)")

        payload: dict = {
            "personId": person_id,
            "leaveTypeId": leave_type_id,
            "startDate": start_date,
            "endDate": end_date,
        }
        if comment:
            payload["comment"] = comment

        print_fetching("Creating leave request…")
        response = client.post("v2/leave/create", data=payload)

        data = response.get("data", {})
        new_id = data.get("id", "—") if isinstance(data, dict) else "—"
        print_success(f"Leave request created! ID: [cyan]{new_id}[/cyan]")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
