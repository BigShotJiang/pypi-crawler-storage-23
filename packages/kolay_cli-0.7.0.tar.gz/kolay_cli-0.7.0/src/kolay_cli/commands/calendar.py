import typer
from typing import Optional
from rich.table import Table
from rich.panel import Panel
from datetime import datetime, timedelta

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, fmt_val, label,
    print_error, print_success, print_fetching, print_empty, kv_table
)

app = typer.Typer(help="Manage calendar events in Kolay.")


def _fmt_datetime(dt: Optional[str], fallback: str = "—") -> str:
    """Parse and pretty-print a datetime string."""
    if not dt:
        return fallback
    try:
        parsed = datetime.strptime(dt[:19], "%Y-%m-%d %H:%M:%S")
        return parsed.strftime("%d %b %Y  %H:%M")
    except ValueError:
        return dt


def _duration(start: str, end: str) -> str:
    """Return human-readable duration between two datetimes."""
    try:
        s = datetime.strptime(start[:19], "%Y-%m-%d %H:%M:%S")
        e = datetime.strptime(end[:19], "%Y-%m-%d %H:%M:%S")
        delta = e - s
        total_minutes = int(delta.total_seconds() // 60)
        if total_minutes < 60:
            return f"{total_minutes}m"
        hours, mins = divmod(total_minutes, 60)
        return f"{hours}h {mins}m" if mins else f"{hours}h"
    except (ValueError, TypeError):
        return "—"


@app.command(name="list")
def list_events(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by title keyword"),
    start: Optional[str] = typer.Option(None, "--start", help="Filter start date (YYYY-MM-DD). Defaults to today."),
    end: Optional[str] = typer.Option(None, "--end", help="Filter end date (YYYY-MM-DD). Defaults to +30 days."),
    page: int = typer.Option(1, "--page", help="Page number"),
    limit: int = typer.Option(20, "--limit", help="Number of records to return"),
):
    """
    List your calendar events. Defaults to the next 30 days.
    """
    try:
        client = KolayClient()

        now = datetime.now()
        start_dt = start or now.strftime("%Y-%m-%d") + " 00:00:00"
        end_dt = end or (now + timedelta(days=30)).strftime("%Y-%m-%d") + " 23:59:59"

        # Normalise to full datetime strings
        if len(start_dt) == 10:
            start_dt += " 00:00:00"
        if len(end_dt) == 10:
            end_dt += " 23:59:59"

        params = {
            "start": start_dt,
            "end": end_dt,
            "page": page,
            "limit": limit,
        }
        if search:
            params["search"] = search

        label_start = start_dt[:10]
        label_end = end_dt[:10]
        print_fetching(f"Fetching events ({label_start} → {label_end})…")
        response = client.get("v2/event/list", params=params)

        data_block = response.get("data", {})
        items = data_block.get("items", []) if isinstance(data_block, dict) else []
        total = data_block.get("totalCount", len(items)) if isinstance(data_block, dict) else len(items)

        if not items:
            print_empty(
                "events",
                hint="Try '--start 2000-01-01' to see all events, or '--search keyword' to search."
            )
            return

        table = Table(
            title=f"Calendar Events  {label_start} → {label_end}",
            header_style="bold cyan",
            border_style="cyan",
        )
        table.add_column("#", style="grey62", width=4, justify="right")
        table.add_column("Short ID", style="grey62", no_wrap=True)
        table.add_column("Title", style="bold white")
        table.add_column("Start", style="steel_blue1")
        table.add_column("End", style="steel_blue1")
        table.add_column("Duration", style="grey62", justify="right")

        for i, event in enumerate(items, start=(page - 1) * limit + 1):
            eid = str(event.get("id", ""))
            title = event.get("title", "—")
            ev_start = event.get("start", "")
            ev_end = event.get("end", "")
            table.add_row(
                str(i),
                short_id(eid),
                title,
                _fmt_datetime(ev_start),
                _fmt_datetime(ev_end),
                _duration(ev_start, ev_end),
            )

        console.print(table)
        shown = min(page * limit, total)
        start_n = (page - 1) * limit + 1
        console.print(f"[grey62]  Page {page} · Showing {start_n}–{shown} of {total} events[/grey62]\n")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="view")
def view_event(event_id: str = typer.Argument(..., help="ID of the event to view")):
    """
    View details of a specific calendar event.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching event {event_id}…")
        response = client.get(f"v2/event/view/{safe_id(event_id)}")

        event = response.get("data", {})
        if not event:
            print_error(
                f"Event '{event_id}' not found.",
                hint="Run 'kolay calendar list' to find valid event IDs."
            )
            return

        title = event.get("title", "—")
        ev_start = event.get("start", "")
        ev_end = event.get("end", "")
        dur = _duration(ev_start, ev_end)
        comment = event.get("comment") or "—"

        console.print(f"\n[bold cyan]📅 Calendar Event[/bold cyan]  [bold white]{title}[/bold white]\n")

        info_tbl = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
        info_tbl.add_column("Key", style="grey85", min_width=12)
        info_tbl.add_column("Value")
        info_tbl.add_row("Start", f"[steel_blue1]{_fmt_datetime(ev_start)}[/steel_blue1]")
        info_tbl.add_row("End", f"[steel_blue1]{_fmt_datetime(ev_end)}[/steel_blue1]")
        info_tbl.add_row("Duration", f"[grey62]{dur}[/grey62]")
        info_tbl.add_row("Comment", fmt_val(event.get("comment")))
        info_tbl.add_row("ID", f"[grey62]{event.get('id', '—')}[/grey62]")
        info_tbl.add_row("Created", f"[grey62]{_fmt_datetime(event.get('createdAt'))}[/grey62]")
        info_tbl.add_row("Updated", f"[grey62]{_fmt_datetime(event.get('updatedAt'))}[/grey62]")

        console.print(Panel(info_tbl, border_style="cyan", expand=False))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_event(
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Event title"),
    start: Optional[str] = typer.Option(None, "--start", "-s", help="Start datetime (YYYY-MM-DD HH:MM:SS)"),
    end: Optional[str] = typer.Option(None, "--end", "-e", help="End datetime (YYYY-MM-DD HH:MM:SS)"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c", help="Optional comment or description"),
):
    """
    Create a new calendar event. Prompts for missing fields.
    """
    console.print("\n[bold cyan]📅 Create Calendar Event[/bold cyan]\n")

    if not title:
        title = typer.prompt("  Title")
    if not start:
        default_start = datetime.now().replace(minute=0, second=0).strftime("%Y-%m-%d %H:%M:%S")
        start = typer.prompt("  Start (YYYY-MM-DD HH:MM:SS)", default=default_start)
    if not end:
        try:
            # Default end = start + 1 hour
            s = datetime.strptime(start[:19], "%Y-%m-%d %H:%M:%S")
            default_end = (s + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            default_end = start
        end = typer.prompt("  End (YYYY-MM-DD HH:MM:SS)", default=default_end)
    if not comment:
        comment_raw = typer.prompt("  Comment (optional)", default="")
        comment = comment_raw if comment_raw.strip() else None

    payload = {"title": title, "start": start, "end": end}
    if comment:
        payload["comment"] = comment

    try:
        client = KolayClient()
        print_fetching(f"Creating event '{title}'…")
        response = client.post("v2/event/create", data=payload)
        data = response.get("data", {})
        new_id = data.get("id", "—") if isinstance(data, dict) else "—"
        dur = _duration(start, end)
        print_success(
            f"Event created! [grey62]{short_id(new_id)}[/grey62]  "
            f"[bold white]{title}[/bold white]  "
            f"[steel_blue1]{_fmt_datetime(start)}[/steel_blue1]  "
            f"[grey62]({dur})[/grey62]"
        )
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_event(
    event_id: str = typer.Argument(..., help="ID of the event to update"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="New title"),
    start: Optional[str] = typer.Option(None, "--start", "-s", help="New start datetime (YYYY-MM-DD HH:MM:SS)"),
    end: Optional[str] = typer.Option(None, "--end", "-e", help="New end datetime (YYYY-MM-DD HH:MM:SS)"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c", help="New comment"),
):
    """
    Update a calendar event. Fetches current values and lets you edit.
    """
    try:
        client = KolayClient()

        # Fetch current event
        print_fetching(f"Fetching event {event_id}…")
        response = client.get(f"v2/event/view/{safe_id(event_id)}")
        event = response.get("data", {})
        if not event:
            print_error(f"Event '{event_id}' not found.", hint="Run 'kolay calendar list' to find valid IDs.")
            return

        cur_title = event.get("title", "")
        cur_start = event.get("start", "")
        cur_end = event.get("end", "")
        cur_comment = event.get("comment", "")

        console.print(f"\n[bold cyan]📅 Update Event:[/bold cyan] [bold white]{cur_title}[/bold white]\n")

        # If no flags provided, go interactive
        if not any([title, start, end, comment]):
            title = typer.prompt("  Title", default=cur_title)
            start = typer.prompt("  Start", default=cur_start)
            end = typer.prompt("  End", default=cur_end)
            comment_raw = typer.prompt("  Comment", default=cur_comment or "")
            comment = comment_raw

        payload = {
            "title": title or cur_title,
            "start": start or cur_start,
            "end": end or cur_end,
            "comment": comment if comment is not None else cur_comment,
        }

        print_fetching("Saving changes…")
        client.put(f"v2/event/update/{safe_id(event_id)}", data=payload)
        print_success(f"Event updated: [bold white]{payload['title']}[/bold white]")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete")
def delete_event(event_id: str = typer.Argument(..., help="ID of the event to delete")):
    """
    Delete a calendar event.
    """
    try:
        client = KolayClient()

        # Show the event first so user knows what they're deleting
        try:
            response = client.get(f"v2/event/view/{safe_id(event_id)}")
            event = response.get("data", {})
            title = event.get("title", event_id)
            ev_start = _fmt_datetime(event.get("start", ""))
        except APIError:
            title = event_id
            ev_start = ""

        confirm_msg = f"Delete '[bold white]{title}[/bold white]'"
        if ev_start:
            confirm_msg += f" on [steel_blue1]{ev_start}[/steel_blue1]"
        confirm_msg += "?"
        console.print(f"\n  {confirm_msg}")
        typer.confirm("  Proceed", abort=True)

        print_fetching("Deleting event…")
        client.delete(f"v2/event/delete/{safe_id(event_id)}")
        print_success(f"Event '[bold white]{title}[/bold white]' deleted.")

    except typer.Abort:
        console.print("[grey62]  Cancelled.[/grey62]\n")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
