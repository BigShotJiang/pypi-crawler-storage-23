import typer
from rich.panel import Panel
from rich.table import Table

from ..config import set_config_value, get_api_token
from ..api import KolayClient, APIError
from ..ui import console, print_error, print_success, kv_table

app = typer.Typer(help="Authentication commands for the Kolay CLI.")


@app.command()
def login(token: str = typer.Option(..., prompt="Kolay API token", hide_input=True)):
    """
    Save your Kolay API token and verify it against the API.
    """
    set_config_value("api_token", token)
    try:
        client = KolayClient(token=token)
        response = client.get("v2/profile/me")
        data = response.get("data", {})
        first_name = data.get("firstName", "")
        last_name = data.get("lastName", "")
        console.print(f"\n[bold green]✔ Logged in as [bold white]{first_name} {last_name}[/bold white][/bold green]\n")
    except APIError:
        console.print("\n[orange1]  Token saved, but could not verify it against the API.[/orange1]")
        console.print("[grey62]  → Make sure the token is correct and not expired.[/grey62]\n")


@app.command()
def status():
    """
    Check if you are currently logged in and show your profile.
    """
    token = get_api_token()
    if not token:
        print_error(
            "You are not logged in.",
            hint="Run 'kolay auth login' to set your API token."
        )
        return
    try:
        client = KolayClient(token=token)
        response = client.get("v2/profile/me")
        data = response.get("data", {})
        first_name = data.get("firstName", "")
        last_name = data.get("lastName", "")
        work_email = data.get("workEmail") or data.get("email") or "—"
        console.print(f"\n[bold green]● Logged in[/bold green]  [bold white]{first_name} {last_name}[/bold white]  [grey62]{work_email}[/grey62]\n")
    except APIError:
        console.print(f"\n[orange1]Token exists but API verification failed.[/orange1]")
        console.print("[grey62]  → Token may be expired. Run 'kolay auth login' to refresh.[/grey62]\n")


@app.command()
def me():
    """
    Show the profile of the currently authenticated user.
    """
    try:
        client = KolayClient()
        response = client.get("v2/profile/me")
        data = response.get("data", {})

        first_name = data.get("firstName", "")
        last_name = data.get("lastName", "")
        full_name = f"{first_name} {last_name}".strip()

        console.print(f"\n[bold cyan]My Profile[/bold cyan]  [bold white]{full_name}[/bold white]\n")
        tbl = kv_table(data)
        console.print(Panel(tbl, border_style="cyan", expand=False))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
