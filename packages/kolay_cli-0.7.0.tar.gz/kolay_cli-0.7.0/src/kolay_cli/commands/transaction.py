import typer
from typing import Optional
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, display_status, fmt_val, fmt_num, label,
    print_error, print_success, print_fetching, print_empty, kv_table
)

app = typer.Typer(help="Manage transactions (advances, bonuses, overtime, etc.) in Kolay.")

TRANSACTION_TYPES = [
    "advancePayment",
    "overtime",
    "bonus",
    "premium",
    "otherCut",
    "militaryBenefit",
    "nationalHolidayBenefit",
    "fuelAllowanceBenefit",
]

CURRENCIES = ["TL", "USD", "EUR", "GBP", "AZN", "AED", "JPY", "SGD", "RUB", "THB", "CNH", "KRW", "AUD"]


@app.command(name="list")
def list_transactions(
    page: int = typer.Option(1, help="Page number"),
    person_id: Optional[str] = typer.Option(None, "--person-id", help="Filter by person ID"),
    type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type (e.g. advancePayment, bonus)"),
    status: Optional[str] = typer.Option(None, "--status", help="Filter by status: waiting, approved, rejected"),
    limit: int = typer.Option(20, help="Number of records to return"),
):
    """
    List transactions. Defaults to all types, all statuses.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching transactions (page {page})…")

        payload = {
            "page": page,
            "limit": limit,
            "startDate": "2000-01-01",
            "endDate": "2100-12-31",
        }
        if person_id:
            payload["personId"] = person_id
        if type:
            payload["type"] = type
        if status:
            payload["status"] = status

        response = client.post("v2/transaction/list", data=payload)
        data_block = response.get("data", {})
        items = data_block.get("items", []) if isinstance(data_block, dict) else (data_block if isinstance(data_block, list) else [])
        total = data_block.get("totalCount", len(items)) if isinstance(data_block, dict) else len(items)

        if not items:
            print_empty("transactions", hint="Try a different --type or --status filter.")
            return

        table = Table(title="Transactions", header_style="bold cyan", border_style="cyan")
        table.add_column("#", style="grey62", width=4, justify="right")
        table.add_column("Short ID", style="grey62", no_wrap=True)
        table.add_column("Person", style="bold white")
        table.add_column("Type", style="steel_blue1")
        table.add_column("Amount", justify="right", style="bold white")
        table.add_column("Date", style="grey62")
        table.add_column("Status", justify="center")

        for i, trx in enumerate(items, start=(page - 1) * limit + 1):
            tid = str(trx.get("id", ""))
            person = trx.get("person", {})
            if isinstance(person, dict):
                person_name = f"{person.get('firstName', '')} {person.get('lastName', '')}".strip() or "—"
            else:
                person_name = str(trx.get("personId", "—"))
            trx_type = trx.get("type", "—")
            amount = f"{fmt_num(trx.get('amount', 0))} {trx.get('currency', 'TL')}"
            date = (trx.get("date") or "—")[:10]
            st = display_status(trx.get("status", ""))
            table.add_row(str(i), short_id(tid), person_name, trx_type, amount, date, st)

        console.print(table)
        shown = min(page * limit, total)
        start_n = (page - 1) * limit + 1
        console.print(f"[grey62]  Page {page} · Showing {start_n}–{shown} of {total} transactions[/grey62]\n")

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="view")
def view_transaction(transaction_id: str = typer.Argument(..., help="ID of the transaction to view")):
    """
    View details of a specific transaction.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching transaction {transaction_id}…")
        response = client.get(f"v2/transaction/view/{safe_id(transaction_id)}")

        trx = response.get("data", {})
        if not trx:
            print_error(f"Transaction '{transaction_id}' not found.", hint="Run 'kolay transaction list' to find valid IDs.")
            return

        trx_type = trx.get("type", "—")
        st = display_status(trx.get("status", ""))
        console.print(f"\n[bold cyan]Transaction[/bold cyan]  [bold white]{trx_type}[/bold white]  {st}\n")

        display = {k: v for k, v in trx.items() if k not in ("person", "items", "type", "status") and not isinstance(v, (dict, list))}
        tbl = kv_table(display)
        console.print(Panel(tbl, title="Details", border_style="cyan", expand=False))

        # Sub-items (for expense transactions)
        sub_items = trx.get("items", [])
        if sub_items:
            si_tbl = Table(title="Line Items", header_style="bold cyan", box=None, padding=(0, 2, 0, 0))
            si_tbl.add_column("Name", style="grey85")
            si_tbl.add_column("Amount", justify="right", style="bold white")
            si_tbl.add_column("VAT %", justify="right", style="grey62")
            for si in sub_items:
                si_tbl.add_row(
                    si.get("name") or "—",
                    fmt_num(si.get("amount")),
                    fmt_num(si.get("vatRate")),
                )
            console.print(Panel(si_tbl, border_style="steel_blue1"))

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete")
def delete_transaction(transaction_id: str = typer.Argument(..., help="ID of the transaction to delete")):
    """
    Delete a specific transaction.
    """
    try:
        client = KolayClient()
        confirm = typer.confirm(f"Delete transaction {transaction_id}?", abort=True)
        print_fetching(f"Deleting transaction {transaction_id}…")
        client.delete(f"v2/transaction/delete/{safe_id(transaction_id)}")
        print_success("Transaction deleted.")
    except typer.Abort:
        console.print("[grey62]Cancelled.[/grey62]")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_transaction(
    person_id: str = typer.Option(..., "--person-id", "-p", help="ID of the person"),
    type: str = typer.Option(..., "--type", "-t", help=f"Type: {', '.join(TRANSACTION_TYPES)}"),
    amount: str = typer.Option(..., "--amount", "-a", help="Amount (must be ≥ 1)"),
    currency: str = typer.Option("TL", "--currency", "-c", help=f"Currency ({', '.join(CURRENCIES)})"),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date (YYYY-MM-DD). Defaults to today."),
    description: Optional[str] = typer.Option(None, "--desc", help="Optional description (max 255 chars)"),
    installment_plan: Optional[str] = typer.Option(None, "--installments", help="Installment plan (required for advancePayment)"),
    status: str = typer.Option("waiting", "--status", help="Initial status: waiting, approved, rejected"),
):
    """
    Create a new transaction (advance payment, bonus, overtime, etc.).
    """
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    if type not in TRANSACTION_TYPES:
        print_error(
            f"'{type}' is not a valid transaction type.",
            hint=f"Valid types: {', '.join(TRANSACTION_TYPES)}"
        )
        raise typer.Exit(1)

    if currency not in CURRENCIES:
        print_error(
            f"'{currency}' is not a valid currency.",
            hint=f"Valid currencies: {', '.join(CURRENCIES)}"
        )
        raise typer.Exit(1)

    payload = {
        "personId": person_id,
        "type": type,
        "amount": amount,
        "currency": currency,
        "date": date,
        "status": status,
        "isGross": False,
        "paid": False,
        "affectPayroll": False,
    }
    if description:
        payload["description"] = description
    if type == "advancePayment":
        if not installment_plan:
            installment_plan = typer.prompt("Installment plan (e.g. 1, 3, 6)", default="1")
        payload["installmentPlan"] = installment_plan

    try:
        client = KolayClient()
        print_fetching(f"Creating {type} transaction for person {person_id}…")
        client.post("v2/transaction/create", data=payload)
        print_success(f"{type} transaction of {amount} {currency} created.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
