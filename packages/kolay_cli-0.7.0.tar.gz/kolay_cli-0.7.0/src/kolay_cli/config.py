import json
import os
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".config" / "kolay"
CONFIG_FILE = CONFIG_DIR / "config.json"


def get_config_value(key: str) -> Optional[str]:
    """Get a value from the config file or environment variables."""
    # Environment variables take precedence over the config file
    env_val = os.getenv(f"KOLAY_{key.upper()}")
    if env_val:
        return env_val

    if not CONFIG_FILE.exists():
        return None

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get(key)
    except (json.JSONDecodeError, OSError):
        return None


def set_config_value(key: str, value: str) -> None:
    """Set a value in the config file and ensure restricted permissions (0o600)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            data = {}

    data[key] = value

    # Write atomically with restricted permissions from the start.
    # Using os.open() with O_CREAT ensures the file is created as 0o600
    # (owner read/write only) before any data is written — no window where
    # another user could read a world-readable file before chmod runs.
    fd = os.open(CONFIG_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def get_api_token() -> Optional[str]:
    return get_config_value("api_token")


def get_base_url() -> str:
    return get_config_value("base_url") or "https://api.kolayik.com"
