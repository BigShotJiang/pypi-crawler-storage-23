import re
import requests
from typing import Dict, Any, Optional

from . import config

# IDs from Kolay API are 32-char hex strings. Accept hex + basic alphanum.
_SAFE_ID_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

class APIError(Exception):
    pass


def safe_id(value: str, label: str = "ID") -> str:
    """Validate a user-supplied ID before it is interpolated into a URL path.
    Rejects path traversal characters, empty strings, and non-alphanum values."""
    if not value or not value.strip():
        raise APIError(f"{label} cannot be empty.")
    value = value.strip()
    if not _SAFE_ID_RE.match(value):
        raise APIError(f"Invalid {label}: contains illegal characters.")
    return value

class KolayClient:
    def __init__(self, token: Optional[str] = None, base_url: Optional[str] = None):
        self.token = token or config.get_api_token()
        self.base_url = (base_url or config.get_base_url()).rstrip("/")

        if not self.token:
            raise APIError("API token is required. Please set it using 'kolay auth login' or the KOLAY_API_TOKEN environment variable.")

        # Enforce HTTPS to prevent accidental plaintext credential exposure
        if not self.base_url.startswith("https://"):
            raise APIError("Base URL must use HTTPS. Check your KOLAY_BASE_URL setting.")

        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Accept-Language": "en"
        })

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("GET", endpoint, params=params)

    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("POST", endpoint, json=data)

    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("PUT", endpoint, json=data)

    def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("DELETE", endpoint, params=params)

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        # Reject path traversal attempts in the endpoint
        if ".." in endpoint or endpoint.startswith("/") or "://" in endpoint:
            raise APIError("Invalid API endpoint.")
        url = f"{self.base_url}/{endpoint}"
        
        try:
            response = self.session.request(method, url, timeout=30, **kwargs)
            response.raise_for_status()
            if response.content:
                return response.json()
            return {}
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code
            from .ui import HTTP_ERRORS
            # Try to get the API's own message
            api_msg = None
            try:
                error_data = e.response.json()
                api_msg = (
                    error_data.get("message")
                    or error_data.get("error")
                    or None
                )
            except (ValueError, KeyError):
                pass
            # For 422, prefer the API message (already in EN via Accept-Language: en)
            if status_code == 422 and api_msg:
                raise APIError(api_msg)
            # Fall back to our own friendly messages
            friendly = HTTP_ERRORS.get(status_code)
            if friendly:
                raise APIError(friendly)
            # Last resort: use API message or raw status
            raise APIError(api_msg or f"Unexpected error (HTTP {status_code}).")
        except requests.exceptions.ConnectionError:
            raise APIError("Could not connect to the Kolay API. Check your internet connection.")
        except requests.exceptions.Timeout:
            raise APIError("The request timed out. Try again in a moment.")
        except Exception as e:
            raise APIError(f"Unexpected error: {str(e)}")
