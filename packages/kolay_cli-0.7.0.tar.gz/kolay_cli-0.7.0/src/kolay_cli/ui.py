"""
Shared UI utilities for kolay-cli.
Single source of truth for colors, labels, formatting, and error display.
"""
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

# ---------------------------------------------------------------------------
# Color Palette — enforced across all modules
# NEVER put yellow + blue / cyan on the same screen
# ---------------------------------------------------------------------------
# primary   : bold cyan      — section titles, panel borders, table titles
# secondary : bold magenta   — person names, highlights
# accent    : bold white     — values next to labels
# success   : bold green     — success messages, active/approved
# danger    : bold red       — errors, rejected
# warning   : orange1        — replaces yellow for warnings/waiting
# info      : steel_blue1    — replaces plain blue for secondary info
# muted     : grey62         — N/A, timestamps, short IDs

STATUS_STYLES = {
    "active":    "[green]● Active[/green]",
    "inactive":  "[red]○ Inactive[/red]",
    "approved":  "[green]✔ Approved[/green]",
    "waiting":   "[orange1]⏳ Waiting[/orange1]",
    "rejected":  "[red]✘ Rejected[/red]",
    "cancelled": "[grey62]⊘ Cancelled[/grey62]",
    "pending":   "[orange1]⏳ Pending[/orange1]",
}

FIELD_LABELS = {
    "id":                    "ID",
    "firstName":             "First Name",
    "lastName":              "Last Name",
    "name":                  "Name",
    "workEmail":             "Work Email",
    "email":                 "Email",
    "mobilePhone":           "Phone",
    "birthday":              "Birthday",
    "gender":                "Gender",
    "idNumber":              "ID Number",
    "employmentStartDate":   "Start Date",
    "status":                "Status",
    "createdAt":             "Created",
    "updatedAt":             "Updated",
    "amount":                "Amount",
    "currency":              "Currency",
    "date":                  "Date",
    "type":                  "Type",
    "installmentPlan":       "Installments",
    "description":           "Description",
    "paid":                  "Paid",
    "isGross":               "Gross",
    "affectPayroll":         "Affects Payroll",
    "personId":              "Person ID",
    "startDate":             "Start Date",
    "endDate":               "End Date",
    "leaveTypeId":           "Leave Type ID",
    "reasonCode":            "Reason Code",
    "details":               "Details",
    "isPaid":                "Paid Leave",
    "dayLimit":              "Day Limit",
    "used":                  "Days Used",
    "totalUpcoming":         "Upcoming",
    "unused":                "Remaining",
    "nextAccrualDate":       "Next Accrual",
    "primary":               "Primary",
}

HTTP_ERRORS = {
    400: "Bad request — please check your input.",
    401: "Not authorized. Run 'kolay auth login' to set your API token.",
    403: "You don't have permission to perform this action.",
    404: "Not found. Double-check the ID and try again.",
    429: "You're being rate-limited. Slow down and try again in a moment.",
    500: "Kolay API returned a server error. Try again later.",
    503: "Kolay API is temporarily unavailable. Try again later.",
}


def short_id(full_id: str) -> str:
    """Return a displayed short version of a UUID (last 8 chars, dimmed)."""
    if not full_id or full_id == "N/A":
        return "[grey62]—[/grey62]"
    clean = str(full_id)
    return f"[grey62]…{clean[-8:]}[/grey62]" if len(clean) > 8 else f"[grey62]{clean}[/grey62]"


def display_status(status: str) -> str:
    """Return a formatted, icon-prefixed status badge."""
    if not status:
        return "[grey62]—[/grey62]"
    return STATUS_STYLES.get(str(status).lower(), f"[white]{status}[/white]")


def fmt_val(val) -> str:
    """Format a value for display — handle None, bool, empty string."""
    if val is None or val == "" or val == "N/A":
        return "[grey62]—[/grey62]"
    if isinstance(val, bool):
        return "[green]Yes[/green]" if val else "[red]No[/red]"
    return str(val)


def fmt_num(val) -> str:
    """Format a numeric value, removing .0 suffix."""
    if val is None:
        return "[grey62]—[/grey62]"
    try:
        f = float(val)
        return str(int(f)) if f == int(f) else str(f)
    except (ValueError, TypeError):
        return str(val)


def label(key: str) -> str:
    """Convert a camelCase API key to a human-readable label."""
    return FIELD_LABELS.get(key, key.replace("_", " ").title())


def print_error(msg: str, hint: str = None):
    """Print a clean, user-friendly error message."""
    # Strip redundant "API Error: " prefix if present
    clean = msg
    for prefix in ("API Error: API Error:", "API Error:", "Request failed:"):
        if clean.startswith(prefix):
            clean = clean[len(prefix):].strip()
            break
    console.print(f"\n[bold red]✘ Error:[/bold red] {clean}")
    if hint:
        console.print(f"  [grey62]→ {hint}[/grey62]")
    console.print()


def print_success(msg: str):
    """Print a clean success message."""
    console.print(f"[bold green]✔ Success:[/bold green] {msg}")


def print_fetching(msg: str):
    """Print a dim fetching/loading message."""
    console.print(f"[grey62]{msg}[/grey62]")


def print_empty(entity: str, hint: str = None):
    """Print a context-aware empty-state message."""
    console.print(f"\n[grey62]No {entity} found.[/grey62]")
    if hint:
        console.print(f"  [grey62]→ {hint}[/grey62]\n")


def kv_table(data: dict, exclude: list = None) -> Table:
    """Build a clean key-value panel table from a dict."""
    exclude = exclude or []
    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
    table.add_column("Key", style="grey85", no_wrap=True, min_width=16)
    table.add_column("Value")
    for k, v in data.items():
        if k in exclude or isinstance(v, (dict, list)):
            continue
        table.add_row(label(k), fmt_val(v))
    return table
