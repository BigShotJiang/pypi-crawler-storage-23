"""Gateway — FastAPI server providing REST API and WebSocket for the UI."""
