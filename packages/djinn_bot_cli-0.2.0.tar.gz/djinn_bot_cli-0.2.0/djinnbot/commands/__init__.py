"""Djinnbot CLI commands package."""
