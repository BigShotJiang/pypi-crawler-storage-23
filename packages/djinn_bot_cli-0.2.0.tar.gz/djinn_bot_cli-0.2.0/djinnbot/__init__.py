"""Djinnbot CLI - Python CLI for the event-driven agent orchestration framework."""

__version__ = "0.2.0"
