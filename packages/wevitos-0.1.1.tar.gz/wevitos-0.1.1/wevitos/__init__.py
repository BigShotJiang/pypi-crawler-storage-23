from wevitos.client import init, notify, _client

__all__ = ['init', 'notify']
