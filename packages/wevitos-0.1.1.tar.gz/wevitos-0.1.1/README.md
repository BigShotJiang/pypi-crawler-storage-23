# Wevitos

Lightweight error tracking for Python/Django apps. Captures unhandled exceptions with full stacktraces, request data, and user info — then sends them to [wevitos.com](https://wevitos.com).

Zero external dependencies. Uses only Python stdlib.

## Installation

```bash
pip install wevitos
```

## Quick Setup (Django)

1. Get your API key from [wevitos.com/dashboard](https://wevitos.com/dashboard) — create a project and copy the token.

2. Add to your `settings.py`:

```python
import wevitos

wevitos.init(
    api_key='YOUR_API_KEY',
    environment='production',  # or 'staging', 'development', etc.
)

MIDDLEWARE += ['wevitos.middleware.WevitosMiddleware']
```

That's it. Unhandled exceptions in your views will be captured automatically.

## Manual Error Reporting

You can also report errors manually anywhere in your code:

```python
import wevitos

try:
    risky_operation()
except Exception as e:
    wevitos.notify(e, extra={'user_id': 123, 'action': 'checkout'})
```

## What Gets Captured

- Exception class, message, and full stacktrace with source context (5 lines before/after)
- Request data: method, URL, headers (cookies and auth headers are excluded)
- User info: user ID and email (if authenticated)
- Server name, environment, and release version
- Any extra metadata you pass via `wevitos.notify()`

## Configuration Options

```python
wevitos.init(
    api_key='YOUR_API_KEY',       # Required — from wevitos.com
    environment='production',      # Optional — tags errors by environment
    release='1.2.3',               # Optional — your app version
    app_root='/app',               # Optional — filters stacktrace to your code
)
```

## How It Works

- Errors are sent asynchronously in a background daemon thread — zero impact on your app's response time.
- If the Wevitos server is unreachable, errors are silently dropped (your app is never affected).
- Errors are grouped by a fingerprint based on exception class + file + function + line number.
- Duplicate errors increment the count instead of creating noise.

## Get Your API Key

1. Go to [wevitos.com](https://wevitos.com) and log in
2. Create a project (or select an existing one)
3. Copy the API key from the project setup page
4. Paste it in your `wevitos.init()` call

## Links

- Dashboard: [wevitos.com](https://wevitos.com)
- PyPI: [pypi.org/project/wevitos](https://pypi.org/project/wevitos/)
- Source: [github.com/xzitlou/wevitos](https://github.com/xzitlou/wevitos)
