Dataset Extras
==============

In addition to the L1 science frames, each DL-NIRSP dataset includes a collection of "dataset extras", which are described in detail on this page.

**NOTE:** The primary purpose of dataset extras is to provide a common context between the user and the DKIST Data Center
when discussing issues seen in the L1 data. Any user who uses dataset extras for analysis or inferring properties of the L1
data does so *at their own risk*. **Support for the dataset extras as useful end-user data is not guaranteed.**

Location and Naming
-------------------

All dataset extras are included with a full download of the main dataset and live in a subdirectory called "extra". The
general naming scheme is

`DLNIRSP_{DATASET_ID}_{NAME}_{DETAIL}_{COUNTER}.fits`

with

DATASET_ID
    The dataset ID of the current dataset. Matches the same value in the names of L1 files.

NAME
    The identifier of the current extra. See the list below.

DETAIL
    Some Dataset Extras use extra detail in their filenames where multiple files of the same type are provided with
    a property that changes. This can be found in the Dark and Polcal-as-Science Dataset Extras (see their description
    below for more information).

COUNTER
    A counter that starts from 1. Allows for multiple extras of the same type, although this is very rare.

Headers
-------

All dataset extra files have headers that conform to the `Dataset Extras FITS Specification <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#>`_.
Please see that page for a complete list of header keys and their meanings. Note that, apart from the
`DL-NIRSP <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#dl-nirsp-keywords>`_ table,
not all extras will have all header keys; the specific tables that apply to each extra are listed below.

Shape differences between Dataset Extras and L1 files
-----------------------------------------------------
The DL-NIRSP is an Integral Field Unit (IFU) fed spectropolarimeter and so the L1 data is re-mapped from 2D data
observed by the instrument (x and y dimensions along the CCD chip) to 3D data (solar longitude, solar latitude,
wavelength) for scientific use. The Dataset Extras are left in their 2D form (with the exception of the bad pixel map,
see below) to facilitate their use in finding and resolving possible calibration issues due to bad data or bugs in
the data processing pipeline.

List of Dataset Extras
----------------------

The values of this list correspond to the "NAME" field mentioned above.

BAD-PIXEL-MAP
    The frame that identifies bad pixels in L1 data. The bad pixel data is re-mapped in the same way as L1
    science data so it can be used to determine bad pixel in the L1 frames directly. It is produced by the
    `~dkist_processing_dlnirsp.tasks.bad_pixel_map` task. See :doc:`here </bad_pixel_calibration>` for more info. The
    file is a cube with shape matching that of the L1 data.
    **Header tables** `Common`_, `Aggregate`_, `GOS`_

DARK
    The average dark frame used to correct all other frames. The result of the `~dkist_processing_dlnirsp.tasks.dark` task.
    This extra also includes a `EXP_TIME_{VALUE}` part of the filename that corresponds to the sensor exposure
    time of the given dark. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

SOLAR-GAIN
    The average solar gain/flat array used to correct science data, with solar spectrum removed. The result of the
    `~dkist_processing_dlnirsp.tasks.solar` task. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

CHARACTERISTIC-SPECTRA
    The measured characteristic solar spectra that are removed from raw solar gain frames to produce the SOLAR-GAIN frames.
    The shape of the file is determined by the number of IFU groups.
    See :doc:`here </gain>` for more info. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

SPECTRAL-CURVATURE-SHIFTS
    The pixel shift in the dispersion direction to apply to each spatial pixel to align all spectra to the same
    relative wavelength grid. The data array is of the shape `(N, M)` where `N` is the number of IFU groups and `M` is
    the number of spatial pixels in each group. Some groups are smaller than others so each row is `NaN`-padded to be
    the same length as the longest group.
    See :doc:`here </geometric>` for more information. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

SPECTRAL-CURVATURE-SCALES
    The pixel scale in the dispersion direction to apply to each spatial pixel to align all spectra to the same
    relative wavelength grid. The data array is of the shape `(N, M)` where `N` is the number of IFU groups and `M` is
    the number of spatial pixels in each group. Some groups are smaller than others so each row is `NaN`-padded to be
    the same length as the longest group.
    See :doc:`here </geometric>` for more information. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

WAVELENGTH-CALIBRATION-INPUT-SPECTRUM
    Representative solar spectrum (derived from the solar gain images) used to compute the absolute wavelength solution.
    See :doc:`here </wavelength_calibration>` for more information. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

WAVELENGTH-CALIBRATION-REFERENCE-SPECTRUM
    The best-fit combination of Solar and telluric atlases. See :doc:`here </wavelength_calibration>` for more information.
    **Header tables**: `Common`_, `Atlas`_

REFERENCE-WAVELENGTH-VECTOR
    Wavelength abscissa for both the input and best-fit atlas spectra. Units are nanometers.
    **Header tables**: `Common`_, `Wavecal`_

DEMODULATION-MATRICES
    Arrays used to demodulate science data. Each has shape `(2048, 2048, 4, 8)`; the first two axes represent the chip
    size of the detector and the last two correspond to Stokes dimension and modulation state, respectively.
    See :doc:`here </polarization_calibration>` for more information. **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_

POLCAL-AS-SCIENCE
    The INPUT POLCAL task-type frames processed as if they were science frames. Files are provided for each stokes state
    for each `Calibration Sequence <https://docs.dkist.nso.edu/projects/pac/en/stable/background.html#the-rol-of-polcal-data>`_
    step, and if multiple frames per CS step are recorded they will also be provided. The polcal-as-science filenames
    will reference these properties in their filenames with the language
    `CS_STEP_{VALUE}_CS_STEP_FRAME_{VALUE}_{STOKES}` These POLCAL frames are processed in
    :doc:`exactly the same way </science_calibration>` as science frames.
    **Header tables**: `Common`_, `IPTASK`_, `GOS`_, `PCAS`_

.. _Common: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#common-keywords
.. _Aggregate: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#aggregate-keywords
.. _IPTASK: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#iptask-keywords
.. _GOS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#gos-configuration-keywords
.. _Wavecal: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#wavelength-calibration-keywords
.. _Atlas: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#atlas-keywords
.. _PCAS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#pcas-keywords
