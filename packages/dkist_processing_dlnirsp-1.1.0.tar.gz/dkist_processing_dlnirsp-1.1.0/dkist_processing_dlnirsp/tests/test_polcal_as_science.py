from typing import Type

import numpy as np
import pytest
from dkist_data_simulator.spec122 import Spec122Dataset
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_dlnirsp.models.constants import DlnirspConstants
from dkist_processing_dlnirsp.models.tags import DlnirspTag
from dkist_processing_dlnirsp.tasks.polcal_as_science import DlnirspPCASConstants
from dkist_processing_dlnirsp.tasks.polcal_as_science import PolcalAsScienceCalibration
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingConstants
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingParameters
from dkist_processing_dlnirsp.tests.conftest import write_calibration_sequence_frames
from dkist_processing_dlnirsp.tests.conftest import write_dark_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_geometric_calibration_to_task
from dkist_processing_dlnirsp.tests.conftest import write_simple_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_solar_gain_frames_to_task


@pytest.fixture
def polcal_obs_time() -> float:
    return 2.0


@pytest.fixture
def dark_signal() -> float:
    return 100.0


@pytest.fixture
def clear_signal() -> float:
    return 200.0


@pytest.fixture
def solar_signal() -> float:
    return 2000.0


@pytest.fixture
def frames_per_cs_step() -> int:
    return 2


@pytest.fixture
def make_dark_data(dark_signal):
    def make_array(frame: Spec122Dataset):
        shape = frame.array_shape[1:]
        return np.ones(shape) * dark_signal

    return make_array


@pytest.fixture
def make_solar_data(solar_signal):
    def make_array(frame: Spec122Dataset):
        shape = frame.array_shape[1:]
        return np.ones(shape) * solar_signal

    return make_array


@pytest.fixture
def pcas_constants(num_slits) -> Type[DlnirspConstants]:
    class PCASConstantsClass(DlnirspPCASConstants):
        @property
        def num_slits(self) -> int:
            return num_slits

    return PCASConstantsClass


@pytest.fixture
def polcal_as_science_task(
    recipe_run_id,
    link_constants_db,
    jband_static_bad_pix_array,
    tmp_path,
    assign_input_dataset_doc_to_task,
    jband_ifu_x_pos_array,
    polcal_obs_time,
    make_dark_data,
    make_solar_data,
    shifts_and_scales,
    reference_wave_axis,
    jband_ifu_y_pos_array,
    write_drifted_group_ids_to_task,
    constants_class_with_different_num_slits,
    make_full_demodulation_matrix,
    small_calibration_sequence,
    dark_signal,
    clear_signal,
    pcas_constants,
    frames_per_cs_step,
):
    link_constants_db(
        recipe_run_id=recipe_run_id,
        constants_obj=DlnirspTestingConstants(NUM_FRAMES_PER_CS_STEP=frames_per_cs_step),
    )
    with PolcalAsScienceCalibration(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        parameters = DlnirspTestingParameters()
        assign_input_dataset_doc_to_task(
            task,
            parameters,
        )
        task.constants = pcas_constants(recipe_run_id=recipe_run_id, task_name="test")
        array_shape = jband_ifu_x_pos_array.shape
        task.write(
            data=jband_static_bad_pix_array.astype(np.int8),
            tags=[DlnirspTag.intermediate_frame(), DlnirspTag.task_bad_pixel_map()],
            encoder=fits_array_encoder,
        )
        write_dark_frames_to_task(
            task,
            array_shape=array_shape,
            exp_time_ms=polcal_obs_time,
            tags=[
                DlnirspTag.intermediate(),
                DlnirspTag.task_dark(),
                DlnirspTag.exposure_time(polcal_obs_time),
            ],
            data_func=make_dark_data,
        )
        write_solar_gain_frames_to_task(
            task,
            array_shape=array_shape,
            num_modstates=1,
            tags=[
                DlnirspTag.intermediate(),
                DlnirspTag.task_solar_gain(),
            ],
            data_func=make_solar_data,
        )
        shift_dict, scale_dict, _, _ = shifts_and_scales
        write_geometric_calibration_to_task(
            task, shift_dict=shift_dict, scale_dict=scale_dict, wave_axis=reference_wave_axis
        )
        task.write(
            data=jband_ifu_x_pos_array,
            tags=[
                DlnirspTag.intermediate_frame(),
                DlnirspTag.task_drifted_ifu_x_pos(),
            ],
            encoder=fits_array_encoder,
        )
        task.write(
            data=jband_ifu_y_pos_array,
            tags=[
                DlnirspTag.intermediate_frame(),
                DlnirspTag.task_drifted_ifu_y_pos(),
            ],
            encoder=fits_array_encoder,
        )
        write_drifted_group_ids_to_task(task)
        write_simple_frames_to_task(
            task,
            task_type=TaskName.polcal.value,
            array_shape=array_shape,
            num_modstates=8,
            tags=[DlnirspTag.intermediate(), DlnirspTag.task_demodulation_matrices()],
            data_func=make_full_demodulation_matrix,
        )
        pol_status, pol_theta, ret_status, ret_theta, dark_status = small_calibration_sequence
        num_polcal_frames = write_calibration_sequence_frames(
            task=task,
            pol_status=pol_status,
            pol_theta=pol_theta,
            ret_status=ret_status,
            ret_theta=ret_theta,
            dark_status=dark_status,
            dark_signal=dark_signal,
            clear_signal=clear_signal,
            array_shape=array_shape,
            exp_time=polcal_obs_time,
            num_frames_per_cs_step=frames_per_cs_step,
            tags=[
                DlnirspTag.linearized(),
                DlnirspTag.exposure_time(polcal_obs_time),
                DlnirspTag.frame(),
                DlnirspTag.task_polcal(),
            ],
        )
        yield task, num_polcal_frames
        task._purge()


def test_polcal_as_science_task(polcal_as_science_task, mocker, fake_gql_client):
    """
    Given: A PolcalAsScienceCalibration task with tagged POLCAL frames and required intermediate data
    When: Running the task
    Then: The correct polcal-as-science products are made
    """
    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )
    task, num_polcal_frames = polcal_as_science_task
    task()
    for stokes in ["I", "Q", "U", "V"]:
        for cs_step in range(task.constants.num_cs_steps):
            for frame_in_cs_step in range(task.constants.num_frames_per_cs_step):
                files = list(
                    task.read(
                        tags=[
                            DlnirspTag.task(TaskName.polcal_as_science),
                            DlnirspTag.intermediate_frame(),
                            DlnirspTag.stokes(stokes),
                            DlnirspTag.cs_step_frame(frame_in_cs_step),
                            DlnirspTag.cs_step(cs_step),
                        ]
                    )
                )
                assert len(files) == 1
