"""Parsing Stems for answering time-related questions."""

import datetime
from typing import Callable
from typing import Type

from dkist_processing_common.models.fits_access import MetadataKey
from dkist_processing_common.models.flower_pot import SetStem
from dkist_processing_common.models.flower_pot import SpilledDirt
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.parsers.task import parse_header_ip_task_with_gains
from dkist_processing_common.parsers.task import passthrough_header_ip_task
from dkist_processing_common.parsers.time import TaskDatetimeBudBase
from dkist_processing_common.parsers.unique_bud import TaskUniqueBud

from dkist_processing_dlnirsp.models.constants import DlnirspBudName
from dkist_processing_dlnirsp.parsers.dlnirsp_l0_fits_access import DlnirspL0FitsAccess
from dkist_processing_dlnirsp.parsers.dlnirsp_l0_fits_access import DlnirspRampFitsAccess


class DLnirspSolarGainIpStartTimeBud(TaskUniqueBud):
    """Bud for finding the start time of the solar gain IP."""

    def __init__(self):
        super().__init__(
            constant_name=DlnirspBudName.solar_gain_ip_start_time.value,
            metadata_key=MetadataKey.ip_start_time,
            ip_task_types=TaskName.solar_gain.value,
            task_type_parsing_function=parse_header_ip_task_with_gains,
        )


class DlnirspTimeObsBud(SetStem):
    """
    Produce a tuple of all time_obs values present in the dataset.

    The time_obs is a unique identifier for all raw frames in a single ramp. Hence, this list identifies all
    the ramps that must be processed in a data set.
    """

    def __init__(self):
        super().__init__(stem_name=DlnirspBudName.time_obs_list.value)

    def setter(self, fits_obj: DlnirspRampFitsAccess) -> str:
        """
        Set the time_obs for this fits object.

        Parameters
        ----------
        fits_obj
            The input fits object

        Returns
        -------
        The time_obs value associated with this fits object
        """
        return fits_obj.time_obs

    def getter(self) -> tuple[str, ...]:
        """
        Get the list of time_obs values.

        Returns
        -------
        A tuple of exposure times
        """
        time_obs_tup = tuple(sorted(self.value_set))
        return time_obs_tup


class TaskDateEndBud(TaskDatetimeBudBase):
    """Class for the date end task Bud."""

    def __init__(
        self,
        constant_name: str,
        ip_task_types: str | list[str],
        task_type_parsing_function: Callable = passthrough_header_ip_task,
    ):
        super().__init__(
            stem_name=constant_name,
            metadata_key=MetadataKey.time_obs,
            ip_task_types=ip_task_types,
            task_type_parsing_function=task_type_parsing_function,
        )

    def setter(self, fits_obj: DlnirspL0FitsAccess) -> float | Type[SpilledDirt]:
        """
        Calculate the date end and store it as unix seconds if the task type is in the desired types.

        Parameters
        ----------
        fits_obj
            The input fits object
        Returns
        -------
        The datetime in seconds
        """
        # super().setter() returns date-begin in unix seconds
        date_beg = super().setter(fits_obj)
        if date_beg == SpilledDirt:
            return SpilledDirt
        exp_time = fits_obj.fpa_exposure_time_ms / 1000.0
        date_end = date_beg + exp_time
        return date_end

    def getter(self) -> str:
        """
        Return the latest date end for the ip task type converted from unix seconds to datetime string.

        Returns
        -------
        Return the maximum date end as a datetime string
        """
        # super().getter() returns a sorted list
        max_time = super().getter()[-1]
        max_time_dt = datetime.datetime.fromtimestamp(max_time, tz=datetime.timezone.utc)
        return max_time_dt.strftime("%Y-%m-%dT%H:%M:%S.%f")
