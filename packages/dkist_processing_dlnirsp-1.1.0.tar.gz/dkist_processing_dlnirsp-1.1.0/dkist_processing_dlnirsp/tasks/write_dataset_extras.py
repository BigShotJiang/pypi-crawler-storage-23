"""Transform data written in other pipeline tasks into dataset extras for delivery alongside L1 science data."""

from typing import Type

import numpy as np
from dkist_processing_common.codecs.asdf import asdf_decoder
from dkist_processing_common.codecs.fits import fits_array_decoder
from dkist_processing_common.codecs.json import json_decoder
from dkist_processing_common.models.constants import ConstantsBase
from dkist_processing_common.models.extras import DatasetExtraHeaderData
from dkist_processing_common.models.extras import DatasetExtraHeaderSection
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks.write_extra import WriteL1DatasetExtras
from kombu.utils import cached_property

from dkist_processing_dlnirsp.models.constants import DlnirspConstants
from dkist_processing_dlnirsp.models.fits_access import DlnirspMetadataKey
from dkist_processing_dlnirsp.models.parameters import DlnirspParameters
from dkist_processing_dlnirsp.models.tags import DlnirspTag


def stack_pad_right(values: list[np.ndarray], fill=np.nan, dtype=float):
    """
    Stack 1D arrays of different lengths into a 2D array by right-padding.

    If the input values is of length N, the output shape is (n, max_len)
    """
    values = [np.asarray(v) for v in values]
    n = len(values)
    max_len = max((v.size for v in values), default=0)

    result = np.full((n, max_len), fill, dtype=dtype)
    for i, v in enumerate(values):
        result[i, : v.size] = v

    return result


class DlnirspWriteL1DatasetExtras(WriteL1DatasetExtras):
    """Class supporting the construction of dataset extras."""

    @property
    def constants_model_class(self) -> Type[ConstantsBase]:
        """Supply the correct class, so we can access DL-NIRSP-specific constants."""
        return DlnirspConstants

    def __init__(self, recipe_run_id: int, workflow_name: str, workflow_version: str):
        super().__init__(
            recipe_run_id=recipe_run_id,
            workflow_name=workflow_name,
            workflow_version=workflow_version,
        )

        # Here's where we get parameters right
        self.parameters = DlnirspParameters(
            scratch=self.scratch,
            obs_ip_start_time=self.constants.obs_ip_start_time,
            wavelength=self.constants.wavelength,
            arm_id=self.constants.arm_id,
        )

    def run(self) -> None:
        """Define dataset extras and write to disk."""
        # Grab the geometric data for use in the creation of some extras
        geometric_dict: dict[str, dict] = next(
            self.read(
                tags=[DlnirspTag.intermediate(), DlnirspTag.task_geometric()], decoder=asdf_decoder
            )
        )
        # Make the extras
        self.write_bad_pixel_map_dataset_extra()
        self.write_dark_dataset_extra()
        self.write_solar_gain_dataset_extra()
        self.write_characteristic_spectrum_dataset_extra()
        self.write_spectral_curvature_shifts_dataset_extra(geometric_dict=geometric_dict)
        self.write_spectral_curvature_scales_dataset_extra(geometric_dict=geometric_dict)
        self.write_wavelength_calibration_input_spectrum_dataset_extra()
        self.write_wavelength_calibration_reference_spectrum_dataset_extra()
        self.write_wavelength_calibration_reference_wavelength_vector_dataset_extra()
        if self.constants.correct_for_polarization:
            self.write_demodulation_matrices_dataset_extra()
            self.write_polcal_as_science_dataset_extra()

    @cached_property
    def wavelength_calibration_headers(self) -> dict[str, str | float]:
        """Update common headers with wavelength calibration data."""
        wavecal_solution = next(
            self.read(
                tags=[DlnirspTag.task_wavelength_solution(), DlnirspTag.intermediate()],
                decoder=json_decoder,
            )
        )
        # The wavecal solution has axis 3 for all keys, use axis 1 of the extra for these as the spec doesn't allow for axis 3.
        return {k.replace("3", "1"): wavecal_solution.get(k) for k in wavecal_solution.keys()}

    @cached_property
    def atlas_headers(self) -> dict[str, str]:
        """Update common headers with atlas data."""
        return {"ATLASURL": self.parameters.wavecal_atlas_download_config.base_url}

    def dataset_extra_headers(
        self,
        header_data: DatasetExtraHeaderData,
    ) -> dict:
        """Update common headers with instrument specific ones."""
        header_dict = super().dataset_extra_headers(header_data=header_data)
        # DL-NIRSP headers
        # -----------------
        new_dlnirsp_headers = {
            DlnirspMetadataKey.arm_id: self.constants.arm_id,
            DlnirspMetadataKey.polarimeter_mode: self.constants.polarimeter_mode,
            DlnirspMetadataKey.number_of_modulator_states: self.constants.num_modstates,
            DlnirspMetadataKey.grating_position_deg: self.constants.grating_position_deg.value,
            DlnirspMetadataKey.arm_position_mm: self.constants.arm_position_mm.value,
            DlnirspMetadataKey.grating_constant_inverse_mm: self.constants.grating_constant_inverse_mm.value,
        }
        header_dict[DatasetExtraHeaderSection.dlnirsp] = new_dlnirsp_headers

        # Wavelength Calibration headers
        # -------------------------------
        header_dict[DatasetExtraHeaderSection.wavecal] = self.wavelength_calibration_headers

        # Atlas headers
        # --------------
        header_dict[DatasetExtraHeaderSection.atlas] = self.atlas_headers

        return header_dict

    def write_bad_pixel_map_dataset_extra(self):
        """Create the bad pixel map dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.bad_pixel_map)
        data = next(
            self.read(
                tags=[
                    DlnirspTag.intermediate(),
                    DlnirspTag.task("BAD_PIXEL_CUBE"),
                ],
                decoder=fits_array_decoder,
            )
        )
        total_exposure_time = self.constants.lamp_gain_exposure_times[0]
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.dark,
                total_exposure=total_exposure_time,
                readout_exposure=self.constants.dark_readout_times_per_dark_exposure_time[
                    total_exposure_time
                ][0],
                extra_name=DatasetExtraType.bad_pixel_map,
                end_time=self.constants.dark_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_dark_dataset_extra(self):
        """Create the dark dataset extra."""
        target_exp_times = self.constants.non_dark_task_exposure_times
        for exp_time in target_exp_times:
            filename = self.format_extra_filename(
                extra_name=DatasetExtraType.dark, detail=f"{DlnirspTag.exposure_time(exp_time)}"
            )
            data = next(
                self.read(
                    tags=DlnirspTag.intermediate_frame_dark(exposure_time=exp_time),
                    decoder=fits_array_decoder,
                )
            )
            header = self.build_dataset_extra_header(
                sections=[
                    DatasetExtraHeaderSection.common,
                    DatasetExtraHeaderSection.aggregate,
                    DatasetExtraHeaderSection.gos,
                    DatasetExtraHeaderSection.iptask,
                    DatasetExtraHeaderSection.dlnirsp,
                ],
                header_data=DatasetExtraHeaderData(
                    filename=filename,
                    task_type=TaskName.dark,
                    total_exposure=exp_time,
                    readout_exposure=self.constants.dark_readout_times_per_dark_exposure_time[
                        exp_time
                    ][0],
                    extra_name=DatasetExtraType.dark,
                    end_time=self.constants.dark_date_end,
                ),
            )
            self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_solar_gain_dataset_extra(self):
        """Create the solar gain dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.solar_gain)
        data = next(
            self.read(
                tags=[DlnirspTag.intermediate_frame(), DlnirspTag.task_solar_gain()],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.solar_gain,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_characteristic_spectrum_dataset_extra(self):
        """Create the characteristic spectrum dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.characteristic_spectra)
        data = next(
            self.read(
                tags=[
                    DlnirspTag.frame(),
                    DlnirspTag.intermediate(),
                    DlnirspTag.task("SC_PAD_CHAR_SPEC"),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.solar_gain,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_spectral_curvature_shifts_dataset_extra(self, geometric_dict: dict[str, dict]):
        """Create the spectral curvature shifts dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.spectral_curvature_shifts)
        spectral_shifts: dict[int, np.ndarray] = geometric_dict["spectral_shifts"]
        data = stack_pad_right(values=list(spectral_shifts.values()))
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.solar_gain,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_spectral_curvature_scales_dataset_extra(self, geometric_dict: dict[str, dict]):
        """Create the spectral curvature scales dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.spectral_curvature_scales)
        spectral_scales: dict[int, np.ndarray] = geometric_dict["spectral_scales"]
        data = stack_pad_right(values=list(spectral_scales.values()))
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.solar_gain,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_wavelength_calibration_input_spectrum_dataset_extra(self):
        """Create the wavelength calibration input spectrum dataset extra."""
        filename = self.format_extra_filename(
            extra_name=DatasetExtraType.wavelength_calibration_input_spectrum
        )
        data = next(
            self.read(
                tags=[
                    DlnirspTag.intermediate(),
                    DlnirspTag.task_wavelength_calibration_input_spectrum(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.wavelength_calibration_input_spectrum,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_wavelength_calibration_reference_spectrum_dataset_extra(self):
        """Create the wavelength calibration reference spectrum dataset extra."""
        filename = self.format_extra_filename(
            extra_name=DatasetExtraType.wavelength_calibration_reference_spectrum
        )
        data = next(
            self.read(
                tags=[
                    DlnirspTag.intermediate(),
                    DlnirspTag.task_wavelength_calibration_reference_spectrum(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.atlas,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.wavelength_calibration_reference_spectrum,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_wavelength_calibration_reference_wavelength_vector_dataset_extra(self):
        """Create the wavelength calibration reference wavelength vector dataset extra."""
        filename = self.format_extra_filename(
            extra_name=DatasetExtraType.reference_wavelength_vector
        )
        data = next(
            self.read(
                tags=[
                    DlnirspTag.intermediate(),
                    DlnirspTag.task_wavelength_calibration_reference_wavelength_vector(),
                ],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.wavecal,
                DatasetExtraHeaderSection.dlnirsp,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.solar_gain,
                total_exposure=self.constants.solar_gain_exposure_times[0],
                readout_exposure=self.constants.solar_gain_readout_exposure_times[0],
                extra_name=DatasetExtraType.reference_wavelength_vector,
                end_time=self.constants.solar_gain_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_demodulation_matrices_dataset_extra(self):
        """Create the demodulation matrices dataset extra."""
        filename = self.format_extra_filename(extra_name=DatasetExtraType.demodulation_matrices)
        data = next(
            self.read(
                tags=[DlnirspTag.intermediate_frame(), DlnirspTag.task_demodulation_matrices()],
                decoder=fits_array_decoder,
            )
        )
        header = self.build_dataset_extra_header(
            sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.dlnirsp,
                DatasetExtraHeaderSection.aggregate,
            ],
            header_data=DatasetExtraHeaderData(
                filename=filename,
                task_type=TaskName.polcal,
                total_exposure=self.constants.polcal_exposure_times[0],
                readout_exposure=self.constants.polcal_readout_exposure_times[0],
                extra_name=DatasetExtraType.demodulation_matrices,
                end_time=self.constants.polcal_date_end,
            ),
        )
        self.assemble_and_write_dataset_extra(data=data, header=header, filename=filename)

    def write_polcal_as_science_dataset_extra(self):
        """Create the polcal as science dataset extras."""
        for stokes in self.constants.stokes_params:
            for cs_step in range(self.constants.num_cs_steps):
                for cs_step_frame in range(self.constants.num_frames_per_cs_step):
                    filename = self.format_extra_filename(
                        extra_name=DatasetExtraType.polcal_as_science,
                        detail=f"{DlnirspTag.cs_step(cs_step)}_{DlnirspTag.cs_step_frame(cs_step_frame)}_{DlnirspTag.stokes(stokes)}",
                    )
                    data = next(
                        self.read(
                            tags=[
                                DlnirspTag.task(TaskName.polcal_as_science),
                                DlnirspTag.intermediate_frame(),
                                DlnirspTag.stokes(stokes),
                                DlnirspTag.cs_step(cs_step),
                                DlnirspTag.cs_step_frame(cs_step_frame),
                            ],
                            decoder=fits_array_decoder,
                        )
                    )
                    header = self.build_dataset_extra_header(
                        sections=[
                            DatasetExtraHeaderSection.common,
                            DatasetExtraHeaderSection.iptask,
                            DatasetExtraHeaderSection.dlnirsp,
                            DatasetExtraHeaderSection.gos,
                            DatasetExtraHeaderSection.pcas,
                        ],
                        header_data=DatasetExtraHeaderData(
                            filename=filename,
                            task_type=TaskName.polcal,
                            total_exposure=self.constants.polcal_exposure_times[0],
                            readout_exposure=self.constants.polcal_readout_exposure_times[0],
                            extra_name=DatasetExtraType.polcal_as_science,
                            end_time=self.constants.polcal_date_end,
                            num_cs_steps=self.constants.num_cs_steps,
                            cs_step=cs_step,
                            num_frames_per_cs_step=self.constants.num_frames_per_cs_step,
                            frame_in_cs_step=cs_step_frame,
                            stokes=stokes,
                        ),
                    )
                    self.assemble_and_write_dataset_extra(
                        data=data, header=header, filename=filename
                    )
