from typing import TYPE_CHECKING
from typing import Any
from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_models.managers.model_manager import Manager
from amsdal_models.querysets.base_queryset import ModelType
from amsdal_models.querysets.base_queryset import QuerySet
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

from amsdal.contrib.auth.models.permission import *  # noqa: F403

if TYPE_CHECKING:
    from amsdal_server.apps.common.permissions.enums import Action
    from starlette.authentication import AuthCredentials
    from starlette.authentication import BaseUser


class UserApiManager(Manager):
    """Manager for User API with scope-based filtering."""

    def get_queryset(self) -> QuerySet[ModelType]:
        from amsdal.context.manager import AmsdalContextManager
        from amsdal.contrib.auth.permissions import has_admin_permissions

        qs = super().get_queryset()

        request = AmsdalContextManager().get_context().get('request', None)
        if not request or not request.auth:
            return qs.none()

        # Super admin sees all users
        if has_admin_permissions(request.auth):
            return qs

        # Regular users can only see their own profile
        auth_user = getattr(request, 'user', None)
        if auth_user and auth_user.is_authenticated:
            return qs.filter(email=auth_user.identity)

        return qs.none()


class User(Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    api_objects: ClassVar[UserApiManager] = UserApiManager()

    email: str = Field(title='Email')
    password: bytes = Field(title='Password (hash)')
    permissions: list['Permission'] | None = Field(None, title='Permissions')  # noqa: F405

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return f'User(email={self.email})'

    async def apre_update(self) -> None:
        import bcrypt

        original_object = await self.arefetch_from_db()
        password = self.password
        if original_object.password and password is not None:
            if isinstance(password, str):
                password = password.encode('utf-8')
            try:
                if not bcrypt.checkpw(password, original_object.password):
                    self.password = password
            except ValueError:
                hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
                self.password = hashed_password

    @property
    def display_name(self) -> str:
        """
        Returns the display name of the user.

        This method returns the email of the user as their display name.

        Returns:
            str: The email of the user.
        """
        return self.email

    @property
    def requires_mfa(self) -> bool:
        """
        Determines if MFA is required for this user.

        This checks both the per-user override (mfa_required) and the global
        REQUIRE_MFA_BY_DEFAULT setting.

        Returns:
            bool: True if MFA is required, False otherwise.
        """
        from amsdal.contrib.auth.settings import auth_settings

        # Fall back to global setting
        return auth_settings.REQUIRE_MFA_BY_DEFAULT

    async def ahas_valid_mfa_device(self) -> bool:
        """
        Check if the user has at least one confirmed and active MFA device.

        Returns:
            bool: True if the user has a valid MFA device, False otherwise.
        """
        from amsdal.contrib.auth.utils.mfa import aget_active_user_devices

        devices = await aget_active_user_devices(self)
        for device_list in devices.values():
            if device_list:
                return True
        return False

    def has_valid_mfa_device(self) -> bool:
        """
        Check if the user has at least one confirmed and active MFA device (sync version).

        Returns:
            bool: True if the user has a valid MFA device, False otherwise.
        """
        from amsdal.contrib.auth.utils.mfa import get_active_user_devices

        devices = get_active_user_devices(self)
        for device_list in devices.values():
            if device_list:
                return True
        return False

    def pre_init(self, *, is_new_object: bool, kwargs: dict[str, Any]) -> None:  # noqa: ARG002
        if 'email' in kwargs and isinstance(kwargs['email'], str):
            kwargs['email'] = kwargs['email'].lower()

    def post_init(self, *, is_new_object: bool, kwargs: dict[str, Any]) -> None:
        """
        Post-initializes a user object by validating email and password, and hashing the password.

        This method checks if the email and password are provided and valid. If the object is new,
        it hashes the password and sets the object ID to the lowercased email.

        Args:
            is_new_object (bool): Indicates if the object is new.
            kwargs (dict[str, Any]): The keyword arguments containing user details.

        Raises:
            UserCreationError: If the email or password is invalid.
        """
        import bcrypt

        from amsdal.contrib.auth.errors import UserCreationError

        email = kwargs.get('email', None)
        password = kwargs.get('password', None)
        if email is None or email == '':
            msg = "Email can't be empty"
            raise UserCreationError(msg)
        if password is None or password == '':
            msg = "Password can't be empty"
            raise UserCreationError(msg)
        kwargs['email'] = email.lower()
        if is_new_object and '_metadata' not in kwargs:
            if isinstance(password, str):
                password = password.encode('utf-8')
            hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
            self.password = hashed_password
            self._object_id = email.lower()

    def pre_create(self) -> None:
        """
        Pre-creates a user object.

        This method is a placeholder for any pre-creation logic that needs to be executed
        before a user object is created.
        """
        pass

    def pre_update(self) -> None:
        import bcrypt

        original_object = self.refetch_from_db()
        password = self.password
        if original_object.password and password is not None:
            if isinstance(password, str):
                password = password.encode('utf-8')
            try:
                if not bcrypt.checkpw(password, original_object.password):
                    self.password = password
            except ValueError:
                hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
                self.password = hashed_password

    def has_object_permission(
        self,
        user: 'BaseUser',
        action: 'Action',
        update_data: dict[str, Any] | None = None,
        auth: 'AuthCredentials | None' = None,
    ) -> bool:
        """Check if a user has permission to perform an action on this user object.

        Args:
            user: The user requesting the action.
            action: The action being requested.
            update_data: Data being updated (for UPDATE actions). Can be mutated to filter fields.
            auth: Auth credentials containing scopes.

        Returns:
            bool: True if the user has permission, False otherwise.
        """
        from amsdal_server.apps.common.permissions.enums import Action as ActionEnum

        from amsdal.contrib.auth.permissions import has_admin_permissions
        from amsdal.contrib.auth.permissions import has_permissions

        if has_admin_permissions(auth):
            return True

        action_value = action.value if hasattr(action, 'value') else action
        if not has_permissions(f'models.User:{action_value}', auth):
            return False

        # create - only admin (public registration through separate transaction)
        if action == ActionEnum.CREATE:
            return False

        # For UPDATE: filter sensitive fields for non-admin users
        if action == ActionEnum.UPDATE and update_data is not None:
            # Silently remove permissions field - users cannot grant themselves permissions
            update_data.pop('permissions', None)

        # read/update/delete - only own profile
        if user.is_authenticated:
            return self.email == user.identity

        return False
