from typing import TYPE_CHECKING
from typing import Any
from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_models.managers.model_manager import Manager
from amsdal_models.querysets.base_queryset import ModelType
from amsdal_models.querysets.base_queryset import QuerySet
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

if TYPE_CHECKING:
    from amsdal_server.apps.common.permissions.enums import Action
    from starlette.authentication import AuthCredentials
    from starlette.authentication import BaseUser


class PermissionApiManager(Manager):
    """Manager for Permission API with scope-based filtering."""

    def get_queryset(self) -> QuerySet[ModelType]:
        from amsdal.context.manager import AmsdalContextManager
        from amsdal.contrib.auth.permissions import has_admin_permissions

        qs = super().get_queryset()

        request = AmsdalContextManager().get_context().get('request', None)
        if not request or not request.auth:
            return qs.none()

        # Only super admins can see permissions
        if has_admin_permissions(request.auth):
            return qs

        return qs.none()


class Permission(Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    api_objects: ClassVar[PermissionApiManager] = PermissionApiManager()

    resource_type: str = Field(default='models', title='Resource Type')
    model: str = Field(title='Model')
    action: str = Field(title='Action')

    @property
    def display_name(self) -> str:
        """
        Returns the display name of the user.

        This method returns a formatted string combining the model and action of the user.

        Returns:
            str: The formatted display name in the format 'model:action'.
        """
        return f'{self.model}:{self.action}'

    def has_object_permission(
        self,
        user: 'BaseUser',  # noqa: ARG002
        action: 'Action',
        update_data: dict[str, Any] | None = None,  # noqa: ARG002
        auth: 'AuthCredentials | None' = None,
    ) -> bool:
        """Check if a user has permission to perform an action on this permission object.

        Only super admins can manage permissions.

        Args:
            user: The user requesting the action.
            action: The action being requested.
            update_data: Data being updated (not used for Permission - only admins can access).
            auth: Auth credentials containing scopes.

        Returns:
            bool: True if the user has permission, False otherwise.
        """
        from amsdal.contrib.auth.permissions import has_admin_permissions
        from amsdal.contrib.auth.permissions import has_permissions

        if has_admin_permissions(auth):
            return True

        action_value = action.value if hasattr(action, 'value') else action
        return has_permissions(f'models.Permission:{action_value}', auth)
