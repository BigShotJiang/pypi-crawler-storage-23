from datetime import UTC
from datetime import datetime
from typing import TYPE_CHECKING
from typing import Any
from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_models.managers.model_manager import Manager
from amsdal_models.querysets.base_queryset import ModelType
from amsdal_models.querysets.base_queryset import QuerySet
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

from amsdal.contrib.auth.utils.mfa import DeviceType

if TYPE_CHECKING:
    from amsdal_server.apps.common.permissions.enums import Action
    from starlette.authentication import AuthCredentials
    from starlette.authentication import BaseUser


def _now_utc() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(tz=UTC)


class MFADeviceApiManager(Manager):
    """Manager for MFADevice API with scope-based filtering."""

    def get_queryset(self) -> QuerySet[ModelType]:
        from amsdal.context.manager import AmsdalContextManager
        from amsdal.contrib.auth.permissions import has_admin_permissions

        qs = super().get_queryset()

        request = AmsdalContextManager().get_context().get('request', None)
        if not request or not request.auth:
            return qs.none()

        # Super admin sees all devices
        if has_admin_permissions(request.auth):
            return qs

        # Regular users can only see their own devices
        auth_user = getattr(request, 'user', None)
        if auth_user and auth_user.is_authenticated:
            return qs.filter(user_email=auth_user.identity)

        return qs.none()


class MFADevice(Model):
    """
    Base model for Multi-Factor Authentication devices.

    This model serves as the base class for all MFA device types (TOTP, Backup Codes, Email, SMS).
    Each device is associated with a user and must be confirmed before it can be used for authentication.

    Attributes:
        user_email (str): Email of the user who owns this device (reference to User).
        device_type (str): Type of MFA device ('totp', 'backup_code', 'email', 'sms').
        name (str): User-friendly name for the device.
        is_active (bool): Whether the device is currently active and can be used.
        confirmed (bool): Whether the device has been verified during setup.
        created_at (datetime): When the device was created.
        last_used_at (datetime | None): When the device was last used for authentication.
    """

    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    api_objects: ClassVar[MFADeviceApiManager] = MFADeviceApiManager()

    user_email: str = Field(title='User Email')
    device_type: DeviceType | None = Field(default=None, title='Device Type')
    name: str = Field(title='Device Name')
    is_active: bool = Field(True, title='Is Active')
    confirmed: bool = Field(False, title='Confirmed')
    created_at: datetime = Field(default_factory=_now_utc, title='Created At')
    last_used_at: datetime | None = Field(None, title='Last Used At')

    @property
    def display_name(self) -> str:
        """
        Returns the display name of the device.

        Returns:
            str: The device name and type.
        """
        return f'{self.name} ({self.device_type})'

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        return f'MFADevice(name={self.name}, type={self.device_type}, user={self.user_email})'

    def has_object_permission(
        self,
        user: 'BaseUser',
        action: 'Action',
        update_data: dict[str, Any] | None = None,
        auth: 'AuthCredentials | None' = None,
    ) -> bool:
        """
        Check if a user has permission to perform an action on this device.

        Users can only manage their own devices. Admins with wildcard permissions
        can manage all devices.

        Args:
            user: The user requesting the action.
            action: The action being requested.
            update_data: Data being updated (for UPDATE actions). Can be mutated to filter fields.
            auth: Auth credentials containing scopes.

        Returns:
            bool: True if the user has permission, False otherwise.
        """
        from amsdal_server.apps.common.permissions.enums import Action as ActionEnum

        from amsdal.contrib.auth.permissions import has_admin_permissions
        from amsdal.contrib.auth.permissions import has_permissions

        if has_admin_permissions(auth):
            return True

        action_value = action.value if hasattr(action, 'value') else action
        if not has_permissions(f'models.MFADevice:{action_value}', auth):
            return False

        # For UPDATE: filter user_email - cannot reassign device to another user
        if action == ActionEnum.UPDATE and update_data is not None:
            update_data.pop('user_email', None)

        # Users can only manage their own devices
        if user.is_authenticated:
            return self.user_email == user.identity

        return False
