"""MFA code delivery events."""

from amsdal_utils.events.context import EventContext
from amsdal_utils.events.event import Event


class SendMFACodeContext(EventContext):
    """Context for MFA code delivery.

    Attributes:
        device_type: The type of MFA device ('email' or 'sms').
        recipient: The email address or phone number to deliver the code to.
        code: The generated MFA code.
        user_email: The user's email (for audit/logging).
        device_name: The device label.
    """

    device_type: str
    recipient: str
    code: str
    user_email: str
    device_name: str


class SendMFACodeEvent(Event[SendMFACodeContext]):
    """Emitted when an MFA code needs to be delivered to a user."""
