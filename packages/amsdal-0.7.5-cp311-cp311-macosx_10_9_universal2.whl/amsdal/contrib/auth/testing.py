"""Testing utilities for auth module."""

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any


@contextmanager
def override_auth_settings(**kwargs: Any) -> Iterator[None]:
    """
    Context manager that temporarily overrides auth settings.

    Example:
        from amsdal.contrib.auth.testing import override_auth_settings

        with override_auth_settings(REQUIRE_DEFAULT_AUTHORIZATION=True):
            response = client.get('/api/users/')
            assert response.status_code == 403
    """
    from amsdal.contrib.auth.settings import auth_settings

    original_values = {}
    for key in kwargs:
        original_values[key] = getattr(auth_settings, key)

    for key, value in kwargs.items():
        setattr(auth_settings, key, value)

    try:
        yield
    finally:
        for key, value in original_values.items():
            setattr(auth_settings, key, value)
