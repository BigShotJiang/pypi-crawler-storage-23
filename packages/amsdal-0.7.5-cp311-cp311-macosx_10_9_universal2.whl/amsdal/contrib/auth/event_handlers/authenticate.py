"""Event listener for user authentication."""

import logging
from typing import TYPE_CHECKING
from typing import Any

import jwt
from amsdal_server.apps.common.events.auth import AuthenticateContext
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn
from amsdal_utils.models.enums import Versions

from amsdal.contrib.auth.errors import AuthenticationError
from amsdal.contrib.auth.users import AuthenticatedUser

if TYPE_CHECKING:
    from amsdal.contrib.auth.models.user import User

logger = logging.getLogger(__name__)


class AuthenticateUserListener(EventListener[AuthenticateContext]):
    """Authenticates a user based on a provided JWT token.

    This listener decodes the JWT token from the auth_header and retrieves
    the corresponding user from the database. If the token is invalid or expired,
    it raises an `AuthenticationError`.
    """

    def handle(
        self,
        context: AuthenticateContext,
        next_fn: NextFn[AuthenticateContext],
    ) -> AuthenticateContext:
        from amsdal.contrib.auth.models.user import User
        from amsdal.contrib.auth.settings import auth_settings

        user = None

        try:
            if not auth_settings.AUTH_JWT_KEY:
                msg = 'AUTH_JWT_KEY is not configured.'
                raise AuthenticationError(msg)

            jwt_payload = jwt.decode(
                context.auth_header,
                auth_settings.AUTH_JWT_KEY,
                algorithms=['HS256'],
            )
            email = jwt_payload['email']

            user = (
                User.objects.filter(
                    email=email,
                    _address__object_version=Versions.LATEST,
                )
                .get_or_none()
                .execute()
            )

        except jwt.ExpiredSignatureError as exc:
            logger.error('Auth token expired. Defaulting to anonymous user.')
            msg = 'Auth token has expired.'
            raise AuthenticationError(msg) from exc
        except Exception as exc:
            logger.error('Auth token decode failure. Defaulting to anonymous user.')
            msg = 'Failed to decode auth token.'
            raise AuthenticationError(msg) from exc

        permissions = self._load_permissions(user) if user else []
        scopes = self._generate_scopes(permissions)
        auth_user = AuthenticatedUser(user) if user else None

        return next_fn(
            context.create_next(
                listener_id=self.listener_id,
                user=auth_user,
                scopes=scopes,
            )
        )

    async def ahandle(
        self,
        context: AuthenticateContext,
        next_fn: AsyncNextFn[AuthenticateContext],
    ) -> AuthenticateContext:
        from amsdal.contrib.auth.models.user import User
        from amsdal.contrib.auth.settings import auth_settings

        user = None

        try:
            if not auth_settings.AUTH_JWT_KEY:
                msg = 'AUTH_JWT_KEY is not configured.'
                raise AuthenticationError(msg)

            jwt_payload = jwt.decode(
                context.auth_header,
                auth_settings.AUTH_JWT_KEY,
                algorithms=['HS256'],
            )
            email = jwt_payload['email']

            user = (
                await User.objects.filter(
                    email=email,
                    _address__object_version=Versions.LATEST,
                )
                .get_or_none()
                .aexecute()
            )

        except jwt.ExpiredSignatureError as exc:
            logger.error('Auth token expired. Defaulting to anonymous user.')
            msg = 'Auth token has expired.'
            raise AuthenticationError(msg) from exc
        except Exception as exc:
            logger.error('Auth token decode failure. Defaulting to anonymous user.')
            msg = 'Failed to decode auth token.'
            raise AuthenticationError(msg) from exc

        permissions = await self._aload_permissions(user) if user else []
        scopes = self._generate_scopes(permissions)
        auth_user = AuthenticatedUser(user) if user else None

        return await next_fn(
            context.create_next(
                listener_id=self.listener_id,
                user=auth_user,
                scopes=scopes,
            )
        )

    def _generate_scopes(self, permissions: list[Any]) -> list[str]:
        """Generate scopes from loaded permissions."""
        scopes: list[str] = []

        for permission in permissions:
            resource_type = getattr(permission, 'resource_type', 'models')
            if resource_type == '*' and permission.model == '*' and permission.action == '*':
                scope = '*:*'
            else:
                scope = f'{resource_type}.{permission.model}:{permission.action}'
            scopes.append(scope)

        return scopes

    def _load_permissions(self, user: 'User') -> list[Any]:
        """Load user permissions (sync)."""
        from amsdal_models.classes.helpers.reference_loader import ReferenceLoader
        from amsdal_utils.models.data_models.reference import Reference

        permissions = getattr(user, 'permissions', None)
        if not permissions:
            return []

        return [ReferenceLoader(p).load_reference() if isinstance(p, Reference) else p for p in permissions]

    async def _aload_permissions(self, user: 'User') -> list[Any]:
        """Load user permissions (async)."""
        import asyncio

        from amsdal_models.classes.helpers.reference_loader import ReferenceLoader
        from amsdal_utils.models.data_models.reference import Reference

        permissions = getattr(user, 'permissions', None)
        if asyncio.iscoroutine(permissions):
            permissions = await permissions
        if not permissions:
            return []

        result = []
        for _permission in permissions:
            if asyncio.iscoroutine(_permission):
                _permission = await _permission
            if isinstance(_permission, Reference):
                _permission = await ReferenceLoader(_permission).aload_reference()
            result.append(_permission)
        return result
