"""Event listener for creating a super user on server startup."""

import logging

from amsdal_data.transactions.decorators import async_transaction
from amsdal_data.transactions.decorators import transaction
from amsdal_server.apps.common.events.server import ServerStartupContext
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn
from amsdal_utils.models.enums import Versions

logger = logging.getLogger(__name__)


class CheckAndCreateSuperUserListener(EventListener[ServerStartupContext]):
    """Ensures the existence of a super user in the system.

    This listener checks if a super user exists based on the provided email and password
    in the authentication settings. If the super user does not exist, it creates one.
    """

    @transaction
    def handle(  # type: ignore[override]
        self,
        context: ServerStartupContext,
        next_fn: NextFn[ServerStartupContext],
    ) -> ServerStartupContext:
        """Check for the existence of a super user and create one if necessary."""
        from amsdal.contrib.auth.models.permission import Permission
        from amsdal.contrib.auth.models.user import User
        from amsdal.contrib.auth.settings import auth_settings

        logger.info('Ensure super user exists')

        if not (auth_settings.ADMIN_USER_EMAIL and auth_settings.ADMIN_USER_PASSWORD):
            logger.info('Email / password missing for super user - skipping')
            return next_fn(context)

        user = (
            User.objects.filter(email=auth_settings.ADMIN_USER_EMAIL, _address__object_version=Versions.LATEST)
            .get_or_none()
            .execute()
        )
        if user is not None:
            logger.info('Super user already exists - skipping')
            return next_fn(context)

        logger.info("Super user doesn't exist - creating now")

        access_all_permission = (
            Permission.objects.filter(
                model='*',
                action='*',
                resource_type='*',
                _address__object_version=Versions.LATEST,
            )
            .get()
            .execute()
        )

        instance = User(  # type: ignore[call-arg]
            email=auth_settings.ADMIN_USER_EMAIL,
            password=auth_settings.ADMIN_USER_PASSWORD.encode(),
            permissions=[access_all_permission],
        )
        instance.save(force_insert=True)
        logger.info('Super user created successfully')

        return next_fn(context)

    @async_transaction
    async def ahandle(  # type: ignore[override]
        self,
        context: ServerStartupContext,
        next_fn: AsyncNextFn[ServerStartupContext],
    ) -> ServerStartupContext:
        """Check for the existence of a super user and create one if necessary (async)."""
        from amsdal.contrib.auth.models.permission import Permission
        from amsdal.contrib.auth.models.user import User
        from amsdal.contrib.auth.settings import auth_settings

        logger.info('Ensure super user exists')

        if not (auth_settings.ADMIN_USER_EMAIL and auth_settings.ADMIN_USER_PASSWORD):
            logger.info('Email / password missing for super user - skipping')
            return await next_fn(context)

        user = (
            await User.objects.filter(email=auth_settings.ADMIN_USER_EMAIL, _address__object_version=Versions.LATEST)
            .get_or_none()
            .aexecute()
        )
        if user is not None:
            logger.info('Super user already exists - skipping')
            return await next_fn(context)

        logger.info("Super user doesn't exist - creating now")

        access_all_permission = (
            await Permission.objects.filter(
                model='*',
                action='*',
                resource_type='*',
                _address__object_version=Versions.LATEST,
            )
            .get()
            .aexecute()
        )

        instance = User(  # type: ignore[call-arg]
            email=auth_settings.ADMIN_USER_EMAIL,
            password=auth_settings.ADMIN_USER_PASSWORD.encode(),
            permissions=[access_all_permission],
        )
        await instance.asave(force_insert=True)  # type: ignore[misc]
        logger.info('Super user created successfully')

        return await next_fn(context)
