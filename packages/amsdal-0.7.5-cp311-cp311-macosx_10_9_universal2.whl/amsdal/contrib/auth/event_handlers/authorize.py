"""Event listeners for authorization."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from typing import Any

from amsdal_models.classes.class_manager import ClassManager
from amsdal_models.classes.model import Model
from amsdal_server.apps.common.events.authorize import ClassAuthorizeContext
from amsdal_server.apps.common.events.authorize import ObjectAuthorizeContext
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn

if TYPE_CHECKING:
    from amsdal.contrib.auth.decorators import PermissionSet

logger = logging.getLogger(__name__)


class ClassAuthorizeListener(EventListener[ClassAuthorizeContext]):
    """Handles class-level authorization checks.

    Uses the composable permission system (__permissions__ attribute) to determine access.
    Falls back to REQUIRE_DEFAULT_AUTHORIZATION setting when no explicit permissions are set.
    """

    def handle(
        self,
        context: ClassAuthorizeContext,
        next_fn: NextFn[ClassAuthorizeContext],
    ) -> ClassAuthorizeContext:
        authorized, error_message = self._check_permissions(
            request=context.request,
            resource_type=context.resource_type,
            resource_name=context.resource_name,
            action=context.action,
        )

        return next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    async def ahandle(
        self,
        context: ClassAuthorizeContext,
        next_fn: AsyncNextFn[ClassAuthorizeContext],
    ) -> ClassAuthorizeContext:
        authorized, error_message = self._check_permissions(
            request=context.request,
            resource_type=context.resource_type,
            resource_name=context.resource_name,
            action=context.action,
        )

        return await next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    def _check_permissions(
        self,
        request: Any,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
    ) -> tuple[bool, str | None]:
        """Check if user has permission via the composable permission system."""
        from amsdal.contrib.auth.permissions import has_admin_permissions

        # Super admin shortcut
        if has_admin_permissions(getattr(request, 'auth', None)):
            return True, None

        perm_set = self._get_permission_set(resource_type, resource_name)
        permission_obj = perm_set.get_permission(action.value)

        if permission_obj is None:
            return True, None

        if permission_obj.has_permission(request, action):
            return True, None

        return False, f'Permission denied for {action.value} on {resource_type.value}.{resource_name}'

    def _get_permission_set(self, resource_type: ResourceType, resource_name: str) -> PermissionSet:
        """Get the PermissionSet for a resource, falling back to defaults."""
        from amsdal.contrib.auth.decorators import PermissionSet
        from amsdal.contrib.auth.permissions import AllowAny as _AllowAny
        from amsdal.contrib.auth.permissions import BasePermission
        from amsdal.contrib.auth.permissions import RequireAuth as _RequireAuth
        from amsdal.contrib.auth.settings import auth_settings

        raw_permissions = None

        if resource_type == ResourceType.MODELS:
            try:
                model_class = ClassManager().import_class(resource_name)
                raw_permissions = getattr(model_class, '__permissions__', None)
            except (ValueError, ImportError):
                pass
        elif resource_type == ResourceType.TRANSACTIONS:
            try:
                from amsdal.services.transaction_execution import TransactionExecutionService

                transaction_func = TransactionExecutionService().get_transaction_func(resource_name)
                raw_permissions = getattr(transaction_func, '__permissions__', None)
            except Exception:  # noqa: S110
                pass

        # If __permissions__ is a raw BasePermission, wrap in PermissionSet
        if isinstance(raw_permissions, BasePermission):
            return PermissionSet(default=raw_permissions)

        # If __permissions__ is already a PermissionSet, use it
        if isinstance(raw_permissions, PermissionSet):
            return raw_permissions

        # No __permissions__ set — use default from REQUIRE_DEFAULT_AUTHORIZATION
        default_perm = _RequireAuth if auth_settings.REQUIRE_DEFAULT_AUTHORIZATION else _AllowAny
        return PermissionSet(default=default_perm)


class ObjectAuthorizeListener(EventListener[ObjectAuthorizeContext]):
    """Handles object-level authorization checks.

    Checks has_object_permission() on the model instance if it exists.
    """

    def handle(
        self,
        context: ObjectAuthorizeContext,
        next_fn: NextFn[ObjectAuthorizeContext],
    ) -> ObjectAuthorizeContext:
        authorized, error_message = self._check_object_permission(
            request=context.request,
            obj=context.obj,
            action=context.action,
            update_data=context.update_data,
        )

        return next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    async def ahandle(
        self,
        context: ObjectAuthorizeContext,
        next_fn: AsyncNextFn[ObjectAuthorizeContext],
    ) -> ObjectAuthorizeContext:
        authorized, error_message = self._check_object_permission(
            request=context.request,
            obj=context.obj,
            action=context.action,
            update_data=context.update_data,
        )

        return await next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    def _check_object_permission(
        self,
        request: Any,
        obj: Model,
        action: Action,
        update_data: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        """Check if user has permission on the specific object."""
        if hasattr(obj, 'has_object_permission'):
            if not obj.has_object_permission(request.user, action, update_data=update_data, auth=request.auth):
                return False, f'Permission denied for {action.value} on {obj.__class__.__name__} object'

        return True, None
