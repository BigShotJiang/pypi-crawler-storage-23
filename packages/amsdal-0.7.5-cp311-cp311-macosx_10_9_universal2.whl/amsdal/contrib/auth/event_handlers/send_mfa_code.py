"""Event listener for sending MFA codes via email."""

import logging

from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn

from amsdal.contrib.auth.events.mfa import SendMFACodeContext

logger = logging.getLogger(__name__)


class SendEmailMFACodeListener(EventListener[SendMFACodeContext]):
    """Sends MFA codes via email using amsdal_mail.

    This is the default listener for email-based MFA code delivery.
    It only handles contexts where device_type is 'email' and passes
    other device types to the next listener in the chain.

    To use a custom email backend, unsubscribe this listener and register
    your own implementation.
    """

    def handle(
        self,
        context: SendMFACodeContext,
        next_fn: NextFn[SendMFACodeContext],
    ) -> SendMFACodeContext:
        if context.device_type != 'email':
            return next_fn(context)

        try:
            from amsdal_mail import send_mail  # type: ignore[import-not-found]
        except ImportError as e:
            msg = 'amsdal_mail is required to send MFA codes via email. Please install it to use this feature.'
            raise ImportError(msg) from e

        status = send_mail(
            subject='Your MFA Code',
            message=f'Your verification code is: {context.code}',
            recipient_list=[context.recipient],
        )
        if not status.is_success:
            msg = f'Failed to send MFA code to {context.recipient}'
            raise RuntimeError(msg)

        return next_fn(context)

    async def ahandle(
        self,
        context: SendMFACodeContext,
        next_fn: AsyncNextFn[SendMFACodeContext],
    ) -> SendMFACodeContext:
        if context.device_type != 'email':
            return await next_fn(context)

        try:
            from amsdal_mail import send_mail  # type: ignore[import-not-found]
        except ImportError as e:
            msg = 'amsdal_mail is required to send MFA codes via email. Please install it to use this feature.'
            raise ImportError(msg) from e

        status = send_mail(
            subject='Your MFA Code',
            message=f'Your verification code is: {context.code}',
            recipient_list=[context.recipient],
        )
        if not status.is_success:
            msg = f'Failed to send MFA code to {context.recipient}'
            raise RuntimeError(msg)

        return await next_fn(context)
