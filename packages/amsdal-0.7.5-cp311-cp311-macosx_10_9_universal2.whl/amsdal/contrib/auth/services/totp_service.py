"""TOTP device enrollment and confirmation service."""

from amsdal_utils.models.enums import Versions

from amsdal.contrib.auth.errors import InvalidMFACodeError
from amsdal.contrib.auth.errors import MFADeviceNotFoundError
from amsdal.contrib.auth.errors import MFASetupError
from amsdal.contrib.auth.errors import UserNotFoundError
from amsdal.contrib.auth.models.totp_device import TOTPDevice
from amsdal.contrib.auth.models.user import User
from amsdal.contrib.auth.settings import auth_settings
from amsdal.contrib.auth.utils.mfa import generate_qr_code_url
from amsdal.contrib.auth.utils.mfa import generate_totp_secret


class TOTPService:
    """Service for TOTP device two-step enrollment flow.

    Note: This service contains pure business logic only.
    - build_* methods return UNSAVED instances
    - Authorization and save should be done at transaction level
    """

    # ==================== HELPERS ====================

    @classmethod
    def _validate_user_exists(cls, email: str) -> User:
        """Validate user exists, raise UserNotFoundError if not."""
        user = User.objects.filter(email=email, _address__object_version=Versions.LATEST).get_or_none().execute()
        if user is None:
            msg = f'User with email {email} not found'
            raise UserNotFoundError(msg)
        return user

    @classmethod
    async def _avalidate_user_exists(cls, email: str) -> User:
        """Async version: Validate user exists, raise UserNotFoundError if not."""
        user = await User.objects.filter(email=email, _address__object_version=Versions.LATEST).get_or_none().aexecute()
        if user is None:
            msg = f'User with email {email} not found'
            raise UserNotFoundError(msg)
        return user

    # ==================== BUILD METHODS (return unsaved) ====================

    @classmethod
    def build_totp_device(
        cls,
        target_user_email: str,
        device_name: str,
        issuer: str | None = None,
    ) -> tuple[TOTPDevice, str, str]:
        """
        Build TOTP device instance (unsaved) with secret and QR code URL.

        Args:
            target_user_email: Email of user to setup device for.
            device_name: User-friendly name for the device.
            issuer: TOTP issuer name (defaults to MFA_TOTP_ISSUER setting).

        Returns:
            tuple[TOTPDevice, str, str]: Unsaved device instance, secret, and QR code URL.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Secret is returned ONLY during setup.
            User must scan QR or manually enter secret.
            Device is created with confirmed=False.
        """
        cls._validate_user_exists(target_user_email)

        # Generate TOTP secret
        secret = generate_totp_secret()

        # Generate QR code URL
        if issuer is None:
            issuer = auth_settings.MFA_TOTP_ISSUER

        qr_code_url = generate_qr_code_url(secret, target_user_email, issuer)

        # Create unconfirmed TOTP device (NOT saved)
        device = TOTPDevice(  # type: ignore[call-arg]
            user_email=target_user_email,
            name=device_name,
            secret=secret,
            qr_code_url=qr_code_url,
            confirmed=False,
        )

        return device, secret, qr_code_url

    @classmethod
    async def abuild_totp_device(
        cls,
        target_user_email: str,
        device_name: str,
        issuer: str | None = None,
    ) -> tuple[TOTPDevice, str, str]:
        """
        Async version: Build TOTP device instance (unsaved) with secret and QR code URL.

        Args:
            target_user_email: Email of user to setup device for.
            device_name: User-friendly name for the device.
            issuer: TOTP issuer name (defaults to MFA_TOTP_ISSUER setting).

        Returns:
            tuple[TOTPDevice, str, str]: Unsaved device instance, secret, and QR code URL.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Secret is returned ONLY during setup.
            User must scan QR or manually enter secret.
            Device is created with confirmed=False.
        """
        await cls._avalidate_user_exists(target_user_email)

        # Generate TOTP secret
        secret = generate_totp_secret()

        # Generate QR code URL
        if issuer is None:
            issuer = auth_settings.MFA_TOTP_ISSUER

        qr_code_url = generate_qr_code_url(secret, target_user_email, issuer)

        # Create unconfirmed TOTP device (NOT saved)
        device = TOTPDevice(  # type: ignore[call-arg]
            user_email=target_user_email,
            name=device_name,
            secret=secret,
            qr_code_url=qr_code_url,
            confirmed=False,
        )

        return device, secret, qr_code_url

    # ==================== QUERY METHODS ====================

    @classmethod
    def find_totp_device(cls, device_id: str) -> TOTPDevice:
        """
        Find TOTP device by ID.

        Args:
            device_id: ID of the device to find.

        Returns:
            TOTPDevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
        device = (
            TOTPDevice.objects.filter(_object_id=device_id, _address__object_version=Versions.LATEST)
            .get_or_none()
            .execute()
        )

        if device is None:
            msg = f'TOTP device with ID {device_id} not found'
            raise MFADeviceNotFoundError(msg)

        return device

    @classmethod
    async def afind_totp_device(cls, device_id: str) -> TOTPDevice:
        """
        Async version: Find TOTP device by ID.

        Args:
            device_id: ID of the device to find.

        Returns:
            TOTPDevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
        device = (
            await TOTPDevice.objects.filter(_object_id=device_id, _address__object_version=Versions.LATEST)
            .get_or_none()
            .aexecute()
        )

        if device is None:
            msg = f'TOTP device with ID {device_id} not found'
            raise MFADeviceNotFoundError(msg)

        return device

    # ==================== CONFIRMATION METHODS ====================

    @classmethod
    def confirm_totp_device(
        cls,
        device: TOTPDevice,
        verification_code: str,
    ) -> TOTPDevice:
        """
        Confirm TOTP device by verifying code.

        Args:
            device: The TOTP device to confirm.
            verification_code: 6-digit code from authenticator app.

        Returns:
            TOTPDevice: The confirmed device (unsaved).

        Raises:
            InvalidMFACodeError: If verification code is incorrect.
            MFASetupError: If device already confirmed.

        Note:
            This method modifies the device but does NOT save it.
            Caller is responsible for saving.
        """
        # Verify device not already confirmed
        if device.confirmed:
            msg = f'Device {device._object_id} is already confirmed'
            raise MFASetupError(msg)

        # Verify code
        if not device.verify_code(verification_code):
            msg = 'Invalid verification code'
            raise InvalidMFACodeError(msg)

        # Mark as confirmed (NOT saved)
        device.confirmed = True

        return device
