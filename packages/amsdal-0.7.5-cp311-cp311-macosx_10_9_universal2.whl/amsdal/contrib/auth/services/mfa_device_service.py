"""MFA device management service for email, backup codes, listing, and removal."""

from amsdal_utils.models.enums import Versions

from amsdal.contrib.auth.errors import MFADeviceNotFoundError
from amsdal.contrib.auth.errors import UserNotFoundError
from amsdal.contrib.auth.models.backup_code import BackupCode
from amsdal.contrib.auth.models.email_mfa_device import EmailMFADevice
from amsdal.contrib.auth.models.mfa_device import MFADevice
from amsdal.contrib.auth.models.user import User
from amsdal.contrib.auth.settings import auth_settings
from amsdal.contrib.auth.utils.mfa import generate_backup_codes


class MFADeviceService:
    """Service for general MFA device management operations.

    Note: This service contains pure business logic only.
    - build_* methods return UNSAVED instances
    - Authorization and save should be done at transaction level
    """

    # ==================== HELPERS ====================

    @classmethod
    def _validate_user_exists(cls, email: str) -> User:
        """Validate user exists, raise UserNotFoundError if not."""
        user = User.objects.filter(email=email, _address__object_version=Versions.LATEST).get_or_none().execute()
        if user is None:
            msg = f'User with email {email} not found'
            raise UserNotFoundError(msg)
        return user

    @classmethod
    async def _avalidate_user_exists(cls, email: str) -> User:
        """Async version: Validate user exists, raise UserNotFoundError if not."""
        user = await User.objects.filter(email=email, _address__object_version=Versions.LATEST).get_or_none().aexecute()
        if user is None:
            msg = f'User with email {email} not found'
            raise UserNotFoundError(msg)
        return user

    # ==================== BUILD METHODS (return unsaved) ====================

    @classmethod
    def build_email_device(
        cls,
        target_user_email: str,
        device_name: str,
        email: str | None = None,
    ) -> EmailMFADevice:
        """
        Build email MFA device instance (unsaved).

        Args:
            target_user_email: Email of user to add device for.
            device_name: User-friendly name for the device.
            email: Email for MFA codes (defaults to target_user_email).

        Returns:
            EmailMFADevice: Unsaved device instance.

        Raises:
            UserNotFoundError: If target user doesn't exist.
        """
        cls._validate_user_exists(target_user_email)

        # Default email to target user's email
        if email is None:
            email = target_user_email

        # Construct device (NOT saved)
        return EmailMFADevice(  # type: ignore[call-arg]
            user_email=target_user_email,
            name=device_name,
            email=email,
        )

    @classmethod
    async def abuild_email_device(
        cls,
        target_user_email: str,
        device_name: str,
        email: str | None = None,
    ) -> EmailMFADevice:
        """
        Async version: Build email MFA device instance (unsaved).

        Args:
            target_user_email: Email of user to add device for.
            device_name: User-friendly name for the device.
            email: Email for MFA codes (defaults to target_user_email).

        Returns:
            EmailMFADevice: Unsaved device instance.

        Raises:
            UserNotFoundError: If target user doesn't exist.
        """
        await cls._avalidate_user_exists(target_user_email)

        # Default email to target user's email
        if email is None:
            email = target_user_email

        # Construct device (NOT saved)
        return EmailMFADevice(  # type: ignore[call-arg]
            user_email=target_user_email,
            name=device_name,
            email=email,
        )

    @classmethod
    def build_backup_codes(
        cls,
        target_user_email: str,
        device_name: str = 'Backup Codes',
        code_count: int | None = None,
    ) -> tuple[list[BackupCode], list[str]]:
        """
        Build backup code instances (unsaved) and return plaintext codes.

        Args:
            target_user_email: Email of user to add codes for.
            device_name: Name for the backup code set.
            code_count: Number of codes (defaults to MFA_BACKUP_CODES_COUNT setting).

        Returns:
            tuple[list[BackupCode], list[str]]: Unsaved device instances and plaintext codes.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Plaintext codes are returned ONLY during creation.
            Caller must display/send these to user immediately.
            Codes cannot be retrieved later.
        """
        cls._validate_user_exists(target_user_email)

        # Get code count from parameter or settings
        if code_count is None:
            code_count = auth_settings.MFA_BACKUP_CODES_COUNT

        # Generate plaintext codes
        plaintext_codes = generate_backup_codes(code_count)

        # Create BackupCode instances (NOT saved)
        devices = [
            BackupCode(  # type: ignore[call-arg]
                user_email=target_user_email,
                name=device_name,
                code=code,  # type: ignore[arg-type]  # Will be hashed in post_init
            )
            for code in plaintext_codes
        ]

        return devices, plaintext_codes

    @classmethod
    async def abuild_backup_codes(
        cls,
        target_user_email: str,
        device_name: str = 'Backup Codes',
        code_count: int | None = None,
    ) -> tuple[list[BackupCode], list[str]]:
        """
        Async version: Build backup code instances (unsaved) and return plaintext codes.

        Args:
            target_user_email: Email of user to add codes for.
            device_name: Name for the backup code set.
            code_count: Number of codes (defaults to MFA_BACKUP_CODES_COUNT setting).

        Returns:
            tuple[list[BackupCode], list[str]]: Unsaved device instances and plaintext codes.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Plaintext codes are returned ONLY during creation.
            Caller must display/send these to user immediately.
            Codes cannot be retrieved later.
        """
        await cls._avalidate_user_exists(target_user_email)

        # Get code count from parameter or settings
        if code_count is None:
            code_count = auth_settings.MFA_BACKUP_CODES_COUNT

        # Generate plaintext codes
        plaintext_codes = generate_backup_codes(code_count)

        # Create BackupCode instances (NOT saved)
        devices = [
            BackupCode(  # type: ignore[call-arg]
                user_email=target_user_email,
                name=device_name,
                code=code,  # type: ignore[arg-type]  # Will be hashed in post_init
            )
            for code in plaintext_codes
        ]

        return devices, plaintext_codes

    # ==================== QUERY METHODS ====================

    @classmethod
    def find_device(cls, device_id: str) -> MFADevice:
        """
        Find MFA device by ID across all device types.

        Args:
            device_id: ID of the device to find.

        Returns:
            MFADevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
        from amsdal.contrib.auth.models.sms_device import SMSDevice
        from amsdal.contrib.auth.models.totp_device import TOTPDevice

        for device_class in [TOTPDevice, BackupCode, EmailMFADevice, SMSDevice]:
            device = (
                device_class.objects.filter(  # type: ignore[attr-defined]
                    _object_id=device_id, _address__object_version=Versions.LATEST
                )
                .get_or_none()
                .execute()
            )
            if device is not None:
                return device

        msg = f'MFA device with ID {device_id} not found'
        raise MFADeviceNotFoundError(msg)

    @classmethod
    async def afind_device(cls, device_id: str) -> MFADevice:
        """
        Async version: Find MFA device by ID across all device types.

        Args:
            device_id: ID of the device to find.

        Returns:
            MFADevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
        from amsdal.contrib.auth.models.sms_device import SMSDevice
        from amsdal.contrib.auth.models.totp_device import TOTPDevice

        for device_class in [TOTPDevice, BackupCode, EmailMFADevice, SMSDevice]:
            device = (
                await device_class.objects.filter(  # type: ignore[attr-defined]
                    _object_id=device_id, _address__object_version=Versions.LATEST
                )
                .get_or_none()
                .aexecute()
            )
            if device is not None:
                return device

        msg = f'MFA device with ID {device_id} not found'
        raise MFADeviceNotFoundError(msg)
