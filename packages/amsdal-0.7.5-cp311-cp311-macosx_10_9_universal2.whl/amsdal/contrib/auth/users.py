"""User wrapper for Starlette authentication."""

from typing import TYPE_CHECKING

from starlette.authentication import BaseUser

if TYPE_CHECKING:
    from amsdal.contrib.auth.models.user import User


class AuthenticatedUser(BaseUser):
    """Wrapper around ORM User model for Starlette authentication.

    Provides the BaseUser interface while giving access to the underlying
    ORM user model for additional functionality.
    """

    def __init__(self, user: 'User') -> None:
        self._user = user

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def display_name(self) -> str:
        return self._user.display_name

    @property
    def identity(self) -> str:
        return self._user.email

    @property
    def user(self) -> 'User':
        """Access the underlying ORM User model."""
        return self._user

    def __str__(self) -> str:
        return self.display_name

    def __repr__(self) -> str:
        return f'AuthenticatedUser({self.identity})'
