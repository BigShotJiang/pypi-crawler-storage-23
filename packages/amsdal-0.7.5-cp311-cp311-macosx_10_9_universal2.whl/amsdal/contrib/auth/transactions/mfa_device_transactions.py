"""MFA device transaction wrappers for API endpoints."""

from amsdal_data.transactions.decorators import async_transaction
from amsdal_data.transactions.decorators import transaction
from amsdal_server.apps.common.errors import AmsdalAuthorizationError
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_utils.models.enums import Versions
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from starlette.requests import Request

from amsdal.context.manager import AmsdalContextManager
from amsdal.contrib.auth.decorators import allow_any
from amsdal.contrib.auth.decorators import require_auth
from amsdal.contrib.auth.models.backup_code import BackupCode
from amsdal.contrib.auth.models.email_mfa_device import EmailMFADevice
from amsdal.contrib.auth.models.sms_device import SMSDevice
from amsdal.contrib.auth.models.totp_device import TOTPDevice
from amsdal.contrib.auth.services.mfa_device_service import MFADeviceService
from amsdal.contrib.auth.utils.mfa import DeviceType

# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

TAGS = ['Auth', 'MFA']


class AddEmailDeviceRequest(BaseModel):
    """Request model for adding email MFA device."""

    target_user_email: str = Field(..., description='Email of user to add device for')
    device_name: str = Field(..., description='User-friendly name for the device')
    email: str | None = Field(None, description='Email for MFA codes (defaults to target_user_email)')


class EmailDeviceResponse(BaseModel):
    """Response model for email MFA device."""

    device_id: str = Field(..., description='Device ID')
    user_email: str = Field(..., description='User email')
    name: str = Field(..., description='Device name')
    email: str = Field(..., description='Email where MFA codes are sent')
    confirmed: bool = Field(..., description='Whether device is confirmed')

    @classmethod
    def from_device(cls, device: EmailMFADevice) -> 'EmailDeviceResponse':
        """Create response from EmailMFADevice model."""
        return cls(
            device_id=str(device._object_id),
            user_email=device.user_email,
            name=device.name,
            email=device.email,
            confirmed=device.confirmed,
        )


class AddBackupCodesRequest(BaseModel):
    """Request model for adding backup codes."""

    target_user_email: str = Field(..., description='Email of user to add codes for')
    device_name: str = Field('Backup Codes', description='Name for the backup code set')
    code_count: int | None = Field(None, description='Number of codes to generate (optional)', ge=1, le=20)


class AddBackupCodesResponse(BaseModel):
    """Response model for adding backup codes."""

    model_config = ConfigDict(
        json_schema_extra={
            'example': {
                'device_count': 10,
                'codes': ['ABC123DEF456', 'GHI789JKL012', '...'],
            },
        },
    )

    device_count: int = Field(..., description='Number of backup codes generated')
    codes: list[str] = Field(..., description='Plaintext backup codes (DISPLAY ONCE)')


class ListDevicesRequest(BaseModel):
    """Request model for listing MFA devices."""

    target_user_email: str = Field(..., description='Email of user to list devices for')
    include_unconfirmed: bool = Field(False, description='Whether to include unconfirmed devices')


class DeviceInfo(BaseModel):
    """Device information for list response."""

    device_id: str = Field(..., description='Device ID')
    name: str = Field(..., description='Device name')
    confirmed: bool = Field(..., description='Whether device is confirmed')
    device_type: str = Field(..., description='Type of device')


class ListDevicesResponse(BaseModel):
    """Response model for listing MFA devices."""

    totp_devices: list[DeviceInfo] = Field(default_factory=list, description='TOTP authenticator devices')
    email_devices: list[DeviceInfo] = Field(default_factory=list, description='Email MFA devices')
    sms_devices: list[DeviceInfo] = Field(default_factory=list, description='SMS MFA devices')
    backup_codes: list[DeviceInfo] = Field(default_factory=list, description='Backup code devices')
    total_count: int = Field(..., description='Total number of devices')

    @classmethod
    def from_device_dict(cls, devices_by_type: dict) -> 'ListDevicesResponse':  # type: ignore[type-arg]
        """Create response from service layer result."""
        totp_devices = [
            DeviceInfo(
                device_id=device._object_id,
                name=device.name,
                confirmed=device.confirmed,
                device_type='totp',
            )
            for device in devices_by_type.get(DeviceType.TOTP, [])
        ]

        email_devices = [
            DeviceInfo(
                device_id=device._object_id,
                name=device.name,
                confirmed=device.confirmed,
                device_type='email',
            )
            for device in devices_by_type.get(DeviceType.EMAIL, [])
        ]

        sms_devices = [
            DeviceInfo(
                device_id=device._object_id,
                name=device.name,
                confirmed=device.confirmed,
                device_type='sms',
            )
            for device in devices_by_type.get(DeviceType.SMS, [])
        ]

        backup_codes = [
            DeviceInfo(
                device_id=device._object_id,
                name=device.name,
                confirmed=device.confirmed,
                device_type='backup_code',
            )
            for device in devices_by_type.get(DeviceType.BACKUP_CODE, [])
        ]

        total = len(totp_devices) + len(email_devices) + len(sms_devices) + len(backup_codes)

        return cls(
            totp_devices=totp_devices,
            email_devices=email_devices,
            sms_devices=sms_devices,
            backup_codes=backup_codes,
            total_count=total,
        )


class RemoveDeviceRequest(BaseModel):
    """Request model for removing MFA device."""

    device_id: str = Field(..., description='ID of device to remove')
    hard_delete: bool = Field(False, description='If True, permanently delete; if False, soft delete')


class RemoveDeviceResponse(BaseModel):
    """Response model for removing MFA device."""

    device_id: str = Field(..., description='ID of removed device')
    deleted: bool = Field(..., description='Whether device was permanently deleted')


# ============================================================================
# TRANSACTION FUNCTIONS
# ============================================================================


def _get_request() -> Request:
    """Helper to get current request from context."""
    return AmsdalContextManager().get_context().get('request')  # type: ignore[return-value]


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def add_mfa_email_device_transaction(
    target_user_email: str,
    device_name: str,
    email: str | None = None,
) -> EmailDeviceResponse:
    """
    Add email MFA device for a user.

    Email devices are automatically confirmed and can be used immediately.

    Args:
        target_user_email: Email of user to add device for.
        device_name: User-friendly name for the device.
        email: Email for MFA codes (defaults to target_user_email).

    Returns:
        EmailDeviceResponse: Created device details.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build device via service (no save)
    device = MFADeviceService.build_email_device(
        target_user_email=target_user_email,
        device_name=device_name,
        email=email,
    )

    # 2. Check permission BEFORE save
    if not device.has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save
    device.save(force_insert=True)

    return EmailDeviceResponse.from_device(device)


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def aadd_mfa_email_device_transaction(
    target_user_email: str,
    device_name: str,
    email: str | None = None,
) -> EmailDeviceResponse:
    """
    Async version of add_email_device_transaction.

    Add email MFA device for a user.

    Args:
        target_user_email: Email of user to add device for.
        device_name: User-friendly name for the device.
        email: Email for MFA codes (defaults to target_user_email).

    Returns:
        EmailDeviceResponse: Created device details.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build device via service (no save)
    device = await MFADeviceService.abuild_email_device(
        target_user_email=target_user_email,
        device_name=device_name,
        email=email,
    )

    # 2. Check permission BEFORE save
    if not device.has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save
    await device.asave(force_insert=True)

    return EmailDeviceResponse.from_device(device)


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def add_mfa_backup_codes_transaction(
    target_user_email: str,
    device_name: str,
    code_count: int | None = None,
) -> AddBackupCodesResponse:
    """
    Add backup codes for a user.

    Backup codes are one-time use codes that can be used if primary
    MFA methods are unavailable.

    Security Note:
        Plaintext codes are returned ONLY during creation.
        Caller must display/send these to user immediately.
        Codes cannot be retrieved later.

    Args:
        target_user_email: Email of user to add codes for.
        device_name: Name for the backup code set.
        code_count: Number of codes to generate (optional).

    Returns:
        AddBackupCodesResponse: Contains plaintext backup codes.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build devices via service (no save)
    devices, plaintext_codes = MFADeviceService.build_backup_codes(
        target_user_email=target_user_email,
        device_name=device_name,
        code_count=code_count,
    )

    # 2. Check permission using first device as representative
    if devices and not devices[0].has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save all devices
    for device in devices:
        device.save(force_insert=True)

    return AddBackupCodesResponse(
        device_count=len(devices),
        codes=plaintext_codes,
    )


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def aadd_mfa_backup_codes_transaction(
    target_user_email: str,
    device_name: str,
    code_count: int | None = None,
) -> AddBackupCodesResponse:
    """
    Async version of add_backup_codes_transaction.

    Add backup codes for a user.

    Args:
        target_user_email: Email of user to add codes for.
        device_name: Name for the backup code set.
        code_count: Number of codes to generate (optional).

    Returns:
        AddBackupCodesResponse: Contains plaintext backup codes.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build devices via service (no save)
    devices, plaintext_codes = await MFADeviceService.abuild_backup_codes(
        target_user_email=target_user_email,
        device_name=device_name,
        code_count=code_count,
    )

    # 2. Check permission using first device as representative
    if devices and not devices[0].has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save all devices
    for device in devices:
        await device.asave(force_insert=True)

    return AddBackupCodesResponse(
        device_count=len(devices),
        codes=plaintext_codes,
    )


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def list_mfa_devices_transaction(
    target_user_email: str,
    include_unconfirmed: bool = False,  # noqa: FBT001, FBT002
) -> ListDevicesResponse:
    """
    List all MFA devices for a user.

    Returns devices grouped by type (TOTP, Email, SMS, Backup Codes).
    Authorization is handled by checking if user can view devices for target_user_email.
    Super admins can view any user's devices, regular users can only view their own.

    Args:
        target_user_email: Email of user to list devices for.
        include_unconfirmed: Whether to include unconfirmed devices.

    Returns:
        ListDevicesResponse: Devices grouped by type.
    """
    from amsdal.contrib.auth.permissions import has_admin_permissions

    request = _get_request()

    # Check authorization: super admin can view any, regular user only their own
    if not has_admin_permissions(request.auth):
        auth_user = getattr(request, 'user', None)
        if not auth_user or not auth_user.is_authenticated or auth_user.identity != target_user_email:
            raise AmsdalAuthorizationError(
                action=Action.READ,
                resource_name='MFADevice',
                error_message=f'User does not have permission to list devices for {target_user_email}',
            )

    result: dict[DeviceType, list] = {}  # type: ignore[type-arg]

    for device_class, device_type in [
        (TOTPDevice, DeviceType.TOTP),
        (BackupCode, DeviceType.BACKUP_CODE),
        (EmailMFADevice, DeviceType.EMAIL),
        (SMSDevice, DeviceType.SMS),
    ]:
        query = device_class.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            _address__object_version=Versions.LATEST,
        )

        if not include_unconfirmed:
            query = query.filter(confirmed=True)

        result[device_type] = query.execute()

    return ListDevicesResponse.from_device_dict(result)


@allow_any
@transaction(tags=TAGS)  # type: ignore[call-arg]
def list_mfa_types_transaction(target_user_email: str) -> list[str]:
    result: dict[DeviceType, list] = {}  # type: ignore[type-arg]

    for device_class, device_type in [
        (TOTPDevice, DeviceType.TOTP),
        (BackupCode, DeviceType.BACKUP_CODE),
        (EmailMFADevice, DeviceType.EMAIL),
        (SMSDevice, DeviceType.SMS),
    ]:
        query = device_class.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            confirmed=True,
            _address__object_version=Versions.LATEST,
        )

        result[device_type] = query.execute()

    return list({device_type.value for device_type, devices in result.items() if devices})


@allow_any
@transaction(tags=TAGS)  # type: ignore[call-arg]
def generate_email_mfa_challenge_transaction(target_user_email: str) -> None:
    device = (
        EmailMFADevice.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            confirmed=True,
            _address__object_version=Versions.LATEST,
        )
        .first()
        .execute()
    )

    if not device:
        msg = 'No active email MFA device found for user'
        raise ValueError(msg)

    device.generate_and_send_code()
    device.save()


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def alist_mfa_devices_transaction(
    target_user_email: str,
    include_unconfirmed: bool = False,  # noqa: FBT001, FBT002
) -> ListDevicesResponse:
    """
    Async version of list_devices_transaction.

    List all MFA devices for a user.
    Authorization is handled by checking if user can view devices for target_user_email.
    Super admins can view any user's devices, regular users can only view their own.

    Args:
        target_user_email: Email of user to list devices for.
        include_unconfirmed: Whether to include unconfirmed devices.

    Returns:
        ListDevicesResponse: Devices grouped by type.
    """
    from amsdal.contrib.auth.permissions import has_admin_permissions

    request = _get_request()

    # Check authorization: super admin can view any, regular user only their own
    if not has_admin_permissions(request.auth):
        auth_user = getattr(request, 'user', None)
        if not auth_user or not auth_user.is_authenticated or auth_user.identity != target_user_email:
            raise AmsdalAuthorizationError(
                action=Action.READ,
                resource_name='MFADevice',
                error_message=f'User does not have permission to list devices for {target_user_email}',
            )

    result: dict[DeviceType, list] = {}  # type: ignore[type-arg]

    for device_class, device_type in [
        (TOTPDevice, DeviceType.TOTP),
        (BackupCode, DeviceType.BACKUP_CODE),
        (EmailMFADevice, DeviceType.EMAIL),
        (SMSDevice, DeviceType.SMS),
    ]:
        query = device_class.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            _address__object_version=Versions.LATEST,
        )

        if not include_unconfirmed:
            query = query.filter(confirmed=True)

        result[device_type] = await query.aexecute()

    return ListDevicesResponse.from_device_dict(result)


@allow_any
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def alist_mfa_types_transaction(target_user_email: str) -> list[str]:
    result: dict[DeviceType, list] = {}  # type: ignore[type-arg]

    for device_class, device_type in [
        (TOTPDevice, DeviceType.TOTP),
        (BackupCode, DeviceType.BACKUP_CODE),
        (EmailMFADevice, DeviceType.EMAIL),
        (SMSDevice, DeviceType.SMS),
    ]:
        query = device_class.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            confirmed=True,
            _address__object_version=Versions.LATEST,
        )

        result[device_type] = await query.aexecute()

    return list({device_type.value for device_type, devices in result.items() if devices})


@allow_any
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def agenerate_email_mfa_challenge_transaction(target_user_email: str) -> None:
    device = await (
        EmailMFADevice.objects.filter(  # type: ignore[attr-defined]
            user_email=target_user_email,
            is_active=True,
            confirmed=True,
            _address__object_version=Versions.LATEST,
        )
        .first()
        .aexecute()
    )

    if not device:
        msg = 'No active email MFA device found for user'
        raise ValueError(msg)

    device.generate_and_send_code()
    await device.asave()


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def remove_mfa_device_transaction(
    device_id: str,
    hard_delete: bool = False,  # noqa: FBT001, FBT002
) -> RemoveDeviceResponse:
    """
    Remove (deactivate or delete) an MFA device.

    By default performs soft delete (marks inactive) to preserve audit trail.
    Use hard_delete=True to permanently remove the device.

    Args:
        device_id: ID of device to remove.
        hard_delete: If True, permanently delete; if False, soft delete.

    Returns:
        RemoveDeviceResponse: Removal confirmation.

    Raises:
        AmsdalAuthorizationError: If user lacks permission.
        MFADeviceNotFoundError: If device doesn't exist.
    """
    request = _get_request()

    # 1. Find device via service
    device = MFADeviceService.find_device(device_id)

    # 2. Check permission BEFORE delete
    if not device.has_object_permission(request.user, Action.DELETE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.DELETE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to remove device {device_id}',
        )

    # 3. Delete (transaction level)
    if hard_delete:
        device.delete()
    else:
        device.is_active = False
        device.save()

    return RemoveDeviceResponse(
        device_id=device_id,
        deleted=hard_delete,
    )


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def aremove_mfa_device_transaction(
    device_id: str,
    hard_delete: bool = False,  # noqa: FBT001, FBT002
) -> RemoveDeviceResponse:
    """
    Async version of remove_device_transaction.

    Remove (deactivate or delete) an MFA device.

    Args:
        device_id: ID of device to remove.
        hard_delete: If True, permanently delete; if False, soft delete.

    Returns:
        RemoveDeviceResponse: Removal confirmation.

    Raises:
        AmsdalAuthorizationError: If user lacks permission.
        MFADeviceNotFoundError: If device doesn't exist.
    """
    request = _get_request()

    # 1. Find device via service
    device = await MFADeviceService.afind_device(device_id)

    # 2. Check permission BEFORE delete
    if not device.has_object_permission(request.user, Action.DELETE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.DELETE,
            resource_name='MFADevice',
            error_message=f'User does not have permission to remove device {device_id}',
        )

    # 3. Delete (transaction level)
    if hard_delete:
        await device.adelete()
    else:
        device.is_active = False
        await device.asave()

    return RemoveDeviceResponse(
        device_id=device_id,
        deleted=hard_delete,
    )
