"""TOTP device transaction wrappers for API endpoints."""

from amsdal_data.transactions.decorators import async_transaction
from amsdal_data.transactions.decorators import transaction
from amsdal_server.apps.common.errors import AmsdalAuthorizationError
from amsdal_server.apps.common.permissions.enums import Action
from pydantic import BaseModel
from pydantic import Field
from starlette.requests import Request

from amsdal.context.manager import AmsdalContextManager
from amsdal.contrib.auth.decorators import require_auth
from amsdal.contrib.auth.models.totp_device import TOTPDevice
from amsdal.contrib.auth.services.totp_service import TOTPService

# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

TAGS = ['Auth', 'MFA', 'TOTP']


class SetupTOTPDeviceRequest(BaseModel):
    """Request model for TOTP device setup."""

    target_user_email: str = Field(..., description='Email of user to setup device for')
    device_name: str = Field(..., description='User-friendly name for the device')
    issuer: str | None = Field(None, description='TOTP issuer name (optional)')


class SetupTOTPDeviceResponse(BaseModel):
    """Response model for TOTP device setup."""

    secret: str = Field(..., description='Base32 TOTP secret (show to user ONCE)')
    qr_code_url: str = Field(..., description='otpauth:// URL for QR code generation')
    device_id: str = Field(..., description='ID of unconfirmed device')


class ConfirmTOTPDeviceRequest(BaseModel):
    """Request model for TOTP device confirmation."""

    device_id: str = Field(..., description='ID of unconfirmed device from setup')
    verification_code: str = Field(..., description='6-digit code from authenticator app', min_length=6, max_length=6)


class ConfirmTOTPDeviceResponse(BaseModel):
    """Response model for TOTP device confirmation."""

    device_id: str = Field(..., description='ID of confirmed device')
    user_email: str = Field(..., description='User email')
    name: str = Field(..., description='Device name')
    confirmed: bool = Field(..., description='Confirmation status')

    @classmethod
    def from_device(cls, device: TOTPDevice) -> 'ConfirmTOTPDeviceResponse':
        """Create response from TOTPDevice model."""
        return cls(
            device_id=str(device._object_id),
            user_email=device.user_email,
            name=device.name,
            confirmed=device.confirmed,
        )


# ============================================================================
# TRANSACTION FUNCTIONS
# ============================================================================


def _get_request() -> Request:
    """Helper to get current request from context."""
    return AmsdalContextManager().get_context().get('request')  # type: ignore[return-value]


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def add_mfa_totp_device_transaction(
    target_user_email: str,
    device_name: str,
    issuer: str | None = None,
) -> SetupTOTPDeviceResponse:
    """
    Setup TOTP device (Step 1 of 2).

    Creates an unconfirmed TOTP device and returns the secret and QR code URL.
    The secret is only returned once and cannot be retrieved later.

    Args:
        target_user_email: Email of user to setup device for.
        device_name: User-friendly name for the device.
        issuer: TOTP issuer name (optional).

    Returns:
        SetupTOTPDeviceResponse: Contains secret, QR code URL, and device ID.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build device via service (no save)
    device, secret, qr_code_url = TOTPService.build_totp_device(
        target_user_email=target_user_email,
        device_name=device_name,
        issuer=issuer,
    )

    # 2. Check permission BEFORE save
    if not device.has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='TOTPDevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save
    device.save(force_insert=True)

    return SetupTOTPDeviceResponse(
        secret=secret,
        qr_code_url=qr_code_url,
        device_id=str(device._object_id),
    )


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def aadd_mfa_totp_device_transaction(
    target_user_email: str,
    device_name: str,
    issuer: str | None = None,
) -> SetupTOTPDeviceResponse:
    """
    Async version of add_mfa_totp_device_transaction.

    Setup TOTP device (Step 1 of 2).

    Args:
        target_user_email: Email of user to setup device for.
        device_name: User-friendly name for the device.
        issuer: TOTP issuer name (optional).

    Returns:
        SetupTOTPDeviceResponse: Contains secret, QR code URL, and device ID.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
    request = _get_request()

    # 1. Build device via service (no save)
    device, secret, qr_code_url = await TOTPService.abuild_totp_device(
        target_user_email=target_user_email,
        device_name=device_name,
        issuer=issuer,
    )

    # 2. Check permission BEFORE save
    if not device.has_object_permission(request.user, Action.CREATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.CREATE,
            resource_name='TOTPDevice',
            error_message=f'User does not have permission to create devices for {target_user_email}',
        )

    # 3. Save
    await device.asave(force_insert=True)

    return SetupTOTPDeviceResponse(
        secret=secret,
        qr_code_url=qr_code_url,
        device_id=str(device._object_id),
    )


@require_auth
@transaction(tags=TAGS)  # type: ignore[call-arg]
def confirm_mfa_totp_device_transaction(
    device_id: str,
    verification_code: str,
) -> ConfirmTOTPDeviceResponse:
    """
    Confirm TOTP device by verifying code (Step 2 of 2).

    Validates the verification code from the authenticator app and marks
    the device as confirmed if successful.

    Args:
        device_id: ID of unconfirmed device from setup.
        verification_code: 6-digit code from authenticator app.

    Returns:
        ConfirmTOTPDeviceResponse: Confirmed device details.

    Raises:
        MFADeviceNotFoundError: If device doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
        InvalidMFACodeError: If verification code is incorrect.
        MFASetupError: If device already confirmed.
    """
    request = _get_request()

    # 1. Find device via service
    device = TOTPService.find_totp_device(device_id)

    # 2. Check permission BEFORE confirmation
    if not device.has_object_permission(request.user, Action.UPDATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.UPDATE,
            resource_name='TOTPDevice',
            error_message=f'User does not have permission to confirm device {device_id}',
        )

    # 3. Confirm device (validates code, marks confirmed, but doesn't save)
    device = TOTPService.confirm_totp_device(device, verification_code)

    # 4. Save
    device.save()

    return ConfirmTOTPDeviceResponse.from_device(device)


@require_auth
@async_transaction(tags=TAGS)  # type: ignore[call-arg]
async def aconfirm_mfa_totp_device_transaction(
    device_id: str,
    verification_code: str,
) -> ConfirmTOTPDeviceResponse:
    """
    Async version of confirm_mfa_totp_device_transaction.

    Confirm TOTP device by verifying code (Step 2 of 2).

    Args:
        device_id: ID of unconfirmed device from setup.
        verification_code: 6-digit code from authenticator app.

    Returns:
        ConfirmTOTPDeviceResponse: Confirmed device details.

    Raises:
        MFADeviceNotFoundError: If device doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
        InvalidMFACodeError: If verification code is incorrect.
        MFASetupError: If device already confirmed.
    """
    request = _get_request()

    # 1. Find device via service
    device = await TOTPService.afind_totp_device(device_id)

    # 2. Check permission BEFORE confirmation
    if not device.has_object_permission(request.user, Action.UPDATE, auth=request.auth):
        raise AmsdalAuthorizationError(
            action=Action.UPDATE,
            resource_name='TOTPDevice',
            error_message=f'User does not have permission to confirm device {device_id}',
        )

    # 3. Confirm device (validates code, marks confirmed, but doesn't save)
    device = TOTPService.confirm_totp_device(device, verification_code)

    # 4. Save
    await device.asave()

    return ConfirmTOTPDeviceResponse.from_device(device)
