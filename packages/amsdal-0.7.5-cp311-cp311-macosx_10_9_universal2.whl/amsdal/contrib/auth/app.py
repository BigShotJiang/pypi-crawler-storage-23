from amsdal_utils.events import EventBus

from amsdal.contrib.app_config import AppConfig


class AuthAppConfig(AppConfig):
    """
    Configuration class for the authentication application.

    This class sets up the necessary listeners for various lifecycle events
    related to authentication and permission checks.
    """

    def on_setup(self) -> None:
        """
        Sets up listeners for various lifecycle events.

        This method adds listeners for server startup, authentication, authorization,
        and MFA code delivery.
        """
        from amsdal_server.apps.common.events.auth import AuthenticateEvent
        from amsdal_server.apps.common.events.authorize import ClassAuthorizeEvent
        from amsdal_server.apps.common.events.authorize import ObjectAuthorizeEvent
        from amsdal_server.apps.common.events.server import ServerStartupEvent

        from amsdal.contrib.auth.event_handlers import AuthenticateUserListener
        from amsdal.contrib.auth.event_handlers import CheckAndCreateSuperUserListener
        from amsdal.contrib.auth.event_handlers import ClassAuthorizeListener
        from amsdal.contrib.auth.event_handlers import ObjectAuthorizeListener
        from amsdal.contrib.auth.event_handlers import SendEmailMFACodeListener
        from amsdal.contrib.auth.events.mfa import SendMFACodeEvent

        EventBus.subscribe(ServerStartupEvent, CheckAndCreateSuperUserListener)
        EventBus.subscribe(AuthenticateEvent, AuthenticateUserListener)
        EventBus.subscribe(ClassAuthorizeEvent, ClassAuthorizeListener)
        EventBus.subscribe(ObjectAuthorizeEvent, ObjectAuthorizeListener)
        EventBus.subscribe(SendMFACodeEvent, SendEmailMFACodeListener)
