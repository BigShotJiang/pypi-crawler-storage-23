"""Composable permission classes for the auth system.

Provides DRF-style permission objects that can be combined with & (AND) and | (OR) operators.

Usage:
    from amsdal.contrib.auth.permissions import AllowAny, RequireAuth, RequirePermissions

    # Singletons
    AllowAny                                          # always allows
    RequireAuth                                       # requires authenticated user
    RequireAuth & RequirePermissions('models.Post:*') # requires auth AND matching permissions
    RequireAuth | AllowAny                            # requires auth OR allows any (always passes)
"""

from __future__ import annotations

from abc import ABC
from abc import abstractmethod
from typing import TYPE_CHECKING
from typing import Any

if TYPE_CHECKING:
    from amsdal_server.apps.common.permissions.enums import Action


class BasePermission(ABC):
    """Abstract base for all permission classes."""

    @abstractmethod
    def has_permission(self, request: Any, action: Action) -> bool:
        """Return True if permission is granted."""
        ...

    def __and__(self, other: BasePermission) -> BasePermission:
        return _AndPermission(self, other)

    def __or__(self, other: BasePermission) -> BasePermission:
        return _OrPermission(self, other)

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}()'


class _AndPermission(BasePermission):
    """Composite permission: both must pass."""

    def __init__(self, left: BasePermission, right: BasePermission) -> None:
        self.left = left
        self.right = right

    def has_permission(self, request: Any, action: Action) -> bool:
        return self.left.has_permission(request, action) and self.right.has_permission(request, action)

    def __repr__(self) -> str:
        return f'({self.left!r} & {self.right!r})'


class _OrPermission(BasePermission):
    """Composite permission: at least one must pass."""

    def __init__(self, left: BasePermission, right: BasePermission) -> None:
        self.left = left
        self.right = right

    def has_permission(self, request: Any, action: Action) -> bool:
        return self.left.has_permission(request, action) or self.right.has_permission(request, action)

    def __repr__(self) -> str:
        return f'({self.left!r} | {self.right!r})'


class _AllowAny(BasePermission):
    """Always grants permission."""

    def has_permission(self, request: Any, action: Action) -> bool:  # noqa: ARG002
        return True


class _RequireAuth(BasePermission):
    """Requires the user to be authenticated."""

    def has_permission(self, request: Any, action: Action) -> bool:  # noqa: ARG002
        if request is None:
            return False
        user = getattr(request, 'user', None)
        if user is None:
            return False
        return bool(getattr(user, 'is_authenticated', False))


class RequirePermissions(BasePermission):
    """Requires the user to have specific permission strings (all must match).

    Args:
        *permission_strings: Permission strings like 'models.Post:read'.
            All strings must match (AND logic). Use | operator for OR logic.
    """

    def __init__(self, *permission_strings: str) -> None:
        if not permission_strings:
            msg = 'RequirePermissions requires at least one permission string'
            raise ValueError(msg)
        self.permission_strings = permission_strings

    def has_permission(self, request: Any, action: Action) -> bool:  # noqa: ARG002
        from amsdal.contrib.auth.utils.scopes import match_scope

        if request is None:
            return False
        auth = getattr(request, 'auth', None)
        if auth is None:
            return False

        user_scopes = set(getattr(auth, 'scopes', []))
        return all(match_scope(perm, user_scopes) for perm in self.permission_strings)

    def __repr__(self) -> str:
        perms = ', '.join(repr(p) for p in self.permission_strings)
        return f'RequirePermissions({perms})'


# Module-level singleton instances
AllowAny = _AllowAny()
RequireAuth = _RequireAuth()


def has_admin_permissions(auth: Any) -> bool:
    """Check if auth credentials have super admin (full access) permissions.

    Args:
        auth: Auth credentials object (e.g. request.auth). Can be None.

    Returns:
        True if auth contains the '*:*' wildcard permission.
    """
    from amsdal.contrib.auth.utils.scopes import is_super_admin

    if auth is None:
        return False

    user_scopes = set(getattr(auth, 'scopes', []))
    return is_super_admin(user_scopes)


def has_permissions(required: str, auth: Any) -> bool:
    """Check if auth credentials have a specific permission (supports wildcards).

    Args:
        required: Permission string to check, e.g. 'models.Post:read'.
        auth: Auth credentials object (e.g. request.auth). Can be None.

    Returns:
        True if auth contains a matching permission.
    """
    from amsdal.contrib.auth.utils.scopes import match_scope

    if auth is None:
        return False

    user_scopes = set(getattr(auth, 'scopes', []))
    return match_scope(required, user_scopes)
