"""Permission decorators for the auth system.

Usage:
    from amsdal.contrib.auth.decorators import permissions, require_auth, allow_any
    from amsdal.contrib.auth.permissions import RequireAuth, AllowAny, RequirePermissions

    @permissions(RequireAuth)                              # blanket
    @permissions(read=RequireAuth, execute=RequireAuth & RequirePermissions('...'))  # per-action
    @require_auth                                          # alias for @permissions(RequireAuth)
    @allow_any                                             # alias for @permissions(AllowAny)
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Any

if TYPE_CHECKING:
    from amsdal.contrib.auth.permissions import BasePermission


class PermissionSet:
    """Container for per-action or blanket permissions.

    Stores a default permission and optional per-action overrides.
    `get_permission(action)` returns the action-specific permission or falls back to default.
    """

    def __init__(
        self,
        default: BasePermission | None = None,
        *,
        read: BasePermission | None = None,
        create: BasePermission | None = None,
        update: BasePermission | None = None,
        delete: BasePermission | None = None,
        execute: BasePermission | None = None,
    ) -> None:
        self.default = default
        self._actions: dict[str, BasePermission] = {}
        if read is not None:
            self._actions['read'] = read
        if create is not None:
            self._actions['create'] = create
        if update is not None:
            self._actions['update'] = update
        if delete is not None:
            self._actions['delete'] = delete
        if execute is not None:
            self._actions['execute'] = execute

    def get_permission(self, action_value: str) -> BasePermission | None:
        """Return action-specific permission or fall back to default."""
        return self._actions.get(action_value, self.default)


def permissions(
    perm: BasePermission | None = None,
    *,
    read: BasePermission | None = None,
    create: BasePermission | None = None,
    update: BasePermission | None = None,
    delete: BasePermission | None = None,
    execute: BasePermission | None = None,
) -> Any:
    """Decorator that sets __permissions__ on a class or function.

    Args:
        perm: Default permission for all actions. Mutually exclusive with per-action args
              when used as the only permission.
        read: Permission for read action.
        create: Permission for create action.
        update: Permission for update action.
        delete: Permission for delete action.
        execute: Permission for execute action.

    Usage:
        @permissions(RequireAuth)
        @permissions(read=AllowAny, create=RequireAuth)
        @permissions(RequireAuth, execute=RequireAuth & RequirePermissions('...'))
    """

    def decorator(func_or_class: Any) -> Any:
        perm_set = PermissionSet(
            default=perm,
            read=read,
            create=create,
            update=update,
            delete=delete,
            execute=execute,
        )
        func_or_class.__permissions__ = perm_set
        return func_or_class

    return decorator


def require_auth(func_or_class: Any) -> Any:
    """Alias for @permissions(RequireAuth)."""
    from amsdal.contrib.auth.permissions import RequireAuth as _RequireAuth

    return permissions(_RequireAuth)(func_or_class)


def allow_any(func_or_class: Any) -> Any:
    """Alias for @permissions(AllowAny)."""
    from amsdal.contrib.auth.permissions import AllowAny as _AllowAny

    return permissions(_AllowAny)(func_or_class)
