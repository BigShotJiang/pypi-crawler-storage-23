"""Utility functions for scope matching."""


def is_super_admin(scopes: set[str]) -> bool:
    """Check if scopes contain super admin wildcard.

    Args:
        scopes: Set of scopes to check

    Returns:
        True if scopes contain '*:*' wildcard
    """
    return '*:*' in scopes


def match_scope(required_scope: str, available_scopes: set[str]) -> bool:
    """Check if required scope matches any available scope (including wildcards).

    Supports wildcard patterns:
    - `*:*` - matches everything
    - `models.*:*` - matches all actions on all models
    - `models.MyModel:*` - matches all actions on MyModel
    - `models.*:read` - matches read action on all models

    Args:
        required_scope: The scope to check, e.g. 'models.MyModel:read'
        available_scopes: Set of scopes to match against

    Returns:
        True if required_scope matches any available scope
    """
    if required_scope in available_scopes:
        return True

    if '*:*' in available_scopes:
        return True

    try:
        resource_part, action = required_scope.rsplit(':', 1)
        resource_type, resource_name = resource_part.split('.', 1)
    except ValueError:
        return False

    patterns = [
        f'{resource_type}.*:*',
        f'{resource_type}.{resource_name}:*',
        f'{resource_type}.*:{action}',
    ]

    return any(pattern in available_scopes for pattern in patterns)
