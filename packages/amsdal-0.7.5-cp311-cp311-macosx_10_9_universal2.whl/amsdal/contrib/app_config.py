from abc import ABC
from abc import abstractmethod


class AppConfig(ABC):
    @abstractmethod
    def on_setup(self) -> None: ...
