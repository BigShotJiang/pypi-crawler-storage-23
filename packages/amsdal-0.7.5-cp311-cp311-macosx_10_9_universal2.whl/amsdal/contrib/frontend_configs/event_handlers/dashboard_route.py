"""Event listener for registering dashboard config route."""

import typing as t

from amsdal_server.apps.common.events.server import RouterSetupContext
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn
from fastapi import APIRouter
from fastapi.responses import JSONResponse


async def _aget_config() -> dict[str, t.Any] | None:
    from amsdal.contrib.frontend_configs.models.frontend_config_dashboard import FrontendConfigDashboard

    config = await FrontendConfigDashboard.objects.filter(_address__object_id='default').first().aexecute()

    if not config:
        return None

    return config.model_dump(mode='json')


def _get_config() -> dict[str, t.Any] | None:
    from amsdal.contrib.frontend_configs.models.frontend_config_dashboard import FrontendConfigDashboard

    config = FrontendConfigDashboard.objects.filter(_address__object_id='default').first().execute()

    if not config:
        return None

    return config.model_dump(mode='json')


class DashboardRouteListener(EventListener[RouterSetupContext]):
    """Listener that registers the dashboard config route."""

    def handle(
        self,
        context: RouterSetupContext,
        next_fn: NextFn[RouterSetupContext],
    ) -> RouterSetupContext:
        router = APIRouter()

        @router.get('/api/contrib/frontend-config/dashboard/config')
        async def get_dashboard_config() -> JSONResponse:
            if AmsdalConfigManager().get_config().async_mode:
                _data = await _aget_config()
            else:
                _data = _get_config()

            return JSONResponse(_data)

        context.app.include_router(router)

        return next_fn(context)

    async def ahandle(
        self,
        context: RouterSetupContext,
        next_fn: AsyncNextFn[RouterSetupContext],
    ) -> RouterSetupContext:
        return self.handle(context, next_fn)  # type: ignore[arg-type]
