# mypy: disable-error-code="arg-type"
"""Event listeners for adding control field to object responses."""

import contextlib
from typing import Any

from amsdal_models.classes.errors import AmsdalClassNotFoundError
from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseContext
from amsdal_server.apps.objects.events.pre_response import ObjectListPreResponseContext
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn
from amsdal_utils.models.data_models.core import LegacyDictSchema
from amsdal_utils.models.data_models.enums import CoreTypes
from amsdal_utils.models.enums import Versions
from amsdal_utils.schemas.schema import PropertyData

from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectDetailResponse
from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectListResponse

_CORE_TO_FRONTEND_TYPES = {
    CoreTypes.NUMBER.value: 'number',
    CoreTypes.INTEGER.value: 'integer',
    CoreTypes.BOOLEAN.value: 'checkbox',
    CoreTypes.STRING.value: 'text',
    CoreTypes.ANYTHING.value: 'text',
    CoreTypes.BINARY.value: 'text',
    CoreTypes.DATE.value: 'date',
    CoreTypes.DATETIME.value: 'datetime',
}


def _process_property(field_name: str, property_data: PropertyData) -> dict[str, Any]:
    """Convert property data to frontend configuration dictionary."""
    type_definition: dict[str, Any]

    if property_data.type in _CORE_TO_FRONTEND_TYPES:
        type_definition = {'type': _CORE_TO_FRONTEND_TYPES[property_data.type]}
    elif property_data.type == CoreTypes.ARRAY.value:
        type_definition = {
            'type': 'array',
            'control': _process_property(f'{field_name}_items', property_data.items),
        }
    elif property_data.type == CoreTypes.DICTIONARY.value:
        if isinstance(property_data.items, LegacyDictSchema):
            type_definition = {
                'type': 'dict',
                'control': _process_property(
                    f'{field_name}_items',
                    PropertyData(
                        type=property_data.items.key_type,
                        items=None,
                        title=None,
                        read_only=False,
                        options=None,
                        default=None,
                        field_name=field_name,
                        field_id=None,
                        is_deleted=False,
                    ),
                ),
            }
        else:
            type_definition = {
                'type': 'dict',
                'control': _process_property(f'{field_name}_items', property_data.items.key),  # type: ignore[union-attr]
            }
    elif property_data.type == 'File':
        type_definition = {'type': 'file'}
    else:
        type_definition = {'type': 'object_latest', 'entityType': property_data.type}

    if getattr(property_data, 'default', None) is not None:
        type_definition['value'] = property_data.default

    if getattr(property_data, 'options', None) is not None:
        type_definition['options'] = [{'label': option.key, 'value': option.value} for option in property_data.options]  # type: ignore[union-attr]

    return {
        'name': field_name,
        'label': property_data.title if hasattr(property_data, 'title') and property_data.title else field_name,
        **type_definition,
    }


def _populate_frontend_config_with_values(config: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
    """Populate frontend config with values from response."""
    if config.get('controls') and isinstance(config['controls'], list):
        for control in config['controls']:
            _populate_frontend_config_with_values(control, values)

    if config.get('name') in values:
        config['value'] = values[config['name']]

    return config


def _get_values_from_response(response: dict[str, Any] | list[dict[str, Any]]) -> dict[str, Any]:
    """Extract values from response rows."""
    if not isinstance(response, dict) or 'rows' not in response or not response['rows']:
        return {}

    for row in response['rows']:
        if '_metadata' in row and row['_metadata'].get('next_version') is None:
            return row

    return response['rows'][0]


def _get_default_control(class_name: str) -> dict[str, Any]:
    """Get default frontend control config for a class."""
    from amsdal_models.classes.class_manager import ClassManager

    from amsdal.contrib.frontend_configs.conversion import convert_to_frontend_config
    from amsdal.contrib.frontend_configs.models.frontend_control_config import FrontendControlConfig
    from amsdal.models.core.file import File

    target_class = None
    with contextlib.suppress(AmsdalClassNotFoundError):
        target_class = ClassManager().import_class(class_name)

    if not target_class:
        return {}

    if target_class is File:
        config = {
            'type': 'group',
            'name': 'File',
            'label': 'File',
            'controls': [
                {'label': 'Filename', 'name': 'filename', 'type': 'text', 'required': True},
                {'label': 'Data', 'name': 'data', 'type': 'Bytes', 'required': True},
                {'label': 'Size', 'name': 'size', 'type': 'number', 'required': False},
            ],
        }
    else:
        config = convert_to_frontend_config(target_class, is_transaction=False)

    return FrontendControlConfig(**config).model_dump(exclude_none=True)


async def _aget_default_control(class_name: str) -> dict[str, Any]:
    """Async version: Get default frontend control config for a class."""
    from amsdal_models.classes.class_manager import ClassManager

    from amsdal.contrib.frontend_configs.conversion import aconvert_to_frontend_config
    from amsdal.contrib.frontend_configs.models.frontend_control_config import FrontendControlConfig
    from amsdal.models.core.file import File

    target_class = None
    with contextlib.suppress(AmsdalClassNotFoundError):
        target_class = ClassManager().import_class(class_name)

    if not target_class:
        return {}

    if target_class is File:
        config = {
            'type': 'group',
            'name': 'File',
            'label': 'File',
            'controls': [
                {'label': 'Filename', 'name': 'filename', 'type': 'text', 'required': True},
                {'label': 'Data', 'name': 'data', 'type': 'Bytes', 'required': True},
                {'label': 'Size', 'name': 'size', 'type': 'number', 'required': False},
            ],
        }
    else:
        config = await aconvert_to_frontend_config(target_class, is_transaction=False)

    return FrontendControlConfig(**config).model_dump(exclude_none=True)


def _get_control_config(class_name: str) -> dict[str, Any] | None:
    """Load control config from FrontendModelConfig or get default."""
    from amsdal.contrib.frontend_configs.models.frontend_model_config import FrontendModelConfig

    config = (
        FrontendModelConfig.objects.all()
        .first(
            class_name=class_name,
            _metadata__is_deleted=False,
            _address__object_version=Versions.LATEST,
        )
        .execute()
    )

    if config and config.control:
        return config.control.model_dump(exclude_none=True)

    return _get_default_control(class_name)


async def _aget_control_config(class_name: str) -> dict[str, Any] | None:
    """Async version: Load control config from FrontendModelConfig or get default."""
    from amsdal.contrib.frontend_configs.models.frontend_model_config import FrontendModelConfig

    config = await (
        FrontendModelConfig.objects.all()
        .first(
            class_name=class_name,
            _metadata__is_deleted=False,
            _address__object_version=Versions.LATEST,
        )
        .aexecute()
    )

    if config and config.control:
        return config.control.model_dump(exclude_none=True)

    return await _aget_default_control(class_name)


class ObjectListControlListener(EventListener[ObjectListPreResponseContext]):
    """Listener that adds control field to object list response."""

    def handle(
        self,
        context: ObjectListPreResponseContext,
        next_fn: NextFn[ObjectListPreResponseContext],
    ) -> ObjectListPreResponseContext:
        control_config = _get_control_config(context.class_name)

        if control_config:
            control = _populate_frontend_config_with_values(control_config, {})
            new_response = ExtendedObjectListResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return next_fn(context)

    async def ahandle(
        self,
        context: ObjectListPreResponseContext,
        next_fn: AsyncNextFn[ObjectListPreResponseContext],
    ) -> ObjectListPreResponseContext:
        control_config = await _aget_control_config(context.class_name)

        if control_config:
            control = _populate_frontend_config_with_values(control_config, {})
            new_response = ExtendedObjectListResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return await next_fn(context)


class ObjectDetailControlListener(EventListener[ObjectDetailPreResponseContext]):
    """Listener that adds control field to object detail response."""

    def handle(
        self,
        context: ObjectDetailPreResponseContext,
        next_fn: NextFn[ObjectDetailPreResponseContext],
    ) -> ObjectDetailPreResponseContext:
        control_config = _get_control_config(context.class_name)

        if control_config:
            values = _get_values_from_response(context.response.model_dump())
            control = _populate_frontend_config_with_values(control_config, values)
            new_response = ExtendedObjectDetailResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return next_fn(context)

    async def ahandle(
        self,
        context: ObjectDetailPreResponseContext,
        next_fn: AsyncNextFn[ObjectDetailPreResponseContext],
    ) -> ObjectDetailPreResponseContext:
        control_config = await _aget_control_config(context.class_name)

        if control_config:
            values = _get_values_from_response(context.response.model_dump())
            control = _populate_frontend_config_with_values(control_config, values)
            new_response = ExtendedObjectDetailResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return await next_fn(context)
