# mypy: disable-error-code="arg-type"
"""Event listeners for adding control field to transaction responses."""

from typing import Any

from amsdal_server.apps.transactions.events.pre_response import TransactionDetailPreResponseContext
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn

from amsdal.contrib.frontend_configs.conversion import convert_to_frontend_config
from amsdal.contrib.frontend_configs.serializers.extended_transaction_response import ExtendedTransactionDetailResponse


def _build_transaction_control(transaction_name: str) -> dict[str, Any] | None:
    """Build frontend control config for a transaction."""
    from amsdal_server.apps.transactions.services.transaction_api import TransactionApi

    for definition, file_path in TransactionApi.get_transaction_definitions():
        if definition.name == transaction_name:
            transaction_function = TransactionApi.load_transaction_function(definition, file_path)
            return convert_to_frontend_config(transaction_function)
    return None


class TransactionDetailControlListener(EventListener[TransactionDetailPreResponseContext]):
    """Listener that adds control field to transaction detail response."""

    def handle(
        self,
        context: TransactionDetailPreResponseContext,
        next_fn: NextFn[TransactionDetailPreResponseContext],
    ) -> TransactionDetailPreResponseContext:
        control = _build_transaction_control(context.transaction_name)

        if control:
            new_response = ExtendedTransactionDetailResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return next_fn(context)

    async def ahandle(
        self,
        context: TransactionDetailPreResponseContext,
        next_fn: AsyncNextFn[TransactionDetailPreResponseContext],
    ) -> TransactionDetailPreResponseContext:
        control = _build_transaction_control(context.transaction_name)

        if control:
            new_response = ExtendedTransactionDetailResponse(
                **context.response.model_dump(),
                control=control,
            )
            context = context.create_next(
                listener_id=self.listener_id,
                response=new_response,
            )

        return await next_fn(context)
