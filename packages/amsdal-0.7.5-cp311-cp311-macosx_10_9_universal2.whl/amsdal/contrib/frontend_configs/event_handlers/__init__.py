"""Event handlers for frontend_configs plugin."""

from amsdal.contrib.frontend_configs.event_handlers.dashboard_route import DashboardRouteListener
from amsdal.contrib.frontend_configs.event_handlers.object_control import ObjectDetailControlListener
from amsdal.contrib.frontend_configs.event_handlers.object_control import ObjectListControlListener
from amsdal.contrib.frontend_configs.event_handlers.transaction_control import TransactionDetailControlListener

__all__ = [
    'DashboardRouteListener',
    'ObjectDetailControlListener',
    'ObjectListControlListener',
    'TransactionDetailControlListener',
]
