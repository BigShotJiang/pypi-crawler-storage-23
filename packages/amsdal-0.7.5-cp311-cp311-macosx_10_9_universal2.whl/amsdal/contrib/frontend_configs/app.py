from amsdal_utils.events import EventBus

from amsdal.contrib.app_config import AppConfig


class FrontendConfigAppConfig(AppConfig):
    """
    Application configuration class for frontend configurations.

    This class extends the AppConfig and sets up event listeners
    to process frontend configurations.
    """

    def on_setup(self) -> None:
        """
        Registers extended response models and event listeners.

        This method:
        1. Registers ExtendedColumnInfo to extend the base ColumnInfo model
        2. Registers extended object/transaction response models with 'control' field
        3. Subscribes event listeners to add 'control' field to responses
        4. Subscribes route listener for dashboard config endpoint

        Returns:
            None
        """
        from amsdal_server.apps.common.events.server import RouterSetupEvent
        from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseEvent
        from amsdal_server.apps.objects.events.pre_response import ObjectListPreResponseEvent
        from amsdal_server.apps.transactions.events.pre_response import TransactionDetailPreResponseEvent
        from amsdal_server.registry import ResponseModelRegistry

        from amsdal.contrib.frontend_configs.event_handlers import DashboardRouteListener
        from amsdal.contrib.frontend_configs.event_handlers import ObjectDetailControlListener
        from amsdal.contrib.frontend_configs.event_handlers import ObjectListControlListener
        from amsdal.contrib.frontend_configs.event_handlers import TransactionDetailControlListener
        from amsdal.contrib.frontend_configs.serializers import ExtendedColumnInfo
        from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectDetailResponse
        from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectListResponse
        from amsdal.contrib.frontend_configs.serializers.extended_transaction_response import (
            ExtendedTransactionDetailResponse,
        )

        # Register extended models
        ResponseModelRegistry.register('ColumnInfo', ExtendedColumnInfo)
        ResponseModelRegistry.register('ObjectListResponse', ExtendedObjectListResponse)
        ResponseModelRegistry.register('ObjectDetailResponse', ExtendedObjectDetailResponse)
        ResponseModelRegistry.register('TransactionDetailResponse', ExtendedTransactionDetailResponse)

        # Subscribe event listeners for adding 'control' field
        EventBus.subscribe(ObjectListPreResponseEvent, ObjectListControlListener)
        EventBus.subscribe(ObjectDetailPreResponseEvent, ObjectDetailControlListener)
        EventBus.subscribe(TransactionDetailPreResponseEvent, TransactionDetailControlListener)

        # Subscribe route listener for dashboard config endpoint
        EventBus.subscribe(RouterSetupEvent, DashboardRouteListener)
