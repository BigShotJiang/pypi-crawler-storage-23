from amsdal_models.migration import migrations
from amsdal_utils.models.enums import ModuleType


class Migration(migrations.Migration):
    operations: list[migrations.Operation] = [
        migrations.UpdateClass(
            module_type=ModuleType.CONTRIB,
            class_name='FrontendConfigDashboardElement',
            old_schema={
                'title': 'FrontendConfigDashboardElement',
                'required': ['type'],
                'properties': {
                    'type': {
                        'type': 'string',
                        'options': [
                            {'key': 'section', 'value': 'section'},
                            {'key': 'grid', 'value': 'grid'},
                            {'key': 'grid_col', 'value': 'grid_col'},
                            {'key': 'chart', 'value': 'chart'},
                            {'key': 'table', 'value': 'table'},
                            {'key': 'form', 'value': 'form'},
                        ],
                        'title': 'Type',
                        'enum': ['section', 'grid', 'grid_col', 'chart', 'table', 'form'],
                    },
                    'chart_type': {
                        'type': 'string',
                        'title': 'Chart Type',
                        'description': 'Type of chart (for chart elements)',
                    },
                    'columns': {
                        'type': 'integer',
                        'title': 'Columns',
                        'description': 'Number of columns for grid layout',
                    },
                    'rows': {'type': 'integer', 'title': 'Rows', 'description': 'Number of rows for grid layout'},
                    'title': {'type': 'string', 'title': 'Title', 'description': 'Title of the dashboard element'},
                    'elements': {
                        'type': 'array',
                        'items': {'type': 'FrontendConfigDashboardElement', 'title': 'FrontendConfigDashboardElement'},
                        'title': 'Elements',
                        'description': 'Nested dashboard elements for section or grid types',
                    },
                    'control_source': {
                        'type': 'FrontendConfigDashboardControlSource',
                        'title': 'FrontendConfigDashboardControlSource',
                        'description': 'Control source configuration for form elements',
                    },
                    'data_source': {
                        'type': 'FrontendConfigDashboardDataSource',
                        'title': 'FrontendConfigDashboardDataSource',
                        'description': 'Data source configuration for chart or table elements',
                    },
                },
                'meta_class': 'TypeMeta',
                'custom_code': 'from amsdal.contrib.frontend_configs.models.frontend_control_config import *',
                'storage_metadata': {
                    'table_name': 'FrontendConfigDashboardElement',
                    'db_fields': {},
                    'foreign_keys': {},
                },
            },
            new_schema={
                'title': 'FrontendConfigDashboardElement',
                'required': ['type'],
                'properties': {
                    'type': {
                        'type': 'string',
                        'options': [
                            {'key': 'section', 'value': 'section'},
                            {'key': 'grid', 'value': 'grid'},
                            {'key': 'grid_col', 'value': 'grid_col'},
                            {'key': 'chart', 'value': 'chart'},
                            {'key': 'table', 'value': 'table'},
                            {'key': 'form', 'value': 'form'},
                        ],
                        'title': 'Type',
                        'enum': ['section', 'grid', 'grid_col', 'chart', 'table', 'form'],
                    },
                    'chart_type': {
                        'type': 'string',
                        'title': 'Chart Type',
                        'description': 'Type of chart (for chart elements)',
                    },
                    'columns': {
                        'type': 'integer',
                        'title': 'Columns',
                        'description': 'Number of columns for grid layout',
                    },
                    'rows': {'type': 'integer', 'title': 'Rows', 'description': 'Number of rows for grid layout'},
                    'title': {'type': 'string', 'title': 'Title', 'description': 'Title of the dashboard element'},
                    'elements': {
                        'type': 'array',
                        'items': {'type': 'FrontendConfigDashboardElement', 'title': 'FrontendConfigDashboardElement'},
                        'title': 'Elements',
                        'description': 'Nested dashboard elements for section or grid types',
                    },
                    'control_source': {
                        'type': 'FrontendConfigDashboardControlSource',
                        'title': 'FrontendConfigDashboardControlSource',
                        'description': 'Control source configuration for form elements',
                    },
                    'data_source': {
                        'type': 'FrontendConfigDashboardDataSource',
                        'title': 'FrontendConfigDashboardDataSource',
                        'description': 'Data source configuration for chart or table elements',
                    },
                    'on_row_click': {
                        'type': 'array',
                        'items': {
                            'type': 'FrontendConfigControlAction|InvokeAction|UpdateValueAction|ChangeContextAction|SaveAction',
                            'description': 'Navigation action for form controls (backward compatible).',
                            'title': 'FrontendConfigControlAction',
                        },
                        'title': 'On Row Click',
                        'description': 'Actions to execute when a table row is clicked',
                    },
                },
                'meta_class': 'TypeMeta',
                'custom_code': 'from amsdal.contrib.frontend_configs.models.frontend_control_config import *',
                'storage_metadata': {
                    'table_name': 'FrontendConfigDashboardElement',
                    'db_fields': {},
                    'foreign_keys': {},
                },
            },
        ),
    ]
