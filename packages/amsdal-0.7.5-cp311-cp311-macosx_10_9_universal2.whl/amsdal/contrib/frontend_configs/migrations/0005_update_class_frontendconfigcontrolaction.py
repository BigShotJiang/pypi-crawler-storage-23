from amsdal_models.migration import migrations
from amsdal_utils.models.enums import ModuleType


class Migration(migrations.Migration):
    operations: list[migrations.Operation] = [
        migrations.UpdateClass(
            module_type=ModuleType.CONTRIB,
            class_name="FrontendConfigControlAction",
            old_schema={
                "title": "FrontendConfigControlAction",
                "type": "FrontendConfigSkipNoneBase",
                "required": ["action", "text", "type"],
                "properties": {
                    "action": {"type": "string", "title": "Action"},
                    "text": {"type": "string", "title": "Text"},
                    "type": {"type": "string", "title": "Type"},
                    "dataLayerEvent": {"type": "string", "title": "Data Layer Event"},
                    "activator": {"type": "string", "title": "Activator"},
                    "icon": {"type": "string", "title": "Icon"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic import field_validator\n\n\n@field_validator('action', mode='after')\n@classmethod\ndef validate_action(cls, v: str) -> str:\n    \"\"\"\n        Validates the action string to ensure it is one of the allowed values.\n\n        This method checks if the action string starts with 'navigate::' or is one of the predefined\n        actions. If the action string is invalid, it raises a ValueError.\n\n        Args:\n            cls: The class this method is attached to.\n            v (str): The action string to validate.\n\n        Returns:\n            str: The validated action string.\n\n        Raises:\n            ValueError: If the action string is not valid.\n        \"\"\"\n    if not v.startswith('navigate::') and v not in ['goPrev', 'goNext', 'goNextWithSubmit', 'submit', 'submitWithDataLayer']:\n        msg = 'Action must be one of: goPrev, goNext, goNextWithSubmit, submit, submitWithDataLayer, navigate::{string}'\n        raise ValueError(msg)\n    return v\n\n@field_validator('type')\n@classmethod\ndef validate_value_in_options_type(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['action-button', 'arrow-next', 'arrow-prev', 'text-next', 'text-prev'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigControlAction", "db_fields": {}, "foreign_keys": {}},
                "description": "Navigation action for form controls (backward compatible).",
            },
            new_schema={
                "title": "FrontendConfigControlAction",
                "type": "FrontendConfigSkipNoneBase",
                "required": ["action", "text", "type"],
                "properties": {
                    "action": {"type": "string", "title": "Action"},
                    "text": {"type": "string", "title": "Text"},
                    "type": {"type": "string", "title": "Type"},
                    "dataLayerEvent": {"type": "string", "title": "Data Layer Event"},
                    "activator": {"type": "string", "title": "Activator"},
                    "icon": {"type": "string", "title": "Icon"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic import field_validator\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\n\n\n@field_validator('action', mode='after')\n@classmethod\ndef validate_action(cls, v: str) -> str:\n    \"\"\"\n        Validates the action string to ensure it is one of the allowed values.\n\n        This method checks if the action string starts with 'navigate::' or is one of the predefined\n        actions. If the action string is invalid, it raises a ValueError.\n\n        Args:\n            cls: The class this method is attached to.\n            v (str): The action string to validate.\n\n        Returns:\n            str: The validated action string.\n\n        Raises:\n            ValueError: If the action string is not valid.\n        \"\"\"\n    if not v.startswith('navigate::') and v not in ['goPrev', 'goNext', 'goNextWithSubmit', 'submit', 'submitWithDataLayer']:\n        msg = 'Action must be one of: goPrev, goNext, goNextWithSubmit, submit, submitWithDataLayer, navigate::{string}'\n        raise ValueError(msg)\n    return v\n\n@field_validator('type')\n@classmethod\ndef validate_value_in_options_type(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['action-button', 'arrow-next', 'arrow-prev', 'text-next', 'text-prev'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigControlAction", "db_fields": {}, "foreign_keys": {}},
                "description": "Navigation action for form controls (backward compatible).",
            },
        ),
        migrations.UpdateClass(
            module_type=ModuleType.CONTRIB,
            class_name="FrontendConfigGroupValidator",
            old_schema={
                "title": "FrontendConfigGroupValidator",
                "type": "FrontendConfigSkipNoneBase",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigGroupValidator", "db_fields": {}, "foreign_keys": {}},
            },
            new_schema={
                "title": "FrontendConfigGroupValidator",
                "type": "FrontendConfigSkipNoneBase",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigGroupValidator", "db_fields": {}, "foreign_keys": {}},
            },
        ),
        migrations.UpdateClass(
            module_type=ModuleType.CONTRIB,
            class_name="FrontendActivatorConfig",
            old_schema={
                "title": "FrontendActivatorConfig",
                "type": "FrontendConfigGroupValidator",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                    "value": {"type": "anything", "title": "Value"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_group_validator import *\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendActivatorConfig", "db_fields": {}, "foreign_keys": {}},
            },
            new_schema={
                "title": "FrontendActivatorConfig",
                "type": "FrontendConfigGroupValidator",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                    "value": {"type": "anything", "title": "Value"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_group_validator import *\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendActivatorConfig", "db_fields": {}, "foreign_keys": {}},
            },
        ),
        migrations.UpdateClass(
            module_type=ModuleType.CONTRIB,
            class_name="FrontendConfigValidator",
            old_schema={
                "title": "FrontendConfigValidator",
                "type": "FrontendConfigGroupValidator",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                    "function": {"type": "string", "title": "Function"},
                    "value": {"type": "string", "title": "Value"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_group_validator import *\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\n@field_validator('function')\n@classmethod\ndef validate_value_in_options_function(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['max', 'maxLength', 'min', 'minLength', 'pattern', 'required'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigValidator", "db_fields": {}, "foreign_keys": {}},
            },
            new_schema={
                "title": "FrontendConfigValidator",
                "type": "FrontendConfigGroupValidator",
                "properties": {
                    "mainControl": {"type": "string", "title": "Main Control"},
                    "dependentControls": {"type": "array", "items": {"type": "string"}, "title": "Dependent Controls"},
                    "condition": {"type": "string", "title": "Condition"},
                    "function": {"type": "string", "title": "Function"},
                    "value": {"type": "string", "title": "Value"},
                },
                "meta_class": "TypeMeta",
                "custom_code": "from typing import Any\n\nfrom amsdal_models.builder.validators.options_validators import validate_options\nfrom pydantic.functional_validators import field_validator\n\nfrom amsdal.contrib.frontend_configs.models.frontend_config_group_validator import *\nfrom amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *\n\n\n@field_validator('condition')\n@classmethod\ndef validate_value_in_options_condition(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['eq', 'exist', 'gt', 'gte', 'lt', 'lte', 'neq'])\n\n@field_validator('function')\n@classmethod\ndef validate_value_in_options_function(cls: type, value: Any) -> Any:\n    return validate_options(value, options=['max', 'maxLength', 'min', 'minLength', 'pattern', 'required'])\n\ndef model_dump(self, **kwargs: Any) -> dict[str, Any]:\n    kwargs['exclude_none'] = True\n    return super().model_dump(**kwargs)\n\ndef model_dump_json(self, **kwargs: Any) -> str:\n    kwargs['exclude_none'] = True\n    return super().model_dump_json(**kwargs)",
                "storage_metadata": {"table_name": "FrontendConfigValidator", "db_fields": {}, "foreign_keys": {}},
            },
        ),
    ]
