from typing import Any
from typing import ClassVar
from typing import Literal
from typing import Optional

from amsdal_models.classes.model import Model
from amsdal_models.classes.model import TypeModel
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

from amsdal.contrib.frontend_configs.models.frontend_control_config import *  # noqa: F403


class FrontendConfigDashboardQueryParams(TypeModel):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    field: str = Field(..., description='Field name for the query parameter')
    operator: str = Field(..., description='Operator for the query parameter')
    value: Optional[Any] = Field(default=None, description='Value for the query parameter')


class FrontendConfigDashboardDataSource(TypeModel):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    type: Literal['class', 'transaction']
    method_type: Literal['GET', 'POST'] | None = Field(default=None, description='HTTP method type for the data source')
    entity_name: str = Field(..., description='Name of the entity or transaction')
    query_params: list[FrontendConfigDashboardQueryParams] | None = Field(
        default=None, description='List of query parameters for filtering data (for class type)'
    )
    body: Any = Field(default=None, description='Request body for transaction data source (for transaction type)')


class FrontendConfigDashboardControlSource(TypeModel):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    type: Literal['static', 'dynamic']
    static_value: Optional['FrontendControlConfig'] = Field(default=None, title='Control')  # noqa: F405
    dynamic_value: FrontendConfigDashboardDataSource | None = Field(
        default=None, description='Data source configuration for control'
    )


class FrontendConfigDashboardElement(TypeModel):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    type: Literal['section', 'grid', 'grid_col', 'chart', 'table', 'form']
    chart_type: str | None = Field(default=None, description='Type of chart (for chart elements)')
    columns: int | None = Field(default=None, description='Number of columns for grid layout')
    rows: int | None = Field(default=None, description='Number of rows for grid layout')
    title: str | None = Field(default=None, description='Title of the dashboard element')
    elements: list['FrontendConfigDashboardElement'] | None = Field(
        default=None, description='Nested dashboard elements for section or grid types'
    )
    control_source: FrontendConfigDashboardControlSource | None = Field(
        default=None, description='Control source configuration for form elements'
    )
    data_source: FrontendConfigDashboardDataSource | None = Field(
        default=None, description='Data source configuration for chart or table elements'
    )
    on_row_click: list['ActionType'] | None = Field(  # noqa: F405
        default=None, description='Actions to execute when a table row is clicked'
    )


class FrontendConfigDashboard(Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    title: str = Field(..., description='Title of the dashboard')
    elements: list[FrontendConfigDashboardElement] = Field(..., description='List of dashboard elements')
