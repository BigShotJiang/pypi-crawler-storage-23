# mypy: disable-error-code="name-defined"
"""Extended transaction response models with control field."""

from typing import Any

from amsdal_server.apps.transactions.serializers.responses import _TransactionDetailResponse


class ExtendedTransactionDetailResponse(_TransactionDetailResponse):
    """Transaction detail response with optional control field."""

    control: dict[str, Any] | None = None
