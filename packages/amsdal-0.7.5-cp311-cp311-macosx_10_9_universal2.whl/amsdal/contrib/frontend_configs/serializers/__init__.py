"""Frontend configs serializers."""

from amsdal.contrib.frontend_configs.serializers.extended_column_info import ExtendedColumnInfo
from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectDetailResponse
from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectListResponse

__all__ = [
    'ExtendedColumnInfo',
    'ExtendedObjectDetailResponse',
    'ExtendedObjectListResponse',
]
