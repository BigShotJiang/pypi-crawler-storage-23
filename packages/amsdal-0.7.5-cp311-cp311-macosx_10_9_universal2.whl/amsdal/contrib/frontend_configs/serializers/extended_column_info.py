"""Extended column info model with frontend_configs-specific fields.

This module extends ColumnInfo from amsdal_server with additional
fields needed for frontend configuration and control rendering.
"""

from typing import Any

from amsdal_server.apps.common.serializers.base_column_info import ColumnInfo


class ExtendedColumnInfo(ColumnInfo):
    """Extended column info with frontend_configs-specific fields.

    Extends ColumnInfo with:
    - control: Form control configuration for input/editing
    """

    control: dict[str, Any] | None = None
