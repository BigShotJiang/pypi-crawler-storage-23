# mypy: disable-error-code="name-defined"
"""Extended object response models with control field."""

from typing import Any

from amsdal_server.apps.objects.serializers.responses import _ObjectDetailResponse
from amsdal_server.apps.objects.serializers.responses import _ObjectListResponse


class ExtendedObjectListResponse(_ObjectListResponse):
    """Object list response with control field for form configuration."""

    control: dict[str, Any] | None = None


class ExtendedObjectDetailResponse(_ObjectDetailResponse):
    """Object detail response with control field for form configuration."""

    control: dict[str, Any] | None = None
