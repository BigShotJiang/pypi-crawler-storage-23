from enum import StrEnum


class DbExecutionType(StrEnum):
    lakehouse_only = 'lakehouse_only'
    include_state_db = 'include_state_db'


class StateOption(StrEnum):
    sqlite = 'sqlite'
    postgres = 'postgres'


class LakehouseOption(StrEnum):
    postgres = 'postgres'
    sqlite = 'sqlite'
