"""Management UI static files for mnemory."""
