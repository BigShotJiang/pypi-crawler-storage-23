# Benchmark suite for mnemory.
