# Flet Desktop client in Flutter (light)

[![python](https://img.shields.io/badge/python-%3E%3D3.10-%2334D058)](https://pypi.org/project/flet-desktop-light)
[![docstring coverage](https://docs.flet.dev/assets/badges/docs-coverage/flet-desktop-light.svg)](https://docs.flet.dev/assets/badges/docs-coverage/flet-desktop-light.svg)

This package contains a compiled Flutter Flet desktop client with audio and video
components removed.
