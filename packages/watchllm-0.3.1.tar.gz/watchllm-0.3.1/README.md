# WatchLLM SDK

The Flight Recorder SDK for AI Agents.

## Install

```bash
pip install watchllm
```

Optional extras:

```bash
pip install "watchllm[langchain]"
pip install "watchllm[crewai]"
pip install "watchllm[mcp]"
pip install "watchllm[all]"
```

## Quick Start

```python
import watchllm

watchllm.configure(
    api_url="https://watchllm-7a6am.ondigitalocean.app",
    project_name="my-project",
)

@watchllm.watch
def run_agent(prompt: str):
    return {"ok": True, "prompt": prompt}

run_agent("hello")
```

## Features

- `@watch` decorator for automatic trace capture
- `watch_trace()` context manager for manual instrumentation
- LangChain callback handler support
- CrewAI hook support
- MCP client wrapper support
- Fork & resume API (`resume_from_fork`)
