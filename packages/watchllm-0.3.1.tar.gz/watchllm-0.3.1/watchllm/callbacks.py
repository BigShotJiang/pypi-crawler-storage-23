"""
LangChain callback handler for WatchLLM flight recording.

Inherits from ``langchain_core.callbacks.BaseCallbackHandler`` when
available; otherwise falls back to a plain object so the SDK never
hard-depends on LangChain at import time.

Covered hooks:
    on_llm_start / on_llm_end / on_llm_error
    on_tool_start / on_tool_end / on_tool_error
    on_chain_start / on_chain_end / on_chain_error
    on_retriever_start / on_retriever_end
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Sequence

from watchllm.dispatcher import AsyncDispatcher
from watchllm.types import EventType, TraceEvent

logger = logging.getLogger("watchllm.callbacks")

# ── Graceful BaseCallbackHandler import ─────────────────────
# If langchain-core is installed, inherit from the real base so LangChain
# recognises us.  Otherwise, fall back to `object` — the duck-typed
# method signatures still work when wired manually.

try:
    from langchain_core.callbacks import BaseCallbackHandler as _Base

    _HAS_LANGCHAIN = True
except ImportError:  # pragma: no cover
    _Base = object  # type: ignore[misc,assignment]
    _HAS_LANGCHAIN = False


class WatchLLMCallbackHandler(_Base):  # type: ignore[misc]
    """
    LangChain-compatible callback handler that records every reasoning
    step to the WatchLLM backend.

    Usage::

        from watchllm.callbacks import WatchLLMCallbackHandler

        handler = WatchLLMCallbackHandler(trace_id="...", dispatcher=d)
        chain.invoke(input, config={"callbacks": [handler]})
    """

    # Tell LangChain not to raise on ignored events
    raise_error = False
    # A descriptive name for LangChain's tracer UI
    name = "WatchLLMCallbackHandler"

    def __init__(self, trace_id: str, dispatcher: AsyncDispatcher) -> None:
        # Only call super if we actually inherited from BaseCallbackHandler
        if _HAS_LANGCHAIN:
            super().__init__()
        self.trace_id = trace_id
        self._dispatcher = dispatcher
        self._timers: dict[str, float] = {}

    # ── helpers ─────────────────────────────────────────────

    def _start_timer(self, run_id: uuid.UUID | None) -> str:
        eid = str(run_id or uuid.uuid4())
        self._timers[eid] = time.perf_counter()
        return eid

    def _pop_duration(self, event_id: str) -> float | None:
        start = self._timers.pop(event_id, None)
        return (time.perf_counter() - start) * 1000 if start is not None else None

    @staticmethod
    def _extract_tokens(response: Any) -> tuple[int, int]:
        """
        Pull token counts from an LLMResult or AIMessage.

        LangChain ≥ 0.3 stores usage in several places; we try them
        in order of reliability.
        """
        prompt_tok = 0
        completion_tok = 0

        # 1) AIMessage.usage_metadata  (langchain-core ≥ 0.3)
        if hasattr(response, "generations"):
            for gen_list in response.generations:
                for gen in gen_list:
                    msg = getattr(gen, "message", None)
                    um = getattr(msg, "usage_metadata", None) if msg else None
                    if isinstance(um, dict):
                        prompt_tok += um.get("input_tokens", 0)
                        completion_tok += um.get("output_tokens", 0)

        # 2) LLMResult.llm_output["token_usage"]  (legacy)
        if prompt_tok == 0 and hasattr(response, "llm_output") and response.llm_output:
            tu = response.llm_output.get("token_usage", {})
            prompt_tok = tu.get("prompt_tokens", 0)
            completion_tok = tu.get("completion_tokens", 0)

        return prompt_tok, completion_tok

    @staticmethod
    def _response_text(response: Any) -> str:
        """Best-effort extraction of the LLM output text."""
        if hasattr(response, "generations"):
            parts: list[str] = []
            for gen_list in response.generations:
                for gen in gen_list:
                    parts.append(getattr(gen, "text", str(gen)))
            return "\n".join(parts)
        return str(response)

    def _emit(self, event: TraceEvent) -> None:
        self._dispatcher.enqueue_event(event)

    # ── LLM Events ──────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = self._start_timer(run_id)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.LLM_START,
            input_data={"prompts": prompts},
            context_snapshot={"serialized": serialized, **kwargs.get("metadata", {})},
        ))

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        in_tok, out_tok = self._extract_tokens(response)

        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.LLM_END,
            input_tokens=in_tok,
            output_tokens=out_tok,
            output_data=self._response_text(response),
            duration_ms=duration,
        ))

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.ERROR,
            error=f"LLM error: {error}",
            duration_ms=duration,
        ))

    # ── Tool Events ─────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = self._start_timer(run_id)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.TOOL_START,
            input_data=input_str,
            context_snapshot=serialized,
            mcp_tool_name=serialized.get("name"),
        ))

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.TOOL_END,
            output_data=output,
            duration_ms=duration,
        ))

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.ERROR,
            error=f"Tool error: {error}",
            duration_ms=duration,
        ))

    # ── Chain Events ────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = self._start_timer(run_id)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.CHAIN_START,
            input_data=inputs,
            context_snapshot=serialized,
        ))

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.CHAIN_END,
            output_data=outputs,
            duration_ms=duration,
        ))

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.ERROR,
            error=f"Chain error: {error}",
            duration_ms=duration,
        ))

    # ── Retriever Events ────────────────────────────────────

    def on_retriever_start(
        self,
        serialized: dict[str, Any],
        query: str,
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = self._start_timer(run_id)
        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.TOOL_START,
            input_data={"query": query},
            context_snapshot=serialized,
            mcp_tool_name="retriever",
        ))

    def on_retriever_end(
        self,
        documents: Sequence[Any],
        *,
        run_id: uuid.UUID | None = None,
        parent_run_id: uuid.UUID | None = None,
        **kwargs: Any,
    ) -> None:
        eid = str(run_id or uuid.uuid4())
        duration = self._pop_duration(eid)
        # Serialize document content (avoid dumping full Document objects)
        doc_summaries = []
        for doc in documents:
            if hasattr(doc, "page_content"):
                doc_summaries.append({
                    "content": doc.page_content[:500],
                    "metadata": getattr(doc, "metadata", {}),
                })
            else:
                doc_summaries.append(str(doc)[:500])

        self._emit(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            parent_event_id=str(parent_run_id) if parent_run_id else None,
            event_type=EventType.TOOL_END,
            output_data={"documents": doc_summaries, "count": len(documents)},
            duration_ms=duration,
            mcp_tool_name="retriever",
        ))
