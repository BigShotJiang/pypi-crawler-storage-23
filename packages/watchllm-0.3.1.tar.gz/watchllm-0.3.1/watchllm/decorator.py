"""
The ``@watch`` decorator and ``watch_trace`` context manager.

Two ways to instrument agent code:

1. **Decorator** — wraps a function, auto-detects framework::

        @watch
        def my_agent():
            chain = create_chain()
            return chain.invoke("hello")

        @watch(project_name="research", agent_name="alpha")
        async def my_async_agent():
            ...

2. **Context manager** — explicit scope control::

        with watch_trace(project_name="support") as ctx:
            handler = ctx.langchain_handler()
            chain.invoke(input, config={"callbacks": [handler]})

3. **Time-travel fork & resume**::

        # Fork from a specific step and get a pre-loaded context
        fork = watchllm.resume_from_fork(trace_id, step_id=5)
        messages = fork.chat_history()   # LangChain ChatMessageHistory
        context  = fork.context_snapshot  # Raw agent state

        # Use inside a trace context
        with watch_trace() as ctx:
            new_fork = ctx.fork(step_id=5)

Auto-detection logic:
    - If LangChain objects are found in args/kwargs → attach callback
    - If CrewAI Crew is found → register hooks
    - Otherwise → record generic start/finish events
"""

from __future__ import annotations

import asyncio
import contextlib
import functools
import inspect
import logging
import uuid
from typing import Any, Callable, Generator, TypeVar

import httpx

from watchllm.dispatcher import AsyncDispatcher
from watchllm.types import (
    EventType,
    ForkPayload,
    Framework,
    TraceEvent,
    TraceStart,
    WatchLLMConfig,
)

logger = logging.getLogger("watchllm.decorator")

F = TypeVar("F", bound=Callable[..., Any])

# ── Global state ────────────────────────────────────────────

_default_config = WatchLLMConfig()
_dispatcher: AsyncDispatcher | None = None


def configure(
    *,
    api_url: str | None = None,
    api_key: str | None = None,
    project_name: str | None = None,
    enabled: bool | None = None,
    on_sentinel_kill: Callable | None = None,
    on_sentinel_nudge: Callable | None = None,
    **kwargs: Any,
) -> None:
    """
    Set the global WatchLLM configuration.

    Call this once at startup before any ``@watch`` decorated functions run::

        import watchllm
        watchllm.configure(
            api_url="https://api.watchllm.dev",
            api_key="wlm_sk_...",
            project_name="my-project",
        )
    """
    global _default_config, _dispatcher

    updates: dict[str, Any] = {}
    if api_url is not None:
        updates["api_url"] = api_url
    if api_key is not None:
        updates["api_key"] = api_key
    if project_name is not None:
        updates["project_name"] = project_name
    if enabled is not None:
        updates["enabled"] = enabled
    if on_sentinel_kill is not None:
        updates["on_sentinel_kill"] = on_sentinel_kill
    if on_sentinel_nudge is not None:
        updates["on_sentinel_nudge"] = on_sentinel_nudge
    updates.update(kwargs)

    _default_config = _default_config.model_copy(update=updates)

    # Reset dispatcher so it picks up new config
    if _dispatcher:
        _dispatcher.stop()
    _dispatcher = None


def _get_dispatcher() -> AsyncDispatcher:
    """Lazily initialize the global dispatcher."""
    global _dispatcher
    if _dispatcher is None:
        _dispatcher = AsyncDispatcher(_default_config)
        _dispatcher.start()
    return _dispatcher


def get_config() -> WatchLLMConfig:
    """Return the current global config (read-only)."""
    return _default_config


def shutdown() -> None:
    """Flush pending events and stop the background dispatcher."""
    global _dispatcher
    if _dispatcher:
        _dispatcher.stop()
        _dispatcher = None


# ── Framework detection ─────────────────────────────────────


def _detect_framework(obj: Any) -> Framework:
    """Detect which AI framework an object belongs to."""
    cls_name = type(obj).__name__
    module = type(obj).__module__ or ""

    # LangChain
    if "langchain" in module or cls_name in ("RunnableSequence", "AgentExecutor"):
        return Framework.LANGCHAIN

    # CrewAI
    if "crewai" in module or cls_name == "Crew":
        return Framework.CREWAI

    # MCP
    if "mcp" in module or cls_name in ("ClientSession", "Client"):
        return Framework.MCP

    return Framework.UNKNOWN


def _detect_framework_from_args(args: tuple, kwargs: dict) -> tuple[Framework, Any | None]:
    """Scan function args for recognisable framework objects."""
    for arg in args:
        fw = _detect_framework(arg)
        if fw != Framework.UNKNOWN:
            return fw, arg

    for arg in kwargs.values():
        fw = _detect_framework(arg)
        if fw != Framework.UNKNOWN:
            return fw, arg

    return Framework.GENERIC, None


def _attach_langchain_callback(obj: Any, trace_id: str, dispatcher: AsyncDispatcher) -> None:
    """Attempt to inject WatchLLM callback into a LangChain runnable."""
    from watchllm.callbacks import WatchLLMCallbackHandler

    handler = WatchLLMCallbackHandler(trace_id=trace_id, dispatcher=dispatcher)

    # LangChain RunnableSequence.with_config()
    if hasattr(obj, "config"):
        existing = obj.config.get("callbacks", []) if isinstance(obj.config, dict) else []
        if handler not in existing:
            existing.append(handler)
    logger.debug("LangChain callback attached to %s", type(obj).__name__)


def _attach_crewai_hooks(obj: Any, trace_id: str, dispatcher: AsyncDispatcher) -> None:
    """Register WatchLLM hooks on a CrewAI Crew."""
    from watchllm.hooks import CrewAIHooks

    hooks = CrewAIHooks(trace_id=trace_id, dispatcher=dispatcher)
    hooks.register(obj)


# ── The @watch decorator ────────────────────────────────────


def watch(
    func: F | None = None,
    *,
    project_name: str | None = None,
    agent_name: str | None = None,
) -> F | Callable[[F], F]:
    """
    Decorator that wraps an agent function with WatchLLM flight recording.

    Works with both sync and async functions::

        @watch
        def sync_agent(): ...

        @watch(project_name="research")
        async def async_agent(): ...
    """

    def decorator(fn: F) -> F:
        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                if not _default_config.enabled:
                    return await fn(*args, **kwargs)
                return await _execute_watched(fn, args, kwargs, project_name, agent_name, is_async=True)
            return async_wrapper  # type: ignore[return-value]
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                if not _default_config.enabled:
                    return fn(*args, **kwargs)
                return _execute_watched_sync(fn, args, kwargs, project_name, agent_name)
            return sync_wrapper  # type: ignore[return-value]

    if func is not None:
        return decorator(func)
    return decorator  # type: ignore[return-value]


async def _execute_watched(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    project_name: str | None,
    agent_name: str | None,
    is_async: bool = False,
) -> Any:
    """Core logic for the async @watch wrapper."""
    dispatcher = _get_dispatcher()
    trace_id = str(uuid.uuid4())
    detected_fw, fw_obj = _detect_framework_from_args(args, kwargs)

    # Signal trace start
    dispatcher.enqueue_start(TraceStart(
        trace_id=trace_id,
        project_name=project_name or _default_config.project_name,
        agent_name=agent_name or fn.__name__,
        framework=detected_fw.value,
    ))

    # Auto-attach framework-specific instrumentation
    if fw_obj:
        if detected_fw == Framework.LANGCHAIN:
            _attach_langchain_callback(fw_obj, trace_id, dispatcher)
        elif detected_fw == Framework.CREWAI:
            _attach_crewai_hooks(fw_obj, trace_id, dispatcher)

    # Record start
    dispatcher.enqueue_event(TraceEvent(
        trace_id=trace_id,
        event_type=EventType.AGENT_ACTION,
        input_data={"function": fn.__qualname__, "args_count": len(args)},
    ))

    try:
        result = await fn(*args, **kwargs)
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.AGENT_FINISH,
            output_data=str(result)[:2000] if result is not None else None,
        ))
        return result
    except Exception as exc:
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.ERROR,
            error=f"{type(exc).__name__}: {exc}",
        ))
        raise


def _execute_watched_sync(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    project_name: str | None,
    agent_name: str | None,
) -> Any:
    """Core logic for the sync @watch wrapper."""
    dispatcher = _get_dispatcher()
    trace_id = str(uuid.uuid4())
    detected_fw, fw_obj = _detect_framework_from_args(args, kwargs)

    # Signal trace start
    dispatcher.enqueue_start(TraceStart(
        trace_id=trace_id,
        project_name=project_name or _default_config.project_name,
        agent_name=agent_name or fn.__name__,
        framework=detected_fw.value,
    ))

    # Auto-attach framework-specific instrumentation
    if fw_obj:
        if detected_fw == Framework.LANGCHAIN:
            _attach_langchain_callback(fw_obj, trace_id, dispatcher)
        elif detected_fw == Framework.CREWAI:
            _attach_crewai_hooks(fw_obj, trace_id, dispatcher)

    # Record start
    dispatcher.enqueue_event(TraceEvent(
        trace_id=trace_id,
        event_type=EventType.AGENT_ACTION,
        input_data={"function": fn.__qualname__, "args_count": len(args)},
    ))

    try:
        result = fn(*args, **kwargs)
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.AGENT_FINISH,
            output_data=str(result)[:2000] if result is not None else None,
        ))
        return result
    except Exception as exc:
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.ERROR,
            error=f"{type(exc).__name__}: {exc}",
        ))
        raise


# ── watch_trace context manager ─────────────────────────────


class TraceContext:
    """
    Context object yielded by ``watch_trace()``.

    Provides factory methods for framework-specific handlers
    so you can wire instrumentation manually.
    """

    def __init__(self, trace_id: str, dispatcher: AsyncDispatcher) -> None:
        self.trace_id = trace_id
        self.dispatcher = dispatcher

    def langchain_handler(self) -> Any:
        """Create a LangChain callback handler bound to this trace."""
        from watchllm.callbacks import WatchLLMCallbackHandler
        return WatchLLMCallbackHandler(trace_id=self.trace_id, dispatcher=self.dispatcher)

    def crewai_hooks(self) -> Any:
        """Create CrewAI hooks bound to this trace."""
        from watchllm.hooks import CrewAIHooks
        return CrewAIHooks(trace_id=self.trace_id, dispatcher=self.dispatcher)

    def wrap_mcp(self, session: Any, server_url: str = "") -> Any:
        """Wrap an MCP ClientSession with recording."""
        from watchllm.mcp import WatchLLMMCPClient
        return WatchLLMMCPClient(
            session,
            trace_id=self.trace_id,
            dispatcher=self.dispatcher,
            server_url=server_url,
        )

    def record_event(self, event: TraceEvent) -> None:
        """Manually enqueue an event into this trace."""
        event.trace_id = self.trace_id
        self.dispatcher.enqueue_event(event)

    def fork(self, step_id: int | str) -> "ForkContext":
        """
        Surgical fork — re-spawn from a specific step in this trace.

        Calls the backend fork API and returns a :class:`ForkContext`
        pre-loaded with memory and history up to the fork point.

        Usage::

            with watch_trace() as ctx:
                # ... run some steps ...
                fork = ctx.fork(step_id=5)
                messages = fork.chat_history()
                # Continue with the forked context
        """
        return _fork_trace_sync(self.trace_id, step_id)


class ForkContext(TraceContext):
    """
    A trace context pre-loaded with memory from a fork point.

    Extends :class:`TraceContext` with access to the parent trace's
    state at the fork step: context snapshots, event history, and
    reconstructed chat messages.

    Typical usage::

        fork = watchllm.resume_from_fork("trace-uuid", step_id=5)

        # Access the agent's memory at the fork point
        print(fork.context_snapshot)

        # Get chat messages for LangChain memory
        history = fork.chat_history()

        # Use as a normal trace context
        handler = fork.langchain_handler()
        chain.invoke(input, config={"callbacks": [handler]})
    """

    def __init__(
        self,
        trace_id: str,
        dispatcher: AsyncDispatcher,
        payload: ForkPayload,
    ) -> None:
        super().__init__(trace_id=trace_id, dispatcher=dispatcher)
        self._payload = payload

    @property
    def payload(self) -> ForkPayload:
        """The raw :class:`ForkPayload` from the backend."""
        return self._payload

    @property
    def parent_trace_id(self) -> str:
        """The trace ID of the parent (source of the fork)."""
        return self._payload.parent_trace_id

    @property
    def fork_from_step(self) -> str:
        """The step ID / step_order that was forked from."""
        return self._payload.fork_from_step

    @property
    def context_snapshot(self) -> dict[str, Any]:
        """
        Accumulated context from every event up to the fork point.

        This is the agent's full "brain state" — all context_snapshot
        dicts merged together.
        """
        return self._payload.context_snapshot

    @property
    def history(self) -> list[dict[str, Any]]:
        """Lean list of events (event_id, type, step, i/o) up to the fork."""
        return self._payload.history

    @property
    def messages(self) -> list[dict[str, str]]:
        """
        Reconstructed chat message list.

        Each entry has ``role`` ("user" / "assistant" / "tool") and
        ``content``.  Tool messages also include a ``name`` key.
        """
        return self._payload.message_history

    @property
    def fork_metadata(self) -> dict[str, Any]:
        """Extra metadata about the fork (parent name, framework, counts)."""
        return self._payload.fork_metadata

    def chat_history(self) -> Any:
        """
        Return a LangChain ``ChatMessageHistory`` pre-loaded with
        the fork's messages.

        Requires ``langchain-community`` or ``langchain-core`` to be
        installed.  Falls back to returning the raw message list if
        LangChain is not available.

        Usage::

            fork = watchllm.resume_from_fork(trace_id, step_id=5)
            memory = ConversationBufferMemory(chat_memory=fork.chat_history())
            chain = LLMChain(llm=llm, memory=memory, prompt=prompt)
        """
        messages = self._payload.message_history
        try:
            from langchain_community.chat_message_histories import (
                ChatMessageHistory,
            )
            from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

            history = ChatMessageHistory()
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if role == "assistant":
                    history.add_message(AIMessage(content=content))
                elif role == "tool":
                    # ToolMessage requires a tool_call_id; synthesize one
                    history.add_message(
                        ToolMessage(
                            content=content,
                            tool_call_id=msg.get("name", "tool"),
                        )
                    )
                else:
                    history.add_message(HumanMessage(content=content))
            return history

        except ImportError:
            pass

        # Fallback: try langchain_core only (lighter dep)
        try:
            from langchain_core.chat_history import InMemoryChatMessageHistory
            from langchain_core.messages import AIMessage, HumanMessage

            history = InMemoryChatMessageHistory()
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if role == "assistant":
                    history.add_message(AIMessage(content=content))
                else:
                    history.add_message(HumanMessage(content=content))
            return history

        except ImportError:
            logger.debug("LangChain not available — returning raw message list")
            return messages

    def crewai_context(self) -> dict[str, Any]:
        """
        Return a dict suitable for CrewAI task context injection.

        Merges the context_snapshot with a ``chat_history`` key containing
        the reconstructed message list, which CrewAI tasks can consume.

        Usage::

            fork = watchllm.resume_from_fork(trace_id, step_id=5)
            task = Task(
                description="Continue the analysis...",
                context=fork.crewai_context(),
            )
        """
        ctx = dict(self._payload.context_snapshot)
        ctx["chat_history"] = self._payload.message_history
        ctx["fork_metadata"] = self._payload.fork_metadata
        return ctx


# ── Fork helpers ────────────────────────────────────────────


def _fork_trace_sync(
    trace_id: str,
    step_id: int | str,
    *,
    api_url: str | None = None,
    api_key: str | None = None,
) -> ForkContext:
    """
    Call the backend fork API synchronously and return a ForkContext.

    This is the workhorse behind ``resume_from_fork()`` and
    ``TraceContext.fork()``.
    """
    url = api_url or _default_config.api_url
    headers: dict[str, str] = {"Content-Type": "application/json"}
    key = api_key or _default_config.api_key
    if key:
        headers["Authorization"] = f"Bearer {key}"

    try:
        with httpx.Client(base_url=url, timeout=30.0, headers=headers) as client:
            resp = client.post(f"/v1/traces/{trace_id}/fork/{step_id}")
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPStatusError as exc:
        logger.error("Fork API returned %d: %s", exc.response.status_code, exc.response.text)
        raise RuntimeError(
            f"Fork failed (HTTP {exc.response.status_code}): {exc.response.text}"
        ) from exc
    except httpx.HTTPError as exc:
        logger.error("Fork API unreachable: %s", exc)
        raise RuntimeError(f"Fork API unreachable: {exc}") from exc

    payload = ForkPayload(**data)
    dispatcher = _get_dispatcher()

    logger.info(
        "Fork created: %s from %s at step %s (%d events, %d messages)",
        payload.fork_trace_id,
        payload.parent_trace_id,
        payload.fork_from_step,
        len(payload.history),
        len(payload.message_history),
    )

    return ForkContext(
        trace_id=payload.fork_trace_id,
        dispatcher=dispatcher,
        payload=payload,
    )


async def _fork_trace_async(
    trace_id: str,
    step_id: int | str,
    *,
    api_url: str | None = None,
    api_key: str | None = None,
) -> ForkContext:
    """Async version of ``_fork_trace_sync``."""
    url = api_url or _default_config.api_url
    headers: dict[str, str] = {"Content-Type": "application/json"}
    key = api_key or _default_config.api_key
    if key:
        headers["Authorization"] = f"Bearer {key}"

    try:
        async with httpx.AsyncClient(base_url=url, timeout=30.0, headers=headers) as client:
            resp = await client.post(f"/v1/traces/{trace_id}/fork/{step_id}")
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPStatusError as exc:
        logger.error("Fork API returned %d: %s", exc.response.status_code, exc.response.text)
        raise RuntimeError(
            f"Fork failed (HTTP {exc.response.status_code}): {exc.response.text}"
        ) from exc
    except httpx.HTTPError as exc:
        logger.error("Fork API unreachable: %s", exc)
        raise RuntimeError(f"Fork API unreachable: {exc}") from exc

    payload = ForkPayload(**data)
    dispatcher = _get_dispatcher()

    return ForkContext(
        trace_id=payload.fork_trace_id,
        dispatcher=dispatcher,
        payload=payload,
    )


def resume_from_fork(
    trace_id_or_payload: str | ForkPayload,
    *,
    step_id: int | str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
) -> ForkContext:
    """
    Resume an agent from a fork point — **the core time-travel API**.

    Accepts either:

    1. A ``trace_id`` + ``step_id`` → calls the backend fork API::

        fork = watchllm.resume_from_fork("trace-uuid", step_id=5)

    2. A pre-fetched :class:`ForkPayload` (e.g., from a webhook)::

        fork = watchllm.resume_from_fork(payload)

    Returns a :class:`ForkContext` that extends TraceContext with:

    * ``fork.context_snapshot`` — full agent brain state at the fork
    * ``fork.messages`` — reconstructed (role, content) chat pairs
    * ``fork.chat_history()`` — LangChain ChatMessageHistory object
    * ``fork.crewai_context()`` — dict for CrewAI task injection
    * ``fork.langchain_handler()`` — callback handler for the fork trace
    * ``fork.crewai_hooks()`` — hooks for the fork trace
    """
    if isinstance(trace_id_or_payload, ForkPayload):
        payload = trace_id_or_payload
        dispatcher = _get_dispatcher()
        return ForkContext(
            trace_id=payload.fork_trace_id,
            dispatcher=dispatcher,
            payload=payload,
        )

    # It's a trace_id string — we need a step_id
    if step_id is None:
        raise ValueError(
            "step_id is required when calling resume_from_fork with a trace_id. "
            "Usage: resume_from_fork('trace-uuid', step_id=5)"
        )

    return _fork_trace_sync(
        trace_id_or_payload,
        step_id,
        api_url=api_url,
        api_key=api_key,
    )


async def resume_from_fork_async(
    trace_id_or_payload: str | ForkPayload,
    *,
    step_id: int | str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
) -> ForkContext:
    """
    Async version of :func:`resume_from_fork`.

    Use this in async agent code::

        fork = await watchllm.resume_from_fork_async("trace-uuid", step_id=5)
        handler = fork.langchain_handler()
        result = await chain.ainvoke(input, config={"callbacks": [handler]})
    """
    if isinstance(trace_id_or_payload, ForkPayload):
        payload = trace_id_or_payload
        dispatcher = _get_dispatcher()
        return ForkContext(
            trace_id=payload.fork_trace_id,
            dispatcher=dispatcher,
            payload=payload,
        )

    if step_id is None:
        raise ValueError("step_id is required when calling with a trace_id")

    return await _fork_trace_async(
        trace_id_or_payload,
        step_id,
        api_url=api_url,
        api_key=api_key,
    )


@contextlib.contextmanager
def watch_trace(
    *,
    project_name: str | None = None,
    agent_name: str = "manual_trace",
    metadata: dict[str, Any] | None = None,
) -> Generator[TraceContext, None, None]:
    """
    Context manager for explicit trace scoping::

        with watch_trace(project_name="support") as ctx:
            handler = ctx.langchain_handler()
            chain.invoke(input, config={"callbacks": [handler]})
    """
    if not _default_config.enabled:
        yield TraceContext(trace_id="disabled", dispatcher=_get_dispatcher())
        return

    dispatcher = _get_dispatcher()
    trace_id = str(uuid.uuid4())

    dispatcher.enqueue_start(TraceStart(
        trace_id=trace_id,
        project_name=project_name or _default_config.project_name,
        agent_name=agent_name,
        framework="manual",
        metadata=metadata or {},
    ))

    ctx = TraceContext(trace_id=trace_id, dispatcher=dispatcher)

    try:
        yield ctx
    except Exception as exc:
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.ERROR,
            error=f"{type(exc).__name__}: {exc}",
        ))
        raise
    finally:
        dispatcher.enqueue_event(TraceEvent(
            trace_id=trace_id,
            event_type=EventType.AGENT_FINISH,
            output_data="trace_complete",
        ))
