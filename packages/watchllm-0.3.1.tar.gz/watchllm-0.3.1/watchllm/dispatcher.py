"""
Async event dispatcher — streams trace events to the WatchLLM backend
without blocking the agent's reasoning loop.

Architecture:
    ┌─────────────────────────────────────────┐
    │  Agent Thread                            │
    │  handler.on_llm_end(...)                │
    │     └─ dispatcher.enqueue_event(ev)     │  ← instant, non-blocking
    └──────────────┬──────────────────────────┘
                   │  deque (thread-safe)
    ┌──────────────▼──────────────────────────┐
    │  Dispatcher Background Thread            │
    │  asyncio event loop                      │
    │     flush_loop() → httpx POST batches   │
    │     parse X-WatchLLM-Action headers     │
    │     fire on_sentinel_kill / on_nudge     │
    └─────────────────────────────────────────┘
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from watchllm.types import SentinelAlert, TraceEvent, TraceStart, WatchLLMConfig

logger = logging.getLogger("watchllm.dispatcher")


class AsyncDispatcher:
    """
    Fire-and-forget event dispatcher with Sentinel awareness.

    Key features:
    - Background thread with its own asyncio loop (never blocks the agent)
    - Batches events and flushes on interval OR buffer-full
    - Reads X-WatchLLM-Action headers and fires sentinel callbacks
    - Exponential backoff on network failures
    - Single-event flush mode (`send_event_sync`) for immediate Sentinel feedback
    """

    def __init__(self, config: WatchLLMConfig) -> None:
        self._config = config
        self._buffer: deque[dict] = deque(maxlen=10_000)
        self._client: httpx.AsyncClient | None = None
        self._sync_client: httpx.Client | None = None
        self._flush_task: asyncio.Task | None = None
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._running = False
        self._consecutive_failures = 0
        self._last_sentinel_action: str | None = None

    # ── HTTP clients ────────────────────────────────────────

    def _build_headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self._config.api_key:
            h["Authorization"] = f"Bearer {self._config.api_key}"
        return h

    def _get_async_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self._config.api_url,
                timeout=10.0,
                headers=self._build_headers(),
            )
        return self._client

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                base_url=self._config.api_url,
                timeout=10.0,
                headers=self._build_headers(),
            )
        return self._sync_client

    # ── Public API ──────────────────────────────────────────

    def start(self) -> None:
        """Start the background flush loop."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name="watchllm-dispatcher",
        )
        self._thread.start()
        logger.debug("WatchLLM dispatcher started")

    def stop(self) -> None:
        """Flush remaining events and shut down gracefully."""
        self._running = False
        if self._loop and not self._loop.is_closed():
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=5.0)
        # Close sync client if used
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()
        logger.debug("WatchLLM dispatcher stopped (%d events still buffered)", len(self._buffer))

    @property
    def pending(self) -> int:
        """Number of events waiting to be flushed."""
        return len(self._buffer)

    @property
    def last_sentinel_action(self) -> str | None:
        """The most recent Sentinel action received from the backend."""
        return self._last_sentinel_action

    def enqueue_start(self, payload: TraceStart) -> None:
        """Record a new trace start (non-blocking)."""
        self._buffer.append({"type": "start", "data": payload.model_dump(mode="json")})

    def enqueue_event(self, event: TraceEvent) -> None:
        """Enqueue a trace event for async dispatch (non-blocking)."""
        self._buffer.append({"type": "event", "data": event.model_dump(mode="json")})

    def send_event_sync(self, event: TraceEvent) -> SentinelAlert | None:
        """
        Send a single event synchronously and return the Sentinel response.

        Use this when you need immediate Sentinel feedback (e.g., before
        letting the agent continue). Falls back to enqueue if the
        backend is unreachable.
        """
        from watchllm.types import SentinelAction, SentinelAlert

        try:
            client = self._get_sync_client()
            resp = client.post(
                "/v1/record/event",
                json=event.model_dump(mode="json"),
            )
            resp.raise_for_status()
            return self._parse_sentinel_headers(
                dict(resp.headers),
                trace_id=event.trace_id,
                event_id=event.event_id,
            )
        except httpx.HTTPError as exc:
            logger.warning("Sync dispatch failed, falling back to buffer: %s", exc)
            self.enqueue_event(event)
            return None

    # ── Background loop ─────────────────────────────────────

    def _run_loop(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._flush_loop())
        finally:
            # Ensure HTTP client is closed
            if self._client and not self._client.is_closed:
                self._loop.run_until_complete(self._client.aclose())
            self._loop.close()

    async def _flush_loop(self) -> None:
        interval = self._config.flush_interval_ms / 1000.0
        while self._running:
            await asyncio.sleep(interval)
            await self._flush()
        # Final flush on shutdown
        await self._flush()

    async def _flush(self) -> None:
        if not self._buffer:
            return

        batch: list[dict] = []
        while self._buffer and len(batch) < self._config.max_batch_size:
            batch.append(self._buffer.popleft())

        starts = [item["data"] for item in batch if item["type"] == "start"]
        events = [item["data"] for item in batch if item["type"] == "event"]

        try:
            client = self._get_async_client()

            # Send trace starts one by one (they're rare)
            for start_payload in starts:
                await client.post("/v1/record/start", json=start_payload)

            # Batch-send events
            if events:
                resp = await client.post("/v1/record/events", json=events)
                resp.raise_for_status()

                # Parse and handle Sentinel headers
                alert = self._parse_sentinel_headers(
                    dict(resp.headers),
                    trace_id=events[-1].get("trace_id", ""),
                    event_id=events[-1].get("event_id", ""),
                )
                if alert:
                    self._fire_sentinel_callback(alert)

            # Reset failure counter on success
            self._consecutive_failures = 0

        except httpx.HTTPError as exc:
            self._consecutive_failures += 1
            backoff = min(
                self._config.retry_base_delay_ms * (2 ** self._consecutive_failures) / 1000,
                30.0,  # cap at 30s
            )
            logger.warning(
                "WatchLLM dispatch failed (attempt %d, backoff %.1fs): %s",
                self._consecutive_failures,
                backoff,
                exc,
            )

            # Re-enqueue failed items (prepend so they retry first)
            if self._consecutive_failures <= self._config.max_retries:
                for item in reversed(batch):
                    self._buffer.appendleft(item)
            else:
                logger.error(
                    "Dropping %d events after %d consecutive failures",
                    len(batch),
                    self._consecutive_failures,
                )

            await asyncio.sleep(backoff)

    # ── Sentinel header parsing ─────────────────────────────

    def _parse_sentinel_headers(
        self,
        headers: dict[str, str],
        trace_id: str = "",
        event_id: str = "",
    ) -> SentinelAlert | None:
        """Extract Sentinel state from response headers."""
        from watchllm.types import SentinelAction, SentinelAlert

        action_raw = headers.get("x-watchllm-action", "OK").upper()
        if action_raw == "OK":
            self._last_sentinel_action = None
            return None

        try:
            action = SentinelAction(action_raw)
        except ValueError:
            logger.warning("Unknown Sentinel action from backend: %s", action_raw)
            return None

        score = 0.0
        try:
            score = float(headers.get("x-watchllm-sentinel-score", "0"))
        except (ValueError, TypeError):
            pass

        message = headers.get("x-watchllm-sentinel-message", "")

        alert = SentinelAlert(
            action=action,
            score=score,
            message=message,
            trace_id=trace_id,
            event_id=event_id,
        )
        self._last_sentinel_action = action_raw
        return alert

    def _fire_sentinel_callback(self, alert: SentinelAlert) -> None:
        """Invoke user-registered sentinel callbacks on the main thread."""
        from watchllm.types import SentinelAction

        logger.warning(
            "Sentinel alert: %s (score=%.3f) — %s",
            alert.action.value,
            alert.score,
            alert.message,
        )

        try:
            if alert.action == SentinelAction.KILL and self._config.on_sentinel_kill:
                self._config.on_sentinel_kill(alert)
            elif alert.action == SentinelAction.NUDGE and self._config.on_sentinel_nudge:
                self._config.on_sentinel_nudge(alert)
        except Exception:
            logger.exception("Error in sentinel callback")
