"""
MCP (Model Context Protocol) tool-call inspector for WatchLLM.

Wraps the ``mcp.ClientSession`` to intercept every ``call_tool``
invocation, capturing the request payload and response before/after
it hits the MCP server.  This gives full visibility into tool usage
without modifying the MCP server itself.

Architecture:
    Agent → WatchLLMMCPClient.call_tool(name, args)
        ├─ record MCP_REQUEST event
        ├─ delegate to real session.call_tool(name, args)
        ├─ record MCP_RESPONSE event (with timing)
        └─ return original result untouched

Usage::

    from mcp import ClientSession
    from watchllm.mcp import WatchLLMMCPClient

    session = ClientSession(read_stream, write_stream)
    watched = WatchLLMMCPClient(session, trace_id="...", dispatcher=dispatcher)

    # Use 'watched' exactly like the original session
    result = await watched.call_tool("search", {"query": "hello"})
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from watchllm.dispatcher import AsyncDispatcher
from watchllm.types import EventType, TraceEvent

logger = logging.getLogger("watchllm.mcp")


class WatchLLMMCPClient:
    """
    Transparent wrapper around an MCP ClientSession that records
    every tool call to WatchLLM.

    Delegates all attribute access to the underlying session so it's
    a drop-in replacement.
    """

    def __init__(
        self,
        session: Any,
        *,
        trace_id: str,
        dispatcher: AsyncDispatcher,
        server_url: str = "",
    ) -> None:
        self._session = session
        self._trace_id = trace_id
        self._dispatcher = dispatcher
        self._server_url = server_url

    # ── Transparent proxy ───────────────────────────────────

    def __getattr__(self, name: str) -> Any:
        """Proxy everything except call_tool to the real session."""
        return getattr(self._session, name)

    # ── Intercepted call_tool ───────────────────────────────

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """
        Intercept tool calls, record them, then delegate to the real session.

        Records:
          1. MCP_REQUEST  — tool name + arguments (before the call)
          2. MCP_RESPONSE — result + duration  (after the call)
          3. ERROR        — if the tool call throws
        """
        event_id = str(uuid.uuid4())
        start = time.perf_counter()

        # ── Record request ──────────────────────────────────
        self._dispatcher.enqueue_event(TraceEvent(
            event_id=event_id,
            trace_id=self._trace_id,
            event_type=EventType.MCP_REQUEST,
            mcp_tool_name=name,
            mcp_server_url=self._server_url or self._detect_server_url(),
            input_data=arguments,
            mcp_tool_metadata={
                "kwargs": {k: str(v) for k, v in kwargs.items()} if kwargs else {},
            },
        ))

        # ── Delegate to real session ────────────────────────
        try:
            result = await self._session.call_tool(name, arguments, **kwargs)
        except Exception as exc:
            duration_ms = (time.perf_counter() - start) * 1000
            self._dispatcher.enqueue_event(TraceEvent(
                event_id=str(uuid.uuid4()),
                trace_id=self._trace_id,
                parent_event_id=event_id,
                event_type=EventType.ERROR,
                mcp_tool_name=name,
                mcp_server_url=self._server_url,
                error=f"MCP tool error: {exc}",
                duration_ms=duration_ms,
            ))
            raise

        duration_ms = (time.perf_counter() - start) * 1000

        # ── Record response ─────────────────────────────────
        self._dispatcher.enqueue_event(TraceEvent(
            event_id=str(uuid.uuid4()),
            trace_id=self._trace_id,
            parent_event_id=event_id,
            event_type=EventType.MCP_RESPONSE,
            mcp_tool_name=name,
            mcp_server_url=self._server_url or self._detect_server_url(),
            output_data=self._safe_serialize(result),
            duration_ms=duration_ms,
        ))

        return result

    # ── List tools (also intercepted for observability) ─────

    async def list_tools(self, **kwargs: Any) -> Any:
        """Record when the agent discovers available tools."""
        result = await self._session.list_tools(**kwargs)

        # Log tool discovery as metadata (not a full event — avoid noise)
        tools = []
        if hasattr(result, "tools"):
            for t in result.tools:
                tools.append({
                    "name": getattr(t, "name", str(t)),
                    "description": getattr(t, "description", "")[:200],
                })

        logger.info(
            "MCP tools discovered for trace %s: %s",
            self._trace_id,
            [t["name"] for t in tools],
        )
        return result

    # ── Helpers ─────────────────────────────────────────────

    def _detect_server_url(self) -> str:
        """Try to extract the server URL from the session object."""
        for attr in ("server_url", "url", "_url", "base_url"):
            val = getattr(self._session, attr, None)
            if val:
                return str(val)
        return ""

    @staticmethod
    def _safe_serialize(obj: Any) -> Any:
        """Convert MCP result to a JSON-safe representation."""
        if obj is None:
            return None

        # mcp.types.CallToolResult has .content list
        if hasattr(obj, "content"):
            parts = []
            for item in obj.content:
                if hasattr(item, "text"):
                    parts.append({"type": "text", "text": item.text[:2000]})
                elif hasattr(item, "data"):
                    parts.append({"type": "binary", "size": len(item.data)})
                else:
                    parts.append({"type": "unknown", "value": str(item)[:500]})
            return {"content": parts, "isError": getattr(obj, "isError", False)}

        # Fallback
        try:
            return str(obj)[:2000]
        except Exception:
            return "<unserializable>"


def wrap_mcp_session(
    session: Any,
    *,
    trace_id: str,
    dispatcher: AsyncDispatcher,
    server_url: str = "",
) -> WatchLLMMCPClient:
    """
    Convenience factory to wrap an MCP ClientSession.

    Usage::

        from watchllm.mcp import wrap_mcp_session
        watched = wrap_mcp_session(session, trace_id=tid, dispatcher=d)
    """
    return WatchLLMMCPClient(
        session,
        trace_id=trace_id,
        dispatcher=dispatcher,
        server_url=server_url,
    )
