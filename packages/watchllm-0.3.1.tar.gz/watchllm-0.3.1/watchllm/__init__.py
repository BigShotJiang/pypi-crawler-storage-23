"""
WatchLLM SDK — The Flight Recorder for AI Agents.

Quick start::

    import watchllm

    # 1. Configure once at startup
    watchllm.configure(api_url="http://localhost:8000", project_name="my-project")

    # 2. Decorate any agent function
    @watchllm.watch
    def my_agent():
        chain = build_chain()
        return chain.invoke("hello")

    # 3. Or use the context manager for explicit control
    with watchllm.watch_trace(project_name="support") as ctx:
        handler = ctx.langchain_handler()
        chain.invoke(input, config={"callbacks": [handler]})

    # 4. Time-travel: fork & resume from any step
    fork = watchllm.resume_from_fork("trace-uuid", step_id=5)
    messages = fork.chat_history()   # LangChain ChatMessageHistory
    handler  = fork.langchain_handler()
    chain.invoke(input, config={"callbacks": [handler]})
"""

from watchllm.decorator import (
    ForkContext,
    TraceContext,
    configure,
    get_config,
    resume_from_fork,
    resume_from_fork_async,
    shutdown,
    watch,
    watch_trace,
)
from watchllm.types import (
    EventType,
    ForkPayload,
    Framework,
    SentinelAction,
    SentinelAlert,
    TraceEvent,
    TraceStart,
    WatchLLMConfig,
)

__version__ = "0.3.1"

__all__ = [
    # Core API
    "watch",
    "watch_trace",
    "configure",
    "get_config",
    "shutdown",
    # Fork & Resume (Time Travel)
    "resume_from_fork",
    "resume_from_fork_async",
    "ForkContext",
    "TraceContext",
    # Types
    "WatchLLMConfig",
    "TraceEvent",
    "TraceStart",
    "EventType",
    "Framework",
    "SentinelAction",
    "SentinelAlert",
    "ForkPayload",
]
