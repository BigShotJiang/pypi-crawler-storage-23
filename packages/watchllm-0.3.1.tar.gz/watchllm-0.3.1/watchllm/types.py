"""Pydantic models for WatchLLM events and configuration."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, Field


# ── Enums ───────────────────────────────────────────────────


class EventType(str, Enum):
    """Types of events captured by the flight recorder."""

    LLM_START = "llm_start"
    LLM_END = "llm_end"
    TOOL_START = "tool_start"
    TOOL_END = "tool_end"
    MCP_REQUEST = "mcp_request"
    MCP_RESPONSE = "mcp_response"
    CHAIN_START = "chain_start"
    CHAIN_END = "chain_end"
    AGENT_ACTION = "agent_action"
    AGENT_FINISH = "agent_finish"
    SENTINEL_ALERT = "sentinel_alert"
    ERROR = "error"


class SentinelAction(str, Enum):
    """Actions the backend Sentinel can request."""

    OK = "OK"
    NUDGE = "NUDGE"
    KILL = "KILL"


class Framework(str, Enum):
    """Auto-detected framework identifiers."""

    LANGCHAIN = "langchain"
    CREWAI = "crewai"
    MCP = "mcp"
    GENERIC = "generic"
    UNKNOWN = "unknown"


# ── Core Models ─────────────────────────────────────────────


class TraceEvent(BaseModel):
    """A single event in an agent's execution trace."""

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    trace_id: str
    parent_event_id: str | None = None
    event_type: EventType
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Token accounting
    input_tokens: int = 0
    output_tokens: int = 0

    # State snapshot
    input_data: Any = None
    output_data: Any = None
    context_snapshot: dict[str, Any] | None = None

    # MCP-specific metadata
    mcp_tool_name: str | None = None
    mcp_server_url: str | None = None
    mcp_tool_metadata: dict[str, Any] | None = None

    # Timing
    duration_ms: float | None = None

    # Error info
    error: str | None = None

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class TraceStart(BaseModel):
    """Payload to initialize a new trace."""

    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_name: str = "default"
    agent_name: str = "unnamed_agent"
    framework: str = "unknown"
    metadata: dict[str, Any] = Field(default_factory=dict)


class SentinelAlert(BaseModel):
    """Parsed alert from X-WatchLLM-* response headers."""

    action: SentinelAction
    score: float = 0.0
    message: str = ""
    trace_id: str = ""
    event_id: str = ""


class ForkPayload(BaseModel):
    """
    Data returned by POST /v1/traces/{id}/fork/{step_id}.

    Used by ``watchllm.resume_from_fork()`` to re-spawn an agent
    with full memory/context up to the fork point.
    """

    fork_trace_id: str
    parent_trace_id: str
    fork_from_step: str
    context_snapshot: dict[str, Any] = Field(default_factory=dict)
    history: list[dict[str, Any]] = Field(default_factory=list)
    message_history: list[dict[str, str]] = Field(default_factory=list)
    fork_metadata: dict[str, Any] = Field(default_factory=dict)


# ── Configuration ───────────────────────────────────────────


class WatchLLMConfig(BaseModel):
    """Configuration for the WatchLLM SDK."""

    api_url: str = "http://localhost:8000"
    api_key: str | None = None
    project_name: str = "default"
    enabled: bool = True
    async_dispatch: bool = True

    # Batching
    max_batch_size: int = 50
    flush_interval_ms: int = 1000

    # Retry
    max_retries: int = 3
    retry_base_delay_ms: int = 200

    # Sentinel
    on_sentinel_kill: Callable[[SentinelAlert], None] | None = None
    on_sentinel_nudge: Callable[[SentinelAlert], None] | None = None

    model_config = {"arbitrary_types_allowed": True}
