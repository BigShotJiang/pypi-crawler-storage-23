"""
CrewAI 2026 Hook System integration for WatchLLM flight recording.

Uses CrewAI's official hook registration API introduced in 2026:
    crew.register_before_llm_call_hook(fn)
    crew.register_after_llm_call_hook(fn)
    crew.register_before_tool_call_hook(fn)
    crew.register_after_tool_call_hook(fn)
    crew.register_after_task_hook(fn)

If the crew object doesn't expose a hook, we skip it silently —
this means the SDK stays forward-compatible as CrewAI evolves.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from watchllm.dispatcher import AsyncDispatcher
from watchllm.types import EventType, TraceEvent

logger = logging.getLogger("watchllm.hooks")


class CrewAIHooks:
    """
    CrewAI 2026 Hook System integration.

    Captures LLM calls, tool invocations, and task completions
    with full timing and input/output recording.

    Usage::

        from watchllm.hooks import CrewAIHooks

        hooks = CrewAIHooks(trace_id="...", dispatcher=dispatcher)
        hooks.register(crew)
        crew.kickoff()
    """

    def __init__(self, trace_id: str, dispatcher: AsyncDispatcher) -> None:
        self.trace_id = trace_id
        self._dispatcher = dispatcher
        self._timers: dict[str, float] = {}
        self._pending_inputs: dict[str, Any] = {}  # event_id → input captured in before_*
        self._registered = False

    # ── Registration ────────────────────────────────────────

    def register(self, crew: Any) -> None:
        """
        Register WatchLLM hooks on a CrewAI Crew instance.

        Silently skips any hook the crew doesn't support.
        """
        hooks_wired = 0

        # Before hooks — capture inputs + start timer
        for attr, fn in [
            ("register_before_llm_call_hook", self._before_llm),
            ("register_before_tool_call_hook", self._before_tool),
        ]:
            if hasattr(crew, attr):
                getattr(crew, attr)(fn)
                hooks_wired += 1

        # After hooks — capture output + compute duration
        for attr, fn in [
            ("register_after_llm_call_hook", self._after_llm),
            ("register_after_tool_call_hook", self._after_tool),
            ("register_after_task_hook", self._after_task),
        ]:
            if hasattr(crew, attr):
                getattr(crew, attr)(fn)
                hooks_wired += 1

        self._registered = hooks_wired > 0
        if self._registered:
            logger.info("WatchLLM hooks registered on CrewAI crew (%d hooks)", hooks_wired)
        else:
            logger.warning("No CrewAI hooks available — crew may be an older version")

    @property
    def is_registered(self) -> bool:
        return self._registered

    # ── Before hooks (input capture) ────────────────────────

    def _before_llm(self, prompt: Any = None, **kwargs: Any) -> None:
        """Capture the LLM prompt before the call happens."""
        eid = str(uuid.uuid4())
        self._timers[eid] = time.perf_counter()
        self._pending_inputs[eid] = prompt

        # Store the event_id so after_llm can correlate
        # We use a thread-local-ish trick: stash it in _last_llm_eid
        self._last_llm_eid = eid

        self._dispatcher.enqueue_event(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            event_type=EventType.LLM_START,
            input_data=self._safe_str(prompt),
            context_snapshot=self._extract_context(kwargs),
        ))

    def _before_tool(self, tool_name: str = "", input_data: Any = None, **kwargs: Any) -> None:
        """Capture the tool input before the call happens."""
        eid = str(uuid.uuid4())
        self._timers[eid] = time.perf_counter()
        self._pending_inputs[eid] = input_data
        self._last_tool_eid = eid

        self._dispatcher.enqueue_event(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            event_type=EventType.TOOL_START,
            input_data=self._safe_str(input_data),
            mcp_tool_name=str(tool_name) if tool_name else None,
            context_snapshot=self._extract_context(kwargs),
        ))

    # ── After hooks (output capture + timing) ───────────────

    def _after_llm(self, result: Any = None, **kwargs: Any) -> None:
        """Hook called after every CrewAI LLM call."""
        eid = getattr(self, "_last_llm_eid", None) or str(uuid.uuid4())
        duration = self._pop_duration(eid)

        # Try to extract token counts from the result
        in_tok, out_tok = self._extract_crewai_tokens(result)

        self._dispatcher.enqueue_event(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            event_type=EventType.LLM_END,
            output_data=self._safe_str(result),
            input_tokens=in_tok,
            output_tokens=out_tok,
            duration_ms=duration,
            context_snapshot=self._extract_context(kwargs),
        ))

    def _after_tool(self, tool_name: str = "", result: Any = None, **kwargs: Any) -> None:
        """Hook called after every CrewAI tool invocation."""
        eid = getattr(self, "_last_tool_eid", None) or str(uuid.uuid4())
        duration = self._pop_duration(eid)

        self._dispatcher.enqueue_event(TraceEvent(
            event_id=eid,
            trace_id=self.trace_id,
            event_type=EventType.TOOL_END,
            mcp_tool_name=str(tool_name) if tool_name else None,
            output_data=self._safe_str(result),
            duration_ms=duration,
            mcp_tool_metadata=self._extract_context(kwargs),
        ))

    def _after_task(self, task_output: Any = None, **kwargs: Any) -> None:
        """Hook called when a CrewAI task completes."""
        # Extract agent name from task metadata if available
        agent_name = None
        if hasattr(task_output, "agent"):
            agent_name = str(task_output.agent)
        elif "agent" in kwargs:
            agent_name = str(kwargs["agent"])

        self._dispatcher.enqueue_event(TraceEvent(
            event_id=str(uuid.uuid4()),
            trace_id=self.trace_id,
            event_type=EventType.AGENT_FINISH,
            output_data=self._safe_str(task_output),
            context_snapshot={
                "agent": agent_name,
                **self._extract_context(kwargs),
            } if agent_name else self._extract_context(kwargs),
        ))

    # ── Helpers ─────────────────────────────────────────────

    def _pop_duration(self, event_id: str) -> float | None:
        start = self._timers.pop(event_id, None)
        self._pending_inputs.pop(event_id, None)
        return (time.perf_counter() - start) * 1000 if start is not None else None

    @staticmethod
    def _safe_str(obj: Any) -> str:
        """Convert any object to a string without crashing."""
        if obj is None:
            return ""
        try:
            return str(obj)
        except Exception:
            return repr(obj)

    @staticmethod
    def _extract_context(kwargs: dict[str, Any]) -> dict[str, Any]:
        """Extract serializable context from hook kwargs."""
        if not kwargs:
            return {}
        ctx: dict[str, Any] = {}
        for k, v in kwargs.items():
            try:
                # Only include simple types to avoid serialization issues
                if isinstance(v, (str, int, float, bool, type(None))):
                    ctx[k] = v
                elif isinstance(v, (list, dict)):
                    ctx[k] = v
                else:
                    ctx[k] = str(v)
            except Exception:
                ctx[k] = "<unserializable>"
        return ctx

    @staticmethod
    def _extract_crewai_tokens(result: Any) -> tuple[int, int]:
        """Try to pull token counts from a CrewAI result object."""
        in_tok = 0
        out_tok = 0
        if hasattr(result, "usage"):
            usage = result.usage
            if isinstance(usage, dict):
                in_tok = usage.get("prompt_tokens", 0) or usage.get("input_tokens", 0)
                out_tok = usage.get("completion_tokens", 0) or usage.get("output_tokens", 0)
        return in_tok, out_tok
