"""Kospel C.MI electric heater HTTP API client."""
