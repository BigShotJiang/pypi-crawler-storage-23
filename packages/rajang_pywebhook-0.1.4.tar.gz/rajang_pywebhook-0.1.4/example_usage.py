#!/usr/bin/env python3
"""
Example usage of the py-lib-template library.

Run this to see the library in action:
    python example_usage.py
"""

# example usage from lib
from lib.py_lib_template import add, add_many, AddResult

def main() -> None:
    print("=" * 50)
    print("Py Lib Template - Example Usage")
    print("=" * 50)

    # Example 1: Simple addition
    print("\n1. Simple Addition (add function)")
    print("-" * 40)
    
    a, b = 10, 20
    result = add(a, b)
    print(f"  add({a}, {b}) = {result}")
    
    x, y = 3.14, 2.86
    result = add(x, y)
    print(f"  add({x}, {y}) = {result}")

    # Example 2: Adding multiple numbers
    print("\n2. Multiple Addition (add_many function)")
    print("-" * 40)
    
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result = add_many(*numbers)
    print(f"  Input: {numbers}")
    print(f"  Sum: {result.value}")
    print(f"  Operands tracked: {result.operands}")

    # Example 3: Named tuple access
    print("\n3. AddResult Named Tuple")
    print("-" * 40)
    
    result = add_many(100, 200, 300)
    print(f"  Result object: {result}")
    print(f"  result.value = {result.value}")
    print(f"  result.operands = {result.operands}")
    
    # Can also access by index like a tuple
    print(f"  result[0] = {result[0]} (value)")
    print(f"  result[1] = {result[1]} (operands)")

    # Example 4: Error handling
    print("\n4. Error Handling")
    print("-" * 40)
    
    try:
        add_many()  # Empty call should raise
    except ValueError as e:
        print(f"  Caught expected error: {e}")

    print("\n" + "=" * 50)
    print("Examples completed!")
    print("=" * 50)


if __name__ == "__main__":
    main()
