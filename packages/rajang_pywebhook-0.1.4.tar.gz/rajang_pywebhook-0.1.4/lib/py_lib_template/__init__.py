"""
Py Lib Template - A Python library template.

This is the main entry point for the library.
All public exports should be defined here.
"""

from .math_utils import add, add_many, AddResult

__version__ = "0.1.0"
__all__ = ["add", "add_many", "AddResult"]
