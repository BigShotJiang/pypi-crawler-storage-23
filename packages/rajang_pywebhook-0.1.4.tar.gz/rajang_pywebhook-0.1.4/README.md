# Py Lib Template

A Python library template with modern packaging setup for PyPI publishing.

Create your own libraries in the lib folder, using the py_lib_template example, you can create your own library by changing the name of the folder and update the folder name in the pyproject.toml file. Follow the steps below for more details

## Installation

```bash
pip install py-lib-template
```

## Usage

### Basic Addition

```python
from lib import add

# Add two numbers
result = add(1, 2)
print(result)  # 3

# Works with floats too
result = add(1.5, 2.5)
print(result)  # 4.0
```

### Adding Multiple Numbers

```python
from lib import add_many

# Add multiple numbers
result = add_many(1, 2, 3, 4, 5)
print(result.value)     # 15
print(result.operands)  # [1, 2, 3, 4, 5]
```

## Development

### Setup

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Unix/Mac)
source venv/bin/activate

# Install in development mode
pip install
pip install build
pip install twine
```

### Pre-Build

- In pyproject.toml. Update the version and name of the library that you wish to publish.

### Build

```bash
# Build the package
python build_lib.py

# Or manually
python -m build --outdir pypi_publish
```

### Test

```bash
pytest
```

### Lint & Format

```bash
# Format code
black lib tests

# Lint
ruff lib tests

# Type check
mypy lib
```

### Publish

```bash
# Build first
python build_lib.py

# Publish to PyPI (requires credentials)
cd pypi_publish
python -m twine upload *
```

## Project Structure

```
lib/
├── py_lib_template/                    # Library source code
│   ├── __init__.py        # Package entry point
│   └── math_utils.py      # Example module
├── pypi_publish/          # Build artifacts (wheel, sdist)
├── tests/                 # Test files
├── pyproject.toml         # Package configuration
└── README.md
```

## License

MIT
