from lielab.cppLielab.optimize import GoldenMinimize
