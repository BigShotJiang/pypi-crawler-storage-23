from lielab.cppLielab.optimize import NewtonMinimize
