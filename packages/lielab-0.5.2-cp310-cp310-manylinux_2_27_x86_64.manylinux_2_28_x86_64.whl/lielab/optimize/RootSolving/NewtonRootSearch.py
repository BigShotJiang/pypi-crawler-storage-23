from lielab.cppLielab.optimize import NewtonRootSearch
