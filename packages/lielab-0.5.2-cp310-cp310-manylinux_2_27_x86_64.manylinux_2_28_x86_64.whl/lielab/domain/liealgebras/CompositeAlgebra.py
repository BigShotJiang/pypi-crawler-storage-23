from lielab.cppLielab.domain import CompositeAlgebra
