import numpy as np

TOL_FINE = 1e-6
TOL_COARSE = 1e-3

an_int = int(2)
a_double = float(2)
an_imag_int = 2j # TODO: I think this is actually just a double
an_imag_double = 2.0j
