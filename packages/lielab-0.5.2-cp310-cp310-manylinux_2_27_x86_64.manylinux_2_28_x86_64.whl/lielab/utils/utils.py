

# class search_linearx(_search_linearx):
#     def __call__(self, function, x0):
#         self.init(x0)
#         x = x0

#         while (self.algo_status == ALGO_STATUS.OK):
#             x = self.step(x, function(x))

#         return x
