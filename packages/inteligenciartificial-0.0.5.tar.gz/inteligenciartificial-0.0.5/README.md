# Paquete Inteligencia Artificial

Paquete de algoritmos de Inteligencia Artificial para aprendizaje de estructura de Redes Bayesianas.

## Instalación
```bash
pip install inteligenciartificial
```

O desde fuente local:
```bash
pip install ./fia
```

## Uso

### Algoritmos de aprendizaje de estructura

#### K2

Algoritmo greedy que requiere un orden topológico de variables. Agrega padres iterativamente si mejoran la métrica de scoring.

```python
from inteligenciartificial.modelografosprobabilisticos.busqueda import K2
from inteligenciartificial.modelografosprobabilisticos.metricas import Entropia, BIC

orden = ["Churn", "tenure_cat", "OnlineSecurity", "TechSupport", "Contract"]
k2 = K2(orden, max_padres=4, df=df_train, metrica=Entropia())
# [K2] Grafos explorados: 35 | Tiempo: 0.1234 s | Throughput: 283.61 grafos/s

modelo = k2.fit(X_train, y_train, alpha=1.0)
```

#### Hill-Climbing

Algoritmo de búsqueda local que parte de un grafo vacío y en cada paso evalúa operaciones de agregar, eliminar e invertir aristas, seleccionando la que mayor mejora produce.

```python
from inteligenciartificial.modelografosprobabilisticos.busqueda import HillClimbing
from inteligenciartificial.modelografosprobabilisticos.metricas import BIC

variables = ["Churn", "tenure_cat", "OnlineSecurity", "TechSupport", "Contract"]
hc = HillClimbing(variables, max_padres=4, df=df_train, metrica=BIC(), max_iter=100)
# [HillClimbing] Grafos explorados: 420 | Tiempo: 1.5678 s | Throughput: 267.90 grafos/s

modelo = hc.fit(X_train, y_train, alpha=1.0)
```

### Métricas de throughput

Ambos algoritmos (K2 y Hill-Climbing) reportan automáticamente al finalizar el entrenamiento:

| Atributo | Descripción |
|---|---|
| `grafos_explorados` | Cantidad de configuraciones de grafo (conjuntos de padres) evaluadas |
| `tiempo_segundos` | Tiempo total de la búsqueda de estructura en segundos |
| `throughput` | Tasa de exploración: `grafos_explorados / tiempo_segundos` (grafos/s) |

```python
print(k2.grafos_explorados)   # e.g., 35
print(k2.tiempo_segundos)     # e.g., 0.1234
print(k2.throughput)           # e.g., 283.61
```

### Métricas de scoring

| Métrica | Descripción |
|---|---|
| `Entropia` | Usa `-H(X\|Pa)` como score (mayor es mejor) |
| `BIC` | Bayesian Information Criterion con penalización `(k/2)*log(N)` |

### Modelos

- **RedBayesiana**: Red Bayesiana discreta con CPTs estimadas por conteos + suavizado Dirichlet(alpha).
- **NaiveBayes**: Caso especial donde todas las features dependen únicamente de la clase.

## Dependencias

- `numpy >= 1.23`
- `pandas >= 1.5`

## Licencia

MIT
