from . import modelografosprobabilisticos
__all__ = ['modelografosprobabilisticos']
