# inteligenciartificial/modelografosprobabilisticos/busqueda/hill_climbing.py

import time
from collections import deque
from typing import List, Optional
import pandas as pd
from ..grafo import Grafo
from ..modelos.red_bayesiana import RedBayesiana
from ..utils import ensure_categorical


class HillClimbing:
    """
    Algoritmo Hill-Climbing para aprendizaje de estructura de Redes Bayesianas.

    Parte de un grafo vacío y en cada iteración evalúa tres tipos de operaciones:
      - Agregar una arista (u -> v)
      - Eliminar una arista (u -> v)
      - Invertir una arista (u -> v) a (v -> u)

    Selecciona la operación que mayor mejora produce en el score total y la aplica.
    Se detiene cuando ninguna operación mejora el score o se alcanza 'max_iter'.

    Reporta métricas de throughput: grafos explorados, tiempo y throughput (grafos/s).
    """
    def __init__(self, variables: List[str], max_padres: int, df: pd.DataFrame,
                 metrica, alpha: Optional[float] = None, max_iter: int = 100):
        self.variables = variables
        self.max_padres = max_padres
        self.df = ensure_categorical(df)
        self.metrica = metrica
        self.alpha = alpha
        self.max_iter = max_iter

        self.grafos_explorados = 0
        self.tiempo_segundos = 0.0
        self.throughput = 0.0

        self._grafo = self._aprender_estructura()

    @staticmethod
    def _hay_camino(aristas_set, variables, origen, destino):
        """BFS para verificar si existe un camino de 'origen' a 'destino'."""
        adj = {v: [] for v in variables}
        for u, v in aristas_set:
            adj[u].append(v)
        visitados = set()
        cola = deque([origen])
        while cola:
            nodo = cola.popleft()
            if nodo == destino:
                return True
            if nodo in visitados:
                continue
            visitados.add(nodo)
            for hijo in adj.get(nodo, []):
                cola.append(hijo)
        return False

    def _padres_de(self, aristas, v):
        """Devuelve los padres de v en el conjunto de aristas dado."""
        return sorted(u for u, w in aristas if w == v)

    def _aprender_estructura(self) -> Grafo:
        inicio = time.perf_counter()
        grafos_explorados = 0

        aristas = set()

        # Cache de scores por nodo (inicialmente sin padres)
        scores = {}
        for v in self.variables:
            scores[v] = self.metrica.score(self.df, v, [])
            grafos_explorados += 1

        for _ in range(self.max_iter):
            mejor_delta = 0.0
            mejor_op = None

            # --- 1. Operaciones ADD ---
            for u in self.variables:
                for v in self.variables:
                    if u == v or (u, v) in aristas:
                        continue
                    padres_v = self._padres_de(aristas, v)
                    if len(padres_v) >= self.max_padres:
                        continue
                    # Verificar aciclicidad: agregar u->v crea ciclo si hay camino v->u
                    if self._hay_camino(aristas, self.variables, v, u):
                        continue
                    nuevos_padres = sorted(padres_v + [u])
                    nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
                    grafos_explorados += 1
                    delta = nuevo_score_v - scores[v]
                    if delta > mejor_delta + 1e-12:
                        mejor_delta = delta
                        mejor_op = ('add', u, v, {'v': nuevo_score_v})

            # --- 2. Operaciones DELETE ---
            for (u, v) in list(aristas):
                padres_v = self._padres_de(aristas, v)
                nuevos_padres = sorted(p for p in padres_v if p != u)
                nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
                grafos_explorados += 1
                delta = nuevo_score_v - scores[v]
                if delta > mejor_delta + 1e-12:
                    mejor_delta = delta
                    mejor_op = ('del', u, v, {'v': nuevo_score_v})

            # --- 3. Operaciones REVERSE ---
            for (u, v) in list(aristas):
                if (v, u) in aristas:
                    continue
                padres_u = self._padres_de(aristas, u)
                if len(padres_u) >= self.max_padres:
                    continue
                # Verificar aciclicidad del reverso: en el grafo sin (u,v), hay camino u->v?
                aristas_sin = aristas - {(u, v)}
                if self._hay_camino(aristas_sin, self.variables, u, v):
                    continue
                padres_v = self._padres_de(aristas, v)
                nuevos_padres_v = sorted(p for p in padres_v if p != u)
                nuevos_padres_u = sorted(padres_u + [v])
                nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres_v)
                nuevo_score_u = self.metrica.score(self.df, u, nuevos_padres_u)
                grafos_explorados += 1
                delta = (nuevo_score_v - scores[v]) + (nuevo_score_u - scores[u])
                if delta > mejor_delta + 1e-12:
                    mejor_delta = delta
                    mejor_op = ('rev', u, v, {'v': nuevo_score_v, 'u': nuevo_score_u})

            if mejor_op is None:
                break

            # Aplicar la mejor operación
            op_tipo = mejor_op[0]
            if op_tipo == 'add':
                _, u_op, v_op, new_scores = mejor_op
                aristas.add((u_op, v_op))
                scores[v_op] = new_scores['v']
            elif op_tipo == 'del':
                _, u_op, v_op, new_scores = mejor_op
                aristas.discard((u_op, v_op))
                scores[v_op] = new_scores['v']
            elif op_tipo == 'rev':
                _, u_op, v_op, new_scores = mejor_op
                aristas.discard((u_op, v_op))
                aristas.add((v_op, u_op))
                scores[v_op] = new_scores['v']
                scores[u_op] = new_scores['u']

        fin = time.perf_counter()
        self.grafos_explorados = grafos_explorados
        self.tiempo_segundos = fin - inicio
        self.throughput = grafos_explorados / self.tiempo_segundos if self.tiempo_segundos > 0 else float('inf')

        print(f"[HillClimbing] Grafos explorados: {self.grafos_explorados} | "
              f"Tiempo: {self.tiempo_segundos:.4f} s | "
              f"Throughput: {self.throughput:.2f} grafos/s")

        grafo = Grafo(list(aristas))
        for v in self.variables:
            grafo._nodos.add(v)
        return grafo

    def fit(self, X: pd.DataFrame, y: pd.Series = None, alpha: Optional[float] = None):
        """
        Devuelve una RedBayesiana con CPTs estimadas.
        'alpha' aquí tiene prioridad sobre el de __init__; si ambos son None, se usa 1.0.
        """
        a = 1.0 if (alpha is None and self.alpha is None) else (self.alpha if alpha is None else alpha)
        rb = RedBayesiana(self._grafo, alpha=a)
        rb.fit(X, y)
        return rb

    def __repr__(self):
        return (f"HillClimbing(grafo={self._grafo}, "
                f"grafos_explorados={self.grafos_explorados}, "
                f"throughput={self.throughput:.2f} grafos/s)")
