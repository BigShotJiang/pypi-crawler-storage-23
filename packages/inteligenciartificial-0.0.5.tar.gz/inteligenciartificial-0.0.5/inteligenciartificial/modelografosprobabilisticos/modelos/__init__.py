from .naive_bayes import NaiveBayes
from .red_bayesiana import RedBayesiana
__all__=['NaiveBayes','RedBayesiana']
