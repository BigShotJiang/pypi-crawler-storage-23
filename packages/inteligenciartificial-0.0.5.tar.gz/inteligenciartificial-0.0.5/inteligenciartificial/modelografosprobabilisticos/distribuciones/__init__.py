from .discreta import (
    DistribucionDiscreta,
    DistribucionMarginalDiscreta,
    DistribucionConjuntaDiscreta,
    DistribucionCondicionalDiscreta,
)
__all__=['DistribucionDiscreta','DistribucionMarginalDiscreta','DistribucionConjuntaDiscreta','DistribucionCondicionalDiscreta']
