"""
Framework-agnostic job tracking for ARQ
Works automatically when arq-optimus-dashboard is installed

NO USER CODE CHANGES REQUIRED!
Tracking is automatically applied when WorkerSettings is loaded.
"""

import asyncio
import logging
from functools import wraps
from typing import Callable

logger = logging.getLogger('arq_optimus')

TTL_30_DAYS = 2592000  # 30 days in seconds


def create_tracking_wrapper(func: Callable) -> Callable:
    """
    Internal wrapper that adds tracking to a task
    Called automatically by __init__.py, not by users directly
    
    This wraps user tasks with:
    - Job lifecycle tracking (running/completed/failed)
    - TTL synchronization (ensures metadata and results expire together)
    - Status tracking queues (arq:track:*)
    
    Args:
        func: The async task function to wrap
    
    Returns:
        Wrapped function with tracking
    """
    @wraps(func)
    async def wrapper(ctx, *args, **kwargs):
        job_id = ctx.get('job_id')
        redis = ctx.get('redis')  # ARQ provides Redis connection in context
        
        if not job_id or not redis:
            # No tracking context available, just execute
            return await func(ctx, *args, **kwargs)
        
        import time
        timestamp = time.time()
        
        # Mark job as running
        try:
            await redis.zadd(redis.track_running, {job_id: timestamp})
            await redis.zadd(redis.track_all, {job_id: timestamp})
            
            # Defensive: Ensure job metadata has TTL
            job_key = redis.job_key_prefix + job_id
            if await redis.exists(job_key):
                current_ttl = await redis.ttl(job_key)
                if current_ttl < 0 or current_ttl > TTL_30_DAYS:
                    await redis.expire(job_key, TTL_30_DAYS)
                    
        except Exception as e:
            logger.warning(f"Failed to track job start {job_id}: {e}")
        
        # Execute the actual task
        try:
            result = await func(ctx, *args, **kwargs)
            
            # Mark as completed
            try:
                await redis.zrem(redis.track_running, job_id)
                await redis.zadd(redis.track_completed, {job_id: time.time()})
                
                # Sync result TTL with job metadata TTL
                await asyncio.sleep(0.1)  # Let ARQ write result
                
                result_key = redis.result_key_prefix + job_id
                job_key = redis.job_key_prefix + job_id
                
                if await redis.exists(result_key):
                    job_ttl = await redis.ttl(job_key)
                    if job_ttl > 0:
                        await redis.expire(result_key, job_ttl)
                    else:
                        await redis.expire(result_key, TTL_30_DAYS)
            
            except Exception as e:
                logger.warning(f"Failed to track job completion {job_id}: {e}")
            
            return result
            
        except Exception as e:
            # Mark as failed
            try:
                await redis.zrem(redis.track_running, job_id)
                await redis.zadd(redis.track_failed, {job_id: time.time()})
                
                # Sync result TTL for failed jobs too
                await asyncio.sleep(0.1)
                
                result_key = redis.result_key_prefix + job_id
                job_key = redis.job_key_prefix + job_id
                
                if await redis.exists(result_key):
                    job_ttl = await redis.ttl(job_key)
                    if job_ttl > 0:
                        await redis.expire(result_key, job_ttl)
                    else:
                        await redis.expire(result_key, TTL_30_DAYS)
            
            except Exception as err:
                logger.warning(f"Failed to track job failure {job_id}: {err}")
            
            raise  # Re-raise original exception
    
    # Mark as tracked to avoid double-wrapping
    wrapper._arq_optimus_tracked = True
    
    return wrapper


def wrap_functions_with_tracking(settings):
    """
    Helper to wrap all functions in WorkerSettings with tracking
    
    Called automatically when arq_optimus_dashboard is imported
    
    Args:
        settings: WorkerSettings instance or class
    """
    # Get functions list
    original_functions = getattr(settings, 'functions', [])
    
    if not original_functions:
        logger.warning("No functions found in WorkerSettings to track")
        return
    
    # Wrap each function (skip if already wrapped)
    wrapped_functions = []
    wrapped_count = 0
    
    for func in original_functions:
        if hasattr(func, '_arq_optimus_tracked'):
            # Already wrapped
            wrapped_functions.append(func)
        else:
            # Wrap with tracking
            wrapped_func = create_tracking_wrapper(func)
            wrapped_functions.append(wrapped_func)
            wrapped_count += 1
    
    # Update settings
    settings.functions = wrapped_functions
    
    if wrapped_count > 0:
        logger.info(f"🎯 ARQ Optimus auto-tracking enabled for {wrapped_count} tasks")
