# ARQ Optimus Dashboard

🚀 **Real-time monitoring and management dashboard for ARQ (Async Redis Queue) Optimus**

## Features

- ✨ **Real-time Monitoring**: Auto-refresh every 5 seconds to track job progress
- 🎯 **Native Job Cancellation**: Uses ARQ's native `Job.abort()` method for proper cancellation
- 📊 **Queue Statistics**: Live view of queued, running, completed, and failed jobs
- 🔍 **Status Filtering**: Filter jobs by status (queued/running/completed/failed/cancelled)
- 🎨 **Modern UI**: Clean, responsive dashboard with status badges
- ⚡ **FastAPI Backend**: High-performance async API with proper Redis connection management
- 🔒 **Redis Cloud Support**: Works with Redis SSL/TLS connections

## Installation

```bash
# Clone the arq-optimus repository
git clone https://github.com/arpansahu/arq-optimus.git
cd arq-optimus

# Install in editable mode
pip install -e .
```

## Usage

### Start the Dashboard

```bash
# Basic usage
arq-optimus-dashboard --redis-url redis://localhost:6379

# With Redis Cloud (SSL)
arq-optimus-dashboard --redis-url rediss://redis.example.com:6379

# Custom host and port
arq-optimus-dashboard --redis-url redis://localhost:6379 --host 127.0.0.1 --port 9000

# With authentication
arq-optimus-dashboard --redis-url redis://localhost:6379 --username admin --password secret
```

### Access the Dashboard

Once started, open your browser to:
```
http://localhost:8910
```

## Architecture

### Backend Structure

```
arq_optimus_dashboard/
├── __init__.py
├── main.py          # FastAPI app with routes
├── core.py          # ARQManager with native Job.abort()
├── cli.py           # Command-line interface
├── api/
│   └── __init__.py  # REST API endpoints
├── templates/
│   └── dashboard.html
└── static/
```

### Key Components

#### ARQManager (`core.py`)
- **Native Job Cancellation**: Uses `Job.abort(timeout=5.0, poll_delay=0.5)`
- **Job Listing**: Retrieve jobs with status filtering
- **Queue Statistics**: Real-time queue metrics
- **Job Management**: Delete completed/failed jobs

#### REST API (`api/__init__.py`)
- `GET /api/status` - Get queue statistics
- `GET /api/jobs` - List jobs (with optional status filter)
- `GET /api/jobs/{job_id}` - Get job details
- `POST /api/jobs/{job_id}/cancel` - Cancel a queued job
- `DELETE /api/jobs/{job_id}` - Delete a completed/failed job

#### Dashboard UI (`templates/dashboard.html`)
- Real-time job monitoring with auto-refresh
- Status badges (queued/running/completed/failed/cancelled)
- Cancel button (only for queued jobs)
- Delete button (only for completed/failed/cancelled jobs)
- Queue statistics cards
- Status filtering

## Key Features

### Native Job Cancellation

Unlike other ARQ dashboards, ARQ Optimus Dashboard uses ARQ's **native `Job.abort()` method** for proper job cancellation:

```python
async def cancel_job(self, job_id: str) -> Dict[str, Any]:
    """Cancel a job using native Job.abort()"""
    pool = await self.get_pool()
    job = Job(job_id, redis=pool)
    abort_success = await job.abort(timeout=5.0, poll_delay=0.5)
    
    if abort_success:
        return {"success": True, "message": "Job cancelled successfully"}
    else:
        return {"success": False, "message": "Job could not be cancelled"}
```

### Status-Based Actions

- **Queued Jobs**: Show cancel button (can be aborted before execution)
- **Running Jobs**: Show "Running..." (cannot be cancelled)
- **Completed/Failed/Cancelled**: Show delete button (cleanup)

### Auto-Refresh

Dashboard automatically refreshes every 5 seconds to show real-time job status updates.

## Development

### Running from Source

```bash
# Clone and setup
git clone https://github.com/arpansahu/arq-optimus.git
cd arq-optimus
pip install -e .

# Start dashboard
arq-optimus-dashboard --redis-url redis://localhost:6379
```

### Testing with ARQ Worker

```bash
# Terminal 1: Start ARQ worker
cd /path/to/your/project
arq worker.WorkerSettings

# Terminal 2: Start dashboard
arq-optimus-dashboard --redis-url redis://localhost:6379

# Terminal 3: Enqueue jobs
python enqueue_jobs.py
```

## Configuration

### Redis Connection

The dashboard supports various Redis configurations:

```bash
# Local Redis
--redis-url redis://localhost:6379

# Redis Cloud with SSL
--redis-url rediss://redis.example.com:6379

# With authentication
--redis-url redis://user:password@localhost:6379

# Or use separate username/password flags
--redis-url redis://localhost:6379 --username admin --password secret
```

### Server Options

```bash
--host 0.0.0.0          # Bind to all interfaces (default)
--port 8910             # Port number (default: 8910)
```

## Performance

ARQ Optimus Dashboard is built with performance in mind:

- **Async Operations**: All Redis operations are async
- **Connection Pooling**: Reuses Redis connections
- **Lightweight UI**: Minimal JavaScript, no heavy frameworks
- **Efficient Queries**: Optimized Redis queries for job listing

## Credits

Built on top of [ARQ](https://github.com/python-arq/arq) by Samuel Colvin.

## License

MIT License - see [LICENSE](../LICENSE) for details.
