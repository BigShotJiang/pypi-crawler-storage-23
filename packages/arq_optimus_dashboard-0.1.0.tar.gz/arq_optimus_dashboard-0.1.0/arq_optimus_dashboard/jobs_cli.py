"""
CLI commands for ARQ Optimus job management (no dashboard required)

Usage:
  arq-optimus stats --redis-url redis://localhost:6379
  arq-optimus list --redis-url redis://localhost:6379 --status running
  arq-optimus info <job_id> --redis-url redis://localhost:6379
  arq-optimus cancel <job_id> --redis-url redis://localhost:6379
  arq-optimus delete <job_id> --redis-url redis://localhost:6379
"""
import asyncio
import os
import sys
from datetime import datetime
from typing import Optional

import click

from . import __version__
from .core import ARQManager


def _run_async(coro):
    """Run an async coroutine synchronously"""
    return asyncio.run(coro)


@click.group('arq-optimus')
@click.version_option(version=__version__, prog_name='arq-optimus')
def cli():
    """ARQ Optimus - Job queue management CLI

    Monitor and manage ARQ async task queues from the command line.
    """
    pass


@cli.command()
@click.option('--redis-url', required=True, help='Redis connection URL')
@click.option('--key-prefix', default=lambda: os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''), help='Key prefix for multi-project Redis (env: ARQ_OPTIMUS_KEY_PREFIX)')
def stats(redis_url: str, key_prefix: str):
    """Show queue statistics"""
    async def _stats():
        manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
        try:
            info = await manager.get_queue_info()
            prefix_str = f" (prefix: '{key_prefix}')" if key_prefix else ""
            click.echo(f"\n📊 ARQ Queue Statistics{prefix_str}")
            click.echo("=" * 40)
            click.echo(f"  Queued:     {info.get('queued', 0):>6}")
            click.echo(f"  Running:    {info.get('running', 0):>6}")
            click.echo(f"  Completed:  {info.get('completed', 0):>6}")
            click.echo(f"  Failed:     {info.get('failed', 0):>6}")
            click.echo(f"  Cancelled:  {info.get('cancelled', 0):>6}")
            click.echo("-" * 40)
            click.echo(f"  Total:      {info.get('total', 0):>6}")
            click.echo()
        except Exception as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    _run_async(_stats())


@cli.command('list')
@click.option('--redis-url', required=True, help='Redis connection URL')
@click.option('--key-prefix', default=lambda: os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''), help='Key prefix for multi-project Redis (env: ARQ_OPTIMUS_KEY_PREFIX)')
@click.option('--status', type=click.Choice(['queued', 'running', 'completed', 'failed', 'cancelled']),
              default=None, help='Filter by job status')
@click.option('--limit', default=20, help='Maximum number of jobs to show')
@click.option('--offset', default=0, help='Offset for pagination')
def list_jobs(redis_url: str, key_prefix: str, status: Optional[str], limit: int, offset: int):
    """List jobs in the queue"""
    async def _list():
        manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
        try:
            jobs = await manager.list_jobs(status=status, limit=limit, offset=offset, minimal=True)
            
            status_label = status or "all"
            prefix_str = f" (prefix: '{key_prefix}')" if key_prefix else ""
            click.echo(f"\n📋 {status_label.capitalize()} Jobs{prefix_str} ({len(jobs)} shown)")
            click.echo("=" * 80)
            
            if not jobs:
                click.echo("  No jobs found.")
                click.echo()
                return
            
            # Header
            click.echo(f"  {'JOB ID':<36} {'FUNCTION':<24} {'STATUS':<12}")
            click.echo("-" * 80)
            
            for job in jobs:
                job_id = job.get('job_id', '?')[:36]
                func = job.get('function', '?')[:24]
                st = job.get('status', '?')
                
                # Color-code status
                if st == 'running':
                    st_display = click.style(st, fg='blue')
                elif st == 'completed':
                    st_display = click.style(st, fg='green')
                elif st == 'failed':
                    st_display = click.style(st, fg='red')
                elif st == 'queued':
                    st_display = click.style(st, fg='yellow')
                elif st == 'cancelled':
                    st_display = click.style(st, fg='magenta')
                else:
                    st_display = st
                
                click.echo(f"  {job_id:<36} {func:<24} {st_display}")
            
            click.echo()
        except Exception as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    _run_async(_list())


@cli.command()
@click.argument('job_id')
@click.option('--redis-url', required=True, help='Redis connection URL')
@click.option('--key-prefix', default=lambda: os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''), help='Key prefix for multi-project Redis (env: ARQ_OPTIMUS_KEY_PREFIX)')
def info(job_id: str, redis_url: str, key_prefix: str):
    """Show detailed info for a specific job"""
    async def _info():
        manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
        try:
            job_info = await manager.get_job_info(job_id)
            
            if not job_info:
                click.echo(f"❌ Job '{job_id}' not found", err=True)
                sys.exit(1)
            
            click.echo(f"\n🔍 Job Details")
            click.echo("=" * 60)
            click.echo(f"  Job ID:      {job_info.get('job_id', '?')}")
            click.echo(f"  Function:    {job_info.get('function', '?')}")
            
            # Status with color
            st = job_info.get('status', '?')
            if st == 'running':
                st_display = click.style(st, fg='blue', bold=True)
            elif st == 'completed':
                st_display = click.style(st, fg='green', bold=True)
            elif st == 'failed':
                st_display = click.style(st, fg='red', bold=True)
            elif st == 'queued':
                st_display = click.style(st, fg='yellow', bold=True)
            elif st == 'cancelled':
                st_display = click.style(st, fg='magenta', bold=True)
            else:
                st_display = st
            click.echo(f"  Status:      {st_display}")
            
            cancellable = job_info.get('cancellable', True)
            click.echo(f"  Cancellable: {'Yes' if cancellable else 'No'}")
            
            if job_info.get('enqueue_time'):
                click.echo(f"  Enqueued:    {job_info['enqueue_time']}")
            if job_info.get('start_time'):
                click.echo(f"  Started:     {job_info['start_time']}")
            if job_info.get('finish_time'):
                click.echo(f"  Finished:    {job_info['finish_time']}")
            
            if job_info.get('args'):
                click.echo(f"  Args:        {job_info['args']}")
            if job_info.get('kwargs'):
                click.echo(f"  Kwargs:      {job_info['kwargs']}")
            
            if job_info.get('success') is not None:
                click.echo(f"  Success:     {job_info['success']}")
            if job_info.get('result') is not None:
                click.echo(f"  Result:      {job_info['result']}")
            if job_info.get('error'):
                click.echo(f"  Error:       {click.style(job_info['error'], fg='red')}")
            
            click.echo()
        except Exception as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    _run_async(_info())


@cli.command()
@click.argument('job_id')
@click.option('--redis-url', required=True, help='Redis connection URL')
@click.option('--key-prefix', default=lambda: os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''), help='Key prefix for multi-project Redis (env: ARQ_OPTIMUS_KEY_PREFIX)')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
def cancel(job_id: str, redis_url: str, key_prefix: str, force: bool):
    """Cancel a queued or running job"""
    if not force:
        click.confirm(f'Cancel job {job_id}?', abort=True)
    
    async def _cancel():
        manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
        try:
            result = await manager.cancel_job(job_id)
            
            if result.get('success'):
                click.echo(f"✅ {result.get('message', 'Job cancelled')}")
            else:
                click.echo(f"❌ {result.get('message', 'Cancel failed')}", err=True)
                sys.exit(1)
        except Exception as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    _run_async(_cancel())


@cli.command()
@click.argument('job_id')
@click.option('--redis-url', required=True, help='Redis connection URL')
@click.option('--key-prefix', default=lambda: os.environ.get('ARQ_OPTIMUS_KEY_PREFIX', ''), help='Key prefix for multi-project Redis (env: ARQ_OPTIMUS_KEY_PREFIX)')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
def delete(job_id: str, redis_url: str, key_prefix: str, force: bool):
    """Delete a completed/failed job from Redis"""
    if not force:
        click.confirm(f'Delete job {job_id}?', abort=True)
    
    async def _delete():
        manager = ARQManager(redis_url=redis_url, key_prefix=key_prefix)
        try:
            result = await manager.delete_job(job_id)
            
            if result.get('success'):
                click.echo(f"✅ {result.get('message', 'Job deleted')}")
            else:
                click.echo(f"❌ {result.get('message', 'Delete failed')}", err=True)
                sys.exit(1)
        except Exception as e:
            click.echo(f"❌ Error: {e}", err=True)
            sys.exit(1)
    
    _run_async(_delete())


if __name__ == '__main__':
    cli()
