"""huntd — your coding fingerprint. Local git analytics dashboard."""

__version__ = "0.3.0"
