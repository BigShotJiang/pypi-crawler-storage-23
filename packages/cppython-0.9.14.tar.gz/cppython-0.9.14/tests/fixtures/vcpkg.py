"""Shared fixtures for VCPkg plugin tests"""
