"""
Tests for internal_variables support across SarvamToolBaseContext,
SarvamToolContext, SarvamOnStartToolContext, and SarvamOnEndToolContext.

These are the changes introduced to enable sandbox tools to access
internal runtime state (e.g. job_id, campaign_id).
"""

from datetime import datetime

import pytest

from sarvam_conv_ai_sdk.tool import (
    EngagementMetadata,
    SarvamInteractionTranscript,
    SarvamOnEndToolContext,
    SarvamOnStartToolContext,
    SarvamToolBaseContext,
    SarvamToolContext,
    SarvamToolLanguageName,
)


def make_metadata() -> EngagementMetadata:
    return EngagementMetadata(
        interaction_id="test_interaction_123", app_id="test_app", app_version=1
    )


def make_transcript() -> SarvamInteractionTranscript:
    return SarvamInteractionTranscript(
        interaction_transcript=[],
        interaction_start_time=datetime.now(),
        interaction_end_time=datetime.now(),
    )


# ---------------------------------------------------------------------------
# SarvamToolBaseContext
# ---------------------------------------------------------------------------


class TestBaseContextInternalVariables:

    def test_default_is_empty(self):
        ctx = SarvamToolBaseContext(engagement_metadata=make_metadata())
        assert ctx.internal_variables == {}

    def test_init_with_internal_variables(self):
        ctx = SarvamToolBaseContext(
            engagement_metadata=make_metadata(),
            internal_variables={"job_id": "j1", "campaign_id": "c1"},
        )
        assert ctx.internal_variables == {"job_id": "j1", "campaign_id": "c1"}

    def test_get_internal_variable_success(self):
        ctx = SarvamToolBaseContext(
            engagement_metadata=make_metadata(),
            internal_variables={"job_id": "j1", "campaign_id": "c1"},
        )
        assert ctx.get_internal_variable("job_id") == "j1"
        assert ctx.get_internal_variable("campaign_id") == "c1"

    def test_get_internal_variable_not_found(self):
        ctx = SarvamToolBaseContext(engagement_metadata=make_metadata())
        with pytest.raises(
            ValueError, match="Internal variable missing_key not found"
        ):
            ctx.get_internal_variable("missing_key")

    def test_set_internal_variable_new_key(self):
        ctx = SarvamToolBaseContext(engagement_metadata=make_metadata())
        ctx.set_internal_variable("job_id", "new_job_123")
        assert ctx.internal_variables["job_id"] == "new_job_123"

    def test_set_internal_variable_update_existing(self):
        ctx = SarvamToolBaseContext(
            engagement_metadata=make_metadata(),
            internal_variables={"job_id": "old"},
        )
        ctx.set_internal_variable("job_id", "updated")
        assert ctx.get_internal_variable("job_id") == "updated"

    def test_set_internal_variable_non_serializable(self):
        ctx = SarvamToolBaseContext(engagement_metadata=make_metadata())

        def bad():
            pass

        with pytest.raises(
            ValueError, match="Variable value is not serializable"
        ):
            ctx.set_internal_variable("bad_key", bad)


# ---------------------------------------------------------------------------
# SarvamToolContext (mid-turn)
# ---------------------------------------------------------------------------


class TestToolContextInternalVariables:

    def _ctx(self, internal_variables=None):
        kwargs = {}
        if internal_variables is not None:
            kwargs["internal_variables"] = internal_variables
        return SarvamToolContext(
            language=SarvamToolLanguageName.ENGLISH,
            allowed_languages=[SarvamToolLanguageName.ENGLISH],
            state="main_menu",
            next_valid_states=["weather"],
            engagement_metadata=make_metadata(),
            **kwargs,
        )

    def test_default_is_empty(self):
        assert self._ctx().internal_variables == {}

    def test_init_with_internal_variables(self):
        ctx = self._ctx({"job_id": "j1"})
        assert ctx.internal_variables == {"job_id": "j1"}
        assert ctx.get_internal_variable("job_id") == "j1"

    def test_set_and_get_internal_variable(self):
        ctx = self._ctx()
        ctx.set_internal_variable("campaign_id", "c1")
        assert ctx.get_internal_variable("campaign_id") == "c1"

    def test_internal_variables_independent_of_agent_variables(self):
        ctx = self._ctx({"job_id": "j1"})
        assert ctx.agent_variables == {}
        assert ctx.internal_variables == {"job_id": "j1"}


# ---------------------------------------------------------------------------
# SarvamOnStartToolContext (on_start)
# ---------------------------------------------------------------------------


class TestOnStartContextInternalVariables:

    def _ctx(self, internal_variables=None):
        kwargs = {}
        if internal_variables is not None:
            kwargs["internal_variables"] = internal_variables
        return SarvamOnStartToolContext(
            user_identifier="user123",
            initial_state_name="welcome",
            initial_language_name=SarvamToolLanguageName.ENGLISH,
            engagement_metadata=make_metadata(),
            **kwargs,
        )

    def test_default_is_empty(self):
        assert self._ctx().internal_variables == {}

    def test_init_with_internal_variables(self):
        ctx = self._ctx({"job_id": "j1"})
        assert ctx.get_internal_variable("job_id") == "j1"

    def test_set_internal_variable(self):
        ctx = self._ctx()
        ctx.set_internal_variable("job_id", "new_j1")
        assert ctx.get_internal_variable("job_id") == "new_j1"

    def test_internal_variables_not_found_raises(self):
        ctx = self._ctx()
        with pytest.raises(
            ValueError, match="Internal variable missing not found"
        ):
            ctx.get_internal_variable("missing")


# ---------------------------------------------------------------------------
# SarvamOnEndToolContext (on_end)
# ---------------------------------------------------------------------------


class TestOnEndContextInternalVariables:

    def _ctx(self, internal_variables=None):
        kwargs = {}
        if internal_variables is not None:
            kwargs["internal_variables"] = internal_variables
        return SarvamOnEndToolContext(
            user_identifier="user123",
            interaction_transcript=make_transcript(),
            engagement_metadata=make_metadata(),
            **kwargs,
        )

    def test_default_is_empty(self):
        assert self._ctx().internal_variables == {}

    def test_init_with_internal_variables(self):
        ctx = self._ctx({"job_id": "j1", "campaign_id": "c1"})
        assert ctx.get_internal_variable("job_id") == "j1"
        assert ctx.get_internal_variable("campaign_id") == "c1"

    def test_set_internal_variable(self):
        ctx = self._ctx()
        ctx.set_internal_variable("job_id", "end_j1")
        assert ctx.get_internal_variable("job_id") == "end_j1"

    def test_internal_variables_not_found_raises(self):
        ctx = self._ctx()
        with pytest.raises(
            ValueError, match="Internal variable missing not found"
        ):
            ctx.get_internal_variable("missing")

    def test_internal_variables_independent_of_agent_variables(self):
        ctx = self._ctx({"job_id": "j1"})
        assert ctx.agent_variables == {}
        assert ctx.internal_variables == {"job_id": "j1"}
