from .gguf_path import configure_gguf_path

configure_gguf_path()

__all__ = ["__version__"]
__version__ = "0.1.6"
