"""IMS MCP Server - Model Context Protocol server for IMS (Instruction Management Systems).

This package provides a FastMCP server that connects to IMS
for advanced retrieval-augmented generation capabilities.

Environment Variables:
    R2R_API_BASE: IMS server URL (default: http://localhost:7272)
    R2R_COLLECTION: Collection name for queries (optional)
    R2R_API_KEY: API key for authentication (optional)
    
Note: Environment variables use R2R_ prefix for compatibility with underlying R2R SDK.
"""

# Version is read from pyproject.toml (single source of truth)
try:
    from importlib.metadata import version
    __version__ = version("ims-mcp")
except Exception:
    __version__ = "unknown"

__author__ = "Igor Solomatov"

# Default PostHog Project API Key (injected during CI/CD build from GitHub secret)
# Users can override via POSTHOG_API_KEY env var or set to empty string to disable
# Placeholder is replaced by build.sh during CI/CD, stays as placeholder in local builds
DEFAULT_POSTHOG_API_KEY = "phc_UKvXMv2eOdBAIjLUsjripzQSmKFfmJIVZgx4b4AYjc9"

from ims_mcp.server import mcp

__all__ = ["mcp", "__version__", "DEFAULT_POSTHOG_API_KEY"]

