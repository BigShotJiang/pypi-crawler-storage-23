"""Connection management commands: connect, connections, disconnect."""

import asyncio

import click

from mcpbundles.config import AuthError, CLISettings
from mcpbundles.connections import ConnectionManager
from mcpbundles.mcp_client import hub_session, ConnectionError
from mcpbundles.output import render_success, render_error, render_warning, print_json, stdout_console

from rich.panel import Panel
from rich.table import Table


@click.command()
@click.argument("name")
@click.option("--url", help="Override server URL (default: mcp.mcpbundles.com)")
@click.option("--endpoint", default="/hub/", help="MCP endpoint path (default: /hub/)")
@click.option("--bundle", help="Connect to a bundle endpoint by slug (sets endpoint to /mcp/bundle/<slug>/)")
@click.option("--workspace", help="Workspace ID")
@click.option("--default", "is_default", is_flag=True, help="Set as default connection")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.pass_context
def connect(ctx: click.Context, name: str, url: str | None, endpoint: str, bundle: str | None, workspace: str | None, is_default: bool, as_json: bool) -> None:
    """Create a named connection to an MCP endpoint.

    Validates the connection by opening an MCP session before saving.

    Examples:
        mcpbundles connect hub --default
        mcpbundles connect hubspot --bundle hubspot
        mcpbundles connect prod --url https://mcp.mcpbundles.com
    """
    if bundle:
        endpoint = f"/mcp/bundle/{bundle}/"

    settings: CLISettings = ctx.obj["settings"]
    base_url = url or settings.base_url

    try:
        auth = settings.require_auth()
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(1)

    asyncio.run(_connect_impl(name, base_url, endpoint, workspace, is_default, as_json, auth))


async def _connect_impl(name: str, base_url: str, endpoint: str, workspace: str | None, is_default: bool, as_json: bool, auth: str) -> None:
    stdout_console.print(f"Connecting to [cyan]{base_url}{endpoint}[/] ...")

    try:
        async with hub_session(auth, base_url, endpoint) as session:
            result = await session.list_tools()
            tool_count = len(result.tools)
    except (AuthError, ConnectionError) as exc:
        render_error(f"Connection failed: {exc}")
        raise SystemExit(1)

    mgr = ConnectionManager()
    existing = mgr.get(name)
    if existing:
        render_warning(f"Connection '{name}' already exists — overwriting.")
        mgr.remove(name)

    conn = mgr.create(
        name=name,
        url=base_url,
        endpoint=endpoint,
        workspace_id=workspace,
        is_default=is_default,
    )

    if as_json:
        from dataclasses import asdict
        print_json(asdict(conn))
    else:
        render_success(f"Connection '{name}' created → {conn.display_target} ({tool_count} tools)")
        if is_default:
            stdout_console.print(f"  Set as [bold]default[/bold] connection")


@click.command("connections")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def list_connections(as_json: bool) -> None:
    """List all named connections."""
    mgr = ConnectionManager()
    conns = mgr.list_connections()

    if not conns:
        render_warning("No connections. Use 'mcpbundles connect <name>' to create one.")
        return

    if as_json:
        from dataclasses import asdict
        print_json([asdict(c) for c in conns])
        return

    table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Target", style="white")
    table.add_column("Session", style="dim")
    table.add_column("Default", style="green")

    for c in conns:
        session_str = "✓" if c.session_id else "—"
        default_str = "★" if c.is_default else ""
        table.add_row(c.name, c.display_target, session_str, default_str)

    panel = Panel(table, title=f"Connections ({len(conns)})", border_style="blue", padding=(1, 2))
    stdout_console.print(panel)


@click.command()
@click.argument("name")
def disconnect(name: str) -> None:
    """Remove a named connection."""
    mgr = ConnectionManager()
    if mgr.remove(name):
        render_success(f"Connection '{name}' removed.")
    else:
        render_error(f"Connection '{name}' not found.")
        raise SystemExit(1)
