from collections import defaultdict

from ..workspaces.get_workspaces import get_owned_workspaces, get_shared_workspaces
from ..repos import APIRepo


def group_projects_per_workspace(projects, workspaces):
    workspace_projects = defaultdict(lambda: {"projects": [], "owner_id": None})
    for project in projects:
        workspace_id = project["workspace_id"]
        workspace = next((ws for ws in workspaces if ws["id"] == workspace_id), None)
        if not workspace:
            continue
        workspace_name = workspace["name"]
        workspace_projects[workspace_name]["projects"].append(project["name"])
        workspace_projects[workspace_name]["owner_id"] = workspace.get("owner_id")
    return workspace_projects


def get_owned_projects(user):
    repo = APIRepo()
    projects = repo.retrieve_projects(user)
    workspaces = get_owned_workspaces(user)

    return group_projects_per_workspace(projects, workspaces)


def get_shared_projects(user):
    repo = APIRepo()
    projects = repo.retrieve_shared_projects(user)
    workspaces = get_shared_workspaces(user)
    return group_projects_per_workspace(projects, workspaces)


def get_projects_names_in_workspace(user, workspace):
    repo = APIRepo()
    projects_in_workspace, error = repo.retrieve_owned_projects_in_workspace(
        user, workspace
    )
    if error:
        raise Exception(f"Error retrieving projects in workspace: {error}")
    return [project["name"] for project in projects_in_workspace]


def get_project_in_workspace(user, workspace_name, project_name):
    repo = APIRepo()
    projects_in_workspace, error = repo.retrieve_owned_projects_in_workspace(
        user, workspace_name
    )
    if error:
        raise Exception("Error retrieving projects in workspace")

    for project in projects_in_workspace:
        if project["name"] == project_name:
            return project
    raise Exception(
        f"No project named '{project_name}' found in workspace '{workspace_name}'."
    )
