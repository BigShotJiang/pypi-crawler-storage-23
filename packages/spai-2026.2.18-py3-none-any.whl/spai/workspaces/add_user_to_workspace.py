from .get_workspaces import get_owned_workspaces
from ..repos.APIRepo import APIRepo


def add_user_to_workspace(user, user_email_to_add, role, workspace_name):
    # owner can grant access to owned workspaces to other users
    workspaces = get_owned_workspaces(user) 
    workspace_id = None
    for workspace in workspaces:
        if workspace["name"] == workspace_name:
            workspace_id = workspace['id']
    # TODO: mantainers of shared workspaces can grant access to shared workspaces to other users
    if not workspace_id:
       raise Exception(f"Workspace {workspace_name} not found")
    repo = APIRepo()
    data, error = repo.add_user_to_workspace(user, {"email": user_email_to_add, "role": role}, workspace_id)
    if error:
        raise Exception(f"Error adding user to workspace: {error}")
    return data
