from ..repos import APIRepo


def get_owned_workspaces(user):
    repo = APIRepo()
    data, error = repo.retrieve_owned_workspaces_by_user(user)
    if error:
        raise Exception(f"Error occured retrieving workspaces: {error}")
    return data


def get_shared_workspaces(user):
    repo = APIRepo()
    data, error = repo.retrieve_shared_workspaces_by_user(user)
    if error:
        raise Exception(f"Error occured retrieving workspaces: {error}")
    return data
