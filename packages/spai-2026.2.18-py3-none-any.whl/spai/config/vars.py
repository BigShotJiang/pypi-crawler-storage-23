import json
import os
from typing import Any, Dict


class SPAIVars:
    def __init__(self, current_dir: str = os.getcwd()
):
        max_tries = 3
        self.vars = None
        for _ in range(max_tries):

            file_path = current_dir + "/spai.vars.json"
            if os.path.isfile(file_path):
                
                print(f"Loading vars from {file_path}")
                if os.path.getsize(file_path) == 0:
                    raise ValueError(f"{file_path} is empty")
                
                with open(current_dir + "/spai.vars.json") as f:
                    data = json.load(f)
                
                if not isinstance(data, dict):
                    raise json.JSONDecodeError(f"{file_path} must contain a JSON object")

                self.vars = data
                return

            current_dir = os.path.dirname(current_dir)
        
        raise FileNotFoundError("No vars file found.")


    def __getitem__(self, key: str) -> Any | None:
        if self.vars and key in self.vars:
            return self.vars[key]
        return None

    def __repr__(self) -> str:
        if self.vars:
            return json.dumps(self.vars, indent=2)
        
    def get_all(self) -> Dict:
        return self.vars if self.vars else {}


def parse_vars(vars) -> Dict:
    variables = {}
    for var in vars:
        key, value = var.split("=")
        try:
            # Attempt to parse the value as JSON
            value = json.loads(value)
        except json.JSONDecodeError:
            # If it's not valid JSON, leave it as a string
            pass
        variables[key] = value
    return variables
