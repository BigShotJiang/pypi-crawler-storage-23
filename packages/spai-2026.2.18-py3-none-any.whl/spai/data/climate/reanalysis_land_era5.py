from datetime import date
from pathlib import Path
import dotenv
import os

import geopandas as gpd
import numpy as np
import requests
import xarray as xr

from ...storage import Storage
from .area_of_interest import AreaOfInterest

dotenv.load_dotenv()


PAT = os.getenv(
    "EARTH_DATA_HUB_PAT"
  )  #  https://earthdatahub.destine.eu/account-settings
MAX_DOWNLOAD_SIZE_MB = 5000
ERA5_VARS = ["asn", "d2m", "e", "es", "evabs", "evaow", "evatc", 
    "evavt", "fal", "lai_hv", "lai_lv", "lblt", "licd", "lict", "lmld", "lmlt", 
    "lshf", "ltlt", "pev", "ro", "rsn", "sde", "sf", "skt", "slhf", "smlt", 
    "snowc", "sp", "src", "sro", "sshf", "ssr", "ssrd", "ssro", "stl1", "stl2", 
    "stl3", "stl4", "str", "strd", "swvl1", "swvl2", "swvl3", "swvl4", "t2m", 
    "tp", "tsn", "u10", "v10"]


class LoadedData:
    def __init__(self, data: xr.Dataset):
        self.data = data

    def download(self, name: str, storage: Storage) -> Path:
        if self.data.nbytes / 1e6 > MAX_DOWNLOAD_SIZE_MB:
            raise ValueError(
                f"Data request larger than {MAX_DOWNLOAD_SIZE_MB}MB, please select a smaller area, shorter the time range, or reduce the temporal or sp"
            )

        print(f"Downloading {(self.data.nbytes / 1e6,)} MB")

        data = self.data.compute()
        path = storage.create(
            data,
            name=name,
        )

        print(f"Data downloaded to {path}")
        return Path(path)


def check_access(url: str) -> None:
    
    url = f"{url}/.zgroup"
    r = requests.head(
        url,
        auth=("edh", PAT),
        allow_redirects=True,
    )

    if r.status_code == 401:
        raise RuntimeError("Unauthorized (401): maybe your token is expired.")
    if r.status_code == 403:
        raise RuntimeError("Forbidden (403): request limit exceeded.")
    if r.status_code == 404:
        raise RuntimeError("Not found (404): the requested dataset does not exist.")
    if r.ok:
        return
    

def _to0360(lon):
    """Convert longitude(s) from [-180,180] to [0,360)."""
    return np.mod(lon, 360.0)


def _to180(lon):
    """Convert longitude(s) from [0,360) to [-180,180)."""
    return ((lon + 180.0) % 360.0) - 180.0


def aoi_to_0360_parts(aoi: AreaOfInterest):
    """
    Convert an AOI in -180..180 to one or two AOIs in 0..360 (for ERA5).
    Returns a list of plain dicts, since AreaOfInterest enforces -180..180.
    """
    x0, x1 = _to0360(aoi.xmin), _to0360(aoi.xmax)

    # AOI doesn’t cross the dateline
    if aoi.xmin <= aoi.xmax:
        if x0 <= x1:
            return [{"xmin": float(x0), "xmax": float(x1),
                     "ymin": aoi.ymin, "ymax": aoi.ymax}]
        else:
            # Wraps around due to modulo behavior
            return [
                {"xmin": float(x0), "xmax": 360.0, "ymin": aoi.ymin, "ymax": aoi.ymax},
                {"xmin": 0.0, "xmax": float(x1), "ymin": aoi.ymin, "ymax": aoi.ymax},
            ]
    else:
        # Crosses the antimeridian (e.g. 170 → -170)
        return [
            {"xmin": float(x0), "xmax": 360.0, "ymin": aoi.ymin, "ymax": aoi.ymax},
            {"xmin": 0.0, "xmax": float(x1), "ymin": aoi.ymin, "ymax": aoi.ymax},
        ]




def load_era5(
    aoi: gpd.GeoDataFrame,
    start_date: date,
    end_date: date | None = None,
    dataset: str = "reanalysis-era5-land-no-antartica-v0",
    era5_vars: list[str, None] = [],
) -> xr.Dataset:
    f"""
    For env vars see https://confluence.ecmwf.int/display/CKB/ERA5-Land%3A+data+documentation#heading-Parameterlistings
    ERA5 vars available: {ERA5_VARS}
    """

    aoi = AreaOfInterest.from_geodataframe(aoi)

    if end_date is None:
        end_date = start_date

    if start_date > end_date:
        raise ValueError("Start date must be before or equal to end_date")

    if era5_vars and not set(era5_vars).issubset(ERA5_VARS):
        raise ValueError(f"At least one of the passed vars is not in allowed vars: {ERA5_VARS}")

    url = f"https://edh:{PAT}@data.earthdatahub.destine.eu/era5/{dataset}.zarr"
    check_access(url)

    if not PAT:
        raise ValueError(
            "No PAT found for Earth Data Hub, please set EARTH_DATA_HUB_PAT on https://earthdatahub.destine.eu/ and store in your .env"
        )
    
    parts = aoi_to_0360_parts(aoi)
    datasets = []

    for p in parts:
        if not (-90 <= aoi.ymin <= 90 and -90 <= aoi.ymax <= 57.1):
            raise ValueError("Latitude values must be between -90 and 57.1 degrees for ERA5 data")

        ds = xr.open_dataset(
            url,
            storage_options={"client_kwargs": {"trust_env": True}},
            chunks={},
            engine="zarr",
        )

        data = ds.sel(
            valid_time=slice(
                np.datetime64(start_date), np.datetime64(end_date) + np.timedelta64(1, "D")
            ),
            latitude=slice(aoi.ymax, aoi.ymin),
            longitude=slice(aoi.xmin, aoi.xmax),
        )

        if era5_vars:
            data = data[era5_vars]

        if data.valid_time.size == 0:
            raise ValueError("No data available to download for the specified date range")
        datasets.append(data)

    ds = xr.concat(datasets, dim="longitude") if len(datasets) > 1 else datasets[0]
    ds = ds.assign_coords(longitude=_to180(ds.longitude)).sortby("longitude")
    
    return LoadedData(data=ds)
