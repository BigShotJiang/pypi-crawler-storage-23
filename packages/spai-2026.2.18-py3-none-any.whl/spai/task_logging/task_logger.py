from typing import Optional
import httpx
from pydantic import BaseModel


class TaskCreate(BaseModel):
    service_id: str
    name: str
    km2: Optional[int] = None
    km: Optional[int] = None


class TaskLogger:
    """
    A class to interact with the post task endpoint, so private services can log their process for billing.
    """

    def __init__(
        self,
        deployment_id: str,
        api_key: str,
        spai_api_url: str = "https://spai-test.earthpulse.ai/",
    ):
        self.api_key = api_key
        self.post_task_endpoint = (
            f"{spai_api_url.rstrip('/')}/usage/deployments/{deployment_id}/tasks"
        )

    def log_task(self, task: TaskCreate) -> bool:
        response = httpx.post(
            self.post_task_endpoint,
            json=task.model_dump(),
            headers={"X-API-Key": self.api_key},
        )
        response.raise_for_status()
        return response
