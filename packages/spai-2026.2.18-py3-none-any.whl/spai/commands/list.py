import typer


from ..auth import auth
from ..project import get_shared_projects, get_owned_projects, get_services
from ..workspaces.get_workspaces import get_owned_workspaces, get_shared_workspaces

app = typer.Typer(help="Retrieve information about your projects and services")


@app.command(help="List all projects")
def projects():
    try:
        user = auth()
        owned_projects = get_owned_projects(user)
        shared_projects = get_shared_projects(user)

        if len(owned_projects) == 0 and len(shared_projects) == 0:
            return typer.echo("No projects found.")

        for workspace in list(shared_projects.keys()):
            if (
                workspace in owned_projects
                and owned_projects[workspace]["owner_id"]
                == shared_projects[workspace]["owner_id"]
            ):
                del shared_projects[workspace]

        typer.echo("Owned projects:")
        for workspace, data in owned_projects.items():
            typer.echo(f"\nworkspace: {workspace}")
            for project in data["projects"]:
                typer.echo(f"  - {project}")

        typer.echo("\n\nShared projects:")
        for workspace, data in shared_projects.items():
            typer.echo(f"\nworkspace: {workspace}")
            for project in data["projects"]:
                typer.echo(f"  - {project}")

    except Exception as e:
        typer.echo(f"Error: {e}")


@app.command(help="List all services in a project")
def services(
    project: str = typer.Argument(..., help="Project name"),
    workspace: str = typer.Option(
        "default", "--workspace", "-w", help="Workspace name"
    ),
):
    try:
        user = auth()
        services = get_services(user, project, workspace_name=workspace, format=True)
        if len(services) == 0:
            return typer.echo(f"No services running in project '{project}'.")
        typer.echo(f"Services in project '{project}': {services}")
    except Exception as e:
        typer.echo(f"Error: {e}")


@app.command(help="List all your workspaces")
def workspaces():
    try:
        user = auth()
        owned_workspaces = get_owned_workspaces(user)
        shared_workspaces = get_shared_workspaces(user)
        for ws in owned_workspaces:
            shared_workspaces = [
                sws for sws in shared_workspaces if sws["id"] != ws["id"]
            ]
        typer.echo("Owned workspaces:")
        for ws in owned_workspaces:
            typer.echo(f"  - {ws['name']}")
        typer.echo("\nShared workspaces:")
        for ws in shared_workspaces:
            # email = get_user_email_for_id(ws["owner_id"], user)
            # typer.echo(f"  - {ws['name']}, (owner: {email})")
            typer.echo(f"  - {ws['name']}")
    except Exception as e:
        raise e


if __name__ == "__main__":
    app()
