"""Round-trip test: deserialize XML → serialize → compare with original."""

import pytest
from annotationpro_format import deserialize_annotation, serialize_annotation

SAMPLE_XML = """<?xml version="1.0" standalone="yes"?>
<AnnotationSystemDataSet xmlns="http://tempuri.org/AnnotationSystemDataSet.xsd">
  <Layer>
    <Id>ed9dcc21-1dfb-47db-8777-3b5c1131d168</Id>
    <Name>Layer 1</Name>
    <ForeColor>-3281999</ForeColor>
    <BackColor>-16777216</BackColor>
    <IsSelected>true</IsSelected>
    <Height>40</Height>
    <CoordinateControlStyle>1</CoordinateControlStyle>
    <IsLocked>true</IsLocked>
    <IsClosed>true</IsClosed>
    <ShowOnSpectrogram>true</ShowOnSpectrogram>
    <ShowAsChart>true</ShowAsChart>
    <ChartMinimum>-10</ChartMinimum>
    <ChartMaximum>500</ChartMaximum>
    <ShowBoundaries>true</ShowBoundaries>
    <IncludeInFrequency>true</IncludeInFrequency>
    <Parameter1Name>P1</Parameter1Name>
    <Parameter2Name>P2</Parameter2Name>
    <Parameter3Name>P3</Parameter3Name>
    <IsVisible>true</IsVisible>
    <FontSize>11</FontSize>
  </Layer>
  <Segment>
    <Id>ab1c2902-0049-4a2e-8aa4-6413bb78b989</Id>
    <IdLayer>ed9dcc21-1dfb-47db-8777-3b5c1131d168</IdLayer>
    <Label>This is phrase</Label>
    <ForeColor>-16777216</ForeColor>
    <BackColor>-1</BackColor>
    <BorderColor>-16777216</BorderColor>
    <Start>12333.0</Start>
    <Duration>44300.0</Duration>
    <IsSelected>true</IsSelected>
    <Feature>Feature</Feature>
    <Language>PL</Language>
    <Group>---</Group>
    <Name>-- na --</Name>
    <Parameter1>12</Parameter1>
    <Parameter2>32</Parameter2>
    <Parameter3>44</Parameter3>
    <IsMarker>false</IsMarker>
    <Marker>marker test</Marker>
    <RScript>no</RScript>
  </Segment>
  <Configuration>
    <Key>Samplerate</Key>
    <Value>44100</Value>
  </Configuration>
  <Configuration>
    <Key>Version</Key>
    <Value>5</Value>
  </Configuration>
</AnnotationSystemDataSet>"""


def test_deserialize_serialize_roundtrip():
    annotation = deserialize_annotation(SAMPLE_XML)
    assert annotation.configuration.get("Samplerate") == "44100"
    assert len(annotation.layers) == 1
    layer = annotation.layers[0]
    assert layer.name == "Layer 1"
    assert len(layer.segments) == 1
    seg = layer.segments[0]
    assert seg.label == "This is phrase"
    assert seg.start == 12333.0
    assert seg.duration == 44300.0

    xml_out = serialize_annotation(annotation)
    # Compare structure: same Layers and Segments and key config entries
    parsed_again = deserialize_annotation(xml_out)
    assert len(parsed_again.layers) == len(annotation.layers)
    assert parsed_again.layers[0].name == annotation.layers[0].name
    assert len(parsed_again.layers[0].segments) == 1
    assert parsed_again.layers[0].segments[0].label == "This is phrase"


def test_seconds_helpers():
    from annotationpro_format import (
        Annotation,
        Layer,
        Segment,
        get_segment_start_seconds,
        get_segment_duration_seconds,
        set_segment_start_seconds,
        set_segment_duration_seconds,
        seconds_to_samples,
        samples_to_seconds,
    )

    annotation = Annotation(samplerate=44100)
    assert seconds_to_samples(1.5, 44100) == 66150.0
    assert samples_to_seconds(66150, 44100) == 1.5

    seg = Segment("test", start=0.0, duration=0.0)
    set_segment_start_seconds(annotation, seg, 2.5)
    set_segment_duration_seconds(annotation, seg, 1.25)
    assert get_segment_start_seconds(annotation, seg) == 2.5
    assert get_segment_duration_seconds(annotation, seg) == 1.25
    assert seg.start == 2.5 * 44100
    assert seg.duration == 1.25 * 44100
