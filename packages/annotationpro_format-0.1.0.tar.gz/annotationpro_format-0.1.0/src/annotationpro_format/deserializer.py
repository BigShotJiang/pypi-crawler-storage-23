"""
Deserializes antx XML content to Annotation PRO model.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from io import BytesIO
from typing import Optional

from .model import (
    Annotation,
    Layer,
    Segment,
    SegmentCollection,
)

# Default namespace in antx XML (ElementTree expands tags to {uri}LocalName)
NS = "http://tempuri.org/AnnotationSystemDataSet.xsd"


def _tag(name: str) -> str:
    return f"{{{NS}}}{name}" if NS else name


def _text(el: Optional[ET.Element], tag: str, default: str = "") -> str:
    """Get text content of first child with tag, or default."""
    if el is None:
        return default
    child = el.find(_tag(tag))
    if child is None:
        return default
    return (child.text or "").strip()


def _int(el: Optional[ET.Element], tag: str, default: int = 0) -> int:
    """Get integer from child tag."""
    s = _text(el, tag)
    if not s:
        return default
    try:
        return int(s)
    except ValueError:
        return default


def _float(el: Optional[ET.Element], tag: str, default: float = 0.0) -> float:
    """Get float from child tag."""
    s = _text(el, tag)
    if not s:
        return default
    try:
        return float(s)
    except ValueError:
        return default


def _bool(s: str) -> bool:
    """Parse boolean string (True/true/False/false)."""
    return s.strip().lower() in ("true", "1", "yes")


def deserialize_segment(node: ET.Element) -> Segment:
    """Parse one Segment element into Segment model."""
    segment = Segment(
        label=_text(node, "Label"),
        start=_float(node, "Start"),
        duration=_float(node, "Duration"),
    )
    segment.id = _text(node, "Id") or segment.id
    segment.id_layer = _text(node, "IdLayer")
    segment.fore_color = _int(node, "ForeColor", -16777216)
    segment.back_color = _int(node, "BackColor", -1)
    segment.border_color = _int(node, "BorderColor", -16777216)
    segment.is_selected = _bool(_text(node, "IsSelected"))
    segment.feature = _text(node, "Feature")
    segment.language = _text(node, "Language")
    segment.group = _text(node, "Group")
    segment.name = _text(node, "Name")
    segment.parameter1 = _text(node, "Parameter1")
    segment.parameter2 = _text(node, "Parameter2")
    segment.parameter3 = _text(node, "Parameter3")
    segment.is_marker_enabled = _bool(_text(node, "IsMarker"))
    segment.marker = _text(node, "Marker")
    segment.r_script = _text(node, "RScript")
    return segment


def deserialize_layer(node: ET.Element) -> Layer:
    """Parse one Layer element into Layer model (without segments)."""
    layer = Layer(name=_text(node, "Name"))
    layer.id = _text(node, "Id") or layer.id
    layer.fore_color = _int(node, "ForeColor", -16777216)
    layer.back_color = _int(node, "BackColor", -3281999)
    layer.is_selected = _bool(_text(node, "IsSelected"))
    layer.height = _int(node, "Height", 70)
    layer.coordinate_control_style = _int(node, "CoordinateControlStyle", 3)
    layer.is_locked = _bool(_text(node, "IsLocked"))
    layer.is_closed = _bool(_text(node, "IsClosed"))
    layer.show_on_spectrogram = _bool(_text(node, "ShowOnSpectrogram"))
    layer.show_as_chart = _bool(_text(node, "ShowAsChart"))
    layer.chart_minimum = _int(node, "ChartMinimum", -50)
    layer.chart_maximum = _int(node, "ChartMaximum", 50)
    layer.show_boundaries = _bool(_text(node, "ShowBoundaries"))
    layer.include_in_frequency = _bool(_text(node, "IncludeInFrequency"))
    layer.parameter1_name = _text(node, "Parameter1Name") or "Parameter 1"
    layer.parameter2_name = _text(node, "Parameter2Name") or "Parameter 2"
    layer.parameter3_name = _text(node, "Parameter3Name") or "Parameter 3"
    layer.is_visible = _bool(_text(node, "IsVisible"))
    layer.font_size = _int(node, "FontSize", 10)
    layer.segments = SegmentCollection(layer.id)
    return layer


def deserialize_configuration(root: ET.Element) -> dict[str, str]:
    """Parse all Configuration elements into a dict."""
    config: dict[str, str] = {}
    for node in root.findall(f".//{_tag('Configuration')}"):
        key = _text(node, "Key")
        value = _text(node, "Value")
        if key:
            config[key] = value
    return config


def deserialize_annotation(xml_content: str | bytes) -> Annotation:
    """
    Deserialize antx XML string to Annotation model.

    Args:
        xml_content: XML string or bytes (e.g. from .antx file).

    Returns:
        Annotation instance with layers and segments filled.

    Raises:
        ET.ParseError: If XML is invalid.
    """
    if isinstance(xml_content, str):
        xml_content = xml_content.encode("utf-8")
    tree = ET.parse(BytesIO(xml_content))
    root = tree.getroot()

    # Default samplerate from config or 44100
    config = deserialize_configuration(root)
    samplerate_str = config.get("Samplerate", "44100")
    try:
        samplerate = int(samplerate_str)
    except ValueError:
        samplerate = 44100

    annotation = Annotation(samplerate=samplerate)
    annotation.configuration = config

    # Layers (without segments)
    layers: list[Layer] = []
    for node in root.findall(_tag("Layer")):
        layers.append(deserialize_layer(node))
    annotation.layers = layers

    # Segments and assign to layers by IdLayer
    layer_by_id = {layer.id: layer for layer in layers}
    for node in root.findall(_tag("Segment")):
        segment = deserialize_segment(node)
        lid = segment.id_layer
        if lid and lid in layer_by_id:
            layer_by_id[lid].segments.append(segment)

    return annotation
