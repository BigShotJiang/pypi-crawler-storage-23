"""
Model classes for Annotation PRO antx format.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


# Configuration keys (same as Java)
SAMPLERATE_KEY = "Samplerate"
VERSION_KEY = "Version"
FILE_VERSION_KEY = "FileVersion"
CREATED_KEY = "Created"
MODIFIED_KEY = "Modified"
PROJECT_TITLE_KEY = "ProjectTitle"
PROJECT_ENVIRONMENT = "ProjectEnvironment"
PROJECT_NOISES = "ProjectNoises"
PROJECT_COLLECTION = "ProjectCollection"
PROJECT_CORPUS_TYPE = "ProjectCorpusType"
PROJECT_CORPUS_OWNER = "ProjectCorpusOwner"
PROJECT_LICENSE = "ProjectLicense"
PROJECT_DESCRIPTION = "ProjectDescription"

VERSION = "5"


@dataclass
class AudioFile:
    """Represents audio file in annotation pro format."""

    name: str
    file_name: str
    external: bool
    current: bool
    id: Optional[str] = None

    def __post_init__(self) -> None:
        if self.id is None:
            self.id = str(uuid.uuid4())


@dataclass
class Segment:
    """Single annotation segment: start, duration, label and metadata."""

    label: str
    start: float
    duration: float
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    id_layer: Optional[str] = None
    fore_color: int = -16777216
    back_color: int = -1
    border_color: int = -16777216
    is_selected: bool = False
    feature: str = ""
    language: str = ""
    group: str = ""
    name: str = ""
    parameter1: str = ""
    parameter2: str = ""
    parameter3: str = ""
    is_marker_enabled: bool = False
    marker: str = ""
    r_script: str = ""


class SegmentCollection(list):
    """List of segments with layer id; assigns id_layer when segments are added."""

    def __init__(self, id_layer: str, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self.id_layer = id_layer

    def append(self, segment: Segment) -> None:
        segment.id_layer = self.id_layer
        super().append(segment)

    def insert(self, index: int, segment: Segment) -> None:
        segment.id_layer = self.id_layer
        super().insert(index, segment)


@dataclass
class Layer:
    """Annotation layer with segments and display settings."""

    name: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    fore_color: int = -16777216
    back_color: int = -3281999
    is_selected: bool = True
    height: int = 70
    coordinate_control_style: int = 3
    is_locked: bool = False
    is_closed: bool = False
    show_on_spectrogram: bool = False
    show_as_chart: bool = False
    chart_minimum: int = -50
    chart_maximum: int = 50
    show_boundaries: bool = True
    include_in_frequency: bool = True
    parameter1_name: str = "Parameter 1"
    parameter2_name: str = "Parameter 2"
    parameter3_name: str = "Parameter 3"
    is_visible: bool = True
    font_size: int = 10
    segments: Optional[SegmentCollection] = None

    def __post_init__(self) -> None:
        if self.segments is None:
            self.segments = SegmentCollection(self.id)
        else:
            self.segments.id_layer = self.id


@dataclass
class Annotation:
    """
    Root model for Annotation PRO format.
    Holds configuration (dict) and list of layers; each layer has segments.
    """

    samplerate: int
    layers: list[Layer] = field(default_factory=list)
    configuration: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        now = datetime.now().isoformat(sep=" ", timespec="seconds")
        self.configuration.setdefault(SAMPLERATE_KEY, str(self.samplerate))
        self.configuration.setdefault(VERSION_KEY, VERSION)
        self.configuration.setdefault(FILE_VERSION_KEY, VERSION)
        self.configuration.setdefault(CREATED_KEY, now)
        self.configuration.setdefault(MODIFIED_KEY, now)
        self.configuration.setdefault(PROJECT_TITLE_KEY, "")
        self.configuration.setdefault(PROJECT_ENVIRONMENT, "")
        self.configuration.setdefault(PROJECT_NOISES, "")
        self.configuration.setdefault(PROJECT_COLLECTION, "")
        self.configuration.setdefault(PROJECT_CORPUS_TYPE, "")
        self.configuration.setdefault(PROJECT_CORPUS_OWNER, "")
        self.configuration.setdefault(PROJECT_LICENSE, "")
        self.configuration.setdefault(PROJECT_DESCRIPTION, "")
