"""
Helpers for working with segment start/duration in seconds.
ANTX files store times in samples; these helpers convert to/from seconds using the annotation samplerate.
"""

from __future__ import annotations

from .model import Annotation, Segment


def seconds_to_samples(seconds: float, samplerate: int) -> float:
    """Convert time in seconds to sample count."""
    return seconds * samplerate


def samples_to_seconds(samples: float, samplerate: int) -> float:
    """Convert sample count to time in seconds."""
    if samplerate <= 0:
        return 0.0
    return samples / samplerate


def get_segment_start_seconds(annotation: Annotation, segment: Segment) -> float:
    """Get segment start time in seconds (segment.start is in samples)."""
    return samples_to_seconds(segment.start, annotation.samplerate)


def get_segment_duration_seconds(annotation: Annotation, segment: Segment) -> float:
    """Get segment duration in seconds (segment.duration is in samples)."""
    return samples_to_seconds(segment.duration, annotation.samplerate)


def set_segment_start_seconds(
    annotation: Annotation, segment: Segment, seconds: float
) -> None:
    """Set segment start from time in seconds (writes to segment.start in samples)."""
    segment.start = seconds_to_samples(seconds, annotation.samplerate)


def set_segment_duration_seconds(
    annotation: Annotation, segment: Segment, seconds: float
) -> None:
    """Set segment duration from time in seconds (writes to segment.duration in samples)."""
    segment.duration = seconds_to_samples(seconds, annotation.samplerate)
