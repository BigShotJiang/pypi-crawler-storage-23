"""
Serializes Annotation PRO model to antx XML string.
"""

from __future__ import annotations

from .model import Annotation, Layer, Segment


def _escape(s: str | None) -> str:
    """Escape XML special characters."""
    if s is None:
        s = ""
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _format_float(x: float) -> str:
    """Format float for XML (match Java Double: 12333.0 for whole numbers)."""
    if x == int(x):
        return f"{int(x)}.0"
    return str(x)


def serialize_segment(segment: Segment) -> str:
    """Serialize one segment to XML."""
    return (
        "  <Segment>\n"
        f"    <Id>{_escape(segment.id or "")}</Id>\n"
        f"    <IdLayer>{_escape(segment.id_layer or "")}</IdLayer>\n"
        f"    <Label>{_escape(segment.label)}</Label>\n"
        f"    <ForeColor>{segment.fore_color}</ForeColor>\n"
        f"    <BackColor>{segment.back_color}</BackColor>\n"
        f"    <BorderColor>{segment.border_color}</BorderColor>\n"
        f"    <Start>{_format_float(segment.start)}</Start>\n"
        f"    <Duration>{_format_float(segment.duration)}</Duration>\n"
        f"    <IsSelected>{str(segment.is_selected).lower()}</IsSelected>\n"
        f"    <Feature>{_escape(segment.feature)}</Feature>\n"
        f"    <Language>{_escape(segment.language)}</Language>\n"
        f"    <Group>{_escape(segment.group)}</Group>\n"
        f"    <Name>{_escape(segment.name)}</Name>\n"
        f"    <Parameter1>{_escape(segment.parameter1)}</Parameter1>\n"
        f"    <Parameter2>{_escape(segment.parameter2)}</Parameter2>\n"
        f"    <Parameter3>{_escape(segment.parameter3)}</Parameter3>\n"
        f"    <IsMarker>{str(segment.is_marker_enabled).lower()}</IsMarker>\n"
        f"    <Marker>{_escape(segment.marker)}</Marker>\n"
        f"    <RScript>{_escape(segment.r_script)}</RScript>\n"
        "  </Segment>\n"
    )


def serialize_layer(layer: Layer) -> str:
    """Serialize one layer to XML."""
    return (
        "  <Layer>\n"
        f"    <Id>{_escape(layer.id)}</Id>\n"
        f"    <Name>{_escape(layer.name)}</Name>\n"
        f"    <ForeColor>{layer.fore_color}</ForeColor>\n"
        f"    <BackColor>{layer.back_color}</BackColor>\n"
        f"    <IsSelected>{str(layer.is_selected).lower()}</IsSelected>\n"
        f"    <Height>{layer.height}</Height>\n"
        f"    <CoordinateControlStyle>{layer.coordinate_control_style}</CoordinateControlStyle>\n"
        f"    <IsLocked>{str(layer.is_locked).lower()}</IsLocked>\n"
        f"    <IsClosed>{str(layer.is_closed).lower()}</IsClosed>\n"
        f"    <ShowOnSpectrogram>{str(layer.show_on_spectrogram).lower()}</ShowOnSpectrogram>\n"
        f"    <ShowAsChart>{str(layer.show_as_chart).lower()}</ShowAsChart>\n"
        f"    <ChartMinimum>{layer.chart_minimum}</ChartMinimum>\n"
        f"    <ChartMaximum>{layer.chart_maximum}</ChartMaximum>\n"
        f"    <ShowBoundaries>{str(layer.show_boundaries).lower()}</ShowBoundaries>\n"
        f"    <IncludeInFrequency>{str(layer.include_in_frequency).lower()}</IncludeInFrequency>\n"
        f"    <Parameter1Name>{_escape(layer.parameter1_name)}</Parameter1Name>\n"
        f"    <Parameter2Name>{_escape(layer.parameter2_name)}</Parameter2Name>\n"
        f"    <Parameter3Name>{_escape(layer.parameter3_name)}</Parameter3Name>\n"
        f"    <IsVisible>{str(layer.is_visible).lower()}</IsVisible>\n"
        f"    <FontSize>{layer.font_size}</FontSize>\n"
        "  </Layer>\n"
    )


def serialize_configuration(configuration: dict[str, str]) -> str:
    """Serialize configuration entries to XML."""
    parts = []
    for key, value in configuration.items():
        parts.append(
            "  <Configuration>\n"
            f"    <Key>{_escape(key)}</Key>\n"
            f"    <Value>{_escape(value)}</Value>\n"
            "  </Configuration>\n"
        )
    return "".join(parts)


def serialize_annotation(annotation: Annotation) -> str:
    """
    Serialize annotation to antx XML string.

    Args:
        annotation: Annotation model instance.

    Returns:
        XML string compatible with Annotation PRO antx format.
    """
    parts = [
        '<?xml version="1.0" standalone="yes"?>\n',
        '<AnnotationSystemDataSet xmlns="http://tempuri.org/AnnotationSystemDataSet.xsd">\n',
    ]
    for layer in annotation.layers:
        parts.append(serialize_layer(layer))
    for layer in annotation.layers:
        for segment in layer.segments:
            parts.append(serialize_segment(segment))
    parts.append(serialize_configuration(annotation.configuration))
    parts.append("</AnnotationSystemDataSet>")
    return "".join(parts)
