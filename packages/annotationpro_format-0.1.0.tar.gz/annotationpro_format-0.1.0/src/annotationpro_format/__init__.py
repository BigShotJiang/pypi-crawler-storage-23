"""
Annotation PRO antx format – read/write .antx files (Annotation PRO XML).
"""

from .model import (
    VERSION,
    Annotation,
    AudioFile,
    Layer,
    Segment,
    SegmentCollection,
)
from .serializer import serialize_annotation
from .deserializer import deserialize_annotation
from .seconds import (
    seconds_to_samples,
    samples_to_seconds,
    get_segment_start_seconds,
    get_segment_duration_seconds,
    set_segment_start_seconds,
    set_segment_duration_seconds,
)

__all__ = [
    "Annotation",
    "AudioFile",
    "Layer",
    "Segment",
    "SegmentCollection",
    "VERSION",
    "serialize_annotation",
    "deserialize_annotation",
    "seconds_to_samples",
    "samples_to_seconds",
    "get_segment_start_seconds",
    "get_segment_duration_seconds",
    "set_segment_start_seconds",
    "set_segment_duration_seconds",
]
