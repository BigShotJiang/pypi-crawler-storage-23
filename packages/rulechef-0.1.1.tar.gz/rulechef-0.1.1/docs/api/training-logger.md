# Training Data Logger

Captures LLM calls as structured training data for model distillation.

## TrainingDataLogger

::: rulechef.training_logger.TrainingDataLogger
    options:
      members:
        - __init__
        - log
        - count
