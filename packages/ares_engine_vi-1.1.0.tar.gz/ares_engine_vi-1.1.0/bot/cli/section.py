import os
import subprocess
import requests
from bot.ui.banner import Banner
from bot.utils.common_utils import clear_screen, choice_selector, return_buffer
from bot.file_manager.directory import select_file
from bot.ui.content import display_about, display_help


class Sections:

    def __init__(self, console) -> None:
        self.banner = Banner(console)
        self.console = console
        self.current_section = ""

    def home_pagesection(self) -> None:
        clear_screen()
        self.banner.home_banner()

        while True:
            option = choice_selector(["Get started", "Hits file", "Fails file", "About","Help", "Exit"])
            match option:
                case "Get started":
                    self.__start_bot_automating()
                case "About":
                    self.__about()
                case "Hits file":
                    self.__read_hit_file()
                    return_buffer()
                case "Fails file":
                    self.__read_failed_file()
                    return_buffer()
                case "Help":
                    self.__help()
                case "Exit":
                    os._exit(0)
                case _:
                    pass

    def __read_hit_file(self) -> None:
        if os.name == "nt":
            subprocess.run(["notepad", "hits_readable.txt"])
        else:
            subprocess.run(["nano", "hits_readable.txt"])
    def __read_failed_file(self) -> None:
        if os.name == "nt":
            subprocess.run(["notepad","fails_readable.txt"])
        else:
            subprocess.run(["nano","fails_readable.txt"])

    def __start_bot_automating(self) -> None:
        select_file(self.console, os.path.expanduser("~"))

    def __about(self) -> None:
        self.current_section = "About"
        display_about()
        self.__common_navigator()
    
    def __help(self) -> None:
        self.current_section = "Help"
        clear_screen()
        self.banner.about()
        display_help()
        self. __common_navigator()

    def __common_navigator(self) -> None:
        option = choice_selector(
            ["Back to home", "Help" if self.current_section != "Help" else "Exit"]
        )
        match option:
            case "Back to home":
                self.home_pagesection()
            case "Help":
                self.__help()
            case _:
                pass