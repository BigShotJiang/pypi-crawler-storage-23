success_keywords = [
    "dashboard", "account overview",
    "logout", "sign out", "welcome","WELCOME", "Welcome Back",

    # Common greetings / status
    "hello", "hi", "profile", "my account", "account home", "home page",
    "settings", "user settings", "preferences", "account details",
    
    # Navigation / sections
    "main menu", "control panel", "management", "member area",
    "client portal", "user portal", "portal home", "admin panel",
    
    # Confirmation words
    "success", "successful login", "logged in", "login successful",
    "signed in", "authentication successful", "session active", "active session",
    "dashboard overview", "overview page", "welcome message", "account summary",
    
    # User-specific
    "my profile", "my dashboard", "my settings", "my homepage", "my account summary",
    "recent activity", "notifications", "messages", "inbox", "tasks", "activities"
]

failure_keywords = [
    "incorrect password", "invalid credentials",
    "authentication failed", "wrong password",
    "login failed", "try again",
    "account locked", "not valid",

    # Common error messages
    "username or password incorrect", "user not found",
    "email or password incorrect", "cannot log in",
    "failed to authenticate", "sign in failed",
    "invalid username", "invalid login",
    
    # Security / access issues
    "account disabled", "account temporarily locked",
    "too many attempts", "captcha required", "verification failed",
    "access denied", "permission denied", "login attempt blocked",
    
    # Expired or inactive accounts
    "password expired", "account expired", "inactive account",
    "user deactivated", "session expired", "login session expired",
    
    # Misc messages
    "please check your credentials", "login not allowed",
    "unauthorized access", "failed login attempt",
    "authentication error", "login credentials invalid",
    "email not registered", "invalid token", "mfa required",
    "two-factor authentication failed", "otp incorrect", "security check failed"
]