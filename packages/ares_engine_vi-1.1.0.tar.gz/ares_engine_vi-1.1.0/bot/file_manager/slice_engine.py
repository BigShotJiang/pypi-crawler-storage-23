from bot.script.bot_script import AresEngine
import asyncio

class ByTurboSliceEngine():

    def __init__(self):
        self.accounts = []

    def intial_acc_list(self) -> None:
        return self.accounts

    def extract_combo_content(self, file_path: str) -> list[str]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f, 1):
                    line = line.strip()
                    if not line or ":" not in line:
                        continue
                    
                    # Supports email:pass or user:pass
                    parts = line.split(":", 1)
                    self.accounts.append({
                        "user": parts[0].strip(),
                        "pass_": parts[1].strip(),
                        "line": i
                    })
        except Exception as e:
            print(f"Error reading file: {e}")

    def dispatch_combo_credential(self, ui_state) -> list[str]:
        if ui_state[next(reversed(ui_state))][2] != "WAIT":
            return self.accounts[int(next(reversed(ui_state))): int(next(reversed(ui_state)))+30]
        else:
            return None
        
