"""oubliette_dungeon.storage - Results storage backends."""

from oubliette_dungeon.storage.json_file import RedTeamResultsDB

__all__ = ["RedTeamResultsDB"]
