from setuptools import setup, find_packages

setup(
    name="genuine2049",
    version="0.1.2", # تأكد من رفع الإصدار
    packages=find_packages(), # هذه الدالة هي التي تبحث عن مجلد genuine2049
    include_package_data=True,
    install_requires=[
        "pywebview",
    ],
    author="Ghalib",
    description="إطار عمل لتصميم واجهات المستخدم بتصميم مستقبلي",
    url="https://github.com/your-username/genuine-joi-2049",
)