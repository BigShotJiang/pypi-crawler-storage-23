import asyncio
from enum import Enum
from Osdental.Shared.Logger import logger
from Osdental.Helpers.AuditLogHelper import AuditLogHelper
from Osdental.Models.AuditConfig import AuditConfig
from Osdental.Messaging import IMessageQueue
<<<<<<< HEAD
from Osdental.Models.Response import Response
=======
>>>>>>> 1cf4297b6fe2dc55507a2c9e16f4fbe7ee1f13e1

class AuditType(Enum):
    RESPONSE = "RESPONSE"
    ERROR = "ERROR"

class AuditDispatcher:

    def __init__(self, service_bus: IMessageQueue, audit_config: AuditConfig, max_queue_size: int = 5000):
        self.service_bus = service_bus
        self.audit_config = audit_config
        self.queue = asyncio.Queue(maxsize=max_queue_size)
        self.worker_task = None

    # Se llama en startup
    async def start(self):
        self.worker_task = asyncio.create_task(self._worker())

    # Se llama en shutdown
    async def stop(self):
        # Esperar a que la cola se vacíe
        await self.queue.join()

        # Enviar sentinel para cerrar worker
        await self.queue.put(None)

        # Esperar a que el worker termine
        if self.worker_task:
            await self.worker_task

    # no bloquea
    async def dispatch(self, security, result):
        try:
            payload = {
                "security": security,
                "result": result
            }

            self.queue.put_nowait(payload)

        except asyncio.QueueFull:
            logger.exception("Audit queue full. Dropping message.")

    # Worker real
    async def _worker(self):
        while True:
            payload = await self.queue.get()
            # Sentinel detectado → salir limpio
            if payload is None:
                self.queue.task_done()
                break

            try:
                await self._process(payload)
            except Exception:
                logger.exception("Audit processing failed")
            finally:
                self.queue.task_done()

    # Aquí vive toda la lógica fea
    async def _process(self, payload):
        security = payload["security"]
<<<<<<< HEAD
        result: Response = payload["result"]
=======
        result = payload["result"]
>>>>>>> 1cf4297b6fe2dc55507a2c9e16f4fbe7ee1f13e1

        operation_name = security.gql_request.operation_name
        if operation_name == 'UnknownOperation':
            logger.info("Skipping audit: no data in GraphQL response")
            return
        
        request_audit_payload = await AuditLogHelper.build_request_payload(
            security, self.audit_config
        )

<<<<<<< HEAD
        status = result.status
=======
        status = result.get("status")
        data = result.get("data")
        error = result.get("error")
>>>>>>> 1cf4297b6fe2dc55507a2c9e16f4fbe7ee1f13e1
        
        ERROR_PREFIXES = ("DB_ERROR", "DB_WARNING")
        if status.upper().startswith(ERROR_PREFIXES):
            payload = AuditLogHelper.build_final_payload(
                type=AuditType.ERROR.value,
                status_code=status,
<<<<<<< HEAD
                error=result.error
=======
                error=error
>>>>>>> 1cf4297b6fe2dc55507a2c9e16f4fbe7ee1f13e1
            )

            audit_message = request_audit_payload | payload

        else:
            payload = AuditLogHelper.build_final_payload(
                type=AuditType.RESPONSE.value,
                status_code=status,
<<<<<<< HEAD
                result=result.data
=======
                result=data
>>>>>>> 1cf4297b6fe2dc55507a2c9e16f4fbe7ee1f13e1
            )

            audit_message = request_audit_payload | payload
        
        await self.service_bus.enqueue(audit_message)