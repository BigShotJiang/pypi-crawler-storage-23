from typing import Callable, Type, Dict, Any

class MessageBus:
    def __init__(
        self,
        handlers: Dict[Type, Callable]
    ):
        self.handlers = handlers

    async def handle(self, command: Any):
        handler = self.handlers[type(command)]
        return await handler.handle(command)