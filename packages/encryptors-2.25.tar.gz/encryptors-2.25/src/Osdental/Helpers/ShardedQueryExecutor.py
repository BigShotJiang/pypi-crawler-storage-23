import asyncio
from typing import Callable, Awaitable, Any, Optional
from Osdental.Shared.Enums.ShardQueryPolicy import ShardQueryPolicy
from Osdental.Models.ShardResource import DatabaseData
from Osdental.Exception.ControlledException import ShardDatabaseException
from Osdental.Shared.Logger import logger


class ShardDatabaseException(Exception):
    def __init__(
        self, 
        message: str
    ):
        super().__init__(message)

class ShardedQueryExecutor:

    def __init__(self, shards: list[DatabaseData], max_concurrency: int = 10):
        self.shards = shards
        self._sem = asyncio.Semaphore(max_concurrency)


    async def execute(
        self,
        policy: ShardQueryPolicy,
        executor: Callable[[DatabaseData], Awaitable[Any]]
    ) -> Any:

        if policy is ShardQueryPolicy.FIRST_FOUND:
            return await self._execute_first_found(executor)

        if policy is ShardQueryPolicy.COLLECT_ALL:
            return await self._execute_collect_all(executor)

        raise ValueError(f"Unsupported policy: {policy}")
    

    async def _run_with_limit(self, shard, executor):
        async with self._sem:
            return await executor(shard)


    async def _execute_first_found(self, executor: Callable[[DatabaseData], Awaitable[Optional[Any]]]) -> Optional[Any]:

        tasks = [
            asyncio.create_task(self._run_with_limit(shard, executor))
            for shard in self.shards
        ]

        try:
            for task in asyncio.as_completed(tasks):
                try:
                    result = await task
                    if result is not None:
                        for t in tasks:
                            t.cancel()
                        return result

                except ShardDatabaseException:
                    for t in tasks:
                        t.cancel()
                    raise

                except asyncio.CancelledError:
                    raise

                except Exception:
                    logger.exception("Shard execution failed (ignored)")
                    continue
            
            return None

        finally:
            await asyncio.gather(*tasks, return_exceptions=True)

    

    async def _execute_collect_all(self, executor: Callable[[DatabaseData], Awaitable[Optional[Any]]]):

        tasks = [
            asyncio.create_task(self._run_with_limit(shard, executor))
            for shard in self.shards
        ]

        results = []

        try:
            for task in asyncio.as_completed(tasks):
                try:
                    result = await task
                    if result is not None:
                        results.append(result)

                except ShardDatabaseException:
                    for t in tasks:
                        t.cancel()
                    raise

                except Exception:
                    for t in tasks:
                        t.cancel()
                    raise

            return results

        finally:
            await asyncio.gather(*tasks, return_exceptions=True)