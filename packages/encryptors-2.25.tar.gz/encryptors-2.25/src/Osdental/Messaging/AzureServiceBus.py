import json
from typing import Dict
from azure.servicebus.aio import ServiceBusClient
from azure.servicebus import ServiceBusMessage
from Osdental.Messaging import IMessageQueue

"""
from azure.servicebus import ServiceBusRetryMode

client = ServiceBusClient.from_connection_string(
    conn_str,
    retry_total=5,
    retry_backoff_factor=0.8,
    retry_mode=ServiceBusRetryMode.EXPONENTIAL
)
==========
@asynccontextmanager
async def lifespan(app: FastAPI):

    servicebus_client = ServiceBusClient.from_connection_string(
        settings.SB_CONN_STR,
        retry_total=5,
        retry_backoff_factor=0.8
    )

    app.state.sb_client = servicebus_client

    yield

    await servicebus_client.close()


No controlas prefetch para los listener 
receiver = client.get_queue_receiver(
    queue_name="myqueue",
    prefetch_count=50
)

"""
class AzureServiceBusQueue(IMessageQueue):

    def __init__(self, client: ServiceBusClient, queue_name: str):
        self._client = client
        self._queue_name = queue_name

    async def enqueue(self, message: Dict | str) -> None:
        sender = self._client.get_queue_sender(queue_name=self._queue_name)

        async with sender:
            payload = json.dumps(message) if isinstance(message, dict) else message

            sb_message = ServiceBusMessage(
                payload,
                content_type="application/json"
            )

            await sender.send_messages(sb_message)
