from Osdental.Shared.Enums.Code import Code
from Osdental.Shared.Enums.Message import Message

class OSDException(Exception):
    """ Base class for all custom exceptions. """
    def __init__(
        self, 
        message: str = Message.UNEXPECTED_ERROR_MSG, 
        error: str = None, 
        status_code: str = Code.APP_ERROR_CODE
    ):
        super().__init__(message)
        self.message = message
        self.error = error
        self.status_code = status_code

    
class UnauthorizedException(OSDException):
    def __init__(
        self,
        message: str = Message.PORTAL_ACCESS_RESTRICTED_MSG,
        error: str = None,
        status_code: str = Code.UNAUTHORIZATED_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class RequestDataException(OSDException):
    def __init__(
        self,
        message: str = Message.INVALID_REQUEST_PARAMS_MSG,
        error:str = None,
        status_code: str = Code.INVALID_REQUEST_PARAMS_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)


class DatabaseConnectionException(OSDException):
    def __init__(
        self,
        message: str = Message.INVALID_FORMAT_MSG,
        error: str = None,
        status_code: str = Code.DATABASE_CONNECTION_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)


class DatabaseException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.DATABASE_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)


class JWTokenException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.JWT_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class HttpClientException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.HTTP_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class AzureException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.AZURE_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class RedisException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.REDIS_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class ValidationDataException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.REQUEST_VALIDATION_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class UnexpectedException(OSDException):
    def __init__(
        self, 
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.UNEXPECTED_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class MissingFieldException(OSDException):
    def __init__(
        self,
        message: str = Message.MISSING_FIELD_ERROR_MSG,
        error: str = None,
        status_code: str = Code.MISSING_FIELD_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class ProfilePermissionDeniedException(OSDException):
    def __init__(
        self,
        message: str = Message.PROFILE_PERMISSION_DENIED_MSG,
        error: str = None,
        status_code: str = Code.PROFILE_PERMISSION_DENIED_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class InvalidFormatException(OSDException):
    def __init__(
        self,
        message: str = Message.INVALID_FORMAT_MSG,
        error: str = None,
        status_code: str = Code.INVALID_FORMAT_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)

class ShardDatabaseException(OSDException):
    def __init__(
        self,
        message: str = Message.UNEXPECTED_ERROR_MSG,
        error: str = None,
        status_code: str = Code.DB_UNKNOWN_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)