import json
from Osdental.Encryptor.Aes import AES
from Osdental.Models._SecurityContext import GraphQLRequest
from Osdental.Models.Encryptor import Encryptor

class GraphQLPayloadService:

    def decrypt(self, gql_request: GraphQLRequest, encryptor: Encryptor):
        encrypted_data = gql_request.variables.get("data")

        if not encrypted_data:
            return None

        if not encryptor:
            raise ValueError("Encryptor not available")

        decrypted = AES.decrypt(encryptor.aes_auth, encrypted_data)

        if isinstance(decrypted, str):
            try:
                decrypted = json.loads(decrypted)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON in decrypted payload")
            
        return decrypted