from Osdental.Encryptor.Aes import AES
from Osdental.Encryptor.Jwt import JWT
from Osdental.Models.Token import AuthToken
from Osdental.Pipeline._Ports import IAuthService
from Osdental.Exception.ControlledException import UnauthorizedException

class TokenService:

    def __init__(self, jwt_user_key: str, auth_service: IAuthService):
        self.jwt_user_key = jwt_user_key
        self.auth_service = auth_service

    async def authenticate(self, request):
        authorization = request.headers.get("authorization")
        if not authorization or not authorization.startswith("Bearer "):
            raise ValueError("Missing Bearer token")

        encrypted_token = authorization.split(" ")[1]
        encryptor = getattr(request.app.state, "encryptor", None)
        if not encryptor:
            raise ValueError("Encryptor not available")

        user_token = AES.decrypt(encryptor.aes_user, encrypted_token)
        payload = JWT.extract_payload(user_token, self.jwt_user_key)
        token = AuthToken(**payload)

        # Validate via RPC
        is_valid = await self.auth_service.validate_auth_token(token.id_token, token.id_user)
        if not is_valid:
            raise UnauthorizedException()

        return token
