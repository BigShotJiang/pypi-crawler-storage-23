from typing import Protocol

class IAuthService(Protocol):

    async def validate_auth_token(self, id_token: str, id_user: str) -> bool:
        ...
