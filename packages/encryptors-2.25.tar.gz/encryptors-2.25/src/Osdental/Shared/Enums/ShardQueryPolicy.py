from enum import Enum

class ShardQueryPolicy(Enum):
    FIRST_FOUND = "first_found"     # by id, unique
    COLLECT_ALL = "collect_all"     # lists, searches