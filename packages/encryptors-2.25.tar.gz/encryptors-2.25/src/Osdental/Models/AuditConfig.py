from pydantic import BaseModel

class AuditConfig(BaseModel):
    environment: str
    microservice_name: str
    microservice_version: str
