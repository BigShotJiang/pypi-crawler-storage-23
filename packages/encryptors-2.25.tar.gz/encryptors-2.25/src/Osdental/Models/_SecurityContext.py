from typing import Dict, Any
from pydantic import BaseModel
from fastapi import Request
from Osdental.Models.Token import AuthToken
from Osdental.Models.Encryptor import Encryptor

class GraphQLRequest(BaseModel):
    operation_type: str
    operation_name: str
    variables: Dict[str, Any]


class SecurityContext(BaseModel):
    request: Request
    token: AuthToken
    encryptor: Encryptor
    payload: Dict[str, Any]
    gql_request: GraphQLRequest