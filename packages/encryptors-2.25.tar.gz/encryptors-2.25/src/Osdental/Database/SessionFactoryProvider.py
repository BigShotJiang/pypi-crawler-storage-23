from Osdental.Database.ISessionFactoryProvider import ISessionFactoryProvider
from Osdental.Database import SessionManager
from Osdental.Models.ShardResource import DatabaseData

class SessionFactoryProvider(ISessionFactoryProvider):

    async def get(self, db: DatabaseData):
        return await SessionManager.get_session_factory(db.conn_string)
