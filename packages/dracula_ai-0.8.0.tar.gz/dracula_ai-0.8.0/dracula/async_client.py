from google import genai
from pathlib import Path
from .memory import AsyncMemory
from .tools import Tool, ToolRegistry, ToolResult
from .stats import AsyncStats
from .retry import async_retry
from .models import GeminiModel
from .personas import PERSONAS
from ._version import __version__
from .version_checker import check_latest_version
from .logger import get_logger, enable_logging, disable_logging, enable_file_logging
from .exceptions import InvalidAPIKeyException, ChatException, PersonaException
from .validators import (
    validate_api_key,
    validate_temperature,
    validate_max_output_tokens,
    validate_max_messages,
    validate_prompt,
    validate_message,
    validate_filepath,
    validate_language,
    validate_model,
)

logger = get_logger(f"dracula.{__name__}")


class AsyncDracula:
    """
    Async version of Dracula for use in async applications.

    AsyncDracula provides the same features as Dracula but with
    full async support, making it perfect for Discord bots, FastAPI
    web apps, Telegram bots, and any other async Python application.

    Args:
        api_key (str): Your Google Gemini API key.
        model (GeminiModel | str): The Gemini model to use. Defaults to GeminiModel.FLASH.
        max_messages (int): Maximum number of messages to keep in memory. Defaults to 10.
        prompt (str): System prompt that defines the AI's personality.
        temperature (float): Controls response creativity between 0.0 and 2.0.
        max_output_tokens (int): Maximum length of responses in tokens.
        stats_filepath (str): Path to save usage stats.
        language (str): Language for responses. Defaults to 'English'.
        logging (bool): Enable or disable logging. Defaults to False.
        log_level (str): Logging level. Defaults to 'DEBUG'.
        log_file (str): Path to log file. Defaults to None.
        log_max_bytes (int): Maximum log file size in bytes. Defaults to 5MB.
        log_backup_count (int): Number of backup log files to keep. Defaults to 5.

    Example:
        >>> import asyncio
        >>> from dracula import AsyncDracula
        >>> async def main():
        ...     async with AsyncDracula(api_key="your-api-key") as ai:
        ...         response = await ai.chat("Hello!")
        ...         print(response)
        >>> asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        model: GeminiModel | str = GeminiModel.FLASH,
        max_messages: int = 10,
        prompt: str = "You are a helpful assistant.",
        temperature: float = 1.0,
        max_output_tokens: int = 8192,
        language: str = "English",
        logging: bool = False,
        log_level: str = "DEBUG",
        log_file: str = None,
        log_max_bytes: int = 5 * 1024 * 1024,
        log_backup_count: int = 5,
        tools: list = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        db_path: str | Path = None,
    ):
        """Initializes the AsyncDracula client.

        Args:
            api_key (str): Your Google Gemini API key.
            model (GeminiModel | str): The model to use for generations.
            max_messages (int): Limit for message history retention.
            prompt (str): The initial system instruction.
            db_path (str): Filepath for the SQLite memory database.
        """

        validate_api_key(api_key)
        validate_model(model)
        validate_temperature(temperature)
        validate_max_output_tokens(max_output_tokens)
        validate_max_messages(max_messages)
        validate_prompt(prompt)
        validate_language(language)

        self.tool_registry = ToolRegistry(tools or [])

        if logging:
            enable_logging(log_level)
        else:
            disable_logging()

        if log_file:
            enable_file_logging(
                log_file, max_bytes=log_max_bytes, backup_count=log_backup_count
            )

        try:
            self.client = genai.Client(api_key=api_key)
            self.model_name = model.value if isinstance(model, GeminiModel) else model
        except Exception:
            raise InvalidAPIKeyException("Invalid API key or model name.")

        self.prompt = prompt
        self.language = language
        self.temperature = temperature
        self.max_output_tokens = max_output_tokens
        self.memory = AsyncMemory(db_path=db_path, max_messages=max_messages)
        self.stats = AsyncStats()
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        check_latest_version(__version__)

        self._chat_session = None
        self._initialized = False

        logger.debug(
            f"AsyncDracula initialized with model={self.model_name}, "
            f"language={language}, temperature={temperature}"
        )

    async def _ensure_initialized(self):
        """Ensures that the memory database and chat session are ready.

        Since async operations cannot occur in __init__, this method handles
        the deferred setup of the SQLite schema and the initial session.
        """

        if not self._initialized:
            await self.memory.initialize()
            await self.stats.initialize()
            await self._create_chat_session()
            self._initialized = True

    async def chat(self, message: str, auto_call: bool = True) -> str | ToolResult:
        """Sends a message and returns the model's response asynchronously.

        Args:
            message (str): The user input text.
            auto_call (bool): Whether to handle tool calls automatically.

        Returns:
            str: The text response generated by Gemini.
        """
        await self._ensure_initialized()
        validate_message(message)

        async def _do_chat():
            await self.stats.record_message(message)
            logger.debug(f"Sending message: {message[:50]}...")

            response = await self._chat_session.send_message(message)

            while True:
                tool_call_found = False

                if not response.candidates or not response.candidates[0].content:
                    raise ChatException(
                        "Response was blocked or returned empty (likely due to safety filters)."
                    )

                for part in response.candidates[0].content.parts:
                    if hasattr(part, "function_call") and part.function_call:
                        tool_call_found = True
                        tool_name = part.function_call.name
                        tool_args = dict(part.function_call.args)

                        logger.debug(f"Tool call requested: {tool_name}({tool_args})")

                        if not auto_call:
                            return ToolResult(
                                requires_tool_call=True,
                                tool_name=tool_name,
                                tool_args=tool_args,
                                text=None,
                            )

                        tool = self.tool_registry.get(tool_name)
                        tool_result = await tool.async_call(**tool_args)
                        logger.debug(f"Tool '{tool_name}' returned: {tool_result}")

                        response = await self._chat_session.send_message(
                            genai.types.Part(
                                function_response=genai.types.FunctionResponse(
                                    name=tool_name,
                                    response={"result": str(tool_result)},
                                )
                            )
                        )
                        break

                if not tool_call_found:
                    reply = response.text
                    if not reply:
                        raise ChatException("Received an empty response from Gemini.")

                    await self.memory.add_message("user", message)
                    await self.memory.add_message("model", reply)
                    await self.stats.record_response(reply)
                    self._full_history = await self.memory.get_history()
                    logger.debug(f"Received response: {reply[:50]}...")
                    return reply

        return await async_retry(
            _do_chat, max_retries=self.max_retries, retry_delay=self.retry_delay
        )

    async def stream(self, message: str):
        """Asynchronously streams the response word by word with memory integration.

        This method ensures the database is initialized, records the outgoing
        user message, and yields chunks of the response in real-time. Once
        the stream completes, the full response is persisted to the SQLite
        backend to maintain conversational context.

        Args:
            message (str): The user input text to send to Gemini.

        Yields:
            str: Chunks of text as they are generated by the model.

        Raises:
            ChatException: If the stream is interrupted or the database
                operations fail.
        """
        await self._ensure_initialized()
        validate_message(message)
        await self.stats.record_message(message)

        last_exception = None

        for attempt in range(self.max_retries + 1):
            full_reply = ""
            try:
                async for chunk in await self._chat_session.send_message_stream(
                    message
                ):
                    if chunk.text:
                        full_reply += chunk.text
                        yield chunk.text

                await self.memory.add_message("user", message)
                await self.memory.add_message("model", full_reply)

                await self.stats.record_response(full_reply)
                self._full_history = await self.memory.get_history()
                return

            except Exception as e:
                last_exception = e

                if full_reply:
                    logger.error(
                        f"Async stream interrupted after partial response: {str(e)}"
                    )
                    raise ChatException(
                        f"Stream interrupted during generation: {str(e)}"
                    )

                if attempt == self.max_retries:
                    raise ChatException(
                        f"Stream failed after {self.max_retries} retries. Last error: {str(e)}"
                    )

                import asyncio

                delay = self.retry_delay * (2**attempt)
                logger.warning(
                    f"Async stream attempt {attempt + 1} failed: {str(e)}. "
                    f"Retrying in {delay}s..."
                )
                await asyncio.sleep(delay)

        raise last_exception

    def set_prompt(self, prompt: str) -> "AsyncDracula":
        """
        Change the system prompt and clear conversation memory.

        Args:
            prompt (str): The new system prompt.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_prompt(prompt)
        self.prompt = prompt
        self.memory.clear()
        self._create_chat_session()
        logger.info("Prompt updated.")
        return self

    def set_temperature(self, temperature: float) -> "AsyncDracula":
        """
        Change the temperature setting.

        Args:
            temperature (float): A value between 0.0 and 2.0.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_temperature(temperature)
        self.temperature = temperature
        return self

    def set_max_output_tokens(self, max_output_tokens: int) -> "AsyncDracula":
        """
        Change the maximum response length in tokens.

        Args:
            max_output_tokens (int): Maximum number of tokens in the response.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_max_output_tokens(max_output_tokens)
        self.max_output_tokens = max_output_tokens
        return self

    def set_language(self, language: str) -> "AsyncDracula":
        """
        Change the response language and clear conversation memory.

        Args:
            language (str): The language for responses.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_language(language)
        self.language = language
        self.memory.clear()
        self._create_chat_session()
        logger.info(f"Language changed to '{language}'")
        return self

    def set_model(self, model: GeminiModel | str) -> "AsyncDracula":
        """
        Change the Gemini model.

        Args:
            model (GeminiModel | str): The model to use.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_model(model)
        self.model_name = model.value if isinstance(model, GeminiModel) else model
        self._create_chat_session()
        logger.info(f"Model changed to '{self.model_name}'")
        return self

    def set_persona(self, persona: str) -> "AsyncDracula":
        """
        Switch to a built-in persona instantly.

        Args:
            persona (str): The name of the persona to use.

        Returns:
            AsyncDracula: The current instance for method chaining.

        Raises:
            PersonaException: If the persona name is not recognized.
        """
        if persona not in PERSONAS:
            available = ", ".join(PERSONAS.keys())
            raise PersonaException(
                f"Unknown persona '{persona}'. Available personas: {available}"
            )

        selected = PERSONAS[persona]
        self.set_prompt(selected["prompt"])
        self.set_temperature(selected["temperature"])
        self.set_language(selected["language"])
        logger.info(f"Persona changed to '{persona}'")
        return self

    def set_log_level(self, level: str) -> "AsyncDracula":
        """
        Change the logging level.

        Args:
            level (str): Logging level — DEBUG, INFO, WARNING, ERROR, or CRITICAL.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        enable_logging(level)
        return self

    def set_retry(self, max_retries: int, retry_delay: float = 1.0) -> "AsyncDracula":
        """
        Change the retry settings.

        Args:
            max_retries (int): Maximum number of retry attempts.
            retry_delay (float): Initial delay in seconds between retries.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_retry(max_retries=5, retry_delay=2.0)
        """
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        logger.info(
            f"Retry settings updated: max_retries={max_retries}, retry_delay={retry_delay}"
        )
        return self

    def list_personas(self) -> list:
        """
        Return a list of all available built-in persona names.

        Returns:
            list: A list of persona name strings.
        """
        return list(PERSONAS.keys())

    async def list_available_models(self) -> list:
        """
        Asynchronously fetch all currently available Gemini models from the API.

        Returns:
            list: A list of available model name strings.
        """
        try:
            models = await self.client.aio.models.list()
            return [model.name for model in models]
        except Exception as e:
            raise ChatException(f"Failed to fetch models: {str(e)}")

    def get_stats(self) -> dict:
        """Return the current usage statistics."""
        return self.stats.get_stats()

    def reset_stats(self):
        """Reset all usage statistics back to zero."""
        self.stats.reset()

    def save_history(self, filepath: str):
        """Save the conversation history to a JSON file."""
        validate_filepath(filepath)
        self.memory.save(filepath)

    def load_history(self, filepath: str):
        """Load conversation history from a JSON file."""
        validate_filepath(filepath)
        self.memory.load(filepath)

    async def clear_memory(self):
        """Permanently clears conversational history from the SQLite database.

        This action also resets the current active chat session.
        """
        await self._ensure_initialized()
        await self.memory.clear()
        await self._create_chat_session()
        logger.info("Asynchronous memory and session cleared.")

    def get_history(self) -> list:
        """Return the full conversation history."""
        return self.memory.get_history()

    def print_history(self):
        """Print the conversation history in a clean, readable format."""
        history = self.memory.get_history()

        if not history:
            print("No conversation history yet.")
            return

        print("\n" + "═" * 50)
        print("         🧛 DRACULA CONVERSATION HISTORY")
        print("═" * 50)

        for i, msg in enumerate(history, 1):
            if msg["role"] == "user":
                print(f"\n[{i}] 👤 You:")
            else:
                print(f"\n[{i}] 🤖 Gemini:")
            print(f"    {msg['content']}")

        print("\n" + "═" * 50 + "\n")

    async def close(self):
        """Close the async client and release all resources."""
        try:
            if hasattr(self.client, "_api_client"):
                if hasattr(self.client._api_client, "_session"):
                    session = self.client._api_client._session
                    if session and not session.closed:
                        await session.close()
        except Exception:
            pass

    async def __aenter__(self) -> "AsyncDracula":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        self.clear_memory()
        await self.close()
        return False

    def _build_system_instruction(self) -> str:
        """Build the system instruction with language."""
        if self.language.lower() != "auto":
            return f"{self.prompt} Always respond in {self.language}."
        return self.prompt

    def _build_config(self) -> genai.types.GenerateContentConfig:
        """Build the GenerateContentConfig."""
        config = genai.types.GenerateContentConfig(
            system_instruction=self._build_system_instruction(),
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
        )
        if self.tool_registry.has_tools():
            config.tools = [
                genai.types.Tool(
                    function_declarations=self.tool_registry.get_gemini_schemas()
                )
            ]
        return config

    async def _create_chat_session(self):
        """Creates or restores a Gemini chat session with stored history.

        Fetches history from the asynchronous SQLite backend to populate
        the initial context of the Gemini session.
        """
        history_data = await self.memory.get_history()

        config = genai.types.GenerateContentConfig(
            system_instruction=self._build_system_instruction(),
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
        )

        if self.tool_registry.has_tools():
            config.tools = [
                genai.types.Tool(
                    function_declarations=self.tool_registry.get_gemini_schemas()
                )
            ]

        self._chat_session = self.client.aio.chats.create(
            model=self.model_name,
            config=config,
            history=[
                genai.types.Content(
                    role=msg["role"], parts=[genai.types.Part(text=msg["content"])]
                )
                for msg in history_data
            ],
        )

    def add_tool(self, tool: Tool) -> "AsyncDracula":
        """
        Register a new tool after initialization.

        Args:
            tool (Tool): The tool to register.

        Returns:
            AsyncDracula: The current instance for method chaining.

        Example:
            >>> ai.add_tool(get_weather)
        """
        self.tool_registry.register(tool)
        self._create_chat_session()
        logger.info(f"Tool '{tool.name}' registered.")
        return self

    def list_tools(self) -> list:
        """
        Return a list of all registered tool names.

        Returns:
            list: List of tool name strings.

        Example:
            >>> print(ai.list_tools())
        """
        return self.tool_registry.list_tools()
