"""
PandaDock test suite
"""
