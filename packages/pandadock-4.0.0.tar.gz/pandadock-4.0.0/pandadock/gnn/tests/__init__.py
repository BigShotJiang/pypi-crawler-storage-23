"""Tests for PandaDock-GNN module."""
