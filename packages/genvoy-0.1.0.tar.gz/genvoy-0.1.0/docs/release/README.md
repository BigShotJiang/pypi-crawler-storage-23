﻿# Release Docs

- [CHECKLIST.md](./CHECKLIST.md)
- [RELEASE_NOTES_TEMPLATE.md](./RELEASE_NOTES_TEMPLATE.md)

These files are used in Phase 4 for consistent release quality and communication.
