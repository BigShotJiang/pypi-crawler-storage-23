"""MCP prompt templates for common Houdini workflows."""

from __future__ import annotations

# Internal
from . import workflows  # noqa: F401
