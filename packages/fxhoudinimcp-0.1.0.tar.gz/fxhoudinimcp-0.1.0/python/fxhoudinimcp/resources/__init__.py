"""MCP resource definitions for FXHoudini-MCP."""

from __future__ import annotations

# Internal
from . import scene_resources  # noqa: F401
from . import geo_resources  # noqa: F401
from . import usd_resources  # noqa: F401
