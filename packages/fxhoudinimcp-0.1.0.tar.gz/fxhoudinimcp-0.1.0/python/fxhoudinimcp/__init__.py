"""FXHoudini-MCP: Comprehensive MCP server for SideFX Houdini."""

__version__ = "0.1.0"
