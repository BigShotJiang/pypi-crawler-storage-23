# :material-book-open-variant:{.scale-in-center} How-to

Guides for using fxhoudinimcp with your AI assistant and Houdini.

- **[Configuration](configuration.md)** — Environment variables, transport modes, and advanced setup
- **[Tools](tools.md)** — Overview of all 167 tools across 19 categories
