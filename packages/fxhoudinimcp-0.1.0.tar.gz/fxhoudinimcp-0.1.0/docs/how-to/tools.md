# :material-wrench:{.scale-in-center} Tools

## Overview

fxhoudinimcp exposes **167 tools** across **19 categories**, covering every major Houdini context.

Once connected, your AI assistant can:

``` text
"Create a procedural rock generator with mountain displacement"
"Set up a Pyro simulation with a sphere source"
"Build a USD scene with a camera, dome light, and ground plane"
"Create an HDA from the selected subnet"
"Debug why my scene has cooking errors"
```

## Categories

### Scene Management (7 tools)

Open, save, import/export, and query scene information.

### Node Operations (16 tools)

Create, delete, copy, connect, layout nodes, and manage flags.

### Parameters (10 tools)

Get/set parameter values, expressions, keyframes, and spare parameters.

### Geometry — SOPs (12 tools)

Read points, primitives, attributes, groups. Perform sampling and nearest-point searches.

### LOPs/USD (18 tools)

Stage inspection, USD prims, layers, composition arcs, variants, and lighting setup.

### DOPs (8 tools)

Query simulation info, DOP objects, step/reset simulations, and check memory usage.

### PDG/TOPs (10 tools)

Cook tasks, inspect work items, manage schedulers and dependency graphs.

### COPs — Copernicus (7 tools)

Image nodes, layers, and VDB data access.

### HDAs (10 tools)

Create, install, and manage Houdini Digital Assets and their sections.

### Animation (9 tools)

Set keyframes, control the playbar, and manage frame ranges.

### Rendering (9 tools)

Viewport capture, render node management, render settings, and launch renders.

### VEX (5 tools)

Create/edit wrangle nodes and validate VEX code.

### Code Execution (4 tools)

Execute Python, HScript, expressions, and manage environment variables.

### Viewport/UI (10 tools)

Pane management, viewport screenshots, and error detection.

### Scene Context (8 tools)

Network overview, cook chains, selection state, scene summaries, and error analysis.

### Workflows (8 tools)

One-call Pyro, RBD, FLIP, and Vellum simulation setup. SOP chains and render configuration.

### Materials (4 tools)

List, inspect, and create materials and shader networks.

### CHOPs (4 tools)

Channel data access, CHOP node management, and channel-to-parameter export.

### Cache (4 tools)

List, inspect, clear, and write file caches.

### Takes (4 tools)

List, create, and switch takes with parameter overrides.
