# :material-download:{.scale-in-center} Installation

--8<-- "README.md:installation"

## Optional Dependencies

### MkDocs Documentation

For building the documentation locally:

``` shell
pip install -e ".[mkdocs]"
```
