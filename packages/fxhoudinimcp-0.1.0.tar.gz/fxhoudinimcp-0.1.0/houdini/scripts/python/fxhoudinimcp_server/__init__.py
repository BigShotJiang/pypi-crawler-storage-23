"""FXHoudini-MCP server plugin for Houdini.

This module runs inside Houdini's Python environment and exposes
hwebserver endpoints that the external MCP server communicates with.
"""
