Weaviate Exceptions
===================

.. automodule:: weaviate.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
