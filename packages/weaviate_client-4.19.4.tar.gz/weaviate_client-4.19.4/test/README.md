Refer to [CONTRIBUTING.md](CONTRIBUTING.md) file for instructions on how to run the tests.
