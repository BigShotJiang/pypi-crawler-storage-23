[ Skip to main content ](https://learn.microsoft.com/en-us/contribute/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/contribute/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/contribute/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/contribute/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/contribute/)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
![](https://learn.microsoft.com/en-us/contribute/media/experts-hub-long-format-400.png)
Microsoft Learn
# Experts Hub
A space for leaders, creators, and problem solvers to get inspiring ideas and resources to share their expertise.
[ Creator inspiration  ](https://learn.microsoft.com/en-us/contribute/#high-demand-topics-that-need-expert-creators)[ Resources for experts  ](https://learn.microsoft.com/en-us/contribute/#further-your-impact-with-guidance-from-trusted-community-experts)[ Expert communities  ](https://learn.microsoft.com/en-us/contribute/#get-involved-in-technical-communities-at-microsoft)
## High-demand topics that need expert creators
Overview of this section
This section highlights high‑interest topics your audience is already searching for and talking about. Think of these as prime opportunities to create content that stands out and attracts learners who are actively looking for guidance.
If a topic aligns with your expertise, jump in and turn it into content that showcases your voice and point of view. You might:
  * Produce a video or write an article
  * Share your perspective in a Q&A thread
  * Spark a conversation on TechCommunity or your preferred forum
  * Host a user group session or live demo


Creating around these topics helps people learn faster and makes your work more discoverable by meeting learners exactly where their curiosity is. It also reinforces your reputation as someone who leads the conversation and brings clarity to complex ideas.
Notable in Q&A
Grow your reputation on Microsoft Q&A by providing expert insights, clarification, and solutions on these trending topics:
  * There's interest in understanding the differences between [Developer Command Prompt and Developer PowerShell in Visual Studio](https://learn.microsoft.com/en-us/answers/questions/5722678/what-are-the-different-between-developer-command-p).
  * Help Azure users [understand error codes](https://learn.microsoft.com/en-us/answers/questions/5562339/error-code-5000225-message-this-tenant-has-been-bl) related to managing [tenant lifecycles in Microsoft Entra](https://learn.microsoft.com/en-us/entra/fundamentals/inaccessible-tenant).
  * Learners want to understand how to use agents created from templates in Copilot Studio, such as the [Customer Insight template agent](https://learn.microsoft.com/en-us/answers/questions/5527396/an-agent-created-through-co-pilot-studio-is-not-ab).


Updates and tools for AI builders in Microsoft Foundry
  * [Claude Opus 4.6 is now in Microsoft Foundry](https://azure.microsoft.com/en-us/blog/claude-opus-4-6-anthropics-powerful-model-for-coding-agents-and-enterprise-workflows-is-now-available-in-microsoft-foundry-on-azure/), enabling advanced reasoning for AI agents acting on business systems.
  * For healthcare and life sciences applications, see [Claude's specialized capabilities with Foundry](https://www.microsoft.com/en-us/industry/blog/healthcare/2026/01/11/bridging-the-gap-between-ai-and-medicine-claude-in-microsoft-foundry-advances-capabilities-for-healthcare-and-life-sciences-customers/).
  * Explore the [catalog of AI models from Foundry](https://ai.azure.com/catalog/models) and documentation on [Foundry Models sold directly by Azure](https://learn.microsoft.com/en-us/azure/ai-foundry/foundry-models/concepts/models-sold-directly-by-azure?view=foundry-classic&tabs=global-standard-aoai,global-standard&pivots=azure-openai). Audiences want to understand how to leverage these models in their AI solutions.
  * Check out a hands-on way to improve security posture and build customer trust in an agentic AI solution with [the AI Red Teaming agent in Microsoft Foundry](https://github.com/microsoft/aitour26-LTG156-safeguard-agentic-ai-solutions-with-ai-red-teaming-agent).


Azure updates for developers
  * Developer audiences are interested in building and remotely hosting MCP servers. [This episode](https://learn.microsoft.com/en-us/shows/azure-friday/host-remote-mcp-servers-on-azure-functions), led by Scott Hanselman and Lily Ma, demonstrates how to remotely host MCP servers on Azure Functions with official MCP SDKs.
  * Explore a [deep dive into the AKS MCP Server & Agentic CLI](https://www.youtube.com/watch?v=tEPfxO1FEMk) in January's AKS community call.
  * As more audiences build AI agents, they're looking to improve cost efficiency on Azure. [This learning path on maximizing AI agent ROI](https://learn.microsoft.com/en-us/training/paths/maximize-cost-efficiency-ai-agents/) offers strategies for cost-conscious decisions, ROI forecasting, and scalable architectures to optimize investments on Azure.


AI for all levels of .NET developers
Help .NET developers across multiple skill levels understand the foundations and opportunities for leveraging AI in their applications.
  * [Hands-on course](https://github.com/microsoft/Generative-AI-for-beginners-dotnet) and [accompanying video series](https://www.youtube.com/playlist?list=PLdo4fOcmZ0oUkPkWy9EtmBvFAjfp4ZHnx) on Generative AI fundamentals with .NET.
  * [Video overview of modernizing .NET apps with GitHub Copilot](https://www.youtube.com/watch?v=-YKguff5GY8).
  * [Workshop for .NET developers](https://github.com/Azure-Samples/modernize-monolith-workshop) looking for hands‑on experience modernizing a legacy .NET Framework monolith using AI‑powered tools and GitHub Copilot agents.


![A GitHub Copilot chat interaction with the Microsoft Learn MCP Server](https://learn.microsoft.com/en-us/contribute/media/learn-server-app-lifecycle-dark.png)
## Content creation resources for the Microsoft Learn MCP Server
A set of ready-to-use assets to help you accurately present, demo, and share the Microsoft Learn MCP Server with your audience.
  * Professional slide deck with speaker notes
  * Graphics for socials, blogs, or other amplification
  * Validated use cases for demos and hands-on learning ideas


[Download the explainer deck](https://aka.ms/LearnMCPServer-expert-explainerdeck) [Download the graphics set and example use cases](https://aka.ms/LearnMCPServer-expert-graphics)
## Further your impact with guidance from trusted community experts
  * [Scale your impact](https://learn.microsoft.com/en-us/collections/xkggupt7qm714q)
Advice for reaching more learners and sharing your expertise with a wider audience.
  * [Help choose our next topic](https://forms.office.com/r/ZdCra8XWkr)
Provide your input on guidance you'd like to see from community experts.


## Level up your Learn contributor journey
Find tools and resources on Learn to bring your expertise to more learners. There are many ways to create, curate, and accelerate your impact with Learn:
  * Edit documentation
  * Create a Collection
  * Create and share AI-generated Plans
  * Respond in Q&A


[Edit documentation & manage Collections](https://learn.microsoft.com/en-us/contribute/content/how-to-write-overview) [Create AI-generated Plans](https://learn.microsoft.com/en-us/training/support/plans)
![A woman holding a laptop.](https://learn.microsoft.com/en-us/contribute/media/learn-contributor-journey.jpg)
## Get involved in technical communities at Microsoft
## Meet featured experts leading the way in their communities
  * ![Konstantinos Passadis](https://learn.microsoft.com/en-us/contribute/media/highlight-decorative-circle.png)
Konstantinos Passadis
Microsoft Azure MVP
"From curiosity to community impact, my path has been shaped by learning, sharing, and building with others. Leadership is the privilege of enabling people to thrive."
[View Konstantinos's profile](https://www.linkedin.com/in/kpassad/)
  * ![Navika Chhauda](https://learn.microsoft.com/en-us/contribute/media/highlight-decorative-circle-1.png)
Navika Chhauda
Microsoft Azure MVP
"I advocate for using tech for a good cause and making technology inclusive and accessible to all. For me, tech leadership means creating deep impact—prioritizing meaningful change and empowering everyone everywhere."
[View Navika's profile](https://www.linkedin.com/in/navikachhauda/)
  * ![Ziggy Zulueta](https://learn.microsoft.com/en-us/contribute/media/highlight-decorative-circle-2.png)
Ziggy Zulueta
AI Platform MVP
"Empowering people through technology isn’t just my job but also my passion. Turning complex tools into strategic business leverage defines my journey as a technical leader."
[View Ziggy's profile](https://www.linkedin.com/in/ziggyzulueta/)


![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_light.jpg?branch=main) ![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_dark.jpg?branch=main)
## Impactful opportunities happening now
  * [Contribute to awesome-azd](https://github.com/azure/awesome-azd)
Share templates for using the Azure Developer CLI (azd) by contributing to the awesome-azd collection.
  * [Participate in Awesome Copilot](https://github.com/github/awesome-copilot)
Instructions, prompts, and configurations to tailor AI responses from GitHub Copilot contributed from community experts like you.
  * [Join the Azure AI Foundry Discord community](https://discord.com/invite/microsoftfoundry)
Join the Azure AI Foundry community to share your knowledge and connect with other AI experts and learners.
  * [Agent Creators](https://adoption.microsoft.com/en-us/ai-agents/agent-creators/)
Connect with Agent Creators, recognized for their passion for sharing knowledge within their communities.


## Expert programs and communities across Microsoft
  * [Microsoft MVP, Student Ambassadors, and Regional Directors program](https://mvp.microsoft.com/)
Join Microsoft's recognized expert programs to connect with peers, share your knowledge, and gain exclusive benefits.
  * [Microsoft Certified Trainer](https://learn.microsoft.com/en-us/credentials/certifications/mct-certification)
Join the Microsoft Certified Trainer program to deliver official Microsoft training courses and help others achieve their certification goals.
  * [DevRel Communities](https://developer.microsoft.com/en-us/community#developer-communities)
Check out Microsoft Developer communities to connect with fellow developers, browse user groups, and explore resources.
  * [TechCommunity](https://techcommunity.microsoft.com/kb/gettingstarted/getting-started-on-the-tech-community/3512627)
Learn how to connect with other experts or add your voice on the various community hubs on TechCommunity.
  * [Microsoft Learn Q&A](https://learn.microsoft.com/en-us/answers)
Answer questions on Microsoft Q&A from developers and technology users around the world.
  * [Learning Rooms](https://learn.microsoft.com/en-us/training/learn-community)
Explore learning rooms led by Learn Experts to share knowledge and collaborate on Microsoft technologies.
  * [Microsoft 365 and Power Platform Community](https://pnp.github.io/)
Join the Microsoft 365 and Power Platform Community to connect with experts, share your knowledge, and collaborate on solutions.
  * [Microsoft 365 Champion](https://adoption.microsoft.com/become-a-champion/)
Become a trusted peer who helps others learn and use Microsoft 365 effectively.


## Frequently asked questions
What is the Experts Hub?
A public home on Microsoft Learn where technical experts can discover high‑value ways to share, contribute, access creator resources, get involved in opportunities across Microsoft, and have the opportunity to be recognized for their impact.
What's the difference between the Experts Hub and Learn Experts (Learning Rooms)?
Experts Hub is an open destination on Learn for all contributors; “Learn Experts” are invited community leaders who support learners by facilitating [Learning Rooms](https://techcommunity.microsoft.com/discussions/skills-hub-discussions/meet-the-microsoft-learn-experts/3782298). One is a place, the other is a role.
Who can become an expert?
Anyone with a passion for sharing knowledge about Microsoft technologies! Whether you're a developer, IT pro, data scientist, or student, your expertise is valuable to the community.
What accounts do experts need?
We recommend having a Microsoft Learn account and a GitHub account. A Microsoft Learn account allows you to contribute to Q&A and create Collections, while a GitHub account allows you to edit documentation or file an issue about open-source product documentation.
Do I need to be a Microsoft MVP to be an expert?
You don't need any special credentials or experience to contribute, just a desire to share your expertise or participate in the community.
What's in it for me?
As a technical expert on Microsoft Learn, you can gain visibility through attribution and spotlights, access curated opportunities to help you make an impact, and earn digital recognition.
## Connect with us
[ Twitter ](https://twitter.com/MicrosoftLearn "Twitter") [ LinkedIn ](https://www.linkedin.com/showcase/microsoftlearn/ "LinkedIn") [ Website ](https://www.tiktok.com/@microsoftlearn "Website") [ Website ](https://aka.ms/MicrosoftLearnNewsletter "Website")
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fcontribute%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
