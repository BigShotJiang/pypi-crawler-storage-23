[ Skip to main content ](https://learn.microsoft.com/en-us/copilot/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/copilot/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/copilot/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/copilot/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/copilot/)
[ Microsoft Copilot  ](https://learn.microsoft.com/en-us/copilot/)
  * Experiences
    * Microsoft 365 Copilot Chat
      * [ Overview ](https://learn.microsoft.com/en-us/copilot/overview/)
      * [ Privacy & protections ](https://learn.microsoft.com/en-us/copilot/privacy-and-protections/)
      * [ Manage access ](https://learn.microsoft.com/en-us/copilot/manage/)
      * [ FAQ ](https://learn.microsoft.com/en-us/copilot/faq/)
      * [ Glossary ](https://learn.microsoft.com/en-us/copilot/glossary)
    * [ Microsoft 365 Copilot ](https://learn.microsoft.com/en-us/copilot/microsoft-365/)
    * [ Microsoft 365 Copilot for Finance ](https://learn.microsoft.com/en-us/copilot/finance/)
    * [ Microsoft 365 Copilot for Sales ](https://learn.microsoft.com/en-us/microsoft-sales-copilot/)
    * [ Microsoft 365 Copilot for Service ](https://learn.microsoft.com/en-us/microsoft-copilot-service/)
    * [ Copilots and generative AI in Dynamics 365 ](https://learn.microsoft.com/en-us/dynamics365/copilot/)
    * [ Copilots and generative AI in Industry Solutions ](https://learn.microsoft.com/en-us/industry/copilot/)
    * [ Copilots and generative AI in Power Platform ](https://learn.microsoft.com/en-us/power-platform/copilot/)
    * [ Microsoft Security Copilot ](https://learn.microsoft.com/en-us/copilot/security/)
    * [ Copilot in Azure (Preview) ](https://learn.microsoft.com/en-us/azure/copilot/)
    * [ Azure AI Foundry ](https://learn.microsoft.com/en-us/azure/ai-studio/)
    * [ GitHub Copilot ](https://docs.github.com/copilot)
  * Enhance and build
    * [ Plugins for Security Copilot ](https://learn.microsoft.com/en-us/copilot/security/plugin-overview)
    * [ Adopt, extend and build Copilot experiences ](https://learn.microsoft.com/en-us/copilot/roadmap/overview)
    * [ Microsoft 365 Copilot extensibility ](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/)
    * [ Microsoft Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
  * [ Shows ](https://learn.microsoft.com/en-us/shows/copilot-learning-hub/)
  * Resources
    * [ Copilot Q&A ](https://learn.microsoft.com/en-us/search/?terms=copilot&category=QnA)
    * [ Copilot training ](https://learn.microsoft.com/en-us/training/browse/?terms=copilot)
    * [ Copilot Prompt Gallery ](https://copilot.cloud.microsoft/prompts)
    * [ Microsoft 365 Copilot adoption ](https://adoption.microsoft.com/copilot/)
    * [ AI agents hub ](https://aka.ms/BuildAgents)
    * [ Copilot FAQ ](https://learn.microsoft.com/en-us/copilot/faq)
  * More
    * Experiences
      * Microsoft 365 Copilot Chat
        * [ Overview ](https://learn.microsoft.com/en-us/copilot/overview/)
        * [ Privacy & protections ](https://learn.microsoft.com/en-us/copilot/privacy-and-protections/)
        * [ Manage access ](https://learn.microsoft.com/en-us/copilot/manage/)
        * [ FAQ ](https://learn.microsoft.com/en-us/copilot/faq/)
        * [ Glossary ](https://learn.microsoft.com/en-us/copilot/glossary)
      * [ Microsoft 365 Copilot ](https://learn.microsoft.com/en-us/copilot/microsoft-365/)
      * [ Microsoft 365 Copilot for Finance ](https://learn.microsoft.com/en-us/copilot/finance/)
      * [ Microsoft 365 Copilot for Sales ](https://learn.microsoft.com/en-us/microsoft-sales-copilot/)
      * [ Microsoft 365 Copilot for Service ](https://learn.microsoft.com/en-us/microsoft-copilot-service/)
      * [ Copilots and generative AI in Dynamics 365 ](https://learn.microsoft.com/en-us/dynamics365/copilot/)
      * [ Copilots and generative AI in Industry Solutions ](https://learn.microsoft.com/en-us/industry/copilot/)
      * [ Copilots and generative AI in Power Platform ](https://learn.microsoft.com/en-us/power-platform/copilot/)
      * [ Microsoft Security Copilot ](https://learn.microsoft.com/en-us/copilot/security/)
      * [ Copilot in Azure (Preview) ](https://learn.microsoft.com/en-us/azure/copilot/)
      * [ Azure AI Foundry ](https://learn.microsoft.com/en-us/azure/ai-studio/)
      * [ GitHub Copilot ](https://docs.github.com/copilot)
    * Enhance and build
      * [ Plugins for Security Copilot ](https://learn.microsoft.com/en-us/copilot/security/plugin-overview)
      * [ Adopt, extend and build Copilot experiences ](https://learn.microsoft.com/en-us/copilot/roadmap/overview)
      * [ Microsoft 365 Copilot extensibility ](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/)
      * [ Microsoft Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
    * [ Shows ](https://learn.microsoft.com/en-us/shows/copilot-learning-hub/)
    * Resources
      * [ Copilot Q&A ](https://learn.microsoft.com/en-us/search/?terms=copilot&category=QnA)
      * [ Copilot training ](https://learn.microsoft.com/en-us/training/browse/?terms=copilot)
      * [ Copilot Prompt Gallery ](https://copilot.cloud.microsoft/prompts)
      * [ Microsoft 365 Copilot adoption ](https://adoption.microsoft.com/copilot/)
      * [ AI agents hub ](https://aka.ms/BuildAgents)
      * [ Copilot FAQ ](https://learn.microsoft.com/en-us/copilot/faq)


[ Get Microsoft Copilot ](https://www.microsoft.com/microsoft-copilot) [ Open Microsoft 365 Copilot ](https://copilot.cloud.microsoft)
Microsoft Learn
# Microsoft Copilot learning hub for IT Pros and Developers
Explore our learning hub designed for IT professionals and developers. Our hub provides in-depth Microsoft Copilot information, helping you understand which Copilot is right for your needs. Access technical documentation, product references, and training modules to enhance your skills and knowledge. Discover how to streamline your workflows, improve productivity, and bring AI-driven solutions to your organization. Start your journey today and unlock the full potential of AI in your work.
## Explore libraries and training
Discover how Copilot is integrated within Microsoft products designed to enhance your productivity and streamline your workflows. Access the Copilot hub sites for technical information, product reference, and guidance. See filtered lists of training to gain the skills and knowledge you need to leverage these powerful tools effectively.
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-microsoft-365.png)
Microsoft 365 Copilot
Learn about Microsoft 365 Copilot and how your organization can use this for work.
[Microsoft 365 Copilot documentation](https://learn.microsoft.com/en-us/copilot/microsoft-365/) [Microsoft 365 Copilot training](https://learn.microsoft.com/en-us/collections/6wpf7tdggkn5g)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-dynamics-365.png)
Copilot experiences in Dynamics 365
Find Copilot and generative AI guidance for Dynamics 365 apps.
[Copilot in Dynamics 365 documentation](https://learn.microsoft.com/en-us/dynamics365/copilot/) [Copilot in Dynamics 365 training](https://learn.microsoft.com/en-us/training/paths/use-copilot-sales/)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-power-platform.png)
Copilot experiences in Power Platform
Get an overview of Copilot and generative AI uses in Power Platform.
[Copilot in Power Platform documentation](https://learn.microsoft.com/en-us/power-platform/copilot/) [Copilot in Power Platform training](https://learn.microsoft.com/en-us/training/paths/copilot-power-platform/)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-studio.png)
Microsoft Copilot Studio
Explore how to build AI-driven solutions with Microsoft Copilot Studio.
[Copilot Studio documentation](https://learn.microsoft.com/en-us/microsoft-copilot-studio/) [Copilot Studio training](https://learn.microsoft.com/en-us/training/paths/work-power-virtual-agents/)


  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-microsoft-security.png)
Microsoft Security Copilot
Use Security Copilot to bring the full power of OpenAI architecture to defend your organization at machine speed and scale.
[Microsoft Security Copilot documentation](https://learn.microsoft.com/en-us/copilot/security/) [Microsoft Security Copilot training](https://learn.microsoft.com/en-us/training/paths/security-copilot-and-ai/)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-microsoft-fabric.png)
Copilot in Microsoft Fabric
Discover how Copilot in Microsoft Fabric and Power BI transforms data analysis, generates insights, and creates visualizations.
[Copilot in Microsoft Fabric documentation](https://learn.microsoft.com/en-us/fabric/fundamentals/copilot-fabric-overview) [Copilot in Microsoft Fabric training](https://learn.microsoft.com/en-us/training/paths/work-smarter-with-copilot-in-microsoft-fabric/)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-azure.png)
Copilot in Azure
Manage operations from cloud to edge with an AI assistant and learn to be more effective in your work.
[Copilot in Azure documentation](https://learn.microsoft.com/en-us/azure/copilot/) [Copilot in Azure training](https://learn.microsoft.com/en-us/training/paths/build-ai-copilot-vcore-based-azure-cosmos-db-mongodb-azure-openai/)
  * ![](https://learn.microsoft.com/en-us/copilot/media/copilot/copilot-learning-hub/copilot-in-github.png)
GitHub Copilot
Gain proficiency with GitHub Copilot to revolutionize your coding experience.
[GitHub Copilot documentation](https://docs.github.com/copilot/) [GitHub Copilot training](https://learn.microsoft.com/en-us/collections/w0giztqwz4mpn)


## More resources
Curious about which Copilot to use and how to get started? Access the resources to understand Copilot use cases, the fundamentals, how to deploy, and how to extend in your own environments as a technical professional.
  * [Discover more about Copilot](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
Training to get started and deepen your understanding of Microsoft Copilot and Microsoft Foundry for developers and Microsoft Copilot in Azure.
  * [Microsoft Copilot adoption in your organization](https://adoption.microsoft.com/copilot)
Explore adoption resources to help you deploy and drive user adoption of Microsoft Copilot and agents.
  * [Copilot learning hub video series](https://learn.microsoft.com/en-us/shows/copilot-learning-hub/)
Watch videos to learn about Copilot and agents capabilities, deployment, and extensibility.
  * [Microsoft Security for AI](https://learn.microsoft.com/en-us/security/security-for-ai/)
Explore documentation for securing, protecting, and governing your AI apps and data.
  * [FastTrack your Copilot deployment](https://learn.microsoft.com/en-us/fasttrack)
Get personalized assistance from Microsoft experts to help you deploy Copilot in your organization.
  * [Build an Agent in a day](https://aka.ms/nextAgIAD)
Join a hands-on, instructor-led workshop to learn how to build agents with Copilot Studio.
  * [Copilot Studio Agent Academy](https://microsoft.github.io/agent-academy/)
Join this hands-on training and learn to build, scale, and deploy intelligent agents using real-world tools and use cases.
  * [AI in Action video series](https://www.youtube.com/playlist?list=PLi9EhCY4z99UQhlhVAryGX4NSPIYTSiMo)
Check out the Powering Up with Power Automate series where each video shares different AI experiences with Power Automate to enhance the way you work.


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fcopilot%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
