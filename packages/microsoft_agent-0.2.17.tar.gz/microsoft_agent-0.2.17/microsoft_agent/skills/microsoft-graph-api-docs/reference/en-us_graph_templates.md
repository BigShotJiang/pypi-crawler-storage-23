[ Skip to main content ](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#main)
AI Apps & Agents Dev Days: Experiment with what's next in AI-driven apps and agent design [ Register now ](https://aka.ms/AIAppsandAgentsLearn) Dismiss alert
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
# IaC templates for Microsoft Graph resources documentation
Define Microsoft Graph resources with Bicep and Terraform templates, and deploy them in Infrastructure as Code (IaC) environments.
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-overview.svg?branch=main)
Overview
[Get started with Infrastructure as Code (IaC)](https://learn.microsoft.com/en-us/azure/developer/iac/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-concept.svg?branch=main)
Concept
[Compare Bicep and Terraform](https://learn.microsoft.com/en-us/azure/developer/terraform/comparing-terraform-and-bicep)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-overview.svg?branch=main)
Overview
[Bicep templates for Microsoft Graph](https://learn.microsoft.com/en-us/graph/templates/bicep/overview-bicep-templates-for-graph)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-overview.svg?branch=main)
Overview
[Terraform templates for Microsoft Graph](https://learn.microsoft.com/en-us/graph/templates/terraform/overview-terraform-for-graph)
### Deploy with Bicep
  * [Deploy in interactive scenarios](https://learn.microsoft.com/en-us/graph/templates/bicep/quickstart-create-bicep-interactive-mode)
  * [Deploy in app-only scenarios](https://learn.microsoft.com/en-us/graph/templates/bicep/quickstart-create-bicep-zero-touch-mode)


### Deploy with Terraform
  * [Get started](https://learn.microsoft.com/en-us/graph/templates/terraform/quickstart-create-terraform)


### Microsoft Graph on Bicep reference
  * [v1.0 reference](https://learn.microsoft.com/en-us/graph/templates/bicep/reference/overview?view=graph-bicep-1.0)
  * [beta reference](https://learn.microsoft.com/en-us/graph/templates/bicep/reference/overview?view=graph-bicep-beta)


### Microsoft Graph on Terraform reference
  * [v1.0 reference](https://learn.microsoft.com/en-us/graph/templates/terraform/reference/v1.0/overview)
  * [beta reference](https://learn.microsoft.com/en-us/graph/templates/terraform/reference/beta/overview)


[](https://learn.microsoft.com/en-us/graph/templates/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#other-resources)
## Other resources
### Training: IaC using Bicep
  * [ Introduction to infrastructure as code using Bicep ](https://learn.microsoft.com/en-us/training/modules/introduction-to-infrastructure-as-code-using-bicep/)


### Training: IaC using Terraform
  * [ Introduction to infrastructure as code using Terraform ](https://learn.microsoft.com/en-us/training/modules/terraform-introduction-to-infrastructure-as-code/)


### Help and Support
Get help and support for Microsoft Graph types and templates.
  * [ Bicep templates for Microsoft Graph ](https://github.com/microsoftgraph/msgraph-bicep-types/issues)
  * [ Terraform templates for Microsoft Graph ](https://github.com/Microsoft/terraform-provider-msgraph/issues)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Ftemplates%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
