[ Skip to main content ](https://learn.microsoft.com/en-us/credentials/#main)
Join the AI Challenge: Sharpen your skills, earn credentials, and win 50% off a Microsoft AI Certification. [ Lets go! ](https://aka.ms/CredentialsAIChallenge_Learn) Dismiss alert
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/credentials/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/credentials/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/credentials/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/credentials/)
[ Credentials  ](https://learn.microsoft.com/en-us/credentials/)
  * [ Browse Credentials ](https://learn.microsoft.com/en-us/credentials/browse)
  * [ Certification Renewals ](https://learn.microsoft.com/en-us/certifications/renew-your-microsoft-certification)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/certifications/help/)
  * More
    * [ Browse Credentials ](https://learn.microsoft.com/en-us/credentials/browse)
    * [ Certification Renewals ](https://learn.microsoft.com/en-us/certifications/renew-your-microsoft-certification)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/certifications/help/)


MICROSOFT LEARN
# Microsoft Credentials
Showcase your real-world expertise with Microsoft Credentials.
From role-based Certifications to scenario-based Applied Skills, now available for technical and business professionals, Microsoft-verified credentials help you grow your AI career and help teams stay ready for what’s next.
[Browse credentials](https://learn.microsoft.com/en-us/credentials/browse)
## Microsoft Certifications
Demonstrate skills and expertise across AI, cloud, security, and business roles.
  * Comprehensive: Earned by passing an exam that reflects key job responsibilities and tasks.
  * Progressive: Supports all stages of career from Fundamentals to Associate, Expert, and Specialty.
  * Renewable: Renew eligible Certifications annually at no cost by completing a short online assessment.
  * Shareable: Showcase your globally-recognized Certification on social platforms like LinkedIn.


[Browse Certifications](https://learn.microsoft.com/en-us/credentials/browse/?credential_types=certification) [View poster](https://aka.ms/CertificationsPoster)
![Microsoft Certifications Poster](https://learn.microsoft.com/en-us/credentials/images/certifications-poster.png)
![Applied Skills Poster](https://learn.microsoft.com/en-us/credentials/images/appliedskills-poster.png)
## Microsoft Applied Skills
Demonstrate your ability to use Microsoft technologies in real-world AI and cloud scenarios.
  * Practical: Earned by completing a series of tasks through an interactive, lab-based assessment
  * Flexible: Short, skill-specific, and available on demand.
  * Aligned: Maps to role-based Certifications; includes beginner and intermediate levels.
  * Shareable: Share your credential on social platforms like LinkedIn to highlight your skills.


[Learn more](https://learn.microsoft.com/en-us/credentials/applied-skills/) [View poster](https://go.microsoft.com/fwlink/?linkid=2321752)
## Choose the path that fits your goals
Two credential types, one outcome: Job-ready skills. Globally recognized and validated by Microsoft. To get started, choose a credential, prepare with training, earn by passing an exam (Certifications) or a lab-based assessment (Applied Skills), then celebrate by sharing your credential on social platforms like LinkedIn.
[Watch the video](https://learn-video.azurefd.net/vod/player?id=9789da66-1466-4a87-98c7-ecd9d49d5cc7)
![](https://learn.microsoft.com/en-us/credentials/images/new-business-credentials.png)
## New! Credentials for business professionals
As AI reshapes roles, Microsoft Credentials keep pace. Earn new business-focused credentials that help you lead with AI, make better decisions, and enhance daily work.
[Discover more](https://learn.microsoft.com/en-us/credentials/browse/?credential_types=)
## Why earn a Microsoft Credential?
  * 70%
of organizations believe industry-recognized credentials are essential or very important tools for skills training.
[IDC Infobrief, Published June 2024 *](https://aka.ms/AppliedSkillsIDCInfobrief)
  * 63%
of professionals received or expected a job promotion after earning a certification.
[Pearson VUE, 2025 Value of IT Certification Candidate Report](https://go.pearsonvue.com/voc)
  * 76%
of employees show increased ability to innovate and enhance processes after earning a certification.
[Pearson VUE, 2025 Value of IT Certification Candidate Report](https://go.pearsonvue.com/voc)


_*IDC InfoBrief, Sponsored by Microsoft, Skilling Up! Leveraging Full and Micro-Credentials for Optimal Skilling Solutions, Doc. #US52019124, June, 2024._
## Resources for every stage of learning
  * ![](https://learn.microsoft.com/en-us/credentials/images/discover.png)
Discover
Learn about the wide range of Microsoft credentials available to validate and showcase your proficiency.
[Browse credentials](https://learn.microsoft.com/en-us/credentials/browse/)
  * ![](https://learn.microsoft.com/en-us/credentials/images/train.png)
Train
Gain technical skills that you can apply to everyday situations through personalized learning experiences.
[Learn about training](https://learn.microsoft.com/en-us/training/)
  * ![](https://learn.microsoft.com/en-us/credentials/images/practice.png)
Practice
Use carefully curated, guided videos, and practice assessments to prepare and get ready for certification exams.
[Explore practice assessments](https://learn.microsoft.com/en-us/credentials/certifications/practice-assessments-for-microsoft-certifications)
  * ![](https://learn.microsoft.com/en-us/credentials/images/showcase.png)
Earn
Demonstrate your expertise with a Microsoft Certification or Microsoft Applied Skills credential.
[Learn about credentials](https://learn.microsoft.com/en-us/credentials/browse/)
  * ![](https://learn.microsoft.com/en-us/credentials/images/share.png)
Share
Celebrate your credentials by sharing on social platforms like LinkedIn and with organizations, colleagues, hiring managers, and recruiters.
  * ![](https://learn.microsoft.com/en-us/credentials/images/renew.png)
Renew
Keep your certifications—and your skills—up to date at no cost, so you’re always right for the job.
[Renew your certification](https://learn.microsoft.com/en-us/credentials/certifications/renew-your-microsoft-certification)


## How credentials make a difference
  * ![Özgür Orhan](https://learn.microsoft.com/en-us/credentials/images/ozg%C3%BCr-orhan.jpg)
Özgür Orhan
IT Security & Infrastructure Services Group Manager, Koç Holding
"With Microsoft Applied Skills, our learners working on current and future strategic digital transformation projects will be able to grasp knowledge and validate their skills in a shorter period of time."
[Learn more](https://aka.ms/AppliedSkills_Koc)
  * ![Alisa Chernysh](https://learn.microsoft.com/en-us/credentials/images/a-chernysh.png)
Alisa Chernysh
Senior Alliance Director, EPAM
"One of the ways we differentiate ourselves for clients is by making it real. With Applied Skills, we can move beyond academic knowledge to demonstrate proficiency and client impact. That gives us a competitive advantage."
[Learn more](https://www.microsoft.com/en/customers/story/25354-epam-systems-fejleszto-kft-microsoft-fabric)


![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_light.jpg?branch=main) ![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_dark.jpg?branch=main)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fcredentials%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
