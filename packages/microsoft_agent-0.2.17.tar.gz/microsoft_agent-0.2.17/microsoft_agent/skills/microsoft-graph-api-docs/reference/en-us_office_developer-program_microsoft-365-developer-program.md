[ Skip to main content ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
[ Office Add-ins  ](https://learn.microsoft.com/en-us/office/dev/add-ins/)
  * Guides
    * [ Beginners ](https://learn.microsoft.com/en-us/office/dev/add-ins/overview/learning-path-beginner)
    * [ Transition from VSTO ](https://learn.microsoft.com/en-us/office/dev/add-ins/overview/learning-path-transition)
  * Office applications
    * [ Excel ](https://learn.microsoft.com/en-us/office/dev/add-ins/excel)
    * [ OneNote ](https://learn.microsoft.com/en-us/office/dev/add-ins/onenote)
    * [ Outlook ](https://learn.microsoft.com/en-us/office/dev/add-ins/outlook)
    * [ PowerPoint ](https://learn.microsoft.com/en-us/office/dev/add-ins/powerpoint)
    * [ Project ](https://learn.microsoft.com/en-us/office/dev/add-ins/project)
    * [ Visio ](https://learn.microsoft.com/en-us/office/dev/add-ins/visio)
    * [ Word ](https://learn.microsoft.com/en-us/office/dev/add-ins/word)
  * Resources
    * [ Office Dev Center ](https://developer.microsoft.com/office)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/office-add-ins/)
    * [ Samples ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Samples,Office%20Add-ins)
    * [ Tools ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Tools,Office%20Add-ins)
    * [ Videos ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Videos,Podcasts,Office%20Add-ins)
    * [ Community Calls ](https://aka.ms/M365DevCalls)
    * [ Developer Program ](https://aka.ms/m365devprogram)
    * [ Support ](https://developer.microsoft.com/office#officecommunity)
    * [ All Resources ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Office)
  * More
    * Guides
      * [ Beginners ](https://learn.microsoft.com/en-us/office/dev/add-ins/overview/learning-path-beginner)
      * [ Transition from VSTO ](https://learn.microsoft.com/en-us/office/dev/add-ins/overview/learning-path-transition)
    * Office applications
      * [ Excel ](https://learn.microsoft.com/en-us/office/dev/add-ins/excel)
      * [ OneNote ](https://learn.microsoft.com/en-us/office/dev/add-ins/onenote)
      * [ Outlook ](https://learn.microsoft.com/en-us/office/dev/add-ins/outlook)
      * [ PowerPoint ](https://learn.microsoft.com/en-us/office/dev/add-ins/powerpoint)
      * [ Project ](https://learn.microsoft.com/en-us/office/dev/add-ins/project)
      * [ Visio ](https://learn.microsoft.com/en-us/office/dev/add-ins/visio)
      * [ Word ](https://learn.microsoft.com/en-us/office/dev/add-ins/word)
    * Resources
      * [ Office Dev Center ](https://developer.microsoft.com/office)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/office-add-ins/)
      * [ Samples ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Samples,Office%20Add-ins)
      * [ Tools ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Tools,Office%20Add-ins)
      * [ Videos ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Videos,Podcasts,Office%20Add-ins)
      * [ Community Calls ](https://aka.ms/M365DevCalls)
      * [ Developer Program ](https://aka.ms/m365devprogram)
      * [ Support ](https://developer.microsoft.com/office#officecommunity)
      * [ All Resources ](https://developer.microsoft.com/microsoft-365/gallery/?filterBy=Office)


[ Free account ](https://aka.ms/m365devprogram)
Search
Suggestions will filter as you type
  * [Microsoft 365 Developer Program](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
  * [Set up a developer subscription](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-get-started)
  * [Join as a Visual Studio subscriber](https://learn.microsoft.com/en-us/office/developer-program/join-with-visual-studio)
  * [Purchase Copilot licenses](https://learn.microsoft.com/en-us/office/developer-program/purchase-copilot-licenses)
  * [Build solutions](https://learn.microsoft.com/en-us/office/developer-program/build-microsoft-365-solutions)
  * [Use sample data packs](https://learn.microsoft.com/en-us/office/developer-program/install-sample-packs)
  * [Developer Program FAQ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * [Terms and conditions](https://learn.microsoft.com/en-us/office/developer-program/terms-and-conditions)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Microsoft 365 ](https://learn.microsoft.com/en-us/microsoft-365/)
  3. [ Developer Program ](https://learn.microsoft.com/en-us/office/developer-program)


  1. [Learn](https://learn.microsoft.com/en-us/)
  2. [Microsoft 365](https://learn.microsoft.com/en-us/microsoft-365/)
  3. [Developer Program](https://learn.microsoft.com/en-us/office/developer-program)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program) Add to Collections Add to plan [ Edit ](https://github.com/OfficeDev/office-dev-program-docs/blob/main/docs/microsoft-365-developer-program.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Foffice%2Fdeveloper-program%2Fmicrosoft-365-developer-program%3FWT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Foffice%2Fdeveloper-program%2Fmicrosoft-365-developer-program%3FWT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Foffice%2Fdeveloper-program%2Fmicrosoft-365-developer-program%3FWT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Foffice%2Fdeveloper-program%2Fmicrosoft-365-developer-program%3FWT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Welcome to the Microsoft 365 Developer Program
Feedback
Summarize this article for me
##  In this article
  1. [Microsoft 365 Developer Program eligibility overview](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#microsoft-365-developer-program-eligibility-overview)
  2. [Join the Microsoft 365 Developer Program](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#join-the-microsoft-365-developer-program)
  3. [Related content](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#related-content)


The Microsoft 365 Developer Program includes a Microsoft 365 E5 developer subscription that you can use to create your own sandbox and develop solutions independent of your production environment. You can build Microsoft Teams apps, Office Add-ins for Word, Excel, PowerPoint, or Outlook, or SharePoint Add-ins, using Microsoft Graph, the SharePoint Framework, Power Apps, and more. You also get access to [Microsoft Intune](https://learn.microsoft.com/en-us/mem/intune/fundamentals/what-is-intune).
Do you have a Visual Studio Pro or Enterprise subscription? If so, you can take advantage of additional benefits when you join the program; for details, see [Join with Visual Studio](https://learn.microsoft.com/en-us/office/developer-program/join-with-visual-studio).
[](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#microsoft-365-developer-program-eligibility-overview)
## Microsoft 365 Developer Program eligibility overview
Use the following quick reference to see if you are eligible.
Expand table
**Category** | **Qualification** | **How to join** | **See also**
---|---|---|---
Visual Studio Subscribers | Visual Studio Professional or Enterprise subscription holders automatically qualify. | Sign up via Visual Studio portal. | [Join now](https://learn.microsoft.com/en-us/office/developer-program/join-with-visual-studio)
ISV Success Program Members | Companies enrolled in ISV Success Program or eligible MAICPP tiers can request a Microsoft 365 E5 developer subscription. | Once you sign up for the developer program with your corporate email, you'll see an option to request a M365 E5 Developer subscription. |  [- Learn more about the ISV Success Program](https://learn.microsoft.com/en-us/partner-center/membership/isv-success)

[- Learn more about the MAICPP](https://www.microsoft.com/americas-partner-one/maicpp?msockid=111adc8963d469eb14c7c9c562866859)
Microsoft AI Cloud Partner Program Participants | Eligible MAICPP partner levels include:

  * Azure Expert Managed Service Providers (MSP)
  * Solutions Partners
  * Specialization Partners
  * Managed Partners
  * Microsoft Action Pack Subscribers
  * Partner Success Core Benefits Recipients
  * Partner Success Expanded Benefits Recipients
  * Partner Launch Benefits Recipients
  * Legacy Gold/Silver Partners

| Sign in with your corporate email and the eligibility option will appear. | [Learn more about partner types](https://learn.microsoft.com/en-us/partner-center/membership/mpn-overview#services-partner)
Premier or Unified Support Plan Members | Companies with a Premier or Unified Support contract are eligible. | To request a subscription, after registering for the developer program, reach out to your Microsoft partner contact to request a Microsoft 365 E5 Developer subscription using the same email address you signed up with.

  * Customer Success Account Manager (CSAM) (for Premier or Unified Support customers)
  * Partner Development Manager (PDM) (for Managed Partners)
  * Customer Support Engineer (for ISV Partners)

| N/A
Government clouds | The Microsoft 365 Developer Program is not offered in Microsoft's government clouds such as Microsoft 365 Government (GCC, GCC High, or DoD). | Government cloud environments are designed to meet specific regulatory and compliance requirements, and some programs or features available in the commercial cloud are not supported there. | N/A
[](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#join-the-microsoft-365-developer-program)
## Join the Microsoft 365 Developer Program
If you're a paid Visual Studio subscriber, we recommend that you join the program by activating the benefit through the Visual Studio membership portal. For details, see [Join with Visual Studio](https://learn.microsoft.com/en-us/office/developer-program/join-with-visual-studio).
  1. Go to the [Join the Microsoft 365 Developer Program](https://developer.microsoft.com/microsoft-365/dev-program) page.
  2. In the upper-right corner, choose **Sign in** to sign in with your Microsoft account or Microsoft Entra-enabled email.
The following sign-in options are not supported:
     * Phone numbers.
     * Email accounts with the ***.onmicrosoft.com** domain.
If you're signed in with one of these options, you'll get an error message and will need to sign in with a supported email account. For more information, see [What account can I use to sign up for the Developer Program?](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq?source=docs#what-account-can-i-use-to-sign-up-for-the-microsoft-365-developer-program-)
Remember the email account that you sign in with. You'll sign in to the [Developer Program dashboard](https://developer.microsoft.com/microsoft-365/profile) with this account. This account is different than the admin ID that you'll use for your Microsoft 365 developer subscription.
  3. After signing in, choose **Join now**.
  4. On the **Microsoft 365 Developer Program Signup** page, complete the following fields in the online form:
     * Contact Email
     * Country/Region
     * Company
  5. Review the **terms and conditions**. You'll need to select the check box before you can join.
  6. Optionally, select the **I would like to hear from the Microsoft 365 Developer Program** check box if you want to hear from Microsoft about new capabilities and other updates.
  7. Choose **Next**.
  8. On the **Microsoft 365 Developer Program Preferences** page, let us know your preferences so we can personalize your experience, including:
     * The industry that you work in.
     * The type of applications or solutions that you're interested in developing.
     * Products, technologies, and programming languages that you're interested in.
  9. When you're finished, choose **Join**. Your preferences appear on the next page in the top right, and you will see a Welcome message and will receive a welcome email.


[](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#related-content)
## Related content
  * For frequently asked questions about the Microsoft 365 Developer Program, see the [FAQ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq).
  * [Extend Teams apps across Microsoft 365](https://learn.microsoft.com/en-us/microsoftteams/platform/m365-apps/overview).


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ Terms and conditions ](https://learn.microsoft.com/en-us/office/developer-program/terms-and-conditions?source=recommendations)
Learn about the Microsoft 365 Developer Program terms and conditions.
  * [ Set up a Microsoft 365 developer sandbox subscription ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-get-started?source=recommendations)
Set up a Microsoft 365 developer subscription for building solutions independent of your production environment.
  * [ Use sample data packs with your Microsoft 365 Developer Program subscription ](https://learn.microsoft.com/en-us/office/developer-program/install-sample-packs?source=recommendations)
Learn how to install sample data packs on your developer subscription to help get your sandbox environment up and running quickly.
  * [ Join the Microsoft 365 Developer Program with a Visual Studio Professional or Enterprise subscription ](https://learn.microsoft.com/en-us/office/developer-program/join-with-visual-studio?source=recommendations)
All new members of the Microsoft 365 Developer Program (including Visual Studio Professional and Enterprise subscribers) can sign up for a Microsoft 365 E5 developer subscription (Windows not included).
  * [ Use your developer subscription to build Microsoft 365 solutions ](https://learn.microsoft.com/en-us/office/developer-program/build-microsoft-365-solutions?source=recommendations)
Use your Microsoft 365 developer subscription to build the solutions you want.


Show 2 more
Certification
[ Microsoft Certified: Power Platform Developer Associate - Certifications ](https://learn.microsoft.com/en-us/credentials/certifications/power-platform-developer-associate/?source=recommendations)
Demonstrate how to simplify, automate, and transform business tasks and processes using Microsoft Power Platform Developer.
* * *
  * Last updated on 10/07/2025


##  In this article
  1. [Microsoft 365 Developer Program eligibility overview](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#microsoft-365-developer-program-eligibility-overview)
  2. [Join the Microsoft 365 Developer Program](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#join-the-microsoft-365-developer-program)
  3. [Related content](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program#related-content)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Foffice%2Fdeveloper-program%2Fmicrosoft-365-developer-program)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
