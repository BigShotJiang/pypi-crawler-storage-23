[ Skip to main content ](https://learn.microsoft.com/en-us/answers/tags/133/azure#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/133/azure)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/?id=aHR0cHM6Ly9hdXRob3JpbmctZG9jcy1taWNyb3NvZnQucG9vbHBhcnR5LmJpei9kZXZyZWwvMjQxYTUyMzktZmUyYi00NzE1LTk3N2UtMTM5OGM0ODdhMzJj&styleGuideLabel=Azure)
![](https://learn.microsoft.com/en-us/media/logos/logo_azure.svg)
Microsoft Q&A
#  Azure
137,946 questions
A cloud computing platform and infrastructure for building, deploying and managing applications and services through a worldwide network of Microsoft-managed datacenters.
Sign in to follow  Follow
Filters
## Filter
* * *
### Content
[ All questions 137.9K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=null) [ No answers 17.2K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=unanswered) [ Has answers 120.7K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=answered) [ No answers or comments 1.1K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withoutengagement) [ With accepted answer 43.2K  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withacceptedanswer) [ With recommended answer 88  ](https://learn.microsoft.com/en-us/answers/tags/133/azure?filterby=withrecommendedanswer)
##  137,946 questions with Azure-related tags
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/tags/133/azure?orderby=answercount&page=1)
1 answer
##  [ How can I use Azue for students ](https://learn.microsoft.com/en-us/answers/questions/5787178/how-can-i-use-azue-for-students)
I am student at Antalya Bilim Universty (Antalya/Türkiye). I heard about Azure for Students benefit. I would like to be user to do some work on Azure my school projects however I am unable to verify my account. Could you please help me to solve the…
Azure Cost Management
[ Azure Cost Management ](https://learn.microsoft.com/en-us/answers/tags/118/azure-cost-management/)
A Microsoft offering that enables tracking of cloud usage and expenditures for Azure and other cloud providers.
4,765 questions
Sign in to follow  Follow
asked Feb 24, 2026, 4:12 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(128,%2083%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EYT%3C/text%3E%3C/svg%3E)
[YUSUF TİRYAKİ](https://learn.microsoft.com/en-us/users/na/?userid=4e083894-f06f-4a4b-b939-2789dc7f1bb4) 0 Reputation points
edited the question Feb 24, 2026, 7:17 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/DSq8thXX1EC7bjdlrVIvlQ.png?8DE168)
[Gérard Oomens](https://learn.microsoft.com/en-us/users/na/?userid=b6bc2a0d-d715-40d4-bb6e-3765ad522f95) 118.7K Reputation points • Volunteer Moderator
1 answer
##  [ Private offer VM creation via az CLI fails ](https://learn.microsoft.com/en-us/answers/questions/5787064/private-offer-vm-creation-via-az-cli-fails)
I have a private offer in the marketplace, and I'm trying to create a VM from it for testing, using az CLI. I can see the offer, SKUs and versions via the CLI, but when I try to accept terms or create a VM, I get "offer ID not found" errors: …
Azure Virtual Machines
[ Azure Virtual Machines ](https://learn.microsoft.com/en-us/answers/tags/94/azure-virtual-machines/)
An Azure service that is used to provision Windows and Linux virtual machines.
9,891 questions
Sign in to follow  Follow
asked Feb 24, 2026, 2:40 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(220.8,%2075%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EC%3C/text%3E%3C/svg%3E)
[Clarivize](https://learn.microsoft.com/en-us/users/na/?userid=b69fc7c5-4734-4831-8776-91e06c40b2fe) 0 Reputation points
answered Feb 24, 2026, 7:15 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(249.60000000000002,%2021%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMD%3C/text%3E%3C/svg%3E)
[Manish Deshpande](https://learn.microsoft.com/en-us/users/na/?userid=c7821999-f86d-4f2f-848e-57f67650b375) 3,580 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Azure external DNS spf record is not updating when changed ](https://learn.microsoft.com/en-us/answers/questions/5787157/azure-external-dns-spf-record-is-not-updating-when)
I have made changes to our spf record and n o changes show when checking mxtoolbox. It is set to update with TTL 60minutes, changed a week ago. Not sure if it is a subscription issue. We don't have a balance.
Azure DNS
[ Azure DNS ](https://learn.microsoft.com/en-us/answers/tags/77/azure-dns/)
An Azure service that enables hosting Domain Name System (DNS) domains in Azure.
859 questions
Sign in to follow  Follow
asked Feb 24, 2026, 3:52 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(198.4,%2086%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ETS%3C/text%3E%3C/svg%3E)
[Tasha Steele](https://learn.microsoft.com/en-us/users/na/?userid=ab6dd28c-a6f9-487f-a544-f65fc76d1fb7) 0 Reputation points
edited the question Feb 24, 2026, 7:14 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2096%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Ankit Yadav](https://learn.microsoft.com/en-us/users/na/?userid=8b2f9683-34a8-4b44-a7ee-9780f7021c11) 11,495 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How long does it take Azure to take payment after the card is updated? ](https://learn.microsoft.com/en-us/answers/questions/5782485/how-long-does-it-take-azure-to-take-payment-after)
My card on file was replaced. I thought I updated the card in billing, but must not have finalized. I have updated the card, but I am unable to reactivate. Says it could take up to 24 hours? Any way to streamline that?
Azure Cost Management
[ Azure Cost Management ](https://learn.microsoft.com/en-us/answers/tags/118/azure-cost-management/)
A Microsoft offering that enables tracking of cloud usage and expenditures for Azure and other cloud providers.
4,765 questions
Sign in to follow  Follow
asked Feb 20, 2026, 10:50 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(198.4,%2040%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECL%3C/text%3E%3C/svg%3E)
[Cargo Largo](https://learn.microsoft.com/en-us/users/na/?userid=b62406c2-7ffe-0003-0000-000000000000) 0 Reputation points
commented Feb 24, 2026, 7:08 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(236.8,%2068%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EBY%3C/text%3E%3C/svg%3E)
[Bharath Y P](https://learn.microsoft.com/en-us/users/na/?userid=7a4cb6c8-530a-4ca8-9322-648330cf2c9b) 4,705 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Azure SMB file share accessible via shared key but not via cloud-only Kerberos authentication ](https://learn.microsoft.com/en-us/answers/questions/5786011/azure-smb-file-share-accessible-via-shared-key-but)
After a ransomware attack destroyed the network, everything was migrated to cloud-only; all user accounts manually migrated from the destroyed DC/AD to Entra ID, all files restored from backups to SharePoint, all devices to Intune, all MFA, everyone is…
Azure Files
[ Azure Files ](https://learn.microsoft.com/en-us/answers/tags/66/azure-files/)
An Azure service that offers file shares in the cloud.
1,491 questions
Sign in to follow  Follow
asked Feb 23, 2026, 10:25 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(224.00000000000003,%2069%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EI%3C/text%3E%3C/svg%3E)
[IT](https://learn.microsoft.com/en-us/users/na/?userid=70e695e6-4b67-4d61-863e-1636b1f77b8e) 0 Reputation points
commented Feb 24, 2026, 7:05 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(224.00000000000003,%2069%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EI%3C/text%3E%3C/svg%3E)
[IT](https://learn.microsoft.com/en-us/users/na/?userid=70e695e6-4b67-4d61-863e-1636b1f77b8e) 0 Reputation points
1 answer
##  [ Static Web App BYO backend returns HTML 500 before Function execution (invocations stay 0) ](https://learn.microsoft.com/en-us/answers/questions/5785328/static-web-app-byo-backend-returns-html-500-before)
We have a production Azure Static Web App with a linked Azure Function App backend. Current behavior: User sign-in works normally. /.auth/me returns a valid clientPrincipal. API calls from the Static Web App fail with HTTP 500 and content-type:…
Azure Static Web Apps
[ Azure Static Web Apps ](https://learn.microsoft.com/en-us/answers/tags/448/static-web-apps/)
An Azure service that provides streamlined full-stack web app development.
1,337 questions
Sign in to follow  Follow
asked Feb 23, 2026, 11:06 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(243.2,%2095%,%2033%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ELL%3C/text%3E%3C/svg%3E)
[Lionel Lapidos](https://learn.microsoft.com/en-us/users/na/?userid=7a69554e-e4d0-4146-856c-48676f09bf16) 0 Reputation points
commented Feb 24, 2026, 6:56 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(99.2,%2085%,%2019%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGV%3C/text%3E%3C/svg%3E)
[Golla Venkata Pavani ](https://learn.microsoft.com/en-us/users/na/?userid=3f1852fc-98fe-4bcf-b906-d4f71b3ac189) 1,830 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Error 5xx and especially Error 500.30 application fail to start - No application insight data ](https://learn.microsoft.com/en-us/answers/questions/5732066/error-5x-and-especially-error-500-30-application-f)
Hi, we are facing some problems with our web application. We have 4 instances of P0v3. The max CPU used at high load is 60%-70% and memory 60%. At high load we have 4K-5K requests per minute. Occasionally, at web app monitoring we see a few error 500…
Azure App Service
[ Azure App Service ](https://learn.microsoft.com/en-us/answers/tags/436/azure-app-service/)
Azure App Service is a service used to create and deploy scalable, mission-critical web apps.
9,710 questions
Sign in to follow  Follow
asked Jan 22, 2026, 3:27 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(67.2,%2047%,%2016%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMS%3C/text%3E%3C/svg%3E)
[Mike Sarafidis](https://learn.microsoft.com/en-us/users/na/?userid=21ae4785-234e-4b3d-941d-e567386a7071) 21 Reputation points
edited a comment Feb 24, 2026, 6:54 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(99.2,%2085%,%2019%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGV%3C/text%3E%3C/svg%3E)
[Golla Venkata Pavani ](https://learn.microsoft.com/en-us/users/na/?userid=3f1852fc-98fe-4bcf-b906-d4f71b3ac189) 1,830 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How to enable sms for local numbers (paid subscription) ](https://learn.microsoft.com/en-us/answers/questions/5787229/how-to-enable-sms-for-local-numbers-\(paid-subscrip)
"Your subscription is not eligible for Brand and Campaign registration." This is the error I get even though I'm on a paid subscription. I need to enable SMS for my local phone numbers however this is not currently possible. How do I enable…
Azure Communication Services
[ Azure Communication Services ](https://learn.microsoft.com/en-us/answers/tags/128/azure-communication-services/)
An Azure communication platform for deploying applications across devices and platforms.
1,566 questions
Sign in to follow  Follow
asked Feb 24, 2026, 5:12 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(41.6,%2028.999999999999996%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ER%3C/text%3E%3C/svg%3E)
[Ryan5021](https://learn.microsoft.com/en-us/users/na/?userid=a132982f-f990-4002-844f-be1c944e1020) 0 Reputation points
commented Feb 24, 2026, 6:46 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(41.6,%2028.999999999999996%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ER%3C/text%3E%3C/svg%3E)
[Ryan5021](https://learn.microsoft.com/en-us/users/na/?userid=a132982f-f990-4002-844f-be1c944e1020) 0 Reputation points
1 answer
##  [ Hi, Everyone I need help I have been trying to get my Azure credits for days ](https://learn.microsoft.com/en-us/answers/questions/5787299/hi-everyone-i-need-help-i-have-been-trying-to-get)
I need help PLEASE I have been trying to access my Azure credits for the last 5 days and first I had some how changed the Global Admin so I was locked out for that. When I finally got that fixed Azure somehow changed my account from personal to a…
Azure | Azure Startups
[ Azure | Azure Startups ](https://learn.microsoft.com/en-us/answers/tags/503/azure-azure-startups/)
Startups: Companies that are in their initial stages of business and typically developing a business model and seeking financing.
![](https://learn.microsoft.com/en-us/media/logos/logo_azure.svg)
1,144 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:45 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(284.8,%2065%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EEO%3C/text%3E%3C/svg%3E)
[Elizabeth Outlaw](https://learn.microsoft.com/en-us/users/na/?userid=8d9ad65d-a4cf-40e0-8e15-b9307614bbae) 0 Reputation points
answered Feb 24, 2026, 6:46 PM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
0 answers
##  [ Verify academic status ](https://learn.microsoft.com/en-us/answers/questions/5786360/verify-academic-status)
I'm a teacher at CVO Scala, Roeselare. I'd like to validate a Windows 11 Education version and need a valid serial number. When I login with cvoscala.be on azure to verify my academic status, I receive the message "U hebt geen toegang", meaning…
Azure Cost Management
[ Azure Cost Management ](https://learn.microsoft.com/en-us/answers/tags/118/azure-cost-management/)
A Microsoft offering that enables tracking of cloud usage and expenditures for Azure and other cloud providers.
4,765 questions
Sign in to follow  Follow
asked Feb 24, 2026, 5:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(313.6,%2093%,%2040%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJS%3C/text%3E%3C/svg%3E)
[Joan Staels](https://learn.microsoft.com/en-us/users/na/?userid=98bcc9e3-ccc9-4dd3-9e8b-0cdf0857c326) 0 Reputation points
edited the question Feb 24, 2026, 6:42 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 4,855 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Vector index creation stuck ](https://learn.microsoft.com/en-us/answers/questions/5787175/vector-index-creation-stuck)
Hi, I'm following the learning module from Microsoft Learn: Develop a RAG-based solution with your own data using Microsoft Foundry. I'm using Azure free account. I'm trying to create a vector index in my Azure AI Search resource. It is stuck in this…
Azure AI Search
[ Azure AI Search ](https://learn.microsoft.com/en-us/answers/tags/109/azure-cognitive-search/)
An Azure search service with built-in artificial intelligence capabilities that enrich information to help identify and explore relevant content at scale.
1,511 questions
Sign in to follow  Follow
asked Feb 24, 2026, 4:10 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(108.80000000000001,%2031%,%2020%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ETA%3C/text%3E%3C/svg%3E)
[Tripti Abraham](https://learn.microsoft.com/en-us/users/na/?userid=f343a17d-d060-4df0-9cf5-9e0e762027b2) 20 Reputation points
commented Feb 24, 2026, 6:41 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(80,%207.000000000000001%,%2017%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Praneeth Maddali](https://learn.microsoft.com/en-us/users/na/?userid=bb2507a8-63fa-48d8-aaa7-3570a11fbcc3) 4,855 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Artifact Signing: Email to "complete process" leads to "system maintenance" site since over one week ](https://learn.microsoft.com/en-us/answers/questions/5787288/artifact-signing-email-to-complete-process-leads-t)
Hi, 3 months ago I paid for "trusted signing", now "artifact signing". It's been stuck at "in progress", but last week I got an email "Action required: Complete your identity validation process". However, since a…
Artifact Signing
[ Artifact Signing ](https://learn.microsoft.com/en-us/answers/tags/1579/artifact-signing/)
A fully managed end-to-end service for digitally signing code, documents, and applications. (formerly Trusted Signing)
619 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:31 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(217.60000000000002,%2041%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDG%3C/text%3E%3C/svg%3E)
[Daniel Gallenberger](https://learn.microsoft.com/en-us/users/na/?userid=6e84c1a1-f533-49f2-8e28-98c17dce99c5) 0 Reputation points
asked Feb 24, 2026, 6:31 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(217.60000000000002,%2041%,%2031%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDG%3C/text%3E%3C/svg%3E)
[Daniel Gallenberger](https://learn.microsoft.com/en-us/users/na/?userid=6e84c1a1-f533-49f2-8e28-98c17dce99c5) 0 Reputation points
1 answer
##  [ "Image recipe validation tests failed" Error during Arc Registration in a nested environment ](https://learn.microsoft.com/en-us/answers/questions/2288100/image-recipe-validation-tests-failed-error-during)
Env: Nested Virtualization MSLab During the Arc registration process using "Invoke-AzStackHciArcInitialization" command, the command fails saying "Image recipe validation tests failed.". See image attached. So this totally blocks…
Azure Local
[ Azure Local ](https://learn.microsoft.com/en-us/answers/tags/654/azure-local/)
279 questions
Sign in to follow  Follow
asked Jun 27, 2025, 9:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(48,%207.000000000000001%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJD%3C/text%3E%3C/svg%3E)
[Jayanth Dattatri YKB](https://learn.microsoft.com/en-us/users/na/?userid=1507e5a0-8a48-4240-b51c-a55edf1fd0a8) 40 Reputation points • MVP
edited a comment Feb 24, 2026, 6:22 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(12.8,%2082%,%2011%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJI%3C/text%3E%3C/svg%3E)
[James Iwan](https://learn.microsoft.com/en-us/users/na/?userid=0aff4b82-3b7b-4f60-80ef-74e9565dcd53) 0 Reputation points
2 answers
##  [ No access to training site ](https://learn.microsoft.com/en-us/answers/questions/5787045/no-access-to-training-site)
Hello, I am on training to get AZ-900, need student access for training and certification path on this.
Azure | Azure Training
[ Azure | Azure Training ](https://learn.microsoft.com/en-us/answers/tags/447/azure-azure-training/)
Training: Instruction to develop new skills.
![](https://learn.microsoft.com/en-us/media/logos/logo_azure.svg)
3,091 questions
Sign in to follow  Follow
asked Feb 24, 2026, 2:26 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(176,%2052%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGC%3C/text%3E%3C/svg%3E)
[Gable Cordero](https://learn.microsoft.com/en-us/users/na/?userid=55f5a261-df2f-45fa-bb1a-0309f5d9f009) 0 Reputation points
answered Feb 24, 2026, 6:20 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(249.60000000000002,%2021%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMD%3C/text%3E%3C/svg%3E)
[Manish Deshpande](https://learn.microsoft.com/en-us/users/na/?userid=c7821999-f86d-4f2f-848e-57f67650b375) 3,580 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ Azure DevOps Server (on-prem), cannot get past "401 - Uh-oh, you do not have access." ](https://learn.microsoft.com/en-us/answers/questions/5693385/azure-devops-server-\(on-prem\)-cannot-get-past-401)
Apologies in advance for the lengthy question. I am using Azure DevOps Server on a local server (VM). Install and setup completes without any issues. I am able to setup repos and pipelines, add work items, everything is great. Then after a few days,…
Azure DevOps
[ Azure DevOps ](https://learn.microsoft.com/en-us/answers/tags/768/azure-devops/)
1,220 questions
Sign in to follow  Follow
asked Jan 5, 2026, 11:36 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(252.8,%2059%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJC%3C/text%3E%3C/svg%3E)
[Joseph Choi](https://learn.microsoft.com/en-us/users/na/?userid=a7a9d59c-8060-4779-b886-36a2179a967a) 5 Reputation points
edited a comment Feb 24, 2026, 6:16 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(208,%2057.99999999999999%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDC%3C/text%3E%3C/svg%3E)
[Dr. Chris Benner](https://learn.microsoft.com/en-us/users/na/?userid=6c5d58ae-0146-43bb-be2b-f508e51f785c) 0 Reputation points
1 answer
##  [ Geocoding API uses outdated road/address network ](https://learn.microsoft.com/en-us/answers/questions/5785952/geocoding-api-uses-outdated-road-address-network)
Guys, your geocoding api does not identify address that exist. I tried alternative, google and arcgis geocoding apis and their apis properly geocode the location. please update your backend with newer road network. We regularly use the Azure subscription…
Azure Maps
[ Azure Maps ](https://learn.microsoft.com/en-us/answers/tags/209/azure-maps/)
An Azure service that provides geospatial APIs to add maps, spatial analytics, and mobility solutions to apps.
908 questions
Sign in to follow  Follow
asked Feb 23, 2026, 8:56 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2057.99999999999999%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESA%3C/text%3E%3C/svg%3E)
[Synytsia, Anton](https://learn.microsoft.com/en-us/users/na/?userid=b105839d-6163-438a-a691-7b0ce2e89e0e) 0 Reputation points
answered Feb 24, 2026, 6:12 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/1c21e7e9ef0e4489a0ee4cc00b604d9d.png)
[IoTGirl](https://learn.microsoft.com/en-us/users/na/?userid=682ea176-70c6-414d-8a64-8cbdd03d2332) 3,841 Reputation points • Microsoft Employee • Moderator
2 answers
##  [ Cloud Shell failed to request a terminal ](https://learn.microsoft.com/en-us/answers/questions/5786824/cloud-shell-failed-to-request-a-terminal)
Trying to access Powershell in the browser and getting an error. Sorry, your Cloud Shell failed to request a terminal.Please click the restart button. If the issue persists, please file a ticket New support request. <PII>
Azure Cloud Services
[ Azure Cloud Services ](https://learn.microsoft.com/en-us/answers/tags/84/azure-cloud-services/)
An Azure platform as a service offer that is used to deploy web and cloud applications.
867 questions
Sign in to follow  Follow
asked Feb 24, 2026, 11:25 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(128,%2049%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EUR%3C/text%3E%3C/svg%3E)
[Ullrich, Robert - OCIO-CEC, CO](https://learn.microsoft.com/en-us/users/na/?userid=c4049e44-055c-45f2-9ddb-bc2934ee0c7a) 0 Reputation points
answered Feb 24, 2026, 6:11 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(249.60000000000002,%2021%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMD%3C/text%3E%3C/svg%3E)
[Manish Deshpande](https://learn.microsoft.com/en-us/users/na/?userid=c7821999-f86d-4f2f-848e-57f67650b375) 3,580 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Azure function with a connection OPenAsync generates an exception ](https://learn.microsoft.com/en-us/answers/questions/5785886/azure-function-with-a-connection-openasync-generat)
Greetings Community, The intent of my Azure C# function consists of accessing a Database hosted by a serverless Azure resource. With the use of the logger, I found out that it fails on the instruction await connection.OpenAsync(); An exception is…
Azure Functions
[ Azure Functions ](https://learn.microsoft.com/en-us/answers/tags/87/azure-functions/)
An Azure service that provides an event-driven serverless compute platform.
6,372 questions
Sign in to follow  Follow
asked Feb 23, 2026, 7:38 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(0,%2014.000000000000002%,%2010%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Patrick M](https://learn.microsoft.com/en-us/users/na/?userid=a00f142c-7745-4e1b-9b55-0a870e56f77f) 0 Reputation points
commented Feb 24, 2026, 6:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(0,%2014.000000000000002%,%2010%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPM%3C/text%3E%3C/svg%3E)
[Patrick M](https://learn.microsoft.com/en-us/users/na/?userid=a00f142c-7745-4e1b-9b55-0a870e56f77f) 0 Reputation points
4 answers
##  [ Is Azure a good option for data integration? ](https://learn.microsoft.com/en-us/answers/questions/5782441/is-azure-a-good-option-for-data-integration)
Hello everyone, I am a business graduate student where for one of my classes, we're working with a company to help them with a data management project. They're a non-profit sports foundation that has a couple different programs each with its own website…
Azure Data Factory
[ Azure Data Factory ](https://learn.microsoft.com/en-us/answers/tags/194/azure-data-factory/)
An Azure service for ingesting, preparing, and transforming data at scale.
12,069 questions
Sign in to follow  Follow
asked Feb 20, 2026, 10:12 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(233.6,%2088%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESB%3C/text%3E%3C/svg%3E)
[Shermer, Benjamin M](https://learn.microsoft.com/en-us/users/na/?userid=73887f67-3351-4c95-8f3a-e6e5ffee3046) 0 Reputation points
answered Feb 24, 2026, 6:05 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(16,%202%,%2011%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMK%3C/text%3E%3C/svg%3E)
[Manoj Kumar Boyini ](https://learn.microsoft.com/en-us/users/na/?userid=0f50cb22-cc6f-42c4-bbce-4ca7de7d59d7) 7,990 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Try to use gpt-4o-transcribe-diarize through HTTP-Request for transcription-results in Server Error ](https://learn.microsoft.com/en-us/answers/questions/5764353/try-to-use-gpt-4o-transcribe-diarize-through-http)
Im building an automation in copilot studio/power automate which includes transcribing an audio file. I use a HTTP-Request to connect to my azure ai foundry models. I first tried it with whisper which worked perfectly and also gpto 4o-mini-transcribe.…
Azure Translator in Foundry Tools
[ Azure Translator in Foundry Tools ](https://learn.microsoft.com/en-us/answers/tags/132/azure-translator/)
An Azure service to easily conduct machine translation with a simple REST API call.
543 questions
Sign in to follow  Follow
asked Feb 6, 2026, 3:35 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(169.60000000000002,%204%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPN%3C/text%3E%3C/svg%3E)
[Paul Nesch](https://learn.microsoft.com/en-us/users/na/?userid=53043c3f-dd30-4661-9f7d-f2ec795d082c) 0 Reputation points
commented Feb 24, 2026, 6:05 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(204.8,%2015%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMM%3C/text%3E%3C/svg%3E)
[Manas Mohanty](https://learn.microsoft.com/en-us/users/na/?userid=6ed415a7-b41e-41ad-bd5b-ede8461a8b16) 14,415 Reputation points • Microsoft External Staff • Moderator
  * [ ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=4)
  * ...
  * [ 6898 ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=6898)
  * [ ](https://learn.microsoft.com/en-us/answers/tags/133/azure?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Ftags%2F133%2Fazure)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
