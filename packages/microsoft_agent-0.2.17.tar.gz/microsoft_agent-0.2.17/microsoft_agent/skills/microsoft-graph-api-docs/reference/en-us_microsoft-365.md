[ Skip to main content ](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide)
[ Microsoft 365  ](https://learn.microsoft.com/en-us/microsoft-365/)
  * Admin foundations
    * [ Microsoft 365 admin center ](https://learn.microsoft.com/en-us/microsoft-365/admin/)
    * [ Billing ](https://learn.microsoft.com/en-us/microsoft-365/commerce/)
    * [ Microsoft 365 service descriptions ](https://learn.microsoft.com/en-us/office365/servicedescriptions/office-365-service-descriptions-technet-library/)
  * [ Security ](https://learn.microsoft.com/en-us/microsoft-365/security/)
  * Microsoft 365 Copilot
    * [ Overview ](https://learn.microsoft.com/en-us/copilot/microsoft-365/microsoft-365-copilot-overview)
    * [ Extensibility ](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/overview)
    * [ Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
  * Products
    * [ Microsoft 365 Apps ](https://learn.microsoft.com/en-us/microsoft-365-apps/)
    * [ Teams ](https://learn.microsoft.com/en-us/microsoftteams/)
    * [ Exchange Online ](https://learn.microsoft.com/en-us/exchange/)
    * [ SharePoint Online ](https://learn.microsoft.com/en-us/sharepoint/)
    * [ Other Microsoft 365 products ](https://learn.microsoft.com/en-us/microsoft-365/)
  * Training
    * [ Training for IT Pros ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft 365 certifications ](https://learn.microsoft.com/en-us/certifications/browse/?products=m365)
    * [ Microsoft 365 learning pathways ](https://learn.microsoft.com/en-us/office365/customlearning/)
  * Resources
    * [ Microsoft 365 support ](https://support.microsoft.com/microsoft-365)
    * [ FastTrack ](https://www.microsoft.com/fasttrack/microsoft-365)
    * [ Troubleshooting ](https://learn.microsoft.com/en-us/office/troubleshoot)
    * [ Microsoft 365 tech community ](https://techcommunity.microsoft.com/t5/Microsoft-365/ct-p/microsoft365)
    * [ Resources for developers ](https://developer.microsoft.com/microsoft-365)
  * More
    * Admin foundations
      * [ Microsoft 365 admin center ](https://learn.microsoft.com/en-us/microsoft-365/admin/)
      * [ Billing ](https://learn.microsoft.com/en-us/microsoft-365/commerce/)
      * [ Microsoft 365 service descriptions ](https://learn.microsoft.com/en-us/office365/servicedescriptions/office-365-service-descriptions-technet-library/)
    * [ Security ](https://learn.microsoft.com/en-us/microsoft-365/security/)
    * Microsoft 365 Copilot
      * [ Overview ](https://learn.microsoft.com/en-us/copilot/microsoft-365/microsoft-365-copilot-overview)
      * [ Extensibility ](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/overview)
      * [ Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
    * Products
      * [ Microsoft 365 Apps ](https://learn.microsoft.com/en-us/microsoft-365-apps/)
      * [ Teams ](https://learn.microsoft.com/en-us/microsoftteams/)
      * [ Exchange Online ](https://learn.microsoft.com/en-us/exchange/)
      * [ SharePoint Online ](https://learn.microsoft.com/en-us/sharepoint/)
      * [ Other Microsoft 365 products ](https://learn.microsoft.com/en-us/microsoft-365/)
    * Training
      * [ Training for IT Pros ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft 365 certifications ](https://learn.microsoft.com/en-us/certifications/browse/?products=m365)
      * [ Microsoft 365 learning pathways ](https://learn.microsoft.com/en-us/office365/customlearning/)
    * Resources
      * [ Microsoft 365 support ](https://support.microsoft.com/microsoft-365)
      * [ FastTrack ](https://www.microsoft.com/fasttrack/microsoft-365)
      * [ Troubleshooting ](https://learn.microsoft.com/en-us/office/troubleshoot)
      * [ Microsoft 365 tech community ](https://techcommunity.microsoft.com/t5/Microsoft-365/ct-p/microsoft365)
      * [ Resources for developers ](https://developer.microsoft.com/microsoft-365)


[ Free Account ](https://www.microsoft.com/microsoft-365/microsoft-365-business-standard-one-month-trial)
# Microsoft 365 documentation
Find the solutions, scenarios, and resources you need to get started with Microsoft 365 for your business or organization. Microsoft 365 includes services such as Teams and SharePoint, and Microsoft 365 Apps such as Outlook, Word, Excel, and PowerPoint.
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-get-started.svg?branch=main)
Get started
[Microsoft 365 Copilot](https://learn.microsoft.com/en-us/copilot/microsoft-365/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-get-started.svg?branch=main)
Get started
[Remote learning with Microsoft Teams](https://learn.microsoft.com/en-us/MicrosoftTeams/remote-learning-edu)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-training.svg?branch=main)
Training
[Build your skills with Microsoft Learn training](https://learn.microsoft.com/en-us/training/m365/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-whats-new.svg?branch=main)
What's new
[Microsoft 365 Community Conference - Learn from experts and MVPs, and expand your Intelligent Work skillset](https://aka.ms/mcag/ipm/26004P)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-video.svg?branch=main)
video
[Get your small business started with Microsoft 365](https://learn.microsoft.com/en-us/microsoft-365/business-video/?view=o365-worldwide)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-how-to-guide.svg?branch=main)
How-To Guide
[Set up your infrastructure for hybrid work](https://learn.microsoft.com/en-us/microsoft-365/solutions/empower-people-to-work-remotely?view=o365-worldwide)
### Admin documentation
  * [Microsoft 365 admin center](https://learn.microsoft.com/en-us/microsoft-365/admin/?view=o365-worldwide)
  * [Microsoft 365 for enterprise](https://learn.microsoft.com/en-us/microsoft-365/enterprise/?view=o365-worldwide)
  * [Microsoft 365 for frontline workers](https://learn.microsoft.com/en-us/microsoft-365/frontline/?view=o365-worldwide)
  * [Microsoft 365 Archive](https://learn.microsoft.com/en-us/microsoft-365/archive/?view=o365-worldwide)
  * [Microsoft 365 Backup](https://learn.microsoft.com/en-us/microsoft-365/backup/?view=o365-worldwide)
  * [Microsoft 365 Business Premium](https://learn.microsoft.com/en-us/microsoft-365/business-premium/?view=o365-worldwide)
  * [Microsoft 365 security](https://learn.microsoft.com/en-us/microsoft-365/security/?view=o365-worldwide)
  * [Troubleshooting and support](https://learn.microsoft.com/en-us/office/troubleshoot)
  * [Microsoft 365 pay-as-you-go services](https://learn.microsoft.com/en-us/microsoft-365/services/)


### Products
  * [Microsoft Teams](https://learn.microsoft.com/en-us/MicrosoftTeams)
  * [SharePoint and OneDrive](https://learn.microsoft.com/en-us/sharepoint/introduction)
  * [Microsoft Purview](https://learn.microsoft.com/en-us/purview/)
  * [Microsoft Viva](https://learn.microsoft.com/en-us/viva/)
  * [Exchange Online](https://learn.microsoft.com/en-us/Exchange/exchange-online)
  * [Planner](https://learn.microsoft.com/en-us/office365/planner)
  * [Microsoft Places](https://learn.microsoft.com/en-us/microsoft-365/places)


### Microsoft 365 Apps and Office
  * [Microsoft 365 Apps](https://learn.microsoft.com/en-us/microsoft-365-apps/deploy/plan-microsoft-365-apps)
  * [Office for Mac](https://learn.microsoft.com/en-us/microsoft-365-apps/mac/deployment-guide-for-office-for-mac)
  * [Office LTSC 2024](https://learn.microsoft.com/en-us/office/ltsc/2024/overview)
  * [Outlook for Windows](https://learn.microsoft.com/en-us/microsoft-365-apps/outlook/overview-new-outlook)
  * [Outlook for iOS and Android](https://adoption.microsoft.com/outlook-mobile/)
  * [ See more ](https://learn.microsoft.com/en-us/microsoft-365-apps)


### Solutions for your business
  * [Set up your infrastructure for hybrid work](https://learn.microsoft.com/en-us/microsoft-365/solutions/empower-people-to-work-remotely?view=o365-worldwide)
  * [Set up secure collaboration with Teams](https://learn.microsoft.com/en-us/microsoft-365/solutions/setup-secure-collaboration-with-teams?view=o365-worldwide)
  * [Deploy Microsoft Defender threat protection](https://learn.microsoft.com/en-us/microsoft-365/solutions/deploy-threat-protection?view=o365-worldwide)
  * [Manage data privacy and data protection](https://learn.microsoft.com/en-us/microsoft-365/solutions/data-privacy-protection?view=o365-worldwide)
  * [Microsoft 365 security for smaller businesses and campaigns](https://learn.microsoft.com/en-us/microsoft-365/admin/security-and-compliance/m365b-security-overview)
  * [Microsoft 365 productivity illustrations](https://learn.microsoft.com/en-us/microsoft-365/solutions/productivity-illustrations?view=o365-worldwide)
  * [ See more ](https://learn.microsoft.com/en-us/microsoft-365/solutions/?view=o365-worldwide)


### Manage devices
  * [Deploy Windows](https://learn.microsoft.com/en-us/windows/deployment/)
  * [Microsoft Managed Desktop](https://learn.microsoft.com/en-us/microsoft-365/managed-desktop/?view=o365-worldwide)
  * [Device management with Microsoft Intune](https://learn.microsoft.com/en-us/mem/intune/fundamentals/what-is-intune)


### Hybrid and migration
  * [Migrate your content to SharePoint, OneDrive, and Teams](https://learn.microsoft.com/en-us/sharepointmigration/migrate-to-sharepoint-online)
  * [Hybrid SharePoint](https://learn.microsoft.com/en-us/sharepoint/hybrid/hybrid)
  * [Migrate multiple email accounts to Microsoft 365](https://learn.microsoft.com/en-us/Exchange/mailbox-migration/mailbox-migration)


### More apps and services
  * [Microsoft Bookings](https://learn.microsoft.com/en-us/microsoft-365/bookings/?view=o365-worldwide)
  * [Microsoft Forms](https://learn.microsoft.com/en-us/microsoft-forms/)
  * [Microsoft Stream](https://learn.microsoft.com/en-us/stream/)


### Power Platform in Microsoft 365
  * [Power Apps in Teams](https://learn.microsoft.com/en-us/power-apps/teams/overview)
  * [Power Automate](https://learn.microsoft.com/en-us/power-automate/)
  * [Power Virtual Agents in Teams](https://learn.microsoft.com/en-us/power-virtual-agents/teams/fundamentals-what-is-power-virtual-agents-teams)
  * [Power BI in Teams](https://learn.microsoft.com/en-us/power-bi/collaborate-share/service-collaborate-microsoft-teams)


[](https://learn.microsoft.com/en-us/microsoft-365/?view=o365-worldwide#guidance-and-resources-for-all-audiences)
## Guidance and resources for all audiences
Find documentation and resources for end users, educators, and developers, and find community resources for technical audiences.
![](https://learn.microsoft.com/en-us/office/media/icons/help.svg)
[End users](https://support.microsoft.com/microsoft-365)
![](https://learn.microsoft.com/en-us/office/media/icons/education-tutorial-blue.svg)
[Educators](https://support.microsoft.com/education)
![](https://learn.microsoft.com/en-us/office/media/icons/administrator.svg)
[Education IT](https://learn.microsoft.com/en-us/education)
![](https://learn.microsoft.com/en-us/office/media/icons/developer-blue.svg)
[Developers](https://learn.microsoft.com/en-us/microsoft-365/developer/?view=o365-worldwide)
![](https://learn.microsoft.com/en-us/office/media/icons/deploy-blue.svg)
[FastTrack](https://learn.microsoft.com/en-us/microsoft-365/fasttrack/)
![](https://learn.microsoft.com/en-us/office/media/icons/users-group.svg)
[Microsoft 365 service adoption framework](https://learn.microsoft.com/en-us/training/paths/m365-service-adoption/)
![](https://learn.microsoft.com/en-us/office/media/icons/blog-site-blue.svg)
[Microsoft 365 Community Content](https://learn.microsoft.com/en-us/microsoft-365/community/)
![](https://learn.microsoft.com/en-us/office/media/icons/users-group.svg)
[Tech community](https://techcommunity.microsoft.com/t5/Microsoft-365/ct-p/microsoft365)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fmicrosoft-365%2F%3Fview%3Do365-worldwide)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
