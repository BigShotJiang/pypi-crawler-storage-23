[ Skip to main content ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Version Microsoft Graph REST API v1.0
  * [1.0](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0)
  * [beta](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-beta)


Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [API changelog](https://developer.microsoft.com/en-us/graph/changelog)
  * [Quick start](https://developer.microsoft.com/en-us/graph/quick-start)
  * [Authentication and authorization](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
  * [Use the API](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use SDKs](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use the toolkit](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Deploy with Bicep](https://learn.microsoft.com/en-us/graph/templates?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Known issues](https://developer.microsoft.com/graph/known-issues)
  * [Errors](https://learn.microsoft.com/en-us/graph/errors?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  *     * [Overview](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
    *       * [Overview](https://learn.microsoft.com/en-us/graph/api/resources/calendar-overview?view=graph-rest-1.0)
      *         * [Event](https://learn.microsoft.com/en-us/graph/api/resources/event?view=graph-rest-1.0)
        * [List](https://learn.microsoft.com/en-us/graph/api/user-list-events?view=graph-rest-1.0)
        * [Create](https://learn.microsoft.com/en-us/graph/api/user-post-events?view=graph-rest-1.0)
        * [Get](https://learn.microsoft.com/en-us/graph/api/event-get?view=graph-rest-1.0)
        * [Update](https://learn.microsoft.com/en-us/graph/api/event-update?view=graph-rest-1.0)
        * [Delete](https://learn.microsoft.com/en-us/graph/api/event-delete?view=graph-rest-1.0)
        * [Permanently delete](https://learn.microsoft.com/en-us/graph/api/event-permanentdelete?view=graph-rest-1.0)
        * [Get delta](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0)
        * [Forward event](https://learn.microsoft.com/en-us/graph/api/event-forward?view=graph-rest-1.0)
        * [Cancel event](https://learn.microsoft.com/en-us/graph/api/event-cancel?view=graph-rest-1.0)
        * [Accept event](https://learn.microsoft.com/en-us/graph/api/event-accept?view=graph-rest-1.0)
        * [Tentatively accept](https://learn.microsoft.com/en-us/graph/api/event-tentativelyaccept?view=graph-rest-1.0)
        * [Decline event](https://learn.microsoft.com/en-us/graph/api/event-decline?view=graph-rest-1.0)
        * [Dismiss reminder](https://learn.microsoft.com/en-us/graph/api/event-dismissreminder?view=graph-rest-1.0)
        * [Snooze reminder](https://learn.microsoft.com/en-us/graph/api/event-snoozereminder?view=graph-rest-1.0)
        * [List event instances](https://learn.microsoft.com/en-us/graph/api/event-list-instances?view=graph-rest-1.0)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/api-reference/v1.0/api/event-delta.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fevent-delta%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fevent-delta%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fevent-delta%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fevent-delta%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http) or changing directories.
Access to this page requires authorization. You can try changing directories.
# event: delta
Feedback
Summarize this article for me
##  In this article
  1. [Permissions](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#permissions)
  2. [HTTP request](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#http-request)
  3. [Query parameters](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#query-parameters)
  4. [Request headers](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#request-headers)
  5. [Response](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#response)
  6. [Example](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#example)
  7. [Related content](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#related-content)

Show 3 more
Namespace: microsoft.graph
Get a set of [event](https://learn.microsoft.com/en-us/graph/api/resources/event?view=graph-rest-1.0) resources that have been added, deleted, or updated in a **calendarView** (a range of events defined by start and end dates) of the user's primary calendar.
Typically, synchronizing events in a **calendarView** in a local store entails a round of multiple **delta** function calls. The initial call is a full synchronization, and every subsequent **delta** call in the same round gets the incremental changes (additions, deletions, or updates). This allows you to maintain and synchronize a local store of events in the specified **calendarView** , without having to fetch all the events of that calendar from the server every time.
This API is available in the following [national cloud deployments](https://learn.microsoft.com/en-us/graph/deployments).
Expand table
Global service | US Government L4 | US Government L5 (DOD) | China operated by 21Vianet
---|---|---|---
✅ | ✅ | ✅ | ✅
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#permissions)
## Permissions
Choose the permission or permissions marked as least privileged for this API. Use a higher privileged permission or permissions [only if your app requires it](https://learn.microsoft.com/en-us/graph/permissions-overview#best-practices-for-using-microsoft-graph-permissions). For details about delegated and application permissions, see [Permission types](https://learn.microsoft.com/en-us/graph/permissions-overview#permission-types). To learn more about these permissions, see the [permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference).
Expand table
Permission type | Least privileged permissions | Higher privileged permissions
---|---|---
Delegated (work or school account) | Calendars.Read | Calendars.ReadBasic, Calendars.ReadWrite
Delegated (personal Microsoft account) | Calendars.Read | Calendars.ReadBasic, Calendars.ReadWrite
Application | Calendars.Read | Calendars.ReadBasic, Calendars.ReadWrite
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#http-request)
## HTTP request
HTTP
Copy
```
GET /me/calendarView/delta?startDateTime={start_datetime}&endDateTime={end_datetime}
GET /users/{id}/calendarView/delta?startDateTime={start_datetime}&endDateTime={end_datetime}


```

[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#query-parameters)
## Query parameters
Tracking changes in events incurs a round of one or more **delta** function calls. If you use any query parameter (other than `$deltatoken` and `$skiptoken`), you must specify it in the initial **delta** request. Microsoft Graph automatically encodes any specified parameters into the token portion of the `@odata.nextLink` or `@odata.deltaLink` URL provided in the response. You only need to specify any desired query parameters once upfront. In subsequent requests, simply copy and apply the `@odata.nextLink` or `@odata.deltaLink` URL from the previous response, as that URL already includes the encoded, desired parameters.
Expand table
Query parameter | Type | Description
---|---|---
startDateTime | String | The start date and time of the time range, represented in ISO 8601 format. For example, "2015-11-08T19:00:00.0000000".
endDateTime | String | The end date and time of the time range, represented in ISO 8601 format. For example, "2015-11-08T20:00:00.0000000".
$deltatoken | string | A [state token](https://learn.microsoft.com/en-us/graph/delta-query-overview) returned in the `@odata.deltaLink` URL of the previous **delta** function call for the same calendar view, indicating the completion of that round of change tracking. Save and apply the entire `@odata.deltaLink` URL including this token in the first request of the next round of change tracking for that calendar view.
$skiptoken | string | A [state token](https://learn.microsoft.com/en-us/graph/delta-query-overview) returned in the `@odata.nextLink` URL of the previous **delta** function call, indicating there are further changes to be tracked in the same calendar view.
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#odata-query-parameters)
### OData query parameters
  * Expect a **delta** function call on a **calendarView** to return the same properties you'd normally get from a `GET /calendarView` request. You cannot use `$select` to get only a subset of those properties.
  * There are other OData query parameters that the **delta** function for **calendarView** doesn't support: `$expand`, `$filter`,`$orderby`, and `$search`.


[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#request-headers)
## Request headers
Expand table
Name | Type | Description
---|---|---
Authorization | string | Bearer {token}. Required. Learn more about [authentication and authorization](https://learn.microsoft.com/en-us/graph/auth/auth-concepts).
Content-Type | string | application/json. Required.
Prefer | string | odata.maxpagesize={x}. Optional.
Prefer | string | {Time zone}. Optional, UTC assumed if absent.
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#response)
## Response
If successful, this method returns a `200 OK` response code and [event](https://learn.microsoft.com/en-us/graph/api/resources/event?view=graph-rest-1.0) collection object in the response body.
Within a round of **delta** function calls bound by the date range of a **calendarView** , you may find a **delta** call returning two types of events under `@removed` with the reason `deleted`:
  * Events that are within the date range and that have been deleted since the previous **delta** call.
  * Events that are _outside_ the date range and that have been added, deleted, or updated since the previous **delta** call.


Filter the events under `@removed` for the date range that your scenario requires.
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#example)
## Example
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#request)
##### Request
The following example shows how to make a single **delta** function call, and limit the maximum number of events in the response body to 2.
To track changes in a calendar view, you would make one or more **delta** function calls, with appropriate [state tokens](https://learn.microsoft.com/en-us/graph/delta-query-overview), to get the set of incremental changes since the last delta query.
  * [HTTP](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_http)
  * [C#](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_csharp)
  * [Go](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_go)
  * [Java](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_java)
  * [JavaScript](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_javascript)
  * [PHP](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_php)
  * [Python](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#tabpanel_1_python)


msgraph
Copy Try It
```
GET https://graph.microsoft.com/v1.0/me/calendarView/delta?startdatetime={start_datetime}&enddatetime={end_datetime}
Prefer: odata.maxpagesize=2


```

C#
Copy
```

// Code snippets are only available for the latest version. Current version is 5.x

// To initialize your graphClient, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=csharp
var result = await graphClient.Me.CalendarView.Delta.GetAsDeltaGetResponseAsync((requestConfiguration) =>
{
	requestConfiguration.QueryParameters.StartDateTime = "{start_datetime}";
	requestConfiguration.QueryParameters.EndDateTime = "{end_datetime}";
	requestConfiguration.Headers.Add("Prefer", "odata.maxpagesize=2");
});



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Go
Copy
```


// Code snippets are only available for the latest major version. Current major version is $v1.*

// Dependencies
import (
	  "context"
	  abstractions "github.com/microsoft/kiota-abstractions-go"
	  msgraphsdk "github.com/microsoftgraph/msgraph-sdk-go"
	  graphusers "github.com/microsoftgraph/msgraph-sdk-go/users"
	  //other-imports
)

headers := abstractions.NewRequestHeaders()
headers.Add("Prefer", "odata.maxpagesize=2")


requestStartDateTime := "{start_datetime}"
requestEndDateTime := "{end_datetime}"

requestParameters := &graphusers.CalendarViewDeltaRequestBuilderGetQueryParameters{
	StartDateTime: &requestStartDateTime,
	EndDateTime: &requestEndDateTime,
}
configuration := &graphusers.CalendarViewDeltaRequestBuilderGetRequestConfiguration{
	Headers: headers,
	QueryParameters: requestParameters,
}

// To initialize your graphClient, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=go
delta, err := graphClient.Me().CalendarView().Delta().GetAsDeltaGetResponse(context.Background(), configuration)



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Java
Copy
```

// Code snippets are only available for the latest version. Current version is 6.x

GraphServiceClient graphClient = new GraphServiceClient(requestAdapter);

var result = graphClient.me().calendarView().delta().get(requestConfiguration -> {
	requestConfiguration.queryParameters.startDateTime = "{start_datetime}";
	requestConfiguration.queryParameters.endDateTime = "{end_datetime}";
	requestConfiguration.headers.add("Prefer", "odata.maxpagesize=2");
});



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
JavaScript
Copy
```

const options = {
	authProvider,
};

const client = Client.init(options);

let delta = await client.api('/me/calendarView/delta?startdatetime={start_datetime}&enddatetime={end_datetime}')
	.header('Prefer','odata.maxpagesize=2')
	.get();


```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
PHP
Copy
```

<?php
use Microsoft\Graph\GraphServiceClient;
use Microsoft\Graph\Generated\Users\Item\CalendarView\Delta\DeltaRequestBuilderGetRequestConfiguration;


$graphServiceClient = new GraphServiceClient($tokenRequestContext, $scopes);

$requestConfiguration = new DeltaRequestBuilderGetRequestConfiguration();
$headers = [
		'Prefer' => 'odata.maxpagesize=2',
	];
$requestConfiguration->headers = $headers;

$queryParameters = DeltaRequestBuilderGetRequestConfiguration::createQueryParameters();
$queryParameters->startDateTime = "{start_datetime}";
$queryParameters->endDateTime = "{end_datetime}";
$requestConfiguration->queryParameters = $queryParameters;


$result = $graphServiceClient->me()->calendarView()->delta()->get($requestConfiguration)->wait();


```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Python
Copy
```

# Code snippets are only available for the latest version. Current version is 1.x
from msgraph import GraphServiceClient
from msgraph.generated.users.item.calendar_view.delta.delta_request_builder import DeltaRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
# To initialize your graph_client, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=python
query_params = DeltaRequestBuilder.DeltaRequestBuilderGetQueryParameters(
		start_date_time = "{start_datetime}",
		end_date_time = "{end_datetime}",
)

request_configuration = RequestConfiguration(
query_parameters = query_params,
)
request_configuration.headers.add("Prefer", "odata.maxpagesize=2")


result = await graph_client.me.calendar_view.delta.get(request_configuration = request_configuration)



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#response-1)
##### Response
If the request is successful, the response would include a state token, which is either a _skipToken_ (in an _@odata.nextLink_ response header) or a _deltaToken_ (in an _@odata.deltaLink_ response header). Respectively, they indicate whether you should continue with the round or you have completed getting all the changes for that round.
The response below shows a _skipToken_ in an _@odata.nextLink_ response header.
Note: The response object shown here might be shortened for readability.
HTTP
Copy
```
HTTP/1.1 200 OK
Content-type: application/json

{
  "@odata.nextLink":"https://graph.microsoft.com/v1.0/me/calendarView/delta?$skiptoken={_skipToken_}",
  "value": [
    {
      "originalStartTimeZone": "originalStartTimeZone-value",
      "originalEndTimeZone": "originalEndTimeZone-value",
      "responseStatus": {
        "response": "response-value",
        "time": "datetime-value"
      },
      "transactionId": null,
      "iCalUId": "iCalUId-value",
      "reminderMinutesBeforeStart": 99,
      "isDraft": false,
      "isReminderOn": true
    }
  ]
}

```

[](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#related-content)
## Related content
  * [Use delta query to track changes in Microsoft Graph data](https://learn.microsoft.com/en-us/graph/delta-query-overview)
  * [Get incremental changes to events in a calendar](https://learn.microsoft.com/en-us/graph/delta-query-events)


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 24, 7 PM - Feb 24, 7 PM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 06/21/2024


##  In this article
  1. [Permissions](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#permissions)
  2. [HTTP request](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#http-request)
  3. [Query parameters](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#query-parameters)
  4. [Request headers](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#request-headers)
  5. [Response](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#response)
  6. [Example](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#example)
  7. [Related content](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http#related-content)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/event-delta?view=graph-rest-1.0&tabs=http)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fevent-delta%3Fview%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
