[ Skip to main content ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/?id=aHR0cHM6Ly9hdXRob3JpbmctZG9jcy1taWNyb3NvZnQucG9vbHBhcnR5LmJpei9kZXZyZWwvNDY0YmNiZDgtNWNjNy00ODAxLWI3MzctYTlkM2M2Mzc3Y2Uy&styleGuideLabel=Outlook)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
Microsoft Q&A
#  Outlook
151,889 questions
A Microsoft application for managing email, calendars, contacts, and tasks across devices and platforms.
Sign in to follow  Follow
Filters
## Filter
* * *
### Content
[ All questions 151.9K  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=null) [ No answers 2.9K  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=unanswered) [ Has answers 148.9K  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=answered) [ No answers or comments 1.9K  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=withoutengagement) [ With accepted answer 24.5K  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=withacceptedanswer) [ With recommended answer 69  ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?filterby=withrecommendedanswer)
##  151,889 questions with Outlook-related tags
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?orderby=answercount&page=1)
1 answer
##  [ I can't see any of my SAVED email folders in the Outlook Android App on my phone ](https://learn.microsoft.com/en-us/answers/questions/5787333/i-cant-see-any-of-my-saved-email-folders-in-the-ou)
I am new to Outlook, having migrated over from Gmail. I have successfully linked my Gmail and Comcast email accounts using IMAP. On the PC app, I can see my saved folders, although they seem to work differently than they do on Gmail or Xfinity.…
Outlook | Outlook for mobile | Outlook for Android | For home
[ Outlook | Outlook for mobile | Outlook for Android | For home ](https://learn.microsoft.com/en-us/answers/tags/1427/office-outlook-outlook-mobile-platform-outlook-android-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
1,911 questions
Sign in to follow  Follow
asked Feb 24, 2026, 7:20 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(147.20000000000002,%2065%,%2024%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESW%3C/text%3E%3C/svg%3E)
[Scott Wyatt](https://learn.microsoft.com/en-us/users/na/?userid=b4eb6654-cce3-478a-9526-4c7605f25c8c) 0 Reputation points
answered Feb 24, 2026, 7:20 PM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
2 answers
##  [ My Outlook Not Receiving Emails in Office 365 ](https://learn.microsoft.com/en-us/answers/questions/5786445/my-outlook-not-receiving-emails-in-office-365)
Hi everyone, my Outlook with Office 365 suddenly stopped receiving new emails, even though it shows connected. I’ve tried restarting, checking filters, and updating settings but nothing worked. Has anyone faced this before or knows how to fix it? I need…
Outlook | Windows | New Outlook for Windows | For home
[ Outlook | Windows | New Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1551/office-outlook-platform-windows-new-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
10,674 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:48 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%2047%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ERR%3C/text%3E%3C/svg%3E)
[Roger Reed](https://learn.microsoft.com/en-us/users/na/?userid=dc864731-128c-4816-8653-3e486ac95f2f) 320 Reputation points
answered Feb 24, 2026, 7:19 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2040%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWB%3C/text%3E%3C/svg%3E)
[Winnie-B](https://learn.microsoft.com/en-us/users/na/?userid=f07b4d01-fda0-46c2-b967-7bbe30342586) 5,925 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ api-ms-win-core-winrt-l1-1-0.dll error ](https://learn.microsoft.com/en-us/answers/questions/5782922/api-ms-win-core-winrt-l1-1-0-dll-error)
I spent several hours to resolve this "error" - now 100% resolved. I am a Win 7 user - Win 10 is too invasive and as for Win 11 - don't even think about it :). I kept getting this error - followed all online suggestions, to no avail. Finally ,…
Outlook | Windows | Classic Outlook for Windows | For home
[ Outlook | Windows | Classic Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1177/office-outlook-platform-windows-classic-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
30,391 questions
Sign in to follow  Follow
asked Feb 20, 2026, 9:03 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(179.20000000000002,%2079%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPE%3C/text%3E%3C/svg%3E)
[Pet er](https://learn.microsoft.com/en-us/users/na/?userid=c5d67bde-9e1c-40a9-8421-6cfb5803d375) 130 Reputation points
commented Feb 24, 2026, 7:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(179.20000000000002,%2079%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPE%3C/text%3E%3C/svg%3E)
[Pet er](https://learn.microsoft.com/en-us/users/na/?userid=c5d67bde-9e1c-40a9-8421-6cfb5803d375) 130 Reputation points
2 answers
##  [ My email account has been hacked ](https://learn.microsoft.com/en-us/answers/questions/5787286/my-email-account-has-been-hacked)
Some of my contacts have been receiving scam emails from my email account.
Outlook | Windows | Classic Outlook for Windows | For home
[ Outlook | Windows | Classic Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1177/office-outlook-platform-windows-classic-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
30,391 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:30 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(214.4,%200%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECG%3C/text%3E%3C/svg%3E)
[Carl Gellis](https://learn.microsoft.com/en-us/users/na/?userid=cff6d700-1b52-4afd-9d80-2377e8f58062) 0 Reputation points
answered Feb 24, 2026, 7:05 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/YpKGkv-jdk2rXWEa6zPz5A.png?8DDCD1)
[John Jefferson Doyon](https://learn.microsoft.com/en-us/users/na/?userid=92869262-a3ff-4d76-ab5d-611aeb33f3e4) 59,725 Reputation points • Independent Advisor
1 answer
##  [ My Outlook email account was hacked. Now all of my contacts are missing from Outlook. ](https://learn.microsoft.com/en-us/answers/questions/5787311/my-outlook-email-account-was-hacked-now-all-of-my)
My email was hacked last Tuesday, 2/17. The person in Nigeria sent a phishing email to everyone in my contacts. I noticed today 2/24 that I no longer have Contacts in my Outlook account. I think it must be connected. How do I recover my outlook…
Outlook | MacOS | New Outlook for Mac | For home
[ Outlook | MacOS | New Outlook for Mac | For home ](https://learn.microsoft.com/en-us/answers/tags/1371/office-outlook-macos-new-outlook-mac-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
1,441 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:58 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(28.799999999999997,%2017%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ELF%3C/text%3E%3C/svg%3E)
[Lucille FAREWELL](https://learn.microsoft.com/en-us/users/na/?userid=cebc091a-aae7-4de2-853c-bea77d71bec7) 0 Reputation points
answered Feb 24, 2026, 6:58 PM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
2 answers
##  [ I re-install windows in my pc and then i cannot login in outlook app ](https://learn.microsoft.com/en-us/answers/questions/5786117/i-re-install-windows-in-my-pc-and-then-i-cannot-lo)
Please help check the error message. [Moderator note: personal info removed] Doese it mean that i need to update my windows? In addition, when i login office365 in Edge, the error occurs, but in other browser, i could login.
Outlook | Windows | New Outlook for Windows | For business
[ Outlook | Windows | New Outlook for Windows | For business ](https://learn.microsoft.com/en-us/answers/tags/1214/office-outlook-platform-windows-new-outlook-windows-business/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
11,499 questions
Sign in to follow  Follow
asked Feb 24, 2026, 1:10 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(121.6,%201%,%2021%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EZ%3C/text%3E%3C/svg%3E)
[Zoe](https://learn.microsoft.com/en-us/users/na/?userid=c3fd8e01-df9f-46cd-b329-743d05133647) 20 Reputation points
commented Feb 24, 2026, 6:55 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(121.6,%201%,%2021%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EZ%3C/text%3E%3C/svg%3E)
[Zoe](https://learn.microsoft.com/en-us/users/na/?userid=c3fd8e01-df9f-46cd-b329-743d05133647) 20 Reputation points
1 answer
##  [ "Mark as read" settings automatically reverting ](https://learn.microsoft.com/en-us/answers/questions/5787251/mark-as-read-settings-automatically-reverting)
02/24/2026 I do not want email messages marked as read until i maually change them. I uncheck that option in the mail settings and save (see image). When I go back to my inbox it works initailly, but in a very short period of time, it reverts back to…
Outlook | Windows | New Outlook for Windows | For business
[ Outlook | Windows | New Outlook for Windows | For business ](https://learn.microsoft.com/en-us/answers/tags/1214/office-outlook-platform-windows-new-outlook-windows-business/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
11,499 questions
Sign in to follow  Follow
asked Feb 24, 2026, 5:35 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(211.20000000000002,%2012%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPS%3C/text%3E%3C/svg%3E)
[Pam Stinnett](https://learn.microsoft.com/en-us/users/na/?userid=d6f61bc2-2939-4418-b848-77cae877e854) 0 Reputation points
answered Feb 24, 2026, 6:52 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(124.80000000000001,%2050%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDN%3C/text%3E%3C/svg%3E)
[Darren-Ng](https://learn.microsoft.com/en-us/users/na/?userid=3c95a0df-f4b1-45b0-b95a-f8db1c2e1470) 8,095 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ @outlook.com emails ](https://learn.microsoft.com/en-us/answers/questions/5787278/@outlook-com-emails)
Hi, I use Microsoft Outlook to send and receive emails. This works for most email addresses, however when I send an email to a "@outlook" address it bounces. Can you please advise how this can be fixed. thank you
Outlook | Windows | Classic Outlook for Windows | For home
[ Outlook | Windows | Classic Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1177/office-outlook-platform-windows-classic-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
30,391 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:16 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(134.4,%2018%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJA%3C/text%3E%3C/svg%3E)
[Jo Ann Hanley](https://learn.microsoft.com/en-us/users/na/?userid=4218d2f9-4b29-4c90-ad57-5165756fa96a) 0 Reputation points
answered Feb 24, 2026, 6:48 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/KAa___tGiUSx1xzs5mTSMQ.png?8DDA86)
[EmilyS726](https://learn.microsoft.com/en-us/users/na/?userid=ffbf0628-46fb-4489-b1d7-1cece664d231) 208.3K Reputation points • Independent Advisor
2 answers
##  [ Not receiving incoming emails in my Outlook ](https://learn.microsoft.com/en-us/answers/questions/5787275/not-receiving-incoming-emails-in-my-outlook)
Hi, I recently created a ticket for my issue (https://learn.microsoft.com/en-us/answers/questions/5782807/outlook-not-receiving-incoming-emails?comment=answer-12606944&page=1#comment-2525313) but is it possible to create a ticket to have a specialist…
Outlook | Windows | Classic Outlook for Windows | For business
[ Outlook | Windows | Classic Outlook for Windows | For business ](https://learn.microsoft.com/en-us/answers/tags/332/office-outlook-platform-windows-classic-outlook-windows-business/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
28,737 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:10 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(214.4,%202%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKC%3C/text%3E%3C/svg%3E)
[Kareem Culbertson](https://learn.microsoft.com/en-us/users/na/?userid=cd670232-725b-4224-be80-104b12b4bd47) 90 Reputation points
edited an answer Feb 24, 2026, 6:47 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(297.6,%203%,%2038%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EVV%3C/text%3E%3C/svg%3E)
[Vergil-V](https://learn.microsoft.com/en-us/users/na/?userid=93bee03b-0c02-4802-8887-fb56e1f1a188) 9,765 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Email hack ](https://learn.microsoft.com/en-us/answers/questions/5785260/email-hack)
My email was hacked. I have managed to change the password, but I can't update my 2 step verification for 30 days for security reasons. My recovery phone is no longer in service and I can't get into my email. The hackers have redirected it to them.
Outlook | Web | Outlook.com | Account management, security, and privacy
[ Outlook | Web | Outlook.com | Account management, security, and privacy ](https://learn.microsoft.com/en-us/answers/tags/1466/office-outlook-web-outlook-dotcom-outlook-account/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
20,459 questions
Sign in to follow  Follow
asked Feb 23, 2026, 10:17 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(268.8,%2067%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJM%3C/text%3E%3C/svg%3E)
[Jo Matthews](https://learn.microsoft.com/en-us/users/na/?userid=84b676ea-c128-4523-a3b9-8a0d92e54399) 0 Reputation points
edited an answer Feb 24, 2026, 6:41 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2040%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWB%3C/text%3E%3C/svg%3E)
[Winnie-B](https://learn.microsoft.com/en-us/users/na/?userid=f07b4d01-fda0-46c2-b967-7bbe30342586) 5,925 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ Mail rule exception for Send on Behalf messages ](https://learn.microsoft.com/en-us/answers/questions/5786626/mail-rule-exception-for-send-on-behalf-messages)
Hello I have a rule set up in Exchange > Mail Flow > Rules to add a disclaimer to all emails from members of a specific group. That is working. As part of that rule, I have an exception to not add the disclaimer if a specific word appears in the…
Outlook | Web | Outlook on the web for business | Email
[ Outlook | Web | Outlook on the web for business | Email ](https://learn.microsoft.com/en-us/answers/tags/1399/office-outlook-web-outlook-web-business-email/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
2,524 questions
Sign in to follow  Follow
asked Feb 24, 2026, 9:29 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(54.400000000000006,%2086%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDR%3C/text%3E%3C/svg%3E)
[Denis Repp](https://learn.microsoft.com/en-us/users/na/?userid=a1f78aee-bea6-45f2-8aac-7ec73d71420f) 20 Reputation points
commented Feb 24, 2026, 6:36 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(54.400000000000006,%2086%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDR%3C/text%3E%3C/svg%3E)
[Denis Repp](https://learn.microsoft.com/en-us/users/na/?userid=a1f78aee-bea6-45f2-8aac-7ec73d71420f) 20 Reputation points
4 answers
##  [ Why do I have to create an Outlook.com account now when I already have (and have had) a Microsoft Account that I've used with Outlook Online. ](https://learn.microsoft.com/en-us/answers/questions/5511267/why-do-i-have-to-create-an-outlook-com-account-now)
Previously I could go to outlook.com, sign in with my Microsoft account (personal M365 subscription), and access the Outlook online web app. In the past few weeks when I've tried that, I'm met with this message: You need to create an Outlook.com email…
Outlook | Web | Outlook.com | Account management, security, and privacy
[ Outlook | Web | Outlook.com | Account management, security, and privacy ](https://learn.microsoft.com/en-us/answers/tags/1466/office-outlook-web-outlook-dotcom-outlook-account/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
20,459 questions
Sign in to follow  Follow
asked Aug 1, 2025, 1:55 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(160,%2021%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDJ%3C/text%3E%3C/svg%3E)
[David Jordan](https://learn.microsoft.com/en-us/users/na/?userid=5ccfefe0-2160-47fd-aaac-7cd6552b33ba) 35 Reputation points
commented Feb 24, 2026, 6:31 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(172.8,%2031%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWZ%3C/text%3E%3C/svg%3E)
[William Zaggle](https://learn.microsoft.com/en-us/users/na/?userid=5e4319ed-4154-4e01-9003-a70a83bc7eb1) 0 Reputation points
2 answers
##  [ Change verifiaction info ](https://learn.microsoft.com/en-us/answers/questions/5777629/change-verifiaction-info)
I need to remove an email and phone number assocaited with my account. I cant log in because the phone number they are using to verify I no longer have accesss to
Outlook | Web | Outlook.com | Account management, security, and privacy
[ Outlook | Web | Outlook.com | Account management, security, and privacy ](https://learn.microsoft.com/en-us/answers/tags/1466/office-outlook-web-outlook-dotcom-outlook-account/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
20,459 questions
Sign in to follow  Follow
asked Feb 16, 2026, 11:39 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(246.4,%2036%,%2033%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJS%3C/text%3E%3C/svg%3E)
[John Snyder](https://learn.microsoft.com/en-us/users/na/?userid=aa773f69-0562-4f5a-9938-07a7641d3ec2) 0 Reputation points
commented Feb 24, 2026, 6:25 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(156.8,%2031%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECL%3C/text%3E%3C/svg%3E)
[Chloe-L](https://learn.microsoft.com/en-us/users/na/?userid=493c1875-d6a8-4c10-a6c2-d11254294402) 9,590 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Transfer ownership of scheduled meetings ](https://learn.microsoft.com/en-us/answers/questions/5787158/transfer-ownership-of-scheduled-meetings)
How do I change ownership of scheduled meetings without sending cancelation and new notices to all recipients?
Outlook | Web | Outlook on the web for business | Calendar
[ Outlook | Web | Outlook on the web for business | Calendar ](https://learn.microsoft.com/en-us/answers/tags/1182/office-outlook-web-outlook-web-business-calendar/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
800 questions
Sign in to follow  Follow
asked Feb 24, 2026, 3:53 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(288,%2083%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGV%3C/text%3E%3C/svg%3E)
[Gubata, Vicky@DTSC](https://learn.microsoft.com/en-us/users/na/?userid=9b08a34b-1049-49a6-aa65-20ecbac65144) 0 Reputation points
edited an answer Feb 24, 2026, 6:17 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(204.8,%201%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJN%3C/text%3E%3C/svg%3E)
[Jade Ng](https://learn.microsoft.com/en-us/users/na/?userid=ebdb64a0-1638-42b8-803b-0276210b81e8) 9,270 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ When I go to File > Delegate Access in Outlook, I receive an error stating: "The delegate page is not available. Cannot access Outlook folder." Additionally, when I try to open Manage Rules under the File menu, I get the following message: "The rules on ](https://learn.microsoft.com/en-us/answers/questions/4377151/when-i-go-to-file-\)-delegate-access-in-outlook-i-r)
When I go to File > Delegate Access in Outlook, I receive an error stating: "The delegate page is not available. Cannot access Outlook folder." Additionally, when I try to open Manage Rules under the File menu, I get the following message:…
Outlook | Web | Outlook on the web for business | Email
[ Outlook | Web | Outlook on the web for business | Email ](https://learn.microsoft.com/en-us/answers/tags/1399/office-outlook-web-outlook-web-business-email/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
2,524 questions
Sign in to follow  Follow
asked Jul 17, 2025, 7:21 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(300.8,%2045%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMR%3C/text%3E%3C/svg%3E)
[mary rebecca](https://learn.microsoft.com/en-us/users/na/?userid=9445120a-145c-42ba-b41f-d0469845d3a6) 0 Reputation points
answered Feb 24, 2026, 6:17 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/LO4H44jPMUS0tz2sI-UPrQ.png?8DC537)
[Les](https://learn.microsoft.com/en-us/users/na/?userid=e307ee2c-cf88-4431-b4b7-3dac23e50fad) 26 Reputation points
3 answers
##  [ Pin feature missing on one of my email accounts, but not the other?? ](https://learn.microsoft.com/en-us/answers/questions/5775200/pin-feature-missing-on-one-of-my-email-accounts-bu)
the pin feature is missing on one of my email accounts but not on the other. This just happened this week- how do I restore it?
Outlook | Windows | Classic Outlook for Windows | For home
[ Outlook | Windows | Classic Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1177/office-outlook-platform-windows-classic-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
30,391 questions
Sign in to follow  Follow
asked Feb 13, 2026, 4:04 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(163.2,%2073%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESD%3C/text%3E%3C/svg%3E)
[Susan Dominica](https://learn.microsoft.com/en-us/users/na/?userid=be51db73-1db0-40f0-86b3-0ad0fa00d5b9) 0 Reputation points
answered Feb 24, 2026, 6:15 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(208,%2057.99999999999999%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAN%3C/text%3E%3C/svg%3E)
[Alice-N](https://learn.microsoft.com/en-us/users/na/?userid=6bf55823-0e3a-4eea-b6e0-dad37e18eddc) 6,995 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ junk mail auto delete ](https://learn.microsoft.com/en-us/answers/questions/5731288/junk-mail-auto-delete)
How do I stop Outlook from automatically deleting Junk emails
Outlook | Web | Outlook on the web for business | Email
[ Outlook | Web | Outlook on the web for business | Email ](https://learn.microsoft.com/en-us/answers/tags/1399/office-outlook-web-outlook-web-business-email/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
2,524 questions
Sign in to follow  Follow
asked Jan 21, 2026, 5:56 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(268.8,%2065%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESG%3C/text%3E%3C/svg%3E)
[STEVE GARD](https://learn.microsoft.com/en-us/users/na/?userid=846f5c0e-0186-4f1c-82a7-416f1809e3d2) 0 Reputation points
edited a comment Feb 24, 2026, 6:05 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(28.799999999999997,%2083%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESN%3C/text%3E%3C/svg%3E)
[Sophie N](https://learn.microsoft.com/en-us/users/na/?userid=0a98b32d-51f4-4934-ab43-7dac13ec5572) 11,910 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Can't use Outlook API ](https://learn.microsoft.com/en-us/answers/questions/5784420/cant-use-outlook-api)
Hi, I'm trying to access my personal outlook emails with my program but it seems I don't have the access. When I try to log into entra.microsoft.com, I got the following message: Sign-in failed Error code: interaction_required Error message:…
Outlook | Windows | New Outlook for Windows | For business
[ Outlook | Windows | New Outlook for Windows | For business ](https://learn.microsoft.com/en-us/answers/tags/1214/office-outlook-platform-windows-new-outlook-windows-business/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
11,499 questions
Sign in to follow  Follow
asked Feb 22, 2026, 6:28 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(160,%2089%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ELG%3C/text%3E%3C/svg%3E)
[Lu Gan](https://learn.microsoft.com/en-us/users/na/?userid=5089356e-8b5c-4545-9070-386872289675) 0 Reputation points
edited the question Feb 24, 2026, 6:04 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(124.80000000000001,%2050%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDN%3C/text%3E%3C/svg%3E)
[Darren-Ng](https://learn.microsoft.com/en-us/users/na/?userid=3c95a0df-f4b1-45b0-b95a-f8db1c2e1470) 8,095 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How to sign work account back into Outlook and Authenticator app. ](https://learn.microsoft.com/en-us/answers/questions/5786990/how-to-sign-work-account-back-into-outlook-and-aut)
So I recently got a new iPhone, and when the image on my old phone transferred to my new phone, I was logged out of both my Authenticator app and outlook app for my work accounts, and it won’t show up as an existing account in either app to sign back in…
Outlook | Outlook for mobile | Outlook for iOS | For business
[ Outlook | Outlook for mobile | Outlook for iOS | For business ](https://learn.microsoft.com/en-us/answers/tags/1229/office-outlook-outlook-mobile-platform-outlook-ios-business/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
5,383 questions
Sign in to follow  Follow
asked Feb 24, 2026, 1:34 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(284.8,%2066%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EHA%3C/text%3E%3C/svg%3E)
[Hailey Alexandre](https://learn.microsoft.com/en-us/users/na/?userid=8966d5a6-e821-4a97-a93c-0327df0f4741) 0 Reputation points
answered Feb 24, 2026, 6:00 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(268.8,%2097%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EVH%3C/text%3E%3C/svg%3E)
[Vivian-HT](https://learn.microsoft.com/en-us/users/na/?userid=f84bf972-f9d2-4be0-a067-dd9c94a8e655) 12,270 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How to login to Minecraft successfully using outlook email ](https://learn.microsoft.com/en-us/answers/questions/5787206/how-to-login-to-minecraft-successfully-using-outlo)
When trying to log into Minecraft using my email @outlook.com, I get the error: "Please retry with a different device or other authentication method to sign in. For more details, please see this link". I have confirmed that my Microsoft email…
Outlook | Web | Outlook.com | Account management, security, and privacy
[ Outlook | Web | Outlook.com | Account management, security, and privacy ](https://learn.microsoft.com/en-us/answers/tags/1466/office-outlook-web-outlook-dotcom-outlook-account/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
20,459 questions
Sign in to follow  Follow
asked Feb 24, 2026, 4:43 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(288,%2031%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWB%3C/text%3E%3C/svg%3E)
[William Burger](https://learn.microsoft.com/en-us/users/na/?userid=90f31f69-6a4d-4255-94c6-0cd0ddb21b48) 0 Reputation points
edited the question Feb 24, 2026, 5:55 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/DSq8thXX1EC7bjdlrVIvlQ.png?8DE168)
[Gérard Oomens](https://learn.microsoft.com/en-us/users/na/?userid=b6bc2a0d-d715-40d4-bb6e-3765ad522f95) 118.7K Reputation points • Volunteer Moderator
  * [ ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=4)
  * ...
  * [ 7595 ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=7595)
  * [ ](https://learn.microsoft.com/en-us/answers/tags/778/office-outlook?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Ftags%2F778%2Foffice-outlook)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
