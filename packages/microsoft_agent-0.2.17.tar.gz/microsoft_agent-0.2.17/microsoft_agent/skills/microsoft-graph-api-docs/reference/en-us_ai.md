[ Skip to main content ](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader)
[ AI  ](https://learn.microsoft.com/en-us/ai/)
  * AI documentation
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/azure/ai-foundry/)
    * [ Azure OpenAI ](https://learn.microsoft.com/en-us/azure/ai-services/openai/?wt.mc_id=aihub_openaidocs_webpage_cnl)
    * [ Azure AI Search ](https://learn.microsoft.com/en-us/azure/azure/search/?wt.mc_id=aihub_AISearchdocs_webpage_cnl)
    * [ Azure AI for Developers ](https://learn.microsoft.com/en-us/azure/developer/ai/?wt.mc_id=aihub_AIDevsdocs_webpage_cnl)
    * [ AI apps for .NET developers ](https://learn.microsoft.com/en-us/dotnet/ai/?wt.mc_id=aihub_NETdocs_webpage_cnl)
    * [ Microsoft Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/?wt.mc_id=aihub_studiodocs_webpage_cnl)
    * [ GitHub Copilot for Azure ](https://learn.microsoft.com/en-us/azure/developer/github-copilot-azure/)
    * [ Azure for Developers ](https://learn.microsoft.com/en-us/azure/developer/?wt.mc_id=aihub_AzDevsdocs_webpage_cnl)
    * [ Windows AI ](https://learn.microsoft.com/en-us/windows/ai/)
  * AI training
    * [ Training for AI engineers ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer)
    * [ Training for Data Scientists ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist)
    * [ AI for Education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education)
    * [ Browse all AI training ](https://learn.microsoft.com/en-us/training/browse/?resource_type=learning%20path&expanded=data-ai&subjects=artificial-intelligence)
  * AI frameworks
    * [ Cloud Adoption Framework ](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/strategy/inform/ai)
    * [ HAX Toolkit ](https://www.microsoft.com/en-us/research/project/hax-toolkit/)
    * [ Microsoft Agent Framework ](https://learn.microsoft.com/en-us/agent-framework/)
  * AI resources
    * [ AI for developers ](https://developer.microsoft.com/en-us/ai?wt.mc_id=aihub_aidevelopers_webpage_wwl)
    * Connect with AI communities
      * [ AI & ML tech communities ](https://techcommunity.microsoft.com/t5/artificial-intelligence-and/ct-p/AI)
      * [ Microsoft Foundry Discord ](https://aka.ms/azureaifoundry/discord)
      * [ Microsoft Foundry Developer Forum ](https://aka.ms/azureaifoundry/forum)
      * [ Data & AI Microsoft Learning rooms ](https://techcommunity.microsoft.com/t5/custom/page/page-id/learn?product=Data%20and%20AI)
      * [ Global AI community ](https://globalai.community/)
      * [ Microsoft 365 Copilot Community ](https://techcommunity.microsoft.com/category/microsoft365copilot/blog/microsoft365copilotblog)
      * [ Microsoft for Startups Founders Hub ](https://foundershub.startups.microsoft.com/)
    * More AI Resources
      * [ AI at Microsoft ](https://www.microsoft.com/ai)
      * [ AI for developers ](https://developer.microsoft.com/en-us/ai?wt.mc_id=aihub_aidevelopers_webpage_wwl)
      * [ AI Skills Navigator ](https://aka.ms/AISkillsNavigator_Learn?UTM_Source=WWL&UTM_Medium=Learn&UTM_Campaign=LandingPage&UTM_Content=AISN)
      * [ Create an AI Learning Culture ](https://aka.ms/5KeyConsiderations)
      * [ Learn for Organizations ](https://aka.ms/AIforLFO)
      * [ Microsoft virtual training days ](https://aka.ms/AITrainingDays)
      * [ Training Services Partners ](https://learn.microsoft.com/en-us/credentials/support/partners)
  * AI events
    * [ Microsoft AI Tour ](https://learn.microsoft.com/en-us/ai/ai-tour/?wt.mc_id=aihub_aitour_webpage_wwl)
  * Hub extras
    * [ Top picks archive ](https://learn.microsoft.com/en-us/ai/ai-resources/featured-top-picks)
    * [ Additional resources ](https://learn.microsoft.com/en-us/ai/ai-resources)
    * Discover more
      * [ Copilot learning hub ](https://learn.microsoft.com/en-us/copilot)
      * [ Security hub ](https://learn.microsoft.com/en-us/security)
      * [ AI for startups ](https://learn.microsoft.com/en-us/startups)
  * More
    * AI documentation
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/azure/ai-foundry/)
      * [ Azure OpenAI ](https://learn.microsoft.com/en-us/azure/ai-services/openai/?wt.mc_id=aihub_openaidocs_webpage_cnl)
      * [ Azure AI Search ](https://learn.microsoft.com/en-us/azure/azure/search/?wt.mc_id=aihub_AISearchdocs_webpage_cnl)
      * [ Azure AI for Developers ](https://learn.microsoft.com/en-us/azure/developer/ai/?wt.mc_id=aihub_AIDevsdocs_webpage_cnl)
      * [ AI apps for .NET developers ](https://learn.microsoft.com/en-us/dotnet/ai/?wt.mc_id=aihub_NETdocs_webpage_cnl)
      * [ Microsoft Copilot Studio ](https://learn.microsoft.com/en-us/microsoft-copilot-studio/?wt.mc_id=aihub_studiodocs_webpage_cnl)
      * [ GitHub Copilot for Azure ](https://learn.microsoft.com/en-us/azure/developer/github-copilot-azure/)
      * [ Azure for Developers ](https://learn.microsoft.com/en-us/azure/developer/?wt.mc_id=aihub_AzDevsdocs_webpage_cnl)
      * [ Windows AI ](https://learn.microsoft.com/en-us/windows/ai/)
    * AI training
      * [ Training for AI engineers ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer)
      * [ Training for Data Scientists ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist)
      * [ AI for Education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education)
      * [ Browse all AI training ](https://learn.microsoft.com/en-us/training/browse/?resource_type=learning%20path&expanded=data-ai&subjects=artificial-intelligence)
    * AI frameworks
      * [ Cloud Adoption Framework ](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/strategy/inform/ai)
      * [ HAX Toolkit ](https://www.microsoft.com/en-us/research/project/hax-toolkit/)
      * [ Microsoft Agent Framework ](https://learn.microsoft.com/en-us/agent-framework/)
    * AI resources
      * [ AI for developers ](https://developer.microsoft.com/en-us/ai?wt.mc_id=aihub_aidevelopers_webpage_wwl)
      * Connect with AI communities
        * [ AI & ML tech communities ](https://techcommunity.microsoft.com/t5/artificial-intelligence-and/ct-p/AI)
        * [ Microsoft Foundry Discord ](https://aka.ms/azureaifoundry/discord)
        * [ Microsoft Foundry Developer Forum ](https://aka.ms/azureaifoundry/forum)
        * [ Data & AI Microsoft Learning rooms ](https://techcommunity.microsoft.com/t5/custom/page/page-id/learn?product=Data%20and%20AI)
        * [ Global AI community ](https://globalai.community/)
        * [ Microsoft 365 Copilot Community ](https://techcommunity.microsoft.com/category/microsoft365copilot/blog/microsoft365copilotblog)
        * [ Microsoft for Startups Founders Hub ](https://foundershub.startups.microsoft.com/)
      * More AI Resources
        * [ AI at Microsoft ](https://www.microsoft.com/ai)
        * [ AI for developers ](https://developer.microsoft.com/en-us/ai?wt.mc_id=aihub_aidevelopers_webpage_wwl)
        * [ AI Skills Navigator ](https://aka.ms/AISkillsNavigator_Learn?UTM_Source=WWL&UTM_Medium=Learn&UTM_Campaign=LandingPage&UTM_Content=AISN)
        * [ Create an AI Learning Culture ](https://aka.ms/5KeyConsiderations)
        * [ Learn for Organizations ](https://aka.ms/AIforLFO)
        * [ Microsoft virtual training days ](https://aka.ms/AITrainingDays)
        * [ Training Services Partners ](https://learn.microsoft.com/en-us/credentials/support/partners)
    * AI events
      * [ Microsoft AI Tour ](https://learn.microsoft.com/en-us/ai/ai-tour/?wt.mc_id=aihub_aitour_webpage_wwl)
    * Hub extras
      * [ Top picks archive ](https://learn.microsoft.com/en-us/ai/ai-resources/featured-top-picks)
      * [ Additional resources ](https://learn.microsoft.com/en-us/ai/ai-resources)
      * Discover more
        * [ Copilot learning hub ](https://learn.microsoft.com/en-us/copilot)
        * [ Security hub ](https://learn.microsoft.com/en-us/security)
        * [ AI for startups ](https://learn.microsoft.com/en-us/startups)


[ Open Microsoft Foundry Portal ](https://ai.azure.com/?cid=learnDocs) [ Get started with Azure ](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn-exp2)
![](https://learn.microsoft.com/en-us/ai/media/hero-ai-learning-hub-dark-background.png)
Microsoft Learn
# AI learning hub
Accelerate your AI learning with resources tailored for technical and business roles to support AI skill development for individuals and organizations. Find curated AI training for any level of AI fluency, like designing and customizing agents at scale with Microsoft Foundry, advancing your expertise in managing AI workloads with Microsoft 365 Copilot, unleashing your creativity and productivity with Microsoft Copilot, and more.
# Discover top picks
  * ![](https://learn.microsoft.com/en-us/azure/reusable-content/ce-skilling/azure/media/ai-services/ai-foundry.svg)
[Get started with Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry?wt.mc_id=aihub_FoundryHub_webpage_cnl)
Explore documentation to design, customize, and manage AI applications and agents at scale with Microsoft Foundry.
  * ![](https://learn.microsoft.com/en-us/ai/media/ignite-glyphs/overview-magenta.png)
[Automate your business with Foundry Agent Service](https://learn.microsoft.com/en-us/azure/ai-foundry/agents/overview?view=foundry)
Read this article and learn to orchestrate models and tools into trusted, end-to-end AI agents with Foundry Agent Service.
  * ![](https://learn.microsoft.com/en-us/ai/media/ignite-glyphs/training-1-purple.png)
[Start learning AI concepts for developers and technology professionals](https://learn.microsoft.com/en-us/training/paths/ai-concepts/)
Get a basic introduction to core AI concepts with this learning path and then dive into common AI solutions.
  * ![](https://learn.microsoft.com/en-us/ai/media/ignite-glyphs/how-to-guide-2-orange.png)
[Define a Microsoft AI strategy to create business value in nonprofit](https://learn.microsoft.com/en-us/training/modules/define-microsoft-ai-strategy-create-business-value-nonprofit)
Learn how to incorporate AI technologies that can support your nonprofit business value through this training module.


## Start with strong foundations
Build your AI fluency - learn what AI is, the services and technologies it includes, responsible AI, how you and your organization can put AI to work, and more.
  * ![](https://learn.microsoft.com/en-us/ai/media/discover-ai-fundamentals.png)
Discover AI fundamentals
[Get started](https://learn.microsoft.com/en-us/training/courses/ai-900t00)
  * ![](https://learn.microsoft.com/en-us/ai/media/learn-responsible-ai.png)
Drive AI transformation in your organization
[Get started with the course](https://learn.microsoft.com/en-us/training/courses/ab-731t00#course-syllabus)
  * ![](https://learn.microsoft.com/en-us/ai/media/introduction-to-generative-ai.png)
Get an introduction to generative AI
[Get started](https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/)
  * ![](https://learn.microsoft.com/en-us/ai/media/ai-in-your-daily-work.png)
AI in your daily work: basics for boosting productivity with Microsoft 365 Copilot
[Get started](https://learn.microsoft.com/en-us/training/paths/craft-effective-prompts-copilot-microsoft-365/)


## Expand your AI skills based on your role
Get ready to use Copilot and build AI apps. Discover the transformational experiences you can implement by using Microsoft's AI apps and services. Select a role to explore focused skilling resources.
  * [Business or technical leader](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_business-technical-leader)
  * [Business user](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_business-user)
  * [Data professional](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_data-professional)
  * [Data scientist](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_data-scientist)
  * [Developer](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_developer)
  * [IT professional](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_it-professional)
  * [Low-code developer](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_low-code-developer)
  * [Security professional](https://learn.microsoft.com/en-us/ai/?tabs=business-technical-leader#tabpanel_1_security-professional)


### Business or technical leader
**[Transform your business with Microsoft AI](https://learn.microsoft.com/en-us/training/paths/transform-your-business-with-microsoft-ai/?wt.mc_aihub_plan_transformbiz_wwl)**
In this learning path, business leaders will find the knowledge and resources to adopt AI in their organizations. Explore planning, strategizing, and scaling AI projects in a responsible way.
**[Unlock business potential with AI apps and agents](https://learn.microsoft.com/en-us/plans/pzxuztqe0kpjq)**
Start or continue your AI transformation journey with foundational Azure AI knowledge and skills, including cost management and security considerations.
**[Accelerate generative AI model selection, evaluation, and multimodal integration with Microsoft Foundry](https://learn.microsoft.com/en-us/plans/qp1rfqtpk3n7r8)**
Find out how to benchmark models, apply multimodal models to help enhance customer satisfaction, and complete evaluations to help ensure performance and safety.
**[Accelerate developer productivity with GitHub Copilot Agents](https://learn.microsoft.com/en-us/plans/j2j1fzzymrmqgw)**
This plan helps technical decision-makers evaluate AI-enhanced developer tools, improve workflow efficiency, and gain hands-on experience with GitHub Copilot.
### Business user
**[Empower your productivity and creativity with AI tools](https://learn.microsoft.com/en-us/plans/w0giztqd44m20)**
Learn to simplify tasks, boost productivity, and craft compelling presentations. Turn AI capabilities into real business value.
**[Work smarter with AI](https://learn.microsoft.com/en-us/training/paths/work-smarter-with-ai/?wt.mc_aihub_plan_fabricdp600z_wwl)**
Get more done and unleash your creativity with Microsoft Copilot. In this learning path, you'll explore how to use Microsoft Copilot to help you research, find information, and generate effective content.
### Data professional
**[Build AI-Powered data solutions with Microsoft Fabric](https://learn.microsoft.com/en-us/plans/67qnt7t3oxrwz8)**
This skilling plan helps data engineers, analysts, and developers build expertise in Microsoft Fabric, Power BI, Copilot, Data Agents, and Lakehouse. Learn to design AI-powered solutions using real-time data and advanced analytics. Develop skills to integrate, automate, and visualize data, optimize pipelines, and apply best practices in governance and security.
**[Build real-time data solutions with real-time intelligence in Microsoft Fabric](https://learn.microsoft.com/en-us/plans/pry1h173kr8r7g)**
Learn how to design, implement, and fine-tune real-time data streaming and analytics solutions using Real-Time Intelligence in Microsoft Fabric. This plan focuses on the core jobs data professionals perform to ingest, process, and analyze live data—transforming it into actionable insights that inform timely, data-driven business decisions.
**[Validate your Fabric data engineering expertise with the DP-700 Certification](https://learn.microsoft.com/en-us/plans/8q0kcztgzyd3ep)**
Build a solid understanding of Microsoft Fabric and prepare to take Exam DP-700 to earn the Fabric Data Engineer Associate Certification.
**[Run large data engineering workloads with Azure Databricks](https://learn.microsoft.com/en-us/plans/1k1nhot4666r1x)**
Build foundational knowledge, and then explore data management, pipeline automation, CI/CD workflows, and advanced techniques that help ensure the effective handling of large-scale data workloads.
**[Transform data for AI solutions with Azure Databricks](https://learn.microsoft.com/en-us/plans/7w07c8t6wz8y6p)**
Learn how to best use Azure Databricks for implementing AI and machine learning solutions. Get experience with generative AI, data transformation, pipeline implementation, and more.
**[Enhance your Microsoft Fabric analytics engineering skills: Prepare for Exam DP-600](https://learn.microsoft.com/en-us/plans/0eomt1tj6e5z17)**
Discover Microsoft Fabric and its applications in data analytics, advanced data processing, management, and Real-Time Intelligence.
### Data scientist
**[Find the best model for your generative AI solution by using Microsoft Foundry](https://learn.microsoft.com/en-us/plans/pzxuzt2oypg8n)**
Learn how to deploy models, make model selections, work with benchmarking tools, and create multimodal applications by using Microsoft Foundry and Azure OpenAI in Foundry Models.
**[Get AI-Ready with Microsoft 365 Admin](https://learn.microsoft.com/en-us/plans/2x36hj36oje7d3?wt.mc_aihub_plan_m365copadmin_wwl)**
These recommendations are for people that implement data science and machine learning solutions.
### Developer
**[Build and govern responsible AI apps and agents with Microsoft Foundry](https://learn.microsoft.com/en-us/plans/r27t2t1ezjm86)**
Design, govern, and observe AI apps and agents with security, safety, and observability capabilities.
**[Create agentic AI solutions by using Microsoft Foundry](https://learn.microsoft.com/en-us/plans/gkpa3t1o7r55g)**
Find out how to make the most of the latest agentic AI technologies and how to build and integrate AI-driven agents by using Microsoft Foundry.
### IT professional
**[Get AI-Ready with Microsoft 365 Admin](https://learn.microsoft.com/en-us/plans/odn5agtyz2nd64?wt.mc_aihub_plan_managecost_wwl)**
This content helps admins ensure that Microsoft 365 tenants are set up and configured for AI so that future AI features can be integrated as seamlessly as possible.
**[Discover Microsoft 365 Copilot (for administrators)](https://learn.microsoft.com/en-us/plans/odn5agtyz2nd64?wt.mc_aihub_plan_optazuraienv_wwl)**
Focus on security and compliance features to configure in your Microsoft 365 tenant to help protect your organizational data before you implement Microsoft 365 Copilot.
**[Preparing for your organization's AI workloads](https://learn.microsoft.com/en-us/plans/yjxkuetwe0ekq8?sharingId=6F81B482FD5357F5)**
Advance your expertise in designing, securing, and managing AI workloads on Microsoft Azure. This comprehensive plan introduces foundational AI concepts, then guides you through advanced topics.
### Low-code developer
**[Create Power Platform solutions with AI and Copilot](https://learn.microsoft.com/en-us/plans/kx1b2ty2grgzz?wt.mc_aihub_plan_devgenaiexp_wwl)**
Learn to use Copilot to set up Dataverse, create Power Apps, and build Automated Processes. Explore what Microsoft Copilot Studio can do to help you build and extend custom copilots.
**[Accelerate AI development with Low Code](https://learn.microsoft.com/en-us/plans/0k82i63zo353x5?wt.mc_aihub_plan_accgenaimod_wwl)**
Learn how to develop on Dataverse, Power Apps, and Power Automate. This curated content will also cover creation of custom copilots with Microsoft Copilot Studio.
**[Extend Microsoft 365 Copilot (for developers)](https://learn.microsoft.com/en-us/plans/d83ec1tr01jj11?sharingId=D45FAAA2C4A2253?wt.mc_aihub_plan_fabricdp700_wwl)**
Use Copilot Studio actions, and learn about building plugins and connectors for Microsoft 365 Copilot. Discover how to choose the right option for your use case.
**[Build& extend copilots with Microsoft Copilot Studio](https://learn.microsoft.com/en-us/plans/d2x5snr7w237km)**
Use Microsoft Copilot Studio to create conversational AI solutions, and learn how to build actions that extend Microsoft 365 Copilot.
### Security professional
**[Secure your data in the age of AI](https://learn.microsoft.com/en-us/plans/7wzotw2p1xg70w)**
Work with Microsoft Purview, Microsoft Sentinel, and Microsoft Copilot for Security, and learn how to effectively manage, protect, and govern sensitive information in AI-driven environments.
**[Securing AI: Protect, govern, and defend](https://learn.microsoft.com/en-us/plans/nq2bjtpp657o)**
Learn how to secure AI systems and protect sensitive data with Microsoft solutions. Gain practical skills to implement Zero Trust principles, mitigate AI-specific risks, and ensure responsible deployment across hybrid and multicloud environments.



![](https://learn.microsoft.com/en-us/ai/media/certification-banner.png)
## Discover AI credentials for every role
As AI reshapes roles, Microsoft Credentials keep pace. Earn new business-focused credentials that help you lead with AI, make better decisions, and enhance daily work.
[Browse credentials on Learn](https://learn.microsoft.com/en-us/credentials/browse/)
## Review AI documentation
Discover in-depth articles on Microsoft's AI apps and services.
  * [Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
Explore models, services, and capabilities, to safely design, customize, and manage AI applications and agents at scale.
  * [Microsoft Agent Framework](https://learn.microsoft.com/en-us/agent-framework/overview/agent-framework-overview)
Access the new open-source development kit for building AI agents and multi-agent workflows for .NET and Python.
  * [Microsoft Copilot Studio](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
Discover how to build AI-driven copilots with Microsoft Copilot Studio to quickly and simply integrate chat into your website.
  * [Azure AI for Developers](https://learn.microsoft.com/en-us/azure/developer/ai/)
Build generative AI apps on Azure using OpenAI Services.


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fai%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
