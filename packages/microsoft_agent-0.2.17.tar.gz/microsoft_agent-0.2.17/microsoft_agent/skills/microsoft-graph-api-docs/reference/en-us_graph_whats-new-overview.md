[ Skip to main content ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?view=graph-rest-1.0)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach?view=graph-rest-1.0)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments?view=graph-rest-1.0)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support?view=graph-rest-1.0)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph%2Fcontext&view=graph-rest-1.0)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services?view=graph-rest-1.0)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?view=graph-rest-1.0)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?view=graph-rest-1.0)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview?view=graph-rest-1.0)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview?view=graph-rest-1.0)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview?view=graph-rest-1.0)
  *     * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview?view=graph-rest-1.0)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services?view=graph-rest-1.0)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept?view=graph-rest-1.0)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors?view=graph-rest-1.0)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/whats-new-overview.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fwhats-new-overview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fwhats-new-overview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fwhats-new-overview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fwhats-new-overview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0) or changing directories.
Access to this page requires authorization. You can try changing directories.
# What's new in Microsoft Graph
Feedback
Summarize this article for me
##  In this article
  1. [February 2026: New and generally available](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-and-generally-available)
  2. [February 2026: New in preview only](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-in-preview-only)
  3. [January 2026: New and generally available](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-and-generally-available)
  4. [January 2026: New in preview only](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-in-preview-only)
  5. [Contribute to Microsoft Graph](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#contribute-to-microsoft-graph)
  6. [Related content](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#related-content)

Show 2 more
Microsoft Graph provides a unified programmability model that you can use to access data in Microsoft 365, Windows, and Enterprise Mobility + Security. This article provides information about what's new in Microsoft Graph APIs, documentation, SDKs, and more.
For more detailed API-level updates, see the [Microsoft Graph API changelog](https://developer.microsoft.com/graph/changelog/).
For details about previous updates to Microsoft Graph, see [Microsoft Graph what's new history](https://learn.microsoft.com/en-us/graph/whats-new-earlier).
Features in _preview_ status are subject to change without notice, and might not be promoted to generally available (GA) status. Don't use preview features in production apps.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-and-generally-available)
## February 2026: New and generally available
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#search)
### Search
  * Added the **Principal** and **principalCollection** data types to the [externalConnection](https://learn.microsoft.com/en-us/graph/graph/api/resources/resources/externalconnectors-principal) to specify as the data type people property related items in the external connection.
  * Added the **description** property to the [externalConnection properties](https://learn.microsoft.com/en-us/graph/graph/api/resources/externalconnectors-property) to be add description to the schema properties in the external connection.
  * Added more tags or semantic labels that can be added to **labels** [externalConnection property](https://learn.microsoft.com/en-us/graph/graph/api/resources/externalconnectors-property) in the external connection schema. Labels help Microsoft 365 Copilot understand the semantics of the data in the connection and provide more relevant results.
  * Added the **contentCategory** property to the [externalConnection](https://learn.microsoft.com/en-us/graph/graph/api/resources/resources/externalconnectors-externalconnection) to specify the domain category of the content associated with the external connection for improved relevance and ranking.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#files)
### Files
Updated the admin consent requirement for the following delegated permissions related to SharePoint Embedded file storage container management:
  * The `FileStorageContainerType.Manage.All` delegated permission no longer requires admin consent.
  * The `FileStorageContainerTypeReg.Manage.All` delegated permission no longer requires admin consent.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#groups)
### Groups
  * Added the **resourceBehaviorOptions** and **resourceProvisioningOptions** properties to the [group](https://learn.microsoft.com/en-us/graph/api/resources/group) resource. These properties enable you to specify group behaviors and associated resources for a Microsoft 365 group.
  * Added a known issue: For soft deleted security groups, the **securityEnabled** property returns `false` instead of `true`. To identify the group type, use the **groupTypes** property where `["Unified"]` indicates a Microsoft 365 group and an empty array (`[]`) indicates a security group. For more information, see [Get deleted item](https://learn.microsoft.com/en-us/graph/api/directory-deleteditems-get) and [List deleted items](https://learn.microsoft.com/en-us/graph/api/directory-deleteditems-list).


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#identity-and-access--identity-and-sign-in)
### Identity and access | Identity and sign-in
  * QR code authentication method in Microsoft Entra ID lets you manage the QR code authentication method for users, and how they can sign in with a QR code and PIN. The following key resources support this capability:
    * The [qrCodePinAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/qrcodepinauthenticationmethod) resource and related APIs for managing QR code PIN authentication methods for users. This single-factor authentication method is designed for frontline workers and combines a QR code with a PIN. The following related resources were also added: [qrCode](https://learn.microsoft.com/en-us/graph/api/resources/qrcode), [qrPin](https://learn.microsoft.com/en-us/graph/api/resources/qrpin), and [qrCodeImageDetails](https://learn.microsoft.com/en-us/graph/api/resources/qrcodeimagedetails).
    * The [qrCodePinAuthenticationMethodConfiguration](https://learn.microsoft.com/en-us/graph/api/resources/qrcodepinauthenticationmethodconfiguration) resource for managing the QR code authentication method policy for a tenant.
    * Updated the [authenticationMethodModes](https://learn.microsoft.com/en-us/graph/api/resources/authenticationmethodmodes) and [baseAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/baseauthenticationmethod) enumerations to add the `qrCodePin` member to support this new authentication method.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#message-trace)
### Message trace
Use the message trace API to track the flow of email messages through your Exchange Online organization. For more information, see [exchangeMessageTrace](https://learn.microsoft.com/en-us/graph/api/resources/exchangemessagetrace).
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--data-security-and-compliance)
### Security | Data security and compliance
Added the `restrictWebGrounding` member to the [dlpAction](https://learn.microsoft.com/en-us/graph/api/resources/enums-security#dlpaction-values) enumeration to support restricting web grounding actions in data loss prevention policies in Microsoft Purview.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--threat-protection)
### Security | Threat protection
Updated the admin consent requirement for the following delegated permissions related to threat submissions:
  * The `ThreatSubmission.Read` delegated permission now requires admin consent.
  * The `ThreatSubmission.ReadWrite` delegated permission now requires admin consent.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#teamwork-and-communications--administration)
### Teamwork and communications | Administration
  * [Get the policy ID](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamspolicyassignment-getpolicyid) for a given policy name and policy type within Teams administration.
  * [Assign a Teams policy](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamspolicyuserassignment-assign) to a user using the user ID, policy type, and policy ID.
  * [Unassign a Teams policy](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamspolicyuserassignment-unassign) from a user using the user ID and policy type.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-in-preview-only)
## February 2026: New in preview only
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#applications)
### Applications
Use the **requiredResourceAccess** property on [agentIdentityBlueprint](https://learn.microsoft.com/en-us/graph/api/resources/agentidentityblueprint?view=graph-rest-beta&preserve-view=true) to specify the Microsoft Graph permissions (delegated scopes and app roles) required by the agent.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#backup-storage)
### Backup storage
Users can now browse a `fastRestore` endpoint and selectively restore files and folders by creating a browse session.
The granular restore process is designed to be simple and efficient and consists of three main steps:
  * **Create a browse session**
Initiate a browse session for a specific restore point (backup snapshot).
    * You can create a [SharePoint browse session](https://learn.microsoft.com/en-us/graph/api/backuprestoreroot-post-sharepointbrowsesessions?view=graph-rest-beta&preserve-view=true) or a [OneDrive for Business browse session](https://learn.microsoft.com/en-us/graph/api/backuprestoreroot-post-onedriveforbusinessrestoresessions?view=graph-rest-beta&preserve-view=true).
  * **Browse items**
Once the session is created, the user can query it to list all backed-up items available within the browse session.
    * Results are returned as a collection of [browseQueryResponseItem](https://learn.microsoft.com/en-us/graph/api/resources/browsequeryresponseitem?view=graph-rest-beta&preserve-view=true) objects, each representing a file, folder, or other resource.
    * You can browse items within a [SharePoint browse session](https://learn.microsoft.com/en-us/graph/api/sharepointbrowsesession-browse?view=graph-rest-beta&preserve-view=true) or a [OneDrive for Business browse session](https://learn.microsoft.com/en-us/graph/api/onedriveforbusinessbrowsesession-browse?view=graph-rest-beta&preserve-view=true).
  * **Create a restore session**
Select one or more items from the browse session and initiates a restore session.
    * Only the selected items are restored to their previous state, leaving the rest of the site or drive unchanged.
    * You can create a [SharePoint granular restore session](https://learn.microsoft.com/en-us/graph/api/backuprestoreroot-post-sharepointrestoresessions?view=graph-rest-beta&preserve-view=true#example-2-create-a-granular-restore-session) or a [OneDrive for Business granular restore session](https://learn.microsoft.com/en-us/graph/api/backuprestoreroot-post-onedriveforbusinessrestoresessions?view=graph-rest-beta&preserve-view=true#example-2-create-a-granular-restore-session).


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#device-and-app-management--cloud-licensing)
### Device and app management | Cloud licensing
Use the new cloud licensing APIs to manage tenant, user, and group licensing data for Microsoft 365 services. These APIs provide programmatic access to allotments, assignments, assignment errors, subscription lifecycles, and waiting members. For more information, see [Use the cloud licensing API in Microsoft Graph (preview)](https://learn.microsoft.com/en-us/graph/api/resources/cloud-licensing-api-overview?view=graph-rest-beta&preserve-view=true).
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#files-1)
### Files
Added [driveItem: archive](https://learn.microsoft.com/en-us/graph/api/driveitem-archive?view=graph-rest-beta&preserve-view=true) and [driveItem: unarchive](https://learn.microsoft.com/en-us/graph/api/driveitem-unarchive?view=graph-rest-beta&preserve-view=true) to enable organizations to archive and unarchive [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-beta&preserve-view=true) objects.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#identity-and-access--identity-and-sign-in-1)
### Identity and access | Identity and sign-in
  * Added the [agentIdentityType](https://learn.microsoft.com/en-us/graph/api/resources/agentidentitytype?view=graph-rest-beta&preserve-view=true) enumeration to represent the type of Microsoft Entra agent identity for risk detection and management. Use the **identityType** property on the [riskyAgent](https://learn.microsoft.com/en-us/graph/api/resources/riskyagent?view=graph-rest-beta&preserve-view=true) and [agentRiskDetection](https://learn.microsoft.com/en-us/graph/api/resources/agentriskdetection?view=graph-rest-beta&preserve-view=true) resources to classify different types of agent identities.
  * Added new authentication event resources to support Just-In-Time (JIT) user migration scenarios from legacy authentication systems:
    * Use the [onPasswordSubmitListener](https://learn.microsoft.com/en-us/graph/api/resources/onpasswordsubmitlistener?view=graph-rest-beta&preserve-view=true) resource to configure authentication event listeners that trigger during password submission.
    * Use the [onPasswordSubmitCustomExtension](https://learn.microsoft.com/en-us/graph/api/resources/onpasswordsubmitcustomextension?view=graph-rest-beta&preserve-view=true) resource to configure custom extensions that validate passwords against external legacy authentication systems.
    * Use the [onPasswordSubmitHandler](https://learn.microsoft.com/en-us/graph/api/resources/onpasswordsubmithandler?view=graph-rest-beta&preserve-view=true) resource as the base type for handlers invoked during password submission events.
    * Use the [onPasswordMigrationCustomExtensionHandler](https://learn.microsoft.com/en-us/graph/api/resources/onpasswordmigrationcustomextensionhandler?view=graph-rest-beta&preserve-view=true) resource to configure handlers that invoke custom extensions during JIT migration.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#search-1)
### Search
Added the **principal** and **principalCollection** data types to the [externalConnection](https://learn.microsoft.com/en-us/graph/api/resources/externalconnectors-externalconnection?view=graph-rest-beta&preserve-view=true) resource to specify the data type for people‑related property items in the external connection.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--data-security-and-compliance-1)
### Security | Data security and compliance
  * Deprecated the **accessedResources** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) in favor of the **accessedResources_v2** property.
  * Use the **accessedResources_v2** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) to get detailed information about resources accessed during the conversation, including identifiers, access type, and status.
  * Use the **agents** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) to get information about AI agents that participated in the preparation of the message.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--email-and-collaboration-protection)
### Security | Email and collaboration protection
Enhancements to the [detonationDetails](https://learn.microsoft.com/en-us/graph/api/resources/security-detonationdetails?view=graph-rest-beta&preserve-view=true) resource that represents details from analysis of suspicious files and URLs in emails in Microsoft Defender for Office 365:
  * Added the following properties to provide more detailed threat analysis:
    * **detonationBehaviourDetailsV2** - Shows events that took place during detonation in JSON format
    * **entityMetadata** - Additional metadata about the entity in JSON format
    * **mitreTechniques** - Attack techniques aligned with the MITRE ATT&CK framework
    * **staticAnalysis** - Results of static analysis performed on the file or URL
    * **submissionSource** - The source of the submission
  * The **detonationBehaviourDetails** property is deprecated and will stop returning data in March 2026. Use the **detonationBehaviourDetailsV2** property instead.
  * Added the `moveToQuarantine` member to the **remediationAction** enumeration. Use the `Prefer: include-unknown-enum-members` request header to access this evolvable enum member.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-and-generally-available)
## January 2026: New and generally available
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#identity-and-access--governance)
### Identity and access | Governance
Use the **administrationScopeTargets** relationship on the [workflowBase](https://learn.microsoft.com/en-us/graph/api/resources/identitygovernance-workflowbase), [workflow](https://learn.microsoft.com/en-us/graph/api/resources/identitygovernance-workflow), and [workflowVersion](https://learn.microsoft.com/en-us/graph/api/resources/identitygovernance-workflowversion) resources to specify the [administrative units](https://learn.microsoft.com/en-us/graph/api/resources/administrativeunit) in the scope of a lifecycle workflow.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#identity-and-access--identity-and-sign-in-2)
### Identity and access | Identity and sign-in
  * Starting January 26, 2026, users who manage their own [authentication methods](https://learn.microsoft.com/en-us/graph/api/resources/authenticationmethods-overview) through self-service operations, such as adding, updating, or deleting phone numbers and email addresses, must complete multifactor authentication (MFA) if they last authenticated more than 10 minutes ago in the current session. For more guidance on handling this change in your application, see [Microsoft Entra authentication methods API overview](https://learn.microsoft.com/en-us/graph/api/resources/authenticationmethods-overview).
  * Added `qrCode` as a new supported value for the **usageAuthMethod** enumeration which is the type for the **authMethod** property on [credentialUsageSummary](https://learn.microsoft.com/en-us/graph/api/resources/credentialusagesummary?view=graph-rest-beta&preserve-view=true), [userCredentialUsageDetails](https://learn.microsoft.com/en-us/graph/api/resources/usercredentialusagedetails?view=graph-rest-beta&preserve-view=true), [userEventsSummary](https://learn.microsoft.com/en-us/graph/api/resources/usereventssummary?view=graph-rest-beta&preserve-view=true), and [userRegistrationActivitySummary](https://learn.microsoft.com/en-us/graph/api/resources/userregistrationactivitysummary?view=graph-rest-beta&preserve-view=true) resources. This value represents the use of the [QR code](https://learn.microsoft.com/en-us/graph/api/resources/qrcodepinauthenticationmethod?view=graph-rest-beta&preserve-view=true) as an authentication method.
  * You can now manage external authentication methods (EAM) in Microsoft Entra ID to let users choose an external provider to meet multifactor authentication (MFA) requirements when they sign in to Microsoft Entra ID. For more information, see:
    * [externalAuthenticationMethod resource type](https://learn.microsoft.com/en-us/graph/api/resources/externalauthenticationmethod) for managing external authentication methods registered to a user for authentication using an external identity provider.
    * [externalAuthenticationMethodConfiguration resource type](https://learn.microsoft.com/en-us/graph/api/resources/externalauthenticationmethodconfiguration) for managing the tenant-wide policy.
  * Added the **createdDateTime** property to the [authenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/authenticationMethod) resource, which is the base type for the following derived authentication method resources: [fido2AuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/fido2AuthenticationMethod), [microsoftAuthenticatorAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/microsoftAuthenticatorAuthenticationMethod), [passwordAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/passwordAuthenticationMethod), [platformCredentialAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/platformCredentialAuthenticationMethod), [temporaryAccessPassAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/temporaryAccessPassAuthenticationMethod), and [windowsHelloForBusinessAuthenticationMethod](https://learn.microsoft.com/en-us/graph/api/resources/windowsHelloForBusinessAuthenticationMethod).


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#reports--microsoft-365-usage-reports)
### Reports | Microsoft 365 usage reports
Going forward, use the Microsoft 365 Copilot usage APIs under the `/copilot` URL path segment. For more information, see:
  * [Copilot report root](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/api/admin-settings/reports/resources/copilotreportroot)
  * [Get Copilot user count summary](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/api/admin-settings/reports/copilotreportroot-getmicrosoft365copilotusercountsummary)
  * [Get Copilot user count trend](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/api/admin-settings/reports/copilotreportroot-getmicrosoft365copilotusercounttrend)
  * [Get Copilot usage user detail](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/api/admin-settings/reports/copilotreportroot-getmicrosoft365copilotusageuserdetail)


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--advanced-hunting)
### Security | Advanced hunting
Added migration guidance for Microsoft Defender for Endpoint (MDE) advanced hunting APIs to help organizations transition from the retired APIs that were available through the `https://api.securitycenter.microsoft.com` endpoint to the advanced hunting APIs available in Microsoft Graph. For more information, see [Migrate from the older APIs](https://learn.microsoft.com/en-us/graph/api/resources/security-api-overview#migrate-from-older-apis).
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--alerts-and-incidents)
### Security | Alerts and incidents
  * Added the **priorityScore** property to the [incident](https://learn.microsoft.com/en-us/graph/api/resources/security-incident) resource to provide a priority score for the incident from 0 to 100, with > 85 being the top priority, 15 - 85 medium priority, and < 15 low priority. This score is generated using machine learning and is based on multiple factors, including severity, disruption impact, threat intelligence, alert types, asset criticality, threat analytics, incident rarity, and additional priority signals.
  * Made the following updates to APIs for managing Microsoft Defender for Identity (MDI) sensors:
    * Added the **domainName** property to the [sensorCandidate](https://learn.microsoft.com/en-us/graph/api/resources/security-sensorcandidate) resource to specify the domain name of the sensor.
    * Added the **serviceStatus** property to the [sensor](https://learn.microsoft.com/en-us/graph/api/resources/security-sensor) resource to indicate the service status. The possible values are: `stopped`, `starting`, `running`, `disabled`, `onboarding`, `unknown`, `unknownFutureValue`.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--ediscovery)
### Security | eDiscovery
Use the **reportFileMetadata** property on [ediscoveryPurgeDataOperation](https://learn.microsoft.com/en-us/graph/api/resources/security-ediscoverypurgedataoperation) to get the purge job report file metadata.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#teamwork-and-communications--apps)
### Teamwork and communications | Apps
The `TeamsAppInstallation.ManageSelectedForTeam.All` is the least privileged application permission required to install or upgrade a Teams app that requires consent to [resource-specific consent (RSC)](https://learn.microsoft.com/en-us/microsoftteams/platform/graph-api/rsc/resource-specific-consent) permissions when using the [teamsAppInstallation in a team: upgrade](https://learn.microsoft.com/en-us/graph/api/team-teamsappinstallation-upgrade) API.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-in-preview-only)
## January 2026: New in preview only
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#applications-1)
### Applications
The **allowedTenantIds** property on [allowedTenantsAudience](https://learn.microsoft.com/en-us/graph/api/resources/allowedtenantsaudience?view=graph-rest-beta&preserve-view=true) must contain at least one value and can't include more than 20 values.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#device-and-app-management--cloud-pc)
### Device and app management | Cloud PC
  * Use the following resources to represent the data sent to Azure Logic Apps as part of a custom extension callout request when a custom extension in a catalog is used:
    * [accessPackageAssignmentCalloutData](https://learn.microsoft.com/en-us/graph/api/resources/accesspackageassignmentcalloutdata) - for access package assignments
    * [accessPackageAssignmentRequestCalloutData](https://learn.microsoft.com/en-us/graph/api/resources/accesspackageassignmentrequestcalloutdata) - for access package assignment requests
  * Added the [controlConfiguration](https://learn.microsoft.com/en-us/graph/api/resources/controlconfiguration) resource and the **controlConfigurations** relationship to the [entitlementManagement](https://learn.microsoft.com/en-us/graph/api/resources/entitlementmanagement?view=graph-rest-beta&preserve-view=true) resource to represent the policies that control lifecycle and access to access packages across the organization.
  * Added the [entraIdProtectionRiskyUserApproval](https://learn.microsoft.com/en-us/graph/api/resources/entraidprotectionriskyuserapproval) resource to represent the approval configuration for risky users detected by Microsoft Entra ID Protection.
  * Added the [insiderRiskyUserApproval](https://learn.microsoft.com/en-us/graph/api/resources/insiderriskyuserapproval) resource to represent the approval configuration for risky users detected by Microsoft Purview Insider Risk Management.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#device-and-app-management--device-updates)
### Device and app management | Device updates
Added a new approval and deployment management model for Windows quality updates in Autopatch-managed environments. You can now define quality update policies with customizable approval rules, assign deployment rings to group devices for phased rollout, and manage the approval status of update content before deploying to devices. The following resources provide more information:
  * [policy](https://learn.microsoft.com/en-us/graph/api/resources/windowsupdates-policy?view=graph-rest-beta&preserve-view=true)
  * [qualityUpdatePolicy](https://learn.microsoft.com/en-us/graph/api/resources/windowsupdates-qualityupdatepolicy?view=graph-rest-beta&preserve-view=true)
  * [policyApproval](https://learn.microsoft.com/en-us/graph/api/resources/windowsupdates-policyapproval?view=graph-rest-beta&preserve-view=true)
  * [ring](https://learn.microsoft.com/en-us/graph/api/resources/windowsupdates-ring?view=graph-rest-beta&preserve-view=true)
  * [qualityUpdateRing](https://learn.microsoft.com/en-us/graph/api/resources/windowsupdates-qualityupdatering?view=graph-rest-beta&preserve-view=true)


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#groups-1)
### Groups
Use the **welcomeMessageEnabled** property on the [group](https://learn.microsoft.com/en-us/graph/api/resources/group?view=graph-rest-beta&preserve-view=true) resource to control whether a welcome message is sent to new members when they're added to a Microsoft 365 group. The default value is `true`.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#identity-and-access--identity-and-sign-in-3)
### Identity and access | Identity and sign-in
  * Added the `microsoftRevokedSessions` value to the [riskDetail](https://learn.microsoft.com/en-us/graph/api/resources/riskdetail) enumeration to indicate that Microsoft revoked sessions. This enumeration member applies to the following Microsoft Entra Identity Protection resources: [riskDetection](https://learn.microsoft.com/en-us/graph/api/resources/riskdetection?view=graph-rest-beta&preserve-view=true), [riskUserActivity](https://learn.microsoft.com/en-us/graph/api/resources/riskuseractivity), [riskyUser](https://learn.microsoft.com/en-us/graph/api/resources/riskyuser?view=graph-rest-beta&preserve-view=true), and [signIn](https://learn.microsoft.com/en-us/graph/api/resources/signin?view=graph-rest-beta&preserve-view=true).
  * Added `mexico` as a new supported value for the **cloudPcGeographicLocationType** enumeration type. This enum is the return type for the **geographicLocationType** property on [cloudPcDomainJoinConfiguration](https://learn.microsoft.com/en-us/graph/api/resources/cloudpcdomainjoinconfiguration?view=graph-rest-beta&preserve-view=true) and [cloudPcSupportedRegion](https://learn.microsoft.com/en-us/graph/api/resources/cloudpcsupportedregion?view=graph-rest-beta&preserve-view=true).
  * Added the `cloudPCInventoryReport` member to the **cloudPcReportName** enumeration type. This enum is the return type for the **reportName** property on [cloudPcExportJob](https://learn.microsoft.com/en-us/graph/api/resources/cloudPcExportJob?view=graph-rest-beta&preserve-view=true), [getFrontlineReport action](https://learn.microsoft.com/en-us/graph/api/cloudpcreports-getfrontlinereport?view=graph-rest-beta&preserve-view=true), and [getCloudPcRecommendationReports action](https://learn.microsoft.com/en-us/graph/api/cloudpcreports-getcloudpcrecommendationreports?view=graph-rest-beta&preserve-view=true).
  * Use the **category** property on [cloudPcSourceDeviceImage](https://learn.microsoft.com/en-us/graph/api/resources/cloudpcsourcedeviceimage?view=graph-rest-beta&preserve-view=true) to get the category of the source image that is requested. For more information, see [Get cloudPcSourceDeviceImage objects with a specific category](https://learn.microsoft.com/en-us/graph/api/cloudpcdeviceimage-getsourceimages?view=graph-rest-beta&preserve-view=true#example-2-get-cloudpcsourcedeviceimage-objects-with-a-specific-category).
  * Added `refreshPolicyConfiguration` as a supported value for the **status** property on the [cloudPC](https://learn.microsoft.com/en-us/graph/api/resources/cloudpc?view=graph-rest-beta&preserve-view=true) and [cloudPcStatusSummary](https://learn.microsoft.com/en-us/graph/api/resources/cloudpcstatussummary?view=graph-rest-beta&preserve-view=true) to indicate that the Cloud PC is in the process of refreshing the new policy configurations.
  * Added `riskRemediation` as a new member to the [conditionalAccessGrantControl](https://learn.microsoft.com/en-us/graph/api/resources/conditionalaccessgrantcontrols?view=graph-rest-beta&preserve-view=true#builtincontrols-property) enumeration. This value allows users to self-remediate their user risk through conditional access policies.
  * Use the **groupSyncInbound** property on [crossTenantIdentitySyncPolicyPartner](https://learn.microsoft.com/en-us/graph/api/resources/crosstenantidentitysyncpolicypartner?view=graph-rest-beta&preserve-view=true) to define whether groups can be synchronized from a partner tenant in cross-tenant access policy settings.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#message-trace-1)
### Message trace
Use the [userConfiguration](https://learn.microsoft.com/en-us/graph/api/resources/userconfiguration) resource and its associated methods to manage user-specific settings, metadata, or application data tied to mailbox folders, using XML, binary, or dictionary formats.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#reports--identity-and-access-reports)
### Reports | Identity and access reports
  * Removed the **conditionalAccessAudience** resource type. The return type of the **conditionalAccessAudiences** property of the [signIn resource type](https://learn.microsoft.com/en-us/graph/api/resources/signin) is a collection of String objects and not the **conditionalAccessAudience** complex type. Use the message trace API to track the flow of email messages through your Exchange Online organization. For more information, see [exchangeMessageTrace](https://learn.microsoft.com/en-us/graph/api/resources/exchangemessagetrace?view=graph-rest-beta&preserve-view=true).
  * Added `qrCode` as a new supported value for the **usageAuthMethod** enumeration which is the type for the **authMethod** property on [credentialUsageSummary](https://learn.microsoft.com/en-us/graph/api/resources/credentialusagesummary?view=graph-rest-beta&preserve-view=true), [userCredentialUsageDetails](https://learn.microsoft.com/en-us/graph/api/resources/usercredentialusagedetails?view=graph-rest-beta&preserve-view=true), [userEventsSummary](https://learn.microsoft.com/en-us/graph/api/resources/usereventssummary?view=graph-rest-beta&preserve-view=true), and [userRegistrationActivitySummary](https://learn.microsoft.com/en-us/graph/api/resources/userregistrationactivitysummary?view=graph-rest-beta&preserve-view=true) resources. This value represents the use of the [QR code](https://learn.microsoft.com/en-us/graph/api/resources/qrcodepinauthenticationmethod?view=graph-rest-beta&preserve-view=true) as an authentication method.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--alerts-and-incidents-1)
### Security | Alerts and incidents
Added the **priorityScore** property to the [incident](https://learn.microsoft.com/en-us/graph/api/resources/security-incident?view=graph-rest-beta&preserve-view=true) resource to provide a priority score for the incident from 0 to 100, with > 85 being the top priority, 15 - 85 medium priority, and < 15 low priority. This score is generated using machine learning and is based on multiple factors, including severity, disruption impact, threat intelligence, alert types, asset criticality, threat analytics, incident rarity, and additional priority signals.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--cloud-zones)
### Security | Cloud zones
Added support for managing _zones_ in Microsoft Defender for Cloud, enabling organizations to segment multi-cloud environments (Azure, AWS, GCP, and DevOps or registry sources) into logical groupings for access and security management at scale. The [zone](https://learn.microsoft.com/en-us/graph/api/resources/security-zone?view=graph-rest-beta&preserve-view=true) resource type and its associated [environment](https://learn.microsoft.com/en-us/graph/api/resources/security-environment?view=graph-rest-beta&preserve-view=true) resource let you consistently apply least-privilege access controls and manage collections of attached environments within Microsoft Graph.
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#security--data-security-and-compliance-2)
### Security | Data security and compliance
  * Deprecated the **accessedResources** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) in favor of the **accessedResources_v2** property.
  * Use the **accessedResources_v2** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) to get detailed information about resources accessed during the conversation, including identifiers, access type, and status.
  * Use the **agents** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) to get information about AI agents that participated in the preparation of the message.
  * Added the **contentCategory** property on [processConversationMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processconversationmetadata?view=graph-rest-beta&preserve-view=true) and [processFileMetadata](https://learn.microsoft.com/en-us/graph/api/resources/processfilemetadata?view=graph-rest-beta&preserve-view=true) to indicate whether content is AI generated or not.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#teamwork-and-communications--apps-1)
### Teamwork and communications | Apps
  * Use the **layoutType** property on the [channel](https://learn.microsoft.com/en-us/graph/api/resources/channel) resource to create channels with different conversation experiences and switch between them at any time. The property supports two values: `post` for traditional post-reply format and `chat` for a chat-like threading experience. You can set the layout type when [creating a channel](https://learn.microsoft.com/en-us/graph/api/channel-post) and [update it](https://learn.microsoft.com/en-us/graph/api/channel-patch) later to switch between layouts.
  * The `TeamsAppInstallation.ManageSelectedForTeam.All` is the least privileged application permission required to install or upgrade a Teams app that requires consent to [resource-specific consent (RSC)](https://learn.microsoft.com/en-us/microsoftteams/platform/graph-api/rsc/resource-specific-consent) permissions when using the [teamsAppInstallation in a team: upgrade](https://learn.microsoft.com/en-us/graph/api/team-teamsappinstallation-upgrade?view=graph-rest-beta&preserve-view=true) API.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#tenant-administration--configuration-management)
### Tenant administration | Configuration management
The new unified tenant configuration management APIs in Microsoft Graph allow administrators to control and manage configuration settings across a single workload or multiple workloads within an organization. To learn more about supported use cases, see [Use the unified tenant configuration management APIs in Microsoft Graph (preview)](https://learn.microsoft.com/en-us/graph/api/resources/unified-tenant-configuration-management-api-overview?view=graph-rest-beta&preserve-view=true).
[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#contribute-to-microsoft-graph)
## Contribute to Microsoft Graph
Are there scenarios you'd like Microsoft Graph to support?
  * Suggest and vote for new features by using the [Microsoft Graph Feedback Portal](https://aka.ms/graphfeedback). Some new features originate as popular requests from the developer community. The Microsoft Graph team regularly evaluates customer needs and releases new features to the beta (`https://graph.microsoft.com/beta`) and v1.0 (`https://graph.microsoft.com/v1.0`) endpoints.
  * [Join](https://aka.ms/m365-dev-call) the weekly Microsoft 365 platform community call and become an active member of the Microsoft Graph community. To discover the full calendar of developer calls, visit the [Microsoft 365 and Power Platform community page](https://aka.ms/community/calls).
  * [Join](https://ux.microsoft.com/Panel/M365Devs?utm_source=graphDocs) our research panel to provide your input on our developer experiences.


[](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#related-content)
## Related content
  * [Microsoft Graph developer blog](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/).
  * [Microsoft Graph API changelog](https://developer.microsoft.com/graph/changelog/).
  * [Microsoft Graph what's new history](https://learn.microsoft.com/en-us/graph/whats-new-earlier).


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ Versioning, support, and breaking change policies for Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/versioning-and-support?source=recommendations)
Learn about the support and breaking change policies for Microsoft Graph and the versions of the Microsoft Graph API that are currently available.
  * [ Microsoft Graph REST API v1.0 endpoint reference - Microsoft Graph v1.0 ](https://learn.microsoft.com/en-us/graph/api/overview?source=recommendations)
Find reference content for Microsoft Graph REST APIs in the v1.0 endpoint, which includes APIs in general availability (GA) status.
  * [ Use Graph Explorer to try Microsoft Graph APIs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?source=recommendations)
Try Microsoft Graph APIs on the default sample tenant to explore capabilities, or sign in to your tenant and use it as a prototyping tool to fulfill your app scenarios.
  * [ Best practices for working with Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/best-practices-concept?source=recommendations)
Apply these best practices to improve your Microsoft Graph application's performance and make your app more reliable for end users.
  * [ Microsoft Graph what's new history - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/whats-new-earlier?source=recommendations)
Find information about previous additions and updates to Microsoft Graph APIs, documentation, SDKs, and other resources.
  * [ Use the Microsoft Graph API - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/use-the-api?source=recommendations)
Learn how to register your app and get authentication tokens for a user or service before you make requests to the Microsoft Graph API.
  * [ Microsoft Graph national cloud deployments - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/deployments?source=recommendations)
Learn about Microsoft Graph national cloud deployments and the capabilities that are available to developers within each.
  * [ Access data and methods by navigating Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/traverse-the-graph?source=recommendations)
In addition to using the Microsoft Graph API to read and write data, you can use a number of request patterns to traverse through the resources in Microsoft Graph. The metadata document also helps you to understand the data model of the resources and relationships in Microsoft Graph.


Show 5 more
Learning path
[ Explore Microsoft Graph scenarios for ASP.NET Core development - Training ](https://learn.microsoft.com/en-us/training/paths/m365-msgraph-dotnet-core-scenarios/?source=recommendations)
This learning path includes hands-on exercises that will show you how to perform common tasks, such as showing a user's emails, accessing calendar events, and downloading and uploading files, in an ASP.NET Core app using Microsoft Graph APIs.
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 24, 7 PM - Feb 24, 7 PM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 02/23/2026


##  In this article
  1. [February 2026: New and generally available](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-and-generally-available)
  2. [February 2026: New in preview only](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#february-2026-new-in-preview-only)
  3. [January 2026: New and generally available](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-and-generally-available)
  4. [January 2026: New in preview only](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#january-2026-new-in-preview-only)
  5. [Contribute to Microsoft Graph](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#contribute-to-microsoft-graph)
  6. [Related content](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#related-content)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fwhats-new-overview%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
