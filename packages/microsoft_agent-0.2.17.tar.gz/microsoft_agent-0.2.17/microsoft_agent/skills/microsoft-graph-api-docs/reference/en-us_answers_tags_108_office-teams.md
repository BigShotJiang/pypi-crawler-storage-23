[ Skip to main content ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/?id=aHR0cHM6Ly9hdXRob3JpbmctZG9jcy1taWNyb3NvZnQucG9vbHBhcnR5LmJpei9kZXZyZWwvNDA2ZWQwNjUtMjVjMS00NWY4LWFhYTUtZDhiNWM2ZTQ4Y2Q3&styleGuideLabel=Microsoft%20Teams)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
Microsoft Q&A
#  Microsoft Teams
59,089 questions
A collaboration and communication platform that brings together chat, video meetings, file sharing, and app integration, enabling teams to work together effectively from anywhere, in real time.
Sign in to follow  Follow
Filters
## Filter
* * *
### Content
[ All questions 59.1K  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=null) [ No answers 2.8K  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=unanswered) [ Has answers 56.3K  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=answered) [ No answers or comments 659  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=withoutengagement) [ With accepted answer 11.2K  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=withacceptedanswer) [ With recommended answer 28  ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?filterby=withrecommendedanswer)
##  59,089 questions with Microsoft Teams-related tags
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?orderby=answercount&page=1)
4 answers
##  [ My classes disappeared on teams app on my phone but it’s showing up on the laptop! ](https://learn.microsoft.com/en-us/answers/questions/5707470/my-classes-disappeared-on-teams-app-on-my-phone-bu)
My classes are not showing up on my Microsoft teams phone app but it’s perfectly fine on my laptop app… why and how did my classes disappear on my phone app?
Microsoft Teams | Microsoft Teams for education | Teams and channels | Other
[ Microsoft Teams | Microsoft Teams for education | Teams and channels | Other ](https://learn.microsoft.com/en-us/answers/tags/1493/office-teams-teams-education-teams-channels-teams-channels-other/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
1,115 questions
Sign in to follow  Follow
asked Jan 13, 2026, 11:00 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(147.20000000000002,%2052%,%2024%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAC%3C/text%3E%3C/svg%3E)
[Amy Crutcher](https://learn.microsoft.com/en-us/users/na/?userid=a4cd6520-f730-4b38-8abb-e197d29a079c) 0 Reputation points
edited a comment Feb 24, 2026, 7:19 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(144,%2056.00000000000001%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJH%3C/text%3E%3C/svg%3E)
[Jeanie H](https://learn.microsoft.com/en-us/users/na/?userid=4ba5c56d-bcda-4866-9cd3-b00076e99205) 11,225 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ After an update this week, my camera stopped working? I need to have it working again!! Help!! ](https://learn.microsoft.com/en-us/answers/questions/5787316/after-an-update-this-week-my-camera-stopped-workin)
After this weeks update, it apparently removed access to my camera. I need to have it back. How can I do this, or can you help me fix it? Thanks, Alison
Microsoft Teams | Development
[ Microsoft Teams | Development ](https://learn.microsoft.com/en-us/answers/tags/339/office-teams-development-routing/)
Building, integrating, or customizing apps and workflows within Microsoft Teams using developer tools and APIs
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
4,820 questions
Sign in to follow  Follow
asked Feb 24, 2026, 6:59 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(291.2,%2025%,%2038%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAB%3C/text%3E%3C/svg%3E)
[Alison Bolton](https://learn.microsoft.com/en-us/users/na/?userid=b91d25dd-c3cc-4b99-bd5f-1317c273633b) 0 Reputation points
answered Feb 24, 2026, 7:00 PM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
1 answer
##  [ Can't Access My Microsoft Account – No Option to Select "I don't have any of these" for 2FA ](https://learn.microsoft.com/en-us/answers/questions/5512195/cant-access-my-microsoft-account-no-option-to-sele)
Hello, I'm unable to access my Microsoft account associated with my institute email (student account) because the phone number used for two-factor authentication (2FA) is no longer active. I do know my password, but I cannot complete the identity…
Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in
[ Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in ](https://learn.microsoft.com/en-us/answers/tags/1216/office-teams-teams-education-signup-signin-teams-signin/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
466 questions
Sign in to follow  Follow
asked Aug 2, 2025, 11:52 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(3.2,%2036%,%2010%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EHU%3C/text%3E%3C/svg%3E)
[Harshill Utsav K A](https://learn.microsoft.com/en-us/users/na/?userid=fe01c368-d5ed-46ac-999d-d45b6ae0efdb) 0 Reputation points
commented Feb 24, 2026, 6:09 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(28.799999999999997,%2083%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESN%3C/text%3E%3C/svg%3E)
[Sophie N](https://learn.microsoft.com/en-us/users/na/?userid=0a98b32d-51f4-4934-ab43-7dac13ec5572) 11,910 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Microsoft Teams (University Account): Authenticator Not Showing Approval Request – Stuck in Sign-In Loop ](https://learn.microsoft.com/en-us/answers/questions/5787133/microsoft-teams-\(university-account\)-authenticator)
Situation: I am trying to sign into Microsoft Teams on my laptop using my university account. After entering my email and password, Teams displays a number and asks me to approve the sign-in in the Microsoft Authenticator app (number matching). When I…
Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in
[ Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in ](https://learn.microsoft.com/en-us/answers/tags/1216/office-teams-teams-education-signup-signin-teams-signin/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
466 questions
Sign in to follow  Follow
asked Feb 24, 2026, 3:32 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(188.79999999999998,%2010%,%2028%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EOA%3C/text%3E%3C/svg%3E)
[Oliver Al-Masri](https://learn.microsoft.com/en-us/users/na/?userid=5f910f65-e775-4467-b13e-b6621d3f76a1) 0 Reputation points
edited the question Feb 24, 2026, 5:27 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(128,%2098%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKL%3C/text%3E%3C/svg%3E)
[Kristen-L](https://learn.microsoft.com/en-us/users/na/?userid=ff4f0981-c88b-4daf-a21a-ef526ee30734) 9,915 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Teams App will not work on my HP envy ](https://learn.microsoft.com/en-us/answers/questions/5785827/teams-app-will-not-work-on-my-hp-envy)
hi, we recently received a new modem at work. Now my teams app calling will not work with camera and voice.
Microsoft Teams | Microsoft Teams for business | Meetings and calls | Audio and video
[ Microsoft Teams | Microsoft Teams for business | Meetings and calls | Audio and video ](https://learn.microsoft.com/en-us/answers/tags/1444/office-teams-teams-business-meetings-calls-audio-video/)
Managing sound and video settings during Teams meetings and calls for optimal communication
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
2,580 questions
Sign in to follow  Follow
asked Feb 23, 2026, 6:20 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(156.8,%2040%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EM%3C/text%3E%3C/svg%3E)
[Mitch](https://learn.microsoft.com/en-us/users/na/?userid=f494f013-6d98-41c5-917c-d0f345976217) 0 Reputation points
edited a comment Feb 24, 2026, 5:24 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(156.8,%2040%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EM%3C/text%3E%3C/svg%3E)
[Mitch](https://learn.microsoft.com/en-us/users/na/?userid=f494f013-6d98-41c5-917c-d0f345976217) 0 Reputation points
1 answer
##  [ Cant Access Microsoft Business Account ](https://learn.microsoft.com/en-us/answers/questions/5786866/cant-access-microsoft-business-account)
Hello, I created a Microsoft Business Account in order to access teams for an interview as my school stopped supporting it. I now can access it but am continuing to be billed for it. I have the name and the Tenant ID but it doesn't seem to want to take…
Microsoft Teams | Microsoft Teams for business | Teams for Mac
[ Microsoft Teams | Microsoft Teams for business | Teams for Mac ](https://learn.microsoft.com/en-us/answers/tags/1555/office-teams-teams-business-teams-mac/)
Using Microsoft Teams on macOS, including installation, features, and compatibility
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
881 questions
Sign in to follow  Follow
asked Feb 24, 2026, 11:57 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(147.20000000000002,%2037%,%2024%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWP%3C/text%3E%3C/svg%3E)
[Willem Philibert](https://learn.microsoft.com/en-us/users/na/?userid=4d6a3756-48ca-44cb-befc-caf13700d90b) 0 Reputation points
commented Feb 24, 2026, 5:09 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(147.20000000000002,%2037%,%2024%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWP%3C/text%3E%3C/svg%3E)
[Willem Philibert](https://learn.microsoft.com/en-us/users/na/?userid=4d6a3756-48ca-44cb-befc-caf13700d90b) 0 Reputation points
One of the answers was accepted by the question author.
##  [ Planner premium 1 task capabilities ](https://learn.microsoft.com/en-us/answers/questions/5781578/planner-premium-1-task-capabilities)
I recently upgraded and am testing different capabilities within the premium version. Comments in tasks: The free version you were able to add a comments section to tasks, in the upgraded 1 level up premium version, there's no comments section. Is there…
Microsoft Teams | Microsoft Teams for business | Other
[ Microsoft Teams | Microsoft Teams for business | Other ](https://learn.microsoft.com/en-us/answers/tags/809/office-teams-teams-business-other-l1/)
Additional features, settings, or issues not covered by specific Microsoft Teams categories
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
20,873 questions
Sign in to follow  Follow
asked Feb 19, 2026, 2:34 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(307.2,%2060%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJA%3C/text%3E%3C/svg%3E)
[Joanne Almayah](https://learn.microsoft.com/en-us/users/na/?userid=96be6c01-d76d-4138-937e-c5a9c985e7a4) 20 Reputation points
commented Feb 24, 2026, 4:51 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(256,%2017%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EHN%3C/text%3E%3C/svg%3E)
[Hani-N](https://learn.microsoft.com/en-us/users/na/?userid=8017e965-8a49-45de-979e-ff4925a51d4f) 7,415 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How to enable free/personal account user to participant in breakout rooms on Teams ](https://learn.microsoft.com/en-us/answers/questions/5785383/how-to-enable-free-personal-account-user-to-partic)
Hi, I have a frequent situation whereby I can't assign some individuals to a breakout room on teams. All were outside of my organisation and none were using organised- managed accounts. I have seen questions on this topic posted in the past - but no…
Microsoft Teams | Microsoft Teams for business | Meetings and calls | Other
[ Microsoft Teams | Microsoft Teams for business | Meetings and calls | Other ](https://learn.microsoft.com/en-us/answers/tags/1364/office-teams-teams-business-meetings-calls-meetings-other/)
Additional meeting and call-related features and issues within Microsoft Teams for business
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
4,718 questions
Sign in to follow  Follow
asked Feb 23, 2026, 11:53 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(288,%2025%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECH%3C/text%3E%3C/svg%3E)
[Caroline H](https://learn.microsoft.com/en-us/users/na/?userid=90a25110-e700-4d95-84ba-cf766f88968e) 0 Reputation points
commented Feb 24, 2026, 4:37 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(256,%2017%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EHN%3C/text%3E%3C/svg%3E)
[Hani-N](https://learn.microsoft.com/en-us/users/na/?userid=8017e965-8a49-45de-979e-ff4925a51d4f) 7,415 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ I need to cancel teams subscription ](https://learn.microsoft.com/en-us/answers/questions/5787166/i-need-to-cancel-teams-subscription)
I want to cancel TEAMS, I keep getting billed for a service I,ve never used.
Microsoft Teams | Microsoft Teams for business | Other
[ Microsoft Teams | Microsoft Teams for business | Other ](https://learn.microsoft.com/en-us/answers/tags/809/office-teams-teams-business-other-l1/)
Additional features, settings, or issues not covered by specific Microsoft Teams categories
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
20,873 questions
Sign in to follow  Follow
asked Feb 24, 2026, 4:01 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(179.20000000000002,%2070%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESS%3C/text%3E%3C/svg%3E)
[steven SLAUGHTER](https://learn.microsoft.com/en-us/users/na/?userid=5b67d039-3379-4f69-9c73-95b5aa7c0f1f) 0 Reputation points
edited the question Feb 24, 2026, 4:30 PM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/m7v-lobmoE25aKX2g-bpZQ.png?8D828A)
[Stefan Blom](https://learn.microsoft.com/en-us/users/na/?userid=96febb9b-e686-4da0-b968-a5f683e6e965) 333.9K Reputation points • MVP • Volunteer Moderator
2 answers
##  [ teams only sees 1 screen when trying to share - I have 2 ](https://learn.microsoft.com/en-us/answers/questions/5785547/teams-only-sees-1-screen-when-trying-to-share-i-ha)
I have windows 11 on a lenovo laptop. I have 2 screens (extended), one is my laptop and one is the TV screen I am plugged into (with docking station). My screen is extended and shows as extended on my desktop and the TV but when I try and share my…
Microsoft Teams | Microsoft Teams for business | Meetings and calls | Screen sharing
[ Microsoft Teams | Microsoft Teams for business | Meetings and calls | Screen sharing ](https://learn.microsoft.com/en-us/answers/tags/1188/office-teams-teams-business-meetings-calls-screen-sharing/)
Displaying your screen content to others during a Teams meeting or call for collaboration
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
748 questions
Sign in to follow  Follow
asked Feb 23, 2026, 2:01 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(307.2,%204%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAY%3C/text%3E%3C/svg%3E)
[Alicia Y](https://learn.microsoft.com/en-us/users/na/?userid=96e04f47-4573-4697-97d2-5efae62bfe7f) 0 Reputation points
commented Feb 24, 2026, 4:25 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(281.6,%2026%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKN%3C/text%3E%3C/svg%3E)
[Killian-N](https://learn.microsoft.com/en-us/users/na/?userid=8faaedd8-2d66-4ff7-9740-882d7e1ae45a) 9,130 Reputation points • Microsoft External Staff • Moderator
5 answers
##  [ Microsoft Teams Search Not Working – Tried All Troubleshooting Steps ](https://learn.microsoft.com/en-us/answers/questions/5520306/microsoft-teams-search-not-working-tried-all-troub)
Hello, Since yesterday, the search function in Microsoft Teams (desktop app, mobile app, and web version) has completely stopped working for me. This issue started right after a group call and has persisted ever since. Here are all the steps I have…
Microsoft Teams | Microsoft Teams for business | Chats | Search messages and conversations
[ Microsoft Teams | Microsoft Teams for business | Chats | Search messages and conversations ](https://learn.microsoft.com/en-us/answers/tags/1489/office-teams-teams-business-chats-search-messages-conversations/)
Finding specific messages or threads using search tools within Microsoft Teams chat history
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
173 questions
Sign in to follow  Follow
asked Aug 11, 2025, 8:51 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2043%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EBM%3C/text%3E%3C/svg%3E)
[Bita Malekshahi](https://learn.microsoft.com/en-us/users/na/?userid=e1f64d35-9a0a-485e-86ce-c7b04a7ca358) 25 Reputation points
edited a comment Feb 24, 2026, 3:36 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(60.8,%2054%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMK%3C/text%3E%3C/svg%3E)
[Mary Kathryn](https://learn.microsoft.com/en-us/users/na/?userid=ce195e4c-2187-49f1-afc6-8cde8701ad91) 35 Reputation points
4 answers
##  [ Call Queue Calls Appearing as Chat Conversations ](https://learn.microsoft.com/en-us/answers/questions/5782413/call-queue-calls-appearing-as-chat-conversations)
Hoping someone has seen this before or can confirm whether this is expected behavior or a bug. We’re experiencing an issue where calls received through a Call Queue are appearing as new chat conversations in Microsoft Teams. Each time a user receives a…
Microsoft Teams | Microsoft Teams for business | Chats | Other
[ Microsoft Teams | Microsoft Teams for business | Chats | Other ](https://learn.microsoft.com/en-us/answers/tags/1369/office-teams-teams-business-chats-chat-other/)
Additional chat-related features and issues within Microsoft Teams for business
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
1,200 questions
Sign in to follow  Follow
asked Feb 20, 2026, 9:49 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(67.2,%2030%,%2016%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EDN%3C/text%3E%3C/svg%3E)
[Daniel N](https://learn.microsoft.com/en-us/users/na/?userid=213e0d88-2d12-4205-b95d-e789fdf5409d) 90 Reputation points
commented Feb 24, 2026, 3:19 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(195.2,%2064%,%2028%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJH%3C/text%3E%3C/svg%3E)
[James Howells](https://learn.microsoft.com/en-us/users/na/?userid=cd61d646-2a59-4a43-bbfa-baa01f19d01e) 0 Reputation points
2 answers
##  [ I wish to cancel a subscription ](https://learn.microsoft.com/en-us/answers/questions/5785342/i-wish-to-cancel-a-subscription)
I was the Secretary of Information deleted for privacy protection. I have now moved on and I would like to cancel a subscription. My latest invoice dated 18/10/2025 was number Information deleted for privacy protection
Microsoft Teams | Microsoft Teams for business | Meetings and calls | Audio and video
[ Microsoft Teams | Microsoft Teams for business | Meetings and calls | Audio and video ](https://learn.microsoft.com/en-us/answers/tags/1444/office-teams-teams-business-meetings-calls-audio-video/)
Managing sound and video settings during Teams meetings and calls for optimal communication
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
2,580 questions
Sign in to follow  Follow
asked Feb 23, 2026, 11:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(64,%2065%,%2016%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ENW%3C/text%3E%3C/svg%3E)
[Norman Wareing](https://learn.microsoft.com/en-us/users/na/?userid=2c0a658d-cad8-48a4-8086-6bee15f9f30e) 0 Reputation points
commented Feb 24, 2026, 3:10 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(281.6,%2034%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ERN%3C/text%3E%3C/svg%3E)
[Ryan-N](https://learn.microsoft.com/en-us/users/na/?userid=883de4a6-bd7d-4f56-ac21-14e8e7bf3240) 10,615 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ create retention policy for teams ](https://learn.microsoft.com/en-us/answers/questions/5785642/create-retention-policy-for-teams)
create retention policy for teams to remove all history upon closing teams
Microsoft Teams | Microsoft Teams for business | Settings | Privacy
[ Microsoft Teams | Microsoft Teams for business | Settings | Privacy ](https://learn.microsoft.com/en-us/answers/tags/1534/office-teams-teams-business-settings-settings-privacy/)
Controlling data sharing, visibility, and access permissions within Microsoft Teams
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
86 questions
Sign in to follow  Follow
asked Feb 23, 2026, 2:49 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(60.8,%2086%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJA%3C/text%3E%3C/svg%3E)
[Jeremy Addison](https://learn.microsoft.com/en-us/users/na/?userid=fbe1b986-88ba-411d-9d1c-0b853adb016d) 0 Reputation points
commented Feb 24, 2026, 3:08 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(281.6,%2034%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ERN%3C/text%3E%3C/svg%3E)
[Ryan-N](https://learn.microsoft.com/en-us/users/na/?userid=883de4a6-bd7d-4f56-ac21-14e8e7bf3240) 10,615 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ Call forward on no answer question ](https://learn.microsoft.com/en-us/answers/questions/5785942/call-forward-on-no-answer-question)
Is there any way to have a sequence as follows: Incoming (external) phone call to account A is unanswered, forwards to account B and is unanswered there, then goes to account A's voicemail to allow the caller to leave a message with the person they were…
Microsoft Teams | Microsoft Teams for education | Meetings and calls | Other
[ Microsoft Teams | Microsoft Teams for education | Meetings and calls | Other ](https://learn.microsoft.com/en-us/answers/tags/1501/office-teams-teams-education-meetings-calls-meetings-other/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
995 questions
Sign in to follow  Follow
asked Feb 23, 2026, 8:47 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(233.6,%2099%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESR%3C/text%3E%3C/svg%3E)
[Stewart Ross](https://learn.microsoft.com/en-us/users/na/?userid=c7b39922-cb89-47f0-91f1-5cfe11f5df1d) 20 Reputation points
accepted Feb 24, 2026, 2:34 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(233.6,%2099%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESR%3C/text%3E%3C/svg%3E)
[Stewart Ross](https://learn.microsoft.com/en-us/users/na/?userid=c7b39922-cb89-47f0-91f1-5cfe11f5df1d) 20 Reputation points
2 answers
##  [ How do I request to allow a specific domain in teams ](https://learn.microsoft.com/en-us/answers/questions/5786947/how-do-i-request-to-allow-a-specific-domain-in-tea)
Allow Specific domains. Where do I find Users > External Access
Microsoft Teams | Microsoft Teams for business | Settings | Other
[ Microsoft Teams | Microsoft Teams for business | Settings | Other ](https://learn.microsoft.com/en-us/answers/tags/1243/office-teams-teams-business-settings-settings-other/)
Additional settings-related features and issues within Microsoft Teams for business
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
639 questions
Sign in to follow  Follow
asked Feb 24, 2026, 1:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(118.4,%2051%,%2021%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJH%3C/text%3E%3C/svg%3E)
[Jeff Hampton](https://learn.microsoft.com/en-us/users/na/?userid=a37fb51e-adf6-46f5-ada2-51e6f601eb63) 0 Reputation points
answered Feb 24, 2026, 2:11 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2021%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EVN%3C/text%3E%3C/svg%3E)
[Vy Nguyen ](https://learn.microsoft.com/en-us/users/na/?userid=ddc16213-1c5a-4b71-99ad-9c724e7d868c) 9,290 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Why has the 'Add an agenda' button disappeared from my Teams meeting window? ](https://learn.microsoft.com/en-us/answers/questions/5786596/why-has-the-add-an-agenda-button-disappeared-from)
It appears that Microsoft have moved the 'Add meeting notes' or 'Add an agenda' button from the new meeting window in Teams. I can still see it for channel meetings. And I can add the meeting notes if I right click on a meeting, select 'Chat with…
Microsoft Teams | Microsoft Teams for education | Meetings and calls | Other
[ Microsoft Teams | Microsoft Teams for education | Meetings and calls | Other ](https://learn.microsoft.com/en-us/answers/tags/1501/office-teams-teams-education-meetings-calls-meetings-other/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
995 questions
Sign in to follow  Follow
asked Feb 24, 2026, 9:10 AM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/7DpvjovqFEaEW8IZOM1qYA.png?8DDBA3)
[ElaineHarrison-8050](https://learn.microsoft.com/en-us/users/na/?userid=8e6f3aec-ea8b-4614-845b-c21938cd6a60) 0 Reputation points
edited an answer Feb 24, 2026, 1:17 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(281.6,%2026%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKN%3C/text%3E%3C/svg%3E)
[Killian-N](https://learn.microsoft.com/en-us/users/na/?userid=8faaedd8-2d66-4ff7-9740-882d7e1ae45a) 9,130 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ Unable to log into Teams account due to issues with MFA ](https://learn.microsoft.com/en-us/answers/questions/5782380/unable-to-log-into-teams-account-due-to-issues-wit)
I am unable to log in to Teams or admin.microsoft.com with the account I used to subscribe to Teams due to MFA problems. My account ID and password appear to work correctly but, after logging in, I am immediately prompted for a code from Authenticator…
Microsoft Teams | Microsoft Teams for business | Sign up and Sign in | Sign in
[ Microsoft Teams | Microsoft Teams for business | Sign up and Sign in | Sign in ](https://learn.microsoft.com/en-us/answers/tags/1391/office-teams-teams-business-signup-signin-teams-signin/)
Accessing Microsoft Teams using organizational or personal credentials
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
1,235 questions
Sign in to follow  Follow
asked Feb 20, 2026, 9:11 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(265.6,%2028.999999999999996%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAT%3C/text%3E%3C/svg%3E)
[Alasdair Turnbull](https://learn.microsoft.com/en-us/users/na/?userid=e83b2a98-e59d-49f9-be2d-36b04c6125e9) 86 Reputation points
commented Feb 24, 2026, 1:17 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(57.599999999999994,%2023%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAN%3C/text%3E%3C/svg%3E)
[Alexis-NG](https://learn.microsoft.com/en-us/users/na/?userid=18f23036-305c-49ac-885f-97360edd611f) 12,430 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Problem with notifications in incoming calls, messages + screen sharing button becomes fully grey (not editable) in New Teams desktop app ](https://learn.microsoft.com/en-us/answers/questions/5786632/problem-with-notifications-in-incoming-calls-messa)
When someone calls me in teams, nothing pops up and I only see it in activity section as a missing call after they called me. In addition, when someone messages me, I don't see it as a pop-up message notification + I don't receive any sound…
Microsoft Teams | Microsoft Teams for business | Settings | Configure notifications
[ Microsoft Teams | Microsoft Teams for business | Settings | Configure notifications ](https://learn.microsoft.com/en-us/answers/tags/1176/office-teams-teams-business-settings-configure-notifications/)
Adjusting alert preferences for messages, mentions, and activity within Microsoft Teams
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
286 questions
Sign in to follow  Follow
asked Feb 24, 2026, 9:38 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2017%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EK%3C/text%3E%3C/svg%3E)
[KY](https://learn.microsoft.com/en-us/users/na/?userid=07bace1e-7eef-4ec2-b150-21e480adaa5b) 0 Reputation points
edited an answer Feb 24, 2026, 1:17 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(281.6,%2026%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKN%3C/text%3E%3C/svg%3E)
[Killian-N](https://learn.microsoft.com/en-us/users/na/?userid=8faaedd8-2d66-4ff7-9740-882d7e1ae45a) 9,130 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ Hybrid meetings with Teams & PowerPoint Live - Dual Display in meeting room ](https://learn.microsoft.com/en-us/answers/questions/5779861/hybrid-meetings-with-teams-powerpoint-live-dual-di)
Hi, I would like to use present some slides using powerpointlive on Teams with participants attending physically and virtually via. Teams. We would like to use powerpoint live, so that people can present from different locations, and for the attendees…
Microsoft Teams | Microsoft Teams for business | Meetings and calls | Screen sharing
[ Microsoft Teams | Microsoft Teams for business | Meetings and calls | Screen sharing ](https://learn.microsoft.com/en-us/answers/tags/1188/office-teams-teams-business-meetings-calls-screen-sharing/)
Displaying your screen content to others during a Teams meeting or call for collaboration
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
748 questions
Sign in to follow  Follow
asked Feb 18, 2026, 8:07 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(182.40000000000003,%2085%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKV%3C/text%3E%3C/svg%3E)
[Karthik Vemireddy](https://learn.microsoft.com/en-us/users/na/?userid=578a5175-318c-4a5b-b4be-fe99bda30135) 20 Reputation points
commented Feb 24, 2026, 1:02 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(172.8,%2049%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJT%3C/text%3E%3C/svg%3E)
[Jay Tr](https://learn.microsoft.com/en-us/users/na/?userid=b5ea44e9-cedc-4e4d-8854-d09c06b83680) 9,535 Reputation points • Microsoft External Staff • Moderator
  * [ ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=4)
  * ...
  * [ 2955 ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=2955)
  * [ ](https://learn.microsoft.com/en-us/answers/tags/777/office-teams?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Ftags%2F777%2Foffice-teams)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
