[ Skip to main content ](https://learn.microsoft.com/en-us/dynamics365/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/dynamics365/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/dynamics365/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/dynamics365/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/dynamics365/)
[ Dynamics 365  ](https://learn.microsoft.com/en-us/dynamics365/)
  * [ Release plans ](https://learn.microsoft.com/en-us/dynamics365/release-plans/)
  * [ Support ](https://learn.microsoft.com/en-us/dynamics365/get-started/support/)
  * [ Regional availability ](https://learn.microsoft.com/en-us/dynamics365/get-started/availability/)
  * [ Troubleshooting ](https://learn.microsoft.com/en-us/troubleshoot/dynamics-365/)
  * Resources
    * [ Trust Center ](https://go.microsoft.com/fwlink/?linkid=870937)
    * [ Marketplace ](https://marketplace.microsoft.com/)
    * [ Ideas ](https://experience.dynamics.com/ideas/)
    * [ Community ](https://community.dynamics.com/)
  * More
    * [ Release plans ](https://learn.microsoft.com/en-us/dynamics365/release-plans/)
    * [ Support ](https://learn.microsoft.com/en-us/dynamics365/get-started/support/)
    * [ Regional availability ](https://learn.microsoft.com/en-us/dynamics365/get-started/availability/)
    * [ Troubleshooting ](https://learn.microsoft.com/en-us/troubleshoot/dynamics-365/)
    * Resources
      * [ Trust Center ](https://go.microsoft.com/fwlink/?linkid=870937)
      * [ Marketplace ](https://marketplace.microsoft.com/)
      * [ Ideas ](https://experience.dynamics.com/ideas/)
      * [ Community ](https://community.dynamics.com/)


[ Get Dynamics 365 ](https://go.microsoft.com/fwlink/p/?linkid=864782) [ Free trial ](https://www.microsoft.com/dynamics-365/free-trial)
# Microsoft Dynamics 365 documentation
Discover how to deploy, customize, manage, and use Microsoft Dynamics 365 services and applications. Find documentation, training, sample code, tutorials, and more.
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-get-started.svg?branch=main)
Get started
[Start your Dynamics 365 journey](https://learn.microsoft.com/en-us/dynamics365/get-started/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-overview.svg?branch=main)
Overview
[Agents, Copilots, and AI capabilities in Dynamics 365](https://learn.microsoft.com/en-us/dynamics365/copilot/ai-get-started)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-deploy.svg?branch=main)
Deploy
[Find implementation guidance](https://learn.microsoft.com/en-us/dynamics365/guidance/index)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-get-started.svg?branch=main)
Get started
[Get a trial](https://www.microsoft.com/dynamics-365/free-trial)
### Business Central
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/business-central/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/business-central)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/business-central)


### Commerce
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/commerce/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-commerce)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/commerce)


### Sales in Microsoft 365 Copilot
  * [ Documentation ](https://learn.microsoft.com/en-us/microsoft-sales-copilot/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/modules/boost-sales-performance/)
  * [ Get started ](https://learn.microsoft.com/en-us/microsoft-sales-copilot/introduction)


### Service in Microsoft 365 Copilot
  * [ Documentation ](https://learn.microsoft.com/en-us/microsoft-copilot-service/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/modules/get-started-copilot-for-service/)
  * [ Get started ](https://learn.microsoft.com/en-us/microsoft-copilot-service/about-microsoft-copilot-for-service)


### Customer Insights
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/customer-insights/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?expanded=dynamics-365&products=customer-insights-data%2Ccustomer-insights-journeys)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/customer-insights)


### Customer Service
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/customer-service/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/customer-service)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/customer-service)


### Customer Voice
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/customer-voice/help-hub)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?products=customer-voice)


### Dynamics 365 Contact Center
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/contact-center/)
  * [ Training ](https://learn.microsoft.com/en-us/training/modules/get-started-contact-center/)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/contact-center)


### Field Service
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/field-service/user-guide)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/field-service)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/field-service)


### Finance
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/finance/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/finance)
  * [ Take a guided tour ](https://www.microsoft.com/dynamics-365/products/finance)


### Finance agents
  * [ Documentation ](https://learn.microsoft.com/en-us/copilot/finance/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/finance)
  * [ Get started ](https://learn.microsoft.com/en-us/copilot/finance/welcome)


### Fraud Protection
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/fraud-protection)


### Guides
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/mixed-reality/guides/index)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/guides)


### Human Resources
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/human-resources/hr-welcome)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?expanded=dynamics-365&products=dynamics-human-resources)
  * [ Take a guided tour ](https://www.microsoft.com/dynamics-365/products/human-resources)


### Intelligent Order Management
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/intelligent-order-management)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?expanded=dynamics-365&products=dynamics-iom&resource_type=module)


### Project Operations
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/project-operations/)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?expanded=dynamics-365&products=dynamics-project-operations&resource_type=learning%20path)
  * [ Take a guided tour ](https://www.microsoft.com/dynamics-365/products/project-operations)


### Remote Assist
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/mixed-reality/remote-assist/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/browse/?expanded=dynamics-365&products=dynamics-remote-assist&resource_type=learning+path)
  * [ Take a guided tour ](https://www.microsoft.com/dynamics-365/products/mixed-reality/remote-assist)


### Sales (Premium, Enterprise, Professional)
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/sales/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/sales)
  * [ Get a trial ](https://www.microsoft.com/dynamics-365/products/sales)


### Supply Chain Management
  * [ Documentation ](https://learn.microsoft.com/en-us/dynamics365/supply-chain/index)
  * [ Training ](https://learn.microsoft.com/en-us/training/dynamics365/scm)
  * [ Take a guided tour ](https://www.microsoft.com/dynamics-365/products/supply-chain-management)


[](https://learn.microsoft.com/en-us/dynamics365/#see-also)
## See also
###  [Microsoft Power Platform](https://learn.microsoft.com/en-us/power-platform/index)
Analyze data, build solutions, automate processes, and design modern websites
###  [Copilot Studio](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
Discover how to build AI-driven agents easily with Microsoft Copilot Studio
###  [Industry solutions](https://learn.microsoft.com/en-us/dynamics365/industry/index)
Use industry-specific solutions built using Dynamics 365 and Microsoft Power Platform
###  [Dynamics 365 table reference](https://learn.microsoft.com/en-us/dynamics365/developer/reference/about-entity-reference)
Find common tables for Dynamics 365 apps that use Dataverse
###  [Customer Engagement (on-premises)](https://learn.microsoft.com/en-us/dynamics365/customerengagement/on-premises/overview?view=op-9-1&preserve-view=true)
Go to documentation for the on-premises release
###  [Microsoft Teams integration](https://go.microsoft.com/fwlink/p/?linkid=2193500)
Go to the documentation for Microsoft Teams integration
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fdynamics365%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
