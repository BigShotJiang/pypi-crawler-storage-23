[ Skip to main content ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
# Browse all training
Learn new skills and discover the power of Microsoft products with step-by-step guidance. Start your journey today by exploring our learning paths and modules.
##  Filter
Clear all
* * *
###  Products
Find a product
Content will filter as you type
  * .NET
  * Azure
    * Azure AI Content Safety
    * Azure AI Foundry
    * Azure AI services
    * Azure AI Vision
    * Azure API Management
    * Azure Monitor
    * Azure OpenAI Service
    * Azure SQL Database
    * Azure Stream Analytics
    * Azure Synapse Analytics
  * Dynamics 365
    * Business Central
    * Commerce
    * Customer Engagement apps
    * Customer Insights - Data
    * Customer Insights - Journeys
    * Customer Service
    * Dynamics 365 Contact Center
    * Field Service
    * Finance
    * Human Resources
    * Intelligent Order Management
    * Project Operations
    * Sales
    * Supply Chain Management
  * Excel
  * Industry Solutions
  * Microsoft 365
    * Microsoft 365 Admin Center
    * Microsoft 365 Copilot
    * Microsoft 365 Copilot Chat
    * Microsoft 365 Education
  * Microsoft Copilot
  * Microsoft Defender
  * Microsoft Entra
  * Microsoft Fabric
  * Microsoft Power Platform
    * AI Builder
    * Microsoft Copilot Studio
    * Microsoft Dataverse
    * Power Apps
    * Power Automate
    * Power BI
    * Power BI Embedded
    * Power Pages
    * Power Query
  * Microsoft Purview
  * Microsoft Teams
  * Microsoft Teams Phone
  * Microsoft Website
    * Azure Marketplace
    * Microsoft AppSource
  * Office 365
  * OneDrive
  * OneNote
  * Outlook
  * SharePoint
  * SQL Server
  * Visual Studio Code
  * Windows
    * Windows Mixed Reality


###  Roles
Find a role
Content will filter as you type
  * Administrator
  * AI Edge Engineer
  * AI Engineer
  * App Maker
  * Auditor
  * Business Analyst
  * Business Leader
  * Business Owner
  * Business User
  * Data Analyst
  * Data Engineer
  * Data Scientist
  * Database Administrator
  * Developer
  * DevOps Engineer
  * Functional Consultant
  * Higher Education Educator
  * K-12 Educator
  * Network Engineer
  * School Leader
  * Security Engineer
  * Security Operations Analyst
  * Service Adoption Specialist
  * Solution Architect
  * Startup Founder
  * Student
  * Technical Writer
  * Technology Manager


###  Levels
  * Beginner
  * Intermediate
  * Advanced


###  Subjects
Find a subject
Content will filter as you type
  * Application development
    * Bots
    * Cross-platform development
    * DevOps
    * Mixed reality
  * Artificial intelligence
    * Chatbots
    * Classification and analysis
    * Generative AI
    * Machine learning
  * Business applications
    * Automation
    * Business reporting
    * Collaboration
    * Communication
    * Custom app development
    * Customer relationship management
    * Device management
    * E-commerce
    * Field service management
    * Finance and accounting
    * Knowledge management
    * Marketing and sales
    * Process and workflow
    * Productivity
    * Solution design
  * Data management
    * Data analytics
    * Data engineering
    * Data integration
    * Data modeling
    * Data storage
    * Data visualization
    * Databases
  * Security
    * Compliance
    * Identity and access
    * Information protection and governance
    * Insider risk
  * Technical infrastructure
    * Application management
    * Architecture
    * Cloud computing
    * IT management and monitoring
    * Networking


###  Types
  * Course
  * Learning Path
  * Module


Search
Search filters
Clear all
Microsoft Power Platform
##  490 results
Sort by:  Popular
  * Popular
  * Alphabetical (A-Z)
  * Alphabetical (Z-A)
  * Newest
  * Oldest


  * Module
[Get started building with Power BI](https://learn.microsoft.com/en-us/training/modules/get-started-with-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/get-started-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Discover data analysis](https://learn.microsoft.com/en-us/training/modules/data-analytics-microsoft/) ![](https://learn.microsoft.com/en-us/training/achievements/data-analytics-and-microsoft.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Learning Path
[Get started with Microsoft data analytics](https://learn.microsoft.com/en-us/training/paths/data-analytics-microsoft/) ![](https://learn.microsoft.com/en-us/training/achievements/overview-data-analysis-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get started with Copilot in Power BI](https://learn.microsoft.com/en-us/training/modules/power-bi-copilot/) ![](https://learn.microsoft.com/en-us/training/achievements/power-bi-module.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get data in Power BI](https://learn.microsoft.com/en-us/training/modules/get-data/) ![](https://learn.microsoft.com/en-us/training/achievements/get-data.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Clean, transform, and load data in Power BI](https://learn.microsoft.com/en-us/training/modules/clean-data-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/clean-transform-and-load-data-in-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Choose a Power BI model framework](https://learn.microsoft.com/en-us/training/modules/choose-power-bi-model-framework/) ![](https://learn.microsoft.com/en-us/training/achievements/choose-power-bi-model-framework.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Learning Path
[Prepare data for analysis with Power BI](https://learn.microsoft.com/en-us/training/paths/prepare-data-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/data-preparation-in-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Create visual calculations in Power BI Desktop](https://learn.microsoft.com/en-us/training/modules/power-bi-visual-calculations/) ![](https://learn.microsoft.com/en-us/learn/achievements/generic-badge.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Design Power BI reports](https://learn.microsoft.com/en-us/training/modules/power-bi-effective-reports/) ![](https://learn.microsoft.com/en-us/training/achievements/power-bi-effective-reports.svg)
    * Microsoft Power Platform
    * Business User
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Enhance Power BI report designs for the user experience](https://learn.microsoft.com/en-us/training/modules/power-bi-effective-user-experience/) ![](https://learn.microsoft.com/en-us/training/achievements/power-bi-effective-user-experience.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Scope report design requirements](https://learn.microsoft.com/en-us/training/modules/power-bi-effective-requirements/) ![](https://learn.microsoft.com/en-us/training/achievements/power-bi-effective-requirements.svg)
    * Microsoft Power Platform
    * Business User
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Explore fundamentals of data visualization](https://learn.microsoft.com/en-us/training/modules/explore-fundamentals-data-visualization/) ![](https://learn.microsoft.com/en-us/training/achievements/5-explore-fundamentals-of-data-visualization.svg)
    * Azure
    * Administrator
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Course
[Design and manage analytics solutions using Power BI](https://learn.microsoft.com/en-us/training/courses/pl-300t00/) ![](https://learn.microsoft.com/en-us/media/learn/certification/course.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan
  * Module
[Optimize a model for performance in Power BI](https://learn.microsoft.com/en-us/training/modules/optimize-model-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/optimize-model-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Modify DAX filter context in semantic models](https://learn.microsoft.com/en-us/training/modules/dax-power-bi-modify-filter/) ![](https://learn.microsoft.com/en-us/training/achievements/modify-dax-filter-context-power-bi-desktop.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Learning Path
[Model data with Power BI](https://learn.microsoft.com/en-us/training/paths/model-data-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/model-data-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Secure data access in Power BI](https://learn.microsoft.com/en-us/training/modules/row-level-security-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/row-level-security-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Write DAX formulas for semantic models](https://learn.microsoft.com/en-us/training/modules/dax-power-bi-write-formulas/) ![](https://learn.microsoft.com/en-us/training/achievements/dax-power-bi-write-formulas.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get started with Power Apps canvas apps](https://learn.microsoft.com/en-us/training/modules/get-started-with-powerapps/) ![](https://learn.microsoft.com/en-us/training/achievements/get-started-with-powerapps.svg)
    * Microsoft Power Platform
    * Business User
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Perform analytics in Power BI](https://learn.microsoft.com/en-us/training/modules/perform-analytics-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/perform-analytics-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Create dashboards in Power BI](https://learn.microsoft.com/en-us/training/modules/create-dashboards-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/create-dashboards-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Use DAX time intelligence functions in semantic models](https://learn.microsoft.com/en-us/training/modules/dax-power-bi-time-intelligence/) ![](https://learn.microsoft.com/en-us/training/achievements/use-dax-power-bi-desktop.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Manage semantic models in Power BI](https://learn.microsoft.com/en-us/training/modules/manage-datasets-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/manage-datasets-in-power-bi.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get started with Power Automate](https://learn.microsoft.com/en-us/training/modules/get-started-flows/) ![](https://learn.microsoft.com/en-us/training/achievements/get-started-with-flow.svg)
    * Microsoft Power Platform
    * Business User
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Turn insight into action by combining SAP and other data](https://learn.microsoft.com/en-us/training/modules/turn-insight-into-action-combine-sap-other-data/) ![](https://learn.microsoft.com/en-us/learn/achievements/turn-insight-into-action-combine-sap-other-data.svg)
    * Azure
    * Administrator
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Create reports with Power BI and Dataverse for Teams](https://learn.microsoft.com/en-us/training/modules/dataverse-teams-power-bi/) ![](https://learn.microsoft.com/en-us/training/achievements/dataverse-teams-power-bi.svg)
    * Microsoft Teams
    * Business User
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get started with Microsoft Dataverse for Teams](https://learn.microsoft.com/en-us/training/modules/get-started-dataverse-teams/) ![](https://learn.microsoft.com/en-us/training/achievements/get-started-dataverse-teams.svg)
    * Microsoft Power Platform
    * App Maker
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Build your first workflow with Power Automate and Dataverse for Teams](https://learn.microsoft.com/en-us/training/modules/build-first-workflow/) ![](https://learn.microsoft.com/en-us/training/achievements/build-first-workflow.svg)
    * Microsoft Power Platform
    * Business User
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Design scalable semantic models](https://learn.microsoft.com/en-us/training/modules/design-scalable-semantic-models/) ![](https://learn.microsoft.com/en-us/learn/achievements/generic-badge.svg)
    * Microsoft Fabric
    * Data Analyst
    * Advanced
Add
Add to Collections Add to plan Add to Challenges


  *   * 1
  * ...
  * 1
  * 2
  * 3
  * 4
  * ...
  * 10
  *

[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Ftraining%2Fbrowse%2F%3Fproducts%3Dpower-platform)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
