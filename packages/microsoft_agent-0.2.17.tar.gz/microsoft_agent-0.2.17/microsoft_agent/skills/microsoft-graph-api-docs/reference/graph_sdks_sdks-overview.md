[ Skip to main content ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph/context)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    *       * [Overview](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
      * [Install an SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation)
      * [Generate clients with Kiota](https://learn.microsoft.com/en-us/graph/sdks/generate-with-kiota)
      * [Create a client](https://learn.microsoft.com/en-us/graph/sdks/create-client)
      * [Customize a client](https://learn.microsoft.com/en-us/graph/sdks/customize-client)
      * [Choose an authentication provider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers)
      * [Connect to national clouds](https://learn.microsoft.com/en-us/graph/sdks/national-clouds)
      * [Create requests](https://learn.microsoft.com/en-us/graph/sdks/create-requests)
      * [Page through a collection](https://learn.microsoft.com/en-us/graph/sdks/paging)
      * [Create a batch request](https://learn.microsoft.com/en-us/graph/sdks/batch-requests)
      * [Upload large files](https://learn.microsoft.com/en-us/graph/sdks/large-file-upload)
      * [Use beta API](https://learn.microsoft.com/en-us/graph/sdks/use-beta)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=/graph/toc.json)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview)
  *     * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=/graph/toc.json)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/)


  1. [Learn](https://learn.microsoft.com/en-us/)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/sdks/sdks-overview.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fsdks%2Fsdks-overview%3FWT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fsdks%2Fsdks-overview%3FWT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fsdks%2Fsdks-overview%3FWT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fsdks%2Fsdks-overview%3FWT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Microsoft Graph SDK overview
Feedback
Summarize this article for me
##  In this article
  1. [Supported languages](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#supported-languages)
  2. [SDKs in preview or GA status](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-in-preview-or-ga-status)
  3. [SDK vs generated API client](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdk-vs-generated-api-client)
  4. [SDKs supportability](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-supportability)
  5. [Related content](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#related-content)


The Microsoft Graph software development kits (SDKs) are designed to simplify building high-quality, efficient, resilient applications that access Microsoft Graph. The SDKs include two components: a service library and a core library.
The _service library_ contains models and request builders generated from Microsoft Graph metadata. The service library provides a rich, strongly typed, and discoverable experience when working with the many datasets available in Microsoft Graph.
The _core library_ provides features that enhance working with all the Microsoft Graph services. Embedded support for retry handling, secure redirects, transparent authentication, and payload compression improve the quality of your application's interactions with Microsoft Graph with no added complexity while leaving you entirely in control. The core library also supports everyday tasks such as paging through collections and creating batch requests.
[](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#supported-languages)
## Supported languages
SDKs are currently available for the following languages:
  * [C#](https://github.com/microsoftgraph/msgraph-sdk-dotnet)
  * [CLI](https://github.com/microsoftgraph/msgraph-cli)
  * [PowerShell](https://github.com/microsoftgraph/msgraph-sdk-powershell)
  * [TypeScript | JavaScript](https://github.com/microsoftgraph/msgraph-sdk-javascript)
  * [Java](https://github.com/microsoftgraph/msgraph-sdk-java)
  * [Go](https://github.com/microsoftgraph/msgraph-sdk-go)
  * [PHP](https://github.com/microsoftgraph/msgraph-sdk-php)
  * [Python](https://github.com/microsoftgraph/msgraph-sdk-python)


[](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-in-preview-or-ga-status)
## SDKs in preview or GA status
A release of an SDK can be in _preview_ status upon debut or a significant update. Don't assume a preview release is always promoted to generally available (GA) status.
In addition, don't use a preview release of an SDK in production apps, regardless of the version of Microsoft Graph API (v1.0 or beta) it uses.
A release of an SDK in _GA_ status can use the Microsoft Graph API v1.0 endpoint or beta endpoint as specified. Because Microsoft Graph APIs in the beta endpoint are subject to breaking changes, don't use the production apps a GA release of an SDK that accesses the Microsoft Graph API beta endpoint.
[](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdk-vs-generated-api-client)
## SDK vs generated API client
In some cases, it's beneficial to use a Kiota-generated client instead of a Microsoft Graph SDK. For example, a developer that only uses a small subset of the Microsoft Graph APIs and wants to minimize the overall install size of their app can use Kiota to generate a smaller client library. For details, see [Generate Microsoft Graph client libraries with Kiota](https://learn.microsoft.com/en-us/graph/sdks/generate-with-kiota).
[](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-supportability)
## SDKs supportability
Microsoft Graph SDKs are open-source GitHub projects so if you have an issue with the SDK, submit it with all the needed information on the "issues" page. SDK authors and contributors should look into the issue and release a fix accordingly. Microsoft CSS doesn't officially, support SDKs but Microsoft supports the HTTP request of the Microsoft Graph API call you're making.
[](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#related-content)
## Related content
  * Learn more about the features and capabilities of the SDK in the [design requirements documentation](https://github.com/microsoftgraph/msgraph-sdk-design).
  * Request or vote on new features at the [Microsoft 365 Developer Platform ideas forum](https://techcommunity.microsoft.com/t5/microsoft-365-developer-platform/idb-p/Microsoft365DeveloperPlatform/label-name/Microsoft%20Graph).
  * Learn about [generating Microsoft Graph client libraries with Kiota](https://learn.microsoft.com/en-us/graph/sdks/generate-with-kiota) as an alternative to using an SDK.


* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ Install a Microsoft Graph SDK - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation?source=recommendations)
Find instructions for installing the Microsoft Graph SDKs for .NET, Go, Java, JavaScript, PHP, PowerShell, and Python.
  * [ Make API calls using the Microsoft Graph SDKs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/sdks/create-requests?source=recommendations)
Provides instructions for creating Microsoft Graph HTTP requests using the SDKs.
  * [ Use Graph Explorer to try Microsoft Graph APIs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?source=recommendations)
Try Microsoft Graph APIs on the default sample tenant to explore capabilities, or sign in to your tenant and use it as a prototyping tool to fulfill your app scenarios.
  * [ Create a Microsoft Graph client - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/sdks/create-client?source=recommendations)
Describes how to create a client to use to make calls to Microsoft Graph. Includes how to set up authentication and select a sovereign cloud.
  * [ Use the Microsoft Graph SDKs with the beta API - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/sdks/use-beta?source=recommendations)
Describes how to use the Microsoft Graph SDKs with the beta version of the API.
  * [ Microsoft Graph tutorials - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/tutorials/?source=recommendations)
Create a basic application that accesses data via Microsoft Graph in 30 minutes by using a step-by-step Microsoft Graph tutorial.
  * [ Microsoft Graph REST API v1.0 endpoint reference - Microsoft Graph v1.0 ](https://learn.microsoft.com/en-us/graph/api/overview?source=recommendations)
Find reference content for Microsoft Graph REST APIs in the v1.0 endpoint, which includes APIs in general availability (GA) status.


Show 4 more
Module
[ Explore Microsoft Graph - Training ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
Explore Microsoft Graph
Certification
[ Microsoft Certified: Azure Developer Associate - Certifications ](https://learn.microsoft.com/en-us/credentials/certifications/azure-developer/?source=recommendations)
Build end-to-end solutions in Microsoft Azure to create Azure Functions, implement and manage web apps, develop solutions utilizing Azure storage, and more.
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 24, 7 PM - Feb 24, 7 PM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 02/11/2025


##  In this article
  1. [Supported languages](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#supported-languages)
  2. [SDKs in preview or GA status](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-in-preview-or-ga-status)
  3. [SDK vs generated API client](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdk-vs-generated-api-client)
  4. [SDKs supportability](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#sdks-supportability)
  5. [Related content](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview#related-content)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fsdks%2Fsdks-overview)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
