class CCDUtilsError(Exception):
    """Internal error of the pdbeccdutils package."""

    pass


class EntryFailedException(Exception):
    pass
