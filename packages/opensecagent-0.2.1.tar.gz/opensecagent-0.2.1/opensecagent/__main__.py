# OpenSecAgent - Allow running as python -m opensecagent
from opensecagent.main import main

if __name__ == "__main__":
    main()
