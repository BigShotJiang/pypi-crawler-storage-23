# OpenSecAgent - Autonomous Server Cybersecurity Expert Bot
__version__ = "0.2.0"
