# Changelog

## 0.26.0 (2026-02-21)

Full Changelog: [v0.25.0...v0.26.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.25.0...v0.26.0)

### Features

* **api:** api update ([0766e64](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0766e643163c62a7dd0bd8a4219807e92d324151))
* **api:** api update ([927b45e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/927b45e5de52bd9720eb8486bcb2bd1f4a09330e))
* **api:** api update ([d625a8a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d625a8a26cbca08bc38b7fd367c2ad28d5686cf1))


### Chores

* **internal:** remove mock server code ([6b394ce](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6b394ce756627f541073a7c4f4f8de133d3597b1))
* update mock server docs ([e26196f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e26196f9901de7c45b147ecf9cfacd81a6d21f8c))

## 0.25.0 (2026-02-16)

Full Changelog: [v0.24.0...v0.25.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.24.0...v0.25.0)

### Features

* **api:** api update ([806ed74](https://github.com/cooper-square-technologies/profound-python-sdk/commit/806ed74a22943cc3e0c5b2a94aa912f3d5fcfbac))


### Chores

* format all `api.md` files ([b20620e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b20620ef7f2a4bbd2dd16187ce2cc9055d838a6f))
* **internal:** fix lint error on Python 3.14 ([dad311b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/dad311b8613dd97aaf284a8f27542d1a421d853e))

## 0.24.0 (2026-02-10)

Full Changelog: [v0.23.0...v0.24.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.23.0...v0.24.0)

### Features

* **api:** api update ([13de2c2](https://github.com/cooper-square-technologies/profound-python-sdk/commit/13de2c24d8d801e6c559462b0b4be4c865f44bf6))


### Chores

* **internal:** bump dependencies ([1f760c8](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1f760c819d22c5cd47781a6e7c08d3429fd2dac3))

## 0.23.0 (2026-02-06)

Full Changelog: [v0.22.0...v0.23.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.22.0...v0.23.0)

### Features

* add sentiment report example ([633d470](https://github.com/cooper-square-technologies/profound-python-sdk/commit/633d47039e7fe5de61a9a2be52a9d874b0f932ce))
* **api:** `asset_name_filter` as shared model ([8ef47c6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8ef47c6bc0fa79568311dcbcba5cde5ee0eac3b4))
* **api:** api update ([d1e58a4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d1e58a4ecf96dc89ccd074db868595624ce91f12))
* **api:** api update ([4f2583a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4f2583a2de0cce40a6c7bb13c48cb13de4b75c7a))
* **api:** api update ([e0bc1ab](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e0bc1abf911278ca496f47cbb97620b73abf918b))
* **api:** api update ([6126bed](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6126bedea6451ea346da288b41c9451bd938bab1))
* **api:** api update ([5e6e219](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5e6e21910839035536b882cb7df2697bdd9d0112))
* **api:** api update ([a88dd7d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a88dd7d7e6c0e92cd11b1bda2d81043e11f75c24))
* **api:** api update ([08f67be](https://github.com/cooper-square-technologies/profound-python-sdk/commit/08f67bebe1255694775534f6d08773cb4876b926))
* **api:** api update ([af59cdf](https://github.com/cooper-square-technologies/profound-python-sdk/commit/af59cdf3475fd3b472ea0b418045693ff01ddc84))
* **api:** api update ([54d609e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/54d609e4b45a627a7ed81ccfe29c59496b1cdf1e))
* **api:** api update ([75e77df](https://github.com/cooper-square-technologies/profound-python-sdk/commit/75e77dfe7dbb2e1621c2265975f2ae6f9c3bba50))
* **api:** api update ([95b6c1b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/95b6c1ba5128890362864c0dafda243e441d7823))
* **api:** api update ([5ac1330](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5ac13307b60d8a19e53a8d1a122844c0cb78f37b))
* **api:** api update ([e1bd7fe](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e1bd7fec458fe2ae7b2a89dbeeeb5e89abb4924e))
* **api:** api update ([7b6b0ac](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7b6b0acc95387e2e7e761159833560e6a517c34e))
* **api:** api update ([e5874e7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e5874e7926ca2b4ad50f0532a48115337f42068e))
* **api:** api update ([b696adf](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b696adfd0758dc78724a7bc1149765a3684231b8))
* **api:** api update ([e5c5301](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e5c5301d4aa47a4ac333f8efe4918a61ccdbc705))
* **api:** api update ([3832289](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3832289ed984cc219d4bdaab78c28bc86c139f62))
* **api:** api update ([4f0f845](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4f0f84501e794569744169c7acb0c2261001a637))
* **api:** api update ([6a7ac4e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6a7ac4e19194377d21c0c1762d53c57e82e5ee41))
* **api:** api update ([5cc691f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5cc691f5c2b0d1995f205cbc5ecd9ccd8290cefb))
* **api:** api update ([870a189](https://github.com/cooper-square-technologies/profound-python-sdk/commit/870a1890d6c4b322921ccd9a26d6264aec7b6d6e))
* **api:** api update ([a7c9d95](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a7c9d951c6eaa77fb0692bd06c759e93e3e9e63e))
* **api:** api update ([7f7f0fa](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7f7f0fa896ba40bbcb77f0bf64a720d1c3c3b9f0))
* **api:** api update ([1738cbe](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1738cbed2f41a20a29363d9afd80236baef79af3))
* **api:** api update ([085d9f8](https://github.com/cooper-square-technologies/profound-python-sdk/commit/085d9f8399770b47cb271f42ea2814892bda1837))
* **api:** api update ([ca8d06a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ca8d06a7e6d6dc5dcd4b0aa6f7250f6a7dd9bdd3))
* **api:** api update ([975386d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/975386dfb4378c2e9297cb60483dfdc79b3a108d))
* **api:** api update ([328a5b9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/328a5b9edbf3882093614578d0a1c3efa645071b))
* **api:** api update ([e64768f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e64768fc78d1f8adbf3b5a4a30e7fa85ccd7e1b3))
* **api:** api update ([85aeea0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/85aeea01161ff74a9551bac45a1f78122bb4c18d))
* **api:** api update ([98e5e71](https://github.com/cooper-square-technologies/profound-python-sdk/commit/98e5e71a9faa6e4c1582302a176567dd6fe3771a))
* **api:** api update ([d8f71c4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d8f71c41e06888fde3f409476e27b0c2b4026d1a))
* **api:** api update ([f1108e2](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f1108e217ef145b1f92ddcba3f1b5a380a8c60c1))
* **api:** api update ([999ea59](https://github.com/cooper-square-technologies/profound-python-sdk/commit/999ea59c766ee8c477ae7ab326049396f34ad031))
* **api:** api update ([7313d63](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7313d63d1a15a4ca15c2b1ef2b3a0519bdaf9106))
* **api:** api update ([926ca47](https://github.com/cooper-square-technologies/profound-python-sdk/commit/926ca473d53ee6a9f17624e6d3e3e2b25a442e3d))
* **api:** api update ([d3dd09a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d3dd09a39640de617dc371abf214591c9a0164d0))
* **api:** api update ([14eb23c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/14eb23ce4b4589995c78f40246a2148418232fba))
* **api:** api update ([096737f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/096737fe83e68b492d3369262c8ab82edad4637d))
* **api:** api update ([4072456](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4072456a52e3216568b169be62431bb71a5297b5))
* **api:** api update ([15061db](https://github.com/cooper-square-technologies/profound-python-sdk/commit/15061db9cb6f2a6727a62a500ee8c719089c48b9))
* **api:** api update ([01f84df](https://github.com/cooper-square-technologies/profound-python-sdk/commit/01f84df31950f53ca554200e1886343559b96c5f))
* **api:** api update ([e964fd3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e964fd3926b8e649f8562668926f099709c5257e))
* **api:** api update ([c44df9b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c44df9bc6cc2aa8c104e06a22c2d80683a3dec64))
* **api:** api update ([20ac929](https://github.com/cooper-square-technologies/profound-python-sdk/commit/20ac929aaff63c6915e1d8e54c0044bab0b37dae))
* **api:** api update ([67859d5](https://github.com/cooper-square-technologies/profound-python-sdk/commit/67859d581c5b5c5d42339d6f99e1b582296a7aca))
* **api:** api update ([e6698e1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e6698e1832663b74282bb546f5835051562ea4af))
* **api:** api update ([f15139f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f15139ffc374eee528fa796b4736fd35ab3fa33f))
* **api:** api update ([1362b07](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1362b07dc91f38f77e199df714b9f745e1d2aae5))
* **api:** api update ([bcb16a6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/bcb16a6be98fd8abe564126143c5d82c9b076726))
* **api:** api update ([c5a5e26](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c5a5e26344e3c99c850c667df814abd90cd105a4))
* **api:** api update ([536d904](https://github.com/cooper-square-technologies/profound-python-sdk/commit/536d904539ea6c31854be8758c13c521414a2784))
* **api:** api update ([b752022](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b752022d62982ac5b7e1bf1f2a40a396db7732c4))
* **api:** api update ([98add3d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/98add3d78f6e8d6e1227cc4ef7f72e5091f6b95c))
* **api:** api update ([feefc70](https://github.com/cooper-square-technologies/profound-python-sdk/commit/feefc70ef7dcf6e5a55403a3d18d050243dbe29d))
* **api:** api update ([6d1254f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6d1254f3214a42bf7ce5f3c45619cb9b4b626787))
* **api:** api update ([1251abd](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1251abdf8b6d9ccce7b067be07dfc6f3bec8e117))
* **api:** api update ([af5caf5](https://github.com/cooper-square-technologies/profound-python-sdk/commit/af5caf5433df514d77860f4e3eb1eeec25bc79cd))
* **api:** api update ([9bfee9b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9bfee9b5e1939043655c0e642df6ba557cf59ad4))
* **api:** api update ([bd68065](https://github.com/cooper-square-technologies/profound-python-sdk/commit/bd68065b41defc9eed2201abd9f10b8f51f3174d))
* **api:** api update ([afe4769](https://github.com/cooper-square-technologies/profound-python-sdk/commit/afe476906ba8c76b465941b111a4bfdcd77c7153))
* **api:** api update ([9389567](https://github.com/cooper-square-technologies/profound-python-sdk/commit/938956718eedcedcfbafa5c12b9f7d8d7e9e0789))
* **api:** api update ([e794340](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e7943400ba28608442fcc5b2cf79daadbe4d4674))
* **api:** shared models ([2b554d6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2b554d6c2368fdd5ad0ffe013cb69a4fa84b7fda))

## 0.22.0 (2026-02-01)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.21.0...v0.22.0)

### Features

* **api:** api update ([718f40d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/718f40d63a1c4b807ddeb4e9cc7077220fde5f42))
* **api:** api update ([a7dc82d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a7dc82d174b8a9b5873fc7b2b6b6d7ae38675a19))
* **api:** api update ([33ebe8f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/33ebe8f5d0088957d90f876e0a2b8296f080bf62))
* **api:** api update ([9ce0e3a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9ce0e3a5eba2cd1790d3fc4ce18bddc75200d3a9))
* **api:** api update ([1881182](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1881182d8920ef4a8b53df8059723b673bf30fd8))
* **api:** api update ([8bc7f55](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8bc7f553c128caa60d3ee7032c030bd2bdf98cd6))
* **api:** api update ([9fbc355](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9fbc3557542cf60c8136873bd12fc28831f622c7))
* **api:** api update ([d8c1a58](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d8c1a584b6cae074eabefd3fd4e8609aecc05c8a))
* **api:** api update ([b2f96c9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b2f96c97c95114be9dbd894ce7bb2e2196e13d0f))
* **api:** api update ([1b4eaeb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1b4eaeb9ae1189e1c4642e55cc4014afd2ed70a2))
* **api:** api update ([e7094ff](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e7094ff17d73e56439db283ddc40d047394e4e19))
* **api:** api update ([f2e85b8](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f2e85b80c3cab1f85fef8c2a726350d916dbdcd9))
* **api:** api update ([61a7f4f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/61a7f4feaf0919ff8afb5d6271966b918701fa75))
* **api:** api update ([624b623](https://github.com/cooper-square-technologies/profound-python-sdk/commit/624b62303cc287fea5d1d0e3da10364d3f5dcebd))
* **api:** api update ([48c6a0d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/48c6a0dff775583c600da9e67273591e6cda3b6a))
* **api:** api update ([3860e9e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3860e9e510c9f3cd1f5ab9230d79c7e01e2ebb9e))
* **api:** api update ([30075dc](https://github.com/cooper-square-technologies/profound-python-sdk/commit/30075dc78be0de8a881835da9487664d4f2809ee))
* **api:** api update ([88e0399](https://github.com/cooper-square-technologies/profound-python-sdk/commit/88e0399ca844640176f8258716a02c04a6600871))
* **api:** api update ([95e0b04](https://github.com/cooper-square-technologies/profound-python-sdk/commit/95e0b047d2ffa0802100f0d7b1f819613d9ba3d7))
* **api:** api update ([dfa9ad4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/dfa9ad40d18507a8d97045d1a69ccfaac7c94797))
* **api:** api update ([fa19029](https://github.com/cooper-square-technologies/profound-python-sdk/commit/fa19029ea0d89e96a0ea2965f3c96c8068d1cd93))
* **api:** api update ([95584ca](https://github.com/cooper-square-technologies/profound-python-sdk/commit/95584caf6940ada8ab85d3cf57ad19b174f78cc5))
* **api:** api update ([85d1390](https://github.com/cooper-square-technologies/profound-python-sdk/commit/85d13902e54ea3cc38f3e6e5d6bacd3b170b3d41))
* **api:** api update ([963871e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/963871e570d380ed8ca873898727169aee3e1b09))
* **client:** add custom JSON encoder for extended type support ([01eea2f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/01eea2fa4a545dbed2848ec7ca1cde1be54ef00a))

## 0.21.0 (2026-01-29)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.20.0...v0.21.0)

### Features

* **api:** api update ([faa67ee](https://github.com/cooper-square-technologies/profound-python-sdk/commit/faa67ee0a6025217cb3186861500db18af2172f8))
* **api:** api update ([3cb8296](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3cb8296202e25e2119f1336396ccf52bea149cc8))
* **api:** api update ([cdcdd11](https://github.com/cooper-square-technologies/profound-python-sdk/commit/cdcdd117a85061500171d15e1d918fa457120bee))
* **api:** api update ([d3de283](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d3de28341be4eaab9297becefed54f1ee790d68c))
* **api:** api update ([a048cba](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a048cba6b2575f3d8680647bf8648a0c902e5d5e))
* **api:** api update ([2e11b8b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2e11b8b0cf095f832e567aba78f6fc1f33996adb))
* **api:** api update ([22c6325](https://github.com/cooper-square-technologies/profound-python-sdk/commit/22c6325ebfa042a1d6b8ad08306b2d92c03dd80b))
* **api:** api update ([2bb8ee6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2bb8ee652fddb659f7a361f0ec083c3c44eec384))
* **api:** api update ([fe5eee3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/fe5eee3b55e684a61b66b5be23c033c12e95ebbc))
* **api:** api update ([705a4b7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/705a4b793e59dc7cad4ca17e5c1b877d8bfd8d26))
* **api:** api update ([83ffeb0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/83ffeb09e2fcc5f8f7b0bd37669db114c9c78701))
* **api:** api update ([8bf510c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8bf510ccd323ce223d95298e6c29991ee0a16827))
* **api:** api update ([79946a7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/79946a7abfdabfcea529700b679e62564b551a07))
* **api:** api update ([946e4f7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/946e4f77c16285aa770ea66e1f1701d234385d61))
* **api:** api update ([6549dde](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6549dde8a61308759544093fb7a30863b51d5d47))
* **api:** api update ([ca774f3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ca774f3cc7e56d66fd6640a5b97d807709c428ac))
* **api:** api update ([463f51c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/463f51c29d44d11b16091528d5f89794f5818ca9))
* **api:** api update ([0fdd7bb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0fdd7bb400437469c31493e819eaf5c71b76cfc5))
* **api:** api update ([69d2c56](https://github.com/cooper-square-technologies/profound-python-sdk/commit/69d2c562ea8fafccc4b8a5f82fbceb9f3be74120))
* **api:** api update ([e27f1a3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e27f1a3e440cb199acd276483753a13738f2a006))
* **api:** api update ([a5ed739](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a5ed7391096624654cc331e10a4115dacc73e07e))
* **api:** api update ([ec2dc51](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ec2dc5137245785202f0e27ef2e4efe728661c95))


### Bug Fixes

* **docs:** fix mcp installation instructions for remote servers ([9314cf0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9314cf08b83efacbfffe4c68f8409bf5029084c4))

## 0.20.0 (2026-01-27)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.19.0...v0.20.0)

### Features

* **api:** api update ([85cf403](https://github.com/cooper-square-technologies/profound-python-sdk/commit/85cf403d9962ccb61c4fa152139819f55c3d2edc))
* **api:** api update ([ac66001](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ac660011e3332b20da8306ab76bc6c303aa21722))
* **api:** api update ([13307ec](https://github.com/cooper-square-technologies/profound-python-sdk/commit/13307ec0fbab2e8cb89bdaf6c7ced7b36b4ff033))
* **api:** api update ([0158a0a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0158a0a971172ec3c370674d741102c1aeac245c))
* **api:** api update ([f6583a9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f6583a9b396411f404b9c19c015c8e7035259968))
* **api:** api update ([a884b41](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a884b417f509ef368ab3351e92bd508dc8183fc4))
* **api:** api update ([4ceb954](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4ceb95411fa1ea9e82cdb03ca507fef784c6f6ce))
* **api:** api update ([5533b60](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5533b601bf3f395b2c2d4bd52ea7d1fbf5ca06c7))
* **api:** api update ([960f4dd](https://github.com/cooper-square-technologies/profound-python-sdk/commit/960f4dde70574a694cd26af00dfe82930464dfc4))
* **api:** api update ([9b1be30](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9b1be30f1488d9b52f135c53c25e7455a4cbfd60))
* **api:** api update ([0cc54df](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0cc54df4ac32c016c108bde30d96e12dee5bb744))
* **api:** api update ([0e383ec](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0e383ec5a6137f9338d2af8963decd4fc47d5b15))
* **api:** api update ([cb59516](https://github.com/cooper-square-technologies/profound-python-sdk/commit/cb59516b8ec9dcaf15feab6f17981ce6c08f7c2e))
* **api:** api update ([3f2c88b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3f2c88b5917e6ab3ac9b9df16491dc862762d9f4))
* **api:** api update ([01791ce](https://github.com/cooper-square-technologies/profound-python-sdk/commit/01791ce69243545c71d8791aac0d252525f83487))
* **api:** api update ([c648cdf](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c648cdfe4d506ef2963a82ff37e31fc982ee40b4))
* **api:** api update ([b469201](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b4692012016f86f84dfdc82b77f77a4b1c09b987))
* **api:** api update ([51cafb4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/51cafb47bf93697816dfed9fe576421534eae259))
* **api:** api update ([38c6a29](https://github.com/cooper-square-technologies/profound-python-sdk/commit/38c6a29a4e13230e38b495968dceca1bdeac2e4e))
* **api:** api update ([8185a9e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8185a9e138991051751d873707f5e443f503df84))
* **api:** api update ([68347fa](https://github.com/cooper-square-technologies/profound-python-sdk/commit/68347faab2482d16a8d5d1a84cc44b657b22e54b))
* **api:** api update ([c5f7c9c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c5f7c9c903351a7d04315a6067fa336b9cf73662))
* **api:** api update ([1b27615](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1b27615bed1c57e3dd45e5a968a6c3d7ac4d5ac5))
* **api:** api update ([28a272f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/28a272fab28724c3fc243a2215e57b0953d2586f))
* **api:** api update ([92f2cd9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/92f2cd9184a38266357723be8c5ecc0f1935cd2c))
* **api:** api update ([dda6612](https://github.com/cooper-square-technologies/profound-python-sdk/commit/dda66126f2d3c1f45d681a6bc804d4420279b854))
* **api:** api update ([c0c9e83](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c0c9e8390b142e7aeb5e3f09224f6404a590fd93))
* **api:** api update ([38bd72c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/38bd72c1821ac018bc82ca9439225ac65c3084e2))
* **api:** api update ([3e62926](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3e62926d9e095ce00e8051e19454ba9f0c0ffd4e))
* **api:** api update ([072f6d3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/072f6d3fb4357bb68c79537d4c144a4f725fbd00))
* **api:** api update ([6893fd0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6893fd012bee701802fa62fa078ba458b334734f))
* **api:** api update ([9935945](https://github.com/cooper-square-technologies/profound-python-sdk/commit/99359456f4a18b4065e32cf4c6f37d8d640e5274))
* **api:** api update ([ffe33ef](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ffe33ef6206a7f3482e681547613d91f40b175b5))
* **api:** api update ([5244800](https://github.com/cooper-square-technologies/profound-python-sdk/commit/52448000023284904c032b1178400238eeb2f5ca))
* **api:** api update ([44669b5](https://github.com/cooper-square-technologies/profound-python-sdk/commit/44669b53865c41c52a9013b04bc1801a3eaf4546))
* **api:** api update ([e0bbabb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e0bbabb2a26113d0d0c899197ed2bf39b5fad7e0))
* **api:** api update ([a106618](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a1066187f34eedaa47e627f1256523f60c239caf))
* **api:** api update ([418c60c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/418c60c697fd793edc2cee6ef25d2911efb1f15f))
* **api:** api update ([e271c54](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e271c54672edd73cc63218dc3c6dbc612de4c7e6))
* **api:** api update ([6effa88](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6effa88ab228ad3e9f4b944ae0e412a4fea502fc))
* **api:** api update ([a7a8344](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a7a83447a1ad303309c976d2a347caf46fc49aa5))
* **api:** api update ([2380732](https://github.com/cooper-square-technologies/profound-python-sdk/commit/23807320f9b4d8c47bf6dd60739295ece81dd97c))
* **api:** api update ([c067eeb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c067eebed06afc48d5a8e27662cc04352f6701fc))
* **api:** api update ([5720469](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5720469ebc66284b6af15772b25351ae9c7828c1))
* **api:** api update ([1638edb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1638edb61ac2691374618c5372310a99b56d92e4))
* **api:** api update ([4e32ecf](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4e32ecf37ae1cc540101dcdb2ea5f2165b223e45))
* **api:** api update ([7061048](https://github.com/cooper-square-technologies/profound-python-sdk/commit/70610486270044629d8322aff490be80298cd1e4))
* **api:** api update ([7fbd513](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7fbd513f2620662c80ed1c2245522c46a9db3d00))
* **api:** api update ([92ba8f0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/92ba8f0f9d7f29f09f0beabe329a69d2e0f3b5b6))
* **api:** api update ([3dd8cb7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3dd8cb745635fe5b1306015c68c0dd7d414f02e9))
* **api:** api update ([0559b7d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0559b7dcea182b99d25a9ab73c10448c3bc567a1))
* **api:** api update ([ed0a463](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ed0a463d1b8d7dc97ac0f77c18e87b1f9891862d))
* **api:** api update ([4df112c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4df112c87bee62090e00e931f6bc63163a30bb52))
* **api:** api update ([a753451](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a7534517bbd09810881e8544aa81089e5de88892))
* **api:** api update ([3033112](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3033112450668184d8c9c4a5f123bc1843bb7ccf))
* **api:** api update ([72a92c0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/72a92c0920dddf0b81e18dfda80326bc251fa02a))
* **api:** api update ([ee20454](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ee2045477c56385af9508e20111b1911f12f8f19))
* **api:** api update ([4f499cd](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4f499cd0629ade0494167ade4bbeacfe81224727))
* **api:** api update ([2480069](https://github.com/cooper-square-technologies/profound-python-sdk/commit/24800696c24967fdc116575928d8531f16981db9))
* **api:** api update ([6376a56](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6376a56704acc0ecf3eeb5db6fdb4bddd8d73651))
* **api:** api update ([b6876a5](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b6876a5bbaa36c2eb53dd91591f777c7957d0b5d))
* **api:** api update ([1a8ad13](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1a8ad138ba2f1a2506cb97fe33dbf9505b5f6b99))
* **api:** api update ([f6c5b17](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f6c5b1782137e8302a83fc9822b5fd4f68300337))
* **api:** api update ([14799ab](https://github.com/cooper-square-technologies/profound-python-sdk/commit/14799ab24e025bbb6563cc707819d619acfe9c63))
* **api:** api update ([06cebba](https://github.com/cooper-square-technologies/profound-python-sdk/commit/06cebbad0292b4e421f6a4e4291059f9402267f4))
* **api:** api update ([2512f3e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2512f3eeff0cf16aac5b4ac72a06cec97b53d837))
* **api:** api update ([326d6fe](https://github.com/cooper-square-technologies/profound-python-sdk/commit/326d6fee5e49c6e3bfa935cec0d7fb7758b3e345))
* **api:** api update ([f92ef8b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f92ef8bcddd737ab30b89991aa33e6a3e0b8e9b3))
* **api:** api update ([675a7a9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/675a7a992912bd8c950f512f0718943d8746d996))
* **api:** api update ([0e6f937](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0e6f937750f19be2def2857a7fd5d7b2d6c96f35))
* **api:** api update ([6f238fc](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6f238fceedc36dff597a76d187f5b5d341b5a0f1))
* **api:** api update ([e58a063](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e58a063e2039ef10f8e921680f5cac3996c1a246))
* **api:** api update ([d3a82da](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d3a82da3d994551ffb01e64af88e35dd9cca9945))
* **api:** api update ([bfaa678](https://github.com/cooper-square-technologies/profound-python-sdk/commit/bfaa67892d4cffb99493d550494ca3ac05516400))
* **api:** api update ([a6884d4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a6884d47ab38f9ca39ffb7ccb6a7087f588085fe))
* **api:** api update ([e3f9524](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e3f9524d3e8b99f74f8e8791ca1f9a8f67d62aa6))
* **api:** api update ([048daae](https://github.com/cooper-square-technologies/profound-python-sdk/commit/048daae8b79aa71f5c4b836722c70fb9b314fbe4))
* **api:** api update ([d66e6b6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d66e6b6d3fd0b4481150b92a18046e7459f18e0e))
* **api:** api update ([16ad7d2](https://github.com/cooper-square-technologies/profound-python-sdk/commit/16ad7d29488aeb49d897ed553acf87f0c19c8446))
* **api:** api update ([2f44dac](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2f44dacc527f3863d964aeff30470873eabebb77))
* **api:** api update ([c52cb46](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c52cb46c511e500b9a4b1bf4eb9d7a1c267d7c6c))
* **api:** api update ([d338c82](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d338c82c0533dbd85ad99f3e07a5f916d9addc2b))
* **api:** api update ([22de244](https://github.com/cooper-square-technologies/profound-python-sdk/commit/22de244adb8ed326b964e071249896d3ae9c0337))
* **api:** api update ([582c554](https://github.com/cooper-square-technologies/profound-python-sdk/commit/582c55460fd6ac3008df284efced6275aeaa4deb))
* **api:** api update ([1ea527d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1ea527dbff047d8a9b910978bbfd85c6c30210d6))
* **api:** api update ([de79298](https://github.com/cooper-square-technologies/profound-python-sdk/commit/de79298406cfd90fdb7aa385a67a72f97dacb6e8))


### Chores

* **ci:** upgrade `actions/github-script` ([83be57a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/83be57a976264c633d31b33ad57a845c0417a846))

## 0.19.0 (2026-01-19)

Full Changelog: [v0.18.1...v0.19.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.18.1...v0.19.0)

### Features

* add notebook with examples ([0c23aac](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0c23aac7bf80d6591f74f6b9fad75e3fe4bef61b))
* **api:** api update ([3159dc4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3159dc483cc499f1d2afe7a8df863b1a3846abe7))
* **python:** bump edition to `python.2025-11-20` ([365b035](https://github.com/cooper-square-technologies/profound-python-sdk/commit/365b0354c5a26a696d3b11fd411bb27a9335e940))


### Chores

* **style:** lint ([b67bd92](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b67bd92aa8ba4d05beafc4afbdaf848d920e77da))

## 0.18.1 (2026-01-17)

Full Changelog: [v0.18.0...v0.18.1](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.18.0...v0.18.1)

### Chores

* **internal:** update `actions/checkout` version ([a7ada13](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a7ada137690c196e367c278587a162d5c0f0e149))

## 0.18.0 (2026-01-16)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.17.0...v0.18.0)

### Features

* **api:** api update ([b06ca33](https://github.com/cooper-square-technologies/profound-python-sdk/commit/b06ca33336a67c44864052519acb711230bbabb8))
* **api:** api update ([cdda1d0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/cdda1d0555d4a8f49064a2755168c8c6b0fd64d9))
* **api:** api update ([8b3c2c1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8b3c2c17ee5f0ba5729951eccad4b2af4fde2da4))
* **api:** api update ([3524987](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3524987fa2b64bdf67474da7bf38cdcf68fb4370))
* **api:** manual updates ([1dc14f1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1dc14f1c52417d73fcb71813091c2514a79bb4da))
* **api:** manual updates ([0e9a2e4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0e9a2e4baac9a41019c26e0ecb476c3d58c59ca3))
* **api:** moved to org ([e12696d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e12696d409c2052c27445feb62a3220ec1c3fb22))
* **client:** add support for binary request streaming ([5e1ce87](https://github.com/cooper-square-technologies/profound-python-sdk/commit/5e1ce87f1bbbbdc5c72d763e4c39c6b9be337a7f))


### Chores

* **internal:** version bump ([3f8cdec](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3f8cdece8873f5a8e40b491ad1873aebd672e250))
* update SDK settings ([9b64552](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9b64552d18412de716baf4758dea48541b572695))

## 0.17.0 (2026-01-16)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.16.0...v0.17.0)

### Features

* **api:** manual updates ([c082de0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c082de090f5cebc4973253d2510439b9a949b2ce))


### Documentation

* prominently feature MCP server setup in root SDK readmes ([00475d1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/00475d1aeeccebd87977037e6e3b7a290d97ba20))

## 0.16.0 (2026-01-12)

Full Changelog: [v0.15.1...v0.16.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.15.1...v0.16.0)

### Features

* **api:** api update ([26a3d90](https://github.com/cooper-square-technologies/profound-python-sdk/commit/26a3d90af3a54848b45fdb8f0004d0bcfd3970de))
* **api:** api update ([9355ae1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9355ae1b49b17b329dc07dc029c0675e208d01e1))
* **api:** api update ([4fc5d61](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4fc5d611fc73c77d3c02268e29b360639f1e6558))
* **api:** manual updates ([8948105](https://github.com/cooper-square-technologies/profound-python-sdk/commit/89481059f7f9035fec64743f3ffb48dfb4d22dcb))
* **api:** manual updates ([6f5fac6](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6f5fac6b0bbfa2eb45297442295160c796b722eb))


### Documentation

* prominently feature MCP server setup in root SDK readmes ([aaf4f2d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/aaf4f2d3140ec305fe702eb0bddf497b29dcc572))

## 0.15.1 (2026-01-06)

Full Changelog: [v0.15.0...v0.15.1](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.15.0...v0.15.1)

### Chores

* **internal:** codegen related update ([4638fed](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4638fed067725b504f535ff22bb7e77c114756bc))

## 0.15.0 (2025-12-30)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** api update ([f8e641f](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f8e641f05936e690ca5be4be35116108b9ff2b67))
* **api:** api update ([143d969](https://github.com/cooper-square-technologies/profound-python-sdk/commit/143d96960614b1f6c207970beda8a1140de36528))
* **api:** api update ([8182f33](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8182f33d856951a35746de2752f5cf2d1ab96696))


### Bug Fixes

* use async_to_httpx_files in patch method ([e0e219c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e0e219cc848e9794d45f53998ee6dcac46be52e5))


### Chores

* **internal:** add `--fix` argument to lint script ([57c6d49](https://github.com/cooper-square-technologies/profound-python-sdk/commit/57c6d499d0f9c7a68714067ec55ab0a1d908a14a))
* **internal:** add missing files argument to base client ([f514b1b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/f514b1b42cc88ecb4ac40fe8dea36be289603674))
* speedup initial import ([316b0d8](https://github.com/cooper-square-technologies/profound-python-sdk/commit/316b0d8bb4e7d993ed829082616873aabc3ff6ae))

## 0.14.0 (2025-12-12)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([8864b02](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8864b02d9e403962aa086dd3e204f5e21e8fb6a7))
* **api:** api update ([7e96bac](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7e96baca78ddbe24f90c38a5f4cc0f4a691b2045))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([c2c8d12](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c2c8d120144f6fc2025716319fff1dce93ac7148))


### Chores

* add missing docstrings ([3e04a82](https://github.com/cooper-square-technologies/profound-python-sdk/commit/3e04a824af99bbee4543c781a9d592ec304dd504))

## 0.13.0 (2025-12-03)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([bf9299c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/bf9299c3b9f844311dedbbc536c02db13db3100e))
* **api:** api update ([a8d74d3](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a8d74d33b8cc6f4d04634e6d3e8afb25662ddc0f))


### Bug Fixes

* ensure streams are always closed ([49a5d37](https://github.com/cooper-square-technologies/profound-python-sdk/commit/49a5d37750aa6adf7f671c592e9c4a6514f98105))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([0715bd2](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0715bd2a8b92ff962259d6dc473563788b95d6f2))
* **docs:** use environment variables for authentication in code snippets ([426dd1c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/426dd1c47cddc5e573f40c4ada52d0e58c74e37d))
* update lockfile ([1ab8506](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1ab850656e13f8555453740d58c1be30d656f7be))

## 0.12.0 (2025-11-25)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** api update ([10996e0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/10996e0ad8c482f33a97195d2a7cf1f7f33ce286))
* **api:** api update ([6b1f48e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6b1f48e1a6fe0103afe327d5b79d26656add4f3f))


### Chores

* add Python 3.14 classifier and testing ([4041368](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4041368c3f8987738cc3a5e5e33f5e0f7d0e27e9))

## 0.11.0 (2025-11-21)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.10.0...v0.11.0)

### Features

* **api:** added `get /v1/org/assets` ([0c82b6b](https://github.com/cooper-square-technologies/profound-python-sdk/commit/0c82b6b859c3c1099d5fec3702c6cb49d5a23aa1))

## 0.10.0 (2025-11-20)

Full Changelog: [v0.9.1...v0.10.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.9.1...v0.10.0)

### Features

* **api:** add assets endpoint ([8ec3780](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8ec378015028d3d9b1ec4da7dd4a5e26f795e1a3))

## 0.9.1 (2025-11-13)

Full Changelog: [v0.9.0...v0.9.1](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.9.0...v0.9.1)

## 0.9.0 (2025-11-12)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([47d3e50](https://github.com/cooper-square-technologies/profound-python-sdk/commit/47d3e50261b0c6554bd6ce507932dd72d138cdab))


### Bug Fixes

* **client:** close streams without requiring full consumption ([9ae7af9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/9ae7af92567de6cfbe7739b2a12470b4518420f5))
* compat with Python 3.14 ([a41771d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a41771db29daa4c0f73ac248c5794eff0394f999))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([e25c18a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e25c18a3d1d954cf005ea667c1d1cc1f2ed8f08d))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([48e555a](https://github.com/cooper-square-technologies/profound-python-sdk/commit/48e555a385eacdb968e459946e53806dff35a028))
* **internal:** grammar fix (it's -&gt; its) ([8233893](https://github.com/cooper-square-technologies/profound-python-sdk/commit/82338939c32ee3997a20e30ee24aab86d97c5ec9))
* **package:** drop Python 3.8 support ([db71ed2](https://github.com/cooper-square-technologies/profound-python-sdk/commit/db71ed2ad307fb5cefba7dd30f4374c5bb94f10e))

## 0.8.0 (2025-10-28)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([7958299](https://github.com/cooper-square-technologies/profound-python-sdk/commit/7958299a1156ad45de08e406fd0d520c32dac51c))

## 0.7.0 (2025-10-27)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([375f64d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/375f64db88b85ce558e5132e00067af6bdc4ff1f))

## 0.6.0 (2025-10-21)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([4e244ad](https://github.com/cooper-square-technologies/profound-python-sdk/commit/4e244ad88c7e6185b4a3865b3db3b83981e2a865))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([c4d4695](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c4d46955efd31cff4e9d7d22bdd943b116ef5c08))

## 0.5.0 (2025-10-17)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([e0655be](https://github.com/cooper-square-technologies/profound-python-sdk/commit/e0655be0272e66cfed2a71244594557ff5599bc5))

## 0.4.0 (2025-10-15)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([186f6c4](https://github.com/cooper-square-technologies/profound-python-sdk/commit/186f6c4159e5317e67c7b2c3682c06f75243eabc))

## 0.3.0 (2025-10-15)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.2.1...v0.3.0)

### Features

* **api:** api update ([53cac67](https://github.com/cooper-square-technologies/profound-python-sdk/commit/53cac6701202525be9cf6b1e26df6470c92c657a))
* **api:** api update ([1ac0003](https://github.com/cooper-square-technologies/profound-python-sdk/commit/1ac00030a0d587441d3748427852431d6591edbc))

## 0.2.1 (2025-10-11)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.2.0...v0.2.1)

### Chores

* **internal:** detect missing future annotations with ruff ([6089e80](https://github.com/cooper-square-technologies/profound-python-sdk/commit/6089e80afdf7d32aa06eaee1c3598620999d04fd))

## 0.2.0 (2025-10-08)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.1.0...v0.2.0)

### ⚠ BREAKING CHANGES

* **api:** move Pagination to shared models
* **api:** rename reports models

### Features

* **api:** api update ([dfc3d79](https://github.com/cooper-square-technologies/profound-python-sdk/commit/dfc3d7909d6c41534e267114514bd9b94bd0bc0a))
* **api:** manual updates ([99bf2bc](https://github.com/cooper-square-technologies/profound-python-sdk/commit/99bf2bcf8300c6bc8db63e8bfee7c9a9c4bf3bfc))
* **api:** move Pagination to shared models ([aeae55d](https://github.com/cooper-square-technologies/profound-python-sdk/commit/aeae55d2461ad5bacb206c4e887faad4a6e904fa))
* **api:** rename reports models ([435b4fb](https://github.com/cooper-square-technologies/profound-python-sdk/commit/435b4fb8f08c8e7526d58f7bc2515b9826062fc3))

## 0.1.0 (2025-10-03)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/cooper-square-technologies/profound-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([2572b3c](https://github.com/cooper-square-technologies/profound-python-sdk/commit/2572b3c3be7bf6cddc832478cee783e3033065d8))
* **api:** api update ([c0c8f82](https://github.com/cooper-square-technologies/profound-python-sdk/commit/c0c8f8200192aa74cea5b419cb30f9c143f2c35a))
* **api:** api update ([50d7655](https://github.com/cooper-square-technologies/profound-python-sdk/commit/50d765510b400352beb48d3b4f93948e7d37659a))
* **api:** api update ([a9288cf](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a9288cff233e74cce029f1b3985c619f954e45f6))
* **api:** manual updates ([35b9d06](https://github.com/cooper-square-technologies/profound-python-sdk/commit/35b9d06f6add37221a19f0f514f375c108e29318))
* **api:** manual updates ([10650c8](https://github.com/cooper-square-technologies/profound-python-sdk/commit/10650c803530ec140b973ea1159491ed826dd966))
* **api:** manual updates ([555ef71](https://github.com/cooper-square-technologies/profound-python-sdk/commit/555ef71c7d84621e1f60752afd5e17e8e543f631))
* **api:** manual updates ([8aeebd9](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8aeebd9a655310d8f9e34fd6adad982f2bfbd09c))
* **api:** manual updates ([d2b48ca](https://github.com/cooper-square-technologies/profound-python-sdk/commit/d2b48ca9ed0bb2dc836c5bcf5c4fe72ce45b43e1))
* **api:** manual updates ([53a38b1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/53a38b17411e7596a61f9cab7a8e73f058fe71fc))
* **api:** manual updates ([744b812](https://github.com/cooper-square-technologies/profound-python-sdk/commit/744b8125ebd1b2841523497416615a8f7a29a47b))
* **api:** manual updates ([a252b75](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a252b75817d07c3fca801b1e14bbffa31036a088))
* **api:** manual updates ([a777a52](https://github.com/cooper-square-technologies/profound-python-sdk/commit/a777a52c3c7b98a9d5cb7a1d4269a293160ab086))
* **api:** manual updates ([59b83c0](https://github.com/cooper-square-technologies/profound-python-sdk/commit/59b83c01f5bd18d00adeeae9cad709747d1b6d03))


### Chores

* internal changes ([8298af1](https://github.com/cooper-square-technologies/profound-python-sdk/commit/8298af12a5732b34b5935aaa379d5680e25387e2))
* update SDK settings ([986fbd7](https://github.com/cooper-square-technologies/profound-python-sdk/commit/986fbd7a2732151af5e1bd49ff0a7ca610b30e8c))
* update SDK settings ([ed9b35e](https://github.com/cooper-square-technologies/profound-python-sdk/commit/ed9b35e5047fa9fac3f04c37b5e383f293e0c231))
