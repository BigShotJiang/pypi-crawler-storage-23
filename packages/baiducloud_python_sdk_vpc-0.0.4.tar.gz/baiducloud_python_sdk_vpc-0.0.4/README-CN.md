[English](README.md) | 简体中文

## Baidu Cloud vpcApi SDK for Python

## 要求

- Python >=2.7, !=3.0.*, !=3.1.*, !=3.2.*, <4

## 安装

- **使用 pip 安装(推荐)**

如未安装 `pip`, 请先至pip官网 [pip user guide](https://pip.pypa.io/en/stable/installing/ "pip User Guide") 安装pip .

```bash
# 安装 baiducloud_python_sdk_vpc
pip install baiducloud_python_sdk_vpc
```

## 问题

[提交 Issue](https://github.com/baidubce/baiducloud-python-sdk/issues/new)，不符合指南的问题可能会立即关闭。

## 使用说明

[快速使用](https://github.com/baidubce/baiducloud-python-sdk/blob/master/docs/Usage-CN.md)

## 发行说明

每个版本的详细更改记录在[发行说明](./ChangeLog.md)中。

## 相关

- [最新源码](https://github.com/baidubce/baiducloud-python-sdk)

## 许可证

[Apache-2.0](http://www.apache.org/licenses/LICENSE-2.0)