import aitoolman.cli


if __name__ == "__main__":
    aitoolman.cli.main()
