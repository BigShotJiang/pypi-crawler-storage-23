# exceptions.py


class PomaSDKError(Exception):
    """Base class for all custom SDK errors."""


class ApiError(PomaSDKError):
    """Raised when the API returns an error.

    Attributes:
        status_code: HTTP status code from the API (e.g. 400, 401, 403, 404, 500), or None.
        response_body: Raw response body text from the API, or empty string.
        job_id: When the error is for a specific job, the job identifier, or None.
        file_path: When the error is from submit file, the file path, or None.
        url: When the error is from a download, the request URL, or None.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: str | None = None,
        job_id: str | None = None,
        file_path: str | None = None,
        url: str | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body or ""
        self.job_id = job_id
        self.file_path = file_path
        self.url = url


class InvalidInputError(PomaSDKError):
    """Raised when an unsupported *Content‑Type* is given to ``chunk_text``."""


class InvalidResponseError(PomaSDKError):
    """Raised when the server returns non-JSON or empty body."""
