from __future__ import annotations

import base64
from solders.keypair import Keypair
from solders.transaction import Transaction, VersionedTransaction


class SigningManager:
    """Signs Solana transactions using a local keypair."""

    def __init__(self, keypair: Keypair) -> None:
        self._keypair = keypair

    def sign_transaction(self, unsigned_tx_b64: str) -> str:
        """Sign a base64-encoded transaction (unsigned or partially-signed).

        Supports both legacy and versioned transactions.
        Uses partial_sign to preserve any existing signatures (e.g. from
        a gas sponsor's partialSign).
        Returns the signed transaction as a base64 string.
        """
        raw = base64.b64decode(unsigned_tx_b64)

        # Versioned transactions have first byte >= 128
        if raw[0] >= 128:
            vtx = VersionedTransaction.from_bytes(raw)
            signed = VersionedTransaction(vtx.message, [self._keypair])
            return base64.b64encode(bytes(signed)).decode()

        # Legacy transaction — use populate + partial_sign to preserve existing signatures
        tx = Transaction.from_bytes(raw)
        signed = Transaction.populate(tx.message, tx.signatures)
        signed.partial_sign([self._keypair], tx.message.recent_blockhash)
        return base64.b64encode(bytes(signed)).decode()
