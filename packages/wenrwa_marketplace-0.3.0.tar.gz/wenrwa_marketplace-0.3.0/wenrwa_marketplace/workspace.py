from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient
    from .types import Agent, PendingInvite, Workspace, WorkspaceMember


class WorkspaceManager:
    """Higher-level workspace operations with local caching."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client
        self._cache: dict[str, Workspace] = {}

    async def create(self, *, name: str, **kwargs: Any) -> Workspace:
        ws = await self._client.create_workspace(name=name, **kwargs)
        self._cache[ws.id] = ws
        return ws

    async def get(self, workspace_id: str, refresh: bool = False) -> Workspace:
        if not refresh and workspace_id in self._cache:
            return self._cache[workspace_id]
        ws = await self._client.get_workspace(workspace_id)
        self._cache[ws.id] = ws
        return ws

    async def list(self) -> list[Workspace]:
        workspaces = await self._client.list_workspaces()
        for ws in workspaces:
            self._cache[ws.id] = ws
        return workspaces

    async def update(
        self,
        workspace_id: str,
        name: str | None = None,
        description: str | None = None,
        visibility: str | None = None,
        tags: list[str] | None = None,
    ) -> Workspace:
        ws = await self._client.update_workspace(
            workspace_id, name=name, description=description,
            visibility=visibility, tags=tags,
        )
        self._cache[ws.id] = ws
        return ws

    async def get_agents(self, workspace_id: str) -> dict[str, Any]:
        return await self._client.get_workspace_agents(workspace_id)

    async def get_public_tags(self) -> list[str]:
        return await self._client.get_public_tags()

    async def add_agent(self, workspace_id: str, agent_wallet: str) -> None:
        await self._client.add_agent(workspace_id, agent_wallet)
        self._cache.pop(workspace_id, None)

    async def get_my_invites(self) -> list[PendingInvite]:
        return await self._client.get_my_invites()

    async def list_members(self, workspace_id: str) -> list[WorkspaceMember]:
        return await self._client.list_members(workspace_id)

    async def kick_member(self, workspace_id: str, wallet: str) -> None:
        await self._client.kick_member(workspace_id, wallet)
        self._cache.pop(workspace_id, None)

    async def leave_workspace(self, workspace_id: str) -> None:
        await self._client.leave_workspace(workspace_id)
        self._cache.pop(workspace_id, None)

    async def set_member_role(self, workspace_id: str, wallet: str, role: str) -> None:
        await self._client.set_member_role(workspace_id, wallet, role)

    async def transfer_ownership(self, workspace_id: str, target_wallet: str) -> None:
        await self._client.transfer_ownership(workspace_id, target_wallet)
        self._cache.pop(workspace_id, None)

    def clear_cache(self) -> None:
        self._cache.clear()
