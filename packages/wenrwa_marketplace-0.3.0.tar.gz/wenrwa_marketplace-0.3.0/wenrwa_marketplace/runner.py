"""
AgentRunner — autonomous agent loop for Python.

Point your agent at a marketplace URL and call `await runner.start()`.
The runner handles discovery, registration, polling, bidding,
heartbeats, and submission. You provide one function: `execute`.

Usage:
    runner = AgentRunner(
        marketplace_url="https://api.wenrwa.com",
        keypair=my_keypair,
        agent_name="MyBot",
        agent_capabilities=["python", "data-engineering"],
        execute=my_execute_fn,
    )
    await runner.start()
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

import httpx
from solders.keypair import Keypair

from .client import MarketplaceClient
from .cost_estimator import CostEstimator, TASK_COMPLEXITY
from .types import Bounty


logger = logging.getLogger("wenrwa.runner")


# ── Types ────────────────────────────────────────────────────────────


@dataclass
class ExecutionContext:
    """Helpers passed to your execute function."""

    _bounty_id: str
    _client: MarketplaceClient
    aborted: bool = False

    @property
    def client(self) -> MarketplaceClient:
        return self._client

    async def progress(self, percentage: int, message: str | None = None) -> None:
        """Report progress (0-100) with optional message."""
        await self._client.report_progress(self._bounty_id, percentage, message)

    async def message(self, content: str) -> None:
        """Send a message on the bounty thread."""
        await self._client.send_message(self._bounty_id, content)


@dataclass
class ExecutionResult:
    """Return this from your execute function."""

    result_hash: str
    result_url: str | None = None
    result_data: dict[str, Any] | None = None
    pr_url: str | None = None
    deliverable_type: str | None = None


@dataclass
class RunnerStats:
    """Live statistics for the runner."""

    started_at: float = 0.0
    bounties_completed: int = 0
    bounties_failed: int = 0
    total_earned: int = 0
    current_assignments: list[str] = field(default_factory=list)
    tokens_used: int = 0
    tokens_remaining: int | None = None


@dataclass
class ScheduleConfig:
    """When to start/stop the runner."""

    start_at: str | None = None
    """ISO 8601 datetime to start. Omit for immediate."""
    stop_at: str | None = None
    """ISO 8601 datetime to stop."""
    run_duration_seconds: float | None = None
    """Alternative to stop_at: run for this many seconds after start."""


@dataclass
class BudgetConfig:
    """Token budget tracking — stop when exhausted."""

    max_tokens: int
    """Maximum total tokens to consume before stopping."""
    estimate_usage: Callable[[Bounty, ExecutionResult], int] | None = None
    """Custom estimator. Receives bounty + result, returns estimated tokens used."""
    on_budget_threshold: Callable[[float, int], None] | None = None
    """Callback fired when usage crosses 80%, 90%, 95% thresholds."""
    initial_tokens_used: int = 0
    """Resume from a previous run — pre-seed the tokens-used counter."""
    persist_path: str | None = None
    """File path to persist budget state. Auto-loads on construction, saves after each bounty."""


@dataclass
class AggressiveModeConfig:
    """Bid more aggressively as deadline/budget approaches."""

    enabled: bool = False
    activate_at_time_remaining_seconds: float | None = None
    """Activate when this many seconds remain before stop_at. Default: 43200 (12h)."""
    activate_at_budget_remaining_pct: float | None = None
    """Activate when budget remaining drops below this %. Default: 50."""
    bid_reduction_factor: float | None = None
    """Bid at this fraction of the reward. 0.6 = 60%. Default: 0.7."""
    skip_bid_filters: bool = False
    """Skip user's should_bid filter in aggressive mode."""


# Type alias for the execute callback
ExecuteFn = Callable[[Bounty, ExecutionContext], Awaitable[ExecutionResult]]
ShouldBidFn = Callable[[Bounty], bool]
BidAmountFn = Callable[[Bounty], str]

_BUDGET_THRESHOLDS = [80, 90, 95]


class AgentRunner:
    """
    Autonomous agent loop.

    Handles discovery, registration, polling, bidding, heartbeats, and
    submission. You provide one function: ``execute``.
    """

    def __init__(
        self,
        *,
        marketplace_url: str,
        keypair: Keypair,
        agent_name: str,
        agent_capabilities: list[str],
        execute: ExecuteFn,
        agent_model: str | None = None,
        agent_description: str | None = None,
        should_bid: ShouldBidFn | None = None,
        bid_amount: BidAmountFn | None = None,
        max_concurrent: int = 1,
        poll_interval_seconds: float = 30.0,
        heartbeat_interval_seconds: float = 60.0,
        min_balance_sol: float = 0.01,
        auto_accept_invites: bool = False,
        schedule: ScheduleConfig | None = None,
        budget: BudgetConfig | None = None,
        aggressive_mode: AggressiveModeConfig | None = None,
    ) -> None:
        self._marketplace_url = marketplace_url.rstrip("/")
        self._keypair = keypair
        self._agent_name = agent_name
        self._agent_model = agent_model
        self._agent_description = agent_description
        self._agent_capabilities = agent_capabilities
        self._execute = execute
        self._should_bid = should_bid
        self._bid_amount = bid_amount
        self._max_concurrent = max_concurrent
        self._poll_interval = poll_interval_seconds
        self._heartbeat_interval = heartbeat_interval_seconds
        self._min_balance_sol = min_balance_sol
        self._auto_accept_invites = auto_accept_invites
        self._schedule = schedule
        self._budget = budget
        self._aggressive_mode = aggressive_mode

        self._client: MarketplaceClient | None = None
        self._running = False
        self._poll_task: asyncio.Task[None] | None = None
        self._stop_task: asyncio.Task[None] | None = None
        self._start_task: asyncio.Task[None] | None = None
        self._active_bounties: dict[str, ExecutionContext] = {}

        # Budget tracking
        self._last_fired_threshold = 0
        self._cost_estimator = CostEstimator()

        # Load initial token usage: explicit > persisted file > 0
        initial = 0
        if budget:
            initial = budget.initial_tokens_used or 0
            if initial == 0 and budget.persist_path:
                initial = self._load_persisted_budget(budget.persist_path)
        self._tokens_used = initial

        # Aggressive mode state
        self._aggressive_active = False

        self.stats = RunnerStats()
        if budget:
            self.stats.tokens_used = initial
            self.stats.tokens_remaining = budget.max_tokens - initial

    # ── Lifecycle ────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the autonomous agent loop. Runs until ``stop()`` is called."""
        if self._running:
            return

        # Handle scheduled start
        if self._schedule and self._schedule.start_at:
            import datetime

            start_at = datetime.datetime.fromisoformat(self._schedule.start_at)
            now = datetime.datetime.now(datetime.timezone.utc)
            delay = (start_at - now).total_seconds()

            if delay > 0:
                logger.info(
                    "[AgentRunner] Scheduled start at %s (in %.0fs)",
                    self._schedule.start_at,
                    delay,
                )
                self._start_task = asyncio.create_task(self._delayed_start(delay))
                return

        await self._start_now()

    async def _delayed_start(self, delay: float) -> None:
        await asyncio.sleep(delay)
        await self._start_now()

    async def _start_now(self) -> None:
        if self._running:
            return
        self._running = True
        self.stats.started_at = asyncio.get_event_loop().time()

        logger.info("[AgentRunner] Starting...")

        # 1. Discover protocol
        protocol = await self._discover()
        api_url = f"{self._marketplace_url}/api/v1"
        logger.info(
            "[AgentRunner] Connected to: %s v%s",
            protocol.get("name", "unknown"),
            protocol.get("version", "?"),
        )

        # 2. Initialize SDK client
        self._client = MarketplaceClient(
            api_url=api_url,
            keypair=self._keypair,
            ws_url=self._marketplace_url,
        )

        # 3. Register (or verify)
        await self._ensure_registered()

        # 3b. Check workspace invites
        await self._check_invites()

        # 4. Set up schedule stop
        self._setup_schedule_stop()

        # 5. Start polling loop
        logger.info(
            "[AgentRunner] Polling every %.0fs for open bounties...",
            self._poll_interval,
        )
        self._poll_task = asyncio.create_task(self._poll_loop())

        # 6. Handle signals
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))
            except NotImplementedError:
                pass  # Windows doesn't support add_signal_handler

        if self._budget:
            logger.info(
                "[AgentRunner] Budget: %s tokens",
                f"{self._budget.max_tokens:,}",
            )
        if self._aggressive_mode and self._aggressive_mode.enabled:
            logger.info("[AgentRunner] Aggressive mode enabled (will activate when thresholds met)")

        logger.info("[AgentRunner] Running. Ctrl+C to stop.")

    async def stop(self) -> None:
        """Gracefully stop the runner."""
        if not self._running:
            return
        self._running = False
        logger.info("[AgentRunner] Stopping...")

        # Cancel scheduled start
        if self._start_task and not self._start_task.done():
            self._start_task.cancel()

        # Cancel scheduled stop
        if self._stop_task and not self._stop_task.done():
            self._stop_task.cancel()

        # Cancel polling
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass

        # Signal active work to abort
        for bounty_id, ctx in self._active_bounties.items():
            logger.info("[AgentRunner] Signaling abort for bounty %s", bounty_id)
            ctx.aborted = True

        # Clean up client
        if self._client:
            self._client.stop_all_heartbeats()
            await self._client.close()

        logger.info(
            "[AgentRunner] Stopped. %d completed, %d failed, %s tokens used",
            self.stats.bounties_completed,
            self.stats.bounties_failed,
            f"{self.stats.tokens_used:,}",
        )

    # ── Schedule ─────────────────────────────────────────────────

    def _setup_schedule_stop(self) -> None:
        if not self._schedule:
            return

        stop_seconds: float | None = None

        if self._schedule.stop_at:
            import datetime

            stop_at = datetime.datetime.fromisoformat(self._schedule.stop_at)
            now = datetime.datetime.now(datetime.timezone.utc)
            stop_seconds = (stop_at - now).total_seconds()
        elif self._schedule.run_duration_seconds:
            stop_seconds = self._schedule.run_duration_seconds

        if stop_seconds and stop_seconds > 0:
            logger.info("[AgentRunner] Scheduled stop in %.0fs", stop_seconds)
            self._stop_task = asyncio.create_task(self._delayed_stop(stop_seconds))

    async def _delayed_stop(self, delay: float) -> None:
        await asyncio.sleep(delay)
        logger.info("[AgentRunner] Schedule time reached, stopping...")
        await self.stop()

    # ── Budget ───────────────────────────────────────────────────

    def _track_budget(self, bounty: Bounty, result: ExecutionResult | None) -> None:
        if not self._budget:
            return

        # Estimate tokens used — wrap in try/except so user callback errors don't crash
        try:
            tokens_for_bounty = (
                self._budget.estimate_usage(bounty, result)
                if self._budget.estimate_usage and result
                else self._default_estimate_token_usage(bounty)
            )
        except Exception as exc:
            logger.error("[AgentRunner] estimate_usage callback error: %s. Falling back to default.", exc)
            tokens_for_bounty = self._default_estimate_token_usage(bounty)

        self._tokens_used += tokens_for_bounty
        self.stats.tokens_used = self._tokens_used
        self.stats.tokens_remaining = self._budget.max_tokens - self._tokens_used

        pct_used = (self._tokens_used / self._budget.max_tokens) * 100
        remaining = self._budget.max_tokens - self._tokens_used

        logger.info(
            "[AgentRunner] Budget: %s/%s tokens (%.1f%% used, %s remaining)",
            f"{self._tokens_used:,}",
            f"{self._budget.max_tokens:,}",
            pct_used,
            f"{remaining:,}",
        )

        # Fire threshold callbacks — wrapped in try/except
        if self._budget.on_budget_threshold:
            for threshold in _BUDGET_THRESHOLDS:
                if pct_used >= threshold and self._last_fired_threshold < threshold:
                    self._last_fired_threshold = threshold
                    try:
                        self._budget.on_budget_threshold(pct_used, remaining)
                    except Exception as exc:
                        logger.error("[AgentRunner] on_budget_threshold callback error: %s", exc)

        # Persist budget state to disk
        self._persist_budget()

        self._check_aggressive_mode()

        if self._tokens_used >= self._budget.max_tokens:
            logger.info("[AgentRunner] Budget exhausted, stopping...")
            asyncio.create_task(self.stop())

    def _is_budget_exhausted(self) -> bool:
        if not self._budget:
            return False
        return self._tokens_used >= self._budget.max_tokens

    def _default_estimate_token_usage(self, bounty: Bounty) -> int:
        schema = getattr(bounty, "task_schema", None) or getattr(
            bounty, "taskSchema", None
        )
        if schema and isinstance(schema, dict):
            return self._cost_estimator.estimate_token_usage(schema)
        category = (bounty.category or "generic").lower()
        base = TASK_COMPLEXITY.get(category, TASK_COMPLEXITY["generic"])
        return int(base * 1.5)

    def _persist_budget(self) -> None:
        path = self._budget.persist_path if self._budget else None
        if not path:
            return
        try:
            import datetime
            data = {
                "tokensUsed": self._tokens_used,
                "lastUpdated": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
            with open(path, "w") as f:
                json.dump(data, f)
        except Exception:
            pass  # Non-fatal — best-effort persistence

    def _load_persisted_budget(self, path: str) -> int:
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                if isinstance(data.get("tokensUsed"), (int, float)):
                    logger.info(
                        "[AgentRunner] Loaded persisted budget: %s tokens used (from %s)",
                        f"{int(data['tokensUsed']):,}",
                        data.get("lastUpdated", "unknown"),
                    )
                    return int(data["tokensUsed"])
        except Exception:
            pass  # Non-fatal — start fresh
        return 0

    # ── Aggressive Mode ──────────────────────────────────────────

    def _check_aggressive_mode(self) -> None:
        if not self._aggressive_mode or not self._aggressive_mode.enabled:
            return
        if self._aggressive_active:
            return

        # Check time threshold
        if self._schedule and self._schedule.stop_at:
            import datetime

            stop_at = datetime.datetime.fromisoformat(self._schedule.stop_at)
            now = datetime.datetime.now(datetime.timezone.utc)
            remaining_s = (stop_at - now).total_seconds()
            threshold_s = (
                self._aggressive_mode.activate_at_time_remaining_seconds
                if self._aggressive_mode.activate_at_time_remaining_seconds is not None
                else 43200  # 12 hours
            )
            if remaining_s <= threshold_s:
                self._activate_aggressive_mode("time")
                return

        # Check budget threshold
        if self._budget:
            pct_remaining = (
                (self._budget.max_tokens - self._tokens_used) / self._budget.max_tokens
            ) * 100
            threshold_pct = (
                self._aggressive_mode.activate_at_budget_remaining_pct
                if self._aggressive_mode.activate_at_budget_remaining_pct is not None
                else 50
            )
            if pct_remaining <= threshold_pct:
                self._activate_aggressive_mode("budget")

    def _activate_aggressive_mode(self, reason: str) -> None:
        self._aggressive_active = True
        logger.info(
            "[AgentRunner] Aggressive mode activated (reason: %s threshold)", reason
        )

    def _get_aggressive_bid_amount(self, bounty: Bounty) -> str:
        factor = (
            self._aggressive_mode.bid_reduction_factor
            if self._aggressive_mode and self._aggressive_mode.bid_reduction_factor is not None
            else 0.7
        )
        amount = int(bounty.reward_amount)
        return str(int(amount * factor))

    # ── Discovery ────────────────────────────────────────────────

    async def _discover(self) -> dict[str, Any]:
        logger.info("[AgentRunner] Discovering protocol at %s...", self._marketplace_url)

        async with httpx.AsyncClient() as http:
            try:
                resp = await http.get(
                    f"{self._marketplace_url}/.well-known/agent-protocol",
                    timeout=10.0,
                )
                if resp.status_code == 200:
                    return resp.json()
            except httpx.HTTPError:
                pass

            resp = await http.get(
                f"{self._marketplace_url}/api/v1/agent-protocol",
                timeout=10.0,
            )
            if resp.status_code == 200:
                return resp.json()

        raise RuntimeError(f"Cannot discover marketplace at {self._marketplace_url}")

    # ── Registration ─────────────────────────────────────────────

    async def _ensure_registered(self) -> None:
        assert self._client is not None
        wallet = self._client.wallet_pubkey

        try:
            agent = await self._client.get_agent(wallet)
            logger.info(
                '[AgentRunner] Already registered as "%s" (%s...)',
                agent.name,
                wallet[:8],
            )
        except Exception:
            logger.info("[AgentRunner] Not registered yet, registering...")
            await self._client.register_agent(
                name=self._agent_name,
                capabilities=self._agent_capabilities,
                description=self._agent_description,
                model=self._agent_model,
            )
            logger.info('[AgentRunner] Registered as "%s"', self._agent_name)

    # ── Invites ──────────────────────────────────────────────────

    async def _check_invites(self) -> None:
        """Check and optionally auto-accept pending workspace invites."""
        try:
            assert self._client is not None
            invites = await self._client.get_my_invites()
            if not invites:
                return

            logger.info("[AgentRunner] %d pending workspace invite(s)", len(invites))

            for item in invites:
                ws = item.workspace
                role = item.invite.role or "member"
                ws_name = ws.get("name", "unknown") if isinstance(ws, dict) else getattr(ws, "name", "unknown")
                member_count = ws.get("memberCount", "?") if isinstance(ws, dict) else getattr(ws, "memberCount", "?")
                logger.info('[AgentRunner]   → "%s" (role: %s, %s members)', ws_name, role, member_count)

                if self._auto_accept_invites:
                    try:
                        await self._client.redeem_invite(item.invite.token)
                        logger.info('[AgentRunner]   Accepted invite to "%s"', ws_name)
                    except Exception as exc:
                        logger.warning('[AgentRunner]   Failed to accept invite to "%s": %s', ws_name, exc)

            if not self._auto_accept_invites and invites:
                logger.info("[AgentRunner] Set auto_accept_invites=True to auto-join workspaces")
        except Exception:
            pass  # Non-fatal — invite check is best-effort

    # ── Polling ──────────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        while self._running:
            try:
                await self._poll()
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.error("[AgentRunner] Poll error: %s", exc)

            await asyncio.sleep(self._poll_interval)

    async def _poll(self) -> None:
        assert self._client is not None
        if self._is_budget_exhausted():
            return
        if len(self._active_bounties) >= self._max_concurrent:
            return

        # Check aggressive mode on each poll
        self._check_aggressive_mode()

        # Check assigned bounties first
        result = await self._client.list_bounties(
            assignee_wallet=self._client.wallet_pubkey,
            status="assigned",
            limit=10,
        )
        for bounty in result["bounties"]:
            if bounty.id not in self._active_bounties and len(self._active_bounties) < self._max_concurrent:
                logger.info("[AgentRunner] Found assigned bounty %s, starting work...", bounty.id)
                asyncio.create_task(self._execute_bounty(bounty.id))

        # Browse open bounties
        result = await self._client.list_bounties(
            status="open",
            sort_by="rewardAmount",
            sort_dir="DESC",
            limit=20,
        )
        for bounty in result["bounties"]:
            if not self._running:
                break
            if self._is_budget_exhausted():
                break
            if len(self._active_bounties) >= self._max_concurrent:
                break
            if bounty.id in self._active_bounties:
                continue
            if not self._matches_capabilities(bounty):
                continue

            # User's custom bid strategy (skippable in aggressive mode)
            skip_filters = (
                self._aggressive_active
                and self._aggressive_mode is not None
                and self._aggressive_mode.skip_bid_filters
            )
            if not skip_filters and self._should_bid and not self._should_bid(bounty):
                continue

            try:
                if self._aggressive_active and not self._bid_amount:
                    amount = self._get_aggressive_bid_amount(bounty)
                elif self._bid_amount:
                    amount = self._bid_amount(bounty)
                else:
                    amount = bounty.reward_amount

                tag = " [aggressive]" if self._aggressive_active else ""
                await self._client.bid(
                    bounty.id,
                    amount=amount,
                    message=f"{self._agent_name} ({self._agent_model or 'AI agent'}) — automated bid{tag}",
                )
                logger.info(
                    '[AgentRunner] Bid placed on "%s" (%s) for %s%s',
                    bounty.title,
                    bounty.id,
                    amount,
                    tag,
                )
            except Exception as exc:
                msg = str(exc)
                if "ALREADY_BID" not in msg and "NOT_OPEN" not in msg:
                    logger.error("[AgentRunner] Bid error on %s: %s", bounty.id, msg)

    # ── Capability Matching ──────────────────────────────────────

    def _matches_capabilities(self, bounty: Bounty) -> bool:
        my_caps = [c.lower() for c in self._agent_capabilities]
        category = (bounty.category or "").lower()

        if category and category in my_caps:
            return True

        # Default: bid on everything (user's should_bid can filter)
        return True

    # ── Execution ────────────────────────────────────────────────

    async def _execute_bounty(self, bounty_id: str) -> None:
        assert self._client is not None

        if bounty_id in self._active_bounties:
            return

        ctx = ExecutionContext(_bounty_id=bounty_id, _client=self._client)
        self._active_bounties[bounty_id] = ctx
        self.stats.current_assignments.append(bounty_id)

        bounty: Bounty | None = None
        try:
            bounty = await self._client.get_bounty(bounty_id)
            logger.info('[AgentRunner] Starting work on "%s" (%s)', bounty.title, bounty_id)

            # Start heartbeat
            self._client.start_auto_heartbeat(bounty_id, self._heartbeat_interval)

            # Execute user's work function
            result = await self._execute(bounty, ctx)

            # Submit work
            await self._client.submit_work(
                bounty_id,
                result_hash=result.result_hash,
                result_url=result.result_url,
                result_data=result.result_data,
                pr_url=result.pr_url,
                deliverable_type=result.deliverable_type,
            )

            self.stats.bounties_completed += 1
            try:
                self.stats.total_earned += int(bounty.reward_amount)
            except (ValueError, TypeError):
                pass
            logger.info('[AgentRunner] Submitted work for "%s" (%s)', bounty.title, bounty_id)

            # Track budget AFTER successful completion (don't abort mid-work)
            self._track_budget(bounty, result)

        except Exception as exc:
            self.stats.bounties_failed += 1
            logger.error("[AgentRunner] Failed on bounty %s: %s", bounty_id, exc)

            # Track budget even for failures — API tokens were still consumed
            if bounty is not None:
                self._track_budget(bounty, None)

        finally:
            self._client.stop_auto_heartbeat(bounty_id)
            self._active_bounties.pop(bounty_id, None)
            self.stats.current_assignments = [
                bid for bid in self.stats.current_assignments if bid != bounty_id
            ]
