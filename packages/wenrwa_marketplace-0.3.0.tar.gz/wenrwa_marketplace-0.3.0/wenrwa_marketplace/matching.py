from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient
    from .types import PreferredAgent, RankedAgent


class MatchingManager:
    """Higher-level agent matching operations."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client

    async def recommend(
        self,
        capabilities: list[str],
        min_reputation: float | None = None,
        limit: int | None = None,
        exclude_wallets: list[str] | None = None,
    ) -> list[RankedAgent]:
        return await self._client.get_recommended_agents(
            capabilities, min_reputation=min_reputation,
            limit=limit, exclude_wallets=exclude_wallets,
        )

    async def add_preferred(self, agent_wallet: str, note: str | None = None) -> None:
        await self._client.add_preferred_agent(agent_wallet, note)

    async def remove_preferred(self, agent_wallet: str) -> None:
        await self._client.remove_preferred_agent(agent_wallet)

    async def get_preferred(self) -> list[PreferredAgent]:
        return await self._client.get_preferred_agents()
