"""
ProjectOrchestrator — poster-side automation for building apps via bounties.

The poster-side equivalent of AgentRunner. Decomposes a project into
bounty DAGs, creates them in a workspace, and manages the full lifecycle.

Usage:
    orchestrator = ProjectOrchestrator(client, name="My App")
    specs = await orchestrator.decompose(description="...", llm=my_llm_fn)
    project = await orchestrator.plan(specs)
    result = await orchestrator.run(project)
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional, Union

from .client import MarketplaceClient
from .cost_estimator import CostEstimator
from .types import Bid, Bounty

logger = logging.getLogger("wenrwa.orchestrator")


# ── Types ────────────────────────────────────────────────────────


class ProjectPhase(str, Enum):
    PLANNING = "planning"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


@dataclass
class BountySpec:
    temp_id: str
    title: str
    description: str
    category: Optional[str] = None
    task_schema: Optional[dict[str, Any]] = None
    reward_usd: Optional[float] = None
    blocked_by: Optional[list[str]] = None
    context_keys: Optional[list[str]] = None
    output_context_key: Optional[str] = None
    verification_mode: Optional[str] = None
    priority: int = 0


@dataclass
class BountyState:
    spec: BountySpec
    bounty_id: str
    status: str
    retries: int = 0
    assignee_wallet: Optional[str] = None


@dataclass
class Project:
    id: str
    name: str
    workspace_id: str
    bounties: dict[str, BountyState]  # bountyId -> state
    temp_id_to_id: dict[str, str]  # tempId -> bountyId
    dag_nodes: list[str]
    dag_edges: list[tuple[str, str]]
    estimated_total_cost_usd: float
    estimated_duration_days: int


@dataclass
class ProjectResult:
    completed: int
    failed: int
    total_cost_usd: float
    duration_ms: float
    bounty_results: dict[str, dict[str, Any]]


@dataclass
class ProjectStatus:
    phase: ProjectPhase
    total: int
    completed: int
    in_progress: int
    blocked: int
    failed: int
    open: int
    elapsed: float


AutoAcceptStrategy = Union[str, Callable[[Bounty, list[Bid]], Optional[Bid]]]


# ── DAG Utilities ────────────────────────────────────────────────


def validate_dag(specs: list[BountySpec]) -> None:
    """Validate that specs form a valid DAG (no cycles, no invalid refs)."""
    ids = {s.temp_id for s in specs}

    if len(ids) != len(specs):
        counts: dict[str, int] = defaultdict(int)
        for s in specs:
            counts[s.temp_id] += 1
        dupes = [tid for tid, c in counts.items() if c > 1]
        raise ValueError(f"Duplicate tempId(s): {', '.join(dupes)}")

    for spec in specs:
        for dep in spec.blocked_by or []:
            if dep not in ids:
                raise ValueError(
                    f'"{spec.temp_id}" references unknown dependency "{dep}"'
                )

    # Kahn's algorithm for cycle detection
    in_degree: dict[str, int] = {s.temp_id: 0 for s in specs}
    adj: dict[str, list[str]] = {s.temp_id: [] for s in specs}

    for spec in specs:
        for dep in spec.blocked_by or []:
            adj[dep].append(spec.temp_id)
            in_degree[spec.temp_id] += 1

    queue = [tid for tid, deg in in_degree.items() if deg == 0]
    processed = 0

    while queue:
        node = queue.pop(0)
        processed += 1
        for neighbor in adj[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if processed != len(specs):
        raise ValueError("Dependency graph contains a cycle")


def build_dag_edges(specs: list[BountySpec]) -> list[tuple[str, str]]:
    edges: list[tuple[str, str]] = []
    for spec in specs:
        for dep in spec.blocked_by or []:
            edges.append((dep, spec.temp_id))
    return edges


# ── Decomposer ───────────────────────────────────────────────────


def build_decomposition_prompt(
    description: str,
    constraints: Optional[list[str]] = None,
    max_bounties: int = 15,
) -> str:
    constraints_str = ""
    if constraints:
        constraints_str = "\n\nConstraints:\n" + "\n".join(f"- {c}" for c in constraints)

    return f"""You are a project decomposition expert. Break down the following project into bounties that can be worked on by independent AI agents.

Project Description:
{description}{constraints_str}

Rules:
1. Create at most {max_bounties} bounties
2. Each bounty should be a self-contained unit of work that one agent can complete
3. Use "blockedBy" to express dependencies (a bounty can only start after its dependencies complete)
4. Ensure the dependency graph has NO cycles
5. Root bounties (no dependencies) should be foundational work like schemas, specs, or setup
6. Categories: code, api, testing, documentation, security-audit, deployment, research, data, design, or other relevant categories
7. Each bounty needs a clear, detailed description of what to deliver
8. Use "outputContextKey" to pass results between bounties (e.g., "db-schema", "api-spec")
9. Use "contextKeys" to consume context from predecessor bounties

Return a JSON object with this exact structure:
{{
  "bounties": [
    {{
      "tempId": "unique-short-id",
      "title": "Short descriptive title",
      "category": "code",
      "description": "Detailed description of what to implement, including acceptance criteria",
      "blockedBy": [],
      "outputContextKey": "optional-key-for-downstream",
      "contextKeys": [],
      "estimatedComplexity": "low" | "medium" | "high"
    }}
  ]
}}

Return ONLY the JSON object, no markdown fences or explanation."""


def parse_decomposition_response(raw: str) -> list[BountySpec]:
    """Parse LLM response into BountySpec list, validating the DAG."""
    text = raw.strip()
    if text.startswith("```"):
        text = text.lstrip("`").lstrip("json").lstrip("\n")
        if text.endswith("```"):
            text = text[: -len("```")]

    parsed = json.loads(text)
    bounties = parsed.get("bounties", [])

    if not isinstance(bounties, list) or len(bounties) == 0:
        raise ValueError('LLM response did not contain a "bounties" array')

    specs = [
        BountySpec(
            temp_id=str(b["tempId"]),
            title=str(b["title"]),
            description=str(b["description"]),
            category=b.get("category"),
            blocked_by=b.get("blockedBy"),
            output_context_key=b.get("outputContextKey"),
            context_keys=b.get("contextKeys"),
        )
        for b in bounties
    ]

    validate_dag(specs)
    return specs


# ── ProjectOrchestrator ─────────────────────────────────────────


class ProjectOrchestrator:
    """Poster-side orchestrator for managing project bounty lifecycles."""

    def __init__(
        self,
        client: MarketplaceClient,
        *,
        name: str,
        description: str = "",
        github_repo_url: Optional[str] = None,
        default_deadline_days: int = 7,
        workspace_mode: str = "open",
        auto_accept_bids: Optional[AutoAcceptStrategy] = None,
        auto_approve_verified: bool = False,
        max_retries: int = 2,
        cost_estimator: Optional[CostEstimator] = None,
        max_bounty_reward_usd: Optional[float] = None,
        bid_window_seconds: float = 300.0,
        on_bounty_created: Optional[Callable[[Bounty], None]] = None,
        on_bounty_assigned: Optional[Callable[[Bounty, str], None]] = None,
        on_bounty_completed: Optional[Callable[[Bounty], None]] = None,
        on_bounty_failed: Optional[Callable[[Bounty, str], None]] = None,
        on_project_completed: Optional[Callable[[ProjectResult], None]] = None,
    ) -> None:
        self.client = client
        self.name = name
        self.description = description
        self.github_repo_url = github_repo_url
        self.default_deadline_days = default_deadline_days
        self.workspace_mode = workspace_mode
        self.auto_accept_bids = auto_accept_bids
        self.auto_approve_verified = auto_approve_verified
        self.max_retries = max_retries
        self.cost_estimator = cost_estimator or CostEstimator()
        self.max_bounty_reward_usd = max_bounty_reward_usd
        self.bid_window_seconds = bid_window_seconds

        self.on_bounty_created = on_bounty_created
        self.on_bounty_assigned = on_bounty_assigned
        self.on_bounty_completed = on_bounty_completed
        self.on_bounty_failed = on_bounty_failed
        self.on_project_completed = on_project_completed

        self._phase = ProjectPhase.PLANNING
        self._started_at = 0.0
        self._stopped = False

    # ── Decompose ─────────────────────────────────────────────

    async def decompose(
        self,
        description: str,
        llm: Callable[[str], Awaitable[str]],
        constraints: Optional[list[str]] = None,
        max_bounties: int = 15,
    ) -> list[BountySpec]:
        logger.info("Decomposing project: %s...", description[:80])
        prompt = build_decomposition_prompt(description, constraints, max_bounties)
        raw = await llm(prompt)
        specs = parse_decomposition_response(raw)
        logger.info("Decomposed into %d bounties", len(specs))
        return specs

    async def refine(
        self,
        specs: list[BountySpec],
        feedback: str,
        llm: Callable[[str], Awaitable[str]],
    ) -> list[BountySpec]:
        current = json.dumps(
            {
                "bounties": [
                    {
                        "tempId": s.temp_id,
                        "title": s.title,
                        "description": s.description,
                        "category": s.category,
                        "blockedBy": s.blocked_by or [],
                        "outputContextKey": s.output_context_key,
                        "contextKeys": s.context_keys or [],
                    }
                    for s in specs
                ]
            },
            indent=2,
        )

        prompt = f"""You previously decomposed a project into bounties. The user wants changes.

Current bounties:
{current}

Feedback:
{feedback}

Apply the feedback and return the updated JSON object with the same structure.
Return ONLY the JSON object, no markdown fences or explanation."""

        raw = await llm(prompt)
        return parse_decomposition_response(raw)

    # ── Plan ──────────────────────────────────────────────────

    async def plan(self, specs: list[BountySpec]) -> Project:
        logger.info("Planning project '%s' with %d bounties", self.name, len(specs))

        validate_dag(specs)

        workspace = await self.client.create_workspace(
            name=self.name,
            mode=self.workspace_mode,
            github_repo_url=self.github_repo_url,
        )
        logger.info("Created workspace %s", workspace.id)

        total_cost_usd = 0.0
        bounties_for_batch: list[dict[str, Any]] = []

        from datetime import datetime, timedelta

        for spec in specs:
            if spec.reward_usd is not None:
                reward_amount = self._usd_to_token_amount(spec.reward_usd)
                total_cost_usd += spec.reward_usd
            else:
                task_schema = spec.task_schema or {
                    "description": spec.description,
                    "type": spec.category,
                }
                estimate = await self.cost_estimator.estimate(
                    task_schema=task_schema,
                    category=spec.category,
                )
                reward_usd = estimate.suggested_reward_usd
                if self.max_bounty_reward_usd and reward_usd > self.max_bounty_reward_usd:
                    reward_usd = self.max_bounty_reward_usd
                reward_amount = self._usd_to_token_amount(reward_usd)
                total_cost_usd += reward_usd

            deadline = datetime.utcnow() + timedelta(days=self.default_deadline_days)

            bounties_for_batch.append(
                {
                    "tempId": spec.temp_id,
                    "title": spec.title,
                    "category": spec.category or "code",
                    "taskSchema": spec.task_schema or {"description": spec.description},
                    "rewardAmount": reward_amount,
                    "deadline": deadline.isoformat() + "Z",
                    "blockedBy": spec.blocked_by or [],
                    "verificationMode": spec.verification_mode or "manual",
                    "maxRetries": self.max_retries,
                    "priority": spec.priority,
                }
            )

        bounty_ids = await self.client.create_bounty_batch(workspace.id, bounties_for_batch)

        bounty_states: dict[str, BountyState] = {}
        temp_id_to_id: dict[str, str] = {}

        for i, spec in enumerate(specs):
            bounty_id = bounty_ids[i]
            temp_id_to_id[spec.temp_id] = bounty_id
            status = "blocked" if spec.blocked_by else "pending_signature"
            bounty_states[bounty_id] = BountyState(
                spec=spec, bounty_id=bounty_id, status=status
            )

        dag_depth = self._calculate_dag_depth(specs)
        estimated_duration = dag_depth * self.default_deadline_days

        project = Project(
            id=workspace.id,
            name=self.name,
            workspace_id=workspace.id,
            bounties=bounty_states,
            temp_id_to_id=temp_id_to_id,
            dag_nodes=[s.temp_id for s in specs],
            dag_edges=build_dag_edges(specs),
            estimated_total_cost_usd=total_cost_usd,
            estimated_duration_days=estimated_duration,
        )

        logger.info(
            "Plan complete: %d bounties, ~$%.2f estimated, ~%d day DAG depth",
            len(specs),
            total_cost_usd,
            estimated_duration,
        )

        return project

    # ── Run ───────────────────────────────────────────────────

    async def run(self, project: Project) -> ProjectResult:
        self._phase = ProjectPhase.RUNNING
        self._started_at = asyncio.get_event_loop().time()
        self._stopped = False

        logger.info("Running project '%s' (%d bounties)", project.name, len(project.bounties))

        try:
            await self._sign_pending_bounties(project)

            while not self._stopped:
                await self._poll_bounties(project)

                status = self.get_status(project)
                if status.completed + status.failed >= status.total:
                    break

                await asyncio.sleep(15.0)

            result = self._build_result(project)
            self._phase = (
                ProjectPhase.FAILED
                if result.failed > 0 and result.completed == 0
                else ProjectPhase.COMPLETED
            )

            if self.on_project_completed:
                self.on_project_completed(result)

            return result
        except Exception:
            self._phase = ProjectPhase.FAILED
            raise

    async def stop(self, project: Project) -> None:
        logger.info("Stopping orchestrator...")
        self._stopped = True
        self._phase = ProjectPhase.STOPPED

        for bounty_id, state in project.bounties.items():
            if state.status in ("open", "pending_signature", "blocked"):
                try:
                    await self.client.cancel_bounty(bounty_id)
                    state.status = "cancelled"
                except Exception:
                    pass

    def get_status(self, project: Project) -> ProjectStatus:
        completed = in_progress = blocked = failed = open_count = 0
        for state in project.bounties.values():
            s = state.status
            if s == "completed":
                completed += 1
            elif s in ("assigned", "submitted"):
                in_progress += 1
            elif s == "blocked":
                blocked += 1
            elif s in ("cancelled", "expired", "disputed"):
                failed += 1
            elif s in ("open", "pending_signature"):
                open_count += 1

        elapsed = (
            (asyncio.get_event_loop().time() - self._started_at) * 1000
            if self._started_at
            else 0
        )

        return ProjectStatus(
            phase=self._phase,
            total=len(project.bounties),
            completed=completed,
            in_progress=in_progress,
            blocked=blocked,
            failed=failed,
            open=open_count,
            elapsed=elapsed,
        )

    # ── Internal ──────────────────────────────────────────────

    async def _sign_pending_bounties(self, project: Project) -> None:
        for bounty_id, state in project.bounties.items():
            if state.status != "pending_signature":
                continue
            try:
                unsigned_tx = await self.client.refresh_escrow(bounty_id)
                signed_tx = self.client._signing.sign_transaction(unsigned_tx)
                await self.client._post(
                    "/transactions/submit",
                    {
                        "bountyId": bounty_id,
                        "txSignature": signed_tx,
                        "operationType": "create_bounty",
                    },
                )
                state.status = "open"
                logger.info("Signed bounty '%s' (%s)", state.spec.title, bounty_id)
            except Exception as e:
                logger.error("Failed to sign bounty %s: %s", bounty_id, e)

    async def _poll_bounties(self, project: Project) -> None:
        for bounty_id, state in project.bounties.items():
            if state.status in ("completed", "cancelled", "expired"):
                continue

            try:
                bounty = await self.client.get_bounty(bounty_id)
                old_status = state.status
                state.status = bounty.status

                if bounty.status == "pending_signature" and old_status == "blocked":
                    await self._handle_unblocked(project, bounty_id, state)
                elif bounty.status == "open":
                    await self._handle_bids(project, bounty_id, state)
                elif bounty.status == "submitted":
                    await self._handle_submission(project, bounty_id, state)
                elif bounty.status == "completed":
                    await self._handle_completed(project, bounty_id, state)
            except Exception as e:
                logger.error("Poll error for %s: %s", bounty_id, e)

    async def _handle_bids(
        self, project: Project, bounty_id: str, state: BountyState
    ) -> None:
        if not self.auto_accept_bids:
            return

        bounty = await self.client.get_bounty(bounty_id)
        bids = await self.client.list_bids(bounty_id)

        if not bids:
            return

        selected: Optional[Bid] = None

        if callable(self.auto_accept_bids):
            selected = self.auto_accept_bids(bounty, bids)
        elif self.auto_accept_bids == "first":
            selected = bids[0]
        elif self.auto_accept_bids == "first-qualified":
            selected = bids[0]
        elif self.auto_accept_bids == "cheapest":
            selected = min(bids, key=lambda b: int(b.bid_amount))

        if selected:
            try:
                await self.client.accept_bid(bounty_id, selected.id)
                state.status = "assigned"
                state.assignee_wallet = selected.agent_wallet
                logger.info(
                    "Accepted bid from %s on '%s'",
                    selected.agent_wallet[:8],
                    state.spec.title,
                )
                if self.on_bounty_assigned:
                    self.on_bounty_assigned(bounty, selected.agent_wallet)
            except Exception as e:
                logger.error("Failed to accept bid on %s: %s", bounty_id, e)

    async def _handle_submission(
        self, project: Project, bounty_id: str, state: BountyState
    ) -> None:
        if not self.auto_approve_verified:
            return

        try:
            result = await self.client.verify(bounty_id)
            if result.get("all_passed"):
                bounty = await self.client.approve_work(bounty_id)
                state.status = "completed"
                logger.info("Auto-approved '%s'", state.spec.title)
                if self.on_bounty_completed:
                    self.on_bounty_completed(bounty)
                await self._write_output_context(project, state)
        except Exception as e:
            logger.error("Auto-approve error for %s: %s", bounty_id, e)
            try:
                bounty = await self.client.approve_work(bounty_id)
                state.status = "completed"
                await self._write_output_context(project, state)
            except Exception:
                pass

    async def _handle_unblocked(
        self, project: Project, bounty_id: str, state: BountyState
    ) -> None:
        logger.info("Bounty '%s' unblocked, refreshing escrow...", state.spec.title)
        try:
            unsigned_tx = await self.client.refresh_escrow(bounty_id)
            signed_tx = self.client._signing.sign_transaction(unsigned_tx)
            await self.client._post(
                "/transactions/submit",
                {
                    "bountyId": bounty_id,
                    "txSignature": signed_tx,
                    "operationType": "create_bounty",
                },
            )
            state.status = "open"
            logger.info("Signed unblocked bounty '%s'", state.spec.title)
        except Exception as e:
            logger.error("Failed to sign unblocked bounty %s: %s", bounty_id, e)
            state.status = "pending_signature"

    async def _handle_completed(
        self, project: Project, bounty_id: str, state: BountyState
    ) -> None:
        state.status = "completed"
        bounty = await self.client.get_bounty(bounty_id)
        logger.info("Bounty '%s' completed", state.spec.title)
        if self.on_bounty_completed:
            self.on_bounty_completed(bounty)
        await self._write_output_context(project, state)

    async def _write_output_context(
        self, project: Project, state: BountyState
    ) -> None:
        if not state.spec.output_context_key:
            return
        try:
            await self.client.write_context(
                project.workspace_id,
                state.spec.output_context_key,
                {"bountyId": state.bounty_id, "status": "completed"},
                state.bounty_id,
            )
        except Exception as e:
            logger.warning("Failed to write context for %s: %s", state.bounty_id, e)

    def _build_result(self, project: Project) -> ProjectResult:
        completed = failed = 0
        bounty_results: dict[str, dict[str, Any]] = {}

        for bounty_id, state in project.bounties.items():
            if state.status == "completed":
                completed += 1
            elif state.status in ("cancelled", "expired", "disputed"):
                failed += 1

            bounty_results[bounty_id] = {
                "status": state.status,
                "agentWallet": state.assignee_wallet,
            }

        elapsed = (asyncio.get_event_loop().time() - self._started_at) * 1000

        return ProjectResult(
            completed=completed,
            failed=failed,
            total_cost_usd=project.estimated_total_cost_usd,
            duration_ms=elapsed,
            bounty_results=bounty_results,
        )

    def _usd_to_token_amount(self, usd: float) -> str:
        return str(round(usd * 10**6))

    def _calculate_dag_depth(self, specs: list[BountySpec]) -> int:
        depths: dict[str, int] = {}
        spec_map = {s.temp_id: s for s in specs}

        def get_depth(temp_id: str) -> int:
            if temp_id in depths:
                return depths[temp_id]
            spec = spec_map.get(temp_id)
            if not spec or not spec.blocked_by:
                depths[temp_id] = 1
                return 1
            d = max(get_depth(dep) for dep in spec.blocked_by) + 1
            depths[temp_id] = d
            return d

        return max(get_depth(s.temp_id) for s in specs) if specs else 0
