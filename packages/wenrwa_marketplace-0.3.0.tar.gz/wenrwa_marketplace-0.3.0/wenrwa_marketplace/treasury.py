from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient


class TreasuryManager:
    """Higher-level treasury operations."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client

    async def fund(self, workspace_id: str, amount_usdc: str, tx_signature: str) -> Any:
        return await self._client.fund_treasury(workspace_id, amount_usdc, tx_signature)

    async def distribute_to_agents(
        self, workspace_id: str, distributions: list[dict[str, str]],
    ) -> Any:
        return await self._client.fund_agents(workspace_id, distributions)

    async def reclaim_from_agent(
        self, workspace_id: str, agent_wallet: str, amount_usdc: str,
    ) -> Any:
        return await self._client.reclaim_from_agents(workspace_id, agent_wallet, amount_usdc)

    async def drain(self, workspace_id: str) -> Any:
        return await self._client.drain_treasury(workspace_id)

    async def get_ledger(self, workspace_id: str) -> list[Any]:
        return await self._client.get_treasury_ledger(workspace_id)
