"""
CostEstimator — smart bounty pricing utility.

Analyzes task schemas to estimate costs, converts to USD,
applies market markup, and suggests reward amounts.

Supports two cost models:
  - 'token': LLM-heavy tasks priced via estimated tokens × model pricing
  - 'fixed':  Non-LLM tasks (video, image, audio) with a base USD cost

These are **rough guides** for bounty pricing, not precise estimates.
The real price discovery happens when agents bid competitively.

Usage:
    estimator = CostEstimator(default_model="claude-opus-4")
    estimate = await estimator.estimate({"type": "code", "description": "..."}, reward_symbol="USDC")
    # → CostEstimate(estimated_tokens=60000, base_cost_usd=1.20, ...)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Optional


# ── Model Pricing ────────────────────────────────────────────────

# Cost per 1M tokens in USD (blended input/output average).
MODEL_PRICING: dict[str, float] = {
    "claude-opus-4": 20.0,
    "claude-sonnet-4": 4.0,
    "claude-haiku-4": 1.0,
    "gpt-4o": 6.0,
    "gpt-4o-mini": 0.30,
    "gpt-4-turbo": 12.0,
    "gemini-2.0-pro": 5.0,
    "gemini-2.0-flash": 0.50,
    "llama-3.1-405b": 3.0,
    "llama-3.1-70b": 1.0,
    "mistral-large": 4.0,
    "deepseek-v3": 1.0,
}

# ── Task Categories ─────────────────────────────────────────────

CostModel = Literal["token", "fixed"]


@dataclass
class TaskCategoryConfig:
    """Configuration for a task category."""

    cost_model: CostModel
    """Cost model: 'token' for LLM-heavy tasks, 'fixed' for non-LLM API costs."""
    base_tokens: int
    """Base token estimate for LLM tasks ('token' model). 0 for 'fixed' model."""
    base_cost_usd: float
    """Base USD cost for non-LLM tasks ('fixed' model). 0 for 'token' model."""
    keywords: list[str]
    """Keywords used for auto-detecting this category from task schemas."""


# All supported task categories with cost model, base estimates, and detection keywords.
TASK_CATEGORIES: dict[str, TaskCategoryConfig] = {
    # ── LLM / Token-based ──────────────────────────────
    "code": TaskCategoryConfig("token", 50_000, 0, ["code", "function", "implement", "bug", "fix", "refactor", "programming", "developer"]),
    "research": TaskCategoryConfig("token", 100_000, 0, ["research", "analysis", "report", "investigate", "study"]),
    "data": TaskCategoryConfig("token", 30_000, 0, ["data", "csv", "database", "etl", "dataset", "sql", "pipeline"]),
    "api": TaskCategoryConfig("token", 40_000, 0, ["api", "endpoint", "rest", "graphql", "webhook"]),
    "testing": TaskCategoryConfig("token", 45_000, 0, ["test", "spec", "qa", "coverage", "assertion"]),
    "documentation": TaskCategoryConfig("token", 35_000, 0, ["doc", "readme", "guide", "tutorial", "manual"]),
    "security-audit": TaskCategoryConfig("token", 80_000, 0, ["audit", "security", "vulnerability", "penetration", "cve"]),
    "deployment": TaskCategoryConfig("token", 25_000, 0, ["deploy", "ci/cd", "docker", "kubernetes", "infrastructure", "devops"]),
    "content-writing": TaskCategoryConfig("token", 40_000, 0, ["blog", "article", "copywriting", "content", "seo", "social media"]),
    "creative-writing": TaskCategoryConfig("token", 60_000, 0, ["story", "fiction", "screenplay", "scriptwriting", "narrative", "novel", "creative writing", "short story"]),
    "translation": TaskCategoryConfig("token", 60_000, 0, ["translate", "translation", "localize", "localization", "i18n", "multilingual"]),
    "summarization": TaskCategoryConfig("token", 25_000, 0, ["summarize", "summary", "condense", "digest", "tldr", "meeting notes"]),
    "math-science": TaskCategoryConfig("token", 80_000, 0, ["math", "calculation", "proof", "equation", "simulation", "physics", "chemistry", "scientific"]),
    "legal": TaskCategoryConfig("token", 90_000, 0, ["legal", "contract", "compliance", "regulation", "terms of service", "privacy policy", "liability"]),
    "finance": TaskCategoryConfig("token", 70_000, 0, ["finance", "financial", "accounting", "budget", "forecast", "revenue", "portfolio", "valuation"]),
    "marketing": TaskCategoryConfig("token", 45_000, 0, ["marketing", "campaign", "ad copy", "branding", "growth", "funnel", "conversion"]),
    "education": TaskCategoryConfig("token", 50_000, 0, ["course", "lesson", "curriculum", "quiz", "tutoring", "educational", "training"]),
    "customer-support": TaskCategoryConfig("token", 20_000, 0, ["support", "faq", "helpdesk", "ticket", "response template", "chatbot"]),
    "presentation": TaskCategoryConfig("token", 50_000, 0, ["presentation", "slides", "powerpoint", "pitch deck", "keynote", "google slides"]),
    # ── Non-LLM / Fixed-cost ───────────────────────────
    "video": TaskCategoryConfig("fixed", 0, 5.00, ["video", "animation", "clip", "footage", "motion", "render", "film", "sora", "runway"]),
    "image-generation": TaskCategoryConfig("fixed", 0, 1.00, ["image", "illustration", "graphic", "logo", "banner", "dall-e", "midjourney", "stable diffusion", "generate image"]),
    "audio": TaskCategoryConfig("fixed", 0, 2.00, ["audio", "podcast", "transcription", "voice", "tts", "speech", "music", "sound"]),
    "design": TaskCategoryConfig("fixed", 0, 2.00, ["design", "ui/ux", "ux design", "ui design", "wireframe", "mockup", "figma", "prototype", "layout design"]),
    # ── Fallback ───────────────────────────────────────
    "generic": TaskCategoryConfig("token", 25_000, 0, []),
}

# Backwards-compatible base token estimates by category.
# For token-based categories this is the baseTokens; for fixed-cost categories this returns 0.
TASK_COMPLEXITY: dict[str, int] = {
    k: v.base_tokens for k, v in TASK_CATEGORIES.items()
}

# Keyword detection priority order (most specific → least specific).
_KEYWORD_DETECTION_ORDER: list[str] = [
    "security-audit",
    "math-science",
    "image-generation",
    "creative-writing",
    "content-writing",
    "customer-support",
    "video",
    "audio",
    "design",
    "presentation",
    "legal",
    "finance",
    "marketing",
    "education",
    "testing",
    "api",
    "deployment",
    "data",
    "summarization",
    "translation",
    "research",
    "documentation",
    "code",
]

# ── Token Config ─────────────────────────────────────────────────


@dataclass
class TokenConfig:
    """Configuration for a reward token."""

    decimals: int
    """Number of decimal places (e.g. USDC = 6, SOL = 9)."""
    price_usd: float | None = None
    """USD price per 1 whole token. Required for accurate conversion on non-stablecoins."""


DEFAULT_TOKENS: dict[str, TokenConfig] = {
    "USDC": TokenConfig(decimals=6, price_usd=1.0),
    "USDT": TokenConfig(decimals=6, price_usd=1.0),
}


# ── Types ────────────────────────────────────────────────────────


@dataclass
class CostEstimateBreakdown:
    """Breakdown of how the estimate was calculated."""

    base_tokens: int
    base_cost_usd: float
    complexity_multiplier: float
    description_length_factor: float


@dataclass
class CostEstimate:
    """Result from CostEstimator.estimate()."""

    cost_model: CostModel
    estimated_tokens: int
    base_cost_usd: float
    suggested_reward_usd: float
    suggested_reward_amount: str
    reward_token_price_usd: float
    confidence: int
    model: str
    category: str
    breakdown: CostEstimateBreakdown
    warnings: list[str] = field(default_factory=list)

    @property
    def token_cost_usd(self) -> float:
        """Deprecated: use base_cost_usd instead. Kept for backwards compatibility."""
        return self.base_cost_usd


class CostEstimator:
    """
    Smart bounty pricing utility.

    Analyzes task schemas to estimate costs, converts to USD,
    applies market markup, and suggests reward amounts.

    Supports two cost models:
      - 'token': LLM-heavy tasks (code, research, etc.) priced via tokens × model pricing
      - 'fixed': Non-LLM tasks (video, image, audio, design) with base USD cost
    """

    def __init__(
        self,
        *,
        default_model: str = "claude-sonnet-4",
        market_markup_pct: int = 150,
        custom_pricing: dict[str, float] | None = None,
        custom_complexity: dict[str, int] | None = None,
        custom_categories: dict[str, dict[str, Any]] | None = None,
        custom_tokens: dict[str, TokenConfig] | None = None,
    ) -> None:
        self._model = default_model
        self._markup_pct = market_markup_pct
        self._pricing = {**MODEL_PRICING, **(custom_pricing or {})}
        self._tokens = {**DEFAULT_TOKENS, **(custom_tokens or {})}

        # Build categories: start from built-in, merge custom_categories, then legacy custom_complexity
        cats: dict[str, TaskCategoryConfig] = {
            k: TaskCategoryConfig(v.cost_model, v.base_tokens, v.base_cost_usd, list(v.keywords))
            for k, v in TASK_CATEGORIES.items()
        }

        if custom_categories:
            for key, partial in custom_categories.items():
                base = cats.get(key, TASK_CATEGORIES["generic"])
                cats[key] = TaskCategoryConfig(
                    cost_model=partial.get("cost_model", base.cost_model),
                    base_tokens=partial.get("base_tokens", base.base_tokens),
                    base_cost_usd=partial.get("base_cost_usd", base.base_cost_usd),
                    keywords=partial.get("keywords", list(base.keywords)),
                )

        # Legacy: custom_complexity overrides base_tokens for token-model categories
        if custom_complexity:
            for key, tokens in custom_complexity.items():
                if key in cats:
                    cats[key] = TaskCategoryConfig(
                        cats[key].cost_model, tokens, cats[key].base_cost_usd, cats[key].keywords,
                    )
                else:
                    cats[key] = TaskCategoryConfig("token", tokens, 0, [])

        self._categories = cats

    async def estimate(
        self,
        task_schema: dict[str, Any],
        *,
        category: str | None = None,
        model: str | None = None,
        reward_symbol: str = "USDC",
    ) -> CostEstimate:
        """
        Estimate the cost of executing a bounty task.

        These are rough suggestions to help price bounties — not precise cost calculations.
        Actual costs depend on the agent's model, approach, and efficiency.
        """
        used_model = model or self._model
        warnings: list[str] = []
        detected_category = self._detect_category(task_schema, category)
        cat_config = self._categories.get(detected_category, self._categories["generic"])
        cost_model = cat_config.cost_model

        complexity_multiplier = self._analyze_complexity(task_schema)
        desc_factor = self._description_length_factor(task_schema)

        estimated_tokens = 0
        base_cost_usd = 0.0

        if cost_model == "token":
            base_tokens = cat_config.base_tokens or self._categories["generic"].base_tokens
            estimated_tokens = round(base_tokens * complexity_multiplier * desc_factor)
            cost_per_1m = self._pricing.get(used_model, self._pricing["claude-sonnet-4"])
            base_cost_usd = (estimated_tokens / 1_000_000) * cost_per_1m
        else:
            base_cost_usd = cat_config.base_cost_usd * complexity_multiplier * desc_factor
            warnings.append(
                f'"{detected_category}" uses fixed-cost estimation (not token-based). '
                f"Base cost: ${cat_config.base_cost_usd:.2f}. "
                f"Actual costs vary by provider and output specifications."
            )

        base_cost_usd = round(base_cost_usd, 4)

        suggested_reward_usd = round(
            base_cost_usd * (1 + self._markup_pct / 100), 2
        )

        # Resolve token config
        token_cfg = self._tokens.get(reward_symbol)
        decimals = token_cfg.decimals if token_cfg else 6
        reward_token_price_usd = token_cfg.price_usd if token_cfg else None

        if reward_token_price_usd is None:
            warnings.append(
                f"No USD price configured for {reward_symbol}. "
                f"Reward amount assumes $1/token — provide custom_tokens with price_usd for accuracy."
            )
            reward_token_price_usd = 1.0

        reward_in_whole_tokens = suggested_reward_usd / reward_token_price_usd
        suggested_reward_amount = str(round(reward_in_whole_tokens * 10**decimals))

        confidence = self._calculate_confidence(task_schema, detected_category)

        return CostEstimate(
            cost_model=cost_model,
            estimated_tokens=estimated_tokens,
            base_cost_usd=base_cost_usd,
            suggested_reward_usd=suggested_reward_usd,
            suggested_reward_amount=suggested_reward_amount,
            reward_token_price_usd=reward_token_price_usd,
            confidence=confidence,
            model=used_model,
            category=detected_category,
            warnings=warnings,
            breakdown=CostEstimateBreakdown(
                base_tokens=cat_config.base_tokens,
                base_cost_usd=cat_config.base_cost_usd,
                complexity_multiplier=complexity_multiplier,
                description_length_factor=desc_factor,
            ),
        )

    async def advise_pricing(
        self,
        task_schema: dict[str, Any],
        *,
        category: str | None = None,
        model: str | None = None,
        reward_symbol: str = "USDC",
    ) -> str:
        """Get human-readable pricing advice for a bounty."""
        est = await self.estimate(
            task_schema,
            category=category,
            model=model,
            reward_symbol=reward_symbol,
        )

        title = self._extract_title(task_schema)
        lines = [
            f'Pricing Estimate for "{title}"',
            "\u2500" * 50,
            f"Category:           {est.category} ({est.cost_model} model)",
            f"Model:              {est.model}",
        ]

        if est.cost_model == "token":
            lines.append(f"Estimated tokens:   {est.estimated_tokens:,}")

        lines.extend([
            f"Base cost (USD):    ${est.base_cost_usd:.2f}",
            f"Market markup:      {self._markup_pct}%",
            f"Suggested reward:   ${est.suggested_reward_usd:.2f} USD",
            f"Token amount:       {est.suggested_reward_amount} {reward_symbol} (@ ${est.reward_token_price_usd}/token)",
            f"Confidence:         {est.confidence}%",
            "",
            "Breakdown:",
        ])

        if est.cost_model == "token":
            lines.append(
                f"  Base tokens:      {est.breakdown.base_tokens:,} ({est.category} category)"
            )
        else:
            lines.append(
                f"  Base cost:        ${est.breakdown.base_cost_usd:.2f} ({est.category} category)"
            )

        lines.extend([
            f"  Complexity:       {est.breakdown.complexity_multiplier:.2f}x",
            f"  Description:      {est.breakdown.description_length_factor:.2f}x",
        ])

        if est.warnings:
            lines.extend(["", "Warnings:"])
            for w in est.warnings:
                lines.append(f"  - {w}")

        if est.confidence < 50:
            lines.extend([
                "",
                "Note: Low confidence — consider adding more detail to the task schema.",
            ])

        lines.extend([
            "",
            "Note: These are rough estimates to guide bounty pricing. Actual costs depend on",
            "the agent's model, approach, and task complexity. Price discovery happens at bid time.",
        ])

        return "\n".join(lines)

    def estimate_token_usage(self, task_schema: dict[str, Any]) -> int:
        """
        Estimate token usage for a completed bounty (used by budget tracking).
        For fixed-cost categories, returns a synthetic token count based on base_cost_usd.
        """
        category = self._detect_category(task_schema)
        cat_config = self._categories.get(category, self._categories["generic"])
        multiplier = self._analyze_complexity(task_schema)

        if cat_config.cost_model == "token":
            return round(cat_config.base_tokens * multiplier)

        # For fixed-cost categories, convert base_cost_usd to a synthetic token count
        # using a rough $4/1M tokens (Sonnet-tier) so budget tracking still works
        synthetic_tokens = (cat_config.base_cost_usd * multiplier / 4.0) * 1_000_000
        return round(synthetic_tokens)

    def list_categories(
        self,
    ) -> list[dict[str, Any]]:
        """Get the list of all supported categories (excluding generic)."""
        return [
            {
                "name": name,
                "cost_model": cfg.cost_model,
                "base_tokens": cfg.base_tokens,
                "base_cost_usd": cfg.base_cost_usd,
            }
            for name, cfg in self._categories.items()
            if name != "generic"
        ]

    # ── Private Helpers ──────────────────────────────────────────

    def _detect_category(
        self,
        schema: dict[str, Any],
        override: str | None = None,
    ) -> str:
        if override:
            return override.lower()

        # Check for explicit category/type hints in schema
        if "category" in schema:
            explicit = str(schema["category"]).lower()
            if explicit in self._categories:
                return explicit
        if "type" in schema:
            explicit = str(schema["type"]).lower()
            if explicit in self._categories:
                return explicit

        # Keyword detection — check in priority order
        text = json.dumps(schema).lower()

        # First check the built-in priority order
        for cat_name in _KEYWORD_DETECTION_ORDER:
            cat = self._categories.get(cat_name)
            if not cat:
                continue
            for kw in cat.keywords:
                if kw in text:
                    return cat_name

        # Then check any custom categories not in the priority list
        for cat_name, cat in self._categories.items():
            if cat_name == "generic" or cat_name in _KEYWORD_DETECTION_ORDER:
                continue
            for kw in cat.keywords:
                if kw in text:
                    return cat_name

        return "generic"

    def _analyze_complexity(self, schema: dict[str, Any]) -> float:
        multiplier = 1.0
        text = json.dumps(schema).lower()

        if any(w in text for w in ("multiple", "several", "multi")):
            multiplier += 0.3
        if any(w in text for w in ("complex", "comprehensive", "thorough")):
            multiplier += 0.4
        if any(w in text for w in ("refactor", "rewrite", "redesign")):
            multiplier += 0.5
        if any(w in text for w in ("anchor", "solana", "blockchain")):
            multiplier += 0.3
        if any(w in text for w in ("concurrent", "parallel", "async")):
            multiplier += 0.2

        # Output quantity indicators (especially for fixed-cost categories)
        if any(w in text for w in ("batch", "bulk", "series")):
            multiplier += 0.5
        if any(w in text for w in ("high quality", "hd", "4k", "professional")):
            multiplier += 0.3
        if any(w in text for w in ("long", "extended", "full-length")):
            multiplier += 0.4

        field_count = len(schema)
        if field_count > 10:
            multiplier += 0.3
        elif field_count > 5:
            multiplier += 0.1

        return min(multiplier, 3.0)

    def _description_length_factor(self, schema: dict[str, Any]) -> float:
        length = len(json.dumps(schema))

        if length < 100:
            return 0.8
        if length < 500:
            return 1.0
        if length < 2000:
            return 1.2
        if length < 5000:
            return 1.5
        return 1.8

    def _calculate_confidence(self, schema: dict[str, Any], category: str) -> int:
        confidence = 50

        if "category" in schema or "type" in schema:
            confidence += 15
        if category in self._categories:
            confidence += 10
        if "description" in schema or "taskDescription" in schema:
            confidence += 10

        field_count = len(schema)
        if field_count >= 3:
            confidence += 10
        if field_count >= 6:
            confidence += 5

        return min(confidence, 95)

    def _extract_title(self, schema: dict[str, Any]) -> str:
        if "title" in schema:
            return str(schema["title"])
        if "taskDescription" in schema:
            return str(schema["taskDescription"])[:60]
        if "description" in schema:
            return str(schema["description"])[:60]
        return "Untitled Task"
