from __future__ import annotations

import asyncio
from typing import Callable, Awaitable


class HeartbeatManager:
    """Manages periodic heartbeat tasks using asyncio."""

    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task] = {}

    def start(
        self,
        bounty_id: str,
        send_fn: Callable[[], Awaitable[None]],
        interval_seconds: float = 60.0,
    ) -> None:
        self.stop(bounty_id)

        async def _loop() -> None:
            while True:
                await asyncio.sleep(interval_seconds)
                try:
                    await send_fn()
                except Exception:
                    pass  # Heartbeat failures are non-fatal

        self._tasks[bounty_id] = asyncio.get_event_loop().create_task(_loop())

    def stop(self, bounty_id: str) -> None:
        task = self._tasks.pop(bounty_id, None)
        if task:
            task.cancel()

    def stop_all(self) -> None:
        for bounty_id in list(self._tasks):
            self.stop(bounty_id)
