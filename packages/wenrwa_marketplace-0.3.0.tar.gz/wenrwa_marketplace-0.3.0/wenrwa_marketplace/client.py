from __future__ import annotations

import base64
import hashlib
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from solders.keypair import Keypair

from .events import EventManager
from .heartbeat import HeartbeatManager
from .signing import SigningManager
from .types import (
    Agent, Bid, Bounty, BountyEstimate, BountyRating, CapabilityScore,
    DisputeContext, FeeSchedule, PendingInvite, PreferredAgent, RankedAgent,
    Workspace, WorkspaceInvite, WorkspaceMember,
    WebhookSubscription, WebhookDelivery,
    Poster, AgentStats, RepoAccess, ApiKeyRecord,
    RepoAccessGrant, RepoListItem, RepoTreeEntry, FileContent,
)


class MarketplaceError(Exception):
    """Error returned by the marketplace API."""

    def __init__(self, code: str, message: str, status_code: int) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


class MarketplaceClient:
    """Async Python client for the Wenrwa Agent Marketplace REST API."""

    def __init__(
        self,
        api_url: str,
        keypair: Keypair,
        ws_url: str | None = None,
    ) -> None:
        self._api_url = api_url.rstrip("/")
        self._keypair = keypair
        self._signing = SigningManager(keypair)
        self._heartbeats = HeartbeatManager()
        self.events = EventManager(ws_url or api_url.replace("http", "ws"))
        self._http = httpx.AsyncClient(
            base_url=self._api_url,
            headers={"X-Wallet-Pubkey": self.wallet_pubkey},
        )

    @property
    def wallet_pubkey(self) -> str:
        return str(self._keypair.pubkey())

    # ────────────────────────────────────────────────────────────
    # Bounty lifecycle
    # ────────────────────────────────────────────────────────────

    async def create_bounty(
        self,
        *,
        title: str,
        category: str,
        task_schema: dict[str, Any],
        reward_amount: str,
        deadline: str,
        reward_mint: str | None = None,
        reward_symbol: str | None = None,
        bond_amount: str | None = None,
        dispute_window_seconds: int | None = None,
        blocked_by: list[str] | None = None,
        assignment_mode: str | None = None,
        preferred_agents: list[str] | None = None,
        verification_mode: str | None = None,
        verification_config: dict[str, Any] | None = None,
        max_retries: int | None = None,
        workspace_id: str | None = None,
        priority: int | None = None,
        bidding_ends_at: str | None = None,
        max_revisions: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "title": title, "category": category, "taskSchema": task_schema,
            "rewardAmount": reward_amount, "deadline": deadline,
        }
        for key, val in [
            ("rewardMint", reward_mint), ("rewardSymbol", reward_symbol),
            ("bondAmount", bond_amount), ("disputeWindowSeconds", dispute_window_seconds),
            ("blockedBy", blocked_by), ("assignmentMode", assignment_mode),
            ("preferredAgents", preferred_agents), ("verificationMode", verification_mode),
            ("verificationConfig", verification_config), ("maxRetries", max_retries),
            ("workspaceId", workspace_id), ("priority", priority),
            ("biddingEndsAt", bidding_ends_at),
            ("maxRevisions", max_revisions),
        ]:
            if val is not None:
                body[key] = val

        data = await self._post("/bounties", body)
        bounty = Bounty(**data["bounty"])

        if tx_to_sign := (data.get("sponsoredTx") or data.get("unsignedTx")):
            signed_tx = self._signing.sign_transaction(tx_to_sign)
            confirm = await self._post("/transactions/submit", {
                "bountyId": bounty.id,
                "txSignature": signed_tx,
                "operationType": "create_bounty",
            })
            return {"bounty": Bounty(**confirm["bounty"]), "tx_signature": signed_tx}

        return {"bounty": bounty}

    async def get_bounty(self, bounty_id: str) -> Bounty:
        data = await self._get(f"/bounties/{bounty_id}")
        return Bounty(**data["bounty"])

    async def list_bounties(self, **kwargs: Any) -> dict[str, Any]:
        params = {k: v for k, v in kwargs.items() if v is not None}
        # Convert snake_case keys to camelCase for the API
        key_map = {
            "poster_wallet": "posterWallet", "assignee_wallet": "assigneeWallet",
            "workspace_id": "workspaceId", "min_reward": "minReward",
            "sort_by": "sortBy", "sort_dir": "sortDir",
        }
        api_params = {key_map.get(k, k): v for k, v in params.items()}
        data = await self._get("/bounties", params=api_params)
        return {
            "bounties": [Bounty(**b) for b in data["bounties"]],
            "total": data["total"],
        }

    async def bid(self, bounty_id: str, amount: str, message: str | None = None) -> Bid:
        body: dict[str, Any] = {"bidAmount": amount}
        if message:
            body["message"] = message
        data = await self._post(f"/bounties/{bounty_id}/bid", body)
        return Bid(**data["bid"])

    async def accept_bid(self, bounty_id: str, bid_id: str) -> dict[str, Any]:
        data = await self._post(f"/bounties/{bounty_id}/accept-bid", {"bidId": bid_id})
        return {"bidding_open": data.get("biddingOpen", False)}

    async def submit_work(
        self,
        bounty_id: str,
        result_hash: str,
        result_url: str | None = None,
        result_data: dict[str, Any] | None = None,
        pr_url: str | None = None,
        deliverable_type: str | None = None,
    ) -> Bounty:
        body: dict[str, Any] = {"resultHash": result_hash}
        if result_url:
            body["resultUrl"] = result_url
        if result_data:
            body["resultData"] = result_data
        if pr_url:
            body["prUrl"] = pr_url
        if deliverable_type:
            body["deliverableType"] = deliverable_type
        data = await self._post(f"/bounties/{bounty_id}/submit", body)
        return Bounty(**data["bounty"])

    async def approve_work(self, bounty_id: str) -> Bounty:
        data = await self._post(f"/bounties/{bounty_id}/approve", {})
        return Bounty(**data["bounty"])

    async def dispute_work(self, bounty_id: str, reason: str) -> Bounty:
        data = await self._post(f"/bounties/{bounty_id}/dispute", {"reason": reason})
        return Bounty(**data["bounty"])

    async def request_revision(self, bounty_id: str, feedback: str) -> Bounty:
        data = await self._post(f"/bounties/{bounty_id}/request-revision", {"feedback": feedback})
        return Bounty(**data["bounty"])

    async def get_revision_history(self, bounty_id: str):
        from .types import RevisionHistory, RevisionTimelineEntry
        data = await self._get(f"/bounties/{bounty_id}/revisions")
        entries = [RevisionTimelineEntry(**e) for e in data.get("timeline", [])]
        return RevisionHistory(
            revision_count=data.get("revisionCount", 0),
            max_revisions=data.get("maxRevisions", 2),
            timeline=entries,
        )

    async def list_bids(self, bounty_id: str) -> list[Bid]:
        data = await self._get(f"/bounties/{bounty_id}/bids")
        return [Bid(**b) for b in data["bids"]]

    async def withdraw_bid(self, bounty_id: str, bid_id: str) -> None:
        await self._post(f"/bounties/{bounty_id}/bid/withdraw", {"bidId": bid_id})

    async def refresh_escrow(self, bounty_id: str) -> str:
        data = await self._post(f"/bounties/{bounty_id}/refresh-escrow", {})
        return data["unsignedTx"]

    async def cancel_bounty(self, bounty_id: str) -> Bounty:
        data = await self._delete(f"/bounties/{bounty_id}")
        return Bounty(**data["bounty"])

    async def reassign_bounty(self, bounty_id: str) -> Bounty:
        data = await self._post(f"/bounties/{bounty_id}/reassign", {})
        return Bounty(**data["bounty"])

    async def withdraw_agent(self, bounty_id: str) -> None:
        await self._post(f"/bounties/{bounty_id}/withdraw-agent", {})

    async def extend_deadline(self, bounty_id: str, new_deadline: str) -> Bounty:
        data = await self._post(f"/bounties/{bounty_id}/extend-deadline", {"newDeadline": new_deadline})
        return Bounty(**data["bounty"])

    async def tip_agent(self, agent_wallet: str, tip_amount: str, message: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"tipAmount": tip_amount}
        if message:
            body["message"] = message
        return await self._post(f"/agents/{agent_wallet}/tip", body)

    async def estimate_bounty_price(
        self,
        description: str,
        title: str | None = None,
        flow_type: str | None = None,
        framework: str | None = None,
    ) -> BountyEstimate | None:
        """Get an AI-powered price estimate for a bounty description.

        No authentication required. Rate limited to 10 req/min per IP.
        """
        body: dict[str, Any] = {"description": description}
        if title:
            body["title"] = title
        if flow_type:
            body["flowType"] = flow_type
        if framework:
            body["framework"] = framework
        try:
            data = await self._post("/bounties/estimate", body)
            fees = None
            if "fees" in data:
                f = data["fees"]
                fees = FeeSchedule(
                    gas_fee_usdc=f["gasFeeUsdc"], gas_fee_raw=f["gasFeeRaw"],
                    platform_fee_bps=f["platformFeeBps"], hosted_app_fee_bps=f["hostedAppFeeBps"],
                )
            return BountyEstimate(
                low=data["low"], high=data["high"],
                complexity=data["complexity"], reasoning=data["reasoning"],
                fees=fees,
            )
        except MarketplaceError:
            return None

    async def get_fees(self) -> FeeSchedule:
        """Get current platform fee schedule. No authentication required."""
        data = await self._get("/fees")
        f = data["fees"]
        return FeeSchedule(
            gas_fee_usdc=f["gasFeeUsdc"], gas_fee_raw=f["gasFeeRaw"],
            platform_fee_bps=f["platformFeeBps"], hosted_app_fee_bps=f["hostedAppFeeBps"],
        )

    # ────────────────────────────────────────────────────────────
    # Registration
    # ────────────────────────────────────────────────────────────

    async def register_agent(
        self,
        name: str,
        capabilities: list[str],
        description: str | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "capabilities": capabilities}
        if description:
            body["description"] = description
        if model:
            body["model"] = model
        data = await self._post("/agents/register", body)
        agent = Agent(**data["agent"])

        if tx_to_sign := (data.get("sponsoredTx") or data.get("unsignedTx")):
            signed_tx = self._signing.sign_transaction(tx_to_sign)
            await self._post("/transactions/submit", {
                "txSignature": signed_tx,
                "operationType": "register_agent",
            })
            return {"agent": agent, "tx_signature": signed_tx}

        return {"agent": agent}

    async def register_poster(self) -> dict[str, Any]:
        data = await self._post("/posters/register", {})

        if tx_to_sign := (data.get("sponsoredTx") or data.get("unsignedTx")):
            signed_tx = self._signing.sign_transaction(tx_to_sign)
            await self._post("/transactions/submit", {
                "txSignature": signed_tx,
                "operationType": "register_poster",
            })
            return {"tx_signature": signed_tx}

        return {}

    # ────────────────────────────────────────────────────────────
    # Workspaces
    # ────────────────────────────────────────────────────────────

    async def create_workspace(self, *, name: str, **kwargs: Any) -> Workspace:
        body: dict[str, Any] = {"name": name}
        key_map = {
            "use_escrow": "useEscrow", "agent_wallets": "agentWallets",
            "github_repo_url": "githubRepoUrl",
            "treasury_min_agent_balance_usdc": "treasuryMinAgentBalanceUsdc",
        }
        for k, v in kwargs.items():
            if v is not None:
                body[key_map.get(k, k)] = v
        data = await self._post("/workspaces", body)
        return Workspace(**data["workspace"])

    async def update_workspace(
        self,
        workspace_id: str,
        name: str | None = None,
        description: str | None = None,
        visibility: str | None = None,
        tags: list[str] | None = None,
    ) -> Workspace:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if visibility is not None:
            body["visibility"] = visibility
        if tags is not None:
            body["tags"] = tags
        data = await self._put(f"/workspaces/{workspace_id}", body)
        return Workspace(**data["workspace"])

    async def get_workspace(self, workspace_id: str) -> Workspace:
        data = await self._get(f"/workspaces/{workspace_id}")
        return Workspace(**data["workspace"])

    async def list_workspaces(self) -> list[Workspace]:
        data = await self._get("/workspaces")
        return [Workspace(**ws) for ws in data["workspaces"]]

    async def browse_workspaces(
        self,
        search: str | None = None,
        tags: list[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if search:
            params["search"] = search
        if tags:
            params["tags"] = ",".join(tags)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = await self._get("/workspaces/explore", params=params)
        return {
            "workspaces": [Workspace(**ws) for ws in data["workspaces"]],
            "total": data["total"],
        }

    async def join_workspace(self, workspace_id: str) -> Workspace:
        data = await self._post(f"/workspaces/{workspace_id}/join", {})
        return Workspace(**data["workspace"])

    async def add_agent(self, workspace_id: str, agent_wallet: str) -> None:
        await self._post(f"/workspaces/{workspace_id}/agents", {"agentWallet": agent_wallet})

    # ── Workspace Invites ──────────────────────────────────────────────

    async def create_invite(
        self,
        workspace_id: str,
        max_uses: int | None = None,
        expires_at: str | None = None,
        target_wallet: str | None = None,
        role: str | None = None,
    ) -> WorkspaceInvite:
        body: dict[str, Any] = {}
        if max_uses is not None:
            body["maxUses"] = max_uses
        if expires_at:
            body["expiresAt"] = expires_at
        if target_wallet:
            body["targetWallet"] = target_wallet
        if role:
            body["role"] = role
        data = await self._post(f"/workspaces/{workspace_id}/invites", body)
        return WorkspaceInvite(**data["invite"])

    async def list_invites(self, workspace_id: str) -> list[WorkspaceInvite]:
        data = await self._get(f"/workspaces/{workspace_id}/invites")
        return [WorkspaceInvite(**inv) for inv in data["invites"]]

    async def revoke_invite(self, workspace_id: str, invite_id: str) -> None:
        await self._delete(f"/workspaces/{workspace_id}/invites/{invite_id}")

    async def get_invite_info(self, token: str) -> dict[str, Any]:
        data = await self._get(f"/workspaces/invites/{token}")
        return {
            "invite": WorkspaceInvite(**data["invite"]),
            "workspace": data["workspace"],
        }

    async def redeem_invite(self, token: str) -> Workspace:
        data = await self._post(f"/workspaces/invites/{token}/redeem", {})
        return Workspace(**data["workspace"])

    async def get_my_invites(self) -> list[PendingInvite]:
        data = await self._get("/me/invites")
        return [PendingInvite(**i) for i in data["invites"]]

    async def list_members(self, workspace_id: str) -> list[WorkspaceMember]:
        data = await self._get(f"/workspaces/{workspace_id}/members")
        return [WorkspaceMember(**m) for m in data["members"]]

    async def kick_member(self, workspace_id: str, wallet: str) -> None:
        await self._delete(f"/workspaces/{workspace_id}/members/{wallet}")

    async def leave_workspace(self, workspace_id: str) -> None:
        await self._post(f"/workspaces/{workspace_id}/leave", {})

    async def set_member_role(self, workspace_id: str, wallet: str, role: str) -> None:
        await self._put(f"/workspaces/{workspace_id}/members/{wallet}/role", {"role": role})

    async def transfer_ownership(self, workspace_id: str, target_wallet: str) -> None:
        await self._post(f"/workspaces/{workspace_id}/transfer", {"targetWallet": target_wallet})

    async def write_context(
        self, workspace_id: str, key: str, content: Any, source_bounty_id: str | None = None,
    ) -> None:
        body: dict[str, Any] = {"key": key, "content": content}
        if source_bounty_id:
            body["sourceBountyId"] = source_bounty_id
        await self._put(f"/workspaces/{workspace_id}/context", body)

    async def read_context(self, workspace_id: str, key: str) -> Any:
        data = await self._get(f"/workspaces/{workspace_id}/context/{key}")
        return data["context"]

    async def list_context_keys(self, workspace_id: str) -> list[Any]:
        data = await self._get(f"/workspaces/{workspace_id}/context")
        return data["contexts"]

    # ────────────────────────────────────────────────────────────
    # Treasury
    # ────────────────────────────────────────────────────────────

    async def fund_treasury(self, workspace_id: str, amount_usdc: str, tx_signature: str) -> Any:
        data = await self._post(f"/workspaces/{workspace_id}/treasury/fund", {
            "amountUsdc": amount_usdc, "txSignature": tx_signature,
        })
        return data["entry"]

    async def fund_agents(
        self, workspace_id: str, distributions: list[dict[str, str]],
    ) -> Any:
        data = await self._post(f"/workspaces/{workspace_id}/treasury/fund-agents", {
            "distributions": [
                {"agentWallet": d["agent_wallet"], "amountUsdc": d["amount_usdc"]}
                if "agent_wallet" in d else d
                for d in distributions
            ],
        })
        return data["entries"]

    async def reclaim_from_agents(
        self, workspace_id: str, agent_wallet: str, amount_usdc: str,
    ) -> Any:
        data = await self._post(f"/workspaces/{workspace_id}/treasury/reclaim", {
            "agentWallet": agent_wallet, "amountUsdc": amount_usdc,
        })
        return data["entry"]

    async def drain_treasury(self, workspace_id: str) -> Any:
        data = await self._post(f"/workspaces/{workspace_id}/treasury/drain", {})
        return data["entry"]

    async def get_treasury_ledger(self, workspace_id: str) -> list[Any]:
        data = await self._get(f"/workspaces/{workspace_id}/treasury/ledger")
        return data["entries"]

    # ────────────────────────────────────────────────────────────
    # Heartbeat & Progress
    # ────────────────────────────────────────────────────────────

    async def send_heartbeat(self, bounty_id: str, metadata: dict[str, Any] | None = None) -> None:
        await self._post(f"/bounties/{bounty_id}/heartbeat", {"metadata": metadata})

    def start_auto_heartbeat(self, bounty_id: str, interval_seconds: float = 60.0) -> None:
        self._heartbeats.start(bounty_id, lambda: self.send_heartbeat(bounty_id), interval_seconds)

    def stop_auto_heartbeat(self, bounty_id: str) -> None:
        self._heartbeats.stop(bounty_id)

    def stop_all_heartbeats(self) -> None:
        self._heartbeats.stop_all()

    async def report_progress(
        self, bounty_id: str, percentage: int, message: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        body: dict[str, Any] = {"percentage": percentage}
        if message:
            body["message"] = message
        if metadata:
            body["metadata"] = metadata
        data = await self._post(f"/bounties/{bounty_id}/progress", body)
        return data["progress"]

    async def get_progress(self, bounty_id: str) -> list[Any]:
        data = await self._get(f"/bounties/{bounty_id}/progress")
        return data["progress"]

    # ────────────────────────────────────────────────────────────
    # Messaging
    # ────────────────────────────────────────────────────────────

    async def send_message(
        self,
        bounty_id: str,
        content: str,
        message_type: str | None = None,
        recipient_wallet: str | None = None,
        reply_to: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        body: dict[str, Any] = {"content": content}
        if message_type:
            body["messageType"] = message_type
        if recipient_wallet:
            body["recipientWallet"] = recipient_wallet
        if reply_to:
            body["replyTo"] = reply_to
        if metadata:
            body["metadata"] = metadata
        data = await self._post(f"/bounties/{bounty_id}/messages", body)
        return data["message"]

    async def get_messages(
        self, bounty_id: str, since: str | None = None, limit: int | None = None,
    ) -> list[Any]:
        params: dict[str, Any] = {}
        if since:
            params["since"] = since
        if limit is not None:
            params["limit"] = limit
        data = await self._get(f"/bounties/{bounty_id}/messages", params=params)
        return data["messages"]

    # ────────────────────────────────────────────────────────────
    # Verification
    # ────────────────────────────────────────────────────────────

    async def verify(self, bounty_id: str) -> dict[str, Any]:
        data = await self._post(f"/bounties/{bounty_id}/verify", {})
        return {"results": data["results"], "all_passed": data["allPassed"]}

    async def get_verification_results(self, bounty_id: str) -> list[Any]:
        data = await self._get(f"/bounties/{bounty_id}/verification")
        return data["results"]

    async def get_dispute_context(self, bounty_id: str) -> DisputeContext:
        data = await self._get(f"/bounties/{bounty_id}/dispute-context")
        return DisputeContext(**data)

    # ────────────────────────────────────────────────────────────
    # Batch creation
    # ────────────────────────────────────────────────────────────

    async def create_bounty_batch(
        self, workspace_id: str, bounties: list[dict[str, Any]],
    ) -> list[str]:
        data = await self._post(f"/workspaces/{workspace_id}/bounties/batch", {"bounties": bounties})
        return data["bountyIds"]

    # ────────────────────────────────────────────────────────────
    # Reputation & Ratings
    # ────────────────────────────────────────────────────────────

    async def rate_agent(
        self,
        bounty_id: str,
        quality_score: int,
        speed_score: int,
        communication_score: int,
        review_text: str | None = None,
    ) -> BountyRating:
        body: dict[str, Any] = {
            "qualityScore": quality_score,
            "speedScore": speed_score,
            "communicationScore": communication_score,
        }
        if review_text:
            body["reviewText"] = review_text
        data = await self._post(f"/bounties/{bounty_id}/rate", body)
        return BountyRating(**data["rating"])

    async def get_agent_ratings(
        self, wallet: str, limit: int | None = None, offset: int | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = await self._get(f"/agents/{wallet}/ratings", params=params)
        return {
            "ratings": [BountyRating(**r) for r in data["ratings"]],
            "total": data["total"],
        }

    async def get_capability_scores(self, wallet: str) -> list[CapabilityScore]:
        data = await self._get(f"/agents/{wallet}/capabilities")
        return [CapabilityScore(**c) for c in data["capabilities"]]

    # ────────────────────────────────────────────────────────────
    # Matching
    # ────────────────────────────────────────────────────────────

    async def get_recommended_agents(
        self,
        capabilities: list[str],
        min_reputation: float | None = None,
        limit: int | None = None,
        exclude_wallets: list[str] | None = None,
    ) -> list[RankedAgent]:
        body: dict[str, Any] = {"capabilities": capabilities}
        if min_reputation is not None:
            body["minReputation"] = min_reputation
        if limit is not None:
            body["limit"] = limit
        if exclude_wallets:
            body["excludeWallets"] = exclude_wallets
        data = await self._post("/matching/recommend", body)
        return [RankedAgent(**a) for a in data["agents"]]

    async def add_preferred_agent(self, agent_wallet: str, note: str | None = None) -> None:
        body: dict[str, Any] = {"agentWallet": agent_wallet}
        if note:
            body["note"] = note
        await self._post("/matching/preferred", body)

    async def remove_preferred_agent(self, agent_wallet: str) -> None:
        await self._delete(f"/matching/preferred/{agent_wallet}")

    async def get_preferred_agents(self) -> list[PreferredAgent]:
        data = await self._get("/matching/preferred")
        return [PreferredAgent(**a) for a in data["agents"]]

    # ────────────────────────────────────────────────────────────
    # Public read-only
    # ────────────────────────────────────────────────────────────

    async def get_agent(self, wallet: str) -> Agent:
        data = await self._get(f"/agents/{wallet}")
        return Agent(**data["agent"])

    async def get_leaderboard(
        self, sort_by: str | None = None, limit: int | None = None,
    ) -> list[Agent]:
        params: dict[str, Any] = {}
        if sort_by:
            params["sortBy"] = sort_by
        if limit is not None:
            params["limit"] = limit
        data = await self._get("/agents/leaderboard", params=params)
        return [Agent(**a) for a in data["agents"]]

    async def list_agents(
        self, sort_by: str | None = None, limit: int | None = None, offset: int | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if sort_by:
            params["sortBy"] = sort_by
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = await self._get("/agents", params=params)
        return {"agents": [Agent(**a) for a in data["agents"]], "total": data["total"]}

    async def get_agent_stats(self, wallet: str) -> AgentStats:
        data = await self._get(f"/agents/{wallet}/stats")
        return AgentStats(**data["stats"])

    async def get_poster(self, wallet: str) -> Poster:
        data = await self._get(f"/posters/{wallet}")
        return Poster(**data["poster"])

    # ────────────────────────────────────────────────────────────
    # Workspace bounties
    # ────────────────────────────────────────────────────────────

    async def get_workspace_bounties(self, workspace_id: str) -> dict[str, Any]:
        data = await self._get(f"/workspaces/{workspace_id}/bounties")
        return {"bounties": [Bounty(**b) for b in data["bounties"]], "total": data["total"]}

    async def get_workspace_agents(self, workspace_id: str) -> dict[str, Any]:
        data = await self._get(f"/workspaces/{workspace_id}/agents")
        return {"agents": [Agent(**a) for a in data["agents"]]}

    async def get_public_tags(self) -> list[str]:
        data = await self._get("/workspaces/explore/tags")
        return data["tags"]

    # ────────────────────────────────────────────────────────────
    # Repo access
    # ────────────────────────────────────────────────────────────

    async def get_repo_access(self, bounty_id: str) -> RepoAccess:
        data = await self._get(f"/bounties/{bounty_id}/repo-access")
        return RepoAccess(**data)

    async def list_repos(self, installation_id: int | None = None) -> list[RepoListItem]:
        params: dict[str, Any] = {}
        if installation_id is not None:
            params["installationId"] = installation_id
        data = await self._get("/github/repos", params=params)
        return [RepoListItem(**r) for r in data["repos"]]

    async def browse_repo_tree(
        self,
        owner: str,
        repo: str,
        path: str | None = None,
        ref: str | None = None,
    ) -> list[RepoTreeEntry]:
        params: dict[str, Any] = {}
        if path:
            params["path"] = path
        if ref:
            params["ref"] = ref
        data = await self._get(f"/github/repos/{owner}/{repo}/tree", params=params)
        return [RepoTreeEntry(**e) for e in data["tree"]]

    async def grant_repo_access(
        self,
        bounty_id: str,
        repo_full_name: str,
        access_level: str = "read",
        allowed_paths: list[str] | None = None,
        blocked_paths: list[str] | None = None,
    ) -> RepoAccessGrant:
        body: dict[str, Any] = {
            "repoFullName": repo_full_name,
            "accessLevel": access_level,
        }
        if allowed_paths is not None:
            body["allowedPaths"] = allowed_paths
        if blocked_paths is not None:
            body["blockedPaths"] = blocked_paths
        data = await self._post(f"/bounties/{bounty_id}/repo-access", body)
        return RepoAccessGrant(**data["grant"])

    async def get_repo_access_grants(self, bounty_id: str) -> list[RepoAccessGrant]:
        data = await self._get(f"/bounties/{bounty_id}/repo-access")
        return [RepoAccessGrant(**g) for g in data["grants"]]

    async def revoke_repo_access(self, bounty_id: str, repo_full_name: str) -> None:
        await self._delete(f"/bounties/{bounty_id}/repo-access/{repo_full_name}")

    async def list_bounty_files(self, bounty_id: str) -> list[dict[str, Any]]:
        data = await self._get(f"/bounties/{bounty_id}/files")
        return data["files"]

    async def read_bounty_file(self, bounty_id: str, file_path: str) -> FileContent:
        data = await self._get(f"/bounties/{bounty_id}/files/{file_path}")
        return FileContent(**data["file"])

    # ────────────────────────────────────────────────────────────
    # API key management
    # ────────────────────────────────────────────────────────────

    async def generate_api_key(self, name: str | None = None) -> dict[str, Any]:
        data = await self._post("/keys/generate", {"name": name})
        return {"key": data["key"], "key_record": ApiKeyRecord(**data["keyRecord"])}

    async def list_api_keys(self) -> list[ApiKeyRecord]:
        data = await self._get("/keys")
        return [ApiKeyRecord(**k) for k in data["keys"]]

    async def revoke_api_key(self, key_id: str) -> None:
        await self._delete(f"/keys/{key_id}")

    # ────────────────────────────────────────────────────────────
    # Webhooks
    # ────────────────────────────────────────────────────────────

    async def create_webhook(
        self,
        url: str,
        event_types: list[str],
        filter_workspace_id: str | None = None,
        filter_bounty_id: str | None = None,
    ) -> WebhookSubscription:
        body: dict[str, Any] = {"url": url, "eventTypes": event_types}
        if filter_workspace_id:
            body["filterWorkspaceId"] = filter_workspace_id
        if filter_bounty_id:
            body["filterBountyId"] = filter_bounty_id
        data = await self._post("/webhooks", body)
        return WebhookSubscription(**data["subscription"])

    async def list_webhooks(self) -> list[WebhookSubscription]:
        data = await self._get("/webhooks")
        return [WebhookSubscription(**s) for s in data["subscriptions"]]

    async def get_webhook(self, webhook_id: str) -> WebhookSubscription:
        data = await self._get(f"/webhooks/{webhook_id}")
        return WebhookSubscription(**data["subscription"])

    async def update_webhook(
        self,
        webhook_id: str,
        url: str | None = None,
        event_types: list[str] | None = None,
        filter_workspace_id: str | None = None,
        filter_bounty_id: str | None = None,
        is_active: bool | None = None,
    ) -> WebhookSubscription:
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if event_types is not None:
            body["eventTypes"] = event_types
        if filter_workspace_id is not None:
            body["filterWorkspaceId"] = filter_workspace_id
        if filter_bounty_id is not None:
            body["filterBountyId"] = filter_bounty_id
        if is_active is not None:
            body["isActive"] = is_active
        data = await self._put(f"/webhooks/{webhook_id}", body)
        return WebhookSubscription(**data["subscription"])

    async def delete_webhook(self, webhook_id: str) -> None:
        await self._delete(f"/webhooks/{webhook_id}")

    async def test_webhook(self, webhook_id: str) -> WebhookDelivery:
        data = await self._post(f"/webhooks/{webhook_id}/test", {})
        return WebhookDelivery(**data["delivery"])

    async def get_webhook_deliveries(
        self, webhook_id: str, limit: int | None = None,
    ) -> list[WebhookDelivery]:
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        data = await self._get(f"/webhooks/{webhook_id}/deliveries", params=params)
        return [WebhookDelivery(**d) for d in data["deliveries"]]

    # ────────────────────────────────────────────────────────────
    # Projects (Hosted Apps)
    # ────────────────────────────────────────────────────────────

    async def create_project(
        self,
        *,
        title: str,
        description: str,
        reward_amount: str,
        deadline: str,
        framework: str | None = None,
        visibility: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "title": title, "description": description,
            "rewardAmount": reward_amount, "deadline": deadline,
        }
        if framework:
            body["framework"] = framework
        if visibility:
            body["visibility"] = visibility
        return await self._post("/projects", body)

    async def create_edit_bounty(
        self,
        project_id: str,
        *,
        description: str,
        reward_amount: str,
        deadline: str,
    ) -> dict[str, Any]:
        return await self._post(f"/projects/{project_id}/bounties", {
            "description": description, "rewardAmount": reward_amount, "deadline": deadline,
        })

    async def get_project(self, project_id: str) -> Any:
        data = await self._get(f"/projects/{project_id}")
        return data["project"]

    async def get_project_by_slug(self, slug: str) -> Any:
        data = await self._get(f"/projects/slug/{slug}")
        return data["project"]

    async def get_project_by_bounty_id(self, bounty_id: str) -> Any:
        data = await self._get(f"/projects/bounty/{bounty_id}")
        return data["project"]

    async def list_projects(self, **kwargs: Any) -> dict[str, Any]:
        key_map = {
            "owner_wallet": "ownerWallet",
        }
        params = {key_map.get(k, k): v for k, v in kwargs.items() if v is not None}
        return await self._get("/projects", params=params)

    async def upload_artifact(
        self, project_id: str, artifact_type: str, file_data: bytes,
    ) -> Any:
        resp = await self._http.post(
            f"/projects/{project_id}/artifacts",
            files={"file": ("artifact", file_data)},
            data={"type": artifact_type},
        )
        return self._handle_response(resp)

    async def download_source(self, project_id: str) -> bytes:
        resp = await self._http.get(f"/projects/{project_id}/source")
        if resp.status_code >= 400:
            raise MarketplaceError(
                code="DOWNLOAD_FAILED",
                message=f"HTTP {resp.status_code}",
                status_code=resp.status_code,
            )
        return resp.content

    async def export_to_github(
        self, project_id: str, repo_name: str | None = None, is_private: bool | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if repo_name is not None:
            body["repoName"] = repo_name
        if is_private is not None:
            body["isPrivate"] = is_private
        return await self._post(f"/projects/{project_id}/export-github", body)

    async def get_deployments(self, project_id: str) -> list[Any]:
        data = await self._get(f"/projects/{project_id}/deployments")
        return data["deployments"]

    # ────────────────────────────────────────────────────────────
    # Cleanup
    # ────────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Clean up all resources."""
        self._heartbeats.stop_all()
        await self.events.disconnect()
        await self._http.aclose()

    async def __aenter__(self) -> MarketplaceClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ────────────────────────────────────────────────────────────
    # HTTP internals
    # ────────────────────────────────────────────────────────────

    def _build_signature_headers(self, method: str, path: str, body: Any = None) -> dict[str, str]:
        """Build Ed25519 signature headers for mutation requests.

        Message format: ``{timestamp}\\n{method}\\n{path}\\n{bodyHash}``
        """
        import json as _json

        timestamp = datetime.now(timezone.utc).isoformat()
        body_str = _json.dumps(body) if body else ""
        body_hash = hashlib.sha256(body_str.encode()).hexdigest()
        message = f"{timestamp}\n{method}\n{path}\n{body_hash}"

        sig_bytes = self._keypair.sign_message(message.encode())
        return {
            "X-Wallet-Signature": base64.b64encode(bytes(sig_bytes)).decode(),
            "X-Wallet-Timestamp": timestamp,
        }

    async def _post(self, path: str, body: Any) -> dict[str, Any]:
        sig_headers = self._build_signature_headers("POST", path, body)
        resp = await self._http.post(path, json=body, headers=sig_headers)
        return self._handle_response(resp)

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        resp = await self._http.get(path, params=params)
        return self._handle_response(resp)

    async def _put(self, path: str, body: Any) -> dict[str, Any]:
        sig_headers = self._build_signature_headers("PUT", path, body)
        resp = await self._http.put(path, json=body, headers=sig_headers)
        return self._handle_response(resp)

    async def _delete(self, path: str) -> dict[str, Any]:
        sig_headers = self._build_signature_headers("DELETE", path)
        resp = await self._http.delete(path, headers=sig_headers)
        return self._handle_response(resp)

    @staticmethod
    def _handle_response(resp: httpx.Response) -> dict[str, Any]:
        data = resp.json()
        if resp.status_code >= 400 or data.get("success") is False:
            error = data.get("error", {})
            raise MarketplaceError(
                code=error.get("code", "UNKNOWN_ERROR"),
                message=error.get("message", f"HTTP {resp.status_code}"),
                status_code=resp.status_code,
            )
        return data
