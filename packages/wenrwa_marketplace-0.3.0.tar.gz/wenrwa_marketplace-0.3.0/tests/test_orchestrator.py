"""Tests for ProjectOrchestrator, DAG validation, and decomposer."""

import json
import pytest

from wenrwa_marketplace.orchestrator import (
    BountySpec,
    ProjectOrchestrator,
    ProjectPhase,
    validate_dag,
    build_dag_edges,
    build_decomposition_prompt,
    parse_decomposition_response,
)


# ── DAG Validation ───────────────────────────────────────────────


class TestValidateDAG:
    def test_valid_dag(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A"),
            BountySpec(temp_id="b", title="B", description="B", blocked_by=["a"]),
            BountySpec(temp_id="c", title="C", description="C", blocked_by=["a", "b"]),
        ]
        validate_dag(specs)  # Should not raise

    def test_duplicate_temp_ids(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A"),
            BountySpec(temp_id="a", title="A2", description="A2"),
        ]
        with pytest.raises(ValueError, match="Duplicate tempId"):
            validate_dag(specs)

    def test_invalid_reference(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A", blocked_by=["nonexistent"]),
        ]
        with pytest.raises(ValueError, match="unknown dependency"):
            validate_dag(specs)

    def test_cycle_detection(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A", blocked_by=["b"]),
            BountySpec(temp_id="b", title="B", description="B", blocked_by=["a"]),
        ]
        with pytest.raises(ValueError, match="cycle"):
            validate_dag(specs)

    def test_self_reference_cycle(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A", blocked_by=["a"]),
        ]
        with pytest.raises(ValueError, match="cycle"):
            validate_dag(specs)

    def test_three_node_cycle(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A", blocked_by=["c"]),
            BountySpec(temp_id="b", title="B", description="B", blocked_by=["a"]),
            BountySpec(temp_id="c", title="C", description="C", blocked_by=["b"]),
        ]
        with pytest.raises(ValueError, match="cycle"):
            validate_dag(specs)


class TestBuildDAGEdges:
    def test_edges(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A"),
            BountySpec(temp_id="b", title="B", description="B", blocked_by=["a"]),
            BountySpec(temp_id="c", title="C", description="C", blocked_by=["a", "b"]),
        ]
        edges = build_dag_edges(specs)
        assert ("a", "b") in edges
        assert ("a", "c") in edges
        assert ("b", "c") in edges
        assert len(edges) == 3

    def test_no_dependencies(self):
        specs = [
            BountySpec(temp_id="a", title="A", description="A"),
            BountySpec(temp_id="b", title="B", description="B"),
        ]
        edges = build_dag_edges(specs)
        assert edges == []


# ── Decomposer ───────────────────────────────────────────────────


class TestBuildDecompositionPrompt:
    def test_includes_description(self):
        prompt = build_decomposition_prompt("Build an e-commerce app")
        assert "e-commerce app" in prompt

    def test_includes_constraints(self):
        prompt = build_decomposition_prompt(
            "Build an app",
            constraints=["Use TypeScript", "Use PostgreSQL"],
        )
        assert "TypeScript" in prompt
        assert "PostgreSQL" in prompt

    def test_includes_max_bounties(self):
        prompt = build_decomposition_prompt("Build an app", max_bounties=10)
        assert "10" in prompt


class TestParseDecompositionResponse:
    def test_valid_json(self):
        response = json.dumps(
            {
                "bounties": [
                    {
                        "tempId": "auth",
                        "title": "Build auth",
                        "description": "Implement JWT auth",
                        "category": "code",
                        "blockedBy": [],
                    },
                    {
                        "tempId": "api",
                        "title": "Build API",
                        "description": "REST endpoints",
                        "category": "api",
                        "blockedBy": ["auth"],
                    },
                ]
            }
        )
        specs = parse_decomposition_response(response)
        assert len(specs) == 2
        assert specs[0].temp_id == "auth"
        assert specs[1].blocked_by == ["auth"]

    def test_strips_markdown_fences(self):
        response = '```json\n{"bounties": [{"tempId": "a", "title": "A", "description": "A"}]}\n```'
        specs = parse_decomposition_response(response)
        assert len(specs) == 1

    def test_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            parse_decomposition_response("not json")

    def test_empty_bounties(self):
        with pytest.raises(ValueError, match="bounties"):
            parse_decomposition_response('{"bounties": []}')

    def test_rejects_cyclic_response(self):
        response = json.dumps(
            {
                "bounties": [
                    {"tempId": "a", "title": "A", "description": "A", "blockedBy": ["b"]},
                    {"tempId": "b", "title": "B", "description": "B", "blockedBy": ["a"]},
                ]
            }
        )
        with pytest.raises(ValueError, match="cycle"):
            parse_decomposition_response(response)


# ── ProjectOrchestrator.get_status ───────────────────────────────


class TestGetStatus:
    def test_status_counts(self):
        from wenrwa_marketplace.orchestrator import BountyState, Project

        bounties = {
            "b1": BountyState(
                spec=BountySpec(temp_id="a", title="A", description="A"),
                bounty_id="b1",
                status="completed",
            ),
            "b2": BountyState(
                spec=BountySpec(temp_id="b", title="B", description="B"),
                bounty_id="b2",
                status="assigned",
            ),
            "b3": BountyState(
                spec=BountySpec(temp_id="c", title="C", description="C"),
                bounty_id="b3",
                status="blocked",
            ),
            "b4": BountyState(
                spec=BountySpec(temp_id="d", title="D", description="D"),
                bounty_id="b4",
                status="open",
            ),
            "b5": BountyState(
                spec=BountySpec(temp_id="e", title="E", description="E"),
                bounty_id="b5",
                status="cancelled",
            ),
        }

        project = Project(
            id="ws-1",
            name="Test",
            workspace_id="ws-1",
            bounties=bounties,
            temp_id_to_id={},
            dag_nodes=[],
            dag_edges=[],
            estimated_total_cost_usd=100.0,
            estimated_duration_days=7,
        )

        # Create a minimal mock client
        class MockClient:
            wallet_pubkey = "test"

        orchestrator = ProjectOrchestrator.__new__(ProjectOrchestrator)
        orchestrator._phase = ProjectPhase.RUNNING
        orchestrator._started_at = 0

        status = orchestrator.get_status(project)

        assert status.total == 5
        assert status.completed == 1
        assert status.in_progress == 1
        assert status.blocked == 1
        assert status.open == 1
        assert status.failed == 1
