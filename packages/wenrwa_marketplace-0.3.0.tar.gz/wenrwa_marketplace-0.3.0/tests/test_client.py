"""Tests for the MarketplaceClient using mocked httpx."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch, MagicMock

import httpx
import pytest
import pytest_asyncio
from solders.keypair import Keypair

from wenrwa_marketplace.client import MarketplaceClient, MarketplaceError

API_URL = "http://localhost:3001/api/marketplace"
TEST_KEYPAIR = Keypair.from_seed(bytes([1] * 32))


def make_response(data: dict, status_code: int = 200) -> httpx.Response:
    """Create a mock httpx.Response."""
    body = {"success": status_code < 400, **data}
    return httpx.Response(
        status_code=status_code,
        json=body,
        request=httpx.Request("GET", "http://test"),
    )


def make_error_response(code: str, message: str, status_code: int = 400) -> httpx.Response:
    return httpx.Response(
        status_code=status_code,
        json={"success": False, "error": {"code": code, "message": message}},
        request=httpx.Request("GET", "http://test"),
    )


@pytest.fixture
def mock_http():
    """Patch httpx.AsyncClient methods."""
    with patch.object(httpx.AsyncClient, "post", new_callable=AsyncMock) as mock_post, \
         patch.object(httpx.AsyncClient, "get", new_callable=AsyncMock) as mock_get, \
         patch.object(httpx.AsyncClient, "put", new_callable=AsyncMock) as mock_put, \
         patch.object(httpx.AsyncClient, "delete", new_callable=AsyncMock) as mock_delete:
        yield {"post": mock_post, "get": mock_get, "put": mock_put, "delete": mock_delete}


@pytest.fixture
def client(mock_http):
    return MarketplaceClient(api_url=API_URL, keypair=TEST_KEYPAIR)


# ────────────────────────────────────────────────────────────
# Constructor & properties
# ────────────────────────────────────────────────────────────


class TestConstructor:
    def test_wallet_pubkey(self, client):
        assert client.wallet_pubkey == str(TEST_KEYPAIR.pubkey())

    def test_has_events(self, client):
        assert client.events is not None


# ────────────────────────────────────────────────────────────
# HTTP error handling
# ────────────────────────────────────────────────────────────


class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_raises_marketplace_error(self, client, mock_http):
        mock_http["get"].return_value = make_error_response("NOT_FOUND", "Bounty not found", 404)

        with pytest.raises(MarketplaceError) as exc:
            await client.get_bounty("nonexistent")

        assert exc.value.code == "NOT_FOUND"
        assert exc.value.status_code == 404
        assert "Bounty not found" in str(exc.value)


# ────────────────────────────────────────────────────────────
# Bounty lifecycle
# ────────────────────────────────────────────────────────────


MOCK_BOUNTY = {
    "id": "b-1", "title": "Test Bounty", "status": "open",
    "poster_wallet": "w1", "reward_amount": "1000000000",
}


class TestBountyLifecycle:
    @pytest.mark.asyncio
    async def test_create_bounty_without_unsigned_tx(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bounty": MOCK_BOUNTY})

        result = await client.create_bounty(
            title="Test Bounty", category="code",
            task_schema={"description": "Do something"},
            reward_amount="1000000000",
            reward_mint="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
            reward_symbol="USDC", deadline="2025-12-31T00:00:00Z",
        )

        assert result["bounty"].id == "b-1"
        assert "tx_signature" not in result
        mock_http["post"].assert_called_once()

    @pytest.mark.asyncio
    async def test_get_bounty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"bounty": MOCK_BOUNTY})
        bounty = await client.get_bounty("b-1")
        assert bounty.id == "b-1"
        assert bounty.title == "Test Bounty"

    @pytest.mark.asyncio
    async def test_list_bounties(self, client, mock_http):
        mock_http["get"].return_value = make_response({"bounties": [MOCK_BOUNTY], "total": 1})
        result = await client.list_bounties(status="open", limit=10)
        assert len(result["bounties"]) == 1
        assert result["total"] == 1

    @pytest.mark.asyncio
    async def test_list_bounties_empty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"bounties": [], "total": 0})
        result = await client.list_bounties()
        assert result["bounties"] == []

    @pytest.mark.asyncio
    async def test_bid(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "bid": {"id": "bid-1", "bounty_id": "b-1", "agent_wallet": "w1", "bid_amount": "500000000"},
        })
        bid = await client.bid("b-1", "500000000", message="I can do it")
        assert bid.id == "bid-1"
        assert bid.bid_amount == "500000000"

    @pytest.mark.asyncio
    async def test_accept_bid(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        await client.accept_bid("b-1", "bid-1")
        call_kwargs = mock_http["post"].call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["bidId"] == "bid-1"

    @pytest.mark.asyncio
    async def test_submit_work(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bounty": {**MOCK_BOUNTY, "status": "submitted"}})
        bounty = await client.submit_work("b-1", "abc123")
        assert bounty.status == "submitted"

    @pytest.mark.asyncio
    async def test_approve_work(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bounty": {**MOCK_BOUNTY, "status": "completed"}})
        bounty = await client.approve_work("b-1")
        assert bounty.status == "completed"

    @pytest.mark.asyncio
    async def test_dispute_work(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bounty": {**MOCK_BOUNTY, "status": "disputed"}})
        bounty = await client.dispute_work("b-1", "Bad quality")
        assert bounty.status == "disputed"

    @pytest.mark.asyncio
    async def test_cancel_bounty(self, client, mock_http):
        mock_http["delete"].return_value = make_response({"bounty": {**MOCK_BOUNTY, "status": "cancelled"}})
        bounty = await client.cancel_bounty("b-1")
        assert bounty.status == "cancelled"
        mock_http["delete"].assert_called_once()

    @pytest.mark.asyncio
    async def test_reassign_bounty(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bounty": {**MOCK_BOUNTY, "status": "open", "assignee_wallet": None}})
        bounty = await client.reassign_bounty("b-1")
        assert bounty.status == "open"


# ────────────────────────────────────────────────────────────
# Registration
# ────────────────────────────────────────────────────────────


class TestRegistration:
    @pytest.mark.asyncio
    async def test_register_agent(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "agent": {"wallet_pubkey": "w1", "name": "Agent1", "capabilities": ["code"],
                      "reputation_score": 5000, "weighted_reputation": 0},
        })
        result = await client.register_agent("Agent1", ["code"])
        assert result["agent"].name == "Agent1"
        assert "tx_signature" not in result

    @pytest.mark.asyncio
    async def test_register_poster(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        result = await client.register_poster()
        assert "tx_signature" not in result


# ────────────────────────────────────────────────────────────
# Workspaces
# ────────────────────────────────────────────────────────────


MOCK_WORKSPACE = {"id": "ws-1", "name": "Test Workspace", "mode": "open", "owner_wallet": "w1"}


class TestWorkspaces:
    @pytest.mark.asyncio
    async def test_create_workspace(self, client, mock_http):
        mock_http["post"].return_value = make_response({"workspace": MOCK_WORKSPACE})
        ws = await client.create_workspace(name="Test Workspace")
        assert ws.id == "ws-1"

    @pytest.mark.asyncio
    async def test_get_workspace(self, client, mock_http):
        mock_http["get"].return_value = make_response({"workspace": MOCK_WORKSPACE})
        ws = await client.get_workspace("ws-1")
        assert ws.name == "Test Workspace"

    @pytest.mark.asyncio
    async def test_list_workspaces(self, client, mock_http):
        mock_http["get"].return_value = make_response({"workspaces": [MOCK_WORKSPACE]})
        workspaces = await client.list_workspaces()
        assert len(workspaces) == 1

    @pytest.mark.asyncio
    async def test_add_agent(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        await client.add_agent("ws-1", "agent-wallet")
        mock_http["post"].assert_called_once()

    @pytest.mark.asyncio
    async def test_write_context(self, client, mock_http):
        mock_http["post"].return_value = make_response({"context": {}})
        await client.write_context("ws-1", "my-key", {"data": "test"})
        call_kwargs = mock_http["post"].call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["key"] == "my-key"

    @pytest.mark.asyncio
    async def test_read_context(self, client, mock_http):
        mock_http["get"].return_value = make_response({"context": {"key": "my-key", "content": {"data": "test"}}})
        ctx = await client.read_context("ws-1", "my-key")
        assert ctx["key"] == "my-key"

    @pytest.mark.asyncio
    async def test_list_context_keys(self, client, mock_http):
        mock_http["get"].return_value = make_response({"contexts": [{"key": "k1"}, {"key": "k2"}]})
        keys = await client.list_context_keys("ws-1")
        assert len(keys) == 2


# ────────────────────────────────────────────────────────────
# Treasury
# ────────────────────────────────────────────────────────────


class TestTreasury:
    @pytest.mark.asyncio
    async def test_fund_treasury(self, client, mock_http):
        mock_http["post"].return_value = make_response({"entry": {"id": "e-1", "direction": "fund"}})
        entry = await client.fund_treasury("ws-1", "1000000000", "tx-sig-123")
        assert entry["id"] == "e-1"

    @pytest.mark.asyncio
    async def test_fund_agents(self, client, mock_http):
        mock_http["post"].return_value = make_response({"entries": [{"id": "e-1"}]})
        entries = await client.fund_agents("ws-1", [
            {"agent_wallet": "a1", "amount_usdc": "500000000"},
        ])
        assert len(entries) == 1

    @pytest.mark.asyncio
    async def test_reclaim_from_agents(self, client, mock_http):
        mock_http["post"].return_value = make_response({"entry": {"id": "e-2", "direction": "reclaim"}})
        entry = await client.reclaim_from_agents("ws-1", "a1", "250000000")
        assert entry["direction"] == "reclaim"

    @pytest.mark.asyncio
    async def test_drain_treasury(self, client, mock_http):
        mock_http["post"].return_value = make_response({"entry": {"id": "e-3", "direction": "drain"}})
        entry = await client.drain_treasury("ws-1")
        assert entry["direction"] == "drain"

    @pytest.mark.asyncio
    async def test_get_treasury_ledger(self, client, mock_http):
        mock_http["get"].return_value = make_response({"entries": [{"id": "e-1"}, {"id": "e-2"}]})
        ledger = await client.get_treasury_ledger("ws-1")
        assert len(ledger) == 2


# ────────────────────────────────────────────────────────────
# Heartbeat & Progress
# ────────────────────────────────────────────────────────────


class TestHeartbeatProgress:
    @pytest.mark.asyncio
    async def test_send_heartbeat(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        await client.send_heartbeat("b-1")
        mock_http["post"].assert_called_once()

    @pytest.mark.asyncio
    async def test_send_heartbeat_with_metadata(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        await client.send_heartbeat("b-1", metadata={"cpu": 42})
        call_kwargs = mock_http["post"].call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["metadata"] == {"cpu": 42}

    @pytest.mark.asyncio
    async def test_report_progress(self, client, mock_http):
        mock_http["post"].return_value = make_response({"progress": {"id": "p-1", "percentage": 50}})
        progress = await client.report_progress("b-1", 50, message="Halfway")
        assert progress["id"] == "p-1"

    @pytest.mark.asyncio
    async def test_get_progress(self, client, mock_http):
        mock_http["get"].return_value = make_response({"progress": [{"id": "p-1"}, {"id": "p-2"}]})
        progress = await client.get_progress("b-1")
        assert len(progress) == 2


# ────────────────────────────────────────────────────────────
# Messaging
# ────────────────────────────────────────────────────────────


class TestMessaging:
    @pytest.mark.asyncio
    async def test_send_message(self, client, mock_http):
        mock_http["post"].return_value = make_response({"message": {"id": "msg-1", "content": "Hello"}})
        msg = await client.send_message("b-1", "Hello", message_type="info")
        assert msg["id"] == "msg-1"

    @pytest.mark.asyncio
    async def test_get_messages(self, client, mock_http):
        mock_http["get"].return_value = make_response({"messages": [{"id": "msg-1"}]})
        msgs = await client.get_messages("b-1", limit=5)
        assert len(msgs) == 1

    @pytest.mark.asyncio
    async def test_get_messages_empty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"messages": []})
        msgs = await client.get_messages("b-1")
        assert msgs == []


# ────────────────────────────────────────────────────────────
# Verification
# ────────────────────────────────────────────────────────────


class TestVerification:
    @pytest.mark.asyncio
    async def test_verify(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "results": [{"strategy": "schema", "passed": True}], "allPassed": True,
        })
        res = await client.verify("b-1")
        assert res["all_passed"] is True
        assert len(res["results"]) == 1

    @pytest.mark.asyncio
    async def test_get_verification_results(self, client, mock_http):
        mock_http["get"].return_value = make_response({"results": [{"strategy": "schema"}]})
        results = await client.get_verification_results("b-1")
        assert len(results) == 1


# ────────────────────────────────────────────────────────────
# Batch creation
# ────────────────────────────────────────────────────────────


class TestBatchCreation:
    @pytest.mark.asyncio
    async def test_create_bounty_batch(self, client, mock_http):
        mock_http["post"].return_value = make_response({"bountyIds": ["b-1", "b-2", "b-3"]})
        ids = await client.create_bounty_batch("ws-1", [
            {"title": "Task 1"}, {"title": "Task 2"}, {"title": "Task 3"},
        ])
        assert ids == ["b-1", "b-2", "b-3"]


# ────────────────────────────────────────────────────────────
# Reputation & Ratings
# ────────────────────────────────────────────────────────────


class TestReputation:
    @pytest.mark.asyncio
    async def test_rate_agent(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "rating": {"id": "r-1", "bounty_id": "b-1", "quality_score": 5,
                       "speed_score": 4, "communication_score": 5},
        })
        rating = await client.rate_agent("b-1", 5, 4, 5, review_text="Great!")
        assert rating.quality_score == 5

    @pytest.mark.asyncio
    async def test_get_agent_ratings(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "ratings": [{"id": "r-1", "bounty_id": "b-1", "quality_score": 5,
                         "speed_score": 4, "communication_score": 5}],
            "total": 1,
        })
        result = await client.get_agent_ratings("w1", limit=10)
        assert len(result["ratings"]) == 1
        assert result["total"] == 1

    @pytest.mark.asyncio
    async def test_get_capability_scores(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "capabilities": [{"capability": "code", "weighted_score": 4.2, "completed_count": 10}],
        })
        scores = await client.get_capability_scores("w1")
        assert len(scores) == 1
        assert scores[0].capability == "code"


# ────────────────────────────────────────────────────────────
# Matching
# ────────────────────────────────────────────────────────────


class TestMatching:
    @pytest.mark.asyncio
    async def test_get_recommended_agents(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "agents": [
                {"wallet_pubkey": "a1", "match_score": 0.95, "weighted_reputation": 4.2},
                {"wallet_pubkey": "a2", "match_score": 0.80, "weighted_reputation": 3.8},
            ],
        })
        agents = await client.get_recommended_agents(["code"], limit=5)
        assert len(agents) == 2
        assert agents[0].match_score == 0.95

    @pytest.mark.asyncio
    async def test_add_preferred_agent(self, client, mock_http):
        mock_http["post"].return_value = make_response({})
        await client.add_preferred_agent("agent-wallet", note="Good agent")
        call_kwargs = mock_http["post"].call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["agentWallet"] == "agent-wallet"

    @pytest.mark.asyncio
    async def test_remove_preferred_agent(self, client, mock_http):
        mock_http["delete"].return_value = make_response({})
        await client.remove_preferred_agent("agent-wallet")
        mock_http["delete"].assert_called_once()

    @pytest.mark.asyncio
    async def test_get_preferred_agents(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "agents": [{"agent_wallet": "a1", "note": "Great", "success_count": 5, "avg_rating": 4.5}],
        })
        agents = await client.get_preferred_agents()
        assert len(agents) == 1
        assert agents[0].avg_rating == 4.5


# ────────────────────────────────────────────────────────────
# Public read-only
# ────────────────────────────────────────────────────────────


class TestNewAgentsPostersMethods:
    @pytest.mark.asyncio
    async def test_list_agents(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "agents": [
                {"wallet_pubkey": "a1", "capabilities": [], "reputation_score": 5000, "weighted_reputation": 4.0},
            ],
            "total": 1,
        })
        result = await client.list_agents(sort_by="reputation", limit=10)
        assert len(result["agents"]) == 1
        assert result["total"] == 1

    @pytest.mark.asyncio
    async def test_list_agents_empty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"agents": [], "total": 0})
        result = await client.list_agents()
        assert result["agents"] == []

    @pytest.mark.asyncio
    async def test_get_agent_stats(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "stats": {"total_bounties": 10, "completed_bounties": 8, "failed_bounties": 2,
                       "total_earnings": "5000", "avg_rating": 4.5},
        })
        stats = await client.get_agent_stats("w1")
        assert stats.total_bounties == 10
        assert stats.avg_rating == 4.5

    @pytest.mark.asyncio
    async def test_get_poster(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "poster": {"wallet_pubkey": "p1", "bounties_created": 5, "total_spent": "1000"},
        })
        poster = await client.get_poster("p1")
        assert poster.wallet_pubkey == "p1"
        assert poster.bounties_created == 5


class TestWorkspaceBounties:
    @pytest.mark.asyncio
    async def test_get_workspace_bounties(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "bounties": [MOCK_BOUNTY], "total": 1,
        })
        result = await client.get_workspace_bounties("ws-1")
        assert len(result["bounties"]) == 1
        assert result["total"] == 1


class TestRepoAccess:
    @pytest.mark.asyncio
    async def test_get_repo_access(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "repo_url": "https://github.com/org/repo",
            "access_token": "ghs_xxx",
            "expires_at": "2026-01-01T00:00:00Z",
            "clone_url": "https://x-access-token:ghs_xxx@github.com/org/repo.git",
            "permissions": ["contents:read"],
        })
        access = await client.get_repo_access("b-1")
        assert access.repo_url == "https://github.com/org/repo"
        assert access.access_token == "ghs_xxx"
        assert "contents:read" in access.permissions


MOCK_API_KEY_RECORD = {
    "id": "k-1", "key_prefix": "wm_sk_abc1", "wallet_pubkey": "w1",
    "permissions": ["read", "write"], "rate_limit_per_minute": 60,
    "is_active": True, "total_requests": 0,
}


class TestApiKeyManagement:
    @pytest.mark.asyncio
    async def test_generate_api_key(self, client, mock_http):
        mock_http["post"].return_value = make_response({
            "key": "wm_sk_abc123", "keyRecord": MOCK_API_KEY_RECORD,
        })
        result = await client.generate_api_key("my-key")
        assert result["key"] == "wm_sk_abc123"
        assert result["key_record"].id == "k-1"

    @pytest.mark.asyncio
    async def test_list_api_keys(self, client, mock_http):
        mock_http["get"].return_value = make_response({"keys": [MOCK_API_KEY_RECORD]})
        keys = await client.list_api_keys()
        assert len(keys) == 1
        assert keys[0].id == "k-1"

    @pytest.mark.asyncio
    async def test_revoke_api_key(self, client, mock_http):
        mock_http["delete"].return_value = make_response({})
        await client.revoke_api_key("k-1")
        mock_http["delete"].assert_called_once()


class TestPublicReadOnly:
    @pytest.mark.asyncio
    async def test_get_agent(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "agent": {"wallet_pubkey": "w1", "name": "Agent1", "capabilities": ["code"],
                      "reputation_score": 5000, "weighted_reputation": 4.0},
        })
        agent = await client.get_agent("w1")
        assert agent.wallet_pubkey == "w1"
        assert "code" in agent.capabilities

    @pytest.mark.asyncio
    async def test_get_leaderboard(self, client, mock_http):
        mock_http["get"].return_value = make_response({
            "agents": [
                {"wallet_pubkey": "a1", "capabilities": []},
                {"wallet_pubkey": "a2", "capabilities": []},
            ],
        })
        agents = await client.get_leaderboard(sort_by="reputation", limit=10)
        assert len(agents) == 2

    @pytest.mark.asyncio
    async def test_get_leaderboard_empty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"agents": []})
        agents = await client.get_leaderboard()
        assert agents == []


# ────────────────────────────────────────────────────────────
# Webhooks
# ────────────────────────────────────────────────────────────

MOCK_WEBHOOK_SUB = {
    "id": "wh-1", "owner_wallet": "w1", "url": "https://example.com/hook",
    "secret": "wh_sec_abc123", "event_types": ["bounty:created"],
    "is_active": True, "consecutive_failures": 0,
}

MOCK_WEBHOOK_DELIVERY = {
    "id": "del-1", "subscription_id": "wh-1", "event_id": "evt-1",
    "event_type": "bounty:created", "attempt": 1, "status": "success",
    "http_status": 200,
}


class TestWebhooks:
    @pytest.mark.asyncio
    async def test_create_webhook(self, client, mock_http):
        mock_http["post"].return_value = make_response({"subscription": MOCK_WEBHOOK_SUB})
        sub = await client.create_webhook("https://example.com/hook", ["bounty:created"])
        assert sub.id == "wh-1"
        assert sub.secret == "wh_sec_abc123"
        assert sub.event_types == ["bounty:created"]

    @pytest.mark.asyncio
    async def test_list_webhooks(self, client, mock_http):
        mock_http["get"].return_value = make_response({"subscriptions": [MOCK_WEBHOOK_SUB]})
        subs = await client.list_webhooks()
        assert len(subs) == 1
        assert subs[0].url == "https://example.com/hook"

    @pytest.mark.asyncio
    async def test_get_webhook(self, client, mock_http):
        mock_http["get"].return_value = make_response({"subscription": MOCK_WEBHOOK_SUB})
        sub = await client.get_webhook("wh-1")
        assert sub.id == "wh-1"

    @pytest.mark.asyncio
    async def test_update_webhook(self, client, mock_http):
        updated = {**MOCK_WEBHOOK_SUB, "url": "https://new.example.com/hook"}
        mock_http["put"].return_value = make_response({"subscription": updated})
        sub = await client.update_webhook("wh-1", url="https://new.example.com/hook")
        assert sub.url == "https://new.example.com/hook"
        mock_http["put"].assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_webhook(self, client, mock_http):
        mock_http["delete"].return_value = make_response({})
        await client.delete_webhook("wh-1")
        mock_http["delete"].assert_called_once()

    @pytest.mark.asyncio
    async def test_test_webhook(self, client, mock_http):
        mock_http["post"].return_value = make_response({"delivery": MOCK_WEBHOOK_DELIVERY})
        delivery = await client.test_webhook("wh-1")
        assert delivery.status == "success"
        assert delivery.http_status == 200

    @pytest.mark.asyncio
    async def test_get_webhook_deliveries(self, client, mock_http):
        mock_http["get"].return_value = make_response({"deliveries": [MOCK_WEBHOOK_DELIVERY]})
        deliveries = await client.get_webhook_deliveries("wh-1", limit=10)
        assert len(deliveries) == 1
        assert deliveries[0].event_type == "bounty:created"

    @pytest.mark.asyncio
    async def test_list_webhooks_empty(self, client, mock_http):
        mock_http["get"].return_value = make_response({"subscriptions": []})
        subs = await client.list_webhooks()
        assert subs == []
