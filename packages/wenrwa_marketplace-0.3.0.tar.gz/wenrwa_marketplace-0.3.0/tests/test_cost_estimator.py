"""Tests for CostEstimator."""

import pytest

from wenrwa_marketplace.cost_estimator import (
    CostEstimator,
    CostEstimate,
    MODEL_PRICING,
    TASK_COMPLEXITY,
    TASK_CATEGORIES,
    TaskCategoryConfig,
    TokenConfig,
    DEFAULT_TOKENS,
)


@pytest.fixture
def estimator():
    return CostEstimator(default_model="claude-opus-4", market_markup_pct=150)


# ── Constants ──────────────────────────────────────────────────


class TestModelPricing:
    def test_major_models(self):
        assert MODEL_PRICING["claude-opus-4"] == 20.0
        assert MODEL_PRICING["claude-sonnet-4"] == 4.0
        assert MODEL_PRICING["gpt-4o"] == 6.0
        assert MODEL_PRICING["gemini-2.0-pro"] == 5.0


class TestTaskComplexity:
    def test_all_categories(self):
        assert TASK_COMPLEXITY["code"] == 50_000
        assert TASK_COMPLEXITY["research"] == 100_000
        assert TASK_COMPLEXITY["data"] == 30_000
        assert TASK_COMPLEXITY["api"] == 40_000
        assert TASK_COMPLEXITY["generic"] == 25_000

    def test_derived_from_categories(self):
        assert TASK_COMPLEXITY["code"] == TASK_CATEGORIES["code"].base_tokens
        assert TASK_COMPLEXITY["video"] == 0  # fixed-cost has no base_tokens


class TestTaskCategories:
    def test_total_count(self):
        names = list(TASK_CATEGORIES.keys())
        assert len(names) == 24  # 19 token + 4 fixed + generic

    def test_has_expected_categories(self):
        assert "code" in TASK_CATEGORIES
        assert "video" in TASK_CATEGORIES
        assert "image-generation" in TASK_CATEGORIES
        assert "generic" in TASK_CATEGORIES

    def test_token_and_fixed_models(self):
        assert TASK_CATEGORIES["code"].cost_model == "token"
        assert TASK_CATEGORIES["video"].cost_model == "fixed"
        assert TASK_CATEGORIES["image-generation"].cost_model == "fixed"
        assert TASK_CATEGORIES["audio"].cost_model == "fixed"
        assert TASK_CATEGORIES["design"].cost_model == "fixed"


class TestDefaultTokens:
    def test_usdc(self):
        assert DEFAULT_TOKENS["USDC"].decimals == 6
        assert DEFAULT_TOKENS["USDC"].price_usd == 1.0

    def test_sol_no_default_price(self):
        assert DEFAULT_TOKENS["SOL"].decimals == 9
        assert DEFAULT_TOKENS["SOL"].price_usd is None


# ── estimate() ──────────────────────────────────────────────────


class TestEstimate:
    @pytest.mark.asyncio
    async def test_complete_estimate(self, estimator):
        result = await estimator.estimate(
            {"type": "code", "taskDescription": "Write a function to sort an array"},
            reward_symbol="USDC",
        )
        assert isinstance(result, CostEstimate)
        assert result.estimated_tokens > 0
        assert result.base_cost_usd > 0
        assert result.token_cost_usd > 0  # backwards compat alias
        assert result.suggested_reward_usd > 0
        assert result.suggested_reward_amount
        assert result.reward_token_price_usd == 1.0
        assert result.confidence > 0
        assert result.model == "claude-opus-4"
        assert result.category == "code"
        assert result.cost_model == "token"
        assert result.warnings == []

    @pytest.mark.asyncio
    async def test_category_from_schema_type(self, estimator):
        result = await estimator.estimate(
            {"type": "research", "description": "Analyze market trends"},
        )
        assert result.category == "research"
        assert result.estimated_tokens >= 50_000

    @pytest.mark.asyncio
    async def test_explicit_category_override(self, estimator):
        result = await estimator.estimate(
            {"description": "Do something"},
            category="data",
        )
        assert result.category == "data"

    @pytest.mark.asyncio
    async def test_keyword_detection_testing(self, estimator):
        result = await estimator.estimate(
            {"description": "Write unit tests for the auth module"},
        )
        assert result.category == "testing"

    @pytest.mark.asyncio
    async def test_keyword_detection_security(self, estimator):
        result = await estimator.estimate(
            {"description": "Perform a security audit of the smart contract"},
        )
        assert result.category == "security-audit"

    @pytest.mark.asyncio
    async def test_model_override(self, estimator):
        gpt_result = await estimator.estimate(
            {"type": "code", "description": "Fix a bug"},
            model="gpt-4o",
        )
        opus_result = await estimator.estimate(
            {"type": "code", "description": "Fix a bug"},
            model="claude-opus-4",
        )
        assert gpt_result.model == "gpt-4o"
        assert gpt_result.base_cost_usd < opus_result.base_cost_usd

    @pytest.mark.asyncio
    async def test_usdc_reward_amounts(self, estimator):
        result = await estimator.estimate(
            {"type": "code", "description": "Simple task"},
            reward_symbol="USDC",
        )
        expected = round(result.suggested_reward_usd * 1_000_000)
        assert int(result.suggested_reward_amount) == expected
        assert result.reward_token_price_usd == 1.0

    @pytest.mark.asyncio
    async def test_unknown_token_without_price_warns(self, estimator):
        result = await estimator.estimate(
            {"type": "code", "description": "Simple task"},
            reward_symbol="UNKNOWN",
        )
        assert len(result.warnings) >= 1
        assert any("No USD price configured for UNKNOWN" in w for w in result.warnings)
        # Falls back to $1/token
        assert result.reward_token_price_usd == 1.0
        # Defaults to 6 decimals for unknown tokens
        expected = round(result.suggested_reward_usd * 1_000_000)
        assert int(result.suggested_reward_amount) == expected

    @pytest.mark.asyncio
    async def test_sol_with_explicit_price(self):
        est = CostEstimator(
            default_model="claude-opus-4",
            custom_tokens={"SOL": TokenConfig(decimals=9, price_usd=150.0)},
        )
        result = await est.estimate(
            {"type": "code", "description": "Simple task"},
            reward_symbol="SOL",
        )
        assert result.reward_token_price_usd == 150.0
        assert result.warnings == []
        # Reward in SOL should be much smaller in whole-token terms
        reward_in_sol = result.suggested_reward_usd / 150.0
        expected = round(reward_in_sol * 1_000_000_000)
        assert int(result.suggested_reward_amount) == expected

    @pytest.mark.asyncio
    async def test_custom_token(self):
        est = CostEstimator(
            default_model="claude-sonnet-4",
            custom_tokens={"WEN": TokenConfig(decimals=9, price_usd=0.01)},
        )
        result = await est.estimate(
            {"type": "generic", "description": "Task"},
            reward_symbol="WEN",
        )
        assert result.reward_token_price_usd == 0.01
        assert result.warnings == []

    @pytest.mark.asyncio
    async def test_unknown_token_warns(self, estimator):
        result = await estimator.estimate(
            {"type": "generic", "description": "Task"},
            reward_symbol="BONK",
        )
        assert len(result.warnings) >= 1
        assert any("BONK" in w for w in result.warnings)
        assert result.reward_token_price_usd == 1.0

    @pytest.mark.asyncio
    async def test_markup(self, estimator):
        result = await estimator.estimate(
            {"type": "generic", "description": "Task"},
        )
        expected = round(result.base_cost_usd * 2.5, 2)
        assert result.suggested_reward_usd == expected

    @pytest.mark.asyncio
    async def test_complex_more_tokens(self, estimator):
        simple = await estimator.estimate(
            {"type": "code", "description": "Fix a typo"},
        )
        complex_ = await estimator.estimate(
            {
                "type": "code",
                "description": "Comprehensive refactoring of multiple concurrent Anchor programs on Solana blockchain",
            },
        )
        assert complex_.estimated_tokens > simple.estimated_tokens

    @pytest.mark.asyncio
    async def test_longer_description_factor(self, estimator):
        short = await estimator.estimate(
            {"type": "code", "description": "Fix bug"},
        )
        long_desc = "A" * 3000
        long_ = await estimator.estimate(
            {"type": "code", "description": long_desc},
        )
        assert (
            long_.breakdown.description_length_factor
            > short.breakdown.description_length_factor
        )

    @pytest.mark.asyncio
    async def test_higher_confidence_with_more_fields(self, estimator):
        sparse = await estimator.estimate(
            {"description": "Do something"},
        )
        rich = await estimator.estimate(
            {
                "type": "code",
                "description": "Implement feature",
                "taskDescription": "Detailed description",
                "language": "typescript",
                "repoUrl": "https://github.com/example/repo",
                "testCommand": "npm test",
            },
        )
        assert rich.confidence > sparse.confidence

    @pytest.mark.asyncio
    async def test_confidence_capped_at_95(self, estimator):
        result = await estimator.estimate(
            {
                "type": "code",
                "category": "code",
                "description": "Full details",
                "taskDescription": "Even more details",
                "language": "typescript",
                "extra1": "a",
                "extra2": "b",
                "extra3": "c",
            },
        )
        assert result.confidence <= 95

    @pytest.mark.asyncio
    async def test_token_cost_usd_backwards_compat(self, estimator):
        result = await estimator.estimate(
            {"type": "code", "description": "Task"},
        )
        assert result.token_cost_usd == result.base_cost_usd


# ── New Category Detection ──────────────────────────────────────


class TestNewCategoryDetection:
    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "description,expected_category",
        [
            ("Create a blog post about AI", "content-writing"),
            ("Translate this document to Spanish", "translation"),
            ("Summarize this long document into a short digest", "summarization"),
            ("Create a pitch deck presentation", "presentation"),
            ("Generate a product logo", "image-generation"),
            ("Create a 30-second promotional video clip", "video"),
            ("Record a podcast audio intro", "audio"),
            ("Create a wireframe mockup in Figma", "design"),
            ("Review this contract for legal compliance", "legal"),
            ("Create a financial revenue forecast for Q3", "finance"),
            ("Create a marketing campaign for launch", "marketing"),
            ("Develop a course curriculum on TypeScript", "education"),
            ("Build a customer support FAQ chatbot", "customer-support"),
            ("Prove this math equation", "math-science"),
            ("Write a short story about a robot", "creative-writing"),
        ],
    )
    async def test_category_detection(self, estimator, description, expected_category):
        result = await estimator.estimate({"description": description})
        assert result.category == expected_category


# ── Fixed-Cost Model ──────────────────────────────────────────


class TestFixedCostModel:
    @pytest.mark.asyncio
    async def test_video_returns_fixed_model(self, estimator):
        result = await estimator.estimate(
            {"type": "video", "description": "Create a short clip"},
        )
        assert result.cost_model == "fixed"
        assert result.estimated_tokens == 0
        assert result.base_cost_usd > 0
        assert result.suggested_reward_usd > 0
        assert result.category == "video"

    @pytest.mark.asyncio
    async def test_code_returns_token_model(self, estimator):
        result = await estimator.estimate(
            {"type": "code", "description": "Fix a bug"},
        )
        assert result.cost_model == "token"
        assert result.estimated_tokens > 0

    @pytest.mark.asyncio
    async def test_fixed_cost_warning(self, estimator):
        result = await estimator.estimate(
            {"type": "video", "description": "Create a clip"},
        )
        assert any("fixed-cost estimation" in w for w in result.warnings)

    @pytest.mark.asyncio
    async def test_complexity_multipliers_on_fixed(self, estimator):
        simple = await estimator.estimate(
            {"type": "video", "description": "Short clip"},
        )
        complex_ = await estimator.estimate(
            {
                "type": "video",
                "description": "A batch of multiple HD professional video clips in a series",
            },
        )
        assert complex_.base_cost_usd > simple.base_cost_usd

    @pytest.mark.asyncio
    async def test_synthetic_token_count_for_fixed(self, estimator):
        tokens = estimator.estimate_token_usage(
            {"type": "video", "description": "Create a video"},
        )
        assert tokens > 0


# ── list_categories() ──────────────────────────────────────────


class TestListCategories:
    def test_excludes_generic(self, estimator):
        cats = estimator.list_categories()
        assert len(cats) == 23  # 24 total - generic
        names = [c["name"] for c in cats]
        assert "generic" not in names
        assert "code" in names
        assert "video" in names

    def test_includes_cost_model_info(self, estimator):
        cats = estimator.list_categories()
        video = next(c for c in cats if c["name"] == "video")
        assert video["cost_model"] == "fixed"
        assert video["base_cost_usd"] == 5.0
        assert video["base_tokens"] == 0

        code = next(c for c in cats if c["name"] == "code")
        assert code["cost_model"] == "token"
        assert code["base_tokens"] == 50_000


# ── customCategories ──────────────────────────────────────────


class TestCustomCategories:
    @pytest.mark.asyncio
    async def test_add_new_category(self):
        custom = CostEstimator(
            custom_categories={
                "3d-modeling": {
                    "cost_model": "fixed",
                    "base_tokens": 0,
                    "base_cost_usd": 10.0,
                    "keywords": ["3d model", "blender", "render scene"],
                },
            },
        )
        result = await custom.estimate(
            {"description": "Create a 3d model of a house"},
        )
        assert result.category == "3d-modeling"
        assert result.cost_model == "fixed"

    @pytest.mark.asyncio
    async def test_override_builtin_base_cost(self):
        custom = CostEstimator(
            custom_categories={
                "video": {"base_cost_usd": 20.0},
            },
        )
        result = await custom.estimate(
            {"type": "video", "description": "Create a clip"},
        )
        assert result.breakdown.base_cost_usd == 20.0


# ── advisePricing() ──────────────────────────────────────────


class TestAdvisePricing:
    @pytest.mark.asyncio
    async def test_formatted_advice(self, estimator):
        advice = await estimator.advise_pricing(
            {"type": "code", "taskDescription": "Add unit tests for auth"},
            reward_symbol="USDC",
        )
        assert "Category:" in advice
        assert "Model:" in advice
        assert "Estimated tokens:" in advice
        assert "Suggested reward:" in advice
        assert "USDC" in advice

    @pytest.mark.asyncio
    async def test_unknown_token_advice_includes_warnings(self, estimator):
        advice = await estimator.advise_pricing(
            {"type": "code", "description": "Task"},
            reward_symbol="UNKNOWN",
        )
        assert "Warnings:" in advice
        assert "No USD price configured for UNKNOWN" in advice

    @pytest.mark.asyncio
    async def test_no_low_confidence_note(self, estimator):
        advice = await estimator.advise_pricing({"x": 1})
        assert "Low confidence" not in advice
        assert "Confidence:" in advice

    @pytest.mark.asyncio
    async def test_token_model_shows_token_info(self, estimator):
        advice = await estimator.advise_pricing(
            {"type": "code", "description": "Fix a bug"},
        )
        assert "token model" in advice
        assert "Estimated tokens:" in advice
        assert "Base tokens:" in advice

    @pytest.mark.asyncio
    async def test_fixed_model_shows_base_cost(self, estimator):
        advice = await estimator.advise_pricing(
            {"type": "video", "description": "Create a video"},
        )
        assert "fixed model" in advice
        assert "Base cost:" in advice
        assert "Estimated tokens:" not in advice

    @pytest.mark.asyncio
    async def test_rough_estimate_disclaimer(self, estimator):
        advice = await estimator.advise_pricing(
            {"type": "code", "description": "Task"},
        )
        assert "rough estimates" in advice
        assert "Price discovery happens at bid time" in advice


# ── estimate_token_usage() ──────────────────────────────────────


class TestEstimateTokenUsage:
    def test_returns_token_count(self, estimator):
        tokens = estimator.estimate_token_usage(
            {"type": "code", "description": "Write a function"},
        )
        assert tokens > 0
        assert isinstance(tokens, int)

    def test_complex_tasks_more_tokens(self, estimator):
        simple = estimator.estimate_token_usage(
            {"type": "generic", "description": "Simple"},
        )
        complex_ = estimator.estimate_token_usage(
            {
                "type": "research",
                "description": "Comprehensive analysis of multiple blockchain protocols",
            },
        )
        assert complex_ > simple


# ── Config ──────────────────────────────────────────────────────


class TestConfig:
    @pytest.mark.asyncio
    async def test_custom_pricing(self, estimator):
        custom = CostEstimator(
            default_model="my-model",
            custom_pricing={"my-model": 50.0},
        )
        result = await custom.estimate(
            {"type": "generic", "description": "Task"},
        )
        default = await estimator.estimate(
            {"type": "generic", "description": "Task"},
        )
        assert result.model == "my-model"
        assert result.base_cost_usd > default.base_cost_usd

    @pytest.mark.asyncio
    async def test_custom_complexity(self):
        custom = CostEstimator(custom_complexity={"code": 200_000})
        result = await custom.estimate(
            {"type": "code", "description": "Write code"},
        )
        default = await CostEstimator().estimate(
            {"type": "code", "description": "Write code"},
        )
        assert result.estimated_tokens > default.estimated_tokens

    @pytest.mark.asyncio
    async def test_default_model(self):
        result = await CostEstimator().estimate({"description": "Task"})
        assert result.model == "claude-sonnet-4"

    @pytest.mark.asyncio
    async def test_default_markup(self):
        result = await CostEstimator().estimate(
            {"type": "generic", "description": "Task"},
        )
        expected = round(result.base_cost_usd * 2.5, 2)
        assert result.suggested_reward_usd == expected
