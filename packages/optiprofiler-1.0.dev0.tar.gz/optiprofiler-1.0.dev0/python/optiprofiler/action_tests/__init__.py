# Action tests for OptiProfiler (not discovered by pytest)
