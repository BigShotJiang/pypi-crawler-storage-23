Mithril CLI and SDK

## Installation

```bash
# For CLI usage
uv tool install mithril-client

# For SDK usage (as a dependency)
uv add mithril-client
```

## CLI Usage

```bash
# Launch a task
ml launch task.yaml -c my-cluster

# Launch with GPU specification
ml launch 'python train.py' --gpus A100:4

# Check status (falls through to sky)
ml status

# Tear down
ml down my-cluster
```

## SDK Usage

```python
from mithril import sky

# All skypilot functionality via fallthrough
task = sky.Task(run="echo hello")
sky.launch(task)
```

## Development

```bash
uv sync --dev
uv run pytest
```

We recommend using [prek](https://prek.j178.dev/) (drop-in replacement for `pre-commit`)
to run the repo’s git hook checks:

```bash
brew install prek
prek install
```
