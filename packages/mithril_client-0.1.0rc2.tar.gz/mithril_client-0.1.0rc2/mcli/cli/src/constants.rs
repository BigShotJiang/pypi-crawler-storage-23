use crate::config::resolve_api_url;

/// Default API URL for the Mithril platform
pub const DEFAULT_API_URL: &str = "https://api.mithril.ai";

/// Base URL for the Mithril web app
pub fn app_url() -> String {
    resolve_api_url(DEFAULT_API_URL).replace("api", "app")
}

/// URL where users can get their API key
pub fn api_keys_url() -> String {
    format!("{}/account/api-keys", app_url())
}

/// URL where users can configure billing settings
pub fn billing_settings_url() -> String {
    format!("{}/settings/billing", app_url())
}
