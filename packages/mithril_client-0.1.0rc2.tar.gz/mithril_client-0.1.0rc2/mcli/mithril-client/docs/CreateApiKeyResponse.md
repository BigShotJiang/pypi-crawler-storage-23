# CreateApiKeyResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**created_at** | **String** |  | 
**expires_at** | **String** |  | 
**deactivated_at** | Option<**String**> |  | [optional]
**snippet** | **String** |  | 
**secret** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


