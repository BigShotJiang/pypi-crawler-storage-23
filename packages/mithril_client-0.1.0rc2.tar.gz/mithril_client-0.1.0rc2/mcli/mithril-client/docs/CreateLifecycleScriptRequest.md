# CreateLifecycleScriptRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project** | **String** |  | 
**name** | **String** |  | 
**content** | **String** |  | 
**description** | Option<**String**> |  | [optional]
**scope** | Option<[**models::PublicLifecycleScriptScope**](PublicLifecycleScriptScope.md)> |  | [optional][default to Project]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


