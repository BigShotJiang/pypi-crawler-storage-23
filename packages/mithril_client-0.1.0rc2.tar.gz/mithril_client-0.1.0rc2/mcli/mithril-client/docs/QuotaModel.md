# QuotaModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** | Unique identifier for the quota | 
**project** | **String** | Project FID this quota belongs to | 
**instance_type** | Option<**String**> |  | [optional]
**product_type** | **String** | Type of product (e.g., 'Spot', 'Reservations', 'Storage') | 
**total_quantity** | **i32** | Total quota quantity used | 
**used_quantity** | **i32** | Total quota quantity used | 
**units** | **String** | Units for the quota (e.g., 'instances', 'GB') | 
**name** | **String** | Human-readable display name for the quota | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


