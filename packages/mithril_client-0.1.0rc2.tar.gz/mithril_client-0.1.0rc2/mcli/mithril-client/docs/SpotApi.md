# \SpotApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancel_bid_v2_spot_bids_bid_fid_delete**](SpotApi.md#cancel_bid_v2_spot_bids_bid_fid_delete) | **DELETE** /v2/spot/bids/{bid_fid} | Cancel Bid
[**create_bid_v2_spot_bids_post**](SpotApi.md#create_bid_v2_spot_bids_post) | **POST** /v2/spot/bids | Create Bid
[**get_auctions_v2_spot_availability_get**](SpotApi.md#get_auctions_v2_spot_availability_get) | **GET** /v2/spot/availability | Get Auctions
[**get_bid_history_v2_spot_bids_bid_fid_history_get**](SpotApi.md#get_bid_history_v2_spot_bids_bid_fid_history_get) | **GET** /v2/spot/bids/{bid_fid}/history | Get Bid History
[**get_bid_status_v2_spot_bids_bid_fid_status_get**](SpotApi.md#get_bid_status_v2_spot_bids_bid_fid_status_get) | **GET** /v2/spot/bids/{bid_fid}/status | Get Bid Status
[**get_bid_v2_spot_bids_bid_fid_get**](SpotApi.md#get_bid_v2_spot_bids_bid_fid_get) | **GET** /v2/spot/bids/{bid_fid} | Get Bid
[**get_bids_v2_spot_bids_get**](SpotApi.md#get_bids_v2_spot_bids_get) | **GET** /v2/spot/bids | Get Bids
[**update_bid_v2_spot_bids_bid_fid_patch**](SpotApi.md#update_bid_v2_spot_bids_bid_fid_patch) | **PATCH** /v2/spot/bids/{bid_fid} | Update Bid



## cancel_bid_v2_spot_bids_bid_fid_delete

> cancel_bid_v2_spot_bids_bid_fid_delete(bid_fid)
Cancel Bid

Cancel a Spot bid

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**bid_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## create_bid_v2_spot_bids_post

> models::BidModel create_bid_v2_spot_bids_post(create_bid_request)
Create Bid

Place a new Spot bid

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_bid_request** | [**CreateBidRequest**](CreateBidRequest.md) |  | [required] |

### Return type

[**models::BidModel**](BidModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_auctions_v2_spot_availability_get

> Vec<models::AuctionModel> get_auctions_v2_spot_availability_get()
Get Auctions

Get the Spot availability across all regions.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::AuctionModel>**](AuctionModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_bid_history_v2_spot_bids_bid_fid_history_get

> models::BidHistoryResponse get_bid_history_v2_spot_bids_bid_fid_history_get(bid_fid)
Get Bid History

Get the history of events for a Spot bid.  Returns a list of historical events including: - placing the bid - pausing the bid - resuming the bid - terminating the bid - changes to the limit price

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**bid_fid** | **String** |  | [required] |

### Return type

[**models::BidHistoryResponse**](BidHistoryResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_bid_status_v2_spot_bids_bid_fid_status_get

> models::BidStatusResponse get_bid_status_v2_spot_bids_bid_fid_status_get(bid_fid)
Get Bid Status

Get detailed status of a Spot bid.  Returns a detailed status that includes instance-level status information. The status can be one of: Open, Allocated, Preempting, Terminated, Paused, Relocating.  \"Relocating\" indicates that part of the order is being relocated.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**bid_fid** | **String** |  | [required] |

### Return type

[**models::BidStatusResponse**](BidStatusResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_bid_v2_spot_bids_bid_fid_get

> models::BidModel get_bid_v2_spot_bids_bid_fid_get(bid_fid)
Get Bid

Get a single Spot bid by FID

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**bid_fid** | **String** |  | [required] |

### Return type

[**models::BidModel**](BidModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_bids_v2_spot_bids_get

> models::GetBidsResponse get_bids_v2_spot_bids_get(next_cursor, sort_by, sort_dir, project, instance_type, region, status, name, limit)
Get Bids

Get all Spot bids for a project, or all user's projects if not specified

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**next_cursor** | Option<[**serde_json::Value**](SerdeJson__Value.md)> |  |  |
**sort_by** | Option<**String**> |  |  |
**sort_dir** | Option<[**models::SortDirection**](Models__SortDirection.md)> |  |  |
**project** | Option<**String**> |  |  |
**instance_type** | Option<**String**> |  |  |
**region** | Option<**String**> |  |  |
**status** | Option<**String**> |  |  |
**name** | Option<**String**> |  |  |
**limit** | Option<**i32**> |  |  |

### Return type

[**models::GetBidsResponse**](GetBidsResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_bid_v2_spot_bids_bid_fid_patch

> models::BidModel update_bid_v2_spot_bids_bid_fid_patch(bid_fid, update_bid_request)
Update Bid

Update the limit price of a Spot bid

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**bid_fid** | **String** |  | [required] |
**update_bid_request** | [**UpdateBidRequest**](UpdateBidRequest.md) |  | [required] |

### Return type

[**models::BidModel**](BidModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

