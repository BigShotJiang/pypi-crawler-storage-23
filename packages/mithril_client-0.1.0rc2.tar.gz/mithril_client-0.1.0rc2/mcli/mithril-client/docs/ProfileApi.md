# \ProfileApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_me_v2_me_get**](ProfileApi.md#get_me_v2_me_get) | **GET** /v2/me | Get Me
[**get_my_teammates_v2_me_teammates_get**](ProfileApi.md#get_my_teammates_v2_me_teammates_get) | **GET** /v2/me/teammates | Get My Teammates



## get_me_v2_me_get

> models::MeResponse get_me_v2_me_get()
Get Me

Get the current user's profile

### Parameters

This endpoint does not need any parameter.

### Return type

[**models::MeResponse**](MeResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_my_teammates_v2_me_teammates_get

> Vec<models::TeammateResponse> get_my_teammates_v2_me_teammates_get()
Get My Teammates

Get teammates visible to the current user.  Returns teammates from the user's organization, filtered by shared project membership (unless the user is an org admin, in which case all org members are visible). Can be used by a client to map user FIDs to user profiles.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::TeammateResponse>**](TeammateResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

