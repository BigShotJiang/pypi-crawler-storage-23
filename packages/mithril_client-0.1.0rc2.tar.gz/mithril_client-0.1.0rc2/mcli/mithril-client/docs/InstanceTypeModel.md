# InstanceTypeModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**num_cpus** | **i32** |  | 
**cpu_type** | **String** |  | 
**ram_gb** | **i32** |  | 
**num_gpus** | **i32** |  | 
**gpu_type** | **String** |  | 
**gpu_memory_gb** | **i32** |  | 
**gpu_socket** | **String** |  | 
**local_storage_gb** | **i32** |  | 
**network_type** | Option<**String**> |  | [optional]
**ib_count** | **i32** |  | 
**bridge_count** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


