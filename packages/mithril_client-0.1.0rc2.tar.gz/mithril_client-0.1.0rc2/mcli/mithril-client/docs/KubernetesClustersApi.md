# \KubernetesClustersApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_kubernetes_cluster_v2_kubernetes_clusters_post**](KubernetesClustersApi.md#create_kubernetes_cluster_v2_kubernetes_clusters_post) | **POST** /v2/kubernetes/clusters | Create Kubernetes Cluster
[**delete_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_delete**](KubernetesClustersApi.md#delete_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_delete) | **DELETE** /v2/kubernetes/clusters/{cluster_fid} | Delete Kubernetes Cluster
[**get_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_get**](KubernetesClustersApi.md#get_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_get) | **GET** /v2/kubernetes/clusters/{cluster_fid} | Get Kubernetes Cluster
[**get_kubernetes_clusters_v2_kubernetes_clusters_get**](KubernetesClustersApi.md#get_kubernetes_clusters_v2_kubernetes_clusters_get) | **GET** /v2/kubernetes/clusters | Get Kubernetes Clusters



## create_kubernetes_cluster_v2_kubernetes_clusters_post

> models::KubernetesClusterModel create_kubernetes_cluster_v2_kubernetes_clusters_post(create_kubernetes_cluster_request)
Create Kubernetes Cluster

Create a new Kubernetes cluster

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_kubernetes_cluster_request** | [**CreateKubernetesClusterRequest**](CreateKubernetesClusterRequest.md) |  | [required] |

### Return type

[**models::KubernetesClusterModel**](KubernetesClusterModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## delete_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_delete

> delete_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_delete(cluster_fid)
Delete Kubernetes Cluster

Delete a Kubernetes cluster

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**cluster_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_get

> models::KubernetesClusterModel get_kubernetes_cluster_v2_kubernetes_clusters_cluster_fid_get(cluster_fid)
Get Kubernetes Cluster

Get a specific Kubernetes cluster

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**cluster_fid** | **String** |  | [required] |

### Return type

[**models::KubernetesClusterModel**](KubernetesClusterModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_kubernetes_clusters_v2_kubernetes_clusters_get

> Vec<models::KubernetesClusterModel> get_kubernetes_clusters_v2_kubernetes_clusters_get(project)
Get Kubernetes Clusters

Get all Kubernetes clusters for a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |

### Return type

[**Vec<models::KubernetesClusterModel>**](KubernetesClusterModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

