# BidStatusResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bid_fid** | **String** |  | 
**status** | **Status** |  (enum: Open, Allocated, Preempting, Terminated, Paused, Relocating) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


