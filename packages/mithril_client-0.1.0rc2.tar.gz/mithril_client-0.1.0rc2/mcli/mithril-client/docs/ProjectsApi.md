# \ProjectsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_projects_v2_projects_get**](ProjectsApi.md#get_projects_v2_projects_get) | **GET** /v2/projects | Get Projects



## get_projects_v2_projects_get

> Vec<models::ProjectModel> get_projects_v2_projects_get()
Get Projects

Get all projects a user has access to

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::ProjectModel>**](ProjectModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

