# CurrentPricesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spot_price_cents** | Option<**i32**> |  | [optional]
**reserved_price_cents** | Option<**i32**> |  | [optional]
**minimum_price_cents** | Option<**i32**> |  | [optional]
**lowest_allocated_bid_cents** | Option<**i32**> |  | [optional]
**dynamic_win_price_cents** | Option<**i32**> |  | [optional]
**available_capacity** | Option<**i32**> |  | [optional]
**total_capacity** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


