# TeammateResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**fid** | **String** |  | 
**user_name** | Option<**String**> |  | [optional]
**email** | Option<**String**> |  | [optional]
**organization_role** | Option<**String**> |  | [optional]
**project_ids** | **Vec<String>** |  | 
**deactivated_at** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


