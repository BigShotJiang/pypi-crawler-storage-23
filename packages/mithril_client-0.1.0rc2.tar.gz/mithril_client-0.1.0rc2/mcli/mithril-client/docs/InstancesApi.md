# \InstancesApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_instance_status_v2_instances_instance_id_status_get**](InstancesApi.md#get_instance_status_v2_instances_instance_id_status_get) | **GET** /v2/instances/{instance_id}/status | Get Instance Status
[**get_instances_v2_instances_get**](InstancesApi.md#get_instances_v2_instances_get) | **GET** /v2/instances | Get Instances



## get_instance_status_v2_instances_instance_id_status_get

> models::InstanceStatusResponse get_instance_status_v2_instances_instance_id_status_get(instance_id)
Get Instance Status

Get the status of a specific instance by its ID

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**instance_id** | **String** |  | [required] |

### Return type

[**models::InstanceStatusResponse**](InstanceStatusResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_instances_v2_instances_get

> models::GetInstancesResponse get_instances_v2_instances_get(project, next_cursor, sort_by, sort_dir, instance_type, region, status_in, order_type_in, bid_fid_in, reservation_fid_in, limit)
Get Instances

Get all instances for a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |
**next_cursor** | Option<[**serde_json::Value**](SerdeJson__Value.md)> |  |  |
**sort_by** | Option<**String**> |  |  |
**sort_dir** | Option<[**models::SortDirection**](Models__SortDirection.md)> |  |  |
**instance_type** | Option<**String**> |  |  |
**region** | Option<**String**> |  |  |
**status_in** | Option<[**Vec<String>**](String.md)> |  |  |
**order_type_in** | Option<[**Vec<String>**](String.md)> |  |  |
**bid_fid_in** | Option<[**Vec<String>**](String.md)> |  |  |
**reservation_fid_in** | Option<[**Vec<String>**](String.md)> |  |  |
**limit** | Option<**i32**> |  |  |

### Return type

[**models::GetInstancesResponse**](GetInstancesResponse.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

