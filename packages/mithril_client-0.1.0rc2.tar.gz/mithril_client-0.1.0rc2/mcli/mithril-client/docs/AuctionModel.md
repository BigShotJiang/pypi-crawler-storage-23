# AuctionModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**instance_type** | **String** |  | 
**region** | **String** |  | 
**capacity** | **i32** |  | 
**last_instance_price** | **String** |  | 
**lowest_allocated_price** | Option<**String**> |  | [optional]
**adjustable_memory** | **bool** |  | 
**default_image_version** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


