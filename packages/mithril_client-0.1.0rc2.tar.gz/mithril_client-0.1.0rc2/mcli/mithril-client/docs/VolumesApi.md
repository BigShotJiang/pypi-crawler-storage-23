# \VolumesApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_volume_v2_volumes_post**](VolumesApi.md#create_volume_v2_volumes_post) | **POST** /v2/volumes | Create Volume
[**delete_volume_v2_volumes_volume_fid_delete**](VolumesApi.md#delete_volume_v2_volumes_volume_fid_delete) | **DELETE** /v2/volumes/{volume_fid} | Delete Volume
[**get_volumes_v2_volumes_get**](VolumesApi.md#get_volumes_v2_volumes_get) | **GET** /v2/volumes | Get Volumes
[**update_volume_v2_volumes_volume_fid_patch**](VolumesApi.md#update_volume_v2_volumes_volume_fid_patch) | **PATCH** /v2/volumes/{volume_fid} | Update Volume



## create_volume_v2_volumes_post

> models::VolumeModel create_volume_v2_volumes_post(create_volume_request)
Create Volume

Creates a new storage volume.  Args:     user_info: Authenticated user information.     body: Request body containing volume creation details (size, region, etc).  Returns:     VolumeModel: The created volume model.  Raises:     HTTPException: If user unauthorized or creation fails.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_volume_request** | [**CreateVolumeRequest**](CreateVolumeRequest.md) |  | [required] |

### Return type

[**models::VolumeModel**](VolumeModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## delete_volume_v2_volumes_volume_fid_delete

> delete_volume_v2_volumes_volume_fid_delete(volume_fid)
Delete Volume

Deletes a storage volume.  Permanently removes a volume. The volume must not be currently in use/attached.  Args:     user_info: Authenticated user information.     volume_fid: Identifier of the volume to delete.  Raises:     HTTPException: If volume not found, user unauthorized, or volume is in use.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**volume_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_volumes_v2_volumes_get

> Vec<models::VolumeModel> get_volumes_v2_volumes_get(project, region)
Get Volumes

Retrieves all storage volumes for a specific project.  Args:     user_info: Authenticated user information.     project: Identifier of the project to list volumes for.     region: Optional region filter.  Returns:     list[VolumeModel]: A list of volume models belonging to the project.  Raises:     HTTPException: If project is missing or user is not authorized.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |
**region** | Option<**String**> |  |  |

### Return type

[**Vec<models::VolumeModel>**](VolumeModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_volume_v2_volumes_volume_fid_patch

> models::VolumeModel update_volume_v2_volumes_volume_fid_patch(volume_fid, update_volume_request)
Update Volume

Updates a storage volume's mutable properties (e.g., name).  Args:     user_info: Authenticated user information.     volume_fid: Identifier of the volume to update.     body: Request body containing updated fields.  Returns:     VolumeModel: The updated volume model.  Raises:     HTTPException: If volume not found or user unauthorized.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**volume_fid** | **String** |  | [required] |
**update_volume_request** | [**UpdateVolumeRequest**](UpdateVolumeRequest.md) |  | [required] |

### Return type

[**models::VolumeModel**](VolumeModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

