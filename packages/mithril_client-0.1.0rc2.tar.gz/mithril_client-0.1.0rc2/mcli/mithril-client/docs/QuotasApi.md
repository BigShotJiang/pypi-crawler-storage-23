# \QuotasApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_quotas_v2_quotas_get**](QuotasApi.md#get_quotas_v2_quotas_get) | **GET** /v2/quotas | Get Quotas



## get_quotas_v2_quotas_get

> Vec<models::QuotaModel> get_quotas_v2_quotas_get(project)
Get Quotas

Get all quotas for a project in unified format

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |

### Return type

[**Vec<models::QuotaModel>**](QuotaModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

