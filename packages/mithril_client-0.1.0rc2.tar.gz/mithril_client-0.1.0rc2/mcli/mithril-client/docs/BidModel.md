# BidModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**project** | **String** |  | 
**created_by** | **String** |  | 
**created_at** | **String** |  | 
**deactivated_at** | Option<**String**> |  | [optional]
**limit_price** | **String** |  | 
**instance_quantity** | **i32** |  | 
**instance_type** | **String** |  | 
**region** | Option<**String**> |  | [optional]
**instances** | **Vec<String>** |  | 
**launch_specification** | [**models::LaunchSpecificationModel**](LaunchSpecificationModel.md) |  | 
**status** | **Status** |  (enum: Open, Allocated, Preempting, Terminated, Paused) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


