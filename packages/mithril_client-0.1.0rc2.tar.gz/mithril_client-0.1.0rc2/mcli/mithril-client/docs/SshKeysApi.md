# \SshKeysApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_ssh_key_v2_ssh_keys_post**](SshKeysApi.md#create_ssh_key_v2_ssh_keys_post) | **POST** /v2/ssh-keys | Create Ssh Key
[**delete_ssh_key_v2_ssh_keys_ssh_key_fid_delete**](SshKeysApi.md#delete_ssh_key_v2_ssh_keys_ssh_key_fid_delete) | **DELETE** /v2/ssh-keys/{ssh_key_fid} | Delete Ssh Key
[**get_ssh_keys_v2_ssh_keys_get**](SshKeysApi.md#get_ssh_keys_v2_ssh_keys_get) | **GET** /v2/ssh-keys | Get Ssh Keys
[**update_ssh_key_v2_ssh_keys_ssh_key_fid_patch**](SshKeysApi.md#update_ssh_key_v2_ssh_keys_ssh_key_fid_patch) | **PATCH** /v2/ssh-keys/{ssh_key_fid} | Update Ssh Key



## create_ssh_key_v2_ssh_keys_post

> models::CreatedSshKeyModel create_ssh_key_v2_ssh_keys_post(create_ssh_key_request)
Create Ssh Key

Create a new SSH key. If public_key is not provided, this endpoint will generate a new RSA key pair and return both the private and public keys.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**create_ssh_key_request** | [**CreateSshKeyRequest**](CreateSshKeyRequest.md) |  | [required] |

### Return type

[**models::CreatedSshKeyModel**](CreatedSshKeyModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## delete_ssh_key_v2_ssh_keys_ssh_key_fid_delete

> delete_ssh_key_v2_ssh_keys_ssh_key_fid_delete(ssh_key_fid)
Delete Ssh Key

Delete an SSH key. Note that SSH keys used in active bids/reservations cannot be deleted.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**ssh_key_fid** | **String** |  | [required] |

### Return type

 (empty response body)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_ssh_keys_v2_ssh_keys_get

> Vec<models::NewSshKeyModel> get_ssh_keys_v2_ssh_keys_get(project)
Get Ssh Keys

Get all SSH keys for a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | **String** |  | [required] |

### Return type

[**Vec<models::NewSshKeyModel>**](NewSshKeyModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_ssh_key_v2_ssh_keys_ssh_key_fid_patch

> models::NewSshKeyModel update_ssh_key_v2_ssh_keys_ssh_key_fid_patch(ssh_key_fid, update_ssh_key_request)
Update Ssh Key

Update an SSH key to set it as required. Only admins can set a key as required.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**ssh_key_fid** | **String** |  | [required] |
**update_ssh_key_request** | [**UpdateSshKeyRequest**](UpdateSshKeyRequest.md) |  | [required] |

### Return type

[**models::NewSshKeyModel**](NewSshKeyModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

