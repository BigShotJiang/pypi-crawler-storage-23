# Clusters Overview

Clusters are managed compute environments created by `ml launch`.

## Lifecycle

1. **Launch** — `ml launch` creates cluster
2. **Running** — Execute jobs with `ml exec`
3. **Stop** — `ml stop` pauses (keeps state)
4. **Start** — `ml start` resumes stopped cluster
5. **Down** — `ml down` terminates and deletes

## Commands

| Command | Description |
|---------|-------------|
| `ml status` | List clusters and jobs |
| `ml exec` | Run command on cluster |
| `ml logs` | View job logs |
| `ml queue` | View job queue |
| `ml stop` | Stop cluster |
| `ml start` | Start stopped cluster |
| `ml down` | Delete cluster |
| `ssh` | SSH into cluster (via SkyPilot SSH config) |

## Cluster names

- Specified with `-c` flag
- Auto-generated if not provided
- Used for all subsequent commands

## SkyPilot integration

These commands pass through to SkyPilot:
- `ml exec` → `sky exec`
- `ml status` → `sky status`
- `ml stop` → `sky stop`
- `ml start` → `sky start`
- `ml down` → `sky down`

