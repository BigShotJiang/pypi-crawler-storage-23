# SSH (Clusters)

SSH into a cluster created by `ml launch`.

SkyPilot automatically configures SSH for your clusters. Use raw `ssh` to connect:

## Usage

```bash
ssh my-cluster
```

## Run command

```bash
ssh my-cluster nvidia-smi
```

## Specific node

For multi-node clusters, SkyPilot creates entries for each worker node:

```bash
ssh my-cluster-worker1
ssh my-cluster-worker2
```

## Show SSH config

```bash
cat ~/.ssh/config
```

Look for the entry matching your cluster name.

## `ml ssh` (instances)

`ml ssh` is a separate command for connecting to Mithril instances (created via `ml instance create`), not SkyPilot clusters. See the [ml ssh reference](../09-reference/cli/ml-ssh.md) for details.
