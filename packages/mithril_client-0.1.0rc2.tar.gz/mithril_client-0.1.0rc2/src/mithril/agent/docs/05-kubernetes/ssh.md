# K8s SSH

SSH into Kubernetes cluster control node.

## Usage

```bash
ml k8s ssh my-cluster
```

## Interactive mode

```bash
ml k8s ssh
```

Shows picker if name omitted.

## Run command

```bash
ml k8s ssh my-cluster kubectl get nodes
```

## Options

| Flag | Description |
|------|-------------|
| `--show` | Show SSH command, don't execute |
| `-i, --identity` | SSH key path (auto-detected) |

## Examples

### Interactive shell

```bash
ml k8s ssh my-cluster
```

### Run kubectl

```bash
ml k8s ssh my-cluster kubectl get pods -A
```

### Show SSH command

```bash
ml k8s ssh my-cluster --show
```

## When to use

- Debug control plane
- Access cluster without local kubeconfig
- Run kubectl directly on control node
- Troubleshoot networking

