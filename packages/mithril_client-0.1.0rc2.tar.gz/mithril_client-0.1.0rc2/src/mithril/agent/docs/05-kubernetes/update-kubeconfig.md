# Update Kubeconfig

Fetch Kubernetes cluster credentials and update local kubeconfig.

## Usage

```bash
ml k8s update-kubeconfig my-cluster
```

## Interactive mode

```bash
ml k8s update-kubeconfig
```

Shows picker if name omitted.

## Options

| Flag | Description |
|------|-------------|
| `-i, --identity` | SSH key path (auto-detected) |
| `-y, --yes` | Skip confirmation |
| `--no-backup` | Don't backup existing kubeconfig |
| `--skip-validation` | Don't validate with kubectl |

## What it does

1. Connects to control node via SSH
2. Fetches kubeconfig from cluster
3. Backs up existing `~/.kube/config`
4. Merges new credentials
5. Validates with `kubectl cluster-info`

## After update

```bash
# Switch context if needed
kubectl config get-contexts
kubectl config use-context my-cluster

# Use cluster
kubectl get nodes
kubectl get pods -A
```

## Backup location

Existing kubeconfig backed up to:
`~/.kube/config.backup.<timestamp>`

## Skip backup

```bash
ml k8s update-kubeconfig my-cluster --no-backup
```

