# K8s List

List Kubernetes clusters.

## Usage

```bash
ml k8s list
```

## Options

| Flag | Description |
|------|-------------|
| `--all` | Include terminated clusters |
| `--json` | JSON output |

## Examples

### Active clusters

```bash
ml k8s list
```

### All clusters

```bash
ml k8s list --all
```

### JSON output

```bash
ml k8s list --json
```

## Output columns

| Column | Description |
|--------|-------------|
| NAME | Cluster name |
| STATUS | Cluster state |
| REGION | Region |
| NODES | Number of nodes |
| CREATED | Creation time |

