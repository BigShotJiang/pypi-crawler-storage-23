# Spot Bidding

Mithril compute is allocated through a blind second-price auction from unreserved capacity.

## How it works

1. Submit bid with **limit price** (max you're willing to pay)
2. Bid becomes **open** in the marketplace
3. Auction evaluates all open bids every 2 minutes
4. When **spot price** ≤ your limit price AND capacity available → **allocated**
5. You pay spot price (not limit price) — second-price auction
6. If spot price rises above limit price → **preempted**

## Use cases

- Batch jobs that tolerate delays or preemptions
- Horizontally scaling inference capacity
- Short critical workloads when reserved capacity unavailable

## Setting the right limit price

**To allocate immediately**: Set limit price at your next best alternative (e.g., AWS/GCP on-demand price). This ensures allocation unless spot exceeds alternatives.

| Strategy | Allocation | Preemption risk | Cost |
|----------|-----------|-----------------|------|
| Conservative (higher limit) | Faster | Lower | Higher ceiling |
| Aggressive (lower limit) | Slower | Higher | Lower ceiling |

**Default limit price**: $32.00/hour if not specified.

Check current spot prices in Mithril console **Price Chart** page.

## Preemption

When spot price exceeds your limit price:

1. **5-minute notice** — status changes to `Preempting`
2. **Instances shut down** after 5 minutes
3. **Boot disks preserved** — environment intact
4. **Bid returns to `Open`** — auto-reallocates when price drops
5. **Ephemeral storage lost** — local NVMe/scratch wiped

### Storage behavior

| Storage Type | Preemption | Pause |
|--------------|------------|-------|
| Boot disk | Preserved | Preserved |
| Ephemeral (NVMe) | Lost | Lost |
| Persistent volumes | Preserved | Preserved |
| Edit persistent storage | Not allowed | Allowed |

### Handling preemption

Use startup scripts to auto-resume workloads:
```bash
# systemd service runs on subsequent startups
```

Use persistent volumes for checkpoints:
```yaml
volumes:
  /checkpoints: my-checkpoint-volume
```

## Pause & resume

Manually pause to stop billing and preserve your environment:

```bash
# Via console: ••• menu → "Pause Bid"
# Instances spin down, boot disk preserved, billing stops

# Resume: ••• menu → "Resume Bid"
# Instances restart with same boot disk, storage, SSH keys
```

## Troubleshooting

### Bid not allocating

Common reasons:

- **Higher bids**: Other bids with higher limit prices are allocated first
- **Earlier equivalent bids**: Bids at the same limit price are served in submission order
- **All-or-nothing**: You requested multiple instances, but not enough capacity remains after higher bids are allocated

**Fix**: Increase limit price or reduce instance count.

### Capacity always available?

Yes. Unlike traditional clouds, Mithril maintains dedicated spot capacity in every region.
