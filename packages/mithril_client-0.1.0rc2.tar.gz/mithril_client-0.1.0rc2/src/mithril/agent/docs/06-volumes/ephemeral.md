# Ephemeral Volumes

Temporary storage created with cluster, deleted on termination.

## Use in task

```yaml
volumes:
  /scratch:
    type: ephemeral
    size: 500GB
```

## Properties

| Property | Value |
|----------|-------|
| Lifecycle | Deleted with cluster |
| Performance | Local SSD speeds |
| Size | Configurable |
| Persistence | None |

## Use cases

- Temporary working space
- Build artifacts
- Cache directories
- Shuffle space for data processing

## Example

```yaml
name: data-processing

resources:
  infra: mithril
  accelerators: A100:4

volumes:
  /data: my-dataset          # Persistent input
  /scratch:                   # Ephemeral working space
    type: ephemeral
    size: 1000GB
  /output: results-volume    # Persistent output

run: |
  # Process data using scratch space
  python process.py \
    --input /data \
    --scratch /scratch \
    --output /output
```

## Size specification

```yaml
volumes:
  /scratch:
    type: ephemeral
    size: 100GB    # Gigabytes
```

