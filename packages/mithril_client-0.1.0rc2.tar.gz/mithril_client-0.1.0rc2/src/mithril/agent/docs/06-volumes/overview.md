# Volumes Overview

Persistent storage for ML workloads.

## Volume types

| Type | Description |
|------|-------------|
| Persistent | Long-lived, survives instance termination |
| Ephemeral | Temporary, deleted with cluster |

## Quick start

```bash
# Create volume
ml sky volumes apply \
  --name my-volume \
  --infra mithril/us-central5-a \
  --type mithril-file-share \
  --size 100GB

# Use in task YAML
volumes:
  /data: my-volume
```

## Volume interfaces

| Interface | Type | Use case |
|-----------|------|----------|
| File (NFS) | `mithril-file-share` | Shared access, multiple instances |
| Block | `mithril-block` | Single instance, high performance |

> Not all regions support both interfaces. See [Region availability](persistent.md#region-availability) for details.

## See also

- `persistent.md` — Creating and using persistent volumes
- `ephemeral.md` — Temporary scratch storage
- `sync.md` — How volumes sync to SkyPilot
