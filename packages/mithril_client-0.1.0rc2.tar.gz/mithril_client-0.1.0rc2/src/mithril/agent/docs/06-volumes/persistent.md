# Persistent Volumes

Long-lived storage that survives instance termination.

## Create volume

### File share (NFS)

For shared access across multiple instances:

```bash
ml sky volumes apply \
  --name my-data-volume \
  --infra mithril/us-central5-a \
  --type mithril-file-share \
  --size 100GB
```

### Block storage

For single-instance high performance:

```bash
ml sky volumes apply \
  --name my-block-volume \
  --infra mithril/us-central5-a \
  --type mithril-block \
  --size 500GB
```

## Manage volumes

```bash
# List volumes
ml sky volumes ls

# Delete volume
ml sky volumes delete my-volume
```

## Use in task

```yaml
name: training
resources:
  accelerators: B200:8
  infra: mithril/us-central5-a  # Must match volume region

volumes:
  /data: my-data-volume
  /checkpoints: my-checkpoints-volume

run: |
  python train.py --data /data --output /checkpoints
```

## Multiple volumes

```yaml
volumes:
  /data: dataset-volume
  /models: pretrained-models
  /output: training-output
```

## Region availability

Not all regions support persistent volumes. Some regions support only file share or only block storage. Check the Mithril console for current region support.

Volume and instance must be in the same region:

```yaml
resources:
  infra: mithril/us-central5-a  # Volume region

volumes:
  /data: my-volume  # Must be in us-central5-a
```

## Volume properties

| Property | Description |
|----------|-------------|
| Name | Unique identifier |
| Region | Geographic location (in `--infra`) |
| Size | Capacity (e.g., `100GB`, `1TB`) |
| Type | `mithril-file-share` or `mithril-block` |
