# Quickstart

## 1. Navigate to your project

```bash
cd my-training-project
```

## 2. Create a task file

```yaml
# task.yaml

# Directory to sync to the remote VM so your code and data are available
workdir: .

resources:
  infra: mithril
  accelerators: B200:8

# Runs once when the cluster is first provisioned (install deps, download data, etc.)
setup: |
  pip install -r requirements.txt

# Your training entrypoint — executed on the cluster
run: |
  nvidia-smi
  python train.py
```

> See [Task YAML Spec](../02-launch/yaml/task-spec.md) for the full reference.

## 3. Launch

```bash
ml launch task.yaml -c my-cluster
```

This provisions a cluster and runs your task on it. See [Tasks, Clusters, and Jobs](../02-launch/concepts/tasks-clusters-jobs.md) for how these concepts relate.

## 4. Check status

```bash
ml status
```

## 5. View job queue and logs

```bash
ml queue my-cluster        # list jobs on the cluster
ml logs my-cluster         # stream logs for the latest job
```

## 6. SSH

Start a local `tmux` session (install if needed - highly recommended) and SSH into the cluster inside it. This lets you run commands on the cluster without opening a new SSH connection each time.

```bash
tmux new-session -d -s my-cluster
tmux send-keys -t my-cluster 'ssh my-cluster' Enter
```

## 7. Iterate

Edit your code or `run` commands and re-run on the same cluster:

```bash
ml exec my-cluster task.yaml
```

`ml exec` only syncs `workdir` and runs the `run` commands — it skips provisioning, setup, and file mounts, so it's much faster. If you change `setup`, `file_mounts`, or `resources`, use `ml launch -c my-cluster task.yaml` instead.

## 8. Tear down

```bash
ml down my-cluster
```
