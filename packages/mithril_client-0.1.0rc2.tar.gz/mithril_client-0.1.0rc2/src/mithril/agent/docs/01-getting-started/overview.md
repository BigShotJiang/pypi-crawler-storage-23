# Getting Started Overview

## Quick path

1. **Create** → Write a `task.yaml` with your resources and commands
2. **Launch** → `ml launch task.yaml -c my-cluster`
3. **Iterate** → `ssh`, `ml exec`, `ml status`
4. **Tear down** → `ml down my-cluster`

## Topics

| Doc | Description |
|-----|-------------|
| `setup.md` | API keys, auth, and config file |
| `quickstart.md` | First launch in 2 minutes |

## Next steps

- Launch your first GPU cluster → `quickstart.md`
