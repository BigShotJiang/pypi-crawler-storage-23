# Setup

Run `ml setup --check`. If not configured, ask the user to run `ml setup`.

## Non-interactive setup (CI/scripts)

Skip `ml setup` by setting environment variables:

- **API key**: get one at <https://app.mithril.ai/account/api-keys>
- **Project ID**: project `fid` from the projects API:
  ```bash
  curl -H "Authorization: Bearer <API_KEY>" https://api.mithril.ai/v2/projects
  ```

```bash
export MITHRIL_API_KEY=fkey_xxx
export MITHRIL_PROJECT=proj_xxx
```
