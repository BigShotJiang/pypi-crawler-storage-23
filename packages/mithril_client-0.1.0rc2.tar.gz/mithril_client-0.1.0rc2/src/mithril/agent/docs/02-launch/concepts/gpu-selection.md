# GPU Selection

Specify GPUs for your tasks.

## Format

```
TYPE:COUNT
```

## CLI

```bash
ml launch 'python train.py' --gpus B200:8
```

## YAML

```yaml
resources:
  accelerators: B200:8
```

## SDK

```python
task.set_resources(sky.Resources(
    infra='mithril',
    accelerators='B200:8',
))
```

## Discover available GPUs

### For `ml launch` (SkyPilot catalog)

```bash
ml sky show-gpus --infra mithril -a   # All GPUs with pricing
ml sky show-gpus B200 --all-regions   # Region availability
```

### For `ml instance create` (Mithril marketplace)

```bash
ml instance list-types                # All instance types
```
