# Dryrun

Validate launch configuration without actually launching.

## CLI

```bash
ml launch task.yaml --dryrun
```

## SDK

```python
sky.launch(
    task=task,
    cluster_name='my-cluster',
    dryrun=True,
)
```

## Output

Shows:
- Cluster name (or auto-generated)
- Task configuration
- Resource requirements

## Example output

```
Dry run mode:
  Cluster: my-cluster
  Task: <Task name='training', ...>
  Resources: <Resources infra=mithril, accelerators=B200:8>
```

## Use cases

- Validate YAML syntax
- Check resource availability
- Preview what would be launched
- Debug configuration issues

## No resources consumed

- No API calls to provision
- No costs incurred
- No cluster created
