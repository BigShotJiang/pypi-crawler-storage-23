# Task YAML

Define tasks in YAML for reproducible, version-controlled launches.

## Quick start

```yaml
# task.yaml
resources:
  accelerators: B200:8
run: python train.py
```

```bash
ml launch task.yaml -c my-cluster
```

## Full example

```yaml
name: distributed-training

resources:
  infra: mithril
  accelerators: B200:8

num_nodes: 2

workdir: .

file_mounts:
  /data: s3://my-bucket/data

envs:
  WANDB_API_KEY: xxx
  BATCH_SIZE: 32

setup: |
  pip install -r requirements.txt

run: |
  torchrun --nproc_per_node=8 train.py

config:
  mithril:
    limit_price: 8.0
```

## Topics

- [Task Spec](task-spec.md) — full field reference
- [Resources](resources.md) — resource block details
- [File Mounts](file-mounts.md) — remote storage, volumes, workdir
