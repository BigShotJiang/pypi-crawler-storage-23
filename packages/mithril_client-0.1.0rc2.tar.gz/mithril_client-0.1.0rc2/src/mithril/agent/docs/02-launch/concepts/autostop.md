# Autostop

Automatically stop clusters after an idle period.

## CLI

```bash
ml launch task.yaml -c my-cluster -i 30
```

Cluster stops after 30 minutes of no jobs running.

## SDK

```python
sky.launch(
    task=task,
    cluster_name='my-cluster',
    idle_minutes_to_autostop=30,
)
```

## YAML

Not directly in task YAML — use CLI flag or SDK parameter.

## Behavior

- Timer starts when no jobs are running
- Any new job resets timer
- Stopped cluster can be restarted with `ml start`

## Disable autostop

```bash
ml launch task.yaml -c my-cluster -i 0
```

Setting to 0 disables autostop.

## Auto-teardown

To delete (not just stop) after job completes:

### CLI

```bash
ml launch task.yaml -c my-cluster --down
```

### SDK

```python
sky.launch(
    task=task,
    cluster_name='my-cluster',
    down=True,
)
```

## Check autostop status

```bash
ml status
```

Shows autostop configuration for each cluster.
