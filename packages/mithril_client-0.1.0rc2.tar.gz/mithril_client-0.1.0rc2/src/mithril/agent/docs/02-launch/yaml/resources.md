# Resources Block

Define compute requirements in the `resources` block.

## Full specification

```yaml
resources:
  infra: mithril
  accelerators: B200:8
  cpus: 32+
  memory: 256+
  disk_size: 500
  disk_tier: best
```

## Fields

| Field | Type | CLI override | Description |
|-------|------|-------------|-------------|
| `infra` | string | `--infra` | Infrastructure (`mithril`, `mithril/region`) |
| `accelerators` | string | `--gpus` | GPU type:count (e.g., `B200:8`) |
| `cpus` | string | `--cpus` | vCPU count (e.g., `32`, `32+` for minimum) |
| `memory` | string | `--memory` | Memory in GB (e.g., `256`, `256+`) |
| `disk_size` | int | — | Disk size in GB |
| `disk_tier` | string | — | `low`, `medium`, `high`, `best` |

## Minimum requirements

Use `+` suffix for "at least":

```yaml
resources:
  cpus: 16+      # At least 16 vCPUs
  memory: 64+    # At least 64GB RAM
```

## GPU specification

```yaml
resources:
  accelerators: B200:8
```

Common types:
- `B200:8` — 8x NVIDIA B200
- `A100-80GB:4` — 4x A100 80GB
- `A100:4` — 4x A100 40GB
- `L4:1` — 1x NVIDIA L4

## Minimal example

```yaml
resources:
  accelerators: B200:8
```

Infra defaults to `mithril`, other fields auto-selected.
