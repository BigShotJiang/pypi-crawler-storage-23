# Instance List

List instances and spot bids.

## Usage

```bash
ml instance list
```

## Default behavior

Shows active instances only (pending, running, etc.).

## Options

| Flag | Description |
|------|-------------|
| `--all` | Include completed/cancelled |
| `-s, --state STATE` | Filter by state |
| `--limit N` | Maximum results |
| `--json` | JSON output |

## Examples

### Active only (default)

```bash
ml instance list
```

### All instances

```bash
ml instance list --all
```

### Filter by state

```bash
ml instance list --state running
ml instance list --state pending
```

### JSON for scripting

```bash
ml instance list --json | jq '.[] | .name'
```

## Output columns

| Column | Description |
|--------|-------------|
| NAME | Bid/instance name |
| STATUS | Current state |
| TYPE | Instance type |
| REGION | Region |
| PRICE | Current/max price |

## Valid states

`allocated`, `pending`, `open`, `starting`, `running`, `paused`, `preempting`, `completed`, `failed`, `cancelled`

