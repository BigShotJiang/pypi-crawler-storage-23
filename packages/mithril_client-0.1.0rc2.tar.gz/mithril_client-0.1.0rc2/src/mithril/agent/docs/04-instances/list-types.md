# List Instance Types

Show available GPU instance types.

## Usage

```bash
ml instance list-types
```

## Options

| Flag | Description |
|------|-------------|
| `-r, --region` | Filter by region |
| `-v, --verbose` | Show memory/details |
| `--json` | JSON output |

## Examples

### All types

```bash
ml instance list-types
```

### By region

```bash
ml instance list-types -r us-central5-a
```

### Verbose (with specs)

```bash
ml instance list-types -v
```

## Output

| Column | Description |
|--------|-------------|
| TYPE | Instance type name |
| GPUS | GPU count and type |
| VCPUS | vCPU count |
| MEMORY | RAM (verbose only) |
| REGIONS | Available regions |

## Common types

| Type | GPUs |
|------|------|
| `b200` | 1x B200 192GB |
| `8xb200` | 8x B200 192GB |
| `a100` | 1x A100 40GB |
| `a100-80gb` | 1x A100 80GB |
| `8xa100` | 8x A100 40GB |
| `8xa100-80gb` | 8x A100 80GB |

## Check pricing

Instance type availability and pricing varies. Use Mithril console for current prices.

