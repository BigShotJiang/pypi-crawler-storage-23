# Instance States

Instances/bids progress through these states.

## State diagram

```
pending → open → allocated → starting → running
                    ↓                       ↓
                 failed                  preempting → (back to open)
                    ↓                       ↓
               cancelled              completed/failed
```

## States

| State | Description |
|-------|-------------|
| `pending` | Bid submitted, being processed |
| `open` | Bid active in marketplace, waiting for allocation |
| `allocated` | Resources reserved, preparing to start |
| `starting` | VM booting up |
| `running` | Instance ready and accessible |
| `paused` | Temporarily paused |
| `preempting` | Being preempted, will return to open |
| `completed` | Finished normally |
| `failed` | Error occurred |
| `cancelled` | Cancelled by user |

## Active states

These states count as "active":
- `pending`
- `open`
- `allocated`
- `starting`
- `running`
- `paused`
- `preempting`

## Terminal states

- `completed`
- `failed`
- `cancelled`

## Check state

```bash
ml instance info my-instance
ml instance list --state running
```

