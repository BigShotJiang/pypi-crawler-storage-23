"""Internal CLI utilities (not user-facing commands)."""
