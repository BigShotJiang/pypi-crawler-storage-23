from __future__ import annotations

from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_volume_request import CreateVolumeRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.volume_model import VolumeModel
from ...types import Response


def _get_kwargs(
    *,
    body: CreateVolumeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/volumes",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VolumeModel | None:
    if response.status_code == 201:
        response_201 = VolumeModel.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VolumeModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateVolumeRequest,
) -> Response[HTTPValidationError | VolumeModel]:
    """Create Volume

     Creates a new storage volume.

    Args:
        user_info: Authenticated user information.
        body: Request body containing volume creation details (size, region, etc).

    Returns:
        VolumeModel: The created volume model.

    Raises:
        HTTPException: If user unauthorized or creation fails.

    Args:
        body (CreateVolumeRequest): Request model for creating a new storage volume.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VolumeModel]
    """
    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CreateVolumeRequest,
) -> HTTPValidationError | VolumeModel | None:
    """Create Volume

     Creates a new storage volume.

    Args:
        user_info: Authenticated user information.
        body: Request body containing volume creation details (size, region, etc).

    Returns:
        VolumeModel: The created volume model.

    Raises:
        HTTPException: If user unauthorized or creation fails.

    Args:
        body (CreateVolumeRequest): Request model for creating a new storage volume.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VolumeModel
    """
    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateVolumeRequest,
) -> Response[HTTPValidationError | VolumeModel]:
    """Create Volume

     Creates a new storage volume.

    Args:
        user_info: Authenticated user information.
        body: Request body containing volume creation details (size, region, etc).

    Returns:
        VolumeModel: The created volume model.

    Raises:
        HTTPException: If user unauthorized or creation fails.

    Args:
        body (CreateVolumeRequest): Request model for creating a new storage volume.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VolumeModel]
    """
    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateVolumeRequest,
) -> HTTPValidationError | VolumeModel | None:
    """Create Volume

     Creates a new storage volume.

    Args:
        user_info: Authenticated user information.
        body: Request body containing volume creation details (size, region, etc).

    Returns:
        VolumeModel: The created volume model.

    Raises:
        HTTPException: If user unauthorized or creation fails.

    Args:
        body (CreateVolumeRequest): Request model for creating a new storage volume.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VolumeModel
    """
    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
