from __future__ import annotations

from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_bids_response import GetBidsResponse
from ...models.get_bids_v2_spot_bids_get_sort_by import GetBidsV2SpotBidsGetSortBy
from ...models.get_bids_v2_spot_bids_get_status import GetBidsV2SpotBidsGetStatus
from ...models.http_validation_error import HTTPValidationError
from ...models.sort_direction import SortDirection
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    next_cursor: Any | Unset = UNSET,
    sort_by: GetBidsV2SpotBidsGetSortBy | Unset = UNSET,
    sort_dir: SortDirection | Unset = UNSET,
    project: None | str | Unset = UNSET,
    instance_type: None | str | Unset = UNSET,
    region: None | str | Unset = UNSET,
    status: GetBidsV2SpotBidsGetStatus | Unset = UNSET,
    name: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["next_cursor"] = next_cursor

    json_sort_by: str | Unset = UNSET
    if not isinstance(sort_by, Unset):
        json_sort_by = sort_by.value

    params["sort_by"] = json_sort_by

    json_sort_dir: str | Unset = UNSET
    if not isinstance(sort_dir, Unset):
        json_sort_dir = sort_dir.value

    params["sort_dir"] = json_sort_dir

    json_project: None | str | Unset
    if isinstance(project, Unset):
        json_project = UNSET
    else:
        json_project = project
    params["project"] = json_project

    json_instance_type: None | str | Unset
    if isinstance(instance_type, Unset):
        json_instance_type = UNSET
    else:
        json_instance_type = instance_type
    params["instance_type"] = json_instance_type

    json_region: None | str | Unset
    if isinstance(region, Unset):
        json_region = UNSET
    else:
        json_region = region
    params["region"] = json_region

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_name: None | str | Unset
    if isinstance(name, Unset):
        json_name = UNSET
    else:
        json_name = name
    params["name"] = json_name

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/spot/bids",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetBidsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = GetBidsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetBidsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    next_cursor: Any | Unset = UNSET,
    sort_by: GetBidsV2SpotBidsGetSortBy | Unset = UNSET,
    sort_dir: SortDirection | Unset = UNSET,
    project: None | str | Unset = UNSET,
    instance_type: None | str | Unset = UNSET,
    region: None | str | Unset = UNSET,
    status: GetBidsV2SpotBidsGetStatus | Unset = UNSET,
    name: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[GetBidsResponse | HTTPValidationError]:
    """Get Bids

     Get all Spot bids for a project, or all user's projects if not specified

    Args:
        next_cursor (Any | Unset):
        sort_by (GetBidsV2SpotBidsGetSortBy | Unset):
        sort_dir (SortDirection | Unset):
        project (None | str | Unset):
        instance_type (None | str | Unset):
        region (None | str | Unset):
        status (GetBidsV2SpotBidsGetStatus | Unset):
        name (None | str | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetBidsResponse | HTTPValidationError]
    """
    kwargs = _get_kwargs(
        next_cursor=next_cursor,
        sort_by=sort_by,
        sort_dir=sort_dir,
        project=project,
        instance_type=instance_type,
        region=region,
        status=status,
        name=name,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    next_cursor: Any | Unset = UNSET,
    sort_by: GetBidsV2SpotBidsGetSortBy | Unset = UNSET,
    sort_dir: SortDirection | Unset = UNSET,
    project: None | str | Unset = UNSET,
    instance_type: None | str | Unset = UNSET,
    region: None | str | Unset = UNSET,
    status: GetBidsV2SpotBidsGetStatus | Unset = UNSET,
    name: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> GetBidsResponse | HTTPValidationError | None:
    """Get Bids

     Get all Spot bids for a project, or all user's projects if not specified

    Args:
        next_cursor (Any | Unset):
        sort_by (GetBidsV2SpotBidsGetSortBy | Unset):
        sort_dir (SortDirection | Unset):
        project (None | str | Unset):
        instance_type (None | str | Unset):
        region (None | str | Unset):
        status (GetBidsV2SpotBidsGetStatus | Unset):
        name (None | str | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetBidsResponse | HTTPValidationError
    """
    return sync_detailed(
        client=client,
        next_cursor=next_cursor,
        sort_by=sort_by,
        sort_dir=sort_dir,
        project=project,
        instance_type=instance_type,
        region=region,
        status=status,
        name=name,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    next_cursor: Any | Unset = UNSET,
    sort_by: GetBidsV2SpotBidsGetSortBy | Unset = UNSET,
    sort_dir: SortDirection | Unset = UNSET,
    project: None | str | Unset = UNSET,
    instance_type: None | str | Unset = UNSET,
    region: None | str | Unset = UNSET,
    status: GetBidsV2SpotBidsGetStatus | Unset = UNSET,
    name: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[GetBidsResponse | HTTPValidationError]:
    """Get Bids

     Get all Spot bids for a project, or all user's projects if not specified

    Args:
        next_cursor (Any | Unset):
        sort_by (GetBidsV2SpotBidsGetSortBy | Unset):
        sort_dir (SortDirection | Unset):
        project (None | str | Unset):
        instance_type (None | str | Unset):
        region (None | str | Unset):
        status (GetBidsV2SpotBidsGetStatus | Unset):
        name (None | str | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetBidsResponse | HTTPValidationError]
    """
    kwargs = _get_kwargs(
        next_cursor=next_cursor,
        sort_by=sort_by,
        sort_dir=sort_dir,
        project=project,
        instance_type=instance_type,
        region=region,
        status=status,
        name=name,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    next_cursor: Any | Unset = UNSET,
    sort_by: GetBidsV2SpotBidsGetSortBy | Unset = UNSET,
    sort_dir: SortDirection | Unset = UNSET,
    project: None | str | Unset = UNSET,
    instance_type: None | str | Unset = UNSET,
    region: None | str | Unset = UNSET,
    status: GetBidsV2SpotBidsGetStatus | Unset = UNSET,
    name: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> GetBidsResponse | HTTPValidationError | None:
    """Get Bids

     Get all Spot bids for a project, or all user's projects if not specified

    Args:
        next_cursor (Any | Unset):
        sort_by (GetBidsV2SpotBidsGetSortBy | Unset):
        sort_dir (SortDirection | Unset):
        project (None | str | Unset):
        instance_type (None | str | Unset):
        region (None | str | Unset):
        status (GetBidsV2SpotBidsGetStatus | Unset):
        name (None | str | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetBidsResponse | HTTPValidationError
    """
    return (
        await asyncio_detailed(
            client=client,
            next_cursor=next_cursor,
            sort_by=sort_by,
            sort_dir=sort_dir,
            project=project,
            instance_type=instance_type,
            region=region,
            status=status,
            name=name,
            limit=limit,
        )
    ).parsed
