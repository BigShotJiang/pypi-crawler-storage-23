from __future__ import annotations

from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.update_volume_request import UpdateVolumeRequest
from ...models.volume_model import VolumeModel
from ...types import Response


def _get_kwargs(
    volume_fid: str,
    *,
    body: UpdateVolumeRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/volumes/{volume_fid}".format(
            volume_fid=quote(str(volume_fid), safe="")
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VolumeModel | None:
    if response.status_code == 200:
        response_200 = VolumeModel.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VolumeModel]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    volume_fid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateVolumeRequest,
) -> Response[HTTPValidationError | VolumeModel]:
    """Update Volume

     Updates a storage volume's mutable properties (e.g., name).

    Args:
        user_info: Authenticated user information.
        volume_fid: Identifier of the volume to update.
        body: Request body containing updated fields.

    Returns:
        VolumeModel: The updated volume model.

    Raises:
        HTTPException: If volume not found or user unauthorized.

    Args:
        volume_fid (str):
        body (UpdateVolumeRequest): Request model for updating an existing storage volume.

    Attributes:
                name: New name for the volume. Must follow naming conventions.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VolumeModel]
    """
    kwargs = _get_kwargs(
        volume_fid=volume_fid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    volume_fid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateVolumeRequest,
) -> HTTPValidationError | VolumeModel | None:
    """Update Volume

     Updates a storage volume's mutable properties (e.g., name).

    Args:
        user_info: Authenticated user information.
        volume_fid: Identifier of the volume to update.
        body: Request body containing updated fields.

    Returns:
        VolumeModel: The updated volume model.

    Raises:
        HTTPException: If volume not found or user unauthorized.

    Args:
        volume_fid (str):
        body (UpdateVolumeRequest): Request model for updating an existing storage volume.

    Attributes:
                name: New name for the volume. Must follow naming conventions.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VolumeModel
    """
    return sync_detailed(
        volume_fid=volume_fid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    volume_fid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateVolumeRequest,
) -> Response[HTTPValidationError | VolumeModel]:
    """Update Volume

     Updates a storage volume's mutable properties (e.g., name).

    Args:
        user_info: Authenticated user information.
        volume_fid: Identifier of the volume to update.
        body: Request body containing updated fields.

    Returns:
        VolumeModel: The updated volume model.

    Raises:
        HTTPException: If volume not found or user unauthorized.

    Args:
        volume_fid (str):
        body (UpdateVolumeRequest): Request model for updating an existing storage volume.

    Attributes:
                name: New name for the volume. Must follow naming conventions.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VolumeModel]
    """
    kwargs = _get_kwargs(
        volume_fid=volume_fid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    volume_fid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateVolumeRequest,
) -> HTTPValidationError | VolumeModel | None:
    """Update Volume

     Updates a storage volume's mutable properties (e.g., name).

    Args:
        user_info: Authenticated user information.
        volume_fid: Identifier of the volume to update.
        body: Request body containing updated fields.

    Returns:
        VolumeModel: The updated volume model.

    Raises:
        HTTPException: If volume not found or user unauthorized.

    Args:
        volume_fid (str):
        body (UpdateVolumeRequest): Request model for updating an existing storage volume.

    Attributes:
                name: New name for the volume. Must follow naming conventions.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VolumeModel
    """
    return (
        await asyncio_detailed(
            volume_fid=volume_fid,
            client=client,
            body=body,
        )
    ).parsed
