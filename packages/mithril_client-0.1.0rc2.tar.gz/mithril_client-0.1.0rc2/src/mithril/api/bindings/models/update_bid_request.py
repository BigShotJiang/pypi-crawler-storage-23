from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Self, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateBidRequest")


@_attrs_define
class UpdateBidRequest:
    """Attributes:
    limit_price (None | str | Unset):
    paused (bool | None | Unset):
    volumes (list[str] | None | Unset):
    memory_gb (int | None | Unset):
    """

    limit_price: None | str | Unset = UNSET
    paused: bool | None | Unset = UNSET
    volumes: list[str] | None | Unset = UNSET
    memory_gb: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        limit_price: None | str | Unset
        if isinstance(self.limit_price, Unset):
            limit_price = UNSET
        else:
            limit_price = self.limit_price

        paused: bool | None | Unset
        if isinstance(self.paused, Unset):
            paused = UNSET
        else:
            paused = self.paused

        volumes: list[str] | None | Unset
        if isinstance(self.volumes, Unset):
            volumes = UNSET
        elif isinstance(self.volumes, list):
            volumes = self.volumes

        else:
            volumes = self.volumes

        memory_gb: int | None | Unset
        if isinstance(self.memory_gb, Unset):
            memory_gb = UNSET
        else:
            memory_gb = self.memory_gb

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if limit_price is not UNSET:
            field_dict["limit_price"] = limit_price
        if paused is not UNSET:
            field_dict["paused"] = paused
        if volumes is not UNSET:
            field_dict["volumes"] = volumes
        if memory_gb is not UNSET:
            field_dict["memory_gb"] = memory_gb

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_limit_price(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        limit_price = _parse_limit_price(d.pop("limit_price", UNSET))

        def _parse_paused(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        paused = _parse_paused(d.pop("paused", UNSET))

        def _parse_volumes(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError
                volumes_type_0 = cast(list[str], data)

                return volumes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        volumes = _parse_volumes(d.pop("volumes", UNSET))

        def _parse_memory_gb(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        memory_gb = _parse_memory_gb(d.pop("memory_gb", UNSET))

        update_bid_request = cls(
            limit_price=limit_price,
            paused=paused,
            volumes=volumes,
            memory_gb=memory_gb,
        )

        update_bid_request.additional_properties = d
        return update_bid_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
