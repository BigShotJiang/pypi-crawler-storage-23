from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Self, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_kubernetes_cluster_request_k8s_version import (
    CreateKubernetesClusterRequestK8SVersion,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateKubernetesClusterRequest")


@_attrs_define
class CreateKubernetesClusterRequest:
    """Attributes:
    name (str):
    project (str):
    region (str):
    ssh_keys (list[str]):
    instance_type (str):
    k8s_version (CreateKubernetesClusterRequestK8SVersion | Unset):  Default:
        CreateKubernetesClusterRequestK8SVersion.VALUE_0.
    image_version (None | str | Unset):
    """

    name: str
    project: str
    region: str
    ssh_keys: list[str]
    instance_type: str
    k8s_version: CreateKubernetesClusterRequestK8SVersion | Unset = (
        CreateKubernetesClusterRequestK8SVersion.VALUE_0
    )
    image_version: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        project = self.project

        region = self.region

        ssh_keys = self.ssh_keys

        instance_type = self.instance_type

        k8s_version: str | Unset = UNSET
        if not isinstance(self.k8s_version, Unset):
            k8s_version = self.k8s_version.value

        image_version: None | str | Unset
        if isinstance(self.image_version, Unset):
            image_version = UNSET
        else:
            image_version = self.image_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "project": project,
                "region": region,
                "ssh_keys": ssh_keys,
                "instance_type": instance_type,
            }
        )
        if k8s_version is not UNSET:
            field_dict["k8s_version"] = k8s_version
        if image_version is not UNSET:
            field_dict["image_version"] = image_version

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)
        name = d.pop("name")

        project = d.pop("project")

        region = d.pop("region")

        ssh_keys = cast(list[str], d.pop("ssh_keys"))

        instance_type = d.pop("instance_type")

        _k8s_version = d.pop("k8s_version", UNSET)
        k8s_version: CreateKubernetesClusterRequestK8SVersion | Unset
        if isinstance(_k8s_version, Unset):
            k8s_version = UNSET
        else:
            k8s_version = CreateKubernetesClusterRequestK8SVersion(_k8s_version)

        def _parse_image_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        image_version = _parse_image_version(d.pop("image_version", UNSET))

        create_kubernetes_cluster_request = cls(
            name=name,
            project=project,
            region=region,
            ssh_keys=ssh_keys,
            instance_type=instance_type,
            k8s_version=k8s_version,
            image_version=image_version,
        )

        create_kubernetes_cluster_request.additional_properties = d
        return create_kubernetes_cluster_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
