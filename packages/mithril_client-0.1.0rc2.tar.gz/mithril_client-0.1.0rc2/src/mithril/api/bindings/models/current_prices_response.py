from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Self, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CurrentPricesResponse")


@_attrs_define
class CurrentPricesResponse:
    """Attributes:
    spot_price_cents (int | None | Unset):
    reserved_price_cents (int | None | Unset):
    minimum_price_cents (int | None | Unset):
    lowest_allocated_bid_cents (int | None | Unset):
    dynamic_win_price_cents (int | None | Unset):
    available_capacity (int | None | Unset):
    total_capacity (int | None | Unset):
    """

    spot_price_cents: int | None | Unset = UNSET
    reserved_price_cents: int | None | Unset = UNSET
    minimum_price_cents: int | None | Unset = UNSET
    lowest_allocated_bid_cents: int | None | Unset = UNSET
    dynamic_win_price_cents: int | None | Unset = UNSET
    available_capacity: int | None | Unset = UNSET
    total_capacity: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        spot_price_cents: int | None | Unset
        if isinstance(self.spot_price_cents, Unset):
            spot_price_cents = UNSET
        else:
            spot_price_cents = self.spot_price_cents

        reserved_price_cents: int | None | Unset
        if isinstance(self.reserved_price_cents, Unset):
            reserved_price_cents = UNSET
        else:
            reserved_price_cents = self.reserved_price_cents

        minimum_price_cents: int | None | Unset
        if isinstance(self.minimum_price_cents, Unset):
            minimum_price_cents = UNSET
        else:
            minimum_price_cents = self.minimum_price_cents

        lowest_allocated_bid_cents: int | None | Unset
        if isinstance(self.lowest_allocated_bid_cents, Unset):
            lowest_allocated_bid_cents = UNSET
        else:
            lowest_allocated_bid_cents = self.lowest_allocated_bid_cents

        dynamic_win_price_cents: int | None | Unset
        if isinstance(self.dynamic_win_price_cents, Unset):
            dynamic_win_price_cents = UNSET
        else:
            dynamic_win_price_cents = self.dynamic_win_price_cents

        available_capacity: int | None | Unset
        if isinstance(self.available_capacity, Unset):
            available_capacity = UNSET
        else:
            available_capacity = self.available_capacity

        total_capacity: int | None | Unset
        if isinstance(self.total_capacity, Unset):
            total_capacity = UNSET
        else:
            total_capacity = self.total_capacity

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if spot_price_cents is not UNSET:
            field_dict["spot_price_cents"] = spot_price_cents
        if reserved_price_cents is not UNSET:
            field_dict["reserved_price_cents"] = reserved_price_cents
        if minimum_price_cents is not UNSET:
            field_dict["minimum_price_cents"] = minimum_price_cents
        if lowest_allocated_bid_cents is not UNSET:
            field_dict["lowest_allocated_bid_cents"] = lowest_allocated_bid_cents
        if dynamic_win_price_cents is not UNSET:
            field_dict["dynamic_win_price_cents"] = dynamic_win_price_cents
        if available_capacity is not UNSET:
            field_dict["available_capacity"] = available_capacity
        if total_capacity is not UNSET:
            field_dict["total_capacity"] = total_capacity

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        d = dict(src_dict)

        def _parse_spot_price_cents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        spot_price_cents = _parse_spot_price_cents(d.pop("spot_price_cents", UNSET))

        def _parse_reserved_price_cents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        reserved_price_cents = _parse_reserved_price_cents(
            d.pop("reserved_price_cents", UNSET)
        )

        def _parse_minimum_price_cents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        minimum_price_cents = _parse_minimum_price_cents(
            d.pop("minimum_price_cents", UNSET)
        )

        def _parse_lowest_allocated_bid_cents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        lowest_allocated_bid_cents = _parse_lowest_allocated_bid_cents(
            d.pop("lowest_allocated_bid_cents", UNSET)
        )

        def _parse_dynamic_win_price_cents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        dynamic_win_price_cents = _parse_dynamic_win_price_cents(
            d.pop("dynamic_win_price_cents", UNSET)
        )

        def _parse_available_capacity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        available_capacity = _parse_available_capacity(
            d.pop("available_capacity", UNSET)
        )

        def _parse_total_capacity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_capacity = _parse_total_capacity(d.pop("total_capacity", UNSET))

        current_prices_response = cls(
            spot_price_cents=spot_price_cents,
            reserved_price_cents=reserved_price_cents,
            minimum_price_cents=minimum_price_cents,
            lowest_allocated_bid_cents=lowest_allocated_bid_cents,
            dynamic_win_price_cents=dynamic_win_price_cents,
            available_capacity=available_capacity,
            total_capacity=total_capacity,
        )

        current_prices_response.additional_properties = d
        return current_prices_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
