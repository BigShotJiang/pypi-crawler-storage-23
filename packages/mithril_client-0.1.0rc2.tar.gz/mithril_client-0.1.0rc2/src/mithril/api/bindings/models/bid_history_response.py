from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Self, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.bid_history_event_model import BidHistoryEventModel


T = TypeVar("T", bound="BidHistoryResponse")


@_attrs_define
class BidHistoryResponse:
    """Response model for bid history.

    Attributes:
        bid_fid (str):
        events (list[BidHistoryEventModel]): List of historical events for this bid, ordered by timestamp
    """

    bid_fid: str
    events: list[BidHistoryEventModel]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bid_fid = self.bid_fid

        events = []
        for events_item_data in self.events:
            events_item = events_item_data.to_dict()
            events.append(events_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bid_fid": bid_fid,
                "events": events,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls, src_dict: Mapping[str, Any]) -> Self:
        from ..models.bid_history_event_model import BidHistoryEventModel

        d = dict(src_dict)
        bid_fid = d.pop("bid_fid")

        events = []
        _events = d.pop("events")
        for events_item_data in _events:
            events_item = BidHistoryEventModel.from_dict(events_item_data)

            events.append(events_item)

        bid_history_response = cls(
            bid_fid=bid_fid,
            events=events,
        )

        bid_history_response.additional_properties = d
        return bid_history_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
