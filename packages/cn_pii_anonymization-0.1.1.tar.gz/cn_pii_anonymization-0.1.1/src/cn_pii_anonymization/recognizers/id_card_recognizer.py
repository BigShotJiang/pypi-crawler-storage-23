"""
中国大陆身份证识别器

识别中国大陆身份证号码，支持校验码验证。
"""

import re
from datetime import datetime
from typing import Any, ClassVar

from presidio_analyzer import RecognizerResult
from presidio_analyzer.nlp_engine import NlpArtifacts

from cn_pii_anonymization.recognizers.base import CNPIIRecognizer
from cn_pii_anonymization.utils.logger import get_logger

logger = get_logger(__name__)


class CNIDCardRecognizer(CNPIIRecognizer):
    """
    中国大陆身份证识别器

    识别中国大陆18位身份证号码，支持：
    - 地区码验证
    - 出生日期验证
    - 校验码验证
    - OCR错误容错（19位数字时尝试移除多余字符）

    Attributes:
        ID_CARD_PATTERN: 身份证匹配正则（18位）
        ID_CARD_OCR_ERROR_PATTERN: OCR错误容错正则（19位）
        CONTEXT_WORDS: 上下文关键词列表
        PROVINCE_CODES: 省份代码映射

    Example:
        >>> recognizer = CNIDCardRecognizer()
        >>> results = recognizer.analyze(
        ...     "身份证号110101199001011234",
        ...     ["CN_ID_CARD"],
        ...     None
        ... )
    """

    ID_CARD_PATTERN: ClassVar[re.Pattern[str]] = re.compile(
        r"(?<![a-zA-Z\d])[1-9](?:\s*\d){17}(?![a-zA-Z\d])"
    )

    ID_CARD_OCR_ERROR_PATTERN: ClassVar[re.Pattern[str]] = re.compile(
        r"(?<![a-zA-Z\d])[1-9](?:\s*\d){18}(?![a-zA-Z\d])"
    )

    CONTEXT_WORDS: ClassVar[list[str]] = [
        "身份证",
        "身份证号",
        "证件号",
        "身份号码",
        "ID",
        "身份证件",
        "公民身份",
        "身份证号码",
        "身份证明",
        "居民身份证",
    ]

    PROVINCE_CODES: ClassVar[dict[int, str]] = {
        11: "北京",
        12: "天津",
        13: "河北",
        14: "山西",
        15: "内蒙古",
        21: "辽宁",
        22: "吉林",
        23: "黑龙江",
        31: "上海",
        32: "江苏",
        33: "浙江",
        34: "安徽",
        35: "福建",
        36: "江西",
        37: "山东",
        41: "河南",
        42: "湖北",
        43: "湖南",
        44: "广东",
        45: "广西",
        46: "海南",
        50: "重庆",
        51: "四川",
        52: "贵州",
        53: "云南",
        54: "西藏",
        61: "陕西",
        62: "甘肃",
        63: "青海",
        64: "宁夏",
        65: "新疆",
        71: "台湾",
        81: "香港",
        82: "澳门",
    }

    def __init__(self, **kwargs: Any) -> None:
        """
        初始化身份证识别器

        Args:
            **kwargs: 其他参数传递给父类
        """
        super().__init__(
            supported_entities=["CN_ID_CARD"],
            name="CN ID Card Recognizer",
            context=self.CONTEXT_WORDS,
            **kwargs,
        )

    def analyze(
        self,
        text: str,
        entities: list[str],
        nlp_artifacts: NlpArtifacts | None,
    ) -> list[RecognizerResult]:
        """
        分析文本中的身份证号

        支持OCR错误容错：当匹配到19位数字时，尝试移除一位数字
        得到有效的18位身份证号。

        Args:
            text: 待分析的文本
            entities: 要识别的实体类型列表
            nlp_artifacts: NLP处理结果

        Returns:
            识别结果列表
        """
        results = []

        for match in self.ID_CARD_PATTERN.finditer(text):
            id_card = match.group()
            if self._validate_id_card(id_card):
                result = self._create_result(
                    entity_type="CN_ID_CARD",
                    start=match.start(),
                    end=match.end(),
                    score=0.95,
                )
                results.append(result)
            else:
                logger.debug(f"无效身份证号被过滤: {id_card}")

        ocr_error_results = self._handle_ocr_errors(text)
        results.extend(ocr_error_results)

        return results

    def _handle_ocr_errors(self, text: str) -> list[RecognizerResult]:
        """
        处理OCR识别错误的情况

        当OCR将身份证号识别为19位数字时（多了一位），
        尝试移除每一位数字，检查是否能得到有效的18位身份证号。

        Args:
            text: 待分析的文本

        Returns:
            识别结果列表
        """
        results = []

        for match in self.ID_CARD_OCR_ERROR_PATTERN.finditer(text):
            ocr_text = match.group()
            ocr_text_clean = ocr_text.replace(" ", "")

            if len(ocr_text_clean) != 19:
                continue

            valid_id_card = self._try_fix_ocr_error(ocr_text_clean)
            if valid_id_card:
                logger.info(f"OCR错误容错: 从 '{ocr_text_clean}' 修复为 '{valid_id_card}'")
                result = self._create_result(
                    entity_type="CN_ID_CARD",
                    start=match.start(),
                    end=match.end(),
                    score=0.90,
                )
                results.append(result)
            else:
                logger.debug(f"无法修复OCR错误: {ocr_text_clean}")

        return results

    def _try_fix_ocr_error(self, ocr_text: str) -> str | None:
        """
        尝试修复OCR错误

        移除19位数字中的每一位，检查是否能得到有效的18位身份证号。
        优先检查常见错误位置（如第7位，即出生年份开头）。

        Args:
            ocr_text: 19位数字字符串

        Returns:
            修复后的18位身份证号，如果无法修复则返回None
        """
        if len(ocr_text) != 19:
            return None

        priority_positions = [6, 7, 8, 0, 1, 2, 3, 4, 5, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]

        for pos in priority_positions:
            if pos >= len(ocr_text):
                continue
            candidate = ocr_text[:pos] + ocr_text[pos + 1 :]
            if self._validate_id_card(candidate):
                return candidate

        return None

    def _validate_id_card(self, id_card: str) -> bool:
        """
        验证身份证号有效性

        Args:
            id_card: 身份证号字符串（可能包含空格）

        Returns:
            是否为有效的身份证号
        """
        # 去除空格后再验证
        id_card = id_card.replace(" ", "")

        if len(id_card) != 18:
            return False

        province_code = int(id_card[:2])
        if province_code not in self.PROVINCE_CODES:
            return False

        if not self._validate_birth_date(id_card[6:14]):
            return False

        return self._validate_check_digit(id_card)

    @staticmethod
    def _validate_birth_date(date_str: str) -> bool:
        """
        验证出生日期

        Args:
            date_str: 8位日期字符串 (YYYYMMDD)

        Returns:
            是否为有效的日期
        """
        try:
            year = int(date_str[:4])
            month = int(date_str[4:6])
            day = int(date_str[6:8])

            if year < 1900 or year > datetime.now().year:
                return False

            birth_date = datetime(year, month, day)

            return birth_date <= datetime.now()
        except ValueError:
            return False

    @staticmethod
    def _validate_check_digit(id_card: str) -> bool:
        """
        验证校验码

        使用GB 11643-1999标准计算校验码。

        Args:
            id_card: 身份证号字符串

        Returns:
            校验码是否正确
        """
        weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        check_codes = "10X98765432"

        total = sum(int(id_card[i]) * weights[i] for i in range(17))

        expected_check = check_codes[total % 11]
        return id_card[17].upper() == expected_check
