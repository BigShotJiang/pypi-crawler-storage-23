from kplot.axes import access_subplots, subplots
from kplot.cmaps import manoaskies, manoaskies_centered
from kplot.hist import hist
from kplot.image import show 
from kplot.plot import plot, diffplot, powerlawplot
from kplot.utils import alias_kwarg, column_width, two_column_width
from kplot.movie import func_video, show_video, line_video, lines_video, show_video_function, line_video_function
