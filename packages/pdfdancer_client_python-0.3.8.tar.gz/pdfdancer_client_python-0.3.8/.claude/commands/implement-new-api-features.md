Check the updates in  docs/api-schemas (use diff).
Analyze which new features are available in the api. Ignore anything backoffice related, like tenant management, api keys management or similar.
We are interested in PDF features.
For each change you encounter:
- analyze the current implementation and tests
- make a plan how to fully support the new api feature including e2e tests
- Show me a brief summary of what you found and what your plan is
- Wait for my approval
