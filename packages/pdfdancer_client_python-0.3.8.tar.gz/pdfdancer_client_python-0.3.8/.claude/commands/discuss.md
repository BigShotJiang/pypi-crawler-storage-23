We discuss this: $ARGUMENTS.
You ask everything you need to know to completely understand what I want to know.
We discuss options, pros and cons and side effects.
You dont start to code until you have my approval.