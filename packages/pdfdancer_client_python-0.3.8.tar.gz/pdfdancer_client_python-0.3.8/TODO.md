# TODO 

- [ ] handle missing htx
- [ ] remove pydantic dep, check other deps