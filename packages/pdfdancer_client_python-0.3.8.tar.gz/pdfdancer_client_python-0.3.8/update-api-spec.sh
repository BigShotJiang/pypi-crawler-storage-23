#!/bin/sh

wget -O docs/api-schemas/v0.yml https://bucket.pdfdancer.com/api-doc/v0.yml
wget -O docs/api-schemas/v1.yml https://bucket.pdfdancer.com/api-doc/v1.yml

