"""Unit tests for MCP tool definitions."""

from __future__ import annotations

import pytest

from gfp_mcp.tools import (
    TOOL_HANDLERS,
    get_all_tools,
    get_handler,
    get_tool_by_name,
)


def test_get_all_tools() -> None:
    """Test getting all tools."""
    tools = get_all_tools()
    assert isinstance(tools, list)
    assert (
        len(tools) >= 11
    )  # 2 project + 3 core + 3 verification + 1 advanced + 2 sample tools


def test_core_tools_exist() -> None:
    """Test that all core tools are defined."""
    expected_tools = [
        "build_cells",
        "list_cells",
        "get_cell_info",
    ]
    for expected in expected_tools:
        handler = get_handler(expected)
        assert handler is not None, f"Handler '{expected}' not found"


def test_get_tool_by_name() -> None:
    """Test getting a tool by name."""
    tool = get_tool_by_name("build_cells")
    assert tool is not None
    assert tool.name == "build_cells"
    assert tool.description
    assert tool.inputSchema

    tool = get_tool_by_name("nonexistent_tool")
    assert tool is None


def test_tool_schemas() -> None:
    """Test that all tools have valid input schemas."""
    tools = get_all_tools()
    for tool in tools:
        assert tool.name
        assert tool.description
        assert tool.inputSchema
        assert "type" in tool.inputSchema
        assert tool.inputSchema["type"] == "object"
        assert "properties" in tool.inputSchema


def test_build_cells_schema() -> None:
    """Test build_cells tool schema."""
    tool = get_tool_by_name("build_cells")
    assert tool is not None

    schema = tool.inputSchema
    assert "names" in schema["properties"]
    assert "names" in schema["required"]
    assert schema["properties"]["names"]["type"] == "array"

    assert "visualize" in schema["properties"]
    assert schema["properties"]["visualize"]["type"] == "array"
    assert "visualize" not in schema.get("required", [])


def test_list_cells_schema() -> None:
    """Test list_cells tool schema."""
    tool = get_tool_by_name("list_cells")
    assert tool is not None

    schema = tool.inputSchema
    assert "properties" in schema


def test_get_cell_info_schema() -> None:
    """Test get_cell_info tool schema."""
    tool = get_tool_by_name("get_cell_info")
    assert tool is not None

    schema = tool.inputSchema
    assert "name" in schema["properties"]
    assert "name" in schema["required"]


def test_all_tools_unique_names() -> None:
    """Test that all tools have unique names."""
    tools = get_all_tools()
    tool_names = [tool.name for tool in tools]
    assert len(tool_names) == len(set(tool_names)), "Tool names are not unique"


def test_verification_tools_exist() -> None:
    """Test that all verification tools are defined."""
    expected_tools = [
        "check_drc",
        "check_connectivity",
        "check_lvs",
    ]
    for expected in expected_tools:
        handler = get_handler(expected)
        assert handler is not None, f"Handler '{expected}' not found"


def test_check_connectivity_schema() -> None:
    """Test check_connectivity tool schema."""
    tool = get_tool_by_name("check_connectivity")
    assert tool is not None

    schema = tool.inputSchema
    assert "path" in schema["properties"]
    assert "path" in schema["required"]


def test_check_lvs_schema() -> None:
    """Test check_lvs tool schema."""
    tool = get_tool_by_name("check_lvs")
    assert tool is not None

    schema = tool.inputSchema
    assert "cell" in schema["properties"]
    assert "netpath" in schema["properties"]
    assert "cellargs" in schema["properties"]
    assert "cell" in schema["required"]
    assert "netpath" in schema["required"]


def test_check_drc_schema() -> None:
    """Test check_drc tool schema."""
    tool = get_tool_by_name("check_drc")
    assert tool is not None

    schema = tool.inputSchema
    assert "path" in schema["properties"]
    assert "pdk" in schema["properties"]
    assert "process" in schema["properties"]
    assert "timeout" in schema["properties"]
    assert "host" in schema["properties"]
    assert "path" in schema["required"]
    assert "pdk" not in schema.get("required", [])
    assert "process" not in schema.get("required", [])


def test_advanced_tools_exist() -> None:
    """Test that all active advanced tools are defined."""
    expected_tools = [
        "simulate_component",
    ]
    for expected in expected_tools:
        handler = get_handler(expected)
        assert handler is not None, f"Handler '{expected}' not found"


def test_simulate_component_schema() -> None:
    """Test simulate_component tool schema."""
    tool = get_tool_by_name("simulate_component")
    assert tool is not None

    schema = tool.inputSchema
    props = schema["properties"]

    assert "name" in props
    assert props["name"]["type"] == "string"

    assert "layout" in props
    assert props["layout"]["type"] == "object"

    assert "model" in props
    assert props["model"]["type"] == "object"

    assert "how" in props
    assert props["how"]["type"] == "string"
    assert props["how"]["enum"] == ["from_layout", "from_netlist"]

    assert schema["required"] == ["name"]


def test_tool_handlers_registry() -> None:
    """Test that TOOL_HANDLERS contains all expected handlers."""
    assert isinstance(TOOL_HANDLERS, dict)
    assert len(TOOL_HANDLERS) >= 11

    # Verify all handlers have correct names
    for name, handler in TOOL_HANDLERS.items():
        assert handler.name == name
        assert handler.definition is not None
        assert handler.definition.name == name


def test_get_handler() -> None:
    """Test get_handler function."""
    handler = get_handler("build_cells")
    assert handler is not None
    assert handler.name == "build_cells"

    handler = get_handler("nonexistent_tool")
    assert handler is None


def test_project_tools_exist() -> None:
    """Test that project discovery tools are defined."""
    expected_tools = [
        "list_projects",
        "get_project_info",
    ]
    for expected in expected_tools:
        handler = get_handler(expected)
        assert handler is not None, f"Handler '{expected}' not found"


def test_list_projects_no_mapping() -> None:
    """Test that list_projects has no endpoint mapping (registry-only)."""
    handler = get_handler("list_projects")
    assert handler is not None
    assert handler.mapping is None  # Registry-only tool


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
