"""MCP resource definitions for GDSFactory+.

This module defines the MCP resources that are exposed to AI assistants.
Resources provide read-only access to documentation and instruction content.
"""

from __future__ import annotations

from mcp.types import Resource

__all__ = [
    "RESOURCES",
    "get_all_resources",
    "get_resource_content",
]


RESOURCES: list[Resource] = []


RESOURCE_CONTENT: dict[str, str] = {}


def get_all_resources() -> list[Resource]:
    """Get all available MCP resources.

    Returns:
        List of all resource definitions
    """
    return RESOURCES


def get_resource_content(uri: str) -> str | None:
    """Get resource content by URI.

    Args:
        uri: Resource URI

    Returns:
        Resource content string or None if not found
    """
    return RESOURCE_CONTENT.get(uri)
