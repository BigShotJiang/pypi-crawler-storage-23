"""Port center coordinate tool handler.

This module provides the handler for getting port center coordinates
from component instances.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["GetPortCenterHandler"]


class GetPortCenterHandler(ToolHandler):
    """Handler for getting port center coordinates.

    Returns the physical coordinates (x, y) of a specific port
    in a component instance.
    """

    @property
    def name(self) -> str:
        return "get_port_center"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="get_port_center",
            description=(
                "Get the center coordinates (x, y) of a specific port in a component "
                "instance. This is useful for positioning components, routing waveguides, "
                "or analyzing layout geometry. Returns the physical coordinates in "
                "microns."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "netlist": {
                            "type": "string",
                            "description": (
                                "Name of the component/netlist containing the instance"
                            ),
                        },
                        "instance": {
                            "type": "string",
                            "description": "Name of the instance within the netlist",
                        },
                        "port": {
                            "type": "string",
                            "description": "Name of the port to get coordinates for",
                        },
                    },
                    "required": ["netlist", "instance", "port"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="GET", path="/api/port-center")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform get_port_center MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'params' key for query parameters
        """
        return {
            "params": {
                "netlist": args["netlist"],
                "instance": args["instance"],
                "port": args["port"],
            }
        }
