"""Freeze cell tool handler.

This module provides the handler for freezing parametric Python cells
as static schematic netlists.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["FreezeCellHandler"]


class FreezeCellHandler(ToolHandler):
    """Handler for freezing parametric cells.

    Converts a gdsfactory component with specific parameters into
    a fixed netlist representation in YAML format.
    """

    @property
    def name(self) -> str:
        return "freeze_cell"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="freeze_cell",
            description=(
                "Freeze a parametric Python cell as a static schematic netlist. "
                "This converts a gdsfactory component with specific parameters into "
                "a fixed netlist representation in YAML format. Useful for creating "
                "versioned snapshots of parametric designs or preparing components "
                "for simulation workflows."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "cell_name": {
                            "type": "string",
                            "description": "Name of the cell/component to freeze",
                        },
                        "kwargs": {
                            "type": "object",
                            "description": (
                                "Optional keyword arguments to pass to the component "
                                "factory. Use this to specify parameter values when "
                                "freezing the cell. Default is empty (use default params)."
                            ),
                            "default": {},
                        },
                    },
                    "required": ["cell_name"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="POST", path="/freeze/{cell_name}")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform freeze_cell MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'path' and 'json_data' for the request
        """
        cell_name = args["cell_name"]
        kwargs = args.get("kwargs", {})

        return {
            "path": f"/freeze/{cell_name}",
            "json_data": kwargs,  # httpx will JSON-encode this to a string
        }
