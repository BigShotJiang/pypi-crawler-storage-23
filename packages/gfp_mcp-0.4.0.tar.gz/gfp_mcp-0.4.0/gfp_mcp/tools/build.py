"""Build cells tool handler.

This module provides the handler for building GDS cells, including
optional PNG image rendering for visualization.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from mcp.types import ImageContent, TextContent, Tool

from ..config import MCPConfig
from ..notify import notify_show_gds
from ..render import HAS_KLAYOUT, render_built_cells
from ..utils import CellBuildStatus, wait_for_build_completion_via_api
from .base import EndpointMapping, ToolHandler, add_project_param

if TYPE_CHECKING:
    from ..client import FastAPIClient

__all__ = ["BuildCellsHandler"]

logger = logging.getLogger(__name__)


class BuildCellsHandler(ToolHandler):
    """Handler for building GDS cells.

    This handler builds one or more GDS cells and optionally renders
    specified cells to PNG images for visualization.
    """

    @property
    def name(self) -> str:
        return "build_cells"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="build_cells",
            description=(
                "Build one or more GDS cells by name. This creates the physical layout "
                "files (.gds) for photonic components. Pass a list of cell names to build. "
                "For a single cell, pass a list with one element. The tool waits for all "
                "cells to finish building before returning. "
                "Use the optional 'visualize' parameter to specify which cells should be "
                "rendered to PNG images and returned in the response."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "names": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of cell/component names to build (can be a single-item list)",
                        },
                        "visualize": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Optional list of cell names to render as PNG images. "
                                "Only cells in this list will be visualized. If not provided, "
                                "no images are returned. Use this to selectively view only "
                                "the cells you need to inspect."
                            ),
                        },
                        "with_metadata": {
                            "type": "boolean",
                            "description": (
                                "Include metadata in the GDS files (default: true)"
                            ),
                            "default": True,
                        },
                        "register": {
                            "type": "boolean",
                            "description": (
                                "Re-register the cells in the KLayout cache (default: true)"
                            ),
                            "default": True,
                        },
                    },
                    "required": ["names"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="POST", path="/api/build-cells")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform build_cells MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'params' key for query parameters and 'json_data' for body
        """
        return {
            "params": {
                "with_metadata": args.get("with_metadata", True),
                "register": args.get("register", True),
            },
            "json_data": args["names"],
        }

    @staticmethod
    def _resolve_project_path(project: str | None) -> str | None:
        """Resolve project_path from the registry."""
        from ..registry import ServerRegistry

        registry = ServerRegistry()
        if project:
            server = registry.get_server_by_project(project)
        else:
            servers = registry.list_servers()
            server = servers[0] if servers else None
        return server.project_path if server else None

    async def handle(
        self,
        arguments: dict[str, Any],
        client: FastAPIClient,
    ) -> list[TextContent | ImageContent]:
        """Build cells and optionally render images.

        Args:
            arguments: MCP tool arguments
            client: FastAPI client for making requests

        Returns:
            List of TextContent with build results and optional ImageContent
        """
        try:
            project = arguments.get("project")
            transformed = self.transform_request(arguments)

            response = await client.request(
                method=self.mapping.method,
                path=self.mapping.path,
                params=transformed.get("params"),
                json_data=transformed.get("json_data"),
                project=project,
            )

            logger.debug("Build cells result: %s", response)

            # Poll build status API for all cells
            build_results = await wait_for_build_completion_via_api(
                client, arguments["names"], project
            )

            ready = [
                name
                for name, r in build_results.items()
                if r.status == CellBuildStatus.READY
            ]
            failed = {
                name: r.error_message or "Unknown error"
                for name, r in build_results.items()
                if r.status == CellBuildStatus.FAILED
            }
            timed_out = [
                name
                for name, r in build_results.items()
                if r.status == CellBuildStatus.TIMED_OUT
            ]

            status_summary: dict = {"cells_ready": ready}
            if failed:
                status_summary["cells_failed"] = failed
            if timed_out:
                status_summary["cells_timed_out"] = timed_out

            results: list[TextContent | ImageContent] = [
                TextContent(
                    type="text",
                    text=json.dumps(
                        {"build_response": response, "build_status": status_summary},
                        indent=2,
                    ),
                )
            ]

            # Notify VS Code extension to open GDS viewer
            if MCPConfig.UI_NOTIFICATIONS and ready:
                project_path = self._resolve_project_path(project)
                if project_path:
                    await notify_show_gds(project, ready, project_path)

            # Render images if klayout is available and visualize is specified
            visualize = arguments.get("visualize", [])
            if visualize and HAS_KLAYOUT:
                results.extend(await render_built_cells(visualize, project))

            return results

        except Exception as e:
            error_msg = f"Tool execution failed: {e!s}"
            logger.exception(error_msg)
            return [
                TextContent(
                    type="text",
                    text=json.dumps({"error": error_msg}),
                )
            ]
