"""MCP tool definitions and handlers for GDSFactory+.

This package contains all tool handlers, each co-locating:
- MCP Tool definition (name, description, input schema)
- Request transformation (MCP args -> HTTP params/body)
- Response transformation (HTTP response -> MCP format)
- Execution logic (handle method)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base import (
    PROJECT_PARAM_SCHEMA,
    EndpointMapping,
    ToolHandler,
    add_project_param,
)

# Import all handlers
from .bbox import GenerateBboxHandler
from .build import BuildCellsHandler
from .cells import GetCellInfoHandler, ListCellsHandler
from .connectivity import CheckConnectivityHandler
from .drc import CheckDrcHandler
from .freeze import FreezeCellHandler
from .lvs import CheckLvsHandler
from .pdk import GetPdkInfoHandler
from .port import GetPortCenterHandler
from .project import GetProjectInfoHandler, ListProjectsHandler
from .samples import GetSampleFileHandler, ListSamplesHandler
from .simulation import SimulateComponentHandler

if TYPE_CHECKING:
    from mcp.types import Tool

__all__ = [
    # Base classes
    "EndpointMapping",
    "ToolHandler",
    # Registry and utilities
    "TOOL_HANDLERS",
    "get_all_tools",
    "get_tool_by_name",
    "get_handler",
    "PROJECT_PARAM_SCHEMA",
    "add_project_param",
    # Handler classes
    "ListProjectsHandler",
    "GetProjectInfoHandler",
    "BuildCellsHandler",
    "ListCellsHandler",
    "GetCellInfoHandler",
    "CheckDrcHandler",
    "CheckConnectivityHandler",
    "CheckLvsHandler",
    "SimulateComponentHandler",
    "GetPortCenterHandler",
    "GenerateBboxHandler",
    "FreezeCellHandler",
    "GetPdkInfoHandler",
    "ListSamplesHandler",
    "GetSampleFileHandler",
]


def _create_handler_registry() -> dict[str, ToolHandler]:
    """Create the tool handlers registry.

    Returns:
        Dict mapping tool names to handler instances
    """
    handlers = [
        # Project discovery tools
        ListProjectsHandler(),
        GetProjectInfoHandler(),
        # Core building tools
        BuildCellsHandler(),
        ListCellsHandler(),
        GetCellInfoHandler(),
        # Verification tools
        CheckDrcHandler(),
        CheckConnectivityHandler(),
        CheckLvsHandler(),
        # Advanced tools
        SimulateComponentHandler(),
        # GetPortCenterHandler(), # Commented out because so far unused.
        # GenerateBboxHandler(),
        # FreezeCellHandler(),
        # GetPdkInfoHandler(),
        # Sample project tools
        ListSamplesHandler(),
        GetSampleFileHandler(),
    ]
    return {handler.name: handler for handler in handlers}


# Tool handlers registry - each handler is keyed by its tool name for O(1) lookup
TOOL_HANDLERS: dict[str, ToolHandler] = _create_handler_registry()


def get_all_tools() -> list[Tool]:
    """Get all available MCP tools.

    Returns:
        List of Tool definitions from all registered handlers
    """
    return [handler.definition for handler in TOOL_HANDLERS.values()]


def get_tool_by_name(name: str) -> Tool | None:
    """Get a tool definition by name.

    Args:
        name: Tool name to look up

    Returns:
        Tool definition if found, None otherwise
    """
    handler = TOOL_HANDLERS.get(name)
    return handler.definition if handler else None


def get_handler(name: str) -> ToolHandler | None:
    """Get a tool handler by name.

    Args:
        name: Tool name to look up

    Returns:
        ToolHandler instance if found, None otherwise
    """
    return TOOL_HANDLERS.get(name)
