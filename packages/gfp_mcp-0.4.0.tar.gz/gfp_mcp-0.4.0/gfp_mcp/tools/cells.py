"""Cell listing and info tool handlers.

These tools provide information about available cells/components
in the current PDK.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["ListCellsHandler", "GetCellInfoHandler"]


class ListCellsHandler(ToolHandler):
    """Handler for listing all available cells/components."""

    @property
    def name(self) -> str:
        return "list_cells"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="list_cells",
            description=(
                "List all available cells/components that can be built. Returns "
                "the names of all registered component factories in the current PDK. "
                "Use this to discover what components are available before building."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {},
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="GET", path="/api/cells")

    def transform_response(self, response: Any) -> dict[str, Any]:
        """Transform list_cells response to MCP format.

        Args:
            response: FastAPI response (list of cell names)

        Returns:
            Formatted response with cell names
        """
        if isinstance(response, list):
            return {"cells": response, "count": len(response)}
        return response


class GetCellInfoHandler(ToolHandler):
    """Handler for getting detailed info about a specific cell."""

    @property
    def name(self) -> str:
        return "get_cell_info"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="get_cell_info",
            description=(
                "Get detailed information about a specific cell/component. Returns "
                "metadata including the source file, parameters, and other details "
                "about the component factory."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Name of the cell/component to get info about",
                        },
                    },
                    "required": ["name"],
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="GET", path="/api/cell-info")

    def transform_request(self, args: dict[str, Any]) -> dict[str, Any]:
        """Transform get_cell_info MCP args to FastAPI params.

        Args:
            args: MCP tool arguments

        Returns:
            Dict with 'params' key for query parameters
        """
        return {"params": {"name": args["name"]}}
