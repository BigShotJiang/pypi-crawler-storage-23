"""PDK info tool handler.

This module provides the handler for getting information about
the current PDK (Process Design Kit) in use.
"""

from __future__ import annotations

from mcp.types import Tool

from .base import EndpointMapping, ToolHandler, add_project_param

__all__ = ["GetPdkInfoHandler"]


class GetPdkInfoHandler(ToolHandler):
    """Handler for getting PDK information.

    Returns metadata including PDK name, project name, project path,
    server port, and version.
    """

    @property
    def name(self) -> str:
        return "get_pdk_info"

    @property
    def definition(self) -> Tool:
        return Tool(
            name="get_pdk_info",
            description=(
                "Get information about the current PDK (Process Design Kit) in use. "
                "Returns metadata including PDK name, project name, project path, "
                "server port, and version. Use this to verify which PDK is active "
                "and get project configuration details."
            ),
            inputSchema=add_project_param(
                {
                    "type": "object",
                    "properties": {},
                }
            ),
        )

    @property
    def mapping(self) -> EndpointMapping:
        return EndpointMapping(method="GET", path="/info")
