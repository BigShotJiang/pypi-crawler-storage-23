"""GDSFactory+ MCP Server.

This package provides a Model Context Protocol (MCP) server that exposes
GDSFactory+ operations as tools for AI assistants. The server uses STDIO
transport and proxies requests to the FastAPI backend.

Architecture:
- Tool handlers in gfp_mcp/tools/ with co-located definitions and transformers
- STDIO transport for universal compatibility
- HTTP proxy to FastAPI backend via client.py
- Multi-project routing via server registry
- Zero changes to existing FastAPI server

Usage:
    from gfp_mcp import main
    main()

Or via CLI:
    gfp-mcp-serve
"""

from __future__ import annotations

from .client import FastAPIClient
from .config import MCPConfig
from .resources import get_all_resources, get_resource_content
from .server import create_server, main, run_server
from .tools import get_all_tools, get_handler, get_tool_by_name

__all__ = [
    "__version__",
    "FastAPIClient",
    "MCPConfig",
    "create_server",
    "main",
    "run_server",
    "get_all_tools",
    "get_handler",
    "get_tool_by_name",
    "get_all_resources",
    "get_resource_content",
]

__version__ = "0.4.0"
