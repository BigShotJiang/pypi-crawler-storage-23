---
files:
- "knowledges/**/*.md"
- "playbooks/**/*.md"
- "runbooks/**/*.md"
- "../mise-tasks"
---
