---
title: Documentation Management Flow
description: >-
  Documents under the docs directory must always be kept up to date.
  If the content of the documentation becomes outdated, please update it promptly.
---
