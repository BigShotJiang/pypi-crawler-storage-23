---
chat_model: anthropic
tools_with_info:
- run
- text_file_edit
- text_file_view
---

Check the committed changes from the last release to the present,
and add any content not listed in the Unreleased section of CHANGELOG.md.
