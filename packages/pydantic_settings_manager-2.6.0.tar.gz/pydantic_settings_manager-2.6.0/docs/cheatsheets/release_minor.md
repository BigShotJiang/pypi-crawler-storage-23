---
chat_model: anthropic
tools_with_info:
- run
- text_file_edit
- text_file_view
---

Feature implementation and testing have been completed and merged into the main branch.
The updates are documented in the Unreleased section of CHANGELOG.md.

Please perform a minor release.
