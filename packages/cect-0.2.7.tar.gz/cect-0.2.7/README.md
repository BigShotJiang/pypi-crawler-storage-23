# _C. elegans_ Connectome Toolbox

**Please note: this is a <u>Work in Progress</u>! Please contact padraig -at- openworm.org if you are interested in contributing to this work.**

Information on published connectomics data related to _C. elegans_.

See live site at: https://openworm.org/ConnectomeToolbox




