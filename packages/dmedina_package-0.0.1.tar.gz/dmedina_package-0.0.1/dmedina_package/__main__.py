import sys
from dmedina_package.translator import en_es, es_en

if __name__ == "__main__":
    translatio_type = sys.argv[1]
    word = sys.argv[2]

    if translatio_type == "en_es":
        print(en_es.translate_word(word))
    elif translatio_type == "es_en":
        print(es_en.translate_word(word))
    else:
        print(f"Translation type not supported: {translatio_type}")