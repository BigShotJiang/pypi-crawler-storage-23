en_es_translator = {
    "dog": "perro",
    "house": "casa",
    "cat": "gato",
    "car": "coche",
}

def translate_word(word):
    if word not in en_es_translator:
        return "No se encuentra la palabra"
    elif word in en_es_translator:
        return en_es_translator[word]