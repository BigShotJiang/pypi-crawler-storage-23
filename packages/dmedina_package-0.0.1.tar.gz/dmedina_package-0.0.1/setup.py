from setuptools import setup, find_packages

# function to read the requirements.txt file
def read_requirements():
    with open('requirements.txt') as req:
        content = req.read()
        requirements = content.split('\n')
    return requirements

setup(
    name='dmedina-package',
    version='0.0.1',
    #packages=['dmedina_package', 'dmedina_package.translator'],
    packages=find_packages(),
    python_requires='>=3.9',
    install_requires=read_requirements()
)