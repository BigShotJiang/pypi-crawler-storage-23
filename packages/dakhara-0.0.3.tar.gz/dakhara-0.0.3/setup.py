from setuptools import setup, find_packages

setup(
    name="dakhara",
    version="0.0.3",
    author="Your Name",
    author_email="you@example.com",
    description="A simple Telegram bot library.",
    long_description="None",
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/teiebot",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=["pyTelegramBotAPI>=4.14.0", "requests>=2.31.0"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=["telegram", "bot", "teiebot"],
)
