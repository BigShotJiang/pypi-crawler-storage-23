from django.dispatch import Signal

# Fired when a payment is successfully verified
solana_payment_accepted = Signal()
