from enum import Enum


class TransactionTypeEnum(Enum):
    NATIVE = "native"
    SPL = "spl"
