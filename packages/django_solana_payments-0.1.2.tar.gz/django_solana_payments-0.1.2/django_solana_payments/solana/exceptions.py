class BaseSolanaClientException(Exception):
    """Base exception for the solana client"""

    pass
