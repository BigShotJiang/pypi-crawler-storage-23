#
# Copyright (c) 2024 - 2026 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the components of the eric-ide remote server.
"""
