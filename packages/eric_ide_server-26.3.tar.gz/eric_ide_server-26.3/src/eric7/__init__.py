#
# Copyright (c) 2003 - 2026 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the eric Python IDE.

To get more information about eric please see the
<a href="https://eric-ide.python-projects.org/index.html">eric web site</a>.
"""
