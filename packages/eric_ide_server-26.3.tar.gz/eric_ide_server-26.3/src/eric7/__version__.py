#
# Copyright (c) 2024 - 2026 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Module containing some eric-ide version information.
"""

Version = "26.3 (rev. c62f1f07d6e2)"
VersionOnly = "26.3"
