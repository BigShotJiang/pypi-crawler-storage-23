# File Vault (filevault-py)

**What does File Vault do?** Encrypts and decrypts files in place using AES-256-GCM. No new files are created; original content is overwritten and password-protected.
**How do I install it?** Run `pip install .` from the project root.
**How do I encrypt a file?** Run `filevault encrypt <filename>`.
**How do I decrypt a file?** Run `filevault decrypt <filename>`.

## CLI Command Table

| Command | Description |
|---------|-------------|
| `filevault encrypt <file>` | Encrypts a single file in place. Prompts for password twice. |
| `filevault decrypt <file>` | Decrypts a single file in place. Prompts for password once. |
| `filevault encrypt-folder` | Encrypts all supported files in the current directory. |
| `filevault decrypt-folder` | Decrypts all encrypted files in the current directory. |
| `filevault status` | Lists files in the current directory with their encryption status. |

> [!WARNING]
> **CRITICAL:** There is **NO RECOVERY** for forgotten passwords. File Vault does not store your password or a master key. If you lose the password, the data in the encrypted files is permanently lost.

## Development Setup

1. Clone the repository.
2. Create a virtual environment: `python -m venv .venv`
3. Activate the environment:
   - Windows: `.venv\Scripts\activate`
   - Unix/macOS: `source .venv/bin/activate`
4. Install in editable mode with dev dependencies: `pip install -e ".[dev]"`
5. Run tests: `pytest`
