import pytest
import os
import pathlib
from filevault.core import engine, file_detector

def test_encrypt_decrypt_lifecycle(tmp_path):
    # Setup plaintext file
    f = tmp_path / "test.txt"
    original_content = b"This is some secret content."
    f.write_bytes(original_content)
    password = "testpass123"

    # Encrypt
    engine.encrypt_file(str(f), password)
    assert f.exists()
    encrypted_content = f.read_bytes()
    assert encrypted_content != original_content
    assert encrypted_content.startswith(b"FVLT")
    assert file_detector.is_encrypted(str(f)) is True

    # Decrypt with correct password
    engine.decrypt_file(str(f), password)
    assert f.exists()
    restored_content = f.read_bytes()
    assert restored_content == original_content
    assert file_detector.is_encrypted(str(f)) is False

def test_wrong_password_fail(tmp_path):
    f = tmp_path / "test.txt"
    f.write_bytes(b"Secret data")
    password = "correctpassword"
    
    engine.encrypt_file(str(f), password)
    encrypted_bytes = f.read_bytes()

    # Wrong password attempt
    with pytest.raises(ValueError, match="Wrong password"):
        engine.decrypt_file(str(f), "wrongpassword")
    
    # Assert content unchanged
    assert f.read_bytes() == encrypted_bytes

def test_encrypt_blocked_extension(tmp_path):
    f = tmp_path / "script.py"
    original_content = b"print('hello')"
    f.write_bytes(original_content)

    with pytest.raises(ValueError, match="protected"):
        engine.encrypt_file(str(f), "somepassword")
    
    assert f.read_bytes() == original_content

def test_encrypt_already_encrypted(tmp_path):
    f = tmp_path / "test.txt"
    f.write_bytes(b"Secret data")
    password = "pass"
    
    engine.encrypt_file(str(f), password)
    
    with pytest.raises(ValueError, match="already encrypted"):
        engine.encrypt_file(str(f), password)

def test_folder_operations(tmp_path):
    # Setup folder
    txt_file = tmp_path / "doc.txt"
    txt_content = b"text content"
    txt_file.write_bytes(txt_content)

    jpg_file = tmp_path / "image.jpg"
    jpg_content = b"fake image bytes"
    jpg_file.write_bytes(jpg_content)

    py_file = tmp_path / "script.py"
    py_content = b"print('hi')"
    py_file.write_bytes(py_content)

    password = "folderpass"

    # Encrypt folder
    summary = engine.encrypt_folder(str(tmp_path), password)
    
    assert len(summary["encrypted"]) == 2
    assert "doc.txt" in summary["encrypted"]
    assert "image.jpg" in summary["encrypted"]
    assert len(summary["skipped"]) == 1
    assert "script.py" in summary["skipped"]
    assert len(summary["errors"]) == 0

    assert file_detector.is_encrypted(str(txt_file)) is True
    assert file_detector.is_encrypted(str(jpg_file)) is True
    assert file_detector.is_encrypted(str(py_file)) is False
    assert py_file.read_bytes() == py_content

    # Decrypt folder
    summary_dec = engine.decrypt_folder(str(tmp_path), password)
    assert len(summary_dec["decrypted"]) == 2
    assert txt_file.read_bytes() == txt_content
    assert jpg_file.read_bytes() == jpg_content
    assert file_detector.is_encrypted(str(txt_file)) is False
