from filevault.core import key_manager

def test_derive_key_length():
    password = "password123"
    salt = key_manager.generate_salt()
    key = key_manager.derive_key(password, salt)
    assert len(key) == 32

def test_derive_key_determinism():
    password = "password123"
    salt = key_manager.generate_salt()
    key1 = key_manager.derive_key(password, salt)
    key2 = key_manager.derive_key(password, salt)
    assert key1 == key2

def test_derive_key_different_password():
    salt = key_manager.generate_salt()
    key1 = key_manager.derive_key("password123", salt)
    key2 = key_manager.derive_key("password456", salt)
    assert key1 != key2

def test_derive_key_different_salt():
    password = "password123"
    salt1 = key_manager.generate_salt()
    salt2 = key_manager.generate_salt()
    key1 = key_manager.derive_key(password, salt1)
    key2 = key_manager.derive_key(password, salt2)
    assert key1 != key2

def test_generate_salt():
    salt1 = key_manager.generate_salt()
    salt2 = key_manager.generate_salt()
    assert len(salt1) == 16
    assert len(salt2) == 16
    assert salt1 != salt2
