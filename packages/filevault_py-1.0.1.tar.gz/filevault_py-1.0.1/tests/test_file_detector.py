import pytest
from filevault.core import file_detector

def test_is_supported_extensions(tmp_path):
    # Supported extensions
    supported = [".txt", ".jpg", ".png", ".mp3", ".zip"]
    for ext in supported:
        f = tmp_path / f"test{ext}"
        f.write_text("dummy content")
        assert file_detector.is_supported(str(f)) == (True, "")

    # Blocked extensions
    blocked = [".py", ".json", ".env", ".html"]
    for ext in blocked:
        f = tmp_path / f"test{ext}"
        f.write_text("dummy content")
        res, reason = file_detector.is_supported(str(f))
        assert res is False
        assert "protected" in reason or "not supported" in reason

def test_is_encrypted_detection(tmp_path):
    # Plaintext file
    f_plain = tmp_path / "plain.txt"
    f_plain.write_text("Hello World")
    assert file_detector.is_encrypted(str(f_plain)) is False

    # Encrypted file (starts with MAGIC_MARKER)
    f_enc = tmp_path / "enc.txt"
    f_enc.write_bytes(b"FVLT" + b"some_salt" + b"some_nonce" + b"ciphertext")
    assert file_detector.is_encrypted(str(f_enc)) is True

def test_is_supported_content_agnostic(tmp_path):
    # PNG bytes in a .txt file should be supported because of the .txt extension
    f_txt_png = tmp_path / "image_disguised.txt"
    f_txt_png.write_bytes(b"\x89PNG\r\n\x1a\n" + b"some data")
    assert file_detector.is_supported(str(f_txt_png)) == (True, "")

    # Python code in a .txt file should be supported because of the .txt extension
    f_txt_py = tmp_path / "code_disguised.txt"
    f_txt_py.write_text("import os\nprint('hello')")
    assert file_detector.is_supported(str(f_txt_py)) == (True, "")
