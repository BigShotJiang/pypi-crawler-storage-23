from filevault.core.engine import (
    encrypt_file,
    decrypt_file,
    encrypt_folder,
    decrypt_folder,
)

__version__ = "1.0.0"
__author__ = "Your Name"

__all__ = ["encrypt_file", "decrypt_file", "encrypt_folder", "decrypt_folder"]
