"""Object storage abstraction."""

from neuromem.storage.base import ObjectStorage

__all__ = ["ObjectStorage"]
