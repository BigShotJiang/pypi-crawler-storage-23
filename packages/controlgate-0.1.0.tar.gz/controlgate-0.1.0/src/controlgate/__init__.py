"""ControlGate — NIST RMF Cloud Security Hardening Compliance Gate."""

__version__ = "0.1.0"
