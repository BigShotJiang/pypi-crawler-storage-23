.. Bedrock Server Manager Bedrock Downloader Core documentation file

Bedrock Downloader Core Documentation
=====================================

.. autoclass:: bedrock_server_manager.BedrockDownloader
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   .. automethod:: __init__