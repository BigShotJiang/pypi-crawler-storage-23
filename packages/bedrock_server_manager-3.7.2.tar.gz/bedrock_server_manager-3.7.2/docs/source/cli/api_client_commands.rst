.. click:: bsm_api_client.cli.__main__:cli
   :prog: bsm-api-client
   :nested: full