def main():
    print("FlexGraph — https://flexgraph.dev")
