# getflex

FlexGraph CLI — knowledge operating system.

```
pip install getflex
flex init
```

Coming soon at [flexgraph.dev](https://flexgraph.dev)
