from __future__ import annotations

import pytest

from fulcrum_trust.types import TrustConfig, TrustOutcome, TrustState


class TestTrustOutcome:
    def test_values_are_strings(self) -> None:
        assert TrustOutcome.SUCCESS.value == "success"
        assert TrustOutcome.FAILURE.value == "failure"
        assert TrustOutcome.PARTIAL.value == "partial"

    def test_string_comparison(self) -> None:
        assert TrustOutcome.SUCCESS == "success"


class TestTrustState:
    def test_initial_trust_score_is_half(self) -> None:
        """Uninformative prior alpha=1,beta=1 yields trust_score=0.5 (TRUST-01)."""
        state = TrustState(pair_id="abc", agent_a="a", agent_b="b")
        assert state.trust_score == pytest.approx(0.5)

    def test_trust_score_after_successes(self) -> None:
        state = TrustState(
            pair_id="abc", agent_a="a", agent_b="b", alpha=3.0, beta_val=1.0
        )
        assert state.trust_score == pytest.approx(0.75)

    def test_trust_score_after_failures(self) -> None:
        state = TrustState(
            pair_id="abc", agent_a="a", agent_b="b", alpha=1.0, beta_val=3.0
        )
        assert state.trust_score == pytest.approx(0.25)

    def test_interaction_count_defaults_to_zero(self) -> None:
        state = TrustState(pair_id="abc", agent_a="a", agent_b="b")
        assert state.interaction_count == 0

    def test_last_updated_is_set_on_creation(self) -> None:
        import time

        before = time.time()
        state = TrustState(pair_id="abc", agent_a="a", agent_b="b")
        after = time.time()
        assert before <= state.last_updated <= after


class TestTrustConfig:
    def test_default_threshold(self) -> None:
        cfg = TrustConfig()
        assert cfg.threshold == pytest.approx(0.3)

    def test_default_half_life(self) -> None:
        cfg = TrustConfig()
        assert cfg.half_life_seconds == pytest.approx(86400.0)

    def test_default_priors(self) -> None:
        cfg = TrustConfig()
        assert cfg.alpha_prior == pytest.approx(1.0)
        assert cfg.beta_prior == pytest.approx(1.0)

    def test_invalid_threshold_raises(self) -> None:
        with pytest.raises(ValueError, match="threshold"):
            TrustConfig(threshold=0.0)

    def test_threshold_above_one_raises(self) -> None:
        with pytest.raises(ValueError, match="threshold"):
            TrustConfig(threshold=1.5)

    def test_invalid_half_life_raises(self) -> None:
        with pytest.raises(ValueError, match="half_life"):
            TrustConfig(half_life_seconds=-1.0)

    def test_zero_half_life_raises(self) -> None:
        with pytest.raises(ValueError, match="half_life"):
            TrustConfig(half_life_seconds=0.0)

    def test_custom_threshold(self) -> None:
        cfg = TrustConfig(threshold=0.5)
        assert cfg.threshold == pytest.approx(0.5)
