"""
Views for Django Form Workflows

This module provides the core views for form submission, approval workflows,
and submission management.
"""

import json
import logging
from datetime import date, datetime, time
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.files.storage import default_storage
from django.db import models
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .forms import DynamicForm
from .models import ApprovalTask, AuditLog, FormDefinition, FormField, FormSubmission
from .utils import user_can_approve, user_can_submit_form

logger = logging.getLogger(__name__)


def _get_accessible_category_pks(user):
    """Return the set of FormCategory PKs the user is permitted to access.

    A category is accessible when the user satisfies the group restriction at
    **every** level of the ancestor chain:

    * If a category has its own ``allowed_groups``, the user must be in at
      least one of them.
    * If a category has *no* ``allowed_groups`` of its own, access is
      inherited from the parent (or granted freely if there is no parent).

    This means sub-categories without explicit groups automatically inherit
    their parent's restriction, so adding "Students - All" to Student Services
    automatically gates On-Campus and Online as well.
    """
    from .models import FormCategory

    user_group_ids = set(user.groups.values_list("id", flat=True))

    all_cats = list(
        FormCategory.objects.prefetch_related("allowed_groups").order_by("id")
    )
    cat_by_pk = {cat.pk: cat for cat in all_cats}
    # Map each category to its set of required group IDs
    cat_groups = {
        cat.pk: set(cat.allowed_groups.values_list("id", flat=True)) for cat in all_cats
    }

    _cache = {}  # pk -> bool

    def _can_access(cat_pk):
        if cat_pk in _cache:
            return _cache[cat_pk]
        cat = cat_by_pk[cat_pk]
        groups = cat_groups[cat_pk]
        if groups:
            # Has own restriction — user must be in at least one group
            result = bool(user_group_ids & groups)
        elif cat.parent_id is None:
            # Top-level with no restriction — open to all authenticated users
            result = True
        else:
            # Inherit from parent
            result = _can_access(cat.parent_id)
        _cache[cat_pk] = result
        return result

    for cat in all_cats:
        _can_access(cat.pk)

    return {pk for pk, ok in _cache.items() if ok}


def _build_grouped_forms(forms):
    """
    Return a hierarchical list of category-tree nodes for rendering grouped forms.

    Each node in the returned list is a dict::

        {
            "category": FormCategory | None,   # None = uncategorised bucket
            "forms":    [FormDefinition, ...], # forms directly under this category
            "children": [node, ...],           # child category nodes (same structure)
        }

    Only categories that contain at least one visible form (directly or via a
    descendant) are included.  Uncategorised forms are appended as the final
    node with ``"category": None``.

    The tree is built with a single call to ``FormCategory.objects.all()``
    plus the already-filtered ``forms`` queryset, so the number of SQL
    queries is small and constant regardless of nesting depth.
    """
    from .models import FormCategory

    # ---- 1. Bucket forms by category pk --------------------------------
    ordered = forms.order_by(
        "category__order",
        "category__name",
        "name",
    ).select_related("category")

    forms_by_cat = {}  # cat_pk -> [FormDefinition]
    uncategorised = []

    for form in ordered:
        if form.category_id is None:
            uncategorised.append(form)
        else:
            forms_by_cat.setdefault(form.category_id, []).append(form)

    if not forms_by_cat and not uncategorised:
        return []

    # ---- 2. Load all categories and build parent → children map --------
    all_cats = {
        cat.pk: cat for cat in FormCategory.objects.all().order_by("order", "name")
    }
    children_by_parent = {}  # parent_pk | None -> [FormCategory]
    for cat in all_cats.values():
        children_by_parent.setdefault(cat.parent_id, []).append(cat)

    # ---- 3. Determine which categories have visible forms (memoised) ----
    _has_forms_cache = {}

    def _subtree_has_forms(cat_pk):
        if cat_pk in _has_forms_cache:
            return _has_forms_cache[cat_pk]
        result = cat_pk in forms_by_cat
        if not result:
            for child in children_by_parent.get(cat_pk, []):
                if _subtree_has_forms(child.pk):
                    result = True
                    break
        _has_forms_cache[cat_pk] = result
        return result

    # ---- 4. Recursively assemble the tree ------------------------------
    def _build_subtree(cat):
        visible_children = [
            _build_subtree(child)
            for child in children_by_parent.get(cat.pk, [])
            if _subtree_has_forms(child.pk)
        ]
        return {
            "category": cat,
            "forms": forms_by_cat.get(cat.pk, []),
            "children": visible_children,
        }

    top_level = [
        _build_subtree(cat)
        for cat in children_by_parent.get(None, [])
        if _subtree_has_forms(cat.pk)
    ]

    if uncategorised:
        top_level.append({"category": None, "forms": uncategorised, "children": []})

    return top_level


@login_required
def form_list(request):
    """List all active forms the current user has access to.

    For non-staff users two layers of group filtering are applied:

    1. **Form-level** — the user must be in ``submit_groups``, or the form
       has no ``submit_groups`` restriction.
    2. **Category-level** — the full ancestor chain is checked via
       :func:`_get_accessible_category_pks`.  A category with no
       ``allowed_groups`` of its own inherits the restriction of the nearest
       ancestor that has groups set.  A root category with no groups is open
       to all authenticated users.

    Staff / superusers bypass both filters and see every active form.

    Context variables
    -----------------
    forms
        Raw queryset (for templates that just want a flat list).
    grouped_forms
        Ordered list of ``(FormCategory | None, [FormDefinition, ...])``.
    """
    if request.user.is_staff or request.user.is_superuser:
        forms = FormDefinition.objects.filter(is_active=True).select_related("category")
    else:
        user_groups = request.user.groups.all()
        accessible_cat_pks = _get_accessible_category_pks(request.user)
        forms = (
            FormDefinition.objects.filter(is_active=True)
            # Annotate submit_group_count to distinguish "no restriction" from "restricted"
            .annotate(
                submit_group_count=models.Count("submit_groups", distinct=True),
            )
            # Form-level: user in submit_groups OR form has no restriction
            .filter(
                models.Q(submit_groups__in=user_groups) | models.Q(submit_group_count=0)
            )
            # Category-level: no category, or category accessible via hierarchy
            # _get_accessible_category_pks walks the parent chain, so a child
            # category with no allowed_groups inherits its parent's restriction.
            .filter(
                models.Q(category__isnull=True)
                | models.Q(category_id__in=accessible_cat_pks)
            )
            .distinct()
            .select_related("category")
        )

    # --- Optional name search ---
    search_query = request.GET.get("q", "").strip()
    if search_query:
        forms = forms.filter(name__icontains=search_query)

    grouped_forms = _build_grouped_forms(forms)

    return render(
        request,
        "django_forms_workflows/form_list.html",
        {
            "forms": forms,
            "grouped_forms": grouped_forms,
            "search_query": search_query,
        },
    )


@login_required
def form_submit(request, slug):
    """Submit a form"""
    form_def = get_object_or_404(FormDefinition, slug=slug, is_active=True)

    # Check permissions
    if not user_can_submit_form(request.user, form_def):
        messages.error(request, "You don't have permission to submit this form.")
        return redirect("forms_workflows:form_list")

    # Get draft if exists
    draft = FormSubmission.objects.filter(
        form_definition=form_def, submitter=request.user, status="draft"
    ).first()

    if request.method == "POST":
        form = DynamicForm(
            form_definition=form_def,
            user=request.user,
            data=request.POST,
            files=request.FILES,
        )

        if form.is_valid():
            # Save submission first to get an ID for file storage paths
            submission = draft or FormSubmission(
                form_definition=form_def,
                submitter=request.user,
                submission_ip=get_client_ip(request),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
            )
            # Save to get ID (needed for file paths)
            if not submission.pk:
                submission.form_data = {}  # Temporary empty data
                submission.save()

            # Serialize form data to JSON-compatible format (now with submission ID)
            submission.form_data = serialize_form_data(
                form.cleaned_data, submission_id=submission.pk
            )

            if "save_draft" in request.POST:
                submission.status = "draft"
                submission.save()
                messages.success(request, "Draft saved successfully.")

                # Log audit
                AuditLog.objects.create(
                    action="update" if draft else "create",
                    object_type="FormSubmission",
                    object_id=submission.id,
                    user=request.user,
                    user_ip=get_client_ip(request),
                    comments="Saved as draft",
                )
            else:
                submission.status = "submitted"
                submission.submitted_at = timezone.now()
                submission.save()
                messages.success(request, "Form submitted successfully.")

                # Log audit
                AuditLog.objects.create(
                    action="submit",
                    object_type="FormSubmission",
                    object_id=submission.id,
                    user=request.user,
                    user_ip=get_client_ip(request),
                    comments="Form submitted",
                )

                # Create approval tasks if workflow requires approval
                create_approval_tasks(submission)

            return redirect("forms_workflows:my_submissions")
    else:
        initial_data = draft.form_data if draft else None
        form = DynamicForm(
            form_definition=form_def, user=request.user, initial_data=initial_data
        )

    # Get form enhancements configuration
    import json

    form_enhancements_config = json.dumps(form.get_enhancements_config())

    return render(
        request,
        "django_forms_workflows/form_submit.html",
        {
            "form_def": form_def,
            "form": form,
            "is_draft": draft is not None,
            "form_enhancements_config": form_enhancements_config,
        },
    )


@login_required
@require_http_methods(["POST"])
def form_auto_save(request, slug):
    """Auto-save form draft via AJAX"""
    form_def = get_object_or_404(FormDefinition, slug=slug, is_active=True)

    # Check permissions
    if not user_can_submit_form(request.user, form_def):
        return JsonResponse(
            {"success": False, "error": "Permission denied"}, status=403
        )

    try:
        # Parse JSON data
        data = json.loads(request.body)

        # Get or create draft
        draft, created = FormSubmission.objects.get_or_create(
            form_definition=form_def,
            submitter=request.user,
            status="draft",
            defaults={
                "submission_ip": get_client_ip(request),
                "user_agent": request.META.get("HTTP_USER_AGENT", ""),
            },
        )

        # Update form data
        draft.form_data = data
        draft.save()

        # Log audit
        AuditLog.objects.create(
            action="auto_save",
            object_type="FormSubmission",
            object_id=draft.id,
            user=request.user,
            user_ip=get_client_ip(request),
            comments="Auto-saved draft",
        )

        return JsonResponse(
            {
                "success": True,
                "message": "Draft saved",
                "draft_id": draft.id,
                "saved_at": draft.created_at.isoformat(),
            }
        )

    except Exception as e:
        logger.error(f"Auto-save error for form {slug}: {e}")
        return JsonResponse({"success": False, "error": str(e)}, status=500)


@login_required
def my_submissions(request):
    """View user's submissions, optionally filtered by form category.

    Accepts an optional ``?category=<slug>`` query parameter to narrow the
    submission list to a single form category.  The template also receives a
    ``category_counts`` list so the UI can render a filter-pill bar showing
    how many submissions belong to each category.
    """
    base_submissions = FormSubmission.objects.filter(submitter=request.user)

    # --- Category counts (for the filter bar) ---
    raw_counts = (
        base_submissions.values(
            "form_definition__category__pk",
            "form_definition__category__name",
            "form_definition__category__slug",
            "form_definition__category__icon",
            "form_definition__category__order",
        )
        .annotate(count=models.Count("id"))
        .order_by(
            "form_definition__category__order",
            "form_definition__category__name",
        )
    )

    category_counts = []
    for row in raw_counts:
        slug = row["form_definition__category__slug"]
        if slug:  # only include categorised entries in the filter bar
            category_counts.append(
                {
                    "name": row["form_definition__category__name"],
                    "slug": slug,
                    "icon": row["form_definition__category__icon"] or "",
                    "count": row["count"],
                }
            )

    total_submissions_count = base_submissions.count()

    # --- Apply optional category filter ---
    category_slug = request.GET.get("category", "").strip()
    active_category = None

    if category_slug:
        submissions = base_submissions.filter(
            form_definition__category__slug=category_slug
        )
        active_category = next(
            (c for c in category_counts if c["slug"] == category_slug), None
        )
    else:
        submissions = base_submissions

    # --- Form counts within the active category (for the form-level filter bar) ---
    form_slug = request.GET.get("form", "").strip()
    form_counts = []
    active_form = None

    if category_slug:
        raw_form_counts = (
            submissions.values(
                "form_definition__pk",
                "form_definition__name",
                "form_definition__slug",
            )
            .annotate(count=models.Count("id"))
            .order_by("form_definition__name")
        )
        form_counts = [
            {
                "name": r["form_definition__name"],
                "slug": r["form_definition__slug"],
                "count": r["count"],
            }
            for r in raw_form_counts
            if r["form_definition__slug"]
        ]
        if form_slug:
            submissions = submissions.filter(form_definition__slug=form_slug)
            active_form = next((f for f in form_counts if f["slug"] == form_slug), None)

    submissions = submissions.select_related(
        "form_definition__category",
        "form_definition__workflow",
    ).order_by("-created_at")

    # Check if any currently-displayed submissions support bulk export
    any_exportable = submissions.filter(
        form_definition__workflow__allow_bulk_export=True
    ).exists()

    return render(
        request,
        "django_forms_workflows/my_submissions.html",
        {
            "submissions": submissions,
            "category_counts": category_counts,
            "active_category": active_category,
            "category_slug": category_slug,
            "total_submissions_count": total_submissions_count,
            "form_counts": form_counts,
            "form_slug": form_slug,
            "active_form": active_form,
            "any_exportable": any_exportable,
        },
    )


@login_required
def submission_detail(request, submission_id):
    """View submission details"""
    submission = get_object_or_404(FormSubmission, id=submission_id)

    # Check permissions - user must be submitter, approver, or admin
    can_view = (
        submission.submitter == request.user
        or request.user.is_superuser
        or user_can_approve(request.user, submission)
        or request.user.groups.filter(
            id__in=submission.form_definition.admin_groups.all()
        ).exists()
    )

    if not can_view:
        return HttpResponseForbidden(
            "You don't have permission to view this submission."
        )

    # Get approval tasks with related objects for efficient rendering
    approval_tasks = submission.approval_tasks.select_related(
        "workflow_stage", "assigned_to", "assigned_group", "completed_by"
    ).order_by("stage_number", "-created_at")

    # Build stage groups if any tasks are linked to a workflow stage
    stage_groups = None
    if approval_tasks.filter(workflow_stage__isnull=False).exists():
        groups: dict = {}
        for task in approval_tasks:
            stage_key = task.stage_number or 0
            if stage_key not in groups:
                stage_name = (
                    task.workflow_stage.name
                    if task.workflow_stage
                    else f"Stage {stage_key}"
                )
                approval_logic = (
                    task.workflow_stage.approval_logic if task.workflow_stage else "all"
                )
                groups[stage_key] = {
                    "number": stage_key,
                    "name": stage_name,
                    "approval_logic": approval_logic,
                    "tasks": [],
                    "approved_count": 0,
                    "rejected_count": 0,
                    "total_count": 0,
                }
            groups[stage_key]["tasks"].append(task)
            groups[stage_key]["total_count"] += 1
            if task.status == "approved":
                groups[stage_key]["approved_count"] += 1
            elif task.status == "rejected":
                groups[stage_key]["rejected_count"] += 1
        stage_groups = sorted(groups.values(), key=lambda x: x["number"])

    # Resolve fresh presigned URLs for any file-upload fields
    form_data = _resolve_form_data_urls(submission.form_data)
    form_data_ordered = _build_ordered_form_data(submission, form_data)

    return render(
        request,
        "django_forms_workflows/submission_detail.html",
        {
            "submission": submission,
            "approval_tasks": approval_tasks,
            "stage_groups": stage_groups,
            "form_data": form_data,
            "form_data_ordered": form_data_ordered,
        },
    )


@login_required
def approval_inbox(request):
    """View pending approvals, optionally filtered by form category.

    Accepts an optional ``?category=<slug>`` query parameter to narrow the
    task list to a single form category.  The template also receives a
    ``category_counts`` list so the UI can render a filter-pill bar showing
    how many pending tasks belong to each category.
    """
    # Build base queryset of accessible pending tasks (no select_related yet
    # so the values()/annotate() path stays lightweight).
    if request.user.is_superuser:
        base_tasks = ApprovalTask.objects.filter(status="pending")
    else:
        user_groups = request.user.groups.all()
        base_tasks = ApprovalTask.objects.filter(status="pending").filter(
            models.Q(assigned_to=request.user)
            | models.Q(assigned_group__in=user_groups)
        )

    # --- Category counts (for the filter bar) ---
    raw_counts = (
        base_tasks.values(
            "submission__form_definition__category__pk",
            "submission__form_definition__category__name",
            "submission__form_definition__category__slug",
            "submission__form_definition__category__icon",
            "submission__form_definition__category__order",
        )
        .annotate(count=models.Count("id"))
        .order_by(
            "submission__form_definition__category__order",
            "submission__form_definition__category__name",
        )
    )

    category_counts = []
    for row in raw_counts:
        slug = row["submission__form_definition__category__slug"]
        if slug:  # only include categorised entries in the filter bar
            category_counts.append(
                {
                    "name": row["submission__form_definition__category__name"],
                    "slug": slug,
                    "icon": row["submission__form_definition__category__icon"] or "",
                    "count": row["count"],
                }
            )

    total_tasks_count = base_tasks.count()

    # --- Completed count for cross-tab badge ---
    if request.user.is_superuser:
        completed_count = FormSubmission.objects.filter(
            status__in=["approved", "rejected", "withdrawn"]
        ).count()
    else:
        completed_count = (
            FormSubmission.objects.filter(
                status__in=["approved", "rejected", "withdrawn"]
            )
            .filter(
                models.Q(approval_tasks__assigned_to=request.user)
                | models.Q(approval_tasks__assigned_group__in=user_groups)
            )
            .distinct()
            .count()
        )

    # --- Apply optional category filter ---
    category_slug = request.GET.get("category", "").strip()
    active_category = None

    if category_slug:
        display_tasks = base_tasks.filter(
            submission__form_definition__category__slug=category_slug
        )
        active_category = next(
            (c for c in category_counts if c["slug"] == category_slug), None
        )
    else:
        display_tasks = base_tasks

    # --- Form counts within the active category (for the form-level filter bar) ---
    form_slug = request.GET.get("form", "").strip()
    form_counts = []
    active_form = None

    if category_slug:
        raw_form_counts = (
            display_tasks.values(
                "submission__form_definition__pk",
                "submission__form_definition__name",
                "submission__form_definition__slug",
            )
            .annotate(count=models.Count("id"))
            .order_by("submission__form_definition__name")
        )
        form_counts = [
            {
                "name": r["submission__form_definition__name"],
                "slug": r["submission__form_definition__slug"],
                "count": r["count"],
            }
            for r in raw_form_counts
            if r["submission__form_definition__slug"]
        ]
        if form_slug:
            display_tasks = display_tasks.filter(
                submission__form_definition__slug=form_slug
            )
            active_form = next((f for f in form_counts if f["slug"] == form_slug), None)

    display_tasks = display_tasks.select_related(
        "submission__form_definition__category",
        "submission__submitter",
    ).order_by("-created_at")

    # --- Form fields for the column picker (only when a specific form is active) ---
    form_fields = []
    if form_slug and active_form:
        try:
            form_def_obj = FormDefinition.objects.get(slug=form_slug)
            form_fields = list(
                FormField.objects.filter(form_definition=form_def_obj)
                .exclude(field_type__in=["section", "file"])
                .order_by("order")
                .values("field_name", "field_label")
            )
        except FormDefinition.DoesNotExist:
            pass

    return render(
        request,
        "django_forms_workflows/approval_inbox.html",
        {
            "tasks": display_tasks,
            "category_counts": category_counts,
            "active_category": active_category,
            "category_slug": category_slug,
            "total_tasks_count": total_tasks_count,
            "completed_count": completed_count,
            "form_counts": form_counts,
            "form_slug": form_slug,
            "active_form": active_form,
            "form_fields": form_fields,
        },
    )


@login_required
def approve_submission(request, task_id):
    """Approve or reject a submission"""
    task = get_object_or_404(ApprovalTask, id=task_id)
    submission = task.submission
    form_def = submission.form_definition

    # Check permission
    can_approve = (
        task.assigned_to == request.user
        or (task.assigned_group and task.assigned_group in request.user.groups.all())
        or request.user.is_superuser
    )

    if not can_approve:
        messages.error(request, "You don't have permission to approve this.")
        return redirect("forms_workflows:approval_inbox")

    if task.status != "pending":
        messages.warning(request, "This task has already been processed.")
        return redirect("forms_workflows:approval_inbox")

    # Check if this form has approval step fields for the current step
    has_approval_step_fields = form_def.fields.filter(
        approval_step=task.step_number
    ).exists()
    approval_step_form = None

    if request.method == "POST":
        decision = request.POST.get("decision")
        comments = request.POST.get("comments", "")

        if decision not in ["approve", "reject"]:
            messages.error(request, "Invalid decision.")
            return redirect("forms_workflows:approve_submission", task_id=task_id)

        # If there are approval step fields and decision is approve, validate them
        if has_approval_step_fields and decision == "approve":
            from .forms import ApprovalStepForm

            approval_step_form = ApprovalStepForm(
                form_definition=form_def,
                submission=submission,
                approval_task=task,
                user=request.user,
                data=request.POST,
            )

            if not approval_step_form.is_valid():
                messages.error(
                    request, "Please correct the errors in the approval fields."
                )
                _fd = _resolve_form_data_urls(submission.form_data)
                return render(
                    request,
                    "django_forms_workflows/approve.html",
                    {
                        "task": task,
                        "submission": submission,
                        "approval_step_form": approval_step_form,
                        "has_approval_step_fields": has_approval_step_fields,
                        "form_data": _fd,
                        "form_data_ordered": _build_ordered_form_data(submission, _fd),
                    },
                )

            # Update submission form_data with approval step fields
            submission.form_data = approval_step_form.get_updated_form_data()
            submission.save()

        # Update task
        task.status = "approved" if decision == "approve" else "rejected"
        task.completed_by = request.user
        task.completed_at = timezone.now()
        task.comments = comments
        task.decision = decision
        task.save()

        # Update submission status
        workflow = form_def.workflow

        if decision == "reject":
            from .workflow_engine import handle_rejection

            handle_rejection(submission, task, workflow)
        else:
            # Approval - check workflow logic
            from .workflow_engine import handle_approval

            handle_approval(submission, task, workflow)

        # Log audit
        AuditLog.objects.create(
            action="approve" if decision == "approve" else "reject",
            object_type="FormSubmission",
            object_id=submission.id,
            user=request.user,
            user_ip=get_client_ip(request),
            changes={"task_id": task.id, "comments": comments},
        )

        messages.success(request, f"Submission {decision}d successfully.")
        return redirect("forms_workflows:approval_inbox")

    # GET request - create the approval step form if needed
    if has_approval_step_fields:
        from .forms import ApprovalStepForm

        approval_step_form = ApprovalStepForm(
            form_definition=form_def,
            submission=submission,
            approval_task=task,
            user=request.user,
        )

    # Build approval progress context — staged, sequential, or parallel
    approval_steps = []
    approval_step_fields: dict = {}
    all_approval_field_names: list = []
    approval_stages: list = []
    parallel_tasks: list = []
    workflow_mode = "none"
    workflow = form_def.workflow

    if workflow:
        stages = list(workflow.stages.order_by("order"))

        if stages:
            # -------- staged workflow --------
            workflow_mode = "staged"
            current_stage_number = task.stage_number or 1
            all_sub_tasks = list(
                submission.approval_tasks.select_related(
                    "workflow_stage", "assigned_group", "assigned_to"
                ).all()
            )
            tasks_by_stage: dict = {}
            for t in all_sub_tasks:
                key = t.workflow_stage_id
                tasks_by_stage.setdefault(key, []).append(t)

            for i, stage in enumerate(stages, start=1):
                stage_tasks = tasks_by_stage.get(stage.id, [])
                approved_count = sum(1 for t in stage_tasks if t.status == "approved")
                approval_stages.append(
                    {
                        "number": i,
                        "name": stage.name,
                        "approval_logic": stage.approval_logic,
                        "total_stages": len(stages),
                        "is_current": i == current_stage_number,
                        "is_completed": approved_count > 0
                        and not any(t.status == "pending" for t in stage_tasks),
                        "is_rejected": any(t.status == "rejected" for t in stage_tasks),
                        "is_pending": i > current_stage_number,
                        "tasks": stage_tasks,
                        "approved_count": approved_count,
                        "total_count": len(stage_tasks),
                    }
                )

        elif workflow.approval_logic == "sequence":
            # -------- legacy sequential --------
            workflow_mode = "sequence"
            approval_groups = list(workflow.approval_groups.all())
            total_steps = len(approval_groups)
            all_tasks = {t.step_number: t for t in submission.approval_tasks.all()}

            for field in form_def.fields.filter(approval_step__isnull=False).order_by(
                "approval_step", "order"
            ):
                step_num = field.approval_step
                if step_num not in approval_step_fields:
                    approval_step_fields[step_num] = []
                approval_step_fields[step_num].append(
                    {"field_name": field.field_name, "field_label": field.field_label}
                )
                all_approval_field_names.append(field.field_name)

            for idx, group in enumerate(approval_groups, start=1):
                step_task = all_tasks.get(idx)
                approval_steps.append(
                    {
                        "number": idx,
                        "total": total_steps,
                        "group_name": group.name,
                        "is_current": idx == task.step_number,
                        "is_completed": step_task.status == "approved"
                        if step_task
                        else False,
                        "is_rejected": step_task.status == "rejected"
                        if step_task
                        else False,
                        "is_pending": idx > (task.step_number or 0),
                        "task": step_task,
                        "fields": approval_step_fields.get(idx, []),
                    }
                )

        elif workflow.approval_logic in ("all", "any"):
            # -------- legacy parallel --------
            workflow_mode = workflow.approval_logic
            for t in submission.approval_tasks.filter(
                assigned_group__isnull=False
            ).select_related("assigned_group"):
                parallel_tasks.append(
                    {
                        "task": t,
                        "group_name": t.assigned_group.name
                        if t.assigned_group
                        else "—",
                        "is_current": t.id == task.id,
                    }
                )

    # Resolve fresh presigned URLs for any file-upload fields
    form_data = _resolve_form_data_urls(submission.form_data)
    form_data_ordered = _build_ordered_form_data(submission, form_data)

    return render(
        request,
        "django_forms_workflows/approve.html",
        {
            "task": task,
            "submission": submission,
            "approval_step_form": approval_step_form,
            "has_approval_step_fields": has_approval_step_fields,
            # sequential legacy
            "approval_steps": approval_steps,
            "current_step_number": task.step_number,
            "total_steps": len(approval_steps) if approval_steps else 0,
            "approval_field_names": all_approval_field_names,
            # staged
            "approval_stages": approval_stages,
            "current_stage_number": task.stage_number or 1,
            "total_stages": len(approval_stages),
            # parallel legacy
            "parallel_tasks": parallel_tasks,
            # shared
            "workflow_mode": workflow_mode,
            "form_data": form_data,
            "form_data_ordered": form_data_ordered,
        },
    )


@login_required
def completed_approvals(request):
    """View completed submissions where the user was part of the approval workflow.

    Shows submissions with status approved/rejected/withdrawn where the current
    user had an ApprovalTask assigned directly or via group membership.  This
    provides a history / audit view for approvers, which is especially important
    for business-process workflows (e.g. PCN) where data retention matters.

    Accepts an optional ``?category=<slug>`` query parameter and an optional
    ``?form=<slug>`` query parameter for narrowing the list.
    """
    if request.user.is_superuser:
        base_submissions = FormSubmission.objects.filter(
            status__in=["approved", "rejected", "withdrawn"]
        )
    else:
        user_groups = request.user.groups.all()
        # Filter on the ApprovalTask status rather than the FormSubmission status
        # so that a user who approved/rejected their step on a multi-stage workflow
        # can see that submission here even while later steps are still pending.
        # Both conditions (assigned + action taken) must apply to the SAME task
        # row, so we use a single filter() call with compound Q expressions.
        completed_task_sub_ids = (
            ApprovalTask.objects.filter(
                models.Q(assigned_to=request.user)
                | models.Q(assigned_group__in=user_groups),
                status__in=["approved", "rejected"],
            )
            .values_list("submission_id", flat=True)
            .distinct()
        )
        base_submissions = FormSubmission.objects.filter(id__in=completed_task_sub_ids)

    # --- Category counts (for the filter bar) ---
    raw_counts = (
        base_submissions.values(
            "form_definition__category__pk",
            "form_definition__category__name",
            "form_definition__category__slug",
            "form_definition__category__icon",
            "form_definition__category__order",
        )
        .annotate(count=models.Count("id"))
        .order_by(
            "form_definition__category__order",
            "form_definition__category__name",
        )
    )

    category_counts = []
    for row in raw_counts:
        slug = row["form_definition__category__slug"]
        if slug:
            category_counts.append(
                {
                    "name": row["form_definition__category__name"],
                    "slug": slug,
                    "icon": row["form_definition__category__icon"] or "",
                    "count": row["count"],
                }
            )

    total_count = base_submissions.count()

    # --- Pending tasks count for cross-tab badge ---
    if request.user.is_superuser:
        pending_tasks_count = ApprovalTask.objects.filter(status="pending").count()
    else:
        pending_tasks_count = (
            ApprovalTask.objects.filter(status="pending")
            .filter(
                models.Q(assigned_to=request.user)
                | models.Q(assigned_group__in=user_groups)
            )
            .count()
        )

    # --- Apply optional category filter ---
    category_slug = request.GET.get("category", "").strip()
    active_category = None

    if category_slug:
        display_submissions = base_submissions.filter(
            form_definition__category__slug=category_slug
        )
        active_category = next(
            (c for c in category_counts if c["slug"] == category_slug), None
        )
    else:
        display_submissions = base_submissions

    # --- Form counts within the active category (for the form-level filter bar) ---
    form_slug = request.GET.get("form", "").strip()
    form_counts = []
    active_form = None

    if category_slug:
        raw_form_counts = (
            display_submissions.values(
                "form_definition__pk",
                "form_definition__name",
                "form_definition__slug",
            )
            .annotate(count=models.Count("id"))
            .order_by("form_definition__name")
        )
        form_counts = [
            {
                "name": r["form_definition__name"],
                "slug": r["form_definition__slug"],
                "count": r["count"],
            }
            for r in raw_form_counts
            if r["form_definition__slug"]
        ]
        if form_slug:
            display_submissions = display_submissions.filter(
                form_definition__slug=form_slug
            )
            active_form = next((f for f in form_counts if f["slug"] == form_slug), None)

    # --- Status filter (optional) ---
    status_filter = request.GET.get("status", "").strip()
    if status_filter in ["approved", "rejected", "withdrawn", "pending_approval"]:
        display_submissions = display_submissions.filter(status=status_filter)

    display_submissions = display_submissions.select_related(
        "form_definition__category",
        "form_definition__workflow",
        "submitter",
    ).order_by("-completed_at", "-submitted_at")

    # Check if any currently-displayed submissions support bulk export
    any_exportable = display_submissions.filter(
        form_definition__workflow__allow_bulk_export=True
    ).exists()

    # --- Form fields for column picker (when a specific form is filtered) ---
    form_fields = []
    if form_slug and active_form:
        try:
            form_def_obj = FormDefinition.objects.get(slug=form_slug)
            form_fields = list(
                FormField.objects.filter(form_definition=form_def_obj)
                .exclude(field_type__in=["section", "file"])
                .order_by("order")
                .values("field_name", "field_label")
            )
        except FormDefinition.DoesNotExist:
            pass

    return render(
        request,
        "django_forms_workflows/completed_approvals.html",
        {
            "submissions": display_submissions,
            "category_counts": category_counts,
            "active_category": active_category,
            "category_slug": category_slug,
            "total_count": total_count,
            "pending_tasks_count": pending_tasks_count,
            "form_counts": form_counts,
            "form_slug": form_slug,
            "active_form": active_form,
            "status_filter": status_filter,
            "any_exportable": any_exportable,
            "form_fields": form_fields,
        },
    )


@login_required
def withdraw_submission(request, submission_id):
    """Withdraw a submission"""
    submission = get_object_or_404(FormSubmission, id=submission_id)

    # Only submitter can withdraw
    if submission.submitter != request.user:
        return HttpResponseForbidden("You can only withdraw your own submissions.")

    # Check if withdrawal is allowed
    if not submission.form_definition.allow_withdrawal:
        messages.error(request, "This form does not allow withdrawal.")
        return redirect(
            "forms_workflows:submission_detail", submission_id=submission_id
        )

    # Can only withdraw if not yet approved/rejected
    if submission.status in ["approved", "rejected", "withdrawn"]:
        messages.error(request, "This submission cannot be withdrawn.")
        return redirect(
            "forms_workflows:submission_detail", submission_id=submission_id
        )

    if request.method == "POST":
        submission.status = "withdrawn"
        submission.completed_at = timezone.now()
        submission.save()

        # Cancel pending approval tasks
        submission.approval_tasks.filter(status="pending").update(status="skipped")

        # Log audit
        AuditLog.objects.create(
            action="withdraw",
            object_type="FormSubmission",
            object_id=submission.id,
            user=request.user,
            user_ip=get_client_ip(request),
            comments="Submission withdrawn by submitter",
        )

        messages.success(request, "Submission withdrawn successfully.")
        return redirect("forms_workflows:my_submissions")

    return render(
        request,
        "django_forms_workflows/withdraw_confirm.html",
        {"submission": submission},
    )


@login_required
def submission_pdf(request, submission_id):
    """Generate and serve a PDF of a form submission.

    Respects the ``pdf_generation`` setting on the form definition:
      - ``none``          – PDF download is disabled; returns 403.
      - ``anytime``       – PDF is available as soon as the form is submitted.
      - ``post_approval`` – PDF is only available once the submission is approved.
    """
    submission = get_object_or_404(FormSubmission, id=submission_id)
    form_def = submission.form_definition

    # --- permission check (same as submission_detail) ---
    can_view = (
        submission.submitter == request.user
        or request.user.is_superuser
        or user_can_approve(request.user, submission)
        or request.user.groups.filter(id__in=form_def.admin_groups.all()).exists()
    )
    if not can_view:
        return HttpResponseForbidden(
            "You don't have permission to view this submission."
        )

    # --- pdf_generation setting check ---
    pdf_setting = form_def.pdf_generation
    if pdf_setting == "none":
        return HttpResponseForbidden("PDF generation is not enabled for this form.")

    if pdf_setting == "post_approval" and submission.status != "approved":
        return HttpResponseForbidden(
            "PDF is only available after the submission has been approved."
        )

    # --- build width-aware row groups for PDF layout ---
    pdf_rows = _build_pdf_rows(submission)

    # --- render HTML template to a string ---
    from django.template.loader import render_to_string

    html_string = render_to_string(
        "django_forms_workflows/submission_pdf.html",
        {
            "submission": submission,
            "form_def": form_def,
            "pdf_rows": pdf_rows,
            "request": request,
        },
    )

    # --- convert HTML to PDF using WeasyPrint ---
    try:
        from weasyprint import HTML

        base_url = request.build_absolute_uri("/")
        pdf_bytes = HTML(string=html_string, base_url=base_url).write_pdf()
    except ImportError:
        return HttpResponse(
            "PDF generation requires the weasyprint package. "
            "Please install it with: pip install weasyprint",
            status=501,
        )
    except Exception as exc:
        logger.error("WeasyPrint error for submission %s: %s", submission_id, exc)
        return HttpResponse("An error occurred while generating the PDF.", status=500)

    filename = f"submission_{submission_id}.pdf"
    response = HttpResponse(pdf_bytes, content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


# Helper functions


def serialize_form_data(data, submission_id=None):
    """
    Convert form data to JSON-serializable format.

    For file uploads, saves the file to storage and stores the filename,
    storage path, size, and content-type.  The URL is intentionally NOT
    stored here — presigned S3/Spaces URLs expire and must be generated
    on-demand at render time via ``_resolve_form_data_urls()``.
    """
    serialized = {}
    for key, value in data.items():
        if isinstance(value, date | datetime | time):
            serialized[key] = value.isoformat()
        elif isinstance(value, Decimal):
            serialized[key] = str(value)
        elif hasattr(value, "read"):  # File upload (InMemoryUploadedFile or similar)
            # Save file to storage (uses S3/Spaces if configured)
            file_path = save_uploaded_file(value, key, submission_id)
            if file_path:
                serialized[key] = {
                    "filename": value.name,
                    "path": file_path,
                    "size": value.size if hasattr(value, "size") else 0,
                    "content_type": (
                        value.content_type
                        if hasattr(value, "content_type")
                        else "application/octet-stream"
                    ),
                }
            else:
                # Fallback if save fails
                serialized[key] = value.name
        else:
            serialized[key] = value
    return serialized


def save_uploaded_file(file_obj, field_name, submission_id=None):
    """
    Save an uploaded file to storage.

    Returns the storage path or None if save fails.
    """
    try:
        # Generate a unique path for the file
        timestamp = timezone.now().strftime("%Y%m%d_%H%M%S")
        sub_id = submission_id or "temp"

        # Sanitize filename
        original_name = file_obj.name
        # Remove any path components from the filename
        safe_name = original_name.replace("/", "_").replace("\\", "_")

        # Build storage path: uploads/<submission_id>/<timestamp>_<filename>
        storage_path = f"uploads/{sub_id}/{field_name}_{timestamp}_{safe_name}"

        # Save to storage (will use S3/Spaces if configured via STORAGES)
        saved_path = default_storage.save(storage_path, file_obj)

        logger.info(f"Saved uploaded file to: {saved_path}")
        return saved_path

    except Exception as e:
        logger.error(f"Failed to save uploaded file: {e}", exc_info=True)
        return None


def get_file_url(file_info):
    """
    Get a URL for accessing an uploaded file.

    Handles both old format (just filename) and new format (dict with path).
    """
    if isinstance(file_info, dict) and "path" in file_info:
        try:
            return default_storage.url(file_info["path"])
        except Exception as e:
            logger.error(f"Failed to get file URL: {e}")
            return None
    elif isinstance(file_info, str):
        # Old format - just filename, can't generate URL
        return None
    return None


def _build_ordered_form_data(submission, form_data):
    """
    Return form data as an ordered list of dicts, respecting FormField.order.

    The raw ``form_data`` JSON dict preserves insertion order (Python 3.7+),
    but that order reflects when fields were *submitted*, not the declared field
    order on the form.  This helper re-orders the entries so they match the
    field definition ordering configured by the form designer.

    Each returned item has:
      - ``label``: the human-readable field label
      - ``key``:   the field_name / dict key
      - ``value``: the resolved value (may be a file-info dict after URL resolution)
    """
    if not form_data:
        return []

    ordered = []
    seen_keys = set()

    # Walk fields in declared order (sections are skipped – they have no data)
    for field in submission.form_definition.fields.exclude(
        field_type="section"
    ).order_by("order"):
        key = field.field_name
        if key in form_data:
            ordered.append(
                {
                    "label": field.field_label,
                    "key": key,
                    "value": form_data[key],
                }
            )
            seen_keys.add(key)

    # Append any keys in form_data that aren't represented in field definitions
    # (e.g. approval-step fields or legacy entries) so nothing is lost.
    for key, value in form_data.items():
        if key not in seen_keys:
            ordered.append(
                {
                    "label": key.replace("_", " ").title(),
                    "key": key,
                    "value": value,
                }
            )

    return ordered


def _build_pdf_rows(submission):
    """Return form fields grouped into display rows for PDF rendering.

    Unlike :func:`_build_ordered_form_data`, this helper:
    * includes ``section`` fields so section headers appear in the PDF.
    * groups consecutive half-width fields into side-by-side *pair* rows.
    * groups consecutive third-width fields into side-by-side *triple* rows.

    Each row is a dict with one of the following shapes:

    ``{'type': 'section',  'label': str}``
        A section header row spanning the full table width.

    ``{'type': 'full',  'fields': [entry]}``
        A single field rendered across the full row width.

    ``{'type': 'pair',  'fields': [entry, entry]}``
        Two half-width fields rendered side-by-side.

    ``{'type': 'triple',  'fields': [entry, entry, entry]}``
        Three third-width fields rendered side-by-side.

    Where ``entry`` is ``{'label', 'key', 'value', 'width'}``.
    """
    form_data = submission.form_data or {}
    rows = []
    pending_half: list = []
    pending_third: list = []

    def flush_half():
        if len(pending_half) == 2:
            rows.append({"type": "pair", "fields": list(pending_half)})
        elif len(pending_half) == 1:
            rows.append({"type": "full", "fields": list(pending_half)})
        pending_half.clear()

    def flush_third():
        while len(pending_third) >= 3:
            rows.append({"type": "triple", "fields": pending_third[:3]})
            del pending_third[:3]
        # 1 or 2 leftover thirds → fall back to full-width rows
        for fd in pending_third:
            rows.append({"type": "full", "fields": [fd]})
        pending_third.clear()

    seen_keys: set = set()

    for field in submission.form_definition.fields.order_by("order"):
        if field.field_type == "section":
            flush_half()
            flush_third()
            rows.append({"type": "section", "label": field.field_label})
            continue

        key = field.field_name
        if key not in form_data:
            continue

        seen_keys.add(key)
        fd = {
            "label": field.field_label,
            "key": key,
            "value": form_data[key],
            "width": field.width,
        }

        if field.width == "half":
            flush_third()
            pending_half.append(fd)
            if len(pending_half) == 2:
                rows.append({"type": "pair", "fields": list(pending_half)})
                pending_half.clear()
        elif field.width == "third":
            flush_half()
            pending_third.append(fd)
            if len(pending_third) == 3:
                rows.append({"type": "triple", "fields": list(pending_third)})
                pending_third.clear()
        else:
            flush_half()
            flush_third()
            rows.append({"type": "full", "fields": [fd]})

    flush_half()
    flush_third()

    # Append any form_data keys not covered by field definitions (approval-step
    # fields, legacy entries, etc.) so nothing is silently dropped.
    for key, value in form_data.items():
        if key not in seen_keys:
            rows.append(
                {
                    "type": "full",
                    "fields": [
                        {
                            "label": key.replace("_", " ").title(),
                            "key": key,
                            "value": value,
                            "width": "full",
                        }
                    ],
                }
            )

    return rows


def _resolve_form_data_urls(form_data):
    """
    Return a copy of form_data with fresh presigned URLs injected for every
    file-upload entry (i.e. any dict value that contains a ``path`` key).

    Presigned S3/Spaces URLs expire and must never be stored in the database.
    This helper is called in views immediately before rendering a template so
    that the template always receives a valid, unexpired URL.

    Values that are not file-upload dicts are passed through unchanged.
    """
    if not form_data:
        return {}
    resolved = {}
    for key, value in form_data.items():
        if isinstance(value, dict) and "path" in value:
            # Build a fresh copy with a newly-generated URL
            entry = dict(value)  # shallow copy so we don't mutate the model field
            entry["url"] = get_file_url(value)  # may be None if storage is unavailable
            resolved[key] = entry
        else:
            resolved[key] = value
    return resolved


def get_client_ip(request):
    """Get client IP address from request"""
    x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded_for:
        ip = x_forwarded_for.split(",")[0]
    else:
        ip = request.META.get("REMOTE_ADDR")
    return ip


@login_required
@require_http_methods(["POST"])
def bulk_export_submissions(request):
    """Export selected submissions to an Excel spreadsheet.

    Expects a POST body with a JSON list of submission IDs.
    Only submissions whose WorkflowDefinition has ``allow_bulk_export=True``
    are included.  The user must have view permission on each submission
    (same rules as ``submission_detail``).
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
    except ImportError:
        return HttpResponse(
            "Excel export requires the openpyxl package. "
            "Install it with: pip install openpyxl",
            status=501,
        )

    # Parse submission IDs from form data
    submission_ids_raw = request.POST.getlist("submission_ids")
    if not submission_ids_raw:
        # Also accept JSON body
        try:
            body = json.loads(request.body)
            submission_ids_raw = body.get("submission_ids", [])
        except (json.JSONDecodeError, AttributeError):
            pass

    try:
        submission_ids = [int(sid) for sid in submission_ids_raw]
    except (ValueError, TypeError):
        return HttpResponse("Invalid submission IDs.", status=400)

    if not submission_ids:
        return HttpResponse("No submissions selected.", status=400)

    # Fetch submissions that are bulk-exportable
    submissions = (
        FormSubmission.objects.filter(id__in=submission_ids)
        .filter(form_definition__workflow__allow_bulk_export=True)
        .select_related("form_definition", "submitter")
        .order_by("form_definition__name", "-submitted_at")
    )

    # Permission check — only include submissions the user may view
    allowed = []
    for sub in submissions:
        can_view = (
            sub.submitter == request.user
            or request.user.is_superuser
            or user_can_approve(request.user, sub)
            or request.user.groups.filter(
                id__in=sub.form_definition.admin_groups.all()
            ).exists()
        )
        if can_view:
            allowed.append(sub)

    if not allowed:
        return HttpResponse("No exportable submissions found.", status=404)

    # Group submissions by form definition
    from collections import OrderedDict

    by_form: OrderedDict = OrderedDict()
    for sub in allowed:
        fd = sub.form_definition
        if fd.id not in by_form:
            by_form[fd.id] = {"form_def": fd, "submissions": []}
        by_form[fd.id]["submissions"].append(sub)

    # Build workbook — one sheet per form type
    wb = Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(
        start_color="4472C4", end_color="4472C4", fill_type="solid"
    )

    for group in by_form.values():
        fd = group["form_def"]
        subs = group["submissions"]

        # Sheet name (max 31 chars for Excel)
        sheet_name = fd.name[:31]
        ws = wb.create_sheet(title=sheet_name)

        # Determine columns from form field definitions
        fields = list(fd.fields.exclude(field_type="section").order_by("order"))
        field_names = [f.field_name for f in fields]
        field_labels = [f.field_label for f in fields]

        # Build headers: metadata columns + form field columns
        headers = [
            "Submission ID",
            "Submitter",
            "Status",
            "Submitted At",
            "Completed At",
        ]
        headers.extend(field_labels)

        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", wrap_text=True)

        # Write data rows
        for row_idx, sub in enumerate(subs, start=2):
            ws.cell(row=row_idx, column=1, value=sub.id)
            ws.cell(
                row=row_idx,
                column=2,
                value=sub.submitter.get_full_name() or sub.submitter.username,
            )
            ws.cell(row=row_idx, column=3, value=sub.get_status_display())
            ws.cell(
                row=row_idx,
                column=4,
                value=sub.submitted_at.strftime("%Y-%m-%d %H:%M")
                if sub.submitted_at
                else "",
            )
            ws.cell(
                row=row_idx,
                column=5,
                value=sub.completed_at.strftime("%Y-%m-%d %H:%M")
                if sub.completed_at
                else "",
            )

            form_data = sub.form_data or {}
            for field_col, fname in enumerate(field_names, start=6):
                value = form_data.get(fname, "")
                # Handle file upload dicts — just output filename
                if isinstance(value, dict) and "filename" in value:
                    value = value["filename"]
                # Handle lists (multiselect, checkboxes)
                elif isinstance(value, list):
                    value = ", ".join(str(v) for v in value)
                ws.cell(
                    row=row_idx, column=field_col, value=str(value) if value else ""
                )

        # Auto-size columns (approximate)
        for col_idx in range(1, len(headers) + 1):
            max_len = len(str(ws.cell(row=1, column=col_idx).value or ""))
            for row_idx in range(2, len(subs) + 2):
                cell_len = len(str(ws.cell(row=row_idx, column=col_idx).value or ""))
                if cell_len > max_len:
                    max_len = cell_len
            ws.column_dimensions[
                ws.cell(row=1, column=col_idx).column_letter
            ].width = min(max_len + 4, 50)

    # Serialize workbook to response
    from io import BytesIO

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    response = HttpResponse(
        buffer.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    response["Content-Disposition"] = 'attachment; filename="submissions_export.xlsx"'
    return response


def create_approval_tasks(submission):
    """
    Create approval tasks based on workflow definition.

    This is a placeholder - the actual implementation should be in workflow_engine.py
    """
    try:
        from .workflow_engine import create_workflow_tasks

        create_workflow_tasks(submission)
    except ImportError:
        logger.warning("Workflow engine not available")
        # No approval needed, mark as approved
        submission.status = "approved"
        submission.completed_at = timezone.now()
        submission.save()
