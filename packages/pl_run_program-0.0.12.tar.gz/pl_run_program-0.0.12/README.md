# pl-run-program

A simple interface for running non-python programs in python.

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE).
