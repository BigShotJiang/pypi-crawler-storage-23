Shows the Product Tags menu in Purchase app
