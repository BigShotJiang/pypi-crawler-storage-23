from typing import Callable, Optional
from abc import ABC

import torch
import torch.nn as nn


class KernelBackendTorch(nn.Module, ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[torch.Tensor] = None,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        if X is None:
            X = torch.empty((0, 0))

        self.register_buffer("_X", X.float())
        self._N = int(self.X.shape[0])

        self.func = func

        if chunk_size is None:
            chunk_size = self.N

        self.chunk_size = chunk_size

    @property
    def X(self) -> torch.Tensor:
        if isinstance(self._X, torch.Tensor):
            return self._X

        raise RuntimeError()

    @property
    def N(self) -> int:
        return self._N

    def forward(
        self, x: torch.Tensor, y: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        return self.func(x, y)

    def __getitem__(self, key):
        with torch.no_grad():
            if isinstance(key, tuple):
                row_idx, col_idx = key
            else:
                row_idx, col_idx = key, slice(None)

            return self.forward(self.X[row_idx], self.X[col_idx])

    def __matmul__(self, v: torch.Tensor) -> torch.Tensor:
        N, D = self.N, v.shape[1] if v.ndim > 1 else 1

        v = v.view(N, D)
        result = torch.zeros((N, D), device=self.X.device)

        for i in range(0, N, self.chunk_size):
            end_i = min(i + self.chunk_size, N)
            K_i = self.forward(self.X[i:end_i], self.X)

            result[i:end_i] = torch.mm(K_i, v)

        return result.squeeze()
