from typing import Any, Callable, Optional
from vicentin.kernels import LinearKernel


class PhiKernel(LinearKernel):
    def __init__(self, X: Any, phi: Callable, **kwargs) -> None:
        self.phi = phi

        super().__init__(self.phi(X), **kwargs)

    def _compute(self, x: Any, y: Optional[Any] = None):
        x_phi = self.phi(x)
        y_phi = self.phi(y) if y is not None else None

        return super()._compute(x_phi, y_phi)
