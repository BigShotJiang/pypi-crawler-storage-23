FLIP - Federated Learning Interoperability Platform
Copyright 2026 Guy's and St Thomas' NHS Foundation Trust & King's College London

This product includes software developed at
Guy's and St Thomas' NHS Foundation Trust & King's College London
(<https://gsttfoundation.org.uk/>, <https://www.kcl.ac.uk/>).
