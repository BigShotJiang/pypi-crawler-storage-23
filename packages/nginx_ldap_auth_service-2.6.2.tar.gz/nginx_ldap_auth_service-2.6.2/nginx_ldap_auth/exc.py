class ImproperlyConfigured(Exception):
    """
    Raised when the application is improperly configured.
    """
