__version__: str = "2.6.2"
__author__: str = "Caltech IMSS ADS"
__author_email__: str = "imss-ads-staff@caltech.edu"
__description__: str = (
    "A FastAPI app that authenticates users via LDAP and sets a cookie for nginx"
)
