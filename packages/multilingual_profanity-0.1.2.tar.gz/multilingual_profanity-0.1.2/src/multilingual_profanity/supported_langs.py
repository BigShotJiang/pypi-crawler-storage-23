import os

raw_dir = os.path.join(os.path.dirname(__file__), "data", "raw")
langs = sorted(f[:-4] for f in os.listdir(raw_dir) if f.endswith(".txt"))

print("SUPPORTED_LANGUAGES: frozenset[str] = frozenset(")
print("    {")
for lang in langs:
    print(f'        "{lang}",')
print("    }")
print(")")
