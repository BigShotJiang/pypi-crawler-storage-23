from pathlib import Path

import pandas as pd


def build_profanity_parquet(
    txt_dir="src/multilingual_profanity/data/raw",
    output_file="src/multilingual_profanity/data/profanity.parquet",
):
    print("🔨 Building unified Multilingual Parquet file...")

    txt_dir_path = Path(txt_dir)
    output_path = Path(output_file)

    # Ensure the output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not txt_dir_path.exists():
        print(f"❌ Error: Text directory '{txt_dir}' not found.")
        return

    data = []

    # Loop through all .txt files in the directory
    for txt_path in txt_dir_path.glob("*.txt"):
        lang_code = txt_path.stem  # e.g., 'nl.txt' -> 'nl'

        with open(txt_path, "r", encoding="utf-8") as f:
            for line in f:
                word = line.strip().lower()
                # Skip empty lines
                if word:
                    data.append({"lang": lang_code, "word": word})

    if not data:
        print("⚠️ No words found in the text files.")
        return

    # Use Pandas purely for the build step (fast deduplication and Parquet writing)
    df = pd.DataFrame(data)

    # Drop duplicates just in case the raw text files have repeats
    df = df.drop_duplicates()

    # Save to Parquet using PyArrow engine
    df.to_parquet(output_path, engine="pyarrow", index=False)

    print(
        f"✅ Success! Saved {len(df)} total blocked words across {df['lang'].nunique()} languages."
    )
    print(f"💾 File saved to: {output_path}")


if __name__ == "__main__":
    build_profanity_parquet()
