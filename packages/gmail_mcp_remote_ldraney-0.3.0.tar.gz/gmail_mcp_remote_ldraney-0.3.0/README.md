[![PyPI](https://img.shields.io/pypi/v/gmail-mcp-remote-ldraney)](https://pypi.org/project/gmail-mcp-remote-ldraney/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

# gmail-mcp-remote
HTTP/Streamable-HTTP wrapper for gmail-mcp — 3-party OAuth proxy for Claude.ai and cluster integration

## Privacy

See [PRIVACY.md](PRIVACY.md) for our privacy policy.
