"""Gmail MCP Remote — HTTP/OAuth wrapper for gmail-mcp."""
