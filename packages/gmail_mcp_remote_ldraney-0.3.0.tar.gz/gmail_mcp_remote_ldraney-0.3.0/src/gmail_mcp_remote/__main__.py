"""Entry point for `python -m gmail_mcp_remote`."""

from gmail_mcp_remote.server import main

main()
