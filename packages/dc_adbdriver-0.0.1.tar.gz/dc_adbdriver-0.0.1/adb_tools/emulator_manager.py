import subprocess
import os
from time import sleep
import time
import logging

class EmulatorManager:
    def __init__(self):
        self.creation_flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0

    def device_index(self, index):
        return f"emulator-{5554 + 2 * index}"
            
    def list_devices(self):
        try:
            result = subprocess.run(["adb", "devices"], capture_output=True, text=True, check=True, creationflags=self.creation_flags)
            lines = result.stdout.strip().splitlines()[1:]
            devices = []
            for line in lines:
                if line.strip():
                    device_id, _ = line.split()
                    devices.append(device_id)
                    
            return devices
        except Exception as e:
            logging.error(f"Error listing devices: {e}")
            return []   
        
    def wait_for_online(self, index, timeout=30):
        start_time = time.time()
        while True:
            devices = self.list_devices()
            if index in devices:
                return True
            
            if time.time() - start_time > timeout:
                raise RuntimeError("Failed connecting...")
            
            sleep(0.5)     