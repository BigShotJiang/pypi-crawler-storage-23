# Staff Review (Second Pass): code-first-pipeline-rfc.md

**Reviewed RFC**: `code-first-pipeline-rfc.md` (rev 2)  
**Review type**: Staff engineer design review (delta update)  
**Date**: 2026-02-16  
**Decision**: Conditionally approve (2 must-fix blockers remain)

## Executive Summary

The revised RFC is materially stronger and addresses most first-pass findings: thread-safe lazy registration is now correct, class-form transform references are removed, public `to_config_dict()` is introduced, and lazy re-export strategy is specified.

Two blockers remain before merge:

1. Fingerprint scheme/versioning is internally inconsistent.
2. Thread-safety mitigation overclaims what `copy.copy()` guarantees.

## Status Since First Pass

### Closed

1. Lazy registration race: fixed with lock + post-import flag set.
2. Transform reference forms: class-form removed intentionally.
3. Validator/fixer config API: `to_config_dict()` added and documented.
4. Re-export/lazy loading conflict: addressed via `__getattr__` lazy imports.
5. Contracts/test plan sections: added and substantially improved.

### Still Open (must fix)

1. Fingerprint scheme compatibility/versioning contradictions.
2. Concurrency safety claim exceeds actual guarantee of shallow copy.

## Findings (ordered by severity)

### 1. High: fingerprint scheme/versioning contradictions

The RFC adds a new canonical fingerprint component (`transform_id`) but still claims unchanged scheme/version and no cache invalidation.

- New component introduced: `code-first-pipeline-rfc.md:325`
- Claims existing caches not invalidated: `code-first-pipeline-rfc.md:307`
- Claims fingerprint scheme unchanged (`synix:transform:v1`): `code-first-pipeline-rfc.md:508`
- Existing cache semantics doc says component changes require scheme bump: `cache-semantics.md:46`

These are incompatible unless `transform_id` is already present in current `v1` implementation (the RFC text currently says it is new).

**Required fix**

Pick one explicit path and document it:

1. **Bump scheme to `synix:transform:v2`** and accept one-time cache invalidation, or
2. **Keep `v1` unchanged** and do not add `transform_id` to digest in this RFC.

Also update the compatibility matrix and “What Stays Unchanged” section so claims are exact.

### 2. Medium: `copy.copy()` does not guarantee isolation for nested mutable state

The RFC states per-worker `copy.copy(transform)` prevents cross-thread corruption “even if accidental `self` mutation” occurs.

- Claim + mechanism: `code-first-pipeline-rfc.md:360`-`code-first-pipeline-rfc.md:361`
- Strong guarantee statement: `code-first-pipeline-rfc.md:450`

`copy.copy()` is shallow; nested mutables remain shared. The current text overstates safety.

**Required fix**

Adjust wording to match actual guarantees:

1. Keep the normative “no mutation of `self`” contract as primary safety mechanism.
2. Describe `copy.copy()` as a best-effort guard, not a full isolation guarantee.
3. If full isolation is required, use `deepcopy` (with cost caveats) or fresh instance construction per task.

## Additional Consistency Issues (should fix)

### 3. Medium: error semantics table contradicts failure-mode section

- Error table says lazy import failure yields `ValueError`: `code-first-pipeline-rfc.md:424`
- Failure mode section says import error propagates: `code-first-pipeline-rfc.md:438`

**Fix**: choose one behavior (recommended: propagate import error) and make both sections consistent.

### 4. Low: validator contract has a MUST vs fallback contradiction

- Says custom validators with typed constructors MUST provide `layers` via `to_config_dict()`: `code-first-pipeline-rfc.md:394`
- Also says missing override defaults to `{}` and validates all artifacts: `code-first-pipeline-rfc.md:397`

**Fix**: either relax MUST to SHOULD, or remove permissive fallback for new code and fail fast.

## Updated Merge Gate

### Must Fix Before Merge

1. Resolve fingerprint scheme/versioning contradiction (`transform_id` vs `v1`/cache reuse claims).
2. Correct concurrency safety guarantee language around shallow copy.

### Should Fix In This RFC

1. Reconcile lazy import failure semantics (`ValueError` vs import exception).
2. Reconcile validator `to_config_dict()` contract strictness.

## Suggested Test Additions (still recommended)

1. Concurrent cold-start `get_transform()` test.
2. Fingerprint differentiation test for constructor-state transforms.
3. Cross-process fingerprint determinism test.
4. Mixed mode (string + instance) execution equivalence test.

## Prior Art Alignment

No change from first pass: the overall code-first direction remains aligned with Airflow TaskFlow, Prefect flow authoring, and Beam transform composition patterns.

## Sources

- Airflow TaskFlow tutorial: <https://airflow.apache.org/docs/apache-airflow/3.0.0/tutorial/taskflow.html>
- Airflow dynamic DAG generation/top-level code guidance: <https://airflow.apache.org/docs/apache-airflow/stable/howto/dynamic-dag-generation.html>
- Prefect flows: <https://docs.prefect.io/v3/concepts/flows>
- Apache Beam programming guide: <https://beam.apache.org/documentation/programming-guide/>
- Python `copy` module behavior: <https://docs.python.org/3/library/copy.html>
- Python `importlib.metadata` entry points: <https://docs.python.org/3.10/library/importlib.metadata.html>
- Python packaging plugin discovery: <https://packaging.python.org/en/latest/guides/creating-and-discovering-plugins/>
