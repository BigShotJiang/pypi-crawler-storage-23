## Summary

<!-- What changed and why? -->

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Refactor
- [ ] Docs
- [ ] Tests

## Validation

- [ ] Ran tests locally
- [ ] Added/updated tests where needed
- [ ] Updated docs (if applicable)

## Related Issues

<!-- Link issues, e.g. Closes #123 -->

## Notes

<!-- Any tradeoffs, follow-ups, or reviewer context -->
