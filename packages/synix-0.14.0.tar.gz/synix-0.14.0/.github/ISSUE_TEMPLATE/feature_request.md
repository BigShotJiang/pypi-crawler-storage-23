---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

## Problem

<!-- What problem are you trying to solve? -->

## Proposed Solution

<!-- What would you like to happen? -->

## Alternatives Considered

## Additional Context
