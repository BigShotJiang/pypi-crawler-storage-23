"""team_report demo case — ext transforms pipeline with multi-level DAG.

Flow:
  1. Plan     — show the DAG and what will be built
  2. Build    — parse bios + brief, map work styles, reduce team dynamics,
                fold final report
  3. Search   — query across all layers
  4. Validate — check final report has input_count
  5. Rebuild  — second run, everything cached
  6. Explain  — show cache decisions inline

This demonstrates:
  - Two independent level-0 source layers (bios + project_brief)
  - MapSynthesis: 1:1 LLM transform (bio → work style profile)
  - ReduceSynthesis: N:1 rollup (work styles → team dynamics)
  - FoldSynthesis: sequential accumulation (team dynamics + brief → final report)
  - Full-text search across all 5 layers with provenance
  - Incremental rebuild (second run is instant)
  - Explain-cache with inline fingerprint breakdown
"""

case = {
    "name": "team_report",
    "pipeline": "pipeline.py",
    "steps": [
        # Step 1: Plan
        {"name": "note_plan", "command": ["synix", "demo", "note", "1/6 Planning build..."]},
        {"name": "plan", "command": ["synix", "plan", "PIPELINE"]},
        # Step 2: Build
        {
            "name": "note_build",
            "command": ["synix", "demo", "note", "2/6 Building: bios → work styles → team dynamics → final report..."],
        },
        {"name": "build", "command": ["synix", "build", "PIPELINE"]},
        # Step 3: Search
        {"name": "note_search", "command": ["synix", "demo", "note", "3/6 Searching across all layers..."]},
        {"name": "search", "command": ["synix", "search", "climate dashboard", "--mode", "keyword", "--limit", "3"]},
        # Step 4: Validate
        {"name": "note_validate", "command": ["synix", "demo", "note", "4/6 Validating final report..."]},
        {"name": "validate", "command": ["synix", "validate", "PIPELINE", "--json"], "capture_json": True},
        # Step 5: Rebuild — everything cached
        {
            "name": "note_rebuild",
            "command": ["synix", "demo", "note", "5/6 Rebuilding (nothing changed → all cached)..."],
        },
        {"name": "rebuild", "command": ["synix", "build", "PIPELINE"]},
        # Step 6: Explain cache decisions
        {"name": "note_explain", "command": ["synix", "demo", "note", "6/6 Explaining cache decisions..."]},
        {"name": "explain", "command": ["synix", "plan", "PIPELINE", "--explain-cache"]},
    ],
    "goldens": {
        "validate": "validate.json",
    },
}
