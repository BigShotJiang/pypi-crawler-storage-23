"""Backward compatibility shim — moved to synix.build.projections."""

from synix.build.projections import FlatFileProjection  # noqa: F401
