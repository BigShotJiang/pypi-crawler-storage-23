"""Public re-exports for projection layer types.

Usage:
    from synix.projections import SearchIndex, FlatFile
"""

from synix.core.models import FlatFile, SearchIndex  # noqa: F401
