"""Backward compatibility shim — moved to synix.search.indexer."""

from synix.search.indexer import SearchIndexProjection  # noqa: F401
