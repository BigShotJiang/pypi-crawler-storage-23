"""Backward compatibility shim — ProvenanceTracker moved to synix.build.provenance."""

from synix.build.provenance import ProvenanceTracker  # noqa: F401
