"""Backward compatibility shim — ArtifactStore moved to synix.build.artifacts."""

from synix.build.artifacts import ArtifactStore  # noqa: F401
