"""Backward compatibility shim — moved to synix.build.dag."""

from synix.build.dag import needs_rebuild, resolve_build_order  # noqa: F401
