"""Backward compatibility shim — moved to synix.build.pipeline."""

from synix.build.pipeline import load_pipeline, validate_pipeline  # noqa: F401
