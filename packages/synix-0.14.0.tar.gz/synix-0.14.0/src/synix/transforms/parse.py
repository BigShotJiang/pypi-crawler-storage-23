"""Backward compatibility shim — moved to synix.build.parse_transform."""

from synix.build.parse_transform import ParseTransform  # noqa: F401
