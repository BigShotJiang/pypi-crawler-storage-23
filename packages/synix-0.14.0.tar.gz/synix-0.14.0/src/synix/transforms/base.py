"""Backward compatibility shim — use synix.core.models.Transform."""

from synix.build.transforms import PROMPTS_DIR, BaseTransform  # noqa: F401
