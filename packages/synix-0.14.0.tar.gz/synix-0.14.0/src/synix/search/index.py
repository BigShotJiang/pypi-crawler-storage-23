"""Backward compatibility shim — merged into synix.search.indexer."""

from synix.search.indexer import SearchIndex  # noqa: F401
