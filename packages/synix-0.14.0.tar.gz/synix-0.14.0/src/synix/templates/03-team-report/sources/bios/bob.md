Bob Martinez is a product designer based in Austin who focuses on accessibility.
He previously worked at two startups before joining a design agency.
He runs a weekend pottery class at the local community center.
