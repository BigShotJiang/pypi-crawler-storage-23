Carol Okafor is a data scientist living in Chicago who works on climate modeling.
She holds a PhD in atmospheric physics from MIT.
She volunteers as a mentor for underrepresented students in STEM.
