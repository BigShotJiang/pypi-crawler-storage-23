"""Synix CLI — Click commands with Rich formatting."""

from synix.cli.main import main  # noqa: F401
