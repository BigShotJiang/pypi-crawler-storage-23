"""Backward compatibility — use synix.adapters."""
