"""
Test: Which quantization mode gives BEST TRAINING results?

Hypothesis: More aggressive quantization = more regularization = better generalization
"""

import torch
import torch.nn as nn
import copy
from torch.utils.data import DataLoader, TensorDataset

# Simple training test - overfit detection
print("="*60)
print("TRAINING TEST: Which mode prevents overfitting best?")
print("="*60)

# Create overfitting scenario: small dataset, large model
torch.manual_seed(42)
X = torch.randn(100, 256)  # Only 100 samples
Y = torch.randn(100, 256)

# Large model that WILL overfit
class LargeModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(256, 1024),
            nn.ReLU(),
            nn.Linear(1024, 1024),
            nn.ReLU(),
            nn.Linear(1024, 1024),
            nn.ReLU(),
            nn.Linear(1024, 256)
        )
    def forward(self, x):
        return self.layers(x)

def train_and_eval(model, name, epochs=100):
    """Train and return train/test loss to measure overfitting."""
    model = model.cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.MSELoss()

    # Split data
    X_train, X_test = X[:80].cuda(), X[80:].cuda()
    Y_train, Y_test = Y[:80].cuda(), Y[80:].cuda()

    train_losses = []
    test_losses = []

    for epoch in range(epochs):
        # Train
        model.train()
        optimizer.zero_grad()
        out = model(X_train)
        loss = criterion(out, Y_train)
        loss.backward()
        optimizer.step()
        train_losses.append(loss.item())

        # Test
        model.eval()
        with torch.no_grad():
            test_out = model(X_test)
            test_loss = criterion(test_out, Y_test)
            test_losses.append(test_loss.item())

    # Overfitting ratio: test_loss / train_loss (higher = more overfit)
    final_train = train_losses[-1]
    final_test = test_losses[-1]
    overfit_ratio = final_test / final_train

    print(f"{name:<15} Train: {final_train:.4f}  Test: {final_test:.4f}  Overfit: {overfit_ratio:.2f}x")

    return final_train, final_test, overfit_ratio

# Test 1: FP32 baseline
print("\n1. FP32 BASELINE")
model_fp32 = LargeModel()
train_and_eval(model_fp32, "FP32")

# Import quantization
import sys
sys.path.insert(0, '.')
from v4 import quantize_model_v4
from v2 import quantize_model_v2
from v3 import quantize_model_v3

# Test 2: V2 (8x, regularization mode)
print("\n2. INSTANT-QUANT V2 (8x compression)")
model_v2 = LargeModel()
model_v2 = quantize_model_v2(model_v2, verbose=False)
train_and_eval(model_v2, "V2 (8x)")

# Test 3: V4 none mode (same as V2)
print("\n3. V4 none mode (7x)")
model_v4_none = LargeModel()
model_v4_none = quantize_model_v4(model_v4_none, error_mode='none', verbose=False)
train_and_eval(model_v4_none, "V4 none (7x)")

# Test 4: V4 int2 mode
print("\n4. V4 int2 mode (5x)")
model_v4_int2 = LargeModel()
model_v4_int2 = quantize_model_v4(model_v4_int2, error_mode='int2', verbose=False)
train_and_eval(model_v4_int2, "V4 int2 (5x)")

# Test 5: V4 int4 mode (near-lossless)
print("\n5. V4 int4 mode (4x)")
model_v4_int4 = LargeModel()
model_v4_int4 = quantize_model_v4(model_v4_int4, error_mode='int4', verbose=False)
train_and_eval(model_v4_int4, "V4 int4 (4x)")

# Test 6: V3 (lossless)
print("\n6. V3 lossless (2.5x)")
model_v3 = LargeModel()
model_v3 = quantize_model_v3(model_v3, verbose=False)
train_and_eval(model_v3, "V3 (2.5x)")

print("\n" + "="*60)
print("INTERPRETATION:")
print("- Lower overfit ratio = better generalization")
print("- Higher compression with similar overfit = better overall")
print("="*60)
