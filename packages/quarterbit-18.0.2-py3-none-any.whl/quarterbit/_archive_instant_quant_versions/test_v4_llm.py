"""Test V4 modes on TinyLlama"""

import torch
import copy
import sys
sys.path.insert(0, '.')

from v4 import quantize_model_v4, estimate_compression

print("="*60)
print("V4 LLM TEST: TinyLlama-1.1B")
print("="*60)

from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset

tokenizer = AutoTokenizer.from_pretrained("TinyLlama/TinyLlama-1.1B-Chat-v1.0")
tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    torch_dtype=torch.float16
).cuda()

dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="test")

def compute_ppl(model, max_samples=50):
    model.eval()
    total_loss = 0
    total_tokens = 0
    with torch.no_grad():
        for i, sample in enumerate(dataset):
            if i >= max_samples:
                break
            text = sample['text']
            if len(text.strip()) < 50:
                continue
            inputs = tokenizer(text, return_tensors='pt', truncation=True, max_length=512)
            inputs = {k: v.cuda() for k, v in inputs.items()}
            if inputs['input_ids'].shape[1] < 2:
                continue
            outputs = model(**inputs, labels=inputs['input_ids'])
            total_loss += outputs.loss.item() * inputs['input_ids'].shape[1]
            total_tokens += inputs['input_ids'].shape[1]
    return torch.exp(torch.tensor(total_loss / total_tokens)).item()

# Baseline
print("\nComputing FP16 baseline...")
ppl_fp16 = compute_ppl(model)
print(f"FP16 PPL: {ppl_fp16:.2f}")

# Test different V4 modes
modes = ['none', 'int2', 'int4']
results = []

for mode in modes:
    print(f"\nTesting V4 error_mode='{mode}'...")
    model_q = copy.deepcopy(model)
    model_q = quantize_model_v4(model_q, bits=4, group_size=32, error_mode=mode, verbose=False)

    ppl = compute_ppl(model_q)
    change = ((ppl - ppl_fp16) / ppl_fp16) * 100
    compression = estimate_compression(mode)

    print(f"  PPL: {ppl:.2f} ({change:+.1f}%), Compression: {compression:.1f}x")
    results.append((mode, ppl, change, compression))

    del model_q
    torch.cuda.empty_cache()

# Summary
print("\n" + "="*60)
print("SUMMARY")
print("="*60)
print(f"{'Mode':<10} {'PPL':<10} {'Change':<10} {'Compression':<12}")
print("-"*45)
print(f"{'FP16':<10} {ppl_fp16:<10.2f} {'---':<10} {'1x':<12}")
for mode, ppl, change, compression in results:
    print(f"{mode:<10} {ppl:<10.2f} {change:+.1f}%{'':<5} {compression:.1f}x")
