"""
INSTANT-QUANT: Zero-Shot Model Quantization
============================================

Part of QuarterBit - the full-stack compressed training system.

Modules:
- v2: 8x compression with regularization effect
- v3: 2.5x compression with VLA error feedback (lossless)
- fast_core: Fast FP64-based quantization

Usage:
    from quarterbit.instant_quant import quantize_model_v2, quantize_model_v3

    # 8x compression, regularization mode
    model = quantize_model_v2(model, bits=4, group_size=32)

    # 2.5x compression, lossless mode
    model = quantize_model_v3(model, bits=4, group_size=32)
"""

from .v2 import (
    instant_quant_v2,
    dequant_v2,
    QuantizedLinearV2,
    QuantizedConv1DV2,
    quantize_model_v2
)

from .v3 import (
    instant_quant_v3,
    dequant_v3,
    QuantizedLinearV3,
    QuantizedConv1DV3,
    quantize_model_v3,
    toggle_error_correction,
    stochastic_round,
    compute_layer_sigma
)

from .fast_core import (
    compensated_dot,
    optimal_scale_fast,
    optimal_scales_grouped,
    QuantizedLinearFast,
    QuantizedConv1D,
    quantize_model_fast
)

__all__ = [
    # V2
    'instant_quant_v2',
    'dequant_v2',
    'QuantizedLinearV2',
    'QuantizedConv1DV2',
    'quantize_model_v2',
    # V3
    'instant_quant_v3',
    'dequant_v3',
    'QuantizedLinearV3',
    'QuantizedConv1DV3',
    'quantize_model_v3',
    'toggle_error_correction',
    'stochastic_round',
    'compute_layer_sigma',
    # Fast
    'compensated_dot',
    'optimal_scale_fast',
    'optimal_scales_grouped',
    'QuantizedLinearFast',
    'QuantizedConv1D',
    'quantize_model_fast',
]
