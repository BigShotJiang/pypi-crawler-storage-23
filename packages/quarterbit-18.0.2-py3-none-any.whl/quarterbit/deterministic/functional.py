"""
VLA Deterministic Functional API
================================

Drop-in replacements for torch.nn.functional operations.
Cross-hardware reproducible on any GPU architecture.
"""

import torch
import torch.nn.functional as F_torch
from typing import Optional, Tuple, Union
from . import ops


def linear(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None
) -> torch.Tensor:
    """
    Deterministic linear transformation: y = x @ W^T + b

    Cross-hardware reproducible: same bits on any GPU architecture.

    Args:
        input: (*, in_features) tensor
        weight: (out_features, in_features) tensor
        bias: optional (out_features,) tensor

    Returns:
        output: (*, out_features) tensor
    """
    # Handle batched input
    input_shape = input.shape
    in_features = weight.shape[1]
    out_features = weight.shape[0]

    # Flatten batch dimensions (use reshape for non-contiguous tensors)
    if input.dim() > 2:
        input_flat = input.reshape(-1, in_features)
    else:
        input_flat = input.contiguous()

    # Ensure float32 for VLA
    input_f32 = input_flat.float().contiguous()
    weight_f32 = weight.float().contiguous()

    # y = x @ W^T
    output = ops.matmul(input_f32, weight_f32.t())

    # Add bias if present
    if bias is not None:
        bias_f32 = bias.float()
        output = output + bias_f32

    # Restore batch shape
    if input.dim() > 2:
        output_shape = input_shape[:-1] + (out_features,)
        output = output.reshape(*output_shape)

    return output


def conv2d(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    stride: Union[int, Tuple[int, int]] = 1,
    padding: Union[int, Tuple[int, int]] = 0,
    dilation: Union[int, Tuple[int, int]] = 1,
    groups: int = 1
) -> torch.Tensor:
    """
    Deterministic 2D convolution using im2col + VLA matmul.

    Cross-hardware reproducible: same bits on any GPU architecture.

    Args:
        input: (N, C_in, H, W) tensor
        weight: (C_out, C_in/groups, kH, kW) tensor
        bias: optional (C_out,) tensor
        stride, padding, dilation, groups: same as torch.nn.functional.conv2d

    Returns:
        output: (N, C_out, H_out, W_out) tensor
    """
    # Normalize stride, padding, dilation to tuples
    if isinstance(stride, int):
        stride = (stride, stride)
    if isinstance(padding, int):
        padding = (padding, padding)
    if isinstance(dilation, int):
        dilation = (dilation, dilation)

    N, C_in, H, W = input.shape
    C_out, C_in_per_group, kH, kW = weight.shape

    assert C_in == C_in_per_group * groups, "Channel mismatch"

    # Calculate output dimensions
    H_out = (H + 2 * padding[0] - dilation[0] * (kH - 1) - 1) // stride[0] + 1
    W_out = (W + 2 * padding[1] - dilation[1] * (kW - 1) - 1) // stride[1] + 1

    # Use unfold to extract patches (im2col)
    # This gives us a tensor we can matmul with reshaped weights
    input_padded = F_torch.pad(input, (padding[1], padding[1], padding[0], padding[0]))

    # For simplicity, use unfold which handles im2col
    # unfold extracts sliding local blocks
    patches = input_padded.unfold(2, kH, stride[0]).unfold(3, kW, stride[1])
    # patches shape: (N, C_in, H_out, W_out, kH, kW)

    # Reshape for matmul
    # We want: (N, H_out*W_out, C_in*kH*kW) @ (C_in*kH*kW, C_out) -> (N, H_out*W_out, C_out)
    patches = patches.permute(0, 2, 3, 1, 4, 5).contiguous()
    patches = patches.view(N, H_out * W_out, C_in * kH * kW)

    # Reshape weight: (C_out, C_in, kH, kW) -> (C_in*kH*kW, C_out)
    weight_col = weight.view(C_out, -1).t().contiguous()

    # Ensure float32
    patches_f32 = patches.float()
    weight_f32 = weight_col.float()

    # VLA matmul for each batch element
    output = torch.zeros(N, H_out * W_out, C_out, dtype=torch.float32, device=input.device)
    for n in range(N):
        output[n] = ops.matmul(patches_f32[n], weight_f32)

    # Reshape to (N, C_out, H_out, W_out)
    output = output.permute(0, 2, 1).view(N, C_out, H_out, W_out)

    # Add bias
    if bias is not None:
        output = output + bias.view(1, -1, 1, 1)

    return output


def conv1d(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    stride: int = 1,
    padding: int = 0,
    dilation: int = 1,
    groups: int = 1
) -> torch.Tensor:
    """
    Deterministic 1D convolution.

    Implemented by adding a dimension and using conv2d.
    """
    # (N, C, L) -> (N, C, 1, L)
    input_2d = input.unsqueeze(2)
    # (C_out, C_in, K) -> (C_out, C_in, 1, K)
    weight_2d = weight.unsqueeze(2)

    output_2d = conv2d(
        input_2d, weight_2d, bias,
        stride=(1, stride),
        padding=(0, padding),
        dilation=(1, dilation),
        groups=groups
    )

    # (N, C_out, 1, L_out) -> (N, C_out, L_out)
    return output_2d.squeeze(2)


def batch_norm(
    input: torch.Tensor,
    running_mean: Optional[torch.Tensor],
    running_var: Optional[torch.Tensor],
    weight: Optional[torch.Tensor] = None,
    bias: Optional[torch.Tensor] = None,
    training: bool = False,
    momentum: float = 0.1,
    eps: float = 1e-5
) -> torch.Tensor:
    """
    Deterministic batch normalization.

    Uses VLA sum for mean/variance calculation in training mode.
    """
    if not training and running_mean is not None and running_var is not None:
        # Inference mode - use running stats (already deterministic)
        return F_torch.batch_norm(
            input, running_mean, running_var, weight, bias,
            training=False, momentum=momentum, eps=eps
        )

    # Training mode - compute stats deterministically
    N, C = input.shape[0], input.shape[1]
    spatial_dims = input.shape[2:]
    num_elements = N * torch.tensor(spatial_dims).prod().item()

    # Reshape for easier reduction: (N, C, *)
    x = input.view(N, C, -1)

    # Compute mean using VLA sum
    mean = torch.zeros(C, device=input.device, dtype=torch.float64)
    for c in range(C):
        mean[c] = ops.sum(x[:, c, :].contiguous()) / num_elements

    # Compute variance using VLA
    x_centered = x - mean.view(1, C, 1).float()
    var = torch.zeros(C, device=input.device, dtype=torch.float64)
    for c in range(C):
        var[c] = ops.sum((x_centered[:, c, :] ** 2).contiguous()) / num_elements

    # Normalize
    std = (var.float() + eps).sqrt()
    x_norm = x_centered / std.view(1, C, 1)

    # Scale and shift
    if weight is not None:
        x_norm = x_norm * weight.view(1, C, 1)
    if bias is not None:
        x_norm = x_norm + bias.view(1, C, 1)

    # Restore shape
    output = x_norm.view_as(input)

    # Update running stats
    if running_mean is not None:
        running_mean.data = (1 - momentum) * running_mean + momentum * mean.float()
    if running_var is not None:
        running_var.data = (1 - momentum) * running_var + momentum * var.float()

    return output


def softmax(input: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """
    Deterministic softmax.

    Uses VLA sum for the normalization denominator.
    """
    # Subtract max for numerical stability (detach to avoid extra gradients)
    max_val = input.max(dim=dim, keepdim=True)[0].detach()
    exp_x = torch.exp(input - max_val)

    # VLA sum along dim
    if dim == -1:
        dim = input.dim() - 1

    # Move dim to last position for easier processing
    x_moved = exp_x.movedim(dim, -1)
    original_shape = x_moved.shape
    x_flat = x_moved.reshape(-1, x_moved.shape[-1])

    # Sum each row using VLA - preserve autograd by using stack
    sum_list = []
    for i in range(x_flat.shape[0]):
        sum_list.append(ops.sum(x_flat[i].contiguous()))

    # Stack preserves autograd
    sums = torch.stack(sum_list)

    # Normalize - sums has shape (num_rows,), need (num_rows, 1) for broadcast
    x_norm = x_flat / sums.unsqueeze(1)
    x_norm = x_norm.view(*original_shape)
    output = x_norm.movedim(-1, dim)

    return output


def log_softmax(input: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """
    Deterministic log_softmax.

    Uses VLA sum for the normalization denominator.
    log_softmax(x) = x - max(x) - log(sum(exp(x - max(x))))
    """
    if dim == -1:
        dim = input.dim() - 1

    # Subtract max for numerical stability (detach max to avoid extra gradients)
    max_val = input.max(dim=dim, keepdim=True)[0].detach()
    shifted = input - max_val

    exp_x = torch.exp(shifted)

    # Move dim to last position for easier processing
    x_moved = exp_x.movedim(dim, -1)
    original_shape = x_moved.shape
    x_flat = x_moved.reshape(-1, x_moved.shape[-1])

    # Sum each row using VLA - preserve autograd by using stack
    log_sum_list = []
    for i in range(x_flat.shape[0]):
        sum_val = ops.sum(x_flat[i].contiguous())
        log_sum_list.append(torch.log(sum_val))

    # Stack preserves autograd
    log_sums = torch.stack(log_sum_list)

    # Reshape log_sums back to match input shape (minus the softmax dim)
    log_sums_shape = list(original_shape[:-1])
    if len(log_sums_shape) == 0:
        log_sums_reshaped = log_sums.squeeze()
    else:
        log_sums_reshaped = log_sums.view(*log_sums_shape)

    # Move back if needed and add dimension for broadcasting
    if dim != input.dim() - 1:
        log_sums_reshaped = log_sums_reshaped.movedim(-1, dim)

    # log_softmax = shifted - log(sum(exp(shifted)))
    output = shifted - log_sums_reshaped.unsqueeze(dim)

    return output


def cross_entropy(
    input: torch.Tensor,
    target: torch.Tensor,
    weight: Optional[torch.Tensor] = None,
    ignore_index: int = -100,
    reduction: str = 'mean',
    label_smoothing: float = 0.0
) -> torch.Tensor:
    """
    Deterministic cross-entropy loss.

    Uses VLA-based log_softmax and sum for full cross-hardware reproducibility.

    Args:
        input: (N, C) tensor of logits
        target: (N,) tensor of class indices
        weight: optional (C,) tensor of class weights
        ignore_index: target value to ignore
        reduction: 'none', 'mean', or 'sum'
        label_smoothing: amount of label smoothing

    Returns:
        Loss tensor
    """
    # Compute log_softmax deterministically
    log_probs = log_softmax(input, dim=-1)

    # Get number of classes
    n_classes = input.shape[-1]

    # Create mask for valid targets
    valid_mask = target != ignore_index

    # Clamp target to valid range for gathering (will be masked anyway)
    target_clamped = target.clamp(0, n_classes - 1)

    # Gather log probabilities for target classes
    # target_clamped: (N,) -> (N, 1) for gather
    nll = -log_probs.gather(dim=-1, index=target_clamped.unsqueeze(-1)).squeeze(-1)

    # Apply label smoothing if needed
    if label_smoothing > 0:
        # smooth_loss = -mean(log_probs, dim=-1) - preserve autograd
        smooth_loss_list = []
        for i in range(input.shape[0]):
            smooth_loss_list.append(-ops.sum(log_probs[i].contiguous()) / n_classes)
        smooth_loss = torch.stack(smooth_loss_list)
        nll = (1 - label_smoothing) * nll + label_smoothing * smooth_loss

    # Apply class weights if provided
    if weight is not None:
        class_weights = weight[target_clamped]
        nll = nll * class_weights

    # Apply ignore_index mask
    nll = nll * valid_mask.float()

    # Reduction using VLA sum
    if reduction == 'none':
        return nll
    elif reduction == 'sum':
        return ops.sum(nll.contiguous())
    else:  # mean
        valid_count = valid_mask.sum().float()
        if valid_count > 0:
            total = ops.sum(nll.contiguous())
            return total / valid_count
        else:
            return torch.tensor(0.0, device=input.device, requires_grad=True)
