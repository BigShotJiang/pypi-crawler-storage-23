"""
QuarterBit - AXIOM Full-Stack Memory-Efficient Training
========================================================

FULL STACK (4.8x memory reduction):
    - TRAINABLE-QUANT: INT4 weights + FP16 error = 1.6x weight compression
    - AXIOM optimizer: 800x optimizer state compression
    - Train 774M+ models on 8GB GPU!

Optimizer:
    AXIOM    220x compression (280x optimizer + 200x gradients)

Trainer:
    AXIOM_Trainer    Full-stack training with TRAINABLE-QUANT enabled by default

Weight Quantization:
    make_trainable_quantized(model)  # INT4 + FP16 error, fully trainable

Extensions:
    AXIOM_CHECKPOINT    Activation compression (85%)
    AXIOM_DDP           Gradient compression for distributed (128x)

Quick Start:
    from quarterbit import AXIOM, make_trainable_quantized

    model = make_trainable_quantized(model)  # 1.6x weight compression
    opt = AXIOM(model.parameters(), lr=1e-4)
    opt.register_hooks()  # Enable gradient compression

    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        opt.step(loss.item())
        opt.zero_grad()

License:
    Free account required: https://quarterbit.dev
    Run: quarterbit login
"""

__version__ = "18.0.2"  # TRAINABLE-QUANT + AXIOM Full Stack + env var license support
__author__ = "Clouthier Simulation Labs"

# License check on import
from .license import check_license, LicenseError

_LICENSE_VALID = False
try:
    check_license(silent=True)
    _LICENSE_VALID = True
except LicenseError:
    import sys
    print("\n" + "="*60)
    print("QuarterBit requires a free account.")
    print("")
    print("Sign up (free): https://quarterbit.dev")
    print("Then run:       quarterbit login")
    print("="*60 + "\n")

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )

# Main optimizer (requires PyTorch AND license)
if _HAS_TORCH and _LICENSE_VALID:
    from .optimizer import AXIOM
    from .extensions import AXIOM_CHECKPOINT, AXIOM_DDP
    from .trainer import AXIOM_Trainer, TrainerConfig
    from .model_loader import load_model, estimate_memory
    from .trainable_quant import (
        make_trainable_quantized,
        verify_trainable,
        TrainableQuantizedLinear,
        TrainableQuantizedEmbedding,
        TrainableQuantizedConv1D,
    )

    __all__ = [
        # Core optimizer
        "AXIOM",
        # Weight quantization (1.6x compression, fully trainable)
        "make_trainable_quantized",
        "verify_trainable",
        "TrainableQuantizedLinear",
        "TrainableQuantizedEmbedding",
        "TrainableQuantizedConv1D",
        # Model loading helper
        "load_model",
        "estimate_memory",
        # Full-stack trainer
        "AXIOM_Trainer",
        "TrainerConfig",
        # Extensions
        "AXIOM_CHECKPOINT",
        "AXIOM_DDP",
        "__version__",
    ]
elif _HAS_TORCH and not _LICENSE_VALID:
    # License required - provide stub that raises on use
    def _license_required(*args, **kwargs):
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    class _LicenseRequiredClass:
        def __init__(self, *args, **kwargs):
            raise LicenseError(
                "License required. Sign up free at quarterbit.dev then run: quarterbit login"
            )

    AXIOM = _LicenseRequiredClass
    AXIOM_Trainer = _LicenseRequiredClass
    TrainerConfig = _LicenseRequiredClass
    AXIOM_CHECKPOINT = _LicenseRequiredClass
    AXIOM_DDP = _LicenseRequiredClass
    make_trainable_quantized = _license_required
    verify_trainable = _license_required
    TrainableQuantizedLinear = _LicenseRequiredClass
    TrainableQuantizedEmbedding = _LicenseRequiredClass
    TrainableQuantizedConv1D = _LicenseRequiredClass
    load_model = _license_required
    estimate_memory = _license_required

    __all__ = [
        "AXIOM",
        "make_trainable_quantized",
        "verify_trainable",
        "TrainableQuantizedLinear",
        "TrainableQuantizedEmbedding",
        "TrainableQuantizedConv1D",
        "load_model",
        "estimate_memory",
        "AXIOM_Trainer",
        "TrainerConfig",
        "AXIOM_CHECKPOINT",
        "AXIOM_DDP",
        "__version__",
    ]
else:
    __all__ = ["__version__"]
