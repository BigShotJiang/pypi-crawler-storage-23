"""
QuarterBit License Management
=============================

Handles license activation, validation, and usage tracking.

Usage:
    # Login via browser (recommended)
    quarterbit login

    # Or activate with key
    quarterbit activate <LICENSE_KEY>

    # Check status
    quarterbit status
"""

import os
import json
import hashlib
import platform
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

# License server endpoint
LICENSE_API = "https://us-central1-quarterbit.cloudfunctions.net"

# Local config directory
CONFIG_DIR = Path.home() / ".quarterbit"
LICENSE_FILE = CONFIG_DIR / "license.json"
USAGE_FILE = CONFIG_DIR / "usage.json"

# License tiers and limits (must match Firebase backend)
TIER_LIMITS = {
    "FREE": {"gpu_hours_month": 5, "commercial": False, "price": 0},
    "PRO": {"gpu_hours_month": 1000, "commercial": True, "price": 49},
    "TEAM": {"gpu_hours_month": 10000, "commercial": True, "price": 299},
    "ENTERPRISE": {"gpu_hours_month": float("inf"), "commercial": True, "price": "custom"},
}

# Session tracking
_session_start = None
_session_gpu_seconds = 0


def _get_machine_id() -> str:
    """Generate a unique machine identifier."""
    data = f"{platform.node()}-{platform.machine()}-{platform.processor()}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def _ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _load_license() -> Optional[Dict[str, Any]]:
    """Load license from local file."""
    if not LICENSE_FILE.exists():
        return None
    try:
        with open(LICENSE_FILE) as f:
            return json.load(f)
    except:
        return None


def _save_license(data: Dict[str, Any]):
    """Save license to local file."""
    _ensure_config_dir()
    with open(LICENSE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _load_usage() -> Dict[str, Any]:
    """Load usage tracking data."""
    if not USAGE_FILE.exists():
        return {"sessions": [], "gpu_seconds": 0, "month": datetime.now().strftime("%Y-%m")}
    try:
        with open(USAGE_FILE) as f:
            data = json.load(f)
            # Reset if new month
            current_month = datetime.now().strftime("%Y-%m")
            if data.get("month") != current_month:
                data = {"sessions": [], "gpu_seconds": 0, "month": current_month}
            return data
    except:
        return {"sessions": [], "gpu_seconds": 0, "month": datetime.now().strftime("%Y-%m")}


def _save_usage(data: Dict[str, Any]):
    """Save usage tracking data."""
    _ensure_config_dir()
    with open(USAGE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def login() -> Dict[str, Any]:
    """
    Browser-based login flow.
    Opens browser for user to authenticate, then automatically activates.

    Returns:
        dict with activation status and tier info
    """
    import webbrowser
    import time as _time

    machine_id = _get_machine_id()

    # Step 1: Request device auth code
    try:
        req_data = json.dumps({
            "machineId": machine_id,
            "platform": platform.system(),
        }).encode()

        req = urllib.request.Request(
            f"{LICENSE_API}/createDeviceAuth",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())

    except urllib.error.URLError:
        raise ConnectionError("Cannot reach license server. Check your internet connection.")

    device_code = result.get("deviceCode")
    auth_url = result.get("authUrl")

    if not device_code or not auth_url:
        raise ValueError("Failed to initiate login flow")

    # Step 2: Open browser
    print(f"\nOpening browser to complete login...")
    print(f"If browser doesn't open, visit: {auth_url}\n")
    webbrowser.open(auth_url)

    # Step 3: Poll for completion
    print("Waiting for authentication", end="", flush=True)
    for _ in range(60):  # 2 minute timeout
        _time.sleep(2)
        print(".", end="", flush=True)

        try:
            req = urllib.request.Request(
                f"{LICENSE_API}/checkDeviceAuth?code={device_code}",
                method="GET"
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                status = json.loads(resp.read().decode())

            if status.get("completed"):
                print(" Done!\n")

                # Save license
                license_data = {
                    "key": status.get("licenseKey"),
                    "tier": status.get("tier", "FREE"),
                    "email": status.get("email"),
                    "activated_at": datetime.now().isoformat(),
                    "machine_id": machine_id,
                }
                _save_license(license_data)

                return {
                    "status": "activated",
                    "tier": license_data["tier"],
                    "email": license_data["email"],
                    "message": f"Login successful! Tier: {license_data['tier']}"
                }

        except:
            pass

    print(" Timeout")
    raise TimeoutError("Login timed out. Please try again.")


def activate(license_key: str) -> Dict[str, Any]:
    """
    Activate a license key.

    Args:
        license_key: License key from quarterbit.dev dashboard

    Returns:
        dict with activation status and tier info

    Raises:
        ValueError: If license key is invalid
    """
    if not license_key:
        raise ValueError("License key required")

    machine_id = _get_machine_id()

    # Validate with server
    try:
        req_data = json.dumps({
            "licenseKey": license_key,
            "machineId": machine_id,
            "platform": platform.system(),
            "pythonVersion": platform.python_version(),
        }).encode()

        req = urllib.request.Request(
            f"{LICENSE_API}/activateLicense",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())

    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else str(e)
        raise ValueError(f"Activation failed: {error_body}")
    except urllib.error.URLError:
        raise ConnectionError("Cannot reach license server. Check your internet connection.")

    if not result.get("valid"):
        raise ValueError(result.get("error", "Invalid license key"))

    # Save locally
    license_data = {
        "key": license_key,
        "tier": result.get("tier", "FREE"),
        "uid": result.get("uid"),
        "activated_at": datetime.now().isoformat(),
        "machine_id": machine_id,
    }
    _save_license(license_data)

    # Initialize usage from server
    server_usage = result.get("usage", {})
    usage = _load_usage()
    usage["gpu_seconds"] = server_usage.get("gpu_hours_used", 0) * 3600
    _save_usage(usage)

    return {
        "status": "activated",
        "tier": license_data["tier"],
        "message": f"License activated! Tier: {license_data['tier']}"
    }


def deactivate():
    """Remove license from this machine."""
    if LICENSE_FILE.exists():
        LICENSE_FILE.unlink()
    if USAGE_FILE.exists():
        USAGE_FILE.unlink()
    print("License deactivated.")


def get_license_info() -> Dict[str, Any]:
    """Get current license information."""
    license_data = _load_license()
    usage = _load_usage()
    gpu_hours_used = usage.get("gpu_seconds", 0) / 3600

    if not license_data:
        return {
            "tier": None,
            "activated": False,
            "usage": {
                "gpu_hours_used": round(gpu_hours_used, 2),
                "gpu_hours_limit": 0,
                "month": usage.get("month"),
            }
        }

    tier = license_data.get("tier", "FREE")
    limits = TIER_LIMITS.get(tier, TIER_LIMITS["FREE"])

    return {
        "tier": tier,
        "activated": True,
        "email": license_data.get("email"),
        "key": license_data.get("key", "")[:12] + "...",
        "activated_at": license_data.get("activated_at"),
        "limits": limits,
        "usage": {
            "gpu_hours_used": round(gpu_hours_used, 2),
            "gpu_hours_limit": limits["gpu_hours_month"],
            "month": usage.get("month"),
        }
    }


def check_license(silent: bool = False) -> bool:
    """
    Check if license is valid. Called on import.

    Checks in order:
    1. Environment variable QUARTERBIT_LICENSE_KEY
    2. Local file ~/.quarterbit/license.json

    Args:
        silent: If True, don't print messages

    Returns:
        True if valid

    Raises:
        LicenseError: If no license or invalid
    """
    # First check environment variable (for Kaggle/CI environments)
    env_key = os.environ.get('QUARTERBIT_LICENSE_KEY')
    if env_key:
        # Validate format: QB-TIER-XXXXXXXX-XXXXXXXX
        if env_key.startswith('QB-') and len(env_key) >= 20:
            return True

    # Then check local file
    license_data = _load_license()

    if not license_data:
        msg = """
================================================================================
QuarterBit requires a free account to use.

Sign up (free): https://quarterbit.dev
Then run:       quarterbit login

Or if you have a license key:
                quarterbit activate <YOUR_KEY>
================================================================================
"""
        if not silent:
            print(msg)
        raise LicenseError("No license found. Sign up at quarterbit.dev (free)")

    return True


def start_session():
    """Start tracking a training session."""
    global _session_start, _session_gpu_seconds
    _session_start = datetime.now()
    _session_gpu_seconds = 0


def track_step(step_seconds: float = 1.0):
    """Track GPU time for a training step."""
    global _session_gpu_seconds
    _session_gpu_seconds += step_seconds


def end_session():
    """End session and save usage."""
    global _session_start, _session_gpu_seconds

    if _session_start is None:
        return

    # Save local usage
    usage = _load_usage()
    usage["gpu_seconds"] = usage.get("gpu_seconds", 0) + _session_gpu_seconds
    usage["sessions"].append({
        "timestamp": datetime.now().isoformat(),
        "gpu_seconds": _session_gpu_seconds,
    })
    usage["sessions"] = usage["sessions"][-100:]  # Keep last 100
    _save_usage(usage)

    # Report to server
    report_usage()

    # Check limits
    _check_usage_limits(usage)

    _session_start = None
    _session_gpu_seconds = 0


def _check_usage_limits(usage: Dict[str, Any]):
    """Check if usage limits exceeded."""
    info = get_license_info()
    if not info["activated"]:
        return

    gpu_hours_used = usage["gpu_seconds"] / 3600
    gpu_hours_limit = info["usage"]["gpu_hours_limit"]

    if gpu_hours_used > gpu_hours_limit:
        tier = info["tier"]
        raise UsageLimitError(
            f"\n{'='*60}\n"
            f"You've used {gpu_hours_used:.1f} of {gpu_hours_limit} GPU-hours this month.\n\n"
            f"Upgrade at: https://quarterbit.dev/pricing\n"
            f"{'='*60}"
        )


def report_usage():
    """Report usage to server (called at session end)."""
    license_data = _load_license()
    if not license_data:
        return

    usage = _load_usage()

    try:
        req_data = json.dumps({
            "licenseKey": license_data.get("key"),
            "gpuSeconds": usage.get("gpu_seconds", 0),
            "sessionCount": len(usage.get("sessions", [])),
        }).encode()

        req = urllib.request.Request(
            f"{LICENSE_API}/reportUsage",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=5) as resp:
            pass  # Fire and forget
    except:
        pass  # Silent fail - usage reporting is best-effort


class LicenseError(Exception):
    """License validation error."""
    pass


class UsageLimitError(Exception):
    """Usage limit exceeded."""
    pass


# CLI interface
def main():
    """CLI entry point for license management."""
    import sys

    if len(sys.argv) < 2:
        _print_status()
        return

    cmd = sys.argv[1].lower()

    if cmd == "login":
        try:
            result = login()
            print(f"\nSuccess! {result['message']}")
            if result.get('email'):
                print(f"Logged in as: {result['email']}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

    elif cmd == "activate":
        if len(sys.argv) < 3:
            print("Usage: quarterbit activate <LICENSE_KEY>")
            sys.exit(1)
        key = sys.argv[2]
        try:
            result = activate(key)
            print(f"\nSuccess! {result['message']}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

    elif cmd == "deactivate":
        deactivate()

    elif cmd == "status":
        _print_status()

    else:
        print(f"Unknown command: {cmd}")
        print("\nCommands:")
        print("  quarterbit login           - Login via browser (recommended)")
        print("  quarterbit activate <KEY>  - Activate with license key")
        print("  quarterbit deactivate      - Remove license")
        print("  quarterbit status          - Show license info")
        sys.exit(1)


def _print_status():
    """Print license status."""
    print("\nQuarterBit License Status")
    print("=" * 40)

    info = get_license_info()

    if not info["activated"]:
        print("Status: Not activated")
        print("\nSign up (free): https://quarterbit.dev")
        print("Then run:       quarterbit login")
    else:
        print(f"Status: Activated")
        print(f"Tier: {info['tier']}")
        if info.get('email'):
            print(f"Email: {info['email']}")
        print(f"Key: {info.get('key', 'N/A')}")
        print(f"\nUsage this month:")
        print(f"  GPU hours: {info['usage']['gpu_hours_used']:.2f} / {info['usage']['gpu_hours_limit']}")

        if info['tier'] == 'FREE':
            print(f"\nUpgrade for more hours: https://quarterbit.dev/pricing")


if __name__ == "__main__":
    main()
