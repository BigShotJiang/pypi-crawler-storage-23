# Conversation 31189939-7797-48da-aad7-26987e54342c

- Source: `claude`
- User: `pascal`
- System: `Pascals-MBP.local`
- Started: `2026-02-23T13:41:09.903Z`
- CWD: `/Users/pascal/Code/business/convx`

## User

_`2026-02-23T13:41:09.903Z`_

if I run the search in the TUI, how can I make it match exact strings?

## Agent

_`2026-02-23T13:41:16.751Z`_

Could you clarify which TUI you're referring to? For example, are you asking about a specific tool like `fzf`, `lazygit`, `less`, or something else? Or does `convx` have a TUI component you're working with?
