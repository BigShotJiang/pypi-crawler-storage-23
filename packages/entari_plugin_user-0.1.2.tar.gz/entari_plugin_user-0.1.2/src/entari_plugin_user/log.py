from arclet.entari.logger import log

logger = log.wrapper("[user]")
