# MoaT-KV-Cal

% start synopsis
% start main

MoaT-KV-Cal is a calendar extension to MoaT-KV.

It can monitor a calendar (or specific entries thereof), publish pending
entries, set alerts, control that they are acknowledged, and escalate
if/when they are not.

% end synopsis
% end main
