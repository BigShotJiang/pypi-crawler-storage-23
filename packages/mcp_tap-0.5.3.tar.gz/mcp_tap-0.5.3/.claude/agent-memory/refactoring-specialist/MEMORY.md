# Refactoring Specialist Memory — mcp-tap

## Project: mcp-tap (Python MCP meta-server)
- Hexagonal architecture — respect layer boundaries when refactoring
- All dataclasses must remain frozen=True, slots=True
- No findings yet. Fresh project.
