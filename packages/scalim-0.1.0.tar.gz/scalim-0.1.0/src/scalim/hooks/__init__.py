"""Hook system.

This package intentionally does not re-export symbols.
Import hook implementations from `scalim.hooks.base`.
"""

__all__ = []
