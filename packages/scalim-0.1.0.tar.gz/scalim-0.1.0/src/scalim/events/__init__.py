"""Event models and helpers.

This package intentionally does not re-export symbols.
Import concrete event types from `scalim.events.events`, the base `Event` from
`scalim.events.event`, and catalog helpers from `scalim.events.catalog`.
"""

__all__ = []
