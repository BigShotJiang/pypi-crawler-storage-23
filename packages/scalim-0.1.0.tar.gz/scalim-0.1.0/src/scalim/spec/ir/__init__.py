"""IR (intermediate representation) models.

This package intentionally does not re-export symbols.
Import concrete IR models from modules under `scalim.spec.ir.*`.
"""

__all__ = []
