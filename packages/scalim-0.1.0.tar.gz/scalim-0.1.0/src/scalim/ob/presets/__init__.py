"""Observer presets.

This package intentionally does not re-export symbols.
Import presets from concrete modules under `scalim.ob.presets.*`.
"""

__all__ = []
