"""Observability system.

This package intentionally does not re-export symbols.
Import concrete implementations from modules under `scalim.ob.*`.
"""

__all__ = []
