"""Batch executor internal helpers."""
