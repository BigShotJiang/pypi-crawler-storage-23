"""Batch executor package.

Intentionally does not re-export implementation symbols.
Import `BatchExecutor` from `scalim.execution.executor.batch.executor`.
"""
