"""Compute operator package (internal).

Implementation lives in `scalim.execution.executor.operators.compute.executor`.
This package intentionally does not re-export implementation symbols.
"""
