"""Operator executors package.

Intentionally does not re-export implementation symbols.
Import executors from concrete modules under `scalim.execution.executor.operators.*`.
"""
