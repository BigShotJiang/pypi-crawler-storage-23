MISSING = object()

__all__ = [
    "MISSING",
]
