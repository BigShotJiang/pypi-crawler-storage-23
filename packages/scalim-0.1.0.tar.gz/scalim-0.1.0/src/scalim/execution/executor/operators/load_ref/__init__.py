"""LoadRef operator package (internal).

Implementation lives in `scalim.execution.executor.operators.load_ref.executor`.
This package intentionally does not re-export implementation symbols.
"""
