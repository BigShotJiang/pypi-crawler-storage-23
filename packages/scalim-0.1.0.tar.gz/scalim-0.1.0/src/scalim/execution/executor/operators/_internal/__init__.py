"""Internal helper modules for operator executors.

This package is intentionally internal and does not provide a stable import surface.
Keep this `__init__` lightweight and avoid re-exporting implementation symbols.
"""
