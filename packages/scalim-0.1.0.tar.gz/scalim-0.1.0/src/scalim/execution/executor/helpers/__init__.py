"""Executor helper modules (internal).

Avoid relying on package-level re-exports; import from explicit submodules.
"""
