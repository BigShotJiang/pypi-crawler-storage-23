"""Execution runtime internal helpers."""
