"""Execution runtime package (internal).

Implementation lives in `scalim.execution.executor.runtime.runtime`.
"""
