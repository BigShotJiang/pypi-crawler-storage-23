"""Execution executor package.

Intentionally does not re-export implementation symbols.
Import from concrete modules under `scalim.execution.executor.*`.
"""
