"""Base pipeline package.

Intentionally does not re-export implementation symbols.
Import implementations from `scalim.execution.pipeline.base.pipeline`.
"""
