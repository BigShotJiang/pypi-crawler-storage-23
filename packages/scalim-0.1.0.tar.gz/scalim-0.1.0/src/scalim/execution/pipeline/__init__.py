"""Execution pipeline package.

Intentionally does not re-export implementation symbols.
Import pipeline implementations from `scalim.execution.pipeline.base.pipeline`.
"""
