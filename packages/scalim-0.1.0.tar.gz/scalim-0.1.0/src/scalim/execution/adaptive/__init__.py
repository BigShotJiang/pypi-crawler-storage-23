"""Adaptive execution components.

This package hosts the intrabatch fan-out/fan-in scheduler and its supporting
utilities (capture/replay, overlay contexts, tuning/policy).
"""

__all__ = []
