"""Loader ordering helpers.

This package contains internal helpers used by the planning layer to build and
order loader/ref-loader sequences.

Intentionally does not re-export implementation symbols.
Import helpers from the concrete modules under `scalim.planning.loader_ordering.*`.
"""

__all__ = []
