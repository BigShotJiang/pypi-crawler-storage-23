# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import TypedDict

__all__ = ["LedgerAccountCategoryUpdateParams"]


class LedgerAccountCategoryUpdateParams(TypedDict, total=False):
    description: Optional[str]
    """The description of the ledger account category."""

    metadata: Dict[str, str]
    """Additional data represented as key-value pairs.

    Both the key and value must be strings.
    """

    name: str
    """The name of the ledger account category."""
