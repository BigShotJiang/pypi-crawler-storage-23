from .guitar import Guitar
from .drums import DrumMachine
from .synthesizer import Synthesizer, Waveform
