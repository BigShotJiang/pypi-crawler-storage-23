from bluer_sbc.joystick.classes import Joystick
