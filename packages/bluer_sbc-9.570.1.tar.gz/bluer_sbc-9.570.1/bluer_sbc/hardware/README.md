- [Hardware](./hardware.md)
    - [Abstract_Hat](./hat/abstract.py)
        - [Prototype_Hat](./hat/prototype.py)
            - [Display](./display.py)
    - [Screen](./screen.py)
        - [Adafruit_Rgb_Matrix](./adafruit_rgb_matrix.py)
        - [Grove](./grove.py)
        - [Scroll_Phat_HD](./scroll_phat_hd.py)
        - [Sparkfun_Top_phat](./sparkfun_top_phat.py)
        - [Unicorn_16x16](./unicorn_16x16.py)


