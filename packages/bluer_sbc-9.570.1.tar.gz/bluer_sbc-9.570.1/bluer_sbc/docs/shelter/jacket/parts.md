# shelter: jacket: parts

|   |   |   |   |   |
| --- | --- | --- | --- | --- |
| [`DSN-VC288, panel mount, 4-30 VDC, 10A (50A with shunt resistor), voltmeter ammeter`](../parts/dsn-vc288.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dsn-vc288.jpg?raw=true)](../parts/dsn-vc288.md)  | [`Li-Ion battery`](../parts/li-ion-battery.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/lithium-battery.jpg?raw=true)](../parts/li-ion-battery.md) 3 x 26650, 5000 mAh 5C, 3.7 V/4.2V | [`mountable digital thermometer`](../parts/mountable-digital-thermometer.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/mountable-digital-thermometer.jpeg?raw=true)](../parts/mountable-digital-thermometer.md)  | [`pwm manual DC motor controller, 12 V, ≥ 5 A`](../parts/pwm-manual-dc-motor-controller.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pwm-manual-dc-motor-controller.jpg?raw=true)](../parts/pwm-manual-dc-motor-controller.md)  | [`resistance heating wire`](../parts/resistance-heating-wire.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/resistance-heating-wire.jpg?raw=true)](../parts/resistance-heating-wire.md) TBA |

1. [DSN-VC288, panel mount, 4-30 VDC, 10A (50A with shunt resistor), voltmeter ammeter](../parts/dsn-vc288.md).
1. [Li-Ion battery](../parts/li-ion-battery.md): 3 x 26650, 5000 mAh 5C, 3.7 V/4.2V.
1. [mountable digital thermometer](../parts/mountable-digital-thermometer.md).
1. [pwm manual DC motor controller, 12 V, ≥ 5 A](../parts/pwm-manual-dc-motor-controller.md).
1. [resistance heating wire](../parts/resistance-heating-wire.md): TBA.
