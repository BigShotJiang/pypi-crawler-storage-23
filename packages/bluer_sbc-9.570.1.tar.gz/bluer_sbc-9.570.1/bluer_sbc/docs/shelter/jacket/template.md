title:::

- [parts](./parts.md)
- [design](./design/)