title:::

- started with: 100 VAC, 1.59 kΩ ~= 6.3 w - heat was not noticeable.
- 2025-11-07: 200 VAC, 1.59 kΩ ~= 25.2 w - heat is noticeable. ✅