# battery-bus: body: sla

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_221902.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_221902.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220642.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220642.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220520.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220520.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220601.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/battery-bus/20251007_220601.jpg?raw=true) |  |  |
