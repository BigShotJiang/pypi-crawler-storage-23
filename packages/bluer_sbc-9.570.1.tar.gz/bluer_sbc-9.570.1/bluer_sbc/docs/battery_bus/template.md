title:::

> a non-regulated ~12 VDC, ~3 A, DC bus.

- [parts](./parts.md)
- [body](./body)

items:::