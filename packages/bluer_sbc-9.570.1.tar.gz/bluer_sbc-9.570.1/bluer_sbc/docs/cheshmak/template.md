title:::

`cheshmak` 👁️ is an AI media center running [raspbian +gui](https://github.com/kamangir/bluer-ai/blob/main/bluer_ai/docs/install/RPi.md).

- [parts](./parts.md)
- [body](./body)
- [validations](./validations.md).
- [terraform](./terraform.md).
- [installation instructions](./install.md).
- [operation](./operation.md).

items:::