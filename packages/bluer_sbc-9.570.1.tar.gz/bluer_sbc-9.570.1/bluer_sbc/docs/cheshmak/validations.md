# cheshmak: validations

|   |
| --- |
| [![image](https://github.com/kamangir/assets2/raw/main/bryce/09.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/bryce/09.jpg?raw=true) |
