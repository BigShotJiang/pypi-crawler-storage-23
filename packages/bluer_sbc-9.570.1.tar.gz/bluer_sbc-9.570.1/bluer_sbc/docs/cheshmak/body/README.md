# cheshmak: body

- born out of `bryce`.
- previous design(s): [v1](./v1.md), [v2](./v2.md).

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_125949.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_125949.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130000.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130000.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130005.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130005.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130011.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130011.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130016.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130016.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130023.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20260114_130023.jpg?raw=true) |
