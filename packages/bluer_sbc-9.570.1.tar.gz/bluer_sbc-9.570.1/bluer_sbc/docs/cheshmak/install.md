# cheshmak: install

|   |
| --- |
| [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/IMG_20260126_192557.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/IMG_20260126_192557.jpg?raw=true) |
