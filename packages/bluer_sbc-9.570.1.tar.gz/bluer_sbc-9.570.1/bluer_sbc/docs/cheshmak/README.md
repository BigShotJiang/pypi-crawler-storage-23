# cheshmak

`cheshmak` 👁️ is an AI media center running [raspbian +gui](https://github.com/kamangir/bluer-ai/blob/main/bluer_ai/docs/install/RPi.md).

- [parts](./parts.md)
- [body](./body)
- [validations](./validations.md).
- [terraform](./terraform.md).
- [installation instructions](./install.md).
- [operation](./operation.md).

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/01.png?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/01.png?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/20251203_190023.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/20251203_190023.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/raw/main/cheshmak/photo_6030669378703002396_y.jpg?raw=true)](https://github.com/kamangir/assets2/raw/main/cheshmak/photo_6030669378703002396_y.jpg?raw=true) |
