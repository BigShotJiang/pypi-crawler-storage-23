# cheshmak: operation

minimized subset of [swallow ugv](https://github.com/kamangir/bluer-ugv/blob/main/bluer_ugv/docs/swallow/digital/design/operation.md).

- keyboard:
    - i: exit.
    - o: shutdown.
    - p: reboot.
    - u: update.

- leds:
    - blue: data uploaded.
    - green: data collected.
    - red: control loop.
    - yellow: data downloaded.

- push button:
    - flash leds.
