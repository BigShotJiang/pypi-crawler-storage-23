title:::

- head of [swallow computer](../swallow), without the DC motor drivers.
- width x height x length: 140 mm x 95 mm x 75 mm
- used for [swallow design](https://github.com/kamangir/bluer-ugv/tree/main/bluer_ugv/docs/swallow) backs and [rangin](https://github.com/kamangir/bluer-ugv/tree/main/bluer_ugv/docs/rangin) tops.
- [parts](./parts.md)
- previous versions: [v1](./v1.md).

items:::