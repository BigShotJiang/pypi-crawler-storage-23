# parts: whip-antenna

- 433 MHz SMA whip antenna (small stubby or ~10–20 cm) or U.FL -> SMA pigtail if the module has a tiny U.FL connector.

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/whip-antenna.jpeg?raw=true) |
