# parts: brushless-driver

- 300 W industrial brushless motor driver.
- [source](https://samamotor.ir/%D8%AF%D8%B1%D8%A7%DB%8C%D9%88%D8%B1-%D9%85%D9%88%D8%AA%D9%88%D8%B1-%D8%A8%D8%B1%D8%A7%D8%B4%D9%84%D8%B3-bldc/157-%D8%AF%D8%B1%D8%A7%DB%8C%D9%88%D8%B1-%D9%85%D9%88%D8%AA%D9%88%D8%B1-%D8%A8%D8%B1%D8%A7%D8%B4%D9%84%D8%B3-300-%D9%88%D8%A7%D8%AA-%D8%B5%D9%86%D8%B9%D8%AA%DB%8C-bld-300b.html)
- [datasheet](https://aeevn.com/wp-content/uploads/2020/04/bld-300B.pdf)
- [datasheet](https://www.sys-motor.com/Account/Plug-ins/kindeditor/attached/file/20180516/20180516125751_1905.pdf)

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/brushless-driver-1.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/brushless-driver-2.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/brushless-driver-3.jpg?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/brushless-driver-4.jpg?raw=true) |  |  |
