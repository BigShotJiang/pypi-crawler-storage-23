# parts: ac-power-cord-and-plug

- AC power plug, 220 VAC, 2 A

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ac-power-cord-and-plug.jpg?raw=true) |
