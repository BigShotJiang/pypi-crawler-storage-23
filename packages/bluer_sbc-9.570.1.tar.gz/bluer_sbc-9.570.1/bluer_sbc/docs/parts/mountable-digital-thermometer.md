# parts: mountable-digital-thermometer

- mountable digital thermometer

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/mountable-digital-thermometer.jpeg?raw=true) |
