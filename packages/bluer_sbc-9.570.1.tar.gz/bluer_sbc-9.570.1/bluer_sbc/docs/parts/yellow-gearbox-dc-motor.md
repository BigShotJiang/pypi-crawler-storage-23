# parts: yellow-gearbox-dc-motor

- gearboxed DC motor, 6V DC

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/yellow-gearbox-dc-motor.png?raw=true) |
