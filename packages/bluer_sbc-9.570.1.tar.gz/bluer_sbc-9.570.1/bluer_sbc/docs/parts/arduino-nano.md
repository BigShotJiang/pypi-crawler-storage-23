# parts: arduino-nano

- Arduino Nano
- [Arduino Nano BLE](https://store.arduino.cc/products/arduino-nano-33-ble)
- [Different types of Arduino Boards](https://circuitdigest.com/article/different-types-of-arduino-boards)

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/arduino-nano.png?raw=true) |
