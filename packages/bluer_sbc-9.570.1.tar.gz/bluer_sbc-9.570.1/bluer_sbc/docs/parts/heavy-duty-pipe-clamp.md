# parts: heavy-duty-pipe-clamp

- heavy duty pipe clamp

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/heavy-duty-pipe-clamp.jpg?raw=true) |
