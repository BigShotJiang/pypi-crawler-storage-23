# parts: double-sided-tape

- double-sided tape.

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/double-sided-tape.jpg?raw=true) |
