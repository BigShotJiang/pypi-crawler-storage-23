# parts: dc-switch

- on/off DC switch with indicator led

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/on-off-switch.png?raw=true) |
