# parts: dc-fuse

- DC fuse, ANL or MIDI type

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dc-fuse.jpg?raw=true) |
