# parts: potentiometer

- potentiometer

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/potentiometer.jpeg?raw=true) |
