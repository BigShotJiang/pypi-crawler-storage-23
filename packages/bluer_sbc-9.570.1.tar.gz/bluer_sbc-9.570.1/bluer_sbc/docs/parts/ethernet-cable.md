# parts: ethernet-cable

- RJ-45, Cat5e or Cat6
- straight-through (normal) — NOT crossover

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ethernet-cable.jpeg?raw=true) |
