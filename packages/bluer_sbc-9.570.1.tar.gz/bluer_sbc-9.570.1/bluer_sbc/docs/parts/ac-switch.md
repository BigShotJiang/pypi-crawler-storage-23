# parts: ac-switch

- AC switch

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ac-switch.jpg?raw=true) |
