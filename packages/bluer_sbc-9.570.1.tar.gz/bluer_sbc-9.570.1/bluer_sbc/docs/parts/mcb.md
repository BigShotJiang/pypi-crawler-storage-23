# parts: mcb

- miniature circuit breaker (MCB)

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/mcb-3.jpg?raw=true) |
