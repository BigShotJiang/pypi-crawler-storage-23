# parts: on-off-switch

- on/off switch, 12V DC 10 A, with indicator led

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/on-off-switch.png?raw=true) |
