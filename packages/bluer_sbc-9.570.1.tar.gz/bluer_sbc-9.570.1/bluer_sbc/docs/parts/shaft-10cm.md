# parts: shaft-10cm

- shaft, 10 cm
- https://robotexiran.com/product/%d9%85%d8%ad%d9%88%d8%b1-10cm/

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/shaft-10cm.jpg?raw=true) |
