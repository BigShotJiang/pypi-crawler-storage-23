# parts: relay

- relay

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/relay.jpg?raw=true) |
