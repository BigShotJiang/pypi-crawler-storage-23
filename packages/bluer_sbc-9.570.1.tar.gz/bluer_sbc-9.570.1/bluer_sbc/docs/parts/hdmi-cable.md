# parts: hdmi-cable

- hdmi cable

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/hdmi-cable.jpg?raw=true) |
