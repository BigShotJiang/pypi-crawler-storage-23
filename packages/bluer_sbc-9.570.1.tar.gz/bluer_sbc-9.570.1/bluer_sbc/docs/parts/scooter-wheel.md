# parts: scooter-wheel

- scooter wheel, 36 V, 300 W, 650 rpm, 10"
- [source](https://samamotor.ir/%D9%85%D9%88%D8%AA%D9%88%D8%B1-%D9%87%D8%A7%DB%8C-%D8%A7%D8%B3%DA%A9%D9%88%D8%AA%D8%B1%DB%8C/4648-%DA%86%D8%B1%D8%AE-%D9%88-%D9%85%D9%88%D8%AA%D9%88%D8%B1-%D8%A7%D8%B3%DA%A9%D9%88%D8%AA%D8%B1-%D8%A8%D8%B1%D9%82%DB%8C-10-%D8%A7%DB%8C%D9%86%DA%86-300-%D9%88%D8%A7%D8%AA-%DA%86%D8%B1%D8%A7%D8%BA-%D8%AF%D8%A7%D8%B1.html)
- [other example](https://www.dfrobot.com/product-3077.html)

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/scooter-wheel-1.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/scooter-wheel-2.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/scooter-wheel-3.jpg?raw=true) |
