# parts: connector

- auto power connectors

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/connector.jpg?raw=true) |
