# parts: SLA-Battery

- Rechargeable sealed lead acid battery

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/battery.png?raw=true) |
