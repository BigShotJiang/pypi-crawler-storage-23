# parts: speaker

- passive speaker

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/speaker.png?raw=true) |
