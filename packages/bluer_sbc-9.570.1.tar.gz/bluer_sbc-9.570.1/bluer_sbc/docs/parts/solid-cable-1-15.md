# parts: solid-cable-1-15

- solid cable 1-1.5 mm^2

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/solid-cable-1-15.jpg?raw=true) |
