# parts: sd-card-32-gb

- SD card, 32 GB

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/sd-card-32-gb.jpg?raw=true) |
