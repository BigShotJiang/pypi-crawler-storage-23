# parts: resistor

- Resistor, 1/4 watt, 5% tolerance

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/resistor.png?raw=true) |
