# parts: emergency-stop

- emergency stop switch

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/emergency-stop.jpg?raw=true) |
