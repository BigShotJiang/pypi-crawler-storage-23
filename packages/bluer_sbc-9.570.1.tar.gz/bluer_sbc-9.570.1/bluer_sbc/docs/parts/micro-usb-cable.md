# parts: micro-usb-cable

- Micro USB cable

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/micro-usb-cable.jpg?raw=true) |
