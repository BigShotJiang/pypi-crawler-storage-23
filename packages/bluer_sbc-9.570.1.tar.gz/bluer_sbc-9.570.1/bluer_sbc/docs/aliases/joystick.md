# aliases: joystick

```bash
@joystick \
	install
 . install joystick.
@joystick \
	validate \
	[install,~python]
 . validate joystick.
```
