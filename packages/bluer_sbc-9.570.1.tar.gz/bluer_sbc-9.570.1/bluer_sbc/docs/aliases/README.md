# aliases

- [@camera](./camera.md)
- [@joystick](./joystick.md)
- [@parts](./parts.md)
