# nafha: parts-v2

- PWM DC Motor Speed Controller (12 V, ≥ 5 A)
- Inline Blade Fuse Holder + 5 A Fuse
- Cartridge Heater 12 V / 40 W (3D printer type)
- Thermal Fuse 150 °C (10 A)
- High-temperature Silicone Wire (AWG18 or ~1 mm²)
- Digital Thermometer Module + NTC 100 k Sensor
