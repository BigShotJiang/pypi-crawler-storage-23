# arduino: schematics

|   |
| --- |
| [![image](https://github.com/kamangir/bluer-designs/blob/main/arduino/schematics.png?raw=true)](https://github.com/kamangir/bluer-designs/blob/main/arduino/schematics.svg) |
