# arduino: body

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0143.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0143.JPG?raw=true) | [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0144.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0144.JPG?raw=true) | [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0145.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0145.JPG?raw=true) |
| [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0146.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0146.JPG?raw=true) | [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0147.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0147.JPG?raw=true) | [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0149.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0149.JPG?raw=true) |
