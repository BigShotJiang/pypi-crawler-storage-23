# arduino

everything Arduino.

- [schematics](./schematics.md)
- [parts](./parts.md)
- [body](./body.md)
- sample code: 🌈 [colormaps](../../arduino/colormaps/)

|   |
| --- |
| [![image](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0151.JPG?raw=true)](https://github.com/kamangir/assets3/raw/main/arduino/IMG_0151.JPG?raw=true) |
