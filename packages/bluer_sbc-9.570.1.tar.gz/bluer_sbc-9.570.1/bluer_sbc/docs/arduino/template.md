title:::

everything Arduino.

- [schematics](./schematics.md)
- [parts](./parts.md)
- [body](./body.md)
- sample code: 🌈 [colormaps](../../arduino/colormaps/)

items:::