from bluer_objects.README.items import ImageItems

from bluer_sbc.README.designs.anchor import image_template

items = ImageItems(
    {
        image_template.format("03.png"): "",
        image_template.format("20251205_175953.jpg"): "",
    }
)
