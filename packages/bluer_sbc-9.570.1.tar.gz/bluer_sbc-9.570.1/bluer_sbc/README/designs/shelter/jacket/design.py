from bluer_sbc.README.designs.shelter.jacket.parts import parts

docs = [
    {
        "path": "../docs/shelter/jacket/design",
        "macros": {
            "battery-capacity:::": parts["li-ion-battery"],
        },
    },
]
