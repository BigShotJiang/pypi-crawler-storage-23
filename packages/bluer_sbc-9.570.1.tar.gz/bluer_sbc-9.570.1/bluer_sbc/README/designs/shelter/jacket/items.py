from bluer_objects.README.items import ImageItems

from bluer_sbc.README.designs.shelter import image_template

items = ImageItems(
    {
        #
    }
)
