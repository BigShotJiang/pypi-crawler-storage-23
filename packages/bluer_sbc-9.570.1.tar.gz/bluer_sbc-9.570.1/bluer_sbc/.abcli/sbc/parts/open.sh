#! /usr/bin/env bash

function bluer_sbc_parts_open() {
    open $abcli_path_git/assets2/bluer-sbc/parts
}
