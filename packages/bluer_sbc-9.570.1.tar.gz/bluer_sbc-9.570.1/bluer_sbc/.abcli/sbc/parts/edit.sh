#! /usr/bin/env bash

function bluer_sbc_parts_edit() {
    bluer_ai_code $abcli_path_git/bluer-sbc/bluer_sbc/parts/db.py
}
