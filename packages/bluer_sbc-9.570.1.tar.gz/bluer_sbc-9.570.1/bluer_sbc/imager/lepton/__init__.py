# pylint: skip-file

from bluer_sbc.imager.lepton.classes import Lepton

instance = Lepton()
