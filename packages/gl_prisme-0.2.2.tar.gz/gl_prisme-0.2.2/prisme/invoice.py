from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List

from prisme.file import File
from prisme.request import Request, Response


class InvoiceLine:
    def __init__(
        self,
        description: str,
        beneficiary: str | None,
        quantity: int,
        unit_price: int | Decimal,
        text: str,
        project: str | None,
        project_category: int | None,
        ledger_dimension: Dict[str, str | int],
    ):
        self.description = description
        self.beneficiary = beneficiary
        self.quantity = quantity
        self.unit_price = unit_price
        self.text = text
        self.project = project
        self.project_category = project_category
        self.ledger_dimension = ledger_dimension

    @property
    def dict(self) -> Dict[str, str | int | Dict[str, List[dict]] | None]:
        return {
            "Description": self.description,
            "Beneficiary": self.beneficiary,
            "Quantity": self.quantity,
            "UnitPrice": str(Decimal(self.unit_price).quantize(Decimal("0.01"))),
            "AmountCur": str(
                Decimal(self.quantity * self.unit_price).quantize(Decimal("0.01"))
            ),
            "InvoiceTxt": self.text,
            "Project": self.project,
            "ProjCategoryId": self.project_category,
            "ledgerDimensionSegments": {
                "ledgerDimensionSegment": [
                    {"Name": key, "Value": value}
                    for key, value in self.ledger_dimension.items()
                ]
            },
        }


class InvoiceRequest(Request):
    def __init__(
        self,
        order_account_number: str,
        invoice_account_number: str,
        invoice_date: datetime | date,
        due_date: datetime | date,
        accounting_date: datetime | date,
        department_recid: int,
        invoice_ean: int,
        order_form_num: str,
        contact_person_id: str,
        currency_code: str,
        text: str,
        files: List[File],
        lines: List[InvoiceLine],
    ):
        self.order_account_number = order_account_number
        self.invoice_account_number = invoice_account_number
        self.invoice_date = self._ensure_datetime(invoice_date)
        self.due_date = self._ensure_datetime(due_date)
        self.accounting_date = self._ensure_datetime(accounting_date)
        self.ledger_year = ""
        self.department_recid = department_recid
        self.invoice_ean = invoice_ean
        self.order_form_num = order_form_num
        self.contact_person_id = contact_person_id
        self.currency_code = currency_code
        self.text = text
        InvoiceRequest._ensure_list_type(files, File)
        InvoiceRequest._ensure_list_type(lines, InvoiceLine)
        self.files = files
        self.lines = lines

    wrap = "custinvoicetable"
    method = "createFreeTextInvoice"

    @staticmethod
    def _ensure_datetime(date_or_datetime: datetime | date) -> datetime:
        if isinstance(date_or_datetime, date):
            return datetime.combine(date_or_datetime, datetime.min.time())
        if isinstance(date_or_datetime, datetime):
            return date_or_datetime
        raise TypeError(f"Unsupported date type: {type(date_or_datetime)}")

    @staticmethod
    def _ensure_type(item: Any, type_: type) -> None:
        if not isinstance(item, type_):
            raise TypeError(f"Expected {type_}, got {type(item)}")

    @staticmethod
    def _ensure_list_type(item: Any, type_: type) -> None:
        if not isinstance(item, list):
            raise TypeError(f"Expected list, got {type(item)}")
        for i in item:
            InvoiceRequest._ensure_type(i, type_)

    @property
    def dict(self) -> Dict[str, str | int | datetime | Dict[str, List[dict]]]:
        return {
            "OrderAccount": self.order_account_number,
            "InvoiceAccount": self.invoice_account_number,
            "InvoiceDate": self.invoice_date,
            "DueDate": self.due_date,
            "AccountingDate": self.accounting_date,
            "LedgerYear": self.ledger_year,
            "OMDepartmentRecIdExtFUJ": self.department_recid,
            "EinvoiceEANNum": self.invoice_ean,
            "PurchOrderFormNum": self.order_form_num,
            "ContactPersonId": self.contact_person_id,
            "CurrencyCode": self.currency_code,
            "InvoiceIntroTxt": self.text,
            "files": {"file": [file.dict for file in self.files]},
            "custinvoiceLines": {"custinvoiceLine": [line.dict for line in self.lines]},
        }


class InvoiceResponse(Response):

    def __init__(self, request: InvoiceRequest, xml: str):
        super().__init__(request, xml)
        if xml is not None:
            self.rec_id = int(self.data["CustInvoiceTable"]["RecId"])
