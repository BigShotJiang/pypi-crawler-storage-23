Manual testing
--------------

These are manual tests (which require a human). Manual tests include:

- the comparison of images (pyqtgraph exports images differently
  depending on platform, version, and installed packages)

