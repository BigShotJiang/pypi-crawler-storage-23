# This file turns "img" into a Python module such that we can access
# image files in this folder via importlib.resources.
