from mstransfer.cli import main

main()
