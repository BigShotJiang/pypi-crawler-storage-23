from __future__ import annotations

from . import material_data as md
from . import Constants
from .utils import Rot_gen, make_nparray, lunittoScale

import numpy as np 
import numpy.linalg as LA
from typing import Union, List

import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
# import dask 

xrlbool_ = False
try:
    import xraylib as xrl
    #import xraylib_np as xrlnp
    xrlbool_ = True
    #xrlnp.XRayInit()
    xrl.XRayInit()
except ImportError:
    print("Xraylib not available, using (less benchmarked) own implementation instead")

class crystal:
    """A helper class providing basic crystallographic class information about a crystal, including material, orientation, ...
    """
    def __init__(self, Material:str = "Diamond"):
        """Initialize the crystal in default (type dependent) orientation, at 90° angle (pitch-yaw-row format) and room temperature (293 K)

        Args:
            Material (str, optional): [The material type]. Defaults to "Diamond".
        """
        if Material=="Silicon" or Material=="silicon":
            Material=="Si"
        elif Material=="C" or Material=="diamond":
            Material = "Diamond"
        self.autoUpdate = True #for some functions where the angles are changed in the loop, the auto-update can introduce considerable overhead. Can be turned off (only if you know what you are doing!)
        self.material = Material
        self.Tbase:float = 293.
        self.dimension = 2 #the computational dimensionality
        self.thickness = 1E-3
        self._pitch = np.pi/2.0
        self._roll = 0.0
        self._yaw = 0.0

        ######## mounting errors ########
        self._delta_pitch_initial = 0.0
        self._delta_roll_initial = 0.0
        self._delta_yaw_initial = 0.0

        ######## mechanics errors #########
        self._delta_pitch = 0.0
        self._delta_roll = 0.0
        self._delta_yaw = 0.0

        self._pitch_axes = np.array([1.,0.,0])
        self._roll_axes = np.array([0.,1.,0])
        self._yaw_axes = np.array([0.,0.,1.])
        
        self.Z = np.linspace(0.,self.thickness,num=60)
        self.disp_Z = np.zeros(self.Z.size,dtype=float)
        self.isstrained = False
        self.R_cryst2lab = np.eye(3)
        self.set_crystal_planes()
        self.calc_RLab2Cryst()
        self.is_strained = False
        if(xrlbool_):
            self.cryst = xrl.Crystal_GetCrystal(Material)

    ######################################################################
    ############## define user access properties (taking care of correctly updating the data) ####################
    def updateCB(self):
        if self.autoUpdate:
            self.calc_RLab2Cryst()


    ############################# angles #####################
    @property
    def pitch(self) -> float:
        """The crystal pitch angle in radians (where pi/2 means normal incidence)
        """
        return self._pitch
    @pitch.setter
    def pitch(self,pitch:float):
        """Set the crystal pitch angle in radians (where pi/2 means normal incidence)
        """
        self._pitch = pitch
        self.updateCB()
    
    @property
    def roll(self) -> float:
        """The crystal roll angle in radians
        """
        return self._roll
    @roll.setter
    def roll(self,roll:float):
        """Set the crystal roll angle in radians
        """
        self._roll = roll
        self.updateCB()

    @property
    def yaw(self) -> float:
        """The crystal yaw angle in radians
        """
        return self._yaw
    @yaw.setter
    def yaw(self,yaw:float):
        """Set the crystal yaw angle in radians
        """
        self._yaw = yaw
        self.updateCB()


    ############################## angular errors #######################
    @property
    def delta_pitch(self) -> float:
        """Error of the crystal pitch angle in radians 
        """
        return self._delta_pitch
    @delta_pitch.setter
    def delta_pitch(self,delta_pitch:float):
        """Set the crystal pitch angle error in radians
        """
        self._delta_pitch = delta_pitch
        self.updateCB()
    
    @property
    def delta_roll(self) -> float:
        """Error of the crystal roll angle in radians
        """
        return self._delta_roll
    @delta_roll.setter
    def delta_roll(self,delta_roll:float):
        """Set the crystal roll angle error in radians
        """
        self._delta_roll = delta_roll
        self.updateCB()

    @property
    def delta_yaw(self) -> float:
        """Error of the crystal roll angle in radians
        """
        return self._delta_yaw
    @delta_yaw.setter
    def delta_yaw(self,delta_yaw:float):
        """Set the crystal roll angle error in radians
        """
        self._delta_yaw = delta_yaw
        self.updateCB()

    ############################## mounting ##############################
    @property
    def delta_pitch_initial(self) -> float:
        """Initial pitch rotation error of crystal in mounting
        """
        return self._delta_pitch_initial
    
    @delta_pitch_initial.setter
    def delta_pitch_initial(self,delta_pitch_initial:float):
        """Set the initial pitch rotation error of crystal in mounting
        """
        self._delta_pitch_initial = delta_pitch_initial
        self.updateCB()

    @property
    def delta_roll_initial(self) -> float:
        """Initial roll rotation error of crystal in mounting
        """
        return self._delta_roll_initial

    @delta_roll_initial.setter
    def delta_roll_initial(self,delta_roll_initial:float):
        """Set the initial roll rotation error of crystal in mounting
        """
        self._delta_roll_initial = delta_roll_initial
        self.updateCB()

    @property
    def delta_yaw_initial(self) -> float:
        """Initial yaw rotation error of crystal in mounting
        """
        return self._delta_yaw_initial
    @delta_yaw_initial.setter
    def delta_yaw_initial(self,delta_yaw_initial:float):
        """Set the initial yaw rotation error of crystal in mounting
        """
        self._delta_yaw_initial = delta_yaw_initial
        self.updateCB()

    ############################## rotation axis #########################
    @property
    def pitch_axes(self)->np.ndarray:
        """Rotation axes for the pitch rotation as normalized 3x1 Cartesian vector in lab-coordinates
        """
        return self._pitch_axes
    @pitch_axes.setter
    def pitch_axes(self,pitch_axes:np.ndarray):
        """Set the rotation axes for the pitch rotation as normalized Cartesian vector in lab-coordinates
        """
        self._pitch_axes = pitch_axes
        self.updateCB()
    
    @property
    def roll_axes(self)->np.ndarray:
        """Rotation axes for the roll rotation as normalized 3x1 Cartesian vector in lab-coordinates
        """
        return self._roll_axes
    @roll_axes.setter
    def roll_axes(self,roll_axes:np.ndarray):
        """Set the rotation axes for the roll rotation as normalized Cartesian vector in lab-coordinates
        """
        self._roll_axes = roll_axes
        self.updateCB()

    @property
    def yaw_axes(self)->np.ndarray:
        """Rotation axes for the yaw rotation as normalized 3x1 Cartesian vector in lab-coordinates
        """
        return self._yaw_axes
    @yaw_axes.setter
    def yaw_axes(self,yaw_axes:np.ndarray):
        """Set the rotation axes for the yaw rotation as normalized Cartesian vector in lab-coordinates
        """
        self._yaw_axes = yaw_axes
        self.updateCB()
    
        
    def calc_RLab2Cryst(self):
        """Calculate the rotation matrix to transform 
        from the lab to the crystal frame and vice versa.
        """
        # initial rotation in mount
        if self._delta_yaw_initial == 0:
            self.R_cryst2lab = np.eye(3)
        else:
            self.R_cryst2lab = Rot_gen(self._delta_yaw_initial, np.array([0,0,1]))
        if self._delta_roll_initial != 0:
            self.R_cryst2lab = Rot_gen(self._delta_roll_initial, np.array([0,1,0]))@self.R_cryst2lab
        if self._delta_pitch_initial != 0:
            self.R_cryst2lab = Rot_gen(-self._delta_pitch_initial, np.array([1,0,0]))@self.R_cryst2lab

        # rotation by mechanics 
        if(self._yaw+self._delta_yaw!=0):
            self.R_cryst2lab = Rot_gen(self._yaw+self._delta_yaw, self._yaw_axes)
        if(self._roll+self._delta_roll!=0):
            self.R_cryst2lab = Rot_gen(self._roll+self._delta_roll, self._roll_axes)@self.R_cryst2lab
        if(self._pitch + self._delta_pitch - np.pi/2. != 0):
            self.R_cryst2lab = Rot_gen(np.pi/2. - (self._pitch + self._delta_pitch), self._pitch_axes)@self.R_cryst2lab

        self.R_lab2cryst=self.R_cryst2lab.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()

    def set_crystal_planes(self, i: str="100"):
        """sets the 3D crystallographic orientation of the crystal from a list of predefined orientations. 
        The current list of predefined orientations is:
        "100": z=[-1,0,0]; x=[0,-1/sqrt(2),1/sqrt(2)], y=[0,1/sqrt(2),-1/sqrt(2)]
        "111": z=[-1,-1,-1]/sqrt(3); x=[-1/sqrt(2),1/sqrt(2),0], y=[1/sqrt(6),1/sqrt(6),-2/sqrt(6)]

        Args:
            i (str, optional): the predefined configuration. Defaults to "100".
        """
        if(i=="100"):
            self.R_H2cryst = np.array([
                [0, 1/np.sqrt(2), 1/np.sqrt(2)],
                [0, 1/np.sqrt(2), -1/np.sqrt(2)],
                [-1,0,0]
        ])
        elif(i=="111"):
            self.R_H2cryst = np.array([
                [-1/np.sqrt(2), 1/np.sqrt(2),0],
                [1/np.sqrt(6), 1/np.sqrt(6), -2/np.sqrt(6)],
                [-1/np.sqrt(3),-1/np.sqrt(3),-1/np.sqrt(3)]
            ])
        elif(i=="001"):
            self.R_H2cryst = np.array([
                [1/np.sqrt(2), -1/np.sqrt(2),0],
                [1/np.sqrt(2), 1/np.sqrt(2),0],
                [0,0,-1]
            ])
        self.R_cryst2H = self.R_H2cryst.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()

    def set_crystal_planes_xz(self,
        Hx: np.ndarray, Hz: np.ndarray):
        """manually sets the 3D crystallographic orientation of the crystal via definition of the (perpendicular!) x- and z-axis. The y-axis orientation is deduced via the right-hand rule from the other two.

        Args:
            Hx (np.ndarray(shape=3)): the 3D x-axis orientation
            Hz (np.ndarray(shape=3)): [the 3D z-axis orientation]

        Raise:
            AssertionError: orientation vectors must be 3x1 numpy arrays or lists
            AssertionError: orientation vectors must be perpendicular!
        """
        Hx = np.asarray(Hx)
        Hz = np.asarray(Hz)
        assert Hx.size+Hz.size==6 and Hx.size==3, "orientation vectors must be 3d vectors"
        assert np.dot(Hx,Hz)==0, "entered Hx and Hz not perpendicular!" 

        Hx_local = Hx/LA.norm(Hx)
        Hz_local = Hz/LA.norm(Hz)
        Hy_local = np.cross(Hz_local, Hx_local)
        Hy_local = Hy_local/LA.norm(Hy_local)

        self.R_H2cryst = np.array([
                [Hx_local[0], Hx_local[1], Hx_local[2]],
                [Hy_local[0], Hy_local[1], Hy_local[2]],
                [Hz_local[0], Hz_local[1], Hz_local[2]]
        ])

        self.R_cryst2H = self.R_H2cryst.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()

    def set_crystal_planes_xy(self,
        Hx: np.ndarray, Hy: np.ndarray):
        """manually sets the 3D crystallographic orientation of the crystal via definition of the (perpendicular!) x- and y-axis. The z-axis orientation is deduced via the right-hand rule from the other two.

        Args:
            Hx (np.ndarray(shape=3)): the 3D x-axis orientation
            Hy (np.ndarray(shape=3)): [the 3D y-axis orientation]

        Raise:
            AssertionError: orientation vectors must be 3x1 numpy arrays or lists
            AssertionError: orientation vectors must be perpendicular!
        """
        Hx = np.asarray(Hx)
        Hy = np.asarray(Hy)
        assert Hx.size+Hy.size==6 and Hx.size==3, "orientation vectors must be 3d vectors"
        assert np.dot(Hx,Hy)==0, "entered Hx and Hz not perpendicular!" 

        Hx_local = Hx/LA.norm(Hx)
        Hy_local = Hy/LA.norm(Hy)
        Hz_local = np.cross(Hx_local, Hy_local)
        Hz_local = Hz_local/LA.norm(Hz_local)

        self.R_H2cryst = np.array([
                [Hx_local[0], Hx_local[1], Hx_local[2]],
                [Hy_local[0], Hy_local[1], Hy_local[2]],
                [Hz_local[0], Hz_local[1], Hz_local[2]]
        ])

        self.R_cryst2H = self.R_H2cryst.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()

    def set_crystal_planes_z(self, Hz: np.ndarray):
        """manually sets the 3D crystallographic orientation of the crystal via definition of only the z-axis. The x-axis and y-axis orientation are chosen semi-randomly via the right-hand rule from the other z-axis orientation.

        Args:
            Hz (np.ndarray(shape=3)): the 3D z-axis orientation

        Raise:
            AssertionError: orientation vectors must be 3x1 numpy arrays or lists
            AssertionError: orientation vectors must be perpendicular!
        """
        Hz = np.asarray(Hz)
        assert Hz.size==3, "orientation vectors must be 3d vectors"

        Hz_local = Hz/LA.norm(Hz)
        dummyVec = np.array([0,0,1])

        if (dummyVec.dot(Hz_local)==1):
            dummyVec = np.array([1,1,1])

        Hx_local = np.cross(dummyVec, Hz_local)
        Hx_local = Hx_local/np.sqrt(np.sum(Hx_local**2))
        Hy_local = np.cross(Hz_local, Hx_local)
        Hy_local = Hy_local/np.sqrt(np.sum(Hy_local**2))

        self.R_H2cryst = np.array([
                [Hx_local[0], Hx_local[1], Hx_local[2]],
                [Hy_local[0], Hy_local[1], Hy_local[2]],
                [Hz_local[0], Hz_local[1], Hz_local[2]]
        ])

        self.R_cryst2H = self.R_H2cryst.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()

    def set_crystal_planes_yz(self,
        Hy: np.ndarray, Hz: np.ndarray):
        """manually sets the 3D crystallographic orientation of the crystal via definition of the (perpendicular!) y- and z-axis. The x-axis orientation is deduced via the right-hand rule from the other two.

        Args:
            Hy (np.ndarray(shape=3)): the 3D y-axis orientation
            Hz (np.ndarray(shape=3)): [the 3D z-axis orientation]

        Raise:
            AssertionError: orientation vectors must be 3x1 numpy arrays or lists
            AssertionError: orientation vectors must be perpendicular!
        """
        Hz = np.asarray(Hz)
        Hy = np.asarray(Hy)
        assert Hz.size+Hy.size==6 and Hz.size==3, "orientation vectors must be 3d vectors"
        assert np.dot(Hz,Hy)==0, "entered Hx and Hz not perpendicular!" 

        Hz_local = Hz/LA.norm(Hz)
        Hy_local = Hy/LA.norm(Hy)
        Hx_local = np.cross(Hy_local, Hz_local)
        Hx_local = Hx_local/LA.norm(Hx_local)

        self.R_H2cryst = np.array([
                [Hx_local[0], Hx_local[1], Hx_local[2]],
                [Hy_local[0], Hy_local[1], Hy_local[2]],
                [Hz_local[0], Hz_local[1], Hz_local[2]]
        ])

        self.R_cryst2H = self.R_H2cryst.transpose()
        self.R_H2Lab = self.R_cryst2lab@self.R_H2cryst
        self.R_Lab2H = self.R_H2Lab.transpose()




    def get_lattice_spacing(self,T: Union[float,int,np.ndarray]) ->np.ndarray :
        """get the crystals' lattice spacing for a specific temperature

        Args:
            T (float, int or np.ndarray[]): int | float) the crystal temperature

        Returns:
            np.ndarray[float]: the lattice spacing
        """
        return md.lattice_spacing(self.material, T)

    def getDBW(self, H: Union[List[float],np.ndarray], T: Union[float,int,list,np.ndarray]) -> np.ndarray:
        """get the debye-waller factor for a given plane H and temperature T

        Args:
            H (array of floats): 3D plane normal
            T (float,int,or np.ndarray]): the crystal temperature(s)

        Returns:
            np.ndarray: the debye-waller factor(s)
        Raise:
            AssertionError: plane vector must be 3x1 numpy array or list
        """
        H = np.asarray(H)
        assert H.size==3, "orientation vectors must be 3d vectors"
        dbw = md.debye_waller(self.material, T)
        a = self.get_lattice_spacing(T)
        dH = a/np.sqrt(np.sum(H**2)) #only valid for cubic crystal!
        s = 0.5/dH
        return np.exp(-dbw*s*s)

    def getChi(self, E: Union[float, List[float], np.ndarray], H: Union[List[float],np.ndarray], T: Union[float,int,list,np.ndarray]):
        """get the susceptibility for a set of specific energies in eV, temperature in Kelvin and crystal plane. 
        Results differ if xraylib is implemented or not

        Basically just calls getChi_singleE for every E
        Args:
            E (float or list/array of floats): photon energy/ies in eV, 
            H (Union[List[float],np.ndarray]): the crystal plane as 3D vector
            T (Union[float,int,list,np.ndarray]): the crystal temperature(s)
        Returns:
            np.ndarray: 2D array of the complex 0th and Hth order Fourier components of the susceptibilities stored in the columns (second index) 
        """
        E = make_nparray(E)
        a = np.array([self.getChi_singleE(Ei, H, T ) for Ei in E])
        return a.squeeze()


    def getChi_singleE(self, E: float, H: Union[List[float],np.ndarray], T: Union[float,int,list,np.ndarray]):
        """get the susceptibility for a single specific energy in eV, temperature in Kelvin and crystal plane. 
        Results differ if xraylib is implemented or not

        Args:
            E (float): photon energy in eV, 
            H (Union[List[float],np.ndarray]): the crystal plane as 3D vector
            T (Union[float,int,list,np.ndarray]): the crystal temperature(s)
        Returns:
            List[complex]: tuple of the complex 0th and Hth order Fourier components of the susceptibilities
        """
        E = E*1E-3 
        #Hack:, for some reason xraylib returns Nan if E is smaller than the nominal Theta_Bragg=90° energy of the xrl code
        EB = 0.5*1E+10*1E-3*Constants.h_planck_eV*Constants.c0*np.linalg.norm(H)/self.cryst["a"]
        E_H = E if E>(1+1E-6)*EB else 1.00001*EB 
        a = self.get_lattice_spacing(T)
        #dH = a/np.sqrt(np.sum(H**2))
        #s = 0.5/dH
        F_T = self.getDBW(H, T)

        pre = -Constants.r0_atoms*((Constants.h_planck_eV*Constants.c0/E)**2)/(np.pi*a**3)*1E-6
        if(xrlbool_):
            F_0 = xrl.Crystal_F_H_StructureFactor(self.cryst, E, 0, 0, 0, 1., 1.)
            F_H = np.array([xrl.Crystal_F_H_StructureFactor(self.cryst, E_H, int(H[0]), int(H[1]), int(H[2]), F_Ti, 1.) for F_Ti in F_T])
        else:
            pass
            #TODO: Just a placeholder at the moment! See matlab scripts
        return [pre*(F_0.real -1j*F_0.imag), pre*(F_H.real -1j*F_H.imag)]

    def getChis(self, E: Union[float, List[float], np.ndarray], H: Union[List[float],np.ndarray], T: Union[float,int,list,np.ndarray]):
        """get the susceptibilities for a whole set of planes at a set of specific energies in eV, temperature in Kelvin.
        Results differ if xraylib is implemented or not.

        Just calls the subroutine getChis_singleE for each energy point
        Args:
            E (float or list/array of floats): photon energy/ies in eV,
            H (np.ndarray of dimension n_planes x 3 ]): the crystal planes as list of 3D vectors
            T (Union[float,int,list,np.ndarray]): the crystal temperature(s)
        Returns:
            np.ndarray: E-points x n_planes+1 x nplanes+1 dimensional array of the complex susceptibilities, with the diagonal corresponding to the 0th order Fourier component
        """
        E = make_nparray(E)

        return np.array([self.getChis_singleE(Ei, H, T ) for Ei in E])


    def getChis_singleE(self, E: float, H: Union[List[float],np.ndarray], T: Union[float,int,list,np.ndarray]):
        """get the susceptibilities for a whole set of planes at a single specific energy in eV, temperature in Kelvin.
        Results differ if xraylib is implemented or not
        Args:
            E (float): photon energy in eV, 
            H (np.ndarray of dimension n_planes x 3 ]): the crystal planes as list of 3D vectors
            T (Union[float,int,list,np.ndarray]): the crystal temperature(s)
        Returns:
            np.ndarray: n_planes+1 x nplanes+1 dimensional array of the complex susceptibilities, with the diagonal corresponding to the 0th order Fourier component
        """
        E = E*1E-3
        #FIXME: Dirty hack, for some reason xraylib returns Nan if E is smaller than the nominal Theta_Bragg=90° energy of the xrl code
        EB = 0.5*1E+10*1E-3*Constants.h_planck_eV*Constants.c0*np.linalg.norm(H)/self.cryst["a"]
        E_H = E if E>(1+1E-6)*EB else 1.00001*EB 


        nplanes = H.shape[0]

        xArray = np.ndarray([nplanes+1,nplanes+1],dtype=complex)
        
        a = self.get_lattice_spacing(T)[0]
        dbw = md.debye_waller(self.material,T)
        pre = -Constants.r0_atoms*((Constants.h_planck_eV*Constants.c0/E)**2)/(np.pi*a**3)*1E-6
      
        if(xrlbool_):
            F0 = xrl.Crystal_F_H_StructureFactor(self.cryst, E, 0, 0, 0, 1., 1.)
        else:
            F0 = 0 + 0j #TODO: Placeholder
        x0h = pre*(F0.real-1j*F0.imag)

        Hplane_dummy = np.vstack([np.zeros([1,3],dtype=int),H])
        Hd = np.ndarray(3,dtype=int)
        for I1 in range(nplanes+1):
            for I2 in range(nplanes+1):
                if( I1 == I2):
                    xArray[I1,I2]=x0h 
                else:
                    Hd = Hplane_dummy[I1,:] - Hplane_dummy[I2,:]
                    dH=a/np.sqrt(np.sum(Hd**2))
                    s = 0.5/dH
                    F_T = np.exp(-dbw*s*s)
                    if(xrlbool_):
                        F_H = xrl.Crystal_F_H_StructureFactor(self.cryst, E_H,int(Hd[0]), int(Hd[1]), int(Hd[2]), F_T[0], 1.)
                    else:
                        F_H = 0 + 0j #TODO: Placeholder
                    xArray[I1,I2] = pre*(F_H.real - 1j*F_H.imag)
        return xArray
        #

    def read_comsol_data(self,Com_output_file: str,makePlots:bool=False,lplot_unit=None):
        """Imports 2D to 3D strain fields and temperature from a gridded comsol output file

        Args:
            Com_output_file (str): The path to the Comsol file storing the data
            make_plots (bool): If the displacement field(s) shall be plotted. Defaults to False.
            lplot_unit (str or None): If plots shall be made, the length unit the metric data shall be plotted with. If None, take the same unit as the saved data. Defaults to None.
        """

        self.dimension = 0
        observables_lst = np.array(['u ','v ','w ','T '])
        self.observables =  {"u":-1,"v":-1,"w":-1,"T":-1}
        independents_lst = np.array(['X','Y','Z','R'])
        self.independents =  {"X":-1,"Y":-1,"Z":-1,"R":-1}
        try: 
            comstream = open(Com_output_file, 'r')
        except OSError:
            message = f"{self.read_comsol_data.__name__}: File {Com_output_file} not found!"
            raise RuntimeError(message)

        # Check for Dimension and Expressions
        for line in comstream:
            if line.startswith('%'):
                if "Dimension:" in line:
                    self.dimension = int(line.split(':')[1])
                elif "Expressions:" in line:
                    pass
                    # num_expressions = int(line.split(':')[1])
                elif "Length unit:" in line:
                    length_unit = line.split(':')[1].strip().split('\\')[0]
                    
                prev_line = line
            else:
                observables_stored = np.array(prev_line.split("  "))
                observables_stored = observables_stored[observables_stored!='']

                comstream.close()
                break

        for obs in observables_lst:
            for idx,obs_stored in enumerate(observables_stored):
                if obs_stored.find(obs)>=0:
                    self.observables[obs.strip()] = idx
        for ind in independents_lst:
            for idx,obs_stored in enumerate(observables_stored[:self.dimension]):
                if obs_stored.find(ind)>=0:
                    self.independents[ind.strip()] = idx

        #------- load data and put into correct format-----------#
        data = np.loadtxt(Com_output_file,comments='%')

        if makePlots:
            if lplot_unit is None:
                lplot_unit = length_unit

        if(self.dimension==2):
            self.load_Comsol_data_2D(data,length_unit)
            if makePlots:
                self.plot_2D_displacement(lplot_unit)

        elif self.dimension==3:
            self.load_Comsol_data_3D(data,length_unit)
            if makePlots:
                self.plot_3D_displacement(lplot_unit)

        self.thickness = self.independents["Z"].max()
        self.is_strained = True

    def load_Comsol_data_2D(self,data: np.ndarray,length_unit:str):
        """Load three-dimensional Comsol data (R,Z).
           The data will first be resorted, such that the 
           Z-axis will be fast varying and the R-axis will 
           be the slowly varying one.

        Args:
            data (np.ndarray): The full data matrix, unstructured
            length_unit (str): The length unit the metric data is saved with
        """
        lfactor = lunittoScale(length_unit)
        r = data[:,self.independents['R']]
        z = data[:,self.independents['Z']]
        dr_mean = np.mean(np.abs(np.diff(r)))
        dz_mean = np.mean(np.abs(np.diff(z)))

        rzorder = np.flip(np.argsort([dr_mean,dz_mean]))
        rz_full = np.array([r,z])[rzorder]

        numCol0 = np.sum(rz_full[1,:]==rz_full[1,0]).astype(int)
        numCol1 = int(np.size(r)/numCol0)

        #--- the z-axis should be the fast varying one ----#
        def reorder(f):
            if rzorder[0]==1:
                return f
            else:
                return np.transpose(f) 

        self.independents['R'] = reorder(np.reshape(data[:,int(self.independents['R'])],(numCol1,numCol0)))*lfactor
        self.independents['Z'] = reorder(np.reshape(data[:,int(self.independents['Z'])],(numCol1,numCol0)))*lfactor

        if(np.any(self.observables['u']>=0)):
            self.observables['u'] = reorder(np.reshape(data[:,int(self.observables['u'])],(numCol1,numCol0)))*lfactor
        if(np.any(self.observables['v']>=0)):
            self.observables['v'] = reorder(np.reshape(data[:,int(self.observables['v'])],(numCol1,numCol0)))*lfactor
        if(np.any(self.observables['w']>=0)):
            self.observables['w'] = reorder(np.reshape(data[:,int(self.observables['w'])],(numCol1,numCol0)))*lfactor
        if(np.any(self.observables['T']>=0)):
            self.observables['T'] = reorder(np.reshape(data[:,int(self.observables['T'])],(numCol1,numCol0)))
        else:
            self.observables['T'] = reorder(np.ones((numCol1,numCol0)))*self.Tbase

    def load_Comsol_data_3D(self,data: np.ndarray,length_unit:str):
        """Load three-dimensional Comsol data (X,Y,Z).
           The data will first be resorted, such that the 
           Z-axis will be fast varying and the X-axis will 
           be the slowly varying one. 

        Args:
            data (np.nadarray): The full data matrix, unstructured
            length_unit (str): The length unit the metric data is saved with

        """
        lfactor = lunittoScale(length_unit)
        x = data[:,self.independents['X']]
        y = data[:,self.independents['Y']]
        z = data[:,self.independents['Z']]
        dx_mean = np.mean(np.abs(np.diff(x)))
        dy_mean = np.mean(np.abs(np.diff(y)))
        dz_mean = np.mean(np.abs(np.diff(z)))

        xyzorder = np.flip(np.argsort([dx_mean,dy_mean,dz_mean]))
        xyz_full = np.array([x,y,z])[xyzorder]
        numCol01 = np.sum(xyz_full[2,:]==xyz_full[2,0])
        numCol0 = np.sum(xyz_full[1,:numCol01]==xyz_full[1,0]).astype(int)
        numCol1 = np.sum(xyz_full[2,:numCol01:numCol0]==xyz_full[2,0]).astype(int)
        numCol2 = int(np.size(x)/numCol0/numCol1)

        #--- the z-axis should be the fast varying one ----#
        def reorder(f):
            if np.all(xyzorder == np.array([2,1,0])):
                return f
            else:
                return np.moveaxis(f,xyzorder,[2,1,0])
        self.independents['X'] = reorder(np.reshape(x,(numCol2,numCol1,numCol0)))*lfactor
        self.independents['Y'] = reorder(np.reshape(y,(numCol2,numCol1,numCol0)))*lfactor
        self.independents['Z'] = reorder(np.reshape(z,(numCol2,numCol1,numCol0)))*lfactor

        if(np.any(self.observables['u']>=0)):
            self.observables['u'] = reorder(np.reshape(data[:,self.observables['u']],(numCol2,numCol1,numCol0)))*lfactor
        if(np.any(self.observables['v']>=0)):
            self.observables['v'] = reorder(np.reshape(data[:,self.observables['v']],(numCol2,numCol1,numCol0)))*lfactor
        if(np.any(self.observables['w']>=0)):
            self.observables['w'] = reorder(np.reshape(data[:,self.observables['w']],(numCol2,numCol1,numCol0)))*lfactor
        if(np.any(self.observables['T']>=0)):
            self.observables['T'] = reorder(np.reshape(data[:,self.observables['T']],(numCol2,numCol1,numCol0)))
        else:
            self.observables['T'] = reorder(np.ones((numCol2,numCol1,numCol0)))*self.Tbase

    def plot_2D_displacement(self,lunit='µm'):
        num_obs = np.sum([np.size(v)>1 for v in self.observables.values()])
        lfactor = lunittoScale(lunit)
        maxvals = np.array([np.abs(v).max() for v in self.observables.values()])
        plot_params = {'u': [lfactor, f'u [{lunit}]','RdBu_r',
                             [-maxvals[0]/lfactor,maxvals[0]/lfactor]],
                       'v': [lfactor, f'v [{lunit}]','RdBu_r',[-maxvals[1]/lfactor,maxvals[1]/lfactor]], 
                       'w': [lfactor, f'w [{lunit}]','RdBu_r',[-maxvals[2]/lfactor,maxvals[2]/lfactor]],
                       'T': [1, 'T [K]','magma',[None,None]] }
        wsingle = 5
        hsingle = 3
        wpad = 0.05
        ncols = np.min([num_obs,4])
        print(ncols)
        wtot = ncols*(wsingle+wpad) - wpad
        fig, axs = plt.subplots(ncols=ncols,figsize=(wtot,hsingle),sharex='all',sharey='all',gridspec_kw={'wspace':wpad})
        idx = 0
        axs[0].set_ylabel(f"z [{lunit}]",fontsize=32)
        for i,v in self.observables.items():
            if np.size(v)>1:
                
                axs[idx].tick_params(labelsize=28)
                img = axs[idx].pcolormesh(self.independents['R']/lfactor,self.independents['Z']/lfactor,v/plot_params[i][0],cmap=plot_params[i][2],vmin=plot_params[i][3][0],vmax=plot_params[i][3][1])
                axs[idx].set_xlabel(f'R [{lunit}]',fontsize=32)

                if idx>0:
                    axs[idx].tick_params('y',labelleft=False)

                divider = make_axes_locatable(axs[idx])
                ax_cb = divider.append_axes("top", size="23%", pad=0.05)
                fig.add_axes(ax_cb)
                ax_cb.tick_params(labelsize=28)
                fig.colorbar(location='top',cax=ax_cb,mappable=img)
                ax_cb.set_xlabel(plot_params[i][1],fontsize=28,color='black')
                ax_cb.xaxis.set_label_coords(0.5,0.14)

                idx+=1                     
    
    def plot_3D_displacement(self,lunit='µm'):
        num_obs = np.sum([np.size(v)>1 for v in self.observables.values()])
        lfactor = lunittoScale(lunit)
        maxvals = np.array([np.abs(v).max() for v in self.observables.values()])

        plot_params = {'u': [lfactor, f'u [{lunit}]','RdBu_r',[-maxvals[0]/lfactor,maxvals[0]/lfactor]],
                       'v': [lfactor, f'v [{lunit}]','RdBu_r',[-maxvals[1]/lfactor,maxvals[1]/lfactor]], 
                       'w': [lfactor, f'w [{lunit}]','RdBu_r',[-maxvals[2]/lfactor,maxvals[2]/lfactor]],
                       'T': [1, 'T [K]','magma',[None,None]] }
        wsingle = 5
        hsingle = 3
        ncols = np.min([num_obs,4])
        wpad = 0.05
        hpad = 1
        wtot = ncols*(wsingle+wpad) - wpad
        htot = 3*(hsingle+hpad) - hpad
        fig, axs = plt.subplots(ncols=ncols,nrows=3,figsize=(wtot,htot),gridspec_kw={'wspace':wpad,'hspace':hpad})
        for ax in axs.ravel():
            ax.tick_params(labelsize=28)
        idx = 0
        axs[0,0].set_ylabel(f"z [{lunit}]",fontsize=32)
        axs[1,0].set_ylabel(f"z [{lunit}]",fontsize=32)
        axs[2,0].set_ylabel(f"y [{lunit}]",fontsize=32)

        

        ymid = np.argmin(np.abs(self.independents['Y'][0,:,0]))
        xmid = np.argmin(np.abs(self.independents['X'][:,0,0]))
        zmid = np.argmin(np.abs(self.independents['Z'][0,0,:]))
        for i,v in self.observables.items():
            if np.size(v)>1:
                for irow in range(3):
                    if irow==0: #X,Z plot
                        img = axs[irow,idx].pcolormesh(self.independents['X'][:,ymid,:]/lfactor,self.independents['Z'][:,ymid,:]/lfactor,v[:,ymid,:]/plot_params[i][0],cmap=plot_params[i][2],vmin=plot_params[i][3][0],vmax=plot_params[i][3][1])
                        axs[irow,idx].set_xlabel(f'x [{lunit}]',fontsize=32)
                    elif irow==1: #Y,Z plot
                        img = axs[irow,idx].pcolormesh(self.independents['Y'][xmid,:,:]/lfactor,self.independents['Z'][xmid,:,:]/lfactor,v[xmid,:,:]/plot_params[i][0],cmap=plot_params[i][2],vmin=plot_params[i][3][0],vmax=plot_params[i][3][1])
                        axs[irow,idx].set_xlabel(f'y [{lunit}]',fontsize=32)
                    else: #X,Y plot
                        img = axs[irow,idx].pcolormesh(self.independents['X'][:,:,zmid]/lfactor,self.independents['Y'][:,:,zmid]/lfactor,v[:,:,zmid]/plot_params[i][0],cmap=plot_params[i][2],vmin=plot_params[i][3][0],vmax=plot_params[i][3][1])
                        axs[irow,idx].set_xlabel(f'x [{lunit}]',fontsize=32)    
                    if idx>0:
                        axs[irow,idx].tick_params('y',labelleft=False)
                    divider = make_axes_locatable(axs[irow,idx])
                    ax_cb = divider.append_axes("top", size="23%", pad=0.05)
                    fig.add_axes(ax_cb)
                    ax_cb.tick_params(labelsize=28)
                    fig.colorbar(location='top',cax=ax_cb,mappable=img)
                    ax_cb.set_xlabel(plot_params[i][1],fontsize=28,color='black')
                    ax_cb.xaxis.set_label_coords(0.5,0.14)

                idx+=1

    def z_Surf(self) -> np.ndarray:
        """Returns the surface plane

        Returns:
            np.ndarray: the surface plane
        """
        return self.R_cryst2H[:,2]
    def x(self) -> np.ndarray:
        """Returns the x-directed plane

        Returns:
            np.ndarray: the x-orientation
        """
        return self.R_cryst2H[:,0]

    def y(self) -> np.ndarray:
        """Returns the y-directed plane

        Returns:
            np.ndarray: the y-orientation
        """
        return self.R_cryst2H[:,1]
#cr = crystal()

#print(cr.cryst['name'])

