"""MCP (Model Context Protocol) configuration generation."""

import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from atk.env import load_env_file
from atk.plugin_schema import PluginSchema

# Environment variable name for plugin directory
ATK_PLUGIN_DIR = "ATK_PLUGIN_DIR"

# Sentinel written into env when a variable has no resolved value.
# Single authoritative definition — import from here everywhere else.
NOT_SET = "<NOT_SET>"


@dataclass
class McpConfig(ABC):
    """Resolved MCP server configuration for a plugin.

    Produced by generate_mcp_config() after substituting environment variables
    and $ATK_PLUGIN_DIR placeholders.  Use StdioMcpConfig or SseMcpConfig
    directly; this base class is never instantiated on its own.
    """

    identifier: str              # Key used in MCP JSON output and agent CLI commands
    plugin_name: str             # Display name from the plugin schema
    env: dict[str, str]          # Resolved env vars; NOT_SET sentinel for required vars with no value
    missing_vars: list[str]      # Required vars that have no value (appear as NOT_SET in env)
    optional_unset_vars: list[str]  # Optional vars with no value; omitted from env and JSON entirely

    @abstractmethod
    def to_mcp_dict(self) -> dict[str, Any]:
        """Serialize to the standard MCP JSON config structure.

        The returned dict has the identifier as the single top-level key,
        matching what MCP clients expect in their configuration files.
        """


@dataclass
class StdioMcpConfig(McpConfig):
    """Resolved MCP config for a stdio (command-based) server."""

    command: str
    args: list[str]

    def to_mcp_dict(self) -> dict[str, Any]:
        inner: dict[str, Any] = {"command": self.command}
        if self.args:
            inner["args"] = self.args
        if self.env:
            inner["env"] = self.env
        return {self.identifier: inner}


@dataclass
class SseMcpConfig(McpConfig):
    """Resolved MCP config for an SSE (URL-based) server."""

    url: str

    def to_mcp_dict(self) -> dict[str, Any]:
        inner: dict[str, Any] = {"url": self.url}
        if self.env:
            inner["env"] = self.env
        return {self.identifier: inner}


def substitute_plugin_dir(value: str, plugin_dir: Path) -> str:
    """Substitute $ATK_PLUGIN_DIR and ${ATK_PLUGIN_DIR} with absolute path.

    Args:
        value: String that may contain $ATK_PLUGIN_DIR or ${ATK_PLUGIN_DIR}.
        plugin_dir: Absolute path to the plugin directory.

    Returns:
        String with substitutions applied.
    """
    plugin_dir_str = str(plugin_dir.resolve())
    # Replace ${ATK_PLUGIN_DIR} first (more specific)
    value = value.replace(f"${{{ATK_PLUGIN_DIR}}}", plugin_dir_str)
    # Then replace $ATK_PLUGIN_DIR
    value = value.replace(f"${ATK_PLUGIN_DIR}", plugin_dir_str)
    return value


def substitute_env_vars(value: str, env: dict[str, str]) -> str:
    """Substitute $VAR and ${VAR} references using resolved env var values.

    Only substitutes variables that have a real value (not NOT_SET).
    Unresolved variables are left unchanged so the caller can detect them.

    Args:
        value: String that may contain $VAR or ${VAR} references.
        env: Resolved env dict (values may be NOT_SET for missing vars).

    Returns:
        String with known env var references replaced by their resolved values.
    """
    for var_name, var_value in env.items():
        if var_value == NOT_SET:
            continue
        # Replace ${VAR} first (more specific), then $VAR
        value = value.replace(f"${{{var_name}}}", var_value)
        value = value.replace(f"${var_name}", var_value)
    return value


def generate_mcp_config(
    plugin: PluginSchema,
    plugin_dir: Path,
    plugin_identifier: str,
) -> McpConfig:
    """Resolve and return the MCP config for a plugin.

    Substitutes $ATK_PLUGIN_DIR and ${ATK_PLUGIN_DIR} in command and args.
    Resolves environment variables from the plugin's .env file and declared
    defaults.

    Required vars with no value are marked NOT_SET in the env dict and tracked
    in missing_vars — they appear in both plaintext and JSON output so the user
    can see exactly what is broken.

    Optional vars with no value are omitted from the env dict entirely (and
    therefore from JSON output) and tracked in optional_unset_vars for display
    in the plaintext view only.

    Args:
        plugin: The plugin schema.
        plugin_dir: Path to the plugin directory.
        plugin_identifier: The identifier used as the key in MCP JSON output.

    Returns:
        StdioMcpConfig for stdio transport, SseMcpConfig for SSE transport.
    """
    if plugin.mcp is None:
        raise ValueError(f"Plugin '{plugin.name}' has no MCP configuration")

    mcp = plugin.mcp
    env_file = plugin_dir / ".env"
    env_values = load_env_file(env_file) if env_file.exists() else {}

    env: dict[str, str] = {}
    missing_vars: list[str] = []
    optional_unset_vars: list[str] = []
    if mcp.env:
        env_var_defaults = {ev.name: ev.default for ev in plugin.env_vars if ev.default is not None}
        env_var_required = {ev.name: ev.required for ev in plugin.env_vars}
        for var_name in mcp.env:
            value = env_values.get(var_name) or env_var_defaults.get(var_name)
            if value:
                env[var_name] = value
            elif env_var_required.get(var_name, True):
                env[var_name] = NOT_SET
                missing_vars.append(var_name)
            else:
                optional_unset_vars.append(var_name)

    if mcp.transport == "stdio":
        if not mcp.command:
            raise ValueError(
                f"Plugin '{plugin.name}' has transport 'stdio' but no command defined."
            )
        return StdioMcpConfig(
            identifier=plugin_identifier,
            plugin_name=plugin.name,
            command=substitute_plugin_dir(mcp.command, plugin_dir),
            args=[
                substitute_env_vars(substitute_plugin_dir(a, plugin_dir), env)
                for a in (mcp.args or [])
            ],
            env=env,
            missing_vars=missing_vars,
            optional_unset_vars=optional_unset_vars,
        )

    # sse
    if not mcp.endpoint:
        raise ValueError(
            f"Plugin '{plugin.name}' has transport 'sse' but no endpoint defined."
        )
    return SseMcpConfig(
        identifier=plugin_identifier,
        plugin_name=plugin.name,
        url=mcp.endpoint,
        env=env,
        missing_vars=missing_vars,
        optional_unset_vars=optional_unset_vars,
    )


def format_mcp_plaintext(config: McpConfig) -> str:
    """Format MCP config as human-readable plaintext with Rich markup.

    Renders sections appropriate to the transport type:
    - StdioMcpConfig: Name, Command (command + args joined), Environment Variables
    - SseMcpConfig:   Name, URL, Environment Variables

    Args:
        config: The resolved MCP config.

    Returns:
        A string containing Rich markup ready for console.print().
    """
    lines: list[str] = []

    lines.append(f"[bold]Name:[/bold]    {config.plugin_name}")

    if isinstance(config, StdioMcpConfig):
        command_parts = [config.command, *config.args]
        lines.append(f"[bold]Command:[/bold]  {' '.join(command_parts)}")
    elif isinstance(config, SseMcpConfig):
        lines.append(f"[bold]URL:[/bold]     {config.url}")

    if config.env or config.optional_unset_vars:
        lines.append("")
        lines.append("[bold]Environment Variables:[/bold]")
        for key, val in config.env.items():
            if val == NOT_SET:
                lines.append(f"  {key}=[red]{val}[/red]")
            else:
                lines.append(f"  {key}=[dim]{val}[/dim]")
        for var_name in config.optional_unset_vars:
            lines.append(f"  {var_name}=[dim]not set (optional, omitted)[/dim]")

    return "\n".join(lines)


def check_sse_reachable(url: str, timeout: int = 3) -> bool:
    """Return True if the SSE endpoint at url responds within timeout seconds.

    Any HTTP response (including 4xx/5xx) counts as reachable; only connection
    failures, timeouts, and DNS errors return False.

    Args:
        url: The SSE endpoint URL to probe.
        timeout: Maximum seconds to wait for a response.
    """
    try:
        urllib.request.urlopen(url, timeout=timeout)
        return True
    except urllib.error.HTTPError:
        # Server replied with an error status — it is still reachable.
        return True
    except Exception:
        return False

