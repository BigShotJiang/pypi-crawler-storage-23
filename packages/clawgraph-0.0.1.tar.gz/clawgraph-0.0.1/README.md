# clawgraph

A Python package for clawgraph.

## Installation

```bash
pip install clawgraph
```

## Usage

```python
import clawgraph
```

## Development

```bash
# Install in editable mode
pip install -e .

# Build the package
python -m build

# Upload to PyPI
python -m twine upload dist/*
```

## License

MIT
