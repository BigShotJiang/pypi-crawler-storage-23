__version__ = "0.1.22"
__app_name__ = "devmemory"
