from devmemory.cli import main

main()
