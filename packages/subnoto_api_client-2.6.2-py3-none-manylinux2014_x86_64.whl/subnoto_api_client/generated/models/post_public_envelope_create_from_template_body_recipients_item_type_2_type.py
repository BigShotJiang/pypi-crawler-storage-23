from enum import Enum

class PostPublicEnvelopeCreateFromTemplateBodyRecipientsItemType2Type(str, Enum):
    MEMBER = "member"

    def __str__(self) -> str:
        return str(self.value)
