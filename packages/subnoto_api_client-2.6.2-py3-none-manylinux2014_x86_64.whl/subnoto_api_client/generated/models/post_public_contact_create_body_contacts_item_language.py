from enum import Enum

class PostPublicContactCreateBodyContactsItemLanguage(str, Enum):
    EN = "en"
    ES = "es"
    FI = "fi"
    FR = "fr"
    IT = "it"

    def __str__(self) -> str:
        return str(self.value)
