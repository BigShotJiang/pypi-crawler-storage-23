from enum import Enum

class PostPublicEnvelopeSendBodyDistributionMethod(str, Enum):
    EMAIL = "email"
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
