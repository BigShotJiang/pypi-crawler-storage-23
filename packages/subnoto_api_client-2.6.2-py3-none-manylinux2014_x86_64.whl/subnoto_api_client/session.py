# Copyright 2025 Subnoto
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import asyncio
import threading
from typing import Optional

import httpx

try:
    from oak_session_py.oak_client import PyClientSession
except ImportError as e:
    raise ImportError(
        f"oak_client module not found: {e}\n"
        "Make sure oak_session_py is built:\n"
        "  eval \"$(direnv export bash)\" && bazel build //oak_session_py:oak_client"
    )

from .types import SubnotoConfig, SubnotoError


class _BaseSessionManager:
    """Base session manager with shared encryption, cookie, and attestation logic"""
    
    def __init__(self, config: SubnotoConfig):
        self.config = config
        self.session_id: Optional[str] = None
        self.cookies = httpx.Cookies()
        self._session = PyClientSession(
            unattested=config.unattested,
            attester_key=config.attester_key
        )
    
    def _is_session_open(self) -> bool:
        return self._session.is_open()
    
    def _handshake_url(self) -> str:
        return f"{self.config.api_base_url}/tunnel/session"
    
    def _build_handshake_headers(self, url: str) -> dict:
        headers = {"Content-Type": "application/octet-stream"}
        if self.session_id:
            headers["X-Session-Id"] = self.session_id
        cookies_str = self._get_cookies_for_request(url)
        if cookies_str:
            headers["Cookie"] = cookies_str
        return headers
    
    def _get_next_outgoing(self) -> Optional[bytes]:
        """Get next outgoing handshake message, or None if session is open/done"""
        if self._is_session_open():
            return None
        return self._session.next_init_message()
    
    def _process_handshake_response(self, response: httpx.Response, url: str) -> None:
        if not self.session_id:
            session_id_header = response.headers.get("X-Session-Id")
            if not session_id_header:
                raise SubnotoError("No session ID received from server")
            self.session_id = session_id_header
        
        if not response.is_success:
            raise SubnotoError(
                f"Handshake failed with status {response.status_code}: {response.text}",
                response.status_code
            )
        
        self._store_cookies(response, url)
        
        response_data = response.content
        if len(response_data) > 0:
            self._session.handle_init_message(bytes(response_data))
        else:
            raise SubnotoError("Empty response from server during handshake")
    
    def _finalize_handshake(self) -> None:
        if not self._is_session_open() or not self.session_id:
            raise SubnotoError("Failed to establish session after handshake")
    
    def encrypt_request(self, plaintext: bytes) -> bytes:
        """Encrypt a request body"""
        if not self._is_session_open():
            raise SubnotoError("Session not open")
        try:
            return self._session.encrypt_buffer(plaintext)
        except Exception as e:
            raise SubnotoError(f"Encryption failed: {e}")
    
    def decrypt_response(self, encrypted: bytes) -> bytes:
        """Decrypt a response body"""
        if not self._is_session_open():
            raise SubnotoError("Session not open")
        try:
            return bytes(self._session.decrypt_buffer(encrypted))
        except Exception as e:
            raise SubnotoError(f"Decryption failed: {e}")
    
    def get_session_id(self) -> Optional[str]:
        return self.session_id
    
    def _get_cookies_for_request(self, _url: str) -> str:
        return "; ".join(f"{name}={value}" for name, value in self.cookies.items())
    
    def _store_cookies(self, response: httpx.Response, _url: str) -> None:
        self.cookies.extract_cookies(response)
    
    def destroy(self) -> None:
        self._session = None
        self.session_id = None
    
    def get_attestation_results(self) -> Optional[str]:
        if not self._session:
            return None
        try:
            return self._session.get_attestation_results()
        except Exception:
            return None
    
    def get_attestation_status(self) -> Optional[str]:
        if not self._session:
            return None
        try:
            return self._session.get_attestation_status()
        except Exception:
            return None


class SessionManager(_BaseSessionManager):
    """Async session manager for use with SubnotoClient"""
    
    def __init__(self, config: SubnotoConfig, http_client: Optional[httpx.AsyncClient] = None):
        super().__init__(config)
        self.http_client: Optional[httpx.AsyncClient] = http_client
        self._handshake_lock = asyncio.Lock()
    
    async def ensure_session(self) -> None:
        """Ensure session is established, performing handshake if needed"""
        if self._is_session_open():
            return
        async with self._handshake_lock:
            if self._is_session_open():
                return
            await self._handshake()
    
    async def _handshake(self) -> None:
        try:
            for _ in range(4):
                outgoing = self._get_next_outgoing()
                if not outgoing:
                    break
                
                url = self._handshake_url()
                headers = self._build_handshake_headers(url)
                
                if self.http_client:
                    response = await self.http_client.post(url, content=outgoing, headers=headers)
                else:
                    async with httpx.AsyncClient() as client:
                        response = await client.post(url, content=outgoing, headers=headers)
                
                self._process_handshake_response(response, url)
            
            self._finalize_handshake()
        except Exception:
            self.destroy()
            raise


class SyncSessionManager(_BaseSessionManager):
    """Sync session manager for use with SubnotoSyncClient"""
    
    def __init__(self, config: SubnotoConfig, http_client: Optional[httpx.Client] = None):
        super().__init__(config)
        self.http_client: Optional[httpx.Client] = http_client
        self._handshake_lock = threading.Lock()
    
    def ensure_session(self) -> None:
        """Ensure session is established, performing handshake if needed"""
        if self._is_session_open():
            return
        with self._handshake_lock:
            if self._is_session_open():
                return
            self._handshake()
    
    def _handshake(self) -> None:
        try:
            for _ in range(4):
                outgoing = self._get_next_outgoing()
                if not outgoing:
                    break
                
                url = self._handshake_url()
                headers = self._build_handshake_headers(url)
                
                if self.http_client:
                    response = self.http_client.post(url, content=outgoing, headers=headers)
                else:
                    with httpx.Client() as client:
                        response = client.post(url, content=outgoing, headers=headers)
                
                self._process_handshake_response(response, url)
            
            self._finalize_handshake()
        except Exception:
            self.destroy()
            raise
