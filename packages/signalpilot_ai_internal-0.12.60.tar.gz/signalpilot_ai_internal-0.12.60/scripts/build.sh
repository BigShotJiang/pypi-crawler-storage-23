#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

DO_INSTALL=false
DO_OVERWRITE=false

for arg in "$@"; do
  case "$arg" in
    --install) DO_INSTALL=true ;;
    --overwrite) DO_OVERWRITE=true ;;
    *) echo "Unknown option: $arg"; exit 1 ;;
  esac
done

cd "$PROJECT_DIR"

if [ "$DO_INSTALL" = true ]; then
  echo "Installing dependencies..."
  jlpm install
fi

echo "Building frontend (tracking disabled)..."
jlpm build:no_tracking

echo "Installing package in editable mode..."
pip install -e .

if [ "$DO_OVERWRITE" = true ]; then
  echo "Overwriting extension symlink..."
  jupyter labextension develop --overwrite .
fi

echo "Launching Jupyter Lab..."
jupyter lab --port 8888 --ip 0.0.0.0
