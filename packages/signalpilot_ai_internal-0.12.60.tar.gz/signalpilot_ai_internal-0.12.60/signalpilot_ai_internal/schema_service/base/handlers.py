"""Base handler classes for schema services."""

import json
from typing import Any, Dict, List, Optional

from jupyter_server.base.handlers import APIHandler
import tornado.web

from signalpilot_ai_internal.db_config.factory import detect_db_type
from signalpilot_ai_internal.schema_service.base.config import ConfigLoader
from signalpilot_ai_internal.schema_service.base.constants import ALLOWED_READ_STATEMENTS
from signalpilot_ai_internal.schema_service.base.package_manager import PackageManager


class BaseSchemaHandler(APIHandler):
    """Base class for all schema handlers.

    Subclasses must:
    - Set `db_type` class attribute
    - Implement `extract_schema(config)` method
    """

    db_type: str = ""  # Override in subclasses

    def _parse_request(self) -> Dict:
        """Parse and validate request body."""
        try:
            return json.loads(self.request.body.decode("utf-8"))
        except json.JSONDecodeError:
            return {}

    def _get_config(self, body: Dict) -> Optional[Dict]:
        """Get database config from request or environment."""
        # Check for config in request body
        if "config" in body:
            return body["config"]

        # Check for dbUrl in request body
        if "dbUrl" in body:
            url = body["dbUrl"]
            db_type = detect_db_type(url)
            return {"type": db_type, "connectionUrl": url}

        # Fall back to environment
        return ConfigLoader.get_config_by_type(self.db_type)

    def _handle_error(self, status: int, message: str, detail: str = "") -> None:
        """Send error response."""
        self.set_status(status)
        response = {"error": message}
        if detail:
            response["message"] = detail
        self.finish(json.dumps(response))

    @tornado.web.authenticated
    def post(self) -> None:
        """Handle POST request - template method."""
        try:
            body = self._parse_request()

            config = self._get_config(body)
            if not config:
                self._handle_error(
                    400,
                    f"No {self.db_type} configuration provided and none found in environment",
                )
                return

            # Ensure required packages are installed
            try:
                PackageManager.ensure_installed(self.db_type)
            except ImportError as e:
                self._handle_error(500, str(e))
                return

            # Extract schema - implemented by subclasses
            try:
                result = self.extract_schema(config)
                self.finish(json.dumps(result))
            except Exception as e:
                self._handle_error(500, f"Error connecting to {self.db_type}: {str(e)}")

        except Exception as e:
            self._handle_error(500, "Internal server error", str(e))

    def extract_schema(self, config: Dict) -> Dict:
        """Extract schema from database. Override in subclasses."""
        raise NotImplementedError("Subclasses must implement extract_schema()")


class BaseQueryHandler(APIHandler):
    """Base class for query execution handlers.

    Subclasses must:
    - Set `db_type` class attribute
    - Implement `execute_query(config, query)` method
    """

    db_type: str = ""  # Override in subclasses

    def _parse_request(self) -> Dict:
        """Parse and validate request body."""
        try:
            return json.loads(self.request.body.decode("utf-8"))
        except json.JSONDecodeError:
            return {}

    def _get_config(self, body: Dict) -> Optional[Dict]:
        """Get database config from request or environment."""
        if "config" in body:
            return body["config"]
        if "dbUrl" in body:
            url = body["dbUrl"]
            db_type = detect_db_type(url)
            return {"type": db_type, "connectionUrl": url}
        return ConfigLoader.get_config_by_type(self.db_type)

    def _handle_error(self, status: int, message: str, detail: str = "") -> None:
        """Send error response."""
        self.set_status(status)
        response = {"error": message}
        if detail:
            response["message"] = detail
        self.finish(json.dumps(response))

    def _validate_query(self, query: str) -> Optional[str]:
        """Validate query is read-only. Returns error message or None."""
        normalized = query.strip().upper()
        if not any(normalized.startswith(stmt) for stmt in ALLOWED_READ_STATEMENTS):
            allowed = ", ".join(ALLOWED_READ_STATEMENTS)
            return f"Only {allowed} statements are allowed for read queries."
        return None

    @tornado.web.authenticated
    def post(self) -> None:
        """Handle POST request - template method."""
        try:
            body = self._parse_request()

            query = body.get("query")
            if not query:
                self._handle_error(400, "Missing 'query' field in request body")
                return

            # Validate query is read-only
            error = self._validate_query(query)
            if error:
                self._handle_error(400, error)
                return

            config = self._get_config(body)
            if not config:
                self._handle_error(
                    400,
                    f"No {self.db_type} configuration provided and none found in environment",
                )
                return

            # Ensure required packages are installed
            try:
                PackageManager.ensure_installed(self.db_type)
            except ImportError as e:
                self._handle_error(500, str(e))
                return

            # Execute query - implemented by subclasses
            try:
                result = self.execute_query(config, query)
                # Safely convert Decimals to float or str for JSON serialization
                def convert_decimal(obj):
                    if isinstance(obj, list):
                        return [convert_decimal(item) for item in obj]
                    elif isinstance(obj, dict):
                        return {k: convert_decimal(v) for k, v in obj.items()}
                    else:
                        try:
                            import decimal
                            if isinstance(obj, decimal.Decimal):
                                # Float preferred unless loss of precision is unacceptable
                                return float(obj)
                        except ImportError:
                            pass
                        return obj

                serializable_result = convert_decimal(result)
                self.finish(json.dumps({"result": serializable_result}))
            except Exception as e:
                self._handle_error(
                    500, f"{self.db_type.title()} query failed: {str(e)}"
                )

        except Exception as e:
            self._handle_error(500, "Internal server error", str(e))

    def execute_query(self, config: Dict, query: str) -> List[Dict]:
        """Execute query and return results. Override in subclasses."""
        raise NotImplementedError("Subclasses must implement execute_query()")
