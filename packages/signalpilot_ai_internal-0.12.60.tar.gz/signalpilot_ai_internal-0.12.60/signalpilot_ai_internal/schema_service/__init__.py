"""Schema service module for database schema extraction and queries."""
