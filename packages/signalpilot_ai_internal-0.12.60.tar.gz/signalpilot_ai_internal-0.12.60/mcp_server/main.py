"""FastAPI entrypoint for MCP tools."""

from __future__ import annotations

import logging
import warnings
from pathlib import Path

# Suppress Databricks connector warnings
warnings.filterwarnings("ignore", message=".*pyarrow is not installed.*")
warnings.filterwarnings("ignore", message=".*_user_agent_entry.*deprecated.*")

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi_mcp import FastApiMCP

from namespaces.database.router import router as database_router
from namespaces.files.router import router as files_router
from namespaces.memory.router import router as memory_router
from namespaces.terminal.router import router as terminal_router

logging.basicConfig(level=logging.INFO)

# Suppress Databricks connector logging - must be after basicConfig
logging.getLogger("databricks.sql.client").setLevel(logging.ERROR)
logging.getLogger("databricks.sql.session").setLevel(logging.ERROR)
logging.getLogger("databricks").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)


def _load_dotenv() -> None:
    env_path = Path(__file__).with_name(".env")
    if env_path.exists():
        load_dotenv(env_path)
    else:
        logger.warning(".env file not found, using environment variables")


def create_app() -> FastAPI:
    _load_dotenv()
    app = FastAPI(title="SignalPilot MCP Server")

    app.include_router(terminal_router, prefix="/terminal", tags=["terminal"])
    app.include_router(
        database_router,
        prefix="/database",
        tags=["database"],
    )
    app.include_router(
        files_router,
        prefix="/files",
        tags=["files"],
    )
    app.include_router(
        memory_router,
        prefix="/memory",
        tags=["memory"],
    )

    mcp = FastApiMCP(app)
    mcp.mount_http(mount_path="/mcp")  # HTTP at /mcp
    mcp.mount_sse(mount_path="/mcp/sse")  # SSE at /mcp/sse
    return app


app = create_app()
