"""Models for memory operations."""

from typing import Optional

from pydantic import BaseModel, Field


class MemoryUpdateRequest(BaseModel):
    """Request to update project memory file."""

    action: str = Field(
        ...,
        description="Action to perform: 'append' to add content, 'replace' to overwrite, 'read' to get current content.",
    )
    content: Optional[str] = Field(
        None,
        description="Content to write (required for append/replace actions).",
    )


class MemoryUpdateResponse(BaseModel):
    """Response from memory update operation."""

    success: bool = Field(..., description="Whether the operation succeeded.")
    content: Optional[str] = Field(
        None,
        description="Current content of the memory file after operation.",
    )
    message: str = Field(..., description="Status message describing what was done.")
    error: Optional[str] = Field(None, description="Error message if operation failed.")


class ChatSearchRequest(BaseModel):
    """Request to search chat history."""

    query: str = Field(..., description="Search query (regex pattern).")
    max_results: int = Field(
        20,
        description="Maximum number of matches to return.",
        ge=1,
        le=100,
    )
    case_insensitive: bool = Field(
        True,
        description="Perform case-insensitive search.",
    )


class ChatSearchMatch(BaseModel):
    """Single chat search match."""

    file: str = Field(..., description="Path to the chat history file.")
    thread_name: str = Field(..., description="Name of the chat thread.")
    thread_id: str = Field(..., description="ID of the chat thread.")
    snippet: str = Field(..., description="Matching text snippet with context.")
    timestamp: int = Field(..., description="Thread lastUpdated timestamp (Unix ms).")


class ChatSearchResponse(BaseModel):
    """Response from chat history search."""

    matches: list[ChatSearchMatch] = Field(
        default_factory=list,
        description="List of matches found.",
    )
    count: int = Field(0, description="Total number of matches found.")
    truncated: bool = Field(
        False,
        description="True if results were truncated due to max_results limit.",
    )
    message: str = Field(..., description="Status message.")
    error: Optional[str] = Field(None, description="Error message if search failed.")
