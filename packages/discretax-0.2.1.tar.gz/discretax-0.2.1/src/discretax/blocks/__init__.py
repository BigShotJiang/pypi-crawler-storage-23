"""This module contains the blocks implemented in Discretax."""

from discretax.blocks.base import AbstractBlock
from discretax.blocks.standard import StandardBlock

__all__ = [
    "AbstractBlock",
    "StandardBlock",
]
