"""Utility functions and mixins for discretax."""

from discretax.utils.param_count import print_param_tree

__all__ = ["print_param_tree"]
