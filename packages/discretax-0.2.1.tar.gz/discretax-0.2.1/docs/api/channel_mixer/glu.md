# GLU Channel Mixer

::: discretax.channel_mixers.glu.GLU
    options:
      members:
        - __init__
        - __call__
