# Identity Channel Mixer

::: discretax.channel_mixers.identity.IdentityChannelMixer
    options:
      members:
        - __init__
        - __call__
