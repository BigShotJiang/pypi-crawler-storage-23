# MLP Channel Mixer

::: discretax.channel_mixers.mlp.MLPChannelMixer
    options:
      members:
        - __init__
        - __call__
