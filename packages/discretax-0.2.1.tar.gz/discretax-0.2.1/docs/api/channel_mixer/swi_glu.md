# SwiGLU Channel Mixer

::: discretax.channel_mixers.swi_glu.SwiGLU
    options:
      members:
        - __init__
        - __call__
