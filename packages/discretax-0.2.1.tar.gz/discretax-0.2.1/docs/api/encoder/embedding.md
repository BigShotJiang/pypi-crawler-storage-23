# Embedding Encoder

::: discretax.encoder.embedding.EmbeddingEncoder
    options:
      members:
        - __init__
        - __call__
