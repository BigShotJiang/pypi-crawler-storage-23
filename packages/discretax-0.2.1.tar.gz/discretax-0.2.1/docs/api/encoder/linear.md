# Linear Encoder

::: discretax.encoder.linear.LinearEncoder
    options:
      members:
        - __init__
        - __call__
