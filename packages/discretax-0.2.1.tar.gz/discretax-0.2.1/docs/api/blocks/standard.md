# Standard Block

::: discretax.blocks.standard.StandardBlock
    options:
        members:
            - __init__
            - __call__
