# DeltaNet Sequence Mixer

::: discretax.sequence_mixers.deltanet.DeltaNetSequenceMixer
    options:
      members:
        - __init__
        - __call__
