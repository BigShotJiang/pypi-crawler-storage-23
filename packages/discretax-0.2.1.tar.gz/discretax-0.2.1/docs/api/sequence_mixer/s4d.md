# S4D Sequence Mixer

::: discretax.sequence_mixers.s4d.S4DSequenceMixer
    options:
      members:
        - __init__
        - __call__
