# Identity Sequence Mixer

::: discretax.sequence_mixers.identity.IdentitySequenceMixer
    options:
      members:
        - __init__
        - __call__
