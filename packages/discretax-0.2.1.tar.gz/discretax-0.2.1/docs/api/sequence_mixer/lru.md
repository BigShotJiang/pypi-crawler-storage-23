# LRU Sequence Mixer

::: discretax.sequence_mixers.lru.LRUSequenceMixer
    options:
      members:
        - __init__
        - __call__
