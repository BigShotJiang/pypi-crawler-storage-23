# LinOSS Sequence Mixer

::: discretax.sequence_mixers.linoss.LinOSSSequenceMixer
    options:
        members:
            - __init__
            - __call__
