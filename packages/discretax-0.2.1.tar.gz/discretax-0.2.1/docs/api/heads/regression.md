# Regression Head

::: discretax.heads.regression.RegressionHead
    options:
      members:
        - __init__
        - __call__
