# Classification Head

::: discretax.heads.classification.ClassificationHead
    options:
      members:
        - __init__
        - __call__
