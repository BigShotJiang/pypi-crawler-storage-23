# Channel Mixer


::: discretax.channel_mixers.base.AbstractChannelMixer
    options:
        members:
            - __init__
            - __call__
