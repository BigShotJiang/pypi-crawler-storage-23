# Sequence Mixer


::: discretax.sequence_mixers.base.AbstractSequenceMixer
    options:
        members:
            - __init__
            - __call__
