# Blocks


::: discretax.blocks.base.AbstractBlock
    options:
        members:
            - __init__
            - __call__
