# Encoder


::: discretax.encoder.base.AbstractEncoder
    options:
        members:
            - __init__
            - __call__
