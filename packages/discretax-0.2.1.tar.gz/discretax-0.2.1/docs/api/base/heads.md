# Heads

::: discretax.heads.base.AbstractHead
    options:
        members:
            - __init__
            - __call__
