# DeltaNet Model

::: discretax.models.deltanet.DeltaNet
    options:
      members:
        - __init__
        - __call__
