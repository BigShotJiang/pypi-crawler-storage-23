# LinOSS Model

::: discretax.models.linoss.LinOSS
    options:
      members:
        - __init__
        - __call__
