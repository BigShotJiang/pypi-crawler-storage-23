Those static files are taken from [equinox](https://github.com/patrick-kidger/equinox/tree/main).
