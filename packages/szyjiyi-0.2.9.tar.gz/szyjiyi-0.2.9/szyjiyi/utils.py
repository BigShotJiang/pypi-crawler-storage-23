from datetime import datetime

MAX_CONTENT_LENGTH = 50000
MAX_TAGS_COUNT = 20
MAX_TAG_LENGTH = 50
MAX_TITLE_LENGTH = 200


def now_iso() -> str:
    """返回当前时间的 ISO 格式字符串（带时区）"""
    return datetime.now().astimezone().isoformat()


def validate_content(content: str) -> str:
    if not content or not isinstance(content, str):
        raise ValueError("content is required and must be a string")
    if len(content) > MAX_CONTENT_LENGTH:
        raise ValueError(f"content exceeds {MAX_CONTENT_LENGTH} chars")
    return content


def validate_tags(tags: list[str]) -> list[str]:
    if not isinstance(tags, list):
        raise ValueError("tags must be a list")
    if len(tags) > MAX_TAGS_COUNT:
        raise ValueError(f"tags count exceeds {MAX_TAGS_COUNT}")
    validated = []
    for t in tags:
        if not isinstance(t, str):
            raise ValueError("each tag must be a string")
        t = t.strip()
        if not t:
            continue
        if len(t) > MAX_TAG_LENGTH:
            raise ValueError(f"tag '{t}' exceeds {MAX_TAG_LENGTH} chars")
        validated.append(t)
    return validated


def validate_title(title: str) -> str:
    if not title or not isinstance(title, str):
        raise ValueError("title is required and must be a string")
    if len(title) > MAX_TITLE_LENGTH:
        raise ValueError(f"title exceeds {MAX_TITLE_LENGTH} chars")
    return title
