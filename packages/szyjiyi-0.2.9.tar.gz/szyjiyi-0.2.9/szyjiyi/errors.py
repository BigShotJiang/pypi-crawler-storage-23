def error_response(error: str, details: str = "") -> dict:
    return {"success": False, "error": error, "details": details}

def success_response(**kwargs) -> dict:
    return {"success": True, **kwargs}

class szyjiyiError(Exception):
    def __init__(self, error: str, details: str = ""):
        self.error = error
        self.details = details
        super().__init__(error)


class NotFoundError(szyjiyiError):
    def __init__(self, resource_type: str, resource_id: str | int):
        super().__init__(f"{resource_type} not found", f"ID: {resource_id}")
        self.resource_type = resource_type
        self.resource_id = resource_id
