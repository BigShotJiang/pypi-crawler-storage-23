# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

# project_root/
# ├── pyproject.toml
# ├── README.md
# ├── LICENSE
# ├── .gitignore
# ├── actions/
# │   ├── __init__.py
# │   ├── utils/
# │   │   ├── __init__.py
# │   │   ├── github_utils.py
# │   │   ├── openai_utils.py
# │   │   └── common_utils.py
# │   ├── dispatch_actions.py
# │   ├── first_interaction.py
# │   ├── review_pr.py
# │   ├── scan_prs.py
# │   ├── summarize_pr.py
# │   ├── summarize_release.py
# │   ├── format_python_docstrings.py
# │   ├── update_file_headers.py
# │   └── update_markdown_code_blocks.py
# └── tests/
#     ├── __init__.py
#     ├── test_first_interaction.py
#     ├── test_summarize_pr.py
#     └── ...

__version__ = "0.2.13"
