import urllib.parse


def main():
    print("🔗 LinkerZap\n")

    ddi = input("DDI (ex: 55): ").strip()
    ddd = input("DDD (ex: 51): ").strip()
    numero = input("Número (somente números): ").strip()
    mensagem = input("Mensagem: ").strip()

    numero_completo = f"{ddi}{ddd}{numero}"
    mensagem_codificada = urllib.parse.quote(mensagem)

    link = f"https://wa.me/{numero_completo}?text={mensagem_codificada}"

    print("\n" + link)


if __name__ == "__main__":
    main()
