# LinkerZap

Ferramenta CLI para gerar links inteligentes para WhatsApp.

## Uso

```bash
linkerzap
