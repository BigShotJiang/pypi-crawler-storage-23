# -*- encoding: utf-8 -*-
__all__ = (
    'PropertyEntry',
    'UserProfileProperties',
    'PlayerProfileProperties',
    'TextureInfo',
    'ClassifiedTextures',
    'UserProfile',
    'PlayerProfile',
    'AvailablePlayerProfiles'
)

from typing import TypeAlias
from uuid import UUID as UUIDType

import attrs


@attrs.define(kw_only=True, slots=True)
class PropertyEntry:
    name: str
    value: str
    signature: str | None = None


UserProfileProperties: TypeAlias = list[PropertyEntry]
PlayerProfileProperties: TypeAlias = list[PropertyEntry]


@attrs.define(kw_only=True, slots=True)
class TextureInfo:
    url: str
    metadata: dict[str, str] = attrs.Factory(dict[str, str])


@attrs.define(kw_only=True, slots=True)
class ClassifiedTextures:
    SKIN: TextureInfo | None = None
    CAPE: TextureInfo | None = None


@attrs.define(kw_only=True, slots=True)
class UserProfile:
    id: UUIDType
    properties: UserProfileProperties = attrs.Factory(UserProfileProperties)


@attrs.define(kw_only=True, slots=True)
class PlayerProfile:
    id: UUIDType
    name: str
    properties: PlayerProfileProperties = attrs.Factory(PlayerProfileProperties)


AvailablePlayerProfiles: TypeAlias = list[PlayerProfile]
