# -*- encoding: utf-8 -*-
__all__ = (
    'VersionManifest',
    'nodes'
)

from collections.abc import Callable
from collections.abc import Iterable
from collections.abc import Iterator
from collections.abc import MutableSequence

import attrs
from typing_extensions import Any
from typing_extensions import overload
from typing_extensions import override

from mcschemas.models.enums import VersionType
from mcschemas.models.versionmanifest import nodes
from mcschemas.models.versionmanifest.nodes import VersionEntry


@attrs.define(kw_only=True, slots=True)
class VersionManifest(MutableSequence[nodes.VersionEntry]):
    latest: nodes.LatestReleaseTypeOfVersion
    """The ID of latest release and snapshot versions."""
    versions: list[nodes.VersionEntry]
    """A list of versions available."""

    @override
    def insert(self, index: int, version_entry: nodes.VersionEntry, /) -> None:  # pyright: ignore[reportIncompatibleMethodOverride]
        self.versions.insert(index, version_entry)

    @override
    def __len__(self) -> int:
        return len(self.versions)

    @overload
    def __getitem__(self, index: int, /) -> VersionEntry:
        ...

    @overload
    def __getitem__(self, slice_: slice, /) -> list[VersionEntry]:
        ...

    @overload
    def __getitem__(self, version_id: str, /) -> VersionEntry:
        ...

    @override
    def __getitem__(self, query: int | slice | str, /) -> Any:  # pyright: ignore[reportIncompatibleMethodOverride]
        if isinstance(query, str):
            for version in self.versions:
                if version.id == query:
                    return version
            else:
                raise KeyError(query)

        return self.versions[query]

    @overload
    def __setitem__(self, index: int, version_entry: VersionEntry, /) -> None:
        ...

    @overload
    def __setitem__(self, slice_: slice, version_entries: Iterable[VersionEntry], /) -> None:
        ...

    @override
    def __setitem__(self, query: int | slice, objs: Any, /) -> None:  # pyright: ignore[reportIncompatibleMethodOverride]
        self.versions[query] = objs

    @overload
    def __delitem__(self, index: int, /) -> None:
        ...

    @overload
    def __delitem__(self, slice_: slice, /) -> None:
        ...

    @override
    def __delitem__(self, query: int | slice, /) -> None:  # pyright: ignore[reportIncompatibleMethodOverride]
        del self.versions[query]

    @staticmethod
    def _versionTypeFilterPredicateFactory(type: VersionType | str, /) -> Callable[[VersionEntry], bool]:
        type = VersionType(type)

        def predicate(version_entry: VersionEntry, /) -> bool:
            return version_entry.type == type

        return predicate

    @staticmethod
    def _versionIdFilterPredicateFactory(keyword: str, /) -> Callable[[VersionEntry], bool]:
        keyword = keyword.lower()

        def predicate(version_entry: VersionEntry, /) -> bool:
            return keyword in version_entry.id.lower()

        return predicate

    def filterVersions(self, *, type: VersionType | str | None = None, keyword: str = '') -> Iterator[VersionEntry]:
        if not type:
            if keyword:
                return filter(self._versionIdFilterPredicateFactory(keyword), self)
            return iter(self)
        else:
            type_filter = filter(self._versionTypeFilterPredicateFactory(type), self)

        if keyword:
            return filter(self._versionIdFilterPredicateFactory(keyword), type_filter)
        return type_filter
