from __future__ import annotations

from dissect.database.bsd.db import DB

__all__ = ["DB"]
