import numpy as np
from XZGUtil.ImagePositioning import window_rectangle
from rapidocr import RapidOCR

# 全局初始化引擎（避免重复创建）
engine = RapidOCR()


def ocr_endpoint(win, word=None):
    """
    对截图进行OCR识别（适配新版RapidOCR的RapidOCROutput返回格式）
    先精确匹配目标词，无结果则模糊匹配（包含该词），返回结果为屏幕绝对坐标（新增中心点）
    :param win: 窗口对象（需包含rectangle()方法，返回带left/top属性的矩形对象）
    :param screenshot: 输入截图（numpy数组，HWC/RGB格式）
    :param word: 要匹配的目标词
    :return: 匹配结果列表（元素包含text/scores/box/center，均为屏幕绝对坐标）
    """
    screenshot = window_rectangle(win)
    # 获取窗口的屏幕坐标矩形（返回带left/top属性的对象，如pywin32的RECT）
    window_rect = win.rectangle()
    # 解析窗口左上角的屏幕坐标（属性式调用，与你的示例对齐）
    win_left = window_rect.left  # 窗口左上角X（屏幕坐标）
    win_top = window_rect.top    # 窗口左上角Y（屏幕坐标）

    # 1. 输入校验
    if not isinstance(screenshot, np.ndarray):
        raise ValueError("screenshot必须是numpy数组！")
    if screenshot.ndim != 3 or screenshot.shape[2] not in (3, 4):
        raise ValueError("screenshot必须是HWC格式的RGB/RGBA数组！")

    # 2. 处理截图：RGBA转RGB（丢弃Alpha通道）
    img_np = screenshot[:, :, :3]

    # 3. 执行OCR（新版返回RapidOCROutput对象，无法解包）
    ocr_result_obj = engine(img_np)

    # 4. 从RapidOCROutput对象中提取核心数据
    if not hasattr(ocr_result_obj, 'boxes') or len(ocr_result_obj.boxes) == 0:
        return []  # 无识别结果直接返回空

    # 5. 初始化匹配结果列表
    exact_match = []  # 精确匹配
    fuzzy_match = []  # 模糊匹配（包含目标词）

    # 6. 遍历OCR结果（按boxes/txts/scores一一对应）
    for box, text, score in zip(ocr_result_obj.boxes, ocr_result_obj.txts, ocr_result_obj.scores):
        # 规范化文本（去空格、转字符串）
        text_str = str(text).strip()
        # 规范化坐标（转为普通列表，兼容tensor/numpy数组）
        box_list = box.tolist() if hasattr(box, 'tolist') else box
        # 规范化置信度（转为float，避免numpy类型）
        score_float = float(score)

        # ========== 核心修改：按你的示例逻辑转换为屏幕绝对坐标 ==========
        screen_box = []
        for (x, y) in box_list:
            # 转换为整数（像素级坐标）+ 窗口偏移，与你的示例对齐
            screen_x = int(x) + win_left
            screen_y = int(y) + win_top
            screen_box.append([screen_x, screen_y])

        # 计算屏幕绝对坐标的中心点（整数除法，与你的示例逻辑一致）
        # box格式：[[x1,y1],[x2,y2],[x3,y3],[x4,y4]] → x1=左上角X, y1=左上角Y；x3=右下角X, y3=右下角Y
        x1, y1 = screen_box[0]
        x3, y3 = screen_box[2]
        w = x3 - x1  # 矩形宽度
        h = y3 - y1  # 矩形高度
        center_x = x1 + w // 2  # 中心点X（屏幕绝对坐标）
        center_y = y1 + h // 2  # 中心点Y（屏幕绝对坐标）
        screen_center = [center_x, center_y]

        # 构建结果字典（坐标均为屏幕绝对坐标，整数格式）
        result_item = {
            'text': text_str,
            'scores': score_float,
            'box': screen_box,       # 屏幕绝对坐标的矩形框（整数）
            'center': screen_center  # 屏幕绝对坐标的中心点（整数）
        }

        # 优先精确匹配
        if text_str == word:
            exact_match.append(result_item)
        elif word == None:
            exact_match.append(result_item)

    # 7. 有精确匹配返回精确，否则返回模糊
    return exact_match
