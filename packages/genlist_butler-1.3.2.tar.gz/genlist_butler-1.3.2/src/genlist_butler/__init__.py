"""GenList Butler - HTML music catalog generator"""

__version__ = "1.3.2"
