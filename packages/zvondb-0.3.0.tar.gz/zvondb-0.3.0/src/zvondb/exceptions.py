class RegistryError(Exception):
    """Base exception for SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


class NotFoundError(RegistryError):
    pass


class ConflictError(RegistryError):
    pass


class AuthenticationError(RegistryError):
    pass


class ArtifactResolutionError(RegistryError):
    pass
