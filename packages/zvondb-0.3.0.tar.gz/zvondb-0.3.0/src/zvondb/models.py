from datetime import datetime
from typing import Any

from pydantic import BaseModel


class ProjectInfo(BaseModel):
    id: str
    name: str
    storage_backends: dict[str, str] = {}
    wandb_api_key: str | None = None
    wandb_entity: str | None = None
    created_at: datetime
    updated_at: datetime


class ExperimentInfo(BaseModel):
    id: str
    name: str
    parent_name: str | None = None
    description: str | None = None
    created_at: datetime
    updated_at: datetime


class ArtifactInfo(BaseModel):
    id: str
    name: str
    version: int
    path: str
    storage_name: str | None = None
    description: str = ""
    metadata: dict[str, Any] = {}
    tags: list[str] = []
    produced_by_id: str
    experiment_name: str
    created_at: datetime


class JobInfo(BaseModel):
    id: str
    name: str
    experiment_name: str
    git_sha: str
    status: str
    metadata: dict[str, Any] = {}
    started_at: datetime
    completed_at: datetime | None = None
    failure_reason: str | None = None
    tracking_url: str | None = None
    created_by: str | None = None


class JobDetailInfo(JobInfo):
    inputs: list[ArtifactInfo] = []
    outputs: list[ArtifactInfo] = []
