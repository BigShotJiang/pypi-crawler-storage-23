"""Evaluation framework for Harness agent benchmarking."""
