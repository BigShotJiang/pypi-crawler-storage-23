"""Synthetic datasets for agent-eval benchmarks."""
