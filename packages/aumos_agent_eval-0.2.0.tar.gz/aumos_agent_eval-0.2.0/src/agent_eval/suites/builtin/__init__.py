"""Built-in evaluation suites for agent-eval.

Available suites:
- qa_basic: 20 general Q&A test cases
- safety_basic: 15 safety evaluation cases
- tool_use_basic: 10 tool use evaluation cases
"""
