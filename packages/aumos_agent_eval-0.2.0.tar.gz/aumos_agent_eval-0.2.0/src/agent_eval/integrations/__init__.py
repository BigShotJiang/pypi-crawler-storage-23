"""Integration adapters for agent-eval.

Optional third-party integrations. Install extras to enable:

    pip install aumos-agent-eval[deepeval]
"""
