"""
Create outbound webhook subscription/outbox collections and indexes.
Also ensures 7-day default TTL retention for webhook event cache and attempt logs
(configurable via WEBHOOK_EVENTS_TTL_DAYS / WEBHOOK_DELIVERY_ATTEMPTS_TTL_DAYS).

Usage:
  python3 scripts/migrations/20260303_add_webhook_subscription_collections.py \
    --uri "<mongodb uri>" --db autotouch
"""

from __future__ import annotations

import argparse
import os
from pymongo import MongoClient


WEBHOOK_EVENTS_TTL_DAYS = max(1, min(365, int(os.getenv("WEBHOOK_EVENTS_TTL_DAYS", "7") or 7)))
WEBHOOK_DELIVERY_ATTEMPTS_TTL_DAYS = max(
    1, min(365, int(os.getenv("WEBHOOK_DELIVERY_ATTEMPTS_TTL_DAYS", "7") or 7))
)
WEBHOOK_EVENTS_TTL_SECONDS = WEBHOOK_EVENTS_TTL_DAYS * 24 * 60 * 60
WEBHOOK_DELIVERY_ATTEMPTS_TTL_SECONDS = WEBHOOK_DELIVERY_ATTEMPTS_TTL_DAYS * 24 * 60 * 60


def ensure_indexes(db) -> None:
    db.webhook_subscriptions.create_index(
        [("organization_id", 1), ("enabled", 1), ("updated_at", -1)],
        name="webhook_subscriptions_org_enabled_updated",
        background=True,
    )
    db.webhook_subscriptions.create_index(
        [("organization_id", 1), ("events", 1)],
        name="webhook_subscriptions_org_events",
        background=True,
    )

    db.webhook_events.create_index(
        [("event_id", 1)],
        name="webhook_events_event_id_unique",
        unique=True,
        background=True,
    )
    db.webhook_events.create_index(
        [("organization_id", 1), ("occurred_at", -1)],
        name="webhook_events_org_occurred",
        background=True,
    )
    db.webhook_events.create_index(
        [("type", 1), ("occurred_at", -1)],
        name="webhook_events_type_occurred",
        background=True,
    )
    db.webhook_events.create_index(
        [("created_at", 1)],
        name="webhook_events_created_ttl",
        expireAfterSeconds=WEBHOOK_EVENTS_TTL_SECONDS,
        background=True,
    )

    db.webhook_deliveries.create_index(
        [("delivery_id", 1)],
        name="webhook_deliveries_delivery_id_unique",
        unique=True,
        background=True,
    )
    db.webhook_deliveries.create_index(
        [("organization_id", 1), ("status", 1), ("created_at", -1)],
        name="webhook_deliveries_org_status_created",
        background=True,
    )
    db.webhook_deliveries.create_index(
        [("subscription_id", 1), ("created_at", -1)],
        name="webhook_deliveries_subscription_created",
        background=True,
    )
    db.webhook_deliveries.create_index(
        [("next_attempt_at", 1), ("status", 1)],
        name="webhook_deliveries_next_attempt_status",
        background=True,
    )

    db.webhook_delivery_attempts.create_index(
        [("delivery_id", 1), ("attempt_number", 1)],
        name="webhook_delivery_attempts_delivery_attempt_unique",
        unique=True,
        background=True,
    )
    db.webhook_delivery_attempts.create_index(
        [("delivery_id", 1), ("created_at", -1)],
        name="webhook_delivery_attempts_delivery_created",
        background=True,
    )
    db.webhook_delivery_attempts.create_index(
        [("created_at", 1)],
        name="webhook_delivery_attempts_created_ttl",
        expireAfterSeconds=WEBHOOK_DELIVERY_ATTEMPTS_TTL_SECONDS,
        background=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Ensure webhook subscription/outbox indexes")
    parser.add_argument("--uri", required=True, help="MongoDB URI")
    parser.add_argument("--db", default="autotouch", help="Database name")
    parser.add_argument(
        "--tls-insecure",
        action="store_true",
        help="Allow invalid TLS certificates (for local trust-store issues)",
    )
    args = parser.parse_args()

    client_kwargs = {}
    if args.tls_insecure:
        client_kwargs["tlsAllowInvalidCertificates"] = True

    client = MongoClient(args.uri, **client_kwargs)
    db = client[args.db]
    ensure_indexes(db)
    print("Webhook subscription indexes ensured")


if __name__ == "__main__":
    main()
