"""Entry point for 'python -m line_solver' invocation."""

from line_solver.cli import main

if __name__ == '__main__':
    main()
