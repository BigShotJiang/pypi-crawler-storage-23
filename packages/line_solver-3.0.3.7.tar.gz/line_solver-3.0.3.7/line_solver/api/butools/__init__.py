"""
BuTools is a Python library for queueing and traffic modelling.
"""
version = "2.0"
verbose = False
checkInput = True
checkPrecision = 1e-12;