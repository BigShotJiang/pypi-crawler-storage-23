r'''
# `snowflake_stage_external_gcs`

Refer to the Terraform Registry for docs: [`snowflake_stage_external_gcs`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class StageExternalGcs(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcs",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs snowflake_stage_external_gcs}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        storage_integration: builtins.str,
        url: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        directory: typing.Optional[typing.Union["StageExternalGcsDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageExternalGcsEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageExternalGcsFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageExternalGcsTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs snowflake_stage_external_gcs} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#database StageExternalGcs#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#name StageExternalGcs#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#schema StageExternalGcs#schema}
        :param storage_integration: Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. GCS stages require a storage integration. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#storage_integration StageExternalGcs#storage_integration}
        :param url: Specifies the URL for the GCS bucket (e.g., 'gcs://bucket/path/'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#url StageExternalGcs#url}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#comment StageExternalGcs#comment}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#directory StageExternalGcs#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encryption StageExternalGcs#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_format StageExternalGcs#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#id StageExternalGcs#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timeouts StageExternalGcs#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5991eee0e9bdc1666e453571458f4dc9872b1b0c15be87e94d125dcce212c91)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = StageExternalGcsConfig(
            database=database,
            name=name,
            schema=schema,
            storage_integration=storage_integration,
            url=url,
            comment=comment,
            directory=directory,
            encryption=encryption,
            file_format=file_format,
            id=id,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a StageExternalGcs resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the StageExternalGcs to import.
        :param import_from_id: The id of the existing StageExternalGcs that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the StageExternalGcs to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__978f0d37f144e9b58c8c3902a53248f44c10b82e9a0e6b702e889a29f7dd9cb9)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putDirectory")
    def put_directory(
        self,
        *,
        enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        auto_refresh: typing.Optional[builtins.str] = None,
        notification_integration: typing.Optional[builtins.str] = None,
        refresh_on_create: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the external stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable StageExternalGcs#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#auto_refresh StageExternalGcs#auto_refresh}
        :param notification_integration: Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#notification_integration StageExternalGcs#notification_integration}
        :param refresh_on_create: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#refresh_on_create StageExternalGcs#refresh_on_create}
        '''
        value = StageExternalGcsDirectory(
            enable=enable,
            auto_refresh=auto_refresh,
            notification_integration=notification_integration,
            refresh_on_create=refresh_on_create,
        )

        return typing.cast(None, jsii.invoke(self, "putDirectory", [value]))

    @jsii.member(jsii_name="putEncryption")
    def put_encryption(
        self,
        *,
        gcs_sse_kms: typing.Optional[typing.Union["StageExternalGcsEncryptionGcsSseKms", typing.Dict[builtins.str, typing.Any]]] = None,
        none: typing.Optional[typing.Union["StageExternalGcsEncryptionNone", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param gcs_sse_kms: gcs_sse_kms block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#gcs_sse_kms StageExternalGcs#gcs_sse_kms}
        :param none: none block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#none StageExternalGcs#none}
        '''
        value = StageExternalGcsEncryption(gcs_sse_kms=gcs_sse_kms, none=none)

        return typing.cast(None, jsii.invoke(self, "putEncryption", [value]))

    @jsii.member(jsii_name="putFileFormat")
    def put_file_format(
        self,
        *,
        avro: typing.Optional[typing.Union["StageExternalGcsFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageExternalGcsFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageExternalGcsFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageExternalGcsFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageExternalGcsFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageExternalGcsFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#avro StageExternalGcs#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#csv StageExternalGcs#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#format_name StageExternalGcs#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#json StageExternalGcs#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#orc StageExternalGcs#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parquet StageExternalGcs#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#xml StageExternalGcs#xml}
        '''
        value = StageExternalGcsFileFormat(
            avro=avro,
            csv=csv,
            format_name=format_name,
            json=json,
            orc=orc,
            parquet=parquet,
            xml=xml,
        )

        return typing.cast(None, jsii.invoke(self, "putFileFormat", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#create StageExternalGcs#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#delete StageExternalGcs#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#read StageExternalGcs#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#update StageExternalGcs#update}.
        '''
        value = StageExternalGcsTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetDirectory")
    def reset_directory(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDirectory", []))

    @jsii.member(jsii_name="resetEncryption")
    def reset_encryption(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncryption", []))

    @jsii.member(jsii_name="resetFileFormat")
    def reset_file_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileFormat", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="cloud")
    def cloud(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cloud"))

    @builtins.property
    @jsii.member(jsii_name="describeOutput")
    def describe_output(self) -> "StageExternalGcsDescribeOutputList":
        return typing.cast("StageExternalGcsDescribeOutputList", jsii.get(self, "describeOutput"))

    @builtins.property
    @jsii.member(jsii_name="directory")
    def directory(self) -> "StageExternalGcsDirectoryOutputReference":
        return typing.cast("StageExternalGcsDirectoryOutputReference", jsii.get(self, "directory"))

    @builtins.property
    @jsii.member(jsii_name="encryption")
    def encryption(self) -> "StageExternalGcsEncryptionOutputReference":
        return typing.cast("StageExternalGcsEncryptionOutputReference", jsii.get(self, "encryption"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> "StageExternalGcsFileFormatOutputReference":
        return typing.cast("StageExternalGcsFileFormatOutputReference", jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="fullyQualifiedName")
    def fully_qualified_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullyQualifiedName"))

    @builtins.property
    @jsii.member(jsii_name="showOutput")
    def show_output(self) -> "StageExternalGcsShowOutputList":
        return typing.cast("StageExternalGcsShowOutputList", jsii.get(self, "showOutput"))

    @builtins.property
    @jsii.member(jsii_name="stageType")
    def stage_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stageType"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "StageExternalGcsTimeoutsOutputReference":
        return typing.cast("StageExternalGcsTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="directoryInput")
    def directory_input(self) -> typing.Optional["StageExternalGcsDirectory"]:
        return typing.cast(typing.Optional["StageExternalGcsDirectory"], jsii.get(self, "directoryInput"))

    @builtins.property
    @jsii.member(jsii_name="encryptionInput")
    def encryption_input(self) -> typing.Optional["StageExternalGcsEncryption"]:
        return typing.cast(typing.Optional["StageExternalGcsEncryption"], jsii.get(self, "encryptionInput"))

    @builtins.property
    @jsii.member(jsii_name="fileFormatInput")
    def file_format_input(self) -> typing.Optional["StageExternalGcsFileFormat"]:
        return typing.cast(typing.Optional["StageExternalGcsFileFormat"], jsii.get(self, "fileFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="storageIntegrationInput")
    def storage_integration_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "storageIntegrationInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "StageExternalGcsTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "StageExternalGcsTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="urlInput")
    def url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "urlInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a09f0759ed5e19bb2343604f5cdc76953cf3324fccc93ef290bd3a7358858bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__964debd55c0a35dfdc7fe8d1df6f9f7b5193d9209729327ffdb0783232eb7aa2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99d73467c8b0100ecdf5c00d9ce97636bc0afff7c5a8dcbd38a27b8430a70907)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79c63b667123073d5275524e9fc350fbc57cc284310eed0c1678d7a109ec86e2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdcaf39ca19638e60a8d2e5561bfc548b9e357bd5d0f17497f8bd5933cb1b390)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="storageIntegration")
    def storage_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "storageIntegration"))

    @storage_integration.setter
    def storage_integration(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__19f56659ccd75a25dfe3b26b0aa556270e3b4f7e5cfa6185f794d5b3afb1dd2b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "storageIntegration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @url.setter
    def url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9672c4b17add3b829828df4e333df5a48a68bd4adb0891327f0f338122e92bcd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "url", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "database": "database",
        "name": "name",
        "schema": "schema",
        "storage_integration": "storageIntegration",
        "url": "url",
        "comment": "comment",
        "directory": "directory",
        "encryption": "encryption",
        "file_format": "fileFormat",
        "id": "id",
        "timeouts": "timeouts",
    },
)
class StageExternalGcsConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        storage_integration: builtins.str,
        url: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        directory: typing.Optional[typing.Union["StageExternalGcsDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageExternalGcsEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageExternalGcsFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageExternalGcsTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#database StageExternalGcs#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#name StageExternalGcs#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#schema StageExternalGcs#schema}
        :param storage_integration: Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. GCS stages require a storage integration. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#storage_integration StageExternalGcs#storage_integration}
        :param url: Specifies the URL for the GCS bucket (e.g., 'gcs://bucket/path/'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#url StageExternalGcs#url}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#comment StageExternalGcs#comment}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#directory StageExternalGcs#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encryption StageExternalGcs#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_format StageExternalGcs#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#id StageExternalGcs#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timeouts StageExternalGcs#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(directory, dict):
            directory = StageExternalGcsDirectory(**directory)
        if isinstance(encryption, dict):
            encryption = StageExternalGcsEncryption(**encryption)
        if isinstance(file_format, dict):
            file_format = StageExternalGcsFileFormat(**file_format)
        if isinstance(timeouts, dict):
            timeouts = StageExternalGcsTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__177ea2f64a584c2d8fdc40a4ed5a7a3e3cdc8b5c8baf2f4faecef098bf46da53)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument storage_integration", value=storage_integration, expected_type=type_hints["storage_integration"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument directory", value=directory, expected_type=type_hints["directory"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument file_format", value=file_format, expected_type=type_hints["file_format"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "database": database,
            "name": name,
            "schema": schema,
            "storage_integration": storage_integration,
            "url": url,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if comment is not None:
            self._values["comment"] = comment
        if directory is not None:
            self._values["directory"] = directory
        if encryption is not None:
            self._values["encryption"] = encryption
        if file_format is not None:
            self._values["file_format"] = file_format
        if id is not None:
            self._values["id"] = id
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def database(self) -> builtins.str:
        '''The database in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#database StageExternalGcs#database}
        '''
        result = self._values.get("database")
        assert result is not None, "Required property 'database' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Specifies the identifier for the stage;

        must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#name StageExternalGcs#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> builtins.str:
        '''The schema in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#schema StageExternalGcs#schema}
        '''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def storage_integration(self) -> builtins.str:
        '''Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity.

        GCS stages require a storage integration. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#storage_integration StageExternalGcs#storage_integration}
        '''
        result = self._values.get("storage_integration")
        assert result is not None, "Required property 'storage_integration' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def url(self) -> builtins.str:
        '''Specifies the URL for the GCS bucket (e.g., 'gcs://bucket/path/').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#url StageExternalGcs#url}
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#comment StageExternalGcs#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def directory(self) -> typing.Optional["StageExternalGcsDirectory"]:
        '''directory block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#directory StageExternalGcs#directory}
        '''
        result = self._values.get("directory")
        return typing.cast(typing.Optional["StageExternalGcsDirectory"], result)

    @builtins.property
    def encryption(self) -> typing.Optional["StageExternalGcsEncryption"]:
        '''encryption block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encryption StageExternalGcs#encryption}
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["StageExternalGcsEncryption"], result)

    @builtins.property
    def file_format(self) -> typing.Optional["StageExternalGcsFileFormat"]:
        '''file_format block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_format StageExternalGcs#file_format}
        '''
        result = self._values.get("file_format")
        return typing.cast(typing.Optional["StageExternalGcsFileFormat"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#id StageExternalGcs#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["StageExternalGcsTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timeouts StageExternalGcs#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["StageExternalGcsTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputDirectoryTable",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputDirectoryTable:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputDirectoryTable(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputDirectoryTableList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputDirectoryTableList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64b41f4574687624d3aa440df8968df14efbf1df8857aaa3630502c4de3c133d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputDirectoryTableOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0619ace4c8518160dd885e1763d6011021525a1605cb7a72bac5b7956827e194)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputDirectoryTableOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86103c95fc924700c7260190c8fbec77948dc7f29d4b548e483ff89388fe5941)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__666a43a51d26e22ba66301b6af75d6ee77ce3bd0fa386e751308776b2821b254)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eca58aa13716890cca87c14e39f132a6e01fa1449052cdb97811832ef9b73b95)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputDirectoryTableOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputDirectoryTableOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c487175b39aa45bf972d7477e0297e14b1c79f70175dd45d42baaaa9af151151)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "autoRefresh"))

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enable"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputDirectoryTable]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputDirectoryTable], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputDirectoryTable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79d6b83816957847c45d02702cca53a9589af9c899e3c9234c2bed2e9da6eda2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormat",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormat:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatAvro:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatAvroList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatAvroList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__800347b1ca4e941deff7610bfb3dd0a276cb7130f03d1b0f6697135711b71141)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatAvroOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46bdb26b1a19ee86151a0d5291d60a5c3d7c751f521c64b2e6ea17ae07f6aadf)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatAvroOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebb79f7a0bdbf5d954fa08096617d9d7dbf74bc7e12cb685e65ae9a135c72810)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a701c05db718266c7f95c97a21214169b310ad54702a9437b3fdb51254dcee9a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7650b9a68f8852a7f8d2f3b2c1d6448c1c7edfcdf04fedeb1d4bf6a7c4a19af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96684c5cc9cb3981da15d3454bd2c043ed122a07fc0fb2351c78ba368dc4a060)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatAvro], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatAvro],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e1d772fb4a51313119c1d4bb0de4b93fdab8e0e756ec826422f778bb8bfdbf27)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatCsv:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatCsvList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatCsvList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f468d5c1638a39ea4a0d79dff9c3e97fd11e195132765cf41b66c23b463fc54)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatCsvOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc2eb6da3a31a555de7518bae9193bebe8db38020a4d99d0a669cb8c6d824c99)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatCsvOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d06c70b8deda293175cc2dc6f22b89c1ab5cf9c4409c4b760ba47b4f22925e96)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7949fd4a196081a63c1f572fd9b73df1c71560722d20cba8a5fb99d42f744e9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb28abafdab1c47b6ef260d643c0e9eef6aa149edc3763959fd6e72fd8dbc9b2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99c00180e7bf5ed9a27f5c564fbd3b01b72952dd91aa8b4209588e750271f681)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "emptyFieldAsNull"))

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "errorOnColumnCountMismatch"))

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "parseHeader"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipBlankLines"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="validateUtf8")
    def validate_utf8(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "validateUtf8"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatCsv], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatCsv],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fcc9a246ebbf46b1a8f9d86468afd620fa0bc0c9a5110fe870b39d66cea8f248)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatJson:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatJsonList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatJsonList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51051df427d277f03262728503edd81bac27d944f282f6284b615e03812c6fc0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatJsonOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36c31dfb09226a647b5207d7861f90b05ec7c94345caa48c8ba00489b2917fac)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatJsonOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__428e132065c82e93f02e4237cc47b7facec0a8fd468e029e67ef5919d8018714)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__479799f37ffb5ced338053c1640b984f7f5bffd25e54f8947752c4dab96dd0f4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5e016048bc61158bc92eb10be78a196e77cb86734d44ec631444acee1281801)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5544a44611341ce3e849a46cd9c28443b504e72cfb96096b5e43cf491735a204)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "allowDuplicate"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enableOctal"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripNullValues"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripOuterArray"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatJson], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatJson],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7f169ef2a9175982a351281236cbc56dc3bbc7f3b33a2ba50ed452f252768f6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd25643d8b94090493d6a63372f991345d2bdb6f732d4f62b8a5ad87d19686eb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45fcdefba177b7f9e16130192c72110141455d671674211ed8a1c921024d765a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36c8a82b8590a3c7d76000fa8669853a7b3b5604340e30cc28ed8f0be4e5ad00)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3e4833a70cfc71a94afcfb56ed4a0f15cdbd09266c6315c93028080fe076cb6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0cfc5caadc63fd7a01ed7a84d27c7918ef0d540b8940bdf07b75f2bc4ce1aeeb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatOrc:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatOrcList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatOrcList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16a348bf4be4dc4433b7d6f22e42d1bf7631df92421032ec984a0d814cf06a6d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatOrcOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9894293c1e873ce7c57740fcbd29e2be4b53ec2eddf93bcb738d65a07acb0d5d)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatOrcOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ef9ac7c140fbd4a90bdd5ebce5f3fdde1ba580095ee74021e5dfb26415484e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b884d81c0ec1343814fa9934e491d1b0564f8c90bad1e123e4a46cd126082d5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b2770d64e8b36dbad963362f46728ad839f5b3e4bfbb88ccdf6e4d0b1b2fe278)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e03c325d4f5fbc0ba79958ade72237cabe7a61c03709d5eb8f3f1ef65a88ea1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatOrc], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatOrc],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__861ca5c0ea1b4414cd2404e7b053f70d44b6f17c53545cf783e1c15ddc9d6c5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c921f06cc2a3f723e039431da272cc07be4006733897b02d51b5185a57a371f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> StageExternalGcsDescribeOutputFileFormatAvroList:
        return typing.cast(StageExternalGcsDescribeOutputFileFormatAvroList, jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> StageExternalGcsDescribeOutputFileFormatCsvList:
        return typing.cast(StageExternalGcsDescribeOutputFileFormatCsvList, jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> StageExternalGcsDescribeOutputFileFormatJsonList:
        return typing.cast(StageExternalGcsDescribeOutputFileFormatJsonList, jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> StageExternalGcsDescribeOutputFileFormatOrcList:
        return typing.cast(StageExternalGcsDescribeOutputFileFormatOrcList, jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageExternalGcsDescribeOutputFileFormatParquetList":
        return typing.cast("StageExternalGcsDescribeOutputFileFormatParquetList", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageExternalGcsDescribeOutputFileFormatXmlList":
        return typing.cast("StageExternalGcsDescribeOutputFileFormatXmlList", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormat]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormat], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormat],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a27a82beac02188f3bfe3aca2fb0317fd1a96f3c695a1753b9fc9d72694171b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatParquet:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatParquetList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatParquetList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7146809e504506785ab2200a065eca5690caa01e3935f3f91d1b2214ae6ce47f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatParquetOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b8e539222773bd6078160f51bcc71977ddc80cc28d3ec2bc28306a5fac408a7)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatParquetOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cfe3b538128c64b24b326282ba35afbd5d6876143aaba184787ff2ac0b0f2c27)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a67ea0c98a06ecd48bacc14e6a1124b538b9160ac2108c832975c322af5e5e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acb41929cff63a0a68c8996d5b8921a7fb7532daa4269f7a324910440a141a89)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ce943f198640802f3e279e74b4cc24a6ee454e3c1e8e2d8a3181a3688d4f02b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "binaryAsText"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "useLogicalType"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "useVectorizedScanner"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatParquet]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatParquet], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatParquet],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c39f598277947ba93a62efee0b6300feb201c532174a63f9b2d875d0e1b8f519)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsDescribeOutputFileFormatXml:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDescribeOutputFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDescribeOutputFileFormatXmlList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatXmlList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec67fccdb658fb4d78e3755369d46ed66a95c005d38b535356dd51af808e1598)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputFileFormatXmlOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__deb5119f2475370563d13786a733cad6b4abd89e0842b475f355008686767e51)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputFileFormatXmlOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e05be074766a36a89f346af1ad31398ceac39b7aafebde001d40288cc227efc6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3dd1bb3d89070c8975adf2a7a7a6495a008fbcdcd89df745dfe9e794ae420fc9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ae92c3a722a53fc486623c1df097601cab25955a837d74e2e48109ccf9c60d4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f27d60ce0e38ef7ab21f89bc1d2624fb2bcc5c651a6675d103a7ecab4714d18)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "disableAutoConvert"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "preserveSpace"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripOuterElement"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalGcsDescribeOutputFileFormatXml]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutputFileFormatXml], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutputFileFormatXml],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__365f113a580cde1b729e3807956a13cf2e167ca00f3fd0814fb47ed9462f5c10)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ec38f218825d4060084c9fabed0078c8116f347f8b7d3930933ab8f730c0b58)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalGcsDescribeOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__834eb255c8faf62ca8add32671e07518d2c27faa54b0827c8eaea19863a3fb67)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsDescribeOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55f09b94294701ce7232133687a4ce83860f0784517bf74bbb9f6d29ca2a4795)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94fb5814e348947e63851359612e9725fc4c0db1aae2a513cf05665c329aab9e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9879003b60e91a64364a06d7f130a078be482018c1cb3e833a7efc8f17c32371)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsDescribeOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDescribeOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f52212b30e73c700f4684ce816a86369050783aa9726fbe6fcd7d0fb3a1387f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="directoryTable")
    def directory_table(self) -> StageExternalGcsDescribeOutputDirectoryTableList:
        return typing.cast(StageExternalGcsDescribeOutputDirectoryTableList, jsii.get(self, "directoryTable"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> StageExternalGcsDescribeOutputFileFormatList:
        return typing.cast(StageExternalGcsDescribeOutputFileFormatList, jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsDescribeOutput]:
        return typing.cast(typing.Optional[StageExternalGcsDescribeOutput], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsDescribeOutput],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba67e996c7e56324c97a42618dd88b72f40c048fed94088fbbc45a802da1dc67)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDirectory",
    jsii_struct_bases=[],
    name_mapping={
        "enable": "enable",
        "auto_refresh": "autoRefresh",
        "notification_integration": "notificationIntegration",
        "refresh_on_create": "refreshOnCreate",
    },
)
class StageExternalGcsDirectory:
    def __init__(
        self,
        *,
        enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        auto_refresh: typing.Optional[builtins.str] = None,
        notification_integration: typing.Optional[builtins.str] = None,
        refresh_on_create: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the external stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable StageExternalGcs#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#auto_refresh StageExternalGcs#auto_refresh}
        :param notification_integration: Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#notification_integration StageExternalGcs#notification_integration}
        :param refresh_on_create: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#refresh_on_create StageExternalGcs#refresh_on_create}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edf43b269a9e55c7633c67e4fe249b480ab6a253008291a4381158e064ef339f)
            check_type(argname="argument enable", value=enable, expected_type=type_hints["enable"])
            check_type(argname="argument auto_refresh", value=auto_refresh, expected_type=type_hints["auto_refresh"])
            check_type(argname="argument notification_integration", value=notification_integration, expected_type=type_hints["notification_integration"])
            check_type(argname="argument refresh_on_create", value=refresh_on_create, expected_type=type_hints["refresh_on_create"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enable": enable,
        }
        if auto_refresh is not None:
            self._values["auto_refresh"] = auto_refresh
        if notification_integration is not None:
            self._values["notification_integration"] = notification_integration
        if refresh_on_create is not None:
            self._values["refresh_on_create"] = refresh_on_create

    @builtins.property
    def enable(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Specifies whether to enable a directory table on the external stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable StageExternalGcs#enable}
        '''
        result = self._values.get("enable")
        assert result is not None, "Required property 'enable' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def auto_refresh(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#auto_refresh StageExternalGcs#auto_refresh}
        '''
        result = self._values.get("auto_refresh")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def notification_integration(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the notification integration used to automatically refresh the directory table metadata.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#notification_integration StageExternalGcs#notification_integration}
        '''
        result = self._values.get("notification_integration")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def refresh_on_create(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#refresh_on_create StageExternalGcs#refresh_on_create}
        '''
        result = self._values.get("refresh_on_create")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsDirectory(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsDirectoryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsDirectoryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68103de66db11fb8711686b7461e5dcb2a4c926e895510e0b1483a720a4bea5e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAutoRefresh")
    def reset_auto_refresh(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoRefresh", []))

    @jsii.member(jsii_name="resetNotificationIntegration")
    def reset_notification_integration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNotificationIntegration", []))

    @jsii.member(jsii_name="resetRefreshOnCreate")
    def reset_refresh_on_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRefreshOnCreate", []))

    @builtins.property
    @jsii.member(jsii_name="autoRefreshInput")
    def auto_refresh_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "autoRefreshInput"))

    @builtins.property
    @jsii.member(jsii_name="enableInput")
    def enable_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationIntegrationInput")
    def notification_integration_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationIntegrationInput"))

    @builtins.property
    @jsii.member(jsii_name="refreshOnCreateInput")
    def refresh_on_create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "refreshOnCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autoRefresh"))

    @auto_refresh.setter
    def auto_refresh(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__971629dcbcdae895d2fe51f646b95426c9c3256c342e08ebd20dcdbdf3c1887d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoRefresh", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enable"))

    @enable.setter
    def enable(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65eefd1fa9e91d46532681d85c25f8312442348b5246562a93f37a5a6c085949)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enable", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationIntegration")
    def notification_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationIntegration"))

    @notification_integration.setter
    def notification_integration(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d089ca723ca5d313cf63b5f1d07868f70f6ca73e4a126d2e7bb875c8af952135)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationIntegration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="refreshOnCreate")
    def refresh_on_create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "refreshOnCreate"))

    @refresh_on_create.setter
    def refresh_on_create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e864a113bae966dda609a6f2c1f5c00c7cc784d04db2f7a491f6619a163b4cc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "refreshOnCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsDirectory]:
        return typing.cast(typing.Optional[StageExternalGcsDirectory], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[StageExternalGcsDirectory]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2871d4e51b6fc3a5bb16c7deaab59ef8969f08ae9890ef3baf18682323d1b28b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryption",
    jsii_struct_bases=[],
    name_mapping={"gcs_sse_kms": "gcsSseKms", "none": "none"},
)
class StageExternalGcsEncryption:
    def __init__(
        self,
        *,
        gcs_sse_kms: typing.Optional[typing.Union["StageExternalGcsEncryptionGcsSseKms", typing.Dict[builtins.str, typing.Any]]] = None,
        none: typing.Optional[typing.Union["StageExternalGcsEncryptionNone", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param gcs_sse_kms: gcs_sse_kms block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#gcs_sse_kms StageExternalGcs#gcs_sse_kms}
        :param none: none block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#none StageExternalGcs#none}
        '''
        if isinstance(gcs_sse_kms, dict):
            gcs_sse_kms = StageExternalGcsEncryptionGcsSseKms(**gcs_sse_kms)
        if isinstance(none, dict):
            none = StageExternalGcsEncryptionNone(**none)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39173221aefd7a0f294a3afa03d6a685769a0b7960fffab8029f337190fb2a2f)
            check_type(argname="argument gcs_sse_kms", value=gcs_sse_kms, expected_type=type_hints["gcs_sse_kms"])
            check_type(argname="argument none", value=none, expected_type=type_hints["none"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if gcs_sse_kms is not None:
            self._values["gcs_sse_kms"] = gcs_sse_kms
        if none is not None:
            self._values["none"] = none

    @builtins.property
    def gcs_sse_kms(self) -> typing.Optional["StageExternalGcsEncryptionGcsSseKms"]:
        '''gcs_sse_kms block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#gcs_sse_kms StageExternalGcs#gcs_sse_kms}
        '''
        result = self._values.get("gcs_sse_kms")
        return typing.cast(typing.Optional["StageExternalGcsEncryptionGcsSseKms"], result)

    @builtins.property
    def none(self) -> typing.Optional["StageExternalGcsEncryptionNone"]:
        '''none block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#none StageExternalGcs#none}
        '''
        result = self._values.get("none")
        return typing.cast(typing.Optional["StageExternalGcsEncryptionNone"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsEncryption(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryptionGcsSseKms",
    jsii_struct_bases=[],
    name_mapping={"kms_key_id": "kmsKeyId"},
)
class StageExternalGcsEncryptionGcsSseKms:
    def __init__(self, *, kms_key_id: typing.Optional[builtins.str] = None) -> None:
        '''
        :param kms_key_id: Specifies the KMS-managed key ID. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#kms_key_id StageExternalGcs#kms_key_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca952cf1fdb58ab2f15c206df31b6f75174dc9d355c720b6029ac16691d8974e)
            check_type(argname="argument kms_key_id", value=kms_key_id, expected_type=type_hints["kms_key_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if kms_key_id is not None:
            self._values["kms_key_id"] = kms_key_id

    @builtins.property
    def kms_key_id(self) -> typing.Optional[builtins.str]:
        '''Specifies the KMS-managed key ID.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#kms_key_id StageExternalGcs#kms_key_id}
        '''
        result = self._values.get("kms_key_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsEncryptionGcsSseKms(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsEncryptionGcsSseKmsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryptionGcsSseKmsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59ed13cdd9dea33f1a2cd8345545043b5f6bf7af2018e54d10bf17c0fd220458)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetKmsKeyId")
    def reset_kms_key_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKmsKeyId", []))

    @builtins.property
    @jsii.member(jsii_name="kmsKeyIdInput")
    def kms_key_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "kmsKeyIdInput"))

    @builtins.property
    @jsii.member(jsii_name="kmsKeyId")
    def kms_key_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "kmsKeyId"))

    @kms_key_id.setter
    def kms_key_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f921ba800ac6c0ec93b9384111a4c7220af0f34f2b6bd0a03b3402435b900fcf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "kmsKeyId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsEncryptionGcsSseKms]:
        return typing.cast(typing.Optional[StageExternalGcsEncryptionGcsSseKms], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsEncryptionGcsSseKms],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebd978415063e946d100d097ba2ed4ade5fdd6337abe2ebcdb63eaa38478f08e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryptionNone",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsEncryptionNone:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsEncryptionNone(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsEncryptionNoneOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryptionNoneOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2805b48f64f9266d0e342ce0af57863c2d51e506152de55527d9b463ad638fa5)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsEncryptionNone]:
        return typing.cast(typing.Optional[StageExternalGcsEncryptionNone], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsEncryptionNone],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4572497efccfed215266e4240c24c873851cdee4ab3b314efabb2930698fe62)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsEncryptionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsEncryptionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__938cd16aff9d0c53ca6715acd0f1008fcbd55f7b84bda0f2f454ad3ead90b2d7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putGcsSseKms")
    def put_gcs_sse_kms(
        self,
        *,
        kms_key_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param kms_key_id: Specifies the KMS-managed key ID. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#kms_key_id StageExternalGcs#kms_key_id}
        '''
        value = StageExternalGcsEncryptionGcsSseKms(kms_key_id=kms_key_id)

        return typing.cast(None, jsii.invoke(self, "putGcsSseKms", [value]))

    @jsii.member(jsii_name="putNone")
    def put_none(self) -> None:
        value = StageExternalGcsEncryptionNone()

        return typing.cast(None, jsii.invoke(self, "putNone", [value]))

    @jsii.member(jsii_name="resetGcsSseKms")
    def reset_gcs_sse_kms(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGcsSseKms", []))

    @jsii.member(jsii_name="resetNone")
    def reset_none(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNone", []))

    @builtins.property
    @jsii.member(jsii_name="gcsSseKms")
    def gcs_sse_kms(self) -> StageExternalGcsEncryptionGcsSseKmsOutputReference:
        return typing.cast(StageExternalGcsEncryptionGcsSseKmsOutputReference, jsii.get(self, "gcsSseKms"))

    @builtins.property
    @jsii.member(jsii_name="none")
    def none(self) -> StageExternalGcsEncryptionNoneOutputReference:
        return typing.cast(StageExternalGcsEncryptionNoneOutputReference, jsii.get(self, "none"))

    @builtins.property
    @jsii.member(jsii_name="gcsSseKmsInput")
    def gcs_sse_kms_input(self) -> typing.Optional[StageExternalGcsEncryptionGcsSseKms]:
        return typing.cast(typing.Optional[StageExternalGcsEncryptionGcsSseKms], jsii.get(self, "gcsSseKmsInput"))

    @builtins.property
    @jsii.member(jsii_name="noneInput")
    def none_input(self) -> typing.Optional[StageExternalGcsEncryptionNone]:
        return typing.cast(typing.Optional[StageExternalGcsEncryptionNone], jsii.get(self, "noneInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsEncryption]:
        return typing.cast(typing.Optional[StageExternalGcsEncryption], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsEncryption],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4cbec3836fbdc391ad8f48e06a97adb836d890a7306480f7a840c7499bad71a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormat",
    jsii_struct_bases=[],
    name_mapping={
        "avro": "avro",
        "csv": "csv",
        "format_name": "formatName",
        "json": "json",
        "orc": "orc",
        "parquet": "parquet",
        "xml": "xml",
    },
)
class StageExternalGcsFileFormat:
    def __init__(
        self,
        *,
        avro: typing.Optional[typing.Union["StageExternalGcsFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageExternalGcsFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageExternalGcsFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageExternalGcsFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageExternalGcsFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageExternalGcsFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#avro StageExternalGcs#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#csv StageExternalGcs#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#format_name StageExternalGcs#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#json StageExternalGcs#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#orc StageExternalGcs#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parquet StageExternalGcs#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#xml StageExternalGcs#xml}
        '''
        if isinstance(avro, dict):
            avro = StageExternalGcsFileFormatAvro(**avro)
        if isinstance(csv, dict):
            csv = StageExternalGcsFileFormatCsv(**csv)
        if isinstance(json, dict):
            json = StageExternalGcsFileFormatJson(**json)
        if isinstance(orc, dict):
            orc = StageExternalGcsFileFormatOrc(**orc)
        if isinstance(parquet, dict):
            parquet = StageExternalGcsFileFormatParquet(**parquet)
        if isinstance(xml, dict):
            xml = StageExternalGcsFileFormatXml(**xml)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3dc859628c57ad1442020a3f735a09a617567375405d583364ab89a611897e72)
            check_type(argname="argument avro", value=avro, expected_type=type_hints["avro"])
            check_type(argname="argument csv", value=csv, expected_type=type_hints["csv"])
            check_type(argname="argument format_name", value=format_name, expected_type=type_hints["format_name"])
            check_type(argname="argument json", value=json, expected_type=type_hints["json"])
            check_type(argname="argument orc", value=orc, expected_type=type_hints["orc"])
            check_type(argname="argument parquet", value=parquet, expected_type=type_hints["parquet"])
            check_type(argname="argument xml", value=xml, expected_type=type_hints["xml"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if avro is not None:
            self._values["avro"] = avro
        if csv is not None:
            self._values["csv"] = csv
        if format_name is not None:
            self._values["format_name"] = format_name
        if json is not None:
            self._values["json"] = json
        if orc is not None:
            self._values["orc"] = orc
        if parquet is not None:
            self._values["parquet"] = parquet
        if xml is not None:
            self._values["xml"] = xml

    @builtins.property
    def avro(self) -> typing.Optional["StageExternalGcsFileFormatAvro"]:
        '''avro block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#avro StageExternalGcs#avro}
        '''
        result = self._values.get("avro")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatAvro"], result)

    @builtins.property
    def csv(self) -> typing.Optional["StageExternalGcsFileFormatCsv"]:
        '''csv block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#csv StageExternalGcs#csv}
        '''
        result = self._values.get("csv")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatCsv"], result)

    @builtins.property
    def format_name(self) -> typing.Optional[builtins.str]:
        '''Fully qualified name of the file format (e.g., 'database.schema.format_name').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#format_name StageExternalGcs#format_name}
        '''
        result = self._values.get("format_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def json(self) -> typing.Optional["StageExternalGcsFileFormatJson"]:
        '''json block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#json StageExternalGcs#json}
        '''
        result = self._values.get("json")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatJson"], result)

    @builtins.property
    def orc(self) -> typing.Optional["StageExternalGcsFileFormatOrc"]:
        '''orc block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#orc StageExternalGcs#orc}
        '''
        result = self._values.get("orc")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatOrc"], result)

    @builtins.property
    def parquet(self) -> typing.Optional["StageExternalGcsFileFormatParquet"]:
        '''parquet block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parquet StageExternalGcs#parquet}
        '''
        result = self._values.get("parquet")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatParquet"], result)

    @builtins.property
    def xml(self) -> typing.Optional["StageExternalGcsFileFormatXml"]:
        '''xml block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#xml StageExternalGcs#xml}
        '''
        result = self._values.get("xml")
        return typing.cast(typing.Optional["StageExternalGcsFileFormatXml"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageExternalGcsFileFormatAvro:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f95a2b7ce6a46d78a2f3eb10915a3a2a67ed4cd7f1163509a6e36ff8be73e326)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bfe04d3ea027c34a7896d655e90255c8e7b5ce14a3b1336fc28371da071e756a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57461a8a93e14262aaaa7e09ad564f6f39848198b8f564048255602b0affd89e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9c763dad5a6e337c52015e9f8f29112a6568d27cb683b45c44e4fb91fdaa9c5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6f8c7ed53cb95a7df9527ba9691ab86611d45d63e2338cfb3f23c5da3b0348b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b9271abae13fea2bc289bdc31c5209f3db3e0322ec73715614aa53af587f973)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatAvro], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatAvro],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ef329e84f728580e2933000a9a8159a08c7837159db124b5e9fd379ea547eb0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "empty_field_as_null": "emptyFieldAsNull",
        "encoding": "encoding",
        "error_on_column_count_mismatch": "errorOnColumnCountMismatch",
        "escape": "escape",
        "escape_unenclosed_field": "escapeUnenclosedField",
        "field_delimiter": "fieldDelimiter",
        "field_optionally_enclosed_by": "fieldOptionallyEnclosedBy",
        "file_extension": "fileExtension",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "parse_header": "parseHeader",
        "record_delimiter": "recordDelimiter",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_blank_lines": "skipBlankLines",
        "skip_byte_order_mark": "skipByteOrderMark",
        "skip_header": "skipHeader",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageExternalGcsFileFormatCsv:
    def __init__(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#empty_field_as_null StageExternalGcs#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encoding StageExternalGcs#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#error_on_column_count_mismatch StageExternalGcs#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape StageExternalGcs#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape_unenclosed_field StageExternalGcs#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_delimiter StageExternalGcs#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_optionally_enclosed_by StageExternalGcs#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parse_header StageExternalGcs#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#record_delimiter StageExternalGcs#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_blank_lines StageExternalGcs#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_header StageExternalGcs#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82352dc3cbc20f48bea2b4ddb7e1177e7f6aebea24ba6d4dfdb024e4d5e517db)
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument empty_field_as_null", value=empty_field_as_null, expected_type=type_hints["empty_field_as_null"])
            check_type(argname="argument encoding", value=encoding, expected_type=type_hints["encoding"])
            check_type(argname="argument error_on_column_count_mismatch", value=error_on_column_count_mismatch, expected_type=type_hints["error_on_column_count_mismatch"])
            check_type(argname="argument escape", value=escape, expected_type=type_hints["escape"])
            check_type(argname="argument escape_unenclosed_field", value=escape_unenclosed_field, expected_type=type_hints["escape_unenclosed_field"])
            check_type(argname="argument field_delimiter", value=field_delimiter, expected_type=type_hints["field_delimiter"])
            check_type(argname="argument field_optionally_enclosed_by", value=field_optionally_enclosed_by, expected_type=type_hints["field_optionally_enclosed_by"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument parse_header", value=parse_header, expected_type=type_hints["parse_header"])
            check_type(argname="argument record_delimiter", value=record_delimiter, expected_type=type_hints["record_delimiter"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_blank_lines", value=skip_blank_lines, expected_type=type_hints["skip_blank_lines"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument skip_header", value=skip_header, expected_type=type_hints["skip_header"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if empty_field_as_null is not None:
            self._values["empty_field_as_null"] = empty_field_as_null
        if encoding is not None:
            self._values["encoding"] = encoding
        if error_on_column_count_mismatch is not None:
            self._values["error_on_column_count_mismatch"] = error_on_column_count_mismatch
        if escape is not None:
            self._values["escape"] = escape
        if escape_unenclosed_field is not None:
            self._values["escape_unenclosed_field"] = escape_unenclosed_field
        if field_delimiter is not None:
            self._values["field_delimiter"] = field_delimiter
        if field_optionally_enclosed_by is not None:
            self._values["field_optionally_enclosed_by"] = field_optionally_enclosed_by
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if parse_header is not None:
            self._values["parse_header"] = parse_header
        if record_delimiter is not None:
            self._values["record_delimiter"] = record_delimiter
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_blank_lines is not None:
            self._values["skip_blank_lines"] = skip_blank_lines
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if skip_header is not None:
            self._values["skip_header"] = skip_header
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def empty_field_as_null(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#empty_field_as_null StageExternalGcs#empty_field_as_null}
        '''
        result = self._values.get("empty_field_as_null")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encoding(self) -> typing.Optional[builtins.str]:
        '''Specifies the character set of the source data when loading data into a table.

        Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encoding StageExternalGcs#encoding}
        '''
        result = self._values.get("encoding")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def error_on_column_count_mismatch(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#error_on_column_count_mismatch StageExternalGcs#error_on_column_count_mismatch}
        '''
        result = self._values.get("error_on_column_count_mismatch")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for field values.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape StageExternalGcs#escape}
        '''
        result = self._values.get("escape")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape_unenclosed_field(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for unenclosed field values only.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape_unenclosed_field StageExternalGcs#escape_unenclosed_field}
        '''
        result = self._values.get("escape_unenclosed_field")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate fields in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_delimiter StageExternalGcs#field_delimiter}
        '''
        result = self._values.get("field_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_optionally_enclosed_by(self) -> typing.Optional[builtins.str]:
        '''Character used to enclose strings. Use ``NONE`` to specify no enclosure character.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_optionally_enclosed_by StageExternalGcs#field_optionally_enclosed_by}
        '''
        result = self._values.get("field_optionally_enclosed_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def parse_header(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parse_header StageExternalGcs#parse_header}
        '''
        result = self._values.get("parse_header")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def record_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate records in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#record_delimiter StageExternalGcs#record_delimiter}
        '''
        result = self._values.get("record_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_blank_lines(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_blank_lines StageExternalGcs#skip_blank_lines}
        '''
        result = self._values.get("skip_blank_lines")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_header(self) -> typing.Optional[jsii.Number]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_header StageExternalGcs#skip_header}
        '''
        result = self._values.get("skip_header")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bd96e25f68099cd05b460333ab5659da0f4f70ac64787ba1dd739e874c9f3ec)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEmptyFieldAsNull")
    def reset_empty_field_as_null(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmptyFieldAsNull", []))

    @jsii.member(jsii_name="resetEncoding")
    def reset_encoding(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncoding", []))

    @jsii.member(jsii_name="resetErrorOnColumnCountMismatch")
    def reset_error_on_column_count_mismatch(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetErrorOnColumnCountMismatch", []))

    @jsii.member(jsii_name="resetEscape")
    def reset_escape(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscape", []))

    @jsii.member(jsii_name="resetEscapeUnenclosedField")
    def reset_escape_unenclosed_field(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscapeUnenclosedField", []))

    @jsii.member(jsii_name="resetFieldDelimiter")
    def reset_field_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldDelimiter", []))

    @jsii.member(jsii_name="resetFieldOptionallyEnclosedBy")
    def reset_field_optionally_enclosed_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldOptionallyEnclosedBy", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetParseHeader")
    def reset_parse_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParseHeader", []))

    @jsii.member(jsii_name="resetRecordDelimiter")
    def reset_record_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRecordDelimiter", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipBlankLines")
    def reset_skip_blank_lines(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipBlankLines", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetSkipHeader")
    def reset_skip_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipHeader", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNullInput")
    def empty_field_as_null_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emptyFieldAsNullInput"))

    @builtins.property
    @jsii.member(jsii_name="encodingInput")
    def encoding_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "encodingInput"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatchInput")
    def error_on_column_count_mismatch_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "errorOnColumnCountMismatchInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeInput")
    def escape_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedFieldInput")
    def escape_unenclosed_field_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeUnenclosedFieldInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiterInput")
    def field_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedByInput")
    def field_optionally_enclosed_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldOptionallyEnclosedByInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="parseHeaderInput")
    def parse_header_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parseHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiterInput")
    def record_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "recordDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLinesInput")
    def skip_blank_lines_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipBlankLinesInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="skipHeaderInput")
    def skip_header_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "skipHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d4bfa454dce30e374461df57a72cd94090e2994df407ccb8d89d4f6842db252)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ace5dfd12308113f756a246cd669817bde79a58453823564ac3115940514c32d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2b10eac53eda1259b59a876ca8faca2c26ca4e934fee0ab107982bda28c56d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emptyFieldAsNull"))

    @empty_field_as_null.setter
    def empty_field_as_null(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b8c1fcdf428525ad3e580bac87977553678bdce28600211d3004d947c66d3ee4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emptyFieldAsNull", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @encoding.setter
    def encoding(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e54f25dd6c2a61cb1db6e0d586aec3a42f7e56f540083dcb375dadfd90cc9592)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "encoding", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "errorOnColumnCountMismatch"))

    @error_on_column_count_mismatch.setter
    def error_on_column_count_mismatch(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f43e5cdaf8f570f0eda2abe5d7c5746e85404395290324b0df75533ca9092fc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorOnColumnCountMismatch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @escape.setter
    def escape(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbda4719d74a229020f7c76d5cc7e5383ea8f9485f19a351b97581f437f89c7d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escape", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @escape_unenclosed_field.setter
    def escape_unenclosed_field(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12fcbda783fce5ccea66d77aa7272b84036dbc60323a30701dcb1e55c623daed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escapeUnenclosedField", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @field_delimiter.setter
    def field_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ad85e8d393bdff940d845596749664b36dccdaff346e2bce0ab591080980fc5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @field_optionally_enclosed_by.setter
    def field_optionally_enclosed_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dfbac768378d8e02cc3c158b66876793eb87e87ea1ceb5cb879db7f776bb4aac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldOptionallyEnclosedBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__198e487447a6e80f4cd92c5b18a5a44b28ad14977cd2342006424a58e9dce57d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bc895a4a99f01dc0f27e1a76b518ba28a3bdc5f97baeafd00417f94e413a211)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a74ac553d7fb0b198c956be3710cf0d709d52a5ca2a57584366bacd719a696e3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parseHeader"))

    @parse_header.setter
    def parse_header(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a999315dc198b89da224c00f5faf81da6704ed66f7b955a457d2088c70221eba)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parseHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @record_delimiter.setter
    def record_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66de82667b2521b26302efd956425276efe33ff715781cb4a45f35134f2feee8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "recordDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63652af13500e18e0221e37b103a030db95b09731548b0c98eedc01ae03a8e4d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipBlankLines"))

    @skip_blank_lines.setter
    def skip_blank_lines(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51014516905b2c34255fc7f2e34c0be64b166f841b2e3fcd02fa78a7e438afef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipBlankLines", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be0ff0b77fbdab76a2715a293a00f9bf17ea43c1c64ce9a6cf3f171303624131)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @skip_header.setter
    def skip_header(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c34548c0235520dfef1edce739393f5c11cc7986cb300341829e9ceabf5d31cc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57b8225abef693b66f5f63c4bd177226e842f68147dfd9592ef934d0641c0019)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb24f254f8e52cfc3d0a45f9a77069112e6ae98b0703fdbf05ce752ea61966dc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd940c5c85af82179872547a553e8de65b2d35cac3349dc3780442c2a95cde04)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatCsv], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatCsv],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ddd30bcbd4e2875835ae83b5f0f1a8f028d4ca3d238225c049cd309503f3417d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={
        "allow_duplicate": "allowDuplicate",
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "enable_octal": "enableOctal",
        "file_extension": "fileExtension",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_null_values": "stripNullValues",
        "strip_outer_array": "stripOuterArray",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageExternalGcsFileFormatJson:
    def __init__(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#allow_duplicate StageExternalGcs#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable_octal StageExternalGcs#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_null_values StageExternalGcs#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_array StageExternalGcs#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c37a7e05def175ca7d766065bfad47129257a9332fb2904f3b51aa4f1709e30)
            check_type(argname="argument allow_duplicate", value=allow_duplicate, expected_type=type_hints["allow_duplicate"])
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument enable_octal", value=enable_octal, expected_type=type_hints["enable_octal"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_null_values", value=strip_null_values, expected_type=type_hints["strip_null_values"])
            check_type(argname="argument strip_outer_array", value=strip_outer_array, expected_type=type_hints["strip_outer_array"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allow_duplicate is not None:
            self._values["allow_duplicate"] = allow_duplicate
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if enable_octal is not None:
            self._values["enable_octal"] = enable_octal
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_null_values is not None:
            self._values["strip_null_values"] = strip_null_values
        if strip_outer_array is not None:
            self._values["strip_outer_array"] = strip_outer_array
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def allow_duplicate(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved).

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#allow_duplicate StageExternalGcs#allow_duplicate}
        '''
        result = self._values.get("allow_duplicate")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_octal(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable_octal StageExternalGcs#enable_octal}
        '''
        result = self._values.get("enable_octal")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_null_values(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_null_values StageExternalGcs#strip_null_values}
        '''
        result = self._values.get("strip_null_values")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_array(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_array StageExternalGcs#strip_outer_array}
        '''
        result = self._values.get("strip_outer_array")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55e5d9b0c4db2d23f567c39bd69a5fa2880c6154c5007da95a4762ef967ce987)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAllowDuplicate")
    def reset_allow_duplicate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowDuplicate", []))

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEnableOctal")
    def reset_enable_octal(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableOctal", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripNullValues")
    def reset_strip_null_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripNullValues", []))

    @jsii.member(jsii_name="resetStripOuterArray")
    def reset_strip_outer_array(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterArray", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicateInput")
    def allow_duplicate_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "allowDuplicateInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="enableOctalInput")
    def enable_octal_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "enableOctalInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValuesInput")
    def strip_null_values_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripNullValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArrayInput")
    def strip_outer_array_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterArrayInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "allowDuplicate"))

    @allow_duplicate.setter
    def allow_duplicate(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f389c11881274aebf3071f1435b7b70078e2f068614406b0c044c9576fa44887)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowDuplicate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4116810125ddfced5d1e43791f9528bbeeaf10f241f270195b73e083c6f5ea6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e0dcc2c34d93f7bfdccfa7852dfd225d92c48b5f7e16b23d197be0cd6840f048)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb15de61c133113b5cfb543110dd9f90f5bb010e498ba98f9de882683250a1ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "enableOctal"))

    @enable_octal.setter
    def enable_octal(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ceb93e641d3f04aef5f86c810b9f878c59b6937cadebe2e09a038293dc63dffe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableOctal", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3537fffb4643c4f1928d9dc231a10acd4c6e0f10ddf05c400dfaf6c663d6a26)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b79c192bb9a69c606c57932898f28486d29d2bad5b1b6713aa780b9505865546)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03074cd69693be6078b36dcf5acf11ea3e048761c07fa6ba0b48e53fcf1e6554)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__383e0ff0d9ff07cdb9abaeb0d3bdfaf2bf182b426e7f457afd4d567d17e78410)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0c15c937cfb45d983467988a5d341e74a81fefcb60cd2da1c7febb2c2fccc3c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__301ee172d09c0e2a6578a2b7652ac7c226d3d8c7070b39f7e389a80cde3de127)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripNullValues"))

    @strip_null_values.setter
    def strip_null_values(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d59aaf55dae81e80d10abb15109f2f043a23a0a673ec8fee84df5c556a40d92d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripNullValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterArray"))

    @strip_outer_array.setter
    def strip_outer_array(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d3de5c54b8d9d5df6702eac422b026e467cd84e53a0e7ccf9e340fda87ee0b0b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterArray", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2a04eb2bbd44a06e255d86b170db7deace5cea8e0bb819495ced25af1fc08fc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__773529d8c3e7a82d9664a318c089010d7e7d271c68b5a84524b96ddfed658573)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__473703b6ceb91d42813f84ae5a5fee9a8f2bf55b3431b9568915734beb3e1320)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatJson], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatJson],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__562669f80015b436ebbdb16ae8cbd20416eccb5a43ed2324865eebc205eccdcb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageExternalGcsFileFormatOrc:
    def __init__(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__24233f96608bd55076c834d1fe800589e5cd34b82dd7a0e9da972f0b7b4bc034)
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9e88040b6d4c09e69a8384bf200f304d4cab60c761cf9e690ddeba7a09e73e8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1f25b21930433eae892ac0e67db38a7f18dd3e34a6f4d8edb9576f45a1da0781)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c482e06eb0dd83ae3d557b87483fe2645de2a7696e30ad71fd08bcd7020f68d7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be0f7a65a0e470eb96866f34808f4f649a3cc624e8d918804667e92c47006dac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatOrc], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatOrc],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4a1c16107eb1462945daed24ddf036fbecc06b5897ee842ce692630e2a12db3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f521b2856aff236773095ff4075271e366d5951b0a2388bfc3d25fc842ddcaf)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAvro")
    def put_avro(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        value = StageExternalGcsFileFormatAvro(
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putAvro", [value]))

    @jsii.member(jsii_name="putCsv")
    def put_csv(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#empty_field_as_null StageExternalGcs#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#encoding StageExternalGcs#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#error_on_column_count_mismatch StageExternalGcs#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape StageExternalGcs#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#escape_unenclosed_field StageExternalGcs#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_delimiter StageExternalGcs#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#field_optionally_enclosed_by StageExternalGcs#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#parse_header StageExternalGcs#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#record_delimiter StageExternalGcs#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_blank_lines StageExternalGcs#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_header StageExternalGcs#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        value = StageExternalGcsFileFormatCsv(
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            empty_field_as_null=empty_field_as_null,
            encoding=encoding,
            error_on_column_count_mismatch=error_on_column_count_mismatch,
            escape=escape,
            escape_unenclosed_field=escape_unenclosed_field,
            field_delimiter=field_delimiter,
            field_optionally_enclosed_by=field_optionally_enclosed_by,
            file_extension=file_extension,
            multi_line=multi_line,
            null_if=null_if,
            parse_header=parse_header,
            record_delimiter=record_delimiter,
            replace_invalid_characters=replace_invalid_characters,
            skip_blank_lines=skip_blank_lines,
            skip_byte_order_mark=skip_byte_order_mark,
            skip_header=skip_header,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putCsv", [value]))

    @jsii.member(jsii_name="putJson")
    def put_json(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#allow_duplicate StageExternalGcs#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#enable_octal StageExternalGcs#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_null_values StageExternalGcs#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_array StageExternalGcs#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        value = StageExternalGcsFileFormatJson(
            allow_duplicate=allow_duplicate,
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            enable_octal=enable_octal,
            file_extension=file_extension,
            ignore_utf8_errors=ignore_utf8_errors,
            multi_line=multi_line,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_null_values=strip_null_values,
            strip_outer_array=strip_outer_array,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putJson", [value]))

    @jsii.member(jsii_name="putOrc")
    def put_orc(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        value = StageExternalGcsFileFormatOrc(
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putOrc", [value]))

    @jsii.member(jsii_name="putParquet")
    def put_parquet(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_as_text StageExternalGcs#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_logical_type StageExternalGcs#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_vectorized_scanner StageExternalGcs#use_vectorized_scanner}
        '''
        value = StageExternalGcsFileFormatParquet(
            binary_as_text=binary_as_text,
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
            use_logical_type=use_logical_type,
            use_vectorized_scanner=use_vectorized_scanner,
        )

        return typing.cast(None, jsii.invoke(self, "putParquet", [value]))

    @jsii.member(jsii_name="putXml")
    def put_xml(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#disable_auto_convert StageExternalGcs#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#preserve_space StageExternalGcs#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_element StageExternalGcs#strip_outer_element}
        '''
        value = StageExternalGcsFileFormatXml(
            compression=compression,
            disable_auto_convert=disable_auto_convert,
            ignore_utf8_errors=ignore_utf8_errors,
            preserve_space=preserve_space,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_outer_element=strip_outer_element,
        )

        return typing.cast(None, jsii.invoke(self, "putXml", [value]))

    @jsii.member(jsii_name="resetAvro")
    def reset_avro(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAvro", []))

    @jsii.member(jsii_name="resetCsv")
    def reset_csv(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCsv", []))

    @jsii.member(jsii_name="resetFormatName")
    def reset_format_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFormatName", []))

    @jsii.member(jsii_name="resetJson")
    def reset_json(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJson", []))

    @jsii.member(jsii_name="resetOrc")
    def reset_orc(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrc", []))

    @jsii.member(jsii_name="resetParquet")
    def reset_parquet(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParquet", []))

    @jsii.member(jsii_name="resetXml")
    def reset_xml(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetXml", []))

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> StageExternalGcsFileFormatAvroOutputReference:
        return typing.cast(StageExternalGcsFileFormatAvroOutputReference, jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> StageExternalGcsFileFormatCsvOutputReference:
        return typing.cast(StageExternalGcsFileFormatCsvOutputReference, jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> StageExternalGcsFileFormatJsonOutputReference:
        return typing.cast(StageExternalGcsFileFormatJsonOutputReference, jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> StageExternalGcsFileFormatOrcOutputReference:
        return typing.cast(StageExternalGcsFileFormatOrcOutputReference, jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageExternalGcsFileFormatParquetOutputReference":
        return typing.cast("StageExternalGcsFileFormatParquetOutputReference", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageExternalGcsFileFormatXmlOutputReference":
        return typing.cast("StageExternalGcsFileFormatXmlOutputReference", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="avroInput")
    def avro_input(self) -> typing.Optional[StageExternalGcsFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatAvro], jsii.get(self, "avroInput"))

    @builtins.property
    @jsii.member(jsii_name="csvInput")
    def csv_input(self) -> typing.Optional[StageExternalGcsFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatCsv], jsii.get(self, "csvInput"))

    @builtins.property
    @jsii.member(jsii_name="formatNameInput")
    def format_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "formatNameInput"))

    @builtins.property
    @jsii.member(jsii_name="jsonInput")
    def json_input(self) -> typing.Optional[StageExternalGcsFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatJson], jsii.get(self, "jsonInput"))

    @builtins.property
    @jsii.member(jsii_name="orcInput")
    def orc_input(self) -> typing.Optional[StageExternalGcsFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatOrc], jsii.get(self, "orcInput"))

    @builtins.property
    @jsii.member(jsii_name="parquetInput")
    def parquet_input(self) -> typing.Optional["StageExternalGcsFileFormatParquet"]:
        return typing.cast(typing.Optional["StageExternalGcsFileFormatParquet"], jsii.get(self, "parquetInput"))

    @builtins.property
    @jsii.member(jsii_name="xmlInput")
    def xml_input(self) -> typing.Optional["StageExternalGcsFileFormatXml"]:
        return typing.cast(typing.Optional["StageExternalGcsFileFormatXml"], jsii.get(self, "xmlInput"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @format_name.setter
    def format_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aa7bbbb9a3921702f72a4fbd24ab7e1f07ccd9a72a73406795be9b3e0516db14)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "formatName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormat]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormat], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormat],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fbd89b0720af0f1d6cc4ab8a9c28ecc7939ebfed6dce11cc9990b4ba8f7ec095)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={
        "binary_as_text": "binaryAsText",
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
        "use_logical_type": "useLogicalType",
        "use_vectorized_scanner": "useVectorizedScanner",
    },
)
class StageExternalGcsFileFormatParquet:
    def __init__(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_as_text StageExternalGcs#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_logical_type StageExternalGcs#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_vectorized_scanner StageExternalGcs#use_vectorized_scanner}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97ac3a905711b12ab8aaf22a2d036c8d04a39172266da4e6bffeec3b3f4477cd)
            check_type(argname="argument binary_as_text", value=binary_as_text, expected_type=type_hints["binary_as_text"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
            check_type(argname="argument use_logical_type", value=use_logical_type, expected_type=type_hints["use_logical_type"])
            check_type(argname="argument use_vectorized_scanner", value=use_vectorized_scanner, expected_type=type_hints["use_vectorized_scanner"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_as_text is not None:
            self._values["binary_as_text"] = binary_as_text
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space
        if use_logical_type is not None:
            self._values["use_logical_type"] = use_logical_type
        if use_vectorized_scanner is not None:
            self._values["use_vectorized_scanner"] = use_vectorized_scanner

    @builtins.property
    def binary_as_text(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#binary_as_text StageExternalGcs#binary_as_text}
        '''
        result = self._values.get("binary_as_text")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_logical_type(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_logical_type StageExternalGcs#use_logical_type}
        '''
        result = self._values.get("use_logical_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_vectorized_scanner(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#use_vectorized_scanner StageExternalGcs#use_vectorized_scanner}
        '''
        result = self._values.get("use_vectorized_scanner")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5eb7ee3453de84511656250d0dc444e79cb6f6e6de2334309a8414cdee8080d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryAsText")
    def reset_binary_as_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryAsText", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @jsii.member(jsii_name="resetUseLogicalType")
    def reset_use_logical_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseLogicalType", []))

    @jsii.member(jsii_name="resetUseVectorizedScanner")
    def reset_use_vectorized_scanner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseVectorizedScanner", []))

    @builtins.property
    @jsii.member(jsii_name="binaryAsTextInput")
    def binary_as_text_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryAsTextInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalTypeInput")
    def use_logical_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useLogicalTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScannerInput")
    def use_vectorized_scanner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useVectorizedScannerInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryAsText"))

    @binary_as_text.setter
    def binary_as_text(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae58342be445a30aa102f573a48d788aa29fda6cac043ef150251f3ed4f7a16c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryAsText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4df2fecb41f30a7e8d5d63d8ae95f5c40cd9000e7d98a4b9b72126545a955161)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b4bc4ca2117fb95ea9e93b3238824a1f4e824d5dcfe6afb5bd0262a969471807)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__565099552ce5b7db22bd4f24461b3d2cf511f331c0ced67ae448eeba1633e6a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d531666a2996f928bdc1ef7cbbc4293db8730c522c0da6a6a2b301bbb472bc29)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useLogicalType"))

    @use_logical_type.setter
    def use_logical_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90c0bf2b124415b70824bb2b4db39a43e8e7605430fec8d916a8a08b1386c3c3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useLogicalType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useVectorizedScanner"))

    @use_vectorized_scanner.setter
    def use_vectorized_scanner(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4a04fa44cebf8a37533e2102c01d6bba6235765418db2526e8d5207114767f6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useVectorizedScanner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatParquet]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatParquet], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatParquet],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd2b09c3c28a8c77f14a3896abfdd7ba4cf7d523098d59daea899b2e7e2d0736)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "disable_auto_convert": "disableAutoConvert",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "preserve_space": "preserveSpace",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_outer_element": "stripOuterElement",
    },
)
class StageExternalGcsFileFormatXml:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#disable_auto_convert StageExternalGcs#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#preserve_space StageExternalGcs#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_element StageExternalGcs#strip_outer_element}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2fe7e4cd4eb6493fc5b173305cb1f6d5c1b2b2b857195f03cb858b80d740436c)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument disable_auto_convert", value=disable_auto_convert, expected_type=type_hints["disable_auto_convert"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument preserve_space", value=preserve_space, expected_type=type_hints["preserve_space"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_outer_element", value=strip_outer_element, expected_type=type_hints["strip_outer_element"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if disable_auto_convert is not None:
            self._values["disable_auto_convert"] = disable_auto_convert
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if preserve_space is not None:
            self._values["preserve_space"] = preserve_space
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_outer_element is not None:
            self._values["strip_outer_element"] = strip_outer_element

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def disable_auto_convert(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#disable_auto_convert StageExternalGcs#disable_auto_convert}
        '''
        result = self._values.get("disable_auto_convert")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def preserve_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#preserve_space StageExternalGcs#preserve_space}
        '''
        result = self._values.get("preserve_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_element(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#strip_outer_element StageExternalGcs#strip_outer_element}
        '''
        result = self._values.get("strip_outer_element")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39f7d8f90893c27151d4e3ca55ac183482b0de22fd7185c8c73ef974f266647e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDisableAutoConvert")
    def reset_disable_auto_convert(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableAutoConvert", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetPreserveSpace")
    def reset_preserve_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreserveSpace", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripOuterElement")
    def reset_strip_outer_element(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterElement", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvertInput")
    def disable_auto_convert_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableAutoConvertInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpaceInput")
    def preserve_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "preserveSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElementInput")
    def strip_outer_element_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterElementInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__869eb52dc04d6fef95c117c84a5e89ea43f6ca53179317d685f83cfa108ce5e5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "disableAutoConvert"))

    @disable_auto_convert.setter
    def disable_auto_convert(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f614ca38b52b2f8b61b130f1e1cfabcc7039139d97e15882b2cc31c4e981840d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableAutoConvert", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0d96a7642463786ffb5d2434ca5460f68c497880b29504d67bbc7c8538b8cc76)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "preserveSpace"))

    @preserve_space.setter
    def preserve_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12074f6fbe5282f9ed8350460a9fc8e0a72da65afb54437eb232b751915b564e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preserveSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33d103cb2f7d8541ab58f46cc9c71ca81298104e220119dfff065cf4b4a6f6ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__443a438a01049e2f2c182ab7478dfa58adb9c01b35a6294e05545a3ba221fb46)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterElement"))

    @strip_outer_element.setter
    def strip_outer_element(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3ea06dd402f6af007bfceba75d2182df3826a22432bbe4d743105aa603aea6e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterElement", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsFileFormatXml]:
        return typing.cast(typing.Optional[StageExternalGcsFileFormatXml], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsFileFormatXml],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3625a36fbae8dfa15450dfe5b98fd39099bc113774523cc799357c6ba59a3930)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsShowOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalGcsShowOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsShowOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsShowOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsShowOutputList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9316f90c6a213bb8222d108d66c0b81747fe9c14da15172983cc0355af886d40)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "StageExternalGcsShowOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17d63f929fe9671c3d1ae8b9f50a2c6c5af5b585c9a20fba93aba5aa0fccd433)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalGcsShowOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9efee8c5d5aa22241686de693b42744c65f89b9ad71636116203b2acd078c25)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__624fdf8fa03230bb34472b7e0db1c64bf3669b814f6f282f8807e219ba95db74)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0c26e5d5eed8d2847d53b7a0bb69b9fe14c4dded442a60d1e84aa9e72f8366d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalGcsShowOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsShowOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4f32f8d5d5c64ef27b544ff49322350e0dba170b7f0c6f8314bcf02919f79e3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="cloud")
    def cloud(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cloud"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="databaseName")
    def database_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseName"))

    @builtins.property
    @jsii.member(jsii_name="directoryEnabled")
    def directory_enabled(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "directoryEnabled"))

    @builtins.property
    @jsii.member(jsii_name="endpoint")
    def endpoint(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "endpoint"))

    @builtins.property
    @jsii.member(jsii_name="hasCredentials")
    def has_credentials(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "hasCredentials"))

    @builtins.property
    @jsii.member(jsii_name="hasEncryptionKey")
    def has_encryption_key(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "hasEncryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @builtins.property
    @jsii.member(jsii_name="ownerRoleType")
    def owner_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ownerRoleType"))

    @builtins.property
    @jsii.member(jsii_name="region")
    def region(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "region"))

    @builtins.property
    @jsii.member(jsii_name="schemaName")
    def schema_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schemaName"))

    @builtins.property
    @jsii.member(jsii_name="storageIntegration")
    def storage_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "storageIntegration"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalGcsShowOutput]:
        return typing.cast(typing.Optional[StageExternalGcsShowOutput], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalGcsShowOutput],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec7e02278deb532cb179001b0f439869c917d1e419f793bbd508f270ee3dddf7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class StageExternalGcsTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#create StageExternalGcs#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#delete StageExternalGcs#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#read StageExternalGcs#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#update StageExternalGcs#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b317713b2014447549a87c20a8648a5bd64f5b93ea5c2c870ef4621f1958197b)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#create StageExternalGcs#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#delete StageExternalGcs#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#read StageExternalGcs#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_gcs#update StageExternalGcs#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalGcsTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalGcsTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalGcs.StageExternalGcsTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0aef76054b1e118012b4e11e31fe1a6a71702cc119f260d68de83999e7afb504)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ba79b60759e064d3d3d96b4d85e8ee628db8073a8ba402ae786a167c82fca89)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ca89665a966aa02e7ee8e6b7a3b30683661380f7a9b9a7fb752a2303d83daaa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ccc35e50b009f3982ecfd5dee8b88bf919a8ec31c65fa7fa274018f30f838dc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a1825440c95be54a37a4a031a06085e107e5eb19b5b00090e8e2e8c4309d2d4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalGcsTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalGcsTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalGcsTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e5f4bb332ff26b5760fab327c50a6967409eb625939279161cac2e1c03c9970)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "StageExternalGcs",
    "StageExternalGcsConfig",
    "StageExternalGcsDescribeOutput",
    "StageExternalGcsDescribeOutputDirectoryTable",
    "StageExternalGcsDescribeOutputDirectoryTableList",
    "StageExternalGcsDescribeOutputDirectoryTableOutputReference",
    "StageExternalGcsDescribeOutputFileFormat",
    "StageExternalGcsDescribeOutputFileFormatAvro",
    "StageExternalGcsDescribeOutputFileFormatAvroList",
    "StageExternalGcsDescribeOutputFileFormatAvroOutputReference",
    "StageExternalGcsDescribeOutputFileFormatCsv",
    "StageExternalGcsDescribeOutputFileFormatCsvList",
    "StageExternalGcsDescribeOutputFileFormatCsvOutputReference",
    "StageExternalGcsDescribeOutputFileFormatJson",
    "StageExternalGcsDescribeOutputFileFormatJsonList",
    "StageExternalGcsDescribeOutputFileFormatJsonOutputReference",
    "StageExternalGcsDescribeOutputFileFormatList",
    "StageExternalGcsDescribeOutputFileFormatOrc",
    "StageExternalGcsDescribeOutputFileFormatOrcList",
    "StageExternalGcsDescribeOutputFileFormatOrcOutputReference",
    "StageExternalGcsDescribeOutputFileFormatOutputReference",
    "StageExternalGcsDescribeOutputFileFormatParquet",
    "StageExternalGcsDescribeOutputFileFormatParquetList",
    "StageExternalGcsDescribeOutputFileFormatParquetOutputReference",
    "StageExternalGcsDescribeOutputFileFormatXml",
    "StageExternalGcsDescribeOutputFileFormatXmlList",
    "StageExternalGcsDescribeOutputFileFormatXmlOutputReference",
    "StageExternalGcsDescribeOutputList",
    "StageExternalGcsDescribeOutputOutputReference",
    "StageExternalGcsDirectory",
    "StageExternalGcsDirectoryOutputReference",
    "StageExternalGcsEncryption",
    "StageExternalGcsEncryptionGcsSseKms",
    "StageExternalGcsEncryptionGcsSseKmsOutputReference",
    "StageExternalGcsEncryptionNone",
    "StageExternalGcsEncryptionNoneOutputReference",
    "StageExternalGcsEncryptionOutputReference",
    "StageExternalGcsFileFormat",
    "StageExternalGcsFileFormatAvro",
    "StageExternalGcsFileFormatAvroOutputReference",
    "StageExternalGcsFileFormatCsv",
    "StageExternalGcsFileFormatCsvOutputReference",
    "StageExternalGcsFileFormatJson",
    "StageExternalGcsFileFormatJsonOutputReference",
    "StageExternalGcsFileFormatOrc",
    "StageExternalGcsFileFormatOrcOutputReference",
    "StageExternalGcsFileFormatOutputReference",
    "StageExternalGcsFileFormatParquet",
    "StageExternalGcsFileFormatParquetOutputReference",
    "StageExternalGcsFileFormatXml",
    "StageExternalGcsFileFormatXmlOutputReference",
    "StageExternalGcsShowOutput",
    "StageExternalGcsShowOutputList",
    "StageExternalGcsShowOutputOutputReference",
    "StageExternalGcsTimeouts",
    "StageExternalGcsTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__a5991eee0e9bdc1666e453571458f4dc9872b1b0c15be87e94d125dcce212c91(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    storage_integration: builtins.str,
    url: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    directory: typing.Optional[typing.Union[StageExternalGcsDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageExternalGcsEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageExternalGcsFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageExternalGcsTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__978f0d37f144e9b58c8c3902a53248f44c10b82e9a0e6b702e889a29f7dd9cb9(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a09f0759ed5e19bb2343604f5cdc76953cf3324fccc93ef290bd3a7358858bd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__964debd55c0a35dfdc7fe8d1df6f9f7b5193d9209729327ffdb0783232eb7aa2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99d73467c8b0100ecdf5c00d9ce97636bc0afff7c5a8dcbd38a27b8430a70907(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79c63b667123073d5275524e9fc350fbc57cc284310eed0c1678d7a109ec86e2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdcaf39ca19638e60a8d2e5561bfc548b9e357bd5d0f17497f8bd5933cb1b390(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__19f56659ccd75a25dfe3b26b0aa556270e3b4f7e5cfa6185f794d5b3afb1dd2b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9672c4b17add3b829828df4e333df5a48a68bd4adb0891327f0f338122e92bcd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__177ea2f64a584c2d8fdc40a4ed5a7a3e3cdc8b5c8baf2f4faecef098bf46da53(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    storage_integration: builtins.str,
    url: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    directory: typing.Optional[typing.Union[StageExternalGcsDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageExternalGcsEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageExternalGcsFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageExternalGcsTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64b41f4574687624d3aa440df8968df14efbf1df8857aaa3630502c4de3c133d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0619ace4c8518160dd885e1763d6011021525a1605cb7a72bac5b7956827e194(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86103c95fc924700c7260190c8fbec77948dc7f29d4b548e483ff89388fe5941(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__666a43a51d26e22ba66301b6af75d6ee77ce3bd0fa386e751308776b2821b254(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eca58aa13716890cca87c14e39f132a6e01fa1449052cdb97811832ef9b73b95(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c487175b39aa45bf972d7477e0297e14b1c79f70175dd45d42baaaa9af151151(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79d6b83816957847c45d02702cca53a9589af9c899e3c9234c2bed2e9da6eda2(
    value: typing.Optional[StageExternalGcsDescribeOutputDirectoryTable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__800347b1ca4e941deff7610bfb3dd0a276cb7130f03d1b0f6697135711b71141(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46bdb26b1a19ee86151a0d5291d60a5c3d7c751f521c64b2e6ea17ae07f6aadf(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebb79f7a0bdbf5d954fa08096617d9d7dbf74bc7e12cb685e65ae9a135c72810(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a701c05db718266c7f95c97a21214169b310ad54702a9437b3fdb51254dcee9a(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7650b9a68f8852a7f8d2f3b2c1d6448c1c7edfcdf04fedeb1d4bf6a7c4a19af(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96684c5cc9cb3981da15d3454bd2c043ed122a07fc0fb2351c78ba368dc4a060(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e1d772fb4a51313119c1d4bb0de4b93fdab8e0e756ec826422f778bb8bfdbf27(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f468d5c1638a39ea4a0d79dff9c3e97fd11e195132765cf41b66c23b463fc54(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc2eb6da3a31a555de7518bae9193bebe8db38020a4d99d0a669cb8c6d824c99(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d06c70b8deda293175cc2dc6f22b89c1ab5cf9c4409c4b760ba47b4f22925e96(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7949fd4a196081a63c1f572fd9b73df1c71560722d20cba8a5fb99d42f744e9c(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb28abafdab1c47b6ef260d643c0e9eef6aa149edc3763959fd6e72fd8dbc9b2(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99c00180e7bf5ed9a27f5c564fbd3b01b72952dd91aa8b4209588e750271f681(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fcc9a246ebbf46b1a8f9d86468afd620fa0bc0c9a5110fe870b39d66cea8f248(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51051df427d277f03262728503edd81bac27d944f282f6284b615e03812c6fc0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36c31dfb09226a647b5207d7861f90b05ec7c94345caa48c8ba00489b2917fac(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__428e132065c82e93f02e4237cc47b7facec0a8fd468e029e67ef5919d8018714(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__479799f37ffb5ced338053c1640b984f7f5bffd25e54f8947752c4dab96dd0f4(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5e016048bc61158bc92eb10be78a196e77cb86734d44ec631444acee1281801(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5544a44611341ce3e849a46cd9c28443b504e72cfb96096b5e43cf491735a204(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7f169ef2a9175982a351281236cbc56dc3bbc7f3b33a2ba50ed452f252768f6(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd25643d8b94090493d6a63372f991345d2bdb6f732d4f62b8a5ad87d19686eb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45fcdefba177b7f9e16130192c72110141455d671674211ed8a1c921024d765a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36c8a82b8590a3c7d76000fa8669853a7b3b5604340e30cc28ed8f0be4e5ad00(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3e4833a70cfc71a94afcfb56ed4a0f15cdbd09266c6315c93028080fe076cb6(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cfc5caadc63fd7a01ed7a84d27c7918ef0d540b8940bdf07b75f2bc4ce1aeeb(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16a348bf4be4dc4433b7d6f22e42d1bf7631df92421032ec984a0d814cf06a6d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9894293c1e873ce7c57740fcbd29e2be4b53ec2eddf93bcb738d65a07acb0d5d(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ef9ac7c140fbd4a90bdd5ebce5f3fdde1ba580095ee74021e5dfb26415484e8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b884d81c0ec1343814fa9934e491d1b0564f8c90bad1e123e4a46cd126082d5(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b2770d64e8b36dbad963362f46728ad839f5b3e4bfbb88ccdf6e4d0b1b2fe278(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e03c325d4f5fbc0ba79958ade72237cabe7a61c03709d5eb8f3f1ef65a88ea1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__861ca5c0ea1b4414cd2404e7b053f70d44b6f17c53545cf783e1c15ddc9d6c5d(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c921f06cc2a3f723e039431da272cc07be4006733897b02d51b5185a57a371f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a27a82beac02188f3bfe3aca2fb0317fd1a96f3c695a1753b9fc9d72694171b(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7146809e504506785ab2200a065eca5690caa01e3935f3f91d1b2214ae6ce47f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b8e539222773bd6078160f51bcc71977ddc80cc28d3ec2bc28306a5fac408a7(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfe3b538128c64b24b326282ba35afbd5d6876143aaba184787ff2ac0b0f2c27(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a67ea0c98a06ecd48bacc14e6a1124b538b9160ac2108c832975c322af5e5e9(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acb41929cff63a0a68c8996d5b8921a7fb7532daa4269f7a324910440a141a89(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ce943f198640802f3e279e74b4cc24a6ee454e3c1e8e2d8a3181a3688d4f02b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c39f598277947ba93a62efee0b6300feb201c532174a63f9b2d875d0e1b8f519(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec67fccdb658fb4d78e3755369d46ed66a95c005d38b535356dd51af808e1598(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__deb5119f2475370563d13786a733cad6b4abd89e0842b475f355008686767e51(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e05be074766a36a89f346af1ad31398ceac39b7aafebde001d40288cc227efc6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3dd1bb3d89070c8975adf2a7a7a6495a008fbcdcd89df745dfe9e794ae420fc9(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ae92c3a722a53fc486623c1df097601cab25955a837d74e2e48109ccf9c60d4(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f27d60ce0e38ef7ab21f89bc1d2624fb2bcc5c651a6675d103a7ecab4714d18(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__365f113a580cde1b729e3807956a13cf2e167ca00f3fd0814fb47ed9462f5c10(
    value: typing.Optional[StageExternalGcsDescribeOutputFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ec38f218825d4060084c9fabed0078c8116f347f8b7d3930933ab8f730c0b58(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__834eb255c8faf62ca8add32671e07518d2c27faa54b0827c8eaea19863a3fb67(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55f09b94294701ce7232133687a4ce83860f0784517bf74bbb9f6d29ca2a4795(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94fb5814e348947e63851359612e9725fc4c0db1aae2a513cf05665c329aab9e(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9879003b60e91a64364a06d7f130a078be482018c1cb3e833a7efc8f17c32371(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f52212b30e73c700f4684ce816a86369050783aa9726fbe6fcd7d0fb3a1387f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba67e996c7e56324c97a42618dd88b72f40c048fed94088fbbc45a802da1dc67(
    value: typing.Optional[StageExternalGcsDescribeOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edf43b269a9e55c7633c67e4fe249b480ab6a253008291a4381158e064ef339f(
    *,
    enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    auto_refresh: typing.Optional[builtins.str] = None,
    notification_integration: typing.Optional[builtins.str] = None,
    refresh_on_create: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68103de66db11fb8711686b7461e5dcb2a4c926e895510e0b1483a720a4bea5e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__971629dcbcdae895d2fe51f646b95426c9c3256c342e08ebd20dcdbdf3c1887d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65eefd1fa9e91d46532681d85c25f8312442348b5246562a93f37a5a6c085949(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d089ca723ca5d313cf63b5f1d07868f70f6ca73e4a126d2e7bb875c8af952135(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e864a113bae966dda609a6f2c1f5c00c7cc784d04db2f7a491f6619a163b4cc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2871d4e51b6fc3a5bb16c7deaab59ef8969f08ae9890ef3baf18682323d1b28b(
    value: typing.Optional[StageExternalGcsDirectory],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39173221aefd7a0f294a3afa03d6a685769a0b7960fffab8029f337190fb2a2f(
    *,
    gcs_sse_kms: typing.Optional[typing.Union[StageExternalGcsEncryptionGcsSseKms, typing.Dict[builtins.str, typing.Any]]] = None,
    none: typing.Optional[typing.Union[StageExternalGcsEncryptionNone, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca952cf1fdb58ab2f15c206df31b6f75174dc9d355c720b6029ac16691d8974e(
    *,
    kms_key_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59ed13cdd9dea33f1a2cd8345545043b5f6bf7af2018e54d10bf17c0fd220458(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f921ba800ac6c0ec93b9384111a4c7220af0f34f2b6bd0a03b3402435b900fcf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebd978415063e946d100d097ba2ed4ade5fdd6337abe2ebcdb63eaa38478f08e(
    value: typing.Optional[StageExternalGcsEncryptionGcsSseKms],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2805b48f64f9266d0e342ce0af57863c2d51e506152de55527d9b463ad638fa5(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4572497efccfed215266e4240c24c873851cdee4ab3b314efabb2930698fe62(
    value: typing.Optional[StageExternalGcsEncryptionNone],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__938cd16aff9d0c53ca6715acd0f1008fcbd55f7b84bda0f2f454ad3ead90b2d7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4cbec3836fbdc391ad8f48e06a97adb836d890a7306480f7a840c7499bad71a(
    value: typing.Optional[StageExternalGcsEncryption],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3dc859628c57ad1442020a3f735a09a617567375405d583364ab89a611897e72(
    *,
    avro: typing.Optional[typing.Union[StageExternalGcsFileFormatAvro, typing.Dict[builtins.str, typing.Any]]] = None,
    csv: typing.Optional[typing.Union[StageExternalGcsFileFormatCsv, typing.Dict[builtins.str, typing.Any]]] = None,
    format_name: typing.Optional[builtins.str] = None,
    json: typing.Optional[typing.Union[StageExternalGcsFileFormatJson, typing.Dict[builtins.str, typing.Any]]] = None,
    orc: typing.Optional[typing.Union[StageExternalGcsFileFormatOrc, typing.Dict[builtins.str, typing.Any]]] = None,
    parquet: typing.Optional[typing.Union[StageExternalGcsFileFormatParquet, typing.Dict[builtins.str, typing.Any]]] = None,
    xml: typing.Optional[typing.Union[StageExternalGcsFileFormatXml, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f95a2b7ce6a46d78a2f3eb10915a3a2a67ed4cd7f1163509a6e36ff8be73e326(
    *,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfe04d3ea027c34a7896d655e90255c8e7b5ce14a3b1336fc28371da071e756a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57461a8a93e14262aaaa7e09ad564f6f39848198b8f564048255602b0affd89e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9c763dad5a6e337c52015e9f8f29112a6568d27cb683b45c44e4fb91fdaa9c5(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6f8c7ed53cb95a7df9527ba9691ab86611d45d63e2338cfb3f23c5da3b0348b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b9271abae13fea2bc289bdc31c5209f3db3e0322ec73715614aa53af587f973(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ef329e84f728580e2933000a9a8159a08c7837159db124b5e9fd379ea547eb0(
    value: typing.Optional[StageExternalGcsFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82352dc3cbc20f48bea2b4ddb7e1177e7f6aebea24ba6d4dfdb024e4d5e517db(
    *,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    empty_field_as_null: typing.Optional[builtins.str] = None,
    encoding: typing.Optional[builtins.str] = None,
    error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
    escape: typing.Optional[builtins.str] = None,
    escape_unenclosed_field: typing.Optional[builtins.str] = None,
    field_delimiter: typing.Optional[builtins.str] = None,
    field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    parse_header: typing.Optional[builtins.str] = None,
    record_delimiter: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_blank_lines: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    skip_header: typing.Optional[jsii.Number] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bd96e25f68099cd05b460333ab5659da0f4f70ac64787ba1dd739e874c9f3ec(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d4bfa454dce30e374461df57a72cd94090e2994df407ccb8d89d4f6842db252(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ace5dfd12308113f756a246cd669817bde79a58453823564ac3115940514c32d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2b10eac53eda1259b59a876ca8faca2c26ca4e934fee0ab107982bda28c56d0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b8c1fcdf428525ad3e580bac87977553678bdce28600211d3004d947c66d3ee4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e54f25dd6c2a61cb1db6e0d586aec3a42f7e56f540083dcb375dadfd90cc9592(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f43e5cdaf8f570f0eda2abe5d7c5746e85404395290324b0df75533ca9092fc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbda4719d74a229020f7c76d5cc7e5383ea8f9485f19a351b97581f437f89c7d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12fcbda783fce5ccea66d77aa7272b84036dbc60323a30701dcb1e55c623daed(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ad85e8d393bdff940d845596749664b36dccdaff346e2bce0ab591080980fc5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfbac768378d8e02cc3c158b66876793eb87e87ea1ceb5cb879db7f776bb4aac(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__198e487447a6e80f4cd92c5b18a5a44b28ad14977cd2342006424a58e9dce57d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bc895a4a99f01dc0f27e1a76b518ba28a3bdc5f97baeafd00417f94e413a211(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a74ac553d7fb0b198c956be3710cf0d709d52a5ca2a57584366bacd719a696e3(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a999315dc198b89da224c00f5faf81da6704ed66f7b955a457d2088c70221eba(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66de82667b2521b26302efd956425276efe33ff715781cb4a45f35134f2feee8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63652af13500e18e0221e37b103a030db95b09731548b0c98eedc01ae03a8e4d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51014516905b2c34255fc7f2e34c0be64b166f841b2e3fcd02fa78a7e438afef(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be0ff0b77fbdab76a2715a293a00f9bf17ea43c1c64ce9a6cf3f171303624131(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c34548c0235520dfef1edce739393f5c11cc7986cb300341829e9ceabf5d31cc(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57b8225abef693b66f5f63c4bd177226e842f68147dfd9592ef934d0641c0019(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb24f254f8e52cfc3d0a45f9a77069112e6ae98b0703fdbf05ce752ea61966dc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd940c5c85af82179872547a553e8de65b2d35cac3349dc3780442c2a95cde04(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ddd30bcbd4e2875835ae83b5f0f1a8f028d4ca3d238225c049cd309503f3417d(
    value: typing.Optional[StageExternalGcsFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c37a7e05def175ca7d766065bfad47129257a9332fb2904f3b51aa4f1709e30(
    *,
    allow_duplicate: typing.Optional[builtins.str] = None,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    enable_octal: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_null_values: typing.Optional[builtins.str] = None,
    strip_outer_array: typing.Optional[builtins.str] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55e5d9b0c4db2d23f567c39bd69a5fa2880c6154c5007da95a4762ef967ce987(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f389c11881274aebf3071f1435b7b70078e2f068614406b0c044c9576fa44887(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4116810125ddfced5d1e43791f9528bbeeaf10f241f270195b73e083c6f5ea6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0dcc2c34d93f7bfdccfa7852dfd225d92c48b5f7e16b23d197be0cd6840f048(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb15de61c133113b5cfb543110dd9f90f5bb010e498ba98f9de882683250a1ee(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ceb93e641d3f04aef5f86c810b9f878c59b6937cadebe2e09a038293dc63dffe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3537fffb4643c4f1928d9dc231a10acd4c6e0f10ddf05c400dfaf6c663d6a26(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b79c192bb9a69c606c57932898f28486d29d2bad5b1b6713aa780b9505865546(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03074cd69693be6078b36dcf5acf11ea3e048761c07fa6ba0b48e53fcf1e6554(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__383e0ff0d9ff07cdb9abaeb0d3bdfaf2bf182b426e7f457afd4d567d17e78410(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0c15c937cfb45d983467988a5d341e74a81fefcb60cd2da1c7febb2c2fccc3c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__301ee172d09c0e2a6578a2b7652ac7c226d3d8c7070b39f7e389a80cde3de127(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d59aaf55dae81e80d10abb15109f2f043a23a0a673ec8fee84df5c556a40d92d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d3de5c54b8d9d5df6702eac422b026e467cd84e53a0e7ccf9e340fda87ee0b0b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2a04eb2bbd44a06e255d86b170db7deace5cea8e0bb819495ced25af1fc08fc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__773529d8c3e7a82d9664a318c089010d7e7d271c68b5a84524b96ddfed658573(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__473703b6ceb91d42813f84ae5a5fee9a8f2bf55b3431b9568915734beb3e1320(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__562669f80015b436ebbdb16ae8cbd20416eccb5a43ed2324865eebc205eccdcb(
    value: typing.Optional[StageExternalGcsFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24233f96608bd55076c834d1fe800589e5cd34b82dd7a0e9da972f0b7b4bc034(
    *,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9e88040b6d4c09e69a8384bf200f304d4cab60c761cf9e690ddeba7a09e73e8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1f25b21930433eae892ac0e67db38a7f18dd3e34a6f4d8edb9576f45a1da0781(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c482e06eb0dd83ae3d557b87483fe2645de2a7696e30ad71fd08bcd7020f68d7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be0f7a65a0e470eb96866f34808f4f649a3cc624e8d918804667e92c47006dac(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4a1c16107eb1462945daed24ddf036fbecc06b5897ee842ce692630e2a12db3(
    value: typing.Optional[StageExternalGcsFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f521b2856aff236773095ff4075271e366d5951b0a2388bfc3d25fc842ddcaf(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa7bbbb9a3921702f72a4fbd24ab7e1f07ccd9a72a73406795be9b3e0516db14(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fbd89b0720af0f1d6cc4ab8a9c28ecc7939ebfed6dce11cc9990b4ba8f7ec095(
    value: typing.Optional[StageExternalGcsFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97ac3a905711b12ab8aaf22a2d036c8d04a39172266da4e6bffeec3b3f4477cd(
    *,
    binary_as_text: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
    use_logical_type: typing.Optional[builtins.str] = None,
    use_vectorized_scanner: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5eb7ee3453de84511656250d0dc444e79cb6f6e6de2334309a8414cdee8080d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae58342be445a30aa102f573a48d788aa29fda6cac043ef150251f3ed4f7a16c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4df2fecb41f30a7e8d5d63d8ae95f5c40cd9000e7d98a4b9b72126545a955161(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b4bc4ca2117fb95ea9e93b3238824a1f4e824d5dcfe6afb5bd0262a969471807(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__565099552ce5b7db22bd4f24461b3d2cf511f331c0ced67ae448eeba1633e6a6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d531666a2996f928bdc1ef7cbbc4293db8730c522c0da6a6a2b301bbb472bc29(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90c0bf2b124415b70824bb2b4db39a43e8e7605430fec8d916a8a08b1386c3c3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4a04fa44cebf8a37533e2102c01d6bba6235765418db2526e8d5207114767f6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd2b09c3c28a8c77f14a3896abfdd7ba4cf7d523098d59daea899b2e7e2d0736(
    value: typing.Optional[StageExternalGcsFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2fe7e4cd4eb6493fc5b173305cb1f6d5c1b2b2b857195f03cb858b80d740436c(
    *,
    compression: typing.Optional[builtins.str] = None,
    disable_auto_convert: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    preserve_space: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_outer_element: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39f7d8f90893c27151d4e3ca55ac183482b0de22fd7185c8c73ef974f266647e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__869eb52dc04d6fef95c117c84a5e89ea43f6ca53179317d685f83cfa108ce5e5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f614ca38b52b2f8b61b130f1e1cfabcc7039139d97e15882b2cc31c4e981840d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d96a7642463786ffb5d2434ca5460f68c497880b29504d67bbc7c8538b8cc76(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12074f6fbe5282f9ed8350460a9fc8e0a72da65afb54437eb232b751915b564e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33d103cb2f7d8541ab58f46cc9c71ca81298104e220119dfff065cf4b4a6f6ae(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__443a438a01049e2f2c182ab7478dfa58adb9c01b35a6294e05545a3ba221fb46(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3ea06dd402f6af007bfceba75d2182df3826a22432bbe4d743105aa603aea6e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3625a36fbae8dfa15450dfe5b98fd39099bc113774523cc799357c6ba59a3930(
    value: typing.Optional[StageExternalGcsFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9316f90c6a213bb8222d108d66c0b81747fe9c14da15172983cc0355af886d40(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17d63f929fe9671c3d1ae8b9f50a2c6c5af5b585c9a20fba93aba5aa0fccd433(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9efee8c5d5aa22241686de693b42744c65f89b9ad71636116203b2acd078c25(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__624fdf8fa03230bb34472b7e0db1c64bf3669b814f6f282f8807e219ba95db74(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0c26e5d5eed8d2847d53b7a0bb69b9fe14c4dded442a60d1e84aa9e72f8366d(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4f32f8d5d5c64ef27b544ff49322350e0dba170b7f0c6f8314bcf02919f79e3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec7e02278deb532cb179001b0f439869c917d1e419f793bbd508f270ee3dddf7(
    value: typing.Optional[StageExternalGcsShowOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b317713b2014447549a87c20a8648a5bd64f5b93ea5c2c870ef4621f1958197b(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0aef76054b1e118012b4e11e31fe1a6a71702cc119f260d68de83999e7afb504(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ba79b60759e064d3d3d96b4d85e8ee628db8073a8ba402ae786a167c82fca89(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ca89665a966aa02e7ee8e6b7a3b30683661380f7a9b9a7fb752a2303d83daaa(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ccc35e50b009f3982ecfd5dee8b88bf919a8ec31c65fa7fa274018f30f838dc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a1825440c95be54a37a4a031a06085e107e5eb19b5b00090e8e2e8c4309d2d4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e5f4bb332ff26b5760fab327c50a6967409eb625939279161cac2e1c03c9970(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalGcsTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
