r'''
# `provider`

Refer to the Terraform Registry for docs: [`snowflake`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class SnowflakeProvider(
    _cdktn_78ede62e.TerraformProvider,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.provider.SnowflakeProvider",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs snowflake}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        account_name: typing.Optional[builtins.str] = None,
        alias: typing.Optional[builtins.str] = None,
        authenticator: typing.Optional[builtins.str] = None,
        cert_revocation_check_mode: typing.Optional[builtins.str] = None,
        client_ip: typing.Optional[builtins.str] = None,
        client_request_mfa_token: typing.Optional[builtins.str] = None,
        client_store_temporary_credential: typing.Optional[builtins.str] = None,
        client_timeout: typing.Optional[jsii.Number] = None,
        crl_allow_certificates_without_crl_url: typing.Optional[builtins.str] = None,
        crl_http_client_timeout: typing.Optional[jsii.Number] = None,
        crl_in_memory_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        crl_on_disk_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_console_login: typing.Optional[builtins.str] = None,
        disable_ocsp_checks: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_query_context_cache: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_saml_url_check: typing.Optional[builtins.str] = None,
        disable_telemetry: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        driver_tracing: typing.Optional[builtins.str] = None,
        enable_single_use_refresh_tokens: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        experimental_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        external_browser_timeout: typing.Optional[jsii.Number] = None,
        host: typing.Optional[builtins.str] = None,
        include_retry_reason: typing.Optional[builtins.str] = None,
        insecure_mode: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        jwt_client_timeout: typing.Optional[jsii.Number] = None,
        jwt_expire_timeout: typing.Optional[jsii.Number] = None,
        keep_session_alive: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        login_timeout: typing.Optional[jsii.Number] = None,
        log_query_parameters: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        log_query_text: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        max_retry_count: typing.Optional[jsii.Number] = None,
        no_proxy: typing.Optional[builtins.str] = None,
        oauth_authorization_url: typing.Optional[builtins.str] = None,
        oauth_client_id: typing.Optional[builtins.str] = None,
        oauth_client_secret: typing.Optional[builtins.str] = None,
        oauth_redirect_uri: typing.Optional[builtins.str] = None,
        oauth_scope: typing.Optional[builtins.str] = None,
        oauth_token_request_url: typing.Optional[builtins.str] = None,
        ocsp_fail_open: typing.Optional[builtins.str] = None,
        okta_url: typing.Optional[builtins.str] = None,
        organization_name: typing.Optional[builtins.str] = None,
        params: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        passcode: typing.Optional[builtins.str] = None,
        passcode_in_password: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        password: typing.Optional[builtins.str] = None,
        port: typing.Optional[jsii.Number] = None,
        preview_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        private_key: typing.Optional[builtins.str] = None,
        private_key_passphrase: typing.Optional[builtins.str] = None,
        profile: typing.Optional[builtins.str] = None,
        protocol: typing.Optional[builtins.str] = None,
        proxy_host: typing.Optional[builtins.str] = None,
        proxy_password: typing.Optional[builtins.str] = None,
        proxy_port: typing.Optional[jsii.Number] = None,
        proxy_protocol: typing.Optional[builtins.str] = None,
        proxy_user: typing.Optional[builtins.str] = None,
        request_timeout: typing.Optional[jsii.Number] = None,
        role: typing.Optional[builtins.str] = None,
        skip_toml_file_permission_verification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        tmp_directory_path: typing.Optional[builtins.str] = None,
        token: typing.Optional[builtins.str] = None,
        token_accessor: typing.Optional[typing.Union["SnowflakeProviderTokenAccessor", typing.Dict[builtins.str, typing.Any]]] = None,
        use_legacy_toml_file: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        user: typing.Optional[builtins.str] = None,
        validate_default_parameters: typing.Optional[builtins.str] = None,
        warehouse: typing.Optional[builtins.str] = None,
        workload_identity_entra_resource: typing.Optional[builtins.str] = None,
        workload_identity_provider: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs snowflake} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param account_name: Specifies your Snowflake account name assigned by Snowflake. For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#account-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ACCOUNT_NAME`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#account_name SnowflakeProvider#account_name}
        :param alias: Alias name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#alias SnowflakeProvider#alias}
        :param authenticator: Specifies the `authentication type <https://pkg.go.dev/github.com/snowflakedb/gosnowflake#AuthType>`_ to use when connecting to Snowflake. Valid options are: ``SNOWFLAKE`` | ``OAUTH`` | ``EXTERNALBROWSER`` | ``OKTA`` | ``SNOWFLAKE_JWT`` | ``TOKENACCESSOR`` | ``USERNAMEPASSWORDMFA`` | ``PROGRAMMATIC_ACCESS_TOKEN`` | ``OAUTH_CLIENT_CREDENTIALS`` | ``OAUTH_AUTHORIZATION_CODE`` | ``WORKLOAD_IDENTITY``. Can also be sourced from the ``SNOWFLAKE_AUTHENTICATOR`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#authenticator SnowflakeProvider#authenticator}
        :param cert_revocation_check_mode: Specifies the certificate revocation check mode. Valid options are: ``DISABLED`` | ``ADVISORY`` | ``ENABLED``. The value is case-insensitive. Can also be sourced from the ``SNOWFLAKE_CERT_REVOCATION_CHECK_MODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#cert_revocation_check_mode SnowflakeProvider#cert_revocation_check_mode}
        :param client_ip: IP address for network checks. Can also be sourced from the ``SNOWFLAKE_CLIENT_IP`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_ip SnowflakeProvider#client_ip}
        :param client_request_mfa_token: When true the MFA token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_REQUEST_MFA_TOKEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_request_mfa_token SnowflakeProvider#client_request_mfa_token}
        :param client_store_temporary_credential: When true the ID token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_store_temporary_credential SnowflakeProvider#client_store_temporary_credential}
        :param client_timeout: The timeout in seconds for the client to complete the authentication. Can also be sourced from the ``SNOWFLAKE_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_timeout SnowflakeProvider#client_timeout}
        :param crl_allow_certificates_without_crl_url: Allow certificates (not short-lived) without CRL DP included to be treated as correct ones. Can also be sourced from the ``SNOWFLAKE_CRL_ALLOW_CERTIFICATES_WITHOUT_CRL_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_allow_certificates_without_crl_url SnowflakeProvider#crl_allow_certificates_without_crl_url}
        :param crl_http_client_timeout: Timeout in seconds for HTTP client used to download CRL. Can also be sourced from the ``SNOWFLAKE_CRL_HTTP_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_http_client_timeout SnowflakeProvider#crl_http_client_timeout}
        :param crl_in_memory_cache_disabled: False by default. When set to true, the CRL in-memory cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_IN_MEMORY_CACHE_DISABLED`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_in_memory_cache_disabled SnowflakeProvider#crl_in_memory_cache_disabled}
        :param crl_on_disk_cache_disabled: False by default. When set to true, the CRL on-disk cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_ON_DISK_CACHE_DISABLED`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_on_disk_cache_disabled SnowflakeProvider#crl_on_disk_cache_disabled}
        :param disable_console_login: Indicates whether console login should be disabled in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_CONSOLE_LOGIN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_console_login SnowflakeProvider#disable_console_login}
        :param disable_ocsp_checks: False by default. When set to true, the driver doesn't check certificate revocation status. Can also be sourced from the ``SNOWFLAKE_DISABLE_OCSP_CHECKS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_ocsp_checks SnowflakeProvider#disable_ocsp_checks}
        :param disable_query_context_cache: Disables HTAP query context cache in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_QUERY_CONTEXT_CACHE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_query_context_cache SnowflakeProvider#disable_query_context_cache}
        :param disable_saml_url_check: Indicates whether the SAML URL check should be disabled. Can also be sourced from the ``SNOWFLAKE_DISABLE_SAML_URL_CHECK`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_saml_url_check SnowflakeProvider#disable_saml_url_check}
        :param disable_telemetry: Disables telemetry in the driver. Can also be sourced from the ``DISABLE_TELEMETRY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_telemetry SnowflakeProvider#disable_telemetry}
        :param driver_tracing: Specifies the logging level to be used by the driver. Valid options are: ``trace`` | ``debug`` | ``info`` | ``print`` | ``warning`` | ``error`` | ``fatal`` | ``panic``. Can also be sourced from the ``SNOWFLAKE_DRIVER_TRACING`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#driver_tracing SnowflakeProvider#driver_tracing}
        :param enable_single_use_refresh_tokens: Enables single use refresh tokens for Snowflake IdP. Can also be sourced from the ``SNOWFLAKE_ENABLE_SINGLE_USE_REFRESH_TOKENS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#enable_single_use_refresh_tokens SnowflakeProvider#enable_single_use_refresh_tokens}
        :param experimental_features_enabled: A list of experimental features. Similarly to preview features, they are not yet stable features of the provider. Enabling given experiment is still considered a preview feature, even when applied to the stable resource. These switches offer experiments altering the provider behavior. If the given experiment is successful, it can be considered an addition in the future provider versions. This field can not be set with environmental variables. Check more details in the `experimental features section <#experimental-features>`_. Active experiments are: ``WAREHOUSE_SHOW_IMPROVED_PERFORMANCE`` | ``GRANTS_STRICT_PRIVILEGE_MANAGEMENT`` | ``PARAMETERS_IGNORE_VALUE_CHANGES_IF_NOT_ON_OBJECT_LEVEL`` | ``PARAMETERS_REDUCED_OUTPUT`` | ``USER_ENABLE_DEFAULT_WORKLOAD_IDENTITY``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#experimental_features_enabled SnowflakeProvider#experimental_features_enabled}
        :param external_browser_timeout: The timeout in seconds for the external browser to complete the authentication. Can also be sourced from the ``SNOWFLAKE_EXTERNAL_BROWSER_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#external_browser_timeout SnowflakeProvider#external_browser_timeout}
        :param host: Specifies a custom host value used by the driver for privatelink connections. Can also be sourced from the ``SNOWFLAKE_HOST`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#host SnowflakeProvider#host}
        :param include_retry_reason: Should retried request contain retry reason. Can also be sourced from the ``SNOWFLAKE_INCLUDE_RETRY_REASON`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#include_retry_reason SnowflakeProvider#include_retry_reason}
        :param insecure_mode: This field is deprecated. Use ``disable_ocsp_checks`` instead. If true, bypass the Online Certificate Status Protocol (OCSP) certificate revocation check. IMPORTANT: Change the default value for testing or emergency situations only. Can also be sourced from the ``SNOWFLAKE_INSECURE_MODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#insecure_mode SnowflakeProvider#insecure_mode}
        :param jwt_client_timeout: The timeout in seconds for the JWT client to complete the authentication. Can also be sourced from the ``SNOWFLAKE_JWT_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_client_timeout SnowflakeProvider#jwt_client_timeout}
        :param jwt_expire_timeout: JWT expire after timeout in seconds. Can also be sourced from the ``SNOWFLAKE_JWT_EXPIRE_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_expire_timeout SnowflakeProvider#jwt_expire_timeout}
        :param keep_session_alive: Enables the session to persist even after the connection is closed. Can also be sourced from the ``SNOWFLAKE_KEEP_SESSION_ALIVE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#keep_session_alive SnowflakeProvider#keep_session_alive}
        :param login_timeout: Login retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the ``SNOWFLAKE_LOGIN_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#login_timeout SnowflakeProvider#login_timeout}
        :param log_query_parameters: When set to true, the parameters will be logged. Requires logQueryText to be enabled first. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_PARAMETERS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_parameters SnowflakeProvider#log_query_parameters}
        :param log_query_text: When set to true, the full query text will be logged. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_TEXT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_text SnowflakeProvider#log_query_text}
        :param max_retry_count: Specifies how many times non-periodic HTTP request can be retried by the driver. Can also be sourced from the ``SNOWFLAKE_MAX_RETRY_COUNT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#max_retry_count SnowflakeProvider#max_retry_count}
        :param no_proxy: A comma-separated list of hostnames, domains, and IP addresses to exclude from proxying. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_NO_PROXY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#no_proxy SnowflakeProvider#no_proxy}
        :param oauth_authorization_url: Authorization URL of OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_AUTHORIZATION_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_authorization_url SnowflakeProvider#oauth_authorization_url}
        :param oauth_client_id: Client id for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_ID`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_id SnowflakeProvider#oauth_client_id}
        :param oauth_client_secret: Client secret for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_SECRET`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_secret SnowflakeProvider#oauth_client_secret}
        :param oauth_redirect_uri: Redirect URI registered in IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_REDIRECT_URI`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_redirect_uri SnowflakeProvider#oauth_redirect_uri}
        :param oauth_scope: Comma separated list of scopes. If empty it is derived from role. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_SCOPE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_scope SnowflakeProvider#oauth_scope}
        :param oauth_token_request_url: Token request URL of OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_TOKEN_REQUEST_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_token_request_url SnowflakeProvider#oauth_token_request_url}
        :param ocsp_fail_open: True represents OCSP fail open mode. False represents OCSP fail closed mode. Fail open true by default. Can also be sourced from the ``SNOWFLAKE_OCSP_FAIL_OPEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#ocsp_fail_open SnowflakeProvider#ocsp_fail_open}
        :param okta_url: The URL of the Okta server. e.g. https://example.okta.com. Okta URL host needs to to have a suffix ``okta.com``. Read more in Snowflake `docs <https://docs.snowflake.com/en/user-guide/oauth-okta>`_. Can also be sourced from the ``SNOWFLAKE_OKTA_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#okta_url SnowflakeProvider#okta_url}
        :param organization_name: Specifies your Snowflake organization name assigned by Snowflake. For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#organization-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ORGANIZATION_NAME`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#organization_name SnowflakeProvider#organization_name}
        :param params: Sets other connection (i.e. session) parameters. `Parameters <https://docs.snowflake.com/en/sql-reference/parameters>`_. This field can not be set with environmental variables. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#params SnowflakeProvider#params}
        :param passcode: Specifies the passcode provided by Duo when using multi-factor authentication (MFA) for login. Can also be sourced from the ``SNOWFLAKE_PASSCODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode SnowflakeProvider#passcode}
        :param passcode_in_password: False by default. Set to true if the MFA passcode is embedded to the configured password. Can also be sourced from the ``SNOWFLAKE_PASSCODE_IN_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode_in_password SnowflakeProvider#passcode_in_password}
        :param password: Password for user + password or `token <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens#generating-a-programmatic-access-token>`_ for `PAT auth <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens>`_. Cannot be used with ``private_key`` and ``private_key_passphrase``. Can also be sourced from the ``SNOWFLAKE_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#password SnowflakeProvider#password}
        :param port: Specifies a custom port value used by the driver for privatelink connections. Can also be sourced from the ``SNOWFLAKE_PORT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#port SnowflakeProvider#port}
        :param preview_features_enabled: A list of preview features that are handled by the provider. See `preview features list <https://github.com/Snowflake-Labs/terraform-provider-snowflake/blob/main/v1-preparations/LIST_OF_PREVIEW_FEATURES_FOR_V1.md>`_. Preview features may have breaking changes in future releases, even without raising the major version. This field can not be set with environmental variables. Preview features that can be enabled are: ``snowflake_account_authentication_policy_attachment_resource`` | ``snowflake_account_password_policy_attachment_resource`` | ``snowflake_alert_resource`` | ``snowflake_alerts_datasource`` | ``snowflake_api_integration_resource`` | ``snowflake_authentication_policy_resource`` | ``snowflake_authentication_policies_datasource`` | ``snowflake_cortex_search_service_resource`` | ``snowflake_cortex_search_services_datasource`` | ``snowflake_current_account_resource`` | ``snowflake_current_account_datasource`` | ``snowflake_current_organization_account_resource`` | ``snowflake_database_datasource`` | ``snowflake_database_role_datasource`` | ``snowflake_dynamic_table_resource`` | ``snowflake_dynamic_tables_datasource`` | ``snowflake_stage_external_azure_resource`` | ``snowflake_external_function_resource`` | ``snowflake_external_functions_datasource`` | ``snowflake_stage_external_gcs_resource`` | ``snowflake_stage_external_s3_resource`` | ``snowflake_stage_external_s3_compatible_resource`` | ``snowflake_external_table_resource`` | ``snowflake_external_tables_datasource`` | ``snowflake_external_volume_resource`` | ``snowflake_failover_group_resource`` | ``snowflake_failover_groups_datasource`` | ``snowflake_file_format_resource`` | ``snowflake_file_formats_datasource`` | ``snowflake_function_java_resource`` | ``snowflake_function_javascript_resource`` | ``snowflake_function_python_resource`` | ``snowflake_function_scala_resource`` | ``snowflake_function_sql_resource`` | ``snowflake_functions_datasource`` | ``snowflake_stage_internal_resource`` | ``snowflake_job_service_resource`` | ``snowflake_listings_datasource`` | ``snowflake_managed_account_resource`` | ``snowflake_materialized_view_resource`` | ``snowflake_materialized_views_datasource`` | ``snowflake_network_policy_attachment_resource`` | ``snowflake_network_rule_resource`` | ``snowflake_notebook_resource`` | ``snowflake_notebooks_datasource`` | ``snowflake_email_notification_integration_resource`` | ``snowflake_notification_integration_resource`` | ``snowflake_object_parameter_resource`` | ``snowflake_password_policy_resource`` | ``snowflake_pipe_resource`` | ``snowflake_pipes_datasource`` | ``snowflake_current_role_datasource`` | ``snowflake_semantic_view_resource`` | ``snowflake_semantic_views_datasource`` | ``snowflake_sequence_resource`` | ``snowflake_sequences_datasource`` | ``snowflake_share_resource`` | ``snowflake_shares_datasource`` | ``snowflake_parameters_datasource`` | ``snowflake_procedure_java_resource`` | ``snowflake_procedure_javascript_resource`` | ``snowflake_procedure_python_resource`` | ``snowflake_procedure_scala_resource`` | ``snowflake_procedure_sql_resource`` | ``snowflake_procedures_datasource`` | ``snowflake_stage_resource`` | ``snowflake_stages_datasource`` | ``snowflake_storage_integration_resource`` | ``snowflake_storage_integration_aws_resource`` | ``snowflake_storage_integration_azure_resource`` | ``snowflake_storage_integration_gcs_resource`` | ``snowflake_storage_integrations_datasource`` | ``snowflake_system_generate_scim_access_token_datasource`` | ``snowflake_system_get_aws_sns_iam_policy_datasource`` | ``snowflake_system_get_privatelink_config_datasource`` | ``snowflake_system_get_snowflake_platform_info_datasource`` | ``snowflake_table_column_masking_policy_application_resource`` | ``snowflake_table_constraint_resource`` | ``snowflake_table_resource`` | ``snowflake_tables_datasource`` | ``snowflake_user_authentication_policy_attachment_resource`` | ``snowflake_user_public_keys_resource`` | ``snowflake_user_password_policy_attachment_resource``. Promoted features that are stable and are enabled by default are: ``snowflake_compute_pool_resource`` | ``snowflake_compute_pools_datasource`` | ``snowflake_git_repository_resource`` | ``snowflake_git_repositories_datasource`` | ``snowflake_image_repository_resource`` | ``snowflake_image_repositories_datasource`` | ``snowflake_listing_resource`` | ``snowflake_service_resource`` | ``snowflake_services_datasource`` | ``snowflake_user_programmatic_access_token_resource`` | ``snowflake_user_programmatic_access_tokens_datasource``. Promoted features can be safely removed from this field. They will be removed in the next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#preview_features_enabled SnowflakeProvider#preview_features_enabled}
        :param private_key: Private Key for username+private-key auth. Cannot be used with ``password``. Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key SnowflakeProvider#private_key}
        :param private_key_passphrase: Supports the encryption ciphers aes-128-cbc, aes-128-gcm, aes-192-cbc, aes-192-gcm, aes-256-cbc, aes-256-gcm, and des-ede3-cbc. Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY_PASSPHRASE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key_passphrase SnowflakeProvider#private_key_passphrase}
        :param profile: Sets the profile to read from ~/.snowflake/config file. Can also be sourced from the ``SNOWFLAKE_PROFILE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#profile SnowflakeProvider#profile}
        :param protocol: A protocol used in the connection. Valid options are: ``http`` | ``https``. Can also be sourced from the ``SNOWFLAKE_PROTOCOL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#protocol SnowflakeProvider#protocol}
        :param proxy_host: The host of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_HOST`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_host SnowflakeProvider#proxy_host}
        :param proxy_password: The password of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_password SnowflakeProvider#proxy_password}
        :param proxy_port: The port of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PORT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_port SnowflakeProvider#proxy_port}
        :param proxy_protocol: The protocol of the proxy to use for the connection. Valid options are: ``http`` | ``https``. The value is case-insensitive. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PROTOCOL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_protocol SnowflakeProvider#proxy_protocol}
        :param proxy_user: The user of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_USER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_user SnowflakeProvider#proxy_user}
        :param request_timeout: request retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the ``SNOWFLAKE_REQUEST_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#request_timeout SnowflakeProvider#request_timeout}
        :param role: Specifies the role to use by default for accessing Snowflake objects in the client session. Can also be sourced from the ``SNOWFLAKE_ROLE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#role SnowflakeProvider#role}
        :param skip_toml_file_permission_verification: False by default. Skips TOML configuration file permission verification. This flag has no effect on Windows systems, as the permissions are not checked on this platform. Instead of skipping the permissions verification, we recommend setting the proper privileges - see `the section below <#toml-file-limitations>`_. Can also be sourced from the ``SNOWFLAKE_SKIP_TOML_FILE_PERMISSION_VERIFICATION`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#skip_toml_file_permission_verification SnowflakeProvider#skip_toml_file_permission_verification}
        :param tmp_directory_path: Sets temporary directory used by the driver for operations like encrypting, compressing etc. Can also be sourced from the ``SNOWFLAKE_TMP_DIRECTORY_PATH`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#tmp_directory_path SnowflakeProvider#tmp_directory_path}
        :param token: Token to use for OAuth and other forms of token based auth. When this field is set here, or in the TOML file, the provider sets the ``authenticator`` to ``OAUTH``. Optionally, set the ``authenticator`` field to the authenticator you want to use. Can also be sourced from the ``SNOWFLAKE_TOKEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token SnowflakeProvider#token}
        :param token_accessor: token_accessor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token_accessor SnowflakeProvider#token_accessor}
        :param use_legacy_toml_file: False by default. When this is set to true, the provider expects the legacy TOML format. Otherwise, it expects the new format. See more in `the section below <#examples>`_ Can also be sourced from the ``SNOWFLAKE_USE_LEGACY_TOML_FILE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#use_legacy_toml_file SnowflakeProvider#use_legacy_toml_file}
        :param user: Username. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_USER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#user SnowflakeProvider#user}
        :param validate_default_parameters: True by default. If false, disables the validation checks for Database, Schema, Warehouse and Role at the time a connection is established. Can also be sourced from the ``SNOWFLAKE_VALIDATE_DEFAULT_PARAMETERS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#validate_default_parameters SnowflakeProvider#validate_default_parameters}
        :param warehouse: Specifies the virtual warehouse to use by default for queries, loading, etc. in the client session. Can also be sourced from the ``SNOWFLAKE_WAREHOUSE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#warehouse SnowflakeProvider#warehouse}
        :param workload_identity_entra_resource: The resource to use for WIF authentication on Azure environment. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_ENTRA_RESOURCE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_entra_resource SnowflakeProvider#workload_identity_entra_resource}
        :param workload_identity_provider: The workload identity provider to use for WIF authentication. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_PROVIDER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_provider SnowflakeProvider#workload_identity_provider}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c1cb44e3b84880ea849eda37563afbbfddfca8446376cb0706c8ec62829c6a5)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = SnowflakeProviderConfig(
            account_name=account_name,
            alias=alias,
            authenticator=authenticator,
            cert_revocation_check_mode=cert_revocation_check_mode,
            client_ip=client_ip,
            client_request_mfa_token=client_request_mfa_token,
            client_store_temporary_credential=client_store_temporary_credential,
            client_timeout=client_timeout,
            crl_allow_certificates_without_crl_url=crl_allow_certificates_without_crl_url,
            crl_http_client_timeout=crl_http_client_timeout,
            crl_in_memory_cache_disabled=crl_in_memory_cache_disabled,
            crl_on_disk_cache_disabled=crl_on_disk_cache_disabled,
            disable_console_login=disable_console_login,
            disable_ocsp_checks=disable_ocsp_checks,
            disable_query_context_cache=disable_query_context_cache,
            disable_saml_url_check=disable_saml_url_check,
            disable_telemetry=disable_telemetry,
            driver_tracing=driver_tracing,
            enable_single_use_refresh_tokens=enable_single_use_refresh_tokens,
            experimental_features_enabled=experimental_features_enabled,
            external_browser_timeout=external_browser_timeout,
            host=host,
            include_retry_reason=include_retry_reason,
            insecure_mode=insecure_mode,
            jwt_client_timeout=jwt_client_timeout,
            jwt_expire_timeout=jwt_expire_timeout,
            keep_session_alive=keep_session_alive,
            login_timeout=login_timeout,
            log_query_parameters=log_query_parameters,
            log_query_text=log_query_text,
            max_retry_count=max_retry_count,
            no_proxy=no_proxy,
            oauth_authorization_url=oauth_authorization_url,
            oauth_client_id=oauth_client_id,
            oauth_client_secret=oauth_client_secret,
            oauth_redirect_uri=oauth_redirect_uri,
            oauth_scope=oauth_scope,
            oauth_token_request_url=oauth_token_request_url,
            ocsp_fail_open=ocsp_fail_open,
            okta_url=okta_url,
            organization_name=organization_name,
            params=params,
            passcode=passcode,
            passcode_in_password=passcode_in_password,
            password=password,
            port=port,
            preview_features_enabled=preview_features_enabled,
            private_key=private_key,
            private_key_passphrase=private_key_passphrase,
            profile=profile,
            protocol=protocol,
            proxy_host=proxy_host,
            proxy_password=proxy_password,
            proxy_port=proxy_port,
            proxy_protocol=proxy_protocol,
            proxy_user=proxy_user,
            request_timeout=request_timeout,
            role=role,
            skip_toml_file_permission_verification=skip_toml_file_permission_verification,
            tmp_directory_path=tmp_directory_path,
            token=token,
            token_accessor=token_accessor,
            use_legacy_toml_file=use_legacy_toml_file,
            user=user,
            validate_default_parameters=validate_default_parameters,
            warehouse=warehouse,
            workload_identity_entra_resource=workload_identity_entra_resource,
            workload_identity_provider=workload_identity_provider,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a SnowflakeProvider resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the SnowflakeProvider to import.
        :param import_from_id: The id of the existing SnowflakeProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the SnowflakeProvider to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b304e00bb8ee82994ae2ec983ed339caa6f5ec7552b845483bcb4c2d8b366aad)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetAccountName")
    def reset_account_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountName", []))

    @jsii.member(jsii_name="resetAlias")
    def reset_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlias", []))

    @jsii.member(jsii_name="resetAuthenticator")
    def reset_authenticator(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAuthenticator", []))

    @jsii.member(jsii_name="resetCertRevocationCheckMode")
    def reset_cert_revocation_check_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCertRevocationCheckMode", []))

    @jsii.member(jsii_name="resetClientIp")
    def reset_client_ip(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetClientIp", []))

    @jsii.member(jsii_name="resetClientRequestMfaToken")
    def reset_client_request_mfa_token(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetClientRequestMfaToken", []))

    @jsii.member(jsii_name="resetClientStoreTemporaryCredential")
    def reset_client_store_temporary_credential(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetClientStoreTemporaryCredential", []))

    @jsii.member(jsii_name="resetClientTimeout")
    def reset_client_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetClientTimeout", []))

    @jsii.member(jsii_name="resetCrlAllowCertificatesWithoutCrlUrl")
    def reset_crl_allow_certificates_without_crl_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCrlAllowCertificatesWithoutCrlUrl", []))

    @jsii.member(jsii_name="resetCrlHttpClientTimeout")
    def reset_crl_http_client_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCrlHttpClientTimeout", []))

    @jsii.member(jsii_name="resetCrlInMemoryCacheDisabled")
    def reset_crl_in_memory_cache_disabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCrlInMemoryCacheDisabled", []))

    @jsii.member(jsii_name="resetCrlOnDiskCacheDisabled")
    def reset_crl_on_disk_cache_disabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCrlOnDiskCacheDisabled", []))

    @jsii.member(jsii_name="resetDisableConsoleLogin")
    def reset_disable_console_login(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableConsoleLogin", []))

    @jsii.member(jsii_name="resetDisableOcspChecks")
    def reset_disable_ocsp_checks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableOcspChecks", []))

    @jsii.member(jsii_name="resetDisableQueryContextCache")
    def reset_disable_query_context_cache(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableQueryContextCache", []))

    @jsii.member(jsii_name="resetDisableSamlUrlCheck")
    def reset_disable_saml_url_check(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableSamlUrlCheck", []))

    @jsii.member(jsii_name="resetDisableTelemetry")
    def reset_disable_telemetry(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableTelemetry", []))

    @jsii.member(jsii_name="resetDriverTracing")
    def reset_driver_tracing(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDriverTracing", []))

    @jsii.member(jsii_name="resetEnableSingleUseRefreshTokens")
    def reset_enable_single_use_refresh_tokens(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableSingleUseRefreshTokens", []))

    @jsii.member(jsii_name="resetExperimentalFeaturesEnabled")
    def reset_experimental_features_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExperimentalFeaturesEnabled", []))

    @jsii.member(jsii_name="resetExternalBrowserTimeout")
    def reset_external_browser_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExternalBrowserTimeout", []))

    @jsii.member(jsii_name="resetHost")
    def reset_host(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHost", []))

    @jsii.member(jsii_name="resetIncludeRetryReason")
    def reset_include_retry_reason(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIncludeRetryReason", []))

    @jsii.member(jsii_name="resetInsecureMode")
    def reset_insecure_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetInsecureMode", []))

    @jsii.member(jsii_name="resetJwtClientTimeout")
    def reset_jwt_client_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJwtClientTimeout", []))

    @jsii.member(jsii_name="resetJwtExpireTimeout")
    def reset_jwt_expire_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJwtExpireTimeout", []))

    @jsii.member(jsii_name="resetKeepSessionAlive")
    def reset_keep_session_alive(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKeepSessionAlive", []))

    @jsii.member(jsii_name="resetLoginTimeout")
    def reset_login_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoginTimeout", []))

    @jsii.member(jsii_name="resetLogQueryParameters")
    def reset_log_query_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLogQueryParameters", []))

    @jsii.member(jsii_name="resetLogQueryText")
    def reset_log_query_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLogQueryText", []))

    @jsii.member(jsii_name="resetMaxRetryCount")
    def reset_max_retry_count(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxRetryCount", []))

    @jsii.member(jsii_name="resetNoProxy")
    def reset_no_proxy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNoProxy", []))

    @jsii.member(jsii_name="resetOauthAuthorizationUrl")
    def reset_oauth_authorization_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthAuthorizationUrl", []))

    @jsii.member(jsii_name="resetOauthClientId")
    def reset_oauth_client_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthClientId", []))

    @jsii.member(jsii_name="resetOauthClientSecret")
    def reset_oauth_client_secret(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthClientSecret", []))

    @jsii.member(jsii_name="resetOauthRedirectUri")
    def reset_oauth_redirect_uri(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthRedirectUri", []))

    @jsii.member(jsii_name="resetOauthScope")
    def reset_oauth_scope(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthScope", []))

    @jsii.member(jsii_name="resetOauthTokenRequestUrl")
    def reset_oauth_token_request_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOauthTokenRequestUrl", []))

    @jsii.member(jsii_name="resetOcspFailOpen")
    def reset_ocsp_fail_open(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOcspFailOpen", []))

    @jsii.member(jsii_name="resetOktaUrl")
    def reset_okta_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOktaUrl", []))

    @jsii.member(jsii_name="resetOrganizationName")
    def reset_organization_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrganizationName", []))

    @jsii.member(jsii_name="resetParams")
    def reset_params(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParams", []))

    @jsii.member(jsii_name="resetPasscode")
    def reset_passcode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPasscode", []))

    @jsii.member(jsii_name="resetPasscodeInPassword")
    def reset_passcode_in_password(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPasscodeInPassword", []))

    @jsii.member(jsii_name="resetPassword")
    def reset_password(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPassword", []))

    @jsii.member(jsii_name="resetPort")
    def reset_port(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPort", []))

    @jsii.member(jsii_name="resetPreviewFeaturesEnabled")
    def reset_preview_features_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreviewFeaturesEnabled", []))

    @jsii.member(jsii_name="resetPrivateKey")
    def reset_private_key(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrivateKey", []))

    @jsii.member(jsii_name="resetPrivateKeyPassphrase")
    def reset_private_key_passphrase(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrivateKeyPassphrase", []))

    @jsii.member(jsii_name="resetProfile")
    def reset_profile(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProfile", []))

    @jsii.member(jsii_name="resetProtocol")
    def reset_protocol(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProtocol", []))

    @jsii.member(jsii_name="resetProxyHost")
    def reset_proxy_host(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProxyHost", []))

    @jsii.member(jsii_name="resetProxyPassword")
    def reset_proxy_password(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProxyPassword", []))

    @jsii.member(jsii_name="resetProxyPort")
    def reset_proxy_port(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProxyPort", []))

    @jsii.member(jsii_name="resetProxyProtocol")
    def reset_proxy_protocol(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProxyProtocol", []))

    @jsii.member(jsii_name="resetProxyUser")
    def reset_proxy_user(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProxyUser", []))

    @jsii.member(jsii_name="resetRequestTimeout")
    def reset_request_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequestTimeout", []))

    @jsii.member(jsii_name="resetRole")
    def reset_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRole", []))

    @jsii.member(jsii_name="resetSkipTomlFilePermissionVerification")
    def reset_skip_toml_file_permission_verification(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipTomlFilePermissionVerification", []))

    @jsii.member(jsii_name="resetTmpDirectoryPath")
    def reset_tmp_directory_path(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTmpDirectoryPath", []))

    @jsii.member(jsii_name="resetToken")
    def reset_token(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetToken", []))

    @jsii.member(jsii_name="resetTokenAccessor")
    def reset_token_accessor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTokenAccessor", []))

    @jsii.member(jsii_name="resetUseLegacyTomlFile")
    def reset_use_legacy_toml_file(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseLegacyTomlFile", []))

    @jsii.member(jsii_name="resetUser")
    def reset_user(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUser", []))

    @jsii.member(jsii_name="resetValidateDefaultParameters")
    def reset_validate_default_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetValidateDefaultParameters", []))

    @jsii.member(jsii_name="resetWarehouse")
    def reset_warehouse(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWarehouse", []))

    @jsii.member(jsii_name="resetWorkloadIdentityEntraResource")
    def reset_workload_identity_entra_resource(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWorkloadIdentityEntraResource", []))

    @jsii.member(jsii_name="resetWorkloadIdentityProvider")
    def reset_workload_identity_provider(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWorkloadIdentityProvider", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="accountNameInput")
    def account_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountNameInput"))

    @builtins.property
    @jsii.member(jsii_name="aliasInput")
    def alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aliasInput"))

    @builtins.property
    @jsii.member(jsii_name="authenticatorInput")
    def authenticator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "authenticatorInput"))

    @builtins.property
    @jsii.member(jsii_name="certRevocationCheckModeInput")
    def cert_revocation_check_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "certRevocationCheckModeInput"))

    @builtins.property
    @jsii.member(jsii_name="clientIpInput")
    def client_ip_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientIpInput"))

    @builtins.property
    @jsii.member(jsii_name="clientRequestMfaTokenInput")
    def client_request_mfa_token_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientRequestMfaTokenInput"))

    @builtins.property
    @jsii.member(jsii_name="clientStoreTemporaryCredentialInput")
    def client_store_temporary_credential_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientStoreTemporaryCredentialInput"))

    @builtins.property
    @jsii.member(jsii_name="clientTimeoutInput")
    def client_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "clientTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="crlAllowCertificatesWithoutCrlUrlInput")
    def crl_allow_certificates_without_crl_url_input(
        self,
    ) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "crlAllowCertificatesWithoutCrlUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="crlHttpClientTimeoutInput")
    def crl_http_client_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "crlHttpClientTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="crlInMemoryCacheDisabledInput")
    def crl_in_memory_cache_disabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "crlInMemoryCacheDisabledInput"))

    @builtins.property
    @jsii.member(jsii_name="crlOnDiskCacheDisabledInput")
    def crl_on_disk_cache_disabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "crlOnDiskCacheDisabledInput"))

    @builtins.property
    @jsii.member(jsii_name="disableConsoleLoginInput")
    def disable_console_login_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableConsoleLoginInput"))

    @builtins.property
    @jsii.member(jsii_name="disableOcspChecksInput")
    def disable_ocsp_checks_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableOcspChecksInput"))

    @builtins.property
    @jsii.member(jsii_name="disableQueryContextCacheInput")
    def disable_query_context_cache_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableQueryContextCacheInput"))

    @builtins.property
    @jsii.member(jsii_name="disableSamlUrlCheckInput")
    def disable_saml_url_check_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableSamlUrlCheckInput"))

    @builtins.property
    @jsii.member(jsii_name="disableTelemetryInput")
    def disable_telemetry_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableTelemetryInput"))

    @builtins.property
    @jsii.member(jsii_name="driverTracingInput")
    def driver_tracing_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "driverTracingInput"))

    @builtins.property
    @jsii.member(jsii_name="enableSingleUseRefreshTokensInput")
    def enable_single_use_refresh_tokens_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableSingleUseRefreshTokensInput"))

    @builtins.property
    @jsii.member(jsii_name="experimentalFeaturesEnabledInput")
    def experimental_features_enabled_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "experimentalFeaturesEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="externalBrowserTimeoutInput")
    def external_browser_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "externalBrowserTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="hostInput")
    def host_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "hostInput"))

    @builtins.property
    @jsii.member(jsii_name="includeRetryReasonInput")
    def include_retry_reason_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "includeRetryReasonInput"))

    @builtins.property
    @jsii.member(jsii_name="insecureModeInput")
    def insecure_mode_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "insecureModeInput"))

    @builtins.property
    @jsii.member(jsii_name="jwtClientTimeoutInput")
    def jwt_client_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "jwtClientTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="jwtExpireTimeoutInput")
    def jwt_expire_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "jwtExpireTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="keepSessionAliveInput")
    def keep_session_alive_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "keepSessionAliveInput"))

    @builtins.property
    @jsii.member(jsii_name="loginTimeoutInput")
    def login_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "loginTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="logQueryParametersInput")
    def log_query_parameters_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "logQueryParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="logQueryTextInput")
    def log_query_text_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "logQueryTextInput"))

    @builtins.property
    @jsii.member(jsii_name="maxRetryCountInput")
    def max_retry_count_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxRetryCountInput"))

    @builtins.property
    @jsii.member(jsii_name="noProxyInput")
    def no_proxy_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "noProxyInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthAuthorizationUrlInput")
    def oauth_authorization_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthAuthorizationUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthClientIdInput")
    def oauth_client_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthClientIdInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthClientSecretInput")
    def oauth_client_secret_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthClientSecretInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthRedirectUriInput")
    def oauth_redirect_uri_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthRedirectUriInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthScopeInput")
    def oauth_scope_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthScopeInput"))

    @builtins.property
    @jsii.member(jsii_name="oauthTokenRequestUrlInput")
    def oauth_token_request_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthTokenRequestUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="ocspFailOpenInput")
    def ocsp_fail_open_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ocspFailOpenInput"))

    @builtins.property
    @jsii.member(jsii_name="oktaUrlInput")
    def okta_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oktaUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="organizationNameInput")
    def organization_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "organizationNameInput"))

    @builtins.property
    @jsii.member(jsii_name="paramsInput")
    def params_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "paramsInput"))

    @builtins.property
    @jsii.member(jsii_name="passcodeInPasswordInput")
    def passcode_in_password_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "passcodeInPasswordInput"))

    @builtins.property
    @jsii.member(jsii_name="passcodeInput")
    def passcode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "passcodeInput"))

    @builtins.property
    @jsii.member(jsii_name="passwordInput")
    def password_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "passwordInput"))

    @builtins.property
    @jsii.member(jsii_name="portInput")
    def port_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "portInput"))

    @builtins.property
    @jsii.member(jsii_name="previewFeaturesEnabledInput")
    def preview_features_enabled_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "previewFeaturesEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="privateKeyInput")
    def private_key_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "privateKeyInput"))

    @builtins.property
    @jsii.member(jsii_name="privateKeyPassphraseInput")
    def private_key_passphrase_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "privateKeyPassphraseInput"))

    @builtins.property
    @jsii.member(jsii_name="profileInput")
    def profile_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "profileInput"))

    @builtins.property
    @jsii.member(jsii_name="protocolInput")
    def protocol_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "protocolInput"))

    @builtins.property
    @jsii.member(jsii_name="proxyHostInput")
    def proxy_host_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyHostInput"))

    @builtins.property
    @jsii.member(jsii_name="proxyPasswordInput")
    def proxy_password_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyPasswordInput"))

    @builtins.property
    @jsii.member(jsii_name="proxyPortInput")
    def proxy_port_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "proxyPortInput"))

    @builtins.property
    @jsii.member(jsii_name="proxyProtocolInput")
    def proxy_protocol_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyProtocolInput"))

    @builtins.property
    @jsii.member(jsii_name="proxyUserInput")
    def proxy_user_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyUserInput"))

    @builtins.property
    @jsii.member(jsii_name="requestTimeoutInput")
    def request_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "requestTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="roleInput")
    def role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "roleInput"))

    @builtins.property
    @jsii.member(jsii_name="skipTomlFilePermissionVerificationInput")
    def skip_toml_file_permission_verification_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "skipTomlFilePermissionVerificationInput"))

    @builtins.property
    @jsii.member(jsii_name="tmpDirectoryPathInput")
    def tmp_directory_path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tmpDirectoryPathInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenAccessorInput")
    def token_accessor_input(self) -> typing.Optional["SnowflakeProviderTokenAccessor"]:
        return typing.cast(typing.Optional["SnowflakeProviderTokenAccessor"], jsii.get(self, "tokenAccessorInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenInput")
    def token_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tokenInput"))

    @builtins.property
    @jsii.member(jsii_name="useLegacyTomlFileInput")
    def use_legacy_toml_file_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "useLegacyTomlFileInput"))

    @builtins.property
    @jsii.member(jsii_name="userInput")
    def user_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "userInput"))

    @builtins.property
    @jsii.member(jsii_name="validateDefaultParametersInput")
    def validate_default_parameters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "validateDefaultParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="warehouseInput")
    def warehouse_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "warehouseInput"))

    @builtins.property
    @jsii.member(jsii_name="workloadIdentityEntraResourceInput")
    def workload_identity_entra_resource_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "workloadIdentityEntraResourceInput"))

    @builtins.property
    @jsii.member(jsii_name="workloadIdentityProviderInput")
    def workload_identity_provider_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "workloadIdentityProviderInput"))

    @builtins.property
    @jsii.member(jsii_name="accountName")
    def account_name(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountName"))

    @account_name.setter
    def account_name(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03b387e559a7c5d1084110bf811384f98795d683f55e504dbf0d589ae9a9ac19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="alias")
    def alias(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alias"))

    @alias.setter
    def alias(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01918df4bf6852d4f8a177f550530eab13c80f8c721704c711e4270b3afd7866)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="authenticator")
    def authenticator(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "authenticator"))

    @authenticator.setter
    def authenticator(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97966a6181128178fb63175e0f1a2bdf6625ace6a52c77a53781b0c11efb5d7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "authenticator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="certRevocationCheckMode")
    def cert_revocation_check_mode(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "certRevocationCheckMode"))

    @cert_revocation_check_mode.setter
    def cert_revocation_check_mode(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88f4042d4d2e0087e5e2484e8d8d5eeefe7d1ccf458d947aa0fa29070e0f4966)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "certRevocationCheckMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="clientIp")
    def client_ip(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientIp"))

    @client_ip.setter
    def client_ip(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47e2005d0c5011e8d2e92bbcb7ec3ed036b98c9ed086337d874686a400d5a212)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "clientIp", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="clientRequestMfaToken")
    def client_request_mfa_token(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientRequestMfaToken"))

    @client_request_mfa_token.setter
    def client_request_mfa_token(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18b9ff9ba622e04e25d04d88d67e00e39f0885aef4ebac4fc835b887cd904fbe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "clientRequestMfaToken", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="clientStoreTemporaryCredential")
    def client_store_temporary_credential(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientStoreTemporaryCredential"))

    @client_store_temporary_credential.setter
    def client_store_temporary_credential(
        self,
        value: typing.Optional[builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e0c6478870695f78387091dbbf567bbcc850a14706850dc5709fae72ae12c72)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "clientStoreTemporaryCredential", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="clientTimeout")
    def client_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "clientTimeout"))

    @client_timeout.setter
    def client_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb6019430dfa3477c9300b87fd2b6fd3f106ef6642507c25fdc02c4230231248)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "clientTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="crlAllowCertificatesWithoutCrlUrl")
    def crl_allow_certificates_without_crl_url(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "crlAllowCertificatesWithoutCrlUrl"))

    @crl_allow_certificates_without_crl_url.setter
    def crl_allow_certificates_without_crl_url(
        self,
        value: typing.Optional[builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__052a329704542fa47a9e66b6dbca2997de90d7df84b3b3a4469162ca13f8f115)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "crlAllowCertificatesWithoutCrlUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="crlHttpClientTimeout")
    def crl_http_client_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "crlHttpClientTimeout"))

    @crl_http_client_timeout.setter
    def crl_http_client_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c0a9bb0688cdb379450c2ba8677186ff61e2697cc60ee5d256777b0cf70852d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "crlHttpClientTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="crlInMemoryCacheDisabled")
    def crl_in_memory_cache_disabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "crlInMemoryCacheDisabled"))

    @crl_in_memory_cache_disabled.setter
    def crl_in_memory_cache_disabled(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ea806b9be19f34ad4c9fb0c1d1f94407908ea325b6493b8f8c56a3645d360d4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "crlInMemoryCacheDisabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="crlOnDiskCacheDisabled")
    def crl_on_disk_cache_disabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "crlOnDiskCacheDisabled"))

    @crl_on_disk_cache_disabled.setter
    def crl_on_disk_cache_disabled(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f8f3d7398aa4146d3889e342ad00fd54254ecea4637bbf7fa3e0d60d218dbce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "crlOnDiskCacheDisabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableConsoleLogin")
    def disable_console_login(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableConsoleLogin"))

    @disable_console_login.setter
    def disable_console_login(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f3001681f4aa2f2c409562bde7f010d6301de4e275345f39229a90ab96d574da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableConsoleLogin", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableOcspChecks")
    def disable_ocsp_checks(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableOcspChecks"))

    @disable_ocsp_checks.setter
    def disable_ocsp_checks(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ddf71661734a6170f5c8f715ff87cf56f50484d5df990dc7403d6808f55387d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableOcspChecks", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableQueryContextCache")
    def disable_query_context_cache(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableQueryContextCache"))

    @disable_query_context_cache.setter
    def disable_query_context_cache(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ddd01de6bce3dec856b499532f643a9471f96abf3f9818890c496e667265b947)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableQueryContextCache", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableSamlUrlCheck")
    def disable_saml_url_check(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableSamlUrlCheck"))

    @disable_saml_url_check.setter
    def disable_saml_url_check(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4eba7b4d38fc8a8f456c68c5676222b1636587962836cef1b233da8fdbc562e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableSamlUrlCheck", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableTelemetry")
    def disable_telemetry(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "disableTelemetry"))

    @disable_telemetry.setter
    def disable_telemetry(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b323eaede07f1ae1045e1f9f00342b7b9283cb92ca825cc36173777a2a98ec9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableTelemetry", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="driverTracing")
    def driver_tracing(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "driverTracing"))

    @driver_tracing.setter
    def driver_tracing(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__814d3ff5f64e284fc577b2c65177432a449bbdc47fca95670e7c0c9fb4e767e5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "driverTracing", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableSingleUseRefreshTokens")
    def enable_single_use_refresh_tokens(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableSingleUseRefreshTokens"))

    @enable_single_use_refresh_tokens.setter
    def enable_single_use_refresh_tokens(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__000df4f6e3b4ad331c34bfd310cea32f21bbf4e6797803de4230f424f78dc20d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableSingleUseRefreshTokens", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="experimentalFeaturesEnabled")
    def experimental_features_enabled(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "experimentalFeaturesEnabled"))

    @experimental_features_enabled.setter
    def experimental_features_enabled(
        self,
        value: typing.Optional[typing.List[builtins.str]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d78067258c15b935505f9d02b276827aaed59049fb57e9d97e42f0220d372a08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "experimentalFeaturesEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="externalBrowserTimeout")
    def external_browser_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "externalBrowserTimeout"))

    @external_browser_timeout.setter
    def external_browser_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65597b05a209f93147eff5843a502787c9d71ff84151e5a0951031b749e61ceb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "externalBrowserTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="host")
    def host(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "host"))

    @host.setter
    def host(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69ecd001639eeef05c5cb7d77d299218d8afcc88dd8f4734fd878d4dd4fcbd16)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "host", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="includeRetryReason")
    def include_retry_reason(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "includeRetryReason"))

    @include_retry_reason.setter
    def include_retry_reason(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b31d1099e09e95cfb4212c35b2b744d35fdcdf5a225f71c1bf7b7e3a9290b273)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "includeRetryReason", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="insecureMode")
    def insecure_mode(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "insecureMode"))

    @insecure_mode.setter
    def insecure_mode(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__627ff05fee2fc8b17281b391582b59c048ad110c37b233584aa34057e54b6c2e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "insecureMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="jwtClientTimeout")
    def jwt_client_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "jwtClientTimeout"))

    @jwt_client_timeout.setter
    def jwt_client_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ee0893d1e609519ae040468cae68d866a29a1cc9f17069299f4c0156cda32e2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "jwtClientTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="jwtExpireTimeout")
    def jwt_expire_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "jwtExpireTimeout"))

    @jwt_expire_timeout.setter
    def jwt_expire_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00075aef5398d5d40dce90dd67c9d2b687d491917adec5d632b2938e7c501c54)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "jwtExpireTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="keepSessionAlive")
    def keep_session_alive(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "keepSessionAlive"))

    @keep_session_alive.setter
    def keep_session_alive(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__efb30fa5ad82887ba9c1e8ff7611868e8cbe97abf2ee4a8019d0228e9bb333d1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "keepSessionAlive", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="loginTimeout")
    def login_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "loginTimeout"))

    @login_timeout.setter
    def login_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76eb650a9c73f2dfd76b8eb4e42be8e1671f17bf584086234fec07fc60c0cd32)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "loginTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="logQueryParameters")
    def log_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "logQueryParameters"))

    @log_query_parameters.setter
    def log_query_parameters(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b997b1034a2d85fe2d8a5992ce2e9837010963839602bea5a11123d8213ad6e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "logQueryParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="logQueryText")
    def log_query_text(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "logQueryText"))

    @log_query_text.setter
    def log_query_text(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63b923a69371ef4e584b2878e2d9fe37077a707b56804f8586b771843a64aa15)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "logQueryText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxRetryCount")
    def max_retry_count(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxRetryCount"))

    @max_retry_count.setter
    def max_retry_count(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e94283e260e64f28788eab480216fb685ffe849db21601641f5cd5bb594fbaf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxRetryCount", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="noProxy")
    def no_proxy(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "noProxy"))

    @no_proxy.setter
    def no_proxy(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a33d1f453bbf71149bde3c30795f5ad60822a5bb93f4aa768fd5e98cd07b8bf7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "noProxy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthAuthorizationUrl")
    def oauth_authorization_url(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthAuthorizationUrl"))

    @oauth_authorization_url.setter
    def oauth_authorization_url(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bca6a701029ca0c0d61c346bb3df9470d3dba08e64c9c94bfb0d856acd66e275)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthAuthorizationUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthClientId")
    def oauth_client_id(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthClientId"))

    @oauth_client_id.setter
    def oauth_client_id(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2548410eb558edf788fb49ed6906037f301b123acf622b8cf560847853fe630f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthClientId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthClientSecret")
    def oauth_client_secret(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthClientSecret"))

    @oauth_client_secret.setter
    def oauth_client_secret(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d59a440849dcac6fd125d40f41fde115d315197bdb9b32b56b4999b31b659b15)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthClientSecret", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthRedirectUri")
    def oauth_redirect_uri(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthRedirectUri"))

    @oauth_redirect_uri.setter
    def oauth_redirect_uri(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40040dadc1ac41c0f4df004742a684cb1c3f8c2549742634f93369ef8b33ca6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthRedirectUri", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthScope")
    def oauth_scope(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthScope"))

    @oauth_scope.setter
    def oauth_scope(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d43e9af2a0b5594ec973b1ce9d16cc42391b810a26f3e075069c8e812676a284)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthScope", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oauthTokenRequestUrl")
    def oauth_token_request_url(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oauthTokenRequestUrl"))

    @oauth_token_request_url.setter
    def oauth_token_request_url(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ca4149c3ecd9b884e65523066da1d81b732abeca1dc77f1efeaa63850b3bb26)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oauthTokenRequestUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ocspFailOpen")
    def ocsp_fail_open(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ocspFailOpen"))

    @ocsp_fail_open.setter
    def ocsp_fail_open(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa43a52c5259bc0c00ad7efd8e72cf906b77bc6978fdf249ed85ffef2611a918)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ocspFailOpen", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="oktaUrl")
    def okta_url(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "oktaUrl"))

    @okta_url.setter
    def okta_url(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b9d66862d58848a99bf1796243ff496b1daa77c02193190ce82a7c3979eb3e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "oktaUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="organizationName")
    def organization_name(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "organizationName"))

    @organization_name.setter
    def organization_name(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8700beaabede1104e580fb8430fc09cbd4dd17dcf6c92231e84b55854829e09b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "organizationName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="params")
    def params(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "params"))

    @params.setter
    def params(
        self,
        value: typing.Optional[typing.Mapping[builtins.str, builtins.str]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4561b3d184a4f7f6d121114b5faf9f023c6439e40551dfaeb5bd489985733cf2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "params", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="passcode")
    def passcode(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "passcode"))

    @passcode.setter
    def passcode(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05eb729eeae80ddd878795de11b343e6a698ba59e4f74b674c4722c4840c90a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "passcode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="passcodeInPassword")
    def passcode_in_password(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "passcodeInPassword"))

    @passcode_in_password.setter
    def passcode_in_password(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f69df39dc0bb68ba452208c4a18ac801117f4a28acdbf719edbd8629f9b34bc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "passcodeInPassword", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="password")
    def password(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "password"))

    @password.setter
    def password(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed25e167e1d0c52555dd83d8a25dcbc90321e238013a47c154b5e677f7a40ac6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "password", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="port")
    def port(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "port"))

    @port.setter
    def port(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__926dfa62a7c399c3b8fe79d527206db7966dea2e9e7bd2600c486f1802a02ab5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "port", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="previewFeaturesEnabled")
    def preview_features_enabled(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "previewFeaturesEnabled"))

    @preview_features_enabled.setter
    def preview_features_enabled(
        self,
        value: typing.Optional[typing.List[builtins.str]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08de9d58ee40e0db49ea3271821e41d4efb091072ebe02779fe5ae65eb2a5f02)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "previewFeaturesEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="privateKey")
    def private_key(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "privateKey"))

    @private_key.setter
    def private_key(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76f17d9efaf46f24fb6e99273cf32d0c4c29cb8bfe1f7df57f8101bfcbd1f940)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "privateKey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="privateKeyPassphrase")
    def private_key_passphrase(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "privateKeyPassphrase"))

    @private_key_passphrase.setter
    def private_key_passphrase(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__752cd0aeb70ac67eef00c64e4a645a4f896c46e78c1d2ed17a204ba7a45b17e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "privateKeyPassphrase", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="profile")
    def profile(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "profile"))

    @profile.setter
    def profile(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02c94dc3335fdc09b8b541e204b14dcd56549a8ef61e628a2d3292d89726cac7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "profile", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="protocol")
    def protocol(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "protocol"))

    @protocol.setter
    def protocol(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba1940de9ae09d6122c85200f1f129b3996555689a6bf7361f881508a1f4d003)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "protocol", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="proxyHost")
    def proxy_host(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyHost"))

    @proxy_host.setter
    def proxy_host(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b25644b1f78e007a0e258c062400bf54a4476456783ab81f3dec773e63a65ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "proxyHost", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="proxyPassword")
    def proxy_password(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyPassword"))

    @proxy_password.setter
    def proxy_password(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c2edebbf57855b1aeeadd48d3ea32ada2ea9915d8e65ef894f5863252ab6f24)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "proxyPassword", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="proxyPort")
    def proxy_port(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "proxyPort"))

    @proxy_port.setter
    def proxy_port(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fe84f7a730f3f3eaa30214e782eefb8a58b34c236e1397a155ce282aa671382)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "proxyPort", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="proxyProtocol")
    def proxy_protocol(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyProtocol"))

    @proxy_protocol.setter
    def proxy_protocol(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__003750c89afb2cb693e437b0e2ab460176196348e1b0389b594e6086999d9a5f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "proxyProtocol", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="proxyUser")
    def proxy_user(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "proxyUser"))

    @proxy_user.setter
    def proxy_user(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e1c3f7290378dd17f45c90552da274afe348517103c217601de7cb026a101619)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "proxyUser", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requestTimeout")
    def request_timeout(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "requestTimeout"))

    @request_timeout.setter
    def request_timeout(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40de66ec410aac127afcb9c27ce567d4d060dca24d8c5a9dd201ee7cbf183a5b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requestTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="role")
    def role(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "role"))

    @role.setter
    def role(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae59f3ce6093e63b0c3c665876be61327f592c4a8aae5d1a665ec50473a4ec08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "role", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipTomlFilePermissionVerification")
    def skip_toml_file_permission_verification(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "skipTomlFilePermissionVerification"))

    @skip_toml_file_permission_verification.setter
    def skip_toml_file_permission_verification(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e67b72c57183dedc417ef7f414f0285e3852642a6bf6fcef15418b5f8b807a3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipTomlFilePermissionVerification", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tmpDirectoryPath")
    def tmp_directory_path(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tmpDirectoryPath"))

    @tmp_directory_path.setter
    def tmp_directory_path(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__843b1c3309daad02d3832fa9e3e22f90c45407328339e6f85acaf2cf5101eb69)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tmpDirectoryPath", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="token")
    def token(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "token"))

    @token.setter
    def token(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9288d41341c76d4af8a4724f7ebd53c84cbd12949ae8cfcaacf261cc6d6cf694)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "token", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tokenAccessor")
    def token_accessor(self) -> typing.Optional["SnowflakeProviderTokenAccessor"]:
        return typing.cast(typing.Optional["SnowflakeProviderTokenAccessor"], jsii.get(self, "tokenAccessor"))

    @token_accessor.setter
    def token_accessor(
        self,
        value: typing.Optional["SnowflakeProviderTokenAccessor"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a4e2d6829013432efb13d8278de7b76f7e69012792a900175a51ee0c718182c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tokenAccessor", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useLegacyTomlFile")
    def use_legacy_toml_file(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "useLegacyTomlFile"))

    @use_legacy_toml_file.setter
    def use_legacy_toml_file(
        self,
        value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a940d5c560528b536432565e4a614be76e87a4a6fb0da98e59e3aeb1731e77a2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useLegacyTomlFile", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="user")
    def user(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "user"))

    @user.setter
    def user(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c4e90f6f4be76a52332e02e7c2e2d6694806def3f30a7c4d93a4047ecdae8f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "user", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="validateDefaultParameters")
    def validate_default_parameters(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "validateDefaultParameters"))

    @validate_default_parameters.setter
    def validate_default_parameters(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cf7c21a99fb03855c6474f1ebc18d02857d81c45e4ff9e0814a129f73252440)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "validateDefaultParameters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="warehouse")
    def warehouse(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "warehouse"))

    @warehouse.setter
    def warehouse(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba091dc4e4d5430d5fd0fb1241260f9c8bce1d6d655a93b3c5c7ddfeffd81683)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "warehouse", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="workloadIdentityEntraResource")
    def workload_identity_entra_resource(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "workloadIdentityEntraResource"))

    @workload_identity_entra_resource.setter
    def workload_identity_entra_resource(
        self,
        value: typing.Optional[builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__722c88d139e0fef539fe7a2c455b635f297c640d9887e8ed46010e693a0ce100)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "workloadIdentityEntraResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="workloadIdentityProvider")
    def workload_identity_provider(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "workloadIdentityProvider"))

    @workload_identity_provider.setter
    def workload_identity_provider(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c468f152b24069a0ad470971196ade1fc2ec071355198a326bb8317c6001c28a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "workloadIdentityProvider", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.provider.SnowflakeProviderConfig",
    jsii_struct_bases=[],
    name_mapping={
        "account_name": "accountName",
        "alias": "alias",
        "authenticator": "authenticator",
        "cert_revocation_check_mode": "certRevocationCheckMode",
        "client_ip": "clientIp",
        "client_request_mfa_token": "clientRequestMfaToken",
        "client_store_temporary_credential": "clientStoreTemporaryCredential",
        "client_timeout": "clientTimeout",
        "crl_allow_certificates_without_crl_url": "crlAllowCertificatesWithoutCrlUrl",
        "crl_http_client_timeout": "crlHttpClientTimeout",
        "crl_in_memory_cache_disabled": "crlInMemoryCacheDisabled",
        "crl_on_disk_cache_disabled": "crlOnDiskCacheDisabled",
        "disable_console_login": "disableConsoleLogin",
        "disable_ocsp_checks": "disableOcspChecks",
        "disable_query_context_cache": "disableQueryContextCache",
        "disable_saml_url_check": "disableSamlUrlCheck",
        "disable_telemetry": "disableTelemetry",
        "driver_tracing": "driverTracing",
        "enable_single_use_refresh_tokens": "enableSingleUseRefreshTokens",
        "experimental_features_enabled": "experimentalFeaturesEnabled",
        "external_browser_timeout": "externalBrowserTimeout",
        "host": "host",
        "include_retry_reason": "includeRetryReason",
        "insecure_mode": "insecureMode",
        "jwt_client_timeout": "jwtClientTimeout",
        "jwt_expire_timeout": "jwtExpireTimeout",
        "keep_session_alive": "keepSessionAlive",
        "login_timeout": "loginTimeout",
        "log_query_parameters": "logQueryParameters",
        "log_query_text": "logQueryText",
        "max_retry_count": "maxRetryCount",
        "no_proxy": "noProxy",
        "oauth_authorization_url": "oauthAuthorizationUrl",
        "oauth_client_id": "oauthClientId",
        "oauth_client_secret": "oauthClientSecret",
        "oauth_redirect_uri": "oauthRedirectUri",
        "oauth_scope": "oauthScope",
        "oauth_token_request_url": "oauthTokenRequestUrl",
        "ocsp_fail_open": "ocspFailOpen",
        "okta_url": "oktaUrl",
        "organization_name": "organizationName",
        "params": "params",
        "passcode": "passcode",
        "passcode_in_password": "passcodeInPassword",
        "password": "password",
        "port": "port",
        "preview_features_enabled": "previewFeaturesEnabled",
        "private_key": "privateKey",
        "private_key_passphrase": "privateKeyPassphrase",
        "profile": "profile",
        "protocol": "protocol",
        "proxy_host": "proxyHost",
        "proxy_password": "proxyPassword",
        "proxy_port": "proxyPort",
        "proxy_protocol": "proxyProtocol",
        "proxy_user": "proxyUser",
        "request_timeout": "requestTimeout",
        "role": "role",
        "skip_toml_file_permission_verification": "skipTomlFilePermissionVerification",
        "tmp_directory_path": "tmpDirectoryPath",
        "token": "token",
        "token_accessor": "tokenAccessor",
        "use_legacy_toml_file": "useLegacyTomlFile",
        "user": "user",
        "validate_default_parameters": "validateDefaultParameters",
        "warehouse": "warehouse",
        "workload_identity_entra_resource": "workloadIdentityEntraResource",
        "workload_identity_provider": "workloadIdentityProvider",
    },
)
class SnowflakeProviderConfig:
    def __init__(
        self,
        *,
        account_name: typing.Optional[builtins.str] = None,
        alias: typing.Optional[builtins.str] = None,
        authenticator: typing.Optional[builtins.str] = None,
        cert_revocation_check_mode: typing.Optional[builtins.str] = None,
        client_ip: typing.Optional[builtins.str] = None,
        client_request_mfa_token: typing.Optional[builtins.str] = None,
        client_store_temporary_credential: typing.Optional[builtins.str] = None,
        client_timeout: typing.Optional[jsii.Number] = None,
        crl_allow_certificates_without_crl_url: typing.Optional[builtins.str] = None,
        crl_http_client_timeout: typing.Optional[jsii.Number] = None,
        crl_in_memory_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        crl_on_disk_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_console_login: typing.Optional[builtins.str] = None,
        disable_ocsp_checks: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_query_context_cache: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        disable_saml_url_check: typing.Optional[builtins.str] = None,
        disable_telemetry: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        driver_tracing: typing.Optional[builtins.str] = None,
        enable_single_use_refresh_tokens: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        experimental_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        external_browser_timeout: typing.Optional[jsii.Number] = None,
        host: typing.Optional[builtins.str] = None,
        include_retry_reason: typing.Optional[builtins.str] = None,
        insecure_mode: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        jwt_client_timeout: typing.Optional[jsii.Number] = None,
        jwt_expire_timeout: typing.Optional[jsii.Number] = None,
        keep_session_alive: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        login_timeout: typing.Optional[jsii.Number] = None,
        log_query_parameters: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        log_query_text: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        max_retry_count: typing.Optional[jsii.Number] = None,
        no_proxy: typing.Optional[builtins.str] = None,
        oauth_authorization_url: typing.Optional[builtins.str] = None,
        oauth_client_id: typing.Optional[builtins.str] = None,
        oauth_client_secret: typing.Optional[builtins.str] = None,
        oauth_redirect_uri: typing.Optional[builtins.str] = None,
        oauth_scope: typing.Optional[builtins.str] = None,
        oauth_token_request_url: typing.Optional[builtins.str] = None,
        ocsp_fail_open: typing.Optional[builtins.str] = None,
        okta_url: typing.Optional[builtins.str] = None,
        organization_name: typing.Optional[builtins.str] = None,
        params: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        passcode: typing.Optional[builtins.str] = None,
        passcode_in_password: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        password: typing.Optional[builtins.str] = None,
        port: typing.Optional[jsii.Number] = None,
        preview_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        private_key: typing.Optional[builtins.str] = None,
        private_key_passphrase: typing.Optional[builtins.str] = None,
        profile: typing.Optional[builtins.str] = None,
        protocol: typing.Optional[builtins.str] = None,
        proxy_host: typing.Optional[builtins.str] = None,
        proxy_password: typing.Optional[builtins.str] = None,
        proxy_port: typing.Optional[jsii.Number] = None,
        proxy_protocol: typing.Optional[builtins.str] = None,
        proxy_user: typing.Optional[builtins.str] = None,
        request_timeout: typing.Optional[jsii.Number] = None,
        role: typing.Optional[builtins.str] = None,
        skip_toml_file_permission_verification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        tmp_directory_path: typing.Optional[builtins.str] = None,
        token: typing.Optional[builtins.str] = None,
        token_accessor: typing.Optional[typing.Union["SnowflakeProviderTokenAccessor", typing.Dict[builtins.str, typing.Any]]] = None,
        use_legacy_toml_file: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        user: typing.Optional[builtins.str] = None,
        validate_default_parameters: typing.Optional[builtins.str] = None,
        warehouse: typing.Optional[builtins.str] = None,
        workload_identity_entra_resource: typing.Optional[builtins.str] = None,
        workload_identity_provider: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_name: Specifies your Snowflake account name assigned by Snowflake. For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#account-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ACCOUNT_NAME`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#account_name SnowflakeProvider#account_name}
        :param alias: Alias name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#alias SnowflakeProvider#alias}
        :param authenticator: Specifies the `authentication type <https://pkg.go.dev/github.com/snowflakedb/gosnowflake#AuthType>`_ to use when connecting to Snowflake. Valid options are: ``SNOWFLAKE`` | ``OAUTH`` | ``EXTERNALBROWSER`` | ``OKTA`` | ``SNOWFLAKE_JWT`` | ``TOKENACCESSOR`` | ``USERNAMEPASSWORDMFA`` | ``PROGRAMMATIC_ACCESS_TOKEN`` | ``OAUTH_CLIENT_CREDENTIALS`` | ``OAUTH_AUTHORIZATION_CODE`` | ``WORKLOAD_IDENTITY``. Can also be sourced from the ``SNOWFLAKE_AUTHENTICATOR`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#authenticator SnowflakeProvider#authenticator}
        :param cert_revocation_check_mode: Specifies the certificate revocation check mode. Valid options are: ``DISABLED`` | ``ADVISORY`` | ``ENABLED``. The value is case-insensitive. Can also be sourced from the ``SNOWFLAKE_CERT_REVOCATION_CHECK_MODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#cert_revocation_check_mode SnowflakeProvider#cert_revocation_check_mode}
        :param client_ip: IP address for network checks. Can also be sourced from the ``SNOWFLAKE_CLIENT_IP`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_ip SnowflakeProvider#client_ip}
        :param client_request_mfa_token: When true the MFA token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_REQUEST_MFA_TOKEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_request_mfa_token SnowflakeProvider#client_request_mfa_token}
        :param client_store_temporary_credential: When true the ID token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_store_temporary_credential SnowflakeProvider#client_store_temporary_credential}
        :param client_timeout: The timeout in seconds for the client to complete the authentication. Can also be sourced from the ``SNOWFLAKE_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_timeout SnowflakeProvider#client_timeout}
        :param crl_allow_certificates_without_crl_url: Allow certificates (not short-lived) without CRL DP included to be treated as correct ones. Can also be sourced from the ``SNOWFLAKE_CRL_ALLOW_CERTIFICATES_WITHOUT_CRL_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_allow_certificates_without_crl_url SnowflakeProvider#crl_allow_certificates_without_crl_url}
        :param crl_http_client_timeout: Timeout in seconds for HTTP client used to download CRL. Can also be sourced from the ``SNOWFLAKE_CRL_HTTP_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_http_client_timeout SnowflakeProvider#crl_http_client_timeout}
        :param crl_in_memory_cache_disabled: False by default. When set to true, the CRL in-memory cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_IN_MEMORY_CACHE_DISABLED`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_in_memory_cache_disabled SnowflakeProvider#crl_in_memory_cache_disabled}
        :param crl_on_disk_cache_disabled: False by default. When set to true, the CRL on-disk cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_ON_DISK_CACHE_DISABLED`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_on_disk_cache_disabled SnowflakeProvider#crl_on_disk_cache_disabled}
        :param disable_console_login: Indicates whether console login should be disabled in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_CONSOLE_LOGIN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_console_login SnowflakeProvider#disable_console_login}
        :param disable_ocsp_checks: False by default. When set to true, the driver doesn't check certificate revocation status. Can also be sourced from the ``SNOWFLAKE_DISABLE_OCSP_CHECKS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_ocsp_checks SnowflakeProvider#disable_ocsp_checks}
        :param disable_query_context_cache: Disables HTAP query context cache in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_QUERY_CONTEXT_CACHE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_query_context_cache SnowflakeProvider#disable_query_context_cache}
        :param disable_saml_url_check: Indicates whether the SAML URL check should be disabled. Can also be sourced from the ``SNOWFLAKE_DISABLE_SAML_URL_CHECK`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_saml_url_check SnowflakeProvider#disable_saml_url_check}
        :param disable_telemetry: Disables telemetry in the driver. Can also be sourced from the ``DISABLE_TELEMETRY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_telemetry SnowflakeProvider#disable_telemetry}
        :param driver_tracing: Specifies the logging level to be used by the driver. Valid options are: ``trace`` | ``debug`` | ``info`` | ``print`` | ``warning`` | ``error`` | ``fatal`` | ``panic``. Can also be sourced from the ``SNOWFLAKE_DRIVER_TRACING`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#driver_tracing SnowflakeProvider#driver_tracing}
        :param enable_single_use_refresh_tokens: Enables single use refresh tokens for Snowflake IdP. Can also be sourced from the ``SNOWFLAKE_ENABLE_SINGLE_USE_REFRESH_TOKENS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#enable_single_use_refresh_tokens SnowflakeProvider#enable_single_use_refresh_tokens}
        :param experimental_features_enabled: A list of experimental features. Similarly to preview features, they are not yet stable features of the provider. Enabling given experiment is still considered a preview feature, even when applied to the stable resource. These switches offer experiments altering the provider behavior. If the given experiment is successful, it can be considered an addition in the future provider versions. This field can not be set with environmental variables. Check more details in the `experimental features section <#experimental-features>`_. Active experiments are: ``WAREHOUSE_SHOW_IMPROVED_PERFORMANCE`` | ``GRANTS_STRICT_PRIVILEGE_MANAGEMENT`` | ``PARAMETERS_IGNORE_VALUE_CHANGES_IF_NOT_ON_OBJECT_LEVEL`` | ``PARAMETERS_REDUCED_OUTPUT`` | ``USER_ENABLE_DEFAULT_WORKLOAD_IDENTITY``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#experimental_features_enabled SnowflakeProvider#experimental_features_enabled}
        :param external_browser_timeout: The timeout in seconds for the external browser to complete the authentication. Can also be sourced from the ``SNOWFLAKE_EXTERNAL_BROWSER_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#external_browser_timeout SnowflakeProvider#external_browser_timeout}
        :param host: Specifies a custom host value used by the driver for privatelink connections. Can also be sourced from the ``SNOWFLAKE_HOST`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#host SnowflakeProvider#host}
        :param include_retry_reason: Should retried request contain retry reason. Can also be sourced from the ``SNOWFLAKE_INCLUDE_RETRY_REASON`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#include_retry_reason SnowflakeProvider#include_retry_reason}
        :param insecure_mode: This field is deprecated. Use ``disable_ocsp_checks`` instead. If true, bypass the Online Certificate Status Protocol (OCSP) certificate revocation check. IMPORTANT: Change the default value for testing or emergency situations only. Can also be sourced from the ``SNOWFLAKE_INSECURE_MODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#insecure_mode SnowflakeProvider#insecure_mode}
        :param jwt_client_timeout: The timeout in seconds for the JWT client to complete the authentication. Can also be sourced from the ``SNOWFLAKE_JWT_CLIENT_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_client_timeout SnowflakeProvider#jwt_client_timeout}
        :param jwt_expire_timeout: JWT expire after timeout in seconds. Can also be sourced from the ``SNOWFLAKE_JWT_EXPIRE_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_expire_timeout SnowflakeProvider#jwt_expire_timeout}
        :param keep_session_alive: Enables the session to persist even after the connection is closed. Can also be sourced from the ``SNOWFLAKE_KEEP_SESSION_ALIVE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#keep_session_alive SnowflakeProvider#keep_session_alive}
        :param login_timeout: Login retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the ``SNOWFLAKE_LOGIN_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#login_timeout SnowflakeProvider#login_timeout}
        :param log_query_parameters: When set to true, the parameters will be logged. Requires logQueryText to be enabled first. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_PARAMETERS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_parameters SnowflakeProvider#log_query_parameters}
        :param log_query_text: When set to true, the full query text will be logged. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_TEXT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_text SnowflakeProvider#log_query_text}
        :param max_retry_count: Specifies how many times non-periodic HTTP request can be retried by the driver. Can also be sourced from the ``SNOWFLAKE_MAX_RETRY_COUNT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#max_retry_count SnowflakeProvider#max_retry_count}
        :param no_proxy: A comma-separated list of hostnames, domains, and IP addresses to exclude from proxying. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_NO_PROXY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#no_proxy SnowflakeProvider#no_proxy}
        :param oauth_authorization_url: Authorization URL of OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_AUTHORIZATION_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_authorization_url SnowflakeProvider#oauth_authorization_url}
        :param oauth_client_id: Client id for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_ID`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_id SnowflakeProvider#oauth_client_id}
        :param oauth_client_secret: Client secret for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_SECRET`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_secret SnowflakeProvider#oauth_client_secret}
        :param oauth_redirect_uri: Redirect URI registered in IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_REDIRECT_URI`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_redirect_uri SnowflakeProvider#oauth_redirect_uri}
        :param oauth_scope: Comma separated list of scopes. If empty it is derived from role. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_SCOPE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_scope SnowflakeProvider#oauth_scope}
        :param oauth_token_request_url: Token request URL of OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_TOKEN_REQUEST_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_token_request_url SnowflakeProvider#oauth_token_request_url}
        :param ocsp_fail_open: True represents OCSP fail open mode. False represents OCSP fail closed mode. Fail open true by default. Can also be sourced from the ``SNOWFLAKE_OCSP_FAIL_OPEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#ocsp_fail_open SnowflakeProvider#ocsp_fail_open}
        :param okta_url: The URL of the Okta server. e.g. https://example.okta.com. Okta URL host needs to to have a suffix ``okta.com``. Read more in Snowflake `docs <https://docs.snowflake.com/en/user-guide/oauth-okta>`_. Can also be sourced from the ``SNOWFLAKE_OKTA_URL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#okta_url SnowflakeProvider#okta_url}
        :param organization_name: Specifies your Snowflake organization name assigned by Snowflake. For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#organization-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ORGANIZATION_NAME`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#organization_name SnowflakeProvider#organization_name}
        :param params: Sets other connection (i.e. session) parameters. `Parameters <https://docs.snowflake.com/en/sql-reference/parameters>`_. This field can not be set with environmental variables. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#params SnowflakeProvider#params}
        :param passcode: Specifies the passcode provided by Duo when using multi-factor authentication (MFA) for login. Can also be sourced from the ``SNOWFLAKE_PASSCODE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode SnowflakeProvider#passcode}
        :param passcode_in_password: False by default. Set to true if the MFA passcode is embedded to the configured password. Can also be sourced from the ``SNOWFLAKE_PASSCODE_IN_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode_in_password SnowflakeProvider#passcode_in_password}
        :param password: Password for user + password or `token <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens#generating-a-programmatic-access-token>`_ for `PAT auth <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens>`_. Cannot be used with ``private_key`` and ``private_key_passphrase``. Can also be sourced from the ``SNOWFLAKE_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#password SnowflakeProvider#password}
        :param port: Specifies a custom port value used by the driver for privatelink connections. Can also be sourced from the ``SNOWFLAKE_PORT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#port SnowflakeProvider#port}
        :param preview_features_enabled: A list of preview features that are handled by the provider. See `preview features list <https://github.com/Snowflake-Labs/terraform-provider-snowflake/blob/main/v1-preparations/LIST_OF_PREVIEW_FEATURES_FOR_V1.md>`_. Preview features may have breaking changes in future releases, even without raising the major version. This field can not be set with environmental variables. Preview features that can be enabled are: ``snowflake_account_authentication_policy_attachment_resource`` | ``snowflake_account_password_policy_attachment_resource`` | ``snowflake_alert_resource`` | ``snowflake_alerts_datasource`` | ``snowflake_api_integration_resource`` | ``snowflake_authentication_policy_resource`` | ``snowflake_authentication_policies_datasource`` | ``snowflake_cortex_search_service_resource`` | ``snowflake_cortex_search_services_datasource`` | ``snowflake_current_account_resource`` | ``snowflake_current_account_datasource`` | ``snowflake_current_organization_account_resource`` | ``snowflake_database_datasource`` | ``snowflake_database_role_datasource`` | ``snowflake_dynamic_table_resource`` | ``snowflake_dynamic_tables_datasource`` | ``snowflake_stage_external_azure_resource`` | ``snowflake_external_function_resource`` | ``snowflake_external_functions_datasource`` | ``snowflake_stage_external_gcs_resource`` | ``snowflake_stage_external_s3_resource`` | ``snowflake_stage_external_s3_compatible_resource`` | ``snowflake_external_table_resource`` | ``snowflake_external_tables_datasource`` | ``snowflake_external_volume_resource`` | ``snowflake_failover_group_resource`` | ``snowflake_failover_groups_datasource`` | ``snowflake_file_format_resource`` | ``snowflake_file_formats_datasource`` | ``snowflake_function_java_resource`` | ``snowflake_function_javascript_resource`` | ``snowflake_function_python_resource`` | ``snowflake_function_scala_resource`` | ``snowflake_function_sql_resource`` | ``snowflake_functions_datasource`` | ``snowflake_stage_internal_resource`` | ``snowflake_job_service_resource`` | ``snowflake_listings_datasource`` | ``snowflake_managed_account_resource`` | ``snowflake_materialized_view_resource`` | ``snowflake_materialized_views_datasource`` | ``snowflake_network_policy_attachment_resource`` | ``snowflake_network_rule_resource`` | ``snowflake_notebook_resource`` | ``snowflake_notebooks_datasource`` | ``snowflake_email_notification_integration_resource`` | ``snowflake_notification_integration_resource`` | ``snowflake_object_parameter_resource`` | ``snowflake_password_policy_resource`` | ``snowflake_pipe_resource`` | ``snowflake_pipes_datasource`` | ``snowflake_current_role_datasource`` | ``snowflake_semantic_view_resource`` | ``snowflake_semantic_views_datasource`` | ``snowflake_sequence_resource`` | ``snowflake_sequences_datasource`` | ``snowflake_share_resource`` | ``snowflake_shares_datasource`` | ``snowflake_parameters_datasource`` | ``snowflake_procedure_java_resource`` | ``snowflake_procedure_javascript_resource`` | ``snowflake_procedure_python_resource`` | ``snowflake_procedure_scala_resource`` | ``snowflake_procedure_sql_resource`` | ``snowflake_procedures_datasource`` | ``snowflake_stage_resource`` | ``snowflake_stages_datasource`` | ``snowflake_storage_integration_resource`` | ``snowflake_storage_integration_aws_resource`` | ``snowflake_storage_integration_azure_resource`` | ``snowflake_storage_integration_gcs_resource`` | ``snowflake_storage_integrations_datasource`` | ``snowflake_system_generate_scim_access_token_datasource`` | ``snowflake_system_get_aws_sns_iam_policy_datasource`` | ``snowflake_system_get_privatelink_config_datasource`` | ``snowflake_system_get_snowflake_platform_info_datasource`` | ``snowflake_table_column_masking_policy_application_resource`` | ``snowflake_table_constraint_resource`` | ``snowflake_table_resource`` | ``snowflake_tables_datasource`` | ``snowflake_user_authentication_policy_attachment_resource`` | ``snowflake_user_public_keys_resource`` | ``snowflake_user_password_policy_attachment_resource``. Promoted features that are stable and are enabled by default are: ``snowflake_compute_pool_resource`` | ``snowflake_compute_pools_datasource`` | ``snowflake_git_repository_resource`` | ``snowflake_git_repositories_datasource`` | ``snowflake_image_repository_resource`` | ``snowflake_image_repositories_datasource`` | ``snowflake_listing_resource`` | ``snowflake_service_resource`` | ``snowflake_services_datasource`` | ``snowflake_user_programmatic_access_token_resource`` | ``snowflake_user_programmatic_access_tokens_datasource``. Promoted features can be safely removed from this field. They will be removed in the next major version. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#preview_features_enabled SnowflakeProvider#preview_features_enabled}
        :param private_key: Private Key for username+private-key auth. Cannot be used with ``password``. Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key SnowflakeProvider#private_key}
        :param private_key_passphrase: Supports the encryption ciphers aes-128-cbc, aes-128-gcm, aes-192-cbc, aes-192-gcm, aes-256-cbc, aes-256-gcm, and des-ede3-cbc. Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY_PASSPHRASE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key_passphrase SnowflakeProvider#private_key_passphrase}
        :param profile: Sets the profile to read from ~/.snowflake/config file. Can also be sourced from the ``SNOWFLAKE_PROFILE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#profile SnowflakeProvider#profile}
        :param protocol: A protocol used in the connection. Valid options are: ``http`` | ``https``. Can also be sourced from the ``SNOWFLAKE_PROTOCOL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#protocol SnowflakeProvider#protocol}
        :param proxy_host: The host of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_HOST`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_host SnowflakeProvider#proxy_host}
        :param proxy_password: The password of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PASSWORD`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_password SnowflakeProvider#proxy_password}
        :param proxy_port: The port of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PORT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_port SnowflakeProvider#proxy_port}
        :param proxy_protocol: The protocol of the proxy to use for the connection. Valid options are: ``http`` | ``https``. The value is case-insensitive. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PROTOCOL`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_protocol SnowflakeProvider#proxy_protocol}
        :param proxy_user: The user of the proxy to use for the connection. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_USER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_user SnowflakeProvider#proxy_user}
        :param request_timeout: request retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the ``SNOWFLAKE_REQUEST_TIMEOUT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#request_timeout SnowflakeProvider#request_timeout}
        :param role: Specifies the role to use by default for accessing Snowflake objects in the client session. Can also be sourced from the ``SNOWFLAKE_ROLE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#role SnowflakeProvider#role}
        :param skip_toml_file_permission_verification: False by default. Skips TOML configuration file permission verification. This flag has no effect on Windows systems, as the permissions are not checked on this platform. Instead of skipping the permissions verification, we recommend setting the proper privileges - see `the section below <#toml-file-limitations>`_. Can also be sourced from the ``SNOWFLAKE_SKIP_TOML_FILE_PERMISSION_VERIFICATION`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#skip_toml_file_permission_verification SnowflakeProvider#skip_toml_file_permission_verification}
        :param tmp_directory_path: Sets temporary directory used by the driver for operations like encrypting, compressing etc. Can also be sourced from the ``SNOWFLAKE_TMP_DIRECTORY_PATH`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#tmp_directory_path SnowflakeProvider#tmp_directory_path}
        :param token: Token to use for OAuth and other forms of token based auth. When this field is set here, or in the TOML file, the provider sets the ``authenticator`` to ``OAUTH``. Optionally, set the ``authenticator`` field to the authenticator you want to use. Can also be sourced from the ``SNOWFLAKE_TOKEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token SnowflakeProvider#token}
        :param token_accessor: token_accessor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token_accessor SnowflakeProvider#token_accessor}
        :param use_legacy_toml_file: False by default. When this is set to true, the provider expects the legacy TOML format. Otherwise, it expects the new format. See more in `the section below <#examples>`_ Can also be sourced from the ``SNOWFLAKE_USE_LEGACY_TOML_FILE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#use_legacy_toml_file SnowflakeProvider#use_legacy_toml_file}
        :param user: Username. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_USER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#user SnowflakeProvider#user}
        :param validate_default_parameters: True by default. If false, disables the validation checks for Database, Schema, Warehouse and Role at the time a connection is established. Can also be sourced from the ``SNOWFLAKE_VALIDATE_DEFAULT_PARAMETERS`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#validate_default_parameters SnowflakeProvider#validate_default_parameters}
        :param warehouse: Specifies the virtual warehouse to use by default for queries, loading, etc. in the client session. Can also be sourced from the ``SNOWFLAKE_WAREHOUSE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#warehouse SnowflakeProvider#warehouse}
        :param workload_identity_entra_resource: The resource to use for WIF authentication on Azure environment. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_ENTRA_RESOURCE`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_entra_resource SnowflakeProvider#workload_identity_entra_resource}
        :param workload_identity_provider: The workload identity provider to use for WIF authentication. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_PROVIDER`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_provider SnowflakeProvider#workload_identity_provider}
        '''
        if isinstance(token_accessor, dict):
            token_accessor = SnowflakeProviderTokenAccessor(**token_accessor)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c375c9b327e9ce8b32d1d503169561f636f352a30a09351e145d81f5d4fec9ad)
            check_type(argname="argument account_name", value=account_name, expected_type=type_hints["account_name"])
            check_type(argname="argument alias", value=alias, expected_type=type_hints["alias"])
            check_type(argname="argument authenticator", value=authenticator, expected_type=type_hints["authenticator"])
            check_type(argname="argument cert_revocation_check_mode", value=cert_revocation_check_mode, expected_type=type_hints["cert_revocation_check_mode"])
            check_type(argname="argument client_ip", value=client_ip, expected_type=type_hints["client_ip"])
            check_type(argname="argument client_request_mfa_token", value=client_request_mfa_token, expected_type=type_hints["client_request_mfa_token"])
            check_type(argname="argument client_store_temporary_credential", value=client_store_temporary_credential, expected_type=type_hints["client_store_temporary_credential"])
            check_type(argname="argument client_timeout", value=client_timeout, expected_type=type_hints["client_timeout"])
            check_type(argname="argument crl_allow_certificates_without_crl_url", value=crl_allow_certificates_without_crl_url, expected_type=type_hints["crl_allow_certificates_without_crl_url"])
            check_type(argname="argument crl_http_client_timeout", value=crl_http_client_timeout, expected_type=type_hints["crl_http_client_timeout"])
            check_type(argname="argument crl_in_memory_cache_disabled", value=crl_in_memory_cache_disabled, expected_type=type_hints["crl_in_memory_cache_disabled"])
            check_type(argname="argument crl_on_disk_cache_disabled", value=crl_on_disk_cache_disabled, expected_type=type_hints["crl_on_disk_cache_disabled"])
            check_type(argname="argument disable_console_login", value=disable_console_login, expected_type=type_hints["disable_console_login"])
            check_type(argname="argument disable_ocsp_checks", value=disable_ocsp_checks, expected_type=type_hints["disable_ocsp_checks"])
            check_type(argname="argument disable_query_context_cache", value=disable_query_context_cache, expected_type=type_hints["disable_query_context_cache"])
            check_type(argname="argument disable_saml_url_check", value=disable_saml_url_check, expected_type=type_hints["disable_saml_url_check"])
            check_type(argname="argument disable_telemetry", value=disable_telemetry, expected_type=type_hints["disable_telemetry"])
            check_type(argname="argument driver_tracing", value=driver_tracing, expected_type=type_hints["driver_tracing"])
            check_type(argname="argument enable_single_use_refresh_tokens", value=enable_single_use_refresh_tokens, expected_type=type_hints["enable_single_use_refresh_tokens"])
            check_type(argname="argument experimental_features_enabled", value=experimental_features_enabled, expected_type=type_hints["experimental_features_enabled"])
            check_type(argname="argument external_browser_timeout", value=external_browser_timeout, expected_type=type_hints["external_browser_timeout"])
            check_type(argname="argument host", value=host, expected_type=type_hints["host"])
            check_type(argname="argument include_retry_reason", value=include_retry_reason, expected_type=type_hints["include_retry_reason"])
            check_type(argname="argument insecure_mode", value=insecure_mode, expected_type=type_hints["insecure_mode"])
            check_type(argname="argument jwt_client_timeout", value=jwt_client_timeout, expected_type=type_hints["jwt_client_timeout"])
            check_type(argname="argument jwt_expire_timeout", value=jwt_expire_timeout, expected_type=type_hints["jwt_expire_timeout"])
            check_type(argname="argument keep_session_alive", value=keep_session_alive, expected_type=type_hints["keep_session_alive"])
            check_type(argname="argument login_timeout", value=login_timeout, expected_type=type_hints["login_timeout"])
            check_type(argname="argument log_query_parameters", value=log_query_parameters, expected_type=type_hints["log_query_parameters"])
            check_type(argname="argument log_query_text", value=log_query_text, expected_type=type_hints["log_query_text"])
            check_type(argname="argument max_retry_count", value=max_retry_count, expected_type=type_hints["max_retry_count"])
            check_type(argname="argument no_proxy", value=no_proxy, expected_type=type_hints["no_proxy"])
            check_type(argname="argument oauth_authorization_url", value=oauth_authorization_url, expected_type=type_hints["oauth_authorization_url"])
            check_type(argname="argument oauth_client_id", value=oauth_client_id, expected_type=type_hints["oauth_client_id"])
            check_type(argname="argument oauth_client_secret", value=oauth_client_secret, expected_type=type_hints["oauth_client_secret"])
            check_type(argname="argument oauth_redirect_uri", value=oauth_redirect_uri, expected_type=type_hints["oauth_redirect_uri"])
            check_type(argname="argument oauth_scope", value=oauth_scope, expected_type=type_hints["oauth_scope"])
            check_type(argname="argument oauth_token_request_url", value=oauth_token_request_url, expected_type=type_hints["oauth_token_request_url"])
            check_type(argname="argument ocsp_fail_open", value=ocsp_fail_open, expected_type=type_hints["ocsp_fail_open"])
            check_type(argname="argument okta_url", value=okta_url, expected_type=type_hints["okta_url"])
            check_type(argname="argument organization_name", value=organization_name, expected_type=type_hints["organization_name"])
            check_type(argname="argument params", value=params, expected_type=type_hints["params"])
            check_type(argname="argument passcode", value=passcode, expected_type=type_hints["passcode"])
            check_type(argname="argument passcode_in_password", value=passcode_in_password, expected_type=type_hints["passcode_in_password"])
            check_type(argname="argument password", value=password, expected_type=type_hints["password"])
            check_type(argname="argument port", value=port, expected_type=type_hints["port"])
            check_type(argname="argument preview_features_enabled", value=preview_features_enabled, expected_type=type_hints["preview_features_enabled"])
            check_type(argname="argument private_key", value=private_key, expected_type=type_hints["private_key"])
            check_type(argname="argument private_key_passphrase", value=private_key_passphrase, expected_type=type_hints["private_key_passphrase"])
            check_type(argname="argument profile", value=profile, expected_type=type_hints["profile"])
            check_type(argname="argument protocol", value=protocol, expected_type=type_hints["protocol"])
            check_type(argname="argument proxy_host", value=proxy_host, expected_type=type_hints["proxy_host"])
            check_type(argname="argument proxy_password", value=proxy_password, expected_type=type_hints["proxy_password"])
            check_type(argname="argument proxy_port", value=proxy_port, expected_type=type_hints["proxy_port"])
            check_type(argname="argument proxy_protocol", value=proxy_protocol, expected_type=type_hints["proxy_protocol"])
            check_type(argname="argument proxy_user", value=proxy_user, expected_type=type_hints["proxy_user"])
            check_type(argname="argument request_timeout", value=request_timeout, expected_type=type_hints["request_timeout"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
            check_type(argname="argument skip_toml_file_permission_verification", value=skip_toml_file_permission_verification, expected_type=type_hints["skip_toml_file_permission_verification"])
            check_type(argname="argument tmp_directory_path", value=tmp_directory_path, expected_type=type_hints["tmp_directory_path"])
            check_type(argname="argument token", value=token, expected_type=type_hints["token"])
            check_type(argname="argument token_accessor", value=token_accessor, expected_type=type_hints["token_accessor"])
            check_type(argname="argument use_legacy_toml_file", value=use_legacy_toml_file, expected_type=type_hints["use_legacy_toml_file"])
            check_type(argname="argument user", value=user, expected_type=type_hints["user"])
            check_type(argname="argument validate_default_parameters", value=validate_default_parameters, expected_type=type_hints["validate_default_parameters"])
            check_type(argname="argument warehouse", value=warehouse, expected_type=type_hints["warehouse"])
            check_type(argname="argument workload_identity_entra_resource", value=workload_identity_entra_resource, expected_type=type_hints["workload_identity_entra_resource"])
            check_type(argname="argument workload_identity_provider", value=workload_identity_provider, expected_type=type_hints["workload_identity_provider"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account_name is not None:
            self._values["account_name"] = account_name
        if alias is not None:
            self._values["alias"] = alias
        if authenticator is not None:
            self._values["authenticator"] = authenticator
        if cert_revocation_check_mode is not None:
            self._values["cert_revocation_check_mode"] = cert_revocation_check_mode
        if client_ip is not None:
            self._values["client_ip"] = client_ip
        if client_request_mfa_token is not None:
            self._values["client_request_mfa_token"] = client_request_mfa_token
        if client_store_temporary_credential is not None:
            self._values["client_store_temporary_credential"] = client_store_temporary_credential
        if client_timeout is not None:
            self._values["client_timeout"] = client_timeout
        if crl_allow_certificates_without_crl_url is not None:
            self._values["crl_allow_certificates_without_crl_url"] = crl_allow_certificates_without_crl_url
        if crl_http_client_timeout is not None:
            self._values["crl_http_client_timeout"] = crl_http_client_timeout
        if crl_in_memory_cache_disabled is not None:
            self._values["crl_in_memory_cache_disabled"] = crl_in_memory_cache_disabled
        if crl_on_disk_cache_disabled is not None:
            self._values["crl_on_disk_cache_disabled"] = crl_on_disk_cache_disabled
        if disable_console_login is not None:
            self._values["disable_console_login"] = disable_console_login
        if disable_ocsp_checks is not None:
            self._values["disable_ocsp_checks"] = disable_ocsp_checks
        if disable_query_context_cache is not None:
            self._values["disable_query_context_cache"] = disable_query_context_cache
        if disable_saml_url_check is not None:
            self._values["disable_saml_url_check"] = disable_saml_url_check
        if disable_telemetry is not None:
            self._values["disable_telemetry"] = disable_telemetry
        if driver_tracing is not None:
            self._values["driver_tracing"] = driver_tracing
        if enable_single_use_refresh_tokens is not None:
            self._values["enable_single_use_refresh_tokens"] = enable_single_use_refresh_tokens
        if experimental_features_enabled is not None:
            self._values["experimental_features_enabled"] = experimental_features_enabled
        if external_browser_timeout is not None:
            self._values["external_browser_timeout"] = external_browser_timeout
        if host is not None:
            self._values["host"] = host
        if include_retry_reason is not None:
            self._values["include_retry_reason"] = include_retry_reason
        if insecure_mode is not None:
            self._values["insecure_mode"] = insecure_mode
        if jwt_client_timeout is not None:
            self._values["jwt_client_timeout"] = jwt_client_timeout
        if jwt_expire_timeout is not None:
            self._values["jwt_expire_timeout"] = jwt_expire_timeout
        if keep_session_alive is not None:
            self._values["keep_session_alive"] = keep_session_alive
        if login_timeout is not None:
            self._values["login_timeout"] = login_timeout
        if log_query_parameters is not None:
            self._values["log_query_parameters"] = log_query_parameters
        if log_query_text is not None:
            self._values["log_query_text"] = log_query_text
        if max_retry_count is not None:
            self._values["max_retry_count"] = max_retry_count
        if no_proxy is not None:
            self._values["no_proxy"] = no_proxy
        if oauth_authorization_url is not None:
            self._values["oauth_authorization_url"] = oauth_authorization_url
        if oauth_client_id is not None:
            self._values["oauth_client_id"] = oauth_client_id
        if oauth_client_secret is not None:
            self._values["oauth_client_secret"] = oauth_client_secret
        if oauth_redirect_uri is not None:
            self._values["oauth_redirect_uri"] = oauth_redirect_uri
        if oauth_scope is not None:
            self._values["oauth_scope"] = oauth_scope
        if oauth_token_request_url is not None:
            self._values["oauth_token_request_url"] = oauth_token_request_url
        if ocsp_fail_open is not None:
            self._values["ocsp_fail_open"] = ocsp_fail_open
        if okta_url is not None:
            self._values["okta_url"] = okta_url
        if organization_name is not None:
            self._values["organization_name"] = organization_name
        if params is not None:
            self._values["params"] = params
        if passcode is not None:
            self._values["passcode"] = passcode
        if passcode_in_password is not None:
            self._values["passcode_in_password"] = passcode_in_password
        if password is not None:
            self._values["password"] = password
        if port is not None:
            self._values["port"] = port
        if preview_features_enabled is not None:
            self._values["preview_features_enabled"] = preview_features_enabled
        if private_key is not None:
            self._values["private_key"] = private_key
        if private_key_passphrase is not None:
            self._values["private_key_passphrase"] = private_key_passphrase
        if profile is not None:
            self._values["profile"] = profile
        if protocol is not None:
            self._values["protocol"] = protocol
        if proxy_host is not None:
            self._values["proxy_host"] = proxy_host
        if proxy_password is not None:
            self._values["proxy_password"] = proxy_password
        if proxy_port is not None:
            self._values["proxy_port"] = proxy_port
        if proxy_protocol is not None:
            self._values["proxy_protocol"] = proxy_protocol
        if proxy_user is not None:
            self._values["proxy_user"] = proxy_user
        if request_timeout is not None:
            self._values["request_timeout"] = request_timeout
        if role is not None:
            self._values["role"] = role
        if skip_toml_file_permission_verification is not None:
            self._values["skip_toml_file_permission_verification"] = skip_toml_file_permission_verification
        if tmp_directory_path is not None:
            self._values["tmp_directory_path"] = tmp_directory_path
        if token is not None:
            self._values["token"] = token
        if token_accessor is not None:
            self._values["token_accessor"] = token_accessor
        if use_legacy_toml_file is not None:
            self._values["use_legacy_toml_file"] = use_legacy_toml_file
        if user is not None:
            self._values["user"] = user
        if validate_default_parameters is not None:
            self._values["validate_default_parameters"] = validate_default_parameters
        if warehouse is not None:
            self._values["warehouse"] = warehouse
        if workload_identity_entra_resource is not None:
            self._values["workload_identity_entra_resource"] = workload_identity_entra_resource
        if workload_identity_provider is not None:
            self._values["workload_identity_provider"] = workload_identity_provider

    @builtins.property
    def account_name(self) -> typing.Optional[builtins.str]:
        '''Specifies your Snowflake account name assigned by Snowflake.

        For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#account-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ACCOUNT_NAME`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#account_name SnowflakeProvider#account_name}
        '''
        result = self._values.get("account_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def alias(self) -> typing.Optional[builtins.str]:
        '''Alias name.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#alias SnowflakeProvider#alias}
        '''
        result = self._values.get("alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def authenticator(self) -> typing.Optional[builtins.str]:
        '''Specifies the `authentication type <https://pkg.go.dev/github.com/snowflakedb/gosnowflake#AuthType>`_ to use when connecting to Snowflake. Valid options are: ``SNOWFLAKE`` | ``OAUTH`` | ``EXTERNALBROWSER`` | ``OKTA`` | ``SNOWFLAKE_JWT`` | ``TOKENACCESSOR`` | ``USERNAMEPASSWORDMFA`` | ``PROGRAMMATIC_ACCESS_TOKEN`` | ``OAUTH_CLIENT_CREDENTIALS`` | ``OAUTH_AUTHORIZATION_CODE`` | ``WORKLOAD_IDENTITY``. Can also be sourced from the ``SNOWFLAKE_AUTHENTICATOR`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#authenticator SnowflakeProvider#authenticator}
        '''
        result = self._values.get("authenticator")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def cert_revocation_check_mode(self) -> typing.Optional[builtins.str]:
        '''Specifies the certificate revocation check mode.

        Valid options are: ``DISABLED`` | ``ADVISORY`` | ``ENABLED``. The value is case-insensitive. Can also be sourced from the ``SNOWFLAKE_CERT_REVOCATION_CHECK_MODE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#cert_revocation_check_mode SnowflakeProvider#cert_revocation_check_mode}
        '''
        result = self._values.get("cert_revocation_check_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def client_ip(self) -> typing.Optional[builtins.str]:
        '''IP address for network checks. Can also be sourced from the ``SNOWFLAKE_CLIENT_IP`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_ip SnowflakeProvider#client_ip}
        '''
        result = self._values.get("client_ip")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def client_request_mfa_token(self) -> typing.Optional[builtins.str]:
        '''When true the MFA token is cached in the credential manager.

        True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_REQUEST_MFA_TOKEN`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_request_mfa_token SnowflakeProvider#client_request_mfa_token}
        '''
        result = self._values.get("client_request_mfa_token")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def client_store_temporary_credential(self) -> typing.Optional[builtins.str]:
        '''When true the ID token is cached in the credential manager.

        True by default in Windows/OSX. False for Linux. Can also be sourced from the ``SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_store_temporary_credential SnowflakeProvider#client_store_temporary_credential}
        '''
        result = self._values.get("client_store_temporary_credential")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def client_timeout(self) -> typing.Optional[jsii.Number]:
        '''The timeout in seconds for the client to complete the authentication.

        Can also be sourced from the ``SNOWFLAKE_CLIENT_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_timeout SnowflakeProvider#client_timeout}
        '''
        result = self._values.get("client_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def crl_allow_certificates_without_crl_url(self) -> typing.Optional[builtins.str]:
        '''Allow certificates (not short-lived) without CRL DP included to be treated as correct ones.

        Can also be sourced from the ``SNOWFLAKE_CRL_ALLOW_CERTIFICATES_WITHOUT_CRL_URL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_allow_certificates_without_crl_url SnowflakeProvider#crl_allow_certificates_without_crl_url}
        '''
        result = self._values.get("crl_allow_certificates_without_crl_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def crl_http_client_timeout(self) -> typing.Optional[jsii.Number]:
        '''Timeout in seconds for HTTP client used to download CRL. Can also be sourced from the ``SNOWFLAKE_CRL_HTTP_CLIENT_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_http_client_timeout SnowflakeProvider#crl_http_client_timeout}
        '''
        result = self._values.get("crl_http_client_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def crl_in_memory_cache_disabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        When set to true, the CRL in-memory cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_IN_MEMORY_CACHE_DISABLED`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_in_memory_cache_disabled SnowflakeProvider#crl_in_memory_cache_disabled}
        '''
        result = self._values.get("crl_in_memory_cache_disabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def crl_on_disk_cache_disabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        When set to true, the CRL on-disk cache is disabled. Can also be sourced from the ``SNOWFLAKE_CRL_ON_DISK_CACHE_DISABLED`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#crl_on_disk_cache_disabled SnowflakeProvider#crl_on_disk_cache_disabled}
        '''
        result = self._values.get("crl_on_disk_cache_disabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def disable_console_login(self) -> typing.Optional[builtins.str]:
        '''Indicates whether console login should be disabled in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_CONSOLE_LOGIN`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_console_login SnowflakeProvider#disable_console_login}
        '''
        result = self._values.get("disable_console_login")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def disable_ocsp_checks(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        When set to true, the driver doesn't check certificate revocation status. Can also be sourced from the ``SNOWFLAKE_DISABLE_OCSP_CHECKS`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_ocsp_checks SnowflakeProvider#disable_ocsp_checks}
        '''
        result = self._values.get("disable_ocsp_checks")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def disable_query_context_cache(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Disables HTAP query context cache in the driver. Can also be sourced from the ``SNOWFLAKE_DISABLE_QUERY_CONTEXT_CACHE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_query_context_cache SnowflakeProvider#disable_query_context_cache}
        '''
        result = self._values.get("disable_query_context_cache")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def disable_saml_url_check(self) -> typing.Optional[builtins.str]:
        '''Indicates whether the SAML URL check should be disabled. Can also be sourced from the ``SNOWFLAKE_DISABLE_SAML_URL_CHECK`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_saml_url_check SnowflakeProvider#disable_saml_url_check}
        '''
        result = self._values.get("disable_saml_url_check")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def disable_telemetry(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Disables telemetry in the driver. Can also be sourced from the ``DISABLE_TELEMETRY`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#disable_telemetry SnowflakeProvider#disable_telemetry}
        '''
        result = self._values.get("disable_telemetry")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def driver_tracing(self) -> typing.Optional[builtins.str]:
        '''Specifies the logging level to be used by the driver.

        Valid options are: ``trace`` | ``debug`` | ``info`` | ``print`` | ``warning`` | ``error`` | ``fatal`` | ``panic``. Can also be sourced from the ``SNOWFLAKE_DRIVER_TRACING`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#driver_tracing SnowflakeProvider#driver_tracing}
        '''
        result = self._values.get("driver_tracing")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_single_use_refresh_tokens(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Enables single use refresh tokens for Snowflake IdP. Can also be sourced from the ``SNOWFLAKE_ENABLE_SINGLE_USE_REFRESH_TOKENS`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#enable_single_use_refresh_tokens SnowflakeProvider#enable_single_use_refresh_tokens}
        '''
        result = self._values.get("enable_single_use_refresh_tokens")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def experimental_features_enabled(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of experimental features.

        Similarly to preview features, they are not yet stable features of the provider. Enabling given experiment is still considered a preview feature, even when applied to the stable resource. These switches offer experiments altering the provider behavior. If the given experiment is successful, it can be considered an addition in the future provider versions. This field can not be set with environmental variables. Check more details in the `experimental features section <#experimental-features>`_. Active experiments are: ``WAREHOUSE_SHOW_IMPROVED_PERFORMANCE`` | ``GRANTS_STRICT_PRIVILEGE_MANAGEMENT`` | ``PARAMETERS_IGNORE_VALUE_CHANGES_IF_NOT_ON_OBJECT_LEVEL`` | ``PARAMETERS_REDUCED_OUTPUT`` | ``USER_ENABLE_DEFAULT_WORKLOAD_IDENTITY``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#experimental_features_enabled SnowflakeProvider#experimental_features_enabled}
        '''
        result = self._values.get("experimental_features_enabled")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def external_browser_timeout(self) -> typing.Optional[jsii.Number]:
        '''The timeout in seconds for the external browser to complete the authentication.

        Can also be sourced from the ``SNOWFLAKE_EXTERNAL_BROWSER_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#external_browser_timeout SnowflakeProvider#external_browser_timeout}
        '''
        result = self._values.get("external_browser_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def host(self) -> typing.Optional[builtins.str]:
        '''Specifies a custom host value used by the driver for privatelink connections.

        Can also be sourced from the ``SNOWFLAKE_HOST`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#host SnowflakeProvider#host}
        '''
        result = self._values.get("host")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def include_retry_reason(self) -> typing.Optional[builtins.str]:
        '''Should retried request contain retry reason. Can also be sourced from the ``SNOWFLAKE_INCLUDE_RETRY_REASON`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#include_retry_reason SnowflakeProvider#include_retry_reason}
        '''
        result = self._values.get("include_retry_reason")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def insecure_mode(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''This field is deprecated.

        Use ``disable_ocsp_checks`` instead. If true, bypass the Online Certificate Status Protocol (OCSP) certificate revocation check. IMPORTANT: Change the default value for testing or emergency situations only. Can also be sourced from the ``SNOWFLAKE_INSECURE_MODE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#insecure_mode SnowflakeProvider#insecure_mode}
        '''
        result = self._values.get("insecure_mode")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def jwt_client_timeout(self) -> typing.Optional[jsii.Number]:
        '''The timeout in seconds for the JWT client to complete the authentication.

        Can also be sourced from the ``SNOWFLAKE_JWT_CLIENT_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_client_timeout SnowflakeProvider#jwt_client_timeout}
        '''
        result = self._values.get("jwt_client_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def jwt_expire_timeout(self) -> typing.Optional[jsii.Number]:
        '''JWT expire after timeout in seconds. Can also be sourced from the ``SNOWFLAKE_JWT_EXPIRE_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#jwt_expire_timeout SnowflakeProvider#jwt_expire_timeout}
        '''
        result = self._values.get("jwt_expire_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def keep_session_alive(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Enables the session to persist even after the connection is closed.

        Can also be sourced from the ``SNOWFLAKE_KEEP_SESSION_ALIVE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#keep_session_alive SnowflakeProvider#keep_session_alive}
        '''
        result = self._values.get("keep_session_alive")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def login_timeout(self) -> typing.Optional[jsii.Number]:
        '''Login retry timeout in seconds EXCLUDING network roundtrip and read out http response.

        Can also be sourced from the ``SNOWFLAKE_LOGIN_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#login_timeout SnowflakeProvider#login_timeout}
        '''
        result = self._values.get("login_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def log_query_parameters(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''When set to true, the parameters will be logged.

        Requires logQueryText to be enabled first. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_PARAMETERS`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_parameters SnowflakeProvider#log_query_parameters}
        '''
        result = self._values.get("log_query_parameters")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def log_query_text(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''When set to true, the full query text will be logged.

        Be aware that it may include sensitive information. Default value is false. Can also be sourced from the ``SNOWFLAKE_LOG_QUERY_TEXT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#log_query_text SnowflakeProvider#log_query_text}
        '''
        result = self._values.get("log_query_text")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def max_retry_count(self) -> typing.Optional[jsii.Number]:
        '''Specifies how many times non-periodic HTTP request can be retried by the driver.

        Can also be sourced from the ``SNOWFLAKE_MAX_RETRY_COUNT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#max_retry_count SnowflakeProvider#max_retry_count}
        '''
        result = self._values.get("max_retry_count")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def no_proxy(self) -> typing.Optional[builtins.str]:
        '''A comma-separated list of hostnames, domains, and IP addresses to exclude from proxying.

        See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_NO_PROXY`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#no_proxy SnowflakeProvider#no_proxy}
        '''
        result = self._values.get("no_proxy")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_authorization_url(self) -> typing.Optional[builtins.str]:
        '''Authorization URL of OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_AUTHORIZATION_URL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_authorization_url SnowflakeProvider#oauth_authorization_url}
        '''
        result = self._values.get("oauth_authorization_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_client_id(self) -> typing.Optional[builtins.str]:
        '''Client id for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_ID`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_id SnowflakeProvider#oauth_client_id}
        '''
        result = self._values.get("oauth_client_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_client_secret(self) -> typing.Optional[builtins.str]:
        '''Client secret for OAuth2 external IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_CLIENT_SECRET`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_client_secret SnowflakeProvider#oauth_client_secret}
        '''
        result = self._values.get("oauth_client_secret")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_redirect_uri(self) -> typing.Optional[builtins.str]:
        '''Redirect URI registered in IdP. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_REDIRECT_URI`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_redirect_uri SnowflakeProvider#oauth_redirect_uri}
        '''
        result = self._values.get("oauth_redirect_uri")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_scope(self) -> typing.Optional[builtins.str]:
        '''Comma separated list of scopes.

        If empty it is derived from role. See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_SCOPE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_scope SnowflakeProvider#oauth_scope}
        '''
        result = self._values.get("oauth_scope")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oauth_token_request_url(self) -> typing.Optional[builtins.str]:
        '''Token request URL of OAuth2 external IdP.

        See `Snowflake OAuth documentation <https://docs.snowflake.com/en/user-guide/oauth>`_. Can also be sourced from the ``SNOWFLAKE_OAUTH_TOKEN_REQUEST_URL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#oauth_token_request_url SnowflakeProvider#oauth_token_request_url}
        '''
        result = self._values.get("oauth_token_request_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ocsp_fail_open(self) -> typing.Optional[builtins.str]:
        '''True represents OCSP fail open mode.

        False represents OCSP fail closed mode. Fail open true by default. Can also be sourced from the ``SNOWFLAKE_OCSP_FAIL_OPEN`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#ocsp_fail_open SnowflakeProvider#ocsp_fail_open}
        '''
        result = self._values.get("ocsp_fail_open")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def okta_url(self) -> typing.Optional[builtins.str]:
        '''The URL of the Okta server.

        e.g. https://example.okta.com. Okta URL host needs to to have a suffix ``okta.com``. Read more in Snowflake `docs <https://docs.snowflake.com/en/user-guide/oauth-okta>`_. Can also be sourced from the ``SNOWFLAKE_OKTA_URL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#okta_url SnowflakeProvider#okta_url}
        '''
        result = self._values.get("okta_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def organization_name(self) -> typing.Optional[builtins.str]:
        '''Specifies your Snowflake organization name assigned by Snowflake.

        For information about account identifiers, see the `Snowflake documentation <https://docs.snowflake.com/en/user-guide/admin-account-identifier#organization-name>`_. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_ORGANIZATION_NAME`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#organization_name SnowflakeProvider#organization_name}
        '''
        result = self._values.get("organization_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def params(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Sets other connection (i.e. session) parameters. `Parameters <https://docs.snowflake.com/en/sql-reference/parameters>`_. This field can not be set with environmental variables.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#params SnowflakeProvider#params}
        '''
        result = self._values.get("params")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def passcode(self) -> typing.Optional[builtins.str]:
        '''Specifies the passcode provided by Duo when using multi-factor authentication (MFA) for login.

        Can also be sourced from the ``SNOWFLAKE_PASSCODE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode SnowflakeProvider#passcode}
        '''
        result = self._values.get("passcode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def passcode_in_password(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        Set to true if the MFA passcode is embedded to the configured password. Can also be sourced from the ``SNOWFLAKE_PASSCODE_IN_PASSWORD`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#passcode_in_password SnowflakeProvider#passcode_in_password}
        '''
        result = self._values.get("passcode_in_password")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def password(self) -> typing.Optional[builtins.str]:
        '''Password for user + password or `token <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens#generating-a-programmatic-access-token>`_ for `PAT auth <https://docs.snowflake.com/en/user-guide/programmatic-access-tokens>`_. Cannot be used with ``private_key`` and ``private_key_passphrase``. Can also be sourced from the ``SNOWFLAKE_PASSWORD`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#password SnowflakeProvider#password}
        '''
        result = self._values.get("password")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def port(self) -> typing.Optional[jsii.Number]:
        '''Specifies a custom port value used by the driver for privatelink connections.

        Can also be sourced from the ``SNOWFLAKE_PORT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#port SnowflakeProvider#port}
        '''
        result = self._values.get("port")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def preview_features_enabled(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of preview features that are handled by the provider.

        See `preview features list <https://github.com/Snowflake-Labs/terraform-provider-snowflake/blob/main/v1-preparations/LIST_OF_PREVIEW_FEATURES_FOR_V1.md>`_. Preview features may have breaking changes in future releases, even without raising the major version. This field can not be set with environmental variables. Preview features that can be enabled are: ``snowflake_account_authentication_policy_attachment_resource`` | ``snowflake_account_password_policy_attachment_resource`` | ``snowflake_alert_resource`` | ``snowflake_alerts_datasource`` | ``snowflake_api_integration_resource`` | ``snowflake_authentication_policy_resource`` | ``snowflake_authentication_policies_datasource`` | ``snowflake_cortex_search_service_resource`` | ``snowflake_cortex_search_services_datasource`` | ``snowflake_current_account_resource`` | ``snowflake_current_account_datasource`` | ``snowflake_current_organization_account_resource`` | ``snowflake_database_datasource`` | ``snowflake_database_role_datasource`` | ``snowflake_dynamic_table_resource`` | ``snowflake_dynamic_tables_datasource`` | ``snowflake_stage_external_azure_resource`` | ``snowflake_external_function_resource`` | ``snowflake_external_functions_datasource`` | ``snowflake_stage_external_gcs_resource`` | ``snowflake_stage_external_s3_resource`` | ``snowflake_stage_external_s3_compatible_resource`` | ``snowflake_external_table_resource`` | ``snowflake_external_tables_datasource`` | ``snowflake_external_volume_resource`` | ``snowflake_failover_group_resource`` | ``snowflake_failover_groups_datasource`` | ``snowflake_file_format_resource`` | ``snowflake_file_formats_datasource`` | ``snowflake_function_java_resource`` | ``snowflake_function_javascript_resource`` | ``snowflake_function_python_resource`` | ``snowflake_function_scala_resource`` | ``snowflake_function_sql_resource`` | ``snowflake_functions_datasource`` | ``snowflake_stage_internal_resource`` | ``snowflake_job_service_resource`` | ``snowflake_listings_datasource`` | ``snowflake_managed_account_resource`` | ``snowflake_materialized_view_resource`` | ``snowflake_materialized_views_datasource`` | ``snowflake_network_policy_attachment_resource`` | ``snowflake_network_rule_resource`` | ``snowflake_notebook_resource`` | ``snowflake_notebooks_datasource`` | ``snowflake_email_notification_integration_resource`` | ``snowflake_notification_integration_resource`` | ``snowflake_object_parameter_resource`` | ``snowflake_password_policy_resource`` | ``snowflake_pipe_resource`` | ``snowflake_pipes_datasource`` | ``snowflake_current_role_datasource`` | ``snowflake_semantic_view_resource`` | ``snowflake_semantic_views_datasource`` | ``snowflake_sequence_resource`` | ``snowflake_sequences_datasource`` | ``snowflake_share_resource`` | ``snowflake_shares_datasource`` | ``snowflake_parameters_datasource`` | ``snowflake_procedure_java_resource`` | ``snowflake_procedure_javascript_resource`` | ``snowflake_procedure_python_resource`` | ``snowflake_procedure_scala_resource`` | ``snowflake_procedure_sql_resource`` | ``snowflake_procedures_datasource`` | ``snowflake_stage_resource`` | ``snowflake_stages_datasource`` | ``snowflake_storage_integration_resource`` | ``snowflake_storage_integration_aws_resource`` | ``snowflake_storage_integration_azure_resource`` | ``snowflake_storage_integration_gcs_resource`` | ``snowflake_storage_integrations_datasource`` | ``snowflake_system_generate_scim_access_token_datasource`` | ``snowflake_system_get_aws_sns_iam_policy_datasource`` | ``snowflake_system_get_privatelink_config_datasource`` | ``snowflake_system_get_snowflake_platform_info_datasource`` | ``snowflake_table_column_masking_policy_application_resource`` | ``snowflake_table_constraint_resource`` | ``snowflake_table_resource`` | ``snowflake_tables_datasource`` | ``snowflake_user_authentication_policy_attachment_resource`` | ``snowflake_user_public_keys_resource`` | ``snowflake_user_password_policy_attachment_resource``. Promoted features that are stable and are enabled by default are: ``snowflake_compute_pool_resource`` | ``snowflake_compute_pools_datasource`` | ``snowflake_git_repository_resource`` | ``snowflake_git_repositories_datasource`` | ``snowflake_image_repository_resource`` | ``snowflake_image_repositories_datasource`` | ``snowflake_listing_resource`` | ``snowflake_service_resource`` | ``snowflake_services_datasource`` | ``snowflake_user_programmatic_access_token_resource`` | ``snowflake_user_programmatic_access_tokens_datasource``. Promoted features can be safely removed from this field. They will be removed in the next major version.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#preview_features_enabled SnowflakeProvider#preview_features_enabled}
        '''
        result = self._values.get("preview_features_enabled")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def private_key(self) -> typing.Optional[builtins.str]:
        '''Private Key for username+private-key auth. Cannot be used with ``password``. Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key SnowflakeProvider#private_key}
        '''
        result = self._values.get("private_key")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def private_key_passphrase(self) -> typing.Optional[builtins.str]:
        '''Supports the encryption ciphers aes-128-cbc, aes-128-gcm, aes-192-cbc, aes-192-gcm, aes-256-cbc, aes-256-gcm, and des-ede3-cbc.

        Can also be sourced from the ``SNOWFLAKE_PRIVATE_KEY_PASSPHRASE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#private_key_passphrase SnowflakeProvider#private_key_passphrase}
        '''
        result = self._values.get("private_key_passphrase")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def profile(self) -> typing.Optional[builtins.str]:
        '''Sets the profile to read from ~/.snowflake/config file. Can also be sourced from the ``SNOWFLAKE_PROFILE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#profile SnowflakeProvider#profile}
        '''
        result = self._values.get("profile")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def protocol(self) -> typing.Optional[builtins.str]:
        '''A protocol used in the connection.

        Valid options are: ``http`` | ``https``. Can also be sourced from the ``SNOWFLAKE_PROTOCOL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#protocol SnowflakeProvider#protocol}
        '''
        result = self._values.get("protocol")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def proxy_host(self) -> typing.Optional[builtins.str]:
        '''The host of the proxy to use for the connection.

        See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_HOST`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_host SnowflakeProvider#proxy_host}
        '''
        result = self._values.get("proxy_host")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def proxy_password(self) -> typing.Optional[builtins.str]:
        '''The password of the proxy to use for the connection.

        See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PASSWORD`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_password SnowflakeProvider#proxy_password}
        '''
        result = self._values.get("proxy_password")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def proxy_port(self) -> typing.Optional[jsii.Number]:
        '''The port of the proxy to use for the connection.

        See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PORT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_port SnowflakeProvider#proxy_port}
        '''
        result = self._values.get("proxy_port")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def proxy_protocol(self) -> typing.Optional[builtins.str]:
        '''The protocol of the proxy to use for the connection.

        Valid options are: ``http`` | ``https``. The value is case-insensitive. See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_PROTOCOL`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_protocol SnowflakeProvider#proxy_protocol}
        '''
        result = self._values.get("proxy_protocol")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def proxy_user(self) -> typing.Optional[builtins.str]:
        '''The user of the proxy to use for the connection.

        See more in `the proxy section below <#proxy>`_. Can also be sourced from the ``SNOWFLAKE_PROXY_USER`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#proxy_user SnowflakeProvider#proxy_user}
        '''
        result = self._values.get("proxy_user")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def request_timeout(self) -> typing.Optional[jsii.Number]:
        '''request retry timeout in seconds EXCLUDING network roundtrip and read out http response.

        Can also be sourced from the ``SNOWFLAKE_REQUEST_TIMEOUT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#request_timeout SnowflakeProvider#request_timeout}
        '''
        result = self._values.get("request_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def role(self) -> typing.Optional[builtins.str]:
        '''Specifies the role to use by default for accessing Snowflake objects in the client session.

        Can also be sourced from the ``SNOWFLAKE_ROLE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#role SnowflakeProvider#role}
        '''
        result = self._values.get("role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_toml_file_permission_verification(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        Skips TOML configuration file permission verification. This flag has no effect on Windows systems, as the permissions are not checked on this platform. Instead of skipping the permissions verification, we recommend setting the proper privileges - see `the section below <#toml-file-limitations>`_. Can also be sourced from the ``SNOWFLAKE_SKIP_TOML_FILE_PERMISSION_VERIFICATION`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#skip_toml_file_permission_verification SnowflakeProvider#skip_toml_file_permission_verification}
        '''
        result = self._values.get("skip_toml_file_permission_verification")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def tmp_directory_path(self) -> typing.Optional[builtins.str]:
        '''Sets temporary directory used by the driver for operations like encrypting, compressing etc.

        Can also be sourced from the ``SNOWFLAKE_TMP_DIRECTORY_PATH`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#tmp_directory_path SnowflakeProvider#tmp_directory_path}
        '''
        result = self._values.get("tmp_directory_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def token(self) -> typing.Optional[builtins.str]:
        '''Token to use for OAuth and other forms of token based auth.

        When this field is set here, or in the TOML file, the provider sets the ``authenticator`` to ``OAUTH``. Optionally, set the ``authenticator`` field to the authenticator you want to use. Can also be sourced from the ``SNOWFLAKE_TOKEN`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token SnowflakeProvider#token}
        '''
        result = self._values.get("token")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def token_accessor(self) -> typing.Optional["SnowflakeProviderTokenAccessor"]:
        '''token_accessor block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token_accessor SnowflakeProvider#token_accessor}
        '''
        result = self._values.get("token_accessor")
        return typing.cast(typing.Optional["SnowflakeProviderTokenAccessor"], result)

    @builtins.property
    def use_legacy_toml_file(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''False by default.

        When this is set to true, the provider expects the legacy TOML format. Otherwise, it expects the new format. See more in `the section below <#examples>`_ Can also be sourced from the ``SNOWFLAKE_USE_LEGACY_TOML_FILE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#use_legacy_toml_file SnowflakeProvider#use_legacy_toml_file}
        '''
        result = self._values.get("use_legacy_toml_file")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def user(self) -> typing.Optional[builtins.str]:
        '''Username. Required unless using ``profile``. Can also be sourced from the ``SNOWFLAKE_USER`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#user SnowflakeProvider#user}
        '''
        result = self._values.get("user")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def validate_default_parameters(self) -> typing.Optional[builtins.str]:
        '''True by default.

        If false, disables the validation checks for Database, Schema, Warehouse and Role at the time a connection is established. Can also be sourced from the ``SNOWFLAKE_VALIDATE_DEFAULT_PARAMETERS`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#validate_default_parameters SnowflakeProvider#validate_default_parameters}
        '''
        result = self._values.get("validate_default_parameters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def warehouse(self) -> typing.Optional[builtins.str]:
        '''Specifies the virtual warehouse to use by default for queries, loading, etc.

        in the client session. Can also be sourced from the ``SNOWFLAKE_WAREHOUSE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#warehouse SnowflakeProvider#warehouse}
        '''
        result = self._values.get("warehouse")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def workload_identity_entra_resource(self) -> typing.Optional[builtins.str]:
        '''The resource to use for WIF authentication on Azure environment. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_ENTRA_RESOURCE`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_entra_resource SnowflakeProvider#workload_identity_entra_resource}
        '''
        result = self._values.get("workload_identity_entra_resource")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def workload_identity_provider(self) -> typing.Optional[builtins.str]:
        '''The workload identity provider to use for WIF authentication. Can also be sourced from the ``SNOWFLAKE_WORKLOAD_IDENTITY_PROVIDER`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#workload_identity_provider SnowflakeProvider#workload_identity_provider}
        '''
        result = self._values.get("workload_identity_provider")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SnowflakeProviderConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.provider.SnowflakeProviderTokenAccessor",
    jsii_struct_bases=[],
    name_mapping={
        "client_id": "clientId",
        "client_secret": "clientSecret",
        "redirect_uri": "redirectUri",
        "refresh_token": "refreshToken",
        "token_endpoint": "tokenEndpoint",
    },
)
class SnowflakeProviderTokenAccessor:
    def __init__(
        self,
        *,
        client_id: builtins.str,
        client_secret: builtins.str,
        redirect_uri: builtins.str,
        refresh_token: builtins.str,
        token_endpoint: builtins.str,
    ) -> None:
        '''
        :param client_id: The client ID for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_ID`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_id SnowflakeProvider#client_id}
        :param client_secret: The client secret for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_SECRET`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_secret SnowflakeProvider#client_secret}
        :param redirect_uri: The redirect URI for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_REDIRECT_URI`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#redirect_uri SnowflakeProvider#redirect_uri}
        :param refresh_token: The refresh token for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_REFRESH_TOKEN`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#refresh_token SnowflakeProvider#refresh_token}
        :param token_endpoint: The token endpoint for the OAuth provider e.g. https://{yourDomain}/oauth/token when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_TOKEN_ENDPOINT`` environment variable. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token_endpoint SnowflakeProvider#token_endpoint}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce505ad3535a3780bd3b4be5de8c7dd84bf27590bda6387f04495857a6d35975)
            check_type(argname="argument client_id", value=client_id, expected_type=type_hints["client_id"])
            check_type(argname="argument client_secret", value=client_secret, expected_type=type_hints["client_secret"])
            check_type(argname="argument redirect_uri", value=redirect_uri, expected_type=type_hints["redirect_uri"])
            check_type(argname="argument refresh_token", value=refresh_token, expected_type=type_hints["refresh_token"])
            check_type(argname="argument token_endpoint", value=token_endpoint, expected_type=type_hints["token_endpoint"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": redirect_uri,
            "refresh_token": refresh_token,
            "token_endpoint": token_endpoint,
        }

    @builtins.property
    def client_id(self) -> builtins.str:
        '''The client ID for the OAuth provider when using a refresh token to renew access token.

        Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_ID`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_id SnowflakeProvider#client_id}
        '''
        result = self._values.get("client_id")
        assert result is not None, "Required property 'client_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def client_secret(self) -> builtins.str:
        '''The client secret for the OAuth provider when using a refresh token to renew access token.

        Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_SECRET`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#client_secret SnowflakeProvider#client_secret}
        '''
        result = self._values.get("client_secret")
        assert result is not None, "Required property 'client_secret' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def redirect_uri(self) -> builtins.str:
        '''The redirect URI for the OAuth provider when using a refresh token to renew access token.

        Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_REDIRECT_URI`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#redirect_uri SnowflakeProvider#redirect_uri}
        '''
        result = self._values.get("redirect_uri")
        assert result is not None, "Required property 'redirect_uri' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def refresh_token(self) -> builtins.str:
        '''The refresh token for the OAuth provider when using a refresh token to renew access token.

        Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_REFRESH_TOKEN`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#refresh_token SnowflakeProvider#refresh_token}
        '''
        result = self._values.get("refresh_token")
        assert result is not None, "Required property 'refresh_token' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def token_endpoint(self) -> builtins.str:
        '''The token endpoint for the OAuth provider e.g. https://{yourDomain}/oauth/token when using a refresh token to renew access token. Can also be sourced from the ``SNOWFLAKE_TOKEN_ACCESSOR_TOKEN_ENDPOINT`` environment variable.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs#token_endpoint SnowflakeProvider#token_endpoint}
        '''
        result = self._values.get("token_endpoint")
        assert result is not None, "Required property 'token_endpoint' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SnowflakeProviderTokenAccessor(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "SnowflakeProvider",
    "SnowflakeProviderConfig",
    "SnowflakeProviderTokenAccessor",
]

publication.publish()

def _typecheckingstub__2c1cb44e3b84880ea849eda37563afbbfddfca8446376cb0706c8ec62829c6a5(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    account_name: typing.Optional[builtins.str] = None,
    alias: typing.Optional[builtins.str] = None,
    authenticator: typing.Optional[builtins.str] = None,
    cert_revocation_check_mode: typing.Optional[builtins.str] = None,
    client_ip: typing.Optional[builtins.str] = None,
    client_request_mfa_token: typing.Optional[builtins.str] = None,
    client_store_temporary_credential: typing.Optional[builtins.str] = None,
    client_timeout: typing.Optional[jsii.Number] = None,
    crl_allow_certificates_without_crl_url: typing.Optional[builtins.str] = None,
    crl_http_client_timeout: typing.Optional[jsii.Number] = None,
    crl_in_memory_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    crl_on_disk_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_console_login: typing.Optional[builtins.str] = None,
    disable_ocsp_checks: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_query_context_cache: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_saml_url_check: typing.Optional[builtins.str] = None,
    disable_telemetry: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    driver_tracing: typing.Optional[builtins.str] = None,
    enable_single_use_refresh_tokens: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    experimental_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    external_browser_timeout: typing.Optional[jsii.Number] = None,
    host: typing.Optional[builtins.str] = None,
    include_retry_reason: typing.Optional[builtins.str] = None,
    insecure_mode: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    jwt_client_timeout: typing.Optional[jsii.Number] = None,
    jwt_expire_timeout: typing.Optional[jsii.Number] = None,
    keep_session_alive: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    login_timeout: typing.Optional[jsii.Number] = None,
    log_query_parameters: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    log_query_text: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    max_retry_count: typing.Optional[jsii.Number] = None,
    no_proxy: typing.Optional[builtins.str] = None,
    oauth_authorization_url: typing.Optional[builtins.str] = None,
    oauth_client_id: typing.Optional[builtins.str] = None,
    oauth_client_secret: typing.Optional[builtins.str] = None,
    oauth_redirect_uri: typing.Optional[builtins.str] = None,
    oauth_scope: typing.Optional[builtins.str] = None,
    oauth_token_request_url: typing.Optional[builtins.str] = None,
    ocsp_fail_open: typing.Optional[builtins.str] = None,
    okta_url: typing.Optional[builtins.str] = None,
    organization_name: typing.Optional[builtins.str] = None,
    params: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    passcode: typing.Optional[builtins.str] = None,
    passcode_in_password: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    password: typing.Optional[builtins.str] = None,
    port: typing.Optional[jsii.Number] = None,
    preview_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_key: typing.Optional[builtins.str] = None,
    private_key_passphrase: typing.Optional[builtins.str] = None,
    profile: typing.Optional[builtins.str] = None,
    protocol: typing.Optional[builtins.str] = None,
    proxy_host: typing.Optional[builtins.str] = None,
    proxy_password: typing.Optional[builtins.str] = None,
    proxy_port: typing.Optional[jsii.Number] = None,
    proxy_protocol: typing.Optional[builtins.str] = None,
    proxy_user: typing.Optional[builtins.str] = None,
    request_timeout: typing.Optional[jsii.Number] = None,
    role: typing.Optional[builtins.str] = None,
    skip_toml_file_permission_verification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    tmp_directory_path: typing.Optional[builtins.str] = None,
    token: typing.Optional[builtins.str] = None,
    token_accessor: typing.Optional[typing.Union[SnowflakeProviderTokenAccessor, typing.Dict[builtins.str, typing.Any]]] = None,
    use_legacy_toml_file: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    user: typing.Optional[builtins.str] = None,
    validate_default_parameters: typing.Optional[builtins.str] = None,
    warehouse: typing.Optional[builtins.str] = None,
    workload_identity_entra_resource: typing.Optional[builtins.str] = None,
    workload_identity_provider: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b304e00bb8ee82994ae2ec983ed339caa6f5ec7552b845483bcb4c2d8b366aad(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03b387e559a7c5d1084110bf811384f98795d683f55e504dbf0d589ae9a9ac19(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01918df4bf6852d4f8a177f550530eab13c80f8c721704c711e4270b3afd7866(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97966a6181128178fb63175e0f1a2bdf6625ace6a52c77a53781b0c11efb5d7e(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88f4042d4d2e0087e5e2484e8d8d5eeefe7d1ccf458d947aa0fa29070e0f4966(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47e2005d0c5011e8d2e92bbcb7ec3ed036b98c9ed086337d874686a400d5a212(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18b9ff9ba622e04e25d04d88d67e00e39f0885aef4ebac4fc835b887cd904fbe(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e0c6478870695f78387091dbbf567bbcc850a14706850dc5709fae72ae12c72(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb6019430dfa3477c9300b87fd2b6fd3f106ef6642507c25fdc02c4230231248(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__052a329704542fa47a9e66b6dbca2997de90d7df84b3b3a4469162ca13f8f115(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c0a9bb0688cdb379450c2ba8677186ff61e2697cc60ee5d256777b0cf70852d(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ea806b9be19f34ad4c9fb0c1d1f94407908ea325b6493b8f8c56a3645d360d4(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f8f3d7398aa4146d3889e342ad00fd54254ecea4637bbf7fa3e0d60d218dbce(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f3001681f4aa2f2c409562bde7f010d6301de4e275345f39229a90ab96d574da(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ddf71661734a6170f5c8f715ff87cf56f50484d5df990dc7403d6808f55387d(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ddd01de6bce3dec856b499532f643a9471f96abf3f9818890c496e667265b947(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4eba7b4d38fc8a8f456c68c5676222b1636587962836cef1b233da8fdbc562e(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b323eaede07f1ae1045e1f9f00342b7b9283cb92ca825cc36173777a2a98ec9c(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__814d3ff5f64e284fc577b2c65177432a449bbdc47fca95670e7c0c9fb4e767e5(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__000df4f6e3b4ad331c34bfd310cea32f21bbf4e6797803de4230f424f78dc20d(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d78067258c15b935505f9d02b276827aaed59049fb57e9d97e42f0220d372a08(
    value: typing.Optional[typing.List[builtins.str]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65597b05a209f93147eff5843a502787c9d71ff84151e5a0951031b749e61ceb(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69ecd001639eeef05c5cb7d77d299218d8afcc88dd8f4734fd878d4dd4fcbd16(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b31d1099e09e95cfb4212c35b2b744d35fdcdf5a225f71c1bf7b7e3a9290b273(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__627ff05fee2fc8b17281b391582b59c048ad110c37b233584aa34057e54b6c2e(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ee0893d1e609519ae040468cae68d866a29a1cc9f17069299f4c0156cda32e2(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00075aef5398d5d40dce90dd67c9d2b687d491917adec5d632b2938e7c501c54(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efb30fa5ad82887ba9c1e8ff7611868e8cbe97abf2ee4a8019d0228e9bb333d1(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76eb650a9c73f2dfd76b8eb4e42be8e1671f17bf584086234fec07fc60c0cd32(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b997b1034a2d85fe2d8a5992ce2e9837010963839602bea5a11123d8213ad6e(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63b923a69371ef4e584b2878e2d9fe37077a707b56804f8586b771843a64aa15(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e94283e260e64f28788eab480216fb685ffe849db21601641f5cd5bb594fbaf(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a33d1f453bbf71149bde3c30795f5ad60822a5bb93f4aa768fd5e98cd07b8bf7(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bca6a701029ca0c0d61c346bb3df9470d3dba08e64c9c94bfb0d856acd66e275(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2548410eb558edf788fb49ed6906037f301b123acf622b8cf560847853fe630f(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d59a440849dcac6fd125d40f41fde115d315197bdb9b32b56b4999b31b659b15(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40040dadc1ac41c0f4df004742a684cb1c3f8c2549742634f93369ef8b33ca6b(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d43e9af2a0b5594ec973b1ce9d16cc42391b810a26f3e075069c8e812676a284(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ca4149c3ecd9b884e65523066da1d81b732abeca1dc77f1efeaa63850b3bb26(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa43a52c5259bc0c00ad7efd8e72cf906b77bc6978fdf249ed85ffef2611a918(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b9d66862d58848a99bf1796243ff496b1daa77c02193190ce82a7c3979eb3e4(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8700beaabede1104e580fb8430fc09cbd4dd17dcf6c92231e84b55854829e09b(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4561b3d184a4f7f6d121114b5faf9f023c6439e40551dfaeb5bd489985733cf2(
    value: typing.Optional[typing.Mapping[builtins.str, builtins.str]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05eb729eeae80ddd878795de11b343e6a698ba59e4f74b674c4722c4840c90a9(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f69df39dc0bb68ba452208c4a18ac801117f4a28acdbf719edbd8629f9b34bc(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed25e167e1d0c52555dd83d8a25dcbc90321e238013a47c154b5e677f7a40ac6(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__926dfa62a7c399c3b8fe79d527206db7966dea2e9e7bd2600c486f1802a02ab5(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08de9d58ee40e0db49ea3271821e41d4efb091072ebe02779fe5ae65eb2a5f02(
    value: typing.Optional[typing.List[builtins.str]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76f17d9efaf46f24fb6e99273cf32d0c4c29cb8bfe1f7df57f8101bfcbd1f940(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__752cd0aeb70ac67eef00c64e4a645a4f896c46e78c1d2ed17a204ba7a45b17e8(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02c94dc3335fdc09b8b541e204b14dcd56549a8ef61e628a2d3292d89726cac7(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba1940de9ae09d6122c85200f1f129b3996555689a6bf7361f881508a1f4d003(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b25644b1f78e007a0e258c062400bf54a4476456783ab81f3dec773e63a65ae(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c2edebbf57855b1aeeadd48d3ea32ada2ea9915d8e65ef894f5863252ab6f24(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fe84f7a730f3f3eaa30214e782eefb8a58b34c236e1397a155ce282aa671382(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__003750c89afb2cb693e437b0e2ab460176196348e1b0389b594e6086999d9a5f(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e1c3f7290378dd17f45c90552da274afe348517103c217601de7cb026a101619(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40de66ec410aac127afcb9c27ce567d4d060dca24d8c5a9dd201ee7cbf183a5b(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae59f3ce6093e63b0c3c665876be61327f592c4a8aae5d1a665ec50473a4ec08(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e67b72c57183dedc417ef7f414f0285e3852642a6bf6fcef15418b5f8b807a3(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__843b1c3309daad02d3832fa9e3e22f90c45407328339e6f85acaf2cf5101eb69(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9288d41341c76d4af8a4724f7ebd53c84cbd12949ae8cfcaacf261cc6d6cf694(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a4e2d6829013432efb13d8278de7b76f7e69012792a900175a51ee0c718182c(
    value: typing.Optional[SnowflakeProviderTokenAccessor],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a940d5c560528b536432565e4a614be76e87a4a6fb0da98e59e3aeb1731e77a2(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c4e90f6f4be76a52332e02e7c2e2d6694806def3f30a7c4d93a4047ecdae8f2(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cf7c21a99fb03855c6474f1ebc18d02857d81c45e4ff9e0814a129f73252440(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba091dc4e4d5430d5fd0fb1241260f9c8bce1d6d655a93b3c5c7ddfeffd81683(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__722c88d139e0fef539fe7a2c455b635f297c640d9887e8ed46010e693a0ce100(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c468f152b24069a0ad470971196ade1fc2ec071355198a326bb8317c6001c28a(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c375c9b327e9ce8b32d1d503169561f636f352a30a09351e145d81f5d4fec9ad(
    *,
    account_name: typing.Optional[builtins.str] = None,
    alias: typing.Optional[builtins.str] = None,
    authenticator: typing.Optional[builtins.str] = None,
    cert_revocation_check_mode: typing.Optional[builtins.str] = None,
    client_ip: typing.Optional[builtins.str] = None,
    client_request_mfa_token: typing.Optional[builtins.str] = None,
    client_store_temporary_credential: typing.Optional[builtins.str] = None,
    client_timeout: typing.Optional[jsii.Number] = None,
    crl_allow_certificates_without_crl_url: typing.Optional[builtins.str] = None,
    crl_http_client_timeout: typing.Optional[jsii.Number] = None,
    crl_in_memory_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    crl_on_disk_cache_disabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_console_login: typing.Optional[builtins.str] = None,
    disable_ocsp_checks: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_query_context_cache: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    disable_saml_url_check: typing.Optional[builtins.str] = None,
    disable_telemetry: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    driver_tracing: typing.Optional[builtins.str] = None,
    enable_single_use_refresh_tokens: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    experimental_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    external_browser_timeout: typing.Optional[jsii.Number] = None,
    host: typing.Optional[builtins.str] = None,
    include_retry_reason: typing.Optional[builtins.str] = None,
    insecure_mode: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    jwt_client_timeout: typing.Optional[jsii.Number] = None,
    jwt_expire_timeout: typing.Optional[jsii.Number] = None,
    keep_session_alive: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    login_timeout: typing.Optional[jsii.Number] = None,
    log_query_parameters: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    log_query_text: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    max_retry_count: typing.Optional[jsii.Number] = None,
    no_proxy: typing.Optional[builtins.str] = None,
    oauth_authorization_url: typing.Optional[builtins.str] = None,
    oauth_client_id: typing.Optional[builtins.str] = None,
    oauth_client_secret: typing.Optional[builtins.str] = None,
    oauth_redirect_uri: typing.Optional[builtins.str] = None,
    oauth_scope: typing.Optional[builtins.str] = None,
    oauth_token_request_url: typing.Optional[builtins.str] = None,
    ocsp_fail_open: typing.Optional[builtins.str] = None,
    okta_url: typing.Optional[builtins.str] = None,
    organization_name: typing.Optional[builtins.str] = None,
    params: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    passcode: typing.Optional[builtins.str] = None,
    passcode_in_password: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    password: typing.Optional[builtins.str] = None,
    port: typing.Optional[jsii.Number] = None,
    preview_features_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_key: typing.Optional[builtins.str] = None,
    private_key_passphrase: typing.Optional[builtins.str] = None,
    profile: typing.Optional[builtins.str] = None,
    protocol: typing.Optional[builtins.str] = None,
    proxy_host: typing.Optional[builtins.str] = None,
    proxy_password: typing.Optional[builtins.str] = None,
    proxy_port: typing.Optional[jsii.Number] = None,
    proxy_protocol: typing.Optional[builtins.str] = None,
    proxy_user: typing.Optional[builtins.str] = None,
    request_timeout: typing.Optional[jsii.Number] = None,
    role: typing.Optional[builtins.str] = None,
    skip_toml_file_permission_verification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    tmp_directory_path: typing.Optional[builtins.str] = None,
    token: typing.Optional[builtins.str] = None,
    token_accessor: typing.Optional[typing.Union[SnowflakeProviderTokenAccessor, typing.Dict[builtins.str, typing.Any]]] = None,
    use_legacy_toml_file: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    user: typing.Optional[builtins.str] = None,
    validate_default_parameters: typing.Optional[builtins.str] = None,
    warehouse: typing.Optional[builtins.str] = None,
    workload_identity_entra_resource: typing.Optional[builtins.str] = None,
    workload_identity_provider: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce505ad3535a3780bd3b4be5de8c7dd84bf27590bda6387f04495857a6d35975(
    *,
    client_id: builtins.str,
    client_secret: builtins.str,
    redirect_uri: builtins.str,
    refresh_token: builtins.str,
    token_endpoint: builtins.str,
) -> None:
    """Type checking stubs"""
    pass
