r'''
# `data_snowflake_grants`

Refer to the Terraform Registry for docs: [`data_snowflake_grants`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class DataSnowflakeGrants(
    _cdktn_78ede62e.TerraformDataSource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrants",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants snowflake_grants}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        future_grants_in: typing.Optional[typing.Union["DataSnowflakeGrantsFutureGrantsIn", typing.Dict[builtins.str, typing.Any]]] = None,
        future_grants_to: typing.Optional[typing.Union["DataSnowflakeGrantsFutureGrantsTo", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_of: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsOf", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_on: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsOn", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_to: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsTo", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants snowflake_grants} Data Source.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param future_grants_in: future_grants_in block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_in DataSnowflakeGrants#future_grants_in}
        :param future_grants_to: future_grants_to block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_to DataSnowflakeGrants#future_grants_to}
        :param grants_of: grants_of block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_of DataSnowflakeGrants#grants_of}
        :param grants_on: grants_on block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_on DataSnowflakeGrants#grants_on}
        :param grants_to: grants_to block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_to DataSnowflakeGrants#grants_to}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#id DataSnowflakeGrants#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2cf9ec2b4f776ad611485b5bbfa6793e6882e74e3648a0ccd8894b01427865a)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = DataSnowflakeGrantsConfig(
            future_grants_in=future_grants_in,
            future_grants_to=future_grants_to,
            grants_of=grants_of,
            grants_on=grants_on,
            grants_to=grants_to,
            id=id,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a DataSnowflakeGrants resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the DataSnowflakeGrants to import.
        :param import_from_id: The id of the existing DataSnowflakeGrants that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the DataSnowflakeGrants to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aaec6695db803fe4416f77c1fdb6a00811e4b591435eb40707a4acbb289a6c10)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putFutureGrantsIn")
    def put_future_grants_in(
        self,
        *,
        database: typing.Optional[builtins.str] = None,
        schema: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param database: Lists all privileges on new (i.e. future) objects of a specified type in the database granted to a role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database DataSnowflakeGrants#database}
        :param schema: Lists all privileges on new (i.e. future) objects of a specified type in the schema granted to a role. Schema must be a fully qualified name ("<db_name>"."<schema_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#schema DataSnowflakeGrants#schema}
        '''
        value = DataSnowflakeGrantsFutureGrantsIn(database=database, schema=schema)

        return typing.cast(None, jsii.invoke(self, "putFutureGrantsIn", [value]))

    @jsii.member(jsii_name="putFutureGrantsTo")
    def put_future_grants_to(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all privileges on new (i.e. future) objects of a specified type in a database or schema granted to the account role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param database_role: Lists all privileges on new (i.e. future) objects granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        '''
        value = DataSnowflakeGrantsFutureGrantsTo(
            account_role=account_role, database_role=database_role
        )

        return typing.cast(None, jsii.invoke(self, "putFutureGrantsTo", [value]))

    @jsii.member(jsii_name="putGrantsOf")
    def put_grants_of(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        application_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
        share: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all users and roles to which the account role has been granted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param application_role: Lists all the users and roles to which the application role has been granted. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        :param database_role: Lists all users and roles to which the database role has been granted. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        :param share: Lists all the accounts for the share and indicates the accounts that are using the share. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        '''
        value = DataSnowflakeGrantsGrantsOf(
            account_role=account_role,
            application_role=application_role,
            database_role=database_role,
            share=share,
        )

        return typing.cast(None, jsii.invoke(self, "putGrantsOf", [value]))

    @jsii.member(jsii_name="putGrantsOn")
    def put_grants_on(
        self,
        *,
        account: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_name: typing.Optional[builtins.str] = None,
        object_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account: Object hierarchy to list privileges on. The only valid value is: ACCOUNT. Setting this attribute lists all the account-level (i.e. global) privileges that have been granted to roles. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account DataSnowflakeGrants#account}
        :param object_name: Name of object to list privileges on. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_name DataSnowflakeGrants#object_name}
        :param object_type: Type of object to list privileges on. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_type DataSnowflakeGrants#object_type}
        '''
        value = DataSnowflakeGrantsGrantsOn(
            account=account, object_name=object_name, object_type=object_type
        )

        return typing.cast(None, jsii.invoke(self, "putGrantsOn", [value]))

    @jsii.member(jsii_name="putGrantsTo")
    def put_grants_to(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        application: typing.Optional[builtins.str] = None,
        application_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
        share: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsToShare", typing.Dict[builtins.str, typing.Any]]] = None,
        user: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all privileges and roles granted to the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param application: Lists all the privileges and roles granted to the application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application DataSnowflakeGrants#application}
        :param application_role: Lists all the privileges and roles granted to the application role. Must be a fully qualified name ("<app_name>"."<app_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        :param database_role: Lists all privileges and roles granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        :param share: share block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        :param user: Lists all the roles granted to the user. Note that the PUBLIC role, which is automatically available to every user, is not listed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#user DataSnowflakeGrants#user}
        '''
        value = DataSnowflakeGrantsGrantsTo(
            account_role=account_role,
            application=application,
            application_role=application_role,
            database_role=database_role,
            share=share,
            user=user,
        )

        return typing.cast(None, jsii.invoke(self, "putGrantsTo", [value]))

    @jsii.member(jsii_name="resetFutureGrantsIn")
    def reset_future_grants_in(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFutureGrantsIn", []))

    @jsii.member(jsii_name="resetFutureGrantsTo")
    def reset_future_grants_to(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFutureGrantsTo", []))

    @jsii.member(jsii_name="resetGrantsOf")
    def reset_grants_of(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGrantsOf", []))

    @jsii.member(jsii_name="resetGrantsOn")
    def reset_grants_on(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGrantsOn", []))

    @jsii.member(jsii_name="resetGrantsTo")
    def reset_grants_to(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGrantsTo", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="futureGrantsIn")
    def future_grants_in(self) -> "DataSnowflakeGrantsFutureGrantsInOutputReference":
        return typing.cast("DataSnowflakeGrantsFutureGrantsInOutputReference", jsii.get(self, "futureGrantsIn"))

    @builtins.property
    @jsii.member(jsii_name="futureGrantsTo")
    def future_grants_to(self) -> "DataSnowflakeGrantsFutureGrantsToOutputReference":
        return typing.cast("DataSnowflakeGrantsFutureGrantsToOutputReference", jsii.get(self, "futureGrantsTo"))

    @builtins.property
    @jsii.member(jsii_name="grants")
    def grants(self) -> "DataSnowflakeGrantsGrantsList":
        return typing.cast("DataSnowflakeGrantsGrantsList", jsii.get(self, "grants"))

    @builtins.property
    @jsii.member(jsii_name="grantsOf")
    def grants_of(self) -> "DataSnowflakeGrantsGrantsOfOutputReference":
        return typing.cast("DataSnowflakeGrantsGrantsOfOutputReference", jsii.get(self, "grantsOf"))

    @builtins.property
    @jsii.member(jsii_name="grantsOn")
    def grants_on(self) -> "DataSnowflakeGrantsGrantsOnOutputReference":
        return typing.cast("DataSnowflakeGrantsGrantsOnOutputReference", jsii.get(self, "grantsOn"))

    @builtins.property
    @jsii.member(jsii_name="grantsTo")
    def grants_to(self) -> "DataSnowflakeGrantsGrantsToOutputReference":
        return typing.cast("DataSnowflakeGrantsGrantsToOutputReference", jsii.get(self, "grantsTo"))

    @builtins.property
    @jsii.member(jsii_name="futureGrantsInInput")
    def future_grants_in_input(
        self,
    ) -> typing.Optional["DataSnowflakeGrantsFutureGrantsIn"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsFutureGrantsIn"], jsii.get(self, "futureGrantsInInput"))

    @builtins.property
    @jsii.member(jsii_name="futureGrantsToInput")
    def future_grants_to_input(
        self,
    ) -> typing.Optional["DataSnowflakeGrantsFutureGrantsTo"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsFutureGrantsTo"], jsii.get(self, "futureGrantsToInput"))

    @builtins.property
    @jsii.member(jsii_name="grantsOfInput")
    def grants_of_input(self) -> typing.Optional["DataSnowflakeGrantsGrantsOf"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsOf"], jsii.get(self, "grantsOfInput"))

    @builtins.property
    @jsii.member(jsii_name="grantsOnInput")
    def grants_on_input(self) -> typing.Optional["DataSnowflakeGrantsGrantsOn"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsOn"], jsii.get(self, "grantsOnInput"))

    @builtins.property
    @jsii.member(jsii_name="grantsToInput")
    def grants_to_input(self) -> typing.Optional["DataSnowflakeGrantsGrantsTo"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsTo"], jsii.get(self, "grantsToInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5129811130eeb72a2d15223fe9feefa7437468f30e557229beb51908739dff5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "future_grants_in": "futureGrantsIn",
        "future_grants_to": "futureGrantsTo",
        "grants_of": "grantsOf",
        "grants_on": "grantsOn",
        "grants_to": "grantsTo",
        "id": "id",
    },
)
class DataSnowflakeGrantsConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        future_grants_in: typing.Optional[typing.Union["DataSnowflakeGrantsFutureGrantsIn", typing.Dict[builtins.str, typing.Any]]] = None,
        future_grants_to: typing.Optional[typing.Union["DataSnowflakeGrantsFutureGrantsTo", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_of: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsOf", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_on: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsOn", typing.Dict[builtins.str, typing.Any]]] = None,
        grants_to: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsTo", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param future_grants_in: future_grants_in block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_in DataSnowflakeGrants#future_grants_in}
        :param future_grants_to: future_grants_to block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_to DataSnowflakeGrants#future_grants_to}
        :param grants_of: grants_of block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_of DataSnowflakeGrants#grants_of}
        :param grants_on: grants_on block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_on DataSnowflakeGrants#grants_on}
        :param grants_to: grants_to block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_to DataSnowflakeGrants#grants_to}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#id DataSnowflakeGrants#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(future_grants_in, dict):
            future_grants_in = DataSnowflakeGrantsFutureGrantsIn(**future_grants_in)
        if isinstance(future_grants_to, dict):
            future_grants_to = DataSnowflakeGrantsFutureGrantsTo(**future_grants_to)
        if isinstance(grants_of, dict):
            grants_of = DataSnowflakeGrantsGrantsOf(**grants_of)
        if isinstance(grants_on, dict):
            grants_on = DataSnowflakeGrantsGrantsOn(**grants_on)
        if isinstance(grants_to, dict):
            grants_to = DataSnowflakeGrantsGrantsTo(**grants_to)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6d321b5d15f78cca5145e441c91d26e14c3b1daf55e5789061beb54815c8d89)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument future_grants_in", value=future_grants_in, expected_type=type_hints["future_grants_in"])
            check_type(argname="argument future_grants_to", value=future_grants_to, expected_type=type_hints["future_grants_to"])
            check_type(argname="argument grants_of", value=grants_of, expected_type=type_hints["grants_of"])
            check_type(argname="argument grants_on", value=grants_on, expected_type=type_hints["grants_on"])
            check_type(argname="argument grants_to", value=grants_to, expected_type=type_hints["grants_to"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if future_grants_in is not None:
            self._values["future_grants_in"] = future_grants_in
        if future_grants_to is not None:
            self._values["future_grants_to"] = future_grants_to
        if grants_of is not None:
            self._values["grants_of"] = grants_of
        if grants_on is not None:
            self._values["grants_on"] = grants_on
        if grants_to is not None:
            self._values["grants_to"] = grants_to
        if id is not None:
            self._values["id"] = id

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def future_grants_in(self) -> typing.Optional["DataSnowflakeGrantsFutureGrantsIn"]:
        '''future_grants_in block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_in DataSnowflakeGrants#future_grants_in}
        '''
        result = self._values.get("future_grants_in")
        return typing.cast(typing.Optional["DataSnowflakeGrantsFutureGrantsIn"], result)

    @builtins.property
    def future_grants_to(self) -> typing.Optional["DataSnowflakeGrantsFutureGrantsTo"]:
        '''future_grants_to block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#future_grants_to DataSnowflakeGrants#future_grants_to}
        '''
        result = self._values.get("future_grants_to")
        return typing.cast(typing.Optional["DataSnowflakeGrantsFutureGrantsTo"], result)

    @builtins.property
    def grants_of(self) -> typing.Optional["DataSnowflakeGrantsGrantsOf"]:
        '''grants_of block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_of DataSnowflakeGrants#grants_of}
        '''
        result = self._values.get("grants_of")
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsOf"], result)

    @builtins.property
    def grants_on(self) -> typing.Optional["DataSnowflakeGrantsGrantsOn"]:
        '''grants_on block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_on DataSnowflakeGrants#grants_on}
        '''
        result = self._values.get("grants_on")
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsOn"], result)

    @builtins.property
    def grants_to(self) -> typing.Optional["DataSnowflakeGrantsGrantsTo"]:
        '''grants_to block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#grants_to DataSnowflakeGrants#grants_to}
        '''
        result = self._values.get("grants_to")
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsTo"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#id DataSnowflakeGrants#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsFutureGrantsIn",
    jsii_struct_bases=[],
    name_mapping={"database": "database", "schema": "schema"},
)
class DataSnowflakeGrantsFutureGrantsIn:
    def __init__(
        self,
        *,
        database: typing.Optional[builtins.str] = None,
        schema: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param database: Lists all privileges on new (i.e. future) objects of a specified type in the database granted to a role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database DataSnowflakeGrants#database}
        :param schema: Lists all privileges on new (i.e. future) objects of a specified type in the schema granted to a role. Schema must be a fully qualified name ("<db_name>"."<schema_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#schema DataSnowflakeGrants#schema}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__822ff480f989179f9dac49cfc4e73b95172d84dd0ac266ec5ce0aa2932fa0d91)
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if database is not None:
            self._values["database"] = database
        if schema is not None:
            self._values["schema"] = schema

    @builtins.property
    def database(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges on new (i.e. future) objects of a specified type in the database granted to a role.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database DataSnowflakeGrants#database}
        '''
        result = self._values.get("database")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def schema(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges on new (i.e. future) objects of a specified type in the schema granted to a role. Schema must be a fully qualified name ("<db_name>"."<schema_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#schema DataSnowflakeGrants#schema}
        '''
        result = self._values.get("schema")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsFutureGrantsIn(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsFutureGrantsInOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsFutureGrantsInOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1451ecd1fa8191d69b68b09b12cc3113e6f0c97b2e7341896bd1e407d7117633)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetDatabase")
    def reset_database(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDatabase", []))

    @jsii.member(jsii_name="resetSchema")
    def reset_schema(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSchema", []))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6ef324414bbfe3fa5376f7012dcc67f849262991b51c2911ac5f9ad80c19fa3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81ed8e9e1fa62b73001b6a6c7b6d691d919611a9aa8a6900d507dbbd837b4613)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsFutureGrantsIn]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsFutureGrantsIn], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsFutureGrantsIn],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5bf8a10ad06aac7bef6034d87d08cbfdcc1bfefdf3a4967dfa55907fae8f173)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsFutureGrantsTo",
    jsii_struct_bases=[],
    name_mapping={"account_role": "accountRole", "database_role": "databaseRole"},
)
class DataSnowflakeGrantsFutureGrantsTo:
    def __init__(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all privileges on new (i.e. future) objects of a specified type in a database or schema granted to the account role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param database_role: Lists all privileges on new (i.e. future) objects granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0827d612df26b7b002d6f08f5632c555cc6a1c27281a363e37596d28069ad6db)
            check_type(argname="argument account_role", value=account_role, expected_type=type_hints["account_role"])
            check_type(argname="argument database_role", value=database_role, expected_type=type_hints["database_role"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account_role is not None:
            self._values["account_role"] = account_role
        if database_role is not None:
            self._values["database_role"] = database_role

    @builtins.property
    def account_role(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges on new (i.e. future) objects of a specified type in a database or schema granted to the account role.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        '''
        result = self._values.get("account_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def database_role(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges on new (i.e. future) objects granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        '''
        result = self._values.get("database_role")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsFutureGrantsTo(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsFutureGrantsToOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsFutureGrantsToOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97e7ec88a3af2d60ff0e5eafe5eb1cb97d34ccaa1f437c2204d03e26449ebd45)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAccountRole")
    def reset_account_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountRole", []))

    @jsii.member(jsii_name="resetDatabaseRole")
    def reset_database_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDatabaseRole", []))

    @builtins.property
    @jsii.member(jsii_name="accountRoleInput")
    def account_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseRoleInput")
    def database_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="accountRole")
    def account_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accountRole"))

    @account_role.setter
    def account_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6d144d0a8f72de6fe7866de816c71f26a900b976befb741c04b41aaa2ddb0ab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="databaseRole")
    def database_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseRole"))

    @database_role.setter
    def database_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__976218507feb88bc1f5077480273025f1afd67796eb8f97e24a18341682b35e3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "databaseRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsFutureGrantsTo]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsFutureGrantsTo], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsFutureGrantsTo],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb29ee728c82455636f4f5cd9065a671451491d12ed3bec13ee0ac946e73f200)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrants",
    jsii_struct_bases=[],
    name_mapping={},
)
class DataSnowflakeGrantsGrants:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsGrants(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsGrantsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__503cad89ffcf6e8ae331f8543d28d4581e37837802a648636c0193f66dcb07fe)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "DataSnowflakeGrantsGrantsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a17e4032e7ddbe4b55d50788829d887b603543314e37871ac2abb58542c760fb)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("DataSnowflakeGrantsGrantsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f8ca18b8b33ad823ec20206b4aaeb4103513cc8cfaeb5bc582933dadd230658)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__738e6a7085522fbfa9ad3b744b8014494f4d747e0908e7c68691d71d8f0e5fd5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb58840a71596f2323520b0f9030ff80b249bbbaabbb3d48f03a93f94fa24187)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsOf",
    jsii_struct_bases=[],
    name_mapping={
        "account_role": "accountRole",
        "application_role": "applicationRole",
        "database_role": "databaseRole",
        "share": "share",
    },
)
class DataSnowflakeGrantsGrantsOf:
    def __init__(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        application_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
        share: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all users and roles to which the account role has been granted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param application_role: Lists all the users and roles to which the application role has been granted. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        :param database_role: Lists all users and roles to which the database role has been granted. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        :param share: Lists all the accounts for the share and indicates the accounts that are using the share. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75980186a223f7c028ce1a4b8181347c484166c9a35e5e10c7109b6aa47b17ef)
            check_type(argname="argument account_role", value=account_role, expected_type=type_hints["account_role"])
            check_type(argname="argument application_role", value=application_role, expected_type=type_hints["application_role"])
            check_type(argname="argument database_role", value=database_role, expected_type=type_hints["database_role"])
            check_type(argname="argument share", value=share, expected_type=type_hints["share"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account_role is not None:
            self._values["account_role"] = account_role
        if application_role is not None:
            self._values["application_role"] = application_role
        if database_role is not None:
            self._values["database_role"] = database_role
        if share is not None:
            self._values["share"] = share

    @builtins.property
    def account_role(self) -> typing.Optional[builtins.str]:
        '''Lists all users and roles to which the account role has been granted.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        '''
        result = self._values.get("account_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def application_role(self) -> typing.Optional[builtins.str]:
        '''Lists all the users and roles to which the application role has been granted.

        Must be a fully qualified name ("<db_name>"."<database_role_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        '''
        result = self._values.get("application_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def database_role(self) -> typing.Optional[builtins.str]:
        '''Lists all users and roles to which the database role has been granted.

        Must be a fully qualified name ("<db_name>"."<database_role_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        '''
        result = self._values.get("database_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def share(self) -> typing.Optional[builtins.str]:
        '''Lists all the accounts for the share and indicates the accounts that are using the share.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        '''
        result = self._values.get("share")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsGrantsOf(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsGrantsOfOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsOfOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__908dbf0e4ccf12849bcbde303d7156075b788d9478fa482ab0f8c777c9579c43)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAccountRole")
    def reset_account_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountRole", []))

    @jsii.member(jsii_name="resetApplicationRole")
    def reset_application_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApplicationRole", []))

    @jsii.member(jsii_name="resetDatabaseRole")
    def reset_database_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDatabaseRole", []))

    @jsii.member(jsii_name="resetShare")
    def reset_share(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetShare", []))

    @builtins.property
    @jsii.member(jsii_name="accountRoleInput")
    def account_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="applicationRoleInput")
    def application_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "applicationRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseRoleInput")
    def database_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="shareInput")
    def share_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "shareInput"))

    @builtins.property
    @jsii.member(jsii_name="accountRole")
    def account_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accountRole"))

    @account_role.setter
    def account_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca67c3ac5289549443855b283469a8e48a335c6e2980621af87ca5dadc9562d1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="applicationRole")
    def application_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "applicationRole"))

    @application_role.setter
    def application_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5874bf7d2673b8ec0983425b9d02f59c73ef17140fe41767c9e0ee9d1fa4de24)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "applicationRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="databaseRole")
    def database_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseRole"))

    @database_role.setter
    def database_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b409620760931dfc6c1cf04c5d51a6ae207c0f6b0d2b2ae1cd4335585842972)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "databaseRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="share")
    def share(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "share"))

    @share.setter
    def share(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1953b14fc808d27a04e28738008af45aafd9e4e789aa1262ddca8c6cfbb85343)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "share", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsGrantsOf]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsGrantsOf], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsGrantsOf],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b96d252d006727dcc08cde25ab81e8222adae9c0fa9472151fe266d10dcef25)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsOn",
    jsii_struct_bases=[],
    name_mapping={
        "account": "account",
        "object_name": "objectName",
        "object_type": "objectType",
    },
)
class DataSnowflakeGrantsGrantsOn:
    def __init__(
        self,
        *,
        account: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_name: typing.Optional[builtins.str] = None,
        object_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account: Object hierarchy to list privileges on. The only valid value is: ACCOUNT. Setting this attribute lists all the account-level (i.e. global) privileges that have been granted to roles. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account DataSnowflakeGrants#account}
        :param object_name: Name of object to list privileges on. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_name DataSnowflakeGrants#object_name}
        :param object_type: Type of object to list privileges on. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_type DataSnowflakeGrants#object_type}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af98751185b1e53085b651d3d1d1c09a8040cfe493c97f7f00c89f94cd105c4b)
            check_type(argname="argument account", value=account, expected_type=type_hints["account"])
            check_type(argname="argument object_name", value=object_name, expected_type=type_hints["object_name"])
            check_type(argname="argument object_type", value=object_type, expected_type=type_hints["object_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account is not None:
            self._values["account"] = account
        if object_name is not None:
            self._values["object_name"] = object_name
        if object_type is not None:
            self._values["object_type"] = object_type

    @builtins.property
    def account(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Object hierarchy to list privileges on.

        The only valid value is: ACCOUNT. Setting this attribute lists all the account-level (i.e. global) privileges that have been granted to roles.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account DataSnowflakeGrants#account}
        '''
        result = self._values.get("account")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def object_name(self) -> typing.Optional[builtins.str]:
        '''Name of object to list privileges on.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_name DataSnowflakeGrants#object_name}
        '''
        result = self._values.get("object_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def object_type(self) -> typing.Optional[builtins.str]:
        '''Type of object to list privileges on.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#object_type DataSnowflakeGrants#object_type}
        '''
        result = self._values.get("object_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsGrantsOn(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsGrantsOnOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsOnOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd1c6ac6be492559dae7b7e98d851860e0bd6fae9e88c95e800d4b0e4a71c495)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAccount")
    def reset_account(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccount", []))

    @jsii.member(jsii_name="resetObjectName")
    def reset_object_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectName", []))

    @jsii.member(jsii_name="resetObjectType")
    def reset_object_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectType", []))

    @builtins.property
    @jsii.member(jsii_name="accountInput")
    def account_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "accountInput"))

    @builtins.property
    @jsii.member(jsii_name="objectNameInput")
    def object_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectNameInput"))

    @builtins.property
    @jsii.member(jsii_name="objectTypeInput")
    def object_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="account")
    def account(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "account"))

    @account.setter
    def account(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d52eee3c7097332913655c558a23cbd7e6bf5679e40db344b1bef15d400357ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "account", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectName")
    def object_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectName"))

    @object_name.setter
    def object_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57476f4cd801e3023c2659af7466792519636ed15b3a6cee91179b3f0e68a00d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectType")
    def object_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectType"))

    @object_type.setter
    def object_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83015f9cbc4595711b5c0e8f88a5fe40564889839280957c7be167fb08ae4418)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsGrantsOn]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsGrantsOn], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsGrantsOn],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa5430c0ebc09781e5c7060ffb635e1cbe4b556374c2db3c7cc34cc656f99d7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class DataSnowflakeGrantsGrantsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d073831680e80a32a608d2ac47ada57bca7c394170c2eb9a174c23dc6e1c652)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="grantedBy")
    def granted_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "grantedBy"))

    @builtins.property
    @jsii.member(jsii_name="grantedOn")
    def granted_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "grantedOn"))

    @builtins.property
    @jsii.member(jsii_name="grantedTo")
    def granted_to(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "grantedTo"))

    @builtins.property
    @jsii.member(jsii_name="granteeName")
    def grantee_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "granteeName"))

    @builtins.property
    @jsii.member(jsii_name="grantOption")
    def grant_option(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "grantOption"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="privilege")
    def privilege(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "privilege"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsGrants]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsGrants], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[DataSnowflakeGrantsGrants]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__394aff91068ca26dc5ac5997a04f344a23c358c3573535ee4dd166e117d8242f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsTo",
    jsii_struct_bases=[],
    name_mapping={
        "account_role": "accountRole",
        "application": "application",
        "application_role": "applicationRole",
        "database_role": "databaseRole",
        "share": "share",
        "user": "user",
    },
)
class DataSnowflakeGrantsGrantsTo:
    def __init__(
        self,
        *,
        account_role: typing.Optional[builtins.str] = None,
        application: typing.Optional[builtins.str] = None,
        application_role: typing.Optional[builtins.str] = None,
        database_role: typing.Optional[builtins.str] = None,
        share: typing.Optional[typing.Union["DataSnowflakeGrantsGrantsToShare", typing.Dict[builtins.str, typing.Any]]] = None,
        user: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param account_role: Lists all privileges and roles granted to the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        :param application: Lists all the privileges and roles granted to the application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application DataSnowflakeGrants#application}
        :param application_role: Lists all the privileges and roles granted to the application role. Must be a fully qualified name ("<app_name>"."<app_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        :param database_role: Lists all privileges and roles granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>"). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        :param share: share block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        :param user: Lists all the roles granted to the user. Note that the PUBLIC role, which is automatically available to every user, is not listed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#user DataSnowflakeGrants#user}
        '''
        if isinstance(share, dict):
            share = DataSnowflakeGrantsGrantsToShare(**share)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71e65ed79f84e1e95ed01756fa5af158a0cb62e8ac3674fb82160c049387e042)
            check_type(argname="argument account_role", value=account_role, expected_type=type_hints["account_role"])
            check_type(argname="argument application", value=application, expected_type=type_hints["application"])
            check_type(argname="argument application_role", value=application_role, expected_type=type_hints["application_role"])
            check_type(argname="argument database_role", value=database_role, expected_type=type_hints["database_role"])
            check_type(argname="argument share", value=share, expected_type=type_hints["share"])
            check_type(argname="argument user", value=user, expected_type=type_hints["user"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account_role is not None:
            self._values["account_role"] = account_role
        if application is not None:
            self._values["application"] = application
        if application_role is not None:
            self._values["application_role"] = application_role
        if database_role is not None:
            self._values["database_role"] = database_role
        if share is not None:
            self._values["share"] = share
        if user is not None:
            self._values["user"] = user

    @builtins.property
    def account_role(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges and roles granted to the role.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#account_role DataSnowflakeGrants#account_role}
        '''
        result = self._values.get("account_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def application(self) -> typing.Optional[builtins.str]:
        '''Lists all the privileges and roles granted to the application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application DataSnowflakeGrants#application}
        '''
        result = self._values.get("application")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def application_role(self) -> typing.Optional[builtins.str]:
        '''Lists all the privileges and roles granted to the application role. Must be a fully qualified name ("<app_name>"."<app_role_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#application_role DataSnowflakeGrants#application_role}
        '''
        result = self._values.get("application_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def database_role(self) -> typing.Optional[builtins.str]:
        '''Lists all privileges and roles granted to the database role. Must be a fully qualified name ("<db_name>"."<database_role_name>").

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#database_role DataSnowflakeGrants#database_role}
        '''
        result = self._values.get("database_role")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def share(self) -> typing.Optional["DataSnowflakeGrantsGrantsToShare"]:
        '''share block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share DataSnowflakeGrants#share}
        '''
        result = self._values.get("share")
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsToShare"], result)

    @builtins.property
    def user(self) -> typing.Optional[builtins.str]:
        '''Lists all the roles granted to the user.

        Note that the PUBLIC role, which is automatically available to every user, is not listed.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#user DataSnowflakeGrants#user}
        '''
        result = self._values.get("user")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsGrantsTo(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsGrantsToOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsToOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1057d04ae621b093f9a2f5591df72779bcff58647569c3de8e5f93329f288905)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putShare")
    def put_share(self, *, share_name: builtins.str) -> None:
        '''
        :param share_name: Lists all of the privileges and roles granted to the specified share. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share_name DataSnowflakeGrants#share_name}
        '''
        value = DataSnowflakeGrantsGrantsToShare(share_name=share_name)

        return typing.cast(None, jsii.invoke(self, "putShare", [value]))

    @jsii.member(jsii_name="resetAccountRole")
    def reset_account_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountRole", []))

    @jsii.member(jsii_name="resetApplication")
    def reset_application(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApplication", []))

    @jsii.member(jsii_name="resetApplicationRole")
    def reset_application_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApplicationRole", []))

    @jsii.member(jsii_name="resetDatabaseRole")
    def reset_database_role(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDatabaseRole", []))

    @jsii.member(jsii_name="resetShare")
    def reset_share(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetShare", []))

    @jsii.member(jsii_name="resetUser")
    def reset_user(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUser", []))

    @builtins.property
    @jsii.member(jsii_name="share")
    def share(self) -> "DataSnowflakeGrantsGrantsToShareOutputReference":
        return typing.cast("DataSnowflakeGrantsGrantsToShareOutputReference", jsii.get(self, "share"))

    @builtins.property
    @jsii.member(jsii_name="accountRoleInput")
    def account_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="applicationInput")
    def application_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "applicationInput"))

    @builtins.property
    @jsii.member(jsii_name="applicationRoleInput")
    def application_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "applicationRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseRoleInput")
    def database_role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseRoleInput"))

    @builtins.property
    @jsii.member(jsii_name="shareInput")
    def share_input(self) -> typing.Optional["DataSnowflakeGrantsGrantsToShare"]:
        return typing.cast(typing.Optional["DataSnowflakeGrantsGrantsToShare"], jsii.get(self, "shareInput"))

    @builtins.property
    @jsii.member(jsii_name="userInput")
    def user_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "userInput"))

    @builtins.property
    @jsii.member(jsii_name="accountRole")
    def account_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accountRole"))

    @account_role.setter
    def account_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b59a44aa73d2a11dcf2b83b5537bb7165578da6d023d13500368b3a91c9e960)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="application")
    def application(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "application"))

    @application.setter
    def application(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25a3392bdcda51fb0df854d2e516fdafea130c16771f7f4a2f133ada51a85191)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "application", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="applicationRole")
    def application_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "applicationRole"))

    @application_role.setter
    def application_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ab1c4fa94baac045c29fb47d8550566b2b0fa3e13a8ba93f95a160d40d0eaab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "applicationRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="databaseRole")
    def database_role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseRole"))

    @database_role.setter
    def database_role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__361a04d20ad9ab5107f47cba0473ef48ba04ba6ab50c04ddd061fca104c51724)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "databaseRole", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="user")
    def user(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "user"))

    @user.setter
    def user(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1db4e72920ffc25044e5f7d4b7fba9491c768281b9cc433e04c565237f9ce394)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "user", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsGrantsTo]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsGrantsTo], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsGrantsTo],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94c8bbd1daca811df100b41929fd9174184df6ca5ab446f0de3af6322a8416ec)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsToShare",
    jsii_struct_bases=[],
    name_mapping={"share_name": "shareName"},
)
class DataSnowflakeGrantsGrantsToShare:
    def __init__(self, *, share_name: builtins.str) -> None:
        '''
        :param share_name: Lists all of the privileges and roles granted to the specified share. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share_name DataSnowflakeGrants#share_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__602b556a4db5b685106da311a88a7956a89dc9739165ad16e3956c05c45d7cc1)
            check_type(argname="argument share_name", value=share_name, expected_type=type_hints["share_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "share_name": share_name,
        }

    @builtins.property
    def share_name(self) -> builtins.str:
        '''Lists all of the privileges and roles granted to the specified share.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/data-sources/grants#share_name DataSnowflakeGrants#share_name}
        '''
        result = self._values.get("share_name")
        assert result is not None, "Required property 'share_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DataSnowflakeGrantsGrantsToShare(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class DataSnowflakeGrantsGrantsToShareOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.dataSnowflakeGrants.DataSnowflakeGrantsGrantsToShareOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbb925fc830f343e22d463201686b556f615a6aa8a89bc1b58643adf964903f4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="shareNameInput")
    def share_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "shareNameInput"))

    @builtins.property
    @jsii.member(jsii_name="shareName")
    def share_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "shareName"))

    @share_name.setter
    def share_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95a4d79c0077c66ff1bd3365eff5050efe8aea3c848632bcfc9198b7066719b4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "shareName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[DataSnowflakeGrantsGrantsToShare]:
        return typing.cast(typing.Optional[DataSnowflakeGrantsGrantsToShare], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[DataSnowflakeGrantsGrantsToShare],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6df92663db8d417dd0ddd29b06fdc74734396ddc405ad4390d7c963e4020007a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "DataSnowflakeGrants",
    "DataSnowflakeGrantsConfig",
    "DataSnowflakeGrantsFutureGrantsIn",
    "DataSnowflakeGrantsFutureGrantsInOutputReference",
    "DataSnowflakeGrantsFutureGrantsTo",
    "DataSnowflakeGrantsFutureGrantsToOutputReference",
    "DataSnowflakeGrantsGrants",
    "DataSnowflakeGrantsGrantsList",
    "DataSnowflakeGrantsGrantsOf",
    "DataSnowflakeGrantsGrantsOfOutputReference",
    "DataSnowflakeGrantsGrantsOn",
    "DataSnowflakeGrantsGrantsOnOutputReference",
    "DataSnowflakeGrantsGrantsOutputReference",
    "DataSnowflakeGrantsGrantsTo",
    "DataSnowflakeGrantsGrantsToOutputReference",
    "DataSnowflakeGrantsGrantsToShare",
    "DataSnowflakeGrantsGrantsToShareOutputReference",
]

publication.publish()

def _typecheckingstub__d2cf9ec2b4f776ad611485b5bbfa6793e6882e74e3648a0ccd8894b01427865a(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    future_grants_in: typing.Optional[typing.Union[DataSnowflakeGrantsFutureGrantsIn, typing.Dict[builtins.str, typing.Any]]] = None,
    future_grants_to: typing.Optional[typing.Union[DataSnowflakeGrantsFutureGrantsTo, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_of: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsOf, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_on: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsOn, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_to: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsTo, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aaec6695db803fe4416f77c1fdb6a00811e4b591435eb40707a4acbb289a6c10(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5129811130eeb72a2d15223fe9feefa7437468f30e557229beb51908739dff5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6d321b5d15f78cca5145e441c91d26e14c3b1daf55e5789061beb54815c8d89(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    future_grants_in: typing.Optional[typing.Union[DataSnowflakeGrantsFutureGrantsIn, typing.Dict[builtins.str, typing.Any]]] = None,
    future_grants_to: typing.Optional[typing.Union[DataSnowflakeGrantsFutureGrantsTo, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_of: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsOf, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_on: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsOn, typing.Dict[builtins.str, typing.Any]]] = None,
    grants_to: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsTo, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__822ff480f989179f9dac49cfc4e73b95172d84dd0ac266ec5ce0aa2932fa0d91(
    *,
    database: typing.Optional[builtins.str] = None,
    schema: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1451ecd1fa8191d69b68b09b12cc3113e6f0c97b2e7341896bd1e407d7117633(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6ef324414bbfe3fa5376f7012dcc67f849262991b51c2911ac5f9ad80c19fa3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81ed8e9e1fa62b73001b6a6c7b6d691d919611a9aa8a6900d507dbbd837b4613(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5bf8a10ad06aac7bef6034d87d08cbfdcc1bfefdf3a4967dfa55907fae8f173(
    value: typing.Optional[DataSnowflakeGrantsFutureGrantsIn],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0827d612df26b7b002d6f08f5632c555cc6a1c27281a363e37596d28069ad6db(
    *,
    account_role: typing.Optional[builtins.str] = None,
    database_role: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97e7ec88a3af2d60ff0e5eafe5eb1cb97d34ccaa1f437c2204d03e26449ebd45(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6d144d0a8f72de6fe7866de816c71f26a900b976befb741c04b41aaa2ddb0ab(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__976218507feb88bc1f5077480273025f1afd67796eb8f97e24a18341682b35e3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb29ee728c82455636f4f5cd9065a671451491d12ed3bec13ee0ac946e73f200(
    value: typing.Optional[DataSnowflakeGrantsFutureGrantsTo],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__503cad89ffcf6e8ae331f8543d28d4581e37837802a648636c0193f66dcb07fe(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a17e4032e7ddbe4b55d50788829d887b603543314e37871ac2abb58542c760fb(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f8ca18b8b33ad823ec20206b4aaeb4103513cc8cfaeb5bc582933dadd230658(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__738e6a7085522fbfa9ad3b744b8014494f4d747e0908e7c68691d71d8f0e5fd5(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb58840a71596f2323520b0f9030ff80b249bbbaabbb3d48f03a93f94fa24187(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75980186a223f7c028ce1a4b8181347c484166c9a35e5e10c7109b6aa47b17ef(
    *,
    account_role: typing.Optional[builtins.str] = None,
    application_role: typing.Optional[builtins.str] = None,
    database_role: typing.Optional[builtins.str] = None,
    share: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__908dbf0e4ccf12849bcbde303d7156075b788d9478fa482ab0f8c777c9579c43(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca67c3ac5289549443855b283469a8e48a335c6e2980621af87ca5dadc9562d1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5874bf7d2673b8ec0983425b9d02f59c73ef17140fe41767c9e0ee9d1fa4de24(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b409620760931dfc6c1cf04c5d51a6ae207c0f6b0d2b2ae1cd4335585842972(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1953b14fc808d27a04e28738008af45aafd9e4e789aa1262ddca8c6cfbb85343(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b96d252d006727dcc08cde25ab81e8222adae9c0fa9472151fe266d10dcef25(
    value: typing.Optional[DataSnowflakeGrantsGrantsOf],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af98751185b1e53085b651d3d1d1c09a8040cfe493c97f7f00c89f94cd105c4b(
    *,
    account: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    object_name: typing.Optional[builtins.str] = None,
    object_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd1c6ac6be492559dae7b7e98d851860e0bd6fae9e88c95e800d4b0e4a71c495(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d52eee3c7097332913655c558a23cbd7e6bf5679e40db344b1bef15d400357ee(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57476f4cd801e3023c2659af7466792519636ed15b3a6cee91179b3f0e68a00d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83015f9cbc4595711b5c0e8f88a5fe40564889839280957c7be167fb08ae4418(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa5430c0ebc09781e5c7060ffb635e1cbe4b556374c2db3c7cc34cc656f99d7e(
    value: typing.Optional[DataSnowflakeGrantsGrantsOn],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d073831680e80a32a608d2ac47ada57bca7c394170c2eb9a174c23dc6e1c652(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__394aff91068ca26dc5ac5997a04f344a23c358c3573535ee4dd166e117d8242f(
    value: typing.Optional[DataSnowflakeGrantsGrants],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71e65ed79f84e1e95ed01756fa5af158a0cb62e8ac3674fb82160c049387e042(
    *,
    account_role: typing.Optional[builtins.str] = None,
    application: typing.Optional[builtins.str] = None,
    application_role: typing.Optional[builtins.str] = None,
    database_role: typing.Optional[builtins.str] = None,
    share: typing.Optional[typing.Union[DataSnowflakeGrantsGrantsToShare, typing.Dict[builtins.str, typing.Any]]] = None,
    user: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1057d04ae621b093f9a2f5591df72779bcff58647569c3de8e5f93329f288905(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b59a44aa73d2a11dcf2b83b5537bb7165578da6d023d13500368b3a91c9e960(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25a3392bdcda51fb0df854d2e516fdafea130c16771f7f4a2f133ada51a85191(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ab1c4fa94baac045c29fb47d8550566b2b0fa3e13a8ba93f95a160d40d0eaab(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__361a04d20ad9ab5107f47cba0473ef48ba04ba6ab50c04ddd061fca104c51724(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1db4e72920ffc25044e5f7d4b7fba9491c768281b9cc433e04c565237f9ce394(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94c8bbd1daca811df100b41929fd9174184df6ca5ab446f0de3af6322a8416ec(
    value: typing.Optional[DataSnowflakeGrantsGrantsTo],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__602b556a4db5b685106da311a88a7956a89dc9739165ad16e3956c05c45d7cc1(
    *,
    share_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbb925fc830f343e22d463201686b556f615a6aa8a89bc1b58643adf964903f4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95a4d79c0077c66ff1bd3365eff5050efe8aea3c848632bcfc9198b7066719b4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6df92663db8d417dd0ddd29b06fdc74734396ddc405ad4390d7c963e4020007a(
    value: typing.Optional[DataSnowflakeGrantsGrantsToShare],
) -> None:
    """Type checking stubs"""
    pass
