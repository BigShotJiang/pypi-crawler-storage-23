r'''
# `snowflake_stage_external_azure`

Refer to the Terraform Registry for docs: [`snowflake_stage_external_azure`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class StageExternalAzure(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzure",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure snowflake_stage_external_azure}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        url: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        credentials: typing.Optional[typing.Union["StageExternalAzureCredentials", typing.Dict[builtins.str, typing.Any]]] = None,
        directory: typing.Optional[typing.Union["StageExternalAzureDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageExternalAzureEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageExternalAzureFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        storage_integration: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageExternalAzureTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        use_privatelink_endpoint: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure snowflake_stage_external_azure} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#database StageExternalAzure#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#name StageExternalAzure#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#schema StageExternalAzure#schema}
        :param url: Specifies the URL for the Azure storage container (e.g., 'azure://account.blob.core.windows.net/container'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#url StageExternalAzure#url}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#comment StageExternalAzure#comment}
        :param credentials: credentials block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#credentials StageExternalAzure#credentials}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#directory StageExternalAzure#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encryption StageExternalAzure#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_format StageExternalAzure#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#id StageExternalAzure#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param storage_integration: Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#storage_integration StageExternalAzure#storage_integration}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timeouts StageExternalAzure#timeouts}
        :param use_privatelink_endpoint: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to use a private link endpoint for Azure storage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_privatelink_endpoint StageExternalAzure#use_privatelink_endpoint}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d78e3c56f6503ff4f153964e686b0b63817cb6f9fd12db45f678d304384780cd)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = StageExternalAzureConfig(
            database=database,
            name=name,
            schema=schema,
            url=url,
            comment=comment,
            credentials=credentials,
            directory=directory,
            encryption=encryption,
            file_format=file_format,
            id=id,
            storage_integration=storage_integration,
            timeouts=timeouts,
            use_privatelink_endpoint=use_privatelink_endpoint,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a StageExternalAzure resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the StageExternalAzure to import.
        :param import_from_id: The id of the existing StageExternalAzure that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the StageExternalAzure to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bc42aed2359109591b4b5ce6aae9871ce192592eddb63ce3fa9ac852675e9031)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putCredentials")
    def put_credentials(self, *, azure_sas_token: builtins.str) -> None:
        '''
        :param azure_sas_token: Specifies the shared access signature (SAS) token for Azure. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_sas_token StageExternalAzure#azure_sas_token}
        '''
        value = StageExternalAzureCredentials(azure_sas_token=azure_sas_token)

        return typing.cast(None, jsii.invoke(self, "putCredentials", [value]))

    @jsii.member(jsii_name="putDirectory")
    def put_directory(
        self,
        *,
        enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        auto_refresh: typing.Optional[builtins.str] = None,
        notification_integration: typing.Optional[builtins.str] = None,
        refresh_on_create: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the external stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable StageExternalAzure#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#auto_refresh StageExternalAzure#auto_refresh}
        :param notification_integration: Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#notification_integration StageExternalAzure#notification_integration}
        :param refresh_on_create: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#refresh_on_create StageExternalAzure#refresh_on_create}
        '''
        value = StageExternalAzureDirectory(
            enable=enable,
            auto_refresh=auto_refresh,
            notification_integration=notification_integration,
            refresh_on_create=refresh_on_create,
        )

        return typing.cast(None, jsii.invoke(self, "putDirectory", [value]))

    @jsii.member(jsii_name="putEncryption")
    def put_encryption(
        self,
        *,
        azure_cse: typing.Optional[typing.Union["StageExternalAzureEncryptionAzureCse", typing.Dict[builtins.str, typing.Any]]] = None,
        none: typing.Optional[typing.Union["StageExternalAzureEncryptionNone", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param azure_cse: azure_cse block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_cse StageExternalAzure#azure_cse}
        :param none: none block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#none StageExternalAzure#none}
        '''
        value = StageExternalAzureEncryption(azure_cse=azure_cse, none=none)

        return typing.cast(None, jsii.invoke(self, "putEncryption", [value]))

    @jsii.member(jsii_name="putFileFormat")
    def put_file_format(
        self,
        *,
        avro: typing.Optional[typing.Union["StageExternalAzureFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageExternalAzureFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageExternalAzureFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageExternalAzureFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageExternalAzureFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageExternalAzureFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#avro StageExternalAzure#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#csv StageExternalAzure#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#format_name StageExternalAzure#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#json StageExternalAzure#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#orc StageExternalAzure#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parquet StageExternalAzure#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#xml StageExternalAzure#xml}
        '''
        value = StageExternalAzureFileFormat(
            avro=avro,
            csv=csv,
            format_name=format_name,
            json=json,
            orc=orc,
            parquet=parquet,
            xml=xml,
        )

        return typing.cast(None, jsii.invoke(self, "putFileFormat", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#create StageExternalAzure#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#delete StageExternalAzure#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#read StageExternalAzure#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#update StageExternalAzure#update}.
        '''
        value = StageExternalAzureTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetCredentials")
    def reset_credentials(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCredentials", []))

    @jsii.member(jsii_name="resetDirectory")
    def reset_directory(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDirectory", []))

    @jsii.member(jsii_name="resetEncryption")
    def reset_encryption(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncryption", []))

    @jsii.member(jsii_name="resetFileFormat")
    def reset_file_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileFormat", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetStorageIntegration")
    def reset_storage_integration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStorageIntegration", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetUsePrivatelinkEndpoint")
    def reset_use_privatelink_endpoint(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUsePrivatelinkEndpoint", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="cloud")
    def cloud(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cloud"))

    @builtins.property
    @jsii.member(jsii_name="credentials")
    def credentials(self) -> "StageExternalAzureCredentialsOutputReference":
        return typing.cast("StageExternalAzureCredentialsOutputReference", jsii.get(self, "credentials"))

    @builtins.property
    @jsii.member(jsii_name="describeOutput")
    def describe_output(self) -> "StageExternalAzureDescribeOutputList":
        return typing.cast("StageExternalAzureDescribeOutputList", jsii.get(self, "describeOutput"))

    @builtins.property
    @jsii.member(jsii_name="directory")
    def directory(self) -> "StageExternalAzureDirectoryOutputReference":
        return typing.cast("StageExternalAzureDirectoryOutputReference", jsii.get(self, "directory"))

    @builtins.property
    @jsii.member(jsii_name="encryption")
    def encryption(self) -> "StageExternalAzureEncryptionOutputReference":
        return typing.cast("StageExternalAzureEncryptionOutputReference", jsii.get(self, "encryption"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> "StageExternalAzureFileFormatOutputReference":
        return typing.cast("StageExternalAzureFileFormatOutputReference", jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="fullyQualifiedName")
    def fully_qualified_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullyQualifiedName"))

    @builtins.property
    @jsii.member(jsii_name="showOutput")
    def show_output(self) -> "StageExternalAzureShowOutputList":
        return typing.cast("StageExternalAzureShowOutputList", jsii.get(self, "showOutput"))

    @builtins.property
    @jsii.member(jsii_name="stageType")
    def stage_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stageType"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "StageExternalAzureTimeoutsOutputReference":
        return typing.cast("StageExternalAzureTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="credentialsInput")
    def credentials_input(self) -> typing.Optional["StageExternalAzureCredentials"]:
        return typing.cast(typing.Optional["StageExternalAzureCredentials"], jsii.get(self, "credentialsInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="directoryInput")
    def directory_input(self) -> typing.Optional["StageExternalAzureDirectory"]:
        return typing.cast(typing.Optional["StageExternalAzureDirectory"], jsii.get(self, "directoryInput"))

    @builtins.property
    @jsii.member(jsii_name="encryptionInput")
    def encryption_input(self) -> typing.Optional["StageExternalAzureEncryption"]:
        return typing.cast(typing.Optional["StageExternalAzureEncryption"], jsii.get(self, "encryptionInput"))

    @builtins.property
    @jsii.member(jsii_name="fileFormatInput")
    def file_format_input(self) -> typing.Optional["StageExternalAzureFileFormat"]:
        return typing.cast(typing.Optional["StageExternalAzureFileFormat"], jsii.get(self, "fileFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="storageIntegrationInput")
    def storage_integration_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "storageIntegrationInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "StageExternalAzureTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "StageExternalAzureTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="urlInput")
    def url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "urlInput"))

    @builtins.property
    @jsii.member(jsii_name="usePrivatelinkEndpointInput")
    def use_privatelink_endpoint_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "usePrivatelinkEndpointInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a961e52249984c8d2e05e7cca4c579a12eccacf4aee0b2ff9cc867ba02e7352e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a12ce798225ad3c65313e3525a4b676e58cf4ddb39c0c18b776a94cdf7c4cef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5189d8a72c4d3468c96eec438a11aed2533d7c51228d9087fdd40d2b710529fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5b9ad04105f80ae99d13ba3e1c5d8aacceefe5701f9a6032c2a72156b2b5552)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d40b747678a2a93691164d287e0352aac6ab0b051ed2f468dd031b67ac753c3e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="storageIntegration")
    def storage_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "storageIntegration"))

    @storage_integration.setter
    def storage_integration(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7257969edcc6d9af07aa9524f71fc299869f4b928b5958fe58423dbbc540ed3f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "storageIntegration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @url.setter
    def url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2be4aa3499e68a93b7222b9af483083d241ae18894f8d7a87a7054e8e6ec9812)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "url", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="usePrivatelinkEndpoint")
    def use_privatelink_endpoint(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "usePrivatelinkEndpoint"))

    @use_privatelink_endpoint.setter
    def use_privatelink_endpoint(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7dc996cfcef8c3d5c842095ba7ce708b10d5199997a98fa3d1798975060edb2c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "usePrivatelinkEndpoint", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "database": "database",
        "name": "name",
        "schema": "schema",
        "url": "url",
        "comment": "comment",
        "credentials": "credentials",
        "directory": "directory",
        "encryption": "encryption",
        "file_format": "fileFormat",
        "id": "id",
        "storage_integration": "storageIntegration",
        "timeouts": "timeouts",
        "use_privatelink_endpoint": "usePrivatelinkEndpoint",
    },
)
class StageExternalAzureConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        url: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        credentials: typing.Optional[typing.Union["StageExternalAzureCredentials", typing.Dict[builtins.str, typing.Any]]] = None,
        directory: typing.Optional[typing.Union["StageExternalAzureDirectory", typing.Dict[builtins.str, typing.Any]]] = None,
        encryption: typing.Optional[typing.Union["StageExternalAzureEncryption", typing.Dict[builtins.str, typing.Any]]] = None,
        file_format: typing.Optional[typing.Union["StageExternalAzureFileFormat", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        storage_integration: typing.Optional[builtins.str] = None,
        timeouts: typing.Optional[typing.Union["StageExternalAzureTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        use_privatelink_endpoint: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param database: The database in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#database StageExternalAzure#database}
        :param name: Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#name StageExternalAzure#name}
        :param schema: The schema in which to create the stage. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#schema StageExternalAzure#schema}
        :param url: Specifies the URL for the Azure storage container (e.g., 'azure://account.blob.core.windows.net/container'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#url StageExternalAzure#url}
        :param comment: Specifies a comment for the stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#comment StageExternalAzure#comment}
        :param credentials: credentials block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#credentials StageExternalAzure#credentials}
        :param directory: directory block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#directory StageExternalAzure#directory}
        :param encryption: encryption block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encryption StageExternalAzure#encryption}
        :param file_format: file_format block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_format StageExternalAzure#file_format}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#id StageExternalAzure#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param storage_integration: Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#storage_integration StageExternalAzure#storage_integration}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timeouts StageExternalAzure#timeouts}
        :param use_privatelink_endpoint: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to use a private link endpoint for Azure storage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_privatelink_endpoint StageExternalAzure#use_privatelink_endpoint}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(credentials, dict):
            credentials = StageExternalAzureCredentials(**credentials)
        if isinstance(directory, dict):
            directory = StageExternalAzureDirectory(**directory)
        if isinstance(encryption, dict):
            encryption = StageExternalAzureEncryption(**encryption)
        if isinstance(file_format, dict):
            file_format = StageExternalAzureFileFormat(**file_format)
        if isinstance(timeouts, dict):
            timeouts = StageExternalAzureTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f2ffad54b701badbfd81929130332e476f46459b4f0e4adbd1677277952e8d0)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument credentials", value=credentials, expected_type=type_hints["credentials"])
            check_type(argname="argument directory", value=directory, expected_type=type_hints["directory"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument file_format", value=file_format, expected_type=type_hints["file_format"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument storage_integration", value=storage_integration, expected_type=type_hints["storage_integration"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument use_privatelink_endpoint", value=use_privatelink_endpoint, expected_type=type_hints["use_privatelink_endpoint"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "database": database,
            "name": name,
            "schema": schema,
            "url": url,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if comment is not None:
            self._values["comment"] = comment
        if credentials is not None:
            self._values["credentials"] = credentials
        if directory is not None:
            self._values["directory"] = directory
        if encryption is not None:
            self._values["encryption"] = encryption
        if file_format is not None:
            self._values["file_format"] = file_format
        if id is not None:
            self._values["id"] = id
        if storage_integration is not None:
            self._values["storage_integration"] = storage_integration
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if use_privatelink_endpoint is not None:
            self._values["use_privatelink_endpoint"] = use_privatelink_endpoint

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def database(self) -> builtins.str:
        '''The database in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#database StageExternalAzure#database}
        '''
        result = self._values.get("database")
        assert result is not None, "Required property 'database' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Specifies the identifier for the stage;

        must be unique for the database and schema in which the stage is created. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#name StageExternalAzure#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> builtins.str:
        '''The schema in which to create the stage.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#schema StageExternalAzure#schema}
        '''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def url(self) -> builtins.str:
        '''Specifies the URL for the Azure storage container (e.g., 'azure://account.blob.core.windows.net/container').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#url StageExternalAzure#url}
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#comment StageExternalAzure#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def credentials(self) -> typing.Optional["StageExternalAzureCredentials"]:
        '''credentials block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#credentials StageExternalAzure#credentials}
        '''
        result = self._values.get("credentials")
        return typing.cast(typing.Optional["StageExternalAzureCredentials"], result)

    @builtins.property
    def directory(self) -> typing.Optional["StageExternalAzureDirectory"]:
        '''directory block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#directory StageExternalAzure#directory}
        '''
        result = self._values.get("directory")
        return typing.cast(typing.Optional["StageExternalAzureDirectory"], result)

    @builtins.property
    def encryption(self) -> typing.Optional["StageExternalAzureEncryption"]:
        '''encryption block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encryption StageExternalAzure#encryption}
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["StageExternalAzureEncryption"], result)

    @builtins.property
    def file_format(self) -> typing.Optional["StageExternalAzureFileFormat"]:
        '''file_format block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_format StageExternalAzure#file_format}
        '''
        result = self._values.get("file_format")
        return typing.cast(typing.Optional["StageExternalAzureFileFormat"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#id StageExternalAzure#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def storage_integration(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#storage_integration StageExternalAzure#storage_integration}
        '''
        result = self._values.get("storage_integration")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["StageExternalAzureTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timeouts StageExternalAzure#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["StageExternalAzureTimeouts"], result)

    @builtins.property
    def use_privatelink_endpoint(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to use a private link endpoint for Azure storage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_privatelink_endpoint StageExternalAzure#use_privatelink_endpoint}
        '''
        result = self._values.get("use_privatelink_endpoint")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureCredentials",
    jsii_struct_bases=[],
    name_mapping={"azure_sas_token": "azureSasToken"},
)
class StageExternalAzureCredentials:
    def __init__(self, *, azure_sas_token: builtins.str) -> None:
        '''
        :param azure_sas_token: Specifies the shared access signature (SAS) token for Azure. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_sas_token StageExternalAzure#azure_sas_token}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e974e8e752756d09d9a57683a2aa51fd4d4ef0dcba8d55e60844233b6333cdb)
            check_type(argname="argument azure_sas_token", value=azure_sas_token, expected_type=type_hints["azure_sas_token"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "azure_sas_token": azure_sas_token,
        }

    @builtins.property
    def azure_sas_token(self) -> builtins.str:
        '''Specifies the shared access signature (SAS) token for Azure.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_sas_token StageExternalAzure#azure_sas_token}
        '''
        result = self._values.get("azure_sas_token")
        assert result is not None, "Required property 'azure_sas_token' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureCredentials(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureCredentialsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureCredentialsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f02c8ce1e33bd1ffb4934760167f12e863b7e0de8d3310f0f467676b6d421cbb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="azureSasTokenInput")
    def azure_sas_token_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "azureSasTokenInput"))

    @builtins.property
    @jsii.member(jsii_name="azureSasToken")
    def azure_sas_token(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "azureSasToken"))

    @azure_sas_token.setter
    def azure_sas_token(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66bd71b41c304b3aac45153100178b9b0e5c66c8f3e2bd958c7317b9feeede35)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "azureSasToken", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureCredentials]:
        return typing.cast(typing.Optional[StageExternalAzureCredentials], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureCredentials],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db9177854ad7ca6e0f0146d910ea8dedf4c07c9d6c9b2ccedf2ddd96f2e94a2e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputDirectoryTable",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputDirectoryTable:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputDirectoryTable(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputDirectoryTableList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputDirectoryTableList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14cb22e9e796ec0f428d7fc47a2b5764e549d4c041c616223f0b738b04be35bb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputDirectoryTableOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__947334cdd470a6237026221ae1db30984c966a81e6f49f2ef9b39248d99368d4)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputDirectoryTableOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a843d762ab23a917a361d37cae6db4a03069207f374a2a6010bca2335a2a8fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09dfba0a9aa0cbb3ce4da55893f30168642bd3cbbd466b633c8c6445d1f0d0ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebb0c13553849903a56e7b8ae57cf947737ac181138eb9f23ec00e7664f1387f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputDirectoryTableOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputDirectoryTableOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__582a32a23eff732df85739635e9f4aa68e336c629811d6e24134e9e488643455)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "autoRefresh"))

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enable"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputDirectoryTable]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputDirectoryTable], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputDirectoryTable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__410622bc6b1a7965c612384e42ab0710a434a3b0d1cb1c2abcf40b43a4244f80)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormat",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormat:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatAvro:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatAvroList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatAvroList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__441459f8e806df3bd5107e381a8f99888b346c1b5852504cd5e939c2ea609acc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatAvroOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdf276c0d075928820dcf28b79e41a0a098e3f7d41c767f866b1ef7d4802d1e5)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatAvroOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__adc33650312e705615e996e89fc702ef67a9e94ae2f78907e41f483fffd965bc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5998f68ccd0a3e0eef534dd1ee2744730c6811173e4731b0057bf685b582be4e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60a17b8b14fcebb123d045edfd53c8b1741140e0c824f166e70ce734df69d505)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e77f375eca2e061f1a7df736033f907063cb9bad6f38f7ccdd174b8ba5364031)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatAvro], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatAvro],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ee538aeb7e52596d29d56807685427abd35027b5f991aeea699dada4e3c3f98)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatCsv:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatCsvList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatCsvList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2033f23ef1b4dedc404d8e2cfa03f834e457a98587af903c621e2140298e6a74)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatCsvOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28aedfaa4e400ee4f6380aa228d7fa599f385fcc3cd80d1b2b32b777b26817b4)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatCsvOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6f08bef9e947420d9b1c151b72cfe7bd0091ea6d61bef65a72c041b5dfb3b04)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6973902cf34154fc076daa7ba0b4fe6536aa2162a186ac2d5840e2e7147b3ca1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47f0b10aeea81ccc3ea1ac739cff85c721fe25d88505be9756aafeabe3c19883)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8dde9f57f13ff1b1f305bac2ef210c6ce4a54da97456d58ba4c6cc6376f02125)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "emptyFieldAsNull"))

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "errorOnColumnCountMismatch"))

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "parseHeader"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipBlankLines"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="validateUtf8")
    def validate_utf8(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "validateUtf8"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatCsv], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatCsv],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03ff5ece30065f27141b3a0f210f73ba37ef362b2d9adcd774c42a90508db2a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatJson:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatJsonList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatJsonList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa19df0eca2762bc9f68ce80bc07a9d2540dac1b0a2ed16bec496af71ac64c7d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatJsonOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c32fba7a7659131d865f75aaf4536c93a29cf29ff8272235078945da28a29f1f)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatJsonOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__347f001282b4b1a66a2b47bd6f90617437cd5ed5ea7e2b3fd371bd9d55848e0b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93883a685b49b9f3ab145d588c845287fd6a8e88081f7c81579a8fc847c5e129)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d20de59df21e1aca73a403c0ee8367a5bb6bef2dc08cfedddec7477a8b6c5dc0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf1e4d293eae19ed0cc8ad0c521a4283b08b6e9eace9390ba46957b08f862a58)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "allowDuplicate"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enableOctal"))

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "multiLine"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripNullValues"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripOuterArray"))

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatJson], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatJson],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__985a5cf1698430231c22c34c9b556231fbb4fefee9fedb2faf990f58dbdaef3e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3821eb10f6b049565a1382e5d5df5d6be4195806ee2619f55b5dca84ebe2772d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ddc64af0e8864347ffca1ac0f5029772d1b10981bc7fbdaf5364f5efbb7680a5)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2658d25f4b39b332fa34ffeb46f60c3590fe45bbb9f352c545e2b8dc6f70d20)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c053fb41b7f9b3e163ccc27ab33c7260e70ed74aa4fa57ccda4d9d01c5487f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41432ffdac6cb530386559f6372a02eb1e8a251f608ad8411a85f0a6a4b7ab06)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatOrc:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatOrcList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatOrcList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38857453be24ccf8cb4b1a649a0559f5e95166249c5931770c4f5f3af0c2545b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatOrcOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c6fabc13fbfbf32d708c67fefc13b88d16cc693b1a06caa9f8e39b51f35973e7)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatOrcOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d764e984208750b0cf5a64d0567f645d3867f01f84482ccf1f465f2f2477dc0d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2bdd3b0319d4c4047d57486300ba60a2d2132c38706aedcb0deb68731d7203f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65db7cb6a0b030019514c007e54967ddc888ad843e00f93d3ec63089a3580eb3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4508b9bbfc333cbbd0d2507ba2ba5076c4ee5bedb0d9f63ddc5016ef0fca9439)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatOrc], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatOrc],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__891a8555181346462148440c7880ee9d12e4529b38a95f69ee92e4e4b0225e88)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c38601f7c0a5fc2fa6ff320c0474134176c5a604d1a10047ae6db5e933bd38cf)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> StageExternalAzureDescribeOutputFileFormatAvroList:
        return typing.cast(StageExternalAzureDescribeOutputFileFormatAvroList, jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> StageExternalAzureDescribeOutputFileFormatCsvList:
        return typing.cast(StageExternalAzureDescribeOutputFileFormatCsvList, jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> StageExternalAzureDescribeOutputFileFormatJsonList:
        return typing.cast(StageExternalAzureDescribeOutputFileFormatJsonList, jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> StageExternalAzureDescribeOutputFileFormatOrcList:
        return typing.cast(StageExternalAzureDescribeOutputFileFormatOrcList, jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageExternalAzureDescribeOutputFileFormatParquetList":
        return typing.cast("StageExternalAzureDescribeOutputFileFormatParquetList", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageExternalAzureDescribeOutputFileFormatXmlList":
        return typing.cast("StageExternalAzureDescribeOutputFileFormatXmlList", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormat]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormat], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormat],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6eb73fe07dd3e52170aa8c9344df31c955fad6d2c7d05088371a7fc4b57941de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatParquet:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatParquetList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatParquetList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9737fc880d3588494fe73825e87310e7dac058adc7d2a3656b08ec0ac9bb030c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatParquetOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e4724e4f89ffe66654cded0802cf1fb0329ca4b1a49145141b8768799ab6d5d)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatParquetOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6471f6c75b031c4727858ebdd9d53a07b6fe2c268dc916d8099cf99b21d786a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__15ccc342fd1b181dc9dad7545bf85586c710daef39cd362ba67b54e864d5b09b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39c41333bee35cb19b519f06381bc549f8f3f6ed9c974f3e85b16ea2b1c60f0f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce42abf671a0ee689715e3a5017ccf7b63d984801709b94d18a5b955e349e7ae)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "binaryAsText"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "trimSpace"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "useLogicalType"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "useVectorizedScanner"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatParquet]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatParquet], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatParquet],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6a7aaf17d9d1bac3d76bae817bd64b31810b7ae07fad37b04b3c14a4c19e810)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureDescribeOutputFileFormatXml:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDescribeOutputFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDescribeOutputFileFormatXmlList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatXmlList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a21fe5dfb04df1edfeb5ebd7839a7ffea04db4db74a0a6b5233a7cc7fbee372)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputFileFormatXmlOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__992836ccff6891ac1e570d4d9e0700572d7bbe908bc21fe483c512582f8ef3c0)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputFileFormatXmlOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__308c6017bdd2831c84096f5e900b96d32058bf1adc83edd9c5e2d452bb27ed6e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__968fba9d6bf01d6bcb9f61140ef3f41e2106fdcd6c93ae226ce6334f65c0b043)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1cec687546653c32b9fa3652277f86a916d11c1265cdbc431a5c29db174721a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db3fba1a8fc591055f8bb533f913f7ae094dfd4ef5c131031eb7432ee07f191d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "disableAutoConvert"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "ignoreUtf8Errors"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "preserveSpace"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "replaceInvalidCharacters"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "skipByteOrderMark"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "stripOuterElement"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[StageExternalAzureDescribeOutputFileFormatXml]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutputFileFormatXml], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutputFileFormatXml],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7594ac6061d14573e2ef5538592c4727afcca6d7093b55cd75cd05f1507d1be0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e032411a68dbcb015b12cb1ccc13e254b2bf15f72780b18f49c5a0a6cc4d9ce)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "StageExternalAzureDescribeOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4414d073a609e2be783ad77a0872300f119f09d5a7ac0add1998c0ebad46a6c6)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureDescribeOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84680c4fa09a802c3b0fd18cc720626b0a8ed4204fffa567bee9c61e579a1366)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3bc2d81acefc2ab065d4bda20d0e5108e30fe9cef6fc40b6e2b4b39eb906c6eb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f8e62199a5b979c79fa4f1d44e15cf1b2477ebc42862ac98342cd6b5b9feb97)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureDescribeOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDescribeOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__251f872d58900f171696aeb5ad298405b4ec946273413e86d6450d357e8346a4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="directoryTable")
    def directory_table(self) -> StageExternalAzureDescribeOutputDirectoryTableList:
        return typing.cast(StageExternalAzureDescribeOutputDirectoryTableList, jsii.get(self, "directoryTable"))

    @builtins.property
    @jsii.member(jsii_name="fileFormat")
    def file_format(self) -> StageExternalAzureDescribeOutputFileFormatList:
        return typing.cast(StageExternalAzureDescribeOutputFileFormatList, jsii.get(self, "fileFormat"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureDescribeOutput]:
        return typing.cast(typing.Optional[StageExternalAzureDescribeOutput], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDescribeOutput],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88f8feccc7505b6cdf293fe63f8677f9c2a81c8caba80477bfc797c44962272d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDirectory",
    jsii_struct_bases=[],
    name_mapping={
        "enable": "enable",
        "auto_refresh": "autoRefresh",
        "notification_integration": "notificationIntegration",
        "refresh_on_create": "refreshOnCreate",
    },
)
class StageExternalAzureDirectory:
    def __init__(
        self,
        *,
        enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        auto_refresh: typing.Optional[builtins.str] = None,
        notification_integration: typing.Optional[builtins.str] = None,
        refresh_on_create: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param enable: Specifies whether to enable a directory table on the external stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable StageExternalAzure#enable}
        :param auto_refresh: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#auto_refresh StageExternalAzure#auto_refresh}
        :param notification_integration: Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#notification_integration StageExternalAzure#notification_integration}
        :param refresh_on_create: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#refresh_on_create StageExternalAzure#refresh_on_create}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00a243eb7b40b9df82931ed619b5e065e5d83d212e5fef2005945c30f6d9f4b3)
            check_type(argname="argument enable", value=enable, expected_type=type_hints["enable"])
            check_type(argname="argument auto_refresh", value=auto_refresh, expected_type=type_hints["auto_refresh"])
            check_type(argname="argument notification_integration", value=notification_integration, expected_type=type_hints["notification_integration"])
            check_type(argname="argument refresh_on_create", value=refresh_on_create, expected_type=type_hints["refresh_on_create"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enable": enable,
        }
        if auto_refresh is not None:
            self._values["auto_refresh"] = auto_refresh
        if notification_integration is not None:
            self._values["notification_integration"] = notification_integration
        if refresh_on_create is not None:
            self._values["refresh_on_create"] = refresh_on_create

    @builtins.property
    def enable(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Specifies whether to enable a directory table on the external stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable StageExternalAzure#enable}
        '''
        result = self._values.get("enable")
        assert result is not None, "Required property 'enable' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def auto_refresh(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#auto_refresh StageExternalAzure#auto_refresh}
        '''
        result = self._values.get("auto_refresh")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def notification_integration(self) -> typing.Optional[builtins.str]:
        '''Specifies the name of the notification integration used to automatically refresh the directory table metadata.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#notification_integration StageExternalAzure#notification_integration}
        '''
        result = self._values.get("notification_integration")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def refresh_on_create(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#refresh_on_create StageExternalAzure#refresh_on_create}
        '''
        result = self._values.get("refresh_on_create")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureDirectory(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureDirectoryOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureDirectoryOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df1251c84050bbee5fa852f02cf66d0be7cd17cf96422480867979764335d78f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAutoRefresh")
    def reset_auto_refresh(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoRefresh", []))

    @jsii.member(jsii_name="resetNotificationIntegration")
    def reset_notification_integration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNotificationIntegration", []))

    @jsii.member(jsii_name="resetRefreshOnCreate")
    def reset_refresh_on_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRefreshOnCreate", []))

    @builtins.property
    @jsii.member(jsii_name="autoRefreshInput")
    def auto_refresh_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "autoRefreshInput"))

    @builtins.property
    @jsii.member(jsii_name="enableInput")
    def enable_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enableInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationIntegrationInput")
    def notification_integration_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationIntegrationInput"))

    @builtins.property
    @jsii.member(jsii_name="refreshOnCreateInput")
    def refresh_on_create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "refreshOnCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="autoRefresh")
    def auto_refresh(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autoRefresh"))

    @auto_refresh.setter
    def auto_refresh(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b94b3e4e1b5d81d877a38da3bf96ca68be266caa7af578b02eb0d8cd6eedf82)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoRefresh", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enable")
    def enable(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enable"))

    @enable.setter
    def enable(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0d945ea5f4f661f391828ce7dca532bf1cd76c14c361a1b0721633c5f902d0b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enable", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationIntegration")
    def notification_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationIntegration"))

    @notification_integration.setter
    def notification_integration(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f7b114cd9e6b1a694b4dbae7305f0c3075e0dbe94b242aee494b91ae6f4a166)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationIntegration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="refreshOnCreate")
    def refresh_on_create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "refreshOnCreate"))

    @refresh_on_create.setter
    def refresh_on_create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__abecb05836662e2397b235ac9f89acdf02484694d934b987201c52623505d8cb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "refreshOnCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureDirectory]:
        return typing.cast(typing.Optional[StageExternalAzureDirectory], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureDirectory],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45bce95001bb9152d3da4c43d64eb5818ffaf48124a99f5da55057ee72bf6ca2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryption",
    jsii_struct_bases=[],
    name_mapping={"azure_cse": "azureCse", "none": "none"},
)
class StageExternalAzureEncryption:
    def __init__(
        self,
        *,
        azure_cse: typing.Optional[typing.Union["StageExternalAzureEncryptionAzureCse", typing.Dict[builtins.str, typing.Any]]] = None,
        none: typing.Optional[typing.Union["StageExternalAzureEncryptionNone", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param azure_cse: azure_cse block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_cse StageExternalAzure#azure_cse}
        :param none: none block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#none StageExternalAzure#none}
        '''
        if isinstance(azure_cse, dict):
            azure_cse = StageExternalAzureEncryptionAzureCse(**azure_cse)
        if isinstance(none, dict):
            none = StageExternalAzureEncryptionNone(**none)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2bd072f1d26b07f44a7876b7846606b12440ef1b83437ad52f23d129f5be69b6)
            check_type(argname="argument azure_cse", value=azure_cse, expected_type=type_hints["azure_cse"])
            check_type(argname="argument none", value=none, expected_type=type_hints["none"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if azure_cse is not None:
            self._values["azure_cse"] = azure_cse
        if none is not None:
            self._values["none"] = none

    @builtins.property
    def azure_cse(self) -> typing.Optional["StageExternalAzureEncryptionAzureCse"]:
        '''azure_cse block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#azure_cse StageExternalAzure#azure_cse}
        '''
        result = self._values.get("azure_cse")
        return typing.cast(typing.Optional["StageExternalAzureEncryptionAzureCse"], result)

    @builtins.property
    def none(self) -> typing.Optional["StageExternalAzureEncryptionNone"]:
        '''none block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#none StageExternalAzure#none}
        '''
        result = self._values.get("none")
        return typing.cast(typing.Optional["StageExternalAzureEncryptionNone"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureEncryption(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryptionAzureCse",
    jsii_struct_bases=[],
    name_mapping={"master_key": "masterKey"},
)
class StageExternalAzureEncryptionAzureCse:
    def __init__(self, *, master_key: builtins.str) -> None:
        '''
        :param master_key: Specifies the 128-bit or 256-bit client-side master key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#master_key StageExternalAzure#master_key}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e40aeb22864c2f263e20d2d5b85fbbed4f174326f0281216fccb866f9fbd760b)
            check_type(argname="argument master_key", value=master_key, expected_type=type_hints["master_key"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "master_key": master_key,
        }

    @builtins.property
    def master_key(self) -> builtins.str:
        '''Specifies the 128-bit or 256-bit client-side master key.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#master_key StageExternalAzure#master_key}
        '''
        result = self._values.get("master_key")
        assert result is not None, "Required property 'master_key' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureEncryptionAzureCse(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureEncryptionAzureCseOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryptionAzureCseOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__671d6bd3336a6a2a56470c19fafde408adf2933c7feace7132a287082fdfe98d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="masterKeyInput")
    def master_key_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "masterKeyInput"))

    @builtins.property
    @jsii.member(jsii_name="masterKey")
    def master_key(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "masterKey"))

    @master_key.setter
    def master_key(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05d21b9b3c3cc85a409178f36b3e852283c4a896a70c9accc16785d7762ec872)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "masterKey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureEncryptionAzureCse]:
        return typing.cast(typing.Optional[StageExternalAzureEncryptionAzureCse], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureEncryptionAzureCse],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39c75c27395d4b4f96e5e4b8f01b4a2e8378b6fdab5e2119c5cf137957155f8e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryptionNone",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureEncryptionNone:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureEncryptionNone(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureEncryptionNoneOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryptionNoneOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d74e50b35de8578ed2efc764a117c5661aae27bba217fadd2468aa94f9a68ce)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureEncryptionNone]:
        return typing.cast(typing.Optional[StageExternalAzureEncryptionNone], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureEncryptionNone],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f0f70e0663d0e278c1744d4c8cfdfe1bfb9201f42d78bd900d4440b4a899d7da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureEncryptionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureEncryptionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6009f0bffc6be69e0573d3bb964ac4882d7a0854284968f35f292bf6dabb158e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAzureCse")
    def put_azure_cse(self, *, master_key: builtins.str) -> None:
        '''
        :param master_key: Specifies the 128-bit or 256-bit client-side master key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#master_key StageExternalAzure#master_key}
        '''
        value = StageExternalAzureEncryptionAzureCse(master_key=master_key)

        return typing.cast(None, jsii.invoke(self, "putAzureCse", [value]))

    @jsii.member(jsii_name="putNone")
    def put_none(self) -> None:
        value = StageExternalAzureEncryptionNone()

        return typing.cast(None, jsii.invoke(self, "putNone", [value]))

    @jsii.member(jsii_name="resetAzureCse")
    def reset_azure_cse(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAzureCse", []))

    @jsii.member(jsii_name="resetNone")
    def reset_none(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNone", []))

    @builtins.property
    @jsii.member(jsii_name="azureCse")
    def azure_cse(self) -> StageExternalAzureEncryptionAzureCseOutputReference:
        return typing.cast(StageExternalAzureEncryptionAzureCseOutputReference, jsii.get(self, "azureCse"))

    @builtins.property
    @jsii.member(jsii_name="none")
    def none(self) -> StageExternalAzureEncryptionNoneOutputReference:
        return typing.cast(StageExternalAzureEncryptionNoneOutputReference, jsii.get(self, "none"))

    @builtins.property
    @jsii.member(jsii_name="azureCseInput")
    def azure_cse_input(self) -> typing.Optional[StageExternalAzureEncryptionAzureCse]:
        return typing.cast(typing.Optional[StageExternalAzureEncryptionAzureCse], jsii.get(self, "azureCseInput"))

    @builtins.property
    @jsii.member(jsii_name="noneInput")
    def none_input(self) -> typing.Optional[StageExternalAzureEncryptionNone]:
        return typing.cast(typing.Optional[StageExternalAzureEncryptionNone], jsii.get(self, "noneInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureEncryption]:
        return typing.cast(typing.Optional[StageExternalAzureEncryption], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureEncryption],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30c65ad5bc7bb099a801eb8bf966b255530b8368b6254e13a4d9e6e1355dd458)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormat",
    jsii_struct_bases=[],
    name_mapping={
        "avro": "avro",
        "csv": "csv",
        "format_name": "formatName",
        "json": "json",
        "orc": "orc",
        "parquet": "parquet",
        "xml": "xml",
    },
)
class StageExternalAzureFileFormat:
    def __init__(
        self,
        *,
        avro: typing.Optional[typing.Union["StageExternalAzureFileFormatAvro", typing.Dict[builtins.str, typing.Any]]] = None,
        csv: typing.Optional[typing.Union["StageExternalAzureFileFormatCsv", typing.Dict[builtins.str, typing.Any]]] = None,
        format_name: typing.Optional[builtins.str] = None,
        json: typing.Optional[typing.Union["StageExternalAzureFileFormatJson", typing.Dict[builtins.str, typing.Any]]] = None,
        orc: typing.Optional[typing.Union["StageExternalAzureFileFormatOrc", typing.Dict[builtins.str, typing.Any]]] = None,
        parquet: typing.Optional[typing.Union["StageExternalAzureFileFormatParquet", typing.Dict[builtins.str, typing.Any]]] = None,
        xml: typing.Optional[typing.Union["StageExternalAzureFileFormatXml", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param avro: avro block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#avro StageExternalAzure#avro}
        :param csv: csv block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#csv StageExternalAzure#csv}
        :param format_name: Fully qualified name of the file format (e.g., 'database.schema.format_name'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#format_name StageExternalAzure#format_name}
        :param json: json block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#json StageExternalAzure#json}
        :param orc: orc block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#orc StageExternalAzure#orc}
        :param parquet: parquet block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parquet StageExternalAzure#parquet}
        :param xml: xml block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#xml StageExternalAzure#xml}
        '''
        if isinstance(avro, dict):
            avro = StageExternalAzureFileFormatAvro(**avro)
        if isinstance(csv, dict):
            csv = StageExternalAzureFileFormatCsv(**csv)
        if isinstance(json, dict):
            json = StageExternalAzureFileFormatJson(**json)
        if isinstance(orc, dict):
            orc = StageExternalAzureFileFormatOrc(**orc)
        if isinstance(parquet, dict):
            parquet = StageExternalAzureFileFormatParquet(**parquet)
        if isinstance(xml, dict):
            xml = StageExternalAzureFileFormatXml(**xml)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57e353e9899e6093e25fd21acbcf641ccbf454050daa14cb1c22ffb135228b24)
            check_type(argname="argument avro", value=avro, expected_type=type_hints["avro"])
            check_type(argname="argument csv", value=csv, expected_type=type_hints["csv"])
            check_type(argname="argument format_name", value=format_name, expected_type=type_hints["format_name"])
            check_type(argname="argument json", value=json, expected_type=type_hints["json"])
            check_type(argname="argument orc", value=orc, expected_type=type_hints["orc"])
            check_type(argname="argument parquet", value=parquet, expected_type=type_hints["parquet"])
            check_type(argname="argument xml", value=xml, expected_type=type_hints["xml"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if avro is not None:
            self._values["avro"] = avro
        if csv is not None:
            self._values["csv"] = csv
        if format_name is not None:
            self._values["format_name"] = format_name
        if json is not None:
            self._values["json"] = json
        if orc is not None:
            self._values["orc"] = orc
        if parquet is not None:
            self._values["parquet"] = parquet
        if xml is not None:
            self._values["xml"] = xml

    @builtins.property
    def avro(self) -> typing.Optional["StageExternalAzureFileFormatAvro"]:
        '''avro block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#avro StageExternalAzure#avro}
        '''
        result = self._values.get("avro")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatAvro"], result)

    @builtins.property
    def csv(self) -> typing.Optional["StageExternalAzureFileFormatCsv"]:
        '''csv block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#csv StageExternalAzure#csv}
        '''
        result = self._values.get("csv")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatCsv"], result)

    @builtins.property
    def format_name(self) -> typing.Optional[builtins.str]:
        '''Fully qualified name of the file format (e.g., 'database.schema.format_name').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#format_name StageExternalAzure#format_name}
        '''
        result = self._values.get("format_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def json(self) -> typing.Optional["StageExternalAzureFileFormatJson"]:
        '''json block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#json StageExternalAzure#json}
        '''
        result = self._values.get("json")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatJson"], result)

    @builtins.property
    def orc(self) -> typing.Optional["StageExternalAzureFileFormatOrc"]:
        '''orc block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#orc StageExternalAzure#orc}
        '''
        result = self._values.get("orc")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatOrc"], result)

    @builtins.property
    def parquet(self) -> typing.Optional["StageExternalAzureFileFormatParquet"]:
        '''parquet block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parquet StageExternalAzure#parquet}
        '''
        result = self._values.get("parquet")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatParquet"], result)

    @builtins.property
    def xml(self) -> typing.Optional["StageExternalAzureFileFormatXml"]:
        '''xml block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#xml StageExternalAzure#xml}
        '''
        result = self._values.get("xml")
        return typing.cast(typing.Optional["StageExternalAzureFileFormatXml"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormat(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatAvro",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageExternalAzureFileFormatAvro:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c733bcb449e6f6333e3c43b921ad3bb4eec2dd8d1ff03337d19cf4f7292fef5c)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatAvro(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatAvroOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatAvroOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f7d3b0c14b4b630ed191908a036bf80bafd8b9af3d34fd13fe8417a52fa76ff)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1619319accd649c18f5a1f73b1335c1e63b1adf6108b9097e9502a0c72be6b2c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f71fb30eee391ea58ff57df2ea566e76a912e939a6dd15891dd105ce730be5e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63227b0c0d79b79bda57382f6d462f43f01e82794b433b2c182db614df509b13)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc85dc142ba9d0109f2731381d981b7e1b0cbc7db02329a2b4d684999dc06521)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatAvro], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatAvro],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d6c42414b8df1456e7e867b5d55bd084001e338efc31d083e034c8727ae5a9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatCsv",
    jsii_struct_bases=[],
    name_mapping={
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "empty_field_as_null": "emptyFieldAsNull",
        "encoding": "encoding",
        "error_on_column_count_mismatch": "errorOnColumnCountMismatch",
        "escape": "escape",
        "escape_unenclosed_field": "escapeUnenclosedField",
        "field_delimiter": "fieldDelimiter",
        "field_optionally_enclosed_by": "fieldOptionallyEnclosedBy",
        "file_extension": "fileExtension",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "parse_header": "parseHeader",
        "record_delimiter": "recordDelimiter",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_blank_lines": "skipBlankLines",
        "skip_byte_order_mark": "skipByteOrderMark",
        "skip_header": "skipHeader",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageExternalAzureFileFormatCsv:
    def __init__(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#empty_field_as_null StageExternalAzure#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encoding StageExternalAzure#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#error_on_column_count_mismatch StageExternalAzure#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape StageExternalAzure#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape_unenclosed_field StageExternalAzure#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_delimiter StageExternalAzure#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_optionally_enclosed_by StageExternalAzure#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parse_header StageExternalAzure#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#record_delimiter StageExternalAzure#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_blank_lines StageExternalAzure#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_header StageExternalAzure#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7d9f17dd68ae4dad2cbc7bfdf4448dbcf0c02b0f6761c58c3ed1e24f0ad2135)
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument empty_field_as_null", value=empty_field_as_null, expected_type=type_hints["empty_field_as_null"])
            check_type(argname="argument encoding", value=encoding, expected_type=type_hints["encoding"])
            check_type(argname="argument error_on_column_count_mismatch", value=error_on_column_count_mismatch, expected_type=type_hints["error_on_column_count_mismatch"])
            check_type(argname="argument escape", value=escape, expected_type=type_hints["escape"])
            check_type(argname="argument escape_unenclosed_field", value=escape_unenclosed_field, expected_type=type_hints["escape_unenclosed_field"])
            check_type(argname="argument field_delimiter", value=field_delimiter, expected_type=type_hints["field_delimiter"])
            check_type(argname="argument field_optionally_enclosed_by", value=field_optionally_enclosed_by, expected_type=type_hints["field_optionally_enclosed_by"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument parse_header", value=parse_header, expected_type=type_hints["parse_header"])
            check_type(argname="argument record_delimiter", value=record_delimiter, expected_type=type_hints["record_delimiter"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_blank_lines", value=skip_blank_lines, expected_type=type_hints["skip_blank_lines"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument skip_header", value=skip_header, expected_type=type_hints["skip_header"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if empty_field_as_null is not None:
            self._values["empty_field_as_null"] = empty_field_as_null
        if encoding is not None:
            self._values["encoding"] = encoding
        if error_on_column_count_mismatch is not None:
            self._values["error_on_column_count_mismatch"] = error_on_column_count_mismatch
        if escape is not None:
            self._values["escape"] = escape
        if escape_unenclosed_field is not None:
            self._values["escape_unenclosed_field"] = escape_unenclosed_field
        if field_delimiter is not None:
            self._values["field_delimiter"] = field_delimiter
        if field_optionally_enclosed_by is not None:
            self._values["field_optionally_enclosed_by"] = field_optionally_enclosed_by
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if parse_header is not None:
            self._values["parse_header"] = parse_header
        if record_delimiter is not None:
            self._values["record_delimiter"] = record_delimiter
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_blank_lines is not None:
            self._values["skip_blank_lines"] = skip_blank_lines
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if skip_header is not None:
            self._values["skip_header"] = skip_header
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def empty_field_as_null(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#empty_field_as_null StageExternalAzure#empty_field_as_null}
        '''
        result = self._values.get("empty_field_as_null")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encoding(self) -> typing.Optional[builtins.str]:
        '''Specifies the character set of the source data when loading data into a table.

        Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encoding StageExternalAzure#encoding}
        '''
        result = self._values.get("encoding")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def error_on_column_count_mismatch(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#error_on_column_count_mismatch StageExternalAzure#error_on_column_count_mismatch}
        '''
        result = self._values.get("error_on_column_count_mismatch")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for field values.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape StageExternalAzure#escape}
        '''
        result = self._values.get("escape")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def escape_unenclosed_field(self) -> typing.Optional[builtins.str]:
        '''Single character string used as the escape character for unenclosed field values only.

        Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape_unenclosed_field StageExternalAzure#escape_unenclosed_field}
        '''
        result = self._values.get("escape_unenclosed_field")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate fields in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_delimiter StageExternalAzure#field_delimiter}
        '''
        result = self._values.get("field_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def field_optionally_enclosed_by(self) -> typing.Optional[builtins.str]:
        '''Character used to enclose strings. Use ``NONE`` to specify no enclosure character.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_optionally_enclosed_by StageExternalAzure#field_optionally_enclosed_by}
        '''
        result = self._values.get("field_optionally_enclosed_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def parse_header(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parse_header StageExternalAzure#parse_header}
        '''
        result = self._values.get("parse_header")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def record_delimiter(self) -> typing.Optional[builtins.str]:
        '''One or more singlebyte or multibyte characters that separate records in an input file.

        Use ``NONE`` to specify no delimiter.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#record_delimiter StageExternalAzure#record_delimiter}
        '''
        result = self._values.get("record_delimiter")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_blank_lines(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_blank_lines StageExternalAzure#skip_blank_lines}
        '''
        result = self._values.get("skip_blank_lines")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_header(self) -> typing.Optional[jsii.Number]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_header StageExternalAzure#skip_header}
        '''
        result = self._values.get("skip_header")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatCsv(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatCsvOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatCsvOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63f59a54952ec4f9e886c2f77ae739635a8cef104d887f6cf51e59e420887adb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEmptyFieldAsNull")
    def reset_empty_field_as_null(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmptyFieldAsNull", []))

    @jsii.member(jsii_name="resetEncoding")
    def reset_encoding(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEncoding", []))

    @jsii.member(jsii_name="resetErrorOnColumnCountMismatch")
    def reset_error_on_column_count_mismatch(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetErrorOnColumnCountMismatch", []))

    @jsii.member(jsii_name="resetEscape")
    def reset_escape(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscape", []))

    @jsii.member(jsii_name="resetEscapeUnenclosedField")
    def reset_escape_unenclosed_field(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEscapeUnenclosedField", []))

    @jsii.member(jsii_name="resetFieldDelimiter")
    def reset_field_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldDelimiter", []))

    @jsii.member(jsii_name="resetFieldOptionallyEnclosedBy")
    def reset_field_optionally_enclosed_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFieldOptionallyEnclosedBy", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetParseHeader")
    def reset_parse_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParseHeader", []))

    @jsii.member(jsii_name="resetRecordDelimiter")
    def reset_record_delimiter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRecordDelimiter", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipBlankLines")
    def reset_skip_blank_lines(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipBlankLines", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetSkipHeader")
    def reset_skip_header(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipHeader", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNullInput")
    def empty_field_as_null_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emptyFieldAsNullInput"))

    @builtins.property
    @jsii.member(jsii_name="encodingInput")
    def encoding_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "encodingInput"))

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatchInput")
    def error_on_column_count_mismatch_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "errorOnColumnCountMismatchInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeInput")
    def escape_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeInput"))

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedFieldInput")
    def escape_unenclosed_field_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escapeUnenclosedFieldInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiterInput")
    def field_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedByInput")
    def field_optionally_enclosed_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fieldOptionallyEnclosedByInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="parseHeaderInput")
    def parse_header_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parseHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="recordDelimiterInput")
    def record_delimiter_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "recordDelimiterInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipBlankLinesInput")
    def skip_blank_lines_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipBlankLinesInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="skipHeaderInput")
    def skip_header_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "skipHeaderInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b7f1bd2b81f1b1f3cbb819208052fca2b1b8e10cfcf27468a4fe37551390db0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6782ca3283a3489c86eb8eeb22a0639fd2040cbb1d63d7725ee6919f34a44e9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fcf1a7b90b74a682cf01620e63b992e9d7101de13376583aedbc8b4f305ebd94)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="emptyFieldAsNull")
    def empty_field_as_null(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emptyFieldAsNull"))

    @empty_field_as_null.setter
    def empty_field_as_null(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef8bd34bd36e319ed7081b854667df8ee0be7ed5f9a43496ec84e9d6403ed969)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emptyFieldAsNull", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="encoding")
    def encoding(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "encoding"))

    @encoding.setter
    def encoding(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e1cc3757a5c3de44452caba76ad20ff4daa37ee387595627435156694fb2de2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "encoding", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="errorOnColumnCountMismatch")
    def error_on_column_count_mismatch(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "errorOnColumnCountMismatch"))

    @error_on_column_count_mismatch.setter
    def error_on_column_count_mismatch(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02f39e77defbc25ebd75a1ff88d7d6b6d583259408a0369d36f1c6ffff7b9271)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "errorOnColumnCountMismatch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escape")
    def escape(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escape"))

    @escape.setter
    def escape(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91dd6fbc94fb61a6c191c9a43826635eb5eaf57506b3e0e041142ade7c82f177)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escape", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escapeUnenclosedField")
    def escape_unenclosed_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escapeUnenclosedField"))

    @escape_unenclosed_field.setter
    def escape_unenclosed_field(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6d6404628172155f016fc0b135a0d372a6720e35ad0147502ae3a29debd12d5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escapeUnenclosedField", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldDelimiter")
    def field_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldDelimiter"))

    @field_delimiter.setter
    def field_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad7874f74a83a4c0c3d3ca59ce07faab8165a9032ff2d56489f5eaafc30c48fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fieldOptionallyEnclosedBy")
    def field_optionally_enclosed_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fieldOptionallyEnclosedBy"))

    @field_optionally_enclosed_by.setter
    def field_optionally_enclosed_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4865bcd55c6c771defb35dde292d3d9f270798672ea96fe167a9ab28b0993595)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fieldOptionallyEnclosedBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d11700dfee78e9113f59c4e249d44a37c5e1876f5b3f2b952ed92f20d34d74f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d463c870cf503558702cb6ee5ea2bcdacf8c61656ea4abf3a7a646ded6e8f572)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7302140980b7363d8fe96ef420f57dc91f6a9e7feb83b925f1e0c634ed9565ba)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parseHeader")
    def parse_header(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parseHeader"))

    @parse_header.setter
    def parse_header(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02e55f5b2ef821a5dc07f10c30e8db99d3395690f1cf0e0e341413e5fbd94423)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parseHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="recordDelimiter")
    def record_delimiter(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "recordDelimiter"))

    @record_delimiter.setter
    def record_delimiter(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a92215fcebd0bdccc5c8e131cad60f5efb559cf3d996342ebc506e7cb8ec5b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "recordDelimiter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25fe71115a112c5cd81c093baf3c793343c486000a6bd7253580d317ae97a438)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipBlankLines")
    def skip_blank_lines(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipBlankLines"))

    @skip_blank_lines.setter
    def skip_blank_lines(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44744db8134869564105a3adf178d65dbb9f1d20741fb58f9f71fcc5de841343)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipBlankLines", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bfe8a402544ea2ef9e406dfa9c1a3ec41fb916664ae4508a2a2fa63401fb483)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipHeader")
    def skip_header(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "skipHeader"))

    @skip_header.setter
    def skip_header(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60501d6f8659677e1ae8b4f47f6be5d4f44db75438eada84e70f9f5a953277cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipHeader", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6cf4c256179d29bb02fd8686e9b54939d83f4b8169b62e7f04ae403fabaeaeb1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__929c11aee8f0ae6a50de6b7818ccb55a7e619c1dbef8008c17405811a90432c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89a9a12c218fe1d21ffdf9083b35706e47bbd4de7f2b8e2c6908a181b45b0802)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatCsv], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatCsv],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e34f6c79bce5fe29c60c95e91dae793d99c0ec0e76ffc2a74d9bb3f82132cceb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatJson",
    jsii_struct_bases=[],
    name_mapping={
        "allow_duplicate": "allowDuplicate",
        "binary_format": "binaryFormat",
        "compression": "compression",
        "date_format": "dateFormat",
        "enable_octal": "enableOctal",
        "file_extension": "fileExtension",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "multi_line": "multiLine",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_null_values": "stripNullValues",
        "strip_outer_array": "stripOuterArray",
        "time_format": "timeFormat",
        "timestamp_format": "timestampFormat",
        "trim_space": "trimSpace",
    },
)
class StageExternalAzureFileFormatJson:
    def __init__(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#allow_duplicate StageExternalAzure#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable_octal StageExternalAzure#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_null_values StageExternalAzure#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_array StageExternalAzure#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2072e9a056cd4b949f6da0b6ca64afe715512276d6d16d20bdaa15b672420eef)
            check_type(argname="argument allow_duplicate", value=allow_duplicate, expected_type=type_hints["allow_duplicate"])
            check_type(argname="argument binary_format", value=binary_format, expected_type=type_hints["binary_format"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument date_format", value=date_format, expected_type=type_hints["date_format"])
            check_type(argname="argument enable_octal", value=enable_octal, expected_type=type_hints["enable_octal"])
            check_type(argname="argument file_extension", value=file_extension, expected_type=type_hints["file_extension"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument multi_line", value=multi_line, expected_type=type_hints["multi_line"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_null_values", value=strip_null_values, expected_type=type_hints["strip_null_values"])
            check_type(argname="argument strip_outer_array", value=strip_outer_array, expected_type=type_hints["strip_outer_array"])
            check_type(argname="argument time_format", value=time_format, expected_type=type_hints["time_format"])
            check_type(argname="argument timestamp_format", value=timestamp_format, expected_type=type_hints["timestamp_format"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allow_duplicate is not None:
            self._values["allow_duplicate"] = allow_duplicate
        if binary_format is not None:
            self._values["binary_format"] = binary_format
        if compression is not None:
            self._values["compression"] = compression
        if date_format is not None:
            self._values["date_format"] = date_format
        if enable_octal is not None:
            self._values["enable_octal"] = enable_octal
        if file_extension is not None:
            self._values["file_extension"] = file_extension
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if multi_line is not None:
            self._values["multi_line"] = multi_line
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_null_values is not None:
            self._values["strip_null_values"] = strip_null_values
        if strip_outer_array is not None:
            self._values["strip_outer_array"] = strip_outer_array
        if time_format is not None:
            self._values["time_format"] = time_format
        if timestamp_format is not None:
            self._values["timestamp_format"] = timestamp_format
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def allow_duplicate(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved).

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#allow_duplicate StageExternalAzure#allow_duplicate}
        '''
        result = self._values.get("allow_duplicate")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def binary_format(self) -> typing.Optional[builtins.str]:
        '''Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        '''
        result = self._values.get("binary_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def date_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        '''
        result = self._values.get("date_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_octal(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable_octal StageExternalAzure#enable_octal}
        '''
        result = self._values.get("enable_octal")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def file_extension(self) -> typing.Optional[builtins.str]:
        '''Specifies the extension for files unloaded to a stage.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        '''
        result = self._values.get("file_extension")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def multi_line(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        '''
        result = self._values.get("multi_line")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_null_values(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_null_values StageExternalAzure#strip_null_values}
        '''
        result = self._values.get("strip_null_values")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_array(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_array StageExternalAzure#strip_outer_array}
        '''
        result = self._values.get("strip_outer_array")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        '''
        result = self._values.get("time_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def timestamp_format(self) -> typing.Optional[builtins.str]:
        '''Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        '''
        result = self._values.get("timestamp_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatJson(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatJsonOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatJsonOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3bc0d40213f69a59f2992505772e3c88939462f4be499811c6d025a61918b84d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAllowDuplicate")
    def reset_allow_duplicate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowDuplicate", []))

    @jsii.member(jsii_name="resetBinaryFormat")
    def reset_binary_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryFormat", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDateFormat")
    def reset_date_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDateFormat", []))

    @jsii.member(jsii_name="resetEnableOctal")
    def reset_enable_octal(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableOctal", []))

    @jsii.member(jsii_name="resetFileExtension")
    def reset_file_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtension", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetMultiLine")
    def reset_multi_line(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMultiLine", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripNullValues")
    def reset_strip_null_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripNullValues", []))

    @jsii.member(jsii_name="resetStripOuterArray")
    def reset_strip_outer_array(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterArray", []))

    @jsii.member(jsii_name="resetTimeFormat")
    def reset_time_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeFormat", []))

    @jsii.member(jsii_name="resetTimestampFormat")
    def reset_timestamp_format(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimestampFormat", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicateInput")
    def allow_duplicate_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "allowDuplicateInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryFormatInput")
    def binary_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="dateFormatInput")
    def date_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "dateFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="enableOctalInput")
    def enable_octal_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "enableOctalInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionInput")
    def file_extension_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fileExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="multiLineInput")
    def multi_line_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "multiLineInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripNullValuesInput")
    def strip_null_values_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripNullValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterArrayInput")
    def strip_outer_array_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterArrayInput"))

    @builtins.property
    @jsii.member(jsii_name="timeFormatInput")
    def time_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="timestampFormatInput")
    def timestamp_format_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timestampFormatInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="allowDuplicate")
    def allow_duplicate(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "allowDuplicate"))

    @allow_duplicate.setter
    def allow_duplicate(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__182493486c89142ad4de134db49ab301de1049ecbda299a42ce191020622d504)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowDuplicate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="binaryFormat")
    def binary_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryFormat"))

    @binary_format.setter
    def binary_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69929b579e2cbe15fb131b91f2e5742b8c2c029404b4feb733d5239e91ccd71b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d55805fd3cf0453794d73f005dc0f9f99c3d889a885fc2da5d179dccb01ba91)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dateFormat")
    def date_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "dateFormat"))

    @date_format.setter
    def date_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2374b02ff7f8ce3334e64a28d89ff35f046c601d5449a6f7c0cc0059bf12182)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dateFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableOctal")
    def enable_octal(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "enableOctal"))

    @enable_octal.setter
    def enable_octal(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a2cb8172b38e910f3b1cd809c25fb2c6d94832c3e36ed77c4daf933bea75120)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableOctal", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fileExtension")
    def file_extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fileExtension"))

    @file_extension.setter
    def file_extension(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__27c3ca6605f353d1403b1bce4d67ed87fefd5316d1862afdbb5b89bb72e1e03f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fileExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f92177831e382d2ffc5a6084399422487ba41a45da6104590616ba112825eb8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="multiLine")
    def multi_line(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "multiLine"))

    @multi_line.setter
    def multi_line(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d05d33a2892c2689cd603e230ef1086049f5bfe899ddb66aeb9dd1507bf7009)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "multiLine", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1114a2fe667dabfc7e858ab5b2a2c5580c845d9079fc909e5f9666e673b51b06)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec7385aa93690cb2db854d45616d5e6d7a074227540ea468af17812d34eeffe2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c7f2d3c1d7d23c5d5f6cb913ca3102b85c4c97a8549668832582eda907a6a9e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripNullValues")
    def strip_null_values(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripNullValues"))

    @strip_null_values.setter
    def strip_null_values(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb96d06839770f95303544b03bebdd22dcb997337ac23361b48d722bb8669231)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripNullValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterArray")
    def strip_outer_array(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterArray"))

    @strip_outer_array.setter
    def strip_outer_array(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__993e77a1fb07a68c6744a4ac0b4f91a24608d5af065fd80da63c0a9b71506fee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterArray", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeFormat")
    def time_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeFormat"))

    @time_format.setter
    def time_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e5dc3a5f1ac125a007c4e5d1e976f20b318c36cf82993eeff87f729792e5825)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timestampFormat")
    def timestamp_format(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timestampFormat"))

    @timestamp_format.setter
    def timestamp_format(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4f844e8c7e8d018454ed0c28bc9acb6645b8a90a3b7e766d68924215dd213b6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timestampFormat", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6150f7d33955be6f9fe55ef4acf63623244e29e6e87f373977e1eb5983cbe06c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatJson], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatJson],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be147db232dc708e065f39952bd2b4f72d0a13f271c9db5e45c5591902982cca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatOrc",
    jsii_struct_bases=[],
    name_mapping={
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
    },
)
class StageExternalAzureFileFormatOrc:
    def __init__(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6754c76f05d786f3e430b7e671df398ac6e97c3a33bdb9e8e732f8ce48eaffa6)
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatOrc(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatOrcOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatOrcOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a546d36fd660b5e62265b44f6ae0a8b8949e98dae015a7f728fb074f23ab9da)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de1fea0c442f8964e73d393055e021960bae78d272a764de2284c48a1312344a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca13f4fbe9f79dea47979842394da8fdd003d5c61e01127b7c5d842cf28f9528)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b69e5cc89fea0412adeb31576bc46c29700bda46bea3d1d8398ac9f48abc201)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatOrc], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatOrc],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b990aa922bc799744bbaa441662394c112236be80bf39e51b0c3d104159687f3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureFileFormatOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e73cd07cbfbde2b8854924e26e7a6d9d2ee455352449e7f7b27fb9d0b3e7ca1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAvro")
    def put_avro(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        value = StageExternalAzureFileFormatAvro(
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putAvro", [value]))

    @jsii.member(jsii_name="putCsv")
    def put_csv(
        self,
        *,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        empty_field_as_null: typing.Optional[builtins.str] = None,
        encoding: typing.Optional[builtins.str] = None,
        error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
        escape: typing.Optional[builtins.str] = None,
        escape_unenclosed_field: typing.Optional[builtins.str] = None,
        field_delimiter: typing.Optional[builtins.str] = None,
        field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        parse_header: typing.Optional[builtins.str] = None,
        record_delimiter: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_blank_lines: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        skip_header: typing.Optional[jsii.Number] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        :param empty_field_as_null: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#empty_field_as_null StageExternalAzure#empty_field_as_null}
        :param encoding: Specifies the character set of the source data when loading data into a table. Valid values: ``BIG5`` | ``EUCJP`` | ``EUCKR`` | ``GB18030`` | ``IBM420`` | ``IBM424`` | ``ISO2022CN`` | ``ISO2022JP`` | ``ISO2022KR`` | ``ISO88591`` | ``ISO88592`` | ``ISO88595`` | ``ISO88596`` | ``ISO88597`` | ``ISO88598`` | ``ISO88599`` | ``ISO885915`` | ``KOI8R`` | ``SHIFTJIS`` | ``UTF8`` | ``UTF16`` | ``UTF16BE`` | ``UTF16LE`` | ``UTF32`` | ``UTF32BE`` | ``UTF32LE`` | ``WINDOWS1250`` | ``WINDOWS1251`` | ``WINDOWS1252`` | ``WINDOWS1253`` | ``WINDOWS1254`` | ``WINDOWS1255`` | ``WINDOWS1256``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#encoding StageExternalAzure#encoding}
        :param error_on_column_count_mismatch: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#error_on_column_count_mismatch StageExternalAzure#error_on_column_count_mismatch}
        :param escape: Single character string used as the escape character for field values. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape StageExternalAzure#escape}
        :param escape_unenclosed_field: Single character string used as the escape character for unenclosed field values only. Use ``NONE`` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#escape_unenclosed_field StageExternalAzure#escape_unenclosed_field}
        :param field_delimiter: One or more singlebyte or multibyte characters that separate fields in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_delimiter StageExternalAzure#field_delimiter}
        :param field_optionally_enclosed_by: Character used to enclose strings. Use ``NONE`` to specify no enclosure character. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#field_optionally_enclosed_by StageExternalAzure#field_optionally_enclosed_by}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param parse_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#parse_header StageExternalAzure#parse_header}
        :param record_delimiter: One or more singlebyte or multibyte characters that separate records in an input file. Use ``NONE`` to specify no delimiter. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#record_delimiter StageExternalAzure#record_delimiter}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_blank_lines: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_blank_lines StageExternalAzure#skip_blank_lines}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param skip_header: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``-1``)) Number of lines at the start of the file to skip. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_header StageExternalAzure#skip_header}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        value = StageExternalAzureFileFormatCsv(
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            empty_field_as_null=empty_field_as_null,
            encoding=encoding,
            error_on_column_count_mismatch=error_on_column_count_mismatch,
            escape=escape,
            escape_unenclosed_field=escape_unenclosed_field,
            field_delimiter=field_delimiter,
            field_optionally_enclosed_by=field_optionally_enclosed_by,
            file_extension=file_extension,
            multi_line=multi_line,
            null_if=null_if,
            parse_header=parse_header,
            record_delimiter=record_delimiter,
            replace_invalid_characters=replace_invalid_characters,
            skip_blank_lines=skip_blank_lines,
            skip_byte_order_mark=skip_byte_order_mark,
            skip_header=skip_header,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putCsv", [value]))

    @jsii.member(jsii_name="putJson")
    def put_json(
        self,
        *,
        allow_duplicate: typing.Optional[builtins.str] = None,
        binary_format: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        date_format: typing.Optional[builtins.str] = None,
        enable_octal: typing.Optional[builtins.str] = None,
        file_extension: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        multi_line: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_null_values: typing.Optional[builtins.str] = None,
        strip_outer_array: typing.Optional[builtins.str] = None,
        time_format: typing.Optional[builtins.str] = None,
        timestamp_format: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param allow_duplicate: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#allow_duplicate StageExternalAzure#allow_duplicate}
        :param binary_format: Defines the encoding format for binary input or output. Valid values: ``HEX`` | ``BASE64`` | ``UTF8``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param date_format: Defines the format of date values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
        :param enable_octal: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#enable_octal StageExternalAzure#enable_octal}
        :param file_extension: Specifies the extension for files unloaded to a stage. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        :param multi_line: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param strip_null_values: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_null_values StageExternalAzure#strip_null_values}
        :param strip_outer_array: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_array StageExternalAzure#strip_outer_array}
        :param time_format: Defines the format of time values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
        :param timestamp_format: Defines the format of timestamp values in the data files. Use ``AUTO`` to have Snowflake auto-detect the format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        value = StageExternalAzureFileFormatJson(
            allow_duplicate=allow_duplicate,
            binary_format=binary_format,
            compression=compression,
            date_format=date_format,
            enable_octal=enable_octal,
            file_extension=file_extension,
            ignore_utf8_errors=ignore_utf8_errors,
            multi_line=multi_line,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_null_values=strip_null_values,
            strip_outer_array=strip_outer_array,
            time_format=time_format,
            timestamp_format=timestamp_format,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putJson", [value]))

    @jsii.member(jsii_name="putOrc")
    def put_orc(
        self,
        *,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        value = StageExternalAzureFileFormatOrc(
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
        )

        return typing.cast(None, jsii.invoke(self, "putOrc", [value]))

    @jsii.member(jsii_name="putParquet")
    def put_parquet(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_as_text StageExternalAzure#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_logical_type StageExternalAzure#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_vectorized_scanner StageExternalAzure#use_vectorized_scanner}
        '''
        value = StageExternalAzureFileFormatParquet(
            binary_as_text=binary_as_text,
            compression=compression,
            null_if=null_if,
            replace_invalid_characters=replace_invalid_characters,
            trim_space=trim_space,
            use_logical_type=use_logical_type,
            use_vectorized_scanner=use_vectorized_scanner,
        )

        return typing.cast(None, jsii.invoke(self, "putParquet", [value]))

    @jsii.member(jsii_name="putXml")
    def put_xml(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#disable_auto_convert StageExternalAzure#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#preserve_space StageExternalAzure#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_element StageExternalAzure#strip_outer_element}
        '''
        value = StageExternalAzureFileFormatXml(
            compression=compression,
            disable_auto_convert=disable_auto_convert,
            ignore_utf8_errors=ignore_utf8_errors,
            preserve_space=preserve_space,
            replace_invalid_characters=replace_invalid_characters,
            skip_byte_order_mark=skip_byte_order_mark,
            strip_outer_element=strip_outer_element,
        )

        return typing.cast(None, jsii.invoke(self, "putXml", [value]))

    @jsii.member(jsii_name="resetAvro")
    def reset_avro(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAvro", []))

    @jsii.member(jsii_name="resetCsv")
    def reset_csv(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCsv", []))

    @jsii.member(jsii_name="resetFormatName")
    def reset_format_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFormatName", []))

    @jsii.member(jsii_name="resetJson")
    def reset_json(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJson", []))

    @jsii.member(jsii_name="resetOrc")
    def reset_orc(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrc", []))

    @jsii.member(jsii_name="resetParquet")
    def reset_parquet(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParquet", []))

    @jsii.member(jsii_name="resetXml")
    def reset_xml(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetXml", []))

    @builtins.property
    @jsii.member(jsii_name="avro")
    def avro(self) -> StageExternalAzureFileFormatAvroOutputReference:
        return typing.cast(StageExternalAzureFileFormatAvroOutputReference, jsii.get(self, "avro"))

    @builtins.property
    @jsii.member(jsii_name="csv")
    def csv(self) -> StageExternalAzureFileFormatCsvOutputReference:
        return typing.cast(StageExternalAzureFileFormatCsvOutputReference, jsii.get(self, "csv"))

    @builtins.property
    @jsii.member(jsii_name="json")
    def json(self) -> StageExternalAzureFileFormatJsonOutputReference:
        return typing.cast(StageExternalAzureFileFormatJsonOutputReference, jsii.get(self, "json"))

    @builtins.property
    @jsii.member(jsii_name="orc")
    def orc(self) -> StageExternalAzureFileFormatOrcOutputReference:
        return typing.cast(StageExternalAzureFileFormatOrcOutputReference, jsii.get(self, "orc"))

    @builtins.property
    @jsii.member(jsii_name="parquet")
    def parquet(self) -> "StageExternalAzureFileFormatParquetOutputReference":
        return typing.cast("StageExternalAzureFileFormatParquetOutputReference", jsii.get(self, "parquet"))

    @builtins.property
    @jsii.member(jsii_name="xml")
    def xml(self) -> "StageExternalAzureFileFormatXmlOutputReference":
        return typing.cast("StageExternalAzureFileFormatXmlOutputReference", jsii.get(self, "xml"))

    @builtins.property
    @jsii.member(jsii_name="avroInput")
    def avro_input(self) -> typing.Optional[StageExternalAzureFileFormatAvro]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatAvro], jsii.get(self, "avroInput"))

    @builtins.property
    @jsii.member(jsii_name="csvInput")
    def csv_input(self) -> typing.Optional[StageExternalAzureFileFormatCsv]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatCsv], jsii.get(self, "csvInput"))

    @builtins.property
    @jsii.member(jsii_name="formatNameInput")
    def format_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "formatNameInput"))

    @builtins.property
    @jsii.member(jsii_name="jsonInput")
    def json_input(self) -> typing.Optional[StageExternalAzureFileFormatJson]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatJson], jsii.get(self, "jsonInput"))

    @builtins.property
    @jsii.member(jsii_name="orcInput")
    def orc_input(self) -> typing.Optional[StageExternalAzureFileFormatOrc]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatOrc], jsii.get(self, "orcInput"))

    @builtins.property
    @jsii.member(jsii_name="parquetInput")
    def parquet_input(self) -> typing.Optional["StageExternalAzureFileFormatParquet"]:
        return typing.cast(typing.Optional["StageExternalAzureFileFormatParquet"], jsii.get(self, "parquetInput"))

    @builtins.property
    @jsii.member(jsii_name="xmlInput")
    def xml_input(self) -> typing.Optional["StageExternalAzureFileFormatXml"]:
        return typing.cast(typing.Optional["StageExternalAzureFileFormatXml"], jsii.get(self, "xmlInput"))

    @builtins.property
    @jsii.member(jsii_name="formatName")
    def format_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "formatName"))

    @format_name.setter
    def format_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5418762edd8a90f5b24c2d19629cf179bd45c9de747af0548b1b8e56c91de89)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "formatName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormat]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormat], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormat],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0427f727f3daa926db4b9505764e80a8158f958634826fb7f5f10ed3c235e6f1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatParquet",
    jsii_struct_bases=[],
    name_mapping={
        "binary_as_text": "binaryAsText",
        "compression": "compression",
        "null_if": "nullIf",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "trim_space": "trimSpace",
        "use_logical_type": "useLogicalType",
        "use_vectorized_scanner": "useVectorizedScanner",
    },
)
class StageExternalAzureFileFormatParquet:
    def __init__(
        self,
        *,
        binary_as_text: typing.Optional[builtins.str] = None,
        compression: typing.Optional[builtins.str] = None,
        null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        trim_space: typing.Optional[builtins.str] = None,
        use_logical_type: typing.Optional[builtins.str] = None,
        use_vectorized_scanner: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param binary_as_text: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_as_text StageExternalAzure#binary_as_text}
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param null_if: String used to convert to and from SQL NULL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param trim_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        :param use_logical_type: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_logical_type StageExternalAzure#use_logical_type}
        :param use_vectorized_scanner: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_vectorized_scanner StageExternalAzure#use_vectorized_scanner}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b64fcb793169d19ead559d7280bf7219b1afd06b608eefc1cd344808085b1896)
            check_type(argname="argument binary_as_text", value=binary_as_text, expected_type=type_hints["binary_as_text"])
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument null_if", value=null_if, expected_type=type_hints["null_if"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument trim_space", value=trim_space, expected_type=type_hints["trim_space"])
            check_type(argname="argument use_logical_type", value=use_logical_type, expected_type=type_hints["use_logical_type"])
            check_type(argname="argument use_vectorized_scanner", value=use_vectorized_scanner, expected_type=type_hints["use_vectorized_scanner"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if binary_as_text is not None:
            self._values["binary_as_text"] = binary_as_text
        if compression is not None:
            self._values["compression"] = compression
        if null_if is not None:
            self._values["null_if"] = null_if
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if trim_space is not None:
            self._values["trim_space"] = trim_space
        if use_logical_type is not None:
            self._values["use_logical_type"] = use_logical_type
        if use_vectorized_scanner is not None:
            self._values["use_vectorized_scanner"] = use_vectorized_scanner

    @builtins.property
    def binary_as_text(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#binary_as_text StageExternalAzure#binary_as_text}
        '''
        result = self._values.get("binary_as_text")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format. Valid values: ``AUTO`` | ``LZO`` | ``SNAPPY`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def null_if(self) -> typing.Optional[typing.List[builtins.str]]:
        '''String used to convert to and from SQL NULL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
        '''
        result = self._values.get("null_if")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def trim_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to remove white space from fields.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
        '''
        result = self._values.get("trim_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_logical_type(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use Parquet logical types when loading data.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_logical_type StageExternalAzure#use_logical_type}
        '''
        result = self._values.get("use_logical_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_vectorized_scanner(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#use_vectorized_scanner StageExternalAzure#use_vectorized_scanner}
        '''
        result = self._values.get("use_vectorized_scanner")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatParquet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatParquetOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatParquetOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77063848606275970f321d90c1f01eed11d1cfca02e3c04a8311453ac0cc9b4e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetBinaryAsText")
    def reset_binary_as_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBinaryAsText", []))

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetNullIf")
    def reset_null_if(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNullIf", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetTrimSpace")
    def reset_trim_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTrimSpace", []))

    @jsii.member(jsii_name="resetUseLogicalType")
    def reset_use_logical_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseLogicalType", []))

    @jsii.member(jsii_name="resetUseVectorizedScanner")
    def reset_use_vectorized_scanner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseVectorizedScanner", []))

    @builtins.property
    @jsii.member(jsii_name="binaryAsTextInput")
    def binary_as_text_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "binaryAsTextInput"))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="nullIfInput")
    def null_if_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "nullIfInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="trimSpaceInput")
    def trim_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "trimSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="useLogicalTypeInput")
    def use_logical_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useLogicalTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScannerInput")
    def use_vectorized_scanner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "useVectorizedScannerInput"))

    @builtins.property
    @jsii.member(jsii_name="binaryAsText")
    def binary_as_text(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "binaryAsText"))

    @binary_as_text.setter
    def binary_as_text(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f66fc80f86ac410a1a7b807466e4bca0a6ab2573d558f65eb17fcc80030a559a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "binaryAsText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__87c4151856e01187b6cdd1a5b61755cc7973f5d73da1482a9a619d7e7fbea6fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nullIf")
    def null_if(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "nullIf"))

    @null_if.setter
    def null_if(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b3c501790f623c663ff17b3c1b8a01554ad959b2c19d548d0d99bfc86a8d651)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nullIf", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa23aaeed942e2db56d4a8b7dce0113d1d1ee6b09ff375486201dd00d428cd9a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="trimSpace")
    def trim_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "trimSpace"))

    @trim_space.setter
    def trim_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a07a9e9ef17873ffc66deaf062da90cc9a8c6f61984931580246fd38ae016fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "trimSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useLogicalType")
    def use_logical_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useLogicalType"))

    @use_logical_type.setter
    def use_logical_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25f72827314738141e7cd2179755a699a1159d8a08f8fdfd9139ac66ae98fbbc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useLogicalType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useVectorizedScanner")
    def use_vectorized_scanner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "useVectorizedScanner"))

    @use_vectorized_scanner.setter
    def use_vectorized_scanner(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acd057cc5c8e84d945939f551230f722f67bf9ffbe8353ccac682abf2e2fd2fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useVectorizedScanner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatParquet]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatParquet], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatParquet],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dab149dae694c166aaa6ea5a8573fe7c19ed32f34d3c23d111bb2f864567da22)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatXml",
    jsii_struct_bases=[],
    name_mapping={
        "compression": "compression",
        "disable_auto_convert": "disableAutoConvert",
        "ignore_utf8_errors": "ignoreUtf8Errors",
        "preserve_space": "preserveSpace",
        "replace_invalid_characters": "replaceInvalidCharacters",
        "skip_byte_order_mark": "skipByteOrderMark",
        "strip_outer_element": "stripOuterElement",
    },
)
class StageExternalAzureFileFormatXml:
    def __init__(
        self,
        *,
        compression: typing.Optional[builtins.str] = None,
        disable_auto_convert: typing.Optional[builtins.str] = None,
        ignore_utf8_errors: typing.Optional[builtins.str] = None,
        preserve_space: typing.Optional[builtins.str] = None,
        replace_invalid_characters: typing.Optional[builtins.str] = None,
        skip_byte_order_mark: typing.Optional[builtins.str] = None,
        strip_outer_element: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param compression: Specifies the compression format. Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        :param disable_auto_convert: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#disable_auto_convert StageExternalAzure#disable_auto_convert}
        :param ignore_utf8_errors: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        :param preserve_space: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#preserve_space StageExternalAzure#preserve_space}
        :param replace_invalid_characters: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        :param skip_byte_order_mark: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        :param strip_outer_element: (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_element StageExternalAzure#strip_outer_element}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0aa302eb53dbdbe8f03b896aba834f4eb3f800bf5ea90fe442a602161cef37a2)
            check_type(argname="argument compression", value=compression, expected_type=type_hints["compression"])
            check_type(argname="argument disable_auto_convert", value=disable_auto_convert, expected_type=type_hints["disable_auto_convert"])
            check_type(argname="argument ignore_utf8_errors", value=ignore_utf8_errors, expected_type=type_hints["ignore_utf8_errors"])
            check_type(argname="argument preserve_space", value=preserve_space, expected_type=type_hints["preserve_space"])
            check_type(argname="argument replace_invalid_characters", value=replace_invalid_characters, expected_type=type_hints["replace_invalid_characters"])
            check_type(argname="argument skip_byte_order_mark", value=skip_byte_order_mark, expected_type=type_hints["skip_byte_order_mark"])
            check_type(argname="argument strip_outer_element", value=strip_outer_element, expected_type=type_hints["strip_outer_element"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if compression is not None:
            self._values["compression"] = compression
        if disable_auto_convert is not None:
            self._values["disable_auto_convert"] = disable_auto_convert
        if ignore_utf8_errors is not None:
            self._values["ignore_utf8_errors"] = ignore_utf8_errors
        if preserve_space is not None:
            self._values["preserve_space"] = preserve_space
        if replace_invalid_characters is not None:
            self._values["replace_invalid_characters"] = replace_invalid_characters
        if skip_byte_order_mark is not None:
            self._values["skip_byte_order_mark"] = skip_byte_order_mark
        if strip_outer_element is not None:
            self._values["strip_outer_element"] = strip_outer_element

    @builtins.property
    def compression(self) -> typing.Optional[builtins.str]:
        '''Specifies the compression format.

        Valid values: ``AUTO`` | ``GZIP`` | ``BZ2`` | ``BROTLI`` | ``ZSTD`` | ``DEFLATE`` | ``RAW_DEFLATE`` | ``NONE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
        '''
        result = self._values.get("compression")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def disable_auto_convert(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#disable_auto_convert StageExternalAzure#disable_auto_convert}
        '''
        result = self._values.get("disable_auto_convert")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_utf8_errors(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether UTF-8 encoding errors produce error conditions.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
        '''
        result = self._values.get("ignore_utf8_errors")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def preserve_space(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#preserve_space StageExternalAzure#preserve_space}
        '''
        result = self._values.get("preserve_space")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def replace_invalid_characters(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
        '''
        result = self._values.get("replace_invalid_characters")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_byte_order_mark(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
        '''
        result = self._values.get("skip_byte_order_mark")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strip_outer_element(self) -> typing.Optional[builtins.str]:
        '''(Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (``default``)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents.

        Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#strip_outer_element StageExternalAzure#strip_outer_element}
        '''
        result = self._values.get("strip_outer_element")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureFileFormatXml(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureFileFormatXmlOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureFileFormatXmlOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b28c99574e80496e8ce739abbfc71ce265f66425977deee538d8fcf4b7e20466)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCompression")
    def reset_compression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCompression", []))

    @jsii.member(jsii_name="resetDisableAutoConvert")
    def reset_disable_auto_convert(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDisableAutoConvert", []))

    @jsii.member(jsii_name="resetIgnoreUtf8Errors")
    def reset_ignore_utf8_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreUtf8Errors", []))

    @jsii.member(jsii_name="resetPreserveSpace")
    def reset_preserve_space(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreserveSpace", []))

    @jsii.member(jsii_name="resetReplaceInvalidCharacters")
    def reset_replace_invalid_characters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReplaceInvalidCharacters", []))

    @jsii.member(jsii_name="resetSkipByteOrderMark")
    def reset_skip_byte_order_mark(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSkipByteOrderMark", []))

    @jsii.member(jsii_name="resetStripOuterElement")
    def reset_strip_outer_element(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStripOuterElement", []))

    @builtins.property
    @jsii.member(jsii_name="compressionInput")
    def compression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "compressionInput"))

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvertInput")
    def disable_auto_convert_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "disableAutoConvertInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8ErrorsInput")
    def ignore_utf8_errors_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ignoreUtf8ErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="preserveSpaceInput")
    def preserve_space_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "preserveSpaceInput"))

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharactersInput")
    def replace_invalid_characters_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "replaceInvalidCharactersInput"))

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMarkInput")
    def skip_byte_order_mark_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "skipByteOrderMarkInput"))

    @builtins.property
    @jsii.member(jsii_name="stripOuterElementInput")
    def strip_outer_element_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "stripOuterElementInput"))

    @builtins.property
    @jsii.member(jsii_name="compression")
    def compression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "compression"))

    @compression.setter
    def compression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e074eed1ca7c54a90d9d021fde3506f43851b253c402a594f36ae7930d9cfd2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "compression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="disableAutoConvert")
    def disable_auto_convert(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "disableAutoConvert"))

    @disable_auto_convert.setter
    def disable_auto_convert(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c09862d943f83347589b6ed53ffdcdc8d62b511c29846bfc5f94297047c8ed7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "disableAutoConvert", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreUtf8Errors")
    def ignore_utf8_errors(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ignoreUtf8Errors"))

    @ignore_utf8_errors.setter
    def ignore_utf8_errors(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84355536cf614f7662f9870c2bcef492335127446f6189a0ca6ba1ef230121df)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreUtf8Errors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preserveSpace")
    def preserve_space(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "preserveSpace"))

    @preserve_space.setter
    def preserve_space(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1a40e884ff6d9cc67c34546fca35c8dbf5be611c7afead38d26cc665203e17f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preserveSpace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="replaceInvalidCharacters")
    def replace_invalid_characters(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "replaceInvalidCharacters"))

    @replace_invalid_characters.setter
    def replace_invalid_characters(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f50c8942a9a48bca4e145a488b78c7e2c4c7fb6fe34e5c812914c8126b67949)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "replaceInvalidCharacters", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="skipByteOrderMark")
    def skip_byte_order_mark(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "skipByteOrderMark"))

    @skip_byte_order_mark.setter
    def skip_byte_order_mark(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1bd908f943d7f768b8bb3d34a8ab22e4cb992bc423d7d8e51d12df76ec553db)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "skipByteOrderMark", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="stripOuterElement")
    def strip_outer_element(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "stripOuterElement"))

    @strip_outer_element.setter
    def strip_outer_element(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__42ffd42ff76dc2bcba191986507c43ebcb0249a6b63fbcb77dfafb2d9ebbf622)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "stripOuterElement", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureFileFormatXml]:
        return typing.cast(typing.Optional[StageExternalAzureFileFormatXml], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureFileFormatXml],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32dae6d0a00c08ab50f1ec36dbd61d7da951c414f5e9951d6915feb7e8dc5900)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureShowOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class StageExternalAzureShowOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureShowOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureShowOutputList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureShowOutputList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6c5fda5f190d39344e84dc1367eef0580b3c998e12dd5a1552c3440ec5a1865)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "StageExternalAzureShowOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e24d1cdb14428a4e37a3d94162266453cc36a567af46b50d0c42fb05249f8273)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("StageExternalAzureShowOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d02733091bdbcff2bf1e0760605ab4107bc696ef8295534c737274d7baed12b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a96dd97ef2e9a91f9a39c3cb58ddcd1ca1a30024f97ed8c55cda13c08411cb9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d76e566b9b2d43de3fbffacbc72420a32de5d34b6838b7046f7738cb690bc32e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class StageExternalAzureShowOutputOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureShowOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57537c63dc43b2bb239542571e6b94f0e50c70d5acb11088aba56bbb46aae9a1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="cloud")
    def cloud(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cloud"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="databaseName")
    def database_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseName"))

    @builtins.property
    @jsii.member(jsii_name="directoryEnabled")
    def directory_enabled(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "directoryEnabled"))

    @builtins.property
    @jsii.member(jsii_name="endpoint")
    def endpoint(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "endpoint"))

    @builtins.property
    @jsii.member(jsii_name="hasCredentials")
    def has_credentials(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "hasCredentials"))

    @builtins.property
    @jsii.member(jsii_name="hasEncryptionKey")
    def has_encryption_key(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "hasEncryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @builtins.property
    @jsii.member(jsii_name="ownerRoleType")
    def owner_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ownerRoleType"))

    @builtins.property
    @jsii.member(jsii_name="region")
    def region(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "region"))

    @builtins.property
    @jsii.member(jsii_name="schemaName")
    def schema_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schemaName"))

    @builtins.property
    @jsii.member(jsii_name="storageIntegration")
    def storage_integration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "storageIntegration"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[StageExternalAzureShowOutput]:
        return typing.cast(typing.Optional[StageExternalAzureShowOutput], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[StageExternalAzureShowOutput],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2cd69d1867748b7a6d033eb9d142a3faabfbdb15786342cea2012f0f45adb892)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class StageExternalAzureTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#create StageExternalAzure#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#delete StageExternalAzure#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#read StageExternalAzure#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#update StageExternalAzure#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03051ce33b778b81fac96d5a28162606a2b463ef890f59579c4bf05ec8486c51)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#create StageExternalAzure#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#delete StageExternalAzure#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#read StageExternalAzure#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.13.0/docs/resources/stage_external_azure#update StageExternalAzure#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StageExternalAzureTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class StageExternalAzureTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-snowflake.stageExternalAzure.StageExternalAzureTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40f5a003ef4bf0fbd789c4bd6efa1a19323b676c281602cf6d4e3d2cb33407de)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3836ae759027a3ba31c451d2ffad923d6e55aa9f3fce328757714b97f23ffc5f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1eb7ba67ba274e0d3d7cdaab22a4318137fd30bdb8dda0ed914945c7ee756e6a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ce666dbec0d421b7bfc2a28871b401f11bb8888958fd240b5ad6711cf092ac2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d281a0652028120afb527444369049cc7ab57058e3711025814fbcb876b054e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalAzureTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalAzureTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalAzureTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5efe1e0605765ddc7286646194bb85d3daa524464819d8fe83abb5172ac57c77)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "StageExternalAzure",
    "StageExternalAzureConfig",
    "StageExternalAzureCredentials",
    "StageExternalAzureCredentialsOutputReference",
    "StageExternalAzureDescribeOutput",
    "StageExternalAzureDescribeOutputDirectoryTable",
    "StageExternalAzureDescribeOutputDirectoryTableList",
    "StageExternalAzureDescribeOutputDirectoryTableOutputReference",
    "StageExternalAzureDescribeOutputFileFormat",
    "StageExternalAzureDescribeOutputFileFormatAvro",
    "StageExternalAzureDescribeOutputFileFormatAvroList",
    "StageExternalAzureDescribeOutputFileFormatAvroOutputReference",
    "StageExternalAzureDescribeOutputFileFormatCsv",
    "StageExternalAzureDescribeOutputFileFormatCsvList",
    "StageExternalAzureDescribeOutputFileFormatCsvOutputReference",
    "StageExternalAzureDescribeOutputFileFormatJson",
    "StageExternalAzureDescribeOutputFileFormatJsonList",
    "StageExternalAzureDescribeOutputFileFormatJsonOutputReference",
    "StageExternalAzureDescribeOutputFileFormatList",
    "StageExternalAzureDescribeOutputFileFormatOrc",
    "StageExternalAzureDescribeOutputFileFormatOrcList",
    "StageExternalAzureDescribeOutputFileFormatOrcOutputReference",
    "StageExternalAzureDescribeOutputFileFormatOutputReference",
    "StageExternalAzureDescribeOutputFileFormatParquet",
    "StageExternalAzureDescribeOutputFileFormatParquetList",
    "StageExternalAzureDescribeOutputFileFormatParquetOutputReference",
    "StageExternalAzureDescribeOutputFileFormatXml",
    "StageExternalAzureDescribeOutputFileFormatXmlList",
    "StageExternalAzureDescribeOutputFileFormatXmlOutputReference",
    "StageExternalAzureDescribeOutputList",
    "StageExternalAzureDescribeOutputOutputReference",
    "StageExternalAzureDirectory",
    "StageExternalAzureDirectoryOutputReference",
    "StageExternalAzureEncryption",
    "StageExternalAzureEncryptionAzureCse",
    "StageExternalAzureEncryptionAzureCseOutputReference",
    "StageExternalAzureEncryptionNone",
    "StageExternalAzureEncryptionNoneOutputReference",
    "StageExternalAzureEncryptionOutputReference",
    "StageExternalAzureFileFormat",
    "StageExternalAzureFileFormatAvro",
    "StageExternalAzureFileFormatAvroOutputReference",
    "StageExternalAzureFileFormatCsv",
    "StageExternalAzureFileFormatCsvOutputReference",
    "StageExternalAzureFileFormatJson",
    "StageExternalAzureFileFormatJsonOutputReference",
    "StageExternalAzureFileFormatOrc",
    "StageExternalAzureFileFormatOrcOutputReference",
    "StageExternalAzureFileFormatOutputReference",
    "StageExternalAzureFileFormatParquet",
    "StageExternalAzureFileFormatParquetOutputReference",
    "StageExternalAzureFileFormatXml",
    "StageExternalAzureFileFormatXmlOutputReference",
    "StageExternalAzureShowOutput",
    "StageExternalAzureShowOutputList",
    "StageExternalAzureShowOutputOutputReference",
    "StageExternalAzureTimeouts",
    "StageExternalAzureTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__d78e3c56f6503ff4f153964e686b0b63817cb6f9fd12db45f678d304384780cd(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    url: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    credentials: typing.Optional[typing.Union[StageExternalAzureCredentials, typing.Dict[builtins.str, typing.Any]]] = None,
    directory: typing.Optional[typing.Union[StageExternalAzureDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageExternalAzureEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageExternalAzureFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    storage_integration: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageExternalAzureTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    use_privatelink_endpoint: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bc42aed2359109591b4b5ce6aae9871ce192592eddb63ce3fa9ac852675e9031(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a961e52249984c8d2e05e7cca4c579a12eccacf4aee0b2ff9cc867ba02e7352e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a12ce798225ad3c65313e3525a4b676e58cf4ddb39c0c18b776a94cdf7c4cef(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5189d8a72c4d3468c96eec438a11aed2533d7c51228d9087fdd40d2b710529fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5b9ad04105f80ae99d13ba3e1c5d8aacceefe5701f9a6032c2a72156b2b5552(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d40b747678a2a93691164d287e0352aac6ab0b051ed2f468dd031b67ac753c3e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7257969edcc6d9af07aa9524f71fc299869f4b928b5958fe58423dbbc540ed3f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2be4aa3499e68a93b7222b9af483083d241ae18894f8d7a87a7054e8e6ec9812(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7dc996cfcef8c3d5c842095ba7ce708b10d5199997a98fa3d1798975060edb2c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f2ffad54b701badbfd81929130332e476f46459b4f0e4adbd1677277952e8d0(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    url: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    credentials: typing.Optional[typing.Union[StageExternalAzureCredentials, typing.Dict[builtins.str, typing.Any]]] = None,
    directory: typing.Optional[typing.Union[StageExternalAzureDirectory, typing.Dict[builtins.str, typing.Any]]] = None,
    encryption: typing.Optional[typing.Union[StageExternalAzureEncryption, typing.Dict[builtins.str, typing.Any]]] = None,
    file_format: typing.Optional[typing.Union[StageExternalAzureFileFormat, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    storage_integration: typing.Optional[builtins.str] = None,
    timeouts: typing.Optional[typing.Union[StageExternalAzureTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    use_privatelink_endpoint: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e974e8e752756d09d9a57683a2aa51fd4d4ef0dcba8d55e60844233b6333cdb(
    *,
    azure_sas_token: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f02c8ce1e33bd1ffb4934760167f12e863b7e0de8d3310f0f467676b6d421cbb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66bd71b41c304b3aac45153100178b9b0e5c66c8f3e2bd958c7317b9feeede35(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db9177854ad7ca6e0f0146d910ea8dedf4c07c9d6c9b2ccedf2ddd96f2e94a2e(
    value: typing.Optional[StageExternalAzureCredentials],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14cb22e9e796ec0f428d7fc47a2b5764e549d4c041c616223f0b738b04be35bb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__947334cdd470a6237026221ae1db30984c966a81e6f49f2ef9b39248d99368d4(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a843d762ab23a917a361d37cae6db4a03069207f374a2a6010bca2335a2a8fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09dfba0a9aa0cbb3ce4da55893f30168642bd3cbbd466b633c8c6445d1f0d0ce(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebb0c13553849903a56e7b8ae57cf947737ac181138eb9f23ec00e7664f1387f(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__582a32a23eff732df85739635e9f4aa68e336c629811d6e24134e9e488643455(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__410622bc6b1a7965c612384e42ab0710a434a3b0d1cb1c2abcf40b43a4244f80(
    value: typing.Optional[StageExternalAzureDescribeOutputDirectoryTable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__441459f8e806df3bd5107e381a8f99888b346c1b5852504cd5e939c2ea609acc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdf276c0d075928820dcf28b79e41a0a098e3f7d41c767f866b1ef7d4802d1e5(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__adc33650312e705615e996e89fc702ef67a9e94ae2f78907e41f483fffd965bc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5998f68ccd0a3e0eef534dd1ee2744730c6811173e4731b0057bf685b582be4e(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60a17b8b14fcebb123d045edfd53c8b1741140e0c824f166e70ce734df69d505(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e77f375eca2e061f1a7df736033f907063cb9bad6f38f7ccdd174b8ba5364031(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ee538aeb7e52596d29d56807685427abd35027b5f991aeea699dada4e3c3f98(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2033f23ef1b4dedc404d8e2cfa03f834e457a98587af903c621e2140298e6a74(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28aedfaa4e400ee4f6380aa228d7fa599f385fcc3cd80d1b2b32b777b26817b4(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6f08bef9e947420d9b1c151b72cfe7bd0091ea6d61bef65a72c041b5dfb3b04(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6973902cf34154fc076daa7ba0b4fe6536aa2162a186ac2d5840e2e7147b3ca1(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47f0b10aeea81ccc3ea1ac739cff85c721fe25d88505be9756aafeabe3c19883(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8dde9f57f13ff1b1f305bac2ef210c6ce4a54da97456d58ba4c6cc6376f02125(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03ff5ece30065f27141b3a0f210f73ba37ef362b2d9adcd774c42a90508db2a6(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa19df0eca2762bc9f68ce80bc07a9d2540dac1b0a2ed16bec496af71ac64c7d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c32fba7a7659131d865f75aaf4536c93a29cf29ff8272235078945da28a29f1f(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__347f001282b4b1a66a2b47bd6f90617437cd5ed5ea7e2b3fd371bd9d55848e0b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93883a685b49b9f3ab145d588c845287fd6a8e88081f7c81579a8fc847c5e129(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d20de59df21e1aca73a403c0ee8367a5bb6bef2dc08cfedddec7477a8b6c5dc0(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf1e4d293eae19ed0cc8ad0c521a4283b08b6e9eace9390ba46957b08f862a58(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__985a5cf1698430231c22c34c9b556231fbb4fefee9fedb2faf990f58dbdaef3e(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3821eb10f6b049565a1382e5d5df5d6be4195806ee2619f55b5dca84ebe2772d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ddc64af0e8864347ffca1ac0f5029772d1b10981bc7fbdaf5364f5efbb7680a5(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2658d25f4b39b332fa34ffeb46f60c3590fe45bbb9f352c545e2b8dc6f70d20(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c053fb41b7f9b3e163ccc27ab33c7260e70ed74aa4fa57ccda4d9d01c5487f8(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41432ffdac6cb530386559f6372a02eb1e8a251f608ad8411a85f0a6a4b7ab06(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38857453be24ccf8cb4b1a649a0559f5e95166249c5931770c4f5f3af0c2545b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6fabc13fbfbf32d708c67fefc13b88d16cc693b1a06caa9f8e39b51f35973e7(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d764e984208750b0cf5a64d0567f645d3867f01f84482ccf1f465f2f2477dc0d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2bdd3b0319d4c4047d57486300ba60a2d2132c38706aedcb0deb68731d7203f(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65db7cb6a0b030019514c007e54967ddc888ad843e00f93d3ec63089a3580eb3(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4508b9bbfc333cbbd0d2507ba2ba5076c4ee5bedb0d9f63ddc5016ef0fca9439(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__891a8555181346462148440c7880ee9d12e4529b38a95f69ee92e4e4b0225e88(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c38601f7c0a5fc2fa6ff320c0474134176c5a604d1a10047ae6db5e933bd38cf(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6eb73fe07dd3e52170aa8c9344df31c955fad6d2c7d05088371a7fc4b57941de(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9737fc880d3588494fe73825e87310e7dac058adc7d2a3656b08ec0ac9bb030c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e4724e4f89ffe66654cded0802cf1fb0329ca4b1a49145141b8768799ab6d5d(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6471f6c75b031c4727858ebdd9d53a07b6fe2c268dc916d8099cf99b21d786a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__15ccc342fd1b181dc9dad7545bf85586c710daef39cd362ba67b54e864d5b09b(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39c41333bee35cb19b519f06381bc549f8f3f6ed9c974f3e85b16ea2b1c60f0f(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce42abf671a0ee689715e3a5017ccf7b63d984801709b94d18a5b955e349e7ae(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6a7aaf17d9d1bac3d76bae817bd64b31810b7ae07fad37b04b3c14a4c19e810(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a21fe5dfb04df1edfeb5ebd7839a7ffea04db4db74a0a6b5233a7cc7fbee372(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__992836ccff6891ac1e570d4d9e0700572d7bbe908bc21fe483c512582f8ef3c0(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__308c6017bdd2831c84096f5e900b96d32058bf1adc83edd9c5e2d452bb27ed6e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__968fba9d6bf01d6bcb9f61140ef3f41e2106fdcd6c93ae226ce6334f65c0b043(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1cec687546653c32b9fa3652277f86a916d11c1265cdbc431a5c29db174721a9(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db3fba1a8fc591055f8bb533f913f7ae094dfd4ef5c131031eb7432ee07f191d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7594ac6061d14573e2ef5538592c4727afcca6d7093b55cd75cd05f1507d1be0(
    value: typing.Optional[StageExternalAzureDescribeOutputFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e032411a68dbcb015b12cb1ccc13e254b2bf15f72780b18f49c5a0a6cc4d9ce(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4414d073a609e2be783ad77a0872300f119f09d5a7ac0add1998c0ebad46a6c6(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84680c4fa09a802c3b0fd18cc720626b0a8ed4204fffa567bee9c61e579a1366(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bc2d81acefc2ab065d4bda20d0e5108e30fe9cef6fc40b6e2b4b39eb906c6eb(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f8e62199a5b979c79fa4f1d44e15cf1b2477ebc42862ac98342cd6b5b9feb97(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__251f872d58900f171696aeb5ad298405b4ec946273413e86d6450d357e8346a4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88f8feccc7505b6cdf293fe63f8677f9c2a81c8caba80477bfc797c44962272d(
    value: typing.Optional[StageExternalAzureDescribeOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00a243eb7b40b9df82931ed619b5e065e5d83d212e5fef2005945c30f6d9f4b3(
    *,
    enable: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    auto_refresh: typing.Optional[builtins.str] = None,
    notification_integration: typing.Optional[builtins.str] = None,
    refresh_on_create: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df1251c84050bbee5fa852f02cf66d0be7cd17cf96422480867979764335d78f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b94b3e4e1b5d81d877a38da3bf96ca68be266caa7af578b02eb0d8cd6eedf82(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0d945ea5f4f661f391828ce7dca532bf1cd76c14c361a1b0721633c5f902d0b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f7b114cd9e6b1a694b4dbae7305f0c3075e0dbe94b242aee494b91ae6f4a166(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__abecb05836662e2397b235ac9f89acdf02484694d934b987201c52623505d8cb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45bce95001bb9152d3da4c43d64eb5818ffaf48124a99f5da55057ee72bf6ca2(
    value: typing.Optional[StageExternalAzureDirectory],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2bd072f1d26b07f44a7876b7846606b12440ef1b83437ad52f23d129f5be69b6(
    *,
    azure_cse: typing.Optional[typing.Union[StageExternalAzureEncryptionAzureCse, typing.Dict[builtins.str, typing.Any]]] = None,
    none: typing.Optional[typing.Union[StageExternalAzureEncryptionNone, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e40aeb22864c2f263e20d2d5b85fbbed4f174326f0281216fccb866f9fbd760b(
    *,
    master_key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__671d6bd3336a6a2a56470c19fafde408adf2933c7feace7132a287082fdfe98d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05d21b9b3c3cc85a409178f36b3e852283c4a896a70c9accc16785d7762ec872(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39c75c27395d4b4f96e5e4b8f01b4a2e8378b6fdab5e2119c5cf137957155f8e(
    value: typing.Optional[StageExternalAzureEncryptionAzureCse],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d74e50b35de8578ed2efc764a117c5661aae27bba217fadd2468aa94f9a68ce(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0f70e0663d0e278c1744d4c8cfdfe1bfb9201f42d78bd900d4440b4a899d7da(
    value: typing.Optional[StageExternalAzureEncryptionNone],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6009f0bffc6be69e0573d3bb964ac4882d7a0854284968f35f292bf6dabb158e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30c65ad5bc7bb099a801eb8bf966b255530b8368b6254e13a4d9e6e1355dd458(
    value: typing.Optional[StageExternalAzureEncryption],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57e353e9899e6093e25fd21acbcf641ccbf454050daa14cb1c22ffb135228b24(
    *,
    avro: typing.Optional[typing.Union[StageExternalAzureFileFormatAvro, typing.Dict[builtins.str, typing.Any]]] = None,
    csv: typing.Optional[typing.Union[StageExternalAzureFileFormatCsv, typing.Dict[builtins.str, typing.Any]]] = None,
    format_name: typing.Optional[builtins.str] = None,
    json: typing.Optional[typing.Union[StageExternalAzureFileFormatJson, typing.Dict[builtins.str, typing.Any]]] = None,
    orc: typing.Optional[typing.Union[StageExternalAzureFileFormatOrc, typing.Dict[builtins.str, typing.Any]]] = None,
    parquet: typing.Optional[typing.Union[StageExternalAzureFileFormatParquet, typing.Dict[builtins.str, typing.Any]]] = None,
    xml: typing.Optional[typing.Union[StageExternalAzureFileFormatXml, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c733bcb449e6f6333e3c43b921ad3bb4eec2dd8d1ff03337d19cf4f7292fef5c(
    *,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f7d3b0c14b4b630ed191908a036bf80bafd8b9af3d34fd13fe8417a52fa76ff(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1619319accd649c18f5a1f73b1335c1e63b1adf6108b9097e9502a0c72be6b2c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f71fb30eee391ea58ff57df2ea566e76a912e939a6dd15891dd105ce730be5e8(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63227b0c0d79b79bda57382f6d462f43f01e82794b433b2c182db614df509b13(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc85dc142ba9d0109f2731381d981b7e1b0cbc7db02329a2b4d684999dc06521(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d6c42414b8df1456e7e867b5d55bd084001e338efc31d083e034c8727ae5a9c(
    value: typing.Optional[StageExternalAzureFileFormatAvro],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7d9f17dd68ae4dad2cbc7bfdf4448dbcf0c02b0f6761c58c3ed1e24f0ad2135(
    *,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    empty_field_as_null: typing.Optional[builtins.str] = None,
    encoding: typing.Optional[builtins.str] = None,
    error_on_column_count_mismatch: typing.Optional[builtins.str] = None,
    escape: typing.Optional[builtins.str] = None,
    escape_unenclosed_field: typing.Optional[builtins.str] = None,
    field_delimiter: typing.Optional[builtins.str] = None,
    field_optionally_enclosed_by: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    parse_header: typing.Optional[builtins.str] = None,
    record_delimiter: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_blank_lines: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    skip_header: typing.Optional[jsii.Number] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63f59a54952ec4f9e886c2f77ae739635a8cef104d887f6cf51e59e420887adb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b7f1bd2b81f1b1f3cbb819208052fca2b1b8e10cfcf27468a4fe37551390db0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6782ca3283a3489c86eb8eeb22a0639fd2040cbb1d63d7725ee6919f34a44e9d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fcf1a7b90b74a682cf01620e63b992e9d7101de13376583aedbc8b4f305ebd94(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef8bd34bd36e319ed7081b854667df8ee0be7ed5f9a43496ec84e9d6403ed969(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e1cc3757a5c3de44452caba76ad20ff4daa37ee387595627435156694fb2de2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02f39e77defbc25ebd75a1ff88d7d6b6d583259408a0369d36f1c6ffff7b9271(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91dd6fbc94fb61a6c191c9a43826635eb5eaf57506b3e0e041142ade7c82f177(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6d6404628172155f016fc0b135a0d372a6720e35ad0147502ae3a29debd12d5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad7874f74a83a4c0c3d3ca59ce07faab8165a9032ff2d56489f5eaafc30c48fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4865bcd55c6c771defb35dde292d3d9f270798672ea96fe167a9ab28b0993595(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d11700dfee78e9113f59c4e249d44a37c5e1876f5b3f2b952ed92f20d34d74f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d463c870cf503558702cb6ee5ea2bcdacf8c61656ea4abf3a7a646ded6e8f572(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7302140980b7363d8fe96ef420f57dc91f6a9e7feb83b925f1e0c634ed9565ba(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02e55f5b2ef821a5dc07f10c30e8db99d3395690f1cf0e0e341413e5fbd94423(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a92215fcebd0bdccc5c8e131cad60f5efb559cf3d996342ebc506e7cb8ec5b5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25fe71115a112c5cd81c093baf3c793343c486000a6bd7253580d317ae97a438(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44744db8134869564105a3adf178d65dbb9f1d20741fb58f9f71fcc5de841343(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bfe8a402544ea2ef9e406dfa9c1a3ec41fb916664ae4508a2a2fa63401fb483(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60501d6f8659677e1ae8b4f47f6be5d4f44db75438eada84e70f9f5a953277cd(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6cf4c256179d29bb02fd8686e9b54939d83f4b8169b62e7f04ae403fabaeaeb1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__929c11aee8f0ae6a50de6b7818ccb55a7e619c1dbef8008c17405811a90432c4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89a9a12c218fe1d21ffdf9083b35706e47bbd4de7f2b8e2c6908a181b45b0802(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e34f6c79bce5fe29c60c95e91dae793d99c0ec0e76ffc2a74d9bb3f82132cceb(
    value: typing.Optional[StageExternalAzureFileFormatCsv],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2072e9a056cd4b949f6da0b6ca64afe715512276d6d16d20bdaa15b672420eef(
    *,
    allow_duplicate: typing.Optional[builtins.str] = None,
    binary_format: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    date_format: typing.Optional[builtins.str] = None,
    enable_octal: typing.Optional[builtins.str] = None,
    file_extension: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    multi_line: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_null_values: typing.Optional[builtins.str] = None,
    strip_outer_array: typing.Optional[builtins.str] = None,
    time_format: typing.Optional[builtins.str] = None,
    timestamp_format: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bc0d40213f69a59f2992505772e3c88939462f4be499811c6d025a61918b84d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__182493486c89142ad4de134db49ab301de1049ecbda299a42ce191020622d504(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69929b579e2cbe15fb131b91f2e5742b8c2c029404b4feb733d5239e91ccd71b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d55805fd3cf0453794d73f005dc0f9f99c3d889a885fc2da5d179dccb01ba91(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2374b02ff7f8ce3334e64a28d89ff35f046c601d5449a6f7c0cc0059bf12182(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a2cb8172b38e910f3b1cd809c25fb2c6d94832c3e36ed77c4daf933bea75120(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__27c3ca6605f353d1403b1bce4d67ed87fefd5316d1862afdbb5b89bb72e1e03f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f92177831e382d2ffc5a6084399422487ba41a45da6104590616ba112825eb8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d05d33a2892c2689cd603e230ef1086049f5bfe899ddb66aeb9dd1507bf7009(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1114a2fe667dabfc7e858ab5b2a2c5580c845d9079fc909e5f9666e673b51b06(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec7385aa93690cb2db854d45616d5e6d7a074227540ea468af17812d34eeffe2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c7f2d3c1d7d23c5d5f6cb913ca3102b85c4c97a8549668832582eda907a6a9e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb96d06839770f95303544b03bebdd22dcb997337ac23361b48d722bb8669231(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__993e77a1fb07a68c6744a4ac0b4f91a24608d5af065fd80da63c0a9b71506fee(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e5dc3a5f1ac125a007c4e5d1e976f20b318c36cf82993eeff87f729792e5825(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4f844e8c7e8d018454ed0c28bc9acb6645b8a90a3b7e766d68924215dd213b6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6150f7d33955be6f9fe55ef4acf63623244e29e6e87f373977e1eb5983cbe06c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be147db232dc708e065f39952bd2b4f72d0a13f271c9db5e45c5591902982cca(
    value: typing.Optional[StageExternalAzureFileFormatJson],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6754c76f05d786f3e430b7e671df398ac6e97c3a33bdb9e8e732f8ce48eaffa6(
    *,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a546d36fd660b5e62265b44f6ae0a8b8949e98dae015a7f728fb074f23ab9da(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de1fea0c442f8964e73d393055e021960bae78d272a764de2284c48a1312344a(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca13f4fbe9f79dea47979842394da8fdd003d5c61e01127b7c5d842cf28f9528(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b69e5cc89fea0412adeb31576bc46c29700bda46bea3d1d8398ac9f48abc201(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b990aa922bc799744bbaa441662394c112236be80bf39e51b0c3d104159687f3(
    value: typing.Optional[StageExternalAzureFileFormatOrc],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e73cd07cbfbde2b8854924e26e7a6d9d2ee455352449e7f7b27fb9d0b3e7ca1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5418762edd8a90f5b24c2d19629cf179bd45c9de747af0548b1b8e56c91de89(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0427f727f3daa926db4b9505764e80a8158f958634826fb7f5f10ed3c235e6f1(
    value: typing.Optional[StageExternalAzureFileFormat],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b64fcb793169d19ead559d7280bf7219b1afd06b608eefc1cd344808085b1896(
    *,
    binary_as_text: typing.Optional[builtins.str] = None,
    compression: typing.Optional[builtins.str] = None,
    null_if: typing.Optional[typing.Sequence[builtins.str]] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    trim_space: typing.Optional[builtins.str] = None,
    use_logical_type: typing.Optional[builtins.str] = None,
    use_vectorized_scanner: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77063848606275970f321d90c1f01eed11d1cfca02e3c04a8311453ac0cc9b4e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f66fc80f86ac410a1a7b807466e4bca0a6ab2573d558f65eb17fcc80030a559a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__87c4151856e01187b6cdd1a5b61755cc7973f5d73da1482a9a619d7e7fbea6fa(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b3c501790f623c663ff17b3c1b8a01554ad959b2c19d548d0d99bfc86a8d651(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa23aaeed942e2db56d4a8b7dce0113d1d1ee6b09ff375486201dd00d428cd9a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a07a9e9ef17873ffc66deaf062da90cc9a8c6f61984931580246fd38ae016fa(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25f72827314738141e7cd2179755a699a1159d8a08f8fdfd9139ac66ae98fbbc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acd057cc5c8e84d945939f551230f722f67bf9ffbe8353ccac682abf2e2fd2fe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dab149dae694c166aaa6ea5a8573fe7c19ed32f34d3c23d111bb2f864567da22(
    value: typing.Optional[StageExternalAzureFileFormatParquet],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0aa302eb53dbdbe8f03b896aba834f4eb3f800bf5ea90fe442a602161cef37a2(
    *,
    compression: typing.Optional[builtins.str] = None,
    disable_auto_convert: typing.Optional[builtins.str] = None,
    ignore_utf8_errors: typing.Optional[builtins.str] = None,
    preserve_space: typing.Optional[builtins.str] = None,
    replace_invalid_characters: typing.Optional[builtins.str] = None,
    skip_byte_order_mark: typing.Optional[builtins.str] = None,
    strip_outer_element: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b28c99574e80496e8ce739abbfc71ce265f66425977deee538d8fcf4b7e20466(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e074eed1ca7c54a90d9d021fde3506f43851b253c402a594f36ae7930d9cfd2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c09862d943f83347589b6ed53ffdcdc8d62b511c29846bfc5f94297047c8ed7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84355536cf614f7662f9870c2bcef492335127446f6189a0ca6ba1ef230121df(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1a40e884ff6d9cc67c34546fca35c8dbf5be611c7afead38d26cc665203e17f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f50c8942a9a48bca4e145a488b78c7e2c4c7fb6fe34e5c812914c8126b67949(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1bd908f943d7f768b8bb3d34a8ab22e4cb992bc423d7d8e51d12df76ec553db(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42ffd42ff76dc2bcba191986507c43ebcb0249a6b63fbcb77dfafb2d9ebbf622(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32dae6d0a00c08ab50f1ec36dbd61d7da951c414f5e9951d6915feb7e8dc5900(
    value: typing.Optional[StageExternalAzureFileFormatXml],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6c5fda5f190d39344e84dc1367eef0580b3c998e12dd5a1552c3440ec5a1865(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e24d1cdb14428a4e37a3d94162266453cc36a567af46b50d0c42fb05249f8273(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d02733091bdbcff2bf1e0760605ab4107bc696ef8295534c737274d7baed12b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a96dd97ef2e9a91f9a39c3cb58ddcd1ca1a30024f97ed8c55cda13c08411cb9(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d76e566b9b2d43de3fbffacbc72420a32de5d34b6838b7046f7738cb690bc32e(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57537c63dc43b2bb239542571e6b94f0e50c70d5acb11088aba56bbb46aae9a1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2cd69d1867748b7a6d033eb9d142a3faabfbdb15786342cea2012f0f45adb892(
    value: typing.Optional[StageExternalAzureShowOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03051ce33b778b81fac96d5a28162606a2b463ef890f59579c4bf05ec8486c51(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40f5a003ef4bf0fbd789c4bd6efa1a19323b676c281602cf6d4e3d2cb33407de(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3836ae759027a3ba31c451d2ffad923d6e55aa9f3fce328757714b97f23ffc5f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1eb7ba67ba274e0d3d7cdaab22a4318137fd30bdb8dda0ed914945c7ee756e6a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ce666dbec0d421b7bfc2a28871b401f11bb8888958fd240b5ad6711cf092ac2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d281a0652028120afb527444369049cc7ab57058e3711025814fbcb876b054e6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5efe1e0605765ddc7286646194bb85d3daa524464819d8fe83abb5172ac57c77(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, StageExternalAzureTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
