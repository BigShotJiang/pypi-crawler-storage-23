

class Curve:
	def __init__(self, ondate, expcal):
		self.contracts = []
		self.data = dict()
		self.data['_type'] = 'VarCurve'
		self.data['ondate'] = {
			'calendar': expcal,
			'curveDate': ondate
		}
		self.data['contracts'] = self.contracts

	def addContract(self, tenor, value):
		c = Contract(tenor, value)
		self.contracts.append(c)

class Contract:
	def __init__(self, tenor, value):
		self.data = dict()
		self.data['tenor'] = tenor
		self.data['value'] = value
