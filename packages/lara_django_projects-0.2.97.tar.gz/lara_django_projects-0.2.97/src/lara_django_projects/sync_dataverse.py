

from logging import getLogger

from django.conf import settings

from django.apps import apps

import asyncio

from .sync_lara_projects import sync_project

from .dataverse_connector_interface import DataverseConnectorInterface

logger = getLogger(__name__)

def sync_with_dataverse(sender, instance, **kwargs):
   
    logger.debug(f"***-- now syncing ProjectSynchronisation - projects post_save_handler1: {sender}, {instance}, ") #{created}


    dvc_if = DataverseConnectorInterface()

    print(f"---***-- now syncing ProjectSynchronisation - projects post_save_handler1: {sender}, {instance}, ")
    
    #projects_to_sync = instance.projects # .projects.all()

    for project in instance.projects.all():
        print(f"   ***-- now syncing Proj: {project.name}")
        sync_project(project, dv_interface=dvc_if)
   
