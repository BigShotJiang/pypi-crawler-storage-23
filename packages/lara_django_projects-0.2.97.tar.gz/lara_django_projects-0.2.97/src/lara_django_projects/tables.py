"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects admin *

:details: lara_django_projects admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_projects >> tables.py" to update this file
________________________________________________________________________
"""
# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_projects
# generated with django-extensions tests_generator  lara_django_projects > tests.py (LARA-version)

import logging
from django.utils.html import format_html
import django_tables2 as tables


from .models import (
    Experiment,
    Project,
    ExperimentsSubset,
    ProjectsSubset,
    ProjectCalendar,
    ExperimentCalendar,
    ProjectSynchronisation,
)


class ExperimentTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_projects:experiment-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_projects:experiment-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_projects:experiment-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = Experiment

        fields = (
            "name",
            "namespace",
            "parent",
            "datetime_start",
            "datetime_added",
            "status",
            "observations",
            "description",
            "remarks",
        )


class ProjectTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_projects:project-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_projects:project-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_projects:project-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = Project

        fields = (
            "name",
            "namespace",
            "parent",
            "datetime_start",
            "datetime_added",
            "status",
            "outcome",
            "description",
            "remarks",
        )


class ExperimentsSubsetTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_projects:experimentselection-detail", [tables.A("pk")]))

    class Meta:
        model = ExperimentsSubset

        fields = ("name", "user")


class ProjSelectionTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_projects:projselection-detail", [tables.A("pk")]))

    class Meta:
        model = ProjectsSubset

        fields = ("name", "user")


class ProjectCalendarTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name_display = tables.Column(linkify=("lara_django_projects:projectscalendar-detail", [tables.A("pk")]))

    class Meta:
        model = ProjectCalendar

        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "project",
        )


class ExperimentCalendarTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name_display = tables.Column(linkify=("lara_django_projects:experimentcalendar-detail", [tables.A("pk")]))

    class Meta:
        model = ExperimentCalendar

        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "experiment",
        )


class ProjectSynchronisationTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(
        linkify=(
            "lara_django_projects:projectsynchronisationsettings-detail",
            [tables.A("pk")],
        )
    )

    class Meta:
        model = ProjectSynchronisation

        fields = (
            "name",
            "target_server",
            "login",
            "pass_wd",
            "auth_key",
            "cert",
            "datetime_started",
            "duration",
            "event_repeat",
            "event_repeat_json",
            "logs",
            "description",
        )
