"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_projects  (LARA-version)

from django_socio_grpc import proto_serializers
from lara_django_base.models import ExternalResource
from lara_django_base.models import GeoLocation
from lara_django_base.models import ItemStatus
from lara_django_base.models import LARASyncServer
from lara_django_base.models import Location
from lara_django_base.models import Namespace
from lara_django_base.models import Tag
from lara_django_data.models import Data
from lara_django_data.models import Evaluation
from lara_django_material_store.models import DeviceInstance
from lara_django_material_store.models import DeviceSetupInstance
from lara_django_material_store.models import LabwareInstance
from lara_django_material_store.models import PartInstance
from lara_django_organisms_store.models import OrganismInstance
from lara_django_people.models import Entity
from lara_django_people.models import Group
from lara_django_processes.models import MethodInstance
from lara_django_processes.models import ProcedureInstance
from lara_django_processes.models import ProcessInstance
from lara_django_projects_grpc.v1 import lara_django_projects_pb2
from lara_django_samples.models import Sample
from lara_django_substances_store.models import MixtureInstance
from lara_django_substances_store.models import PolymerInstance
from lara_django_substances_store.models import SubstanceInstance
from rest_framework.serializers import PrimaryKeyRelatedField
from rest_framework.serializers import UUIDField

from lara_django_projects.models import Experiment
from lara_django_projects.models import ExperimentCalendar
from lara_django_projects.models import ExperimentsSubset
from lara_django_projects.models import Project
from lara_django_projects.models import ProjectCalendar
from lara_django_projects.models import ProjectsSubset
from lara_django_projects.models import ProjectSynchronisation
from lara_django_projects.models import ProjectSyncStatus
from lara_django_projects.models import Task


class TaskProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    entities = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    task_base = PrimaryKeyRelatedField(
        queryset=Task.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = Task
        proto_class = lara_django_projects_pb2.TaskResponse

        proto_class_list = lara_django_projects_pb2.TaskListResponse

        fields = "__all__"


class ProjectProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    entities = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )
    parent = PrimaryKeyRelatedField(
        queryset=Project.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    outcome = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    experiments = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    # data = PrimaryKeyRelatedField(
    #     queryset=Data.objects.all(),
    #     pk_field=UUIDField(format="hex_verbose"),
    #     required=False,
    #     allow_null=True,
    #     many=True,
    # )

    # evaluations = PrimaryKeyRelatedField(
    #     queryset=Evaluation.objects.all(),
    #     pk_field=UUIDField(format="hex_verbose"),
    #     many=True,
    #     required=False,
    #     allow_null=True,
    # )

    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, allow_null=True, required=False
    )

    class Meta:
        model = Project
        proto_class = lara_django_projects_pb2.ProjectResponse

        proto_class_list = lara_django_projects_pb2.ProjectListResponse

        fields = "__all__"  # [namespace', title', name', name_full', parent', hash_sha256', UUID', datetime_start',
        # datetime_added', status', outcome', view_selected', view_collapsed', literature', description',
        # remarks', IRI', handle', lft', rght', level']


class ProjectsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    selected_items = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = ProjectsSubset
        proto_class = lara_django_projects_pb2.ProjectsSubsetResponse

        proto_class_list = lara_django_projects_pb2.ProjectsSubsetListResponse

        fields = "__all__"  # [name', entity']


class ExperimentProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entities = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    parent = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    experiment_design = PrimaryKeyRelatedField(
        queryset=ProcessInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    experiment_base = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), allow_null=True, required=False
    )
    outcome = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    data = PrimaryKeyRelatedField(
        queryset=Data.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    evaluations = PrimaryKeyRelatedField(
        queryset=Evaluation.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    method_instances = PrimaryKeyRelatedField(
        queryset=MethodInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    process_instances = PrimaryKeyRelatedField(
        queryset=ProcessInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    procedure_instances = PrimaryKeyRelatedField(
        queryset=ProcedureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    organism_instances = PrimaryKeyRelatedField(
        queryset=OrganismInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    part_instances = PrimaryKeyRelatedField(
        queryset=PartInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_instances = PrimaryKeyRelatedField(
        queryset=DeviceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    device_setup_instances = PrimaryKeyRelatedField(
        queryset=DeviceSetupInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )
    labware_instances = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    samples = PrimaryKeyRelatedField(
        queryset=Sample.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    reference_experiment = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(), pk_field=UUIDField(format="hex_verbose"), allow_null=True, required=False
    )

    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        allow_null=True,
        required=False,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, allow_null=True, required=False
    )

    class Meta:
        model = Experiment
        proto_class = lara_django_projects_pb2.ExperimentResponse

        proto_class_list = lara_django_projects_pb2.ExperimentListResponse

        fields = "__all__"  # [namespace', title', name', name_full', parent', experiment_design', hash_sha256', UUID',
        # datetime_start',  datetime_added', status', outcome', view_selected',
        # view_collapsed', method', procedure', process', reference_sample_source', parameters', reference_experiment',
        # literature', observations', description', remarks', IRI', handle', lft', rght', level']


class ExperimentsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    selected_items = PrimaryKeyRelatedField(
        queryset=Experiment.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = ExperimentsSubset
        proto_class = lara_django_projects_pb2.ExperimentsSubsetResponse

        proto_class_list = lara_django_projects_pb2.ExperimentsSubsetListResponse

        fields = "__all__"  # [name', entity']


class ProjectCalendarProtoSerializer(proto_serializers.ModelProtoSerializer):
    user = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    geolocation = PrimaryKeyRelatedField(
        queryset=GeoLocation.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    project = PrimaryKeyRelatedField(
        queryset=Project.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, allow_null=True, required=False
    )
    attendees = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = ProjectCalendar
        proto_class = lara_django_projects_pb2.ProjectCalendarResponse

        proto_class_list = lara_django_projects_pb2.ProjectCalendarListResponse

        fields = "__all__"  # [title', calendar_url', summary', description', color', ics',
        # datetime_start', datetime_end', duration',
        # all_day', created', last_modified', timestamp', location', geolocation', conference_url', range',
        # related', role', tzid', offset_utc', alarm_repeat_json', event_repeat', event_repeat_json', user',
        # project']


class ExperimentCalendarProtoSerializer(proto_serializers.ModelProtoSerializer):
    user = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    geolocation = PrimaryKeyRelatedField(
        queryset=GeoLocation.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    project = PrimaryKeyRelatedField(
        queryset=Project.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, allow_null=True, required=False
    )
    attendees = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = ExperimentCalendar
        proto_class = lara_django_projects_pb2.ExperimentCalendarResponse

        proto_class_list = lara_django_projects_pb2.ExperimentCalendarListResponse

        fields = (
            "__all__"  # [title', calendar_url', summary', description', color', ics',
            # datetime_start', datetime_end',
        )
        # duration', all_day', created', last_modified', timestamp', location', geolocation', conference_url', range',
        # related', role', tzid', offset_utc', alarm_repeat_json', event_repeat', event_repeat_json', user',
        #  experiment']


class ProjectSynchronisationProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    server_target = PrimaryKeyRelatedField(
        queryset=LARASyncServer.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    projects = PrimaryKeyRelatedField(
        queryset=Project.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = ProjectSynchronisation
        proto_class = lara_django_projects_pb2.ProjectSynchronisationResponse

        proto_class_list = lara_django_projects_pb2.ProjectSynchronisationListResponse

        fields = "__all__"  # [name', target_server', login', pass_wd', auth_key', cert', datetime_started',
        # duration', event_repeat', event_repeat_json', logs', description']


class ProjectSyncStatusProtoSerializer(proto_serializers.ModelProtoSerializer):
    server = PrimaryKeyRelatedField(
        queryset=LARASyncServer.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    projects = PrimaryKeyRelatedField(
        queryset=Project.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    status = PrimaryKeyRelatedField(queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"))

    class Meta:
        model = ProjectSyncStatus
        proto_class = lara_django_projects_pb2.ProjectSyncStatusResponse

        proto_class_list = lara_django_projects_pb2.ProjectSyncStatusListResponse

        fields = "__all__"  # [project_synchronisation', project', status', datetime_started', duration',
        # event_repeat', event_repeat_json', logs', description']
