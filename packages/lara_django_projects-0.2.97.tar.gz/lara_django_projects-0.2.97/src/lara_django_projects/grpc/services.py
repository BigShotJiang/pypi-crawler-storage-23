"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_projects  (LARA-version)

from django_socio_grpc import generics
from django_socio_grpc import mixins
from lara_django_base.grpc.mixins import AsyncDownloadModelMixin
from lara_django_base.grpc.mixins import AsyncRetrieveByNameModelMixin
from lara_django_base.grpc.mixins import AsyncUploadModelMixin

from lara_django_projects.filters import ExperimentFilter
from lara_django_projects.filters import ProjectFilter
from lara_django_projects.filters import TaskFilter
from lara_django_projects.models import Experiment
from lara_django_projects.models import ExperimentCalendar
from lara_django_projects.models import ExperimentsSubset
from lara_django_projects.models import Project
from lara_django_projects.models import ProjectCalendar
from lara_django_projects.models import ProjectsSubset
from lara_django_projects.models import ProjectSynchronisation
from lara_django_projects.models import ProjectSyncStatus
from lara_django_projects.models import Task

from .serializers import ExperimentCalendarProtoSerializer
from .serializers import ExperimentProtoSerializer
from .serializers import ExperimentsSubsetProtoSerializer
from .serializers import ProjectCalendarProtoSerializer
from .serializers import ProjectProtoSerializer
from .serializers import ProjectsSubsetProtoSerializer
from .serializers import ProjectSynchronisationProtoSerializer
from .serializers import ProjectSyncStatusProtoSerializer
from .serializers import TaskProtoSerializer

import lara_django_projects_grpc.v1.lara_django_projects_pb2 as lara_django_procjects_pb2

class TaskService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_procjects_pb2
    queryset = Task.objects.all()
    serializer_class = TaskProtoSerializer
    filterset_class = TaskFilter


class ExperimentService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_procjects_pb2
    queryset = Experiment.objects.all()
    serializer_class = ExperimentProtoSerializer
    filterset_class = ExperimentFilter


class ProjectService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_procjects_pb2
    queryset = Project.objects.all()
    serializer_class = ProjectProtoSerializer
    filterset_class = ProjectFilter


class ExperimentsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ExperimentsSubset.objects.all()
    serializer_class = ExperimentsSubsetProtoSerializer


class ProjectsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ProjectsSubset.objects.all()
    serializer_class = ProjectsSubsetProtoSerializer


class ProjectCalendarService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ProjectCalendar.objects.all()
    serializer_class = ProjectCalendarProtoSerializer


class ExperimentCalendarService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ExperimentCalendar.objects.all()
    serializer_class = ExperimentCalendarProtoSerializer


class ProjectSynchronisationService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ProjectSynchronisation.objects.all()
    serializer_class = ProjectSynchronisationProtoSerializer


class ProjectSyncStatusService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ProjectSyncStatus.objects.all()
    serializer_class = ProjectSyncStatusProtoSerializer
