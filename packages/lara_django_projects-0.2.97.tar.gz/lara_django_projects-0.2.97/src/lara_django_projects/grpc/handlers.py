"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_projects  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry

from lara_django_projects.grpc.services import ExperimentCalendarService
from lara_django_projects.grpc.services import ExperimentService
from lara_django_projects.grpc.services import ExperimentsSubsetService
from lara_django_projects.grpc.services import ProjectCalendarService
from lara_django_projects.grpc.services import ProjectService
from lara_django_projects.grpc.services import ProjectsSubsetService
from lara_django_projects.grpc.services import ProjectSynchronisationService
from lara_django_projects.grpc.services import ProjectSyncStatusService
from lara_django_projects.grpc.services import TaskService


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_projects", server)

    app_registry.get_grpc_module = lambda: "lara_django_projects_grpc.v1"

    app_registry.register(TaskService)

    app_registry.register(ExperimentService)

    app_registry.register(ProjectService)

    app_registry.register(ProjectsSubsetService)

    app_registry.register(ExperimentsSubsetService)

    app_registry.register(ProjectCalendarService)

    app_registry.register(ExperimentCalendarService)

    app_registry.register(ProjectSynchronisationService)

    app_registry.register(ProjectSyncStatusService)
