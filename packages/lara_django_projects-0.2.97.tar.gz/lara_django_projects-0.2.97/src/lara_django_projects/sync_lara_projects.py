# recursively sync all projects and experiments to dataverse

def sync_project(project, parent_project=None, dv_interface=None):
    dv_interface.create_dataverse_collection(project)

    for experiment in project.experiments.all():
            dv_interface.create_dataset(experiment)
            # iterate over all data
            for datum in experiment.data.all():
                dv_interface.add_file_to_dataset(datum)
    # iterate recursively over all subprojects
    for subproject in project.get_descendants():
        sync_project(subproject, project, dv_interface)