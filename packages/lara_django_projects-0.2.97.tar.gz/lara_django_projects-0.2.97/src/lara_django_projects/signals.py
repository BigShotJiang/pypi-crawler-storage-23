"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_data signals handler *

:details: lara_django_projects signals handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

# get settings from django.conf
import logging

from django.apps import apps

# import asyncio
from django.conf import settings
from django.contrib.postgres.search import SearchVector
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from lara_django_base.decorators import postgres_only
from lara_django_people.models import EntityRole

from .models import Experiment, Project, RoledExperimentEntities, RoledProjectEntities, Task
from .semantics import insert_semantic_data

logger = logging.getLogger("lara_signals")


@receiver(post_save, sender=Project)
def create_default_project_role(sender, instance, created, **kwargs):
    """
    post_save signal handler for Project.

    On creation, ensure every already-linked entity has a RoledProjectEntities
    entry with the default 'contributor' role.
    """
    if created:
        role, _ = EntityRole.objects.get_or_create(name="contributor")
        for entity in instance.entities.all():
            RoledProjectEntities.objects.get_or_create(
                project=instance,
                entity=entity,
                defaults={"role": role},
            )


@receiver(post_save, sender=RoledProjectEntities)
def set_default_project_entity_role(sender, instance, created, **kwargs):
    """
    post_save signal handler for RoledProjectEntities.

    When a new through-model entry is created without an explicit role,
    assign the default 'contributor' role.
    """
    if created and instance.role is None:
        role, _ = EntityRole.objects.get_or_create(name="contributor")
        sender.objects.filter(pk=instance.pk).update(role=role)


@receiver(post_save, sender=Experiment)
def create_default_experiment_role(sender, instance, created, **kwargs):
    """
    post_save signal handler for Experiment.

    On creation, ensure every already-linked entity has a RoledExperimentEntities
    entry with the default 'contributor' role.
    """
    if created:
        role, _ = EntityRole.objects.get_or_create(
            name="contributor",
            defaults={"description": "Contributor of a project or experiment"},
        )
        for entity in instance.entities.all():
            RoledExperimentEntities.objects.get_or_create(
                experiment=instance,
                entity=entity,
                defaults={"role": role},
            )


@receiver(post_save, sender=RoledExperimentEntities)
def set_default_experiment_entity_role(sender, instance, created, **kwargs):
    """
    post_save signal handler for RoledExperimentEntities.

    When a new through-model entry is created without an explicit role,
    assign the default 'contributor' role.
    """
    if created and instance.role is None:
        role, _ = EntityRole.objects.get_or_create(
            name="contributor",
            defaults={"description": "Contributor of a project or experiment"},
        )
        sender.objects.filter(pk=instance.pk).update(role=role)


@receiver(post_save, sender=Task)
@postgres_only
def update_task_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


@receiver(post_save, sender=Project)
@postgres_only
def update_project_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


@receiver(post_save, sender=Experiment)
@postgres_only
def update_experiment_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


# @receiver(post_save, sender=Evaluation)
# def semantics_data_handler(sender, instance, created, **kwargs):
#     """Semantic data post_save signal handler.

#        This function is triggered after an instance of the Evaluation model is saved.
#        It calls the insert_semantics function to handle the semantic data insertion
#        into the triplestore, running asynchronously as celery task.
#     """
#     logger.debug("post_save_handler1: %s, %s ", sender, instance)
#     insert_semantic_data(sender, instance, **kwargs)
