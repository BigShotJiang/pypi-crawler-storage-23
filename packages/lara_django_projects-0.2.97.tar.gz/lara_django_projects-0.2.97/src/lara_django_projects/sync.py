import asyncio

#from prefect import get_client


async def run_sync(sync_name):
    parameters = dict(name=sync_name)
    print("sync_name:", sync_name)        
    # async with get_client() as client:
    #     res = await client.read_deployments()
    #     dp2 = res[0]        
    #     res = await client.create_flow_run_from_deployment(dp2.id, parameters=parameters)

    # print("--------> flow:", res)
