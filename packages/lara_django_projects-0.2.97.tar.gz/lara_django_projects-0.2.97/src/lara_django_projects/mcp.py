"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_projects Model Context Protocol (MCP) handler *

:details: lara_django_projects Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    Experiment,
    ExperimentCalendar,
    ExperimentsSubset,
    OrderedExperimentsSubset,
    OrderedProjectsSubset,
    Project,
    ProjectCalendar,
    ProjectsSubset,
    ProjectSynchronisation,
    ProjectSyncStatus,
    RoledExperimentEntities,
    RoledProjectEntities,
    Task,
)


class TaskQueryTool(ModelQueryToolset):
    """MCP query tool for the `Task` model."""

    model = Task


class ProjectQueryTool(ModelQueryToolset):
    """MCP query tool for the `Project` model."""

    model = Project


class RoledProjectEntitiesQueryTool(ModelQueryToolset):
    """MCP query tool for the `RoledProjectEntities` model."""

    model = RoledProjectEntities


class ProjectsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for the `ProjectsSubset` model."""

    model = ProjectsSubset


class OrderedProjectsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for the `OrderedProjectsSubset` model."""

    model = OrderedProjectsSubset


class ExperimentQueryTool(ModelQueryToolset):
    """MCP query tool for the `Experiment` model."""

    model = Experiment


class RoledExperimentEntitiesQueryTool(ModelQueryToolset):
    """MCP query tool for the `RoledExperimentEntities` model."""

    model = RoledExperimentEntities


class ExperimentsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for the `ExperimentsSubset` model."""

    model = ExperimentsSubset


class OrderedExperimentsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool for the `OrderedExperimentsSubset` model."""

    model = OrderedExperimentsSubset


class ProjectCalendarQueryTool(ModelQueryToolset):
    """MCP query tool for the `ProjectCalendar` model."""

    model = ProjectCalendar


class ExperimentCalendarQueryTool(ModelQueryToolset):
    """MCP query tool for the `ExperimentCalendar` model."""

    model = ExperimentCalendar


class ProjectSynchronisationQueryTool(ModelQueryToolset):
    """MCP query tool for the `ProjectSynchronisation` model."""

    model = ProjectSynchronisation


class ProjectSyncStatusQueryTool(ModelQueryToolset):
    """MCP query tool for the `ProjectSyncStatus` model."""

    model = ProjectSyncStatus
