"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects admin *

:details: lara_django_projects admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_projects >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import Experiment
from .models import RoledExperimentEntities
from .models import ExperimentCalendar
from .models import ExperimentsSubset
from .models import Project
from .models import RoledProjectEntities
from .models import ProjectCalendar
from .models import ProjectsSubset
from .models import ProjectSynchronisation
from .models import ProjectSyncStatus

class RoledProjectEntitiesInline(admin.TabularInline):  # or StackedInline
    model = RoledProjectEntities
    extra = 1 

class RoledExperimentEntitiesInline(admin.TabularInline):  # or StackedInline
    model = RoledExperimentEntities
    extra = 1 

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "name_display",
        "parent",
        "datetime_start",
        "datetime_added",
        "status",
        "outcome",
       
    )
    list_filter = (
        "namespace",
        "parent",
        "datetime_start",
        "datetime_added",
        "status",
        "outcome",
    )
   # raw_id_fields = ("entities", "experiments", "tags")
    search_fields = ("name",)
    inlines = [RoledProjectEntitiesInline]

@admin.register(RoledProjectEntities)
class RoledProjectEntitiesAdmin(admin.ModelAdmin):
    list_display = ("project", "entity", "role")
    list_filter = ("role",)
    search_fields = ("project", "entity")

@admin.register(Experiment)
class ExperimentAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "name_display",
        "parent",
        "datetime_start",
        "datetime_added",
        "status",
        "outcome",
        "parameters",
        "reference_experiment",
        "description",
        "remarks",
    )
    list_filter = (
        "namespace",
        "parent",
        "experiment_design",
        "datetime_start",
        "datetime_added",
        "status",
        "outcome",
        "reference_experiment",
    )
    raw_id_fields = (
        "entities",
        "data",
        "evaluations",
        "method_instances",
        "procedure_instances",
        "process_instances",
        "substance_instances",
        "polymer_instances",
        "mixture_instances",
        "part_instances",
        "device_instances",
        "device_setup_instances",
        "labware_instances",
        "organism_instances",
        "samples",
        "tags",
    )
    search_fields = ("name",)
    inlines = [RoledExperimentEntitiesInline]

@admin.register(RoledExperimentEntities)
class RoledExperimentEntitiesAdmin(admin.ModelAdmin):
    list_display = ("experiment", "entity", "role")
    list_filter = ("role",)
    search_fields = ("experiment", "entity")


@admin.register(ExperimentsSubset)
class ExperimentsSubsetAdmin(admin.ModelAdmin):
    list_display = ("experimentselection_id", "name", "entity")
    list_filter = ("entity",)
    search_fields = ("name",)


@admin.register(ProjectsSubset)
class ProjSelectionAdmin(admin.ModelAdmin):
    list_display = ("projectselection_id", "name", "entity")
    list_filter = ("entity",)
    search_fields = ("name",)


@admin.register(ProjectCalendar)
class ProjectCalendarAdmin(admin.ModelAdmin):
    list_display = (
        "name_display",
        "calendar_url",
        "summary",
        "description",
        "color",
        "datetime_start",
        "datetime_end",
        "duration",
        "all_day",
        "created",
        "datetime_last_modified",
        "timestamp",
        "location",
        "geolocation",
        "conference_url",
        "range",
        "related",
        "role",
        "tzid",
        "offset_utc",
        "alarm_repeat_json",
        "event_repeat",
        "event_repeat_json",
        "user",
        "project",
    )
    list_filter = (
        "datetime_start",
        "datetime_end",
        "all_day",
        "created",
        "datetime_last_modified",
        "timestamp",
        "location",
        "geolocation",
        "user",
        "project",
    )
    raw_id_fields = ("tags", "attendees")


@admin.register(ExperimentCalendar)
class ExperimentCalendarAdmin(admin.ModelAdmin):
    list_display = (
        "name_display",
        "calendar_url",
        "summary",
        "description",
        "color",
        "datetime_start",
        "datetime_end",
        "duration",
        "all_day",
        "created",
        "datetime_last_modified",
        "timestamp",
        "location",
        "geolocation",
        "conference_url",
        "range",
        "related",
        "role",
        "tzid",
        "offset_utc",
        "alarm_repeat_json",
        "event_repeat",
        "event_repeat_json",
        "experimentcalendar_id",
        "user",
        "experiment",
    )
    list_filter = (
        "datetime_start",
        "datetime_end",
        "all_day",
        "created",
        "datetime_last_modified",
        "timestamp",
        "location",
        "geolocation",
        "user",
        "experiment",
    )
    raw_id_fields = ("tags", "attendees")


@admin.register(ProjectSynchronisation)
class ProjectSynchronisationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "datetime_start",
        "event_repeat",
        "event_repeat_json",
        "logs",
        "description",
        "sync_id",
    )
    list_filter = ("datetime_start",)
    raw_id_fields = ("projects",)
    search_fields = ("name",)


@admin.register(ProjectSyncStatus)
class ProjectSyncStatusAdmin(admin.ModelAdmin):
    list_display = (
        # "datetime_start",
        # "datetime_end",
        # "status",
        # "logs",
        # "description",
        # "syncstatus_id",
    )
    # list_filter = ("datetime_start", "datetime_end", "status")
    # raw_id_fields = ("project_sync", )
    search_fields = ("name",)
