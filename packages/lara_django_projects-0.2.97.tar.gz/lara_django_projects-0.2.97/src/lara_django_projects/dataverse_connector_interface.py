

# create the dataverse LinkML model

# 

import asyncio

import json
from datetime import datetime

from httpx import Client

from typing import List, Union, Optional

from pydantic import BaseModel, EmailStr, HttpUrl
from pydantic_settings import BaseSettings

from pyDataverse.api import NativeApi
from pyDataverse.models import Dataverse, Dataset, Datafile
from pyDataverse.utils import read_file

# retrieve the database configuration (e.g. root dataverse url, api key, etc) from the lara_django_base.database_config module

# use environment variables to store the dataverse api key and the dataverse url
# get the dataverse api key and the dataverse url from the environment variables with pydantic settings

class DataverseSettings(BaseSettings):
    dataverse_api_key: str
    dataverse_url: str

    class Config:
        env_file = ".env"

class DataverseContact(BaseModel):
    contactEmail: EmailStr

class Dataverse(BaseModel):
    name: str
    alias: str
    dataverseContacts: List[DataverseContact]
    affiliation: str
    description: str
    dataverseType: str


class DataverseConnectorInterface:
    def __init__(self, dataverse_api_key: str = None, dataverse_url: str = None):
        # Try to get settings from environment variables or use provided parameters
        try:
            self._dataverse_settings = DataverseSettings()
            self.dataverse_api_key = dataverse_api_key or self._dataverse_settings.dataverse_api_key
            self.dataverse_url = dataverse_url or self._dataverse_settings.dataverse_url
        except Exception:
            # If environment variables aren't available, fall back to provided parameters or defaults
            self.dataverse_api_key = dataverse_api_key or ""
            self.dataverse_url = dataverse_url or ""
        
        # Initialize the API connection
        if self.dataverse_url and self.dataverse_api_key:
            self.dv_api = NativeApi(self.dataverse_url, self.dataverse_api_key)
            try:
                resp = self.dv_api.get_info_version()
                print("DataVerse connector established:", resp.json())
            except Exception as e:
                print(f"Failed to establish DataVerse connection: {e}")
                self.dv_api = None
        else:
            self.dv_api = None
            print("DataVerse API key or URL not configured")

       

    def create_dataverse_collection(self, project) -> str:
        if not self.dv_api:
            raise Exception("Dataverse API not initialized")
            
        print(f"+ Creating collection {project.name} with description {project.description}")

        dv_slug = project.name.lower().replace(" ", "-")
        dataverse_definition = Dataverse(
            name=project.name,
            alias=dv_slug,
            dataverseContacts=[
                {"contactEmail": "mark.doerr@example.com"},
                {"contactEmail": "vladimir@example.com"}  
            ],
            affiliation="lara.org",
            description="We do all the science.",
            dataverseType="LABORATORY"
        )
        print(dataverse_definition.model_dump_json())
        
        # Create the dataverse with the root dataverse as parent
        try:
            resp = self.dv_api.create_dataverse("root", dataverse_definition.model_dump_json())
            if resp.status_code == 200:
                # Return the identifier of the created dataverse
                return resp.json().get('data', {}).get('id', '')
            else:
                print(f"Error creating dataverse: {resp.text}")
                return ""
        except Exception as e:
            print(f"Exception creating dataverse: {e}")
            return ""


    def retrieve_dataverse(self) -> List:
        if not self.dv_api:
            return []
        try:
            # Get all dataverses (this is a simplified approach)
            resp = self.dv_api.get_dataverses()
            if resp.status_code == 200:
                return resp.json().get('data', [])
            return []
        except Exception as e:
            print(f"Error retrieving dataverses: {e}")
            return []

    def update_dataverse(self) -> str:
        # Placeholder implementation
        return ""

    def delete_dataverse(self) -> bool:
        # Placeholder implementation
        return False

    def create_dataset(self, experiment) -> str:
        if not self.dv_api:
            raise Exception("Dataverse API not initialized")
            
        print(f"  -> Creating dataset {experiment.name} with description {experiment.description}")
        
        # Create a basic dataset structure
        try:
            # This is a simplified approach - in practice, you'd want to create a proper dataset
            # For now, we'll just return a mock identifier
            return f"dataset-{experiment.name.replace(' ', '-')}"
        except Exception as e:
            print(f"Exception creating dataset: {e}")
            return ""

    def retrieve_dataset(self) -> List:
        if not self.dv_api:
            return []
        try:
            # Get all datasets (simplified)
            resp = self.dv_api.get_datasets()
            if resp.status_code == 200:
                return resp.json().get('data', [])
            return []
        except Exception as e:
            print(f"Error retrieving datasets: {e}")
            return []

    def update_dataset(self) -> str:
        # Placeholder implementation
        return ""

    def delete_dataset(self) -> bool:
        # Placeholder implementation
        return False

    def add_file_to_dataset(self, datum) -> str:
        if not self.dv_api:
            raise Exception("Dataverse API not initialized")
            
        print(f"      - Creating file {datum.name} with description {datum.description}")
        
        # Placeholder for adding file to dataset
        try:
            # In a real implementation, this would upload the file to the dataset
            return f"file-{datum.name.replace(' ', '-')}"
        except Exception as e:
            print(f"Exception adding file to dataset: {e}")
            return ""

    def retrieve_files_from_dataset(self) -> List:
        if not self.dv_api:
            return []
        try:
            # Get files from a dataset (simplified)
            resp = self.dv_api.get_files()
            if resp.status_code == 200:
                return resp.json().get('data', [])
            return []
        except Exception as e:
            print(f"Error retrieving files: {e}")
            return []

    def delete_files_from_dataset(self) -> bool:
        # Placeholder implementation
        return False

    def retrieve_dataset_metadata(self) -> List:
        if not self.dv_api:
            return []
        try:
            # Retrieve dataset metadata using the NativeApi
            # This would typically involve getting metadata for a specific dataset
            # For now, we'll return a mock structure that represents what metadata might look like
            resp = self.dv_api.get_dataset_metadata()
            if resp.status_code == 200:
                return resp.json().get('data', [])
            return []
        except Exception as e:
            print(f"Error retrieving dataset metadata: {e}")
            return []

    def update_dataset_metadata(self) -> str:
        # Placeholder implementation
        return ""

    def retrieve_dataverse_metadata(self) -> List:
        # Placeholder implementation
        return []

    def update_dataverse_metadata(self) -> str:
        # Placeholder implementation
        return ""

    def retrieve_dataset_version(self) -> List:
        # Placeholder implementation
        return []

    def update_dataset_version(self) -> str:
        # Placeholder implementation
        return ""

    def retrieve_dataset_version_metadata(self) -> List:
        # Placeholder implementation
        return []

    def update_dataset_version_metadata(self) -> str:
        # Placeholder implementation
        return ""
    