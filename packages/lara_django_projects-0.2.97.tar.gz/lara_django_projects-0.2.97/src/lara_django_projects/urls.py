"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects urls *

:details: lara_django_projects urls module.
         - add app specific urls here
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.urls import path
from django_socio_grpc.settings import grpc_settings

from . import views

# Add your {cookiecutter.project_slug}} urls here.


# !! this sets the apps namespace to be used in the template
app_name = "lara_django_projects"

# companies and institutions should also be added
# the 'name' attribute is used in templates to address the url independent of the view


urlpatterns = [
    # htmx partial: navbar menu items injection
    path("partials/navbar-menu/", views.navbar_menu_items, name="navbar-menu-items"),
    # the 'name' value as called by the {% url %} template tag
    path("project/overview", views.projects_overview, name="project-overview"),
    path("project/tree/<uuid:pk>/", views.ProjectTree.as_view(), name="project-tree"),
    path("project/list/", views.ProjectSingleTableView.as_view(), name="project-list"),
    path("table/", views.ProjectSingleTable1View.as_view(), name="project-table"),
    path('project/add/', views.ProjectAddView.as_view(), name='project-add'),
    path("project/create/", views.ProjectCreateView.as_view(), name="project-create"),
    path("project/update/<uuid:pk>", views.ProjectUpdateView.as_view(), name="project-update"),
    path("project/delete/<uuid:pk>", views.ProjectDeleteView.as_view(), name="project-delete"),
    path("project/<uuid:pk>/", views.ProjectDetailView.as_view(), name="project-detail"),

    path("experiment/list/", views.ExperimentSingleTableView.as_view(), name="experiment-list"),
    path("experiment/create/", views.ExperimentCreateView.as_view(), name="experiment-create"),
    path("experiment/update/<uuid:pk>", views.ExperimentUpdateView.as_view(), name="experiment-update"),
    path("experiment/delete/<uuid:pk>", views.ExperimentDeleteView.as_view(), name="experiment-delete"),
    path("experiment/<uuid:pk>/", views.ExperimentDetailView.as_view(), name="experiment-detail"),
    path("experiment/data/<uuid:pk>", views.ExperimentDataListView.as_view(), name="experiment-data"),
    path("experiment/devices/<uuid:pk>", views.ExperimentDevicesListView.as_view(), name="experiment-devices"),
    path("experiment/substances/<uuid:pk>", views.ExperimentSubstancesListView.as_view(), name="experiment-substances"),
    path("experiment/data-explorer/<uuid:pk>", views.data_explorer, name="experiment-data-explorer"),
    path("details/<uuid:pk>/", views.ProjectDetails.as_view(), name="project-details"),
    # path('<uuid:pk>/', views.ProjectTree.as_view(), name='project-tree'),
    # path('experiments/<uuid:pk>/', views.ExperimentDetails.as_view(),
    #     name='experiment-details'),
    #path("", views.ProjectSingleTableView.as_view(), name="project-root"),
    path("", views.projects_overview, name="projects-overview"),
    path("reviews/", views.ReviewEmailView.as_view(), name="reviews"),
    # ~ path('^projectslist$', views.projectsList, name='projects-list'), # projects as a long list/table
    # ~ path('search/', views.searchForm, name='searchForm'),
    # ~ path('search-results/', views.search, name='search'),
    # ~ path('results/', views.results, name='results'),
]

# urlpatterns = [
#     path('', views.EntitySingleTableView.as_view(), name='entity-list-root'),
#     path('entities/list/', views.EntitySingleTableView.as_view(), name='entity-list'),
#     path('addresses/list/', views.AddressesListView.as_view(), name='address-list'),
#     path('addresses/create/', views.AddressCreateView.as_view(),
#          name='address-create'),
#     path('addresses/update/<uuid:pk>', views.AddressUpdateView.as_view(),
#          name='address-update'),
#     path('addresses/delete/<uuid:pk>', views.AddressDeleteView.as_view(),
#          name='address-delete'),
# ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# register handlers in settings
grpc_settings.user_settings["GRPC_HANDLERS"] += ["lara_django_projects.grpc.handlers.grpc_handlers"]
