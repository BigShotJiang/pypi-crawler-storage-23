"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_projects app *

:details: lara_django_projects app configuration. 
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django.apps import AppConfig
from django.db.models.signals import post_save, pre_save
from django.urls import include, path


class LaraDjangoProjectsConfig(AppConfig):
    name = "lara_django_projects"
    url_path = "projects/"
    # enter a verbose name for your app: lara_django_projects here - this will be used in the admin interface
    verbose_name = "LARA-django Projects"
    lara_app_icon = "lara_projects_icon.svg"  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = "red"  # this will be used to highlight the app in the main LARA sidebar and app page
    verbose_name_short = "Projects"
    lara_app_description = "Projects and Experiments"
    lara_class_apps = [
        {
            "name": "Projects",
            "path":  "lara_django_projects:projects-overview", # "/projects/project/list",
            "icon": "lara_projects_icon.svg",
            "color": lara_app_color,
        },
        {
            "name": "Experiments",
            "path": "lara_django_projects:experiment-list",
            "icon": "lara_experiments_icon.svg",
            "color": lara_app_color,
        }
    ]

    lara_instance_apps = []

    def ready(self):
        import lara_django_projects.signals 

        #post_save.connect(signals.project_post_save_handler, dispatch_uid="lara_django_projects.post_save")

        # add urlpatterns
        from lara_django.urls import urlpatterns

        urlpatterns += [
            path(self.url_path, include("lara_django_projects.urls", namespace="lara_django_projects")),
        ]
