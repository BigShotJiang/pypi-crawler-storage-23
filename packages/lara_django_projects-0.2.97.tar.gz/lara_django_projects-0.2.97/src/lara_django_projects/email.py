
# This file is used to send email to the user who has submitted the review.
# https://www.youtube.com/watch?v=7dUxyIp5mMI&ab_channel=VeryAcademy

from django.template import Context
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from django.conf import settings


def send_review_email(name, email, review):

    context = {
        'name': name,
        'email': email,
        'review': review,
    }

    email_subject = "Thank you for your review"    
    email_body = render_to_string('email/review_email_message.txt', context).strip()

    email = EmailMessage(
        email_subject, email_body, settings.DEFAULT_FROM_EMAIL, [email, ],
    )
    return email.send(fail_silently=False)