"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_projects models *

:details: lara_django_projects database models.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>
________________________________________________________________________
"""

import datetime
import uuid

from django.conf import settings
from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVectorField
from django.db import models
from django.utils import timezone
from lara_django_base.models import (
    CalendarAbstr,
    ExternalResource,
    ItemStatus,
    Namespace,
    SynchronisationAbstr,
    SyncStatusAbstr,
    Tag,
)
from lara_django_data.models import Data, Evaluation
from lara_django_material_store.models import DeviceInstance, DeviceSetupInstance, LabwareInstance, PartInstance
from lara_django_organisms_store.models import OrganismInstance
from lara_django_people.models import Entity, EntityRole, Group, ItemSubsetAbstr, LaraUser
from lara_django_processes.models import MethodInstance, ProcedureInstance, ProcessInstance
from lara_django_samples.models import Sample
from lara_django_substances_store.models import MixtureInstance, PolymerInstance, SubstanceInstance
from mptt.models import MPTTModel, TreeForeignKey

settings.FIXTURES += [
    "1_projects_fix",
]


class Task(models.Model):
    """
    A generic Task class.

    A task are associated with projects, experiments and workpackages.
    They can be used as workpackages or ToDo list items, e.g.
    """

    model_curi = "lara:projects/Tasks"

    task_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    namespace = models.ForeignKey(
        Namespace,
        related_name="%(app_label)s_%(class)s_namespaces_related",
        related_query_name="%(app_label)s_%(class)s_namespaces_related_query",
        on_delete=models.CASCADE,
        help_text="namespace of task",
    )
    name_display = models.TextField(
        blank=True,
        help_text="human readable task title - to be displayed in the web frontend",
    )
    name = models.TextField(blank=True, help_text="name of the task, should not contain whitespaces")
    entities = models.ManyToManyField(
        Entity,
        related_name="%(app_label)s_%(class)s_entities_related",
        related_query_name="%(app_label)s_%(class)s_entities_related_query",
        blank=True,
        help_text="entities with given roles in the task",
        # through="RoledTaskEntities",
    )
    task_base = models.ForeignKey(
        "self",
        related_name="%(app_label)s_%(class)s_task_base_related",
        related_query_name="%(app_label)s_%(class)s_task_base_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="base task - this can be, e.g., used as a template task",
    )
    description = models.TextField(blank=True, help_text="task description")
    datetime_start = models.DateTimeField(
        null=True,
        blank=True,
        help_text="start of task",  # datetime(1968, 12, 31, tzinfo=timezone.utc),
    )
    datetime_added = models.DateTimeField(
        null=True,
        blank=True,  # datetime(1968, 12, 31, tzinfo=timezone.utc),
        help_text="datetime task added to LARA",
    )

    datetime_end = models.DateTimeField(null=True, blank=True, help_text="end of task")
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="date and time when task was last modified"
    )
    priority = models.FloatField(blank=True, null=True, help_text="priority of the task, between 0 and 1")

    status = models.ForeignKey(
        ItemStatus,
        related_name="%(app_label)s_%(class)s_status_related",
        related_query_name="%(app_label)s_%(class)s_status_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="task status classifier: planned, started, in_progess, finished."
        "It also contains a numeric value for quantifying the progress",
    )
    search_vector = SearchVectorField(null=True)

    class Meta:
        indexes = (GinIndex(fields=["search_vector"]),)

    #     abstract = True
    #     constraints = [
    #         models.UniqueConstraint(
    #             fields=["name"], name="%(app_label)s_%(class)s_name_unique"
    #         )
    #     ]
    #     indexes = (GinIndex(fields=["name"]),)
    #     # ordering = ["name_display"]

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


# class RoledTaskEntities(models.Model):
#     """Through model for the many-to-many relationship between Entity and Task.
#     This class can be used
#     to store the current role of an entity in a task"""

#     model_curi = "lara:projects/RoledTaskEntities"

#     roledtaskentities_id = models.UUIDField(
#         primary_key=True, default=uuid.uuid4, editable=False
#     )

#     entity = models.ForeignKey(
#         Entity,
#         related_name="%(app_label)s_%(class)s_task_related_roled_entity",
#         related_query_name="%(app_label)s_%(class)s_task_related_roled_entity_query",
#         on_delete=models.CASCADE,
#         help_text="entity in the task",
#     )

#     task = models.ForeignKey(
#         Task,
#         related_name="%(app_label)s_%(class)s_roled_entity_related_task",
#         related_query_name="%(app_label)s_%(class)s_roled_entity_related_task_query",
#         on_delete=models.CASCADE,
#         help_text="task",
#     )

#     role = models.ForeignKey(
#         EntityRole,
#         related_name="%(app_label)s_%(class)s_task_related_entity_role",
#         related_query_name="%(app_label)s_%(class)s_task_related_entity_role_query",
#         on_delete=models.CASCADE,
#         help_text="current role of an entity in the task",
#     )

#     class Meta:
#         constraints = [
#             models.UniqueConstraint(
#                 fields=["entity", "role", "task"],
#                 name="%(app_label)s_%(class)s_entity_role_unique",
#             ),
#         ]

#     def save(self, *args, **kwargs):
#         """
#         Here we generate some default values for name_full
#         """
#         print("--------- RoledTaskEntities.save")
#         if self.role is None:
#             self.role, created = EntityRole.objects.get_or_create(name="contributor")

#         super().save(*args, **kwargs)


class ProjectAbstr(MPTTModel):
    """
    Abstract project/experiment or work package or TO-DO list class.

    - mind the time when data and evaluations are added: data might be added before an evaluation has been defined and vice versa
    - finding related experiments: just look at children of an exp in tree or exp, that have this as parent
    - some of the fields are only used by experiments,

    Todo:
      - change device to devices

    """

    namespace = models.ForeignKey(
        Namespace,
        related_name="%(app_label)s_%(class)s_namespaces_related",
        related_query_name="%(app_label)s_%(class)s_namespaces_related_query",
        on_delete=models.CASCADE,
        help_text="namespace of project",
    )

    name_display = models.TextField(
        blank=True,
        help_text="human readable project/experiment title - to be displayed in the web frontend",
    )

    # name is obsolete, only name_full is relevant
    name = models.TextField(
        blank=True,
        null=True,
        help_text="name of the project or experiment, should not contain whitespaces",
    )
    version = models.TextField(blank=True, null=True, help_text="version of the project or experiment")

    groups = models.ManyToManyField(
        Group,
        related_name="%(app_label)s_%(class)s_groups_related",
        related_query_name="%(app_label)s_%(class)s_groups_related_query",
        blank=True,
        help_text="groups of this data",
    )
    # PAC-ID:  https://github.com/ApiniLabs/PAC-ID
    pac_id = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.",
    )
    acl = models.JSONField(
        blank=True,
        null=True,
        help_text="access control list - fine grained data access control",
    )
    # -> ltree,  will be modelled with the PostgreSQL ltree https://pypi.org/project/django-ltree/
    # ~ parent = models.ForeignKey('self', null=True, blank=True, related_name="parent_projects" ,on_delete=models.CASCADE,
    # ~ help_text="parent projects" )
    parent = TreeForeignKey(
        "self",
        null=True,
        blank=True,
        related_name="%(app_label)s_%(class)s_experiment_parent_related",
        related_query_name="%(app_label)s_%(class)s_parent_related_query",
        on_delete=models.CASCADE,
        help_text="mptt - parent projects",
    )

    hash_sha256 = models.CharField(max_length=256, blank=True, null=True, help_text="SHA256 experiment hash")

    datetime_start = models.DateTimeField(
        null=True,
        blank=True,
        help_text="start of project / experiment",  # datetime(1968, 12, 31, tzinfo=timezone.utc),
    )
    datetime_added = models.DateTimeField(
        null=True,
        blank=True,  # datetime(1968, 12, 31, tzinfo=timezone.utc),
        help_text="datetime project / experiment added to LARA",
    )
    datetime_end = models.DateTimeField(null=True, blank=True, help_text="end of project / experiment")
    datetime_last_modified = models.DateTimeField(
        null=True,
        blank=True,
        help_text="date and time when project / experiment was last modified",
    )
    priority = models.FloatField(
        blank=True,
        null=True,
        help_text="priority of the project / experiment, between 0 and 1",
    )
    status = models.ForeignKey(
        ItemStatus,
        related_name="%(app_label)s_%(class)s_status_related",
        related_query_name="%(app_label)s_%(class)s_status_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="experiment status classifier: planned, started, in_progess,"
        " finished, it also contains a numeric value for quantifying the progress",
    )

    timeline = models.JSONField(blank=True, null=True, help_text="timeline of the project / experiment")
    milestones = models.JSONField(blank=True, null=True, help_text="milestones of the project / experiment")

    tasks = models.ManyToManyField(
        Task,
        related_name="%(app_label)s_%(class)s_tasks_related",
        related_query_name="%(app_label)s_%(class)s_tasks_related_query",
        blank=True,
        help_text="tasks of this project or experiment",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        blank=True,
        help_text="project / experiment tags, for easier identification",
    )
    # please define a standardised scheme, best linkML based.
    # defined-context: context defined by a user
    # inferred-context: context inferred by the AI
    # context = models.JSONField(
    #     blank=True, null=True, help_text="context information for the project / experiment to provide, e.g., AI more information"
    # )
    description = models.TextField(blank=True, null=True, help_text="project / experiment description")
    hypothesis_json = models.JSONField(
        blank=True,
        null=True,
        help_text="hypothesis in machine understandable JSON-LD format.",
    )
    hypothesis = models.TextField(
        blank=True,
        null=True,
        help_text="human readable hypothesis of the experiment / project",
    )
    objectives_json = models.JSONField(
        blank=True,
        null=True,
        help_text="objectives and goals in machine understandable JSON-LD format.",
    )
    risks_json = models.JSONField(
        blank=True,
        null=True,
        help_text="risks in machine understandable JSON-LD format.",
    )
    budget = models.JSONField(
        blank=True,
        null=True,
        help_text="budget/costs/actual costs of the project / experiment in JSON-LD format",
    )
    results_json = models.JSONField(
        blank=True,
        null=True,
        help_text="results in machine understandable JSON-LD format.",
    )
    outcome = models.ForeignKey(
        ItemStatus,
        related_name="%(app_label)s_%(class)s_outcome_related",
        related_query_name="%(app_label)s_%(class)s_outcome_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="project / experiment outcome classifier, e.g., preliminary, statistically_confirmed",
    )
    remarks = models.TextField(blank=True, null=True, help_text="remarks to the project / experiment")
    color = models.TextField(
        blank=True,
        null=True,
        help_text="GUI colour representation of the project/experiment, can be used in calendars, or gui elements like frames.",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    pid = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="Persitent Identifier [PID/handle URI](https://www.handle.net/)",
    )

    search_vector = SearchVectorField(null=True)

    class Meta:  # noqa: D106
        abstract = True
        constraints = (
            models.UniqueConstraint(
                fields=["name", "namespace", "version"],
                name="%(app_label)s_%(class)s_namespace_name_version_unique",
            ),
        )
        indexes = (GinIndex(fields=["search_vector"]),)
        # ordering = ["name_display"]

    def __str__(self):  # noqa: D105
        return self.name or ""

    def __repr__(self):  # noqa: D105
        return self.name or ""

    # this feature needs to be used with care (if necessary)
    # ~ class MPTTMeta:
    # ~ order_insertion_by = ['name_display']

    # ~ @my_date.setter
    # ~ def my_date(self, value):
    # ~ if value > datetime.date.today():
    # ~ logger.warning("The date chosen was in the future.")
    # ~ self._my_date = value
    # ~ class Meta:
    # ~ db_table = "lara_projects"


class Project(ProjectAbstr):
    """
    A project with its underlying experiments.

    Project information is designed to be lean. All data and evaluations related information is stored in the experiments.
    A project can have many subprojects which uses the MPTTModel to build a tree structure.
    A project can have many experiments which are stored in the experiments field.
    """

    model_curi = "lara:projects/Project"
    # consider using uuid(project_name)
    project_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    entities = models.ManyToManyField(
        Entity,
        related_name="%(app_label)s_%(class)s_project_related_roled_entities",
        related_query_name="%(app_label)s_%(class)s_project_related_roled_entities_query",
        blank=True,
        help_text="entities with given roles in the project",
        through="RoledProjectEntities",
    )
    project_base = models.ForeignKey(
        "self",
        related_name="%(app_label)s_%(class)s_project_base_related",
        related_query_name="%(app_label)s_%(class)s_project_base_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="base project - this can be, e.g., used as a template project",
    )
    experiments = models.ManyToManyField(
        "Experiment",
        related_name="%(app_label)s_%(class)s_experiments_related",
        related_query_name="%(app_label)s_%(class)s_experiments_related_query",
        blank=True,
        help_text="link to all experiments of a project",
    )
    data = models.ManyToManyField(
        Data,
        related_name="%(app_label)s_%(class)s_data_related",
        related_query_name="%(app_label)s_%(class)s_data_related_query",
        blank=True,
        help_text="data of this project",
    )
    evaluations = models.ManyToManyField(
        Evaluation,
        related_name="%(app_label)s_%(class)s_evaluation_related",
        related_query_name="%(app_label)s_%(class)s_evaluation_related_query",
        blank=True,
        help_text="evaluations of this project",
    )

    def save(self, *args, **kwargs):
        """Here we generate some default values for name_full."""
        if self.project_base is not None:
            # iterate over all fields and use them as default values for new project
            for field in self.project_base._meta.fields:
                try:
                    if field.name != "project_id" or getattr(self, field.name) is None:
                        setattr(self, field.name, getattr(self.project_base, field.name))
                except AttributeError:
                    pass

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.name is None or self.name == "":
            self.name = self.name_display.strip().replace(" ", "_").lower()

        if not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}projects/Projects/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        if self.datetime_start is None:
            self.datetime_start = timezone.now()

        if self.datetime_end is None:
            self.datetime_end = datetime.datetime(2060, 12, 31, tzinfo=datetime.timezone.utc)

        if self.status is None:
            self.status = ItemStatus.objects.get(status="planned")

        if self.datetime_added is None:
            self.datetime_added = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class RoledProjectEntities(models.Model):
    """Through model for the many-to-many relationship between Entity and Project.
    This class can be used to store the current role of an entity in a project"""

    model_curi = "lara:projects/RoledProjectEntities"

    roledprojectentities_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    entity = models.ForeignKey(
        Entity,
        related_name="%(app_label)s_%(class)s_roled_entity_project_related_entity",
        related_query_name="%(app_label)s_%(class)s_roled_entity_project_related_entity_query",
        on_delete=models.CASCADE,
        help_text="entity in the project",
    )

    project = models.ForeignKey(
        Project,
        related_name="%(app_label)s_%(class)s_roled_entities_related_projects",
        related_query_name="%(app_label)s_%(class)s_roled_entity_related_project_query",
        on_delete=models.CASCADE,
        help_text="project",
    )

    role = models.ForeignKey(
        EntityRole,
        related_name="%(app_label)s_%(class)s_project_related_role",
        related_query_name="%(app_label)s_%(class)s_project_related_role_query",
        on_delete=models.CASCADE,
        help_text="current role of an entity in the project",
        null=True,
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["entity", "role", "project"],
                name="%(app_label)s_%(class)s_entity_role_unique",
            ),
        ]

    def save(self, *args, **kwargs):
        """Here we generate some default values for name_full."""
        print("--------- RoledProjectEntities.save")
        if self.role is None:
            self.role, created = EntityRole.objects.get_or_create(name="contributor")

        super().save(*args, **kwargs)


class ProjectsSubset(ItemSubsetAbstr):
    """User or group defined selection of projects"""

    model_curi = "lara:projects/ProjectsSubset"

    projectselection_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    projects = models.ManyToManyField(
        Project,
        related_name="%(app_label)s_%(class)s_projects_related",
        related_query_name="%(app_label)s_%(class)s_projects_related_query",
        blank=True,
        help_text="User or group selected projects",
        through="OrderedProjectsSubset",
    )


class OrderedProjectsSubset(models.Model):
    """Through model for the many-to-many relationship between ProjectsSubset and Project.
    This class can be used to store the order of projects in a subset"""

    model_curi = "lara:projects/OrderedProjectsSubset"

    orderedprojectssubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    project = models.ForeignKey(
        Project,
        related_name="%(app_label)s_%(class)s_project_related",
        related_query_name="%(app_label)s_%(class)s_project",
        on_delete=models.CASCADE,
        help_text="project in the subset",
    )

    projects_subset = models.ForeignKey(
        ProjectsSubset,
        related_name="%(app_label)s_%(class)s_projectssubset_related",
        related_query_name="%(app_label)s_%(class)s_projectssubset",
        on_delete=models.CASCADE,
        help_text="subset of projects",
    )

    order = models.IntegerField(help_text="order of project in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["project", "projects_subset"],
                name="%(app_label)s_%(class)s_project_projectssubset_unique",
            ),
        ]
        ordering = ("order",)


class Experiment(ProjectAbstr):
    """this class stores all details of an LARA experiment
    - mind the time when data and evaluations are added: data might be added before an evaluation has been defined and vice versa
      finding related experiments: just look at children of an exp in tree or exp, that have this as parent
      some of the fields are only used by experiments.
      An experiment can have many sub-experiments which uses the MPTTModel to build a tree structure.
    """

    model_curi = "lara:projects/Experiment"

    experiment_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    entities = models.ManyToManyField(
        Entity,
        related_name="%(app_label)s_%(class)s_experiment_related_roled_entities",
        related_query_name="%(app_label)s_%(class)s_experiment_related_roled_entities_query",
        blank=True,
        help_text="entities with given roles in the experiment",
        through="RoledExperimentEntities",
    )

    experiment_design = models.ForeignKey(
        ProcessInstance,
        related_name="%(app_label)s_%(class)s_experiment_designs_related",
        related_query_name="%(app_label)s_%(class)s_experiment_designs_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="process/procedure describing the experimental design, e.g. via machine learning or doi",
    )
    experiment_base = models.ForeignKey(
        "self",
        related_name="%(app_label)s_%(class)s_experiment_base_related",
        related_query_name="%(app_label)s_%(class)s_experiment_base_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="base experiment - this can be, e.g., used as a template experiment",
    )
    data = models.ManyToManyField(
        Data,
        related_name="%(app_label)s_%(class)s_data_related",
        related_query_name="%(app_label)s_%(class)s_data_related_query",
        blank=True,
        help_text="link to all data of this experiment",
    )
    evaluations = models.ManyToManyField(
        Evaluation,
        related_name="%(app_label)s_%(class)s_evaluation_related",
        related_query_name="%(app_label)s_%(class)s_evaluation_related_query",
        blank=True,
        help_text="all evaluations of this experiment",
    )
    method_instances = models.ManyToManyField(
        MethodInstance,
        blank=True,
        related_name="%(app_label)s_%(class)s_methods_related",
        related_query_name="%(app_label)s_%(class)s_methods_related_query",
        help_text="method for measuring, should be replaced by lara_process.method",
    )
    process_instances = models.ManyToManyField(
        ProcessInstance,
        blank=True,
        related_name="%(app_label)s_%(class)s_process_related",
        related_query_name="%(app_label)s_%(class)s_process_related_query",
        help_text="process",
    )
    procedure_instances = models.ManyToManyField(
        ProcedureInstance,
        blank=True,
        related_name="%(app_label)s_%(class)s_procedure_related",
        related_query_name="%(app_label)s_%(class)s_procedure_related_query",
        help_text="procedure",
    )

    substance_instances = models.ManyToManyField(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substance_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        blank=True,
        help_text="substances used in experiment",
    )

    polymer_instances = models.ManyToManyField(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_related",
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        blank=True,
        help_text="polymers used in experiment",
    )

    mixture_instances = models.ManyToManyField(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixtures_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_related_query",
        blank=True,
        help_text="mixtures used in experiment",
    )

    organism_instances = models.ManyToManyField(
        OrganismInstance,
        related_name="%(app_label)s_%(class)s_organisms_related",
        related_query_name="%(app_label)s_%(class)s_organisms_related_query",
        blank=True,
        help_text="organisms used in experiment",
    )
    part_instances = models.ManyToManyField(
        PartInstance,
        related_name="%(app_label)s_%(class)s_parts_related",
        related_query_name="%(app_label)s_%(class)s_parts_related_query",
        blank=True,
        help_text="parts used in experiment",
    )
    device_instances = models.ManyToManyField(
        DeviceInstance,
        related_name="%(app_label)s_%(class)s_devices_related",
        related_query_name="%(app_label)s_%(class)s_devices_related_query",
        blank=True,
        help_text="devices used in experiment",
    )
    device_setup_instances = models.ManyToManyField(
        DeviceSetupInstance,
        related_name="%(app_label)s_%(class)s_device_setups_related",
        related_query_name="%(app_label)s_%(class)s_device_setups_related_query",
        blank=True,
        help_text="device setups used in experiment",
    )

    labware_instances = models.ManyToManyField(
        LabwareInstance,
        related_name="%(app_label)s_%(class)s_labware_related",
        related_query_name="%(app_label)s_%(class)s_labware_related_query",
        blank=True,
        help_text="labware used in experiment",
    )
    samples = models.ManyToManyField(
        Sample,
        related_name="%(app_label)s_%(class)s_samples_related",
        related_query_name="%(app_label)s_%(class)s_samples_related_query",
        blank=True,
        help_text="samples used in experiment",
    )
    parameters = models.JSONField(
        blank=True,
        null=True,
        help_text="experimental parameters in JSON format, experimental parameters, like temperature, pH, recommended format: SciDat",
    )
    # only one ref experiment ?
    reference_experiment = models.ForeignKey(
        "self",
        related_name="%(app_label)s_%(class)s_reference_experiment_related",
        related_query_name="%(app_label)s_%(class)s_reference_experiment_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="pointer to experiment with reference data",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        blank=True,
        help_text="experiment tags, for easier identification",
    )
    observations = models.TextField(
        blank=True,
        null=True,
        help_text="human readable observations during the experiment",
    )
    observations_json = models.JSONField(
        blank=True,
        null=True,
        help_text="observations in machine understandable JSON-LD format.",
    )

    def save(self, *args, **kwargs):
        """Here we generate some default values for name_full."""
        if self.experiment_base is not None:
            # iterate over all fields and use them as default values for new experiment
            for field in self.experiment_base._meta.fields:
                try:
                    if field.name != "experiment_id" or getattr(self, field.name) is None:
                        setattr(self, field.name, getattr(self.experiment_base, field.name))
                except AttributeError:
                    pass

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.name is None or self.name == "":
            self.name = self.name_display.strip().replace(" ", "_").lower()

        if not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}projects/Experiments/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class RoledExperimentEntities(models.Model):
    """Through model for the many-to-many relationship between Entity and Experiment.
    This class can be used to store the current role of an entity in an experiment"""

    model_curi = "lara:projects/RoledExperimentEntities"

    roledexperimententities_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    entity = models.ForeignKey(
        Entity,
        related_name="%(app_label)s_%(class)s_experiment_related_roled_entity",
        related_query_name="%(app_label)s_%(class)s_experiment_related_roled_entity_query",
        on_delete=models.CASCADE,
        help_text="entity in the experiment",
    )

    experiment = models.ForeignKey(
        Experiment,
        related_name="%(app_label)s_%(class)s_roled_entity_related_experiment",
        related_query_name="%(app_label)s_%(class)s_roled_entity_related_experiment_query",
        on_delete=models.CASCADE,
        help_text="experiment",
    )

    role = models.ForeignKey(
        EntityRole,
        related_name="%(app_label)s_%(class)s_experiment_related_entity_role",
        related_query_name="%(app_label)s_%(class)s_experiment_related_entity_role_query",
        on_delete=models.CASCADE,
        help_text="current role of an entity in the experiment",
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["entity", "role", "experiment"],
                name="%(app_label)s_%(class)s_entity_role_unique",
            ),
        ]

    def save(self, *args, **kwargs):
        """Here we generate some default values for name_full."""
        # if self.role is None:
        #     self.role, created = EntityRole.objects.get_or_create(
        #         name="contributor", defaults={"description": "Contributor of a project or experiment"}
        #     )

        super().save(*args, **kwargs)


class ExperimentsSubset(ItemSubsetAbstr):
    """User or group defined selection of experiments"""

    model_curi = "lara:projects/ExperimentsSubset"

    experimentselection_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    experiments = models.ManyToManyField(
        Experiment,
        related_name="%(app_label)s_%(class)s_experiments_related",
        related_query_name="%(app_label)s_%(class)s_experiments_related_query",
        blank=True,
        help_text="User or group selected experiments",
        through="OrderedExperimentsSubset",
    )


class OrderedExperimentsSubset(models.Model):
    """Through model for the many-to-many relationship between ExperimentsSubset and Experiment.
    This class can be used to store the order of experiments in a subset"""

    model_curi = "lara:projects/OrderedExperimentsSubset"

    orderedexperimentssubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    experiment = models.ForeignKey(
        Experiment,
        related_name="%(app_label)s_%(class)s_experiment_related",
        related_query_name="%(app_label)s_%(class)s_experiment",
        on_delete=models.CASCADE,
        help_text="experiment in the subset",
    )

    experiments_subset = models.ForeignKey(
        ExperimentsSubset,
        related_name="%(app_label)s_%(class)s_experimentssubset_related",
        related_query_name="%(app_label)s_%(class)s_experimentssubset",
        on_delete=models.CASCADE,
        help_text="subset of experiments",
    )

    order = models.IntegerField(help_text="order of experiment in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["experiment", "experiments_subset"],
                name="%(app_label)s_%(class)s_experiment_experimentssubset_unique",
            ),
        ]
        ordering = ("order",)


# ____________ calendars / planning _________


class ProjectCalendar(CalendarAbstr):
    """Project Calendar"""

    model_curi = "lara:projects/ProjectCalendar"
    projectcalendar_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        LaraUser,
        related_name="%(app_label)s_%(class)s_user_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="LARA User, who created the calendar entry",
    )
    attendees = models.ManyToManyField(
        LaraUser,
        related_name="%(app_label)s_%(class)s_attendees_related",
        related_query_name="%(app_label)s_%(class)s_attendees_related_query",
        blank=True,
        help_text="attendees of the meeting",
    )
    project = models.ForeignKey(
        Project,
        related_name="%(app_label)s_%(class)s_device_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="project to be scheduled",
    )

    # adding dates / metadata/ ... attendees upon save (from project)
    def __str__(self):
        return self.name_display or ""

    def __repr__(self) -> str:
        return self.name_display or ""


class ExperimentCalendar(CalendarAbstr):
    """Experiment Calendar"""

    model_curi = "lara:projects/ExperimentCalendar"
    experimentcalendar_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        LaraUser,
        related_name="%(app_label)s_%(class)s_user_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="LARA User, who created the calendar entry",
    )
    attendees = models.ManyToManyField(
        LaraUser,
        related_name="%(app_label)s_%(class)s_attendees_related",
        related_query_name="%(app_label)s_%(class)s_attendees_related_query",
        blank=True,
        help_text="attendees of the meeting",
    )
    experiment = models.ForeignKey(
        Experiment,
        related_name="%(app_label)s_%(class)s_experiment_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="experiment to be scheduled",
    )

    # adding dates / metadata/ ... attendees upon save (from project)

    def __str__(self):
        return self.name_display or ""

    def __repr__(self) -> str:
        return self.name_display or ""


# __________ Exchange / Synchronisation _______


class ProjectSynchronisation(SynchronisationAbstr):
    """Synchronisation settings for (recursive) LARA projects synchronisation with other LARA systems

    :param models: _description_
    :type models: _type_
    """

    model_curi = "lara:projects/ProjectSynchronisation"

    projects = models.ManyToManyField(
        Project,
        related_name="%(app_label)s_%(class)s_projects_related",
        related_query_name="%(app_label)s_%(class)s_projects_related_query",
        blank=True,
        help_text="projects",
    )


class ProjectSyncStatus(SyncStatusAbstr):
    """Synchronisation status for (recursive) LARA projects synchronisation with other LARA systems"""

    model_curi = "lara:projects/ProjectSyncStatus"
    projects = models.ManyToManyField(
        Project,
        related_name="%(app_label)s_%(class)s_projects_related",
        related_query_name="%(app_label)s_%(class)s_projects_related_query",
        blank=True,
        help_text="projects",
    )

    class Meta:
        verbose_name_plural = "ProjectSyncStatus"
        verbose_name = "ProjectSyncStatus"
        # ordering = ['datetime_start']
        get_latest_by = "datetime_start"
        # indexes = [
        #     models.Index(fields=['datetime_start', 'datetime_end']),
        #     models.Index(fields=['datetime_start', 'status']),
        #     models.Index(fields=['datetime_start', 'status', 'datetime_end']),
        # ]
