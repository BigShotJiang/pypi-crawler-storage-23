"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects tests *

:details: lara_django_projects application models tests.
         - 
:authors: mark doerr  <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django.test import TestCase

# from lara_django_projects.models import

# Create your lara_django_projects tests here.
