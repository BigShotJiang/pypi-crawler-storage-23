"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects admin *

:details: lara_django_projects admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_projects > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

import tempfile
from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting
from django.urls import reverse_lazy as rev
from django.utils import timezone

from .models import Experiment
from .models import ExperimentCalendar
from .models import ExperimentsSubset
from .models import Project
from .models import ProjectCalendar
from .models import ProjectsSubset
from .models import ProjectSynchronisation
from .tasks import send_review_email_task


class CustomFormRenderer(TemplatesSetting):
    """Custom renderer using the projects-specific field group template."""

    field_template_name = "lara_django_projects/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""

    template_name = "lara_django_projects/widgets/searchable_select_multiple.html"

    def __init__(self, attrs=None):
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


class ExperimentCreateForm(forms.ModelForm):
    """Form for creating a new experiment with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Experiment
        fields = (
            "namespace",
            "name_display",
            "name",
            "entities",
            "groups",
            "acl",
            "parent",
            "experiment_design",
            "hash_sha256",
            "datetime_start",
            "datetime_added",
            "status",
            "method_instances",
            "process_instances",
            "procedure_instances",
            "substance_instances",
            "polymer_instances",
            "mixture_instances",
            "outcome",
            "parameters",
            "reference_experiment",
            "resources_external",
            "observations",
            "description",
            "remarks",
            "iri",
            "pid",
        )

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "observations",
            "description",
            "remarks",
            "acl",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_added",
        )

        url_fields: ClassVar = ("iri", "pid")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parent": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "experiment_design": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "reference_experiment": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "outcome": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entities": SearchableSelectMultiple(),
            "groups": SearchableSelectMultiple(),
            "method_instances": SearchableSelectMultiple(),
            "process_instances": SearchableSelectMultiple(),
            "procedure_instances": SearchableSelectMultiple(),
            "substance_instances": SearchableSelectMultiple(),
            "polymer_instances": SearchableSelectMultiple(),
            "mixture_instances": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
        }


class ExperimentUpdateForm(forms.ModelForm):
    class Meta:
        model = Experiment
        fields = (
            "namespace",
            "name_display",
            "name",
            "entities",
            "groups",
            "acl",
            "parent",
            "experiment_design",
            "hash_sha256",
            "datetime_start",
            "datetime_added",
            "status",
            "method_instances",
            "process_instances",
            "procedure_instances",
            "substance_instances",
            "polymer_instances",
            "mixture_instances",
            "outcome",
            "parameters",
            "reference_experiment",
            "resources_external",
            "observations",
            "description",
            "remarks",
            "iri",
            "pid",
        )
        widgets = {
            "name_display": forms.TextInput(attrs={"Title": "Name", "required": True}),
            "name": forms.TextInput(attrs={"placeholder": "Name", "required": False}),
            "uri": forms.URLInput(attrs={"placeholder": "uri", "required": False}),
            "version": forms.TextInput(attrs={"placeholder": "Version", "required": False}),
            "datetime_start": forms.DateTimeInput(
                attrs={"placeholder": timezone.now().strftime("%Y-%m-%d %H:%M:%S"), "required": False}
            ),
            "datetime_added": forms.DateTimeInput(
                attrs={"placeholder": timezone.now().strftime("%Y-%m-%d %H:%M:%S"), "required": False}
            ),
            "datetime_end": forms.DateTimeInput(
                attrs={"placeholder": timezone.now().strftime("%Y-%m-%d %H:%M:%S"), "required": False}
            ),
            "entities": forms.SelectMultiple(attrs={"placeholder": "entities", "required": False}),
            "groups": forms.SelectMultiple(attrs={"placeholder": "Groups", "required": False}),
            "method_instances": forms.SelectMultiple(attrs={"placeholder": "Methods", "required": False}),
            "process_instances": forms.SelectMultiple(attrs={"placeholder": "Processes", "required": False}),
            "procedure_instances": forms.SelectMultiple(attrs={"placeholder": "Processes", "required": False}),
        }


class ProjectsAddForm(forms.Form):
    """Form for adding projects via file upload or manual entry."""

    default_renderer: ClassVar = CustomFormRenderer()

    project_list = forms.FileField(
        required=False,
        widget=forms.FileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        help_text="Upload a file containing project data.",
    )
    manual = forms.CharField(
        required=False,
        widget=forms.Textarea(
            attrs={
                "class": "textarea textarea-sm textarea-bordered w-full",
                "rows": 3,
            }
        ),
        help_text="Manually enter project information.",
    )


class ProjectCreateForm(forms.ModelForm):
    """Form for creating a new project with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Project
        fields = (
            "namespace",
            "name_display",
            "name",
            "parent",
            "entities",
            "groups",
            "experiments",
            "datetime_start",
            "datetime_added",
            "datetime_end",
            "status",
            "outcome",
            "resources_external",
            "description",
            "remarks",
            "hash_sha256",
            "iri",
            "pid",
            "acl",
        )

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "description",
            "remarks",
            "acl",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_added",
            "datetime_end",
        )

        url_fields: ClassVar = ("iri", "pid")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parent": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "outcome": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entities": SearchableSelectMultiple(),
            "groups": SearchableSelectMultiple(),
            "experiments": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
        }


class ProjectUpdateForm(forms.ModelForm):
    """Form for updating an existing project with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Project
        fields = (
            "namespace",
            "name_display",
            "name",
            "parent",
            "entities",
            "groups",
            "experiments",
            "datetime_start",
            "datetime_added",
            "datetime_end",
            "status",
            "outcome",
            "resources_external",
            "description",
            "remarks",
            "hash_sha256",
            "iri",
            "pid",
            "acl",
        )

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = (
            "name",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "description",
            "remarks",
            "acl",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_added",
            "datetime_end",
        )

        url_fields: ClassVar = ("iri", "pid")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parent": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "status": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "outcome": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "entities": SearchableSelectMultiple(),
            "groups": SearchableSelectMultiple(),
            "experiments": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
        }


class ExperimentsSubsetCreateForm(forms.ModelForm):
    """Form for creating a new experiments subset."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExperimentsSubset
        fields = ("name",)
        exclude = ("entity", "group")

        text_fields: ClassVar = ("name",)

        widgets: ClassVar = {
            "name": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}),
        }


class ExperimentsSubsetUpdateForm(forms.ModelForm):
    """Form for updating an experiments subset."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExperimentsSubset
        fields = ("name",)
        exclude = ("entity", "group")

        text_fields: ClassVar = ("name",)

        widgets: ClassVar = {
            "name": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}),
        }


class ProjSelectionCreateForm(forms.ModelForm):
    """Form for creating a new projects subset."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectsSubset
        fields = ("name",)
        exclude = ("entity", "group")

        text_fields: ClassVar = ("name",)

        widgets: ClassVar = {
            "name": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}),
        }


class ProjSelectionUpdateForm(forms.ModelForm):
    """Form for updating a projects subset."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectsSubset
        fields = ("name",)
        exclude = ("entity", "group")

        text_fields: ClassVar = ("name",)

        widgets: ClassVar = {
            "name": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}),
        }


class ProjectCalendarCreateForm(forms.ModelForm):
    """Form for creating a new project calendar event."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectCalendar
        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "datetime_last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "project",
        )

        text_fields: ClassVar = (
            "name_display",
            "summary",
            "color",
            "location",
            "role",
            "tzid",
        )

        textarea_fields: ClassVar = (
            "description",
            "ics",
            "alarm_repeat_json",
            "event_repeat_json",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
            "created",
            "datetime_last_modified",
            "timestamp",
        )

        url_fields: ClassVar = ("calendar_url", "conference_url", "geolocation")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "duration": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "offset_utc": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "all_day": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "user": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "project": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "range": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "related": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class ProjectCalendarUpdateForm(forms.ModelForm):
    """Form for updating a project calendar event."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectCalendar
        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "datetime_last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "project",
        )

        text_fields: ClassVar = (
            "name_display",
            "summary",
            "color",
            "location",
            "role",
            "tzid",
        )

        textarea_fields: ClassVar = (
            "description",
            "ics",
            "alarm_repeat_json",
            "event_repeat_json",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
            "created",
            "datetime_last_modified",
            "timestamp",
        )

        url_fields: ClassVar = ("calendar_url", "conference_url", "geolocation")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "duration": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "offset_utc": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "all_day": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "user": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "project": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "range": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "related": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class ExperimentCalendarCreateForm(forms.ModelForm):
    """Form for creating a new experiment calendar event."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExperimentCalendar
        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "datetime_last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "experiment",
        )

        text_fields: ClassVar = (
            "name_display",
            "summary",
            "color",
            "location",
            "role",
            "tzid",
        )

        textarea_fields: ClassVar = (
            "description",
            "ics",
            "alarm_repeat_json",
            "event_repeat_json",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
            "created",
            "datetime_last_modified",
            "timestamp",
        )

        url_fields: ClassVar = ("calendar_url", "conference_url", "geolocation")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "duration": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "offset_utc": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "all_day": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "user": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "experiment": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "range": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "related": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class ExperimentCalendarUpdateForm(forms.ModelForm):
    """Form for updating an experiment calendar event."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExperimentCalendar
        fields = (
            "name_display",
            "calendar_url",
            "summary",
            "description",
            "color",
            "ics",
            "datetime_start",
            "datetime_end",
            "duration",
            "all_day",
            "created",
            "datetime_last_modified",
            "timestamp",
            "location",
            "geolocation",
            "conference_url",
            "range",
            "related",
            "role",
            "tzid",
            "offset_utc",
            "alarm_repeat_json",
            "event_repeat",
            "event_repeat_json",
            "user",
            "experiment",
        )

        text_fields: ClassVar = (
            "name_display",
            "summary",
            "color",
            "location",
            "role",
            "tzid",
        )

        textarea_fields: ClassVar = (
            "description",
            "ics",
            "alarm_repeat_json",
            "event_repeat_json",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
            "created",
            "datetime_last_modified",
            "timestamp",
        )

        url_fields: ClassVar = ("calendar_url", "conference_url", "geolocation")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "duration": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "offset_utc": forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"}),
            "all_day": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
            "user": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "experiment": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "range": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "related": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class ProjectSynchronisationCreateForm(forms.ModelForm):
    """Form for creating a new project synchronisation."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectSynchronisation
        fields = (
            "name",
            "datetime_start",
            "datetime_end",
            "event_repeat",
            "event_repeat_json",
            "logs",
            "description",
        )

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = (
            "event_repeat_json",
            "logs",
            "description",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
        }


class ProjectSynchronisationUpdateForm(forms.ModelForm):
    """Form for updating a project synchronisation."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ProjectSynchronisation
        fields = (
            "name",
            "datetime_start",
            "datetime_end",
            "event_repeat",
            "event_repeat_json",
            "logs",
            "description",
        )

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = (
            "event_repeat_json",
            "logs",
            "description",
        )

        datetime_fields: ClassVar = (
            "datetime_start",
            "datetime_end",
        )

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"})
                for field in datetime_fields
            },
            "event_repeat": forms.CheckboxInput(attrs={"class": "checkbox"}),
        }


# from .forms import ExperimentCreateForm, ProjectCreateForm, ExperimentsSubsetCreateForm, ProjSelectionCreateForm, ProjectCalendarCreateForm, ExperimentCalendarCreateForm, OutputTemplateCreateForm, ReportCreateForm, ProjectSynchronisationCreateFormExperimentUpdateForm, ProjectUpdateForm, ExperimentsSubsetUpdateForm, ProjSelectionUpdateForm, ProjectCalendarUpdateForm, ExperimentCalendarUpdateForm, OutputTemplateUpdateForm, ReportUpdateForm, ProjectSynchronisationUpdateForm


class ReviewForm(forms.Form):
    name = forms.CharField(
        label="Your name",
        min_length=4,
        max_length=100,
        widget=forms.TextInput(attrs={"class": "form-control mb-3", "placeholder": "Your name", "id": "form-name"}),
    )
    email = forms.EmailField(
        label="Your email",
        max_length=200,
        widget=forms.EmailInput(attrs={"class": "form-control mb-3", "placeholder": "Your email", "id": "form-email"}),
    )
    review = forms.CharField(
        label="Review",
        max_length=2000,
        widget=forms.Textarea(
            attrs={"class": "form-control", "placeholder": "Your review", "rows": 5, "id": "form-review"}
        ),
    )

    def send_email(self):
        # send email using celery
        send_review_email_task.delay(self.cleaned_data["name"], self.cleaned_data["email"], self.cleaned_data["review"])
