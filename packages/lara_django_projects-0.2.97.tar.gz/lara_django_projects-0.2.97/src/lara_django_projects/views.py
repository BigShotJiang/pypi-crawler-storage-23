"""
Views for lara_django_projects.

All views use the ``HtmxResponseMixin`` from *lara_django_base* so that
htmx sidebar/navbar clicks receive a bare partial while direct browser
navigation gets the partial auto-wrapped in ``lara_base.html``.
"""

import logging
from dataclasses import dataclass, field

from django.core.paginator import Paginator
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.template.loader import render_to_string
from django.urls import reverse_lazy as rev
from django.utils.safestring import mark_safe
from django.views.generic import CreateView, DeleteView, DetailView, FormView, ListView, UpdateView
from django_tables2 import SingleTableView
from lara_django_base.views_mixins import HtmxResponseMixin
from lara_django_data.models import Data
from lara_django_material_store.models import DeviceInstance
from lara_django_substances_store.models import SubstanceInstance

from .apps import LaraDjangoProjectsConfig
from .filters import ProjectDjFilter
from .forms import (
    ExperimentCreateForm,
    ExperimentsSubsetCreateForm,
    ExperimentsSubsetUpdateForm,
    ExperimentUpdateForm,
    ProjectCreateForm,
    ProjectsAddForm,
    ProjectUpdateForm,
    ProjSelectionCreateForm,
    ProjSelectionUpdateForm,
    ReviewForm,
)
from .models import Experiment, ExperimentsSubset, Project, ProjectsSubset
from .tables import ExperimentTable, ProjectTable

# ---------------------------------------------------------------------------
# Menu / sidebar dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ProjectMenu:
    """Project menu for navigation."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Projects Overview", "path": "lara_django_projects:projects-overview"},
            {"name": "Projects Table", "path": "lara_django_projects:project-list"},
            {"name": "Experiments", "path": "lara_django_projects:experiment-list"},
        ]
    )


@dataclass
class SidebarMenu:
    """Sidebar navigation items for project views."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-500"},
            {"name": "Dashboard", "path": "/dashboard/", "icon": "dashboard", "hover_class": "hover:bg-gray-500"},
            {"name": "Apps", "path": "/apps/", "icon": "apps", "hover_class": "hover:bg-gray-500"},
            {"name": "Projects", "path": "/projects/", "icon": "projects", "hover_class": "hover:bg-red-500"},
            {"name": "Processes", "path": "/processes/", "icon": "processes", "hover_class": "hover:bg-orange-500"},
            {"name": "Data", "path": "/data/", "icon": "data", "hover_class": "hover:bg-sky-500"},
            {
                "name": "Devices",
                "path": "/material/device/list/",
                "icon": "devices",
                "hover_class": "hover:bg-amber-500",
            },
            {
                "name": "Parts",
                "path": "/material/part/list/",
                "icon": "parts",
                "hover_class": "hover:bg-amber-500",
            },
            {
                "name": "Labware",
                "path": "/material/labware/list/",
                "icon": "labware",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Substances", "path": "/substances/", "icon": "substances", "hover_class": "hover:bg-teal-500"},
            {"name": "Organisms", "path": "/organisms/", "icon": "organisms", "hover_class": "hover:bg-lime-500"},
            {"name": "People", "path": "/people/", "icon": "people", "hover_class": "hover:bg-blue-500"},
        ]
    )


@dataclass
class ExperimentsSidebarMenu:
    """Sidebar navigation items with experiment-specific paths."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-500"},
            {"name": "Dashboard", "path": "/dashboard/", "icon": "dashboard", "hover_class": "hover:bg-gray-500"},
            {"name": "Apps", "path": "/apps/", "icon": "apps", "hover_class": "hover:bg-gray-500"},
            {"name": "Samples", "path": "/samples/", "icon": "samples", "hover_class": "hover:bg-yellow-500"},
            {"name": "Processes", "path": "/processes/", "icon": "processes", "hover_class": "hover:bg-orange-500"},
            {"name": "Data", "path": "/data/", "icon": "data", "hover_class": "hover:bg-sky-500"},
            {
                "name": "Devices",
                "path": "/material/device/list/",
                "icon": "devices",
                "hover_class": "hover:bg-amber-500",
            },
            {
                "name": "Parts",
                "path": "/material/part/list/",
                "icon": "parts",
                "hover_class": "hover:bg-amber-500",
            },
            {
                "name": "Labware",
                "path": "/material/labware/list/",
                "icon": "labware",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Substances", "path": "/substances/", "icon": "substances", "hover_class": "hover:bg-teal-500"},
            {"name": "Organisms", "path": "/organisms/", "icon": "organisms", "hover_class": "hover:bg-lime-500"},
            {"name": "People", "path": "/people/", "icon": "people", "hover_class": "hover:bg-blue-500"},
        ]
    )

    def update_paths(self, path_map: dict) -> "ExperimentsSidebarMenu":
        """Update 'path' of menu_items based on *path_map* (name -> new path)."""
        for item in self.menu_items:
            if item["name"] in path_map:
                item["path"] = path_map[item["name"]]
        return self


@dataclass
class BreadcrumbMenu:
    """Breadcrumb navigation items."""

    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-100 text-underline"},
            {
                "name": "Project1",
                "path": "/projects/",
                "icon": "folder",
                "hover_class": "hover:bg-gray-100 text-underline",
            },
        ]
    )

    def update_paths(self, path_map: dict) -> "BreadcrumbMenu":
        """Update 'path' of menu_items based on *path_map* (name -> new path)."""
        for item in self.menu_items:
            if item["name"] in path_map:
                item["path"] = path_map[item["name"]]
        return self


# ---------------------------------------------------------------------------
# Shared context mixin
# ---------------------------------------------------------------------------


class ProjectsTemplateSettingsMixin:
    """Provide common context for every project view (menus, app colour, etc.)."""

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        projects = Project.objects.exclude(parent=None)
        context["projects"] = projects
        context["projects_latest"] = projects.order_by("-datetime_last_modified")
        context["menu_items"] = ProjectMenu().menu_items
        context["app_color"] = LaraDjangoProjectsConfig.lara_app_color
        context["sidebar_menu_items"] = SidebarMenu().menu_items
        return context


# ---------------------------------------------------------------------------
# Navbar menu items endpoint (htmx partial)
# ---------------------------------------------------------------------------


def navbar_menu_items(request):
    """Return navbar menu items partial for htmx injection."""
    context = {"menu_items": ProjectMenu().menu_items}
    return render(request, "lara_django_projects/partials/navbar_menu_items.html", context)


# ---------------------------------------------------------------------------
# Projects overview (function-based, htmx-aware)
# ---------------------------------------------------------------------------


def projects_overview(request):
    """Projects overview with pagination and filtering."""
    projects = Project.objects.exclude(parent=None)
    project_filter = ProjectDjFilter(request.GET, queryset=projects)
    filtered_projects = project_filter.qs

    paginator = Paginator(filtered_projects, 10)
    page_number = request.GET.get("page", 1)
    page_obj = paginator.get_page(page_number)

    context = {
        "page_obj": page_obj,
        "project_count": filtered_projects.count(),
        "title": "Projects - Overview",
        "create_link": "lara_django_projects:project-create",
        "projects": filtered_projects,
        "filter": project_filter,
        "app_color": LaraDjangoProjectsConfig.lara_app_color,
        "menu_items": ProjectMenu().menu_items,
        "sidebar_menu_items": SidebarMenu().menu_items,
    }

    if request.htmx:
        return render(request, "lara_django_projects/partials/projects_overview.html", context)

    # Non-htmx: render partial then wrap in full layout
    partial_html = render_to_string(
        "lara_django_projects/partials/projects_overview.html",
        context=context,
        request=request,
    )
    wrapper_context = {
        **context,
        "inner_content": mark_safe(partial_html),  # noqa: S308
        "page_title": "Projects Overview",
    }
    return render(request, "lara_django_base/htmx_wrapper.html", wrapper_context)


# ---------------------------------------------------------------------------
# Project views (CBV with HtmxResponseMixin)
# ---------------------------------------------------------------------------


class ProjectSingleTableView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, SingleTableView):
    """List projects in a navigable list layout."""

    model = Project
    table_class = ProjectTable
    partial_template_name = "lara_django_projects/partials/list.html"
    page_title = "Project - List"
    success_url = "/projects/project/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - List"
        context["add_link"] = "lara_django_projects:project-add"
        return context


class ProjectSingleTable1View(HtmxResponseMixin, ProjectsTemplateSettingsMixin, SingleTableView):
    """Projects table view with filtering."""

    model = Project
    context_object_name = "projects"
    table_class = ProjectTable
    partial_template_name = "lara_django_projects/partials/table.html"
    page_title = "Project - Table"
    success_url = "/projects/project/table"

    def get_queryset(self):  # noqa: D102
        queryset = super().get_queryset()
        self.filter = ProjectDjFilter(self.request.GET, queryset=queryset)
        return self.filter.qs

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["filter"] = self.filter
        context["status"] = [project.status.status for project in Project.objects.all()]
        context["section_title"] = "Project - Table"
        context["add_link"] = "lara_django_projects:project-add"
        return context


class ProjectAddView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, FormView):
    """Add projects from an uploaded list."""

    partial_template_name = "lara_django_projects/partials/add_form.html"
    page_title = "Project - Add"
    form_class = ProjectsAddForm
    success_url = rev("lara_django_projects:project-list")

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Add"
        context["create_link"] = "lara_django_projects:project-create"
        return context

    def form_valid(self, form):
        """Process the uploaded project list."""
        if form.cleaned_data["project_list"] is not None:
            logging.getLogger(__name__).info("Processing project_list upload")
            self.num_projects_added = 42
        return super().form_valid(form)


class ProjectDetailView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DetailView):
    """Show project details with sub-projects and experiments tabs."""

    model = Project
    partial_template_name = "lara_django_projects/partials/project_detail.html"
    page_title = "Project - Details"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Details"
        context["update_link"] = "lara_django_projects:project-update"
        context["subprojects"] = self.object.get_descendants(include_self=False)
        context["experiments"] = self.object.experiments.all()
        return context


class ProjectCreateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, CreateView):
    """Create a new project."""

    model = Project
    partial_template_name = "lara_django_projects/partials/create_form.html"
    page_title = "Project - Create"
    form_class = ProjectCreateForm
    success_url = "/projects"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Create"
        return context


class ProjectUpdateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, UpdateView):
    """Update an existing project."""

    model = Project
    partial_template_name = "lara_django_projects/partials/update_form.html"
    page_title = "Project - Update"
    form_class = ProjectUpdateForm
    success_url = "/projects"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Update"
        context["delete_link"] = "lara_django_projects:project-delete"
        return context


class ProjectDeleteView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DeleteView):
    """Confirm and delete a project."""

    model = Project
    partial_template_name = "lara_django_projects/partials/delete_form.html"
    page_title = "Project - Delete"
    success_url = "/projects"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Delete"
        context["delete_link"] = "lara_django_projects:project-delete"
        return context


# ---------------------------------------------------------------------------
# Experiment views
# ---------------------------------------------------------------------------


class ExperimentSingleTableView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, SingleTableView):
    """List experiments in a navigable list layout."""

    model = Experiment
    table_class = ExperimentTable
    partial_template_name = "lara_django_projects/partials/list.html"
    page_title = "Experiment - List"
    success_url = "/projects/experiment/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiment - List"
        context["add_link"] = "lara_django_projects:experiment-create"
        return context


class ExperimentDetailView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DetailView):
    """Show experiment details with sub-experiments and data tabs."""

    model = Experiment
    partial_template_name = "lara_django_projects/partials/experiment_detail.html"
    page_title = "Experiment - Details"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiment - Details"
        context["update_link"] = "lara_django_projects:experiment-update"
        path_map = {
            "Data": f"/projects/experiment/data/{self.object.experiment_id}",
            "Devices": f"/projects/experiment/devices/{self.object.experiment_id}",
            "Parts": f"/projects/experiment/parts/{self.object.experiment_id}",
            "Labware": f"/projects/experiment/labware/{self.object.experiment_id}",
            "Substances": f"/projects/experiment/substances/{self.object.experiment_id}",
            "Samples": f"/projects/experiment/samples/{self.object.experiment_id}",
        }
        context["sidebar_menu_items"] = ExperimentsSidebarMenu().update_paths(path_map).menu_items
        return context


class ExperimentCreateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, CreateView):
    """Create a new experiment."""

    model = Experiment
    partial_template_name = "lara_django_projects/partials/create_form.html"
    page_title = "Experiment - Create"
    form_class = ExperimentCreateForm
    success_url = "/projects/experiment/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiment - Create"
        return context


class ExperimentUpdateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, UpdateView):
    """Update an existing experiment."""

    model = Experiment
    partial_template_name = "lara_django_projects/partials/update_form.html"
    page_title = "Experiment - Update"
    form_class = ExperimentUpdateForm
    success_url = "/projects/experiment/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiment - Update"
        context["delete_link"] = "lara_django_projects:experiment-delete"
        return context


class ExperimentDeleteView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DeleteView):
    """Confirm and delete an experiment."""

    model = Experiment
    partial_template_name = "lara_django_projects/partials/delete_form.html"
    page_title = "Experiment - Delete"
    success_url = "/projects/experiment/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiment - Delete"
        context["delete_link"] = "lara_django_projects:experiment-delete"
        return context


# ---------------------------------------------------------------------------
# Subset views - ExperimentsSubset
# ---------------------------------------------------------------------------


class ExperimentsSubsetCreateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, CreateView):
    """Create an experiments subset with automatic entity assignment."""

    model = ExperimentsSubset
    partial_template_name = "lara_django_projects/partials/create_form.html"
    page_title = "Experiments Subset - Create"
    form_class = ExperimentsSubsetCreateForm
    success_url = "/projects/experiment-subset/list"

    def form_valid(self, form):
        """Set entity and group from current user before saving."""
        instance = form.save(commit=False)
        instance.entity = self.request.user
        if hasattr(self.request.user, "groups") and self.request.user.groups.exists():
            instance.group = self.request.user.groups.first()
        instance.save()
        form.save_m2m()
        return HttpResponseRedirect(self.get_success_url())

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiments Subset - Create"
        return context


class ExperimentsSubsetUpdateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, UpdateView):
    """Update an experiments subset."""

    model = ExperimentsSubset
    partial_template_name = "lara_django_projects/partials/update_form.html"
    page_title = "Experiments Subset - Update"
    form_class = ExperimentsSubsetUpdateForm
    success_url = "/projects/experiment-subset/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiments Subset - Update"
        context["delete_link"] = "lara_django_projects:experiment-subset-delete"
        return context


class ExperimentsSubsetDeleteView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DeleteView):
    """Delete an experiments subset."""

    model = ExperimentsSubset
    partial_template_name = "lara_django_projects/partials/delete_form.html"
    page_title = "Experiments Subset - Delete"
    success_url = "/projects/experiment-subset/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiments Subset - Delete"
        return context


class ExperimentsSubsetListView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, ListView):
    """List experiments subsets."""

    model = ExperimentsSubset
    partial_template_name = "lara_django_projects/partials/list.html"
    page_title = "Experiments Subsets"
    context_object_name = "object_list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Experiments Subsets"
        context["add_link"] = "lara_django_projects:experiment-subset-create"
        return context


# ---------------------------------------------------------------------------
# Subset views - ProjectsSubset
# ---------------------------------------------------------------------------


class ProjectsSubsetCreateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, CreateView):
    """Create a projects subset with automatic entity assignment."""

    model = ProjectsSubset
    partial_template_name = "lara_django_projects/partials/create_form.html"
    page_title = "Projects Subset - Create"
    form_class = ProjSelectionCreateForm
    success_url = "/projects/project-subset/list"

    def form_valid(self, form):
        """Set entity and group from current user before saving."""
        instance = form.save(commit=False)
        instance.entity = self.request.user
        if hasattr(self.request.user, "groups") and self.request.user.groups.exists():
            instance.group = self.request.user.groups.first()
        instance.save()
        form.save_m2m()
        return HttpResponseRedirect(self.get_success_url())

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Projects Subset - Create"
        return context


class ProjectsSubsetUpdateView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, UpdateView):
    """Update a projects subset."""

    model = ProjectsSubset
    partial_template_name = "lara_django_projects/partials/update_form.html"
    page_title = "Projects Subset - Update"
    form_class = ProjSelectionUpdateForm
    success_url = "/projects/project-subset/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Projects Subset - Update"
        context["delete_link"] = "lara_django_projects:project-subset-delete"
        return context


class ProjectsSubsetDeleteView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, DeleteView):
    """Delete a projects subset."""

    model = ProjectsSubset
    partial_template_name = "lara_django_projects/partials/delete_form.html"
    page_title = "Projects Subset - Delete"
    success_url = "/projects/project-subset/list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Projects Subset - Delete"
        return context


class ProjectsSubsetListView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, ListView):
    """List projects subsets."""

    model = ProjectsSubset
    partial_template_name = "lara_django_projects/partials/list.html"
    page_title = "Projects Subsets"
    context_object_name = "object_list"

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Projects Subsets"
        context["add_link"] = "lara_django_projects:project-subset-create"
        return context


# ---------------------------------------------------------------------------
# Experiment component views (data, devices, substances)
# ---------------------------------------------------------------------------


class ExperimentDataListView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, ListView):
    """List data associated with an experiment."""

    model = Data
    partial_template_name = "lara_django_projects/partials/experiment_components_list.html"
    page_title = "Data Explorer"
    context_object_name = "data"

    def get_queryset(self):  # noqa: D102
        self.experiment = Experiment.objects.get(experiment_id=self.kwargs["pk"])
        return self.experiment.data.all()

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["create_link"] = "lara_django_data:data-create"
        context["title"] = "Data Explorer"
        context["section_title"] = f"Data of experiment: {self.experiment.name_display}"
        context["breadcrumb_menu_items"] = BreadcrumbMenu().menu_items
        context["view_component"] = "lara_django_projects/components/data_view.html"
        return context


class ExperimentDevicesListView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, ListView):
    """List devices associated with an experiment."""

    model = DeviceInstance
    partial_template_name = "lara_django_projects/partials/experiment_components_list.html"
    page_title = "Devices"
    context_object_name = "devices"

    def get_queryset(self):  # noqa: D102
        self.experiment = Experiment.objects.get(experiment_id=self.kwargs["pk"])
        return self.experiment.device_instances.all()

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = f"Devices - {self.experiment.name_display}"
        context["create_link"] = "lara_django_material_store:device-create"
        context["view_component"] = "lara_django_projects/components/devices_view.html"
        return context


class ExperimentSubstancesListView(HtmxResponseMixin, ProjectsTemplateSettingsMixin, ListView):
    """List substances associated with an experiment."""

    model = SubstanceInstance
    partial_template_name = "lara_django_projects/partials/experiment_components_list.html"
    page_title = "Substances"
    context_object_name = "substances"

    def get_queryset(self):  # noqa: D102
        self.experiment = Experiment.objects.get(experiment_id=self.kwargs["pk"])
        return self.experiment.substance_instances.all()

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = f"Substances - {self.experiment.name_display}"
        context["create_link"] = "lara_django_substances_store:substance-create"
        context["view_component"] = "lara_django_projects/components/substances_view.html"
        return context


# ---------------------------------------------------------------------------
# Data explorer (function-based, htmx-aware)
# ---------------------------------------------------------------------------


def data_explorer(request, pk):
    """HTMX-based data explorer view for a specific experiment."""
    data = Data.objects.get(data_id=pk)
    context = {"data": data}
    return render(request, "lara_django_projects/partials/data_explorer_tabs.html", context)


# ---------------------------------------------------------------------------
# Legacy / older views
# ---------------------------------------------------------------------------


class RootIndexView(HtmxResponseMixin, ListView):
    """Overview of root-level projects."""

    model = Project
    paginate_by = 100
    partial_template_name = "lara_django_projects/partials/root_index.html"
    page_title = "Project - Overview"

    def get_queryset(self):
        """Return only root projects."""
        return Project.objects.filter(level=1)

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Overview"
        context["create_link"] = "lara_django_projects:project-create"
        context["menu_items"] = ProjectMenu().menu_items
        context["root_projects"] = self.get_queryset()
        return context


class ProjectTree(HtmxResponseMixin, ListView):
    """Display a project tree under a given root."""

    model = Project
    partial_template_name = "lara_django_projects/partials/list.html"
    page_title = "Project - Tree"
    context_object_name = "project_list"
    paginate_by = 100

    def get_queryset(self, *args, **kwargs):
        """Return only projects under selected project."""
        self.subtree_root_project = Project.objects.get(project_id=self.kwargs["pk"])
        return self.subtree_root_project.get_descendants()

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Project - Tree"
        context["create_link"] = "lara_django_projects:project-create"
        context["menu_items"] = ProjectMenu().menu_items
        context["subtree_root"] = self.subtree_root_project
        return context


class ProjectDetails(HtmxResponseMixin, DetailView):
    """Simple project detail view (legacy)."""

    model = Project
    partial_template_name = "lara_django_projects/partials/project_detail.html"
    page_title = "Project Details"


class ExperimentDetails(HtmxResponseMixin, DetailView):
    """Simple experiment detail view (legacy)."""

    model = Experiment
    partial_template_name = "lara_django_projects/partials/experiment_detail.html"
    page_title = "Experiment Details"


def show_proj_tree(request):
    """Render a flat project tree (legacy)."""
    context = {"main_project": "All", "projects": Project.objects.all()}
    return render(request, "lara_projects/proj_tree.html", context)


# ---------------------------------------------------------------------------
# Review / search (legacy)
# ---------------------------------------------------------------------------


class ReviewEmailView(HtmxResponseMixin, FormView):
    """Review form that sends an email."""

    partial_template_name = "lara_django_projects/partials/review.html"
    page_title = "Review"
    form_class = ReviewForm
    success_url = "/projects/project/list"

    def form_valid(self, form):
        """Send the review email."""
        form.send_email()
        return HttpResponse("Thank you for your review!")


def search_form(request):
    """Render the search form (legacy)."""
    return render(request, "lara_projects/search.html", context={})


def search(request):
    """Execute a project search (legacy)."""
    search_string = request.POST["search"]
    logger = logging.getLogger(__name__)

    try:
        project_list = []
        curr_project = Project.objects.get(project__name=search_string)
        project_list.append(curr_project)
    except ValueError as err:
        logger.error("Error during search: %s", err)
    else:
        context = {"project_list": project_list}
        return render(request, "lara_projects/results.html", context)


def search_results(request, project_list):
    """Display search results (legacy)."""
    context = {"project_list": project_list}
    return render(request, "lara_projects/results.html", context)
