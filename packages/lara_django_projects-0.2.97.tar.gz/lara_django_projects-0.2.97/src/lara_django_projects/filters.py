"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>
________________________________________________________________________
"""

from typing import ClassVar

import django_filters
from django_filters.rest_framework import FilterSet

from .models import Experiment, Project, Task


class ProjectDjFilter(django_filters.FilterSet):
    """Django Filter for Project model."""

    class Meta:  # noqa: D106
        model = Project
        fields = ("name", "description", "status__status", "datetime_start", "datetime_end", )


# gRPC filters

class TaskFilter(FilterSet):  # noqa: D101
    class Meta:  # noqa: D106
        model = Task
        fields: ClassVar[dict[str, list[str]]] = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "datetime_start": ["lt", "gt", "exact", "range"],
            "datetime_end": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_added": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class ProjectFilter(FilterSet):  # noqa: D101
    class Meta:  # noqa: D106
        model = Project
        fields : ClassVar[dict[str, list[str]]] = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "datetime_start": ["lt", "gt", "exact", "range"],
            "datetime_end": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_added": ["lt", "gt", "exact", "range"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class ExperimentFilter(FilterSet):  # noqa: D101
    class Meta:  # noqa: D106
        model = Experiment
        fields: ClassVar[dict[str, list[str]]] = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "datetime_start": ["lt", "gt", "exact", "range"],
            "datetime_end": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_added": ["lt", "gt", "exact", "range"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "description": ["exact", "contains"],
        }
