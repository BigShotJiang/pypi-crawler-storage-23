"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects celery tasks*

:details: lara_django_projects celery tasks.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from __future__ import absolute_import, unicode_literals

from celery import shared_task

from celery.utils.log import get_task_logger

from .email import send_review_email

logger = get_task_logger(__name__)


@shared_task
def  send_review_email_task(name, email, review):
    """sends an email to a user after a review is submitted"""
    logger.info("Sent review email")
    return send_review_email(name, email, review)