"""scm: Core SDK package for Strata Cloud Manager interaction."""
# scm/__init__.py
