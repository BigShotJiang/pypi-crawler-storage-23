from cidc_api.models import TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
from cidc_api.shared.file_handling import get_column_from_appendix_a, get_column_from_first_row
from cidc_api.telemetry import trace_

# pylint: disable=line-too-long, unnecessary-lambda


EXPECTED_COLUMN_NAMES = ["Data Category", "Cardinality", "Data Element", "Data Type", "Delivery", "Description"]


def validate_category(df, meta):
    """Returns error messages if any values in column "Data Category" are missing"""

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    empty_categories = df.loc[df[category_column] == "", category_column]

    errors = []

    if empty_categories.size > 0:
        row_numbers = [n + 1 for n in list(empty_categories.index)]
        errors = [{"error": "Missing Data Category value(s)", "value": {"row_numbers": row_numbers}}]

    return {"errors": errors, "meta": meta}


def validate_cardinality(df, meta):
    """Returns errors if any values in column "Cardinality" are invalid.
    Cardinality values must be self-consistent in the same Custom Data Category.
    Cardinality must be blank for any Custom Data Element in a Standard Data Category"""

    cardinality_column_name = "Cardinality"

    # skip validation if cardinality_column_name is missing
    if cardinality_column_name not in df.columns:
        return {
            "errors": [{"error": f"{cardinality_column_name} column is missing; skipping cardinality validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    cardinality_column = get_column_from_first_row(df, cardinality_column_name)
    cardinality_by_category = (
        df.iloc[1:].groupby(category_column, as_index=False)[cardinality_column].aggregate(to_set_)
    )
    meta = {**meta, "custom_categories": [], "not_custom_categories": []}

    errors = []

    for category, cardinalities in cardinality_by_category.itertuples(index=False):
        if not category:
            continue

        # When a row in the "Custom Data Elements" tab specifies a custom Data Category, the value for "Cardinality" must be the same for all rows of that Data Category.
        # For example, lesion cannot have one row that says "One row per participant" and another row that says "Multiple rows per participant".
        # Cardinalities do not match for [Data Category] [cell: one per participant] [cell: multiple per participant].
        if len(cardinalities) > 1:
            errors.append(
                {
                    "error": "Cardinalities do not match for category",
                    "value": {"category": category, "cardinalities": sorted(list(cardinalities), key=lambda x: str(x))},
                }
            )

        # Standard Data Category: Cardinality must be blank for categories that are both in appendix A and the Custom Data Elements tab.
        if category in meta["categories"]:
            meta["not_custom_categories"].append(category)

            if cardinalities != {""}:
                errors.append(
                    {
                        "error": "Cardinality must be blank for categories that are both in appendix A and the Custom Data Elements tab",
                        "value": {
                            "category": category,
                            "cardinalities": sorted(list(cardinalities), key=lambda x: str(x)),
                        },
                    }
                )

        # Non-standard Data Category: Cardinality must be present for categories that are not in appendix A tab.
        if category not in meta["categories"]:
            meta["custom_categories"].append(category)

            if cardinalities == {""}:
                errors.append(
                    {
                        "error": "Cardinality must be present for categories that are not in Appendix A tab",
                        "value": {"category": category, "cardinalities": []},
                    }
                )

    return {"errors": errors, "meta": meta}


def validate_participant_id(df, meta):
    """Returns errors if any values in column "Data Element" are missing the 'participant_id' field in their
    respective data category"""

    data_element_column_name = "Data Element"

    # skip validation if data_element_column_name is missing
    if data_element_column_name not in df.columns:
        return {
            "errors": [{"error": f"{data_element_column_name} column is missing; skipping participant_id validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    element_column = get_column_from_first_row(df, data_element_column_name)

    errors = []

    for category in meta["custom_categories"]:
        condition = (df[category_column] == category) & (df[element_column] == "participant_id")
        row_with_participant_id_element = df.loc[condition]

        if row_with_participant_id_element.empty:
            errors.append(
                {
                    "error": "participant_id must be a field specified in each custom Data Category",
                    "value": {"category": category},
                }
            )

    return {"errors": errors, "meta": meta}


def validate_element(df, meta):
    """Returns errors if any values in column "Data Element" are already known to the system in the same Data Category.
    For example, height could not be a Custom Data Element name in the demographic Data Category, but marital_status could.
    """

    data_element_column_name = "Data Element"

    # skip validation if data_element_column_name is missing
    if data_element_column_name not in df.columns:
        return {
            "errors": [{"error": f"{data_element_column_name} column is missing; skipping elements validation"}],
            "meta": meta,
        }

    category_column = get_column_from_first_row(df, TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER)
    element_column = get_column_from_first_row(df, data_element_column_name)
    my_elements_by_category = df.groupby(category_column, as_index=False)[element_column].aggregate(to_set_)

    empty_elements = df.loc[df[element_column] == "", element_column]

    errors = []

    if empty_elements.size > 0:
        row_numbers = [n + 1 for n in list(empty_elements.index)]
        errors = [{"error": "Missing Data Element value(s)", "value": {"row_numbers": row_numbers}}]

    for my_category, my_elements in my_elements_by_category.itertuples(index=False):
        if known_elements := meta["elements_by_category"].get(my_category):
            if known_elements != {""} and (duplicate_elements := known_elements.intersection(my_elements)):
                errors.append(
                    {
                        "error": "Custom Data Elements are already known in their category",
                        "value": {"category": my_category, "elements": list(duplicate_elements)},
                    }
                )

    return {"errors": errors, "meta": meta}


def validate_types(df, meta):
    """Returns errors if any values in column "Data Type" are invalid (string or number)"""

    type_column_name = "Data Type"

    # skip validation if type_column_name is missing
    if type_column_name not in df.columns:
        return {"errors": [{"error": f"{type_column_name} column is missing; skipping types validation"}], "meta": meta}

    allowed_types = ["string", "number"]
    errors = []

    rows_with_invalid_type = df[~df[type_column_name].isin(allowed_types)]
    if not rows_with_invalid_type.empty:
        rows_numbers = [n + 1 for n in list(rows_with_invalid_type.index)]
        invalid_types = list(rows_with_invalid_type[type_column_name].unique())

        errors = [
            {
                "error": f"Invalid types found in {type_column_name} column; only {allowed_types} are accepted",
                "value": {"row_numbers": rows_numbers, "invalid_types": invalid_types},
            }
        ]

    return {"errors": errors, "meta": meta}


def validate_columns(df, meta):
    """Returns error messages if any of the column headers are invalid or missing"""

    errors = []
    columns = df.columns.tolist()

    extra_columns = set(columns) - set(EXPECTED_COLUMN_NAMES)
    missing_columns = set(EXPECTED_COLUMN_NAMES) - set(columns)

    if extra_columns:
        errors.append(
            {
                "error": "Extra columns found in Custom Data Elements tab",
                "value": {"extra_columns": sorted(list(extra_columns))},
            }
        )

    if missing_columns:
        errors.append(
            {
                "error": "Missing columns found in Custom Data Elements tab",
                "value": {"missing_columns": sorted(list(missing_columns))},
            }
        )

    return {"errors": errors, "meta": meta}


def validate_delivery(df, meta) -> dict:
    """Returns error messages if any values in column 'Delivery' are invalid"""

    errors = []

    delivery_column_name = "Delivery"

    # skip validation if delivery_column_name is missing
    if delivery_column_name not in df.columns:
        return {
            "errors": [{"error": f"{delivery_column_name} column is missing; skipping delivery validation"}],
            "meta": meta,
        }

    delivery_values = set(df[delivery_column_name].tolist())
    invalid_delivery_values = delivery_values - {"A", ""}
    if invalid_delivery_values:
        errors.append(
            {
                "error": 'Delivery value can only be "A" or blank',
                "value": {"invalid_delivery_values": sorted(list(invalid_delivery_values))},
            }
        )

    return {"errors": errors, "meta": meta}


def validate_description(df, meta):
    """Returns error messages if any values in column 'Description' are missing"""
    errors = []

    description_column = get_column_from_first_row(df, "Description")
    empty_descriptions = df.loc[df[description_column] == "", description_column]

    if empty_descriptions.size > 0:
        row_numbers = [n + 1 for n in list(empty_descriptions.index)]
        errors = [{"error": "Missing Description value(s)", "value": {"row_numbers": row_numbers}}]

    return {"errors": errors, "meta": meta}


def get_rows_after_condition(df, condition):
    condition_met_index = df[condition].index[0]
    rows_afer_condition_df = df.iloc[condition_met_index + 1 :]

    return rows_afer_condition_df


def get_categories(appendix_a_df):
    category_column = appendix_a_df.columns[0]
    condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    categories = get_rows_after_condition(appendix_a_df, condition)

    return sorted(list(categories[category_column].unique()))


def get_elements_by_category(appendix_a_df):
    category_column = appendix_a_df.columns[0]
    element_column = get_column_from_appendix_a(appendix_a_df, "Data Element")
    condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    categories = get_rows_after_condition(appendix_a_df, condition)
    elements_by_category = categories.groupby(category_column, as_index=False)[element_column].aggregate(to_set_)

    return dict(zip(elements_by_category[category_column], elements_by_category[element_column]))


def to_set_(x):
    return set(x)


@trace_()
def validate(custom_element_df, appendix_a_df):
    # skip if empty or have no data rows (header row not counted)
    if custom_element_df.empty or custom_element_df.shape[0] == 0:
        return {"errors": [], "meta": {}}

    custom_element_df.fillna("", inplace=True)
    categories = get_categories(appendix_a_df)
    elements_by_category = get_elements_by_category(appendix_a_df)
    meta = {"elements_by_category": elements_by_category, "categories": categories}

    errors = []

    for validate_ in [
        validate_columns,
        validate_category,
        validate_cardinality,
        validate_participant_id,
        validate_element,
        validate_types,
        validate_delivery,
        validate_description,
    ]:
        result = validate_(custom_element_df, meta)
        meta = {**meta, **result["meta"]}
        errors.extend(result["errors"])

    return {"errors": errors, "meta": meta}
