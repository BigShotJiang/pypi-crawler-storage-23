"""Octi — LangGraph multi-agent console."""
