"""Allow running as `python -m octo`."""
from octo.cli import main

main()
