"""Proto namespace alias for agent_genesis imports."""

from pathlib import Path

_PROTO_PATH = Path(__file__).resolve().parents[2] / "proto"
__path__ = [str(_PROTO_PATH)]
__all__: list[str] = []
