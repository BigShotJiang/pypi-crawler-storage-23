"""Runtime namespace alias for agent_genesis imports."""

from pathlib import Path

_RUNTIME_PATH = Path(__file__).resolve().parents[2] / "runtime"
__path__ = [str(_RUNTIME_PATH)]
__all__: list[str] = []
