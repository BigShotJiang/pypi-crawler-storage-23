"""Public package namespace for agent_genesis."""

from importlib import metadata

try:
    __version__ = metadata.version("agent-genesis")
except metadata.PackageNotFoundError:
    __version__ = "0.0.3"

__all__ = ["__version__"]
