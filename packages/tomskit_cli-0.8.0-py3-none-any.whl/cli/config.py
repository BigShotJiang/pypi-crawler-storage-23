"""
Directory and file mapping configuration for project scaffolding.
"""

# ============================================================================
# Directory structures (path -> needs __init__.py)
# ============================================================================

BASE_DIRECTORIES: dict[str, bool] = {
    "extensions": True,
    "configs": True,
    "tests": True,
    "logs": False,
    "run": False,
    "docs": False,
}

FASTAPI_DIRECTORIES: dict[str, bool] = {
    "app": True,
    "app/controllers": True,
    "app/middleware": True,
    "app/models": True,
    "app/utils": True,
    "app/errors": True,
    "app/errors/codes": True,
    "migrations": True,
    "migrations/versions": True,
}

CELERY_DIRECTORIES: dict[str, bool] = {
    "tasks": True,
    "scripts": False,
}


def get_directories(project_type: str) -> dict[str, bool]:
    """Return directory structure for a given project type."""
    dirs = BASE_DIRECTORIES.copy()
    if project_type in ("fastapi", "full"):
        dirs.update(FASTAPI_DIRECTORIES)
    if project_type in ("celery", "full"):
        dirs.update(CELERY_DIRECTORIES)
    return dirs


# ============================================================================
# File templates (target_path -> template_path)
# ============================================================================

BASE_FILES: dict[str, str] = {
    ".env.example": "project/base/env_example.j2",
    ".gitignore": "project/base/gitignore.j2",
    "pyproject.toml": "project/base/pyproject_toml.j2",
    "README.md": "project/base/readme.md.j2",
    # Extensions
    "extensions/__init__.py": "__empty__",
    "extensions/ext_logger.py": "project/extensions/ext_logger.py.j2",
    "extensions/ext_warnings.py": "project/extensions/ext_warnings.py.j2",
    "extensions/ext_modules.py": "project/extensions/ext_modules.py.j2",
    "extensions/ext_exception_handlers.py": "project/extensions/ext_exception_handlers.py.j2",
    # Configs
    "configs/__init__.py": "project/configs/init.py.j2",
    "configs/pyproject.py": "project/configs/pyproject.py.j2",
    "configs/settings.py": "project/configs/settings.py.j2",
    # Claude Code support
    "CLAUDE.md": "project/claude/CLAUDE.md.j2",
    "docs/tomskit-guide.md": "project/claude/tomskit-guide.md.j2",
    # Tests
    "tests/__init__.py": "__empty__",
}

FASTAPI_FILES: dict[str, str] = {
    "main.py": "project/fastapi/main.py.j2",
    "app_factory.py": "project/fastapi/app_factory.py.j2",
    "app/__init__.py": "__empty__",
    "app/middleware/__init__.py": "project/fastapi/middleware_init.py.j2",
    "app/middleware/request_id.py": "project/fastapi/middleware_request_id.py.j2",
    "app/middleware/database_session.py": "project/fastapi/middleware_database_session.py.j2",
    "app/middleware/resource_cleanup.py": "project/fastapi/middleware_resource_cleanup.py.j2",
    "app/controllers/__init__.py": "project/fastapi/controllers_init.py.j2",
    "app/models/__init__.py": "project/fastapi/models_init.py.j2",
    "app/errors/__init__.py": "project/errors/init.py.j2",
    "app/errors/exceptions.py": "project/errors/exceptions.py.j2",
    "app/errors/codes/__init__.py": "project/errors/codes/init.py.j2",
    "app/errors/codes/base.py": "project/errors/codes/base.py.j2",
    "app/errors/codes/auth.py": "project/errors/codes/auth.py.j2",
    "app/errors/codes/user.py": "project/errors/codes/user.py.j2",
    # Database / Redis extensions (require FastAPI)
    "extensions/ext_database.py": "project/extensions/ext_database.py.j2",
    "extensions/ext_redis.py": "project/extensions/ext_redis.py.j2",
    # Migrations
    "migrations/__init__.py": "project/migrations/init.py.j2",
    "migrations/alembic.ini": "project/migrations/alembic_ini.j2",
    "migrations/env.py": "project/migrations/env.py.j2",
    "migrations/script.py.mako": "project/migrations/script_mako.j2",
    "migrations/versions/__init__.py": "project/migrations/versions_init.py.j2",
}

CELERY_FILES: dict[str, str] = {
    "celery_app.py": "project/celery/celery_app.py.j2",
    "extensions/ext_celery.py": "project/extensions/ext_celery.py.j2",
    "tasks/__init__.py": "project/celery/tasks_init.py.j2",
    "tasks/example_task.py": "project/celery/example_task.py.j2",
    # Shell scripts
    "scripts/celery_worker.sh": "project/scripts/celery_worker.sh.j2",
    "scripts/celery_beat.sh": "project/scripts/celery_beat.sh.j2",
    "scripts/celery_stop.sh": "project/scripts/celery_stop.sh.j2",
    "scripts/celery_restart.sh": "project/scripts/celery_restart.sh.j2",
    "scripts/celery_status.sh": "project/scripts/celery_status.sh.j2",
    "scripts/celery_check_tasks.sh": "project/scripts/celery_check_tasks.sh.j2",
}


def get_files(project_type: str) -> dict[str, str]:
    """Return file template mappings for a given project type."""
    files = BASE_FILES.copy()
    if project_type in ("fastapi", "full"):
        files.update(FASTAPI_FILES)
    if project_type in ("celery", "full"):
        files.update(CELERY_FILES)
    return files
