#!/usr/bin/env python
# PYTHON_ARGCOMPLETE_OK
"""
toms-fast CLI 工具

命令：
    tomskit init <project_name> [-d desc] [-o dir] [-t full|fastapi|celery]
    tomskit add module <name>
    tomskit add task <name>
    tomskit add extension <name>
    tomskit add service <name>
    tomskit claude init [-d dir]
    tomskit migrations [-d dir]

启用 Tab 自动补全：
    # 对于 bash，添加到 ~/.bashrc:
    eval "$(register-python-argcomplete tomskit)"

    # 对于 zsh，添加到 ~/.zshrc:
    autoload -U bashcompinit
    bashcompinit
    eval "$(register-python-argcomplete tomskit)"
"""

import argparse
import sys
import tomllib
from pathlib import Path

import argcomplete

from .scaffold import create_project


def _get_project_root(project_dir: str | None = None) -> Path:
    """Locate the project root directory."""
    if project_dir is None:
        project_dir_path = Path.cwd()
    else:
        project_dir_path = Path(project_dir).resolve()

    if not (project_dir_path / "main.py").exists() and not (project_dir_path / "app").exists():
        print("❌ 错误: 未找到项目文件，请确保在项目根目录运行此命令")
        sys.exit(1)

    return project_dir_path


def init_migrations(project_path: str | None = None, yes: bool = False):
    """Initialize database migrations for an existing project."""
    project_root = _get_project_root(project_path)

    project_name = project_root.name
    pyproject_path = project_root / "pyproject.toml"
    if pyproject_path.exists():
        try:
            with open(pyproject_path, "rb") as f:
                pyproject_data = tomllib.load(f)
                if "project" in pyproject_data and "name" in pyproject_data["project"]:
                    project_name = pyproject_data["project"]["name"]
        except Exception:
            pass

    migrations_dir = project_root / "migrations"
    alembic_ini = migrations_dir / "alembic.ini"

    if migrations_dir.exists() and alembic_ini.exists():
        if yes:
            print("⚠️  警告: migrations 目录和 alembic.ini 已存在，将覆盖现有配置")
        else:
            print("⚠️  警告: migrations 目录和 alembic.ini 已存在")
            response = input("是否重新初始化？这将覆盖现有配置 (y/N): ")
            if response.lower() != "y":
                print("❌ 已取消")
                return

    print(f"🚀 正在为 {project_name} 项目初始化数据库迁移...")
    print(f"📁 项目路径: {project_root}")

    from .renderer import TemplateRenderer

    renderer = TemplateRenderer()
    context = {"project_name": project_name}

    migrations_dir.mkdir(exist_ok=True)
    versions_dir = migrations_dir / "versions"
    versions_dir.mkdir(exist_ok=True)

    (migrations_dir / "__init__.py").write_text('"""\n数据库迁移目录\n"""\n', encoding="utf-8")
    (versions_dir / "__init__.py").write_text('"""\n数据库迁移版本目录\n"""\n', encoding="utf-8")

    content = renderer.render("project/migrations/alembic_ini.j2", **context)
    alembic_ini.write_text(content, encoding="utf-8")
    print("  ✓ 创建文件: migrations/alembic.ini")

    content = renderer.render("project/migrations/env.py.j2", **context)
    (migrations_dir / "env.py").write_text(content, encoding="utf-8")
    print("  ✓ 创建文件: migrations/env.py")

    content = renderer.render("project/migrations/script_mako.j2", **context)
    (migrations_dir / "script.py.mako").write_text(content, encoding="utf-8")
    print("  ✓ 创建文件: migrations/script.py.mako")

    print("\n✅ 数据库迁移初始化成功！")
    print("\n📝 下一步:")
    print("   # 创建初始迁移:")
    print("   uv run alembic -c migrations/alembic.ini revision --autogenerate -m 'Initial migration'")
    print("   # 应用迁移到数据库:")
    print("   uv run alembic -c migrations/alembic.ini upgrade head")


def init_claude(project_path: str | None = None):
    """Initialize Claude Code support for an existing project."""
    project_root = _get_project_root(project_path)

    from .renderer import TemplateRenderer

    renderer = TemplateRenderer()

    print("Initializing Claude Code support...")

    content = renderer.render("project/claude/CLAUDE.md.j2")
    (project_root / "CLAUDE.md").write_text(content, encoding="utf-8")
    print("  ✓ Created CLAUDE.md")

    print("\n✅ Claude Code support initialized successfully!")


def main():
    """CLI entry function."""
    parser = argparse.ArgumentParser(
        description="tomskit 项目脚手架生成器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  tomskit init <project_name>        创建新项目
  tomskit migrations                 初始化数据库迁移
  tomskit add module <name>          创建完整模块（Model + Service + Controller + Schema）
  tomskit add task <name>            创建 Celery 异步任务
  tomskit add extension <name>       创建 FastAPI 扩展
  tomskit add service <name>         创建独立 Service
  tomskit claude init                初始化 Claude Code 支持（CLAUDE.md + skills）

Examples:
  tomskit init my-app                    创建名为 my-app 的新项目
  tomskit init my-app -d "我的项目"       创建项目并指定描述
  tomskit init my-app -t fastapi         创建仅 FastAPI 项目
  tomskit init my-app -y                 跳过交互提示
  tomskit add module user                创建 user 模块
  tomskit add service payment            创建独立的 payment service
        """
    )

    parser.add_argument(
        "-y", "--yes",
        action="store_true",
        default=False,
        help="跳过所有交互提示，使用默认值",
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # init command
    init_parser = subparsers.add_parser("init", help="创建新项目")
    init_parser.add_argument("project_name", help="项目名称")
    init_parser.add_argument(
        "-o", "--output",
        dest="target_dir",
        help="目标目录（默认为当前目录）",
        default=None,
    )
    init_parser.add_argument(
        "-t", "--type",
        dest="project_type",
        choices=["fastapi", "celery", "full"],
        default="full",
        help="项目类型（默认: full）",
    )
    init_parser.add_argument(
        "-d", "--description",
        dest="description",
        help="项目描述",
        default=None,
    )

    # migrations command
    migrations_parser = subparsers.add_parser("migrations", help="初始化数据库迁移")
    migrations_parser.add_argument(
        "-d", "--dir",
        dest="project_dir",
        help="项目目录（默认为当前目录）",
        default=None,
    )

    # add command
    add_parser = subparsers.add_parser("add", help="添加模块组件")
    add_subparsers = add_parser.add_subparsers(dest="add_type", help="组件类型")

    # add module
    module_parser = add_subparsers.add_parser("module", help="创建完整模块（Model + Service + Controller + Schema）")
    module_parser.add_argument("name", help="模块名称")
    module_parser.add_argument("-d", "--dir", dest="project_dir", default=None)

    # add task
    task_parser = add_subparsers.add_parser("task", help="创建 Celery 异步任务")
    task_parser.add_argument("name", help="任务名称")
    task_parser.add_argument("-d", "--dir", dest="project_dir", default=None)

    # add extension
    ext_parser = add_subparsers.add_parser("extension", help="创建 FastAPI 扩展")
    ext_parser.add_argument("name", help="扩展名称")
    ext_parser.add_argument("-d", "--dir", dest="project_dir", default=None)

    # add service
    service_parser = add_subparsers.add_parser("service", help="创建独立 Service")
    service_parser.add_argument("name", help="Service 名称")
    service_parser.add_argument("-d", "--dir", dest="project_dir", default=None)

    # claude command
    claude_parser = subparsers.add_parser("claude", help="Claude Code 支持")
    claude_subparsers = claude_parser.add_subparsers(dest="claude_action", help="Claude 操作")

    claude_init_parser = claude_subparsers.add_parser("init", help="初始化 Claude Code 支持")
    claude_init_parser.add_argument("-d", "--dir", dest="project_dir", default=None)

    argcomplete.autocomplete(parser)
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "init":
        project_name = args.project_name
        if not project_name.replace("_", "").replace("-", "").isalnum():
            print("❌ 错误: 项目名称只能包含字母、数字、下划线和连字符")
            sys.exit(1)

        description = args.description
        if not description and not args.yes:
            description = input("请输入项目描述（可选，直接回车使用默认值）: ").strip()
            if not description:
                description = None

        try:
            create_project(project_name, args.target_dir, args.project_type, description)
        except Exception as e:
            print(f"❌ 创建项目失败: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    elif args.command == "migrations":
        try:
            init_migrations(args.project_dir, yes=args.yes)
        except Exception as e:
            print(f"❌ 初始化 migrations 失败: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    elif args.command == "add":
        if args.add_type is None:
            print("❌ 错误: 请指定组件类型（module/task/extension/service）")
            print("\n用法: tomskit add <type> <name>")
            sys.exit(1)

        project_root = _get_project_root(args.project_dir)

        try:
            from .generators import (
                ModuleGenerator,
                TaskGenerator,
                ExtensionGenerator,
                ServiceGenerator,
            )

            if args.add_type == "module":
                ModuleGenerator(project_root).create_module(args.name)
            elif args.add_type == "task":
                TaskGenerator(project_root).create_task(args.name)
            elif args.add_type == "extension":
                ExtensionGenerator(project_root).create_extension(args.name)
            elif args.add_type == "service":
                ServiceGenerator(project_root).create_service(args.name)
            else:
                print(f"❌ 错误: 不支持的组件类型: {args.add_type}")
                sys.exit(1)
        except Exception as e:
            print(f"❌ 创建组件失败: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    elif args.command == "claude":
        if args.claude_action == "init":
            try:
                init_claude(args.project_dir)
            except Exception as e:
                print(f"❌ 初始化 Claude Code 支持失败: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
        else:
            print("❌ 错误: 请指定操作（init）")
            print("示例: tomskit claude init")
            sys.exit(1)


if __name__ == "__main__":
    main()
