"""
Project scaffold generator.

Creates a new project directory structure with all necessary files.
"""

from pathlib import Path

from .config import get_directories, get_files
from .renderer import TemplateRenderer


class ProjectScaffold:
    """Project scaffold generator."""

    def __init__(
        self,
        project_name: str,
        target_dir: str | None = None,
        project_type: str = "full",
        description: str | None = None,
    ):
        self.project_name = project_name
        self.project_type = project_type

        project_type_names = {
            "fastapi": "FastAPI",
            "celery": "Celery",
            "full": "FastAPI + Celery",
        }
        self.project_type_name = project_type_names.get(project_type, project_type)

        if description is None:
            description = f"基于 toms-fast 的 {self.project_type_name} 应用"
        self.description = description

        current_dir = Path.cwd()
        if target_dir is None:
            if current_dir.name == project_name:
                self.project_path = current_dir
            else:
                self.project_path = current_dir / project_name
        else:
            self.project_path = Path(target_dir)

        self.renderer = TemplateRenderer()

    def create(self):
        """Create the project structure."""
        print(f"🚀 正在创建项目: {self.project_name}")
        print(f"📦 项目类型: {self.project_type_name}")
        print(f"📁 目标目录: {self.project_path}")

        if self.project_path.exists() and any(self.project_path.iterdir()):
            has_app = (self.project_path / "app").exists()
            has_main = (self.project_path / "main.py").exists()
            if has_app or has_main:
                print(f"⚠️  警告: 目录 {self.project_path} 中已存在项目结构")
                response = input("是否继续？这将覆盖现有文件 (y/N): ")
                if response.lower() != "y":
                    print("❌ 已取消")
                    return

        self._create_directories()
        self._create_files()

        print("\n✅ 项目创建成功！")
        print("\n📝 下一步:")
        if self.project_path == Path.cwd():
            print("   # 已在项目目录中")
        else:
            print(f"   cd {self.project_path}")
        print("   uv sync  # 安装依赖（使用 uv 管理）")
        print("   cp .env.example .env")
        print("   # 编辑 .env 文件配置数据库和 Redis")

        if self.project_type in ("fastapi", "full"):
            print("\n   # 数据库迁移:")
            print("   uv run alembic -c migrations/alembic.ini revision --autogenerate -m 'Initial migration'")
            print("   uv run alembic -c migrations/alembic.ini upgrade head")
            print("\n   # 运行 FastAPI 应用:")
            print("   uv run uvicorn main:app --reload")
        if self.project_type in ("celery", "full"):
            print("   # 运行 Celery Worker:")
            print("   uv run celery -A celery_app worker --loglevel=info")

    def _create_directories(self):
        """Create directory structure from config."""
        directories = get_directories(self.project_type)
        for dir_path_str, need_init in directories.items():
            dir_path = self.project_path / dir_path_str
            dir_path.mkdir(parents=True, exist_ok=True)
            if need_init:
                init_file = dir_path / "__init__.py"
                if not init_file.exists():
                    init_file.touch()
                print(f"  ✓ 创建目录: {dir_path_str}/ (含 __init__.py)")
            else:
                print(f"  ✓ 创建目录: {dir_path_str}/")

    def _create_files(self):
        """Create all files from config templates."""
        files = get_files(self.project_type)
        context = {
            "project_name": self.project_name,
            "project_type": self.project_type,
            "project_type_name": self.project_type_name,
            "description": self.description,
        }

        for file_path_str, template_path in files.items():
            if template_path == "__empty__":
                content = ""
            else:
                content = self.renderer.render(template_path, **context)

            file_path = self.project_path / file_path_str
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            print(f"  ✓ 创建文件: {file_path_str}")

        # Make shell scripts executable
        scripts_dir = self.project_path / "scripts"
        if scripts_dir.exists():
            for sh_file in scripts_dir.glob("*.sh"):
                sh_file.chmod(0o755)


def create_project(
    project_name: str,
    target_dir: str | None = None,
    project_type: str = "full",
    description: str | None = None,
):
    """Convenience function to create a project."""
    scaffold = ProjectScaffold(project_name, target_dir, project_type, description)
    scaffold.create()
