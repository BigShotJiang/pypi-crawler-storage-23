"""
Jinja2 template renderer

Unified rendering engine for project scaffolding and module generation.
"""

import re
from pathlib import Path

from jinja2 import Environment, FileSystemLoader


def _to_snake_case(name: str) -> str:
    """Convert camelCase or PascalCase to snake_case."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    result = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
    return result.replace("-", "_")


def _to_camel_case(name: str) -> str:
    """Convert snake_case to PascalCase (CamelCase)."""
    return "".join(x.title() for x in name.split("_"))


class TemplateRenderer:
    """Jinja2-based template renderer."""

    def __init__(self, templates_dir: Path | None = None):
        if templates_dir is None:
            templates_dir = Path(__file__).parent / "templates"
        self.templates_dir = templates_dir
        self.env = Environment(
            loader=FileSystemLoader(str(templates_dir)),
            keep_trailing_newline=True,
            lstrip_blocks=True,
            trim_blocks=True,
        )
        self.env.filters["snake_case"] = _to_snake_case
        self.env.filters["camel_case"] = _to_camel_case
        self.env.filters["pascal_case"] = _to_camel_case

    def render(self, template_path: str, **context) -> str:
        """Render a template file with the given context."""
        template = self.env.get_template(template_path)
        return template.render(**context)

    def render_string(self, template_str: str, **context) -> str:
        """Render a template string with the given context."""
        template = self.env.from_string(template_str)
        return template.render(**context)

    @staticmethod
    def get_name_variants(name: str) -> dict[str, str]:
        """Return snake_case and PascalCase variants of a name."""
        snake = _to_snake_case(name)
        camel = _to_camel_case(snake)
        return {
            "name": name,
            "snake_name": snake,
            "camel_name": camel,
        }
