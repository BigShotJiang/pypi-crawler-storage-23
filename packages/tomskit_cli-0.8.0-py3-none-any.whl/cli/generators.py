"""
Component generators for modules, tasks, extensions, and services.
"""

from pathlib import Path

from .renderer import TemplateRenderer


class ModuleGenerator:
    """Generate a full module (model + service + controller)."""

    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.renderer = TemplateRenderer()

    def create_module(self, name: str) -> None:
        """Create a complete module."""
        context = self.renderer.get_name_variants(name)
        snake_name = context["snake_name"]
        camel_name = context["camel_name"]

        print(f"Creating module: {name}")

        # Create directories
        (self.project_root / "app" / "models").mkdir(parents=True, exist_ok=True)
        (self.project_root / "app" / "controllers" / snake_name).mkdir(parents=True, exist_ok=True)
        (self.project_root / "app" / "services" / snake_name).mkdir(parents=True, exist_ok=True)

        # Model
        content = self.renderer.render("module/model.py.j2", **context)
        (self.project_root / "app" / "models" / f"{snake_name}.py").write_text(content, encoding="utf-8")
        print(f"  ✓ Created model: app/models/{snake_name}.py")

        # Service __init__.py
        content = self.renderer.render("service/__init__.py.j2", **context)
        (self.project_root / "app" / "services" / snake_name / "__init__.py").write_text(content, encoding="utf-8")

        # Service service.py
        content = self.renderer.render("service/service.py.j2", **context)
        (self.project_root / "app" / "services" / snake_name / "service.py").write_text(content, encoding="utf-8")
        print(f"  ✓ Created service: app/services/{snake_name}/")

        # Controller __init__.py
        content = self.renderer.render("module/__init__.py.j2", **context)
        (self.project_root / "app" / "controllers" / snake_name / "__init__.py").write_text(content, encoding="utf-8")

        # Controller resources.py
        content = self.renderer.render("module/resources.py.j2", **context)
        (self.project_root / "app" / "controllers" / snake_name / "resources.py").write_text(content, encoding="utf-8")
        print(f"  ✓ Created controller: app/controllers/{snake_name}/")

        # Controller module.py
        content = self.renderer.render("module/module.py.j2", **context)
        (self.project_root / "app" / "controllers" / snake_name / "module.py").write_text(content, encoding="utf-8")
        print(f"  ✓ Created module config: app/controllers/{snake_name}/module.py")

        # Controller schemas.py
        content = self.renderer.render("module/schemas.py.j2", **context)
        (self.project_root / "app" / "controllers" / snake_name / "schemas.py").write_text(content, encoding="utf-8")
        print(f"  ✓ Created schemas: app/controllers/{snake_name}/schemas.py")

        # Auto-update ext_modules.py
        ext_modules_updated = self._update_ext_modules(snake_name)

        # Auto-update models/__init__.py
        models_init_updated = self._update_models_init(snake_name, camel_name)

        print(f"\n✓ Module '{name}' created successfully!")

        if ext_modules_updated:
            print("  ✓ Updated extensions/ext_modules.py")
        else:
            print("\n⚠️  请手动在 extensions/ext_modules.py 中注册模块:")
            print(f"     from app.controllers.{snake_name}.module import init_{snake_name}_module")
            print(f"     init_{snake_name}_module(app)")

        if models_init_updated:
            print("  ✓ Updated app/models/__init__.py")
        else:
            print(f"\n⚠️  请手动在 app/models/__init__.py 中导入模型:")
            print(f"     from .{snake_name} import {camel_name}  # noqa: F401")

        print(f"\nNext steps:")
        print(f"  1. Create a migration: uv run alembic -c migrations/alembic.ini revision --autogenerate -m 'Add {snake_name} table'")
        print("  2. Apply migrations: uv run alembic -c migrations/alembic.ini upgrade head")

    def _update_ext_modules(self, snake_name: str) -> bool:
        """Update ext_modules.py with marker-based injection."""
        ext_modules_file = self.project_root / "extensions" / "ext_modules.py"

        if not ext_modules_file.exists():
            return False

        content = ext_modules_file.read_text(encoding="utf-8")

        import_line = f"from app.controllers.{snake_name}.module import init_{snake_name}_module"
        init_line = f"init_{snake_name}_module(app)"

        # Check if already registered
        for line in content.split("\n"):
            stripped = line.strip()
            if not stripped.startswith("#") and import_line in stripped:
                return True

        # Try marker-based injection
        import_marker = "# --- MODULE IMPORTS ---"
        import_end_marker = "# --- END MODULE IMPORTS ---"
        init_marker = "# --- MODULE INIT ---"
        init_end_marker = "# --- END MODULE INIT ---"

        if import_marker in content and init_marker in content:
            # Detect indentation of the marker lines
            for line in content.split("\n"):
                if import_end_marker in line:
                    import_indent = line[:len(line) - len(line.lstrip())]
                    break
            else:
                import_indent = "    "

            for line in content.split("\n"):
                if init_end_marker in line:
                    init_indent = line[:len(line) - len(line.lstrip())]
                    break
            else:
                init_indent = "    "

            # Insert import before end marker
            content = content.replace(
                import_indent + import_end_marker,
                f"{import_indent}{import_line}\n{import_indent}{import_end_marker}",
            )
            # Insert init call before end marker
            content = content.replace(
                init_indent + init_end_marker,
                f"{init_indent}{init_line}\n{init_indent}{init_end_marker}",
            )
            # Remove 'pass' if present after init marker
            lines = content.split("\n")
            new_lines = []
            for line in lines:
                # Skip standalone 'pass' that appears between markers
                if line.strip() == "pass":
                    # Check if there's actual init code now
                    if init_line in content:
                        continue
                new_lines.append(line)
            content = "\n".join(new_lines)

            ext_modules_file.write_text(content, encoding="utf-8")
            return True

        # Fallback: try old-style injection (find pass or existing calls)
        lines = content.split("\n")
        new_lines = []
        import_inserted = False
        init_inserted = False
        in_init_app = False

        for line in lines:
            if "def init_app(" in line:
                in_init_app = True

            # Strategy 1: Insert after existing imports
            if not import_inserted and line.strip().startswith("from app.controllers.") and "import init_" in line:
                new_lines.append(line)
                new_lines.append(f"    {import_line}")
                import_inserted = True
                continue

            # Strategy 2: Insert after existing init calls
            if not init_inserted and line.strip().startswith("init_") and line.strip().endswith("_module(app)"):
                new_lines.append(line)
                new_lines.append(f"    {init_line}")
                init_inserted = True
                continue

            # Strategy 3: Replace pass in init_app
            if in_init_app and line.strip() == "pass" and not import_inserted:
                indent = len(line) - len(line.lstrip())
                indent_str = " " * indent
                new_lines.append(f"{indent_str}{import_line}")
                new_lines.append(f"{indent_str}{init_line}")
                import_inserted = True
                init_inserted = True
                continue

            new_lines.append(line)

        if import_inserted and init_inserted:
            ext_modules_file.write_text("\n".join(new_lines), encoding="utf-8")
            return True

        return False

    def _update_models_init(self, snake_name: str, camel_name: str) -> bool:
        """Update app/models/__init__.py with marker-based injection."""
        models_init_file = self.project_root / "app" / "models" / "__init__.py"

        if not models_init_file.exists():
            return False

        content = models_init_file.read_text(encoding="utf-8")

        import_line = f"from .{snake_name} import {camel_name}  # noqa: F401"

        # Check if already imported
        if f"from .{snake_name} import" in content:
            return True

        import_marker = "# --- MODEL IMPORTS ---"
        import_end_marker = "# --- END MODEL IMPORTS ---"

        if import_marker in content:
            content = content.replace(
                import_end_marker,
                f"{import_line}\n{import_end_marker}",
            )
            models_init_file.write_text(content, encoding="utf-8")
            return True

        return False


class TaskGenerator:
    """Generate a Celery task."""

    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.renderer = TemplateRenderer()

    def create_task(self, name: str) -> None:
        """Create a Celery task."""
        context = self.renderer.get_name_variants(name)
        snake_name = context["snake_name"]

        print(f"Creating task: {name}")

        (self.project_root / "tasks").mkdir(parents=True, exist_ok=True)

        content = self.renderer.render("task/task.py.j2", **context)
        (self.project_root / "tasks" / f"{snake_name}_task.py").write_text(content, encoding="utf-8")

        print(f"✓ Task '{name}' created successfully!")
        print(f"\nTo use this task:")
        print(f"  from tasks.{snake_name}_task import {snake_name}")
        print(f"  {snake_name}.delay(message='hello')  # 异步执行")


class ExtensionGenerator:
    """Generate a FastAPI extension."""

    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.renderer = TemplateRenderer()

    def create_extension(self, name: str) -> None:
        """Create a FastAPI extension."""
        context = self.renderer.get_name_variants(name)
        snake_name = context["snake_name"]

        print(f"Creating extension: {name}")

        (self.project_root / "extensions").mkdir(parents=True, exist_ok=True)

        content = self.renderer.render("extension/extension.py.j2", **context)
        (self.project_root / "extensions" / f"ext_{snake_name}.py").write_text(content, encoding="utf-8")

        print(f"✓ Extension '{name}' created successfully!")
        print("\nTo use this extension:")
        print("  1. Import it in app_factory.py:")
        print(f"     from extensions import ext_{snake_name}")
        print("  2. Add it to the extensions list in initialize_extensions()")


class ServiceGenerator:
    """Generate a standalone service."""

    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.renderer = TemplateRenderer()

    def create_service(self, name: str) -> None:
        """Create a service."""
        context = self.renderer.get_name_variants(name)
        snake_name = context["snake_name"]

        print(f"Creating service: {name}")

        service_dir = self.project_root / "app" / "services" / snake_name
        service_dir.mkdir(parents=True, exist_ok=True)

        # Service __init__.py
        content = self.renderer.render("service/__init__.py.j2", **context)
        (service_dir / "__init__.py").write_text(content, encoding="utf-8")

        # Service service.py
        content = self.renderer.render("service/service.py.j2", **context)
        (service_dir / "service.py").write_text(content, encoding="utf-8")

        print(f"✓ Service '{name}' created successfully!")
        print(f"\nTo use this service:")
        print(f"  from app.services.{snake_name} import {context['camel_name']}Service")
