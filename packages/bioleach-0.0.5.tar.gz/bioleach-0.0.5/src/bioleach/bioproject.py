# Imports ======================================================================

from bioleach.env import (
    BIOLEACH_BIOPROJECT_ACCESSION,
    BIOLEACH_STUDY_ACCESSION,
    BIOLEACH_STUDY_TITLE,
    BIOLEACH_ABSTRACT
)

# Constants ====================================================================

BIOLEACH_BIOPROJECT = (
    BIOLEACH_BIOPROJECT_ACCESSION,
    BIOLEACH_STUDY_ACCESSION,
    BIOLEACH_STUDY_TITLE,
    BIOLEACH_ABSTRACT
)
