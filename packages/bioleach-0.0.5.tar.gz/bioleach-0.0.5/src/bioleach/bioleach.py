#===============================================================================
# bioleach.py
#===============================================================================

# Imports ======================================================================

from argparse import ArgumentParser
from functools import partial
from math import floor
from multiprocessing import Pool
import os
import os.path
import pandas as pd
from sqlalchemy import text
import sys
from bioleach.version import __version__
from bioleach.env import (
    BIOLEACH_SOURCE_DB_FILE,
    BIOLEACH_PIPELINE_DB_FILE,
    BIOLEACH_DATA_DIR,
    BIOLEACH_READS_DIR,
    BIOLEACH_TRIM_ALGORITHM,
    BIOLEACH_REMOVE_CONTAM_ALGORITHM,
    BIOLEACH_CONTIGS_DIR,
    BIOLEACH_ALIGNMENTS_DIR,
    BIOLEACH_GENES_DIR
)
from bioleach.bioproject import BIOLEACH_BIOPROJECT
from bioleach.database import (
    fetch_sra_metadata,
    load_organisms_metadata,
    dialect_agnostic_engine,
    create_source_database,
    create_pipeline_database
)
from bioleach.download import (
    download_sra_reads,
    clean_up_sra_reads
)
from bioleach.trim import trim_adapters_quality
from bioleach.remove_contaminants import remove_contaminants
from bioleach.assemble_contigs import (
    assemble_contigs_megahit,
    collect_contig_lengths,
    plot_contig_lengths,
    map_to_contigs_bowtie2,
    calculate_coverage
)
from bioleach.predict import predict_genes


# Functions ====================================================================

def _create_source_database(args):
    bioproject_columns, biosample_columns, bioleach_biosamples = fetch_sra_metadata()
    organisms_metadata, organisms = load_organisms_metadata()
    create_source_database(
        bioproject_columns,
        biosample_columns,
        tuple(organisms_metadata.columns),
        BIOLEACH_BIOPROJECT,
        bioleach_biosamples,
        organisms,
        dialect='mysql' if args.mysql else 'sqlite',
        database=args.database
    )


def _create_pipeline_database(args):
    engine_source = dialect_agnostic_engine(
        dialect='mysql' if args.mysql else 'sqlite',
        database=args.source_db
    )
    create_pipeline_database(
        engine_source,
        accessions=args.accessions,
        dialect='mysql' if args.mysql else 'sqlite',
        database=args.database
    )


def _export_database(args):
    if args.source:
        database = BIOLEACH_SOURCE_DB_FILE
    elif args.pipeline:
        database = BIOLEACH_PIPELINE_DB_FILE
    else:
        database = args.database
    engine = dialect_agnostic_engine(
        dialect='mysql' if args.mysql else 'sqlite',
        database=database
    )
    df = pd.read_sql(f"SELECT * FROM {args.table}", engine)
    df.to_csv(args.out, sep=(',' if repr(args.out).endswith('.csv') else '\t'), index=False)


def _download_sra_reads(args):
    engine = dialect_agnostic_engine(dialect='mysql' if args.mysql else 'sqlite', database=args.pipeline_db)
    download_sra_reads(engine)


def _clean_up(args):
    clean_up_sra_reads(args.directory)
    if args.sqlite:
        if os.path.exists(args.source_db):
            os.remove(os.path.join(args.source_db))
        if os.path.exists(args.pipeline_db):
            os.remove(os.path.join(args.pipeline_db))
    if args.mysql:
        engine_source = dialect_agnostic_engine(dialect='mysql', database=args.source_db)
        engine_pipeline = dialect_agnostic_engine(dialect='mysql', database=args.pipeline_db)
        with engine_source.connect() as conn_source, engine_pipeline.connect() as conn_pipeline:
            conn_pipeline.execute(text(f'DROP DATABASE {args.pipeline_db}'))
            conn_pipeline.commit()
            conn_source.execute(text(f'DROP DATABASE {args.source_db}'))
            conn_source.commit()


def _trim(
    fastq_prefix,
    output_dir = BIOLEACH_READS_DIR,
    algorithm: str = 'fastp',
    threads: int = 1
):
    trim_adapters_quality(
        f'{fastq_prefix}_1.fastq',
        f'{fastq_prefix}_2.fastq',
        output_dir=output_dir,
        algorithm=algorithm,
        threads=threads
    )
    return os.path.isfile(f'{fastq_prefix}_1_val_1.fq') and os.path.isfile(f'{fastq_prefix}_2_val_2.fq')


def _remove_contaminants(
    fastq_prefix,
    output_dir = BIOLEACH_READS_DIR,
    algorithm: str = 'kraken2',
    threads: int = 1
):
    remove_contaminants(
        f'{fastq_prefix}_1_val_1.fq',
        f'{fastq_prefix}_2_val_2.fq',
        output_dir=output_dir,
        algorithm=algorithm,
        threads=threads
    )
    return os.path.isfile(f'{fastq_prefix}_clean_1.fq') and os.path.isfile(f'{fastq_prefix}_clean_2.fq')

def mark_complete(run_accession, column, conn):
    conn.execute(text(f"""
        UPDATE pipeline_accessions
        SET {column} = 1
        WHERE run_accession = '{run_accession}'
    """))


def construct_read_preprocessing_func(func, db_column, prev_fastq_suffix=None):
    def read_preprocessing_func(args):
        engine = dialect_agnostic_engine(
            dialect='mysql' if args.mysql else 'sqlite', database=args.database
        )
        with engine.connect() as conn:
            fastq_prefixes, run_accessions = zip(
                *((row.fastq_prefix, row.run_accession) for row in conn.execute(text("SELECT fastq_prefix, run_accession FROM pipeline_accessions")))
            )
            if args.parallel:
                with Pool(processes=min(args.processes, len(fastq_prefixes))) as pool:
                    results = pool.map(
                        partial(
                            func, algorithm=args.algorithm,
                            threads=max(1, floor(args.processes / len(fastq_prefixes)))
                        ),
                        fastq_prefixes
                    )
                for completed, run_accession, fastq_prefix in zip(results, run_accessions, fastq_prefixes):
                    if completed:
                        mark_complete(run_accession, db_column, conn)
                        if prev_fastq_suffix:
                            os.remove(fastq_prefix + prev_fastq_suffix.format(1))
                            os.remove(fastq_prefix + prev_fastq_suffix.format(2))
            else:
                for fastq_prefix, run_accession in zip(fastq_prefixes, run_accessions):
                    completed = func(fastq_prefix, algorithm=args.algorithm, threads=args.processes)
                    if completed:
                        mark_complete(run_accession, db_column, conn)
                        if prev_fastq_suffix:
                            os.remove(fastq_prefix + prev_fastq_suffix.format(1))
                            os.remove(fastq_prefix + prev_fastq_suffix.format(2))
            conn.commit()
    return read_preprocessing_func


def assemble_contigs(
    fastq_prefix,
    contigs_dir = BIOLEACH_CONTIGS_DIR,
    alignments_dir = BIOLEACH_ALIGNMENTS_DIR,
    threads: int = 1
):
    if not os.path.isdir(contigs_dir):
        os.mkdir(contigs_dir)
    if not os.path.isdir(alignments_dir):
        os.mkdir(alignments_dir)
    contig_prefix = os.path.join(contigs_dir, os.path.basename(fastq_prefix))
    alignment_prefix = os.path.join(alignments_dir, os.path.basename(fastq_prefix))
    assemble_contigs_megahit(
        f'{fastq_prefix}_clean_1.fq',
        f'{fastq_prefix}_clean_2.fq',
        output_prefix=contig_prefix,
        threads=threads
    )
    contig_lengths = collect_contig_lengths(f'{contig_prefix}.contigs.fa')
    plot_contig_lengths(contig_lengths, contig_prefix)
    map_to_contigs_bowtie2(
        f'{contig_prefix}.contigs.fa',
        f'{fastq_prefix}_clean_1.fq',
        f'{fastq_prefix}_clean_2.fq',
        f'{alignment_prefix}.bam',
        threads=threads
    )
    calculate_coverage(f'{alignment_prefix}.bam').to_csv(
        f'{alignment_prefix}.idxstats', sep='\t'
    )
    return os.path.isfile(f'{alignment_prefix}.idxstats')


def _assemble_contigs(args):
    engine = dialect_agnostic_engine(
        dialect='mysql' if args.mysql else 'sqlite', database=args.database
    )
    with engine.connect() as conn:
        fastq_prefixes, run_accessions = zip(
            *((row.fastq_prefix, row.run_accession) for row in conn.execute(text("SELECT fastq_prefix, run_accession FROM pipeline_accessions")))
        )
        for fastq_prefix, run_accession in zip(fastq_prefixes, run_accessions):
            completed = assemble_contigs(fastq_prefix, threads=args.processes)
            if completed:
                mark_complete(run_accession, 'assembled_contigs', conn)
                os.remove(fastq_prefix + '_clean_{}.fq'.format(1))
                os.remove(fastq_prefix + '_clean_{}.fq'.format(2))


def _predict_genes(args):
    if not os.path.isdir(args.genes_dir):
        os.mkdir(args.genes_dir)
    engine = dialect_agnostic_engine(
        dialect='mysql' if args.mysql else 'sqlite', database=args.database
    )
    with engine.connect() as conn:
        run_accessions = tuple(
            row.run_accession for row in conn.execute(text("SELECT run_accession FROM pipeline_accessions"))
        )
        if args.processes:
            with Pool(processes=min(args.processes, len(run_accessions))) as pool:
                results = pool.map(
                    partial(
                        predict_genes,
                        contigs_dir=args.contigs_dir,
                        genes_dir=args.genes_dir
                    ),
                    run_accessions
                )
            for completed, run_accession in zip(results, run_accessions):
                if completed:
                    mark_complete(run_accession, 'predicted_genes', conn)
        else:
            for run_accession in run_accessions:
                completed = predict_genes(
                    run_accession,
                    args.contigs_dir,
                    args.genes_dir
                )
                if completed:
                    mark_complete(run_accession, 'predicted_genes', conn)


def _data_dir(args):
    print(BIOLEACH_DATA_DIR)


def parse_arguments():
    parser = ArgumentParser(description='Bioinformatics analysis of a bioleaching microbial community')
    parser.add_argument('--version', action='version',
        version='%(prog)s {version}'.format(version=__version__))
    parser.set_defaults(func=lambda _: parser.print_help(sys.stdout))
    subparsers = parser.add_subparsers()

    # create-source-db
    parser_create_source_db = subparsers.add_parser(
        'create-source-db', help='create source database'
    )
    parser_create_source_db.set_defaults(func=_create_source_database)
    parser_create_source_db.add_argument(
        '-d', '--database', metavar='<database[.db]>', default=BIOLEACH_SOURCE_DB_FILE,
        help=f'path to sqlite database file, or name of mysql database (default: {BIOLEACH_SOURCE_DB_FILE})'
    )
    parser_create_source_db.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # create-pipeline-db
    parser_create_pipeline_db = subparsers.add_parser(
        'create-pipeline-db', help='create pipeline database'
    )
    parser_create_pipeline_db.set_defaults(func=_create_pipeline_database)
    parser_create_pipeline_db.add_argument(
        '-d', '--database', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or name of mysql pipeline database (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_create_pipeline_db.add_argument(
        '-s', '--source-db', metavar='<database[.db]>', default=BIOLEACH_SOURCE_DB_FILE,
        help=f'path to sqlite source database file, or name of mysql source database (default: {BIOLEACH_SOURCE_DB_FILE})'
    )
    parser_create_pipeline_db.add_argument(
        '-a', '--accessions', metavar='<SRRX>', nargs='*', default=[],
        help='SRA accessions to include in pipeline'
    )
    parser_create_pipeline_db.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # export-db
    parser_export_db = subparsers.add_parser('export-db', help='export database')
    parser_export_db.set_defaults(func=_export_database)
    parser_export_db.add_argument(
        'table', metavar='<table>', help='name of table to export'
    )
    db_select_group = parser_export_db.add_mutually_exclusive_group(required=True)
    db_select_group.add_argument(
        '-s', '--source', action='store_true', help='export the source db'
    )
    db_select_group.add_argument(
        '-p', '--pipeline', action='store_true', help='export the pipeline db'
    )
    db_select_group.add_argument(
        '-d', '--database', metavar='<database[.db]>',
        help='path to sqlite database file or mysql database name'
    )
    parser_export_db.add_argument(
        '-o', '--out', metavar='<path/to/file.{csv,tsv}', default=sys.stdout,
        help='path to output file'
    )
    parser_export_db.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # download
    parser_download = subparsers.add_parser('download', help='download SRA reads')
    parser_download.set_defaults(func=_download_sra_reads)
    parser_download.add_argument(
        '--pipeline-db', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_download.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # trim and preprocess
    parser_trim = subparsers.add_parser(
        'trim', help='trim Illumina adapters and low-quality bases'
    )
    parser_trim.set_defaults(func=construct_read_preprocessing_func(_trim, 'trimmed'))
    parser_trim.add_argument(
        '--database', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_trim.add_argument(
        '--output-dir', metavar='<output_dir/>', default=BIOLEACH_READS_DIR,
        help=f'destination directory for trimmed reads (default: {BIOLEACH_READS_DIR})'
    )
    parser_trim.add_argument(
        '--algorithm', choices=('fastp', 'bbtools', 'trim-galore', 'trimmomatic'), default=BIOLEACH_TRIM_ALGORITHM,
        help=f'choose algorithm for adapter and quality trimming (default: {BIOLEACH_TRIM_ALGORITHM})'
    )
    parser_trim.add_argument(
        '--processes', type=int, default=1,
        help='number of processes for adapter and quality trimming (default: 1)'
    )
    parser_trim.add_argument(
        '--parallel', action='store_true',
        help='trim multiple sequencing datasets in parallel'
    )
    parser_trim.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )
    
    # remove contaminants
    parser_remove_contaminants = subparsers.add_parser(
        'remove-contam', help='remove contaminant reads'
    )
    parser_remove_contaminants.set_defaults(
        func=construct_read_preprocessing_func(
            _remove_contaminants,
            'removed_contaminants',
            prev_fastq_suffix='_{0}_val_{0}.fq'
        )
    )
    parser_remove_contaminants.add_argument(
        '--database', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_remove_contaminants.add_argument(
        '--output-dir', metavar='<output_dir/>', default=BIOLEACH_READS_DIR,
        help=f'destination directory for decontaminated reads (default: {BIOLEACH_READS_DIR})'
    )
    parser_remove_contaminants.add_argument(
        '--algorithm', choices=('kraken2', 'bbtools', 'bowtie2', 'bwa', 'minimap2'),
        default=BIOLEACH_REMOVE_CONTAM_ALGORITHM,
        help=f'choose algorithm for contaminant removal (default: {BIOLEACH_REMOVE_CONTAM_ALGORITHM})'
    )
    parser_remove_contaminants.add_argument(
        '--processes', type=int, default=1,
        help='number of processes for contaminant removal (default: 1)'
    )
    parser_remove_contaminants.add_argument(
        '--parallel', action='store_true',
        help='decontaminate multiple sequencing datasets in parallel'
    )
    parser_remove_contaminants.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # assemble contigs
    parser_assemble_contigs = subparsers.add_parser(
        'assemble',
        help='assemble metagenome contigs'
    )
    parser_assemble_contigs.set_defaults(func=_assemble_contigs)
    parser_assemble_contigs.add_argument(
        '--database', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_assemble_contigs.add_argument(
        '--contigs-dir', metavar='<contigs_dir/>', default=BIOLEACH_CONTIGS_DIR,
        help=f'destination directory for assembled contigs (default: {BIOLEACH_CONTIGS_DIR})'
    )
    parser_assemble_contigs.add_argument(
        '--alignments-dir', metavar='<alignments_dir/>', default=BIOLEACH_ALIGNMENTS_DIR,
        help=f'destination directory for BAM files (default: {BIOLEACH_ALIGNMENTS_DIR})'
    )
    parser_assemble_contigs.add_argument(
        '--processes', type=int, default=1,
        help='number of processes for contig assembly (default: 1)'
    )
    parser_assemble_contigs.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # assemble contigs
    parser_predict_genes = subparsers.add_parser(
        'predict',
        help='predict genes'
    )
    parser_predict_genes.set_defaults(func=_predict_genes)
    parser_predict_genes.add_argument(
        '--database', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )
    parser_predict_genes.add_argument(
        '--contigs-dir', metavar='<contigs_dir/>', default=BIOLEACH_CONTIGS_DIR,
        help=f'destination directory for assembled contigs (default: {BIOLEACH_CONTIGS_DIR})'
    )
    parser_predict_genes.add_argument(
        '--genes-dir', metavar='<genes_dir/>', default=BIOLEACH_GENES_DIR,
        help=f'destination directory for BAM files (default: {BIOLEACH_GENES_DIR})'
    )
    parser_predict_genes.add_argument(
        '--processes', type=int, default=None,
        help='number of processes for gene prediction (default: 1)'
    )
    parser_predict_genes.add_argument(
        '-m', '--mysql', action='store_true',
        help='use a configured mysql database, requires that environment variables be set'
    )

    # clean up
    parser_clean = subparsers.add_parser('clean', help='clean up SRA reads')
    parser_clean.set_defaults(func=_clean_up)
    parser_clean.add_argument(
        '--directory', metavar='<directory/>',
        default=BIOLEACH_READS_DIR,
        help=f'directory containing downloaded SRA reads (default: {BIOLEACH_READS_DIR})'
    )
    parser_dialect_group = parser_clean.add_mutually_exclusive_group()
    parser_dialect_group.add_argument(
        '-s', '--sqlite', action='store_true',
        help='clean up a configured sqlite database'
    )
    parser_dialect_group.add_argument(
        '-m', '--mysql', action='store_true',
        help='clean up a configured mysql database, requires that environment variables be set'
    )
    parser_clean.add_argument(
        '--source-db', metavar='<database[.db]>', default=BIOLEACH_SOURCE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_SOURCE_DB_FILE})'
    )
    parser_clean.add_argument(
        '--pipeline-db', metavar='<database[.db]>', default=BIOLEACH_PIPELINE_DB_FILE,
        help=f'path to sqlite pipeline database file, or mysql pipeline database name (default: {BIOLEACH_PIPELINE_DB_FILE})'
    )

    # data directory
    parser_data_dir = subparsers.add_parser(
        'data-dir', help='show the currently configured data directory'
    )
    parser_data_dir.set_defaults(func=_data_dir)
    return parser.parse_args()


def main():
    args = parse_arguments()
    args.func(args)


# Execute ======================================================================

if __name__ == '__main__':
    main()
