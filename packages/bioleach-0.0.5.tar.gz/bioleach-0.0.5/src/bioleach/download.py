# Imports ======================================================================

import os
import os.path
import shutil
import ftplib
from sqlalchemy import text
from subprocess import run
from bioleach.env import (
    BIOLEACH_READS_DIR,
    BIOLEACH_PHIX_FTP,
    BIOLEACH_PHIX_FTP_PATH,
    BIOLEACH_PHIX
)


# Functions ====================================================================

def download_sra_reads(engine):
    """Download reads from SRA using fastq-dump

    Parameters
    ----------
    engine_pipeline
        SQL database engine
    """

    with engine.connect() as conn:
        for row in conn.execute(
            text("SELECT run_accession, fastq_prefix FROM pipeline_accessions")
        ):
            run(('fasterq-dump', '--outdir', os.path.dirname(row.fastq_prefix), row.run_accession))


def clean_up_sra_reads(
    reads_dir=BIOLEACH_READS_DIR
):
    """Clean up reads that were downloaded from SRA

    Parameters
    ----------
    reads_dir
        directory containing downloaded reads
    """

    if os.path.exists(reads_dir):
        shutil.rmtree(reads_dir)


def download_phix(
        phix_ftp: str = BIOLEACH_PHIX_FTP,
        phix_ftp_path: str = BIOLEACH_PHIX_FTP_PATH,
        phix_fasta = BIOLEACH_PHIX
):
    """Download the phix sequence fasta file

    Parameters
    ----------
    phix_ftp
        ftp server
    phix_ftp_path
        file path on ftp server
    phix_fasta
        destination for phix fasta file
    """

    ftp = ftplib.FTP(phix_ftp)
    ftp.login()
    with open(phix_fasta, "wb") as f:
        ftp.retrbinary(f"RETR {phix_ftp_path}", f.write)
