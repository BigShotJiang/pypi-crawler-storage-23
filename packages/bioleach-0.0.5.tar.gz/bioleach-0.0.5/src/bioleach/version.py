__version__ = '0.0.5' # Don't forget to match with pyproject.toml and docs/source/conf.py
