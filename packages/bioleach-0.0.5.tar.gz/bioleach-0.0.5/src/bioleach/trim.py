import os.path
from shutil import which
from subprocess import run
from tempfile import TemporaryDirectory
from bioleach.env import BIOLEACH_READS_DIR


def trim_adapters_dedup_fastp(
        fastq_in_1, fastq_in_2,
        fastq_out_1, fastq_out_2,
        report_prefix,
        threads: int = 1
    ):
    """Use fastp to trim adapters and low-quality bases, and deduplicate reads

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq output files
    fastq_out_1, fastq_out_2
        paired-end fastq output files
    threads : int
        number of threads for parallel processing
    """

    if not which('fastp'):
        raise RuntimeError('fastp not found')
    with TemporaryDirectory(dir=BIOLEACH_READS_DIR) as temp_dir:
        run((
            'fastp', '--thread', str(threads),
            '--dedup', '--cut_tail',
            '--json', f'{report_prefix}_fastp_post_dedup.json',
            '--html', f'{report_prefix}_fastp_post_dedup.html',
            '-i', fastq_in_1,
            '-I', fastq_in_2,
            '-o', os.path.join(temp_dir, os.path.basename(fastq_out_1)),
            '-O', os.path.join(temp_dir, os.path.basename(fastq_out_2))
        ))
        run((
            'fastp', '--thread', str(threads),
            '--dont_eval_duplication', '--cut_front', '--cut_right',
            '--json', f'{report_prefix}_fastp_post_trim.json',
            '--html', f'{report_prefix}_fastp_post_trim.html',
            '-i', os.path.join(temp_dir, os.path.basename(fastq_out_1)),
            '-I', os.path.join(temp_dir, os.path.basename(fastq_out_2)),
            '-o', fastq_out_1,
            '-O', fastq_out_2
        ))


def trim_adapters_bbtools(in1, in2, out1, out2, threads: int = 1):
    """Use BBtools to trim adapters

    Parameters
    ----------
    in1, in2
        paired-end fastq input files
    out1, out2
        paried-end fastq output files
    """

    if not which('bbduk.sh'):
        raise RuntimeError('bbtools not found')
    run((
        'bbduk.sh',
        f'in1={in1}',
        f'in2={in2}',
        f'out1={out1}',
        f'out2={out2}',
        f'threads={threads}',
        'ref=adapters',
        'ktrim=r',
        'k=23',
        'mink=11',
        'hdist=1',
        'tpe',
        'tbo'
    ))


def trim_adapters_trim_galore(fastq_in_1, fastq_in_2, output_dir, cores: int = 1):
    """Use trim-galore to trim adapters and low-quality bases

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    output_dir
        output directory
    cores : int
        number of cores to use for adapter trimming
    """

    if not which('trim_galore'):
        raise RuntimeError('trim_galore not found')
    run((
        'trim_galore',
        '--paired',
        '--fastqc',
        '--output_dir', output_dir,
        '--cores', str(cores),
        fastq_in_1,
        fastq_in_2
    ))


def trim_adapters_trimmomatic(
        fastq_in_1,
        fastq_in_2,
        fastq_out_1_paired,
        fastq_out_1_unpaired,
        fastq_out_2_paired,
        fastq_out_2_unpaired,
        threads: int = 1
    ):
    """Use trimmomatic to trim adapters and low-quality bases

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1_paired,
        path to output fastq file (paired reads)
    fastq_out_1_unpaired,
        path to output fastq file (unpaired reads)
    fastq_out_2_paired,
        path to output fastq file (paired reads)
    fastq_out_2_unpaired,
        path to output fastq file (unpaired reads)
    threads : int
        number of threads for parallel processing
    """

    if not which('trimmomatic'):
        raise RuntimeError('trimmomatic not found')
    run((
        'trimmomatic', 'PE', '-threads', str(threads),
        fastq_in_1, fastq_in_2,
        fastq_out_1_paired,
        fastq_out_1_unpaired,
        fastq_out_2_paired,
        fastq_out_2_unpaired,
        'ILLUMINACLIP:TruSeq3-PE.fa:2:30:10:2:True',
        'LEADING:3',
        'TRAILING:3',
        'MINLEN:36'
    ))


def trim_adapters_quality(
        fastq_1,
        fastq_2,
        output_dir=BIOLEACH_READS_DIR,
        algorithm: str = 'fastp',
        threads: int = 1
):
    """Use one of the available algorithms to trim adapters and low-quality bases

    Parameters
    ----------
    fastq_1, fastq_2
        paired-end fastq input files
    output_dir
        output directory
    algorithm : str
        algorithm for adapter trimming, 'fastp', 'bbtools', 'trim-galore', or 'trimmomatic'
    threads : int
        number of cores to use for adapter trimming
    """

    if algorithm == 'fastp':
        trim_adapters_dedup_fastp(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, os.path.basename(fastq_1)[:-8]),
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            threads=threads
        )
    elif algorithm == 'bbtools':
        trim_adapters_bbtools(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            threads=threads
        )
    elif algorithm == 'trim-galore':
        trim_adapters_trim_galore(
                fastq_1,
                fastq_2,
                output_dir=output_dir,
                cores=threads
            )
    elif algorithm == 'trimmomatic':
        trim_adapters_trimmomatic(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1U.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2U.fq'),
            threads=threads
        )
    else:
        raise ValueError(f'Algorithm {algorithm} not available.')

