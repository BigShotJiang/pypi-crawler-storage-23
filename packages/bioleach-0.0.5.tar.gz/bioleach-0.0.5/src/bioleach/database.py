# Imports ======================================================================

import os
import os.path
import pandas as pd
from pysradb.sraweb import SRAweb
import mysql.connector
from sqlalchemy import create_engine, text
from bioleach.env import (
    BIOLEACH_STUDY_ACCESSION,
    BIOLEACH_READS_DIR,
    BIOLEACH_ORGANISMS_META,
    BIOLEACH_ORGANISMS_DIR,
    BIOLEACH_MYSQL_HOST,
    BIOLEACH_MYSQL_USER,
    BIOLEACH_MYSQL_PORT,
    BIOLEACH_MYSQL_PASSWORD
)


# Functions ====================================================================

def fetch_sra_metadata(study_accession: str = BIOLEACH_STUDY_ACCESSION):
    """Fetch metadata about a bioproject / study from SRA

    Parameters
    ----------
    study_acession : str
        Study (SRP) or bioproject (PRJ) accession value

    Returns
    -------
    tuple
        bioproject_columns, biosample_columns, biosamples
    """

    client = SRAweb()
    metadata = client.sra_metadata(study_accession)
    bioproject_columns = (
        'bioproject_accession',
        'study_accession',
        'study_title',
        'abstract'
    )
    biosample_columns = tuple((
        'biosample_accession',
        *(col for col in metadata.columns if col not in bioproject_columns + ('biosample',)),
        'fastq_prefix'
    ))
    biosamples = (
        (
            row.loc['biosample'], *(row.loc[col] for col in biosample_columns[1:-1]),
            os.path.join(
                BIOLEACH_READS_DIR,
                row.loc['run_accession']
            )
        )
        for _, row in metadata.iterrows()
    )
    return bioproject_columns, biosample_columns, biosamples


def load_organisms_metadata(
    organisms_metadata_file=BIOLEACH_ORGANISMS_META,
    organisms_dir=BIOLEACH_ORGANISMS_DIR
):
    """Load in metadata about the included organisms

    Parameters
    ----------
    organisms_metadata_file
        path to file containing the organism metadata
    organisms_dir
        directory containing contig sequences

    Returns
    -------
    tuple
        organisms_metadata, organisms
    """

    organisms_metadata = pd.read_csv(organisms_metadata_file)
    organisms = (
        (row.loc['organism'], row.loc['bioproject'], os.path.join(organisms_dir, row.loc['contigs']))
        for _, row in organisms_metadata.iterrows()
    )
    return organisms_metadata, organisms


def lookup_bioproject_id(bioproject: str, connection):
    """Load in metadata about the included organisms

    Parameters
    ----------
    bioproject: str
        bioproject accession (PRJ)
    cursor
        SQL database cursor

    Returns
    -------
    int
        the bioproject ID value from the bioproject table
    """

    return connection.execute(text(f"SELECT id FROM bioproject WHERE bioproject_accession = '{bioproject}'")).fetchone()[0]


def dialect_agnostic_engine(dialect: str = 'sqlite', database: str = ':memory:'):
    if dialect == 'sqlite':
        db = f"sqlite+pysqlite:///{database}"
    elif dialect == 'mysql':
        db = f"mysql+mysqlconnector://{BIOLEACH_MYSQL_USER}:{BIOLEACH_MYSQL_PASSWORD}@{BIOLEACH_MYSQL_HOST}/{database}"
        connection = mysql.connector.connect(
            user=BIOLEACH_MYSQL_USER,
            password=BIOLEACH_MYSQL_PASSWORD,
            host=BIOLEACH_MYSQL_HOST,
            port=BIOLEACH_MYSQL_PORT
        )
        cur = connection.cursor()
        cur.execute(f"CREATE DATABASE IF NOT EXISTS {database}")
        connection.commit()
        connection.close()
    else:
        raise ValueError('dialect must be sqlite or mysql')
    engine = create_engine(db, echo=True)
    return engine


def create_source_database(
    bioproject_columns,
    biosample_columns,
    organism_columns,
    bioproject,
    biosamples,
    organisms,
    dialect: str = 'sqlite',
    database: str = ':memory:'
):
    """Create the source database

    Parameters
    ----------
    bioproject_columns
    biosample_columns
    organism_columns
    bioproject : str
    biosamples
    organisms
    dialect: str
        sqlite or mysql
    database: str
        location of the sqlite databse file (sqlite) or name of database (mysql)

    Returns
    -------
    sqlalchemy.Engine
        engine object for the source database
    """

    bioproject_column_types = (
        'TEXT', # bioproject_accession
        'TEXT', # study_accession
        'TEXT',        # study_title
        'TEXT'         # abstract
    )
    biosample_column_types = (
        'TEXT', # biosample_accession
        'TEXT', # experiment_accession
        'TEXT',        # experiment_title
        'TEXT',        # experiment_desc
        'TEXT',        # organism_taxid
        'TEXT',        # organism_name
        'TEXT',        # library_name
        'TEXT',        # library_strategy
        'TEXT',        # library_source
        'TEXT',        # library_selection
        'TEXT',        # library_layout
        'TEXT', # sample_accession
        'TEXT',        # sample_title
        'TEXT',        # bioproject
        'TEXT',        # instrument
        'TEXT',        # instrument_model
        'TEXT',        # instrument_model_desc
        'BIGINT',     # total_spots
        'BIGINT',     # total_size
        'TEXT',        # run_accession
        'BIGINT',     # run_total_spots
        'BIGINT',     # run_total_bases
        'TEXT'         # fastq_prefix
    )
    organism_column_types = (
        'TEXT', # organism
        'TEXT', # bioproject
        'TEXT'  # contigs
    )
    engine = dialect_agnostic_engine(dialect=dialect, database=database)
    with engine.connect() as conn:
        if dialect == 'sqlite':
            conn.execute(text(f"""CREATE TABLE bioproject (id INTEGER PRIMARY KEY AUTOINCREMENT, {
                ', '.join(' '.join(x) for x in zip(bioproject_columns, bioproject_column_types))
            })"""))
            conn.execute(text(f"""CREATE TABLE biosample (id INTEGER PRIMARY KEY AUTOINCREMENT, {
                ', '.join(' '.join(x) for x in zip(biosample_columns, biosample_column_types))
            }, bioproject_id INTEGER NOT NULL, FOREIGN KEY (bioproject_id) REFERENCES bioproject (id))"""))
            conn.execute(text(f"""CREATE TABLE organism (id INTEGER PRIMARY KEY AUTOINCREMENT, {
                ', '.join(' '.join(x) for x in zip(organism_columns, organism_column_types))
            }, bioproject_id INTEGER NOT NULL, FOREIGN KEY (bioproject_id) REFERENCES bioproject (id))"""))
        elif dialect == 'mysql':
            conn.execute(text(f"""
                CREATE TABLE bioproject (
                id INTEGER AUTO_INCREMENT,
                {', '.join(' '.join(x) for x in zip(bioproject_columns, bioproject_column_types))},
                PRIMARY KEY (id)
                ) ENGINE = InnoDB
            """))
            conn.execute(text(f"""
                CREATE TABLE biosample (
                id INTEGER AUTO_INCREMENT,
                {', '.join(' '.join(x) for x in zip(biosample_columns, biosample_column_types))},
                bioproject_id INTEGER NOT NULL,
                FOREIGN KEY fk_bioproject_id (bioproject_id) REFERENCES bioproject (id),
                PRIMARY KEY (id)
                ) ENGINE = InnoDB
            """))
            conn.execute(text(f"""
                CREATE TABLE organism (
                id INTEGER AUTO_INCREMENT,
                {', '.join(' '.join(x) for x in zip(organism_columns, organism_column_types))},
                bioproject_id INTEGER NOT NULL,
                FOREIGN KEY fk_bioproject_id (bioproject_id) REFERENCES bioproject (id),
                PRIMARY KEY (id)
                ) ENGINE = InnoDB
            """))
        conn.execute(text(f"""
            INSERT INTO
                bioproject ({', '.join(bioproject_columns)})
            VALUES
                (:{', :'.join(bioproject_columns)})
            """),
            [dict(zip(bioproject_columns, bioproject))]
        )
        conn.execute(text(f"""
            INSERT INTO
                biosample ({', '.join(biosample_columns)}, bioproject_id)
            VALUES
                (:{', :'.join(biosample_columns)}, :bioproject_id)
            """),
            [dict(zip(biosample_columns + ('bioproject_id',), samp + (lookup_bioproject_id(samp[13], conn),)))
             for samp in biosamples]
        )
        conn.execute(text(f"""
            INSERT INTO
                organism ({', '.join(organism_columns)}, bioproject_id)
            VALUES
                (:{', :'.join(organism_columns)}, :bioproject_id)
            """),
            [dict(zip(organism_columns + ('bioproject_id',), org + (lookup_bioproject_id(org[1], conn),)))
             for org in organisms]
        )
        conn.commit()
    return engine


def create_pipeline_database(
    engine_source,
    accessions: list = [],
    dialect: str = 'sqlite',
    database: str = ':memory:'
):
    """Create the source database

    Parameters
    ----------
    engine_source
        engine object from the source database
    accessions : list
        list of experiment, sample, or run accessions to include in the pipeline
    dialect: str
        sqlite or mysql
    database: str
        location of the sqlite databse file (sqlite) or name of database (mysql)

    Returns
    -------
    sqlalchemy.Engine
        engine object for the pipeline database
    """

    accession_columns = (
        'experiment_accession',
        'sample_accession',
        'run_accession',
        'fastq_prefix',
        'trimmed',
        'removed_contaminants',
        'assembled_contigs',
        'predicted_genes'
    )
    accession_column_types = (
        'TEXT', # experiment_accession
        'TEXT', # sample_accession
        'TEXT', # run_accession
        'TEXT', # fastq_prefix
        'BOOL', # trimmed
        'BOOL', # removed_contaminants
        'BOOL', # assembled_contigs
        'BOOL'  # predicted_genes
    )
    engine_pipeline = dialect_agnostic_engine(dialect=dialect, database=database)
    with engine_source.connect() as conn_source, engine_pipeline.connect() as conn_pipeline:
        if dialect == 'sqlite':
            conn_pipeline.execute(text(f"""CREATE TABLE pipeline_accessions (id INTEGER PRIMARY KEY AUTOINCREMENT, {
                ', '.join(' '.join(x) for x in zip(accession_columns, accession_column_types))
            })"""))
        elif dialect == 'mysql':
            conn_pipeline.execute(text(f"""
                CREATE TABLE pipeline_accessions (
                id INT AUTO_INCREMENT,
                {', '.join(' '.join(x) for x in zip(accession_columns, accession_column_types))},
                PRIMARY KEY (id)
                ) ENGINE = InnoDB
            """))
        for row in conn_source.execute(
            text("SELECT experiment_accession, sample_accession, run_accession, fastq_prefix FROM biosample")
        ):
            accession_values = row.experiment_accession, row.sample_accession, row.run_accession
            if (not accessions) or set(accession_values).intersection(set(accessions)):
                conn_pipeline.execute(text(f"""
                    INSERT INTO
                        pipeline_accessions ({', '.join(accession_columns)})
                    VALUES
                        (:{', :'.join(accession_columns)})
                    """),
                    dict(zip(accession_columns, (
                        row.experiment_accession,
                        row.sample_accession,
                        row.run_accession,
                        row.fastq_prefix
                    ) + (False,) * (len(accession_columns) - 4)))
                )
        conn_pipeline.commit()
    return engine_pipeline
