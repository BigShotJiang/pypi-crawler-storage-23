import os
import os.path
import tomllib

BIOLEACH_CONFIG_FILE = os.environ.get(
    'BIOLEACH_CONFIG_FILE',
    os.path.join(os.environ.get('HOME'), '.bioleach-config.toml')
)
BIOLEACH_CONFIG = tomllib.load(BIOLEACH_CONFIG_FILE) if os.path.exists(BIOLEACH_CONFIG_FILE) else None
BIOLEACH_BIOPROJECT_ACCESSION = os.environ.get(
    'BIOLEACH_BIOPROJECT_ACCESSION',
    'PRJNA1170356'
)
BIOLEACH_STUDY_ACCESSION = os.environ.get(
    'BIOLEACH_STUDY_ACCESSION',
    'SRP537212'
)
BIOLEACH_STUDY_TITLE = os.environ.get(
    'BIOLEACH_STUDY_TITLE',
    'Bioleaching microbial community'
)
BIOLEACH_DATA_DIR = os.environ.get(
    'BIOLEACH_DATA_DIR',
    os.path.join(os.path.dirname(__file__), 'data')
)
BIOLEACH_SOURCE_DB_FILE = os.environ.get(
    'BIOLEACH_DB_FILE',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_source.db')
)
BIOLEACH_PIPELINE_DB_FILE = os.environ.get(
    'BIOLEACH_DB_FILE',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_pipeline.db')
)
BIOLEACH_READS_DIR = os.environ.get(
    'BIOLEACH_READS_DIR',
    os.path.join(BIOLEACH_DATA_DIR, 'reads')
)
BIOLEACH_CONTIGS_DIR = os.environ.get(
    'BIOLEACH_CONTIGS_DIR',
    os.path.join(BIOLEACH_DATA_DIR, 'contigs')
)
BIOLEACH_ALIGNMENTS_DIR = os.environ.get(
    'BIOLEACH_ALIGNMENTS_DIR',
    os.path.join(BIOLEACH_DATA_DIR, 'alignments')
)
BIOLEACH_GENES_DIR = os.environ.get(
    'BIOLEACH_GENES_DIR',
    os.path.join(BIOLEACH_DATA_DIR, 'genes')
)
BIOLEACH_ORGANISMS_META = os.environ.get(
    'BIOLEACH_ORGANISMS_META',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_organisms.csv')
)
BIOLEACH_ORGANISMS_DIR = os.environ.get(
    'BIOLEACH_ORGANISMS_DIR',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_organisms')
)
BIOLEACH_ABSTRACT_FILE = os.environ.get(
    'BIOLEACH_ABSTRACT_FILE',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_abstract.txt')
)
with open(BIOLEACH_ABSTRACT_FILE, 'rt') as f:
    bioleach_abstract = f.read()
BIOLEACH_ABSTRACT = os.environ.get('BIOLEACH_ABSTRACT', bioleach_abstract)
BIOLEACH_MYSQL_HOST = os.environ.get('BIOLEACH_MYSQL_HOST', 'localhost')
BIOLEACH_MYSQL_USER = os.environ.get('BIOLEACH_MYSQL_USER', 'root')
BIOLEACH_MYSQL_PORT = os.environ.get('BIOLEACH_MYSQL_PORT', 3306)
BIOLEACH_MYSQL_PASSWORD = os.environ.get('BIOLEACH_MYSQL_PASSWORD')

BIOLEACH_PHIX_FTP = os.environ.get('BIOLEACH_PHIX_FTP', 'ftp.ncbi.nlm.nih.gov')
BIOLEACH_PHIX_FTP_PATH = os.environ.get(
    'BIOLEACH_PHIX_FTP_PATH',
    'genomes/all/GCF/000/819/615/GCF_000819615.1_ViralProj14015/GCF_000819615.1_ViralProj14015_cds_from_genomic.fna.gz'
)
BIOLEACH_PHIX = os.environ.get(
    'BIOLEACH_PHIX',
    os.path.join(BIOLEACH_DATA_DIR, os.path.basename(BIOLEACH_PHIX_FTP_PATH))
)
BIOLEACH_PHIX_PREFIX = os.environ.get(
    'BIOLEACH_PHIX_PREFIX',
    os.path.join(
        BIOLEACH_DATA_DIR,
        '.'.join(os.path.basename(BIOLEACH_PHIX).split('.')[:-1])
    )
)
BIOLEACH_KRAKEN2_DB = os.environ.get(
    'BIOLEACH_KRAKEN2_DB',
    os.path.join(BIOLEACH_DATA_DIR, 'bioleach_kraken2_db')
)

BIOLEACH_TRIM_ALGORITHM = os.environ.get('BIOLEACH_TRIM_ALGORITHM', 'fastp')
BIOLEACH_REMOVE_CONTAM_ALGORITHM = os.environ.get('BIOLEACH_REMOVE_CONTAM_ALGORITHM', 'kraken2')

