# Imports ======================================================================

import pandas as pd
import seaborn as sns
from Bio import SeqIO
from shutil import which
from subprocess import Popen, PIPE, run
from tempfile import TemporaryDirectory
import os.path
from io import StringIO

from bioleach.gzip_agnostic_open import gzip_agnostic_open


# Constants ====================================================================

MEGAHIT_MEMORY_FLAG = {'minimum': 0, 'moderate': 1, 'all': 2}


# Functions ====================================================================

def assemble_contigs_megahit(
    fastq_in_1, fastq_in_2,
    output_prefix,
    min_contig_length: int = 1000,
    threads: int = 1,
    memory_frac: float = 0.9,
    memory_flag: str = 'moderate'
):
    """Assemble contigs using megahit

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    output_dir
        directory for output files
    min_contig_length : int
        minimum contig length to report
    threads : int
        number of threads
    memory_frac : str
        fraction of available memory to be allocated
    memory_flag : str
        setting for usage of allocated memory: "minimum",
        "moderate", or "all"
    """

    if not which('megahit'):
        raise RuntimeError('megahit not found')
    with TemporaryDirectory(dir=os.path.dirname(output_prefix)) as temp_dir:
        run((
            'megahit',
            '--min-contig-len', str(min_contig_length),
            '--num-cpu-threads', str(threads),
            '--memory', str(memory_frac),
            '--mem-flag', str(MEGAHIT_MEMORY_FLAG[memory_flag]),
            '-1', fastq_in_1,
            '-2', fastq_in_2,
            '--out-dir', os.path.join(temp_dir, os.path.basename(output_prefix)),
            '--out-prefix', output_prefix
        ))


def collect_contig_lengths(contigs_fasta):
    """Scan a FASTA file produced by megahit and collect the contig lengths

    Parameters
    ----------
    contigs_fasta
        FASTA file containing contigs
    """
    with gzip_agnostic_open(contigs_fasta, mode='rt') as f:
        return pd.DataFrame(
            {'id': record.id, 'len': int(x[4:])}
            for record in SeqIO.parse(f, 'fasta')
            for x in record.description.split(' ') if x.startswith('len=')
        )


def plot_contig_lengths(contig_lengths, accession):
    """Scan a FASTA file produced by megahit and collect the contig lengths

    Parameters
    ----------
    contig_lengths : DataFrame
    accession : str
    """

    ax = sns.histplot(data=contig_lengths, x='len')
    fig = ax.get_figure()
    fig.tight_layout()
    fig.savefig(f'{accession}_contig_lengths.svg')
    fig.clf()


def map_to_contigs_bowtie2(filtered_fasta, fastq_in_1, fastq_in_2, bam_out, threads: int = 1):
    """Map reads to contigs with bowtie2

    Parameters
    ----------
    """

    with TemporaryDirectory(dir=os.path.dirname(bam_out)) as temp_dir:
        idx_prefix = os.path.join(temp_dir, os.path.basename(filtered_fasta)[:-3])
        run(('bowtie2-build', filtered_fasta, idx_prefix))
        with Popen((
            'bowtie2',
            '--threads', str(threads),
            '-x', idx_prefix,
            '-1', fastq_in_1,
            '-2', fastq_in_2
        ), stdout=PIPE) as bowtie2:
            run(('samtools', 'sort', '-o', os.path.join(temp_dir, os.path.basename(bam_out))), stdin=bowtie2.stdout)
        run(('samtools', 'index', os.path.join(temp_dir, os.path.basename(bam_out))))
        run(('samtools', 'view', '-b', '-F', '4', '-o', bam_out, os.path.join(temp_dir, os.path.basename(bam_out))))
    run(('samtools', 'index', bam_out))


def calculate_coverage(bam_file):
    return pd.read_table(
        StringIO(run(
            ('samtools', 'idxstats', bam_file),
            capture_output=True,
            text=True
        ).stdout),
        names=('id', 'length', 'mapped', 'unmapped'),
        index_col='id'
    )
