"""
# bioleach

This package defines a bioinformatics pipeline to support reproducing the analysis published in [^1] of microbial consortia in a copper bioleaching context. See the following excerpt from the bioproject abstract for reference:

> Here, we established a copper bioleaching microbial consortium on chalcopyrite and then transferred it to chalcocite to investigate how the community composition shifts due to changes in mineral structure and the absence of mineral-derived Fe. The initial inoculum came from a bioleaching column at a copper heap-leaching system in Cyprus. The solution chemistry was determined and microbial communities characterized by genome-resolved metagenomics after four and eight weeks of cultivation.

The metagenome sequencing reads are available from NCBI bioproject [PRJNA1170356](https://www.ncbi.nlm.nih.gov/bioproject?term=PRJNA1170356) / SRA study [SRP537212](https://trace.ncbi.nlm.nih.gov/Traces/?view=study&acc=SRP537212), while genomes and plasmids are available from ggKbase proect [Cu_Bioleaching_Organisms_and_Plasmids](https://ggkbase.berkeley.edu/cu_bioleaching_organisms_and_plasmids).

[^1]: Lane et al. [Bioleaching Microbial Community Metabolism and Composition
Driven by Copper Sulphide Mineral Type](https://doi.org/10.1111/1758-2229.70261). Environmental Microbiology Reports 2025.
"""

from bioleach.version import __version__
from bioleach.bioproject import BIOLEACH_BIOPROJECT
from bioleach.env import (
    BIOLEACH_SOURCE_DB_FILE,
    BIOLEACH_PIPELINE_DB_FILE,
    BIOLEACH_DATA_DIR,
    BIOLEACH_READS_DIR,
    BIOLEACH_TRIM_ALGORITHM,
    BIOLEACH_REMOVE_CONTAM_ALGORITHM,
    BIOLEACH_CONTIGS_DIR,
    BIOLEACH_ALIGNMENTS_DIR,
    BIOLEACH_GENES_DIR
)
from bioleach.database import dialect_agnostic_engine
from bioleach.bioleach import (
    _create_source_database,
    _create_pipeline_database,
    _export_database,
    _download_sra_reads,
    construct_read_preprocessing_func,
    _trim,
    _remove_contaminants,
    _assemble_contigs,
    mark_complete
)
