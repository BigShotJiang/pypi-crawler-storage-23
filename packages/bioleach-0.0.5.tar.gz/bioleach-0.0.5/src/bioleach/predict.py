from subprocess import run
import os.path

# https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1008727

def predict_genes_prodigal(contigs_fasta, output_prefix, procedure='single'):
    run((
        'prodigal',
        '-p', procedure,
        '-i', contigs_fasta,
        '-o', f'{output_prefix}.gbk',
        '-d', f'{output_prefix}.fna',
        '-a', f'{output_prefix}.faa'
    ))

def predict_genes(run_accession, contigs_dir, genes_dir):
    predict_genes_prodigal(
        os.path.join(contigs_dir, f'{run_accession}.contigs.fa'),
        os.path.join(genes_dir, run_accession),
        procedure='meta'
    )
