from subprocess import Popen, PIPE, run
from shutil import which
import os.path
import tempfile
from bioleach.env import (
    BIOLEACH_READS_DIR,
    BIOLEACH_PHIX,
    BIOLEACH_PHIX_PREFIX,
    BIOLEACH_KRAKEN2_DB
)
from bioleach.download import download_phix

# https://www.cell.com/cell-reports-methods/fulltext/S2667-2375(25)00254-1
# https://academic.oup.com/gigascience/article/doi/10.1093/gigascience/giaf004/8045180?login=false#506556268
# https://link.springer.com/article/10.1186/s12859-023-05492-w
# https://academic.oup.com/nargab/article/7/3/lqaf105/8211928?login=false

def remove_contaminants_bbtools(fastq_in_1, fastq_in_2, fastq_out_1, fastq_out_2, threads: int = 1):
    """Use BBtools to remove phix contamination

    Parameters
    ----------
    in1, in2
        paired-end fastq input files
    out1, out2
        paried-end fastq output files
    threads: int
        number of threads to use
    """

    if not which('bbduk.sh'):
        raise RuntimeError('bbduk.sh not found')
    run((
        'bbduk.sh',
        f'in1={fastq_in_1}',
        f'in2={fastq_in_2}',
        f'out1={fastq_out_1}',
        f'out2={fastq_out_2}',
        f'threads={threads}',
        f'ref={BIOLEACH_PHIX}',
        'k=31',
        'hdist=1',
        f'stats={fastq_in_1[:-11]}_stats.txt'
    ))


def remove_contaminants_alignment(args, fastq_out_1, fastq_out_2):
    """Remove contaminants with an alignment-based method

    Parameters
    ----------
    args
        iterable of arguments defining the command line for the sequence aligner
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    """

    with tempfile.TemporaryDirectory(dir=BIOLEACH_READS_DIR) as temp_dir:
        with Popen(args, stdout=PIPE) as aligner:
            run(('samtools', 'sort', '-o', os.path.join(temp_dir, 'sort.bam')), stdin=aligner.stdout)
        run(('samtools', 'index', os.path.join(temp_dir, 'sort.bam')))
        with Popen(('samtools', 'view', '-b', '-f', '4', os.path.join(temp_dir, 'sort.bam')), stdout=PIPE) as view_unmapped:
            with Popen(('samtools', 'collate', '-u', '-O', '-'), stdin=view_unmapped.stdout, stdout=PIPE) as collate:
                run(('samtools', 'fastq', '-0', '/dev/null', '-s', '/dev/null', '-n', '-1', fastq_out_1, '-2', fastq_out_2), stdin=collate.stdout)


def remove_contaminants_bowtie2(
    fastq_in_1, fastq_in_2,
    fastq_out_1, fastq_out_2,
    local: bool = False,
    preset: str = 'very-fast',
    threads: int = 1
):
    """Remove contaminants by alignment to phix with bowtie2

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    local : bool
        if True, perform local instead of end-to-end alignment
    preset : str
        bowtie2 preset setting, one of 'very-fast', 'fast', 'sensitive', or 'very-sensitive'
    threads : int
        number of threads
    """

    if not which('bowtie2'):
        raise RuntimeError('bowtie2 not found')
    if not which('samtools'):
        raise RuntimeError('samtools not found')
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    if not os.path.exists(f'{BIOLEACH_PHIX[:-2]}1.bt2'):
        run(('bowtie2-build', BIOLEACH_PHIX, BIOLEACH_PHIX_PREFIX))
    args = ('bowtie2', f'--{preset}', '--threads', str(threads), '-x', BIOLEACH_PHIX_PREFIX, '-1', fastq_in_1, '-2', fastq_in_2) + local * ('--local',)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants_bwa(
    fastq_in_1, fastq_in_2,
    fastq_out_1, fastq_out_2,
    threads: int = 1
):
    """Remove contaminants by alignment to phix with bwa

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    threads : int
        number of threads
    """

    if not which('bwa'):
        raise RuntimeError('bwa not found')
    if not which('samtools'):
        raise RuntimeError('samtools not found')
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    if not all(os.path.exists(f'{BIOLEACH_PHIX}.{ext}') for ext in ('amb', 'ann', 'bwt', 'pac', 'sa')):
        run(('bwa index', BIOLEACH_PHIX))
    args = ('bwa', 'mem', '-t', str(threads), BIOLEACH_PHIX, fastq_in_1, fastq_in_2)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants_minimap2(
    fastq_in_1, fastq_in_2,
    fastq_out_1, fastq_out_2,
    threads: int = 1
):
    """Remove contaminants by alignment to phix with minimap2

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    threads : int
        number of threads
    """

    if not which('minimap2'):
        raise RuntimeError('minimap2 not found')
    if not which('samtools'):
        raise RuntimeError('samtools not found')
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    args = ('minimap2', '-t', str(threads), '-ax', 'sr', BIOLEACH_PHIX, fastq_in_1, fastq_in_2)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants_kraken2(
    fastq_in_1, fastq_in_2,
    fastq_out_format,
    threads: int = 1
):
    """Remove contaminants using kraken2

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    threads : int
        number of threads
    """

    if not which('kraken2'):
        raise RuntimeError('kraken2 not found')
    if not os.path.exists(BIOLEACH_KRAKEN2_DB):
        os.mkdir(BIOLEACH_KRAKEN2_DB)
        run(('k2', 'download-taxonomy', '--db', BIOLEACH_KRAKEN2_DB))
        run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--accession', 'GCF_000819615.1'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'viral'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'human'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'fungi'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'plant'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'protozoa'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'UniVec_core'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'vertebrate_mammalian'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'vertebrate_other'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'mitochondrion'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'invertebrate'))
        #run(('k2', 'download-library', '--threads', str(threads), '--no-masking', '--db', BIOLEACH_KRAKEN2_DB, '--library', 'plastid'))
        run(('k2', 'build', '--threads', str(threads), '--db', BIOLEACH_KRAKEN2_DB))
        run(('k2', 'clean', '--threads', str(threads), '--db', BIOLEACH_KRAKEN2_DB))
    run(('k2', 'classify', '--threads', str(threads), '--db', BIOLEACH_KRAKEN2_DB, '--paired', '--output', '-', '--unclassified-out', fastq_out_format, fastq_in_1, fastq_in_2))
        


def remove_contaminants(
    fastq_in_1, fastq_in_2,
    output_dir=BIOLEACH_READS_DIR,
    algorithm: str = 'bbtools',
    threads: int = 1
):
    """Use one of the available algorithms to remove contaminants

    Parameters
    ----------
    fastq_1, fastq_2
        paired-end fastq input files
    output_dir
        output directory
    algorithm : str
        algorithm for adapter trimming, 'bbtools', 'bowtie2', 'bwa', 'minimap2',
    threads : int
        number of cores to use for adapter trimming
    """

    if algorithm == 'bbtools':
        remove_contaminants_bbtools(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'bowtie2':
        remove_contaminants_bowtie2(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'bwa':
        remove_contaminants_bwa(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'minimap2':
        remove_contaminants_bwa(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'kraken2':
        remove_contaminants_kraken2(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean#.fq'),
            threads=threads
        )
    else:
        raise ValueError(f'Algorithm {algorithm} not available.')

