import pytest
import os.path
import pandas as pd
from bioleach.env import BIOLEACH_ORGANISMS_DIR
from bioleach.assemble_contigs import collect_contig_lengths

@pytest.fixture
def contig_lengths():
    return pd.DataFrame(
        [
            ['k141_0', 307],
            ['k141_11790', 318]
        ],
        columns=('id', 'len')
    )

def test_contig_lengths(contig_lengths):
    contigs_fasta = os.path.join(
        os.path.dirname(__file__),
        'data',
        'megahit_test.contigs.fa.gz'
    )
    assert all(collect_contig_lengths(contigs_fasta) == contig_lengths)
