# bioleach

## Overview

The `bioleach` package defines a bioinformatics pipeline to support reproducing the analysis published in [^1] of microbial consortia in a copper bioleaching context. The metagenome sequencing reads are available from NCBI bioproject [PRJNA1170356](https://www.ncbi.nlm.nih.gov/bioproject?term=PRJNA1170356) / SRA study [SRP537212](https://trace.ncbi.nlm.nih.gov/Traces/?view=study&acc=SRP537212), while genomes and plasmids are available from ggKbase proect [Cu_Bioleaching_Organisms_and_Plasmids](https://ggkbase.berkeley.edu/cu_bioleaching_organisms_and_plasmids). See also the [full package documentation](https://aaylward.gitlab.io/bioleach).

See the following excerpt from the bioproject abstract for reference:

> Here, we established a copper bioleaching microbial consortium on chalcopyrite and then transferred it to chalcocite to investigate how the community composition shifts due to changes in mineral structure and the absence of mineral-derived Fe. The initial inoculum came from a bioleaching column at a copper heap-leaching system in Cyprus. The solution chemistry was determined and microbial communities characterized by genome-resolved metagenomics after four and eight weeks of cultivation.

## Background

The global demand for copper (Cu) is likely to outpace supply over the next decade due to widespread electrification, adoption of renewable energy technologies, and declining mine productivity. 

> ![IEA copper figure](docs/source/_static/iea-copper-2025.png)
> [Copper demand data](https://www.iea.org/reports/copper-2) from the International Energy Agency's [Global Critical Minerals Outlook](https://www.iea.org/reports/global-critical-minerals-outlook-2025).

One critical piece of the copper supply chain is **bioleaching**, the activity of microbes that extract copper and other metals during heap leaching. Microbial communities involved in the bioleaching process could be used to improve copper production and have been the subject of scientific research for at least the past two decades. For example, a recent study [^1] by scientists from UC Berkeley, MIT, and other institutions investigated the in microbial populations present on two different minerals found in copper mines, chalcopyrite and chalcocite.

> ![Experimental diagram](docs/source/_static/lane-etal-diagram.png)
> Diagram of experimental design from [^1].

[^1]: Lane et al. [Bioleaching Microbial Community Metabolism and Composition
Driven by Copper Sulphide Mineral Type](https://doi.org/10.1111/1758-2229.70261). *Environmental Microbiology Reports* 2025.

## Installation

The suggested method for installing `bioleach` is via `pip` in a dedicated conda environment

```sh
conda create -n bioleach -c conda-forge -c bioconda \
  pandas seaborn biopython sra-tools pysradb \
  mysql-connector-python sqlalchemy fastp kraken2 bowtie2 \
  megahit prodigal
conda activate bioleach
pip install bioleach
```

Running `bioleach` with no arguments will display the usage text:
```
usage: bioleach [-h] [--version]
                {create-source-db,create-pipeline-db,export-db,download,trim,remove-contam,assemble,clean,data-dir} ...

Bioinformatics analysis of a bioleaching microbial community

positional arguments:
  {create-source-db,create-pipeline-db,export-db,download,trim,remove-contam,assemble,clean,data-dir}
    create-source-db    create source database
    create-pipeline-db  create pipeline database
    export-db           export database
    download            download SRA reads
    trim                trim Illumina adapters and low-quality bases
    remove-contam       remove contaminant reads
    assemble            assemble metagenome contigs
    clean               clean up SRA reads
    data-dir            show the currently configured data directory

options:
  -h, --help            show this help message and exit
  --version             show program's version number and exit
```
