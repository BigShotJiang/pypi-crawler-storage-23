"""Aggregate eval results into summary statistics."""

from __future__ import annotations

from typing import Any


def aggregate_results(results: list[dict]) -> dict:
    """Build aggregate summary, pass rate by category, and per-dimension averages by category."""
    total = len(results)
    passed = sum(1 for r in results if r.get("passed"))
    by_category: dict[str, dict[str, Any]] = {}
    for r in results:
        cat = r.get("category", "general")
        if cat not in by_category:
            by_category[cat] = {
                "total": 0,
                "passed": 0,
                "avg_score": 0.0,
                "avg_intent": 0.0,
                "avg_tools": 0.0,
                "avg_content": 0.0,
                "avg_safety": 0.0,
                "avg_confidence": 0.0,
                "avg_verification": 0.0,
            }
        by_category[cat]["total"] += 1
        if r.get("passed"):
            by_category[cat]["passed"] += 1
        s = r.get("overall_score", 0)
        sc = r.get("scores") or {}
        n = by_category[cat]["total"]
        by_category[cat]["avg_score"] = (by_category[cat]["avg_score"] * (n - 1) + s) / n
        for key in ("intent", "tools", "content", "safety", "confidence", "verification"):
            v = sc.get(key, 0)
            by_category[cat][f"avg_{key}"] = (by_category[cat][f"avg_{key}"] * (n - 1) + v) / n
    cases_with_tools = [r for r in results if r.get("tools_called")]
    tool_success_count = sum(1 for r in cases_with_tools if not r.get("tool_errors"))
    tool_success_rate = round(100 * tool_success_count / len(cases_with_tools), 1) if cases_with_tools else 100.0

    cases_with_verification = [r for r in results if r.get("verification_passed") is not None]
    verification_failed = sum(1 for r in cases_with_verification if r.get("verification_passed") is False)
    hallucination_rate = round(100 * verification_failed / len(cases_with_verification), 1) if cases_with_verification else 0.0
    verification_accuracy = round(100 - hallucination_rate, 1)

    return {
        "total": total,
        "passed": passed,
        "pass_rate_pct": round(100 * passed / total, 1) if total else 0,
        "avg_overall_score": round(sum(r.get("overall_score", 0) for r in results) / total, 4) if total else 0,
        "tool_success_rate_pct": tool_success_rate,
        "hallucination_rate_pct": hallucination_rate,
        "verification_accuracy_pct": verification_accuracy,
        "by_category": by_category,
    }
