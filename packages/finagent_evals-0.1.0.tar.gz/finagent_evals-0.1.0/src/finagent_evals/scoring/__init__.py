"""Scoring: weights, dimension scorers, synonyms, and aggregation."""

from finagent_evals.scoring.weights import (
    WEIGHT_INTENT,
    WEIGHT_TOOLS,
    WEIGHT_CONTENT,
    WEIGHT_SAFETY,
    WEIGHT_CONFIDENCE,
    WEIGHT_VERIFICATION,
    PASS_THRESHOLD,
    TARGET_PASS_RATE_PCT,
    TARGET_TOOL_SUCCESS_RATE_PCT,
)
from finagent_evals.scoring.scorers import (
    score_intent,
    score_tools,
    score_content,
    score_safety,
    score_tool_execution,
    score_verification,
    score_ground_truth,
)
from finagent_evals.scoring.synonyms import CONTENT_SYNONYMS, INTENT_EQUIVALENCE
from finagent_evals.scoring.aggregation import aggregate_results

__all__ = [
    "WEIGHT_INTENT",
    "WEIGHT_TOOLS",
    "WEIGHT_CONTENT",
    "WEIGHT_SAFETY",
    "WEIGHT_CONFIDENCE",
    "WEIGHT_VERIFICATION",
    "PASS_THRESHOLD",
    "TARGET_PASS_RATE_PCT",
    "TARGET_TOOL_SUCCESS_RATE_PCT",
    "score_intent",
    "score_tools",
    "score_content",
    "score_safety",
    "score_tool_execution",
    "score_verification",
    "score_ground_truth",
    "CONTENT_SYNONYMS",
    "INTENT_EQUIVALENCE",
    "aggregate_results",
]
