"""Content synonyms and intent equivalence mappings for fuzzy matching."""

from __future__ import annotations

# Synonyms for content scoring: term -> alternative that also counts as found
CONTENT_SYNONYMS: dict[str, str] = {
    "win_rate": "win rate",
    "win rate": "win_rate",
    "recorded": "logged",
    "logged": "recorded",
    "not financial advice": "not advice",
    "not advice": "not financial advice",
    "informational only": "not financial advice",
    "allocation": "diversification",
    "diversification": "allocation",
    "concentration": "concentrated",
    "concentrated": "concentration",
    "capital gains": "capital gain",
    "capital gain": "capital gains",
    "wash sale": "wash-sale",
    "wash-sale": "wash sale",
    "cannot guarantee": "no guarantee",
    "no guarantee": "cannot guarantee",
    "symbol": "ticker",
    "ticker": "symbol",
    "stock": "ticker",
}

# Intent equivalence: if expected intent is X, these intents also count as correct
INTENT_EQUIVALENCE: dict[str, set[str]] = {
    "portfolio_health": {"portfolio_overview", "risk_check"},
    "performance_review": {"journal_analysis"},
    "tax_implications": {"general", "compliance"},
    "compliance": {"risk_check", "general", "tax_implications"},
    "multi_step": {
        "risk_check", "portfolio_overview", "general",
        "portfolio_health", "performance_review",
        "tax_implications", "compliance", "journal_analysis",
    },
    "journal_analysis": {"performance_review"},
}
