"""finagent-evals: 111 labeled eval cases, deterministic checks, and scoring for financial trading agents."""

__version__ = "0.1.0"

# Cases
from finagent_evals.cases import (
    GOLDEN_CASES,
    eval_cases,
    scenarios,
    get_all_cases,
    get_all_scenarios,
    get_scenarios_by_filter,
    get_coverage_summary,
)

# Checks
from finagent_evals.checks import (
    check_tools,
    check_tools_any,
    check_tools_plus_any_of,
    check_must_contain,
    check_contains_any,
    check_must_not_contain,
    check_sources,
    check_authoritative_sources,
    check_ground_truth,
    check_structural,
    run_golden_checks,
)

# Scoring
from finagent_evals.scoring import (
    WEIGHT_INTENT,
    WEIGHT_TOOLS,
    WEIGHT_CONTENT,
    WEIGHT_SAFETY,
    WEIGHT_CONFIDENCE,
    WEIGHT_VERIFICATION,
    PASS_THRESHOLD,
    score_intent,
    score_tools,
    score_content,
    score_safety,
    score_tool_execution,
    score_verification,
    score_ground_truth,
    CONTENT_SYNONYMS,
    INTENT_EQUIVALENCE,
    aggregate_results,
)

# Mocks
from finagent_evals.mocks import (
    MockGhostfolioClient,
    MOCK_HOLDINGS,
    MOCK_PERFORMANCE,
    MOCK_ACCOUNTS,
    MOCK_ORDERS,
    MOCK_OHLCV_SYMBOLS,
    MOCK_LAST_CLOSE,
    mock_fetch_with_retry,
)

# Sources
from finagent_evals.sources import get_source_by_id, get_sources_for_tools, TOOL_TO_SOURCES

__all__ = [
    "__version__",
    # Cases
    "GOLDEN_CASES",
    "eval_cases",
    "scenarios",
    "get_all_cases",
    "get_all_scenarios",
    "get_scenarios_by_filter",
    "get_coverage_summary",
    # Checks
    "check_tools",
    "check_tools_any",
    "check_tools_plus_any_of",
    "check_must_contain",
    "check_contains_any",
    "check_must_not_contain",
    "check_sources",
    "check_authoritative_sources",
    "check_ground_truth",
    "check_structural",
    "run_golden_checks",
    # Scoring
    "WEIGHT_INTENT",
    "WEIGHT_TOOLS",
    "WEIGHT_CONTENT",
    "WEIGHT_SAFETY",
    "WEIGHT_CONFIDENCE",
    "WEIGHT_VERIFICATION",
    "PASS_THRESHOLD",
    "score_intent",
    "score_tools",
    "score_content",
    "score_safety",
    "score_tool_execution",
    "score_verification",
    "score_ground_truth",
    "CONTENT_SYNONYMS",
    "INTENT_EQUIVALENCE",
    "aggregate_results",
    # Mocks
    "MockGhostfolioClient",
    "MOCK_HOLDINGS",
    "MOCK_PERFORMANCE",
    "MOCK_ACCOUNTS",
    "MOCK_ORDERS",
    "MOCK_OHLCV_SYMBOLS",
    "MOCK_LAST_CLOSE",
    "mock_fetch_with_retry",
    # Sources
    "get_source_by_id",
    "get_sources_for_tools",
    "TOOL_TO_SOURCES",
]
