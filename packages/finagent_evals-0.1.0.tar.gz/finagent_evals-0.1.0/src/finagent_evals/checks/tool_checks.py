"""Tool selection checks -- verify expected tools were called."""

from __future__ import annotations


def check_tools(expected: list[str], actual: list[str], exact: bool = False) -> tuple[bool, str]:
    """Check if expected tools were called. Returns (passed, error_message)."""
    missing = [t for t in expected if t not in actual]
    if missing:
        return (False, f"Missing tools: {missing}")

    if exact:
        extra = [t for t in actual if t not in expected]
        if extra:
            return (False, f"Extra tools (exact_tools=True): {extra}")

    if not expected and actual:
        return (False, f"Expected no tools but agent called: {actual}")

    return (True, "")


def check_tools_any(expected_any: list[str], actual: list[str]) -> tuple[bool, str]:
    """Pass if at least one of expected_any was called, or no tools were called."""
    if not expected_any:
        return (True, "")
    if not actual:
        return (True, "")
    for t in expected_any:
        if t in actual:
            return (True, "")
    return (False, f"Expected one of {expected_any} or no tools; got: {actual}")


def check_tools_plus_any_of(
    expected: list[str], expected_one_of: list[str], actual: list[str]
) -> tuple[bool, str]:
    """Pass if all expected tools were called AND at least one of expected_one_of was called."""
    ok, err = check_tools(expected, actual)
    if not ok:
        return (False, err)
    if not expected_one_of:
        return (True, "")
    for t in expected_one_of:
        if t in actual:
            return (True, "")
    return (False, f"Expected all of {expected} and at least one of {expected_one_of}; got: {actual}")
