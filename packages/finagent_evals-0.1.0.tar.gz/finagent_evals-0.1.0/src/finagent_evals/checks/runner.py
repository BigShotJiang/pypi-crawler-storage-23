"""Run all seven golden checks and return structured result."""

from __future__ import annotations

from finagent_evals.checks.tool_checks import (
    check_tools,
    check_tools_any,
    check_tools_plus_any_of,
)
from finagent_evals.checks.content_checks import (
    check_must_contain,
    check_contains_any,
    check_must_not_contain,
)
from finagent_evals.checks.source_checks import (
    check_sources,
    check_authoritative_sources,
)
from finagent_evals.checks.ground_truth_checks import check_ground_truth
from finagent_evals.checks.structural_checks import check_structural


def run_golden_checks(case: dict, result: dict) -> dict:
    """Run all seven golden checks and return structured result."""
    response = result.get("response") or {}
    response_text = response.get("summary") or ""
    disclaimer = response.get("disclaimer") or ""
    if disclaimer and disclaimer.lower() not in response_text.lower():
        response_text = response_text + "\n" + disclaimer
    tools_called = result.get("tools_called") or []

    # 1. Tool selection
    expected_any = case.get("expected_tools_any") or []
    expected_plus_any_of = case.get("expected_tools_plus_any_of") or []
    if expected_plus_any_of:
        tool_ok, tool_err = check_tools_plus_any_of(
            case.get("expected_tools", []),
            expected_plus_any_of,
            tools_called,
        )
    elif expected_any:
        tool_ok, tool_err = check_tools_any(expected_any, tools_called)
    else:
        tool_ok, tool_err = check_tools(
            case.get("expected_tools", []),
            tools_called,
            exact=case.get("exact_tools", False),
        )

    # 2. Tool execution
    tools_called = result.get("tools_called") or []
    tool_errors = result.get("tool_errors") or []
    if tools_called:
        tool_exec_ok = len(tool_errors) == 0
        tool_exec_err = "; ".join(tool_errors) if tool_errors else ""
    else:
        tool_exec_ok = True
        tool_exec_err = ""

    # 3. Source citation
    source_ok, source_err = check_sources(
        case.get("expected_sources", []),
        response_text,
    )

    expected_auth = case.get("expected_authoritative_sources", [])
    if expected_auth:
        auth_sources = response.get("authoritative_sources", [])
        auth_ok, auth_err = check_authoritative_sources(expected_auth, auth_sources)
        if not auth_ok:
            source_ok = False
            source_err = (source_err + "; " + auth_err) if source_err else auth_err

    # 4. Content validation
    must_contain = list(case.get("expected_output_contains") or []) + list(case.get("should_contain") or [])
    content_ok, content_err = check_must_contain(must_contain, response_text)

    contains_any = case.get("expected_output_contains_any") or []
    if content_ok and contains_any:
        any_ok, any_err = check_contains_any(contains_any, response_text)
        if not any_ok:
            content_ok, content_err = False, any_err

    # 5. Negative validation
    negative_ok, negative_err = check_must_not_contain(
        case.get("should_not_contain", []),
        response_text,
    )

    # 6. Ground truth validation
    ground_truth_ok, ground_truth_err = check_ground_truth(
        case.get("ground_truth_contains", []),
        response_text,
    )

    # 7. Structural validation
    react_step = result.get("react_step")
    latency_seconds = result.get("latency_seconds")
    structural_ok, structural_err = check_structural(
        react_step=react_step,
        max_react_steps=case.get("max_react_steps"),
        latency_seconds=latency_seconds,
        max_latency_seconds=case.get("max_latency_seconds"),
    )

    all_checks = [tool_ok, tool_exec_ok, source_ok, content_ok, negative_ok, ground_truth_ok, structural_ok]
    all_passed = all(c for c in all_checks if c is not None)

    return {
        "passed": all_passed,
        "tool_selection": {"passed": tool_ok, "error": tool_err},
        "tool_execution": {"passed": tool_exec_ok, "error": tool_exec_err},
        "source_citation": {"passed": source_ok, "error": source_err},
        "content": {"passed": content_ok, "error": content_err},
        "negative": {"passed": negative_ok, "error": negative_err},
        "ground_truth": {"passed": ground_truth_ok, "error": ground_truth_err},
        "structural": {"passed": structural_ok, "error": structural_err},
    }
