"""Content validation checks -- verify response contains required terms."""

from __future__ import annotations


DEFAULT_GIVE_UP_PHRASES = [
    "i couldn't",
    "i was unable",
    "i don't have access",
    "unable to process",
    "unable to retrieve",
    "i cannot access",
]


def check_must_contain(terms: list[str], response_text: str) -> tuple[bool, str]:
    """Check that all required terms appear in the response."""
    if not terms:
        return (True, "")

    text_lower = response_text.lower()
    missing = [t for t in terms if t.lower() not in text_lower]

    if missing:
        return (False, f"Missing required content: {missing}")

    return (True, "")


def check_contains_any(terms: list[str], response_text: str) -> tuple[bool, str]:
    """Check that at least one of the terms appears in the response."""
    if not terms:
        return (True, "")

    text_lower = response_text.lower()
    for t in terms:
        if t.lower() in text_lower:
            return (True, "")

    return (False, f"Missing required content (any of): {terms}")


def check_must_not_contain(
    forbidden: list[str],
    response_text: str,
    give_up_phrases: list[str] | None = None,
) -> tuple[bool, str]:
    """Check that no forbidden terms or give-up phrases appear in the response."""
    if not response_text.strip():
        return (False, "Response is empty")

    text_lower = response_text.lower()
    errors = []

    for term in forbidden:
        if term.lower() in text_lower:
            errors.append(f"Forbidden term found: '{term}'")

    for phrase in (give_up_phrases if give_up_phrases is not None else DEFAULT_GIVE_UP_PHRASES):
        if phrase.lower() in text_lower:
            errors.append(f"Give-up phrase found: '{phrase}'")

    if errors:
        return (False, "; ".join(errors))

    return (True, "")
