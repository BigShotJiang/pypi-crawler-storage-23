"""Structural checks -- verify react step count and latency within budget."""

from __future__ import annotations


def check_structural(
    react_step: int | None,
    max_react_steps: int | None,
    latency_seconds: float | None,
    max_latency_seconds: float | None,
) -> tuple[bool, str]:
    """Check react step count and latency against per-case budgets."""
    errors = []

    if max_react_steps is not None and react_step is not None:
        if react_step > max_react_steps:
            errors.append(
                f"ReAct steps {react_step} exceeds max {max_react_steps}"
            )

    if max_latency_seconds is not None and latency_seconds is not None:
        if latency_seconds > max_latency_seconds:
            errors.append(
                f"Latency {latency_seconds:.1f}s exceeds max {max_latency_seconds}s"
            )

    if errors:
        return (False, "; ".join(errors))

    return (True, "")
