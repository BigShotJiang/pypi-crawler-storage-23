"""Ground truth checks -- verify known mock-data values appear in the response."""

from __future__ import annotations


def check_ground_truth(terms: list[str], response_text: str) -> tuple[bool, str]:
    """Check that known ground-truth values from mock data appear in the response."""
    if not terms:
        return (True, "")

    text_lower = response_text.lower()
    missing = [t for t in terms if str(t).lower() not in text_lower]

    if missing:
        return (False, f"Missing ground truth values: {missing}")

    return (True, "")
