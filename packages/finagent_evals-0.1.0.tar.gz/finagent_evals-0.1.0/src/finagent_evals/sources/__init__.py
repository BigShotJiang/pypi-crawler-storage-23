"""Authoritative sources knowledge store for tax and compliance citations.

Bundled with finagent-evals so check functions can resolve source IDs
without depending on agent code.
"""

from __future__ import annotations

import json
from importlib import resources


# Module-level cache
_sources: list[dict] | None = None


def _load_sources() -> list[dict]:
    global _sources
    if _sources is None:
        ref = resources.files("finagent_evals.sources").joinpath("sources.json")
        _sources = json.loads(ref.read_text(encoding="utf-8"))
    return _sources


TOOL_TO_SOURCES: dict[str, list[str]] = {
    "compliance_check": ["irc_1091", "irs_pub550", "irc_1222", "irc_1h", "irs_pub544"],
    "tax_estimate": ["irc_1", "irs_pub17", "irc_1222", "irc_1h"],
}


def get_sources_for_tools(tools_called: list[str]) -> list[dict]:
    """Return list of {"id", "label", "url"} for tools that have authoritative sources."""
    sources = _load_sources()
    source_map = {s["id"]: s for s in sources}
    seen: set[str] = set()
    result: list[dict] = []
    for tool in tools_called:
        for sid in TOOL_TO_SOURCES.get(tool, []):
            if sid not in seen and sid in source_map:
                seen.add(sid)
                s = source_map[sid]
                result.append({"id": s["id"], "label": s["label"], "url": s["url"]})
    return result


def get_source_by_id(source_id: str) -> dict | None:
    """Lookup a single source record by id."""
    sources = _load_sources()
    for s in sources:
        if s["id"] == source_id:
            return s
    return None
