"""Eval case collections: golden (34), scenarios (47), dataset (30) = 111 total."""

from __future__ import annotations

from finagent_evals.cases.golden import GOLDEN_CASES
from finagent_evals.cases.scenarios import (
    scenarios,
    get_all_scenarios,
    get_scenarios_by_filter,
    get_coverage_summary,
)
from finagent_evals.cases.dataset import eval_cases

__all__ = [
    "GOLDEN_CASES",
    "scenarios",
    "get_all_scenarios",
    "get_scenarios_by_filter",
    "get_coverage_summary",
    "eval_cases",
    "get_all_cases",
]


def get_all_cases() -> list[dict]:
    """Return all 111 eval cases with a 'layer' tag indicating origin.

    Layers:
      - golden: 34 post-commit validation cases
      - scenario: 47 coverage-map cases
      - dataset: 30 intent/confidence cases
    """
    cases: list[dict] = []
    for c in GOLDEN_CASES:
        cases.append({**c, "layer": "golden"})
    for c in get_all_scenarios():
        cases.append({**c, "layer": "scenario"})
    for c in eval_cases:
        cases.append({**c, "layer": "dataset"})
    return cases
