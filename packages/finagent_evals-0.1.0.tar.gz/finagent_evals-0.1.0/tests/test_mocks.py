"""Tests for mock infrastructure."""

import json
from importlib import resources

from finagent_evals.mocks import (
    MockGhostfolioClient,
    MOCK_HOLDINGS,
    MOCK_LAST_CLOSE,
    mock_fetch_with_retry,
)


class TestMockGhostfolioClient:
    def test_get_holdings(self):
        client = MockGhostfolioClient()
        holdings = client.get_holdings()
        assert "holdings" in holdings
        assert len(holdings["holdings"]) == 2

    def test_get_performance(self):
        client = MockGhostfolioClient()
        perf = client.get_performance()
        assert "performance" in perf

    def test_lookup_symbol_aapl(self):
        client = MockGhostfolioClient()
        result = client.lookup_symbol("AAPL")
        assert result["items"][0]["symbol"] == "AAPL"

    def test_lookup_symbol_unknown(self):
        client = MockGhostfolioClient()
        result = client.lookup_symbol("ZZZZ")
        assert result["total"] == 1  # returns generic match

    def test_create_order(self):
        client = MockGhostfolioClient()
        resp = client.create_order({"symbol": "AAPL", "type": "BUY", "quantity": 10, "unitPrice": 150, "date": "2025-01-01"})
        assert resp["symbol"] == "AAPL"

    def test_health_check(self):
        client = MockGhostfolioClient()
        assert client.health_check() is True


class TestMockMarketData:
    def test_fetch_returns_dataframes(self):
        data = mock_fetch_with_retry(["AAPL", "GOOG"], "252d", "1d")
        assert "AAPL" in data
        assert "GOOG" in data
        assert len(data["AAPL"]) > 0

    def test_last_close_pinned(self):
        data = mock_fetch_with_retry(["AAPL"], "252d", "1d")
        last_close = data["AAPL"]["Close"].iloc[-1]
        assert last_close == MOCK_LAST_CLOSE["AAPL"]

    def test_unknown_symbol(self):
        data = mock_fetch_with_retry(["ZZZZ"], "60d", "1d")
        assert "ZZZZ" in data


class TestSeedData:
    def test_seed_data_loadable(self):
        ref = resources.files("finagent_evals.mocks").joinpath("seed_data.json")
        data = json.loads(ref.read_text(encoding="utf-8"))
        assert "activities" in data
        assert len(data["activities"]) == 8
