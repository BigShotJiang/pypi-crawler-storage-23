"""Tests for case collections."""

from finagent_evals.cases import (
    GOLDEN_CASES,
    eval_cases,
    get_all_scenarios,
    get_all_cases,
    get_scenarios_by_filter,
    get_coverage_summary,
)


def test_golden_count():
    assert len(GOLDEN_CASES) == 34


def test_scenario_count():
    assert len(get_all_scenarios()) == 47


def test_dataset_count():
    assert len(eval_cases) == 30


def test_total_cases():
    all_cases = get_all_cases()
    assert len(all_cases) == 111


def test_all_cases_have_layer():
    for case in get_all_cases():
        assert "layer" in case
        assert case["layer"] in ("golden", "scenario", "dataset")


def test_all_cases_have_input():
    for case in get_all_cases():
        assert "input" in case or "query" in case


def test_golden_cases_have_ids():
    ids = [c["id"] for c in GOLDEN_CASES]
    assert len(ids) == len(set(ids)), "Duplicate IDs in golden cases"


def test_scenario_filter():
    single = get_scenarios_by_filter(category="single_tool")
    assert len(single) > 0
    for c in single:
        assert c["category"] == "single_tool"


def test_coverage_summary():
    summary = get_coverage_summary()
    assert summary["total"] == 47
    assert "by_category" in summary
    assert "by_difficulty" in summary
