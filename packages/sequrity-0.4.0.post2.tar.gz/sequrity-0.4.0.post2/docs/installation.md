# Installation

You can interact with the Sequrity API using either the Sequrity client or directly via REST API calls.

=== "Sequrity client"

    Install the Sequrity Python client:

    ```bash
    pip install sequrity
    ```

=== "REST API"

    No installation required. Use any HTTP client (curl, httpx, requests, etc.).