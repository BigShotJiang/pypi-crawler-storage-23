# Sequrity Client

The `SequrityClient` is the main synchronous client for interacting with Sequrity's API.

::: sequrity._client.SequrityClient
    options:
      show_root_heading: true
      show_source: true