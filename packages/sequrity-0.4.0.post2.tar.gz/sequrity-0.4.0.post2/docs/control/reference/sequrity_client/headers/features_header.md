# Security Features / X-Features

::: sequrity.control.types.headers.FeaturesHeader
    options:
      show_root_heading: true
      show_source: true
      members: ["single_llm", "dual_llm"]

::: sequrity.control.types.headers.TaggerConfig
    options:
      show_root_heading: false
      show_source: false

::: sequrity.control.types.headers.ConstraintConfig
    options:
      show_root_heading: false
      show_source: false
