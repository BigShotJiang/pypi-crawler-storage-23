## Security Policy / X-Policy

Configure security policies using SQRT policy language.

::: sequrity.control.types.headers.SecurityPolicyHeader
    options:
      show_root_heading: true
      show_source: true

::: sequrity.control.types.headers.PolicyCode
    options:
      show_root_heading: true
      show_source: false

::: sequrity.control.types.headers.InternalPolicyPresets
    options:
      show_root_heading: true
      show_source: false

::: sequrity.control.types.headers.ControlFlowMetaPolicy
    options:
      show_root_heading: true
      show_source: false
