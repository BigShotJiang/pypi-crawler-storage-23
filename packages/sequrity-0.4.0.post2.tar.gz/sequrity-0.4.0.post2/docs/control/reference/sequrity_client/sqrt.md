# SQRT Policy Parser

::: sequrity.sqrt.parser.check
    options:
      show_root_heading: true

::: sequrity.sqrt.parser.check_file
  options:
    show_root_heading: true

::: sequrity.sqrt.parser.validate
    options:
      show_root_heading: true

::: sequrity.sqrt.parser.parse
    options:
      show_root_heading: true
---

::: sequrity.sqrt.parser.ParseResult
    options:
      show_root_heading: true
      show_source: true

::: sequrity.sqrt.parser.SqrtParseError
    options:
      show_root_heading: true