# ValueWithMeta

::: sequrity.control.types.dual_llm_response.ValueWithMeta
    options:
      show_root_heading: true
      show_source: true

::: sequrity.control.types.dual_llm_response.MetaData
    options:
      show_root_heading: true
      show_source: true
