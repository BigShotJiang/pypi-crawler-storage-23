# SQRT Policy Grammar

This is the formal grammar specification for the SQRT language for Sequrity Control's tool policy definitions.
The grammar is defined using [Lark](https://lark-parser.readthedocs.io/).

```lark
--8<-- "src/sequrity/sqrt/grammar.lark"
```