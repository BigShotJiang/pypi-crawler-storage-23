"""Formatters - Renderização de resultados."""
