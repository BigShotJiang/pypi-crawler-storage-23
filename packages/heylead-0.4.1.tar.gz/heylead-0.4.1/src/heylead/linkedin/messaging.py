# Legacy module — all LinkedIn messaging operations now in unipile.py
# Kept as empty file to avoid import errors during transition.
