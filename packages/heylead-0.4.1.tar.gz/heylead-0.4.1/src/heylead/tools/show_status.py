"""Tool 5: show_status — Dashboard in the chat.

Shows campaign stats, acceptance rate, reply rate, hot leads,
account health, and free tier usage.

The chat IS the dashboard. Forever.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from ..config import get_tier
from ..constants import (
    FREE_MAX_CAMPAIGNS,
    FREE_MAX_ENGAGEMENTS,
    FREE_MAX_FOLLOWUPS,
    FREE_MONTHLY_INVITATIONS,
    FREE_MONTHLY_MESSAGES,
    PRO_MAX_FOLLOWUPS,
    TIER_PRO,
    WEEKLY_INVITATION_CAP,
)
from ..db.queries import (
    count_followup_ready,
    get_campaign,
    get_campaign_stats,
    get_campaign_outcomes,
    get_campaign_velocity,
    get_engagement_stats,
    get_monthly_usage,
    get_rate_limit_today,
    get_setting,
    get_weekly_invitation_sum,
    list_campaigns,
    list_icps,
)
from ..db.schema import get_db
from ..formatter import conversion_rate_display, format_duration, health_rating, progress_bar, stars

logger = logging.getLogger(__name__)


async def run_show_status(campaign_id: str = "") -> str:
    """Show outreach dashboard.

    If campaign_id is provided: show detailed stats for that campaign.
    If empty: show overview of all campaigns + account health.
    """

    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "👋 Welcome to HeyLead — your AI LinkedIn SDR!\n\n"
            "You haven't set up your profile yet. Let's fix that!\n\n"
            "Say 'set up my profile' or run setup_profile, and I'll walk you through "
            "connecting your LinkedIn account and configuring AI in about 2 minutes.\n\n"
            "After setup, you can:\n"
            "  → create_campaign('find me fintech CTOs') — find prospects\n"
            "  → generate_and_send() — craft personalized messages\n"
            "  → check_replies() — see who responded\n"
            "  → show_status() — your outreach dashboard"
        )

    # ── Specific campaign view ──
    if campaign_id:
        return await _show_campaign_detail(campaign_id)

    # ── Overview ──
    return await _show_overview()


async def _show_overview() -> str:
    """Show overview of all campaigns + account health."""

    campaigns = list_campaigns()
    tier = get_tier()
    rate_data = get_rate_limit_today()
    usage = get_monthly_usage()

    output = ["📊 **HeyLead Dashboard**\n"]

    # ── Account Health ──
    sent = rate_data.get("sent", 0)
    accepted = rate_data.get("accepted", 0)
    daily_limit = rate_data.get("daily_limit", 15)
    acceptance_rate = accepted / sent if sent > 0 else 0.0

    weekly_sent = get_weekly_invitation_sum()

    # Try to fetch InMail balance + SSI score (non-blocking)
    inmail_credits = -1
    ssi_data: dict = {}
    try:
        from ..linkedin import get_account_id, get_linkedin_client, UnipileError
        account_id = get_account_id()
        if account_id:
            client = get_linkedin_client()
            try:
                inmail_data = await client.get_inmail_balance(account_id)
                inmail_credits = inmail_data.get("credits", -1)
            except Exception:
                pass
            try:
                ssi_data = await client.get_ssi_score(account_id)
            except Exception:
                pass
            finally:
                await client.close()
    except Exception:
        pass

    output.append("Account Health:")
    output.append(f"├── Rating: {health_rating(acceptance_rate)}")
    output.append(f"├── Today: {sent}/{daily_limit} invitations sent")
    output.append(f"├── Weekly: {weekly_sent}/{WEEKLY_INVITATION_CAP} invitations")
    output.append(f"├── Daily limit: {daily_limit}/day (adaptive)")
    if inmail_credits >= 0:
        output.append(f"├── InMail credits: {inmail_credits}")
    ssi_score = ssi_data.get("score", 0)
    if ssi_score:
        ssi_pillars = ssi_data.get("pillars", [])
        pillar_str = ", ".join(f"{p['name']}: {p['score']}" for p in ssi_pillars if p.get("name")) if ssi_pillars else ""
        ssi_line = f"├── SSI Score: {ssi_score}/100"
        if pillar_str:
            ssi_line += f" ({pillar_str})"
        output.append(ssi_line)
    output.append(f"└── Acceptance rate: {acceptance_rate:.0%}" if sent > 0 else "└── Acceptance rate: No data yet")
    output.append("")

    # ── Free tier usage ──
    if tier != TIER_PRO:
        inv_used = usage.get("invitations_sent", 0)
        msg_used = usage.get("messages_sent", 0)

        output.append("Free Tier Usage (this month):")
        output.append(f"├── Invitations: {inv_used}/{FREE_MONTHLY_INVITATIONS} {progress_bar(inv_used, FREE_MONTHLY_INVITATIONS, 15)}")
        output.append(f"├── Messages: {msg_used}/{FREE_MONTHLY_MESSAGES} {progress_bar(msg_used, FREE_MONTHLY_MESSAGES, 15)}")
        output.append(f"└── Campaigns: {len([c for c in campaigns if c['status'] in ('active', 'draft')])}/{FREE_MAX_CAMPAIGNS}")
        output.append("")

    # ── Campaigns ──
    if not campaigns:
        output.append("No campaigns yet.")
        output.append("Create one: create_campaign(\"your target description\")")
    else:
        output.append(f"Campaigns ({len(campaigns)}):")
        for i, camp in enumerate(campaigns):
            is_last = i == len(campaigns) - 1
            prefix = "└──" if is_last else "├──"

            stats = get_campaign_stats(camp["id"])
            status_icon = {
                "active": "🟢",
                "paused": "⏸️",
                "completed": "✅",
                "draft": "📝",
            }.get(camp["status"], "⚪")

            hot = stats.get("hot_leads", 0)
            hot_str = f" 🔥{hot}" if hot > 0 else ""

            output.append(
                f"{prefix} {status_icon} {camp['name']} — "
                f"{stats['invited']} sent, "
                f"{stats['connected']} connected, "
                f"{stats['replied']} replied{hot_str}"
            )

    output.append("")

    # ── Saved ICPs ──
    icps = list_icps(status="active")
    if icps:
        output.append(f"Saved ICPs ({len(icps)}):")
        for i, icp in enumerate(icps[:5]):
            is_last = i == min(4, len(icps) - 1)
            prefix = "└──" if is_last else "├──"
            confidence = icp.get("confidence", 0.5)
            output.append(
                f"{prefix} `{icp['id'][:8]}...` {icp['name']} "
                f"({stars(confidence)} {confidence:.0%})"
            )
        if len(icps) > 5:
            output.append(f"    ... and {len(icps) - 5} more")
        output.append("    Tip: create_campaign(icp_id=\"<id>\") to use a saved ICP")
        output.append("")

    # ── Hot leads summary ──
    db = get_db()
    hot_leads = db.execute(
        """SELECT c.name, c.title, c.company, c.linkedin_url
           FROM outreaches o
           JOIN contacts c ON o.contact_id = c.id
           WHERE o.status = 'hot_lead'
           ORDER BY o.updated_at DESC
           LIMIT 5"""
    ).fetchall()
    db.close()

    if hot_leads:
        output.append(f"🔥 Hot Leads ({len(hot_leads)}):")
        for i, lead in enumerate(hot_leads):
            l = dict(lead)
            is_last = i == len(hot_leads) - 1
            prefix = "└──" if is_last else "├──"
            role = l.get("title", "")
            if l.get("company"):
                role += f" at {l['company']}" if role else l["company"]
            output.append(f"{prefix} {l['name']} — {role}")
        output.append("")

    # ── Engagement stats ──
    eng_stats = get_engagement_stats()
    eng_comments = eng_stats.get("comments", 0)
    eng_reactions = eng_stats.get("reactions", 0)
    eng_total = eng_comments + eng_reactions
    if eng_total > 0:
        output.append(f"💬 Engagements ({eng_total}):")
        output.append(f"├── Comments: {eng_comments}")
        output.append(f"└── Reactions: {eng_reactions}")
        output.append("")
    elif tier != TIER_PRO:
        eng_used = usage.get("engagements_sent", 0)
        if eng_used > 0:
            output.append(f"💬 Engagements: {eng_used}/{FREE_MAX_ENGAGEMENTS} this month")
            output.append("")

    # ── Follow-up ready hint ──
    max_followups = PRO_MAX_FOLLOWUPS if tier == TIER_PRO else FREE_MAX_FOLLOWUPS
    total_followup_ready = 0
    for camp in campaigns:
        if camp.get("status") in ("active", "draft"):
            total_followup_ready += count_followup_ready(camp["id"], max_followups)
    if total_followup_ready > 0:
        output.append(
            f"💬 {total_followup_ready} prospect{'s' if total_followup_ready != 1 else ''} "
            "ready for follow-up — use send_followup()"
        )
        output.append("")

    # ── Paused campaigns hint ──
    paused_campaigns = [c for c in campaigns if c.get("status") == "paused"]
    if paused_campaigns:
        output.append(f"⏸️ {len(paused_campaigns)} paused campaign(s):")
        for pc in paused_campaigns[:3]:
            output.append(f"   └── {pc['name']} — resume_campaign(\"{pc['id'][:8]}...\")")
        output.append("")

    # ── Archived campaigns hint ──
    completed_campaigns = [c for c in campaigns if c.get("status") == "completed"]
    if completed_campaigns:
        output.append(f"📦 {len(completed_campaigns)} archived campaign(s)")
        output.append("")

    # ── Quick actions ──
    has_active = any(c.get("status") == "active" for c in campaigns)
    has_paused = len(paused_campaigns) > 0
    has_copilot = any(
        c.get("status") == "active" and c.get("mode") == "copilot"
        for c in campaigns
    )

    output.append("Quick actions:")
    output.append("├── \"any replies?\" → check_replies")
    output.append("├── \"what's next?\" → suggest_next_action")
    output.append("├── \"detailed report\" → campaign_report")
    if has_copilot:
        output.append("├── \"send messages\" → generate_and_send")
    if total_followup_ready > 0:
        output.append("├── \"send follow-up\" → send_followup")
    output.append("├── \"engage posts\" → engage_prospect")
    if has_active:
        output.append("├── \"pause outreach\" → pause_campaign")
    if has_paused:
        output.append("├── \"resume outreach\" → resume_campaign")
    output.append("├── \"export results\" → export_campaign")
    output.append("├── \"compare campaigns\" → compare_campaigns")
    output.append("├── \"edit campaign\" → edit_campaign")
    output.append("├── \"view conversation\" → show_conversation")
    output.append("├── \"retry errors\" → retry_failed")
    output.append("├── \"skip prospect\" → skip_prospect")
    output.append("├── \"stop everything\" → emergency_stop")
    output.append("└── \"create campaign\" → create_campaign")

    return "\n".join(output)


async def _show_campaign_detail(campaign_id: str) -> str:
    """Show detailed stats for a specific campaign."""

    campaign = get_campaign(campaign_id)
    if not campaign:
        return f"❌ Campaign not found: {campaign_id}"

    stats = get_campaign_stats(campaign_id)
    config = json.loads(campaign.get("config_json", "{}"))
    icp = json.loads(campaign.get("icp_json", "{}"))

    # Calculate days since creation
    import time
    created = campaign.get("created_at", 0)
    days = (int(time.time()) - created) // 86400 if created else 0

    output = [
        f"📊 Campaign: **{campaign['name']}** (Day {days})",
        f"   Mode: {'🤖 Autopilot' if campaign.get('mode') == 'autopilot' else '👤 Copilot'}",
        f"   Target: {config.get('target_description', 'N/A')}",
        "",
    ]

    # Stats tree
    total = stats.get("total_prospects", 0)
    invited = stats.get("invited", 0)
    connected = stats.get("connected", 0)
    replied = stats.get("replied", 0)
    hot = stats.get("hot_leads", 0)
    skipped = stats.get("skipped", 0)
    pending = total - invited - skipped

    output.append("Progress:")
    output.append(f"├── Invitations sent: {invited}")
    acc_str = f"{stats['acceptance_rate']:.0%}"
    mature = stats.get('mature_acceptance_rate', 0)
    if mature > 0 and mature != stats['acceptance_rate']:
        acc_str += f" (7d+: {mature:.0%})"
    output.append(f"├── Accepted: {connected} ({acc_str})" if invited > 0 else f"├── Accepted: {connected}")
    output.append(f"├── Replies: {replied} ({stats['reply_rate']:.0%})" if connected > 0 else f"├── Replies: {replied}")
    output.append(f"├── Hot leads: {hot} 🔥" if hot > 0 else f"├── Hot leads: {hot}")
    if skipped > 0:
        output.append(f"├── Skipped: {skipped}")
    output.append(f"└── Remaining: {pending} prospects queued")
    output.append("")

    # Funnel visualization
    if invited > 0:
        output.append("Funnel:")
        output.append(f"├── Queued:    {progress_bar(total, total, 20)} {total}")
        output.append(f"├── Sent:      {progress_bar(invited, total, 20)} {invited}")
        output.append(f"├── Connected: {progress_bar(connected, total, 20)} {connected}")
        output.append(f"├── Replied:   {progress_bar(replied, total, 20)} {replied}")
        output.append(f"└── Hot leads: {progress_bar(hot, total, 20)} {hot}")
        output.append("")

    # Velocity metrics
    velocity = get_campaign_velocity(campaign_id)
    cnt_accept = velocity.get("count_accepted", 0)
    if cnt_accept > 0:
        avg_tta = velocity.get("avg_time_to_accept")
        avg_ttr = velocity.get("avg_time_to_reply")
        output.append("Velocity:")
        output.append(f"\u251c\u2500\u2500 Avg time to accept: {format_duration(avg_tta)}")
        if avg_ttr is not None:
            output.append(f"\u2514\u2500\u2500 Avg time to reply: {format_duration(avg_ttr)}")
        else:
            output.append(f"\u2514\u2500\u2500 Avg time to reply: No replies yet")
        output.append("")

    # Outcomes section
    outcomes = get_campaign_outcomes(campaign_id)
    if outcomes["total_closed"] > 0:
        output.append("Outcomes:")
        output.append(f"\u251c\u2500\u2500 \U0001f3c6 Won: {outcomes['closed_happy']}")
        output.append(f"\u251c\u2500\u2500 \U0001f4c9 Lost: {outcomes['closed_unhappy']}")
        if outcomes["opted_out"] > 0:
            output.append(f"\u251c\u2500\u2500 \U0001f6ab Opted out: {outcomes['opted_out']}")
        output.append(f"\u2514\u2500\u2500 Conversion: {conversion_rate_display(outcomes['closed_happy'], outcomes['closed_unhappy'])}")
        output.append("")

    # Engagement stats for this campaign
    camp_eng = get_engagement_stats(campaign_id)
    camp_comments = camp_eng.get("comments", 0)
    camp_reactions = camp_eng.get("reactions", 0)
    camp_eng_total = camp_comments + camp_reactions
    if camp_eng_total > 0:
        output.append("Engagements:")
        output.append(f"├── Comments: {camp_comments}")
        output.append(f"└── Reactions: {camp_reactions}")
        output.append("")

    # Top prospects with status
    db = get_db()
    top_contacts = db.execute(
        """SELECT c.name, c.title, c.company, c.fit_score, o.status
           FROM contacts c
           JOIN outreaches o ON o.contact_id = c.id
           WHERE c.campaign_id = ?
           ORDER BY c.fit_score DESC
           LIMIT 5""",
        (campaign_id,),
    ).fetchall()
    db.close()

    if top_contacts:
        output.append("Top Prospects:")
        status_icons = {
            "pending": "⏳",
            "invited": "📤",
            "connected": "🤝",
            "messaged": "💬",
            "replied": "📩",
            "hot_lead": "🔥",
            "review_pending": "👀",
            "skipped": "⏭️",
            "opted_out": "🚫",
            "closed_happy": "✅",
            "closed_unhappy": "❌",
            "error": "⚠️",
        }
        for i, contact in enumerate(top_contacts):
            c = dict(contact)
            is_last = i == len(top_contacts) - 1
            prefix = "└──" if is_last else "├──"
            icon = status_icons.get(c.get("status", ""), "⚪")
            role = c.get("title", "")
            if c.get("company"):
                role += f" at {c['company']}" if role else c["company"]
            output.append(f"{prefix} {icon} {c['name']} — {role} ({stars(c.get('fit_score', 0))})")
        output.append("")

    return "\n".join(output)
