"""Tool: experiment_loop — Product Manager hypothesis engine.

Pulls all campaign performance data, runs LLM analysis,
generates 1-3 experiment hypotheses in 4 pillars:
Users, Customers, Shareholders, Data.
"""

from __future__ import annotations

import json
import logging
import time as _time
from datetime import datetime, timezone
from typing import Any

from ..db.queries import (
    get_campaign_outcomes,
    get_campaign_stats,
    get_campaign_velocity,
    get_deal_profiles,
    get_engagement_stats,
    get_monthly_usage,
    get_rate_limit_today,
    get_setting,
    get_stale_outreaches,
    get_weekly_invitation_sum,
    list_campaigns,
    list_experiments,
    save_experiment,
)
from ..formatter import format_duration

logger = logging.getLogger(__name__)

# Minimum invitations across all campaigns before analysis is useful
_MIN_INVITED = 5

# Max campaigns to include in snapshot (token budget)
_MAX_CAMPAIGNS = 5

_PILLAR_ICONS = {
    "users": "👥",
    "customers": "🤝",
    "shareholders": "💰",
    "data": "📊",
}

_PRIORITY_LABELS = {
    "high": "[HIGH]",
    "medium": "[MED]",
    "low": "[LOW]",
}

_EXPERIMENT_SYSTEM = (
    "You are a product manager analyzing LinkedIn outreach campaign data.\n"
    "Your job: identify patterns, generate experiment hypotheses, recommend next steps.\n\n"
    "4 pillars:\n"
    "- Users (prospects): Who responds, targeting quality, segment gaps\n"
    "- Customers (converters): Patterns among won deals vs lost deals\n"
    "- Shareholders (business): Efficiency, pipeline velocity, cost\n"
    "- Data (metrics): Anomalies, trends, benchmark comparison\n\n"
    "Benchmarks: acceptance 20-30% good, >35% excellent, <15% needs work.\n"
    "Reply rate: 10-20% of connected is good. Accept time: 2-5d typical.\n"
    "Reply time: 1-3d after connection typical.\n\n"
    "Output structured JSON only. No markdown, no explanation outside JSON."
)

_EXPERIMENT_PROMPT = """Analyze this campaign performance data and generate 1-3 experiment hypotheses.

{snapshot}

Return ONLY valid JSON:
{{
    "health_check": "1-2 sentence overall assessment",
    "hypotheses": [
        {{
            "pillar": "users|customers|shareholders|data",
            "title": "Short hypothesis (< 10 words)",
            "evidence": "Cite specific numbers from the data above",
            "suggested_test": "Concrete action to test this",
            "priority": "high|medium|low"
        }}
    ],
    "do_this_next": "Single most impactful action RIGHT NOW"
}}"""


async def run_experiment_loop(
    campaign_id: str = "",
    show_history: bool = False,
) -> str:
    """Run the experiment analysis loop."""
    # -- Pre-checks --
    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before running experiments.\n\n"
            "Please run `setup_profile` first."
        )

    # -- History mode --
    if show_history:
        return _format_history()

    # -- Gather data --
    snapshot, campaigns_data = _build_snapshot(campaign_id)
    if not campaigns_data:
        return snapshot  # Error message

    # -- LLM analysis --
    analysis = await _run_analysis(snapshot)
    if not analysis:
        return "❌ Experiment analysis failed. Check logs for details."

    # -- Persist --
    camp_ids = ",".join(c["id"] for c in campaigns_data)
    save_experiment(snapshot, json.dumps(analysis), camp_ids)

    # -- Format output --
    return _format_report(analysis)


# ──────────────────────────────────────────────
# Data Gathering
# ──────────────────────────────────────────────


def _build_snapshot(campaign_id: str = "") -> tuple[str, list[dict]]:
    """Build a compact text snapshot of all campaign data for LLM analysis.

    Returns (snapshot_text, campaigns_data_list).
    If not enough data, returns (error_message, []).
    """
    if campaign_id:
        from ..db.queries import get_campaign
        camp = get_campaign(campaign_id)
        if not camp:
            return (f"Campaign not found: {campaign_id}", [])
        campaigns = [camp]
    else:
        campaigns = list_campaigns("active") + list_campaigns("paused")

    if not campaigns:
        return (
            "No active or paused campaigns found.\n\n"
            "Create one first: `create_campaign(\"your target description\")`",
            [],
        )

    # Sort by invitation count (most active first), cap at _MAX_CAMPAIGNS
    campaigns_with_stats = []
    total_invited = 0

    for camp in campaigns:
        camp_id = camp["id"]
        stats = get_campaign_stats(camp_id)
        total_invited += stats.get("invited", 0)
        campaigns_with_stats.append({
            "id": camp_id,
            "campaign": camp,
            "stats": stats,
        })

    # Check minimum threshold
    if total_invited < _MIN_INVITED:
        return (
            f"Not enough data yet — only {total_invited} invitations sent "
            f"(need at least {_MIN_INVITED}).\n\n"
            "Keep running your campaigns and check back soon!",
            [],
        )

    # Sort by invited count desc, cap
    campaigns_with_stats.sort(
        key=lambda x: x["stats"].get("invited", 0), reverse=True,
    )
    top = campaigns_with_stats[:_MAX_CAMPAIGNS]
    overflow = len(campaigns_with_stats) - _MAX_CAMPAIGNS

    # Build snapshot text
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    lines = [f"## CAMPAIGN DATA (as of {today})\n"]

    for cws in top:
        camp = cws["campaign"]
        stats = cws["stats"]
        camp_id = camp["id"]

        config = {}
        try:
            config = json.loads(camp.get("config_json", "{}") or "{}")
        except (json.JSONDecodeError, TypeError):
            pass

        status = camp.get("status", "active")
        mode = camp.get("mode", "copilot")
        created = camp.get("created_at", 0)
        age_days = max(1, (_time.time() - created) // 86400) if created else 0
        target = config.get("target_description", "N/A")

        lines.append(
            f'### Campaign: "{camp.get("name", "Untitled")}" '
            f"({status}, Day {int(age_days)}, {mode})"
        )
        lines.append(f"Target: {target}")

        # Funnel
        total = stats.get("total_prospects", 0)
        invited = stats.get("invited", 0)
        connected = stats.get("connected", 0)
        replied = stats.get("replied", 0)
        hot = stats.get("hot_leads", 0)
        acc_rate = stats.get("acceptance_rate", 0)
        reply_rate = stats.get("reply_rate", 0)
        lines.append(
            f"Funnel: {total} prospects → {invited} invited → "
            f"{connected} connected ({acc_rate:.0f}%) → "
            f"{replied} replied ({reply_rate:.0f}%) → {hot} hot"
        )

        # Velocity
        velocity = get_campaign_velocity(camp_id)
        avg_tta = velocity.get("avg_time_to_accept")
        avg_ttr = velocity.get("avg_time_to_reply")
        if avg_tta is not None or avg_ttr is not None:
            parts = []
            if avg_tta is not None:
                parts.append(f"accept {format_duration(avg_tta)} avg")
            if avg_ttr is not None:
                parts.append(f"reply {format_duration(avg_ttr)} avg")
            lines.append(f"Velocity: {' | '.join(parts)}")

        # Outcomes
        outcomes = get_campaign_outcomes(camp_id)
        won = outcomes.get("closed_happy", 0)
        lost = outcomes.get("closed_unhappy", 0)
        opted = outcomes.get("opted_out", 0)
        total_closed = won + lost
        conv_pct = f"{won / total_closed * 100:.0f}%" if total_closed else "N/A"
        lines.append(
            f"Outcomes: {won} won, {lost} lost, {opted} opted_out ({conv_pct} conv)"
        )

        # Engagement
        eng = get_engagement_stats(camp_id)
        comments = eng.get("comments", 0)
        reactions = eng.get("reactions", 0)
        lines.append(f"Engagement: {comments} comments, {reactions} reactions")

        # Stale leads
        stale = get_stale_outreaches(camp_id, stale_days=14)
        if stale:
            stale_names = ", ".join(
                f"{s['name']} {s['days_stale']}d" for s in stale[:3]
            )
            lines.append(f"Stale (14d+): {len(stale)} leads ({stale_names})")

        # Won/Lost profiles
        won_profiles = get_deal_profiles(camp_id, "closed_happy", 3)
        for p in won_profiles:
            lines.append(
                f"Won: {p['name']} ({p['title']}, {p['company']}, fit={p['fit_score']:.1f})"
            )
        lost_profiles = get_deal_profiles(camp_id, "closed_unhappy", 3)
        for p in lost_profiles:
            lines.append(
                f"Lost: {p['name']} ({p['title']}, {p['company']}, fit={p['fit_score']:.1f})"
            )

        lines.append("")  # blank line between campaigns

    if overflow > 0:
        lines.append(f"(+ {overflow} more campaign(s) not shown)\n")

    # Account health
    rate = get_rate_limit_today()
    weekly = get_weekly_invitation_sum()
    usage = get_monthly_usage()
    lines.append("### Account Health")
    lines.append(
        f"Today: {rate.get('sent', 0)}/{rate.get('daily_limit', 15)} invitations "
        f"| Weekly: {weekly} "
        f"| Monthly: {usage.get('invitations_sent', 0)} sent, "
        f"{usage.get('messages_sent', 0)} msgs"
    )

    snapshot = "\n".join(lines)
    campaigns_data = [cws["campaign"] for cws in top]
    return snapshot, campaigns_data


# ──────────────────────────────────────────────
# LLM Analysis
# ──────────────────────────────────────────────


async def _run_analysis(snapshot: str) -> dict[str, Any] | None:
    """Send snapshot to LLM and get experiment hypotheses."""
    prompt = _EXPERIMENT_PROMPT.format(snapshot=snapshot)

    from ..config import has_local_llm_key, is_backend_mode

    try:
        if is_backend_mode() and not has_local_llm_key():
            from ..linkedin import get_linkedin_client
            client = get_linkedin_client()
            try:
                result = await client.analyze_experiments(snapshot)
            finally:
                await client.close()
            return result
        else:
            from ..ai.llm import LLMClient
            from ..ai.json_repair import parse_json

            llm_client = LLMClient()
            raw = await llm_client.generate(
                prompt,
                system=_EXPERIMENT_SYSTEM,
                temperature=0.4,
                max_tokens=2500,
            )
            return parse_json(raw, fallback={
                "health_check": "Analysis could not be parsed.",
                "hypotheses": [],
                "do_this_next": "Run campaign_report() for detailed metrics.",
            })
    except Exception as e:
        logger.error(f"Experiment analysis failed: {e}", exc_info=True)
        return None


# ──────────────────────────────────────────────
# Output Formatting
# ──────────────────────────────────────────────


def _format_report(analysis: dict[str, Any]) -> str:
    """Format the LLM analysis into a user-facing report."""
    today = datetime.now(timezone.utc).strftime("%b %d")
    out = [f"🔬 **Experiment Analysis** ({today})\n"]

    # Health check
    health = analysis.get("health_check", "")
    if health:
        out.append(f"**Health:** {health}\n")

    # Hypotheses
    hypotheses = analysis.get("hypotheses", [])
    if hypotheses:
        out.append("**Hypotheses:**\n")
        for i, hyp in enumerate(hypotheses, 1):
            pillar = hyp.get("pillar", "data").lower()
            icon = _PILLAR_ICONS.get(pillar, "📊")
            priority = hyp.get("priority", "medium").lower()
            plabel = _PRIORITY_LABELS.get(priority, "[MED]")
            title = hyp.get("title", "")
            evidence = hyp.get("evidence", "")
            test = hyp.get("suggested_test", "")

            out.append(f"{i}. {plabel} {icon} **{pillar.title()}:** {title}")
            if evidence:
                out.append(f"   Evidence: {evidence}")
            if test:
                out.append(f"   Test: {test}")
            out.append("")
    else:
        out.append("No hypotheses generated — try again with more data.\n")

    # Do this next
    do_next = analysis.get("do_this_next", "")
    if do_next:
        out.append(f"→ **Do this next:** {do_next}\n")

    out.append("─────────")
    out.append("`experiment_loop(show_history=True)` for past analyses.")

    return "\n".join(out)


def _format_history() -> str:
    """Format recent experiment history."""
    experiments = list_experiments(limit=5)
    if not experiments:
        return (
            "No experiment history yet.\n\n"
            "Run `experiment_loop()` to generate your first analysis."
        )

    out = ["🔬 **Experiment History** (last 5)\n"]

    for exp in experiments:
        created = exp.get("created_at", 0)
        dt = datetime.fromtimestamp(created, tz=timezone.utc)
        date_str = dt.strftime("%b %d, %H:%M")
        status = exp.get("status", "pending")
        status_icon = {
            "pending": "⏳",
            "tested": "🧪",
            "validated": "✅",
            "dismissed": "❌",
        }.get(status, "⏳")

        try:
            result = json.loads(exp.get("result_json", "{}"))
        except (json.JSONDecodeError, TypeError):
            result = {}

        health = result.get("health_check", "N/A")
        hyp_count = len(result.get("hypotheses", []))
        do_next = result.get("do_this_next", "")

        out.append(f"**{date_str}** {status_icon} {status}")
        out.append(f"  Health: {health}")
        out.append(f"  {hyp_count} hypothesis(es)")
        if do_next:
            out.append(f"  → {do_next}")

        # Show hypothesis titles
        for hyp in result.get("hypotheses", []):
            pillar = hyp.get("pillar", "data").lower()
            icon = _PILLAR_ICONS.get(pillar, "📊")
            out.append(f"  {icon} {hyp.get('title', '')}")

        out.append("")

    return "\n".join(out)
