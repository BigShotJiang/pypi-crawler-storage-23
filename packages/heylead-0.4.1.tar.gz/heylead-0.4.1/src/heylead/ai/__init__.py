"""HeyLead AI layer — LLM clients, voice analysis, message generation."""
