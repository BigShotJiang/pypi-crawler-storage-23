#cursor.py
import os


#used to calculate the corners of stdout
#Also accessible through 'aviothic.TERMINALWIDTH' or 'aviothic.TERMINALHEIGHT'
TERMINALWIDTH, TERMINALHEIGHT = os.get_terminal_size()


#using ANSI escape codes to show or hide the text cursor
def CursorShown(shown):
    if shown == 0:
        print("\033[?25l", end='')
    elif shown == 1:
        print("\033[?25h", end='')


#positions the text cursor to one of four corners based on user input and the dimensions of stdout
def CursorToCorner(corner):
    if corner == "topleft".lower():
        print("\033[H")

    elif corner == "topright".lower():
        print(f"\033[0;{TERMINALWIDTH}H", end='')

    elif corner == "bottomleft".lower():
        print(f"\033[{TERMINALHEIGHT};1H", end='')

    elif corner == "bottomright".lower():
        print(f"\033[{TERMINALHEIGHT};{TERMINALWIDTH}H", end='')