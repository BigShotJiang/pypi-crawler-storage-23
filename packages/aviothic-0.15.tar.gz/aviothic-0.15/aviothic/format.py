#format.py

#options for text:

#color options normal and bright for foreground and background
black_fg, bright_black_fg, black_bg, bright_black_bg = "\033[30m", "\033[30;1m", "\033[40m", "\033[40;1m"
red_fg, bright_red_fg, red_bg, bright_red_bg = "\033[31m", "\033[31;1m", "\033[41m", "\033[41;1m"
green_fg, bright_green_fg, green_bg, bright_green_bg = "\033[32m", "\033[32;1m", "\033[42m", "\033[42;1m"
yellow_fg, bright_yellow_fg, yellow_bg, bright_yellow_bg =	"\033[33m", "\033[33;1m", "\033[43m", "\033[43;1m"
blue_fg, bright_blue_fg, blue_bg, bright_blue_bg =	"\033[34m", "\033[34;1m", "\033[44m", "\033[44;1m"
magenta_fg, bright_magenta_fg, magenta_bg, bright_magenta_bg = "\033[35m", "\033[35;1m", "\033[45m", "\033[45;1m"
cyan_fg, bright_cyan_fg, cyan_bg, bright_cyan_bg =	"\033[36m", "\033[36;1m", "\033[46m", "\033[46;1m"
white_fg, bright_white_fg, white_bg, bright_white_bg = "\033[37m", "\033[37;1m", "\033[47m", "\033[47;1m"

#text formatting options
bold = "\033[1m"
italic = "\033[3m"
underline = "\033[4m"
strikethrough = "\033[9m"

#reset all formatting
reset = "\033[0m"


#tuples for accessing colors with indices
fg_color_list = (red_fg, bright_red_fg,
                green_fg, bright_green_fg,
                blue_fg, bright_blue_fg,
                yellow_fg, bright_yellow_fg,
                cyan_fg, bright_cyan_fg,
                magenta_fg, bright_magenta_fg, 
                black_fg, bright_black_fg,
                white_fg, bright_white_fg)

bg_color_list = (red_bg, bright_red_bg,
                green_bg, bright_green_bg,
                blue_bg, bright_blue_bg,
                yellow_bg, bright_yellow_bg,
                cyan_bg, bright_cyan_bg,
                magenta_bg, bright_magenta_bg, 
                black_bg, bright_black_bg,
                white_bg, bright_white_bg)