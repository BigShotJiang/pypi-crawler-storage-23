# How to install

Simply run this command in your terminal:
**`pip install aviothic`**

if you do not have pip installed, follow this guide:
https://pip.pypa.io/en/stable/installation/
# How to use

This python module utilizes the ANSI escape codes that are built into python's core functionality. These simple codes allow you to do a variety of things such as adding flair to strings with colors or with other special formatting.

## Adding formatting to your python strings:
In order to add special formatting to your strings in python, just use fstrings!
there are lots of colors and other format options available to use. In order to undo any formatting changes you may have made, add the variable `aviothic.format.reset` to the end of your string.

here's a simple example of how to change the visuals of how a string looks:

`#asigning variables`
`reset = aviothic.format.reset`
`color = aviothic.format.bright_red_fg`
`bold = aviothic.format.bold`

`#making the string bold and bright red, then reseting formatting after`
`print(f"{bold}{color}wow so bold and red!{reset}")`

Have fun making your strings pretty!
## Positioning the text cursor
description not finished sorry
