# IO Module Refactoring Plan

## Context
`src/routix/io.py` 파일을 기능별로 분리하여 모듈 구조를 개선합니다. 현재 파일은 7개의 함수가 모두 단일 파일에 위치해 있으며, 이를 YAML, JSON, Path 관련 기능별로 분리하여 유지보수성과 확장성을 높입니다.

## Target Structure
```
src/routix/
├── io/
│   ├── __init__.py      # 공개 API 재-export
│   ├── path.py          # init_timestamped_working_dir, extract_prefix_from_filename
│   ├── yaml.py          # object_to_yaml, yaml_to_object, tuple_to_pyyaml_key, pyyaml_key_to_tuple
│   └── json.py          # object_to_json
└── io.py               # (옵션) 구호 import 경로 유지용
```

## Implementation Steps

### 1. Create `src/routix/io/` directory and modules

#### `src/routix/io/path.py`
- `init_timestamped_working_dir()` - timestamped working directory 생성
- `extract_prefix_from_filename()` - 파일명에서 prefix 추출

#### `src/routix/io/yaml.py`
- `object_to_yaml()` - Python object to YAML 저장
- `yaml_to_object()` - YAML 파일에서 object 로드
- `tuple_to_pyyaml_key()` - tuple key를 YAML format으로 변환
- `pyyaml_key_to_tuple()` - YAML format key를 tuple로 변환

#### `src/routix/io/json.py`
- `object_to_json()` - Python object to JSON 저장

#### `src/routix/io/__init__.py`
```python
from .path import init_timestamped_working_dir, extract_prefix_from_filename
from .yaml import object_to_yaml, yaml_to_object, tuple_to_pyyaml_key, pyyaml_key_to_tuple
from .json import object_to_json

__all__ = [
    "init_timestamped_working_dir",
    "extract_prefix_from_filename",
    "object_to_yaml",
    "yaml_to_object",
    "tuple_to_pyyaml_key",
    "pyyaml_key_to_tuple",
    "object_to_json",
]
```

### 2. Update import statements in dependent files

- `src/routix/dynamic_data_object.py`
- `src/routix/report/subroutine_report_statistics.py`
- `src/routix/metric_time_series/metric_time_series.py`
- `src/routix/metric_time_series/named_time_series_store.py`

### 3. Remove old `src/routix/io.py` (after verification)

## Verification Steps
1. `python -c "from routix.io import object_to_yaml, object_to_json, yaml_to_object"` - import 확인
2. 기존 테스트 실행: `pytest` 또는 해당 프로젝트의 테스트 커맨드
3. 직렬화/역직렬화 기능 테스트
