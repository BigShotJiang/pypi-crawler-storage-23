psiaudio.stim module
====================

.. automodule:: psiaudio.stim
   :members:
   :undoc-members:
   :show-inheritance:
