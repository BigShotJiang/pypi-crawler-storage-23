========
Examples
========

This page contains example plots demonstrating functionality provided by `psiaudio`. These examples are a great way to get started quickly. Click on any image to see the full image and source code.
