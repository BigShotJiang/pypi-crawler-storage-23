# -*- coding: utf-8 -*-
"""Clouvel Formatters — dict→markdown formatting for tool output.

Extracted from tool_dispatch.py to reduce God Object size.
"""
