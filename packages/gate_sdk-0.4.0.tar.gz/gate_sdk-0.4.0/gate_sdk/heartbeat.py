"""
Gate SDK - Heartbeat Manager

Manages heartbeat token acquisition and validation.
Heartbeat tokens prove Gate is alive and enforcing policy.
Required for all signing operations.

Features:
- Per-signer token cache (multi-signer support)
- Automatic refresh with jitter per signer
- Exponential backoff on failures
- LRU eviction when max signers reached
- Idle TTL eviction for unused signers
- Local rate limiting per signer
- Client instance metadata tracking
"""

import time
import threading
import random
import uuid
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass, field

from .http import HttpClient
from .errors import GateError, GateAuthError

logger = logging.getLogger(__name__)


@dataclass
class HeartbeatToken:
    """Heartbeat token with expiration"""
    token: str
    expires_at: int  # Unix timestamp (seconds)
    jti: Optional[str] = None  # JWT ID (for reference)
    policy_hash: Optional[str] = None  # Policy hash (for reference)


@dataclass
class SignerHeartbeatEntry:
    """Per-signer heartbeat state"""
    token: Optional[HeartbeatToken] = None
    refresh_timer: Optional[threading.Timer] = None
    consecutive_failures: int = 0
    last_acquire_attempt_ms: float = 0
    last_used_ms: float = 0
    acquiring: bool = False
    acquire_event: Optional[threading.Event] = None  # signals when acquisition completes


class HeartbeatManager:
    """Manages heartbeat token acquisition and refresh (per-signer cache)"""

    def __init__(
        self,
        http_client: HttpClient,
        tenant_id: str,
        signer_id: str,
        environment: str = "prod",
        refresh_interval_seconds: int = 10,
        client_instance_id: Optional[str] = None,
        sdk_version: Optional[str] = None,
        api_key: Optional[str] = None,
        max_signers: int = 20,
        signer_idle_ttl_seconds: int = 300,
        local_rate_limit_seconds: float = 2.1,
    ):
        """
        Initialize heartbeat manager.

        Args:
            http_client: HTTP client for API calls
            tenant_id: Tenant ID
            signer_id: Default signer ID (e.g., "kms:alias/prod-signer")
            environment: Environment (default: "prod")
            refresh_interval_seconds: How often to refresh heartbeat (default: 10s)
            client_instance_id: Unique client instance ID (auto-generated if not provided)
            sdk_version: SDK version for tracking (default: "1.0.0")
            api_key: Optional API key for heartbeat authentication
            max_signers: Max concurrent signer entries (default: 20)
            signer_idle_ttl_seconds: Evict signers idle longer than this (default: 300s / 5 min)
            local_rate_limit_seconds: Min seconds between acquire attempts per signer (default: 2.1s)
        """
        self._http_client = http_client
        self._tenant_id = tenant_id
        self._default_signer_id = self._normalize_signer_id(signer_id)
        self._environment = environment
        self._base_refresh_interval = refresh_interval_seconds
        self._client_instance_id = client_instance_id or str(uuid.uuid4())
        self._sdk_version = sdk_version or "1.0.0"
        self._max_backoff_seconds = 30
        self._api_key = api_key

        # Per-signer cache
        self._max_signers = max_signers
        self._signer_idle_ttl_ms = signer_idle_ttl_seconds * 1000
        self._local_rate_limit_ms = local_rate_limit_seconds * 1000

        self._signer_entries: Dict[str, SignerHeartbeatEntry] = {}
        self._lock = threading.Lock()
        self._started = False
        self._eviction_timer: Optional[threading.Timer] = None

        # Legacy compat: keep _signer_id as alias for _default_signer_id
        self._signer_id = self._default_signer_id

    @staticmethod
    def _normalize_signer_id(signer_id: str) -> str:
        """Normalize signer_id by stripping alias/ prefix."""
        if signer_id.startswith("alias/"):
            return signer_id[len("alias/"):]
        return signer_id

    def start(self, wait_for_initial: bool = True) -> None:
        """
        Start heartbeat manager.

        Args:
            wait_for_initial: If True, acquire initial heartbeat for default signer before returning.
        """
        if self._started:
            return

        self._started = True

        # Start eviction timer
        self._start_eviction_timer()

        # Acquire initial heartbeat for default signer
        if self._default_signer_id and self._default_signer_id != "unknown":
            if wait_for_initial:
                max_retries = 5
                retry_delay = 0.5
                heartbeat_acquired = False
                for attempt in range(max_retries):
                    try:
                        print(f"[HEARTBEAT] Attempting to acquire initial heartbeat (attempt {attempt + 1}/{max_retries})...")
                        token = self.get_token_for_signer(self._default_signer_id, max_wait_seconds=5.0)
                        if token:
                            print(f"[HEARTBEAT] Initial heartbeat acquired successfully (token length: {len(token)})")
                            heartbeat_acquired = True
                            break
                    except Exception as e:
                        if attempt < max_retries - 1:
                            print(f"[HEARTBEAT] Failed to acquire initial heartbeat (attempt {attempt + 1}/{max_retries}): {e}, retrying in {retry_delay}s...")
                            time.sleep(retry_delay)
                            retry_delay *= 1.5
                        else:
                            print(f"[HEARTBEAT] Failed to acquire initial heartbeat after {max_retries} attempts: {e}")
                            print(f"[HEARTBEAT] Will continue - sign() calls may fail until heartbeat is acquired")

                if not heartbeat_acquired:
                    print(f"[HEARTBEAT] WARNING: Initial heartbeat not acquired - sign() calls will fail until heartbeat is available")
            else:
                try:
                    self.get_token_for_signer(self._default_signer_id, max_wait_seconds=5.0)
                except Exception as e:
                    print(f"[HEARTBEAT] Failed to acquire initial heartbeat: {e}")

    def stop(self) -> None:
        """Stop heartbeat manager and clean up all timers."""
        if not self._started:
            return

        self._started = False

        # Cancel eviction timer
        if self._eviction_timer:
            self._eviction_timer.cancel()
            self._eviction_timer = None

        # Cancel all per-signer refresh timers
        with self._lock:
            for entry in self._signer_entries.values():
                if entry.refresh_timer:
                    entry.refresh_timer.cancel()
            self._signer_entries.clear()

    def get_token_for_signer(self, signer_id: str, max_wait_seconds: float = 2.0) -> str:
        """
        Get heartbeat token for a specific signer. Creates entry if needed.

        Args:
            signer_id: The signer to get a token for
            max_wait_seconds: Max time to wait for token acquisition (default: 2.0s)

        Returns:
            Heartbeat token string

        Raises:
            GateError: If heartbeat manager not started or token unavailable
        """
        if not self._started:
            raise GateError("HEARTBEAT_MISSING",
                            code="HEARTBEAT_MISSING")

        normalized = self._normalize_signer_id(signer_id)
        start_time = time.time()
        max_wait_ms = max_wait_seconds * 1000

        with self._lock:
            entry = self._signer_entries.get(normalized)

            if entry is not None:
                # Update last used time
                entry.last_used_ms = time.time() * 1000

                # Cache hit: return valid token immediately
                if entry.token and entry.token.expires_at > int(time.time()) + 2:
                    return entry.token.token
            else:
                # New signer: evict LRU if at capacity
                if len(self._signer_entries) >= self._max_signers:
                    self._evict_lru_entry()

                entry = SignerHeartbeatEntry(
                    last_used_ms=time.time() * 1000,
                )
                self._signer_entries[normalized] = entry

        # If another thread is already acquiring for this signer, wait on its event
        if entry.acquiring and entry.acquire_event:
            remaining = max(0, max_wait_seconds - (time.time() - start_time))
            if remaining > 0:
                entry.acquire_event.wait(timeout=remaining)

            # Check if token is now available
            with self._lock:
                if entry.token and entry.token.expires_at > int(time.time()) + 2:
                    return entry.token.token

        # Check local rate limit
        now_ms = time.time() * 1000
        time_since_last = now_ms - entry.last_acquire_attempt_ms
        if time_since_last < self._local_rate_limit_ms:
            wait_needed_ms = self._local_rate_limit_ms - time_since_last
            remaining_ms = max(0, max_wait_ms - (time.time() - start_time) * 1000)
            if wait_needed_ms >= remaining_ms:
                raise GateError(
                    "HEARTBEAT_MISSING",
                    code="HEARTBEAT_MISSING",
                )
            if wait_needed_ms > 0:
                time.sleep(wait_needed_ms / 1000)

        # Acquire synchronously in calling thread
        self._acquire_heartbeat_for_signer(normalized, entry)

        # Return token if valid
        with self._lock:
            if entry.token and entry.token.expires_at > int(time.time()) + 2:
                return entry.token.token

        raise GateError(
            "HEARTBEAT_MISSING",
            code="HEARTBEAT_MISSING",
        )

    def _acquire_heartbeat_for_signer(self, signer_id: str, entry: SignerHeartbeatEntry) -> None:
        """Acquire a heartbeat token for a specific signer. NEVER logs token value (security)."""
        event = threading.Event()
        entry.acquiring = True
        entry.acquire_event = event
        entry.last_acquire_attempt_ms = time.time() * 1000

        try:
            if not self._api_key:
                raise ValueError(
                    "Heartbeat API key is required. GATE_HEARTBEAT_KEY must be set in environment or passed to HeartbeatManager."
                )

            headers = {"x-gate-heartbeat-key": self._api_key}

            response = self._http_client.request(
                method="POST",
                path="/api/v1/gate/heartbeat",
                headers=headers,
                body={
                    "tenantId": self._tenant_id,
                    "signerId": signer_id,
                    "environment": self._environment,
                    "clientInstanceId": self._client_instance_id,
                    "sdkVersion": self._sdk_version,
                },
            )

            if response.get("success"):
                data = response.get("data", {})
                token = data.get("heartbeatToken")
                expires_at = data.get("expiresAt")
                jti = data.get("jti")
                policy_hash = data.get("policyHash")

                if not token or not expires_at:
                    raise GateError("Invalid heartbeat response: missing token or expiresAt")

                # Check if entry was evicted during fetch
                with self._lock:
                    if signer_id not in self._signer_entries:
                        return

                    entry.token = HeartbeatToken(
                        token=token,
                        expires_at=expires_at,
                        jti=jti,
                        policy_hash=policy_hash,
                    )
                    entry.consecutive_failures = 0

                print(f"[HEARTBEAT] Acquired heartbeat token for signer '{signer_id}'", {
                    "expires_at": expires_at,
                    "jti": jti,
                    "policy_hash": policy_hash[:8] + "..." if policy_hash else None,
                })

                # Schedule refresh for this signer
                self._schedule_refresh_for_signer(signer_id, entry)
            else:
                error = response.get("error", {})
                raise GateError(f"Heartbeat acquisition failed: {error.get('message', 'Unknown error')}")

        except Exception as e:
            with self._lock:
                entry.consecutive_failures += 1
            print(f"[HEARTBEAT] Failed to acquire heartbeat for signer '{signer_id}': {str(e)}")
            raise
        finally:
            entry.acquiring = False
            event.set()
            entry.acquire_event = None

    def _schedule_refresh_for_signer(self, signer_id: str, entry: SignerHeartbeatEntry) -> None:
        """Schedule a background refresh timer for a specific signer."""
        if not self._started:
            return

        with self._lock:
            if signer_id not in self._signer_entries:
                return

        # Cancel existing timer
        if entry.refresh_timer:
            entry.refresh_timer.cancel()
            entry.refresh_timer = None

        base_interval = self._base_refresh_interval
        jitter = random.uniform(0, 2)
        backoff = self._calculate_backoff(entry)
        interval = base_interval + jitter + backoff

        def refresh():
            if not self._started:
                return
            with self._lock:
                if signer_id not in self._signer_entries:
                    return

            try:
                self._acquire_heartbeat_for_signer(signer_id, entry)
            except Exception as e:
                logger.debug(f"[HEARTBEAT] Background refresh failed for signer '{signer_id}': {e}")
                # _acquire_heartbeat_for_signer already increments consecutive_failures
                # Reschedule with backoff
                self._schedule_refresh_for_signer(signer_id, entry)

        timer = threading.Timer(interval, refresh)
        timer.daemon = True
        timer.start()
        entry.refresh_timer = timer

    def _calculate_backoff(self, entry: SignerHeartbeatEntry) -> float:
        """Calculate exponential backoff for a signer entry (capped at max_backoff_seconds)."""
        if entry.consecutive_failures == 0:
            return 0.0
        return min(
            2 ** entry.consecutive_failures,
            self._max_backoff_seconds,
        )

    def _evict_lru_entry(self) -> None:
        """Evict the least-recently-used signer entry. Must be called under self._lock."""
        if not self._signer_entries:
            return

        lru_signer = min(self._signer_entries, key=lambda k: self._signer_entries[k].last_used_ms)
        entry = self._signer_entries.pop(lru_signer)
        if entry.refresh_timer:
            entry.refresh_timer.cancel()

    def _start_eviction_timer(self) -> None:
        """Start the repeating idle eviction timer (every 60s)."""
        if self._eviction_timer:
            self._eviction_timer.cancel()

        def evict_idle():
            if not self._started:
                return
            now_ms = time.time() * 1000
            with self._lock:
                to_evict = [
                    sid for sid, entry in self._signer_entries.items()
                    if now_ms - entry.last_used_ms > self._signer_idle_ttl_ms
                ]
                for sid in to_evict:
                    entry = self._signer_entries.pop(sid)
                    if entry.refresh_timer:
                        entry.refresh_timer.cancel()

            # Reschedule
            if self._started:
                self._start_eviction_timer()

        timer = threading.Timer(60.0, evict_idle)
        timer.daemon = True
        timer.start()
        self._eviction_timer = timer

    # ── Backward compatibility ──────────────────────────────────────────

    def get_token(self) -> Optional[str]:
        """
        Get current heartbeat token for the default signer (deprecated).

        Returns:
            Heartbeat token string, or None if missing/expired
        """
        with self._lock:
            entry = self._signer_entries.get(self._default_signer_id)
            if not entry or not entry.token:
                return None
            if entry.token.expires_at <= int(time.time()) + 2:
                return None
            return entry.token.token

    def is_valid(self) -> bool:
        """Check if current heartbeat token is valid (deprecated)."""
        return self.get_token() is not None

    def update_signer_id(self, signer_id: str) -> None:
        """
        Update default signer ID (deprecated).

        No longer invalidates cached tokens — just updates the default signer reference.
        """
        normalized = self._normalize_signer_id(signer_id)
        self._default_signer_id = normalized
        self._signer_id = normalized

    def get_client_instance_id(self) -> str:
        """Get client instance ID (for tracking)"""
        return self._client_instance_id

    # Legacy alias used by old _refresh_loop (removed)
    @property
    def _current_token(self) -> Optional[HeartbeatToken]:
        """Legacy property: returns default signer's token."""
        with self._lock:
            entry = self._signer_entries.get(self._default_signer_id)
            return entry.token if entry else None

    @property
    def _consecutive_failures(self) -> int:
        """Legacy property: returns default signer's failure count."""
        with self._lock:
            entry = self._signer_entries.get(self._default_signer_id)
            return entry.consecutive_failures if entry else 0


def require_heartbeat(func):
    """
    Decorator to require valid heartbeat before executing function.

    Usage:
        @require_heartbeat
        def sign(...):
            ...
    """
    def wrapper(self, *args, **kwargs):
        # Check if heartbeat manager exists and has valid token
        if hasattr(self, '_heartbeat_manager'):
            token = self._heartbeat_manager.get_token()
            if not token:
                raise GateError(
                    "HEARTBEAT_MISSING",
                    "Signing blocked: Heartbeat token is missing or expired. Gate must be alive and enforcing policy."
                )
        else:
            # No heartbeat manager - fail hard
            raise GateError(
                "HEARTBEAT_MISSING",
                "Signing blocked: Heartbeat manager not initialized. Gate heartbeat is required."
            )

        return func(self, *args, **kwargs)
    return wrapper
