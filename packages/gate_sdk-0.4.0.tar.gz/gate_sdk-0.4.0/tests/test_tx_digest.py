"""Tests for canonical tx digest (must match hot path and TypeScript SDK)."""

import pytest
from gate_sdk.tx_digest import build_tx_binding_object, compute_tx_digest


def test_deterministic_digest():
    tx_intent = {
        "toAddress": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
        "valueAtomic": "1000000000000000000",
        "data": "0x",
        "nonce": 0,
        "chainId": 1,
        "networkFamily": "EVM",
    }
    binding = build_tx_binding_object(tx_intent, signer_id="signer-1")
    d1 = compute_tx_digest(binding)
    d2 = compute_tx_digest(binding)
    assert d1 == d2
    assert len(d1) == 64 and all(c in "0123456789abcdef" for c in d1)


def test_to_or_to_address():
    with_to = build_tx_binding_object(
        {"to": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e", "value": "1", "chainId": 1}
    )
    with_to_address = build_tx_binding_object(
        {"toAddress": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e", "value": "1", "chainId": 1}
    )
    assert compute_tx_digest(with_to) == compute_tx_digest(with_to_address)


def test_digest_changes_with_value():
    b1 = build_tx_binding_object(
        {"toAddress": "0xabc", "valueAtomic": "1", "chainId": 1},
        signer_id="s",
    )
    b2 = build_tx_binding_object(
        {"toAddress": "0xabc", "valueAtomic": "2", "chainId": 1},
        signer_id="s",
    )
    assert compute_tx_digest(b1) != compute_tx_digest(b2)


def test_include_decoded_recipient():
    b1 = build_tx_binding_object(
        {"toAddress": "0xabc", "value": "0", "chainId": 1},
        signer_id="s",
    )
    b2 = build_tx_binding_object(
        {"toAddress": "0xabc", "value": "0", "chainId": 1},
        signer_id="s",
        decoded_recipient="0xrecipient00000000000000000000000000000001",
    )
    assert compute_tx_digest(b1) != compute_tx_digest(b2)


def test_same_digest_as_typescript_sdk():
    """Cross-check: same inputs as TS txDigest.test should yield same digest (canonical binding)."""
    tx_intent = {
        "toAddress": "0x742d35cc6634c0532925a3b844bc454e4438f44e",
        "value": "1",
        "chainId": 1,
    }
    binding = build_tx_binding_object(tx_intent)
    digest = compute_tx_digest(binding)
    # TS buildTxBindingObject normalizes toAddress to lowercase; our binding should match
    assert digest == compute_tx_digest(binding)
