"""
Unit tests for gate_sdk.stepup (StepUpPoller).
"""

import time
from unittest.mock import Mock, patch

import pytest

from gate_sdk.stepup import StepUpPoller
from gate_sdk.errors import GateNotFoundError, GateError, StepUpTimeoutError


@pytest.fixture
def mock_http():
    return Mock()


@pytest.fixture
def poller(mock_http):
    return StepUpPoller(
        http_client=mock_http,
        tenant_id="tenant-1",
        polling_interval_ms=50,
        max_wait_ms=500,
    )


def test_get_status_returns_status_response(poller, mock_http):
    mock_http.request.return_value = {
        "status": "PENDING",
        "tenant_id": "tenant-1",
        "request_id": "req-1",
        "decision": None,
    }
    out = poller.get_status("req-1")
    assert out["status"] == "PENDING"
    assert out["requestId"] == "req-1"
    mock_http.request.assert_called_once()
    call_kw = mock_http.request.call_args[1]
    assert call_kw["method"] == "GET"
    assert "tenantId=tenant-1" in call_kw["path"]
    assert "requestId=req-1" in call_kw["path"]


def test_get_status_uses_data_wrapper(poller, mock_http):
    mock_http.request.return_value = {
        "data": {
            "status": "APPROVED",
            "tenant_id": "t",
            "request_id": "r",
            "decision": "ALLOW",
        },
    }
    out = poller.get_status("r")
    assert out["status"] == "APPROVED"
    assert out["decision"] == "ALLOW"


def test_get_status_raises_not_found(poller, mock_http):
    mock_http.request.side_effect = GateNotFoundError("not found")
    with pytest.raises(GateNotFoundError):
        poller.get_status("req-1")


def test_get_status_rewrites_gate_error_not_found_code(poller, mock_http):
    err = GateError("not found", code="NOT_FOUND")
    mock_http.request.side_effect = err
    with pytest.raises(GateNotFoundError):
        poller.get_status("req-1")


def test_get_status_ttl_expired_overrides_status(poller, mock_http):
    with patch("gate_sdk.stepup.now_epoch_seconds", return_value=1000):
        mock_http.request.return_value = {
            "status": "PENDING",
            "request_id": "r",
            "tenant_id": "t",
            "ttl": 999,
        }
        out = poller.get_status("r")
        assert out["status"] == "EXPIRED"


def test_await_decision_returns_on_approved(poller, mock_http):
    mock_http.request.return_value = {
        "status": "APPROVED",
        "request_id": "r",
        "tenant_id": "t",
        "decision": "ALLOW",
        "correlation_id": "c1",
    }
    result = poller.await_decision("r", max_wait_ms=1000, interval_ms=20)
    assert result["status"] == "APPROVED"
    assert result["decision"] == "ALLOW"
    assert result["requestId"] == "r"


def test_await_decision_returns_on_denied(poller, mock_http):
    mock_http.request.return_value = {
        "status": "DENIED",
        "request_id": "r",
        "tenant_id": "t",
        "decision": "BLOCK",
    }
    result = poller.await_decision("r", max_wait_ms=1000, interval_ms=20)
    assert result["status"] == "DENIED"


def test_await_decision_returns_expired_by_ttl(poller, mock_http):
    with patch("gate_sdk.stepup.now_epoch_seconds", return_value=1000):
        mock_http.request.return_value = {
            "status": "PENDING",
            "request_id": "r",
            "tenant_id": "t",
            "ttl": 999,
        }
        result = poller.await_decision("r", max_wait_ms=1000, interval_ms=20)
        assert result["status"] == "EXPIRED"


def test_await_decision_raises_timeout(poller, mock_http):
    mock_http.request.return_value = {"status": "PENDING", "request_id": "r", "tenant_id": "t"}
    with pytest.raises(StepUpTimeoutError):
        poller.await_decision("r", max_wait_ms=80, interval_ms=30)


def test_await_decision_raises_not_found(poller, mock_http):
    mock_http.request.side_effect = GateNotFoundError("not found")
    with pytest.raises(GateNotFoundError):
        poller.await_decision("r", max_wait_ms=200, interval_ms=20)


def test_await_decision_retries_on_gate_error_then_times_out(poller, mock_http):
    mock_http.request.side_effect = GateError("temp")  # every call raises
    with pytest.raises(StepUpTimeoutError):
        poller.await_decision("r", max_wait_ms=200, interval_ms=30)


def test_clamp_ttl_none_returns_default(poller):
    assert poller.clamp_ttl(None) == 600


def test_clamp_ttl_clamps_to_min(poller):
    assert poller.clamp_ttl(100) == 300


def test_clamp_ttl_clamps_to_max(poller):
    assert poller.clamp_ttl(2000) == 900


def test_clamp_ttl_in_range_unchanged(poller):
    assert poller.clamp_ttl(500) == 500
