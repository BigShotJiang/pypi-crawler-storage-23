"""
Tests for Gate SDK HeartbeatManager (per-signer token cache)
"""

import time
import threading
import pytest
from unittest.mock import Mock, patch, MagicMock

from gate_sdk.heartbeat import HeartbeatManager, HeartbeatToken, SignerHeartbeatEntry
from gate_sdk.errors import GateError


def make_heartbeat_response(signer_id="test-signer", expires_in=60):
    """Helper: build a successful heartbeat API response."""
    return {
        "success": True,
        "data": {
            "heartbeatToken": f"token-for-{signer_id}-{int(time.time())}",
            "expiresAt": int(time.time()) + expires_in,
            "jti": f"jti-{signer_id}",
            "policyHash": "abcdef1234567890",
        },
    }


def create_manager(**overrides):
    """Helper: create a HeartbeatManager with a mocked HTTP client."""
    http_client = Mock()
    defaults = dict(
        http_client=http_client,
        tenant_id="test-tenant",
        signer_id="default-signer",
        environment="test",
        refresh_interval_seconds=600,  # large so background refreshes don't fire during tests
        api_key="test-api-key",
        max_signers=3,
        signer_idle_ttl_seconds=300,
        local_rate_limit_seconds=2.1,
    )
    defaults.update(overrides)
    mgr = HeartbeatManager(**defaults)
    return mgr, http_client


class TestCacheHit:
    def test_cache_hit_returns_immediately(self):
        """Valid cached token returned without an HTTP call."""
        mgr, http = create_manager()
        http.request.return_value = make_heartbeat_response("signer-a")

        mgr._started = True  # skip start() to avoid initial acquire complexity
        token1 = mgr.get_token_for_signer("signer-a")
        assert http.request.call_count == 1

        # Second call should be a cache hit — no new HTTP call
        token2 = mgr.get_token_for_signer("signer-a")
        assert http.request.call_count == 1
        assert token1 == token2

        mgr.stop()


class TestSignerIsolation:
    def test_different_signers_get_independent_tokens(self):
        """Signer A and B each get their own token via separate HTTP calls."""
        mgr, http = create_manager()

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True

        token_a = mgr.get_token_for_signer("signer-a")
        token_b = mgr.get_token_for_signer("signer-b")

        assert http.request.call_count == 2
        assert "signer-a" in token_a
        assert "signer-b" in token_b

        mgr.stop()

    def test_switching_signers_does_not_invalidate(self):
        """Token for signer A survives after fetching for signer B."""
        mgr, http = create_manager(local_rate_limit_seconds=0)

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True

        token_a1 = mgr.get_token_for_signer("signer-a")
        _ = mgr.get_token_for_signer("signer-b")

        # signer-a token should still be cached
        token_a2 = mgr.get_token_for_signer("signer-a")
        assert token_a1 == token_a2
        # Only 2 HTTP calls: signer-a + signer-b (no re-fetch for signer-a)
        assert http.request.call_count == 2

        mgr.stop()


class TestLRUEviction:
    def test_lru_eviction_at_max_signers(self):
        """Oldest entry evicted when max_signers exceeded."""
        mgr, http = create_manager(max_signers=2, local_rate_limit_seconds=0)

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True

        mgr.get_token_for_signer("signer-a")
        mgr.get_token_for_signer("signer-b")

        # Adding signer-c should evict signer-a (LRU)
        mgr.get_token_for_signer("signer-c")

        assert "signer-a" not in mgr._signer_entries
        assert "signer-b" in mgr._signer_entries
        assert "signer-c" in mgr._signer_entries

        mgr.stop()


class TestIdleEviction:
    def test_idle_eviction(self):
        """Unused signer's entry + timer removed after TTL."""
        mgr, http = create_manager(signer_idle_ttl_seconds=0, local_rate_limit_seconds=0)

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True

        mgr.get_token_for_signer("signer-idle")

        # Manually set last_used far in the past
        with mgr._lock:
            mgr._signer_entries["signer-idle"].last_used_ms = 0

        # Trigger eviction manually (rather than waiting 60s for timer)
        now_ms = time.time() * 1000
        with mgr._lock:
            to_evict = [
                sid for sid, entry in mgr._signer_entries.items()
                if now_ms - entry.last_used_ms > mgr._signer_idle_ttl_ms
            ]
            for sid in to_evict:
                entry = mgr._signer_entries.pop(sid)
                if entry.refresh_timer:
                    entry.refresh_timer.cancel()

        assert "signer-idle" not in mgr._signer_entries

        mgr.stop()


class TestLocalRateLimit:
    def test_local_rate_limit(self):
        """Second fetch for same signer within rate limit window doesn't make HTTP call."""
        mgr, http = create_manager(local_rate_limit_seconds=2.1)

        http.request.return_value = make_heartbeat_response("signer-a")
        mgr._started = True

        # First call acquires
        mgr.get_token_for_signer("signer-a")
        assert http.request.call_count == 1

        # Expire the cached token to force re-acquire attempt
        with mgr._lock:
            entry = mgr._signer_entries["signer-a"]
            entry.token = HeartbeatToken(token="expired", expires_at=0)

        # Rate limit should prevent a new HTTP call within 2.1s window
        # With max_wait_seconds=0.1 (less than rate limit wait), should raise
        with pytest.raises(GateError):
            mgr.get_token_for_signer("signer-a", max_wait_seconds=0.1)

        # Still only 1 HTTP call
        assert http.request.call_count == 1

        mgr.stop()


class TestConcurrentRequests:
    def test_concurrent_requests_share_fetch(self):
        """Two threads calling for same new signer result in 1 HTTP call."""
        mgr, http = create_manager(local_rate_limit_seconds=0)

        call_count = 0
        call_lock = threading.Lock()

        def slow_response(**kwargs):
            nonlocal call_count
            with call_lock:
                call_count += 1
            time.sleep(0.3)  # Simulate slow network
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = slow_response
        mgr._started = True

        results = [None, None]
        errors = [None, None]

        def fetch(idx):
            try:
                results[idx] = mgr.get_token_for_signer("shared-signer", max_wait_seconds=5.0)
            except Exception as e:
                errors[idx] = e

        t1 = threading.Thread(target=fetch, args=(0,))
        t2 = threading.Thread(target=fetch, args=(1,))
        t1.start()
        time.sleep(0.05)  # Stagger slightly so t1 starts acquiring first
        t2.start()
        t1.join(timeout=10)
        t2.join(timeout=10)

        # Both should succeed
        assert errors[0] is None, f"Thread 0 error: {errors[0]}"
        assert errors[1] is None, f"Thread 1 error: {errors[1]}"
        assert results[0] is not None
        assert results[1] is not None

        # Should be at most 2 calls (t2 may have started before t1's acquire_event was set)
        # But if properly coalesced, only 1
        # Due to race conditions in tests, accept 1-2
        assert call_count <= 2

        mgr.stop()


class TestBackwardCompat:
    def test_backward_compat_get_token(self):
        """get_token() returns default signer's token."""
        mgr, http = create_manager()
        http.request.return_value = make_heartbeat_response("default-signer")
        mgr._started = True

        # Acquire via new API
        mgr.get_token_for_signer("default-signer")

        # Old API should return same token
        token = mgr.get_token()
        assert token is not None
        assert "default-signer" in token

        mgr.stop()

    def test_backward_compat_update_signer_id(self):
        """update_signer_id() updates default, doesn't invalidate other entries."""
        mgr, http = create_manager(local_rate_limit_seconds=0)

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True

        # Acquire for signer-a
        token_a = mgr.get_token_for_signer("signer-a")

        # Update default to signer-b (should NOT invalidate signer-a)
        mgr.update_signer_id("signer-b")

        # signer-a still cached
        token_a2 = mgr.get_token_for_signer("signer-a")
        assert token_a == token_a2

        # Default is now signer-b
        assert mgr._default_signer_id == "signer-b"

        mgr.stop()

    def test_backward_compat_is_valid(self):
        """is_valid() delegates to get_token()."""
        mgr, http = create_manager()
        http.request.return_value = make_heartbeat_response("default-signer")
        mgr._started = True

        # No token yet for default signer
        assert mgr.is_valid() is False

        # Acquire
        mgr.get_token_for_signer("default-signer")
        assert mgr.is_valid() is True

        mgr.stop()

    def test_alias_prefix_normalization(self):
        """alias/signer-a and signer-a resolve to the same entry."""
        mgr, http = create_manager(local_rate_limit_seconds=0)

        http.request.return_value = make_heartbeat_response("signer-a")
        mgr._started = True

        token1 = mgr.get_token_for_signer("alias/signer-a")
        token2 = mgr.get_token_for_signer("signer-a")

        # Same entry — only 1 HTTP call
        assert http.request.call_count == 1
        assert token1 == token2

        mgr.stop()


class TestStopCleansUp:
    def test_stop_cleans_all_timers(self):
        """stop() cancels all refresh + eviction timers."""
        mgr, http = create_manager(local_rate_limit_seconds=0)

        def side_effect(**kwargs):
            sid = kwargs.get("body", {}).get("signerId", "unknown")
            return make_heartbeat_response(sid)

        http.request.side_effect = side_effect
        mgr._started = True
        mgr._start_eviction_timer()

        mgr.get_token_for_signer("signer-a")
        mgr.get_token_for_signer("signer-b")

        # Verify timers exist
        assert mgr._eviction_timer is not None

        mgr.stop()

        assert mgr._started is False
        assert mgr._eviction_timer is None
        assert len(mgr._signer_entries) == 0


class TestNotStarted:
    def test_raises_when_not_started(self):
        """get_token_for_signer raises when manager not started."""
        mgr, _ = create_manager()

        with pytest.raises(GateError, match="HEARTBEAT_MISSING"):
            mgr.get_token_for_signer("signer-a")
