"""
Unit tests for GateClient decision token enforcement (ENFORCE + require_decision_token).
Verifies DECISION_TOKEN_MISSING, DECISION_TOKEN_EXPIRED, DECISION_TOKEN_DIGEST_MISMATCH.
"""

import os
import time
import pytest
from unittest.mock import Mock, patch

from gate_sdk.client import GateClient, GateClientConfig
from gate_sdk.auth import ApiKeyAuth
from gate_sdk.errors import BlockIntelBlockedError
from gate_sdk.tx_digest import build_tx_binding_object, compute_tx_digest


@pytest.fixture
def enforce_config():
    """Config with ENFORCE + require_decision_token, non-local."""
    return GateClientConfig(
        base_url="https://api.example.com",
        tenant_id="tenant-123",
        auth=ApiKeyAuth(mode="apiKey", api_key="test-api-key"),
        timeout_ms=50,
        mode="ENFORCE",
        require_decision_token=True,
        local=False,
    )


@pytest.fixture
def mock_http():
    with patch("gate_sdk.client.HttpClient") as m:
        client = Mock()
        m.return_value = client
        yield client


@pytest.fixture
def mock_heartbeat():
    with patch("gate_sdk.client.HeartbeatManager") as m:
        manager = Mock()
        m.return_value = manager
        manager.get_token.return_value = "mock-heartbeat-token"
        manager.start = Mock()
        manager.update_signer_id = Mock()
        yield manager


def test_decision_token_missing(enforce_config, mock_http, mock_heartbeat):
    """ALLOW response without decisionToken/txDigest -> DECISION_TOKEN_MISSING."""
    os.environ["GATE_HEARTBEAT_KEY"] = "test-key"
    try:
        mock_http.request.return_value = {
            "success": True,
            "data": {
                "decision": "ALLOW",
                "reason_codes": [],
            },
        }
        client = GateClient(enforce_config)

        with pytest.raises(BlockIntelBlockedError) as exc_info:
            client.evaluate(
                {
                    "txIntent": {"toAddress": "0xabc", "value": "0", "chainId": 1},
                    "signingContext": {"signerId": "signer-1"},
                }
            )
        assert exc_info.value.reason_code == "DECISION_TOKEN_MISSING"
    finally:
        os.environ.pop("GATE_HEARTBEAT_KEY", None)


def test_decision_token_expired(enforce_config, mock_http, mock_heartbeat):
    """ALLOW response with expired expires_at -> DECISION_TOKEN_EXPIRED."""
    os.environ["GATE_HEARTBEAT_KEY"] = "test-key"
    try:
        binding = build_tx_binding_object(
            {"toAddress": "0xabc", "value": "0", "chainId": 1},
            signer_id="signer-1",
        )
        digest = compute_tx_digest(binding)
        mock_http.request.return_value = {
            "success": True,
            "data": {
                "decision": "ALLOW",
                "reason_codes": [],
                "decision_token": "eyJ.mock",
                "tx_digest": digest,
                "expires_at": int(time.time()) - 60,
            },
        }
        client = GateClient(enforce_config)

        with pytest.raises(BlockIntelBlockedError) as exc_info:
            client.evaluate(
                {
                    "txIntent": {"toAddress": "0xabc", "value": "0", "chainId": 1},
                    "signingContext": {"signerId": "signer-1"},
                }
            )
        assert exc_info.value.reason_code == "DECISION_TOKEN_EXPIRED"
    finally:
        os.environ.pop("GATE_HEARTBEAT_KEY", None)


def test_decision_token_digest_mismatch(enforce_config, mock_http, mock_heartbeat):
    """ALLOW response with txDigest not matching request -> DECISION_TOKEN_DIGEST_MISMATCH."""
    os.environ["GATE_HEARTBEAT_KEY"] = "test-key"
    try:
        mock_http.request.return_value = {
            "success": True,
            "data": {
                "decision": "ALLOW",
                "reason_codes": [],
                "decision_token": "eyJ.mock",
                "tx_digest": "wrong-digest",
                "expires_at": int(time.time()) + 30,
            },
        }
        client = GateClient(enforce_config)

        with pytest.raises(BlockIntelBlockedError) as exc_info:
            client.evaluate(
                {
                    "txIntent": {"toAddress": "0xabc", "value": "0", "chainId": 1},
                    "signingContext": {"signerId": "signer-1"},
                }
            )
        assert exc_info.value.reason_code == "DECISION_TOKEN_DIGEST_MISMATCH"
    finally:
        os.environ.pop("GATE_HEARTBEAT_KEY", None)


def test_decision_token_accept_when_match(enforce_config, mock_http, mock_heartbeat):
    """ALLOW with valid token and matching txDigest -> success."""
    os.environ["GATE_HEARTBEAT_KEY"] = "test-key"
    try:
        binding = build_tx_binding_object(
            {"toAddress": "0xabc", "value": "0", "chainId": 1},
            signer_id="signer-1",
        )
        digest = compute_tx_digest(binding)
        mock_http.request.return_value = {
            "success": True,
            "data": {
                "decision": "ALLOW",
                "reason_codes": [],
                "decision_token": "eyJ.mock",
                "tx_digest": digest,
                "expires_at": int(time.time()) + 30,
            },
        }
        client = GateClient(enforce_config)

        result = client.evaluate(
            {
                "txIntent": {"toAddress": "0xabc", "value": "0", "chainId": 1},
                "signingContext": {"signerId": "signer-1"},
            }
        )
        assert result["decision"] == "ALLOW"
    finally:
        os.environ.pop("GATE_HEARTBEAT_KEY", None)


def test_no_enforcement_in_local_mode():
    """When local=True, ALLOW without token is accepted."""
    with patch("gate_sdk.client.HttpClient") as m_http:
        with patch("gate_sdk.client.HeartbeatManager"):
            m_http.return_value.request.return_value = {
                "success": True,
                "data": {"decision": "ALLOW", "reason_codes": []},
            }
            config = GateClientConfig(
                base_url="https://api.example.com",
                tenant_id="tenant-123",
                auth=ApiKeyAuth(mode="apiKey", api_key="test-api-key"),
                timeout_ms=50,
                mode="ENFORCE",
                require_decision_token=True,
                local=True,
            )
            client = GateClient(config)
            result = client.evaluate(
                {
                    "txIntent": {"toAddress": "0xabc", "value": "0", "chainId": 1},
                    "signingContext": {"signerId": "signer-1"},
                }
            )
            assert result["decision"] == "ALLOW"
