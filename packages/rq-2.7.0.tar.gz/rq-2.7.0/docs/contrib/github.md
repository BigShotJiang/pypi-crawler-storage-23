---
title: "Contributing to RQ"
layout: contrib
---

If you'd like to contribute to RQ, simply [fork](https://github.com/rq/rq)
the project on GitHub and submit a pull request.

Please bear in mind the philosiphy behind RQ: it should rather remain small and
simple, than packed with features.  And it should value insightfulness over
performance.
