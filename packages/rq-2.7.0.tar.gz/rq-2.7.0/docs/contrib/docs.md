---
title: "Documentation"
layout: contrib
---

### Running docs locally

To build the docs, run [jekyll](http://jekyllrb.com/):

```
jekyll serve
```

If you rather use Vagrant, see [these instructions][v].

[v]: {{site.baseurl}}contrib/vagrant/
