---
title: "RQ: Sending Exceptions to Sentry"
layout: patterns
---

## Sending Exceptions to Sentry

Please visit Sentry's [RQ integration page](https://docs.sentry.io/platforms/python/integrations/rq/).
