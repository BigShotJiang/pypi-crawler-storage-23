from __future__ import annotations

import json
import os
import shutil
import sqlite3
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import sqlite_vec

DEFAULT_DB_PATH = Path.home() / ".codemem" / "mem.sqlite"
LEGACY_DEFAULT_DB_PATHS = (
    Path.home() / ".codemem.sqlite",
    Path.home() / ".opencode-mem.sqlite",
)
SCHEMA_VERSION = 1


def _sidecar_paths(path: Path) -> list[Path]:
    return [path, Path(f"{path}-wal"), Path(f"{path}-shm")]


def _move_with_sidecars(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    for src_part, dst_part in zip(_sidecar_paths(src), _sidecar_paths(dst), strict=True):
        if not src_part.exists():
            continue
        try:
            src_part.replace(dst_part)
        except OSError:
            shutil.copy2(src_part, dst_part)
            src_part.unlink(missing_ok=True)


def migrate_legacy_default_db(target: Path) -> None:
    if target != DEFAULT_DB_PATH:
        return
    if target.exists():
        return
    for legacy in LEGACY_DEFAULT_DB_PATHS:
        legacy_path = legacy.expanduser()
        if not legacy_path.exists():
            continue
        _move_with_sidecars(legacy_path, target)
        return


def sqlite_vec_version(conn: sqlite3.Connection) -> str | None:
    try:
        row = conn.execute("select vec_version()").fetchone()
    except sqlite3.Error:
        return None
    if not row or row[0] is None:
        return None
    return str(row[0])


def _load_sqlite_vec(conn: sqlite3.Connection) -> None:
    try:
        conn.enable_load_extension(True)
    except AttributeError as exc:
        raise RuntimeError(
            "sqlite-vec requires a Python SQLite build that supports extension loading. "
            "Install a Python build with enable_load_extension (mise/homebrew) and try again."
        ) from exc
    try:
        sqlite_vec.load(conn)
        if sqlite_vec_version(conn) is None:
            raise RuntimeError("sqlite-vec loaded but version check failed")
    except Exception as exc:  # pragma: no cover
        message = (
            "Failed to load sqlite-vec extension. "
            "Semantic recall requires sqlite-vec; see README for platform-specific setup. "
            "If you need to run without embeddings temporarily, set CODEMEM_EMBEDDING_DISABLED=1."
        )
        text = str(exc)
        if "ELFCLASS32" in text:
            message = (
                "Failed to load sqlite-vec extension (ELFCLASS32). "
                "On Linux aarch64, PyPI may ship a 32-bit vec0.so; replace it with the 64-bit aarch64 loadable. "
                "See README section: 'sqlite-vec on aarch64 (Linux)'. "
                "If you need to run without embeddings temporarily, set CODEMEM_EMBEDDING_DISABLED=1."
            )
        raise RuntimeError(message) from exc
    finally:
        try:
            conn.enable_load_extension(False)
        except AttributeError:
            return


def connect(db_path: Path | str, check_same_thread: bool = True) -> sqlite3.Connection:
    path = Path(db_path).expanduser()
    migrate_legacy_default_db(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=check_same_thread)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        conn.execute("PRAGMA journal_mode = WAL")
    except sqlite3.OperationalError:
        conn.execute("PRAGMA journal_mode = DELETE")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def _initialize_schema_v1(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            cwd TEXT,
            project TEXT,
            git_remote TEXT,
            git_branch TEXT,
            user TEXT,
            tool_version TEXT,
            metadata_json TEXT,
            import_key TEXT
        );

        CREATE TABLE IF NOT EXISTS artifacts (
            id INTEGER PRIMARY KEY,
            session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
            kind TEXT NOT NULL,
            path TEXT,
            content_text TEXT,
            content_hash TEXT,
            created_at TEXT NOT NULL,
            metadata_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_artifacts_session_kind ON artifacts(session_id, kind);

        CREATE TABLE IF NOT EXISTS memory_items (
            id INTEGER PRIMARY KEY,
            session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
            kind TEXT NOT NULL,
            title TEXT NOT NULL,
            body_text TEXT NOT NULL,
            confidence REAL DEFAULT 0.5,
            tags_text TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            metadata_json TEXT,
            user_prompt_id INTEGER,
            deleted_at TEXT,
            rev INTEGER DEFAULT 0,
            import_key TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_memory_items_active_created ON memory_items(active, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_memory_items_session ON memory_items(session_id);

        CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
            title, body_text, tags_text,
            content='memory_items',
            content_rowid='id'
        );

        CREATE TRIGGER IF NOT EXISTS memory_items_ai AFTER INSERT ON memory_items BEGIN
            INSERT INTO memory_fts(rowid, title, body_text, tags_text)
            VALUES (new.id, new.title, new.body_text, new.tags_text);
        END;

        DROP TRIGGER IF EXISTS memory_items_au;
        CREATE TRIGGER memory_items_au AFTER UPDATE ON memory_items BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, title, body_text, tags_text)
            VALUES('delete', old.id, old.title, old.body_text, old.tags_text);
            INSERT INTO memory_fts(rowid, title, body_text, tags_text)
            VALUES (new.id, new.title, new.body_text, new.tags_text);
        END;

        DROP TRIGGER IF EXISTS memory_items_ad;
        CREATE TRIGGER memory_items_ad AFTER DELETE ON memory_items BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, title, body_text, tags_text)
            VALUES('delete', old.id, old.title, old.body_text, old.tags_text);
        END;

        CREATE TABLE IF NOT EXISTS usage_events (
            id INTEGER PRIMARY KEY,
            session_id INTEGER REFERENCES sessions(id) ON DELETE SET NULL,
            event TEXT NOT NULL,
            tokens_read INTEGER DEFAULT 0,
            tokens_written INTEGER DEFAULT 0,
            tokens_saved INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            metadata_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_usage_events_event_created ON usage_events(event, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_usage_events_session ON usage_events(session_id);

        CREATE TABLE IF NOT EXISTS raw_events (
            id INTEGER PRIMARY KEY,
            opencode_session_id TEXT NOT NULL,
            event_id TEXT,
            event_seq INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            ts_wall_ms INTEGER,
            ts_mono_ms REAL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(opencode_session_id, event_seq)
        );
        CREATE INDEX IF NOT EXISTS idx_raw_events_session_seq ON raw_events(opencode_session_id, event_seq);
        CREATE INDEX IF NOT EXISTS idx_raw_events_created_at ON raw_events(created_at DESC);

        CREATE TABLE IF NOT EXISTS raw_event_sessions (
            opencode_session_id TEXT PRIMARY KEY,
            cwd TEXT,
            project TEXT,
            started_at TEXT,
            last_seen_ts_wall_ms INTEGER,
            last_received_event_seq INTEGER NOT NULL DEFAULT -1,
            last_flushed_event_seq INTEGER NOT NULL DEFAULT -1,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS opencode_sessions (
            opencode_session_id TEXT PRIMARY KEY,
            session_id INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_opencode_sessions_session_id ON opencode_sessions(session_id);

        CREATE TABLE IF NOT EXISTS raw_event_flush_batches (
            id INTEGER PRIMARY KEY,
            opencode_session_id TEXT NOT NULL,
            start_event_seq INTEGER NOT NULL,
            end_event_seq INTEGER NOT NULL,
            extractor_version TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(opencode_session_id, start_event_seq, end_event_seq, extractor_version)
        );
        CREATE INDEX IF NOT EXISTS idx_raw_event_flush_batches_session ON raw_event_flush_batches(opencode_session_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_raw_event_flush_batches_status ON raw_event_flush_batches(status, updated_at DESC);

        CREATE TABLE IF NOT EXISTS user_prompts (
            id INTEGER PRIMARY KEY,
            session_id INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
            project TEXT,
            prompt_text TEXT NOT NULL,
            prompt_number INTEGER,
            created_at TEXT NOT NULL,
            created_at_epoch INTEGER NOT NULL,
            metadata_json TEXT,
            import_key TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_user_prompts_session ON user_prompts(session_id);
        CREATE INDEX IF NOT EXISTS idx_user_prompts_project ON user_prompts(project);
        CREATE INDEX IF NOT EXISTS idx_user_prompts_created ON user_prompts(created_at_epoch DESC);

        CREATE TABLE IF NOT EXISTS session_summaries (
            id INTEGER PRIMARY KEY,
            session_id INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
            project TEXT,
            request TEXT,
            investigated TEXT,
            learned TEXT,
            completed TEXT,
            next_steps TEXT,
            notes TEXT,
            files_read TEXT,
            files_edited TEXT,
            prompt_number INTEGER,
            created_at TEXT NOT NULL,
            created_at_epoch INTEGER NOT NULL,
            metadata_json TEXT,
            import_key TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_session_summaries_session ON session_summaries(session_id);
        CREATE INDEX IF NOT EXISTS idx_session_summaries_project ON session_summaries(project);
        CREATE INDEX IF NOT EXISTS idx_session_summaries_created ON session_summaries(created_at_epoch DESC);

        CREATE TABLE IF NOT EXISTS replication_ops (
            op_id TEXT PRIMARY KEY,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            op_type TEXT NOT NULL,
            payload_json TEXT,
            clock_rev INTEGER NOT NULL,
            clock_updated_at TEXT NOT NULL,
            clock_device_id TEXT NOT NULL,
            device_id TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_replication_ops_created ON replication_ops(created_at, op_id);
        CREATE INDEX IF NOT EXISTS idx_replication_ops_entity ON replication_ops(entity_type, entity_id);

        CREATE TABLE IF NOT EXISTS replication_cursors (
            peer_device_id TEXT PRIMARY KEY,
            last_applied_cursor TEXT,
            last_acked_cursor TEXT,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS sync_peers (
            peer_device_id TEXT PRIMARY KEY,
            name TEXT,
            pinned_fingerprint TEXT,
            public_key TEXT,
            addresses_json TEXT,
            created_at TEXT NOT NULL,
            last_seen_at TEXT,
            last_sync_at TEXT,
            last_error TEXT
        );

        CREATE TABLE IF NOT EXISTS sync_nonces (
            nonce TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS sync_device (
            device_id TEXT PRIMARY KEY,
            public_key TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS sync_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            peer_device_id TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            ok INTEGER NOT NULL,
            ops_in INTEGER NOT NULL,
            ops_out INTEGER NOT NULL,
            error TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sync_attempts_peer_started ON sync_attempts(peer_device_id, started_at);

        CREATE TABLE IF NOT EXISTS sync_daemon_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            last_error TEXT,
            last_traceback TEXT,
            last_error_at TEXT,
            last_ok_at TEXT
        );
        """
    )
    _ensure_column(conn, "sessions", "project", "TEXT")
    _ensure_column(conn, "sessions", "import_key", "TEXT")
    _ensure_column(conn, "memory_items", "subtitle", "TEXT")
    _ensure_column(conn, "memory_items", "facts", "TEXT")
    _ensure_column(conn, "memory_items", "narrative", "TEXT")
    _ensure_column(conn, "memory_items", "concepts", "TEXT")
    _ensure_column(conn, "memory_items", "files_read", "TEXT")
    _ensure_column(conn, "memory_items", "files_modified", "TEXT")
    _ensure_column(conn, "memory_items", "prompt_number", "INTEGER")
    _ensure_column(conn, "memory_items", "user_prompt_id", "INTEGER")
    _ensure_column(conn, "memory_items", "import_key", "TEXT")
    _ensure_column(conn, "memory_items", "deleted_at", "TEXT")
    _ensure_column(conn, "memory_items", "rev", "INTEGER")
    _ensure_column(conn, "user_prompts", "import_key", "TEXT")
    _ensure_column(conn, "session_summaries", "import_key", "TEXT")
    _ensure_column(conn, "raw_event_sessions", "cwd", "TEXT")
    _ensure_column(conn, "sync_peers", "public_key", "TEXT")
    _ensure_column(conn, "sync_peers", "projects_include_json", "TEXT")
    _ensure_column(conn, "sync_peers", "projects_exclude_json", "TEXT")
    _ensure_column(conn, "raw_event_sessions", "project", "TEXT")
    _ensure_column(conn, "raw_event_sessions", "started_at", "TEXT")
    _ensure_column(conn, "raw_event_sessions", "last_seen_ts_wall_ms", "INTEGER")
    _ensure_column(conn, "raw_event_sessions", "last_received_event_seq", "INTEGER")
    _ensure_column(conn, "raw_events", "event_id", "TEXT")
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_raw_events_event_id ON raw_events(opencode_session_id, event_id)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_import_key ON sessions(import_key)")
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_memory_items_import_key ON memory_items(import_key)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_memory_items_user_prompt_id ON memory_items(user_prompt_id)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_session_summaries_import_key ON session_summaries(import_key)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_user_prompts_import_key ON user_prompts(import_key)"
    )


def _schema_user_version(conn: sqlite3.Connection) -> int:
    row = conn.execute("PRAGMA user_version").fetchone()
    if row is None:
        return 0
    return int(row[0])


def _normalize_legacy_memory_kinds(conn: sqlite3.Connection) -> None:
    row = conn.execute(
        "SELECT 1 FROM memory_items WHERE lower(trim(kind)) = 'project' LIMIT 1"
    ).fetchone()
    if row is None:
        return
    conn.execute("UPDATE memory_items SET kind = 'decision' WHERE lower(trim(kind)) = 'project'")


def _ensure_vector_schema(conn: sqlite3.Connection) -> None:
    if os.getenv("CODEMEM_EMBEDDING_DISABLED", "").lower() in {"1", "true", "yes"}:
        return
    _load_sqlite_vec(conn)
    conn.execute(
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS memory_vectors USING vec0(
            embedding float[384],
            memory_id INTEGER,
            chunk_index INTEGER,
            content_hash TEXT,
            model TEXT
        );
        """
    )


def _ensure_raw_event_reliability_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS raw_event_ingest_stats (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            inserted_events INTEGER NOT NULL DEFAULT 0,
            skipped_events INTEGER NOT NULL DEFAULT 0,
            skipped_invalid INTEGER NOT NULL DEFAULT 0,
            skipped_duplicate INTEGER NOT NULL DEFAULT 0,
            skipped_conflict INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS raw_event_ingest_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            inserted_events INTEGER NOT NULL DEFAULT 0,
            skipped_invalid INTEGER NOT NULL DEFAULT 0,
            skipped_duplicate INTEGER NOT NULL DEFAULT 0,
            skipped_conflict INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_raw_event_ingest_samples_created
        ON raw_event_ingest_samples(created_at)
        """
    )
    _ensure_column(conn, "raw_event_ingest_stats", "skipped_invalid", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(
        conn, "raw_event_ingest_stats", "skipped_duplicate", "INTEGER NOT NULL DEFAULT 0"
    )
    _ensure_column(conn, "raw_event_ingest_stats", "skipped_conflict", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(conn, "raw_event_flush_batches", "attempt_count", "INTEGER NOT NULL DEFAULT 0")


def initialize_schema(conn: sqlite3.Connection) -> None:
    if _schema_user_version(conn) < SCHEMA_VERSION:
        _initialize_schema_v1(conn)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    _ensure_vector_schema(conn)
    _ensure_raw_event_reliability_schema(conn)
    _normalize_legacy_memory_kinds(conn)
    _cleanup_orphan_prompt_links(conn)
    if conn.in_transaction:
        conn.commit()


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, column_type: str) -> None:
    existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column in existing:
        return
    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_type}")


def _cleanup_orphan_prompt_links(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        UPDATE memory_items AS m
        SET user_prompt_id = NULL
        WHERE m.user_prompt_id IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM user_prompts WHERE user_prompts.id = m.user_prompt_id
          )
        """
    )


def to_json(data: Any) -> str:
    if data is None:
        payload: Any = {}
    else:
        payload = data
    return json.dumps(payload, ensure_ascii=False)


def from_json(text: str | None) -> dict[str, Any]:
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {}


def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(r) for r in rows]
