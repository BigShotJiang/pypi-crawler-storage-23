from yt_dlp.extractor.common import InfoExtractor


class PackagePluginIE(InfoExtractor):
    _VALID_URL = 'package'
    pass
