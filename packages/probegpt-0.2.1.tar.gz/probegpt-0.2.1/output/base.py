from abc import ABC, abstractmethod

from core.models import DiscoveryResult


class AbstractOutput(ABC):
    @abstractmethod
    def emit(self, result: DiscoveryResult) -> None:
        """Called for each result as it arrives during the discovery loop."""
        ...

    @abstractmethod
    def finalize(self, results: list[DiscoveryResult]) -> None:
        """Called once at the end with the complete result list."""
        ...

    def update_status(self, msg: str) -> None:
        """Optional live status update — no-op by default."""

    def log(self, msg: str) -> None:
        """Optional inline log line — no-op by default."""
