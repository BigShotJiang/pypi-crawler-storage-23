from abc import ABC, abstractmethod

from pydantic_ai.models import Model

from prompts.models import Probe

SEPARATOR = "---"


class AbstractStrategy(ABC):
    @abstractmethod
    def generate(self, seeds: list[Probe], model: Model, count: int = 5) -> list[str]:
        """Generate new probe candidates from seed prompts."""
        ...

    @abstractmethod
    def get_name(self) -> str: ...

    @abstractmethod
    def get_description(self) -> str: ...

    def _parse_candidates(self, text: str) -> list[str]:
        """Split on separator lines, discard empty segments."""
        parts = text.split(f"\n{SEPARATOR}\n")
        return [p.strip() for p in parts if p.strip() and p.strip() != SEPARATOR]
