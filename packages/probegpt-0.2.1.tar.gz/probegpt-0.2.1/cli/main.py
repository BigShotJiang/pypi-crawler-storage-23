"""outofthebox — entry point."""

from cli.app import OutOfTheBoxApp


def main() -> None:
    OutOfTheBoxApp().run()


if __name__ == "__main__":
    main()
