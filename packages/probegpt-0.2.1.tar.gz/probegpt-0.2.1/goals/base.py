from pydantic import BaseModel


class GoalResult(BaseModel):
    achieved: bool
    score: float
    reason: str
    goal_name: str
