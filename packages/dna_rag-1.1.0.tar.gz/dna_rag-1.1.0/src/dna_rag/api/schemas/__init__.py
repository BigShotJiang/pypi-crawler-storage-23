"""Request / response schemas for the API layer."""
