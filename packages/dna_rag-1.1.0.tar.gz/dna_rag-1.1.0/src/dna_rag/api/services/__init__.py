"""Application services that orchestrate core engine with I/O."""
