"""Streamlit UI adapter for DNA RAG."""
