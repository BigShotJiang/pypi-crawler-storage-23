"""DNA file format parsers for dna-rag."""

from dna_rag.parsers.detector import detect_and_parse

__all__ = ["detect_and_parse"]
