"""Tests for structflo.cser — pure-logic unit tests (no GPU, no model weights)."""
