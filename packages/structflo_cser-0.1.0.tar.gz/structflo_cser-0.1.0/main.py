def main():
    print("Hello from struct-labels!")


if __name__ == "__main__":
    main()
