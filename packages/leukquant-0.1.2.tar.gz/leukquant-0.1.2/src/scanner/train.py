"""
Leukquant — Model Training Pipeline
=====================================
Supported data sources
----------------------
  synthetic   Random 258-feature data — no dataset required (default)
  ember       Elastic EMBER 2018 dataset (~1 M PE samples, 2351 features)
              Requires: pip install ember lief
              Dataset:  https://github.com/elastic/ember
  virusshare  VirusShare MD5/SHA-256 hash lists → populates signature DB
              (No model training — hash-based detection only)
              Download: https://virusshare.com/hashfiles
  kaggle      Kaggle CSV malware datasets (generic feature matrix)
              Requires: pip install kaggle  +  ~/.kaggle/kaggle.json
  files       Raw binary sample directories (malware/ + benign/ folders)
              Uses EMBER features when ember+lief are installed (recommended),
              otherwise falls back to the built-in 258-dim basic extractor

All training modes export an ONNX RandomForest and a companion
<model>.meta.json with {"n_features": N, "source": "<source>"} so the
scanner knows which feature extractor to use at inference time.

CLI (examples)
--------------
  leukquant train                                              # synthetic
  leukquant train --source ember --ember-dir ~/data/ember2018
  leukquant train --source virusshare --hash-list ~/VirusShare_00000.md5
  leukquant train --source kaggle --csv ~/malware_features.csv
  leukquant train --source files --malware-dir ~/samples/mal --benign-dir ~/samples/ok
"""

import os
import json
import logging
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
from typing import Optional
from src.paths import app_path

logger = logging.getLogger(__name__)

SYNTHETIC_FEATURE_COUNT = 258  # size + entropy + 256-bin byte histogram


# ═══════════════════════════════════════════════════════════════════════════════
# Internal helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _save_model(
    clf: RandomForestClassifier,
    n_features: int,
    output_path: str,
    source: str,
    n_samples: int = 0,
    threshold: float = None,
) -> None:
    """Serialize clf to ONNX and write a companion .meta.json.

    The .meta.json includes a recommended *threshold* so the scanner can
    auto-calibrate without requiring a manual config change.  The threshold
    is derived from the training-sample count:
      ≥ 10 000 samples  → 0.85  (high-confidence, large-dataset models)
      ≥ 1 000 samples   → 0.70
      ≥ 100 samples     → 0.60
      < 100 samples     → 0.50  (small sample sets; prefer low false-negatives)
    The caller may override by passing an explicit *threshold*.
    """
    if threshold is None:
        if n_samples >= 10_000:
            threshold = 0.85
        elif n_samples >= 1_000:
            threshold = 0.70
        elif n_samples >= 100:
            threshold = 0.60
        else:
            threshold = 0.50

    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    initial_type = [("float_input", FloatTensorType([None, n_features]))]
    onx = convert_sklearn(clf, initial_types=initial_type, target_opset=12)
    with open(output_path, "wb") as f:
        f.write(onx.SerializeToString())

    meta_path = os.path.splitext(output_path)[0] + ".meta.json"
    with open(meta_path, "w") as f:
        json.dump({
            "n_features": n_features,
            "source":     source,
            "n_samples":  n_samples,
            "threshold":  threshold,
        }, f, indent=2)

    logger.info(
        f"Model saved    → {output_path}  "
        f"(features={n_features}, source={source}, "
        f"samples={n_samples}, threshold={threshold})"
    )
    logger.info(f"Metadata saved → {meta_path}")


def _build_rf(n_estimators: int = 100) -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=12,
        n_jobs=-1,
        random_state=42,
        class_weight="balanced",
    )


# Minimum samples per class needed for a stratified 80/20 split:
# each split must have >= 2 samples per class  →  2 / 0.2 = 10
_STRATIFY_MIN = 10


def _safe_train_test_split(
    X: np.ndarray,
    y: np.ndarray,
    test_size: float = 0.2,
    random_state: int = 42,
):
    """
    Stratified train/test split when every class has >= _STRATIFY_MIN
    samples, plain random split otherwise.

    Always warns when any class is critically under-represented so the
    user knows the evaluation report will be incomplete or unreliable.
    """
    classes, counts = np.unique(y.astype(int), return_counts=True)
    minority = int(counts.min())
    minority_label = {0: "benign", 1: "malicious"}.get(int(classes[counts.argmin()]), str(classes[counts.argmin()]))

    if minority < 5:
        logger.warning(
            f"Only {minority} '{minority_label}' sample(s) — the model will "
            f"have very poor recall for that class. Collect at least 50+ samples "
            f"per class for meaningful results."
        )

    if minority >= _STRATIFY_MIN:
        return train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )

    logger.warning(
        f"Minority class ('{minority_label}') has only {minority} sample(s); "
        f"need >= {_STRATIFY_MIN} for a stratified split. "
        f"Using a random split — the evaluation report may be missing classes."
    )
    return train_test_split(X, y, test_size=test_size, random_state=random_state)


def _fit_and_report(clf, X_tr, y_tr, X_te, y_te):
    logger.info(
        f"Training RandomForestClassifier — "
        f"samples={len(X_tr)}, features={X_tr.shape[1]}, "
        f"trees={clf.n_estimators}"
    )
    clf.fit(X_tr.astype(np.float32), y_tr.astype(int))
    if len(X_te) > 0:
        y_pred = clf.predict(X_te.astype(np.float32))
        _label_map = {0: "benign", 1: "malicious"}
        _present   = sorted(set(y_te.astype(int)))
        _names     = [_label_map.get(l, str(l)) for l in _present]
        report = classification_report(
            y_te, y_pred,
            labels=_present, target_names=_names,
            zero_division=0,
        )
        logger.info(f"\n{report}")
    return clf


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Synthetic  (default — no external dataset needed)
# ═══════════════════════════════════════════════════════════════════════════════

def train_dummy_model(
    output_path: str = None,
    n_estimators: int = 100,
    n_samples: int = 2000,
) -> None:
    """
    Generate a synthetic ONNX model using 258-feature random data.

    Heuristic: high Shannon entropy + small file -> more likely malicious.
    Useful for testing and development when no real dataset is available.
    """
    output_path = output_path or app_path("models", "malware_detector.onnx")
    logger.info(f"Generating synthetic dataset ({n_samples} samples, {SYNTHETIC_FEATURE_COUNT} features)…")
    rng = np.random.default_rng(42)
    X = rng.random((n_samples, SYNTHETIC_FEATURE_COUNT)).astype(np.float32)
    # feature[0] = size (0-1), feature[1] = entropy (0-1 scaled)
    y = ((X[:, 1] > 0.65) & (X[:, 0] < 0.8)).astype(int)

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = _fit_and_report(_build_rf(n_estimators), X_tr, y_tr, X_te, y_te)
    _save_model(clf, SYNTHETIC_FEATURE_COUNT, output_path, "synthetic", n_samples=len(X_tr))


# ═══════════════════════════════════════════════════════════════════════════════
# 2. EMBER 2018  (Elastic / endgame)
# ═══════════════════════════════════════════════════════════════════════════════

def train_with_ember(
    ember_data_dir: str,
    output_path: str = None,
    subset_size: Optional[int] = None,
    n_estimators: int = 100,
) -> None:
    """
    Train on the EMBER 2018 PE malware dataset (2351 features).

    Setup
    -----
    1. Install dependencies:
           pip install ember lief
    2. Download the dataset (~8 GB compressed):
           https://ember.elastic.co/ember_dataset_2018_2.tar.bz2
       Or clone the repo and follow its README:
           https://github.com/elastic/ember
    3. Extract — you should get an ember2018/ folder containing:
           X_train.dat  y_train.dat  X_test.dat  y_test.dat
    4. Run:
           leukquant train --source ember --ember-dir ~/data/ember2018

    Parameters
    ----------
    ember_data_dir : Path to the extracted ember2018/ directory.
    output_path    : Where to save the ONNX model.
    subset_size    : Optional cap on training samples (e.g. 100_000 for speed).
    n_estimators   : Number of RandomForest trees.
    """
    output_path = output_path or app_path("models", "malware_detector.onnx")
    from src.scanner.dataset_loaders import load_ember_dataset
    X_tr, y_tr, X_te, y_te = load_ember_dataset(ember_data_dir, subset_size=subset_size)
    clf = _fit_and_report(_build_rf(n_estimators), X_tr, y_tr, X_te, y_te)
    _save_model(clf, X_tr.shape[1], output_path, "ember", n_samples=len(X_tr))


# ═══════════════════════════════════════════════════════════════════════════════
# 3. VirusShare  (hash-list → signature DB, no ONNX model)
# ═══════════════════════════════════════════════════════════════════════════════

def import_virusshare_hashes(hash_list_path: str) -> int:
    """
    Bulk-import a VirusShare MD5 / SHA-256 hash list into the local
    threat-signature database (no ONNX model is produced).

    Hash lists are free to download — no account required:
        https://virusshare.com/hashfiles
    Each .md5 file contains ~131 000 MD5 hashes from one VirusShare archive.

    Parameters
    ----------
    hash_list_path : Local path to the downloaded .md5 / .txt hash list.

    Returns
    -------
    Number of new signatures inserted (duplicates are silently skipped).
    """
    from src.scanner.dataset_loaders import load_virusshare_hashes
    from src.db.database import DatabaseManager

    entries = load_virusshare_hashes(hash_list_path)
    db = DatabaseManager()
    inserted = db.add_threat_signatures_bulk(entries)

    logger.info(
        f"VirusShare import: {inserted} new / {len(entries)} total hashes "
        f"from {os.path.basename(hash_list_path)}"
    )
    return inserted


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Kaggle CSV  (generic numeric feature matrix)
# ═══════════════════════════════════════════════════════════════════════════════

def train_with_kaggle_csv(
    csv_path: str,
    output_path: str = None,
    label_col: str = "label",
    n_estimators: int = 100,
) -> None:
    """
    Train on a Kaggle CSV malware dataset.

    Popular datasets
    ----------------
      Malware Analysis Predictions
        https://www.kaggle.com/datasets/rtatman/malware-classification
      Microsoft Malware Classification BIG 2015 (competition)
        https://www.kaggle.com/competitions/malware-classification

    The CSV must have numeric feature columns and a label column
    containing 0/1 values (or string values like "malware"/"benign").

    Setup
    -----
    1. Install the Kaggle CLI:
           pip install kaggle
    2. Create an API token at https://www.kaggle.com/settings → API
       and place it at ~/.kaggle/kaggle.json
    3. Download the dataset:
           leukquant train --source kaggle \\
               --kaggle-dataset rtatman/malware-classification \\
               --dest-dir data/kaggle
       This saves the files to data/kaggle/ and prints the CSV path.
    4. Train:
           leukquant train --source kaggle --csv data/kaggle/malware_features.csv

    Parameters
    ----------
    csv_path     : Path to the CSV file.
    output_path  : Where to save the ONNX model.
    label_col    : Name of the ground-truth label column.
    n_estimators : Number of RandomForest trees.
    """
    output_path = output_path or app_path("models", "malware_detector.onnx")
    from src.scanner.dataset_loaders import load_kaggle_csv_dataset
    X, y = load_kaggle_csv_dataset(csv_path, label_col=label_col)
    X_tr, X_te, y_tr, y_te = _safe_train_test_split(X, y)
    clf = _fit_and_report(_build_rf(n_estimators), X_tr, y_tr, X_te, y_te)
    _save_model(clf, X_tr.shape[1], output_path, "kaggle", n_samples=len(X_tr))


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Raw binary sample directories
# ═══════════════════════════════════════════════════════════════════════════════

def train_with_file_dirs(
    malware_dir: str,
    benign_dir: Optional[str] = None,
    output_path: str = None,
    max_files: Optional[int] = None,
    n_estimators: int = 100,
) -> None:
    """
    Train on raw binary files using the 258-dim basic feature extractor
    (file_size + Shannon entropy + 256-bin byte histogram).

    Use this when you have downloaded actual sample archives:
        - VirusShare zip archives   -> malware_dir
        - Linux/Windows system bins -> benign_dir  (optional)

    Parameters
    ----------
    malware_dir  : Directory tree of malware sample binaries.
    benign_dir   : Directory tree of benign sample binaries (optional).
    output_path  : Where to save the ONNX model.
    max_files    : Per-class file cap to avoid memory exhaustion.
    n_estimators : Number of RandomForest trees.
    """
    output_path = output_path or app_path("models", "malware_detector.onnx")
    from src.scanner.dataset_loaders import scan_directory_for_features
    from src.scanner.extract import HAS_EMBER
    # Use EMBER features when ember+lief are available — they provide rich PE
    # structure info (imports, exports, sections, strings, …) that makes even
    # small sample sets far more discriminative than byte-histogram features.
    # Fall back to basic 258-dim extractor when EMBER is not installed.
    _use_ember = None  # auto: True if HAS_EMBER, False otherwise
    X, y = scan_directory_for_features(
        malware_dir, benign_dir, max_files=max_files, use_ember=_use_ember
    )
    X_tr, X_te, y_tr, y_te = _safe_train_test_split(X, y)
    clf = _fit_and_report(_build_rf(n_estimators), X_tr, y_tr, X_te, y_te)
    source = "ember" if (HAS_EMBER and X_tr.shape[1] > SYNTHETIC_FEATURE_COUNT) else "files"
    _save_model(clf, X_tr.shape[1], output_path, source, n_samples=len(X_tr))


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import logging as _log
    _log.basicConfig(level=_log.INFO, format="%(asctime)s %(levelname)s %(message)s")
    train_dummy_model()
