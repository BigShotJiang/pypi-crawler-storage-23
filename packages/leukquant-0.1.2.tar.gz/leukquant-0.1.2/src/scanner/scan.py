import os
import json
import numpy as np
import onnxruntime as ort
import logging
import hashlib
from src.scanner.extract import extract_features, BASIC_FEATURE_COUNT
from src.db.database import DatabaseManager
from src.config import Config

logger = logging.getLogger(__name__)


class LocalScanner:
    """
    Two-stage file scanner:
    1. Hash lookup against local SQLite threat signature DB.
    2. ONNX model inference on extracted file features.

    The companion <model>.meta.json file (written by train.py) records:
        {"n_features": N, "source": "<synthetic|ember|kaggle|files>"}
    so the scanner always uses the feature extractor that matches the
    model's training feature set.
    """

    def __init__(self, model_path: str = None, threshold: float = None):
        cfg = Config.get()
        self.model_path = model_path or cfg.get_value(
            "scanner", "model_path", default="models/malware_detector.onnx"
        )
        # threshold=None means "auto" — read from meta.json first, then config
        self._threshold_override = threshold
        self.threshold = threshold or cfg.get_value(
            "scanner", "malware_threshold", default=0.85
        )
        self.session = None
        self.n_features: int = BASIC_FEATURE_COUNT  # updated from meta
        self.model_source: str = "synthetic"
        self.db = DatabaseManager()
        self._load_model()

    # ── meta helper ──────────────────────────────────────────────────────────

    def _load_meta(self) -> dict:
        """Read companion .meta.json if it exists, else return defaults."""
        meta_path = os.path.splitext(self.model_path)[0] + ".meta.json"
        if os.path.exists(meta_path):
            try:
                with open(meta_path) as f:
                    return json.load(f)
            except Exception as exc:
                logger.warning(f"Could not read model metadata: {exc}")
        return {"n_features": BASIC_FEATURE_COUNT, "source": "synthetic"}

    def _load_model(self):
        if not os.path.exists(self.model_path):
            logger.warning(
                f"Model not found at '{self.model_path}'. "
                "Run 'leukquant train' to generate a model."
            )
            return
        try:
            self.session = ort.InferenceSession(self.model_path)
            meta = self._load_meta()
            self.n_features = meta.get("n_features", BASIC_FEATURE_COUNT)
            self.model_source = meta.get("source", "synthetic")
            # Prefer threshold stored in meta.json (set at training time based
            # on sample count) unless the caller supplied an explicit override.
            if self._threshold_override is None and "threshold" in meta:
                self.threshold = float(meta["threshold"])
            logger.info(
                f"Loaded ONNX model from {self.model_path} "
                f"(source={self.model_source}, features={self.n_features}, "
                f"threshold={self.threshold})"
            )
        except Exception as e:
            logger.error(f"Failed to load model: {e}")

    @staticmethod
    def hash_file(file_path: str) -> str:
        """Compute SHA-256 of a file (primary hash)."""
        h = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    @staticmethod
    def hash_file_md5(file_path: str) -> str:
        """Compute MD5 of a file (used for VirusShare hash-list lookups)."""
        h = hashlib.md5()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    def scan_file(self, file_path: str) -> dict:
        if not os.path.exists(file_path):
            return {"file": file_path, "error": "File not found"}

        file_hash     = self.hash_file(file_path)      # SHA-256 — primary / display
        file_hash_md5 = self.hash_file_md5(file_path)  # MD5 — for VirusShare lookups

        # Stage 1 — signature DB lookup (SHA-256 first, then MD5 for VirusShare)
        sig = self.db.get_threat_signature(file_hash)
        if not sig and file_hash_md5:
            sig = self.db.get_threat_signature(file_hash_md5)
        if sig:
            return {
                "file": file_path,
                "hash": file_hash,
                "malware_probability": 1.0,
                "verdict": "MALICIOUS",
                "method": "signature",
                "severity": sig.get("severity", 5),
                "source": sig.get("source", "local"),
            }

        # Stage 2 — AI model inference
        if not self.session:
            return {
                "file": file_path,
                "hash": file_hash,
                "malware_probability": 0.0,
                "verdict": "UNKNOWN",
                "method": "none",
                "error": "Model not loaded",
            }

        try:
            # Select extractor by feature count, not source tag — this works
            # correctly for every source (synthetic/ember/files/kaggle) and
            # is robust to lief version differences in the EMBER vector length.
            use_ember = (self.n_features > BASIC_FEATURE_COUNT)
            features = extract_features(file_path, use_ember=use_ember)

            # Validate dimension before handing to ONNX — give a clear message
            if len(features) != self.n_features:
                return {
                    "file": file_path,
                    "hash": file_hash,
                    "malware_probability": 0.0,
                    "verdict": "ERROR",
                    "method": "none",
                    "error": (
                        f"Feature dimension mismatch: extractor produced {len(features)} "
                        f"but model expects {self.n_features}. "
                        f"Retrain with: leukquant train --source {'ember' if use_ember else 'synthetic'}"
                    ),
                }
            tensor = np.array([features], dtype=np.float32)
            input_name = self.session.get_inputs()[0].name
            result = self.session.run(None, {input_name: tensor})

            # skl2onnx emits a ZipMap as result[1] for probability output
            if (
                len(result) > 1
                and isinstance(result[1], list)
                and isinstance(result[1][0], dict)
            ):
                score = float(result[1][0].get(1, 0.0))
            else:
                probs = result[0][0]
                score = float(probs[1]) if len(probs) > 1 else float(probs[0])

            verdict = "MALICIOUS" if score > self.threshold else "CLEAN"
            return {
                "file": file_path,
                "hash": file_hash,
                "malware_probability": score,
                "verdict": verdict,
                "method": "ai_model",
            }
        except Exception as e:
            logger.error(f"Error scanning {file_path}: {e}")
            return {"file": file_path, "error": str(e)}
