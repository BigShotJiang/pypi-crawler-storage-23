"""
Leukquant — Dataset Loaders
============================
Handles loading / downloading training data from:

  ember       Elastic EMBER 2018 PE malware dataset
              (~1 M labeled PE samples, 2351 pre-computed features)
              https://github.com/elastic/ember

  virusshare  VirusShare MD5 / SHA-256 hash lists → signature DB
              https://virusshare.com/hashfiles  (free, no account)

  kaggle      Kaggle CSV malware datasets via the kaggle API
              https://www.kaggle.com/datasets/rtatman/malware-classification

  files       Raw binary sample directories (malware / benign)
              Features extracted with src.scanner.extract (258-dim)

Usage
-----
>>> from src.scanner.dataset_loaders import load_ember_dataset
>>> X_tr, y_tr, X_te, y_te = load_ember_dataset("~/data/ember2018")
"""

import os
import csv as csv_mod
import json
import logging
import numpy as np
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# EMBER 2018
# ═══════════════════════════════════════════════════════════════════════════════

def load_ember_dataset(
    data_dir: str,
    subset_size: Optional[int] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Load the EMBER 2018 dataset from pre-vectorised binary files.

    Steps
    -----
    1. Download:
         https://ember.elastic.co/ember_dataset_2018_2.tar.bz2
       (~8 GB compressed, ~14 GB extracted)
    2. Extract — you should see files like:
         ember2018/X_train.dat  ember2018/y_train.dat
         ember2018/X_test.dat   ember2018/y_test.dat
    3. Run:
         leukquant train --source ember --ember-dir ~/data/ember2018

    Requires
    --------
        pip install ember lief

    Parameters
    ----------
    data_dir    : Path to the extracted ember2018/ directory.
    subset_size : Optional cap on training samples (useful for quick tests).

    Returns
    -------
    (X_train, y_train, X_test, y_test) — float32 / int32 arrays.
    Unlabeled samples (y == -1) are filtered out automatically.
    """
    try:
        import ember as ember_lib
    except ImportError:
        raise ImportError(
            "EMBER package not installed.\n"
            "  pip install ember lief\n"
            "Dataset download: https://github.com/elastic/ember"
        )

    data_dir = os.path.expanduser(data_dir)
    if not os.path.isdir(data_dir):
        raise FileNotFoundError(
            f"EMBER data directory not found: {data_dir}\n"
            "Download: https://ember.elastic.co/ember_dataset_2018_2.tar.bz2"
        )

    logger.info(f"Loading EMBER vectorised features from: {data_dir}")
    X_train, y_train, X_test, y_test = ember_lib.read_vectorized_features(
        data_dir, feature_version=2
    )

    # Remove unlabeled rows (y == -1)
    mask_tr = y_train != -1
    mask_te = y_test != -1
    X_train, y_train = X_train[mask_tr], y_train[mask_tr]
    X_test, y_test   = X_test[mask_te],  y_test[mask_te]

    if subset_size:
        n = min(subset_size, len(X_train))
        idx = np.random.default_rng(42).choice(len(X_train), n, replace=False)
        X_train, y_train = X_train[idx], y_train[idx]
        logger.info(f"Using subset: {n} training samples")

    logger.info(
        f"EMBER dataset — train: {X_train.shape}, "
        f"test: {X_test.shape}, features: {X_train.shape[1]}"
    )
    return (
        X_train.astype(np.float32),
        y_train.astype(np.int32),
        X_test.astype(np.float32),
        y_test.astype(np.int32),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# VirusShare  (hash-list → signature DB)
# ═══════════════════════════════════════════════════════════════════════════════

def load_virusshare_hashes(hash_list_path: str) -> list:
    """
    Parse a VirusShare MD5 / SHA-256 hash list and return a list of dicts
    ready to be bulk-inserted into the Leukquant threat-signature DB.

    Hash lists are free to download (no account required):
        https://virusshare.com/hashfiles

    Expected format (one hash per line, comments start with '#'):
        # VirusShare.com - MD5 Hashes from VirusShare_00000.zip
        4a1f3b2c9d5e6f7a8b9c0d1e2f3a4b5c
        ...

    Supports both MD5 (32 hex chars) and SHA-256 (64 hex chars).

    Returns
    -------
    List of dicts: {"hash", "severity", "source", "label"}
    """
    path = os.path.expanduser(hash_list_path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Hash list not found: {path}")

    entries = []
    hex_chars = frozenset("0123456789abcdefABCDEF")
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Accept MD5 (32) or SHA-256 (64) hex strings
            if len(line) in (32, 64) and all(c in hex_chars for c in line):
                entries.append(
                    {
                        "hash":     line.lower(),
                        "severity": 8,
                        "source":   "VirusShare",
                        "label":    "malware",
                    }
                )

    logger.info(
        f"Parsed {len(entries)} hashes from {os.path.basename(path)}"
    )
    return entries


# ═══════════════════════════════════════════════════════════════════════════════
# Kaggle  (API download + CSV loading)
# ═══════════════════════════════════════════════════════════════════════════════

def download_kaggle_dataset(
    dataset: str,
    dest_dir: str = "data/kaggle",
    unzip: bool = True,
) -> str:
    """
    Download a Kaggle dataset using the Kaggle CLI / Python API.

    Requires
    --------
        pip install kaggle
        ~/.kaggle/kaggle.json   (from kaggle.com/settings → API → Create Token)

    Popular malware datasets
    ------------------------
        rtatman/malware-classification
        competitions/malware-classification          (Microsoft BIG 2015)

    Parameters
    ----------
    dataset  : Kaggle dataset slug, e.g. "rtatman/malware-classification".
    dest_dir : Local directory to save the downloaded files.
    unzip    : Automatically unzip after download.

    Returns
    -------
    Path to the destination directory.
    """
    try:
        import kaggle  # noqa: F401  (just verify it's installed)
    except ImportError:
        raise ImportError(
            "kaggle package not installed.\n"
            "  pip install kaggle\n"
            "Credentials: https://www.kaggle.com/settings → API → Create New Token\n"
            "Place kaggle.json at ~/.kaggle/kaggle.json"
        )

    import subprocess
    os.makedirs(dest_dir, exist_ok=True)
    cmd = ["kaggle", "datasets", "download", "-d", dataset, "-p", dest_dir]
    if unzip:
        cmd.append("--unzip")

    logger.info(f"Downloading Kaggle dataset: {dataset}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"Kaggle download failed:\n{result.stderr}")

    logger.info(f"Dataset saved to: {dest_dir}")
    return dest_dir


def load_kaggle_csv_dataset(
    csv_path: str,
    feature_cols: Optional[list] = None,
    label_col: str = "label",
    malicious_values: Optional[set] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load a generic CSV-format Kaggle malware dataset.

    The CSV must have numeric feature columns and a label column that
    contains 0/1 integers, boolean strings, or malware-family names.

    Compatible datasets
    -------------------
        Kaggle Malware Analysis Predictions (CSV export)
        Any CSV where each row is one sample and columns are features.

    Parameters
    ----------
    csv_path         : Path to the CSV file.
    feature_cols     : Explicit list of feature column names.
                       When None, all columns except label_col are used.
    label_col        : Name of the column that holds the ground-truth label.
    malicious_values : String values treated as "malicious" (label=1).
                       Default: {"1", "malware", "malicious", "true"}.

    Returns
    -------
    (X, y) as float32 / int32 numpy arrays.
    """
    if malicious_values is None:
        malicious_values = {"1", "malware", "malicious", "true"}

    path = os.path.expanduser(csv_path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV not found: {path}")

    rows: list[dict] = []
    with open(path, newline="", encoding="utf-8", errors="ignore") as f:
        reader = csv_mod.DictReader(f)
        header = list(reader.fieldnames or [])
        for row in reader:
            rows.append(row)

    if not rows:
        raise ValueError(f"No data found in {csv_path}")

    if label_col not in header:
        raise ValueError(
            f"Label column '{label_col}' not found. "
            f"Available columns: {header}"
        )

    if feature_cols is None:
        feature_cols = [c for c in header if c != label_col]

    logger.info(
        f"Loading {len(rows)} samples × {len(feature_cols)} features from "
        f"{os.path.basename(csv_path)}"
    )

    X, y = [], []
    skipped = 0
    for row in rows:
        try:
            features = [float(row[c]) for c in feature_cols]
            label_raw = str(row[label_col]).strip().lower()
            label = 1 if label_raw in malicious_values else 0
            X.append(features)
            y.append(label)
        except (ValueError, KeyError):
            skipped += 1
            continue

    if skipped:
        logger.warning(f"Skipped {skipped} malformed rows.")

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int32)


# ═══════════════════════════════════════════════════════════════════════════════
# Raw binary sample directories  (malware / benign folders)
# ═══════════════════════════════════════════════════════════════════════════════

def scan_directory_for_features(
    malware_dir: str,
    benign_dir:  Optional[str] = None,
    max_files:   Optional[int] = None,
    use_ember:   Optional[bool] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Walk malware_dir (label=1) and optionally benign_dir (label=0),
    extract features from each file, and return (X, y) arrays.

    Use this when you have downloaded raw binary samples, such as:
        - VirusShare zip archives (malware)
        - Windows / Linux system binaries, installers (benign)

    Feature extraction uses src.scanner.extract.extract_features().
    Pass use_ember=False (default for --source files) to force the
    lightweight 258-dim extractor, which works for any file type and OS.
    Pass use_ember=None to auto-select EMBER when installed.

    When no benign_dir is provided the function automatically loads
    system executables (/usr/bin, /bin, /usr/sbin on Linux;
    C:\\Windows\\System32 on Windows) as stand-in benign samples,
    capped at the same count as the malware set.

    Parameters
    ----------
    malware_dir : Directory tree of malware samples.
    benign_dir  : Optional directory tree of benign samples.
    max_files   : Per-class file cap (to avoid memory exhaustion).
    use_ember   : Feature extractor override (None = auto).

    Returns
    -------
    (X, y) as float32 / int32 numpy arrays.
    """
    from src.scanner.extract import extract_features  # avoid circular import

    def _load_class(directory: str, label: int, limit: Optional[int]):
        files = [p for p in Path(directory).rglob("*") if p.is_file()]
        if limit:
            files = files[:limit]
        feats, labels = [], []
        for fp in files:
            try:
                vec = extract_features(str(fp), use_ember=use_ember)
                feats.append(vec)
                labels.append(label)
            except Exception as exc:
                logger.debug(f"Skipping {fp}: {exc}")
        return feats, labels

    per_class_limit = (max_files // 2) if max_files else None

    X, y = [], []
    mal_feats, mal_labels = _load_class(malware_dir, 1, per_class_limit)
    X.extend(mal_feats)
    y.extend(mal_labels)
    logger.info(f"Loaded {len(mal_feats)} malware samples from {malware_dir}")

    if benign_dir and os.path.isdir(benign_dir):
        ben_feats, ben_labels = _load_class(benign_dir, 0, per_class_limit)
        X.extend(ben_feats)
        y.extend(ben_labels)
        logger.info(f"Loaded {len(ben_feats)} benign samples from {benign_dir}")
    else:
        # Auto-fallback: harvest OS system binaries as benign samples so the
        # model always has both classes to learn from.
        _sys_dirs = [
            d for d in [
                "/usr/bin", "/bin", "/usr/sbin", "/sbin",  # Linux
                r"C:\Windows\System32", r"C:\Windows\SysWOW64",  # Windows
            ]
            if os.path.isdir(d)
        ]
        # Cap benign auto-loading to 10× malware count so the class ratio
        # never exceeds 10:1. With very few malware samples the old fixed
        # ceiling of 200 produced ratios like 40:1, severely impairing the
        # model's ability to learn the malicious class.
        auto_limit = per_class_limit or min(max(len(mal_feats) * 10, 20), 500)
        auto_feats: list = []
        auto_labels: list = []
        for sd in _sys_dirs:
            if len(auto_feats) >= auto_limit:
                break
            remaining = auto_limit - len(auto_feats)
            _f, _l = _load_class(sd, 0, remaining)
            auto_feats.extend(_f)
            auto_labels.extend(_l)
        if auto_feats:
            X.extend(auto_feats)
            y.extend(auto_labels)
            logger.info(
                f"No benign_dir provided — auto-loaded {len(auto_feats)} "
                f"system binaries as benign samples "
                f"(pass --benign-dir for domain-specific samples)."
            )
        else:
            logger.warning(
                "No benign samples found and no system binary directories "
                "detected. The model will train on a single class and will "
                "have poor discrimination. Pass --benign-dir."
            )

    if not X:
        raise ValueError(
            "No samples loaded. Verify that malware_dir (and benign_dir) "
            "contain readable binary files."
        )

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int32)
