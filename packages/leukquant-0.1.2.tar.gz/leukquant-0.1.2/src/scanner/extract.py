"""
Leukquant — Feature Extraction
================================
Two extraction modes selected automatically at runtime:

  EMBER mode  (2351 features)
      Used when the `ember` + `lief` packages are installed.
      Extracts rich PE-file features: section info, imports/exports,
      strings, byte histogram, byte-entropy histogram, etc.
      Install: pip install ember lief

  Basic mode  (258 features)
      Always available — no extra dependencies.
      Features: file_size (raw bytes), Shannon entropy, 256-bin
      normalised byte histogram.

The scanner reads the companion <model>.meta.json to decide which
extractor to use so that inference always matches the training
feature set.
"""

import math
import logging
import os
from collections import Counter

import numpy as np

logger = logging.getLogger(__name__)

# ── EMBER feature extractor (optional) ───────────────────────────────────────
_EMBER_EXTRACTOR = None
HAS_EMBER = False

try:
    import ember as _ember_mod
    import lief
    
    # Verify lief has the required bad_format exception (version compat check)
    if not hasattr(lief, "bad_format"):
        raise ImportError(
            f"lief {lief.__version__} is missing 'bad_format' exception. "
            "This is likely due to a version mismatch. "
            "Please install lief >= 0.9, < 0.13 for EMBER compatibility."
        )
    
    # Instantiate once; PEFeatureExtractor is not thread-safe for parallel
    # file opens, but single-threaded scan is fine.
    _EMBER_EXTRACTOR = _ember_mod.PEFeatureExtractor(feature_version=2)
    
    # Test the extractor with a minimal sample to catch runtime issues early
    test_pe = b"MZ" + b"\x00" * 100  # minimal PE header
    try:
        _ = _EMBER_EXTRACTOR.feature_vector(test_pe)
    except Exception as test_exc:
        raise RuntimeError(
            f"EMBER extractor test failed: {test_exc}. "
            "This may indicate a lief version incompatibility."
        )
    
    HAS_EMBER = True
    logger.debug("ember + lief available: using 2351-dim EMBER feature extractor.")
except Exception as e:
    HAS_EMBER = False
    logger.debug(f"EMBER extractor unavailable: {e}. Falling back to basic 258-dim extractor.")

# The EMBER feature vector length varies slightly with the lief version used
# during extraction.  lief 0.9 (original EMBER paper) produces 2351 features;
# lief 0.12+ produces 2381.  We report the true length from the installed
# version rather than a hardcoded constant so that the scanner can validate
# the match against whatever model was trained.
EMBER_FEATURE_COUNT: int = 0   # resolved at first call to _extract_ember_features()
BASIC_FEATURE_COUNT = 258  # file_size + entropy + 256-bin byte histogram


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

def extract_features(file_path: str, use_ember: bool = None) -> list:
    """
    Extract a flat feature vector from *file_path*.

    Parameters
    ----------
    file_path  : Absolute or relative path to the file.
    use_ember  : Force EMBER (True) or basic (False) mode.
                 None → auto-select: tries EMBER when installed, silently
                 falls back to basic on failure.
                 True → EMBER required; propagates exceptions so the caller
                 can surface the real error rather than a silent dim-mismatch.

    Returns
    -------
    List[float] of length EMBER_FEATURE_COUNT or BASIC_FEATURE_COUNT (258).
    Returns a zero vector of the appropriate length on any read error (basic
    mode only).
    """
    explicitly_requested = use_ember is not None
    if use_ember is None:
        use_ember = HAS_EMBER

    if use_ember and HAS_EMBER:
        return _extract_ember_features(file_path,
                                       silent_fallback=not explicitly_requested)
    return _extract_basic_features(file_path)


def get_feature_count(use_ember: bool = None) -> int:
    """Return the vector length that extract_features() will produce."""
    if use_ember is None:
        use_ember = HAS_EMBER
    if use_ember and HAS_EMBER:
        # Probe the real length by running a tiny extraction once
        global EMBER_FEATURE_COUNT
        if EMBER_FEATURE_COUNT == 0:
            try:
                import tempfile
                with tempfile.NamedTemporaryFile(delete=False, suffix=".bin") as f:
                    f.write(b"\x00" * 64)
                    probe_path = f.name
                v = _extract_ember_features(probe_path)
                os.unlink(probe_path)
                EMBER_FEATURE_COUNT = len(v)
            except Exception:
                EMBER_FEATURE_COUNT = 2381  # safe fallback
        return EMBER_FEATURE_COUNT
    return BASIC_FEATURE_COUNT


# ═══════════════════════════════════════════════════════════════════════════════
# EMBER  (2351-dim PE feature vector)
# ═══════════════════════════════════════════════════════════════════════════════

def _extract_ember_features(file_path: str, silent_fallback: bool = True) -> list:
    """
    Extract EMBER feature vector via ember.PEFeatureExtractor.

    Non-PE files (scripts, documents, etc.) are handled gracefully —
    lief returns zeroed PE-specific sub-features while byte-level
    features (histogram, entropy) are still computed correctly.

    Parameters
    ----------
    silent_fallback : When True (auto-select mode) any extraction error
        silently falls back to the 258-dim basic extractor.  When False
        (explicitly requested) the exception is re-raised so the caller
        can surface the real root cause instead of returning a mismatched
        vector that will fail later at ONNX inference.
    """
    global HAS_EMBER, _EMBER_EXTRACTOR

    try:
        with open(file_path, "rb") as f:
            bytez = f.read()
        fv = _EMBER_EXTRACTOR.feature_vector(bytez)
        return fv.astype(np.float32).tolist()
    except AttributeError as exc:
        # Catch lief version-incompatibility errors (e.g. missing bad_format)
        # at the per-file level in case they slip past the import-time check.
        # Disable EMBER globally so we don't warn for every single file.
        if "bad_format" in str(exc) or "lief" in str(exc).lower():
            logger.warning(
                f"lief version incompatibility detected ({exc}). "
                "Disabling EMBER extractor for this session and falling back to "
                "basic 258-dim extractor. "
                "Install lief >= 0.9, < 0.13 to use EMBER features."
            )
            HAS_EMBER = False
            _EMBER_EXTRACTOR = None
        elif not silent_fallback:
            raise RuntimeError(
                f"EMBER feature extraction failed for "
                f"'{os.path.basename(file_path)}': {exc}"
            ) from exc
        return _extract_basic_features(file_path)
    except Exception as exc:
        if silent_fallback:
            logger.warning(
                f"EMBER extraction failed for {os.path.basename(file_path)}: {exc} "
                "— falling back to basic extractor."
            )
            return _extract_basic_features(file_path)
        # Caller explicitly asked for EMBER — surface the real error.
        raise RuntimeError(
            f"EMBER feature extraction failed for "
            f"'{os.path.basename(file_path)}': {exc}"
        ) from exc


# ═══════════════════════════════════════════════════════════════════════════════
# Basic  (258-dim: size + entropy + byte histogram)
# ═══════════════════════════════════════════════════════════════════════════════

def _extract_basic_features(file_path: str) -> list:
    """
    Extract 258 basic features:
      [0]    File size in bytes (float)
      [1]    Shannon entropy (0 – 8 bits)
      [2-257] Normalised 256-bin byte histogram (counts / total_bytes)

    Returns a zero vector on any read error.
    """
    try:
        with open(file_path, "rb") as f:
            data = f.read()
    except Exception:
        return [0.0] * BASIC_FEATURE_COUNT

    if not data:
        return [0.0] * BASIC_FEATURE_COUNT

    size = len(data)

    # Shannon entropy
    entropy = 0.0
    for count in Counter(data).values():
        p = count / size
        entropy -= p * math.log2(p)

    # Normalised byte histogram
    counts = np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256)
    histogram = (counts / size).astype(np.float32)

    return [float(size), float(entropy)] + histogram.tolist()
