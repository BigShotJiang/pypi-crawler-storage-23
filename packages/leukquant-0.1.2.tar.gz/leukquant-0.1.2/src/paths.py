r"""
Leukquant — Platform-Aware Application Paths
=============================================
All runtime data (models, keys, DBs, quarantine, logs) is stored in a
single, platform-appropriate hidden directory:

  Linux / macOS  ->  ~/.leukquant/
                     (respects XDG_DATA_HOME if set)
  Windows        ->  %APPDATA%\Leukquant\
                     (C:\Users\<user>\AppData\Roaming\Leukquant)

Override everything by setting LEUKQUANT_HOME:
    LEUKQUANT_HOME=/srv/leukquant leukquant scan --file ...

Sub-directory layout
--------------------
  <APP_DIR>/
    config/Leukquant.yml    -- runtime configuration
    models/                 -- ONNX model + .meta.json
    db/                     -- threats.db, behavior_baseline.db
    keys/                   -- kem.pub/priv, sig.pub/priv
    logs/                   -- monitor.pid, application logs
    quarantine/             -- isolated malicious files
    exports/                -- .lqsig signature bundles
    data/                   -- optional dataset downloads (kaggle, etc.)
"""

import os
import platform


def _compute_app_dir() -> str:
    # Explicit override — useful in containers, CI, or multi-user installs
    override = os.environ.get("LEUKQUANT_HOME", "").strip()
    if override:
        return os.path.abspath(os.path.expanduser(override))

    system = platform.system()

    if system == "Windows":
        # %APPDATA% → C:\Users\<user>\AppData\Roaming
        appdata = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(appdata, "Leukquant")

    # Linux / macOS / other POSIX
    # Honour XDG Base Directory spec on Linux if set
    xdg = os.environ.get("XDG_DATA_HOME", "").strip()
    if xdg:
        return os.path.join(os.path.expanduser(xdg), "leukquant")

    # Default: hidden dot-directory in the user's home
    return os.path.join(os.path.expanduser("~"), ".leukquant")


#: Absolute path to the application data directory (computed once at import).
APP_DIR: str = _compute_app_dir()

#: Absolute path to the repository / installed-package root.
#  Running from source  → /path/to/Leukquant/
#  Installed via pip   → <site-packages>/  (parent of the `src` package)
PACKAGE_ROOT: str = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def bundled_models_dir() -> str:
    """
    Return the path to the models directory that is shipped with the package.

    Search order
    ------------
    1. ``src/cli/models/``  — present in both the source tree and an installed
       wheel (declared via ``package-data`` in pyproject.toml).
    2. ``<PACKAGE_ROOT>/models/`` — top-level workspace copy (source-tree only).
    3. Empty string if neither exists (caller must handle gracefully).
    """
    # Preferred: lives inside the installed package tree
    candidate = os.path.join(os.path.dirname(__file__), "cli", "models")
    if os.path.isdir(candidate):
        return os.path.abspath(candidate)

    # Fallback: top-level workspace models/ (development checkout)
    candidate = os.path.join(PACKAGE_ROOT, "models")
    if os.path.isdir(candidate):
        return os.path.abspath(candidate)

    return ""


def app_path(*parts: str) -> str:
    """
    Join *parts* under APP_DIR and return an absolute path.

    Examples
    --------
    >>> app_path("models", "malware_detector.onnx")
    '/home/alice/.leukquant/models/malware_detector.onnx'
    >>> app_path("keys")
    '/home/alice/.leukquant/keys'
    """
    return os.path.join(APP_DIR, *parts)
