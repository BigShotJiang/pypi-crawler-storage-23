import threading
import time
import logging
from collections import deque
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import psutil

logger = logging.getLogger(__name__)


class FileEventTracker(FileSystemEventHandler):
    """Tracks file system create/modify events using a rolling time window."""

    def __init__(self, window_seconds: int = 60):
        super().__init__()
        self.window_seconds = window_seconds
        self._events: deque = deque()
        self._lock = threading.Lock()

    def on_created(self, event):
        if not event.is_directory:
            self._record("created", event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._record("modified", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            self._record("deleted", event.src_path)

    def _record(self, kind: str, path: str):
        now = time.monotonic()
        with self._lock:
            self._events.append((now, kind, path))
            cutoff = now - self.window_seconds
            while self._events and self._events[0][0] < cutoff:
                self._events.popleft()

    def get_rate(self) -> float:
        """Return events-per-minute in the current window."""
        now = time.monotonic()
        cutoff = now - self.window_seconds
        with self._lock:
            recent = sum(1 for ts, _, _ in self._events if ts >= cutoff)
        # Normalize to events/minute
        return (recent / self.window_seconds) * 60


class SystemMonitor:
    """
    Aggregates real-time system metrics:
      - File system event rate (watchdog)
      - Active process count (psutil)
      - Network connection count (psutil)
      - Memory utilization % (psutil)
    """

    def __init__(self, watch_path: str = "/tmp", window_seconds: int = 60):
        self.watch_path = watch_path
        self.file_tracker = FileEventTracker(window_seconds)
        self._observer = Observer()
        self._observer.schedule(self.file_tracker, watch_path, recursive=True)
        self._running = False

    def start(self):
        if not self._running:
            try:
                self._observer.start()
                self._running = True
                logger.info(f"SystemMonitor started. Watching: {self.watch_path}")
            except Exception as e:
                logger.warning(f"Could not start file watcher: {e}")

    def stop(self):
        if self._running:
            self._observer.stop()
            self._observer.join()
            self._running = False
            logger.info("SystemMonitor stopped.")

    def get_snapshot(self) -> dict:
        try:
            mem = psutil.virtual_memory()
            net = psutil.net_connections(kind="inet")
            return {
                "process_spawn_rate": len(psutil.pids()),
                "file_write_rate": self.file_tracker.get_rate(),
                "network_socket_count": len(net),
                "memory_alloc_spikes": mem.percent,
            }
        except Exception as e:
            logger.warning(f"SystemMonitor snapshot error: {e}")
            return {
                "process_spawn_rate": 0,
                "file_write_rate": 0.0,
                "network_socket_count": 0,
                "memory_alloc_spikes": 0.0,
            }

    @staticmethod
    def top_offender_process() -> dict | None:
        """
        Return info on the process consuming the most CPU right now.
        Used by the behavior profiler to decide *what* to quarantine on a
        CRITICAL anomaly event.

        Returns a dict with keys: pid, name, exe, cpu_percent, cmdline
        or None if no process could be identified.
        """
        best = None
        best_cpu = -1.0
        # First call initialises the per-process CPU interval counters.
        for proc in psutil.process_iter(["pid", "name", "exe", "cmdline"]):
            try:
                cpu = proc.cpu_percent(interval=None)
                if cpu > best_cpu:
                    best_cpu = cpu
                    best = proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if best is None:
            return None

        try:
            return {
                "pid":     best.pid,
                "name":    best.name(),
                "exe":     best.exe(),          # absolute path to the binary
                "cpu_percent": best_cpu,
                "cmdline": " ".join(best.cmdline()),
            }
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None
