import time
import numpy as np
import logging
import os
from datetime import datetime
from src.db.database import DatabaseManager
from src.behavior.monitors import SystemMonitor
from src.config import Config
from src.paths import app_path

logger = logging.getLogger(__name__)

MIN_BASELINE_SAMPLES = 10

# Processes whose executables should never be quarantined even at CRITICAL score.
# Add more system-critical binaries here as needed.
_QUARANTINE_BLOCKLIST: frozenset[str] = frozenset({
    "systemd", "init", "kthreadd", "kernel",
    "sshd", "login", "sudo", "su",
    "python", "python3",   # would quarantine ourselves
    "leukquant",
})


class BehaviorProfiler:
    """
    Collects system metrics every `poll_interval` seconds, stores them in SQLite,
    and computes a Z-score anomaly metric against the rolling `baseline_days`-day window.

        A(t) = (1/N) * Σ |x_i(t) − μ_i| / σ_i

    Scores above `alert_threshold` are logged; scores above `quarantine_threshold`
    are also written as anomaly events for downstream quarantine decisions.
    """

    PID_FILE = app_path("logs", "monitor.pid")

    def __init__(self, poll_interval: int = 60):
        cfg = Config.get()
        self.baseline_days: int = cfg.get_value("behavior", "baseline_period_days", default=14)
        self.alert_threshold: float = cfg.get_value("behavior", "alert_threshold", default=3.5)
        self.quarantine_threshold: float = cfg.get_value("behavior", "quarantine_threshold", default=5.0)
        self.poll_interval = poll_interval
        self.db = DatabaseManager()
        self.monitor = SystemMonitor()

    # ─── metric helpers ───────────────────────────────────────────────────────

    def _collect(self) -> dict:
        snap = self.monitor.get_snapshot()
        snap["timestamp"] = datetime.now()
        return snap

    def calculate_anomaly_score(self, metrics: dict) -> float:
        rows = self.db.get_baseline_metrics(days=self.baseline_days)
        if len(rows) < MIN_BASELINE_SAMPLES:
            logger.debug(f"Only {len(rows)} samples in baseline — skipping anomaly scoring.")
            return 0.0

        baseline = np.array(rows, dtype=float)
        means = np.mean(baseline, axis=0)
        stds = np.std(baseline, axis=0)
        stds[stds == 0] = 1e-6

        current = np.array([
            metrics["process_spawn_rate"],
            metrics["file_write_rate"],
            metrics["network_socket_count"],
            metrics["memory_alloc_spikes"],
        ], dtype=float)

        z_scores = np.abs(current - means) / stds
        return float(np.mean(z_scores))

    # ─── quarantine helper ────────────────────────────────────────────────────

    def _try_quarantine_offender(self, score: float, details: str) -> None:
        """
        Identify the top CPU-consuming process and quarantine its executable
        if it is not on the system-process blocklist.
        """
        from src.quarantine.manager import QuarantineManager

        proc = self.monitor.top_offender_process()
        if not proc:
            logger.warning("[AUTO-QUARANTINE] Could not identify top offending process.")
            return

        exe = proc.get("exe", "") or ""
        name = proc.get("name", "") or ""

        if not exe or not os.path.isfile(exe):
            logger.warning(
                f"[AUTO-QUARANTINE] Skipped — no executable path for "
                f"'{name}' (pid={proc['pid']})."
            )
            return

        if name in _QUARANTINE_BLOCKLIST or os.path.basename(exe) in _QUARANTINE_BLOCKLIST:
            logger.warning(
                f"[AUTO-QUARANTINE] Skipped — '{name}' (pid={proc['pid']}) "
                f"is on the system-process blocklist."
            )
            return

        reason = (
            f"Behavior anomaly score={score:.3f} (threshold={self.quarantine_threshold}) | "
            f"pid={proc['pid']} cpu={proc['cpu_percent']:.1f}% | {details}"
        )
        try:
            qm = QuarantineManager()
            qid = qm.quarantine_file(exe, reason=reason)
            logger.warning(
                f"[AUTO-QUARANTINE] '{exe}' quarantined (id={qid}, "
                f"pid={proc['pid']}, cpu={proc['cpu_percent']:.1f}%)."
            )
        except Exception as exc:
            logger.error(f"[AUTO-QUARANTINE] Failed to quarantine '{exe}': {exc}")

    # ─── main loop ────────────────────────────────────────────────────────────

    def monitor_loop(self):
        os.makedirs(app_path("logs"), exist_ok=True)
        with open(self.PID_FILE, "w") as f:
            f.write(str(os.getpid()))

        self.monitor.start()
        logger.info(f"Behavior monitor started (PID {os.getpid()}, interval {self.poll_interval}s).")

        try:
            while True:
                metrics = self._collect()
                self.db.insert_metrics(metrics)
                score = self.calculate_anomaly_score(metrics)

                if score > self.alert_threshold:
                    details = (
                        f"score={score:.3f} | "
                        f"procs={metrics['process_spawn_rate']} | "
                        f"files/min={metrics['file_write_rate']:.1f} | "
                        f"sockets={metrics['network_socket_count']} | "
                        f"mem%={metrics['memory_alloc_spikes']:.1f}"
                    )
                    level = "CRITICAL" if score > self.quarantine_threshold else "WARNING"
                    logger.warning(f"[{level}] Anomaly score {score:.3f} — {details}")
                    self.db.log_anomaly(score, details)

                    # ── Auto-quarantine on CRITICAL ──────────────────────────
                    if score > self.quarantine_threshold:
                        self._try_quarantine_offender(score, details)

                time.sleep(self.poll_interval)
        finally:
            self.monitor.stop()
            if os.path.exists(self.PID_FILE):
                os.remove(self.PID_FILE)
            logger.info("Behavior monitor stopped.")
