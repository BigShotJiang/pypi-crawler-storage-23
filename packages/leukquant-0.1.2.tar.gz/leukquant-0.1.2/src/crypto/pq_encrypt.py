import os
import struct
import logging
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives import serialization

from src.paths import app_path

logger = logging.getLogger(__name__)

try:
    import oqs
    _test_kem = oqs.KeyEncapsulation.__doc__  # probe C library
    HAS_OQS = True
except (ImportError, SystemExit, OSError, RuntimeError):
    HAS_OQS = False
    oqs = None  # type: ignore
    logger.warning("liboqs C library not found. Falling back to classical X25519/Ed25519 crypto.")

class PQCryptoVault:
    def __init__(self, keys_dir: str = None):
        self.keys_dir = keys_dir or app_path("keys")
        os.makedirs(self.keys_dir, exist_ok=True)
        self.kem_alg = "ML-KEM-1024" if HAS_OQS else "X25519"
        self.sig_alg = "ML-DSA-87" if HAS_OQS else "Ed25519"

    def generate_keys(self):
        if HAS_OQS:
            with oqs.KeyEncapsulation(self.kem_alg) as kem:
                kem_pub = kem.generate_keypair()
                kem_priv = kem.export_secret_key()
            with oqs.Signature(self.sig_alg) as sig:
                sig_pub = sig.generate_keypair()
                sig_priv = sig.export_secret_key()
        else:
            kem_key = x25519.X25519PrivateKey.generate()
            kem_priv = kem_key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
            kem_pub = kem_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            
            sig_key = ed25519.Ed25519PrivateKey.generate()
            sig_priv = sig_key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
            sig_pub = sig_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

        # Guard: remove any stale directory at key file paths (can happen if
        # os.makedirs was previously called with a key filename as the path).
        import shutil
        for name in ("kem.priv", "kem.pub", "sig.priv", "sig.pub"):
            p = os.path.join(self.keys_dir, name)
            if os.path.isdir(p):
                logger.warning(f"Removing stale directory at key path: {p}")
                shutil.rmtree(p)

        with open(os.path.join(self.keys_dir, "kem.priv"), "wb") as f: f.write(kem_priv)
        with open(os.path.join(self.keys_dir, "kem.pub"), "wb") as f: f.write(kem_pub)
        with open(os.path.join(self.keys_dir, "sig.priv"), "wb") as f: f.write(sig_priv)
        with open(os.path.join(self.keys_dir, "sig.pub"), "wb") as f: f.write(sig_pub)
        logger.info("Keys generated successfully.")

    def encrypt_file(self, file_path: str, recipient_pub_path: str = None, output_path: str = None):
        if not os.path.exists(file_path):
            logger.error(f"File not found: {file_path}")
            return False

        if output_path is None:
            output_path = file_path + ".sqe"

        if recipient_pub_path is None:
            recipient_pub_path = os.path.join(self.keys_dir, "kem.pub")

        try:
            with open(file_path, "rb") as f:
                plaintext = f.read()
            with open(recipient_pub_path, "rb") as f:
                recipient_pub = f.read()
            with open(os.path.join(self.keys_dir, "sig.priv"), "rb") as f:
                sender_priv = f.read()

            # 1. Key Encapsulation
            if HAS_OQS:
                with oqs.KeyEncapsulation(self.kem_alg) as kem:
                    ciphertext_kem, shared_secret = kem.encap_secret(recipient_pub)
            else:
                ephemeral = x25519.X25519PrivateKey.generate()
                ciphertext_kem = ephemeral.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
                recipient_key = x25519.X25519PublicKey.from_public_bytes(recipient_pub)
                shared_secret = ephemeral.exchange(recipient_key)

            # 2. AES-256-GCM Encryption
            derived_key = HKDF(
                algorithm=hashes.SHA256(),
                length=32,
                salt=None,
                info=b'leukquant-kem-aes'
            ).derive(shared_secret)

            aesgcm = AESGCM(derived_key)
            nonce = os.urandom(12) # 96-bit nonce
            ciphertext = aesgcm.encrypt(nonce, plaintext, None)

            # 3. Signature (must pass secret_key so the OQS context can actually sign)
            if HAS_OQS:
                with oqs.Signature(self.sig_alg, secret_key=sender_priv) as sig:
                    signature = sig.sign(ciphertext)
            else:
                signer = ed25519.Ed25519PrivateKey.from_private_bytes(sender_priv)
                signature = signer.sign(ciphertext)

            # 4. Write Encrypted Bundle
            with open(output_path, "wb") as f:
                # Format: MAGIC(4) + KEM_LEN(4) + KEM + NONCE(12) + SIG_LEN(4) + SIG + CIPHERTEXT
                f.write(b'SQE1')
                f.write(struct.pack('>I', len(ciphertext_kem)))
                f.write(ciphertext_kem)
                f.write(nonce)
                f.write(struct.pack('>I', len(signature)))
                f.write(signature)
                f.write(ciphertext)

            logger.info(f"Successfully encrypted {file_path} to {output_path}")
            return True

        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            return False

    def decrypt_file(self, file_path: str, private_key_path: str = None, output_path: str = None):
        if private_key_path is None:
            private_key_path = os.path.join(self.keys_dir, "kem.priv")
            
        if output_path is None:
            output_path = file_path.replace(".sqe", ".dec")

        try:
            with open(file_path, "rb") as f:
                magic = f.read(4)
                if magic != b'SQE1':
                    raise ValueError("Invalid file format")
                
                kem_len = struct.unpack('>I', f.read(4))[0]
                ciphertext_kem = f.read(kem_len)
                nonce = f.read(12)
                sig_len = struct.unpack('>I', f.read(4))[0]
                signature = f.read(sig_len)
                ciphertext = f.read()

            with open(private_key_path, "rb") as f:
                kem_priv = f.read()

            # 0. Verify signature BEFORE decapsulation (Encrypt-then-Sign: fail fast on tampered data)
            sig_pub_path = os.path.join(self.keys_dir, "sig.pub")
            if os.path.exists(sig_pub_path):
                with open(sig_pub_path, "rb") as f:
                    sender_pub = f.read()
                try:
                    if HAS_OQS:
                        with oqs.Signature(self.sig_alg) as verifier:
                            if not verifier.verify(ciphertext, signature, sender_pub):
                                raise ValueError("Signature verification failed — file may be tampered!")
                    else:
                        pub_key = ed25519.Ed25519PublicKey.from_public_bytes(sender_pub)
                        pub_key.verify(signature, ciphertext)  # raises InvalidSignature if bad
                except Exception as sig_err:
                    raise ValueError(f"Signature verification failed: {sig_err}") from sig_err
            else:
                logger.warning("sig.pub not found — skipping signature verification.")

            # 1. Decapsulate (must pass secret_key to the OQS context)
            if HAS_OQS:
                with oqs.KeyEncapsulation(self.kem_alg, secret_key=kem_priv) as kem:
                    shared_secret = kem.decap_secret(ciphertext_kem)
            else:
                priv_key = x25519.X25519PrivateKey.from_private_bytes(kem_priv)
                peer_pub = x25519.X25519PublicKey.from_public_bytes(ciphertext_kem)
                shared_secret = priv_key.exchange(peer_pub)

            # 2. AES-256-GCM Decryption
            derived_key = HKDF(
                algorithm=hashes.SHA256(),
                length=32,
                salt=None,
                info=b'leukquant-kem-aes'
            ).derive(shared_secret)

            aesgcm = AESGCM(derived_key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)

            with open(output_path, "wb") as f:
                f.write(plaintext)

            logger.info(f"Successfully decrypted {file_path} to {output_path}")
            return True

        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            return False
