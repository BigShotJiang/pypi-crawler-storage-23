"""
Leukquant CLI
=============
Entry point: leukquant <command>

Commands
--------
  init            Set up directories, DBs, and crypto keys
  train           Train ONNX model (synthetic | EMBER | VirusShare | Kaggle | files)
  scan            Scan a file or directory with AI + signature DB
  monitor start   Start behavior monitoring (foreground or --daemon)
  monitor stop    Stop background daemon
  monitor status  Show current anomaly log + system snapshot
  encrypt         PQ-encrypt a file → .sqe bundle
  decrypt         Decrypt a .sqe file
  verify          Verify .sqe file signature
  keygen          Generate a new PQ keypair
  quarantine list Inspect quarantined files
  quarantine restore  Restore a file from quarantine
  quarantine delete   Permanently delete a quarantined file
  add-sig         Manually add a threat hash to the local DB
  export-sigs     Export signatures to a signed binary file
  import-sigs     Import & verify signatures from a binary file
  service install   Register monitor as an auto-start service (survives reboot)
  service uninstall Remove the auto-start service
  status          System health dashboard
"""

import click
import logging
import platform
import signal
import sys
import os
import shutil
import subprocess
import struct
from importlib.metadata import version as _pkg_version, PackageNotFoundError
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from rich import box

# ─── path bootstrap (works both installed and run directly) ──────────────────
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
# All data paths are now absolute (rooted at APP_DIR = ~/.leukquant on Linux,
# %APPDATA%\Leukquant on Windows) — no os.chdir() needed.

from src.scanner.scan import LocalScanner
from src.scanner.train import (
    train_dummy_model,
    train_with_ember,
    import_virusshare_hashes,
    train_with_kaggle_csv,
    train_with_file_dirs,
)
from src.behavior.profiler import BehaviorProfiler
from src.offline.sync import OfflineSync
from src.db.database import DatabaseManager
from src.quarantine.manager import QuarantineManager
from src.service import install_service, uninstall_service, service_installed
from src.config import Config
from src.paths import APP_DIR, app_path, bundled_models_dir

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
console = Console()

# ─── version (single source of truth: pyproject.toml via package metadata) ───
try:
    __version__ = _pkg_version("leukquant")
except PackageNotFoundError:
    # Running directly from source tree without `pip install -e .`
    # Read version straight from pyproject.toml so it still stays in sync.
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # pip install tomli on 3.9/3.10
        except ImportError:
            tomllib = None  # type: ignore

    if tomllib is not None:
        _toml_path = os.path.join(_ROOT, "pyproject.toml")
        try:
            with open(_toml_path, "rb") as _f:
                __version__ = tomllib.load(_f)["project"]["version"]
        except Exception:
            __version__ = "dev"
    else:
        __version__ = "dev"


# ═══════════════════════════════════════════════════════════════════════════════
# Root group
# ═══════════════════════════════════════════════════════════════════════════════

@click.group()
@click.version_option(version=__version__, prog_name="leukquant")
def cli():
    """Leukquant — Fully Local, Decentralized Threat Defense."""


# ═══════════════════════════════════════════════════════════════════════════════
# init
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command()
def init():
    """Initialize directories, databases, and cryptographic keys."""
    console.print(Panel.fit("[bold cyan]Leukquant — Initialization[/bold cyan]"))

    from src.crypto.key_manager import KeyManager

    for d in ("models", "db", "keys", "logs", "quarantine", "exports", "config"):
        full = app_path(d)
        os.makedirs(full, exist_ok=True)
        console.print(f"  [green]\u2713[/green] {full}")

    # ── seed bundled models into APP_DIR/models/ ──────────────────────────────
    src_models = bundled_models_dir()
    dst_models = app_path("models")
    if src_models:
        seeded: list[str] = []
        skipped: list[str] = []
        for fname in os.listdir(src_models):
            if not fname.endswith((".onnx", ".meta.json", ".ggml")):
                continue
            src_file = os.path.join(src_models, fname)
            dst_file = os.path.join(dst_models, fname)
            if os.path.exists(dst_file):
                skipped.append(fname)
            else:
                shutil.copy2(src_file, dst_file)
                seeded.append(fname)
        for fname in seeded:
            console.print(f"  [green]✓[/green] Seeded model: {os.path.join(dst_models, fname)}")
        for fname in skipped:
            console.print(f"  [yellow]↷[/yellow] Model already present, skipped: {fname}")
        if not seeded and not skipped:
            console.print(f"  [yellow]⚠[/yellow] No bundled models found in {src_models}")
    else:
        console.print(
            "  [yellow]⚠[/yellow] No bundled models directory found — "
            "run [bold]leukquant train[/bold] to generate a model."
        )

    db = DatabaseManager()
    console.print("  [green]✓[/green] Databases initialized.")

    km = KeyManager()
    kem_pub, kem_priv = km.generate_kem_keypair()
    km.save_keypair("kem", kem_pub, kem_priv)
    sig_pub, sig_priv = km.generate_sig_keypair()
    km.save_keypair("sig", sig_pub, sig_priv)
    console.print(f"  [green]✓[/green] Keys generated ({'PQC' if km.is_pqc else 'Classical fallback'}).")

    cfg = Config.get()
    cfg.save()
    console.print("  [green]✓[/green] Config saved to config/Leukquant.yml")

    console.print(
        Panel(
            "Done! Run [bold]leukquant train[/bold] to generate the AI model, "
            "then [bold]leukquant scan --file <path>[/bold] to test.",
            title="[green]Success[/green]",
        )
    )


# ═══════════════════════════════════════════════════════════════════════════════
# train
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--output", default=None, show_default=False,
              help=f"Output path for the ONNX model [default: {app_path('models','malware_detector.onnx')}]")
@click.option(
    "--source",
    type=click.Choice(["synthetic", "ember", "virusshare", "kaggle", "files"]),
    default="synthetic", show_default=True,
    help="Training data source",
)
@click.option("--ember-dir",    default=None, help="[ember]      Path to extracted EMBER 2018 directory")
@click.option("--hash-list",    default=None, help="[virusshare] Path to VirusShare .md5 / .txt hash list")
@click.option("--csv",          default=None, metavar="PATH",
              help="[kaggle]     Path to Kaggle CSV feature file")
@click.option("--kaggle-dataset", default=None, metavar="SLUG",
              help="[kaggle]     Kaggle dataset slug to download first, e.g. rtatman/malware-classification")
@click.option("--dest-dir",     default=None, show_default=False,
              help=f"[kaggle]     Download destination [default: {app_path('data', 'kaggle')}]")
@click.option("--malware-dir",  default=None, help="[files]      Directory of malware binary samples")
@click.option("--benign-dir",   default=None, help="[files]      Directory of benign binary samples")
@click.option("--subset",       default=None, type=int,
              help="[ember]      Limit training samples (e.g. 100000)")
@click.option("--estimators",   default=100,  show_default=True, type=int,
              help="Number of RandomForest trees")
def train(output, source, ember_dir, hash_list, csv, kaggle_dataset,
          dest_dir, malware_dir, benign_dir, subset, estimators):
    """
    Train / populate the local threat-detection model.

    \b
    Source options
    --------------
    synthetic    Random 258-feature data — no dataset needed (default)

    ember        Elastic EMBER 2018 — ~1 M labelled PE samples, 2351 features
                   pip install ember lief
                   Download: https://ember.elastic.co/ember_dataset_2018_2.tar.bz2
                   leukquant train --source ember --ember-dir ~/data/ember2018

    virusshare   VirusShare MD5/SHA-256 hash lists → populated into signature DB
                   Download (free, no login): https://virusshare.com/hashfiles
                   leukquant train --source virusshare --hash-list ~/VirusShare_00000.md5

    kaggle       Kaggle CSV malware dataset (pip install kaggle + API token)
                   leukquant train --source kaggle --kaggle-dataset rtatman/malware-classification
                   leukquant train --source kaggle --csv data/kaggle/malware_features.csv

    files        Raw binary samples from local directories (258-feature extractor)
                   leukquant train --source files --malware-dir ~/samples/mal --benign-dir ~/samples/ok
    """
    output   = output   or app_path("models", "malware_detector.onnx")
    dest_dir = dest_dir or app_path("data", "kaggle")

    if source == "synthetic":
        with console.status("[bold yellow]Training on synthetic data…[/bold yellow]", spinner="dots"):
            train_dummy_model(output_path=output, n_estimators=estimators)
        console.print(f"[bold green]✓ Model saved:[/bold green] {output}")

    elif source == "ember":
        if not ember_dir:
            console.print("[red]--ember-dir is required for --source ember[/red]")
            console.print(
                "  Download: [link]https://ember.elastic.co/ember_dataset_2018_2.tar.bz2[/link]\n"
                "  Install:  [bold]pip install ember lief[/bold]"
            )
            sys.exit(1)
        with console.status("[bold yellow]Training on EMBER 2018 dataset…[/bold yellow]", spinner="dots"):
            train_with_ember(
                ember_data_dir=ember_dir,
                output_path=output,
                subset_size=subset,
                n_estimators=estimators,
            )
        console.print(f"[bold green]✓ EMBER model saved:[/bold green] {output}")

    elif source == "virusshare":
        if not hash_list:
            console.print("[red]--hash-list is required for --source virusshare[/red]")
            console.print(
                "  Download hash lists (free): "
                "[link]https://virusshare.com/hashfiles[/link]"
            )
            sys.exit(1)
        with console.status("[bold yellow]Importing VirusShare hashes…[/bold yellow]", spinner="dots"):
            n = import_virusshare_hashes(hash_list)
        console.print(f"[bold green]✓ Imported {n} new threat signatures[/bold green] from {hash_list}")
        console.print("[dim]VirusShare populates the signature DB — no ONNX model is produced.[/dim]")

    elif source == "kaggle":
        # Optional: download first
        if kaggle_dataset and not csv:
            from src.scanner.dataset_loaders import download_kaggle_dataset
            with console.status(f"[bold yellow]Downloading {kaggle_dataset}…[/bold yellow]", spinner="dots"):
                dest = download_kaggle_dataset(kaggle_dataset, dest_dir=dest_dir)
            console.print(f"[green]✓ Dataset downloaded to {dest}[/green]")
            console.print("[dim]Re-run with [bold]--csv <path/to/file.csv>[/bold] to train.[/dim]")
            return
        if not csv:
            console.print("[red]Provide --csv <path> or --kaggle-dataset <slug> for --source kaggle[/red]")
            sys.exit(1)
        with console.status("[bold yellow]Training on Kaggle CSV…[/bold yellow]", spinner="dots"):
            train_with_kaggle_csv(csv_path=csv, output_path=output, n_estimators=estimators)
        console.print(f"[bold green]✓ Kaggle model saved:[/bold green] {output}")

    elif source == "files":
        if not malware_dir:
            console.print("[red]--malware-dir is required for --source files[/red]")
            sys.exit(1)
        with console.status("[bold yellow]Extracting features from binary files…[/bold yellow]", spinner="dots"):
            train_with_file_dirs(
                malware_dir=malware_dir,
                benign_dir=benign_dir,
                output_path=output,
                n_estimators=estimators,
            )
        console.print(f"[bold green]✓ File-trained model saved:[/bold green] {output}")


# ═══════════════════════════════════════════════════════════════════════════════
# scan
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--file", "target", required=True,
              help="File or directory to scan")
@click.option("--quarantine-on-detect", is_flag=True, default=False,
              help="Auto-quarantine files flagged as MALICIOUS")
def scan(target, quarantine_on_detect):
    """Scan a file or directory using local AI + signature database."""
    scanner = LocalScanner()
    qm = QuarantineManager() if quarantine_on_detect else None

    targets = []
    if os.path.isdir(target):
        for root, _, files in os.walk(target):
            for fname in files:
                targets.append(os.path.join(root, fname))
    else:
        targets = [target]

    table = Table(title="Scan Results", box=box.ROUNDED, show_lines=True)
    table.add_column("File", style="dim", max_width=50)
    table.add_column("Hash (SHA-256)", style="cyan", max_width=16)
    table.add_column("Prob", justify="right")
    table.add_column("Method", style="dim")
    table.add_column("Verdict", justify="center")

    malicious_count = 0
    for path in targets:
        result = scanner.scan_file(path)
        if "error" in result:
            table.add_row(path, "—", "—", "—", f"[red]ERROR: {result['error']}[/red]")
            continue

        verdict = result.get("verdict", "UNKNOWN")
        prob = result.get("malware_probability", 0.0)
        short_hash = result.get("hash", "")[:16] + "…"

        if "MALICIOUS" in verdict:
            malicious_count += 1
            v_display = f"[bold red]⚠ {verdict}[/bold red]"
            if qm:
                qid = qm.quarantine_file(path, reason=verdict)
                v_display += f"\n[dim]quarantine id: {qid[:8]}…[/dim]"
        else:
            v_display = f"[bold green]✓ {verdict}[/bold green]"

        table.add_row(
            os.path.basename(path),
            short_hash,
            f"{prob:.4f}",
            result.get("method", "—"),
            v_display,
        )

    console.print(table)
    if malicious_count:
        console.print(f"[bold red]{malicious_count} malicious file(s) detected![/bold red]")
    else:
        console.print("[bold green]All files clean.[/bold green]")


# ═══════════════════════════════════════════════════════════════════════════════
# monitor (subgroup)
# ═══════════════════════════════════════════════════════════════════════════════

@cli.group()
def monitor():
    """Manage the behavior monitoring daemon."""


@monitor.command("start")
@click.option("--daemon", is_flag=True, help="Fork to background and write PID file")
@click.option("--interval", default=60, show_default=True,
              help="Polling interval in seconds")
def monitor_start(daemon, interval):
    """Start behavior monitoring."""
    if daemon:
        script = os.path.abspath(__file__)
        popen_kwargs = dict(
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if platform.system() == "Windows":
            popen_kwargs["creationflags"] = (
                subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            )
        else:
            popen_kwargs["start_new_session"] = True
        proc = subprocess.Popen(
            [sys.executable, script, "monitor", "start", "--interval", str(interval)],
            **popen_kwargs,
        )
        console.print(f"[green]Monitor daemon started (PID {proc.pid}).[/green]")
    else:
        console.print("[bold green]Starting monitor (Ctrl+C to stop)…[/bold green]")
        profiler = BehaviorProfiler(poll_interval=interval)
        try:
            profiler.monitor_loop()
        except KeyboardInterrupt:
            console.print("\n[bold yellow]Monitor stopped.[/bold yellow]")


@monitor.command("stop")
def monitor_stop():
    """Stop a running background daemon."""
    pid_file = BehaviorProfiler.PID_FILE
    if not os.path.exists(pid_file):
        console.print("[red]No monitor daemon found.[/red]")
        return
    with open(pid_file) as f:
        pid = int(f.read().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        os.remove(pid_file)
        console.print(f"[green]Stopped daemon PID {pid}.[/green]")
    except (ProcessLookupError, OSError):
        os.remove(pid_file)
        console.print("[yellow]Process already gone — cleaned up PID file.[/yellow]")


@monitor.command("status")
@click.option("--limit", default=10, show_default=True, help="Number of anomaly entries to show")
def monitor_status(limit):
    """Display recent anomalies and a live system snapshot."""
    from src.behavior.monitors import SystemMonitor
    import psutil

    db = DatabaseManager()

    # Live snapshot
    snap = SystemMonitor().get_snapshot()
    snap_table = Table(title="Live Snapshot", box=box.SIMPLE)
    snap_table.add_column("Metric", style="cyan")
    snap_table.add_column("Value", justify="right")
    for k, v in snap.items():
        snap_table.add_row(k.replace("_", " ").title(), str(round(v, 2)) if isinstance(v, float) else str(v))
    console.print(snap_table)

    # Recent anomalies
    anomalies = db.get_recent_anomalies(limit=limit)
    if not anomalies:
        console.print("[dim]No anomalies logged yet.[/dim]")
        return

    a_table = Table(title=f"Recent Anomalies (last {limit})", box=box.ROUNDED)
    a_table.add_column("Timestamp", style="dim")
    a_table.add_column("Score", justify="right")
    a_table.add_column("Details")
    for a in anomalies:
        score = a["anomaly_score"]
        color = "red" if score > 5.0 else "yellow"
        a_table.add_row(
            str(a["timestamp"]),
            f"[{color}]{score:.3f}[/{color}]",
            a.get("details", ""),
        )
    console.print(a_table)


# ═══════════════════════════════════════════════════════════════════════════════
# encrypt / decrypt / verify
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--file", "file_path", required=True, help="File to encrypt")
@click.option("--recipient", default=None,
              help="Recipient public key path (default: your own keys/kem.pub)")
@click.option("--output", default=None, help="Output .sqe path")
def encrypt(file_path, recipient, output):
    """Encrypt a file to a .sqe bundle using ML-KEM-1024 + AES-256-GCM + ML-DSA-87."""
    from src.crypto.pq_encrypt import PQCryptoVault

    vault = PQCryptoVault()
    ok = vault.encrypt_file(file_path, recipient_pub_path=recipient, output_path=output)
    out = output or file_path + ".sqe"
    if ok:
        console.print(f"[green]✓ Encrypted → {out}[/green]")
    else:
        console.print(f"[red]✗ Encryption failed.[/red]")
        sys.exit(1)


@cli.command()
@click.option("--file", "file_path", required=True, help="Encrypted .sqe file")
@click.option("--key", default=None, help="Private KEM key path (default: keys/kem.priv)")
@click.option("--output", default=None, help="Output path for decrypted file")
def decrypt(file_path, key, output):
    """Decrypt a .sqe bundle."""
    from src.crypto.pq_encrypt import PQCryptoVault

    vault = PQCryptoVault()
    ok = vault.decrypt_file(file_path, private_key_path=key, output_path=output)
    out = output or file_path.replace(".sqe", ".dec")
    if ok:
        console.print(f"[green]✓ Decrypted → {out}[/green]")
    else:
        console.print("[red]✗ Decryption failed.[/red]")
        sys.exit(1)


@cli.command()
@click.option("--file", "file_path", required=True, help="Encrypted .sqe file to verify")
@click.option("--verify-key", default=None,
              help="Signer's public key path (default: keys/sig.pub)")
def verify(file_path, verify_key):
    """Verify the digital signature of a .sqe bundle without decrypting it."""
    from src.crypto.pq_encrypt import PQCryptoVault
    from src.crypto.key_manager import KeyManager

    if not os.path.exists(file_path):
        console.print(f"[red]File not found: {file_path}[/red]")
        sys.exit(1)

    vault = PQCryptoVault()
    sig_pub_path = verify_key or os.path.join(vault.keys_dir, "sig.pub")
    if not os.path.exists(sig_pub_path):
        console.print(f"[red]Signature public key not found: {sig_pub_path}[/red]")
        sys.exit(1)

    try:
        with open(file_path, "rb") as f:
            magic = f.read(4)
            if magic != b"SQE1":
                console.print("[red]Not a valid .sqe file (invalid magic bytes).[/red]")
                sys.exit(1)
            kem_len = struct.unpack(">I", f.read(4))[0]
            f.read(kem_len)        # skip KEM ciphertext
            f.read(12)             # skip nonce
            sig_len = struct.unpack(">I", f.read(4))[0]
            signature = f.read(sig_len)
            ciphertext = f.read()

        with open(sig_pub_path, "rb") as f:
            sig_pub = f.read()

        km = KeyManager()
        valid = km.verify(ciphertext, signature, sig_pub)
        if valid:
            console.print(f"[bold green]✓ Signature valid.[/bold green]  {file_path}")
        else:
            console.print(
                f"[bold red]✗ Signature INVALID — file may be tampered![/bold red]  {file_path}"
            )
            sys.exit(1)
    except Exception as e:
        console.print(f"[red]Verification error: {e}[/red]")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# keygen
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--name", required=True, help="Key name (used as filename prefix)")
@click.option("--kem-algo", default="ML-KEM-1024", show_default=True)
@click.option("--sig-algo", default="ML-DSA-87", show_default=True)
@click.option("--keys-dir", default="keys/", show_default=True)
def keygen(name, kem_algo, sig_algo, keys_dir):
    """Generate a new post-quantum keypair."""
    from src.crypto.key_manager import KeyManager

    km = KeyManager(keys_dir=keys_dir)
    kem_pub, kem_priv = km.generate_kem_keypair(kem_algo)
    km.save_keypair(f"{name}-kem", kem_pub, kem_priv)
    sig_pub, sig_priv = km.generate_sig_keypair(sig_algo)
    km.save_keypair(f"{name}-sig", sig_pub, sig_priv)
    mode = "PQC" if km.is_pqc else "Classical fallback"
    console.print(
        f"[green]✓[/green] Keypair [bold]{name}[/bold] generated "
        f"([dim]{kem_algo} / {sig_algo} — {mode}[/dim])."
    )


# ═══════════════════════════════════════════════════════════════════════════════
# quarantine (subgroup)
# ═══════════════════════════════════════════════════════════════════════════════

@cli.group()
def quarantine():
    """Manage quarantined files."""


@quarantine.command("list")
def quarantine_list():
    """List all quarantined files."""
    qm = QuarantineManager()
    entries = qm.list_quarantined()
    if not entries:
        console.print("[dim]Quarantine is empty.[/dim]")
        return

    table = Table(title="Quarantined Files", box=box.ROUNDED)
    table.add_column("ID (short)", style="cyan")
    table.add_column("Original Path")
    table.add_column("Reason", style="red")
    table.add_column("Hash (short)")
    table.add_column("Timestamp", style="dim")
    for e in entries:
        table.add_row(
            e["id"][:12] + "…",
            e["original_path"],
            e.get("reason", ""),
            (e.get("file_hash") or "")[:16] + "…",
            str(e.get("timestamp", "")),
        )
    console.print(table)


@quarantine.command("restore")
@click.option("--id", "qid", required=True, help="Quarantine entry ID (or prefix)")
def quarantine_restore(qid):
    """Restore a quarantined file to its original location."""
    qm = QuarantineManager()
    # Support prefix matching
    entries = [e for e in qm.list_quarantined() if e["id"].startswith(qid)]
    if not entries:
        console.print(f"[red]No quarantine entry matching '{qid}'.[/red]")
        sys.exit(1)
    if len(entries) > 1:
        console.print(f"[yellow]Ambiguous ID prefix — {len(entries)} matches. Use more characters.[/yellow]")
        sys.exit(1)
    entry = entries[0]
    if qm.restore_file(entry["id"]):
        console.print(f"[green]✓ Restored → {entry['original_path']}[/green]")
    else:
        console.print("[red]✗ Restore failed.[/red]")
        sys.exit(1)


@quarantine.command("delete")
@click.option("--id", "qid", required=True, help="Quarantine entry ID (or prefix)")
@click.confirmation_option(prompt="This will permanently destroy the file. Continue?")
def quarantine_delete(qid):
    """Permanently and securely delete a quarantined file."""
    qm = QuarantineManager()
    entries = [e for e in qm.list_quarantined() if e["id"].startswith(qid)]
    if not entries:
        console.print(f"[red]No quarantine entry matching '{qid}'.[/red]")
        sys.exit(1)
    if qm.delete_permanently(entries[0]["id"]):
        console.print(f"[green]✓ Permanently deleted.[/green]")
    else:
        console.print("[red]✗ Delete failed.[/red]")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# signature management
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command("add-sig")
@click.option("--hash", "file_hash", required=True, help="SHA-256 hash of the malicious file")
@click.option("--severity", default=5, show_default=True, type=click.IntRange(1, 10))
@click.option("--source", default="manual", show_default=True)
def add_sig(file_hash, severity, source):
    """Manually add a threat signature to the local database."""
    db = DatabaseManager()
    db.add_threat_signature(file_hash, severity=severity, source=source)
    console.print(f"[green]✓ Signature added:[/green] [cyan]{file_hash[:24]}…[/cyan] (severity={severity})")


@cli.command("export-sigs")
@click.option("--output", default=None,
              help=f"Output .lqsig path [default: {app_path('exports', 'sigs_export.lqsig')}]")
def export_sigs(output):
    """Export threat signatures to a signed binary file for offline transfer."""
    output = output or app_path("exports", "sigs_export.lqsig")
    sync = OfflineSync()
    if sync.export_signatures(output):
        console.print(f"[green]✓ Exported →[/green] {output}")
    else:
        console.print("[red]✗ Export failed.[/red]")
        sys.exit(1)


@cli.command("import-sigs")
@click.option("--input", "input_path", required=True)
@click.option("--no-verify", is_flag=True, default=False,
              help="Skip HMAC integrity check (not recommended)")
def import_sigs(input_path, no_verify):
    """Import threat signatures from a binary file and verify HMAC integrity."""
    sync = OfflineSync()
    if sync.import_signatures(input_path, verify=not no_verify):
        console.print(f"[green]✓ Signatures imported from {input_path}[/green]")
    else:
        console.print("[red]✗ Import failed (HMAC mismatch or bad file).[/red]")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# service  (auto-start)
# ═══════════════════════════════════════════════════════════════════════════════

@cli.group("service")
def service_group():
    """Install or remove the Leukquant monitor auto-start service."""


@service_group.command("install")
def service_install():
    """
    Register Leukquant as a persistent service that starts automatically
    after every reboot / logon.

    \b
    Linux   → systemd user unit (~/.config/systemd/user/leukquant.service)
               loginctl enable-linger is set so the unit survives logouts
               and starts at boot even without an interactive session.
    Windows → Task Scheduler task (Leukquant\\Monitor), triggered at logon.
    """
    with console.status("[bold yellow]Installing auto-start service…[/bold yellow]", spinner="dots"):
        ok, msg = install_service()
    if ok:
        console.print(f"[bold green]✓ Service installed.[/bold green]")
        for line in msg.splitlines():
            console.print(f"  [dim]{line}[/dim]")
    else:
        console.print(f"[bold red]✗ Installation failed.[/bold red]")
        for line in msg.splitlines():
            console.print(f"  [red]{line}[/red]")
        sys.exit(1)


@service_group.command("uninstall")
def service_uninstall():
    """Remove the auto-start service installed by 'leukquant service install'."""
    with console.status("[bold yellow]Removing auto-start service…[/bold yellow]", spinner="dots"):
        ok, msg = uninstall_service()
    if ok:
        console.print(f"[bold green]✓ Service removed.[/bold green]")
        console.print(f"  [dim]{msg}[/dim]")
    else:
        console.print(f"[bold red]✗ Removal failed.[/bold red]")
        console.print(f"  [red]{msg}[/red]")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# status dashboard
# ═══════════════════════════════════════════════════════════════════════════════

@cli.command("status")
def status():
    """Show a system health dashboard."""
    from src.crypto.key_manager import KeyManager

    db = DatabaseManager()
    km = KeyManager()
    pid_file = BehaviorProfiler.PID_FILE

    daemon_status = "[green]Running[/green]" if os.path.exists(pid_file) else "[dim]Stopped[/dim]"
    model_status = "[green]Present[/green]" if os.path.exists(app_path("models", "malware_detector.onnx")) else "[red]Missing[/red]"

    rows = [
        ("Signatures in DB",   str(db.signature_count())),
        ("Quarantined files",  str(db.quarantine_count())),
        ("Behavior samples",   str(db.metrics_count())),
        ("Monitor daemon",     daemon_status),
        ("Auto-start service", "[green]Installed[/green]" if service_installed() else "[dim]Not installed[/dim]"),
        ("AI model",           model_status),
        ("PQC available",      "[green]Yes[/green]" if km.is_pqc else "[yellow]No (classical fallback)[/yellow]"),
        ("Keys on disk",       ", ".join(km.list_keys()) or "[dim]none[/dim]"),
    ]

    table = Table(title="Leukquant — System Status", box=box.ROUNDED)
    table.add_column("Component", style="cyan")
    table.add_column("Status")
    for k, v in rows:
        table.add_row(k, v)
    console.print(table)


# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    cli()
