"""Overlord intelligence system for MUXI formations."""

from .overlord import Overlord

__all__ = ["Overlord"]
