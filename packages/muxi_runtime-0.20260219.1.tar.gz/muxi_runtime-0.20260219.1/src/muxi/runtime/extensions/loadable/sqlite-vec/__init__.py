"""SQLite-vec extension for MUXI runtime."""

__all__ = []
