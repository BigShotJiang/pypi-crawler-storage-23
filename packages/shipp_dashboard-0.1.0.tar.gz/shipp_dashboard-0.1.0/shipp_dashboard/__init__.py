"""
shipp-dashboard: Full-screen live sports scoreboard tracking NBA, MLB, and Soccer games.
"""
__version__ = "0.1.0"
