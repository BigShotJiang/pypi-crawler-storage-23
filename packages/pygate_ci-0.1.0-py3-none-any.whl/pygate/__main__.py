from pygate.cli import main

main()
