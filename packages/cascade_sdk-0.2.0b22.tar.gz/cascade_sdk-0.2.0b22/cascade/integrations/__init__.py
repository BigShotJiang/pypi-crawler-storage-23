"""
Cascade SDK - Agent Framework Integrations

Auto-instrument popular agent frameworks with one function call.
Each integration translates the framework's native events into
Cascade spans so traces appear in the dashboard automatically.

Usage::

    from cascade import init_tracing
    from cascade.integrations import instrument_langgraph

    init_tracing(project="my_app")
    instrument_langgraph()
    # ... existing framework code unchanged ...
"""

from cascade.integrations.langgraph import instrument_langgraph, setup_langgraph, CascadeLangChainHandler
from cascade.integrations.openai_agents import instrument_openai_agents
from cascade.integrations.claude_agents import (
    wrap_claude_query,
    TracedClaudeClient,
    instrument_claude_agents,
)
from cascade.integrations.pydantic_ai import (
    setup_pydantic_ai,
    instrument_agent,
)

__all__ = [
    # LangGraph / LangChain
    "setup_langgraph",
    "instrument_langgraph",
    "CascadeLangChainHandler",
    "instrument_openai_agents",
    # Claude Agent SDK (recommended)
    "wrap_claude_query",
    "TracedClaudeClient",
    # Claude Agent SDK (legacy)
    "instrument_claude_agents",
    # Pydantic AI
    "setup_pydantic_ai",
    "instrument_agent",
]
