"""
text-forge: Reusable build/publish pipeline for Markdown chapter collections.

Provides MkDocs plugin with Material theme overrides, live editor, and EPUB generation.
"""

__version__ = "0.1.0"
