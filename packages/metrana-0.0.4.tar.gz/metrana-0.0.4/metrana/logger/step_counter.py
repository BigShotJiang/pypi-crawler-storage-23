# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import threading

from metrana.utils.exceptions import MetranaMetricStepError

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class MetricStepCounter:

    def __init__(self) -> None:
        """
        Initialize the metric step counter.
        """

        self._lock = threading.Lock()

        self.steps: dict[str, int] = {}  # Track last step per series; missing key = never used
        self.manual_steps: set[str] = set()  # Track which series use manual steps

    def get_step(self, metric_name: str, scale: str, labels: dict[str, str], step: int | None = None) -> int:
        """
        Get the next step for a given metric, scale, and labels.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.
            labels: The labels of the metric.
            step: The step to use. If None, the next step will be used.

        Returns:
            The next step for the given metric, scale, and labels.

        Raises:
            MetranaMetricStepError: If a manual step is not strictly greater than
                the last step, or if manual and auto-increment steps are mixed for
                the same series.
        """

        with self._lock:
            key = f"{metric_name}:{scale}:{tuple(sorted(labels.items()))}"

            if step is not None:
                # Enforce monotonicity: step must be strictly greater than last step (if any)
                if key in self.steps and step <= self.steps[key]:
                    raise MetranaMetricStepError(
                        f"Steps must be monotonically increasing. Got step: {step} for metric: {metric_name}, "
                        f"scale: {scale}, labels: {labels}. Last step was: {self.steps[key]}"
                    )

                self.manual_steps.add(key)
                self.steps[key] = step

            else:
                if key in self.manual_steps:
                    raise MetranaMetricStepError(
                        f"Metric steps can either be manually set or automatically incremented. "
                        f"Got conflicting values for metric: {metric_name}."
                    )

                step = self.steps.get(key, 0)  # Default to 0 for new series
                self.steps[key] = step + 1

            return step
