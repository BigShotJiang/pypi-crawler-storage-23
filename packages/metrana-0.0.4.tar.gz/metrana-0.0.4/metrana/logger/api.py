# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

# threading.Lock is a factory function pre python3.13 so we can't type hint it with the class directly
# without hitting a TypeError at runtime. Importing annotations turns the type hint to a string so that
# the TypeError is circumvented.
from __future__ import annotations

import os
import threading
from typing import Any
from loguru import logger as loguru_logger

from metrana.logger.logger import MetranaLogger
from metrana.utils.enums import (
    BackpressureStrategy,
    CloseStrategy,
    ErrorStrategy,
    LogLevel,
    ResumeStrategy,
    StandardMetricScale,
)
from metrana.utils.exceptions import (
    MetranaNotInitializedError,
    MetranaAlreadyInitializedError,
    MetranaProcessForkError,
    NoMetranaApiKeyError,
)
from metrana.utils import env_vars
from metrana.utils import logging as metrana_logging

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

RL_EPISODE_LABEL = "episode"
RL_STEP_LABEL = "rl_step"
RL_ENV_ID_LABEL = "environment_id"

# ======================================================================================================================
#
# GLOBALS
#
# ======================================================================================================================

_metrana_logger: MetranaLogger | None = None
_metrana_pid: int | None = None
_metrana_lock: threading.Lock = threading.Lock()
_metrana_lock_pid: int = os.getpid()
_metrana_config: dict[str, Any] | None = None

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def _inject_label_if_absent(
    labels: dict[str, str],
    key: str,
    value: int | None,
    warn_message: str,
    warn_key: str | None = None,
) -> None:
    """
    Inject a label into labels if value is provided and key is not already present.
    If value is None and key is absent, emit a one-time warning deduplicated by warn_key.

    Args:
        labels: Label dict to mutate in place.
        key: Label key to inject under.
        value: Integer value to stringify and inject. If None, no label is added.
        warn_message: Warning message to emit when value is None and key is absent.
        warn_key: Deduplication key passed to warn_once. If None, warn_message is used as the key.
    """

    if value is not None:
        if key not in labels:
            labels[key] = str(value)
    else:
        if key not in labels:
            metrana_logging.warn_once(warn_message, key=warn_key)


def _ensure_lock() -> None:
    """Ensure the process-global lock is valid for this process, creating a new one if the process has forked."""

    global _metrana_lock, _metrana_lock_pid

    current_pid = os.getpid()
    if current_pid != _metrana_lock_pid:
        _metrana_lock = threading.Lock()
        _metrana_lock_pid = current_pid


def _build_logger(**kwargs) -> None:
    """Create and store a new MetranaLogger instance and record the current process ID."""

    global _metrana_logger, _metrana_pid

    _metrana_logger = MetranaLogger(**kwargs)
    _metrana_pid = os.getpid()


def _check_logger_initialized() -> None:
    """Raise MetranaNotInitializedError if the logger has not been initialized."""

    if _metrana_logger is None or _metrana_pid is None:
        raise MetranaNotInitializedError(
            "Metrana logger is not initialized. Please ensure that metrana.init(...) has been called "
            "before calling this function."
        )


def init(
    resume_strategy: ResumeStrategy | str | None = None,
    backpressure_strategy: BackpressureStrategy | str | None = None,
    error_strategy: ErrorStrategy | str | None = None,
    close_strategy: CloseStrategy | str | None = None,
    log_level: LogLevel | str | None = None,
    autoconfigure_loguru: bool = True,
    num_dispatch_workers: int = 4,
    event_queue_max_size: int | None = None,
    dispatch_queue_max_size: int | None = None,
    error_queue_max_size: int | None = None,
    batch_fill_initial_wait: float = 0.1,
    batch_fill_wait_decay: float = 0.5,
    batch_fill_max_waits: int = 3,
    api_key: str | None = None,
    **kwargs,
) -> None:
    """
    Initialize the Metrana logger. Must be called once before log() or close().

    Raises:
        MetranaAlreadyInitializedError: If the logger has already been initialized.

    Args:
        resume_strategy: How to handle existing runs: Never or Allow.
        backpressure_strategy: When the event queue is full: Block, DropNew, or Raise.
        error_strategy: How to handle dispatch errors: Silent, Warn, RaiseOnLog, or RaiseOnClose.
        close_strategy: How to shut down: Immediate, CompletePending, or CompleteAll.
            Can be overridden at close() and defaults to env if unset.
        log_level: Log level for internal loguru configuration when
            autoconfigure_loguru is True.
        autoconfigure_loguru: If True, configure loguru with the given log level.
        num_dispatch_workers: Number of async worker tasks that consume from
            the dispatch queue and send events.
        event_queue_max_size: Max size of the event queue (0 = unbounded).
        dispatch_queue_max_size: Max size of the dispatch queue (0 = unbounded).
        error_queue_max_size: Max size of the error queue (0 = unbounded).
        batch_fill_initial_wait: Initial wait in seconds when filling a batch and the queue
            is temporarily empty (decaying wait).
        batch_fill_wait_decay: Decay factor for each wait (e.g. 0.5 halves the wait each time).
        batch_fill_max_waits: Max number of wait cycles before sending a partial batch.
        api_key: API key for the Metrana API.
        **kwargs: Passed to MetranaLogger (e.g. workspace_name, project_name, run_name,
            ingestion_url, auth).
    """

    global _metrana_config

    _ensure_lock()

    with _metrana_lock:
        if any(variable is not None for variable in [_metrana_logger, _metrana_pid, _metrana_config]):
            raise MetranaAlreadyInitializedError("Metrana logger already initialized! Avoid repeated initialization.")

        api_key = api_key or env_vars.get_api_key()
        if api_key is None:
            raise NoMetranaApiKeyError(
                f"Metrana API key is not set. Please set the API key using the api_key parameter or "
                f"the {env_vars.METRANA_API_KEY} environment variable."
            )

        config = dict(
            resume_strategy=resume_strategy,
            backpressure_strategy=backpressure_strategy,
            error_strategy=error_strategy,
            close_strategy=close_strategy,
            log_level=log_level,
            autoconfigure_loguru=autoconfigure_loguru,
            num_dispatch_workers=num_dispatch_workers,
            event_queue_max_size=event_queue_max_size,
            dispatch_queue_max_size=dispatch_queue_max_size,
            error_queue_max_size=error_queue_max_size,
            batch_fill_initial_wait=batch_fill_initial_wait,
            batch_fill_wait_decay=batch_fill_wait_decay,
            batch_fill_max_waits=batch_fill_max_waits,
            api_key=api_key,
            **kwargs,
        )

        _build_logger(**config)
        _metrana_config = dict(config)


def log(
    metric_name: str,
    value: float | int,
    scale: str | None = None,
    step: int | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        scale: Scale descriptor; must be a StandardMetricScale member name or value
            (e.g. "MLStep", "ML_STEP"). If None, defaults to MLStep.
        step: Step index for this point. If None, the logger assigns the next step
            for this (metric_name, scale, labels) series.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    current_pid = os.getpid()
    logger = _metrana_logger
    stored_pid = _metrana_pid

    if logger is not None and stored_pid == current_pid:
        logger.log(
            metric_name=metric_name,
            value=value,
            scale=scale,
            step=step,
            labels=labels,
            timestamp=timestamp,
        )
        return

    _ensure_lock()

    with _metrana_lock:
        _check_logger_initialized()
        current_pid = os.getpid()

        if _metrana_pid is not None and current_pid != _metrana_pid:
            loguru_logger.debug(
                f"Process fork detected (old pid: {_metrana_pid}, new pid: {current_pid}). "
                f"Rebuilding logger for new process."
            )

            if _metrana_config is None:
                raise MetranaProcessForkError(
                    "Metrana config is not set. Cannot rebuild logger for new process. This should "
                    "be unreachable. Please report this as a bug."
                )

            if _metrana_logger is not None:
                _metrana_logger.kill(timeout=kill_timeout)

            _build_logger(**_metrana_config)

        _metrana_logger.log(
            metric_name=metric_name,
            value=value,
            scale=scale,
            step=step,
            labels=labels,
            timestamp=timestamp,
        )


def close(close_strategy: CloseStrategy | str | None = None, close_timeout: float = 15.0) -> None:
    """
    Close the logger and clear internal state.

    After calling close(), init() may be called again to create a new logger instance.

    Args:
        close_strategy: Close strategy to use.
        close_timeout: Timeout in seconds for the logger to stop.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
    """

    global _metrana_logger, _metrana_pid, _metrana_config

    _ensure_lock()

    with _metrana_lock:
        _check_logger_initialized()

        try:
            _metrana_logger.close(strategy=close_strategy, timeout=close_timeout)
        finally:
            # Always clear state even if close() raises (e.g., RaiseOnClose with errors)
            _metrana_logger = None
            _metrana_pid = None
            _metrana_config = None


def log_rl_step(
    metric_name: str,
    value: float | int,
    step: int | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        step: Step index for this point. If None, the logger assigns the next step
            for this (metric_name, scale, labels) series.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    log(
        metric_name=metric_name,
        value=value,
        scale=StandardMetricScale.ML_STEP.value,
        step=step,
        labels=labels,
        timestamp=timestamp,
        kill_timeout=kill_timeout,
    )


def log_rl_episode(
    metric_name: str,
    value: float | int,
    episode: int | None = None,
    rl_step: int | None = None,
    env_id: int | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event on the EPISODE scale.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        episode: Episode index used as the step for this series. If None, the logger
            assigns the next step automatically.
        rl_step: RL training step to record as a label. If not None and not already
            present in labels, added under the RL_STEP_LABEL key. If None and not
            present in labels, a one-time warning is emitted.
        env_id: Environment ID to record as a label. If not None and not already present
            in labels, added under the RL_ENV_ID_LABEL key. If None and not present in
            labels, a one-time warning is emitted.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    effective_labels = dict(labels) if labels is not None else {}

    _inject_label_if_absent(
        labels=effective_labels,
        key=RL_STEP_LABEL,
        value=rl_step,
        warn_message=(
            f"log_rl_episode called without rl_step and '{RL_STEP_LABEL}' not in labels. "
            "The rl_step will not be recorded for this series."
        ),
        warn_key="log_rl_episode_no_rl_step",
    )
    _inject_label_if_absent(
        labels=effective_labels,
        key=RL_ENV_ID_LABEL,
        value=env_id,
        warn_message=(
            f"log_rl_episode called without env_id and '{RL_ENV_ID_LABEL}' not in labels. "
            "The environment_id will not be recorded for this series."
        ),
        warn_key="log_rl_episode_no_env_id",
    )

    log(
        metric_name=metric_name,
        value=value,
        scale=StandardMetricScale.EPISODE.value,
        step=episode,
        labels=effective_labels,
        timestamp=timestamp,
        kill_timeout=kill_timeout,
    )


def log_rl_environment_step(
    metric_name: str,
    value: float | int,
    env_step: int | None = None,
    episode: int | None = None,
    rl_step: int | None = None,
    env_id: int | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event on the ENVIRONMENT_STEP scale.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        env_step: Environment step index used as the step for this series. If None, the
            logger assigns the next step automatically.
        episode: Episode index to record as a label. If not None and not already present
            in labels, added under the RL_EPISODE_LABEL key. If None and not present in
            labels, a one-time warning is emitted.
        rl_step: RL training step to record as a label. If not None and not already
            present in labels, added under the RL_STEP_LABEL key. If None and not
            present in labels, a one-time warning is emitted.
        env_id: Environment ID to record as a label. If not None and not already present
            in labels, added under the RL_ENV_ID_LABEL key. If None and not present in
            labels, a one-time warning is emitted.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    effective_labels = dict(labels) if labels is not None else {}

    _inject_label_if_absent(
        labels=effective_labels,
        key=RL_EPISODE_LABEL,
        value=episode,
        warn_message=(
            f"log_rl_environment_step called without episode and '{RL_EPISODE_LABEL}' not in labels. "
            "The episode will not be recorded for this series."
        ),
        warn_key="log_rl_env_step_no_rl_episode",
    )
    _inject_label_if_absent(
        labels=effective_labels,
        key=RL_STEP_LABEL,
        value=rl_step,
        warn_message=(
            f"log_rl_environment_step called without rl_step and '{RL_STEP_LABEL}' not in labels. "
            "The rl_step will not be recorded for this series."
        ),
        warn_key="log_rl_env_step_no_rl_step",
    )
    _inject_label_if_absent(
        labels=effective_labels,
        key=RL_ENV_ID_LABEL,
        value=env_id,
        warn_message=(
            f"log_rl_environment_step called without env_id and '{RL_ENV_ID_LABEL}' not in labels. "
            "The environment_id will not be recorded for this series."
        ),
        warn_key="log_rl_env_step_no_env_id",
    )

    log(
        metric_name=metric_name,
        value=value,
        scale=StandardMetricScale.ENVIRONMENT_STEP.value,
        step=env_step,
        labels=effective_labels,
        timestamp=timestamp,
        kill_timeout=kill_timeout,
    )
