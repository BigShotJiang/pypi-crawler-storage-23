# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import hashlib
import asyncio
import queue
import aiohttp
from google.protobuf import json_format

from loguru import logger
from metrana.logger.request_builder import build_v1_update_runs_request
from metrana.utils.metric_event import MetricEvent
from metrana.utils.exceptions import (
    UnrecognizedMetranaErrorStrategyError,
    MetranaErrorQueueFullError,
    MetranaUnregisteredMetricError,
)
from metrana.utils.enums import ErrorStrategy
from metrana.utils import logging

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class Dispatcher:

    _SHUTDOWN_SENTINEL = object()

    UPDATE_RUNS_ENDPOINT = "/runs:update"

    # TODO: Get this from the API so users cannot send unreasonably large batches.
    MAX_BATCH_EVENT_COUNT = 10_000  # Max metric events per batch

    def __init__(
        self,
        session_id: int,
        workspace_name: str,
        project_name: str,
        run_name: str,
        aiohttp_session: aiohttp.ClientSession,
        error_queue: queue.Queue,
        error_strategy: ErrorStrategy,
        ingestion_url: str,
        max_send_retries: int,
        send_retry_initial_delay: float,
        send_retry_max_delay: float,
        send_retry_backoff_factor: float,
        batch_fill_initial_wait: float,
        batch_fill_wait_decay: float,
        batch_fill_max_waits: int,
        max_queue_size: int,
    ) -> None:
        """
        Initialize the dispatcher.

        Each dispatcher owns a single asyncio queue and a registry of series
        (metric_name, scale) hashes. The router assigns series to dispatchers
        so that all events for a given series are always sent through the same
        dispatcher, preserving per-series ordering.

        Args:
            session_id: Session ID used by the backend to loosely identify producers. This does not
            relate to authn or authz.
            workspace_name: The name of the workspace for this run.
            project_name: The name of the project for this run.
            run_name: The name of the run.
            aiohttp_session: Shared aiohttp session for making API calls.
            error_queue: Shared queue for surfacing dispatch errors to the logger.
            error_strategy: How to handle dispatch errors: Silent, Warn, RaiseOnLog,
                or RaiseOnClose.
            ingestion_url: Fully formatted base URL for the ingestion API.
            max_send_retries: Maximum number of send attempts for a failed API call
                (includes the initial attempt).
            send_retry_initial_delay: Initial delay in seconds before the first retry.
            send_retry_max_delay: Maximum delay in seconds between retries.
            send_retry_backoff_factor: Multiplier applied to the delay after each retry.
            batch_fill_initial_wait: Initial wait in seconds when the batch is not full
                and the queue is temporarily empty; used for decaying wait to coalesce
                more events.
            batch_fill_wait_decay: Multiplier applied to the wait after each empty check
                (e.g. 0.5 halves the wait each time).
            batch_fill_max_waits: Maximum number of wait cycles before sending a partial
                batch.
            max_queue_size: Maximum size of this dispatcher's internal queue (0 = unbounded).
        """

        self._queue: asyncio.Queue[MetricEvent | object] = asyncio.Queue(maxsize=max_queue_size)
        self._registry: set[str] = set()

        self._complete_pending_event = asyncio.Event()
        self._complete_all_event = asyncio.Event()

        self._aiohttp_session = aiohttp_session
        self._error_queue = error_queue
        self.error_strategy = error_strategy

        self.session_id = session_id
        self.workspace_name = workspace_name
        self.project_name = project_name
        self.run_name = run_name
        self.ingestion_url = ingestion_url

        self.max_send_retries = max_send_retries
        self.send_retry_initial_delay = send_retry_initial_delay
        self.send_retry_max_delay = send_retry_max_delay
        self.send_retry_backoff_factor = send_retry_backoff_factor

        self.batch_fill_initial_wait = batch_fill_initial_wait
        self.batch_fill_wait_decay = batch_fill_wait_decay
        self.batch_fill_max_waits = batch_fill_max_waits

    @staticmethod
    def _calculate_hash(
        metric_name: str,
        scale: str,
    ) -> str:
        """
        Calculate the SHA-256 hash of the given metric name and scale.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.

        Returns:
            Hex digest of the SHA-256 hash.
        """

        key = f"{metric_name}:{scale}"
        return hashlib.sha256(key.encode()).hexdigest()

    async def _fill_batch_from_queue(
        self,
        initial: list[MetricEvent] | None = None,
        use_decaying_wait: bool = True,
    ) -> list[MetricEvent]:
        """
        Drain available events from the queue into a single batch using get_nowait.
        When the queue is temporarily empty and the batch is not full, may wait with a
        decaying delay (if use_decaying_wait) to coalesce more events before sending.
        Stops when the queue is empty (after any waits), the batch reaches
        MAX_BATCH_EVENT_COUNT, or the shutdown sentinel is seen.

        Args:
            initial: Optional list of events to seed the batch with.
            use_decaying_wait: If True, wait with a decaying delay when the queue is
                temporarily empty to coalesce more events before sending.

        Returns:
            The batch of metric events (may be partial or full).
        """

        batch: list[MetricEvent] = initial if initial else []

        wait_time = self.batch_fill_initial_wait
        waits_left = self.batch_fill_max_waits if use_decaying_wait else 0

        while len(batch) < self.MAX_BATCH_EVENT_COUNT:
            try:
                item = self._queue.get_nowait()

            except asyncio.QueueEmpty:
                if waits_left <= 0 or not batch:
                    return batch

                await asyncio.sleep(wait_time)
                waits_left -= 1
                wait_time *= self.batch_fill_wait_decay
                continue

            if item is self._SHUTDOWN_SENTINEL:
                self._queue.put_nowait(self._SHUTDOWN_SENTINEL)
                return batch

            batch.append(item)

        return batch

    async def _make_api_call(self, batch: list[MetricEvent]) -> None:
        """
        Build and POST an UpdateRunsRequest to the ingestion API with exponential
        backoff retries.

        Args:
            batch: List of MetricEvent objects to send.

        Raises:
            Exception: Re-raises the last exception after max_send_retries is exhausted.
        """

        logger.debug(f"Sending batch of {len(batch)} events to {self.UPDATE_RUNS_ENDPOINT}.")

        request = build_v1_update_runs_request(
            batch=batch,
            session_id=self.session_id,
            workspace_name=self.workspace_name,
            project_name=self.project_name,
            run_name=self.run_name,
        )
        payload = json_format.MessageToDict(request)
        url = self.ingestion_url + self.UPDATE_RUNS_ENDPOINT

        retries = 0

        while retries < self.max_send_retries:
            try:
                async with self._aiohttp_session.post(url, json=payload) as response:
                    if 200 <= response.status < 300:
                        # Nothing done with response right now.
                        break

                    # For any non-2xx response, raise to trigger retry
                    # TODO: Handle other error codes properly.
                    response.raise_for_status()

            except Exception as e:
                retries += 1

                if retries >= self.max_send_retries:
                    raise e

                delay = self.send_retry_initial_delay * (self.send_retry_backoff_factor**retries)
                delay = min(delay, self.send_retry_max_delay)

                await asyncio.sleep(delay)

    def _should_exit(self) -> bool:
        """
        Return True if the dispatcher should exit (shutdown requested and,
        for CompleteAll, queue empty).

        Returns:
            True if the dispatcher should break its run loop.
        """

        if self._complete_pending_event.is_set():
            return True

        if self._complete_all_event.is_set():
            queues_empty = self._queue.empty()

            if queues_empty:
                return True

        return False

    async def run(self) -> None:
        """
        Main loop: wait for an event, greedily batch via _fill_batch_from_queue,
        then dispatch the batch to the ingestion API. Exits on shutdown sentinel
        or flag.
        """

        logger.debug("Dispatcher task started.")

        while True:
            should_break = self._should_exit()
            if should_break:
                break

            try:
                first_event = await self._queue.get()
                if first_event is self._SHUTDOWN_SENTINEL:
                    break

                batch = await self._fill_batch_from_queue(initial=[first_event], use_decaying_wait=True)
                await self._make_api_call(batch=batch)

            except asyncio.CancelledError:
                break

            # TODO: Make this more specific rather than catching everything.
            # TODO: Re-queue failed batch events or spool to disk so data is not silently lost.
            except Exception as e:
                if self.error_strategy is ErrorStrategy.Silent:
                    logger.trace(f"Error dispatching batch: {e}")

                elif self.error_strategy is ErrorStrategy.Warn:
                    logging.warn_once(
                        f"Error dispatching batch: {e}", key=f"error_dispatching_batch_{type(e).__name__}"
                    )

                elif self.error_strategy in [ErrorStrategy.RaiseOnLog, ErrorStrategy.RaiseOnClose]:
                    try:
                        self._error_queue.put_nowait(e)
                    except queue.Full as qf:
                        raise MetranaErrorQueueFullError(
                            "Error queue is full. Cannot add new error and error strategy is Raise. Exiting..."
                        ) from qf

                else:
                    raise UnrecognizedMetranaErrorStrategyError(
                        f"Unrecognized error strategy: {self.error_strategy}. "
                        f"This should be unreachable, please report this as a bug."
                    ) from e

        logger.trace("Dispatcher has broken loop. Exiting coroutine.")

    async def enqueue(self, metric_event: MetricEvent) -> None:
        """
        Put a metric event into this dispatcher's queue.

        Verifies the event's series is registered to this dispatcher before enqueuing.

        Args:
            metric_event: The metric event to enqueue.

        Raises:
            MetranaUnregisteredMetricError: If the event's series is not registered
                with this dispatcher.

        Known Issue: If the queue fills up, the router will hang and all dispatchers
            will not get new points until this put succeeds.
        """

        if not self.has_series(metric_event.metric_name, metric_event.scale):
            raise MetranaUnregisteredMetricError(
                f"Metric '{metric_event.metric_name}' with scale '{metric_event.scale}' "
                f"is not registered with this dispatcher."
            )

        await self._queue.put(metric_event)

    def enqueue_nowait(self, metric_event: MetricEvent) -> None:
        """
        Non-blocking put of a metric event into this dispatcher's queue.

        Does not verify series registration — the caller is responsible for
        ensuring the event belongs to this dispatcher.

        Args:
            metric_event: The metric event to enqueue.

        Raises:
            asyncio.QueueFull: If the queue is full.
        """

        self._queue.put_nowait(metric_event)

    def add_sentinel(self) -> None:
        """
        Best-effort put of the shutdown sentinel into this dispatcher's queue.

        Uses put_nowait so the caller never blocks on a full queue. This is
        safe because the sentinel is only needed to wake a dispatcher blocked
        on an empty get(); in that case the queue is empty and put_nowait
        always succeeds. When the queue is full, the dispatcher is actively
        processing and will exit via _should_exit instead.
        """

        try:
            self._queue.put_nowait(self._SHUTDOWN_SENTINEL)
        except asyncio.QueueFull:
            pass

    def set_complete_pending(self) -> None:
        """
        Signal this dispatcher to exit after completing its current batch.
        """

        self._complete_pending_event.set()

    def set_complete_all(self) -> None:
        """
        Signal this dispatcher to drain its queue fully before exiting.
        """

        self._complete_all_event.set()

    def register(
        self,
        metric_name: str,
        scale: str,
    ) -> None:
        """
        Register a series with this dispatcher.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.
        """

        series_hash = self._calculate_hash(metric_name, scale)
        self._registry.add(series_hash)

    def has_series(self, metric_name: str, scale: str) -> bool:
        """
        Check whether a series is registered with this dispatcher.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.

        Returns:
            True if the series hash is in this dispatcher's registry.
        """

        series_hash = self._calculate_hash(metric_name, scale)
        return series_hash in self._registry
