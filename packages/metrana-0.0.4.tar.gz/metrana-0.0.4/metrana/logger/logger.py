# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import secrets
import asyncio
import http
import threading
import queue
import aiohttp
import requests
from google.protobuf import json_format

from loguru import logger
from metrana_protobuf.ingestion.v1.svc import api_pb2
from metrana_protobuf.ingestion.v1.types import run_definition_pb2

from metrana.logger.dispatcher import Dispatcher
from metrana.logger.step_counter import MetricStepCounter
from metrana.utils.metric_event import MetricEvent
from metrana.utils.exceptions import (
    MetranaEventQueueFullError,
    MetranaLoggerClosedError,
    MetranaRunAlreadyExistsError,
    UnrecognizedMetranaBackpressureStrategyError,
    MetranaErrorQueueFullError,
)
from metrana.utils.enums import (
    BackpressureStrategy,
    CloseStrategy,
    ErrorStrategy,
    LogLevel,
    ResumeStrategy,
    StandardMetricScale,
)
from metrana.utils import env_vars, logging, git_utils

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class MetranaLogger:
    """
    Background metric logger that runs an asyncio event loop in a dedicated thread.

    Accepts events via log(), routes them through per-series dispatchers, and
    supports configurable shutdown behaviour (immediate, complete pending, or
    complete all). Safe to use from multiple threads and after process fork
    when used via the metrana api (kill() clears state so a new logger can be
    created in the child).

    Events are routed by the router task to dispatchers based on their series
    key (metric_name, scale). Each dispatcher owns a queue and batches events
    before sending them to the ingestion API, ensuring per-series ordering.

    Remaining ToDos:
      - Getting short-lived JWTs using the API key and refreshes for it.
      - More specific error handling
      - Tests: Unit, Smoke, Component, Integration
      - Exponential backoff for API calls and run creation
      - BUGFIX: Handle multiple processes and distributed training with resume strategy
        is Never.
      - Handle dispatch errors more specifically rather than blindly retrying.
      - File spooling to save events to disk in case of long outage to our API.
      - Add jitter to exponential backoff to space out calls to the API in
        the event of a long outage.
      - Grab git commit hash if possible
      - Grab system metrics like CPU, memory, disk, network, etc. if possible
      - Save config if possible
      - Grab env vars in a whitelist of specific env vars if possible

    Possible future features:
      - Allow for multiprocessed batching via ProcessPoolExecutor
      - Allow for multiple runs to be run at the same time
    """

    _SHUTDOWN_SENTINEL = object()
    _DRAIN_ENQUEUE_TIMEOUT = 5.0  # Timeout for enqueuing events during shutdown drain

    DEFAULT_URL = "https://development.ingestion.api.metrana.ai"

    CREATE_RUN_ENDPOINT = "/runs"

    AUTHORIZATION_HEADER = "Authorization"

    def __init__(
        self,
        api_key: str,
        workspace_name: str,
        project_name: str,
        run_name: str,
        experiment_name: str | None = None,
        api_version: str = "v1",
        ingestion_url: str | None = None,
        resume_strategy: ResumeStrategy | str | None = None,
        backpressure_strategy: BackpressureStrategy | str | None = None,
        error_strategy: ErrorStrategy | str | None = None,
        close_strategy: CloseStrategy | str | None = None,
        log_level: LogLevel | str | None = None,
        autoconfigure_loguru: bool = True,
        create_project_if_missing: bool = True,
        num_dispatch_workers: int = 4,
        event_queue_max_size: int | None = None,
        dispatch_queue_max_size: int | None = None,
        error_queue_max_size: int | None = None,
        max_event_queue_timeout: float = 60.0,
        max_send_retries: int = 15,
        send_retry_initial_delay: float = 0.1,
        send_retry_max_delay: float = 30.0,
        send_retry_backoff_factor: float = 1.5,
        batch_fill_initial_wait: float = 0.1,
        batch_fill_wait_decay: float = 0.5,
        batch_fill_max_waits: int = 3,
    ) -> None:
        """
        Initialize the logger and start the background loop thread.

        Args:
            api_key: The API key to use for authentication.

            workspace_name: The name of the workspace to use.
            project_name: The name of the project to use.
            run_name: The name of the run to use.
            experiment_name: The name of the experiment to use.

            api_version: The version of the API to use.
            ingestion_url: The URL of the ingestion API to use.

            resume_strategy: How to handle existing runs: Never or Allow.
            backpressure_strategy: When the event queue is full: Block, DropNew, or Raise.
            error_strategy: How to handle dispatch errors: Silent, Warn, RaiseOnLog, or RaiseOnClose.
            close_strategy: How to shut down: Immediate, CompletePending, or CompleteAll.
                Can be overridden at close() and defaults to env if unset.
            log_level: Log level for internal loguru configuration when
                autoconfigure_loguru is True.

            autoconfigure_loguru: If True, configure loguru with the given log level.
            create_project_if_missing: If True, create the project if it does not exist.
            num_dispatch_workers: Number of async worker tasks that consume from
                the dispatch queue and send events.
            event_queue_max_size: Max size of the event queue (0 = unbounded).
            dispatch_queue_max_size: Max size of the dispatch queue (0 = unbounded).
            error_queue_max_size: Max size of the error queue (0 = unbounded).
            max_event_queue_timeout: Maximum timeout in seconds for putting events into the event queue.
            max_send_retries: Maximum number of send attempts for a failed API call
                (includes the initial attempt).
            send_retry_initial_delay: Initial delay in seconds before the first retry.
            send_retry_max_delay: Maximum delay in seconds between retries.
            send_retry_backoff_factor: Multiplier applied to the delay after each retry.
            batch_fill_initial_wait: Initial wait in seconds when the batch is not full and the queue
                is temporarily empty; used for decaying wait to coalesce more events.
            batch_fill_wait_decay: Multiplier applied to the wait after each empty check (e.g. 0.5
                halves the wait each time).
            batch_fill_max_waits: Maximum number of wait cycles before sending a partial batch.
        """

        event_max = event_queue_max_size if event_queue_max_size is not None else env_vars.get_event_queue_max_size()
        dispatch_max = (
            dispatch_queue_max_size if dispatch_queue_max_size is not None else env_vars.get_dispatch_queue_max_size()
        )
        error_max = error_queue_max_size if error_queue_max_size is not None else env_vars.get_error_queue_max_size()

        self._event_queue: queue.Queue | None = queue.Queue(maxsize=event_max)
        self._error_queue: queue.Queue | None = queue.Queue(maxsize=error_max)

        self._loop: asyncio.AbstractEventLoop | None = None
        self._shutdown_event: asyncio.Event | None = None
        self._aiohttp_session: aiohttp.ClientSession | None = None

        self._metric_step_counter = MetricStepCounter()
        self._loop_thread: threading.Thread | None = threading.Thread(target=self._thread_entry, daemon=False)
        self._dispatchers: list[Dispatcher] = []

        self._accept_new_events = True
        self._session_id = secrets.randbits(64)

        resume_strategy = resume_strategy or env_vars.get_resume_strategy()
        self.resume_strategy = ResumeStrategy(resume_strategy)

        backpressure_strategy = backpressure_strategy or env_vars.get_backpressure_strategy()
        self.backpressure_strategy = BackpressureStrategy(backpressure_strategy)

        error_strategy = error_strategy or env_vars.get_error_strategy()
        self.error_strategy = ErrorStrategy(error_strategy)

        close_strategy = close_strategy or env_vars.get_close_strategy()
        self.close_strategy = CloseStrategy(close_strategy)

        self.num_dispatch_workers = num_dispatch_workers
        self.max_dispatch_queue_size = dispatch_max

        self.max_event_queue_timeout = max_event_queue_timeout
        self.create_project_if_missing = create_project_if_missing

        self.max_send_retries = max_send_retries
        self.send_retry_initial_delay = send_retry_initial_delay
        self.send_retry_max_delay = send_retry_max_delay
        self.send_retry_backoff_factor = send_retry_backoff_factor

        self.batch_fill_initial_wait = batch_fill_initial_wait
        self.batch_fill_wait_decay = batch_fill_wait_decay
        self.batch_fill_max_waits = batch_fill_max_waits

        self.api_key = api_key
        self.workspace_name = workspace_name
        self.project_name = project_name
        self.run_name = run_name
        self.experiment_name = experiment_name

        self.ingestion_url = self._format_ingestion_url(
            ingestion_url=ingestion_url or self.DEFAULT_URL,
            api_version=api_version,
        )

        if autoconfigure_loguru:
            logging.configure_logging(log_level)

        self._create_run()
        self._loop_thread.start()

        logger.info(f"Metrana logger initialized for {self.run_path} " f"with {self.num_dispatch_workers} workers.")

    @property
    def run_path(self) -> str:
        """
        Formatted run path: workspace/project/run_name.
        """

        return f"{self.workspace_name}/{self.project_name}/{self.run_name}"

    @staticmethod
    def _format_ingestion_url(ingestion_url: str, api_version: str) -> str:
        """
        Format the ingestion URL by joining the base URL with the API version.

        Args:
            ingestion_url: Base URL of the ingestion API.
            api_version: API version path segment (e.g. "v1").

        Returns:
            Fully formatted ingestion URL.
        """

        if not ingestion_url.endswith("/"):
            ingestion_url += "/"

        if api_version.startswith("/"):
            api_version = api_version[1:]

        if api_version.endswith("/"):
            api_version = api_version[:-1]

        return ingestion_url + api_version

    async def _route_event(self, event: MetricEvent, next_dispatcher_idx: int) -> int:
        """
        Route a single metric event to its assigned dispatcher, or assign it to
        the next dispatcher in round-robin order if the series is not yet registered.

        Respects the configured backpressure strategy when the target dispatcher's
        queue is full: Block waits for space, DropNew drops the event with a warning,
        and Raise puts an error into the error queue.

        Args:
            event: The metric event to route.
            next_dispatcher_idx: Current round-robin index for new series assignment.

        Returns:
            Updated round-robin index (incremented if a new assignment was made).
        """

        target_dispatcher, next_dispatcher_idx = self._find_or_assign_dispatcher(
            event.metric_name, event.scale, next_dispatcher_idx
        )

        try:
            if self.backpressure_strategy is BackpressureStrategy.Block:
                await target_dispatcher.enqueue(event)
            else:
                target_dispatcher.enqueue_nowait(event)

        except asyncio.QueueFull:
            if self.backpressure_strategy is BackpressureStrategy.DropNew:
                logging.warn_once(
                    f"Dispatch queue is full. Dropping event for metric: {event.metric_name}.",
                    key="dispatch_queue_full",
                )
                logger.trace(f"Dispatch queue is full. Dropping event for metric: {event.metric_name}.")

            elif self.backpressure_strategy is BackpressureStrategy.Raise:
                try:
                    self._error_queue.put_nowait(
                        MetranaEventQueueFullError(
                            "Dispatch queue is full. Cannot route event and backpressure strategy is Raise."
                        )
                    )
                except queue.Full as qf:
                    raise MetranaErrorQueueFullError("Error queue is full. Cannot add new error. Exiting...") from qf

            else:
                raise UnrecognizedMetranaBackpressureStrategyError(
                    f"Unrecognized backpressure strategy: {self.backpressure_strategy}. "
                    f"This should be unreachable, please report this as a bug."
                )

        return next_dispatcher_idx

    async def _drain_and_route(self, next_dispatcher_idx: int) -> int:
        """
        Drain remaining events from the event queue and route them to dispatchers.
        Called during CompleteAll shutdown after receiving the sentinel. Always uses
        blocking puts to ensure all events are delivered.

        Args:
            next_dispatcher_idx: Current round-robin index for new series assignment.

        Returns:
            Updated round-robin index.
        """

        if self._event_queue is None:
            return next_dispatcher_idx

        logger.trace("Draining event queue for shutdown.")

        while True:
            try:
                event = self._event_queue.get_nowait()
            except queue.Empty:
                break

            if event is self._SHUTDOWN_SENTINEL:
                break

            target_dispatcher, next_dispatcher_idx = self._find_or_assign_dispatcher(
                event.metric_name, event.scale, next_dispatcher_idx
            )

            try:
                await asyncio.wait_for(target_dispatcher.enqueue(event), timeout=self._DRAIN_ENQUEUE_TIMEOUT)
            except asyncio.TimeoutError:
                logging.warn_once(
                    "Timed out enqueuing event during shutdown drain. Event dropped.",
                    key="drain_enqueue_timeout",
                )

        return next_dispatcher_idx

    async def _router(self) -> None:
        """
        Consume events from the event queue and route them to the appropriate
        dispatcher. New series are assigned to dispatchers in round-robin order;
        once assigned, all events for a given series always go to the same
        dispatcher, preserving per-series ordering.

        On shutdown sentinel, behaviour depends on the close strategy:
          - CompletePending: exits immediately (dispatch sentinels are already
            sent by _wake_tasks).
          - CompleteAll: drains remaining events from the event queue, routes
            them, then sends dispatch sentinels so dispatchers process everything
            before exiting.
          - Immediate: the task is cancelled by _async_main().
        """

        logger.debug("Router task started.")

        next_dispatcher_idx = 0

        while True:
            try:
                event = await self._loop.run_in_executor(None, self._event_queue.get)
            except asyncio.CancelledError:
                break

            if event is self._SHUTDOWN_SENTINEL:
                if self.close_strategy is CloseStrategy.CompleteAll:
                    next_dispatcher_idx = await self._drain_and_route(next_dispatcher_idx)
                    self._put_dispatch_sentinels()
                break

            next_dispatcher_idx = await self._route_event(event, next_dispatcher_idx)

        logger.trace("Router has broken loop. Exiting coroutine.")

    async def _async_main(self) -> None:
        """
        Main async entry: start router and dispatchers, wait for shutdown, then
        apply close strategy and wait for tasks.
        """

        # Need to implement getting short-lived JWTs using the API key
        # and refreshes for it. For MVP, just using API key with each
        # request.
        headers = self._get_authorization_header()
        self._aiohttp_session = aiohttp.ClientSession(headers=headers)

        try:
            tasks: list[asyncio.Task] = []

            for _ in range(self.num_dispatch_workers):
                dispatcher = self._create_dispatcher()
                task = asyncio.create_task(dispatcher.run())
                tasks.append(task)

            task = asyncio.create_task(self._router())
            tasks.append(task)

            await self._shutdown_event.wait()

            self._accept_new_events = False

            if self.close_strategy is CloseStrategy.Immediate:
                logger.trace("Closing logger with immediate strategy. Cancelling tasks.")
                self._put_event_queue_sentinel()
                for task in tasks:
                    task.cancel()

            elif self.close_strategy is CloseStrategy.CompletePending:
                logger.trace("Closing logger with complete pending strategy. Setting complete pending event.")
                for dispatcher in self._dispatchers:
                    dispatcher.set_complete_pending()
                self._wake_tasks()

            elif self.close_strategy is CloseStrategy.CompleteAll:
                logger.trace("Closing logger with complete all strategy. Setting complete all event.")
                for dispatcher in self._dispatchers:
                    dispatcher.set_complete_all()
                self._wake_tasks(include_dispatch_sentinels=False)

            logger.trace("Waiting for metrana tasks to complete.")
            await asyncio.gather(*tasks, return_exceptions=True)
            logger.trace("Metrana tasks completed. Closing logger.")

        finally:
            await self._aiohttp_session.close()

    def _get_authorization_header(self) -> dict[str, str]:
        """
        Get the authorization header for the API key.

        Returns:
            The authorization header.
        """

        return {self.AUTHORIZATION_HEADER: f"Bearer {self.api_key}"}

    def _validate(self) -> None:
        """
        Raise MetranaLoggerClosedError if the logger has been closed or the loop thread is dead.

        Raises:
            MetranaLoggerClosedError: If queues are None or the loop thread is not alive.
        """

        queues_dead = self._event_queue is None or self._error_queue is None
        loop_dead = self._loop_thread is None or not self._loop_thread.is_alive()

        if queues_dead or loop_dead:
            raise MetranaLoggerClosedError(
                "Logger has been closed. You must call metrana.init(...) again to create a new logger instance."
            )

    def _create_run(self) -> None:
        """
        Create the run in the ingestion API. Handles 409 (already exists) based
        on the configured resume strategy.

        Raises:
            MetranaRunAlreadyExistsError: If the run already exists and resume
                strategy is Never.
            requests.HTTPError: If the API returns an unexpected non-2xx status.
        """

        git_commit_sha = git_utils.get_git_sha()
        logger.trace(f"On git commit {git_commit_sha}")  # Temporary to satisfy linters.

        run = run_definition_pb2.Run(
            workspace=self.workspace_name,
            project=self.project_name,
            run_name=self.run_name,
            # git_commit_sha=git_commit_sha - Not added yet. Not sure if this should be in PostGres
            # or stored in a file or something alongside the config when we end up capturing that.
            # The git sha may change when a run is resumed so we'd want to track all the SHAs used.
        )
        if self.experiment_name is not None:
            run.experiment = self.experiment_name

        request = api_pb2.CreateRunRequest(
            run=run,
            create_project_if_missing=self.create_project_if_missing,
        )
        payload = json_format.MessageToDict(request)

        response = requests.post(
            self.ingestion_url + self.CREATE_RUN_ENDPOINT,
            headers=self._get_authorization_header(),
            json=payload,
        )

        # Need to handle other error codes properly.
        if response.status_code == http.HTTPStatus.OK:
            logger.info(f"Created new run: {self.run_path}.")

        elif response.status_code == http.HTTPStatus.CONFLICT:
            # This will fail in multiple processes and distributed training as is. One worker will succeed and
            # all others will fail. Should return run age in the 409 and if the run is younger than X seconds,
            # allow the resume, otherwise raise the error.
            if self.resume_strategy is ResumeStrategy.Never:
                raise MetranaRunAlreadyExistsError(f"Resume strategy is Never and run already exists: {self.run_path}")

            logger.info(f"Resumed existing run: {self.run_path}.")

        else:
            response.raise_for_status()

    def _thread_entry(self) -> None:
        """
        Thread entry point: create the event loop, run the main async coroutine, then clean up.
        """

        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        self._shutdown_event = asyncio.Event()

        try:
            self._loop.run_until_complete(self._async_main())
        finally:
            self._loop.close()

            self._loop = None
            self._shutdown_event = None

    def _put_event_queue_sentinel(self) -> None:
        """
        Best-effort put of the shutdown sentinel into the event queue.

        Uses put_nowait so the caller never blocks on a full queue.
        """

        if self._event_queue is not None:
            try:
                self._event_queue.put_nowait(self._SHUTDOWN_SENTINEL)
            except queue.Full:
                pass

    def _wake_tasks(self, *, include_dispatch_sentinels: bool = True) -> None:
        """
        Put sentinels so tasks blocked on get() wake and can see the shutdown flags.

        For CompleteAll we only wake the router (event queue sentinel). The router
        drains the event queue, routes remaining events, then puts dispatch sentinels
        so dispatchers exit after processing everything. For CompletePending we wake
        both (event + dispatch sentinels) so everyone exits immediately.

        Args:
            include_dispatch_sentinels: If True, put sentinels into each dispatcher's
                queue so dispatchers wake. Set False for CompleteAll so the router
                drains first and puts dispatch sentinels after.
        """

        self._put_event_queue_sentinel()

        if include_dispatch_sentinels:
            self._put_dispatch_sentinels()

    def _put_dispatch_sentinels(self) -> None:
        """
        Put shutdown sentinels into the dispatch queue for all dispatchers.
        """

        for dispatcher in self._dispatchers:
            dispatcher.add_sentinel()

    def _raise_all_errors(self) -> None:
        """
        Drain all errors from the error queue and raise them as an ExceptionGroup.

        Raises:
            ExceptionGroup: If there are any errors in the error queue.
        """

        if self._error_queue is None:
            return

        exceptions: list[Exception] = []

        while not self._error_queue.empty():
            try:
                exceptions.append(self._error_queue.get_nowait())

            except queue.Empty:
                break

        if exceptions:
            raise ExceptionGroup("Metrana encountered the following errors during operation:", exceptions)

    def _find_or_assign_dispatcher(
        self, metric_name: str, scale: str, next_dispatcher_idx: int
    ) -> tuple[Dispatcher, int]:
        """
        Find the dispatcher a series is registered to, or assign it to the next
        dispatcher in round-robin order.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.
            next_dispatcher_idx: Current round-robin index for new series assignment.

        Returns:
            Tuple of (target dispatcher, updated round-robin index).
        """

        for dispatcher in self._dispatchers:
            if dispatcher.has_series(metric_name, scale):
                return dispatcher, next_dispatcher_idx

        target_dispatcher = self._dispatchers[next_dispatcher_idx]
        target_dispatcher.register(metric_name, scale)
        next_dispatcher_idx = (next_dispatcher_idx + 1) % len(self._dispatchers)

        return target_dispatcher, next_dispatcher_idx

    def _create_dispatcher(self) -> Dispatcher:
        """
        Create a new dispatcher, append it to self._dispatchers, and return it.

        Returns:
            The newly created Dispatcher instance.
        """

        dispatcher = Dispatcher(
            session_id=self._session_id,
            workspace_name=self.workspace_name,
            project_name=self.project_name,
            run_name=self.run_name,
            aiohttp_session=self._aiohttp_session,
            error_queue=self._error_queue,
            error_strategy=self.error_strategy,
            ingestion_url=self.ingestion_url,
            max_send_retries=self.max_send_retries,
            send_retry_initial_delay=self.send_retry_initial_delay,
            send_retry_max_delay=self.send_retry_max_delay,
            send_retry_backoff_factor=self.send_retry_backoff_factor,
            batch_fill_initial_wait=self.batch_fill_initial_wait,
            batch_fill_wait_decay=self.batch_fill_wait_decay,
            batch_fill_max_waits=self.batch_fill_max_waits,
            max_queue_size=self.max_dispatch_queue_size,
        )
        self._dispatchers.append(dispatcher)

        return dispatcher

    def log(
        self,
        metric_name: str,
        value: float | int,
        scale: str | None = None,
        step: int | None = None,
        labels: dict[str, str] | None = None,
        timestamp: int | None = None,
    ) -> None:
        """
        Enqueue a metric event for routing and dispatch. Thread-safe.

        Args:
            metric_name: Name of the metric (maps to series metric_name in the API).
            value: Numeric value for this point (int or float).
            scale: Scale descriptor; must be a StandardMetricScale member name or value
                (e.g. "MLStep", "ML_STEP"). If None, defaults to MLStep.
            step: Step index for this point. If None, the logger assigns the next step
                for this (metric_name, scale, labels) series.
            labels: Optional key-value labels identifying the series. Defaults to {}.
            timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.

        Raises:
            MetranaLoggerClosedError: If the logger has been closed or the loop thread is dead.
            MetranaEventQueueFullError: If the event queue is full and backpressure strategy
                is Raise, or if strategy is Block and put times out.
            ValueError: If scale is not None and is not a valid StandardMetricScale member.
            ExceptionGroup: If the error strategy is RaiseOnLog and there are errors in the queue.
        """

        self._validate()

        if self.error_strategy is ErrorStrategy.RaiseOnLog:
            self._raise_all_errors()

        if not self._accept_new_events:
            logging.warn_once("Metrana logger is not accepting new events. Skipping log.", key="no_new_events")

            return

        kwargs = dict(timestamp=timestamp) if timestamp is not None else {}
        labels = labels if labels is not None else {}
        scale = StandardMetricScale.ML_STEP.value if scale is None else StandardMetricScale(scale).value

        step = self._metric_step_counter.get_step(metric_name=metric_name, scale=scale, labels=labels, step=step)

        metric_event = MetricEvent(
            metric_name=metric_name,
            value=float(value),
            scale=scale,
            step=step,
            labels=labels,
            **kwargs,
        )

        try:
            if self.backpressure_strategy is BackpressureStrategy.Block:
                self._event_queue.put(metric_event, timeout=self.max_event_queue_timeout)

            else:
                self._event_queue.put_nowait(metric_event)

        except queue.Full as e:
            if self.backpressure_strategy is BackpressureStrategy.DropNew:
                logging.warn_once(
                    f"Event queue is full. Dropping event for metric: {metric_name}.", key="event_queue_full"
                )
                logger.trace(f"Event queue is full. Dropping event for metric: {metric_name}.")

            elif self.backpressure_strategy in [BackpressureStrategy.Raise, BackpressureStrategy.Block]:
                raise MetranaEventQueueFullError(
                    "Event queue is full. Cannot add new event and backpressure strategy " "is Raise. Exiting..."
                ) from e

            else:
                raise UnrecognizedMetranaBackpressureStrategyError(
                    f"Unrecognized backpressure strategy: {self.backpressure_strategy}. "
                    f"This should be unreachable, please report this as a bug."
                ) from e

    def close(self, strategy: CloseStrategy | str | None = None, timeout: float = 15.0) -> None:
        """
        Request shutdown and wait for the loop thread to finish (up to timeout seconds).

        Uses the given strategy (or the instance/env default). Idempotent if the
        logger is already closed or the loop thread is not alive (e.g. after fork).

        Args:
            strategy: Shutdown strategy for this close: Immediate, CompletePending,
                or CompleteAll. If None, uses the instance default or env.
            timeout: Maximum seconds to wait for the loop thread to exit.

        Raises:
            ExceptionGroup: If the error strategy is RaiseOnClose and there are errors in the queue.
        """

        if self._loop is None or self._loop_thread is None:
            return

        if not self._loop_thread.is_alive():
            self._loop_thread = None
            return

        strategy = CloseStrategy(strategy) if strategy is not None else self.close_strategy
        self.close_strategy = strategy

        logger.info(f"Closing metrana logger with strategy: {self.close_strategy.value}")

        if self._shutdown_event is not None:
            self._loop.call_soon_threadsafe(self._shutdown_event.set)

        self._loop_thread.join(timeout=timeout)
        self._loop_thread = None

        if self.error_strategy is ErrorStrategy.RaiseOnClose:
            self._raise_all_errors()

    def kill(self, timeout: float = 3.0) -> None:
        """
        Close immediately (Immediate strategy) and clear queue references.

        Used after fork so the child can create a new logger without leaking
        references to the parent's queues and thread.

        Args:
            timeout: Maximum seconds to wait for the loop thread to exit before
                clearing references.

        Raises:
            ExceptionGroup: If the error strategy is RaiseOnClose and there are errors in the queue.
        """

        logger.info("Metrana received kill signal. Closing logger immediately.")

        try:
            self.close(strategy=CloseStrategy.Immediate, timeout=timeout)

        except Exception:
            logging.error_once(
                "Errors encountered during kill of Metrana logger. Ignoring...", key="errors_during_kill"
            )

        finally:
            self._event_queue = None
            self._error_queue = None
