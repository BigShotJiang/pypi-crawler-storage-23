# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import sys
import threading
import time
from collections.abc import Callable
from loguru import logger

from metrana.utils import env_vars
from metrana.utils.enums import LogLevel

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class LogOnce:
    """
    Thread-safe (not process-safe) "log once per key" helper for warnings and errors.
    Each key is logged at most once in total (either as a warning or an error), or again after ttl_seconds if set.
    State is held at class level so all callers share the same deduplication.
    """

    _logged: dict[str, float] = {}  # key -> expiry time (monotonic); inf means never expires
    _lock: threading.Lock = threading.Lock()

    @classmethod
    def log_once(
        cls,
        log_method: Callable[[str], None],
        message: str,
        *,
        key: str | None = None,
        ttl_seconds: float | None = None,
    ) -> None:
        """
        Log a message only once per key (or again after ttl_seconds if set).
        If key is not provided, the message itself is used as the key.
        A key that has already been logged will not be logged again until it expires.

        :param log_method: Logger method to call with the message (e.g. logger.warning, logger.error).
        :param message: Message to log.
        :param key: Optional key to deduplicate by. If None, message is used as the key.
        :param ttl_seconds: If set, the key may be logged again after this many seconds. If None, never expires.
        """

        dedupe_key = key if key is not None else message
        now = time.monotonic()
        expiry = now + ttl_seconds if ttl_seconds is not None else float("inf")

        with cls._lock:
            if dedupe_key in cls._logged and now <= cls._logged[dedupe_key]:
                return

            cls._logged[dedupe_key] = expiry
            log_method(message)


# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def warn_once(
    message: str,
    *,
    key: str | None = None,
    ttl_seconds: float | None = None,
) -> None:
    """
    Log a warning only once per key (or again after ttl_seconds if set).
    If key is not provided, the message itself is used as the key.
    A key already used in warn_once or error_once will not be logged again until it expires.
    Thread-safe (not process-safe).

    :param message: Warning message to log.
    :param key: Optional key to deduplicate by. If None, message is used as the key.
    :param ttl_seconds: If set, the key may be logged again after this many seconds. If None, never expires.
    """

    LogOnce.log_once(logger.warning, message, key=key, ttl_seconds=ttl_seconds)


def error_once(
    message: str,
    *,
    key: str | None = None,
    ttl_seconds: float | None = None,
) -> None:
    """
    Log an error only once per key (or again after ttl_seconds if set).
    If key is not provided, the message itself is used as the key.
    A key already used in warn_once or error_once will not be logged again until it expires.
    Thread-safe (not process-safe).

    :param message: Error message to log.
    :param key: Optional key to deduplicate by. If None, message is used as the key.
    :param ttl_seconds: If set, the key may be logged again after this many seconds. If None, never expires.
    """

    LogOnce.log_once(logger.error, message, key=key, ttl_seconds=ttl_seconds)


def configure_logging(level: LogLevel | str | None = None) -> None:
    """
    Reconfigure the loguru default logging sink to use the given log level.
    If no level is passed, uses the value from get_log_level() (e.g. METRANA_LOG_LEVEL env var).

    :param level: Log level to use, or None to use get_log_level().
    """

    effective_level = LogLevel(level) if level is not None else env_vars.get_log_level()
    level_name = effective_level.value

    logger.remove()

    if effective_level is not LogLevel.Off:
        logger.add(sys.stderr, level=level_name)
