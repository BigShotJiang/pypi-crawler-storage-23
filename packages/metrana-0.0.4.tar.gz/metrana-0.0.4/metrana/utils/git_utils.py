# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import subprocess

from metrana.utils import logging

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def get_git_sha() -> str | None:
    """
    Attempts to get the current Git commit SHA so that it can be saved alongside the run.

    Returns:
        Current git commit SHA if git is installed and None otherwise.
    """

    try:
        result = subprocess.run(["git", "rev-parse", "HEAD"], stdout=subprocess.PIPE, check=True)
        return result.stdout.decode("utf-8").strip()

    except Exception:
        logging.warn_once("Could not automatically determine git commit ID.", key="git_commit_sha")

    return None
