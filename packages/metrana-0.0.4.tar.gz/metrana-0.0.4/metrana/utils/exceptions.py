# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from typing import Any, Iterable

# ======================================================================================================================
#
# EXCEPTIONS
#
# ======================================================================================================================


class CustomException(Exception):
    def __init__(self, *args: Iterable[Any]):
        super().__init__(*args)

        self.message: Any = args[0] if args else None

    def __str__(self) -> str:
        if self.message:
            return type(self).__name__ + f": {self.message}"
        else:
            return type(self).__name__ + " raised."


class MetranaAlreadyInitializedError(CustomException):
    pass


class MetranaNotInitializedError(CustomException):
    pass


class MetranaProcessForkError(CustomException):
    pass


class MetranaLoggerClosedError(CustomException):
    pass


class MetranaRunAlreadyExistsError(CustomException):
    pass


class MetranaEventQueueFullError(CustomException):
    pass


class UnrecognizedMetranaBackpressureStrategyError(CustomException):
    pass


class UnrecognizedMetranaErrorStrategyError(CustomException):
    pass


class MetranaMetricStepError(CustomException):
    pass


class MetranaErrorQueueFullError(CustomException):
    pass


class MetranaUnregisteredMetricError(CustomException):
    pass


class NoMetranaApiKeyError(CustomException):
    pass
