# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import os
from typing import Any
from enum import Enum

from metrana.utils.enums import BackpressureStrategy, ErrorStrategy, LogLevel, ResumeStrategy, CloseStrategy

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

METRANA_BACKPRESSURE_STRATEGY = "METRANA_BACKPRESSURE_STRATEGY"
METRANA_ERROR_MODES = "METRANA_ERROR_MODES"
METRANA_LOG_LEVEL = "METRANA_LOG_LEVEL"
METRANA_RESUME_STRATEGY = "METRANA_RESUME_STRATEGY"
METRANA_CLOSE_STRATEGY = "METRANA_CLOSE_STRATEGY"
METRANA_EVENT_QUEUE_MAX_SIZE = "METRANA_EVENT_QUEUE_MAX_SIZE"
METRANA_DISPATCH_QUEUE_MAX_SIZE = "METRANA_DISPATCH_QUEUE_MAX_SIZE"
METRANA_ERROR_QUEUE_MAX_SIZE = "METRANA_ERROR_QUEUE_MAX_SIZE"

METRANA_API_KEY = "METRANA_API_KEY"

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def _get_metrana_environment_variable(
    name: str, allowed_values: type[Enum] | None = None, default: Any | None = None
) -> Any:
    """
    :param name: Name of the environment variable.
    :param allowed_values: Class of the environment variable choices.
    :param default: Default value of the environment variable.
    :return: Value of the environment variable.
    """

    value = os.getenv(name, default=default)

    if allowed_values is not None:
        value = allowed_values(value)

    return value


def get_backpressure_strategy() -> BackpressureStrategy:
    """
    :return: Backpressure strategy.
    """

    return _get_metrana_environment_variable(
        name=METRANA_BACKPRESSURE_STRATEGY,
        allowed_values=BackpressureStrategy,
        default=BackpressureStrategy.DropNew,
    )


def get_error_strategy() -> ErrorStrategy:
    """
    :return: Error strategy.
    """

    return _get_metrana_environment_variable(
        name=METRANA_ERROR_MODES, allowed_values=ErrorStrategy, default=ErrorStrategy.Warn
    )


def get_resume_strategy() -> ResumeStrategy:
    """
    :return: Resume strategy.
    """

    return _get_metrana_environment_variable(
        name=METRANA_RESUME_STRATEGY, allowed_values=ResumeStrategy, default=ResumeStrategy.Allow
    )


def get_log_level() -> LogLevel:
    """
    :return: Log level.
    """

    return _get_metrana_environment_variable(name=METRANA_LOG_LEVEL, allowed_values=LogLevel, default=LogLevel.Success)


def get_close_strategy() -> CloseStrategy:
    """
    :return: Close strategy.
    """

    return _get_metrana_environment_variable(
        name=METRANA_CLOSE_STRATEGY, allowed_values=CloseStrategy, default=CloseStrategy.CompleteAll
    )


def get_event_queue_max_size() -> int:
    """
    :return: Maximum size of the event queue (0 = unbounded) in number of events. Defaults to 10000.
    """
    return int(_get_metrana_environment_variable(name=METRANA_EVENT_QUEUE_MAX_SIZE, default=10000))


def get_dispatch_queue_max_size() -> int:
    """
    :return: Maximum size of the dispatch queue (0 = unbounded) in number of batches. Defaults to 10000.
    """
    return int(_get_metrana_environment_variable(name=METRANA_DISPATCH_QUEUE_MAX_SIZE, default=10000))


def get_error_queue_max_size() -> int:
    """
    :return: Maximum size of the error queue (0 = unbounded) in number of errors. Defaults to 1000.
    """
    return int(_get_metrana_environment_variable(name=METRANA_ERROR_QUEUE_MAX_SIZE, default=1000))


def get_api_key() -> str | None:
    """
    :return: API key.
    """
    return _get_metrana_environment_variable(name=METRANA_API_KEY, default=None)
