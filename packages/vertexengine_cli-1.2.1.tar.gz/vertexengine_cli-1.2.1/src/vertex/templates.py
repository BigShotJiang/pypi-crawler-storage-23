# templates.py
from textwrap import dedent

TEMPLATES: dict[str, dict[str, str]] = {
    "game": {
        "main.py": dedent(
            """\
from VertexEngine.Vertex import App from VertexEngine.engine import GameEngine
from VertexEngine.scenes import Scene 
from VertexEngine import VertexScreen 
from VertexEngine.InputSystem.KeyInputs import Input 
from VertexEngine.InputSystem.Events import ButtonEvents 
from VertexEngine import VertexUI 
from PyQt6.QtWidgets import QVBoxLayout 
import sys 

RED = (255, 0, 0) # Define the color red

# Define what the player is
class Player: 
    def __init__(self): 
        self.x = 250 
        self.y = 200 
        self.width = 80 
        self.height = 80 

    def update(self): 
        if Input.is_pressed("w") or Input.is_pressed("up"): 
            self.y -= 5 

        if Input.is_pressed("s") or Input.is_pressed("down"):   
            self.y += 5

        if Input.is_pressed("a") or Input.is_pressed("left"): 
            self.x -= 5
                                                    
        if Input.is_pressed("d") or Input.is_pressed("right"): 
            self.x += 5 

# Define all the objects in the Main Scene.
class Main(Scene): 
    def __init__(self, engine): 
        super().__init__(engine) 
        self.engine = engine 
        self.button1 = VertexUI.FancyButton("Hallo") 
        events = ButtonEvents() 
        events.on_click(self.button1, self.do_something) 
        layout = QVBoxLayout() 
        layout.addWidget(self.button1) 
        self.setLayout(layout) 
        self.player = Player() 
    def do_something(self): 
        ("click clickity click click :D") 
    def update(self): 
        self.player.update() 
        Input.input_update() 
    def draw(self, surface): 
        draw = VertexScreen.Draw() 
        draw.rect(surface, RED, (self.player.x, self.player.y, self.player.width, self.player.height)) 
            
if __name__ == "__main__": 
    app = App() 
    engine = GameEngine() # defaults to 800x600@60 
    engine.setWindowTitle("VertexEngine Full template!")  # set window title
    engine.show() # show the window
    scene1 = Main(engine) # Put the scene into a Variable for simplicity.
    engine.scene_manager.set_scene(scene1) # Activate the Scene.
    sys.exit(app.exec()) # make it loop forever until 'x' button is clicked
    """
        ),
        "README.md": "# VertexEngine Game\n\nGenerated with VertexEngine. ✨\n",
        ".gitignore": "__pycache__/\n.env\n",
   },
}
