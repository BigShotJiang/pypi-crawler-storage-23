# Distances

::: norfair.distances