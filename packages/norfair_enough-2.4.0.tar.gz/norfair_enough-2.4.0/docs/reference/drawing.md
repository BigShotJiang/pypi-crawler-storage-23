# Drawing

::: norfair.drawing

::: norfair.drawing.draw_points
    options:
        show_root_heading: true
::: norfair.drawing.draw_boxes
    options:
        show_root_heading: true
::: norfair.drawing.color
    options:
        show_root_heading: true
::: norfair.drawing.path
    options:
        show_root_heading: true
::: norfair.drawing.fixed_camera
    options:
        show_root_heading: true
::: norfair.drawing.absolute_grid
    options:
        show_root_heading: true
