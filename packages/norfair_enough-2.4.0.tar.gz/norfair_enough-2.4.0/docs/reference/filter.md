# Filter

::: norfair.filter
    options:
        members: 
            # - FilterFactory
            - FilterPyKalmanFilterFactory
            # - NoFilter
            # - NoFilterFactory
            # - OptimizedKalmanFilter
            - OptimizedKalmanFilterFactory