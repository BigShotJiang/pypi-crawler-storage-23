# Camera Motion

::: norfair.camera_motion