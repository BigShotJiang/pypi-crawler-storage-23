from collections import defaultdict
from collections.abc import Callable, Sequence

import numpy as np

from norfair.drawing.color import Palette
from norfair.drawing.drawer import Drawer
from norfair.tracker import TrackedObject
from norfair.utils import warn_once


class Paths:
    """
    Class that draws the paths taken by a set of points of interest defined from the coordinates of each tracker estimation.

    Parameters
    ----------
    get_points_to_draw : Optional[Callable[[np.ndarray], np.ndarray]], optional
        Function that takes a list of points (the `.estimate` attribute of a [`TrackedObject`][norfair.tracker.TrackedObject])
        and returns a list of points for which we want to draw their paths.

        By default it is the mean point of all the points in the tracker.
    thickness : Optional[int], optional
        Thickness of the circles representing the paths of interest.
    color : Optional[Tuple[int, int, int]], optional
        [Color][norfair.drawing.Color] of the circles representing the paths of interest.
    radius : Optional[int], optional
        Radius of the circles representing the paths of interest.
    attenuation : float, optional
        A float number in [0, 1] that dictates the speed at which the path is erased.
        if it is `0` then the path is never erased.

    Examples
    --------
    >>> from norfair import Tracker, Video, Path
    >>> video = Video("video.mp4")
    >>> tracker = Tracker(...)
    >>> path_drawer = Path()
    >>> for frame in video:
    >>>    detections = get_detections(frame)  # runs detector and returns Detections
    >>>    tracked_objects = tracker.update(detections)
    >>>    frame = path_drawer.draw(frame, tracked_objects)
    >>>    video.write(frame)
    """

    def __init__(
        self,
        get_points_to_draw: Callable[[np.ndarray], np.ndarray] | None = None,
        thickness: int | None = None,
        color: tuple[int, int, int] | None = None,
        radius: int | None = None,
        attenuation: float = 0.01,
    ):
        if get_points_to_draw is None:

            def default_get_points(points):
                return [np.mean(np.array(points), axis=0)]

            self.get_points_to_draw = default_get_points
        else:
            self.get_points_to_draw = (
                get_points_to_draw  # pyrefly: ignore[bad-assignment]
            )

        self.radius = radius
        self.thickness = thickness
        self.color = color
        self.mask: np.ndarray | None = None
        self.attenuation_factor = 1 - attenuation

    def draw(
        self, frame: np.ndarray, tracked_objects: Sequence[TrackedObject]
    ) -> np.ndarray:
        """
        Draw the paths of the points interest on a frame.

        !!! warning
            This method does **not** draw frames in place as other drawers do, the resulting frame is returned.

        Parameters
        ----------
        frame : np.ndarray
            The OpenCV frame to draw on.
        tracked_objects : Sequence[TrackedObject]
            List of [`TrackedObject`][norfair.tracker.TrackedObject] to get the points of interest in order to update the paths.

        Returns
        -------
        np.array
            The resulting frame.
        """
        if self.mask is None:
            frame_scale = frame.shape[0] / 100

            if self.radius is None:
                self.radius = int(max(frame_scale * 0.7, 1))
            if self.thickness is None:
                self.thickness = int(max(frame_scale / 7, 1))

            self.mask = np.zeros(frame.shape, np.uint8)

        mask = (self.mask * self.attenuation_factor).astype("uint8")

        for obj in tracked_objects:
            if obj.abs_to_rel is not None:
                warn_once(
                    "It seems that your using the Path drawer together with MotionEstimator. This is not fully supported and the results will not be what's expected"
                )

            if self.color is None:
                color = Palette.choose_color(obj.id)
            else:
                color = self.color

            points_to_draw = self.get_points_to_draw(obj.estimate)

            for point in points_to_draw:
                mask = Drawer.circle(
                    mask,
                    # pyrefly: ignore[bad-argument-type]
                    position=tuple(point.astype(int)),
                    radius=self.radius,
                    color=color,
                    thickness=self.thickness,
                )

        self.mask = mask
        return Drawer.alpha_blend(mask, frame, alpha=1, beta=1)


class AbsolutePaths:
    """
    Class that draws the absolute paths taken by a set of points.

    Works just like [`Paths`][norfair.drawing.Paths] but supports camera motion.

    !!! warning
        This drawer is not optimized so it can be stremely slow. Performance degrades linearly with
        `max_history * number_of_tracked_objects`.

    Parameters
    ----------
    get_points_to_draw : Optional[Callable[[np.ndarray], np.ndarray]], optional
        Function that takes a list of points (the `.estimate` attribute of a [`TrackedObject`][norfair.tracker.TrackedObject])
        and returns a list of points for which we want to draw their paths.

        By default it is the mean point of all the points in the tracker.
    thickness : Optional[int], optional
        Thickness of the circles representing the paths of interest.
    color : Optional[Tuple[int, int, int]], optional
        [Color][norfair.drawing.Color] of the circles representing the paths of interest.
    radius : Optional[int], optional
        Radius of the circles representing the paths of interest.
    max_history : int, optional
        Number of past points to include in the path. High values make the drawing slower

    Examples
    --------
    >>> from norfair import Tracker, Video, Path
    >>> video = Video("video.mp4")
    >>> tracker = Tracker(...)
    >>> path_drawer = Path()
    >>> for frame in video:
    >>>    detections = get_detections(frame)  # runs detector and returns Detections
    >>>    tracked_objects = tracker.update(detections)
    >>>    frame = path_drawer.draw(frame, tracked_objects)
    >>>    video.write(frame)
    """

    def __init__(
        self,
        get_points_to_draw: Callable[[np.ndarray], np.ndarray] | None = None,
        thickness: int | None = None,
        color: tuple[int, int, int] | None = None,
        radius: int | None = None,
        max_history=20,
    ):
        if get_points_to_draw is None:

            def default_get_points(points):
                return [np.mean(np.array(points), axis=0)]

            self.get_points_to_draw = default_get_points
        else:
            self.get_points_to_draw = (
                get_points_to_draw  # pyrefly: ignore[bad-assignment]
            )

        self.radius = radius
        self.thickness = thickness
        self.color = color
        self.past_points: defaultdict[int | None, list[np.ndarray]] = defaultdict(list)
        self.max_history = max_history
        self.alphas = np.linspace(0.99, 0.01, max_history)

    def draw(self, frame, tracked_objects, coord_transform=None):
        frame_scale = frame.shape[0] / 100

        if self.radius is None:
            self.radius = int(max(frame_scale * 0.7, 1))
        if self.thickness is None:
            self.thickness = int(max(frame_scale / 7, 1))
        for obj in tracked_objects:
            if not obj.live_points.any():
                continue

            if self.color is None:
                color = Palette.choose_color(obj.id)
            else:
                color = self.color

            points_to_draw = self.get_points_to_draw(obj.get_estimate(absolute=True))

            # Convert from absolute to relative coordinates if transform is provided
            points_rel = (
                coord_transform.abs_to_rel(points_to_draw)
                if coord_transform is not None
                else points_to_draw
            )

            for point in points_rel:
                Drawer.circle(
                    frame,
                    # pyrefly: ignore[bad-argument-type]
                    position=tuple(point.astype(int)),
                    radius=self.radius,
                    color=color,
                    thickness=self.thickness,
                )

            last = points_to_draw
            for i, past_points in enumerate(self.past_points[obj.id]):
                overlay = frame.copy()
                last_rel = (
                    coord_transform.abs_to_rel(last)
                    if coord_transform is not None
                    else last
                )
                past_points_rel = (
                    coord_transform.abs_to_rel(past_points)
                    if coord_transform is not None
                    else past_points
                )
                for j, point in enumerate(past_points_rel):
                    Drawer.line(
                        overlay,
                        # pyrefly: ignore[bad-argument-type]
                        tuple(last_rel[j].astype(int)),
                        tuple(point.astype(int)),  # pyrefly: ignore[bad-argument-type]
                        color=color,
                        thickness=self.thickness,
                    )
                last = past_points

                alpha = self.alphas[i]
                frame = Drawer.alpha_blend(overlay, frame, alpha=alpha)
            # pyrefly: ignore[bad-argument-type]
            self.past_points[obj.id].insert(0, points_to_draw)
            self.past_points[obj.id] = self.past_points[obj.id][: self.max_history]
        return frame
