---
name: Help wanted
about: Ask for help in the use of the library
title: ''
labels: help wanted
assignees: ''

---

**Describe the situation you are working on**
_A clear and concise description of your use case._

**Describe what is it that you need help with**
_A clear and concise description of what you don't understand or need help with._

**Additional context**
_Add any other context about the problem here._
