"""Allow running as: python -m clawome"""
from clawome.clawome_cli import main

main()
