"""Shared utilities used by both v1 and v2 workflow nodes."""
