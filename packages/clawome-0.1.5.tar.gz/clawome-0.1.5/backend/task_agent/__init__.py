"""Task Agent — LangGraph-based browser automation agent."""
