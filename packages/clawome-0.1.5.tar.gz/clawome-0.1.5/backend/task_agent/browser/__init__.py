from browser.api import (
    open_browser, get_url, get_dom, get_text,
    click, input_text, select,
    get_tabs, switch_tab, close_tab,
    detect_new_tab,
)
