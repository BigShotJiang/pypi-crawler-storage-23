"""Integration test specific fixtures

Integration tests may use database and multiple components together.
"""


# Add integration-test specific fixtures here (e.g., test database setup)
