"""E2E tests for custom routes functionality"""
