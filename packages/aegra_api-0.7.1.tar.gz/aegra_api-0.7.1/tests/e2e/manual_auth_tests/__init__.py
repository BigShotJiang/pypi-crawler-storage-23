"""E2E tests for authentication flow"""
