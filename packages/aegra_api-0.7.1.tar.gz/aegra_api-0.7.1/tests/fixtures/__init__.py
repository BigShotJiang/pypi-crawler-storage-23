"""Test fixtures for auth and custom routes testing"""
