"""Observability module for the agent server."""
