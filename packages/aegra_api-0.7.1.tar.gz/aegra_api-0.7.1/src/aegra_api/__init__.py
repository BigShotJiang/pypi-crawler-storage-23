"""Aegra API - Self-hosted Agent Protocol server."""

from importlib.metadata import version

__version__ = version("aegra-api")
