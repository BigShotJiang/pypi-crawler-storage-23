from __future__ import annotations

from typing import Any

from .._models import (
    AddContent,
    ConversationContent,
    PreExtractedContent,
    RetrievalConfig,
    StringContent,
)


def _serialize_content(content: AddContent) -> dict[str, Any]:
    """Build the content envelope with the type discriminator."""
    if isinstance(content, str):
        return {"type": "string", "content": content}
    if isinstance(content, StringContent):
        return {"type": "string", "content": content.content}
    if isinstance(content, PreExtractedContent):
        return {
            "type": "pre_extracted",
            "content": content.content,
            "topic": content.topic,
        }
    if isinstance(content, list):
        return {
            "type": "conversation",
            "conversation": {"messages": content},
        }
    if isinstance(content, ConversationContent):
        return _serialize_conversation_content(content)
    raise TypeError(f"Unsupported content type: {type(content)}")  # pragma: no cover


def _serialize_conversation_content(content: ConversationContent) -> dict[str, Any]:
    messages = []
    for msg in content.messages:
        m: dict[str, Any] = {"role": msg.role, "content": msg.content}
        if msg.created_at is not None:
            m["created_at"] = msg.created_at
        if msg.tool_call_metadata is not None:
            m["tool_call_metadata"] = {
                "name": msg.tool_call_metadata.name,
                "id": msg.tool_call_metadata.id,
            }
        messages.append(m)
    conversation: dict[str, Any] = {"messages": messages}
    if content.metadata is not None:
        conversation["metadata"] = content.metadata
    if content.created_at is not None:
        conversation["created_at"] = content.created_at
    if content.updated_at is not None:
        conversation["updated_at"] = content.updated_at
    return {"type": "conversation", "conversation": conversation}


def build_add_body(
    content: AddContent,
    *,
    user_id: str | None,
    conversation_id: str | None,
    group: str | None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"content": _serialize_content(content)}
    if user_id is not None:
        body["user_id"] = user_id
    if conversation_id is not None:
        body["conversation_id"] = conversation_id
    if group is not None:
        body["group"] = group
    return body


def build_memory_params(
    *,
    user_id: str | None,
    group: str | None,
) -> dict[str, str]:
    params: dict[str, str] = {}
    if user_id is not None:
        params["user_id"] = user_id
    if group is not None:
        params["group"] = group
    return params


def build_search_body(
    *,
    query: str,
    topics: list[str] | None,
    user_id: str | None,
    conversation_id: str | None,
    group: str | None,
    retrieval_config: RetrievalConfig | None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"query": query}
    if retrieval_config is not None:
        body["retrieval_config"] = {
            "retrieval_type": retrieval_config.retrieval_type,
            "limit": retrieval_config.limit,
        }
    if topics is not None:
        body["topics"] = topics
    if user_id is not None:
        body["user_id"] = user_id
    if conversation_id is not None:
        body["conversation_id"] = conversation_id
    if group is not None:
        body["group"] = group
    return body
