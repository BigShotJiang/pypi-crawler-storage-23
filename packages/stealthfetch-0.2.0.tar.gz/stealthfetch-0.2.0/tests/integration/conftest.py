"""Integration test configuration."""

from __future__ import annotations

import pytest


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--run-integration",
        action="store_true",
        default=False,
        help="Run integration tests with real HTTP requests",
    )


def pytest_collection_modifyitems(
    config: pytest.Config, items: list[pytest.Item]
) -> None:
    if not config.getoption("--run-integration"):
        skip = pytest.mark.skip(reason="need --run-integration to run")
        for item in items:
            if item.path and "integration" in item.path.parts:
                item.add_marker(skip)
