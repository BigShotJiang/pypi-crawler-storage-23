"""Authentication commands for the OpenCosmo CLI."""

import time
from datetime import datetime

import click
import httpx

from ocp.auth.device import run_device_flow
from ocp.auth.oauth import run_login_flow
from ocp.auth.tokens import delete_tokens, get_token_expiry, load_tokens
from ocp.config.store import get_api_url, get_current_profile
from ocp.utils.api import APIClient


@click.group()
def auth() -> None:
    """Manage authentication."""
    pass


@auth.command()
@click.option(
    "--browser",
    is_flag=True,
    help="Use browser-based redirect flow instead of device code flow",
)
@click.option(
    "--port",
    default=8080,
    type=int,
    help="Local port for OAuth callback (only with --browser)",
)
@click.pass_context
def login(ctx: click.Context, browser: bool, port: int) -> None:
    """Authenticate with OpenCosmo.

    By default uses device code flow: displays a code and URL, then
    waits for you to authorize from any browser on any device.
    Works in SSH sessions and headless environments.

    Use --browser to open a local browser for OAuth redirect flow instead.
    """
    profile = ctx.obj.get("profile") or get_current_profile()
    api_url = get_api_url(profile)

    click.echo(f"Authenticating profile '{profile}' with {api_url}")

    # Check if API is reachable
    click.echo("Checking API availability...")
    try:
        response = httpx.get(f"{api_url}/health", timeout=5.0)
        if response.status_code != 200:
            raise click.ClickException(f"API returned status {response.status_code}")
    except httpx.ConnectError:
        raise click.ClickException(
            f"Cannot connect to API at {api_url}\nMake sure the server is running."
        )

    if browser:
        click.echo("Starting OAuth flow...")
        click.echo("Opening browser for authentication...")
        click.echo("(Complete the login in your browser)\n")

        try:
            run_login_flow(profile=profile, local_port=port)
            click.echo(click.style("Authentication successful!", fg="green"))
        except ValueError as e:
            raise click.ClickException(str(e))
        except Exception as e:
            raise click.ClickException(f"Authentication failed: {e}")
    else:
        try:
            run_device_flow(profile=profile)
            click.echo(click.style("\nAuthentication successful!", fg="green"))
        except KeyboardInterrupt:
            click.echo("\nAuthentication cancelled.")
            ctx.exit(1)
        except ValueError as e:
            raise click.ClickException(str(e))
        except Exception as e:
            raise click.ClickException(f"Authentication failed: {e}")


@auth.command()
@click.pass_context
def logout(ctx: click.Context) -> None:
    """Log out and clear stored tokens.

    Removes local tokens for this profile. Optionally notifies
    the server to invalidate the session.
    """
    profile = ctx.obj.get("profile") or get_current_profile()
    tokens = load_tokens(profile)

    if tokens is None:
        click.echo(f"Not authenticated for profile '{profile}'.")
        return

    # Try to notify server (best effort)
    try:
        with APIClient(profile=profile) as client:
            client.post("/api/v1/auth/logout")
    except Exception:
        # Ignore server errors - we'll delete local tokens anyway
        pass

    # Delete local tokens
    if delete_tokens(profile):
        click.echo(f"Logged out from profile '{profile}'.")
    else:
        click.echo(f"No tokens found for profile '{profile}'.")


@auth.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show authentication status.

    Displays whether you are authenticated and token expiry information.
    """
    profile = ctx.obj.get("profile") or get_current_profile()
    api_url = get_api_url(profile)

    click.echo(f"Profile: {profile}")
    click.echo(f"API URL: {api_url}")
    click.echo()

    tokens = load_tokens(profile)

    if tokens is None:
        click.echo(click.style("Status: Not authenticated", fg="yellow"))
        click.echo("\nRun 'ocp auth login' to authenticate.")
        return

    expiry = get_token_expiry(profile)
    if expiry:
        expiry_dt = datetime.fromtimestamp(expiry)
        now = time.time()

        if expiry <= now:
            if tokens.get("refresh_token"):
                click.echo(click.style("Status: Token expired (will auto-refresh)", fg="yellow"))
            else:
                click.echo(click.style("Status: Token expired", fg="red"))
                click.echo("\nRun 'ocp auth login' to re-authenticate.")
                return
        else:
            remaining = int(expiry - now)
            if remaining < 3600:
                minutes = remaining // 60
                msg = f"Status: Authenticated (expires in {minutes} minutes)"
            else:
                hours = remaining // 3600
                msg = f"Status: Authenticated (expires in {hours} hours)"
            click.echo(click.style(msg, fg="green"))

        click.echo(f"Expires: {expiry_dt.strftime('%Y-%m-%d %H:%M:%S')}")

    if tokens.get("refresh_token"):
        click.echo("Refresh token: Available")
    else:
        click.echo("Refresh token: Not available")
