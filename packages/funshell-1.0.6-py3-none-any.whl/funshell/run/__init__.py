"""
执行shell
"""

from .core import run_shell, run_shell_list

__all__ = ["run_shell", "run_shell_list"]
