#!/usr/bin/env python3
"""Benchmarks for xDSL."""
