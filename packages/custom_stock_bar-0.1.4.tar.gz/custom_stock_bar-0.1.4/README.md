
# Custom stock bar

Tool for convert any price to Custom Bar price


## Badges

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)

