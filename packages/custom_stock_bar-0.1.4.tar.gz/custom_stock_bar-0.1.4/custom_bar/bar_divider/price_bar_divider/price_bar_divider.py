"""Divider bar by Constant price"""
import decimal as dec


class PriceDivider:
    """Class provider Golder Bar Restrictions"""

    def __init__(self, static_restriction: dec.Decimal) -> None:
        self._restriction: dec.Decimal = static_restriction

    def calc_bar_restriction(self, *args: object, **kwargs: object) -> dec.Decimal:
        return self._restriction
