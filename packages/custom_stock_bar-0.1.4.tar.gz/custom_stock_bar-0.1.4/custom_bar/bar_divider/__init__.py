import custom_bar.bar_divider.gold_bar_divider as gold

__all__ = [
    "gold",
]
