[Skip to main content](https://jellyfin.org/downloads/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
# Downloads
[Clients](https://jellyfin.org/downloads)[Server](https://jellyfin.org/downloads/server)[Full Repository](https://repo.jellyfin.org)
[Recommended](https://jellyfin.org/downloads/clients)[All](https://jellyfin.org/downloads/clients/all)
### Jellyfin Media Player
OfficialOpen Source
The official Jellyfin desktop client.
[GitHub](https://github.com/jellyfin/jellyfin-media-player)[Flathub (Linux)](https://flathub.org/apps/details/com.github.iwalton3.jellyfin-media-player)[GitHub Downloads](https://github.com/jellyfin/jellyfin-media-player/releases)
### JellyCon
OfficialOpen Source
Kodi
A lightweight Kodi add-on that lets you browse and play media files directly from your Jellyfin server within the Kodi interface.
[GitHub](https://github.com/jellyfin/jellycon)[Installation Guide](https://github.com/jellyfin/jellycon#installation)
### Jellyfin for Android
OfficialOpen Source
Android
The official Jellyfin app for Android devices.
[GitHub](https://github.com/jellyfin/jellyfin-android)[F-Droid](https://f-droid.org/en/packages/org.jellyfin.mobile/)[Amazon Appstore](https://www.amazon.com/gp/aw/d/B081RFTTQ9)[Play Store](https://play.google.com/store/apps/details?id=org.jellyfin.mobile)
### Jellyfin for iOS
OfficialOpen Source
iOS
The official Jellyfin app for iOS and iPadOS devices.
[GitHub](https://github.com/jellyfin/jellyfin-ios)[App Store](https://apps.apple.com/us/app/jellyfin-mobile/id1480192618?mt=8)
### Jellyfin for Android TV
OfficialOpen Source
Android
The official Jellyfin app for Android TV and Fire TV devices.
[GitHub](https://github.com/jellyfin/jellyfin-androidtv)[F-Droid](https://f-droid.org/en/packages/org.jellyfin.androidtv/)[Amazon Appstore](https://www.amazon.com/gp/aw/d/B07TX7Z725)[Play Store](https://play.google.com/store/apps/details?id=org.jellyfin.androidtv)
### Jellyfin for Roku
OfficialOpen Source
Roku
The official Jellyfin app for Roku devices.
Due to a technical limitation of the Roku store, the Jellyfin app for Roku may state that a cable or satellite subscription is required. However, no subscription of any form is required to use the Jellyfin server or any official client.
[GitHub](https://github.com/jellyfin/jellyfin-roku)[Channel Store](https://channelstore.roku.com/details/592369/jellyfin)
### Jellyfin for WebOS
OfficialOpen Source
LG
The official Jellyfin app for WebOS devices.
[GitHub](https://github.com/jellyfin/jellyfin-webos)[Content Store](https://us.lgappstv.com/main/tvapp/detail?appId=1030579)
### Jellyfin for Xbox
OfficialOpen Source
The official Jellyfin app for Xbox consoles.
[GitHub](https://github.com/jellyfin/jellyfin-xbox)[Microsoft Store](https://apps.microsoft.com/detail/9P2DRTG62QF8)
### Infuse
Third PartyProprietary
iOSApple TV
A third-party client for iOS, iPadOS, and tvOS devices.
[Website](https://firecore.com/infuse)[App Store](https://apps.apple.com/app/id1136220934?mt=8)
[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
