[Skip to main content](https://jellyfin.org/docs/general/installation/windows/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
  * [Introduction](https://jellyfin.org/docs/)
  * [Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Quick Start](https://jellyfin.org/docs/general/quick-start)
  * [Installation](https://jellyfin.org/docs/general/installation/)
    * [Windows](https://jellyfin.org/docs/general/installation/windows)
    * [macOS](https://jellyfin.org/docs/general/installation/macos)
    * [Linux](https://jellyfin.org/docs/general/installation/linux)
    * [Container](https://jellyfin.org/docs/general/installation/container)
    * [Advanced Installation](https://jellyfin.org/docs/general/installation/windows/)
  * [Post-Install Setup](https://jellyfin.org/docs/general/installation/windows/)
  * [Administration](https://jellyfin.org/docs/general/installation/windows/)
  * [Server Guide](https://jellyfin.org/docs/general/installation/windows/)
  * [Clients](https://jellyfin.org/docs/general/clients/)
  * [About Jellyfin](https://jellyfin.org/docs/general/about)
  * [Community Standards](https://jellyfin.org/docs/general/community-standards/)
  * [FAQ](https://jellyfin.org/docs/general/faq)
  * [Contributing](https://jellyfin.org/docs/general/contributing/)
  * [Style Guides](https://jellyfin.org/docs/general/style-guides/)
  * [Testing](https://jellyfin.org/docs/general/testing/)
  * [API Documentation](https://api.jellyfin.org)


  * [](https://jellyfin.org/)
  * [Installation](https://jellyfin.org/docs/general/installation/)
  * Windows


On this page
# Windows
## Installing on Windows[​](https://jellyfin.org/docs/general/installation/windows/#installing-on-windows "Direct link to Installing on Windows")
  1. Download the latest version installer from [the downloads page](https://jellyfin.org/downloads/windows).
  2. Run the installer.
  3. (Optional) When installing as a service (not recommended), pick the service account type.
  4. If everything was completed successfully, Jellyfin is now running.
  5. Open your browser at <http://your_local_IP_address:8096> to finish setting up Jellyfin.


## Updating on Windows[​](https://jellyfin.org/docs/general/installation/windows/#updating-on-windows "Direct link to Updating on Windows")
  1. Download the latest version installer from [the downloads page](https://jellyfin.org/downloads/windows).
  2. Close or Stop Jellyfin from the tray app if it is running.
  3. Run the installer.
  4. If everything was completed successfully, the new version is installed.


## Uninstalling on Windows[​](https://jellyfin.org/docs/general/installation/windows/#uninstalling-on-windows "Direct link to Uninstalling on Windows")
  1. Go to [Add or remove programs](https://support.microsoft.com/en-us/windows/uninstall-or-remove-apps-and-programs-in-windows-4b55f974-2cc6-2d2b-d092-5905080eaf98) in Windows settings.
  2. Search for Jellyfin.
  3. Click Uninstall.


[](https://github.com/jellyfin/jellyfin.org/edit/master/docs/general/installation/windows.md)
[Previous Installation](https://jellyfin.org/docs/general/installation/)[Next macOS](https://jellyfin.org/docs/general/installation/macos)
  * [Installing on Windows](https://jellyfin.org/docs/general/installation/windows/#installing-on-windows)
  * [Updating on Windows](https://jellyfin.org/docs/general/installation/windows/#updating-on-windows)
  * [Uninstalling on Windows](https://jellyfin.org/docs/general/installation/windows/#uninstalling-on-windows)


[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
