[Skip to main content](https://jellyfin.org/docs/general/quick-start/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
  * [Introduction](https://jellyfin.org/docs/)
  * [Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Quick Start](https://jellyfin.org/docs/general/quick-start)
  * [Installation](https://jellyfin.org/docs/general/installation/)
  * [Post-Install Setup](https://jellyfin.org/docs/general/quick-start/)
  * [Administration](https://jellyfin.org/docs/general/quick-start/)
  * [Server Guide](https://jellyfin.org/docs/general/quick-start/)
  * [Clients](https://jellyfin.org/docs/general/clients/)
  * [About Jellyfin](https://jellyfin.org/docs/general/about)
  * [Community Standards](https://jellyfin.org/docs/general/community-standards/)
  * [FAQ](https://jellyfin.org/docs/general/faq)
  * [Contributing](https://jellyfin.org/docs/general/contributing/)
  * [Style Guides](https://jellyfin.org/docs/general/style-guides/)
  * [Testing](https://jellyfin.org/docs/general/testing/)
  * [API Documentation](https://api.jellyfin.org)


  * [](https://jellyfin.org/)
  * Quick Start


On this page
# Quick Start
Welcome to the Jellyfin quick start guide! Jellyfin is a powerful open-source media server that lets you organize, stream, and access your personal media collection—from movies and TV shows to music and photos—on any device. To get started, you'll need to set up the server application, which acts as the central hub for serving your media. This guide will give a quick overview of the steps required to install and configure Jellyfin to get your media server up and running.
## Get started[​](https://jellyfin.org/docs/general/quick-start/#get-started "Direct link to Get started")
  1. [Install and launch Jellyfin](https://jellyfin.org/docs/general/installation) on the computer that will be your media server.
  2. [Complete the setup wizard](https://jellyfin.org/docs/general/post-install/setup-wizard) to create an admin account, add media, and adjust settings.
  3. Enjoy your media!


### (Optional) Extra credit[​](https://jellyfin.org/docs/general/quick-start/#optional-extra-credit "Direct link to \(Optional\) Extra credit")
  * [Install mobile, tv, or desktop clients.](https://jellyfin.org/downloads)
  * [Configure remote access.](https://jellyfin.org/docs/general/post-install/networking/#external-access)


[](https://github.com/jellyfin/jellyfin.org/edit/master/docs/general/quick-start.md)
[Previous Getting Help](https://jellyfin.org/docs/general/getting-help)[Next Installation](https://jellyfin.org/docs/general/installation/)
  * [Get started](https://jellyfin.org/docs/general/quick-start/#get-started)
    * [(Optional) Extra credit](https://jellyfin.org/docs/general/quick-start/#optional-extra-credit)


[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
