---
name: jellyfin-docs
description: Combined user, admin, and API documentation for Jellyfin.
source_url: https://jellyfin.org/docs/, https://api.jellyfin.org
categories: [Documentation, Knowledge Base, Reference]
tags: [docs, reference, jellyfin-docs, knowledge-base]
---

# Jellyfin Docs Documentation

Combined user, admin, and API documentation for Jellyfin.

**Original Sources**:
- [https://jellyfin.org/docs/](https://jellyfin.org/docs/)
- [https://api.jellyfin.org](https://api.jellyfin.org)

**Contains**: 33 markdown files with full folder structure.
*Last updated: February 27, 2026*

## 📚 Table of Contents

- [About Jellyfin](reference/about.md)
- [Backup and Restore](reference/administration_backup-and-restore.md)
- [Migrating](reference/administration_migrate.md)
- [Clients](reference/clients.md)
- [Jellyfin Community Standards](reference/community-standards.md)
- [Contact](reference/contact.md)
- [How to Contribute](reference/contribute.md)
- [Contributing to Jellyfin](reference/contributing.md)
- [Reporting Issues](reference/contributing_issues.md)
- [Welcome to the Jellyfin Documentation](reference/docs.md)
- [Downloads](reference/downloads.md)
- [Downloads](reference/downloads_clients.md)
- [Frequently Asked Questions](reference/faq.md)
- [Getting Help](reference/getting-help.md)
- [Index](reference/index.md)
- [Installation](reference/installation.md)
- [Manual Installation](reference/installation_advanced_manual.md)
- [Building from source](reference/installation_advanced_source.md)
- [Installation on Synology](reference/installation_advanced_synology.md)
- [TrueNAS SCALE](reference/installation_advanced_truenas.md)
- [Container](reference/installation_container.md)
- [Linux](reference/installation_linux.md)
- [macOS](reference/installation_macos.md)
- [Windows](reference/installation_windows.md)
- [Openapi Jellyfin Openapi Stable.Json](reference/openapi_jellyfin-openapi-stable.json.md)
- [Networking](reference/post-install_networking.md)
- [Monitoring](reference/post-install_networking_advanced_monitoring.md)
- [Hardware Acceleration](reference/post-install_transcoding_hardware-acceleration.md)
- [Posts](reference/posts.md)
- [Quick Start](reference/quick-start.md)
- [Plugins](reference/server_plugins.md)
- [Style Guides](reference/style-guides.md)
- [Testing Jellyfin](reference/testing.md)

## 🤖 Agent Usage Guide

- When the user asks anything about **Jellyfin Docs**, consult the reference files.
- Prefer exact quotes and direct links to the relevant file/section.
- The hierarchical TOC above makes navigation fast and intuitive.
- All images and assets are preserved so links work perfectly.
