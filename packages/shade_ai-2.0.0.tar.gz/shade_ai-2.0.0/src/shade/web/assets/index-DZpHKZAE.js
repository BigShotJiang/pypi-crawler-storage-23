(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))s(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const c of r.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&s(c)}).observe(document,{childList:!0,subtree:!0});function n(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(e){if(e.ep)return;e.ep=!0;const r=n(e);fetch(e.href,r)}})();const u=document.querySelector("#app");u.innerHTML=`
  <header>
    <div class="brand">
      <img src="/logo.png" alt="Shade Logo" onerror="this.style.display='none'">
    </div>
  </header>

  <div id="chat-wrapper" class="chat-wrapper">
    <div class="empty-state">
      <h1>Welcome to Shade</h1>
      <p>AI liberated and uncensored—how can I assist your unfiltered requests today?</p>
      <div id="model-info" class="model-badge">Loading model info...</div>
    </div>
  </div>

  <div class="input-container">
    <div class="box-wrapper">
      <textarea id="user-input" placeholder="Message Shade..." rows="1"></textarea>
      <button id="send-btn" class="send-button">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
      </button>
    </div>
  </div>
`;const a=document.querySelector("#chat-wrapper"),i=document.querySelector("#user-input"),p=document.querySelector("#send-btn");i.addEventListener("input",()=>{i.style.height="auto",i.style.height=i.scrollHeight+"px"});function d(t,o){const n=a.querySelector(".empty-state");n&&n.remove();const s=document.createElement("div");return s.className=`message ${t==="user"?"user-message":"bot-message"}`,s.textContent=o,a.appendChild(s),a.scrollTop=a.scrollHeight,s}async function l(){const t=i.value.trim();if(!t)return;i.value="",i.style.height="auto",d("user",t);const o=d("bot","");o.innerHTML=`
    <div class="typing">
      <span></span>
      <span></span>
      <span></span>
    </div>
  `;try{const n=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:t})});if(!n.ok)throw new Error("Server error");const s=await n.json();o.innerHTML=s.response}catch{o.innerHTML='<span style="color: #ef4444">Error: Could not connect to the Shade local server.</span>'}a.scrollTop=a.scrollHeight}p.addEventListener("click",l);i.addEventListener("keydown",t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),l())});async function f(){const t=document.querySelector("#model-info");try{const n=await(await fetch("/info")).json();t.textContent=`Active Model: ${n.model}`}catch{t.textContent="Model: Local Node"}}f();
