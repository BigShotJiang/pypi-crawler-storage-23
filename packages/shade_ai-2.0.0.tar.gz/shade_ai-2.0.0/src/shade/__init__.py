# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 Assem Sabry

"""Shade: Fully automatic censorship removal for language models."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("shade-ai")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = ["__version__"]
