# Quick Commit

Commits atomiques rapides sans review ni security check.

## Instructions

### Étape 0 — Vérification branche protégée

1. Identifier la branche courante : `git branch --show-current`
2. Vérifier si elle est protégée : `glab api projects/:id/protected_branches/:branch`
   - Si la commande retourne un résultat (status 200) → la branche **est protégée**
   - Si elle retourne une erreur 404 → la branche n'est **pas** protégée
3. **Si la branche est protégée** :
   - Analyser les changements (`git diff --stat`) pour générer un nom de branche descriptif
   - Créer et basculer sur une nouvelle branche : `git checkout -b <type>/<description-courte>`
   - Informer l'utilisateur : afficher la branche créée et expliquer pourquoi

### Étape 1 — Analyse des changements

1. `git status` et `git diff --stat` pour voir les changements
2. Regrouper par logique (feature, scope, type)

### Étape 2 — Commits

3. Pour chaque groupe: `git add` + `git commit` avec Conventional Commits

### Étape 3 — Push

4. Une fois tous les commits effectués, proposer à l'utilisateur de push (`git push`, avec `-u origin <branche>` si nouvelle branche)

### Étape 4 — Merge Request (si branche créée à l'étape 0)

5. Après le push, proposer de créer une merge request :
   ```bash
   glab mr create --title "<type>(scope): description" --description "<résumé des changements>" --target-branch <branche-originale> --no-editor
   ```
   **IMPORTANT** : Ne jamais utiliser `--fill` car ce flag ouvre un prompt interactif qui échoue dans Claude Code (pas de TTY).
6. Si la MR est créée, proposer de la merger : `glab mr merge <mr-id> --squash --remove-source-branch`

## Format

```
type(scope): description

Co-Authored-By: Claude <noreply@anthropic.com>
```

Types: feat, fix, refactor, test, docs, style, chore
