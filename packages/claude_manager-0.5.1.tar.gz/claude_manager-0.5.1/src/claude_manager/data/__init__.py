"""Embedded library data - agents, commands, hooks, and MCP server catalogs."""
