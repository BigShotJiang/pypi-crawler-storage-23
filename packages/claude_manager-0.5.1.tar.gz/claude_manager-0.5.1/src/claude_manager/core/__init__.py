"""Core module - business logic for claude-manager."""

from claude_manager.core.paths import ClaudePaths

__all__ = ["ClaudePaths"]
