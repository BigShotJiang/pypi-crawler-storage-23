"""Custom tools for the Claude Code analyzer."""
