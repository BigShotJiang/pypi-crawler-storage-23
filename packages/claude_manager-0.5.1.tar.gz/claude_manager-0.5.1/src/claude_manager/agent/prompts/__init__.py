"""Prompts for the Claude Code analyzer."""
