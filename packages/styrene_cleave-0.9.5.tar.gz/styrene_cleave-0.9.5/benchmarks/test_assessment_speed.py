"""Benchmark tests for assessment speed with various directive sizes."""

import time

import pytest

from cleave.core.assessment import assess_directive
from cleave.core.performance import clear_metrics, get_metrics


@pytest.mark.benchmark
def test_assessment_small_directive():
    """Benchmark assessment of small directive."""
    clear_metrics()

    directive = "Add user login"

    start = time.perf_counter()
    result = assess_directive(directive)
    elapsed = time.perf_counter() - start

    assert result is not None
    assert elapsed < 0.1  # Should be very fast

    metrics = get_metrics()
    print(f"\nSmall directive assessment: {elapsed:.6f}s")
    assert "assess_directive" in metrics


@pytest.mark.benchmark
def test_assessment_medium_directive():
    """Benchmark assessment of medium-sized directive."""
    clear_metrics()

    directive = """
    Implement a complete user authentication system with JWT tokens.
    Include login endpoint, registration, password hashing with bcrypt,
    token generation and validation middleware, protected routes,
    and user session management. Store users in PostgreSQL database.
    """

    start = time.perf_counter()
    result = assess_directive(directive)
    elapsed = time.perf_counter() - start

    assert result is not None
    assert elapsed < 0.5  # Should still be fast

    metrics = get_metrics()
    print(f"\nMedium directive assessment: {elapsed:.6f}s")
    assert "assess_directive" in metrics


@pytest.mark.benchmark
def test_assessment_large_directive():
    """Benchmark assessment of large directive."""
    clear_metrics()

    directive = """
    Build a complete full-stack e-commerce platform with the following features:

    Frontend (React):
    - Product catalog with search, filtering, and sorting
    - Shopping cart with local storage persistence
    - Checkout flow with Stripe integration
    - User authentication and profile management
    - Order history and tracking

    Backend (Django/FastAPI):
    - RESTful API for all frontend operations
    - JWT-based authentication
    - Product CRUD with admin interface
    - Order processing and payment handling
    - Inventory management
    - Email notifications for order confirmations

    Database (PostgreSQL):
    - User accounts and authentication
    - Product catalog with categories and tags
    - Orders and order items
    - Payment transactions
    - Inventory tracking

    Infrastructure:
    - Docker containerization
    - CI/CD pipeline
    - Database migrations
    - Caching with Redis
    - Background job processing with Celery
    - File uploads to S3
    """

    start = time.perf_counter()
    result = assess_directive(directive)
    elapsed = time.perf_counter() - start

    assert result is not None
    assert elapsed < 1.0  # Even large directives should be fast

    metrics = get_metrics()
    print(f"\nLarge directive assessment: {elapsed:.6f}s")
    assert "assess_directive" in metrics


@pytest.mark.benchmark
def test_assessment_repeated():
    """Benchmark repeated assessments (cache effects)."""
    clear_metrics()

    directive = "Add JWT authentication"

    iterations = 100
    start = time.perf_counter()

    for _ in range(iterations):
        assess_directive(directive)

    elapsed = time.perf_counter() - start
    avg_time = elapsed / iterations

    print(f"\n{iterations} assessments: {elapsed:.6f}s total, {avg_time:.6f}s avg")

    assert avg_time < 0.01  # Average should be under 10ms

    metrics = get_metrics()
    assert metrics["assess_directive"]["count"] == iterations
