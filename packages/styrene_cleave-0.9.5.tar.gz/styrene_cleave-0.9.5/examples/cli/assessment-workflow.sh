#!/usr/bin/env bash
# Assessment Workflow Example
# Demonstrates the full assessment pipeline for a complex directive

set -euo pipefail

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Cleave Assessment Workflow ===${NC}\n"

# Define the directive
DIRECTIVE="Implement real-time collaboration features with WebSocket support.
Users should see live cursors, text edits, and presence indicators.
Support conflict resolution for simultaneous edits. Add offline mode
with sync on reconnect. Include integration tests and load testing
for 100 concurrent users."

echo -e "${GREEN}Step 1: Probe the codebase${NC}"
echo "Generate context-aware questions based on existing code"
echo ""

cleave probe --directive "$DIRECTIVE"

echo -e "\n${GREEN}Step 2: Pattern matching${NC}"
echo "Check if directive matches known patterns"
echo ""

cleave match --directive "$DIRECTIVE"

echo -e "\n${GREEN}Step 3: Complexity assessment${NC}"
echo "Calculate complexity score and splitting recommendation"
echo ""

cleave assess --directive "$DIRECTIVE"

echo -e "\n${GREEN}Step 4: Assessment with permission inference${NC}"
echo "Identify required bash permissions upfront"
echo ""

cleave assess --directive "$DIRECTIVE" --infer-permissions

echo -e "\n${GREEN}Step 5: Check permissions gap${NC}"
echo "Compare inferred permissions with settings.local.json"
echo ""

cleave check-permissions --directive "$DIRECTIVE"

echo -e "\n${GREEN}Step 6: Review recommendations${NC}"
echo "Based on the assessment, decide whether to:"
echo "  - Execute directly (complexity <= threshold)"
echo "  - Cleave into 2-3 children (complexity > threshold)"
echo ""

echo -e "${YELLOW}TIP: Use --infer-permissions to enable fire-and-forget execution${NC}"
echo -e "${YELLOW}TIP: Review probe output to understand codebase context${NC}"
echo ""

echo -e "${BLUE}=== Assessment Complete ===${NC}"
