"""Tests for git worktree lifecycle (mocked subprocess)."""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cleave.orchestrator.errors import GitWorktreeError
from cleave.orchestrator.worktree import (
    create_worktree,
    ensure_clean_worktree,
    get_current_branch,
    remove_worktree,
)


def _mock_subprocess(returncode: int = 0, stdout: str = "", stderr: str = ""):
    """Create a mock asyncio.subprocess.Process."""
    proc = AsyncMock()
    proc.communicate = AsyncMock(
        return_value=(stdout.encode(), stderr.encode())
    )
    proc.returncode = returncode
    return proc


class TestGetCurrentBranch:
    def test_returns_branch_name(self) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess(stdout="main")
            result = asyncio.run(get_current_branch(Path("/repo")))
            assert result == "main"

    def test_raises_on_error(self) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess(returncode=1, stderr="not a repo")
            with pytest.raises(GitWorktreeError, match="not a repo"):
                asyncio.run(get_current_branch(Path("/repo")))


class TestEnsureCleanWorktree:
    def test_clean_passes(self) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess(stdout="")
            asyncio.run(ensure_clean_worktree(Path("/repo")))

    def test_dirty_raises(self) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess(stdout=" M src/main.py")
            with pytest.raises(GitWorktreeError, match="uncommitted"):
                asyncio.run(ensure_clean_worktree(Path("/repo")))


class TestCreateWorktree:
    def test_creates_worktree_and_returns_paths(self, tmp_path: Path) -> None:
        call_count = 0

        async def mock_exec(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            return _mock_subprocess()

        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec", side_effect=mock_exec):
            wt_path, branch = asyncio.run(
                create_worktree(tmp_path, "auth-core", "main", child_id=0)
            )
            assert branch == "cleave/auth-core-0"
            assert "auth-core-0" in str(wt_path)
            assert call_count >= 2  # branch -d + worktree add

    def test_sanitizes_label(self, tmp_path: Path) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess()
            wt_path, branch = asyncio.run(
                create_worktree(tmp_path, "Fix Auth/Login Bug #123", "main", child_id=1)
            )
            assert "/" not in branch.split("/", 1)[1]  # after cleave/ prefix
            assert "#" not in branch

    def test_empty_label_gets_fallback(self, tmp_path: Path) -> None:
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess()
            wt_path, branch = asyncio.run(
                create_worktree(tmp_path, "@#$%", "main", child_id=5)
            )
            assert branch == "cleave/child-5"

    def test_collision_prevention(self, tmp_path: Path) -> None:
        """Labels that sanitize identically get unique branches via child_id."""
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess()
            _, branch_a = asyncio.run(
                create_worktree(tmp_path, "foo!", "main", child_id=0)
            )
            _, branch_b = asyncio.run(
                create_worktree(tmp_path, "foo@", "main", child_id=1)
            )
            assert branch_a != branch_b


class TestRemoveWorktree:
    def test_removes_existing(self, tmp_path: Path) -> None:
        wt_path = tmp_path / ".cleave-worktrees" / "test"
        wt_path.mkdir(parents=True)
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess()
            asyncio.run(remove_worktree(tmp_path, wt_path))

    def test_handles_nonexistent(self, tmp_path: Path) -> None:
        wt_path = tmp_path / "nonexistent"
        with patch("cleave.orchestrator.worktree.asyncio.create_subprocess_exec") as mock_exec:
            mock_exec.return_value = _mock_subprocess()
            asyncio.run(remove_worktree(tmp_path, wt_path))  # Should not raise
