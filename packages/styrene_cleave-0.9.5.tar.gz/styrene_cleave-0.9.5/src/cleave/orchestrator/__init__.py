"""Cleave orchestrator — autonomous execution loop for cleave workspaces.

Public API:
    run(config)          → OrchestratorResult  (async)
    resume(workspace)    → OrchestratorResult  (async)
    run_sync(config)     → OrchestratorResult  (blocking)
    resume_sync(path)    → OrchestratorResult  (blocking)
    OrchestratorConfig   — run configuration
    OrchestratorResult   — run outcome
"""

from cleave.orchestrator.config import OrchestratorConfig
from cleave.orchestrator.runner import (
    OrchestratorResult,
    resume,
    resume_sync,
    run,
    run_sync,
)

__all__ = [
    "OrchestratorConfig",
    "OrchestratorResult",
    "resume",
    "resume_sync",
    "run",
    "run_sync",
]
