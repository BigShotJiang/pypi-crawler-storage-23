"""Core cleave algorithms and data structures."""
