//! Prefix placeholder detection

mod detector;

pub use detector::{detect_prefix_binary, detect_prefix_text};
