from itertools import product

import pytest
import torch
from compressed_tensors.quantization import (
    QuantizationArgs,
    QuantizationScheme,
    QuantizationStrategy,
)
from pydantic import ValidationError
from torch.nn import Linear
from torch.testing import assert_close

from llmcompressor.modifiers.awq import AWQMapping, AWQModifier
from llmcompressor.modifiers.awq.base import (
    get_lowest_common_ancestor_with_avoid,
)
from llmcompressor.modifiers.factory import ModifierFactory


@pytest.mark.unit
@pytest.mark.usefixtures("setup_modifier_factory")
def test_awq_is_registered():
    """Ensure AWQModifier is registered in ModifierFactory"""
    modifier = ModifierFactory.create(
        type_="AWQModifier",
        allow_experimental=False,
        allow_registered=True,
        scheme="W4A16_ASYM",
    )

    assert isinstance(modifier, AWQModifier), "AWQModifier not registered"


@pytest.mark.unit
def test_set_resolved_mappings():
    awq = AWQModifier(
        mappings=[
            AWQMapping(
                "re:.*input_layernorm",
                ["re:.*q_proj", "re:.*k_proj", "re:.*v_proj"],
            ),
            AWQMapping("re:.*v_proj", ["re:.*o_proj"]),
            AWQMapping(
                "re:.*up_proj",
                ["re:.*down_proj"],
            ),
        ],
        scheme="W4A16_ASYM",
    )
    self_attn = torch.nn.ModuleDict(
        {
            "q_proj": Linear(4, 4),
            "k_proj": Linear(4, 4),
            "v_proj": Linear(4, 4),
            "o_proj": Linear(4, 4),
        }
    )
    mlp = torch.nn.ModuleDict(
        {
            "experts": torch.nn.ModuleList(
                [
                    torch.nn.ModuleDict(
                        {
                            "gate_proj": Linear(4, 2),
                            "up_proj": Linear(4, 2),
                            "down_proj": Linear(2, 4),
                        }
                    )
                    for _ in range(3)
                ]
            )
        }
    )
    model = torch.nn.ModuleDict(
        {
            "decoder": torch.nn.ModuleDict(
                {
                    "self_attn": self_attn,
                    "input_layernorm": torch.nn.LayerNorm(4),
                    "mlp": mlp,
                }
            )
        }
    )
    awq._set_resolved_mappings(model)
    for mapping in awq._resolved_mappings:
        if "input_layernorm" in mapping.smooth_name:
            assert set(mapping.balance_names) == {
                "decoder.self_attn.q_proj",
                "decoder.self_attn.k_proj",
                "decoder.self_attn.v_proj",
            }
            assert set(mapping.balance_layers) == {
                self_attn.q_proj,
                self_attn.k_proj,
                self_attn.v_proj,
            }
            assert mapping.parent_name == "decoder.self_attn"
            assert mapping.parent == self_attn
        if "self_attn.v_proj" in mapping.smooth_name:
            assert set(mapping.balance_names) == {"decoder.self_attn.o_proj"}
            assert mapping.parent_name == "decoder.self_attn.o_proj"
        if "mlp.experts" in mapping.smooth_name and "up_proj" in mapping.smooth_name:
            expert_idx = mapping.smooth_name.split(".")[-2]
            expected_down_proj = f"decoder.mlp.experts.{expert_idx}.down_proj"
            assert set(mapping.balance_names) == {expected_down_proj}
            assert mapping.parent_name == expected_down_proj
            assert mapping.parent == mlp["experts"][int(expert_idx)]["down_proj"]

    awq = AWQModifier(
        mappings=[
            # make sure we exclude case where o_proj/v_proj shapes are mismatched
            AWQMapping("re:.*v_proj", ["re:.*o_proj"]),
            # make sure we exclude mapping if any balance layers are skipped
            AWQMapping("re:.*v_proj", ["re:.*z_proj", "re:.*o_proj"]),
        ],
        scheme="W4A16_ASYM",
    )
    model = torch.nn.ModuleDict(
        {
            "decoder": torch.nn.ModuleDict(
                {
                    "self_attn": torch.nn.ModuleDict(
                        {
                            "q_proj": Linear(4, 2),
                            "k_proj": Linear(4, 2),
                            "v_proj": Linear(4, 2),
                            "z_proj": Linear(2, 4),
                            "o_proj": Linear(4, 4),
                        }
                    )
                }
            )
        }
    )
    awq._set_resolved_mappings(model)
    if len(awq._resolved_mappings) > 0:
        assert all(
            "o_proj" not in name for name in awq._resolved_mappings[0].balance_names
        ), "should have skipped v->o mapping because o is incompatible"
        assert all(
            "z_proj" not in name for name in awq._resolved_mappings[0].balance_names
        ), (
            "should have skipped v->[z,o] mapping because o is incompatible even though"
            "z is compatible"
        )
    assert len(awq._resolved_mappings) == 0


@pytest.mark.unit
def test_validate():
    AWQModifier(scheme="W4A16", duo_scaling="both")
    with pytest.raises(ValidationError):
        AWQModifier(scheme="W4A16", duo_scaling="Both")
    with pytest.raises(ValidationError):
        AWQModifier(scheme="W4A16", duo_scaling="x")


@pytest.mark.unit
def test_ignore_behavior():
    """Test that mapping is skipped when NO layers are targeted for quantization"""
    # Test case 1: Some balance layers ignored but at least one is targeted
    # Mapping should proceed
    awq = AWQModifier(
        mappings=[
            AWQMapping(
                "re:.*input_layernorm",
                ["re:.*q_proj", "re:.*k_proj", "re:.*v_proj"],
            ),
        ],
        ignore=["re:.*q_proj", "re:.*k_proj"],  # Only 2 of 3 balance layers ignored
        scheme="W4A16_ASYM",
    )

    self_attn = torch.nn.ModuleDict(
        {
            "q_proj": Linear(4, 4),
            "k_proj": Linear(4, 4),
            "v_proj": Linear(4, 4),
        }
    )
    model = torch.nn.ModuleDict(
        {
            "decoder": torch.nn.ModuleDict(
                {
                    "self_attn": self_attn,
                    "input_layernorm": torch.nn.LayerNorm(4),
                }
            )
        }
    )

    awq._set_resolved_mappings(model)

    # Mapping should exist because v_proj is targeted for quantization
    assert len(awq._resolved_mappings) == 1

    # Test case 2: All Linear layers ignored - mapping should be skipped
    # because no layers are targeted for quantization
    awq2 = AWQModifier(
        mappings=[
            AWQMapping(
                "re:.*input_layernorm",
                ["re:.*q_proj", "re:.*k_proj", "re:.*v_proj"],
            ),
        ],
        ignore=["re:.*q_proj", "re:.*k_proj", "re:.*v_proj"],
        scheme="W4A16_ASYM",
    )

    awq2._set_resolved_mappings(model)

    # Mapping should be skipped because no layers are targeted for quantization
    # (input_layernorm is LayerNorm, not Linear, so not targeted anyway)
    assert len(awq2._resolved_mappings) == 0


@pytest.mark.unit
def test_moe_multiple_balance_layers():
    """Test AWQ mapping with multiple balance layers in MoE architecture"""
    awq = AWQModifier(
        mappings=[
            # Map input_layernorm to multiple experts' gate_proj and up_proj
            AWQMapping(
                "re:.*input_layernorm",
                ["re:.*gate_proj", "re:.*up_proj"],
            ),
        ],
        scheme="W4A16_ASYM",
    )

    # Create a simplified MoE model structure
    mlp = torch.nn.ModuleDict(
        {
            "experts": torch.nn.ModuleList(
                [
                    torch.nn.ModuleDict(
                        {
                            "gate_proj": Linear(4, 4),
                            "up_proj": Linear(4, 4),
                            "down_proj": Linear(4, 4),
                        }
                    )
                    for _ in range(2)
                ]
            )
        }
    )
    model = torch.nn.ModuleDict(
        {
            "layer": torch.nn.ModuleDict(
                {
                    "input_layernorm": torch.nn.LayerNorm(4),
                    "mlp": mlp,
                }
            )
        }
    )

    awq._set_resolved_mappings(model)

    # Should have one mapping for input_layernorm
    assert len(awq._resolved_mappings) == 1
    mapping = awq._resolved_mappings[0]

    # Should map to all gate_proj and up_proj across all experts
    expected_balance_names = {
        "layer.mlp.experts.0.gate_proj",
        "layer.mlp.experts.0.up_proj",
        "layer.mlp.experts.1.gate_proj",
        "layer.mlp.experts.1.up_proj",
    }
    assert set(mapping.balance_names) == expected_balance_names

    parent_name, parent = get_lowest_common_ancestor_with_avoid(
        ["embed_tokens", "decoder.self_attn.v_proj"], model
    )
    assert parent_name == "" and parent == model


@pytest.mark.unit
def test_qwen3_next_moe_with_shared_expert():
    """Test AWQ mapping for Qwen3Next architecture with shared_expert.

    Qwen3Next includes a shared_expert in addition to the MoE experts.
    This test verifies that the mapping correctly resolves both experts
    and shared_expert projections.
    """
    awq = AWQModifier(
        mappings=[
            AWQMapping(
                "re:.*post_attention_layernorm$",
                [
                    "re:.*mlp.experts.*.gate_proj$",
                    "re:.*mlp.experts.*.up_proj$",
                    "re:.*mlp.shared_expert.gate_proj$",
                    "re:.*mlp.shared_expert.up_proj$",
                ],
            ),
        ],
        scheme="W4A16_ASYM",
    )

    # Create a Qwen3Next-like MoE model structure with shared_expert
    mlp = torch.nn.ModuleDict(
        {
            "experts": torch.nn.ModuleList(
                [
                    torch.nn.ModuleDict(
                        {
                            "gate_proj": Linear(4, 4),
                            "up_proj": Linear(4, 4),
                            "down_proj": Linear(4, 4),
                        }
                    )
                    for _ in range(2)
                ]
            ),
            "shared_expert": torch.nn.ModuleDict(
                {
                    "gate_proj": Linear(4, 4),
                    "up_proj": Linear(4, 4),
                    "down_proj": Linear(4, 4),
                }
            ),
        }
    )
    model = torch.nn.ModuleDict(
        {
            "layer": torch.nn.ModuleDict(
                {
                    "post_attention_layernorm": torch.nn.LayerNorm(4),
                    "mlp": mlp,
                }
            )
        }
    )

    awq._set_resolved_mappings(model)

    # Should have one mapping for post_attention_layernorm
    assert len(awq._resolved_mappings) == 1
    mapping = awq._resolved_mappings[0]

    # Should map to all gate_proj and up_proj across experts AND shared_expert
    expected_balance_names = {
        "layer.mlp.experts.0.gate_proj",
        "layer.mlp.experts.0.up_proj",
        "layer.mlp.experts.1.gate_proj",
        "layer.mlp.experts.1.up_proj",
        "layer.mlp.shared_expert.gate_proj",
        "layer.mlp.shared_expert.up_proj",
    }
    assert set(mapping.balance_names) == expected_balance_names


@pytest.mark.unit
def test_qwen3_next_hybrid_attention():
    """Test AWQ mapping for Qwen3Next hybrid attention architecture.

    Qwen3Next has two attention types:
    - self_attn: standard attention with q_proj, k_proj, v_proj, o_proj
    - linear_attn: Gated DeltaNet with in_proj_qkvz, in_proj_ba, norm, out_proj

    This test verifies that the mapping correctly resolves both attention types.
    Each attention type needs separate mappings for proper layer grouping.
    """
    awq = AWQModifier(
        mappings=[
            # self_attn mappings (layer 1 has self_attn)
            # Use layer-specific pattern since each mapping must match exactly one
            # smooth_layer
            AWQMapping(
                "re:.*layers\\.1\\.input_layernorm$",
                [
                    "re:.*self_attn.q_proj$",
                    "re:.*self_attn.k_proj$",
                    "re:.*self_attn.v_proj$",
                ],
            ),
            AWQMapping("re:.*self_attn.v_proj$", ["re:.*self_attn.o_proj$"]),
            # linear_attn mappings (layer 0 has linear_attn)
            AWQMapping(
                "re:.*layers\\.0\\.input_layernorm$",
                ["re:.*linear_attn.in_proj_qkvz$", "re:.*linear_attn.in_proj_ba$"],
            ),
            AWQMapping("re:.*linear_attn.norm$", ["re:.*linear_attn.out_proj$"]),
        ],
        scheme="W4A16_ASYM",
    )

    # Create a Qwen3Next-like model with both self_attn and linear_attn layers
    # Layer 0: linear_attn
    linear_attn_layer = torch.nn.ModuleDict(
        {
            "input_layernorm": torch.nn.LayerNorm(4),
            "linear_attn": torch.nn.ModuleDict(
                {
                    "in_proj_qkvz": Linear(4, 16),
                    "in_proj_ba": Linear(4, 4),
                    "norm": torch.nn.LayerNorm(4),
                    "out_proj": Linear(4, 4),
                }
            ),
        }
    )

    # Layer 1: self_attn
    self_attn_layer = torch.nn.ModuleDict(
        {
            "input_layernorm": torch.nn.LayerNorm(4),
            "self_attn": torch.nn.ModuleDict(
                {
                    "q_proj": Linear(4, 4),
                    "k_proj": Linear(4, 4),
                    "v_proj": Linear(4, 4),
                    "o_proj": Linear(4, 4),
                }
            ),
        }
    )

    model = torch.nn.ModuleDict(
        {
            "layers": torch.nn.ModuleList([linear_attn_layer, self_attn_layer]),
        }
    )

    awq._set_resolved_mappings(model)

    # Should have 4 mappings:
    # 1. layer 0 input_layernorm -> linear_attn projections
    # 2. layer 0 linear_attn.norm -> linear_attn.out_proj
    # 3. layer 1 input_layernorm -> self_attn projections
    # 4. layer 1 self_attn.v_proj -> self_attn.o_proj
    assert len(awq._resolved_mappings) == 4

    # Check linear_attn input mapping
    linear_input_mapping = next(
        m for m in awq._resolved_mappings if m.smooth_name == "layers.0.input_layernorm"
    )
    assert set(linear_input_mapping.balance_names) == {
        "layers.0.linear_attn.in_proj_qkvz",
        "layers.0.linear_attn.in_proj_ba",
    }

    # Check linear_attn output mapping
    linear_output_mapping = next(
        m
        for m in awq._resolved_mappings
        if m.smooth_name == "layers.0.linear_attn.norm"
    )
    assert linear_output_mapping.balance_names == ["layers.0.linear_attn.out_proj"]

    # Check self_attn input mapping
    self_input_mapping = next(
        m for m in awq._resolved_mappings if m.smooth_name == "layers.1.input_layernorm"
    )
    assert set(self_input_mapping.balance_names) == {
        "layers.1.self_attn.q_proj",
        "layers.1.self_attn.k_proj",
        "layers.1.self_attn.v_proj",
    }

    # Check self_attn output mapping
    self_output_mapping = next(
        m
        for m in awq._resolved_mappings
        if m.smooth_name == "layers.1.self_attn.v_proj"
    )
    assert self_output_mapping.balance_names == ["layers.1.self_attn.o_proj"]


def _auto_awq_normalize(layers: list[torch.nn.Module], group_size) -> torch.Tensor:
    """
    Original AutoAwq implementation (need to call .mean(0) to get normalized layer
    means
    """
    # [STEP 1]: Compute per-channel mean of normalised weights
    # All layer weights are concatted together
    weight = torch.cat([bl.weight for bl in layers], dim=0)
    orig_shape = weight.shape
    # The weights are reshaped to be organised by quantization group
    if group_size is not None:
        weight = weight.view(-1, group_size)
    # Calculates the relative magnitude of the weights within
    # each of the quantization groups, and rescales each group
    # individually so that each group has weights on a 0-1 scale.
    weight.abs_()
    weight.div_(weight.amax(dim=1, keepdim=True) + 1e-6)
    return weight.view(orig_shape)


@torch.no_grad
@pytest.mark.unit
@pytest.mark.parametrize(
    "n_balance_layers, n_input_features, strategy, group_size",
    [
        (5, 32, QuantizationStrategy.CHANNEL, None),  # channel
        (4, 40, QuantizationStrategy.GROUP, 10),  # group
        (4, 40, QuantizationStrategy.TENSOR, None),  # tensor
        (3, 64, QuantizationStrategy.TENSOR_GROUP, 16),  # tensor_group
    ],
)
def test_compute_layer_means(n_balance_layers, n_input_features, strategy, group_size):
    """
    Confirm our logic to compute duo_scaling layer means via a running tally
    matches the original memory-intensive AutoAWQ implementation, which concats
    all balance layers into a single tensor before reducing to mean
    Large models were prone to fail at this step.
    """
    balance_layers = [
        torch.nn.Linear(n_input_features, 10) for _ in range(n_balance_layers)
    ]

    for balance_layer in balance_layers:
        setattr(
            balance_layer,
            "quantization_scheme",
            QuantizationScheme(
                targets=["Linear"],
                weights=QuantizationArgs(
                    strategy=strategy,
                    group_size=group_size,
                ),
            ),
        )

    match strategy:
        case QuantizationStrategy.GROUP | QuantizationStrategy.TENSOR_GROUP:
            group_size_arg = group_size
        case QuantizationStrategy.TENSOR:
            group_size_arg = n_input_features * 10
        case _:
            group_size_arg = None

    auto_awq_means = _auto_awq_normalize(balance_layers, group_size_arg).mean(0)

    llmc_awq_means = AWQModifier._compute_layer_means(balance_layers).to(
        auto_awq_means.dtype
    )

    assert_close(auto_awq_means, llmc_awq_means)


@pytest.mark.unit
@torch.no_grad
def test_compute_layer_means_does_not_modify_weights():
    """
    Test that _compute_layer_means does not modify the original layer weights.
    This is a regression test for a bug where in-place operations (abs_, div_)
    were modifying the original weights.
    """
    # Create test layers with known weight values
    n_layers = 3
    n_input_features = 16
    layers = [torch.nn.Linear(n_input_features, 8) for _ in range(n_layers)]

    # Set up quantization scheme for channel-wise quantization
    for layer in layers:
        setattr(
            layer,
            "quantization_scheme",
            QuantizationScheme(
                targets=["Linear"],
                weights=QuantizationArgs(
                    strategy=QuantizationStrategy.CHANNEL,
                ),
            ),
        )

    # Store copies of original weights before calling _compute_layer_means
    original_weights = [layer.weight.clone() for layer in layers]

    # Call _compute_layer_means which should NOT modify the original weights
    AWQModifier._compute_layer_means(layers)

    # Verify that the original weights remain unchanged
    for i, layer in enumerate(layers):
        assert_close(
            layer.weight,
            original_weights[i],
            msg=f"Layer {i} weight was modified by _compute_layer_means",
        )


@pytest.mark.unit
@pytest.mark.parametrize(
    "rows, cols, block_height, block_width",
    [
        (
            32,
            256,
            4,
            8,
        ),
        (
            4,
            3,
            2,
            1,
        ),
        (
            10,
            10,
            10,
            10,
        ),
        (
            512,
            256,
            128,
            128,
        ),
    ],
)
@torch.no_grad
def test_block_strategy_compute_layer_means(rows, cols, block_height, block_width):
    """
    Confirm our logic to compute layer means works for BLOCK quantization
    """
    lin = torch.nn.Linear(cols, rows)
    setattr(
        lin,
        "quantization_scheme",
        QuantizationScheme(
            targets=["Linear"],
            weights=QuantizationArgs(
                strategy=QuantizationStrategy.BLOCK,
                block_structure=[block_height, block_width],
            ),
        ),
    )
    # main
    llmc_awq_means = AWQModifier._compute_layer_means([lin])

    # ref
    num_heights = rows // block_height
    num_widths = cols // block_width

    ref_weight = torch.zeros_like(lin.weight)
    with torch.no_grad():
        for i, j in product(range(num_heights), range(num_widths)):
            block = lin.weight[
                i * block_height : (i + 1) * block_height,
                j * block_width : (j + 1) * block_width,
            ].abs()
            block = block / (block.max() + 1e-6)
            ref_weight[
                i * block_height : (i + 1) * block_height,
                j * block_width : (j + 1) * block_width,
            ] = block
    ref_means = ref_weight.sum(0, dtype=torch.float64) / ref_weight.size(0)

    # auto awq
    # we first reshape the weight such that it is effectively per-channel quantization
    # so that we can compare to the existing _auto_awq_normalize function
    orig_shape = lin.weight.shape
    q_args = lin.quantization_scheme.weights
    block_height, block_width = q_args.block_structure
    lin.weight.data = (  # (row, col)
        lin.weight.unflatten(0, (-1, block_height))  # = (num_H*block_H, num_W*block_W)
        .unflatten(-1, (-1, block_width))
        .transpose(1, 2)  # ↳ (num_H, num_W, block_H, block_W)
    )
    auto_awq_means = (
        _auto_awq_normalize([lin], block_height * block_width)
        .transpose(1, 2)
        .reshape(orig_shape)
        .mean(0)
        .to(llmc_awq_means.dtype)
    )

    # check
    assert_close(llmc_awq_means, ref_means, atol=1e-5, rtol=1e-5)
    assert_close(llmc_awq_means, auto_awq_means, atol=1e-5, rtol=1e-5)
