# Llama 4

Quantization examples for Meta's Llama 4 Scout multimodal model.

- [FP8 Example](fp8-example.md)