# Mistral Large 3

Quantization examples for Mistral's 675B parameter model.

- [FP8 Example](fp8-example.md)