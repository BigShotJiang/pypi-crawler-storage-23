# Kimi-K2

Quantization examples for the Kimi-K2 Thinking model.

- [FP8 Example](fp8-example.md)