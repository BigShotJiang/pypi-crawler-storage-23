"""Voice session management using a pluggable VoiceProvider.

Handles the full lifecycle: connect, configure, send/receive audio,
dispatch tool calls, and disconnect. Works with any VoiceProvider
implementation (OpenAI Realtime, Gemini Live, etc.).

Includes automatic reconnection with exponential backoff and push-to-talk.

Manages an InstanceRegistry for multiple agent instances. When an agent
finishes or reports progress, the result is injected into the conversation
via the voice provider so ChatGPT can summarize it to the user.
"""

import asyncio
import logging
from pathlib import Path
from typing import Any, Callable

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.config import RealtimeSettings, get_system_instructions
from voice_vibecoder.instances import InstanceRegistry, InstanceStatus
from voice_vibecoder.tools import (
    get_tool_definitions,
    handle_tool_call,
    handle_tool_call_async,
    configure as configure_tools,
)
from voice_vibecoder.tools.dispatch import _external_tool_handlers
from voice_vibecoder.voice_providers import (
    AudioCommitted,
    AudioDelta,
    FunctionCall,
    ResponseCreated,
    ResponseDone,
    SpeechStarted,
    SpeechStopped,
    TranscriptDelta,
    TranscriptDone,
    UserTranscript,
    VADSettings,
    VoiceError,
    VoiceEvent,
    VoiceProvider,
)

logger = logging.getLogger(__name__)

RECONNECT_MAX_ATTEMPTS = 5
RECONNECT_DELAYS = [2, 4, 8, 16, 30]


class RealtimeSession:
    """Manages a single voice session with multi-instance support."""

    def __init__(
        self,
        provider: VoiceProvider,
        settings: RealtimeSettings,
        repo_root: Path,
        voice_config: VoiceConfig | None = None,
        user_email: str | None = None,
        user_jwt: str | None = None,
        on_audio: Callable[[str], None] | None = None,
        on_transcript: Callable[[str, str], None] | None = None,
        on_status: Callable[[str], None] | None = None,
        on_tool_call: Callable[[str, dict], None] | None = None,
        on_agent_output: Callable[[str, str], None] | None = None,
        on_instance_status: Callable[[str, InstanceStatus], None] | None = None,
        on_interrupt: Callable[[], None] | None = None,
        on_ui_command: Callable[[str, str, Any], None] | None = None,
    ) -> None:
        self._provider = provider
        self._settings = settings
        self._repo_root = repo_root
        self._voice_config = voice_config
        self._user_email = user_email
        self._user_jwt = user_jwt
        self._on_audio = on_audio
        self._on_transcript = on_transcript
        self._on_status = on_status
        self._on_tool_call = on_tool_call
        self._on_instance_status = on_instance_status
        self._on_interrupt = on_interrupt
        self._on_ui_command = on_ui_command
        self._running = False
        self._assistant_transcript = ""
        self._response_pending = False
        self._fallback_task: asyncio.Task | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

        # Create instance registry and wire callbacks
        self._registry = InstanceRegistry(user_email=user_email, user_jwt=user_jwt)
        self._registry.repo_root = str(repo_root) if repo_root else None
        self._registry.on_output = self._on_registry_output
        self._registry.on_task_complete = self._on_agent_task_complete
        self._registry.on_progress = self._on_agent_progress
        self._registry.on_status_change = self._on_registry_status_change
        self._registry.on_question = self._on_agent_question
        self._registry.on_ui_command = self._on_registry_ui_command
        self._registry.on_instance_change = self._on_instance_change

        # Store the output callback for routing
        self._on_agent_output = on_agent_output

        configure_tools(
            registry=self._registry,
            repo_root=repo_root,
            agent_timeout=settings.agent_timeout,
            permission_mode=settings.permission_mode,
            enabled_agents=settings.enabled_agents,
            user_jwt=user_jwt,
            voice_config=voice_config,
        )

    @property
    def registry(self) -> InstanceRegistry:
        return self._registry

    @property
    def connected(self) -> bool:
        return self._running

    async def connect(self) -> None:
        await self._provider.connect()
        self._running = True
        self._loop = asyncio.get_event_loop()
        if self._on_status:
            self._on_status("connected")

    async def configure_session(self) -> None:
        from voice_vibecoder.tools.agent_task import warm_mcp_cache
        from voice_vibecoder.tools.handlers import get_active_instances_text, get_startup_context

        # Pre-warm MCP server cache so first agent spawn doesn't pay the cost
        warm_mcp_cache()

        s = self._settings
        overrides = self._voice_config.system_instructions if self._voice_config else None
        instructions = get_system_instructions(
            s.language, context=get_startup_context(),
            overrides=overrides, enabled_agents=s.enabled_agents,
            active_instances=get_active_instances_text(),
        )

        vad: VADSettings | None = None
        if s.input_mode != "ptt":
            vad = VADSettings(
                threshold=s.vad_threshold,
                silence_duration_ms=s.silence_duration_ms,
                prefix_padding_ms=s.prefix_padding_ms,
            )

        await self._provider.configure(
            instructions=instructions,
            voice=s.voice,
            tools=get_tool_definitions(),
            vad=vad,
        )

    async def send_audio(self, base64_chunk: str) -> None:
        if not self._running:
            return
        await self._provider.send_audio(base64_chunk)

    async def commit_audio(self) -> None:
        if not self._running:
            return
        await self._provider.commit_audio()

    async def inject_user_message(self, text: str) -> None:
        """Inject a text message as if the user spoke it.

        This allows text input to work alongside voice input. The message
        is sent to the voice provider and triggers a response.

        Args:
            text: The user's text message
        """
        if not self._running:
            return

        logger.info("Injecting user text message: %s", text[:50])

        # Add to transcript (same as voice input)
        if self._on_transcript:
            self._on_transcript("user", text)

        # Store in registry for state persistence
        self._registry.add_transcript("user", text)

        # Send to voice provider to generate response
        await self._provider.inject_message(text)

    async def handle_messages(self) -> None:
        try:
            async for event in self._provider.listen():
                if not self._running:
                    break
                try:
                    await self._handle_event(event)
                except Exception as e:
                    logger.error("Error handling event: %s", e, exc_info=True)
        except Exception as e:
            if self._running:
                logger.warning("Voice connection lost: %s", e)
                await self._attempt_reconnect()
            else:
                if self._on_status:
                    self._on_status("disconnected")

    async def _handle_event(self, event: VoiceEvent) -> None:
        match event:
            case AudioDelta(delta=d):
                if self._on_audio:
                    self._on_audio(d)

            case TranscriptDelta(delta=d):
                self._assistant_transcript += d

            case TranscriptDone(transcript=t):
                final = t or self._assistant_transcript
                if final:
                    self._registry.add_transcript("assistant", final)
                    if self._on_transcript:
                        self._on_transcript("assistant", final)
                self._assistant_transcript = ""

            case UserTranscript(transcript=t):
                if t:
                    self._registry.add_transcript("user", t)
                    if self._on_transcript:
                        self._on_transcript("user", t)

            case SpeechStarted():
                await self._provider.cancel_response()
                if self._on_interrupt:
                    self._on_interrupt()
                if self._on_status:
                    self._on_status("listening")

            case SpeechStopped():
                if self._on_status:
                    self._on_status("processing")

            case AudioCommitted():
                self._response_pending = True
                self._start_fallback()

            case ResponseCreated():
                self._response_pending = False
                self._cancel_fallback()

            case FunctionCall(call_id=cid, name=n, arguments=a):
                await self._handle_function_call(cid, n, a)

            case ResponseDone():
                if self._on_status:
                    self._on_status("ready")

            case VoiceError(message=m, is_ignorable=ig):
                if not ig:
                    logger.error("Voice error: %s", m)
                    if self._on_status:
                        self._on_status(f"error: {m}")

    async def _attempt_reconnect(self) -> None:
        for attempt in range(RECONNECT_MAX_ATTEMPTS):
            delay = RECONNECT_DELAYS[min(attempt, len(RECONNECT_DELAYS) - 1)]
            if self._on_status:
                self._on_status(f"reconnecting ({attempt + 1}/{RECONNECT_MAX_ATTEMPTS})")
            await asyncio.sleep(delay)
            if not self._running:
                return
            try:
                await self._provider.connect()
                await self.configure_session()
                if self._on_status:
                    self._on_status("ready")
                await self.handle_messages()
                return
            except Exception as e:
                logger.warning("Reconnect attempt %d failed: %s", attempt + 1, e)
        if self._on_status:
            self._on_status("disconnected")
        self._running = False

    async def disconnect(self) -> None:
        self._running = False
        await self._provider.disconnect()
        if self._on_status:
            self._on_status("disconnected")

    # -- Registry callbacks (called from background threads) --

    def _on_registry_output(self, instance_id: str, line: str) -> None:
        if self._on_agent_output:
            self._on_agent_output(instance_id, line)

    def _on_registry_status_change(self, instance_id: str, status: InstanceStatus) -> None:
        if self._on_instance_status:
            self._on_instance_status(instance_id, status)

    def _on_registry_ui_command(self, instance_id: str, action: str, data: Any) -> None:
        if self._on_ui_command:
            self._on_ui_command(instance_id, action, data)

    def _on_instance_change(self) -> None:
        if self._loop and self._running:
            asyncio.run_coroutine_threadsafe(self._refresh_instructions(), self._loop)

    async def _refresh_instructions(self) -> None:
        from voice_vibecoder.tools.handlers import get_active_instances_text, get_startup_context

        overrides = self._voice_config.system_instructions if self._voice_config else None
        instructions = get_system_instructions(
            self._settings.language, context=get_startup_context(),
            overrides=overrides, enabled_agents=self._settings.enabled_agents,
            active_instances=get_active_instances_text(),
        )
        try:
            await self._provider.update_session(instructions=instructions)
        except Exception as e:
            logger.error("Failed to refresh instructions: %s", e)

    # -- Agent background task completion --

    def _on_agent_task_complete(self, instance_id: str, result: str) -> None:
        logger.info("Agent task complete [%s]: %s", instance_id, result[:500])
        if self._registry and self._registry.on_output:
            is_error = any(kw in result.lower() for kw in ("error", "failed", "cancelled"))
            prefix = "text:[ERROR]" if is_error else "text:[DONE]"
            # Show only the first line as summary — full result was already streamed
            first_line = result.strip().split("\n", 1)[0][:120]
            self._registry.on_output(instance_id, f"{prefix} {first_line}")
        if self._loop and self._running:
            inst = self._registry.get_by_id(instance_id)
            display_key = inst.display_key if inst else "unknown"
            agent_type = inst.agent_type if inst else "claude"
            asyncio.run_coroutine_threadsafe(
                self._inject_agent_result(display_key, result, agent_type), self._loop
            )

    async def _inject_agent_result(self, display_key: str, result: str, agent_type: str = "claude") -> None:
        if not self._running:
            return
        from voice_vibecoder.code_providers.registry import get_agent
        agent_label = get_agent(agent_type).label
        system_text = f"{agent_label} finished on '{display_key}':\n\n{result}"
        try:
            await self._provider.inject_message(system_text)
        except Exception as e:
            logger.error("Failed to inject agent result: %s", e)
        if self._on_status:
            self._on_status("responding")

    # -- Agent background progress updates --

    def _on_agent_progress(self, instance_id: str, progress: str) -> None:
        pass  # Progress is routed via on_output — no voice injection needed

    # -- Agent interactive tool questions --

    def _on_agent_question(self, instance_id: str, question_data: dict) -> None:
        if self._loop and self._running:
            inst = self._registry.get_by_id(instance_id)
            display_key = inst.display_key if inst else "unknown"
            agent_type = inst.agent_type if inst else "claude"
            asyncio.run_coroutine_threadsafe(
                self._inject_agent_question(display_key, question_data, agent_type),
                self._loop,
            )

    async def _inject_agent_question(
        self, display_key: str, question_data: dict, agent_type: str = "claude",
    ) -> None:
        if not self._running:
            return

        from voice_vibecoder.code_providers.registry import get_agent
        label = get_agent(agent_type).label
        formatted = question_data.get("formatted", "The agent has a question.")
        tool = question_data.get("tool", "")

        if tool == "EnterPlanMode":
            system_text = (
                f"{label} on '{display_key}' wants to plan first. Should it plan or just implement?"
            )
        elif tool == "ExitPlanMode":
            system_text = (
                f"{label} on '{display_key}' has a plan ready. "
                "Ask the user if the agent should proceed with the implementation. "
                "Use answer_agent_question to forward their response."
            )
        else:
            system_text = f"{label} on '{display_key}' is asking:\n\n{formatted}"

        try:
            await self._provider.inject_message(system_text)
        except Exception as e:
            logger.error("Failed to inject agent question: %s", e)

    # -- Fallback timer --

    def _start_fallback(self) -> None:
        self._cancel_fallback()
        self._fallback_task = asyncio.create_task(self._fallback_response_create())

    def _cancel_fallback(self) -> None:
        if self._fallback_task and not self._fallback_task.done():
            self._fallback_task.cancel()
            self._fallback_task = None

    async def _fallback_response_create(self) -> None:
        try:
            await asyncio.sleep(1.5)
            if self._response_pending and self._running:
                logger.info("Fallback: sending response.create (server didn't auto-create)")
                await self._provider.request_response()
                self._response_pending = False
        except asyncio.CancelledError:
            pass

    # -- Function call handling --

    # Tools that might do slow I/O (git subprocess, diff generation)
    _SLOW_TOOLS = {"show_diff", "list_branches", "delete_worktree"}

    async def _handle_function_call(self, call_id: str, name: str, arguments: dict) -> None:
        if self._on_tool_call:
            self._on_tool_call(name, arguments)

        if self._on_status:
            self._on_status(f"running: {name}")

        try:
            if name in _external_tool_handlers:
                # External tools are always async — pass user JWT for OBO flows
                result = await handle_tool_call_async(name, arguments, self._user_jwt)
            elif name in self._SLOW_TOOLS:
                # Run slow I/O tools in executor to avoid blocking
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, handle_tool_call, name, arguments)
            else:
                # Sync tools can run directly
                result = handle_tool_call(name, arguments)
        except Exception as e:
            logger.error("Tool call %s raised: %s", name, e, exc_info=True)
            result = f"Error executing {name}: {e}"

        if self._on_status:
            self._on_status("responding")

        await self._provider.send_tool_result(call_id, result)
