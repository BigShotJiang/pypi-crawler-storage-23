"""OpenClaw Agent code provider.

Implements the AgentRunner protocol using the OpenClaw Gateway WebSocket
for streaming code agent interactions. Routes coding tasks to the
OpenClaw gateway which can use any configured model and tools.

This provider enables voice-vibecoder to use OpenClaw (Olaf) as the
coding agent instead of Claude Code CLI. Benefits:
- Same agent identity across all channels (Slack, voice, web)
- Access to all MCP tools (Jira, GitHub, CVPartner, Snøkam APIs)
- Persistent memory and context
- Any model backend (Claude, GPT-4, etc.)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import uuid
from typing import Any, Awaitable, Callable

from voice_vibecoder.code_providers import AgentOutput, AgentResult

logger = logging.getLogger(__name__)

# Default OpenClaw Gateway URL (loopback)
DEFAULT_GATEWAY_URL = "ws://localhost:18789"


def _extract_tool_info(line: str) -> tuple[str, str] | None:
    """Extract tool name and description from agent output lines."""
    match = re.match(r"^\[(\w+)\]\s*(.*)$", line.strip())
    if match:
        return match.group(1), match.group(2)
    return None


class OpenClawRunner:
    """AgentRunner implementation using OpenClaw Gateway WebSocket.
    
    This provider routes coding tasks to OpenClaw, which can:
    - Use any configured model (Claude, GPT-4, etc.)
    - Access all MCP tools (Jira, GitHub, CVPartner, etc.)
    - Maintain conversation context across sessions
    - Use the same identity/persona as the main agent
    """

    def __init__(
        self,
        session_id: str | None = None,
        agent_id: str | None = None,
        env: dict[str, str] | None = None,
        gateway_url: str | None = None,
        gateway_token: str | None = None,
        **_kwargs,
    ) -> None:
        self._session_id = session_id or f"voice-{uuid.uuid4().hex[:8]}"
        self._agent_id = agent_id
        self._env = env
        self._gateway_url = gateway_url or os.environ.get("OPENCLAW_GATEWAY_URL", DEFAULT_GATEWAY_URL)
        self._gateway_token = gateway_token or os.environ.get("OPENCLAW_GATEWAY_TOKEN")
        self._task: asyncio.Task | None = None
        self._ws = None

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        """Run a coding task via OpenClaw Gateway WebSocket."""
        self._task = asyncio.current_task()
        effective_session = session_id or self._session_id
        
        # Add working directory context
        full_message = f"[Working directory: {cwd}]\n\n{message}"
        
        if on_output:
            on_output(AgentOutput(
                category="text",
                content=f"🦞 Connecting to OpenClaw...",
            ))

        try:
            # Try WebSocket first, fall back to CLI if it fails
            result = await self._run_via_websocket(
                full_message, effective_session, on_output, can_use_tool
            )
        except Exception as ws_error:
            logger.warning("WebSocket connection failed, falling back to CLI: %s", ws_error)
            if on_output:
                on_output(AgentOutput(
                    category="text", 
                    content="WebSocket unavailable, using CLI...",
                ))
            result = await self._run_via_cli(
                full_message, cwd, effective_session, on_output
            )
        
        return result

    async def _run_via_websocket(
        self,
        message: str,
        session_id: str,
        on_output: Callable[[AgentOutput], None] | None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None,
    ) -> AgentResult:
        """Connect to OpenClaw Gateway via WebSocket and stream the response."""
        import websockets
        
        result_text = ""
        result_session_id = session_id
        
        async with websockets.connect(self._gateway_url) as ws:
            self._ws = ws
            
            # Wait for challenge
            challenge_raw = await asyncio.wait_for(ws.recv(), timeout=5.0)
            challenge = json.loads(challenge_raw)
            
            if challenge.get("event") != "connect.challenge":
                raise ValueError(f"Expected connect.challenge, got: {challenge}")
            
            # Generate device identity
            device_id = f"voice-vibecoder-{uuid.uuid4().hex[:8]}"
            
            # Send connect request
            connect_req = {
                "type": "req",
                "id": secrets.token_hex(8),
                "method": "connect",
                "params": {
                    "minProtocol": 3,
                    "maxProtocol": 3,
                    "client": {
                        "id": "voice-vibecoder",
                        "version": "1.0.0",
                        "platform": "linux",
                        "mode": "operator",
                    },
                    "role": "operator",
                    "scopes": ["operator.read", "operator.write"],
                    "caps": [],
                    "commands": [],
                    "permissions": {},
                    "auth": {"token": self._gateway_token} if self._gateway_token else {},
                    "locale": "en-US",
                    "userAgent": "voice-vibecoder/1.0.0",
                    "device": {
                        "id": device_id,
                    },
                },
            }
            await ws.send(json.dumps(connect_req))
            
            # Wait for hello-ok
            hello_raw = await asyncio.wait_for(ws.recv(), timeout=5.0)
            hello = json.loads(hello_raw)
            
            if not hello.get("ok"):
                error = hello.get("error", {}).get("message", "Unknown error")
                raise ValueError(f"Connect failed: {error}")
            
            if on_output:
                on_output(AgentOutput(category="text", content="Connected to OpenClaw"))
            
            # Send chat message
            chat_req = {
                "type": "req",
                "id": secrets.token_hex(8),
                "method": "chat.send",
                "params": {
                    "message": message,
                    "sessionKey": session_id,
                },
            }
            
            if self._agent_id:
                chat_req["params"]["agentId"] = self._agent_id
            
            await ws.send(json.dumps(chat_req))
            
            # Stream response
            while True:
                try:
                    msg_raw = await asyncio.wait_for(ws.recv(), timeout=600.0)
                    msg = json.loads(msg_raw)
                except asyncio.TimeoutError:
                    break
                
                msg_type = msg.get("type")
                
                if msg_type == "event":
                    event = msg.get("event", "")
                    payload = msg.get("payload", {})
                    
                    if event == "chat.chunk":
                        # Streaming text chunk
                        text = payload.get("text", "")
                        if text and on_output:
                            for line in text.splitlines():
                                if line.strip():
                                    tool_info = _extract_tool_info(line)
                                    if tool_info:
                                        tool_name, tool_desc = tool_info
                                        category = (
                                            "file_edit" if tool_name in ("Edit", "Write")
                                            else "bash" if tool_name == "Bash"
                                            else "tool_call"
                                        )
                                        on_output(AgentOutput(category=category, content=line))
                                    else:
                                        on_output(AgentOutput(category="text", content=line))
                        result_text += text
                    
                    elif event == "chat.done":
                        # Final response
                        result_text = payload.get("text", result_text)
                        result_session_id = payload.get("sessionKey", session_id)
                        break
                    
                    elif event == "chat.error":
                        error = payload.get("message", "Unknown error")
                        raise RuntimeError(f"OpenClaw error: {error}")
                
                elif msg_type == "res":
                    # Response to our request
                    if not msg.get("ok"):
                        error = msg.get("error", {}).get("message", "Unknown error")
                        raise RuntimeError(f"Request failed: {error}")
                    
                    # chat.send returns immediately, response comes via events
                    payload = msg.get("payload", {})
                    if "text" in payload:
                        result_text = payload["text"]
                        break
        
        self._ws = None
        
        return AgentResult(
            text=result_text,
            session_id=result_session_id,
        )

    async def _run_via_cli(
        self,
        message: str,
        cwd: str,
        session_id: str,
        on_output: Callable[[AgentOutput], None] | None,
    ) -> AgentResult:
        """Fallback: run via openclaw CLI."""
        cmd = [
            "openclaw", "agent",
            "--session-id", session_id,
            "--message", message,
            "--json",
            "--local",
        ]
        
        if self._agent_id:
            cmd.extend(["--agent", self._agent_id])
        
        env = os.environ.copy()
        if self._env:
            env.update(self._env)
        if self._gateway_token:
            env["OPENCLAW_GATEWAY_TOKEN"] = self._gateway_token
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            cwd=cwd,
        )
        
        result_text = ""
        
        async def read_stdout():
            nonlocal result_text
            assert process.stdout
            
            buffer = ""
            while True:
                chunk = await process.stdout.read(1024)
                if not chunk:
                    break
                
                text = chunk.decode("utf-8", errors="replace")
                buffer += text
                
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    
                    if not line:
                        continue
                    
                    try:
                        data = json.loads(line)
                        if isinstance(data, dict):
                            if "result" in data:
                                result_text = data["result"]
                            elif "text" in data:
                                result_text = data["text"]
                        continue
                    except json.JSONDecodeError:
                        pass
                    
                    if on_output:
                        tool_info = _extract_tool_info(line)
                        if tool_info:
                            tool_name, tool_desc = tool_info
                            category = (
                                "file_edit" if tool_name in ("Edit", "Write")
                                else "bash" if tool_name == "Bash"
                                else "tool_call"
                            )
                            on_output(AgentOutput(category=category, content=f"[{tool_name}] {tool_desc}"))
                        else:
                            on_output(AgentOutput(category="text", content=line))
            
            if buffer.strip():
                try:
                    data = json.loads(buffer)
                    if isinstance(data, dict) and "result" in data:
                        result_text = data["result"]
                except json.JSONDecodeError:
                    if on_output:
                        on_output(AgentOutput(category="text", content=buffer.strip()))
        
        async def read_stderr():
            assert process.stderr
            async for line in process.stderr:
                text = line.decode("utf-8", errors="replace").strip()
                if text and on_output:
                    on_output(AgentOutput(category="text", content=f"[stderr] {text}"))
        
        await asyncio.gather(read_stdout(), read_stderr())
        await process.wait()
        
        if process.returncode != 0 and not result_text:
            raise RuntimeError(f"OpenClaw CLI failed with exit code {process.returncode}")
        
        return AgentResult(
            text=result_text,
            session_id=session_id,
        )

    def cancel(self) -> bool:
        """Cancel the running task."""
        if self._ws:
            asyncio.create_task(self._ws.close())
            return True
        
        task = self._task
        if task and not task.done():
            task.cancel()
            return True
        
        return False
