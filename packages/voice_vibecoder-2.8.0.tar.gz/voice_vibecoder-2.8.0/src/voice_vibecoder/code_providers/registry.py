"""Centralized code agent registry.

Single source of truth for agent metadata: labels, CLI commands, colors,
and runner factories. All UI and tool code imports from here instead of
maintaining parallel dictionaries.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from voice_vibecoder.code_providers import AgentRunner


@dataclass(frozen=True)
class AgentInfo:
    """Metadata for a code agent."""
    id: str
    label: str
    cli_command: str
    color: str
    runner_factory: Callable[..., AgentRunner]


def _make_claude_runner(permission_mode: str = "bypass", mcp_servers: dict | None = None, env: dict | None = None, **_kw):
    from voice_vibecoder.code_providers.claude import ClaudeRunner
    return ClaudeRunner(permission_mode=permission_mode, mcp_servers=mcp_servers or None, env=env)


def _make_cursor_runner(**_kw):
    from voice_vibecoder.code_providers.cursor import CursorRunner
    return CursorRunner()


def _make_openclaw_runner(session_id: str | None = None, agent_id: str | None = None, env: dict | None = None, **_kw):
    from voice_vibecoder.code_providers.openclaw import OpenClawRunner
    return OpenClawRunner(session_id=session_id, agent_id=agent_id, env=env)


AGENTS: dict[str, AgentInfo] = {
    "claude": AgentInfo(
        id="claude",
        label="Claude Code",
        cli_command="claude",
        color="cyan",
        runner_factory=_make_claude_runner,
    ),
    "cursor": AgentInfo(
        id="cursor",
        label="Cursor",
        cli_command="cursor-agent",
        color="green",
        runner_factory=_make_cursor_runner,
    ),
    "openclaw": AgentInfo(
        id="openclaw",
        label="OpenClaw",
        cli_command="openclaw",
        color="red",
        runner_factory=_make_openclaw_runner,
    ),
}


def get_agent(agent_id: str) -> AgentInfo:
    """Get agent info by ID. Falls back to claude if unknown."""
    return AGENTS.get(agent_id, AGENTS["claude"])


def get_choices() -> list[tuple[str, str]]:
    """Return [(label, id), ...] for UI select widgets."""
    return [(a.label, a.id) for a in AGENTS.values()]


def get_labels(agent_ids: list[str] | None = None) -> dict[str, str]:
    """Return {id: label} mapping, optionally filtered."""
    if agent_ids:
        return {aid: get_agent(aid).label for aid in agent_ids}
    return {a.id: a.label for a in AGENTS.values()}


def get_badge(agent_id: str) -> str:
    """Return a Rich-markup badge like '[bold cyan]Claude[/bold cyan]'."""
    info = get_agent(agent_id)
    return f"[bold {info.color}]{info.label}[/bold {info.color}]"
