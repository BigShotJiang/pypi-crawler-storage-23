"""Tool definitions and handlers for the Realtime API session.

Re-exports the public API so existing imports keep working.
"""

from voice_vibecoder.tools.definitions import get_tool_definitions
from voice_vibecoder.tools.dispatch import (
    configure,
    handle_tool_call,
    handle_tool_call_async,
    register_external_tools,
    register_helper_override,
    cancel_all_tasks,
    cancel_active_task,
    cancel_instance_task,
)

__all__ = [
    "TOOL_DEFINITIONS",
    "get_tool_definitions",
    "configure",
    "register_external_tools",
    "register_helper_override",
    "handle_tool_call",
    "handle_tool_call_async",
    "cancel_all_tasks",
    "cancel_active_task",
    "cancel_instance_task",
]


def __getattr__(name: str):
    if name == "TOOL_DEFINITIONS":
        return get_tool_definitions()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
