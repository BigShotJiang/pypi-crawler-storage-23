"""Tool dispatch, configuration, and cancellation.

Module-level state holds the registry and config. The dispatcher routes
tool calls to handler functions in handlers.py and agent_task.py.

External tool registration
--------------------------
Projects that extend voice-vibecoder (e.g. openclaw-function) can register
their own async tool handlers via ``register_external_tools``.  Registered
tools are automatically included in the tool definitions sent to OpenAI and
dispatched through ``handle_tool_call_async``.
"""

import logging
from pathlib import Path
from typing import Any, Callable, Awaitable

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.config import PermissionMode
from voice_vibecoder.instances import AgentInstance, InstanceRegistry, InstanceType

logger = logging.getLogger(__name__)

_registry: InstanceRegistry | None = None
_repo_root: Path | None = None
_agent_timeout: int = 300
_permission_mode: PermissionMode = "bypass"
_enabled_agents: list[str] = ["claude"]
_voice_config: VoiceConfig | None = None

# ── External tool registry ───────────────────────────────────────────────────
# Maps tool name → async handler(name, arguments, user_jwt) -> str
_external_tool_handlers: dict[str, Callable[..., Awaitable[str]]] = {}
_external_tool_definitions: list[dict[str, Any]] = []

# ── Helper override ──────────────────────────────────────────────────────────
# Allows an external package (e.g. openclaw-function) to intercept helper
# instance requests with a custom handler (e.g. OpenClaw Gateway).
_helper_override: Callable[..., Awaitable[str | None]] | None = None


def register_helper_override(
    handler: Callable[..., Awaitable[str | None]],
) -> None:
    """Register an override handler for the helper instance.

    When set, helper instance requests (no branch) go through the override
    handler first. If it returns ``None`` or raises, Claude Code is used
    as fallback.

    Handler signature: ``async (message, instance, registry, user_jwt) -> str | None``
    """
    global _helper_override
    _helper_override = handler
    logger.info("Registered helper override: %s", handler.__name__)


def register_external_tools(
    definitions: list[dict[str, Any]],
    handler: Callable[..., Awaitable[str]],
) -> None:
    """Register external tools (used by openclaw-function, etc.).

    Args:
        definitions: List of OpenAI tool definition dicts (each must have a "name" key).
        handler: Async callable ``(name, arguments, user_jwt) -> str`` that handles
                 tool calls for the given definitions.
    """
    _external_tool_definitions.extend(definitions)
    for defn in definitions:
        name = defn["name"]
        _external_tool_handlers[name] = handler
        logger.info("Registered external tool: %s", name)


def get_external_tool_definitions() -> list[dict[str, Any]]:
    """Return a copy of the registered external tool definitions."""
    return list(_external_tool_definitions)


def configure(
    registry: InstanceRegistry,
    repo_root: Path,
    agent_timeout: int = 300,
    permission_mode: PermissionMode = "bypass",
    enabled_agents: list[str] | None = None,
    user_jwt: str | None = None,
    voice_config: VoiceConfig | None = None,
) -> None:
    global _registry, _repo_root, _agent_timeout, _permission_mode, _enabled_agents, _voice_config
    _registry = registry
    _repo_root = repo_root
    _agent_timeout = agent_timeout
    _permission_mode = permission_mode
    _enabled_agents = enabled_agents or ["claude"]
    _voice_config = voice_config


def _default_agent_type() -> str:
    """Return the default agent type from config, or first enabled agent."""
    if _voice_config and _voice_config.default_agent:
        return _voice_config.default_agent
    return _enabled_agents[0] if _enabled_agents else "claude"


def _fuzzy_match_branch(query: str, branches: list[str]) -> str | None:
    """Find a branch by exact match, then substring, shortest wins on ties."""
    exact = [b for b in branches if b == query]
    if exact:
        return exact[0]
    partial = [b for b in branches if query in b]
    if len(partial) == 1:
        return partial[0]
    if partial:
        return min(partial, key=len)
    return None


def _resolve_instance(branch: str | None = None, session_name: str | None = None) -> AgentInstance | None:
    if not _registry:
        return None
    if session_name:
        return _resolve_session(session_name)
    if branch:
        inst = _registry.get_by_branch(branch)
        if inst:
            return inst
        # Fuzzy match against registered branches
        all_branches = [i.branch for i in _registry.get_all()]
        matched = _fuzzy_match_branch(branch, all_branches)
        if matched:
            return _registry.get_by_branch(matched)
        return None
    return _registry.get_default()


def _resolve_session(session_name: str) -> AgentInstance | None:
    """Resolve a session instance by display_name (fuzzy match)."""
    if not _registry:
        return None
    return _registry.get_session_by_name(session_name)


def cancel_instance_task(instance: AgentInstance) -> bool:
    bg_loop = instance._bg_loop
    bg_task = instance._bg_task
    if not bg_loop or not bg_task or bg_task.done():
        return False
    bg_loop.call_soon_threadsafe(bg_task.cancel)
    return True


def cancel_all_tasks() -> int:
    if not _registry:
        return 0
    count = 0
    for inst in _registry.get_all():
        if cancel_instance_task(inst):
            count += 1
    return count


def cancel_active_task() -> bool:
    if not _registry:
        return False
    inst = _registry.get_default()
    return cancel_instance_task(inst) if inst else False


async def handle_tool_call_async(
    name: str, arguments: dict[str, Any], user_jwt: str | None = None,
) -> str:
    """Async tool handler — routes to external handlers or falls back to sync.

    External tools registered via ``register_external_tools`` are dispatched
    here. The handler receives ``(name, arguments, user_jwt)``.
    """
    handler = _external_tool_handlers.get(name)
    if handler:
        try:
            return await handler(name, arguments, user_jwt)
        except Exception as exc:
            logger.error("%s failed: %s", name, exc, exc_info=True)
            return f"Error executing {name}: {exc}"

    # Fall back to sync handler for core tools
    return handle_tool_call(name, arguments)


def handle_tool_call(name: str, arguments: dict[str, Any]) -> str:
    from voice_vibecoder.tools.agent_task import _handle_send_to_agent, _handle_send_to_session
    from voice_vibecoder.tools.handlers import (
        _handle_answer_question,
        _handle_cancel_agent,
        _handle_create_branch_instance,
        _handle_delete_worktree,
        _handle_get_agent_status,
        _handle_list_branches,
        _handle_remove_branch_instance,
        _handle_remove_session,
        _handle_reset_agent,
        _handle_show_diff,
        _handle_show_output,
        _handle_switch_agent,
        _handle_toggle_fullscreen,
    )

    if name == "send_to_agent":
        return _handle_send_to_agent(
            arguments.get("message", ""),
            arguments.get("branch"),
            arguments.get("agent"),
        )
    elif name == "send_to_session":
        return _handle_send_to_session(
            arguments.get("message", ""),
            arguments.get("session_name"),
            arguments.get("agent"),
            arguments.get("display_name"),
        )
    elif name == "switch_agent":
        return _handle_switch_agent(
            arguments.get("agent", ""),
            arguments.get("branch"),
        )
    elif name == "create_branch_instance":
        return _handle_create_branch_instance(arguments.get("branch", ""))
    elif name == "get_agent_status":
        return _handle_get_agent_status(arguments.get("branch"), arguments.get("session_name"))
    elif name == "cancel_agent":
        return _handle_cancel_agent(arguments.get("branch"), arguments.get("session_name"))
    elif name == "reset_agent":
        return _handle_reset_agent(arguments.get("branch"), arguments.get("session_name"))
    elif name == "list_branches":
        return _handle_list_branches()
    elif name == "answer_agent_question":
        return _handle_answer_question(
            arguments.get("answer", ""),
            arguments.get("branch"),
            arguments.get("session_name"),
        )
    elif name == "show_diff":
        return _handle_show_diff(arguments.get("branch"), arguments.get("file"))
    elif name == "show_output":
        return _handle_show_output(arguments.get("branch"), arguments.get("session_name"))
    elif name == "toggle_fullscreen":
        return _handle_toggle_fullscreen(arguments.get("branch"), arguments.get("session_name"))
    elif name == "remove_branch_instance":
        return _handle_remove_branch_instance(arguments.get("branch", ""))
    elif name == "remove_session":
        return _handle_remove_session(arguments.get("session_name", ""))
    elif name == "delete_worktree":
        return _handle_delete_worktree(
            arguments.get("branch", ""),
            arguments.get("delete_branch", False),
        )
    return f"Unknown tool: {name}"
