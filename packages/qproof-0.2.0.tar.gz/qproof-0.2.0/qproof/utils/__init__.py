"""Utility modules for qproof."""
