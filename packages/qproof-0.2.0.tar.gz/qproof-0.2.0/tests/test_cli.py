"""Tests for the qproof CLI."""

from click.testing import CliRunner

from qproof.cli import main


def test_cli_version() -> None:
    """CLI --version outputs the correct version string."""
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    from qproof import __version__
    assert __version__ in result.output


def test_cli_scan_default() -> None:
    """CLI scan . runs without error."""
    runner = CliRunner()
    result = runner.invoke(main, ["scan", "."])
    assert result.exit_code == 0
    assert "qproof" in result.output or "Quantum" in result.output or len(result.output) > 0


def test_cli_scan_nonexistent() -> None:
    """CLI scan with nonexistent path fails."""
    runner = CliRunner()
    result = runner.invoke(main, ["scan", "/tmp/nonexistent_qproof_path"])
    assert result.exit_code != 0
