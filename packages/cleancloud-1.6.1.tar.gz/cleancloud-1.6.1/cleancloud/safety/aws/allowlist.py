ALLOWED_AWS_API_PREFIXES = (
    "Describe",
    "List",
    "Get",
)

FORBIDDEN_AWS_API_PREFIXES = (
    "Delete",
    "Put",
    "Update",
    "Create",
    "Attach",
    "Detach",
    "Modify",
    "Terminate",
    "Associate",
    "Disassociate",
)
