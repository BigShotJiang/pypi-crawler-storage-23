"""CLI package for nanoslides."""

from nanoslides.cli.main import app, run

__all__ = ["app", "run"]

