"""Module entry point for `python -m nanoslides`."""

from nanoslides.cli.main import run

if __name__ == "__main__":
    run()
