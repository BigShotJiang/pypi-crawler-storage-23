from __future__ import annotations

import json
import time
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
import tifffile as tiff
from qtpy.QtCore import QTimer
from qtpy.QtWidgets import (
    QDoubleSpinBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

if TYPE_CHECKING:
    import napari


OUT_NAME = "manual_best"
WORK_SUFFIX = "__work"


def _now() -> str:
    return time.strftime("%H:%M:%S")


def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


class FastLogger:
    """Stream logs using a Qt timer to avoid blocking UI."""

    def __init__(
        self, out_dir="curation_logs", batch_size=300, interval_ms=120
    ):
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(exist_ok=True)
        self.session_id = time.strftime("%Y%m%d_%H%M%S")
        self.jsonl_path = self.out_dir / f"curation_{self.session_id}.jsonl"
        self.tsv_path = self.out_dir / f"curation_{self.session_id}.tsv"

        self.q = deque()
        self.batch_size = int(batch_size)

        self.cols = [
            "time",
            "event",
            "target_id",
            "src_layer",
            "base_layer",
            "src_label",
            "overlap_pixels",
            "area",
            "win_y0",
            "win_y1",
            "win_x0",
            "win_x1",
        ]

        self.f_jsonl = open(
            self.jsonl_path, "a", encoding="utf-8", buffering=1
        )
        self.f_tsv = open(self.tsv_path, "a", encoding="utf-8", buffering=1)
        if self.tsv_path.stat().st_size == 0:
            self.f_tsv.write("\t".join(self.cols) + "\n")

        self.timer = QTimer()
        self.timer.setInterval(int(interval_ms))
        self.timer.timeout.connect(self.flush_some)
        self.timer.start()
        print(f"[{_now()}] [LOG] -> {self.jsonl_path} / {self.tsv_path}")

    def push(self, row: dict):
        self.q.append(row)

    def flush_some(self):
        if not self.q:
            return
        n = min(self.batch_size, len(self.q))
        pop = self.q.popleft
        fj, ft = self.f_jsonl, self.f_tsv
        cols = self.cols

        for _ in range(n):
            r = pop()
            fj.write(json.dumps(r, ensure_ascii=False) + "\n")

            win = r.get("win", [None, None, None, None])
            rr = {
                "time": r.get("time", ""),
                "event": r.get("event", ""),
                "target_id": r.get("target_id", ""),
                "src_layer": r.get("src_layer", ""),
                "base_layer": r.get("base_layer", ""),
                "src_label": r.get("src_label", ""),
                "overlap_pixels": r.get("overlap_pixels", ""),
                "area": r.get("area", ""),
                "win_y0": win[0],
                "win_y1": win[1],
                "win_x0": win[2],
                "win_x1": win[3],
            }
            ft.write("\t".join(str(rr.get(c, "")) for c in cols) + "\n")

    def flush_all(self):
        while self.q:
            self.flush_some()

    def close(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            self.flush_all()
        except Exception:
            pass
        try:
            self.f_jsonl.close()
            self.f_tsv.close()
        except Exception:
            pass


def _is_labels(layer) -> bool:
    try:
        from napari.layers import Labels

        return isinstance(layer, Labels)
    except Exception:
        return layer is not None and layer.__class__.__name__ == "Labels"


def _is_mask_labels_layer(layer) -> bool:
    return _is_labels(layer) and (
        ".mask" in layer.name or layer.name.endswith(WORK_SUFFIX)
    )


def _bbox_from_mask(mask_bool: np.ndarray):
    ys, xs = np.where(mask_bool)
    if ys.size == 0:
        return None
    return (int(ys.min()), int(ys.max()) + 1, int(xs.min()), int(xs.max()) + 1)


def _pad_window(bbox, H, W, pad):
    y0, y1, x0, x1 = bbox
    return (
        max(0, y0 - pad),
        min(H, y1 + pad),
        max(0, x0 - pad),
        min(W, x1 + pad),
    )


def compact_labels_with_map(lb: np.ndarray):
    """
    Compact labels to 1..N (0 stays 0). Return (compacted, mapping old->new).
    Fast vectorized mapping via searchsorted on sorted unique ids.
    """
    flat = lb.ravel()
    ids = np.unique(flat)
    ids = ids[ids != 0]
    if ids.size == 0:
        return lb.astype(np.uint32, copy=True), {}

    new_ids = np.arange(1, ids.size + 1, dtype=np.uint32)

    out = lb.astype(np.uint32, copy=True)
    m = out > 0
    idx = np.searchsorted(ids, out[m])
    out[m] = new_ids[idx]

    mapping = {int(o): int(n) for o, n in zip(ids.tolist(), new_ids.tolist())}
    return out, mapping


class MaskCurationWidget(QWidget):
    """
    Mask curation panel:
    - Follow selected .mask Labels -> create __work copy
    - Prune work objects if overlap with manual_best >= thr
    - Collect objects by click into manual_best with ALWAYS NEW ID overwrite
    - Undo (U): fully restore manual_best window + work bbox to pre-click state
    - Save (S): compact IDs to consecutive 1..N BEFORE writing TIFF
    - Async logging to JSONL + TSV
    - Blink selected layer visibility every 0.5s
    """

    def __init__(self, viewer: napari.viewer.Viewer):
        super().__init__()
        self.viewer = viewer

        self.PARAM = {
            "overlap_prune_thr": 0.70,
            "window_pad": 30,
            "blink_interval_s": 0.5,
            "undo_max_steps": 200,
            "compact_before_save": True,
        }
        self.state = {"collect_mode": False}

        self.logger = FastLogger()
        self.undo_stack = deque(maxlen=int(self.PARAM["undo_max_steps"]))

        # blink state
        self._blink = {"on": False, "layer_name": None}
        self.blink_timer = QTimer(self)
        self.blink_timer.setInterval(
            int(self.PARAM["blink_interval_s"] * 1000)
        )
        self.blink_timer.timeout.connect(self._blink_tick)

        # UI
        panel = QVBoxLayout(self)
        title = QLabel(
            "Mask Curation (NEW ID + UNDO + COMPACT SAVE + FAST LOG + BLINK)"
        )
        title.setStyleSheet("font-weight: bold;")
        panel.addWidget(title)

        # prune thr
        row_thr = QHBoxLayout()
        lbl_thr = QLabel("Overlap prune thr (keep if < thr):")
        self.spin_thr = QDoubleSpinBox()
        self.spin_thr.setRange(0.0, 1.0)
        self.spin_thr.setSingleStep(0.05)
        self.spin_thr.setValue(float(self.PARAM["overlap_prune_thr"]))
        self.spin_thr.valueChanged.connect(
            lambda v: self.PARAM.__setitem__("overlap_prune_thr", float(v))
        )
        row_thr.addWidget(lbl_thr)
        row_thr.addWidget(self.spin_thr)
        panel.addLayout(row_thr)

        # ROI pad
        row_pad = QHBoxLayout()
        lbl_pad = QLabel("ROI pad(px):")
        self.spin_pad = QSpinBox()
        self.spin_pad.setRange(0, 500)
        self.spin_pad.setValue(int(self.PARAM["window_pad"]))
        self.spin_pad.valueChanged.connect(
            lambda v: self.PARAM.__setitem__("window_pad", int(v))
        )
        row_pad.addWidget(lbl_pad)
        row_pad.addWidget(self.spin_pad)
        panel.addLayout(row_pad)

        self.panel_status = QLabel("Select a Labels mask layer to see stats.")
        self.panel_status.setStyleSheet("font-family: Menlo, monospace;")
        panel.addWidget(self.panel_status)

        # buttons
        self.btn_toggle = QPushButton("Toggle Collect (A)")
        self.btn_follow = QPushButton("Follow → Work + Prune")
        self.btn_prune = QPushButton("Prune Now (P)")
        self.btn_reset = QPushButton("Reset Work (R)")
        self.btn_undo = QPushButton("Undo (U)")
        self.btn_stats = QPushButton("Refresh Stats")
        self.btn_save = QPushButton("Save manual_best (S) [COMPACT]")
        self.btn_blink = QPushButton("Blink Selected Layer (0.5s)")

        self.btn_toggle.clicked.connect(self.on_toggle)
        self.btn_follow.clicked.connect(self.on_follow)
        self.btn_prune.clicked.connect(self.on_prune)
        self.btn_reset.clicked.connect(self.on_reset)
        self.btn_undo.clicked.connect(self.on_undo)
        self.btn_stats.clicked.connect(self.on_stats)
        self.btn_save.clicked.connect(self.on_save)
        self.btn_blink.clicked.connect(self.on_blink)

        panel.addWidget(self.btn_toggle)
        panel.addWidget(self.btn_follow)
        panel.addWidget(self.btn_prune)
        panel.addWidget(self.btn_reset)
        panel.addWidget(self.btn_undo)
        panel.addWidget(self.btn_stats)
        panel.addWidget(self.btn_save)
        panel.addWidget(self.btn_blink)

        # hotkeys: avoid binding multiple times per viewer
        # (reopening the dock widget should not stack bindings)
        if not getattr(self.viewer, "_mask_curator_hotkeys_bound", False):
            try:
                self.viewer.bind_key("A")(lambda v: self.on_toggle())
                self.viewer.bind_key("P")(lambda v: self.on_prune())
                self.viewer.bind_key("R")(lambda v: self.on_reset())
                self.viewer.bind_key("S")(lambda v: self.on_save())
                self.viewer.bind_key("U")(lambda v: self.on_undo())
                self.viewer._mask_curator_hotkeys_bound = True
            except Exception:
                pass

        # mouse callback
        self.viewer.mouse_drag_callbacks.append(self._global_click)

        print("[READY] MaskCurationWidget loaded.")
        print("Hotkeys: A collect | P prune | R reset | U undo | S save")
        print("Logs: ./curation_logs (JSONL + TSV)")

    # ---------- viewer helpers ----------
    def get_selected_layer(self):
        sel = self.viewer.layers.selection
        try:
            if sel:
                return list(sel)[0]
        except Exception:
            pass
        try:
            return sel.active
        except Exception:
            return None

    def ensure_manual_best(self, shape):
        if OUT_NAME in [l.name for l in self.viewer.layers]:
            out = self.viewer.layers[OUT_NAME]
            if not _is_labels(out):
                raise RuntimeError(f"{OUT_NAME} exists but is not Labels.")
            if out.data.shape != shape:
                raise RuntimeError(
                    f"{OUT_NAME} shape {out.data.shape} != {shape}"
                )
            return out
        out = np.zeros(shape, dtype=np.uint32)
        return self.viewer.add_labels(out, name=OUT_NAME)

    def get_or_make_work(self, src_layer):
        if src_layer.name.endswith(WORK_SUFFIX):
            return src_layer
        work_name = src_layer.name + WORK_SUFFIX
        if work_name in [l.name for l in self.viewer.layers]:
            w = self.viewer.layers[work_name]
            if not _is_labels(w):
                raise RuntimeError(f"{work_name} exists but is not Labels.")
            src_layer.visible = False
            w.visible = True
            return w
        w = self.viewer.add_labels(src_layer.data.copy(), name=work_name)
        src_layer.visible = False
        w.visible = True
        print(f"[{_now()}] [WORK] created {work_name} (original hidden)")
        return w

    def auto_follow_to_work(self):
        sel = self.get_selected_layer()
        if not _is_mask_labels_layer(sel):
            return None
        work = (
            self.get_or_make_work(sel)
            if not sel.name.endswith(WORK_SUFFIX)
            else sel
        )
        try:
            self.viewer.layers.selection.clear()
            self.viewer.layers.selection.add(work)
        except Exception:
            pass
        return work

    # ---------- core ops ----------
    def prune_work_by_manual_overlap(self, work_layer, thr: float) -> int:
        if OUT_NAME not in [l.name for l in self.viewer.layers]:
            return 0
        manual = self.viewer.layers[OUT_NAME].data
        w = work_layer.data
        if manual.shape != w.shape:
            raise RuntimeError("manual_best shape != work shape")

        w_flat = w.ravel().astype(np.int64, copy=False)
        max_id = int(w_flat.max())
        if max_id == 0:
            return 0

        fg = w_flat > 0
        area = np.bincount(w_flat[fg], minlength=max_id + 1)

        ov_fg = (manual.ravel() > 0) & fg
        ov = np.bincount(w_flat[ov_fg], minlength=max_id + 1)

        ratio = np.zeros_like(ov, dtype=np.float32)
        valid = area > 0
        ratio[valid] = ov[valid] / area[valid]

        prune_ids = np.where(ratio >= thr)[0]
        prune_ids = prune_ids[(prune_ids != 0)]
        if prune_ids.size == 0:
            return 0

        keep = np.ones(max_id + 1, dtype=np.uint8)
        keep[prune_ids] = 0
        w2 = (w.astype(np.int64, copy=False) * keep[w]).astype(
            w.dtype, copy=False
        )

        work_layer.data = w2
        work_layer.refresh()
        return int(prune_ids.size)

    def collect_always_newid(self, work_layer, position):
        out = self.ensure_manual_best(work_layer.data.shape)

        y = int(round(position[-2]))
        x = int(round(position[-1]))
        H, W = work_layer.data.shape[-2], work_layer.data.shape[-1]
        if y < 0 or x < 0 or y >= H or x >= W:
            return

        src_label = int(work_layer.data[y, x])
        if src_label == 0:
            return

        src_layer_name = work_layer.name
        base_layer_name = (
            src_layer_name[: -len(WORK_SUFFIX)]
            if src_layer_name.endswith(WORK_SUFFIX)
            else src_layer_name
        )

        obj = work_layer.data == src_label
        bbox = _bbox_from_mask(obj)
        if bbox is None:
            return

        pad = int(self.PARAM["window_pad"])
        y0, y1, x0, x1 = _pad_window(bbox, H, W, pad)

        # ====== UNDO snapshot: restore PRE-CLICK state exactly ======
        by0, by1, bx0, bx1 = bbox
        manual_prev = out.data[y0:y1, x0:x1].copy()
        work_prev = work_layer.data[by0:by1, bx0:bx1].copy()

        new_id = int(out.data.max()) + 1  # assign now so undo logs target id
        self.undo_stack.append(
            {
                "time": _ts(),
                "work_layer": src_layer_name,
                "manual_win": (int(y0), int(y1), int(x0), int(x1)),
                "manual_prev": manual_prev,
                "work_bbox": (int(by0), int(by1), int(bx0), int(bx1)),
                "work_prev": work_prev,
                "new_id": int(new_id),
                "src_label": int(src_label),
            }
        )

        # ====== perform write (local window) ======
        out_win = out.data[y0:y1, x0:x1].copy()
        obj_win = obj[y0:y1, x0:x1]

        overlap_pixels = int((out_win[obj_win] > 0).sum())
        area = int(obj_win.sum())

        # ALWAYS NEW ID overwrite
        out_win[obj_win] = np.uint32(new_id)

        out.data[y0:y1, x0:x1] = out_win
        out.refresh()

        # remove object from work (whole object)
        work_layer.data[obj] = 0
        work_layer.refresh()

        self.logger.push(
            {
                "time": _ts(),
                "event": "collect_newid",
                "target_id": int(new_id),
                "src_layer": src_layer_name,
                "base_layer": base_layer_name,
                "src_label": int(src_label),
                "overlap_pixels": int(overlap_pixels),
                "area": int(area),
                "win": [int(y0), int(y1), int(x0), int(x1)],
                "params": dict(self.PARAM),
            }
        )

    # ---------- callbacks ----------
    def _global_click(self, viewer, event):
        if not self.state["collect_mode"]:
            return
        if getattr(event, "button", None) != 1:
            return
        work = self.auto_follow_to_work()
        if work is None:
            return
        self.collect_always_newid(work, event.position)
        try:
            self.panel_status.setText(self.stats_for_layer(work))
        except Exception:
            pass

    def stats_for_layer(self, layer):
        if layer is None or not _is_labels(layer):
            return "No Labels layer selected."
        data = layer.data
        flat = data.ravel().astype(np.int64, copy=False)
        max_id = int(flat.max())
        fg = flat > 0
        total = int(flat.size)
        fg_pixels = int(fg.sum())
        if max_id == 0:
            n_objs = 0
        else:
            bc = np.bincount(flat[fg], minlength=max_id + 1)
            n_objs = int((bc > 0).sum())
        return (
            f"Layer: {layer.name}\n"
            f"Objects: {n_objs}\n"
            f"FG%: {fg_pixels/total*100:.2f}%\n"
            f"Max label: {max_id}\n"
            f"collect_mode: {self.state['collect_mode']}\n"
            f"undo_steps: {len(self.undo_stack)}"
        )

    # ---------- UI handlers ----------
    def on_toggle(self):
        self.state["collect_mode"] = not self.state["collect_mode"]
        sel = self.get_selected_layer()
        name = sel.name if sel is not None else "None"
        print(
            f"[{_now()}] [MODE] collect_mode={self.state['collect_mode']} selected={name}"
        )
        if self.state["collect_mode"]:
            work = self.auto_follow_to_work()
            if work is not None:
                removed = self.prune_work_by_manual_overlap(
                    work, float(self.PARAM["overlap_prune_thr"])
                )
                print(
                    f"[{_now()}] [PRUNE] removed={removed} thr={self.PARAM['overlap_prune_thr']}"
                )
                self.panel_status.setText(self.stats_for_layer(work))

    def on_follow(self):
        work = self.auto_follow_to_work()
        if work is None:
            print(f"[{_now()}] select a .mask Labels layer first.")
            return
        removed = self.prune_work_by_manual_overlap(
            work, float(self.PARAM["overlap_prune_thr"])
        )
        print(
            f"[{_now()}] [PRUNE] removed={removed} thr={self.PARAM['overlap_prune_thr']}"
        )
        self.panel_status.setText(self.stats_for_layer(work))

    def on_prune(self):
        sel = self.get_selected_layer()
        if sel is None:
            return
        work = (
            sel
            if sel.name.endswith(WORK_SUFFIX)
            else self.auto_follow_to_work()
        )
        if work is None:
            print(f"[{_now()}] select a work layer or a .mask layer.")
            return
        removed = self.prune_work_by_manual_overlap(
            work, float(self.PARAM["overlap_prune_thr"])
        )
        print(
            f"[{_now()}] [PRUNE] removed={removed} thr={self.PARAM['overlap_prune_thr']}"
        )
        self.panel_status.setText(self.stats_for_layer(work))

    def on_reset(self):
        sel = self.get_selected_layer()
        if not _is_mask_labels_layer(sel):
            return
        thr = float(self.PARAM["overlap_prune_thr"])
        if sel.name.endswith(WORK_SUFFIX):
            base = sel.name[: -len(WORK_SUFFIX)]
            if base not in [l.name for l in self.viewer.layers]:
                return
            src = self.viewer.layers[base]
            sel.data = src.data.copy()
            sel.refresh()
            removed = self.prune_work_by_manual_overlap(sel, thr)
            print(f"[{_now()}] [RESET+PRUNE] removed={removed} thr={thr}")
            self.panel_status.setText(self.stats_for_layer(sel))
            return

        work = self.get_or_make_work(sel)
        work.data = sel.data.copy()
        work.refresh()
        removed = self.prune_work_by_manual_overlap(work, thr)
        print(f"[{_now()}] [RESET+PRUNE] removed={removed} thr={thr}")
        self.panel_status.setText(self.stats_for_layer(work))

    def on_undo(self):
        if not self.undo_stack:
            print(f"[{_now()}] [UNDO] nothing to undo.")
            return

        u = self.undo_stack.pop()

        # restore manual_best window
        if OUT_NAME not in [l.name for l in self.viewer.layers]:
            print(f"[{_now()}] [UNDO] manual_best not found.")
            return
        out_layer = self.viewer.layers[OUT_NAME]
        y0, y1, x0, x1 = u["manual_win"]
        out_layer.data[y0:y1, x0:x1] = u["manual_prev"]
        out_layer.refresh()

        # restore work bbox exactly as pre-click
        wname = u["work_layer"]
        if wname not in [l.name for l in self.viewer.layers]:
            print(f"[{_now()}] [UNDO] work layer '{wname}' not found.")
            return
        work = self.viewer.layers[wname]
        by0, by1, bx0, bx1 = u["work_bbox"]
        work.data[by0:by1, bx0:bx1] = u["work_prev"]
        work.refresh()

        try:
            self.logger.push(
                {
                    "time": _ts(),
                    "event": "undo_collect",
                    "target_id": int(u.get("new_id", -1)),
                    "src_layer": wname,
                    "base_layer": (
                        wname[: -len(WORK_SUFFIX)]
                        if wname.endswith(WORK_SUFFIX)
                        else wname
                    ),
                    "src_label": int(u.get("src_label", -1)),
                    "overlap_pixels": "",
                    "area": "",
                    "win": [int(y0), int(y1), int(x0), int(x1)],
                    "params": dict(self.PARAM),
                }
            )
        except Exception:
            pass

        try:
            self.panel_status.setText(self.stats_for_layer(work))
        except Exception:
            pass

        print(f"[{_now()}] [UNDO] restored pre-click state.")

    def on_stats(self):
        self.panel_status.setText(
            self.stats_for_layer(self.get_selected_layer())
        )

    def on_save(self):
        if OUT_NAME not in [l.name for l in self.viewer.layers]:
            print(f"[{_now()}] [SAVE] manual_best not found.")
            return

        out_layer = self.viewer.layers[OUT_NAME]
        lb = out_layer.data

        # COMPACT BEFORE SAVE (you requested this)
        compact, mapping = compact_labels_with_map(lb)
        out_layer.data = compact
        out_layer.refresh()

        out_id = Path("manual_best_ID_uint32.tif")
        out_blk = Path("manual_best_black_uint8.tif")
        out_map = Path("manual_best_id_map_old_to_new.tsv")

        tiff.imwrite(out_id, compact.astype(np.uint32), compression="zlib")
        black = (compact > 0).astype(np.uint8) * 255
        tiff.imwrite(out_blk, black, compression="zlib")

        # Save mapping (recommended to keep traceability vs logs)
        if mapping:
            with open(out_map, "w", encoding="utf-8") as f:
                f.write("old_id\tnew_id\n")
                for k in sorted(mapping):
                    f.write(f"{k}\t{mapping[k]}\n")

        print(f"[{_now()}] [SAVE] wrote {out_id} and {out_blk}")
        if mapping:
            print(
                f"[{_now()}] [SAVE] wrote mapping {out_map} (old_id -> new_id)"
            )

    # ---------- blink ----------
    def _blink_tick(self):
        name = self._blink["layer_name"]
        if not name or name not in [l.name for l in self.viewer.layers]:
            self.stop_blink(restore=False)
            return
        layer = self.viewer.layers[name]
        layer.visible = not layer.visible

    def start_blink(self):
        sel = self.get_selected_layer()
        if sel is None:
            return
        self._blink["on"] = True
        self._blink["layer_name"] = sel.name
        self.blink_timer.setInterval(
            int(self.PARAM["blink_interval_s"] * 1000)
        )
        self.blink_timer.start()
        print(f"[{_now()}] [BLINK] start: {sel.name}")

    def stop_blink(self, restore=True):
        if self.blink_timer.isActive():
            self.blink_timer.stop()
        if (
            restore
            and self._blink["layer_name"]
            and self._blink["layer_name"]
            in [l.name for l in self.viewer.layers]
        ):
            self.viewer.layers[self._blink["layer_name"]].visible = True
        print(f"[{_now()}] [BLINK] stop")
        self._blink["on"] = False
        self._blink["layer_name"] = None

    def on_blink(self):
        if self._blink["on"]:
            self.stop_blink(restore=True)
        else:
            self.start_blink()

    # ---------- cleanup ----------
    def closeEvent(self, event):
        try:
            self.stop_blink(restore=True)
        except Exception:
            pass
        try:
            if self._global_click in self.viewer.mouse_drag_callbacks:
                self.viewer.mouse_drag_callbacks.remove(self._global_click)
        except Exception:
            pass
        try:
            self.logger.close()
        except Exception:
            pass
        super().closeEvent(event)


def make_mask_curation_widget():
    """Factory compatible across napari versions (no dependency injection)."""
    import napari

    viewer = napari.current_viewer()
    if viewer is None:
        raise RuntimeError(
            "No active napari viewer found. Please open napari first."
        )
    return MaskCurationWidget(viewer)
