from ._version import __version__

# Export only the current widget/factory used by the manifest
from ._widget import MaskCurationWidget, make_mask_curation_widget

__all__ = [
    "__version__",
    "MaskCurationWidget",
    "make_mask_curation_widget",
]
