"""
Configuration modules for the coordination system.
"""

# Empty init to avoid circular imports
# Import directly from auto_run when needed