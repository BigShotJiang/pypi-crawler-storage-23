"""Network layer for Git plugin."""
from .git_network import GitNetwork

__all__ = ["GitNetwork"]
