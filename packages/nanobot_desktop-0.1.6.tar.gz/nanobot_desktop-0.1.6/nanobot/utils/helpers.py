"""Utility functions for nanobot."""

import re
from datetime import datetime
from pathlib import Path


def ensure_dir(path: Path) -> Path:
    """Ensure directory exists, return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_data_path() -> Path:
    """~/.nanobot data directory."""
    return ensure_dir(Path.home() / ".nanobot")


def get_workspace_path(workspace: str | None = None) -> Path:
    """Resolve and ensure workspace path. Defaults to ~/.nanobot/workspace."""
    path = Path(workspace).expanduser() if workspace else Path.home() / ".nanobot" / "workspace"
    return ensure_dir(path)


def timestamp() -> str:
    """Current ISO timestamp."""
    return datetime.now().isoformat()


_UNSAFE_CHARS = re.compile(r'[<>:"/\\|?*]')

def safe_filename(name: str) -> str:
    """Replace unsafe path characters with underscores."""
    return _UNSAFE_CHARS.sub("_", name).strip()


def sync_workspace_templates(workspace: Path, silent: bool = False) -> list[str]:
    """Sync bundled templates to workspace. Only creates missing files."""
    from importlib.resources import files as pkg_files
    try:
        tpl = pkg_files("nanobot") / "templates"
    except Exception:
        return []
    if not tpl.is_dir():
        return []

    added: list[str] = []

    def _write(src, dest: Path):
        if dest.exists():
            return
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(src.read_text(encoding="utf-8") if src else "", encoding="utf-8")
        added.append(str(dest.relative_to(workspace)))

    for item in tpl.iterdir():
        if item.name.endswith(".md"):
            _write(item, workspace / item.name)
    _write(tpl / "memory" / "MEMORY.md", workspace / "memory" / "MEMORY.md")
    _write(None, workspace / "memory" / "HISTORY.md")
    (workspace / "skills").mkdir(exist_ok=True)
    (workspace / "scripts").mkdir(exist_ok=True)
    (workspace / "out").mkdir(exist_ok=True)

    if added and not silent:
        from rich.console import Console
        for name in added:
            Console().print(f"  [dim]Created {name}[/dim]")
    return added


def sync_builtin_skills(workspace: Path, silent: bool = False) -> list[str]:
    """Copy builtin skills from nanobot/skills to workspace/skills. Skips existing to preserve user changes."""
    import shutil

    from nanobot.agent.skills import BUILTIN_SKILLS_DIR

    if not BUILTIN_SKILLS_DIR.exists():
        return []

    skills_dir = workspace / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    added: list[str] = []

    for skill_dir in BUILTIN_SKILLS_DIR.iterdir():
        if not skill_dir.is_dir():
            continue
        dest_dir = skills_dir / skill_dir.name
        if dest_dir.exists():
            continue
        try:
            shutil.copytree(skill_dir, dest_dir, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            added.append(f"skills/{skill_dir.name}")
        except OSError:
            pass

    if added and not silent:
        from rich.console import Console
        for name in added:
            Console().print(f"  [dim]Copied skill: {name}[/dim]")
    return added
