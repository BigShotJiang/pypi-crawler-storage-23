"""Fetch2Gmail: IMAP to Gmail API import with idempotent state tracking."""

__version__ = "1.0.0"
