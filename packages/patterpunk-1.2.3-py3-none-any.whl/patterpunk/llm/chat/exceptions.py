class StructuredOutputParsingError(Exception):
    pass
