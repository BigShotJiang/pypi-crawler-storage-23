import asyncio
import json
import os
import time
import uuid
from abc import ABC
from dataclasses import dataclass, field
from typing import AsyncIterator, Dict, Any, List, Optional, Set, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from patterpunk.llm.streaming import StreamChunk

from patterpunk.config.providers.google import (
    GOOGLE_APPLICATION_CREDENTIALS,
    GOOGLE_DEFAULT_MAX_TOKENS,
    GOOGLE_DEFAULT_TEMPERATURE,
    GOOGLE_DEFAULT_TOP_K,
    GOOGLE_DEFAULT_TOP_P,
    GEMINI_REGION,
)
from patterpunk.config.defaults import (
    MAX_RETRIES,
    RETRY_BASE_DELAY,
    RETRY_MAX_DELAY,
    RETRY_MIN_DELAY,
    RETRY_JITTER_FACTOR,
)
from patterpunk.lib.retry import calculate_backoff_delay

try:
    from google import genai
    from google.genai import types
    from google.genai import errors as genai_errors
    from google.oauth2 import service_account
    from google.auth.transport.requests import Request

    google_genai_available = True
except ImportError:
    google_genai_available = False

from patterpunk.llm.messages.base import Message
from patterpunk.llm.messages.roles import ROLE_SYSTEM, ROLE_USER, ROLE_ASSISTANT
from patterpunk.llm.messages.assistant import AssistantMessage
from patterpunk.llm.messages.tool_call import ToolCallMessage
from patterpunk.llm.messages.tool_result import ToolResultMessage
from patterpunk.llm.models.base import Model, TokenCountingError
from patterpunk.llm.thinking import ThinkingConfig
from patterpunk.llm.types import ToolDefinition, CacheChunk, ToolCall
from patterpunk.llm.output_types import OutputType
from patterpunk.llm.chunks import MultimodalChunk, TextChunk
from patterpunk.llm.messages.cache import get_multimodal_chunks, has_multimodal_content
from patterpunk.logger import logger, logger_llm


class GoogleAuthenticationError(Exception):
    pass


class GoogleRateLimitError(Exception):
    pass


class GoogleMaxTokensError(Exception):
    pass


class GoogleNotImplemented(Exception):
    pass


class GoogleAPIError(Exception):
    pass


@dataclass
class ToolResultBatch:
    """Batch of consecutive tool results for Google API.

    Google requires all function responses for a single function call turn
    to be in a single Content message. This dataclass holds the batched results.
    """

    results: List[Dict[str, Any]] = field(default_factory=list)
    role: str = "tool_result_batch"


class GoogleModel(Model, ABC):
    client: Optional[genai.Client] = None

    @staticmethod
    def get_client(
        location: str,
        google_account_credentials: Optional[str] = None,
    ):
        if google_account_credentials is None:
            google_account_credentials = GOOGLE_APPLICATION_CREDENTIALS
        if not google_account_credentials:
            raise GoogleAuthenticationError(
                "No Google account credentials provided. Please pass `google_account_credentials` to constructor or set `PP_GOOGLE_ACCOUNT_CREDENTIALS` environment variable."
            )

        from json import JSONDecodeError

        try:
            credentials_info = json.loads(google_account_credentials)
        except JSONDecodeError:
            raise GoogleAuthenticationError(
                f"Provided credentials were not in JSON format, please provide the account key .json file as a one-line string in json format"
            )

        credentials = service_account.Credentials.from_service_account_info(
            credentials_info,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        credentials.refresh(Request())
        project_id = credentials_info["project_id"]

        return genai.Client(
            vertexai=True,
            project=project_id,
            location=location,
            credentials=credentials,
        )

    def __init__(
        self,
        model: str,
        location: str = GEMINI_REGION,
        temperature: float = GOOGLE_DEFAULT_TEMPERATURE,
        top_p: float = GOOGLE_DEFAULT_TOP_P,
        top_k: int = GOOGLE_DEFAULT_TOP_K,
        max_tokens: int = GOOGLE_DEFAULT_MAX_TOKENS,
        google_account_credentials: Optional[str] = None,
        client: Optional[genai.Client] = None,
        thinking_config: Optional[ThinkingConfig] = None,
    ):
        if not google_genai_available:
            raise ImportError(
                "The google-genai package is not installed. "
                "Please install it with `pip install google-genai`"
            )
        if google_account_credentials and client:
            raise ValueError(
                "Cannot set both `google_account_credentials` and `client`"
            )

        thinking_budget = None
        include_thoughts = False
        if thinking_config is not None:
            if thinking_config.token_budget is not None:
                thinking_budget = min(thinking_config.token_budget, 24576)
            else:
                effort_to_tokens = {"low": 1500, "medium": 4000, "high": 12000}
                thinking_budget = effort_to_tokens[thinking_config.effort]
            include_thoughts = thinking_config.include_thoughts

        if client:
            self.client = client
        else:
            if not GoogleModel.client:
                GoogleModel.client = GoogleModel.get_client(
                    location, google_account_credentials
                )
            self.client = (
                GoogleModel.get_client(location, google_account_credentials)
                if google_account_credentials
                else GoogleModel.client
            )

        self.model = model
        self.location = location
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        self.max_tokens = max_tokens
        self.thinking_budget = thinking_budget
        self.include_thoughts = include_thoughts
        self.thinking_config = thinking_config
        self._logged_message_ids: Set[str] = set()

    def _get_log_mode(self) -> str:
        """Get logging mode from environment. Checked each time to allow runtime changes."""
        return os.environ.get("PP_LLM_LOG_MODE", "full").lower()

    def _log_request_start(self, messages: List[Message]) -> None:
        """Log request start with message history at DEBUG level.

        Respects PP_LLM_LOG_MODE environment variable:
        - 'full': Log all messages on every request (default)
        - 'incremental': Log only new messages since last request
        """
        header = "─" * 60
        logger_llm.debug(f"\n{header}\n Google Vertex AI Request\n{header}")

        log_mode = self._get_log_mode()

        if log_mode == "incremental":
            # Find messages we haven't logged yet
            new_messages = []
            skipped_count = 0
            for message in messages:
                if message.id in self._logged_message_ids:
                    skipped_count += 1
                else:
                    new_messages.append(message)
                    self._logged_message_ids.add(message.id)

            if skipped_count > 0:
                logger_llm.debug(f"  ... {skipped_count} earlier messages ...")

            messages_to_log = new_messages
        else:
            # Full mode: log everything
            messages_to_log = messages

        for message in messages_to_log:
            self._log_single_message(message)

    def _log_single_message(self, message: Message) -> None:
        """Log a single message with role and content."""
        role = message.role

        # Handle special message types
        if isinstance(message, ToolCallMessage):
            tool_info = [f"{tc.name}({tc.arguments})" for tc in message.tool_calls]
            content = ", ".join(tool_info)
        elif isinstance(message, ToolResultMessage):
            func = message.function_name or "unknown"
            content = f"{func} → {message.content}"
        else:
            content = message.get_content_as_string()

        # Format: role on own line, content indented below
        logger_llm.debug(f"[{role}]")
        for line in content.split("\n"):
            logger_llm.debug(f"    {line}")

    def _log_request_parameters(self, tools: Optional[ToolDefinition]) -> None:
        """Log model parameters at DEBUG level."""
        parts = [f"model={self.model}", f"temp={self.temperature}"]

        if tools:
            tool_names = [
                t["function"]["name"]
                for t in tools
                if t.get("type") == "function" and "function" in t
            ]
            parts.append(f"tools=[{', '.join(tool_names)}]")

        if self.thinking_budget is not None:
            parts.append(f"thinking={self.thinking_budget}")

        logger_llm.debug(f"[params] {', '.join(parts)}")

    def _log_response(
        self,
        message: Union["AssistantMessage", "ToolCallMessage"],
    ) -> None:
        """Log assistant response at DEBUG level."""
        # Mark this message as logged so it won't appear again in incremental mode
        self._logged_message_ids.add(message.id)

        if isinstance(message, ToolCallMessage):
            tool_info = [f"{tc.name}({tc.arguments})" for tc in message.tool_calls]
            logger_llm.debug(f"[response] Tool calls: {', '.join(tool_info)}")
        else:
            content = message.get_content_as_string()
            logger_llm.debug("[response]")
            for line in content.split("\n"):
                logger_llm.debug(f"    {line}")

        if hasattr(message, "thinking_blocks") and message.thinking_blocks:
            logger_llm.debug(f"[thinking] {len(message.thinking_blocks)} block(s)")

    def _log_streaming_complete(
        self,
        text_content: str,
        tool_calls: Optional[List[ToolCall]] = None,
        thinking_present: bool = False,
        usage: Optional[dict] = None,
    ) -> None:
        """Log streaming response after completion."""
        if tool_calls:
            tool_info = [f"{tc.name}({tc.arguments})" for tc in tool_calls]
            logger_llm.debug(f"[response] Tool calls: {', '.join(tool_info)}")
        elif text_content:
            logger_llm.debug("[response]")
            for line in text_content.split("\n"):
                logger_llm.debug(f"    {line}")

        if thinking_present:
            logger_llm.debug("[thinking] Thinking content included")

        if usage:
            usage_parts = []
            for key in ["input_tokens", "output_tokens", "thinking_tokens"]:
                if usage.get(key):
                    label = key.replace("_tokens", "")
                    usage_parts.append(f"{label}={usage[key]}")
            if usage_parts:
                logger_llm.debug(f"[usage] {', '.join(usage_parts)}")

    def _translate_output_types_to_google_modalities(
        self, output_types: Optional[Union[List[OutputType], Set[OutputType]]]
    ) -> Optional[List[str]]:
        if not output_types:
            return None

        modality_mapping = {
            OutputType.TEXT: "TEXT",
            OutputType.IMAGE: "IMAGE",
        }

        modalities = []
        for output_type in output_types:
            if output_type in modality_mapping:
                modalities.append(modality_mapping[output_type])

        return modalities if modalities else None

    def _convert_tools_to_google_format(self, tools: ToolDefinition) -> List:
        if not google_genai_available:
            return []

        type_mapping = {
            "string": "STRING",
            "number": "NUMBER",
            "integer": "INTEGER",
            "boolean": "BOOLEAN",
            "array": "ARRAY",
            "object": "OBJECT",
        }

        function_declarations = []
        for tool in tools:
            if tool.get("type") == "function" and "function" in tool:
                func = tool["function"]

                properties = {}
                for prop_name, prop_def in (
                    func["parameters"].get("properties", {}).items()
                ):
                    json_type = prop_def.get("type", "string")
                    google_type = type_mapping.get(json_type.lower(), "STRING")

                    properties[prop_name] = types.Schema(
                        type=google_type, description=prop_def.get("description", "")
                    )

                function_declaration = types.FunctionDeclaration(
                    name=func["name"],
                    description=func["description"],
                    parameters=types.Schema(
                        type="OBJECT",
                        properties=properties,
                        required=func["parameters"].get("required", []),
                    ),
                )
                function_declarations.append(function_declaration)

        if function_declarations:
            return [types.Tool(function_declarations=function_declarations)]
        return []

    def _create_cache_objects_for_chunks(
        self, chunks: List[Union[CacheChunk, TextChunk]]
    ) -> dict[str, str]:
        cache_mappings = {}

        if not google_genai_available:
            return cache_mappings

        for i, chunk in enumerate(chunks):
            if (
                isinstance(chunk, CacheChunk)
                and chunk.cacheable
                and len(chunk.content) > 32000
            ):
                cache_id = f"cache_chunk_{i}_{hash(chunk.content)}"

                try:
                    cached_content = self.client.caches.create(
                        config=types.CreateCachedContentConfig(
                            model=self.model,
                            contents=[
                                types.Content(
                                    parts=[types.Part.from_text(chunk.content)]
                                )
                            ],
                            ttl=chunk.ttl or types.Timedelta(hours=1),
                        )
                    )
                    cache_mappings[cache_id] = cached_content.name
                except Exception as e:
                    logger.warning(f"Failed to create cache for chunk {i}: {e}")

        return cache_mappings

    def _convert_message_content_for_google(self, content) -> List:
        if isinstance(content, str):
            return [types.Part.from_text(text=content)]

        parts = []

        for chunk in content:
            if isinstance(chunk, TextChunk):
                parts.append(types.Part.from_text(text=chunk.content))
            elif isinstance(chunk, CacheChunk):
                parts.append(types.Part.from_text(text=chunk.content))
            elif isinstance(chunk, MultimodalChunk):
                if chunk.source_type == "gcs_uri":
                    parts.append(
                        types.Part.from_uri(
                            uri=chunk.get_url(),
                            mime_type=chunk.media_type or "application/octet-stream",
                        )
                    )
                elif hasattr(chunk, "file_id"):
                    parts.append(chunk.file_id)
                else:
                    media_type = chunk.media_type or "application/octet-stream"

                    if chunk.source_type == "url":
                        chunk = chunk.download()

                    parts.append(
                        types.Part.from_bytes(
                            data=chunk.to_bytes(), mime_type=media_type
                        )
                    )

        return parts

    def upload_file_to_google(self, chunk: MultimodalChunk):
        import tempfile
        import os

        with tempfile.NamedTemporaryFile(
            suffix=f".{chunk.filename.split('.')[-1] if chunk.filename else 'bin'}",
            delete=False,
        ) as tmp_file:
            tmp_file.write(chunk.to_bytes())
            tmp_file_path = tmp_file.name

        try:
            uploaded_file = self.client.files.upload(file=tmp_file_path)
            return uploaded_file
        finally:
            os.unlink(tmp_file_path)

    def _parse_tool_response_data(self, content: str) -> Dict[str, Any]:
        """Parse tool response content, ensuring dict format for Google API.

        Google requires tool responses to be dicts. This method handles:
        - Valid JSON dict: returned as-is
        - Valid JSON non-dict: wrapped in {"result": value}
        - Invalid JSON: wrapped in {"result": content}

        Args:
            content: The raw tool response content string

        Returns:
            A dict suitable for Google's function_response API
        """
        try:
            response_data = json.loads(content)
            if isinstance(response_data, dict):
                return response_data
            return {"result": response_data}
        except (json.JSONDecodeError, TypeError):
            return {"result": content}

    def _batch_consecutive_tool_results(
        self, messages: List[Message]
    ) -> List[Union[Message, ToolResultBatch]]:
        """
        Batch consecutive tool_result messages into a single batch message.

        Google requires all function responses for a single function call turn
        to be in a single Content message. This method groups consecutive
        tool_result messages together.

        Args:
            messages: List of messages to process

        Returns:
            List with consecutive tool_results grouped into ToolResultBatch objects
        """
        result: List[Union[Message, ToolResultBatch]] = []
        pending_results: List[Dict[str, Any]] = []

        for message in messages:
            if message.role == "tool_result":
                if not message.function_name:
                    raise ValueError(
                        "Google Vertex AI requires function_name in ToolResultMessage."
                    )

                response_data = self._parse_tool_response_data(message.content)
                pending_results.append(
                    {"name": message.function_name, "response": response_data}
                )
            else:
                # Flush any pending results before adding non-tool-result message
                if pending_results:
                    result.append(ToolResultBatch(results=pending_results))
                    pending_results = []
                result.append(message)

        # Flush any remaining results at the end
        if pending_results:
            result.append(ToolResultBatch(results=pending_results))

        return result

    def _convert_messages_for_google_with_cache(
        self, messages: List[Message]
    ) -> tuple[List[types.Content], dict[str, str]]:
        contents = []
        all_cache_mappings = {}

        # Pre-process: batch consecutive tool_result messages
        # Google requires all function responses for a single turn in one Content
        batched_messages = self._batch_consecutive_tool_results(messages)

        for message in batched_messages:
            if message.role == ROLE_SYSTEM:
                continue

            if message.role == "tool_call":
                # Serialize ToolCallMessage as model role with functionCall parts
                parts = []
                for tool_call in message.tool_calls:
                    # Parse arguments from JSON string
                    try:
                        arguments = json.loads(tool_call.arguments)
                    except (json.JSONDecodeError, KeyError):
                        arguments = {}

                    # Google uses FunctionCall for tool requests
                    parts.append(
                        types.Part.from_function_call(
                            name=tool_call.name, args=arguments
                        )
                    )

                contents.append(types.Content(role="model", parts=parts))
                continue

            if message.role == "tool_result_batch":
                # Handle batched tool results (multiple results in one Content)
                parts = []
                for tool_result in message.results:
                    parts.append(
                        types.Part.from_function_response(
                            name=tool_result["name"], response=tool_result["response"]
                        )
                    )
                contents.append(types.Content(role="user", parts=parts))
                continue

            if message.role == "tool_result":
                # Validate required field for Google
                if not message.function_name:
                    raise ValueError(
                        "Google Vertex AI requires function_name in ToolResultMessage. "
                        "Ensure ToolResultMessage is created with function_name from the original ToolCallMessage."
                    )

                response_data = self._parse_tool_response_data(message.content)

                # Google uses functionResponse for tool results
                parts = [
                    types.Part.from_function_response(
                        name=message.function_name, response=response_data
                    )
                ]

                contents.append(types.Content(role="user", parts=parts))
                continue

            if isinstance(message.content, list):
                if has_multimodal_content(message.content):
                    parts = self._convert_message_content_for_google(message.content)
                    has_text = any(
                        isinstance(chunk, (TextChunk, CacheChunk))
                        for chunk in message.content
                    )
                    if not has_text:
                        raise ValueError(
                            "Google requires at least one text block when multimodal content is present. "
                            "Please include text content along with your images or other media."
                        )
                else:
                    cache_mappings = self._create_cache_objects_for_chunks(
                        message.content
                    )
                    all_cache_mappings.update(cache_mappings)

                    parts = []
                    for chunk in message.content:
                        parts.append(types.Part.from_text(text=chunk.content))
            else:
                parts = [types.Part.from_text(text=message.get_content_as_string())]

            if message.role == ROLE_USER:
                contents.append(
                    types.Content(
                        role="user",
                        parts=parts,
                    )
                )
            elif message.role == ROLE_ASSISTANT:
                contents.append(types.Content(role="model", parts=parts))

        return contents, all_cache_mappings

    def _convert_system_messages_for_google_with_cache(
        self, messages: List[Message]
    ) -> str:
        system_parts = []

        for message in messages:
            if message.role == ROLE_SYSTEM:
                if isinstance(message.content, list):
                    content_str = "\n\n".join(
                        chunk.content for chunk in message.content
                    )
                    system_parts.append(content_str)
                else:
                    system_parts.append(message.content)

        return "\n\n".join(system_parts)

    def _build_generation_config(
        self,
        tools: Optional[ToolDefinition],
        structured_output: Optional[object],
        output_types: Optional[Union[List[OutputType], Set[OutputType]]],
        system_instruction: Optional[str],
    ) -> types.GenerateContentConfig:
        config = types.GenerateContentConfig(
            max_output_tokens=self.max_tokens,
            temperature=self.temperature,
            top_p=self.top_p,
            top_k=self.top_k,
        )

        response_modalities = self._translate_output_types_to_google_modalities(
            output_types
        )
        if response_modalities:
            config.response_modalities = response_modalities

        if self.thinking_budget is not None or self.include_thoughts:
            thinking_config_kwargs = {}
            if self.thinking_budget is not None:
                thinking_config_kwargs["thinking_budget"] = self.thinking_budget
            if self.include_thoughts:
                thinking_config_kwargs["include_thoughts"] = self.include_thoughts
            config.thinking_config = types.ThinkingConfig(**thinking_config_kwargs)

        if system_instruction:
            config.system_instruction = system_instruction

        if tools:
            google_tools = self._convert_tools_to_google_format(tools)
            if google_tools:
                config.tools = google_tools
                config.automatic_function_calling = (
                    types.AutomaticFunctionCallingConfig(disable=True)
                )

        if structured_output:
            config.response_mime_type = "application/json"
            if hasattr(structured_output, "__annotations__"):
                config.response_schema = structured_output
            else:
                config.response_schema = structured_output

        return config

    def _prepare_generation_request(
        self,
        messages: List[Message],
        tools: Optional[ToolDefinition] = None,
        structured_output: Optional[object] = None,
        output_types: Optional[Union[List[OutputType], Set[OutputType]]] = None,
    ) -> tuple[List[types.Content], types.GenerateContentConfig, dict[str, str]]:
        system_instruction = self._convert_system_messages_for_google_with_cache(
            messages
        )

        contents, cache_mappings = self._convert_messages_for_google_with_cache(
            messages
        )

        config = self._build_generation_config(
            tools, structured_output, output_types, system_instruction
        )

        return contents, config, cache_mappings

    def _process_generation_response(
        self, response, structured_output: Optional[object]
    ) -> Union[Message, "ToolCallMessage"]:
        if hasattr(response, "candidates") and response.candidates:
            candidate = response.candidates[0]
            if hasattr(candidate, "content") and candidate.content.parts:
                tool_calls = []
                chunks = []
                thinking_blocks = []

                for part in candidate.content.parts:
                    if (
                        hasattr(part, "function_call")
                        and part.function_call is not None
                    ):
                        tool_calls.append(
                            ToolCall(
                                id=f"call_{part.function_call.name}_{uuid.uuid4().hex[:8]}",
                                name=part.function_call.name,
                                arguments=json.dumps(dict(part.function_call.args)),
                            )
                        )

                    elif hasattr(part, "text") and part.text and part.text != "None":
                        if getattr(part, "thought", False):
                            thinking_blocks.append(
                                {"type": "thinking", "thinking": part.text}
                            )
                        else:
                            chunks.append(TextChunk(part.text))

                    elif hasattr(part, "inline_data") and part.inline_data:
                        mime_type = getattr(part.inline_data, "mime_type", None)
                        data = getattr(part.inline_data, "data", None)
                        if data and mime_type:
                            if isinstance(data, bytes):
                                image_chunk = MultimodalChunk.from_bytes(
                                    data, media_type=mime_type
                                )
                            else:
                                image_chunk = MultimodalChunk.from_base64(
                                    data, media_type=mime_type
                                )
                            chunks.append(image_chunk)

                thoughts_token_count = getattr(
                    getattr(response, "usage_metadata", None),
                    "thoughts_token_count",
                    None,
                )
                thinking_kwargs = {}
                if thinking_blocks:
                    thinking_kwargs["thinking_blocks"] = thinking_blocks
                if thoughts_token_count is not None:
                    thinking_kwargs["thinking_token_count"] = thoughts_token_count

                if tool_calls:
                    return ToolCallMessage(tool_calls, **thinking_kwargs)

                if chunks:
                    if len(chunks) == 1 and isinstance(chunks[0], TextChunk):
                        return AssistantMessage(
                            chunks[0].content,
                            structured_output=structured_output,
                            **thinking_kwargs,
                        )
                    else:
                        return AssistantMessage(
                            chunks,
                            structured_output=structured_output,
                            **thinking_kwargs,
                        )

        try:
            if hasattr(response, "text") and response.text:
                content = response.text
                return AssistantMessage(content, structured_output=structured_output)
        except Exception:
            pass

        raise GoogleAPIError("No content found in Vertex AI response")

    def generate_assistant_message(
        self,
        messages: List[Message],
        tools: Optional[ToolDefinition] = None,
        structured_output: Optional[object] = None,
        output_types: Optional[Union[List[OutputType], Set[OutputType]]] = None,
    ) -> Union[Message, "ToolCallMessage"]:
        self._log_request_start(messages)

        contents, config, cache_mappings = self._prepare_generation_request(
            messages, tools, structured_output, output_types
        )

        self._log_request_parameters(tools)

        retry_count = 0

        while retry_count < MAX_RETRIES:
            try:
                response = self.client.models.generate_content(
                    model=self.model, contents=contents, config=config
                )

                result = self._process_generation_response(response, structured_output)
                self._log_response(result)
                return result

            except genai_errors.APIError as error:
                if error.code == 429:
                    if retry_count >= MAX_RETRIES - 1:
                        raise GoogleRateLimitError(
                            f"Rate limit exceeded after {retry_count + 1} retries"
                        ) from error

                    # Calculate delay with exponential backoff and jitter
                    wait_time = calculate_backoff_delay(
                        attempt=retry_count,
                        base_delay=RETRY_BASE_DELAY,
                        max_delay=RETRY_MAX_DELAY,
                        min_delay=RETRY_MIN_DELAY,
                        jitter_factor=RETRY_JITTER_FACTOR,
                    )

                    logger.warning(
                        f"VertexAI: Rate limit hit, attempt {retry_count + 1}/{MAX_RETRIES}. "
                        f"Waiting {wait_time:.1f} seconds before retry."
                    )

                    time.sleep(wait_time)
                    retry_count += 1
                    continue
                else:
                    logger.error(f"VertexAI: Unexpected Api error {error}")
                    raise error
            except Exception as e:
                raise GoogleAPIError(f"Error generating content: {str(e)}") from e

        raise GoogleAPIError(
            "Unexpected outcome - out of retries, but neither error raised or message returned"
        )

    @staticmethod
    def get_available_models(location: Optional[str] = None) -> List[str]:
        default_models = [
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.0-flash",
        ]

        if not google_genai_available:
            return default_models

        try:
            if not GoogleModel.client:
                GoogleModel.client = GoogleModel.get_client(location=GEMINI_REGION)

            client = (
                GoogleModel.get_client(location=location)
                if location
                else GoogleModel.client
            )

            gemini_models = []
            for model in client.models.list(config={"page_size": 100}):
                model_name = model.name.lower()
                if "gemini" in model_name:
                    if model_name.startswith("publishers/google/models/"):
                        model_name = model_name[len("publishers/google/models/") :]
                    gemini_models.append(model_name)

            if not gemini_models:
                return default_models
            return gemini_models
        except Exception:
            return default_models

    @staticmethod
    def get_name():
        return "Vertex AI"

    def _prepare_count_tokens_contents(
        self, content: Union[str, Message, List[Message]]
    ) -> List[types.Content]:
        """
        Prepare contents list for count_tokens API call.

        Converts strings, single messages, or message lists to Google Content format.
        """
        if isinstance(content, str):
            return [
                types.Content(role="user", parts=[types.Part.from_text(text=content)])
            ]
        elif isinstance(content, list):
            return self._convert_messages_for_token_counting(content)
        else:
            return self._convert_messages_for_token_counting([content])

    def count_tokens(self, content: Union[str, Message, List[Message]]) -> int:
        """
        Count tokens using Google's API.

        This makes an API call to Google's count_tokens endpoint, which accurately
        counts all content types including images, audio, and video. For batch
        counting of multiple messages, a single API call is made.

        Args:
            content: A string, single Message, or list of Messages

        Returns:
            Number of tokens

        Raises:
            TokenCountingError: If counting fails
        """
        try:
            contents = self._prepare_count_tokens_contents(content)
            response = self.client.models.count_tokens(
                model=self.model,
                contents=contents,
            )
            return response.total_tokens
        except genai_errors.APIError as e:
            raise TokenCountingError(f"Google API error: {e}")
        except Exception as e:
            raise TokenCountingError(f"Failed to count tokens: {e}")

    async def count_tokens_async(
        self, content: Union[str, Message, List[Message]]
    ) -> int:
        """
        Count tokens using Google's async API.

        Native async version for better concurrency.

        Args:
            content: A string, single Message, or list of Messages

        Returns:
            Number of tokens

        Raises:
            TokenCountingError: If counting fails
        """
        try:
            contents = self._prepare_count_tokens_contents(content)
            response = await self.client.aio.models.count_tokens(
                model=self.model,
                contents=contents,
            )
            return response.total_tokens
        except genai_errors.APIError as e:
            raise TokenCountingError(f"Google API error: {e}")
        except Exception as e:
            raise TokenCountingError(f"Failed to count tokens: {e}")

    def _convert_messages_for_token_counting(
        self, messages: List[Message]
    ) -> List[types.Content]:
        """
        Convert messages to Google format for token counting.

        Filters out system messages and uses existing conversion methods.
        """
        non_system = [m for m in messages if m.role != ROLE_SYSTEM]
        contents, _ = self._convert_messages_for_google_with_cache(non_system)
        return contents

    def __deepcopy__(self, memo_dict):
        new_model = GoogleModel(
            model=self.model,
            location=self.location,
            temperature=self.temperature,
            top_p=self.top_p,
            top_k=self.top_k,
            max_tokens=self.max_tokens,
            client=self.client,
            thinking_config=self.thinking_config,
        )
        new_model._logged_message_ids = self._logged_message_ids.copy()
        return new_model

    async def _stream_with_retry(
        self,
        contents: List[types.Content],
        config: types.GenerateContentConfig,
        max_retries: int,
    ) -> AsyncIterator:
        """
        Execute streaming request with retry logic for API errors.

        429 errors occur at request initiation (before streaming begins),
        so we can safely retry the entire request without data loss.

        Uses exponential backoff with jitter (±50%) for consistent behavior
        across all providers. Minimum delay of 45s respects rate limit windows.

        Args:
            contents: The message contents in Google format
            config: The generation config
            max_retries: Maximum number of retry attempts

        Yields:
            Stream chunks from the API

        Raises:
            GoogleRateLimitError: After exhausting all retries on 429 errors
            GoogleAPIError: For other API errors
        """
        retry_count = 0

        while retry_count < max_retries:
            try:
                # Create stream and iterate - error surfaces on first iteration if 429
                stream = await self.client.aio.models.generate_content_stream(
                    model=self.model, contents=contents, config=config
                )

                # Yield all events from stream
                async for chunk in stream:
                    yield chunk

                return  # Success - exit retry loop

            except genai_errors.APIError as error:
                if error.code == 429:
                    if retry_count >= max_retries - 1:
                        # Exhausted retries
                        raise GoogleRateLimitError(
                            f"Rate limit exceeded after {retry_count + 1} retries"
                        ) from error

                    # Calculate delay with exponential backoff and jitter
                    wait_time = calculate_backoff_delay(
                        attempt=retry_count,
                        base_delay=RETRY_BASE_DELAY,
                        max_delay=RETRY_MAX_DELAY,
                        min_delay=RETRY_MIN_DELAY,
                        jitter_factor=RETRY_JITTER_FACTOR,
                    )

                    logger.warning(
                        f"VertexAI: Rate limit hit during streaming, "
                        f"attempt {retry_count + 1}/{max_retries}. "
                        f"Waiting {wait_time:.1f} seconds before retry."
                    )

                    await asyncio.sleep(wait_time)
                    retry_count += 1
                else:
                    # Non-retryable error
                    logger.error(
                        f"VertexAI: Unexpected API error during streaming: {error}"
                    )
                    raise GoogleAPIError(
                        f"Streaming API error: {str(error)}"
                    ) from error

    async def stream_assistant_message(
        self,
        messages: List[Message],
        tools: Optional[ToolDefinition] = None,
        structured_output: Optional[object] = None,
        output_types: Optional[Union[List[OutputType], Set[OutputType]]] = None,
    ) -> AsyncIterator["StreamChunk"]:
        """
        Stream the assistant message response from Google Vertex AI.

        Yields StreamChunk objects for each streaming event.
        Uses the client.aio.models.generate_content_stream() async API.
        Includes retry logic for 429 rate limit errors.
        """
        from patterpunk.llm.streaming import StreamChunk, StreamEventType

        self._log_request_start(messages)

        contents, config, _ = self._prepare_generation_request(
            messages, tools, structured_output, output_types
        )

        self._log_request_parameters(tools)

        usage_info = None

        # Track accumulated response for logging
        accumulated_text: List[str] = []
        accumulated_tool_calls: List[ToolCall] = []
        thinking_present = False

        # Use retry wrapper instead of direct call
        async for chunk in self._stream_with_retry(
            contents=contents,
            config=config,
            max_retries=MAX_RETRIES,
        ):
            # Yield all events from this chunk
            for stream_chunk in self._convert_stream_chunk_to_events(chunk):
                # Accumulate for final logging
                if stream_chunk.event_type == StreamEventType.TEXT_DELTA:
                    if stream_chunk.text:
                        accumulated_text.append(stream_chunk.text)
                elif stream_chunk.event_type == StreamEventType.THINKING_DELTA:
                    thinking_present = True
                elif stream_chunk.event_type == StreamEventType.TOOL_USE_START:
                    accumulated_tool_calls.append(
                        ToolCall(
                            id=stream_chunk.tool_call_id or "",
                            name=stream_chunk.tool_name or "",
                            arguments="",
                        )
                    )
                elif stream_chunk.event_type == StreamEventType.TOOL_USE_DELTA:
                    if accumulated_tool_calls and stream_chunk.tool_arguments_delta:
                        last = accumulated_tool_calls[-1]
                        accumulated_tool_calls[-1] = ToolCall(
                            id=last.id,
                            name=last.name,
                            arguments=last.arguments
                            + stream_chunk.tool_arguments_delta,
                        )

                yield stream_chunk

            # Check for usage metadata in the chunk
            if hasattr(chunk, "usage_metadata") and chunk.usage_metadata:
                usage_info = {
                    "input_tokens": getattr(
                        chunk.usage_metadata, "prompt_token_count", 0
                    ),
                    "output_tokens": getattr(
                        chunk.usage_metadata, "candidates_token_count", 0
                    ),
                }
                thoughts = getattr(chunk.usage_metadata, "thoughts_token_count", None)
                if thoughts is not None and thoughts > 0:
                    usage_info["thinking_tokens"] = thoughts

        # Log complete response after stream ends
        self._log_streaming_complete(
            text_content="".join(accumulated_text),
            tool_calls=accumulated_tool_calls if accumulated_tool_calls else None,
            thinking_present=thinking_present,
            usage=usage_info,
        )

        # Yield final MESSAGE_END event with usage statistics
        yield StreamChunk(
            event_type=StreamEventType.MESSAGE_END,
            usage=usage_info or {"input_tokens": 0, "output_tokens": 0},
        )

    def _convert_stream_chunk_to_events(self, chunk) -> List["StreamChunk"]:
        """
        Convert a Google streaming chunk to StreamChunk events.

        Returns a list of events. Google returns function calls complete in a single
        chunk, so we yield TOOL_USE_START, TOOL_USE_DELTA, and CONTENT_BLOCK_STOP
        for each function call to match the expected streaming protocol.
        """
        from patterpunk.llm.streaming import StreamChunk, StreamEventType

        events: List["StreamChunk"] = []

        # Extract parts from chunk, handling missing/empty attributes gracefully
        try:
            parts = chunk.candidates[0].content.parts
            if not parts:
                return events
        except (AttributeError, IndexError, TypeError):
            return events

        for part in parts:
            # Handle text content (check if it's thinking or regular text)
            text = getattr(part, "text", None)
            if text:
                # part.thought is a boolean flag indicating thinking content
                is_thinking = getattr(part, "thought", False)
                event_type = (
                    StreamEventType.THINKING_DELTA
                    if is_thinking
                    else StreamEventType.TEXT_DELTA
                )
                events.append(
                    StreamChunk(
                        event_type=event_type,
                        text=text,
                    )
                )

            # Handle function calls
            # Google returns function calls complete in a single chunk,
            # so we emit TOOL_USE_START, TOOL_USE_DELTA, and CONTENT_BLOCK_STOP
            func_call = getattr(part, "function_call", None)
            if func_call is not None:
                tool_call_id = f"call_{func_call.name}_{uuid.uuid4().hex[:8]}"

                # Emit TOOL_USE_START with id and name
                events.append(
                    StreamChunk(
                        event_type=StreamEventType.TOOL_USE_START,
                        tool_call_id=tool_call_id,
                        tool_name=func_call.name,
                    )
                )

                # Emit TOOL_USE_DELTA with arguments
                args_json = json.dumps(dict(func_call.args)) if func_call.args else "{}"
                events.append(
                    StreamChunk(
                        event_type=StreamEventType.TOOL_USE_DELTA,
                        tool_arguments_delta=args_json,
                    )
                )

                # Emit CONTENT_BLOCK_STOP to finalize the tool call
                events.append(
                    StreamChunk(
                        event_type=StreamEventType.CONTENT_BLOCK_STOP,
                    )
                )

        return events
