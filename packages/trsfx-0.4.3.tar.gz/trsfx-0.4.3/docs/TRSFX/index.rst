Crystallographic Indexing
=========================
.. automodule:: TRSFX.indexer
    :members: