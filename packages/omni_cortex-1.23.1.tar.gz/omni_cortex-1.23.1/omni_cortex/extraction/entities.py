"""Entity extraction from memory content.

Supports regex-based extraction (always available) and optional
LLM-enhanced extraction via Anthropic API. Extracts people, projects,
technologies, concepts, organizations, files, and services.
"""

import json
import logging
import os
import re
from dataclasses import dataclass, field

try:
    import httpx as _httpx
except ImportError:
    _httpx = None  # type: ignore[assignment]

ENTITY_TYPES = [
    "person", "project", "technology", "concept",
    "organization", "file", "service",
]

# Known project names (high-confidence matches)
_KNOWN_PROJECTS = [
    "Omni-Cortex", "omni-cortex", "Claude Code", "claude-code",
    "claude-collab-kit", "Surity", "ButterCut",
]

# Known organization names
_KNOWN_ORGS = [
    "Anthropic", "GitHub", "Google", "Microsoft", "OpenAI",
    "AllCytes", "Amazon", "AWS", "Meta", "Apple",
    "Vercel", "Supabase", "Cloudflare", "Netlify",
]

# Known service names
_KNOWN_SERVICES = [
    "Gemini API", "Claude API", "Nano Banana Pro", "GitHub API",
    "Airtable API", "Supabase", "n8n", "PyPI", "npm",
    "Docker Hub", "Shodan", "crt.sh",
]

# Technology patterns (subset of auto_tags.py for entity extraction)
_TECH_PATTERNS: list[tuple[re.Pattern, str]] = [
    # Languages
    (re.compile(r"\bPython\b"), "Python"),
    (re.compile(r"\bJavaScript\b", re.IGNORECASE), "JavaScript"),
    (re.compile(r"\bTypeScript\b", re.IGNORECASE), "TypeScript"),
    (re.compile(r"\bRust\b"), "Rust"),
    (re.compile(r"\bGo(?:lang)?\b"), "Go"),
    (re.compile(r"\bJava\b"), "Java"),
    (re.compile(r"\bC\+\+\b"), "C++"),
    (re.compile(r"\bRuby\b"), "Ruby"),
    (re.compile(r"\bSQL\b"), "SQL"),
    (re.compile(r"\bHTML\b"), "HTML"),
    (re.compile(r"\bCSS\b"), "CSS"),
    (re.compile(r"\bBash\b"), "Bash"),
    # Frameworks
    (re.compile(r"\bReact\b"), "React"),
    (re.compile(r"\bVue(?:\.js)?\b"), "Vue"),
    (re.compile(r"\bAngular\b"), "Angular"),
    (re.compile(r"\bSvelte\b"), "Svelte"),
    (re.compile(r"\bNext\.js\b"), "Next.js"),
    (re.compile(r"\bFastAPI\b", re.IGNORECASE), "FastAPI"),
    (re.compile(r"\bDjango\b"), "Django"),
    (re.compile(r"\bFlask\b"), "Flask"),
    (re.compile(r"\bExpress\b"), "Express"),
    (re.compile(r"\bTailwind(?:CSS)?\b", re.IGNORECASE), "Tailwind"),
    # Tools
    (re.compile(r"\bDocker\b"), "Docker"),
    (re.compile(r"\bKubernetes\b"), "Kubernetes"),
    (re.compile(r"\bGit(?:Hub|Lab)?\b"), "Git"),
    (re.compile(r"\bSQLite\b"), "SQLite"),
    (re.compile(r"\bPostgres(?:QL)?\b", re.IGNORECASE), "PostgreSQL"),
    (re.compile(r"\bRedis\b"), "Redis"),
    (re.compile(r"\bD3\.js\b"), "D3.js"),
    (re.compile(r"\bPydantic\b"), "Pydantic"),
    (re.compile(r"\bpytest\b"), "pytest"),
    (re.compile(r"\bJest\b"), "Jest"),
    (re.compile(r"\bPlaywright\b"), "Playwright"),
    (re.compile(r"\bWebpack\b"), "Webpack"),
    (re.compile(r"\bVite\b"), "Vite"),
    # Concepts (as technologies)
    (re.compile(r"\bMCP\b"), "MCP"),
    (re.compile(r"\bGraphQL\b"), "GraphQL"),
    (re.compile(r"\bREST\b"), "REST"),
    (re.compile(r"\bWebSocket\b"), "WebSocket"),
    (re.compile(r"\bOAuth\b"), "OAuth"),
    (re.compile(r"\bJWT\b"), "JWT"),
    (re.compile(r"\bFTS5\b"), "FTS5"),
]

# Concept patterns (abstract technical terms)
_CONCEPT_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bentity extraction\b", re.IGNORECASE), "entity extraction"),
    (re.compile(r"\bknowledge graph\b", re.IGNORECASE), "knowledge graph"),
    (re.compile(r"\bdeduplication\b", re.IGNORECASE), "deduplication"),
    (re.compile(r"\bconflict detection\b", re.IGNORECASE), "conflict detection"),
    (re.compile(r"\bsemantic search\b", re.IGNORECASE), "semantic search"),
    (re.compile(r"\bembedding(?:s)?\b", re.IGNORECASE), "embeddings"),
    (re.compile(r"\bmigration(?:s)?\b", re.IGNORECASE), "migration"),
    (re.compile(r"\bwebhook(?:s)?\b", re.IGNORECASE), "webhook"),
    (re.compile(r"\bmiddleware\b", re.IGNORECASE), "middleware"),
    (re.compile(r"\bcaching\b", re.IGNORECASE), "caching"),
    (re.compile(r"\bauto-tagging\b", re.IGNORECASE), "auto-tagging"),
    (re.compile(r"\bversioning\b", re.IGNORECASE), "versioning"),
]

# Person detection: Capitalized names (2+ words), @mentions
_PERSON_PATTERN = re.compile(
    r"\b([A-Z][a-z]{1,15}(?:\s[A-Z][a-z]{1,15}){1,2})\b"
)
_AT_MENTION_PATTERN = re.compile(r"@([A-Za-z][A-Za-z0-9_-]{1,30})")

# File path patterns
_FILE_PATTERN = re.compile(
    r"(?:`([a-zA-Z0-9_/\\.-]+\.[a-z]{1,5})`"  # backtick-quoted file.ext
    r"|(?:^|\s)((?:[a-zA-Z0-9_-]+/)+[a-zA-Z0-9_.-]+\.[a-z]{1,5}))"  # path/to/file.ext
)

# Project detection: CamelCase names, github repo URLs
_CAMELCASE_PATTERN = re.compile(r"\b([A-Z][a-z]+(?:[A-Z][a-z]+){1,4})\b")
_REPO_URL_PATTERN = re.compile(
    r"github\.com/([a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+)"
)

# Words that look like person names but aren't
_PERSON_STOPWORDS = {
    "The", "This", "That", "These", "Those", "Some", "None",
    "True", "False", "Error", "Warning", "Success", "Failed",
    "Build", "Phase", "Step", "Task", "Test", "Created",
    "Updated", "Deleted", "Fixed", "Added", "Removed",
    "Status", "Total", "Memory", "Session", "Version",
    "Config", "Index", "Table", "Column", "Field",
    "Schema", "Query", "Import", "Export", "Module",
    "Review", "Check", "Debug", "Deploy", "Install",
    "Global", "Local", "Project", "Current", "Recent",
    "Migration", "Default", "Custom", "Primary", "Foreign",
    "Unique", "Integer", "Select", "Insert", "Update", "Delete",
    "Where", "Order", "Group", "Count", "Summary", "Details",
    "Context", "Content", "Source", "Target", "Action",
    "Completed", "Progress", "Pending", "Override", "Manual",
    "Related", "Existing", "Available", "Required",
}

# Common first names to boost confidence
_KNOWN_FIRST_NAMES = {
    "Tony", "Ralph", "Dan", "John", "Sarah", "Mike", "Chris",
    "David", "James", "Alex", "Sam", "Ben", "Max", "Tom",
}

logger = logging.getLogger(__name__)


@dataclass
class ExtractedEntity:
    """An entity extracted from text."""

    name: str  # Normalized (lowercase)
    display_name: str  # Original casing
    type: str  # person, project, technology, etc.
    mention_context: str = ""  # Snippet showing how entity appears
    confidence: float = 1.0
    source: str = "regex"  # "regex" or "llm"


def _extract_context(text: str, match_str: str, window: int = 40) -> str:
    """Extract a snippet of context around a match."""
    idx = text.find(match_str)
    if idx == -1:
        idx = text.lower().find(match_str.lower())
    if idx == -1:
        return ""
    start = max(0, idx - window)
    end = min(len(text), idx + len(match_str) + window)
    snippet = text[start:end].strip()
    if start > 0:
        snippet = "..." + snippet
    if end < len(text):
        snippet = snippet + "..."
    return snippet


def _extract_entities_regex(
    content: str,
    context: str | None = None,
) -> list[ExtractedEntity]:
    """Extract entities from memory content using regex patterns.

    Args:
        content: The memory content text
        context: Optional additional context

    Returns:
        List of extracted entities (deduplicated by normalized name+type)
    """
    if not content:
        return []

    text = content
    if context:
        text = f"{content}\n{context}"

    seen: dict[tuple[str, str], ExtractedEntity] = {}

    def _add(name: str, display_name: str, entity_type: str,
             ctx: str = "", confidence: float = 1.0) -> None:
        key = (name.lower().strip(), entity_type)
        if key not in seen:
            seen[key] = ExtractedEntity(
                name=name.lower().strip(),
                display_name=display_name.strip(),
                type=entity_type,
                mention_context=ctx,
                confidence=confidence,
                source="regex",
            )

    # 1. Technologies (highest confidence - pattern-matched)
    for pattern, tech_name in _TECH_PATTERNS:
        if pattern.search(text):
            ctx = _extract_context(text, tech_name)
            _add(tech_name, tech_name, "technology", ctx)

    # 2. Known projects
    for project in _KNOWN_PROJECTS:
        if project in text:
            ctx = _extract_context(text, project)
            _add(project, project, "project", ctx)

    # 3. Known organizations
    for org in _KNOWN_ORGS:
        if org in text:
            ctx = _extract_context(text, org)
            _add(org, org, "organization", ctx)

    # 4. Known services
    for service in _KNOWN_SERVICES:
        if service in text:
            ctx = _extract_context(text, service)
            _add(service, service, "service", ctx)

    # 5. Concepts
    for pattern, concept_name in _CONCEPT_PATTERNS:
        if pattern.search(text):
            ctx = _extract_context(text, concept_name)
            _add(concept_name, concept_name, "concept", ctx)

    # 6. GitHub repo URLs -> projects
    for match in _REPO_URL_PATTERN.finditer(text):
        repo = match.group(1)
        ctx = _extract_context(text, match.group(0))
        _add(repo, repo, "project", ctx, confidence=0.9)

    # 7. File paths
    for match in _FILE_PATTERN.finditer(text):
        filepath = match.group(1) or match.group(2)
        if filepath and len(filepath) > 3:
            ctx = _extract_context(text, filepath)
            _add(filepath, filepath, "file", ctx, confidence=0.8)

    # 8. @mentions -> person
    for match in _AT_MENTION_PATTERN.finditer(text):
        name = match.group(1)
        ctx = _extract_context(text, f"@{name}")
        _add(name, name, "person", ctx, confidence=0.9)

    # 9. Capitalized names -> person (conservative)
    for match in _PERSON_PATTERN.finditer(text):
        full_name = match.group(1)
        words = full_name.split()
        # Skip if any word is a stopword
        if any(w in _PERSON_STOPWORDS for w in words):
            continue
        # Skip if it matches a known tech/project/org (already extracted)
        if (full_name.lower(), "technology") in seen:
            continue
        if (full_name.lower(), "project") in seen:
            continue
        if (full_name.lower(), "organization") in seen:
            continue
        ctx = _extract_context(text, full_name)
        confidence = 0.7
        if words[0] in _KNOWN_FIRST_NAMES:
            confidence = 0.9
        _add(full_name, full_name, "person", ctx, confidence)

    # 10. Single known first names (only if standalone, high-confidence)
    for name in _KNOWN_FIRST_NAMES:
        pattern = re.compile(rf"\b{re.escape(name)}\b")
        if pattern.search(text) and (name.lower(), "person") not in seen:
            ctx = _extract_context(text, name)
            _add(name, name, "person", ctx, confidence=0.8)

    return list(seen.values())


_LLM_PROMPT = """\
Extract named entities from this text. Return a JSON array of objects with keys: name, type, confidence.

Entity types (use ONLY these): person, project, technology, concept, organization, file, service

Rules:
- name: the entity name as it appears in text (preserve casing)
- type: one of the 7 types above
- confidence: 0.0-1.0 indicating extraction confidence
- Only include clearly identifiable entities, skip vague references
- For file paths, include the full path

Return ONLY a JSON array, no other text. Example:
[{"name": "Python", "type": "technology", "confidence": 0.95}]

Text to analyze:
"""

_MAX_LLM_INPUT_CHARS = 4000
_LLM_TIMEOUT_SECONDS = 15


def _extract_entities_llm(
    content: str,
    context: str | None = None,
    llm_model: str = "claude-haiku-4-5-20251001",
    llm_api_key: str = "",
) -> list[ExtractedEntity]:
    """Extract entities using the Anthropic API.

    Falls back to empty list on any failure (timeout, HTTP error, parse error).

    Args:
        content: The memory content text
        context: Optional additional context
        llm_model: Anthropic model ID
        llm_api_key: API key (falls back to ANTHROPIC_API_KEY env var)

    Returns:
        List of extracted entities, or empty list on failure
    """
    api_key = llm_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        logger.debug("LLM entity extraction skipped: no API key")
        return []

    text = content or ""
    if context:
        text = f"{text}\n{context}"
    text = text[:_MAX_LLM_INPUT_CHARS]

    if not text.strip():
        return []

    if _httpx is None:
        logger.warning("httpx not available for LLM entity extraction")
        return []

    try:
        response = _httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": llm_model,
                "max_tokens": 1024,
                "messages": [
                    {"role": "user", "content": _LLM_PROMPT + text}
                ],
            },
            timeout=_LLM_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
    except Exception as e:
        logger.debug(f"LLM entity extraction HTTP error: {e}")
        return []

    try:
        data = response.json()
        raw_text = data["content"][0]["text"].strip()

        # Strip markdown code fences if present
        if raw_text.startswith("```"):
            lines = raw_text.split("\n")
            # Remove first line (```json or ```) and last line (```)
            lines = [l for l in lines if not l.strip().startswith("```")]
            raw_text = "\n".join(lines).strip()

        entities_data = json.loads(raw_text)
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        logger.debug(f"LLM entity extraction parse error: {e}")
        return []

    if not isinstance(entities_data, list):
        return []

    results: list[ExtractedEntity] = []
    for item in entities_data:
        if not isinstance(item, dict):
            continue
        name = item.get("name", "").strip()
        etype = item.get("type", "").strip().lower()
        confidence = item.get("confidence", 0.8)
        if not name or etype not in ENTITY_TYPES:
            continue
        if not isinstance(confidence, (int, float)):
            confidence = 0.8
        confidence = max(0.0, min(1.0, float(confidence)))
        results.append(ExtractedEntity(
            name=name.lower(),
            display_name=name,
            type=etype,
            mention_context=_extract_context(text, name) if text else "",
            confidence=confidence,
            source="llm",
        ))

    return results


def _merge_entity_results(
    regex_entities: list[ExtractedEntity],
    llm_entities: list[ExtractedEntity],
) -> list[ExtractedEntity]:
    """Merge regex and LLM extraction results.

    Union keyed by (normalized_name, type). When both sources produce the
    same (name, type), the LLM version wins. Cross-type resolution: if
    regex says "X" is type A but LLM says "X" is type B, keep LLM's
    version and remove regex's.
    """
    merged: dict[tuple[str, str], ExtractedEntity] = {}

    # Start with regex results
    for ent in regex_entities:
        key = (ent.name, ent.type)
        merged[key] = ent

    # Build a lookup of LLM entity names -> types for cross-type resolution
    llm_name_types: dict[str, str] = {}
    for ent in llm_entities:
        llm_name_types[ent.name] = ent.type

    # Apply LLM results (overwrite same-key, add new)
    for ent in llm_entities:
        key = (ent.name, ent.type)
        merged[key] = ent

    # Cross-type resolution: remove regex entries where LLM assigned different type
    keys_to_remove = []
    for (name, etype), entity in merged.items():
        if entity.source == "regex" and name in llm_name_types:
            llm_type = llm_name_types[name]
            if llm_type != etype:
                keys_to_remove.append((name, etype))

    for key in keys_to_remove:
        del merged[key]

    return list(merged.values())


def extract_entities(
    content: str,
    context: str | None = None,
    *,
    llm_enabled: bool = False,
    llm_model: str = "claude-haiku-4-5-20251001",
    llm_api_key: str = "",
) -> list[ExtractedEntity]:
    """Extract entities from memory content.

    Always runs regex extraction. If llm_enabled, also runs LLM extraction
    and merges results. Falls back to regex-only if LLM returns nothing.

    Args:
        content: The memory content text
        context: Optional additional context
        llm_enabled: Whether to also use LLM-based extraction
        llm_model: Anthropic model ID for LLM extraction
        llm_api_key: API key for LLM extraction

    Returns:
        List of extracted entities (deduplicated by normalized name+type)
    """
    regex_results = _extract_entities_regex(content, context)

    if not llm_enabled:
        return regex_results

    llm_results = _extract_entities_llm(content, context, llm_model, llm_api_key)

    if not llm_results:
        return regex_results

    return _merge_entity_results(regex_results, llm_results)
