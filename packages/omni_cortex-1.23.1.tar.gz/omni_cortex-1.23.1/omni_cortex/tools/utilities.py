"""Utility tools for Omni Cortex MCP."""

import json
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict

from mcp.server.fastmcp import FastMCP

from ..database.connection import init_database
from ..database.sync import search_global_memories, get_global_stats, sync_all_project_memories
from ..models.memory import list_memories, update_memory, MemoryUpdate
from ..decay.importance import get_freshness_status, SESSION_TYPES, KNOWLEDGE_TYPES
from ..utils.timestamps import now_iso


# === Input Models ===

class ListTagsInput(BaseModel):
    """Input for listing tags."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    min_count: int = Field(1, description="Minimum usage count", ge=1)
    limit: int = Field(50, description="Maximum tags to return", ge=1, le=200)


class ReviewMemoriesInput(BaseModel):
    """Input for reviewing memories."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    action: str = Field(
        ..., description="Action: list, mark_fresh, mark_outdated, mark_archived"
    )
    days_threshold: int = Field(30, description="Review memories older than this", ge=1)
    memory_ids: Optional[list[str]] = Field(None, description="Memory IDs to update (for mark actions)")
    limit: int = Field(20, description="Maximum memories to list", ge=1, le=100)


class ExportInput(BaseModel):
    """Input for exporting data."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    format: str = Field("markdown", description="Export format: markdown, json, sqlite")
    include_activities: bool = Field(True, description="Include activities")
    include_memories: bool = Field(True, description="Include memories")
    since: Optional[str] = Field(None, description="Export data since this date (ISO 8601)")
    output_path: Optional[str] = Field(None, description="File path to save export")


class GlobalSearchInput(BaseModel):
    """Input for global cross-project search."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    query: str = Field(..., description="Search query", min_length=1)
    type_filter: Optional[str] = Field(None, description="Filter by memory type")
    tags_filter: Optional[list[str]] = Field(None, description="Filter by tags")
    project_filter: Optional[str] = Field(None, description="Filter by project path (substring match)")
    limit: int = Field(20, description="Maximum results", ge=1, le=100)


class GlobalSyncInput(BaseModel):
    """Input for syncing to global index."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    full_sync: bool = Field(False, description="Sync all project memories to global index")


class GetMemoryHistoryInput(BaseModel):
    """Input for retrieving memory version history."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    memory_id: str = Field(..., description="Memory ID to get history for")
    limit: int = Field(20, description="Maximum versions to return", ge=1, le=50)
    include_content: bool = Field(True, description="Include full content (false = metadata only)")


class SearchEntitiesInput(BaseModel):
    """Input for searching entities."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    query: str = Field(..., description="Entity name or partial match", min_length=1)
    type_filter: Optional[str] = Field(None, description="Filter by entity type (person, project, technology, concept, organization, file, service)")
    min_mentions: int = Field(1, description="Minimum mention count", ge=1)
    limit: int = Field(20, description="Maximum results", ge=1, le=50)


class GetEntityGraphInput(BaseModel):
    """Input for getting entity graph data."""

    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)

    entity_name: Optional[str] = Field(None, description="Center on specific entity (optional)")
    entity_type: Optional[str] = Field(None, description="Filter by entity type")
    min_mentions: int = Field(2, description="Only include entities with N+ mentions", ge=1)
    limit: int = Field(50, description="Max nodes", ge=1, le=200)


VALID_ACTIONS = ["list", "mark_fresh", "mark_outdated", "mark_archived"]


def register_utility_tools(mcp: FastMCP) -> None:
    """Register all utility tools with the MCP server."""

    @mcp.tool(
        name="cortex_list_tags",
        annotations={
            "title": "List Tags",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_list_tags(params: ListTagsInput) -> str:
        """List all tags used in memories with usage counts.

        Args:
            params: ListTagsInput with filters

        Returns:
            List of tags and their usage counts
        """
        try:
            conn = init_database()
            cursor = conn.cursor()

            # Query to extract and count tags
            cursor.execute("""
                SELECT tags FROM memories
                WHERE tags IS NOT NULL AND tags != '[]'
            """)

            tag_counts: dict[str, int] = {}
            for row in cursor.fetchall():
                tags = row["tags"]
                if tags:
                    if isinstance(tags, str):
                        tags = json.loads(tags)
                    for tag in tags:
                        tag_counts[tag] = tag_counts.get(tag, 0) + 1

            # Filter by min_count and sort
            filtered = [
                (tag, count)
                for tag, count in tag_counts.items()
                if count >= params.min_count
            ]
            filtered.sort(key=lambda x: x[1], reverse=True)
            filtered = filtered[:params.limit]

            if not filtered:
                return "No tags found."

            lines = ["# Tags", ""]
            for tag, count in filtered:
                lines.append(f"- **{tag}**: {count} memories")

            return "\n".join(lines)

        except Exception as e:
            return f"Error listing tags: {e}"

    @mcp.tool(
        name="cortex_get_memory_history",
        annotations={
            "title": "Get Memory History",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_get_memory_history(params: GetMemoryHistoryInput) -> str:
        """Get the version history of a memory.

        Returns all previous versions of a memory, showing how it evolved
        over time. Each version captures the state before a content-changing
        update, merge, or conflict resolution.

        Args:
            params: GetMemoryHistoryInput with memory_id, limit, include_content

        Returns:
            Version history formatted as markdown
        """
        try:
            conn = init_database()
            from ..models.memory import get_memory, get_memory_versions, get_version_count

            # Verify the memory exists
            memory = get_memory(conn, params.memory_id)
            if not memory:
                return f"Memory not found: {params.memory_id}"

            versions = get_memory_versions(
                conn,
                params.memory_id,
                limit=params.limit,
                include_content=params.include_content,
            )
            total_versions = get_version_count(conn, params.memory_id)

            lines = [
                f"# Version History: {params.memory_id}",
                f"Total versions: {total_versions}",
                "",
                "## Current (Live)",
                f"**Content:** {memory.content[:200]}{'...' if len(memory.content) > 200 else ''}",
                f"**Tags:** {', '.join(memory.tags) if memory.tags else 'none'}",
                f"**Importance:** {memory.importance_score:.0f}/100",
                f"**Updated:** {memory.updated_at}",
                "",
            ]

            if not versions:
                lines.append("*No previous versions recorded.*")
            else:
                for v in versions:
                    lines.append(f"## Version {v['version_number']}")
                    lines.append(f"**Changed by:** {v['changed_by']}")
                    if v.get("change_reason"):
                        lines.append(f"**Reason:** {v['change_reason']}")
                    lines.append(f"**Date:** {v['created_at']}")
                    if params.include_content:
                        content = v.get("content", "")
                        lines.append(f"**Content:** {content[:200]}{'...' if len(content) > 200 else ''}")
                        tags = v.get("tags")
                        if isinstance(tags, list):
                            lines.append(f"**Tags:** {', '.join(tags)}")
                        elif isinstance(tags, str):
                            lines.append(f"**Tags:** {tags}")
                        if v.get("importance_score") is not None:
                            lines.append(f"**Importance:** {v['importance_score']:.0f}/100")
                    lines.append("")

            return "\n".join(lines)

        except Exception as e:
            return f"Error getting memory history: {e}"

    @mcp.tool(
        name="cortex_review_memories",
        annotations={
            "title": "Review Memories",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_review_memories(params: ReviewMemoriesInput) -> str:
        """Review and update memory freshness status.

        Actions:
        - list: Show memories that need review
        - mark_fresh: Mark memories as verified/fresh
        - mark_outdated: Mark memories as outdated
        - mark_archived: Archive memories

        Args:
            params: ReviewMemoriesInput with action and options

        Returns:
            Results of the review action
        """
        try:
            if params.action not in VALID_ACTIONS:
                return f"Invalid action: {params.action}. Valid: {', '.join(VALID_ACTIONS)}"

            conn = init_database()

            if params.action == "list":
                # Find session-type memories that have drifted from stored status
                review_candidates = []

                # Check all session-type memories for freshness drift
                for session_type in SESSION_TYPES:
                    memories, _ = list_memories(
                        conn,
                        type_filter=session_type,
                        limit=500,
                    )
                    for mem in memories:
                        calculated = get_freshness_status(
                            mem.created_at,
                            mem.last_verified,
                            mem.status,
                            review_days=params.days_threshold,
                        )
                        if calculated != mem.status:
                            review_candidates.append((mem, calculated))

                # Also include knowledge-type memories manually flagged as needs_review
                knowledge_flagged, _ = list_memories(
                    conn,
                    status_filter="needs_review",
                    limit=500,
                )
                for mem in knowledge_flagged:
                    if mem.type in KNOWLEDGE_TYPES:
                        review_candidates.append((mem, mem.status))

                if not review_candidates:
                    return "No memories need review."

                # Limit results
                review_candidates = review_candidates[:params.limit]

                lines = [f"# Memories for Review ({len(review_candidates)})", ""]
                for mem, calculated_status in review_candidates:
                    lines.append(f"## {mem.id}")
                    lines.append(f"Type: {mem.type} | Status: {mem.status} -> {calculated_status}")
                    lines.append(f"Last accessed: {mem.last_accessed}")
                    lines.append(f"Content: {mem.content[:100]}...")
                    lines.append("")

                return "\n".join(lines)

            else:
                # Update memories
                if not params.memory_ids:
                    return "No memory IDs provided for update."

                status_map = {
                    "mark_fresh": "fresh",
                    "mark_outdated": "outdated",
                    "mark_archived": "archived",
                }
                new_status = status_map[params.action]

                updated = 0
                for memory_id in params.memory_ids:
                    result = update_memory(
                        conn,
                        memory_id,
                        MemoryUpdate(
                            status=new_status,
                        ),
                    )
                    if result:
                        updated += 1

                return f"Updated {updated} memories to status: {new_status}"

        except Exception as e:
            return f"Error reviewing memories: {e}"

    @mcp.tool(
        name="cortex_export",
        annotations={
            "title": "Export Data",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_export(params: ExportInput) -> str:
        """Export memories and activities to various formats.

        Args:
            params: ExportInput with format and filters

        Returns:
            Exported data or confirmation of file save
        """
        try:
            conn = init_database()

            # SQLite dump format
            if params.format == "sqlite":
                if not params.output_path:
                    return "SQLite export requires output_path parameter."

                from ..config import get_project_db_path
                import shutil

                source_path = get_project_db_path()
                if not source_path.exists():
                    return f"Database not found: {source_path}"

                # Ensure all data is flushed to disk (checkpoint WAL)
                try:
                    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                except Exception:
                    pass  # May fail if not in WAL mode

                # Copy the database file
                shutil.copy2(source_path, params.output_path)

                # Also copy WAL and SHM files if they exist
                for suffix in ["-wal", "-shm"]:
                    wal_path = source_path.parent / (source_path.name + suffix)
                    if wal_path.exists():
                        shutil.copy2(wal_path, params.output_path + suffix)

                return f"SQLite database exported to: {params.output_path}"

            data = {
                "exported_at": now_iso(),
                "format": params.format,
            }

            if params.include_memories:
                memories, _ = list_memories(conn, limit=1000)
                data["memories"] = [m.model_dump() for m in memories]

            if params.include_activities:
                from ..models.activity import get_activities
                activities, _ = get_activities(conn, since=params.since, limit=1000)
                data["activities"] = [a.model_dump() for a in activities]

            if params.format == "json":
                output = json.dumps(data, indent=2, default=str)
            else:
                # Markdown format
                lines = [
                    "# Omni Cortex Export",
                    f"Exported: {data['exported_at']}",
                    "",
                ]

                if params.include_memories and data.get("memories"):
                    lines.append("## Memories")
                    lines.append("")
                    for mem in data["memories"]:
                        lines.append(f"### [{mem['type']}] {mem['id']}")
                        lines.append(f"**Content:** {mem['content']}")
                        if mem.get("context"):
                            lines.append(f"**Context:** {mem['context']}")
                        if mem.get("tags"):
                            lines.append(f"**Tags:** {', '.join(mem['tags'])}")
                        lines.append(f"**Created:** {mem['created_at']}")
                        lines.append("")

                if params.include_activities and data.get("activities"):
                    lines.append("## Activities")
                    lines.append("")
                    for act in data["activities"][:50]:  # Limit for readability
                        lines.append(f"- **{act['event_type']}** ({act['timestamp']})")
                        if act.get("tool_name"):
                            lines.append(f"  Tool: {act['tool_name']}")
                        lines.append("")

                output = "\n".join(lines)

            if params.output_path:
                with open(params.output_path, "w", encoding="utf-8") as f:
                    f.write(output)
                return f"Exported to: {params.output_path}"

            # Truncate if too long
            if len(output) > 10000:
                output = output[:10000] + "\n\n... [truncated]"

            return output

        except Exception as e:
            return f"Error exporting data: {e}"

    @mcp.tool(
        name="cortex_global_search",
        annotations={
            "title": "Search Global Index",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_global_search(params: GlobalSearchInput) -> str:
        """Search memories across all projects via global index.

        This tool searches the global index at ~/.omni-cortex/global.db
        which contains memories from all projects that have global_sync_enabled.

        Args:
            params: GlobalSearchInput with query and filters

        Returns:
            Matching memories from all projects
        """
        try:
            results = search_global_memories(
                query=params.query,
                type_filter=params.type_filter,
                tags_filter=params.tags_filter,
                project_filter=params.project_filter,
                limit=params.limit,
            )

            if not results:
                return f"No memories found in global index for: {params.query}"

            lines = [f"# Global Search Results ({len(results)})", ""]

            # Group by project
            by_project: dict[str, list] = {}
            for mem in results:
                project = mem.get("project_path", "unknown")
                if project not in by_project:
                    by_project[project] = []
                by_project[project].append(mem)

            for project, memories in by_project.items():
                lines.append(f"## Project: {project}")
                lines.append("")

                for mem in memories:
                    lines.append(f"### [{mem['type']}] {mem['id']}")
                    lines.append(f"{mem['content'][:200]}...")
                    if mem.get("tags"):
                        lines.append(f"**Tags:** {', '.join(mem['tags'])}")
                    lines.append(f"**Score:** {mem.get('score', 0):.2f}")
                    lines.append("")

            return "\n".join(lines)

        except Exception as e:
            return f"Error searching global index: {e}"

    @mcp.tool(
        name="cortex_global_stats",
        annotations={
            "title": "Global Index Stats",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_global_stats() -> str:
        """Get statistics from the global memory index.

        Shows total memories, breakdown by project and type.

        Returns:
            Statistics about the global index
        """
        try:
            stats = get_global_stats()

            if "error" in stats:
                return f"Error: {stats['error']}"

            lines = [
                "# Global Index Statistics",
                "",
                f"**Total Memories:** {stats.get('total_memories', 0)}",
                "",
            ]

            if stats.get("by_project"):
                lines.append("## By Project")
                for project, count in stats["by_project"].items():
                    lines.append(f"- {project}: {count}")
                lines.append("")

            if stats.get("by_type"):
                lines.append("## By Type")
                for mem_type, count in stats["by_type"].items():
                    lines.append(f"- {mem_type}: {count}")

            return "\n".join(lines)

        except Exception as e:
            return f"Error getting global stats: {e}"

    @mcp.tool(
        name="cortex_sync_to_global",
        annotations={
            "title": "Sync to Global Index",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_sync_to_global(params: GlobalSyncInput) -> str:
        """Sync project memories to the global index.

        This manually triggers a sync of all project memories to the
        global index. Normally this happens automatically on create/update.

        Args:
            params: GlobalSyncInput with sync options

        Returns:
            Number of memories synced
        """
        try:
            if params.full_sync:
                count = sync_all_project_memories()
                return f"Synced {count} memories to global index."
            else:
                return "Set full_sync=true to sync all project memories to global index."

        except Exception as e:
            return f"Error syncing to global: {e}"

    @mcp.tool(
        name="cortex_search_entities",
        annotations={
            "title": "Search Entities",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_search_entities(params: SearchEntitiesInput) -> str:
        """Search for entities in the knowledge graph.

        Find entities (people, projects, technologies, concepts, etc.)
        by name or partial match. Returns entities with their connected
        memory count and memory IDs.

        Args:
            params: SearchEntitiesInput with query and filters

        Returns:
            Matching entities formatted as markdown
        """
        try:
            conn = init_database()
            from ..models.entity import search_entities

            results = search_entities(
                conn,
                query=params.query,
                type_filter=params.type_filter,
                min_mentions=params.min_mentions,
                limit=params.limit,
            )

            if not results:
                return f"No entities found matching: {params.query}"

            lines = [f"# Entities ({len(results)})", ""]

            for item in results:
                entity = item["entity"]
                mem_count = item["connected_memories"]
                mem_ids = item["memory_ids"]

                lines.append(f"## {entity.display_name} ({entity.type})")
                lines.append(f"- **ID:** {entity.id}")
                lines.append(f"- **Mentions:** {entity.mention_count}")
                lines.append(f"- **Connected memories:** {mem_count}")
                lines.append(f"- **First seen:** {entity.first_seen}")
                lines.append(f"- **Last seen:** {entity.last_seen}")
                if mem_ids:
                    lines.append(f"- **Memory IDs:** {', '.join(mem_ids[:10])}")
                    if len(mem_ids) > 10:
                        lines.append(f"  +{len(mem_ids) - 10} more")
                lines.append("")

            return "\n".join(lines)

        except Exception as e:
            return f"Error searching entities: {e}"

    @mcp.tool(
        name="cortex_get_entity_graph",
        annotations={
            "title": "Get Entity Graph",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def cortex_get_entity_graph(params: GetEntityGraphInput) -> str:
        """Get entity-centric network graph data.

        Returns a D3-compatible graph with entity nodes, memory nodes,
        and edges between them. Use this to understand how entities
        connect memories in the knowledge graph.

        Args:
            params: GetEntityGraphInput with filters

        Returns:
            Graph data formatted as markdown with node/edge summary
        """
        try:
            conn = init_database()
            from ..models.entity import get_entity_graph

            graph = get_entity_graph(
                conn,
                entity_name=params.entity_name,
                entity_type=params.entity_type,
                min_mentions=params.min_mentions,
                limit=params.limit,
            )

            nodes = graph["nodes"]
            edges = graph["edges"]

            if not nodes:
                return "No entities found matching the criteria."

            entity_nodes = [n for n in nodes if n["type"] == "entity"]
            memory_nodes = [n for n in nodes if n["type"] == "memory"]

            lines = [
                "# Entity Graph",
                "",
                f"**Nodes:** {len(nodes)} ({len(entity_nodes)} entities, {len(memory_nodes)} memories)",
                f"**Edges:** {len(edges)}",
                "",
                "## Entities",
                "",
            ]

            for node in entity_nodes:
                lines.append(f"- **{node['label']}** ({node['entity_type']}) - {node['mention_count']} mentions")

            lines.append("")
            lines.append("## Connected Memories")
            lines.append("")

            for node in memory_nodes[:20]:
                lines.append(f"- [{node.get('memory_type', 'general')}] {node['id']}: {node['label']}")

            if len(memory_nodes) > 20:
                lines.append(f"  +{len(memory_nodes) - 20} more memories")

            lines.append("")
            lines.append("## Edges")
            lines.append("")

            edge_types: dict[str, int] = {}
            for edge in edges:
                etype = edge["type"]
                edge_types[etype] = edge_types.get(etype, 0) + 1

            for etype, count in sorted(edge_types.items(), key=lambda x: x[1], reverse=True):
                lines.append(f"- {etype}: {count}")

            return "\n".join(lines)

        except Exception as e:
            return f"Error getting entity graph: {e}"
