"""Entity model and CRUD operations for the knowledge graph."""

import json
import sqlite3
from typing import Optional
from dataclasses import dataclass

from ..utils.ids import generate_entity_id
from ..utils.timestamps import now_iso


@dataclass
class Entity:
    """An entity in the knowledge graph."""

    id: str
    name: str
    display_name: str
    type: str
    first_seen: str
    last_seen: str
    mention_count: int = 1
    metadata: Optional[dict] = None


def upsert_entity(
    conn: sqlite3.Connection,
    name: str,
    display_name: str,
    entity_type: str,
    metadata: Optional[dict] = None,
) -> Entity:
    """Create or update an entity.

    If an entity with the same (name, type) exists, increment mention_count
    and update last_seen. Otherwise, create a new entity.

    Args:
        conn: Database connection
        name: Normalized entity name (lowercase)
        display_name: Original casing for display
        entity_type: Entity type (person, project, technology, etc.)
        metadata: Optional JSON metadata

    Returns:
        The created or updated Entity
    """
    cursor = conn.cursor()
    now = now_iso()
    normalized_name = name.lower().strip()

    # Check if entity exists
    cursor.execute(
        "SELECT * FROM entities WHERE name = ? AND type = ?",
        (normalized_name, entity_type),
    )
    row = cursor.fetchone()

    if row:
        # Update existing entity
        cursor.execute(
            """
            UPDATE entities
            SET mention_count = mention_count + 1,
                last_seen = ?
            WHERE id = ?
            """,
            (now, row["id"]),
        )
        conn.commit()
        return Entity(
            id=row["id"],
            name=row["name"],
            display_name=row["display_name"],
            type=row["type"],
            first_seen=row["first_seen"],
            last_seen=now,
            mention_count=row["mention_count"] + 1,
            metadata=json.loads(row["metadata"]) if row["metadata"] else None,
        )
    else:
        # Create new entity
        entity_id = generate_entity_id()
        metadata_json = json.dumps(metadata) if metadata else None
        cursor.execute(
            """
            INSERT INTO entities (id, name, display_name, type, first_seen, last_seen, mention_count, metadata)
            VALUES (?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (entity_id, normalized_name, display_name, entity_type, now, now, metadata_json),
        )
        conn.commit()
        return Entity(
            id=entity_id,
            name=normalized_name,
            display_name=display_name,
            type=entity_type,
            first_seen=now,
            last_seen=now,
            mention_count=1,
            metadata=metadata,
        )


def link_memory_entity(
    conn: sqlite3.Connection,
    memory_id: str,
    entity_id: str,
    mention_context: str = "",
) -> bool:
    """Create a link between a memory and an entity.

    Args:
        conn: Database connection
        memory_id: Memory ID
        entity_id: Entity ID
        mention_context: Text snippet showing how entity appears

    Returns:
        True if link was created, False if already exists
    """
    now = now_iso()
    try:
        conn.execute(
            """
            INSERT INTO memory_entities (memory_id, entity_id, mention_context, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (memory_id, entity_id, mention_context[:200] if mention_context else "", now),
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


def get_entity(conn: sqlite3.Connection, entity_id: str) -> Optional[Entity]:
    """Get an entity by ID."""
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM entities WHERE id = ?", (entity_id,))
    row = cursor.fetchone()
    if not row:
        return None
    return _row_to_entity(row)


def get_entity_by_name(
    conn: sqlite3.Connection,
    name: str,
    entity_type: str,
) -> Optional[Entity]:
    """Get an entity by normalized name and type."""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM entities WHERE name = ? AND type = ?",
        (name.lower().strip(), entity_type),
    )
    row = cursor.fetchone()
    if not row:
        return None
    return _row_to_entity(row)


def search_entities(
    conn: sqlite3.Connection,
    query: str,
    type_filter: Optional[str] = None,
    min_mentions: int = 1,
    limit: int = 20,
) -> list[dict]:
    """Search entities by name with optional type filter.

    Returns entities with their connected memory count.
    """
    cursor = conn.cursor()

    sql = """
        SELECT e.*, COUNT(me.memory_id) as connected_memories
        FROM entities e
        LEFT JOIN memory_entities me ON e.id = me.entity_id
        WHERE e.name LIKE ?
          AND e.mention_count >= ?
    """
    params: list = [f"%{query.lower()}%", min_mentions]

    if type_filter:
        sql += " AND e.type = ?"
        params.append(type_filter)

    sql += " GROUP BY e.id ORDER BY e.mention_count DESC LIMIT ?"
    params.append(limit)

    cursor.execute(sql, params)
    results = []
    for row in cursor.fetchall():
        entity = _row_to_entity(row)
        # Get connected memory IDs
        cursor2 = conn.cursor()
        cursor2.execute(
            "SELECT memory_id FROM memory_entities WHERE entity_id = ?",
            (entity.id,),
        )
        memory_ids = [r["memory_id"] for r in cursor2.fetchall()]
        results.append({
            "entity": entity,
            "connected_memories": row["connected_memories"],
            "memory_ids": memory_ids,
        })

    return results


def get_entity_graph(
    conn: sqlite3.Connection,
    entity_name: Optional[str] = None,
    entity_type: Optional[str] = None,
    min_mentions: int = 2,
    limit: int = 50,
) -> dict:
    """Get entity-centric graph data in D3-compatible format.

    Returns nodes (entities + memories) and edges (entity-memory links
    + memory-memory relationships).
    """
    cursor = conn.cursor()

    # Build entity query
    sql = """
        SELECT e.* FROM entities e
        WHERE e.mention_count >= ?
    """
    params: list = [min_mentions]

    if entity_name:
        sql += " AND e.name LIKE ?"
        params.append(f"%{entity_name.lower()}%")
    if entity_type:
        sql += " AND e.type = ?"
        params.append(entity_type)

    sql += " ORDER BY e.mention_count DESC LIMIT ?"
    params.append(limit)

    cursor.execute(sql, params)
    entity_rows = cursor.fetchall()

    nodes = []
    edges = []
    memory_ids_seen: set[str] = set()

    # Add entity nodes
    for row in entity_rows:
        entity = _row_to_entity(row)
        nodes.append({
            "id": entity.id,
            "label": entity.display_name,
            "type": "entity",
            "entity_type": entity.type,
            "mention_count": entity.mention_count,
        })

        # Get connected memories
        cursor2 = conn.cursor()
        cursor2.execute(
            """
            SELECT me.memory_id, me.mention_context, m.content, m.type as memory_type
            FROM memory_entities me
            JOIN memories m ON me.memory_id = m.id
            WHERE me.entity_id = ?
            LIMIT 10
            """,
            (entity.id,),
        )
        for mem_row in cursor2.fetchall():
            mem_id = mem_row["memory_id"]

            # Add memory node (if not already added)
            if mem_id not in memory_ids_seen:
                memory_ids_seen.add(mem_id)
                content = mem_row["content"] or ""
                nodes.append({
                    "id": mem_id,
                    "label": content[:50] + ("..." if len(content) > 50 else ""),
                    "type": "memory",
                    "memory_type": mem_row["memory_type"],
                })

            # Add entity-memory edge
            edges.append({
                "source": entity.id,
                "target": mem_id,
                "type": "mentions",
                "context": mem_row["mention_context"] or "",
            })

    # Add memory-memory relationship edges
    if memory_ids_seen:
        placeholders = ",".join(["?"] * len(memory_ids_seen))
        cursor.execute(
            f"""
            SELECT * FROM memory_relationships
            WHERE source_memory_id IN ({placeholders})
               OR target_memory_id IN ({placeholders})
            """,
            list(memory_ids_seen) + list(memory_ids_seen),
        )
        for rel_row in cursor.fetchall():
            edges.append({
                "source": rel_row["source_memory_id"],
                "target": rel_row["target_memory_id"],
                "type": rel_row["relationship_type"],
                "strength": rel_row["strength"],
            })

    return {"nodes": nodes, "edges": edges}


def get_memories_sharing_entity(
    conn: sqlite3.Connection,
    entity_id: str,
    exclude_memory_id: Optional[str] = None,
) -> list[str]:
    """Get all memory IDs linked to a specific entity.

    Args:
        conn: Database connection
        entity_id: Entity ID to search for
        exclude_memory_id: Optional memory ID to exclude from results

    Returns:
        List of memory IDs
    """
    cursor = conn.cursor()
    if exclude_memory_id:
        cursor.execute(
            "SELECT memory_id FROM memory_entities WHERE entity_id = ? AND memory_id != ?",
            (entity_id, exclude_memory_id),
        )
    else:
        cursor.execute(
            "SELECT memory_id FROM memory_entities WHERE entity_id = ?",
            (entity_id,),
        )
    return [row["memory_id"] for row in cursor.fetchall()]


def _row_to_entity(row: sqlite3.Row) -> Entity:
    """Convert a database row to an Entity object."""
    metadata = row["metadata"]
    if metadata and isinstance(metadata, str):
        metadata = json.loads(metadata)
    return Entity(
        id=row["id"],
        name=row["name"],
        display_name=row["display_name"],
        type=row["type"],
        first_seen=row["first_seen"],
        last_seen=row["last_seen"],
        mention_count=row["mention_count"],
        metadata=metadata,
    )
