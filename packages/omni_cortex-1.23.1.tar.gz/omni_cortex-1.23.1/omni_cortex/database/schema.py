"""Database schema definitions for Omni Cortex."""

SCHEMA_VERSION = "1.7"

# Main schema SQL
SCHEMA_SQL = """
-- ============================================
-- OMNI CORTEX MCP DATABASE SCHEMA v1.0
-- ============================================

-- Sessions Table
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,                          -- sess_{timestamp}_{random}
    project_path TEXT NOT NULL,
    started_at TEXT NOT NULL,                     -- ISO 8601
    ended_at TEXT,
    summary TEXT,
    tags TEXT,                                    -- JSON array
    metadata TEXT,                                -- JSON object
    duration_ms INTEGER                           -- v1.3: duration tracking
);

-- Agents Table
CREATE TABLE IF NOT EXISTS agents (
    id TEXT PRIMARY KEY,                          -- Agent ID from Claude Code
    name TEXT,
    type TEXT NOT NULL DEFAULT 'main',            -- main, subagent, tool
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    total_activities INTEGER DEFAULT 0,
    metadata TEXT
);

-- Activities Table (Layer 1)
CREATE TABLE IF NOT EXISTS activities (
    id TEXT PRIMARY KEY,                          -- act_{timestamp}_{random}
    session_id TEXT,
    agent_id TEXT,
    timestamp TEXT NOT NULL,                      -- ISO 8601 with timezone
    event_type TEXT NOT NULL,                     -- pre_tool_use, post_tool_use, etc.
    tool_name TEXT,
    tool_input TEXT,                              -- JSON (truncated to 10KB)
    tool_output TEXT,                             -- JSON (truncated to 10KB)
    duration_ms INTEGER,
    success INTEGER DEFAULT 1,
    error_message TEXT,
    project_path TEXT,
    file_path TEXT,
    metadata TEXT,
    -- Command analytics columns (v1.1)
    command_name TEXT,
    command_scope TEXT,
    mcp_server TEXT,
    skill_name TEXT,
    -- Natural language summaries (v1.2)
    summary TEXT,
    summary_detail TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions(id),
    FOREIGN KEY (agent_id) REFERENCES agents(id)
);

-- Memories Table (Layer 2)
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,                          -- mem_{timestamp}_{random}
    content TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'general',
    tags TEXT,                                    -- JSON array
    context TEXT,

    -- Timestamps
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_accessed TEXT NOT NULL,
    last_verified TEXT,

    -- Usage
    access_count INTEGER DEFAULT 0,

    -- Importance/Decay
    importance_score REAL DEFAULT 50.0,           -- 0-100
    manual_importance INTEGER,                    -- User override

    -- Freshness
    status TEXT DEFAULT 'fresh',                  -- fresh, needs_review, outdated, archived

    -- Attribution
    source_session_id TEXT,
    source_agent_id TEXT,
    source_activity_id TEXT,

    -- Project
    project_path TEXT,
    file_context TEXT,                            -- JSON array

    -- Embedding
    has_embedding INTEGER DEFAULT 0,

    metadata TEXT,

    FOREIGN KEY (source_session_id) REFERENCES sessions(id),
    FOREIGN KEY (source_agent_id) REFERENCES agents(id),
    FOREIGN KEY (source_activity_id) REFERENCES activities(id)
);

-- FTS5 for Full-Text Search
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    content, context, tags,
    content=memories,
    content_rowid=rowid,
    tokenize='porter unicode61'
);

-- Triggers to keep FTS in sync with memories table
CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memories_fts(rowid, content, context, tags)
    VALUES (NEW.rowid, NEW.content, NEW.context, NEW.tags);
END;

CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, content, context, tags)
    VALUES ('delete', OLD.rowid, OLD.content, OLD.context, OLD.tags);
END;

CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, content, context, tags)
    VALUES ('delete', OLD.rowid, OLD.content, OLD.context, OLD.tags);
    INSERT INTO memories_fts(rowid, content, context, tags)
    VALUES (NEW.rowid, NEW.content, NEW.context, NEW.tags);
END;

-- Memory Relationships
CREATE TABLE IF NOT EXISTS memory_relationships (
    id TEXT PRIMARY KEY,
    source_memory_id TEXT NOT NULL,
    target_memory_id TEXT NOT NULL,
    relationship_type TEXT NOT NULL,              -- related_to, supersedes, derived_from, contradicts
    strength REAL DEFAULT 1.0,
    created_at TEXT NOT NULL,
    metadata TEXT,
    FOREIGN KEY (source_memory_id) REFERENCES memories(id) ON DELETE CASCADE,
    FOREIGN KEY (target_memory_id) REFERENCES memories(id) ON DELETE CASCADE,
    UNIQUE(source_memory_id, target_memory_id, relationship_type)
);

-- Activity-Memory Links
CREATE TABLE IF NOT EXISTS activity_memory_links (
    activity_id TEXT NOT NULL,
    memory_id TEXT NOT NULL,
    link_type TEXT NOT NULL,                      -- created, accessed, updated, referenced
    created_at TEXT NOT NULL,
    PRIMARY KEY (activity_id, memory_id, link_type),
    FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE,
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

-- Embeddings
CREATE TABLE IF NOT EXISTS embeddings (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL UNIQUE,
    model_name TEXT NOT NULL,                     -- 'all-MiniLM-L6-v2'
    vector BLOB NOT NULL,                         -- float32 array
    dimensions INTEGER NOT NULL,                  -- 384
    created_at TEXT NOT NULL,
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
);

-- Session Summaries
CREATE TABLE IF NOT EXISTS session_summaries (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL UNIQUE,
    key_learnings TEXT,                           -- JSON array
    key_decisions TEXT,                           -- JSON array
    key_errors TEXT,                              -- JSON array
    files_modified TEXT,                          -- JSON array
    tools_used TEXT,                              -- JSON object
    total_activities INTEGER DEFAULT 0,
    total_memories_created INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    duration_ms INTEGER,                          -- v1.3: duration tracking
    tool_duration_breakdown TEXT,                  -- v1.3: JSON breakdown
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
);

-- Configuration
CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Middleware Cache (v2)
CREATE TABLE IF NOT EXISTS middleware_cache (
    cache_key TEXT NOT NULL,
    terminal_session_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    tool_input_json TEXT,
    cached_response TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    hit_count INTEGER DEFAULT 0,
    response_size INTEGER DEFAULT 0,
    PRIMARY KEY (cache_key, terminal_session_id)
);

-- User Messages (v1.4)
CREATE TABLE IF NOT EXISTS user_messages (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    timestamp TEXT NOT NULL,
    content TEXT NOT NULL,
    word_count INTEGER,
    char_count INTEGER,
    line_count INTEGER,
    has_code_blocks INTEGER DEFAULT 0,
    has_questions INTEGER DEFAULT 0,
    has_commands INTEGER DEFAULT 0,
    tone_indicators TEXT,
    project_path TEXT,
    metadata TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

-- User Style Profiles (v1.4)
CREATE TABLE IF NOT EXISTS user_style_profiles (
    id TEXT PRIMARY KEY,
    project_path TEXT,
    total_messages INTEGER DEFAULT 0,
    avg_word_count REAL,
    avg_char_count REAL,
    common_phrases TEXT,
    vocabulary_richness REAL,
    formality_score REAL,
    question_frequency REAL,
    command_frequency REAL,
    code_block_frequency REAL,
    punctuation_style TEXT,
    greeting_patterns TEXT,
    instruction_style TEXT,
    sample_messages TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    metadata TEXT
);

-- Memory Versions (v1.5)
CREATE TABLE IF NOT EXISTS memory_versions (
    id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    content TEXT NOT NULL,
    context TEXT,
    tags TEXT,
    importance_score REAL,
    changed_by TEXT NOT NULL DEFAULT 'user',
    change_reason TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
    UNIQUE(memory_id, version_number)
);

-- Global Cross-Project Relationships (v1.6)
CREATE TABLE IF NOT EXISTS global_relationships (
    id TEXT PRIMARY KEY,
    source_memory_id TEXT NOT NULL,
    source_project TEXT NOT NULL,
    target_memory_id TEXT NOT NULL,
    target_project TEXT NOT NULL,
    relationship_type TEXT NOT NULL,
    strength REAL DEFAULT 1.0,
    created_at TEXT NOT NULL,
    UNIQUE(source_memory_id, target_memory_id, relationship_type)
);

-- Entities (v1.7)
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    type TEXT NOT NULL,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    mention_count INTEGER DEFAULT 1,
    metadata TEXT,
    UNIQUE(name, type)
);

-- Memory-Entity Links (v1.7)
CREATE TABLE IF NOT EXISTS memory_entities (
    memory_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    mention_context TEXT,
    created_at TEXT NOT NULL,
    PRIMARY KEY (memory_id, entity_id),
    FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
    FOREIGN KEY (entity_id) REFERENCES entities(id) ON DELETE CASCADE
);

-- Schema Migrations
CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_activities_session ON activities(session_id);
CREATE INDEX IF NOT EXISTS idx_activities_agent ON activities(agent_id);
CREATE INDEX IF NOT EXISTS idx_activities_timestamp ON activities(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tool ON activities(tool_name);
CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status);
CREATE INDEX IF NOT EXISTS idx_memories_project ON memories(project_path);
CREATE INDEX IF NOT EXISTS idx_memories_importance ON memories(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_memories_accessed ON memories(last_accessed DESC);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_relationships_source ON memory_relationships(source_memory_id);
CREATE INDEX IF NOT EXISTS idx_relationships_target ON memory_relationships(target_memory_id);
CREATE INDEX IF NOT EXISTS idx_cache_session ON middleware_cache(terminal_session_id);
CREATE INDEX IF NOT EXISTS idx_cache_expires ON middleware_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_activities_command ON activities(command_name);
CREATE INDEX IF NOT EXISTS idx_activities_mcp ON activities(mcp_server);
CREATE INDEX IF NOT EXISTS idx_activities_skill ON activities(skill_name);
CREATE INDEX IF NOT EXISTS idx_activities_duration ON activities(duration_ms);
CREATE INDEX IF NOT EXISTS idx_sessions_duration ON sessions(duration_ms);
CREATE INDEX IF NOT EXISTS idx_user_messages_session ON user_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_user_messages_timestamp ON user_messages(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_user_messages_project ON user_messages(project_path);
CREATE INDEX IF NOT EXISTS idx_user_style_project ON user_style_profiles(project_path);
CREATE INDEX IF NOT EXISTS idx_versions_memory ON memory_versions(memory_id);
CREATE INDEX IF NOT EXISTS idx_versions_created ON memory_versions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_global_rel_source ON global_relationships(source_memory_id);
CREATE INDEX IF NOT EXISTS idx_global_rel_target ON global_relationships(target_memory_id);
CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name);
CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(type);
CREATE INDEX IF NOT EXISTS idx_entities_mentions ON entities(mention_count DESC);
CREATE INDEX IF NOT EXISTS idx_memory_entities_memory ON memory_entities(memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_entities_entity ON memory_entities(entity_id);
"""


def get_schema_sql() -> str:
    """Get the complete schema SQL."""
    return SCHEMA_SQL
