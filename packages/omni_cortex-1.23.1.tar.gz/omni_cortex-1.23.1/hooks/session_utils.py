#!/usr/bin/env python3
"""Shared session management utilities for Claude Code hooks.

Provides per-terminal session isolation so multiple Claude Code instances
running simultaneously each get their own session file and ID.

Terminal Identification (Windows):
  1. Primary: Walk process tree past shell wrappers (bash, cmd, powershell)
     to find the stable Claude Code (claude.exe / node.exe) PID.
     This is needed because hooks are spawned via shell, so os.getppid()
     returns an ephemeral bash PID that changes every invocation.
  2. Fallback: CLAUDE_SESSION_ID environment variable
  3. Last resort: os.getpid()

Terminal Identification (Unix):
  1. Primary: os.getppid() — Claude Code PID (direct child)
  2. Fallback: CLAUDE_SESSION_ID environment variable
  3. Last resort: os.getpid()

Session files: .omni-cortex/sessions/{terminal_id}.json
Backward compat: migrates old .omni-cortex/current_session.json on first use.
"""

import ctypes
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# Session timeout in seconds (4 hours of inactivity = new session)
SESSION_TIMEOUT_SECONDS = 4 * 60 * 60

# Only run stale cleanup when this many session files exist
_CLEANUP_THRESHOLD = 10


def generate_session_id() -> str:
    """Generate a unique session ID matching the MCP format."""
    timestamp_ms = int(time.time() * 1000)
    random_hex = os.urandom(4).hex()
    return f"sess_{timestamp_ms}_{random_hex}"


def _get_project_path() -> str:
    """Get the project path from environment or cwd."""
    return os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())


# Shell executables to skip when walking the process tree.
# These are ephemeral wrappers spawned per hook invocation.
_SHELL_EXES = frozenset({
    b"bash.exe", b"sh.exe", b"dash.exe", b"zsh.exe",
    b"cmd.exe", b"powershell.exe", b"pwsh.exe",
})

# Per-process cache for terminal ID. Each hook invocation is a new Python
# process, so this only lives for one hook call — but get_terminal_id() may
# be called multiple times within that single call (cache check + session mgmt).
_cached_terminal_id: Optional[str] = None


def _find_stable_ancestor_pid() -> Optional[int]:
    """Walk up the process tree past shell wrappers to find a stable ancestor.

    Process tree on Windows (hook invocation):
        claude.exe (stable) -> bash.exe -> bash.exe -> python.exe (hook)

    Uses CreateToolhelp32Snapshot for a single-pass process scan, then
    walks the parent chain skipping shells. Typically completes in <5ms.

    Returns:
        The stable ancestor PID, or os.getppid() as fallback.
    """
    if sys.platform != "win32":
        return os.getppid()

    ppid = os.getppid()
    if not ppid or ppid <= 1:
        return ppid

    try:
        TH32CS_SNAPPROCESS = 0x00000002

        class PROCESSENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize", ctypes.c_ulong),
                ("cntUsage", ctypes.c_ulong),
                ("th32ProcessID", ctypes.c_ulong),
                ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                ("th32ModuleID", ctypes.c_ulong),
                ("cntThreads", ctypes.c_ulong),
                ("th32ParentProcessID", ctypes.c_ulong),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", ctypes.c_ulong),
                ("szExeFile", ctypes.c_char * 260),
            ]

        kernel32 = ctypes.windll.kernel32
        snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if not snapshot:
            return ppid

        pe = PROCESSENTRY32()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32)

        # Build PID -> (parent_pid, exe_name) map in a single pass
        proc_map = {}
        try:
            if kernel32.Process32First(snapshot, ctypes.byref(pe)):
                while True:
                    proc_map[pe.th32ProcessID] = (
                        pe.th32ParentProcessID,
                        pe.szExeFile,  # bytes, e.g. b"bash.exe"
                    )
                    if not kernel32.Process32Next(snapshot, ctypes.byref(pe)):
                        break
        finally:
            kernel32.CloseHandle(snapshot)

        # Walk up the parent chain, skipping shell processes
        pid = ppid
        visited = set()
        while pid and pid > 1 and pid not in visited:
            visited.add(pid)
            entry = proc_map.get(pid)
            if not entry:
                break
            parent_pid, exe_name = entry
            if exe_name.lower() not in _SHELL_EXES:
                return pid  # Found stable ancestor (e.g., claude.exe)
            pid = parent_pid

    except Exception:
        pass  # Fail-open: fall back to PPID

    return ppid


def get_terminal_id() -> str:
    """Get unique identifier for the current terminal.

    On Windows, hooks are spawned via shell (bash/cmd), so os.getppid()
    returns an ephemeral shell PID. We walk up the process tree past
    shell wrappers to find the stable Claude Code PID.

    On Unix, os.getppid() is typically stable (direct spawn).

    Result is cached per-process to avoid repeated process snapshots
    when this function is called multiple times within one hook invocation.

    Returns:
        Terminal identifier string (e.g., "ppid_12345")
    """
    global _cached_terminal_id
    if _cached_terminal_id is not None:
        return _cached_terminal_id

    result = None

    if sys.platform == "win32":
        stable_pid = _find_stable_ancestor_pid()
        if stable_pid and stable_pid > 1 and _is_process_alive(stable_pid):
            result = f"ppid_{stable_pid}"
    else:
        ppid = os.getppid()
        if ppid and ppid > 1:
            result = f"ppid_{ppid}"

    if result is None:
        env_session = os.environ.get("CLAUDE_SESSION_ID")
        if env_session:
            result = f"env_{env_session}"
        else:
            result = f"pid_{os.getpid()}"

    _cached_terminal_id = result
    return result


def _is_process_alive(pid: int) -> bool:
    """Check if a process is still running."""
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

    try:
        kernel32 = ctypes.windll.kernel32
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259

        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.OpenProcess.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.c_uint]
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid)
        if not handle:
            return False

        # OpenProcess can succeed for recently-dead processes; verify with exit code
        exit_code = ctypes.c_ulong()
        kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        result = kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle(handle)

        if result:
            return exit_code.value == STILL_ACTIVE
        return False
    except Exception:
        return True  # Assume alive on error (fail-open)


def _get_sessions_dir() -> Path:
    """Get the per-terminal sessions directory."""
    project_path = _get_project_path()
    return Path(project_path) / ".omni-cortex" / "sessions"


def _get_session_file_path(terminal_id: str) -> Path:
    """Get the session file path for a specific terminal."""
    return _get_sessions_dir() / f"{terminal_id}.json"


def _get_legacy_session_path() -> Path:
    """Get the old single-file session path (for migration)."""
    project_path = _get_project_path()
    return Path(project_path) / ".omni-cortex" / "current_session.json"


def _migrate_legacy_session(terminal_id: str) -> Optional[dict]:
    """Migrate old current_session.json to per-terminal format.

    Returns migrated session data if migration occurred, None otherwise.
    """
    legacy_path = _get_legacy_session_path()
    new_path = _get_session_file_path(terminal_id)

    if not legacy_path.exists() or new_path.exists():
        return None

    try:
        with open(legacy_path, "r") as f:
            session_data = json.load(f)

        # Add terminal_id field
        session_data["terminal_id"] = terminal_id

        # Save to new location
        new_path.parent.mkdir(parents=True, exist_ok=True)
        with open(new_path, "w") as f:
            json.dump(session_data, f, indent=2)

        # Rename old file to mark as migrated (don't delete — other hooks might reference it)
        migrated_path = legacy_path.with_suffix(".json.migrated")
        try:
            legacy_path.rename(migrated_path)
        except OSError:
            pass  # Non-critical if rename fails

        return session_data
    except Exception:
        return None


def load_session_file(terminal_id: str = None) -> Optional[dict]:
    """Load the session file for a terminal.

    Args:
        terminal_id: Terminal identifier. If None, uses current terminal.

    Returns:
        Session data dict or None if not found/invalid.
    """
    if terminal_id is None:
        terminal_id = get_terminal_id()

    session_file = _get_session_file_path(terminal_id)
    if not session_file.exists():
        return None

    try:
        with open(session_file, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def save_session_file(session_data: dict, terminal_id: str = None) -> None:
    """Save session data to the terminal-specific session file.

    Args:
        session_data: Session dict with session_id, terminal_id, etc.
        terminal_id: Terminal identifier. If None, uses current terminal.
    """
    if terminal_id is None:
        terminal_id = session_data.get("terminal_id", get_terminal_id())

    session_file = _get_session_file_path(terminal_id)
    session_file.parent.mkdir(parents=True, exist_ok=True)

    with open(session_file, "w") as f:
        json.dump(session_data, f, indent=2)


def is_session_valid(session_data: dict) -> bool:
    """Check if a session is still valid (not timed out)."""
    last_activity = session_data.get("last_activity_at")
    if not last_activity:
        return False

    try:
        last_time = datetime.fromisoformat(last_activity.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        elapsed_seconds = (now - last_time).total_seconds()
        return elapsed_seconds < SESSION_TIMEOUT_SECONDS
    except (ValueError, TypeError):
        return False


def cleanup_stale_sessions() -> int:
    """Remove session files for terminals that no longer exist.

    Only scans ppid_*.json files since pid-based sessions are inherently
    short-lived and env-based ones can't be validated.

    Returns:
        Number of stale session files removed.
    """
    sessions_dir = _get_sessions_dir()
    if not sessions_dir.exists():
        return 0

    removed = 0
    try:
        for session_file in sessions_dir.glob("ppid_*.json"):
            # Extract PID from filename: ppid_12345.json -> 12345
            try:
                pid_str = session_file.stem.split("_", 1)[1]
                pid = int(pid_str)
            except (IndexError, ValueError):
                continue

            if not _is_process_alive(pid):
                try:
                    session_file.unlink()
                    removed += 1
                except OSError:
                    pass  # File locked or already gone
    except Exception:
        pass  # Cleanup is best-effort

    return removed


def clear_terminal_session(terminal_id: str = None) -> bool:
    """Clear session file for a specific terminal. Used by /handoff.

    Args:
        terminal_id: Terminal to clear. Defaults to current terminal.

    Returns:
        True if session file was found and deleted.
    """
    if terminal_id is None:
        terminal_id = get_terminal_id()

    session_file = _get_session_file_path(terminal_id)
    if session_file.exists():
        try:
            session_file.unlink()
            return True
        except OSError:
            return False
    return False


def create_session_in_db(conn: sqlite3.Connection, session_id: str, project_path: str) -> None:
    """Create a new session record in the database."""
    cursor = conn.cursor()
    now = datetime.now(timezone.utc).isoformat()

    # Ensure sessions table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions'")
    if cursor.fetchone() is None:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                project_path TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                summary TEXT,
                tags TEXT,
                metadata TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at DESC);
            CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project_path);
        """)
        conn.commit()

    _retry_backoff = [0.2, 0.5, 1.0, 2.0, 4.0]
    for _attempt in range(5):
        try:
            cursor.execute(
                "INSERT OR IGNORE INTO sessions (id, project_path, started_at) VALUES (?, ?, ?)",
                (session_id, project_path, now),
            )
            conn.commit()
            break
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and _attempt < 4:
                time.sleep(_retry_backoff[_attempt])
                continue
            raise


def get_or_create_session(conn: sqlite3.Connection, project_path: str) -> str:
    """Get the current session ID, creating a new one if needed.

    Uses per-terminal session files for multi-terminal isolation.
    Signature unchanged from v1 for backward compatibility.

    Args:
        conn: SQLite database connection
        project_path: The project directory path

    Returns:
        The session ID to use for activity logging
    """
    terminal_id = get_terminal_id()
    now_iso = datetime.now(timezone.utc).isoformat()

    # Try loading per-terminal session file
    session_data = load_session_file(terminal_id)

    # If no per-terminal file, try migrating legacy file
    if session_data is None:
        session_data = _migrate_legacy_session(terminal_id)

    if session_data and is_session_valid(session_data):
        # Update last activity time
        session_data["last_activity_at"] = now_iso
        save_session_file(session_data, terminal_id)
        return session_data["session_id"]

    # Create new session
    session_id = generate_session_id()
    create_session_in_db(conn, session_id, project_path)

    session_data = {
        "session_id": session_id,
        "terminal_id": terminal_id,
        "project_path": project_path,
        "started_at": now_iso,
        "last_activity_at": now_iso,
    }
    save_session_file(session_data, terminal_id)

    # Opportunistic stale cleanup
    try:
        sessions_dir = _get_sessions_dir()
        if sessions_dir.exists():
            file_count = len(list(sessions_dir.glob("*.json")))
            if file_count >= _CLEANUP_THRESHOLD:
                cleanup_stale_sessions()
    except Exception:
        pass  # Never block on cleanup

    return session_id


def extract_skill_info(tool_input: dict, project_path: str) -> tuple:
    """Extract skill name and scope from Skill tool input.

    Checks these locations in order:
    1. {project_path}/.claude/commands/{name}.md         -> "project"
    2. {project_path}/.claude/skills/{name}/SKILL.md     -> "project-skill"
    3. ~/.claude/commands/{name}.md                       -> "universal"
    4. ~/.claude/skills/{name}/SKILL.md                   -> "universal-skill"
    5. fallback                                           -> "unknown"

    Handles colon-namespaced skills (e.g., crystal-ball:crystal-ball-predict)
    by using the part before the colon for directory lookup.

    Returns:
        Tuple of (skill_name, command_scope)
    """
    try:
        skill_name = tool_input.get("skill", "")
        if not skill_name:
            return None, None

        # For colon-namespaced skills, use the part before ':' for directory lookup
        lookup_name = skill_name.split(":")[0] if ":" in skill_name else skill_name

        # Check project-level command
        project_cmd = Path(project_path) / ".claude" / "commands" / f"{lookup_name}.md"
        if project_cmd.exists():
            return skill_name, "project"

        # Check project-level skill (SKILL.md)
        project_skill = Path(project_path) / ".claude" / "skills" / lookup_name / "SKILL.md"
        if project_skill.exists():
            return skill_name, "project-skill"

        # Check universal command
        universal_cmd = Path.home() / ".claude" / "commands" / f"{lookup_name}.md"
        if universal_cmd.exists():
            return skill_name, "universal"

        # Check universal skill (SKILL.md)
        universal_skill = Path.home() / ".claude" / "skills" / lookup_name / "SKILL.md"
        if universal_skill.exists():
            return skill_name, "universal-skill"

        return skill_name, "unknown"
    except Exception:
        return None, None


def ensure_analytics_columns(conn: sqlite3.Connection) -> None:
    """Ensure command analytics columns exist in activities table.

    Also backfills NULL skill_name for existing Skill tool entries
    by extracting from the stored tool_input JSON.
    """
    cursor = conn.cursor()
    columns = cursor.execute("PRAGMA table_info(activities)").fetchall()
    column_names = [col[1] for col in columns]

    new_columns = [
        ("command_name", "TEXT"),
        ("command_scope", "TEXT"),
        ("mcp_server", "TEXT"),
        ("skill_name", "TEXT"),
        ("summary", "TEXT"),
        ("summary_detail", "TEXT"),
    ]

    for col_name, col_type in new_columns:
        if col_name not in column_names:
            cursor.execute(f"ALTER TABLE activities ADD COLUMN {col_name} {col_type}")

    # Backfill NULL skill_name for existing Skill events.
    # Uses json_extract to parse skill name from stored tool_input JSON.
    # Idempotent: only updates rows where skill_name is still NULL.
    try:
        cursor.execute("""
            UPDATE activities
            SET skill_name = json_extract(tool_input, '$.skill')
            WHERE tool_name = 'Skill'
              AND (skill_name IS NULL OR skill_name = '')
              AND tool_input LIKE '%"skill"%'
        """)
    except Exception:
        pass  # json_extract may not be available on older SQLite

    conn.commit()
