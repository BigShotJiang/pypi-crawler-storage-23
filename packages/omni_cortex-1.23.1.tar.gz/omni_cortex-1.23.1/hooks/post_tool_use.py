#!/usr/bin/env python3
"""PostToolUse hook - logs tool result after execution.

This hook is called by Claude Code after each tool completes.
It logs the tool output, duration, and success/error status.

Hook configuration for settings.json:
{
    "hooks": {
        "PostToolUse": [
            {
                "type": "command",
                "command": "python hooks/post_tool_use.py"
            }
        ]
    }
}
"""

import json
import re
import sys
import os
import sqlite3
import time as _time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

# Import shared session management
from session_utils import get_or_create_session, extract_skill_info, ensure_analytics_columns

# Import middleware config (fail-open if not available)
try:
    from middleware_config import load_middleware_config
except ImportError:
    load_middleware_config = None

# Import middleware cache (fail-open if not available)
try:
    from middleware_cache import (
        compute_cache_key, store_cache, invalidate_file_cache,
        cleanup_expired_cache, ensure_cache_table, normalize_path,
    )
except ImportError:
    compute_cache_key = None
    store_cache = None
    invalidate_file_cache = None
    cleanup_expired_cache = None
    ensure_cache_table = None
    normalize_path = None


# Patterns for sensitive field names that should be redacted
SENSITIVE_FIELD_PATTERNS = [
    r'(?i)(api[_-]?key|apikey)',
    r'(?i)(password|passwd|pwd)',
    r'(?i)(secret|token|credential)',
    r'(?i)(auth[_-]?token|access[_-]?token)',
    r'(?i)(private[_-]?key|ssh[_-]?key)',
]


def redact_sensitive_fields(data: dict) -> dict:
    """Redact sensitive fields from a dictionary for safe logging.

    Recursively processes nested dicts and lists.
    """
    if not isinstance(data, dict):
        return data

    result = {}
    for key, value in data.items():
        # Check if key matches sensitive patterns
        is_sensitive = any(
            re.search(pattern, str(key))
            for pattern in SENSITIVE_FIELD_PATTERNS
        )

        if is_sensitive:
            result[key] = '[REDACTED]'
        elif isinstance(value, dict):
            result[key] = redact_sensitive_fields(value)
        elif isinstance(value, list):
            result[key] = [
                redact_sensitive_fields(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value

    return result


def get_db_path() -> Path:
    """Get the database path for the current project."""
    project_path = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    return Path(project_path) / ".omni-cortex" / "cortex.db"


def ensure_database(db_path: Path) -> sqlite3.Connection:
    """Ensure database exists and is initialized.

    Auto-creates the database and schema if it doesn't exist.
    This enables 'out of the box' functionality.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")

    # Check if schema exists
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='activities'")
    if cursor.fetchone() is None:
        # Apply minimal schema for activities (full schema applied by MCP)
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS activities (
                id TEXT PRIMARY KEY,
                session_id TEXT,
                agent_id TEXT,
                timestamp TEXT NOT NULL,
                event_type TEXT NOT NULL,
                tool_name TEXT,
                tool_input TEXT,
                tool_output TEXT,
                duration_ms INTEGER,
                success INTEGER DEFAULT 1,
                error_message TEXT,
                project_path TEXT,
                file_path TEXT,
                metadata TEXT,
                started_at_ms INTEGER
            );
            CREATE INDEX IF NOT EXISTS idx_activities_timestamp ON activities(timestamp DESC);
            CREATE INDEX IF NOT EXISTS idx_activities_tool ON activities(tool_name);
        """)
        conn.commit()
    else:
        # Migration: add started_at_ms column for existing databases
        columns = [row[1] for row in cursor.execute("PRAGMA table_info(activities)").fetchall()]
        if "started_at_ms" not in columns:
            cursor.execute("ALTER TABLE activities ADD COLUMN started_at_ms INTEGER")
            conn.commit()

    # Ensure middleware_cache table exists (Spec 2)
    if ensure_cache_table is not None:
        try:
            ensure_cache_table(conn)
        except Exception:
            pass  # Fail-open

    return conn


def generate_id() -> str:
    """Generate a unique activity ID."""
    timestamp_ms = int(datetime.now().timestamp() * 1000)
    random_hex = os.urandom(4).hex()
    return f"act_{timestamp_ms}_{random_hex}"


def truncate(text: str, max_length: int = 4000) -> str:
    """Truncate text with head/tail preservation.

    Keeps first 2000 chars + truncation marker + last 1000 chars.
    """
    if len(text) <= max_length:
        return text
    head_size = 2000
    tail_size = 1000
    marker = f"\n[...truncated {len(text)} chars...]\n"
    return text[:head_size] + marker + text[-tail_size:]


def extract_mcp_server(tool_name: str) -> str:
    """Extract MCP server name from tool name pattern mcp__servername__toolname."""
    if not tool_name or not tool_name.startswith("mcp__"):
        return None

    parts = tool_name.split("__")
    if len(parts) >= 3:
        return parts[1]
    return None



def generate_summary(tool_name: str, tool_input: dict, success: bool) -> tuple:
    """Generate short and detailed summaries for an activity.

    Returns:
        Tuple of (summary, summary_detail)
    """
    if not tool_name:
        return None, None

    input_data = tool_input if isinstance(tool_input, dict) else {}
    short = ""
    detail = ""

    if tool_name == "Read":
        path = input_data.get("file_path", "unknown")
        filename = Path(path).name if path else "file"
        short = f"Read file: {filename}"
        detail = f"Reading contents of {path}"

    elif tool_name == "Write":
        path = input_data.get("file_path", "unknown")
        filename = Path(path).name if path else "file"
        short = f"Write file: {filename}"
        detail = f"Writing/creating file at {path}"

    elif tool_name == "Edit":
        path = input_data.get("file_path", "unknown")
        filename = Path(path).name if path else "file"
        short = f"Edit file: {filename}"
        detail = f"Editing {path}"

    elif tool_name == "Bash":
        cmd = str(input_data.get("command", ""))[:50]
        short = f"Run: {cmd}..."
        detail = f"Executing: {input_data.get('command', 'unknown')}"

    elif tool_name == "Grep":
        pattern = input_data.get("pattern", "")
        short = f"Search: {pattern[:30]}"
        detail = f"Searching for pattern: {pattern}"

    elif tool_name == "Glob":
        pattern = input_data.get("pattern", "")
        short = f"Find files: {pattern[:30]}"
        detail = f"Finding files matching: {pattern}"

    elif tool_name == "Skill":
        skill = input_data.get("skill", "unknown")
        short = f"Run skill: /{skill}"
        detail = f"Executing slash command /{skill}"

    elif tool_name == "Task":
        desc = input_data.get("description", "task")
        short = f"Spawn agent: {desc[:30]}"
        detail = f"Launching sub-agent: {desc}"

    elif tool_name == "TodoWrite":
        todos = input_data.get("todos", [])
        count = len(todos) if isinstance(todos, list) else 0
        short = f"Update todo: {count} items"
        detail = f"Managing task list with {count} items"

    elif tool_name.startswith("mcp__"):
        parts = tool_name.split("__")
        server = parts[1] if len(parts) > 1 else "unknown"
        tool = parts[2] if len(parts) > 2 else tool_name
        short = f"MCP: {server}/{tool}"
        detail = f"Calling {tool} from MCP server {server}"

    else:
        short = f"Tool: {tool_name}"
        detail = f"Using tool {tool_name}"

    if not success:
        short = f"[FAILED] {short}"
        detail = f"[FAILED] {detail}"

    return short, detail


def prune_activities(db_path: Path) -> None:
    """Prune activities and user_messages beyond retention limits, then VACUUM.

    Opens a separate connection for pruning to avoid transaction issues with VACUUM.
    Uses retry-with-backoff for lock resilience.
    """
    ACTIVITY_CAP = 7000
    MESSAGE_CAP = 2000
    MAX_AGE_DAYS = 14

    cutoff = (datetime.now(timezone.utc) - timedelta(days=MAX_AGE_DAYS)).isoformat()

    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")

    retry_backoff = [0.2, 0.5, 1.0, 2.0, 4.0]

    try:
        for attempt in range(5):
            try:
                # Delete activities beyond cap (keep newest)
                conn.execute("""
                    DELETE FROM activities WHERE id NOT IN (
                        SELECT id FROM activities ORDER BY timestamp DESC LIMIT ?
                    )
                """, (ACTIVITY_CAP,))

                # Delete activities older than MAX_AGE_DAYS (exempt Skill events)
                conn.execute("DELETE FROM activities WHERE timestamp < ? AND tool_name != 'Skill'", (cutoff,))

                # Delete user_messages beyond cap (table may not exist)
                try:
                    conn.execute("""
                        DELETE FROM user_messages WHERE id NOT IN (
                            SELECT id FROM user_messages ORDER BY timestamp DESC LIMIT ?
                        )
                    """, (MESSAGE_CAP,))
                    conn.execute("DELETE FROM user_messages WHERE timestamp < ?", (cutoff,))
                except sqlite3.OperationalError:
                    pass  # user_messages table may not exist

                conn.commit()
                break
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < 4:
                    _time.sleep(retry_backoff[attempt])
                    continue
                raise

        # VACUUM must run outside transaction — retry with backoff
        for attempt in range(5):
            try:
                conn.execute("VACUUM")
                break
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < 4:
                    _time.sleep(retry_backoff[attempt])
                    continue
                break  # Skip VACUUM if still locked, not critical
    finally:
        conn.close()


def main():
    """Process PostToolUse hook."""
    try:
        # Read all input at once (more reliable than json.load on stdin)
        raw_input = sys.stdin.read()
        if not raw_input or not raw_input.strip():
            print(json.dumps({}))
            return

        input_data = json.loads(raw_input)

        # Extract data from hook input
        # Note: Claude Code uses 'tool_response' not 'tool_output'
        tool_name = input_data.get("tool_name")
        tool_input = input_data.get("tool_input", {})
        tool_response = input_data.get("tool_response", {})  # Correct field name
        agent_id = input_data.get("agent_id")

        # Determine success/error from response content
        # Claude Code doesn't send 'is_error' - we must detect from response
        is_error = False
        error_message = None

        if isinstance(tool_response, dict):
            # Check for explicit error field
            if "error" in tool_response:
                is_error = True
                error_message = str(tool_response.get("error", ""))[:500]

            # For Bash: check stderr or error patterns in stdout
            elif tool_name == "Bash":
                stderr = tool_response.get("stderr", "")
                stdout = tool_response.get("stdout", "")

                # Check stderr for content (excluding common non-errors)
                if stderr and stderr.strip():
                    # Filter out common non-error stderr output
                    stderr_lower = stderr.lower()
                    non_error_patterns = ["warning:", "note:", "info:"]
                    if not any(p in stderr_lower for p in non_error_patterns):
                        is_error = True
                        error_message = stderr[:500]

                # Check stdout for common error patterns
                if not is_error and stdout:
                    error_patterns = [
                        "command not found",
                        "No such file or directory",
                        "Permission denied",
                        "fatal:",
                        "error:",
                        "Error:",
                        "FAILED",
                        "Cannot find",
                        "not recognized",
                        "Exit code 1",
                    ]
                    stdout_check = stdout[:1000]  # Check first 1000 chars
                    for pattern in error_patterns:
                        if pattern in stdout_check:
                            is_error = True
                            error_message = f"Error pattern detected: {pattern}"
                            break

            # For Read: check for file errors
            elif tool_name == "Read":
                if "error" in str(tool_response).lower():
                    is_error = True
                    error_message = "File read error"

        # Legacy fallback: also check tool_output for backwards compatibility
        tool_output = tool_response if tool_response else input_data.get("tool_output", {})

        # Skip logging our own tools to prevent recursion
        # MCP tools are named like "mcp__omni-cortex__cortex_remember"
        if tool_name and ("cortex_" in tool_name or "omni-cortex" in tool_name):
            print(json.dumps({}))
            return

        project_path = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())

        # Load middleware config (fail-open: defaults to disabled on error)
        middleware_config = None
        if load_middleware_config is not None:
            try:
                middleware_config = load_middleware_config(project_path)
            except Exception:
                middleware_config = None

        # Auto-initialize database (creates if not exists)
        db_path = get_db_path()
        conn = ensure_database(db_path)

        # Ensure analytics columns exist
        ensure_analytics_columns(conn)

        # Get or create session (auto-manages session lifecycle)
        session_id = get_or_create_session(conn, project_path)

        # Redact sensitive fields before logging
        safe_input = redact_sensitive_fields(tool_input) if isinstance(tool_input, dict) else tool_input
        safe_output = redact_sensitive_fields(tool_response) if isinstance(tool_response, dict) else tool_response

        # Extract command analytics
        skill_name = None
        command_scope = None
        mcp_server = None

        # Extract skill info from Skill tool calls
        if tool_name == "Skill" and isinstance(tool_input, dict):
            skill_name, command_scope = extract_skill_info(tool_input, project_path)

        # Extract MCP server from tool name (mcp__servername__toolname pattern)
        if tool_name and tool_name.startswith("mcp__"):
            mcp_server = extract_mcp_server(tool_name)

        # Generate summary for activity
        summary = None
        summary_detail = None
        try:
            summary, summary_detail = generate_summary(tool_name, safe_input, not is_error)
        except Exception:
            pass

        # Get tool duration from pre_tool_use started_at_ms in DB
        duration_ms = None
        try:
            if agent_id:
                row = conn.execute(
                    """SELECT started_at_ms FROM activities
                    WHERE tool_name = ? AND agent_id = ? AND event_type = 'pre_tool_use'
                    AND started_at_ms IS NOT NULL
                    ORDER BY started_at_ms DESC LIMIT 1""",
                    (tool_name, agent_id),
                ).fetchone()
            else:
                row = conn.execute(
                    """SELECT started_at_ms FROM activities
                    WHERE tool_name = ? AND agent_id IS NULL AND event_type = 'pre_tool_use'
                    AND started_at_ms IS NOT NULL
                    ORDER BY started_at_ms DESC LIMIT 1""",
                    (tool_name,),
                ).fetchone()
            if row and row[0]:
                duration_ms = int(datetime.now(timezone.utc).timestamp() * 1000) - row[0]
        except Exception:
            pass  # Fail-open: missing duration is non-critical

        # Insert activity record with analytics columns and duration (retry on lock)
        cursor = conn.cursor()
        _retry_backoff = [0.2, 0.5, 1.0, 2.0, 4.0]
        for _attempt in range(5):
            try:
                cursor.execute(
                    """
                    INSERT INTO activities (
                        id, session_id, agent_id, timestamp, event_type,
                        tool_name, tool_input, tool_output, duration_ms, success, error_message, project_path,
                        skill_name, command_scope, mcp_server, summary, summary_detail
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        generate_id(),
                        session_id,
                        agent_id,
                        datetime.now(timezone.utc).isoformat(),
                        "post_tool_use",
                        tool_name,
                        truncate(json.dumps(safe_input, default=str), 2000),
                        truncate(json.dumps(safe_output, default=str), 4000),
                        duration_ms,
                        0 if is_error else 1,
                        error_message,
                        project_path,
                        skill_name,
                        command_scope,
                        mcp_server,
                        summary,
                        summary_detail,
                    ),
                )
                conn.commit()
                break
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and _attempt < 4:
                    _time.sleep(_retry_backoff[_attempt])
                    continue
                raise

        # === Cache Store + Invalidation (Spec 2) ===
        # After activity logging, handle cache operations.
        if (
            middleware_config is not None
            and store_cache is not None
            and middleware_config.get("enabled", False)
            and middleware_config.get("cache", {}).get("enabled", False)
        ):
            try:
                from session_utils import get_terminal_id, load_session_file

                terminal_id = get_terminal_id()
                session_data = load_session_file(terminal_id)
                terminal_session_id = session_data.get("session_id", "") if session_data else ""

                if terminal_session_id:
                    cache_config = middleware_config.get("cache", {})
                    whitelist = cache_config.get("whitelist", [])
                    ttl_map = cache_config.get("ttl", {})
                    max_size = cache_config.get("max_cached_response_size", 4000)

                    # Store cache for whitelisted tools (only on success)
                    if tool_name in whitelist and not is_error:
                        response_str = json.dumps(tool_response, default=str) if isinstance(tool_response, dict) else str(tool_response)
                        ttl = ttl_map.get(tool_name, 300)
                        cache_key = compute_cache_key(tool_name, tool_input)
                        store_cache(
                            db_path, cache_key, terminal_session_id,
                            tool_name, tool_input, response_str,
                            ttl, max_size,
                        )

                    # Invalidate Read/Grep/Glob cache on Edit or Write
                    if tool_name in ("Edit", "Write") and invalidate_file_cache is not None:
                        file_path = None
                        if isinstance(tool_input, dict):
                            file_path = tool_input.get("file_path")
                        if file_path:
                            invalidate_file_cache(db_path, terminal_session_id, file_path)

                    # Periodic expired cache cleanup (every ~50th call)
                    if cleanup_expired_cache is not None:
                        try:
                            import random
                            if random.randint(1, 50) == 1:
                                cleanup_expired_cache(db_path)
                        except Exception:
                            pass
            except Exception:
                pass  # Fail-open: cache errors never block the hook

        # Auto-retention: prune every 100th call when over cap
        try:
            activity_count = conn.execute("SELECT COUNT(*) FROM activities").fetchone()[0]
            if activity_count % 100 == 0 and activity_count > 7000:
                conn.close()
                prune_activities(db_path)
                conn = None  # Prevent double-close
        except Exception:
            pass  # Pruning is best-effort, never block the hook

        if conn:
            conn.close()

        # Return empty response (no modification)
        print(json.dumps({}))

    except Exception as e:
        # Hooks should never block - log error but continue
        print(json.dumps({"systemMessage": f"Cortex post_tool_use: {e}"}))

    sys.exit(0)


if __name__ == "__main__":
    main()
