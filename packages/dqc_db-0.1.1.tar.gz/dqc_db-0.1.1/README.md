<p align="center">
  <img src="https://dev.dataqualitycompany.app/favicon/DQC-Logo-801x331.png" alt="Data Quality Company" width="200">
</p>

# dqc-db

A thread-safe SQLite wrapper for Python with a single-writer, multi-reader architecture. Built by [Data Quality Company](https://dataqualitycompany.app).

## Features

- **Single writer, many readers** — all writes go through a background writer thread via a queue; each reading thread gets its own connection for parallel reads
- **Two transaction modes** — batched (collects statements, commits at once) and pinned (immediate execution, blocks other writers)
- **Automatic retry** — write operations retry with exponential backoff + jitter on `SQLITE_BUSY` / `SQLITE_LOCKED`
- **Streaming** — fetch large result sets in chunks without loading everything into memory
- **Zero dependencies** — only Python 3.11+ standard library

## Quick start

```python
from dqc_db import DbClient

with DbClient("my.db") as db:
    db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))

    users = db.query("SELECT * FROM users")
    print(users[0]["name"])  # "Alice"
```

## API

### Writes

```python
db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", [("Bob", 25), ("Eve", 42)])
```

### Reads

```python
db.query("SELECT * FROM users")                          # list of rows
db.query_one("SELECT * FROM users WHERE id = ?", (1,))   # single row or None

for chunk in db.stream("SELECT * FROM big_table", chunk_size=5000):
    process(chunk)
```

### Transactions

```python
# Batched (default) — commits everything at once
with db.transaction():
    db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", big_list)

# Pinned — each statement runs immediately, blocks other writers
with db.transaction(mode="pinned"):
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
    db.execute("UPDATE users SET age = 31 WHERE name = ?", ("Alice",))
```

### Constructor options

```python
DbClient(
    db_path=":memory:",
    busy_timeout=5000,
    max_retries=10,
    pragmas={"cache_size": "-20000"},
)
```

### Default PRAGMAs

```
journal_mode = WAL
synchronous = NORMAL
foreign_keys = ON
busy_timeout = 5000
temp_store = MEMORY
wal_autocheckpoint = 1000
```

## Architecture

```
Thread A ──► queue ──► Writer Thread ──► SQLite
Thread B ──►
Thread C ──►
```

- Writes are serialized through a single background writer thread
- Reads use thread-local connections for parallel access
- In-memory databases use shared-cache URIs so all connections see the same data

## License

Proprietary. Copyright Data Quality Company. All rights reserved.
