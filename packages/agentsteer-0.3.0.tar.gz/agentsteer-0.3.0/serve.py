"""Lightweight HTTP server that adapts standard requests to API Gateway v2 event format.

Calls handler(event, None) from the Lambda handler and returns the response.
Uses only stdlib (http.server). No extra dependencies.
"""

import os
import json
import base64
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# If a custom S3 endpoint is set (e.g. MinIO), patch the handler's S3 client
# before importing handler.py, since it creates the client at module level.
_s3_endpoint = os.environ.get("AWS_ENDPOINT_URL", "")
if _s3_endpoint:
    import boto3
    from botocore.config import Config
    _s3_client = boto3.client(
        "s3",
        endpoint_url=_s3_endpoint,
        config=Config(s3={"addressing_style": "path"}),
    )
    # handler.py does `s3 = boto3.client("s3")` at import time.
    # We monkey-patch boto3.client to return our pre-configured client for "s3".
    _original_client = boto3.client
    def _patched_client(service_name, **kwargs):
        if service_name == "s3" and not kwargs.get("endpoint_url"):
            return _s3_client
        return _original_client(service_name, **kwargs)
    boto3.client = _patched_client

from handler import handler  # noqa: E402 - must come after S3 patching


class APIHandler(BaseHTTPRequestHandler):
    """Translate HTTP requests into API Gateway v2 events and call handler()."""

    def _build_event(self, method):
        parsed = urlparse(self.path)
        query_string = parsed.query

        # Parse query params into flat dict (API Gateway v2 style: single values)
        raw_qs = parse_qs(query_string, keep_blank_values=True)
        query_params = {k: v[0] for k, v in raw_qs.items()} if raw_qs else None

        # Read body for POST/PUT/PATCH
        body = ""
        is_base64 = False
        if method in ("POST", "PUT", "PATCH"):
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length > 0:
                raw = self.rfile.read(content_length)
                try:
                    body = raw.decode("utf-8")
                except UnicodeDecodeError:
                    body = base64.b64encode(raw).decode("ascii")
                    is_base64 = True

        # Collect headers as lowercase dict (API Gateway v2 style)
        headers = {}
        for key in self.headers:
            headers[key.lower()] = self.headers[key]

        event = {
            "version": "2.0",
            "rawPath": parsed.path or "/",
            "rawQueryString": query_string,
            "queryStringParameters": query_params,
            "headers": headers,
            "body": body,
            "isBase64Encoded": is_base64,
            "requestContext": {
                "http": {
                    "method": method,
                    "path": parsed.path or "/",
                },
            },
        }
        return event

    def _handle(self, method):
        event = self._build_event(method)
        result = handler(event, None)

        status_code = result.get("statusCode", 200)
        resp_headers = result.get("headers", {})
        resp_body = result.get("body", "")

        self.send_response(status_code)
        for k, v in resp_headers.items():
            self.send_header(k, v)
        self.end_headers()

        if resp_body:
            self.wfile.write(resp_body.encode("utf-8"))

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_OPTIONS(self):
        self._handle("OPTIONS")

    def do_PUT(self):
        self._handle("PUT")

    def do_DELETE(self):
        self._handle("DELETE")

    def log_message(self, format, *args):
        # Use print for consistent logging with handler.py
        print(f"[http] {self.address_string()} {format % args}")


def main():
    port = 8080
    server = HTTPServer(("0.0.0.0", port), APIHandler)
    print(f"[serve] AgentSteer API listening on port {port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("[serve] shutting down")
        server.server_close()


if __name__ == "__main__":
    main()
