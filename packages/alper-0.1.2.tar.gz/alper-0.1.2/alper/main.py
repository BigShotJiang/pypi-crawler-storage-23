def alper():
    print("Hello")