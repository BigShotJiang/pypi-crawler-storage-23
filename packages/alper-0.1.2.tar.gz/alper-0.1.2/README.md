python setup.py sdist bdist_wheel

pip install .whl file ( e.g. "pip install alper-0.1.0-py3-none-any.whl" )

twine upload dist/*

