.. _cli_reference:

CLI Reference
=============

Command-line interface reference for **democli**.

This reference documentation is automatically generated from the command
definitions and provides detailed information about each available command.

Available Commands
------------------

Greetings
~~~~~~~~~

.. toctree::
   :maxdepth: 1

   hello
   greet
   farewell


Quick Reference Table
---------------------

.. list-table::
   :header-rows: 1
   :widths: 25 75

   * - Command
     - Description
   * - :ref:`hello <ref_hello>`
     - Say hello to the world
   * - :ref:`greet <ref_greet>`
     - Greet a specific person
   * - :ref:`farewell <ref_farewell>`
     - Say goodbye
