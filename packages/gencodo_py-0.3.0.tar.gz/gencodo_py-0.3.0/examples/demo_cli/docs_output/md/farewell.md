# farewell

Say goodbye

**Usage:**

```
democli farewell [--formal]
```

## Overview

Prints a farewell message. Supports formal and informal styles.

## Options

| Flag | Description | Default |
|------|-------------|---------|
| `--formal` | Use formal farewell style | `False` |

## Examples

**Say farewell**

```
democli farewell
```

**Formal farewell**

```
democli farewell --formal
```

## See also

- [greet](greet.md)
- [hello](hello.md)
