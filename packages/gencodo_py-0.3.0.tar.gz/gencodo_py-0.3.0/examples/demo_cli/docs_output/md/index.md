# CLI Reference

Command-line interface reference for **democli**.

This reference documentation is automatically generated from the command
definitions and provides detailed information about each available command.

## Available Commands

### Greetings

- [hello](hello.md) -- Say hello to the world
- [greet](greet.md) -- Greet a specific person
- [farewell](farewell.md) -- Say goodbye


## Quick Reference Table

| Command | Description |
|---------|-------------|
| [hello](hello.md) | Say hello to the world |
| [greet](greet.md) | Greet a specific person |
| [farewell](farewell.md) | Say goodbye |
