use faer::mat::from_row_major_slice;
fn main() {}
