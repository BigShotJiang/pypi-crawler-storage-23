"""Core CyteType functionality - internal module.

This module contains internal implementation details for the CyteType class.
Users should not import from this module directly - use the public API via:
    from cytetype import CyteType
"""
