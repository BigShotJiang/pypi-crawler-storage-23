import requests
import sys

def minimax():
	# === Настройки ===
	API_KEY = "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"
	MODEL = "minimax/minimax-m2.5"
	ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

	HEADERS = {
		"Authorization": f"Bearer {API_KEY}",
		"X-Title": "Russian Chat Bot"
	}

	# === История переписки ===
	messages = [
		{"role": "system", "content": "Ты — интеллектуальный помощник. Отвечай всегда на русском языке. Будь вежливым и точным."}
	]

	print(f"💬 Чат с {MODEL} запущен. Напишите 'выход' для завершения.\n")

	# === Основной цикл чата ===
	while True:
		try:
			# Ввод пользователя
			user_input = input("Вы: ").strip()
			if not user_input:
				print("Бот: Пожалуйста, введите сообщение.")
				continue
			if user_input.lower() in ["выход", "exit", "quit", "стоп"]:
				print("Бот: До свидания!")
				break

			# Добавляем сообщение пользователя
			messages.append({"role": "user", "content": user_input})

			# Отправка запроса
			response = requests.post(
				url=ENDPOINT,
				headers=HEADERS,
				json={
					"model": MODEL,
					"messages": messages,
					"temperature": 0.7,
					"max_tokens": 512
				},
				timeout=30
			)

			# Обработка ответа
			if response.status_code == 200:
				data = response.json()
				bot_response = data["choices"][0]["message"]["content"]
				print(f"Бот: {bot_response}")

				# Сохраняем ответ в историю
				messages.append({"role": "assistant", "content": bot_response})
			else:
				error_msg = response.json().get("error", {}).get("message", response.text)
				print(f"❌ Ошибка API ({response.status_code}): {error_msg}")
				if response.status_code == 402:
					print("💡 Подсказка: возможно, закончился баланс. Проверьте аккаунт на https://openrouter.ai/keys")
				elif response.status_code == 404:
					print("💡 Модель не найдена. Убедитесь, что указана правильная модель.")

		except requests.exceptions.Timeout:
			print("❌ Ошибка: таймаут соединения с сервером.")
		except requests.exceptions.RequestException as e:
			print(f"❌ Ошибка сети: {e}")
		except KeyboardInterrupt:
			print("\n👋 Программа остановлена.")
			sys.exit(0)
		except Exception as e:
			print(f"❌ Неизвестная ошибка: {e}")

	print("Чат завершён.")

if __name__ == "__main__":
	minimax()
