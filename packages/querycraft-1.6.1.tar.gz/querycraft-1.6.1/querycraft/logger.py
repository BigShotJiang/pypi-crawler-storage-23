#!/usr/bin/env python3
"""
Module de configuration du logging pour QueryCraft.
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
import colorama

# Initialisation colorama
colorama.init(autoreset=True)


class ColoredFormatter(logging.Formatter):
    """
    Formatter personnalisé avec couleurs pour le terminal.
    """

    COLORS = {
        'DEBUG': colorama.Fore.CYAN,
        'INFO': colorama.Fore.GREEN,
        'WARNING': colorama.Fore.YELLOW,
        'ERROR': colorama.Fore.RED,
        'CRITICAL': colorama.Fore.RED + colorama.Style.BRIGHT,
    }

    def format(self, record):
        # Ajouter la couleur selon le niveau
        if record.levelname in self.COLORS:
            record.levelname = f"{self.COLORS[record.levelname]}{record.levelname}{colorama.Style.RESET_ALL}"
        return super().format(record)


def setup_logger(name: str = "querycraft",
                 level: str = "INFO",
                 log_file: str = None,
                 verbose: bool = False, console: bool = False) -> logging.Logger:
    """
    Configure et retourne un logger pour QueryCraft.

    Args:
        name: Nom du logger (par défaut "querycraft")
        level: Niveau de log (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Chemin du fichier de log (optionnel)
        verbose: Si True, affiche plus de détails

    Returns:
        Logger configuré
    """
    logger = logging.getLogger(name)

    # Éviter les doublons si déjà configuré
    if logger.handlers:
        return logger

    # Convertir le niveau string en constante logging
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    if verbose:
        numeric_level = logging.DEBUG

    logger.setLevel(numeric_level)

    # Format des messages
    detailed_format = '%(asctime)s - %(name)s - %(levelname)s - %(module)s:%(funcName)s:%(lineno)d - %(message)s'
    simple_format = '%(levelname)s - %(message)s'

    # Handler pour la console (terminal)
    if console :
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(numeric_level)

        if verbose:
            console_formatter = ColoredFormatter(detailed_format, datefmt='%Y-%m-%d %H:%M:%S')
        else:
            console_formatter = ColoredFormatter(simple_format)

        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)

    # Handler pour fichier (si spécifié)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # Rotation : 5 fichiers de 10MB max
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)  # Tout logger dans le fichier
        file_formatter = logging.Formatter(detailed_format, datefmt='%Y-%m-%d %H:%M:%S')
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

    return logger


def get_logger(name: str = None) -> logging.Logger:
    """
    Récupère un logger existant ou crée un logger par défaut.

    Args:
        name: Nom du module (utiliser __name__)

    Returns:
        Logger configuré
    """
    if name:
        return logging.getLogger(f"querycraft.{name}")
    return logging.getLogger("querycraft")


# Logger par défaut pour le module
logger = get_logger()
