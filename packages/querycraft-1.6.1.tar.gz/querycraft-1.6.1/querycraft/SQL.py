#!/usr/bin/env python3
from __future__ import annotations

import re  # https://regex101.com/
import copy
import colorama
from sqlglot import parse_one, exp, errors
from sqlglot.expressions import From, Where, Group, Having, Limit, Offset, Order, Select, Join, Subquery, \
    Table

from querycraft.Database import Database
from querycraft.SQLException import SQLException, SQLQueryException
from querycraft.logger import get_logger
from querycraft.tools import (bold_substring, delEntete, group_table_as_rows, compare_query_results_raw,
                              lignes_disparues2,lignes_disparues4, existFile,colorize_sql,highlight_sql_keywords)


# ======================================================================================================================
# ======================================================================================================================

class SQL(object):
    def __init__(self, db=None, dbtype=None, str=None,
                 name=None, debug=False, verbose=False,
                 step_by_step=True, output='txt', first=False):
        self.debug = debug
        self.verbose = verbose
        self.step_by_step = step_by_step
        self.first = False
        self.group_by = None
        self.output = output
        if db is not None:
            self.__dbcon = db
            self.__dbtype = dbtype
            self.__db = Database.get(db, dbtype, debug, verbose,output)
        else:
            self.__db = None
            self.__dbcon = None
            self.__dbtype = None
        self.select = None
        self.distinct = None
        self.from_all = None
        self.from_join = None
        self.where = None
        self.group = None
        self.having = None
        self.order = None
        self.limit = None
        self.offset = None
        self.sqlTables = []
        self.intention = None
        self.exo = None
        self.quest = None
        self.cmp = None
        if str is not None:
            if name is not None:
                self.name = name
            else:
                self.name = str
            self.setSQL(str, first)  # Exécution de la requête
        else:
            self.name = name
            self.__str = None
            self.__data = None
            self.__col_names = None

    def setExo(self, intention, exo, quest, com=None, type=None, inst=None):
        '''
        Permet de positionner les informations sur l'exercice
        intention : intention pédagogique
        exo : numéro de l'exercice
        quest : numéro de la question
        com : commentaire
        inst : instruction
        '''
        self.intention = intention
        self.exo = exo
        self.quest = quest
        self.com = com
        self.type = type
        self.inst = inst

    def getExo(self):
        '''
        Retourne les informations sur l'exercice
        '''
        return (self.exo, self.quest, self.intention, self.com, self.inst)

    def getDB(self):
        return self.__db

    def setDebug(self):
        self.debug = True

    def unsetDebug(self):
        self.debug = False

    def setVerbose(self):
        self.verbose = True

    def unsetVerbose(self):
        self.verbose = False

    def setSQLTables(self, sqltbl):
        """
        Permet de positionner les tables et les alias d'une requête, sans l'analyser.
        :param sqltbl: La liste des tables et alias de la requête.
        :return:
        """
        self.sqlTables = sqltbl

    def printDBTables(self, output='txt'):
        self.__db.printDBTables(output)

    def load(self, file):
        """
        Charge une requête SQL depuis le fichier.
        :param file: Le fichier contenant la requête SQL.
        """
        if not existFile(file):
            raise SQLException("Le fichier n'existe pas.")
        else:
            txt = ""
            with open(file, 'r') as f:
                txt += f.read()
            self.setSQL(txt)

    def setSQL(self, req, first=False):
        self.__str = re.sub('\s+', ' ', req)
        if self.name is None: self.name = req
        self.first = first
        # pour simplifier on met dans la casse de la base de données
        # les noms des tables et des attributs
        if self.first :
            termes = list(self.__db.dbTables.keys())
            termes.extend(self.__db.dbAttributs.keys())
            self.__str = self.__corriger_casse(self.__str, termes)

        self.stringToQuery()
        self.execute()


    def similaire(self, sql2) -> int:
        (hd1, rw1) = self.getTable()
        (hd2, rw2) = sql2.getTable()
        return compare_query_results_raw(hd1, rw1, hd2, rw2)

    def __str__(self) -> str:
        if self.__str is not None:
            return self.__str
        else:
            return 'Requête SQL absente.'

    def getAlias(self, t):
        """
        Retourne l'alias de la table t.
        :param t: La table.
        :return: L'alias de la table.
        """
        for alias in self.sqlTables:
            if alias[0] == t:
                if alias[1] is not None:
                    return alias[1]
                else:
                    return t
        return t

    def __addPrefix(self, att):
        if '.' not in att:
            if att in self.__db.dbAttributs:
                # if x in [y for (y, z) in self.sqlTables]
                lt = [x for x in self.__db.dbAttributs[att]]
                if lt:
                    return self.getAlias(lt[0]) + '.' + att
                else:
                    return att
            else:
                return att
        else:
            return att

    def __sqlNameColumnVerif(self, description):
        """
        Vérifie si le nom des colonnes de la requête sont bien
        cohérents. Sinon renomme les colonnes avec le bon nom.
        """
        keywords = ['select', 'Select', '*', 'from', 'From', 'join', 'on', 'having', 'where', 'using', 'limit', 'order',
                    'group', 'by', 'count', 'offset', ';', '=', 'Tab', 'Sel', 'TaJ', 'Sub', '--']

        req = self.__str.replace(';', '')
        req = req.replace('(', ' ')
        req = req.replace('.', ' ')
        req = req.replace(',', ' ')
        req = req.replace(')', ' ')
        # On épure la requête pour contenir uniquement les mots non-clés SQL (a voir avec prof car pas obligatoire mais + rapide)
        req = list(set(req.split()) - set(keywords))

        # 1) On récupère les tables liées à l'attribut de chaque colonne.
        for j, i in enumerate(description):
            if i[0] in self.__db.dbAttributs:
                lt = [x.lower() for x in self.__db.dbAttributs[i[0]]]
                lt_original = [x for x in self.__db.dbAttributs[i[0]]]

                # 2) On regarde pour chaque table liée à l'attribut lesquelles sont mentionnées dans la requête.
                in_common = list(set([x.lower() for x in req]) & set(lt))
                in_common_original = [x for x in lt_original if x.lower() in in_common]

                # 3) Si le nom d'origine dans la colonne de la table est bien mentionné, on laisse, sinon on le remplace par le nom de la première table qui mentionne l'attribut.
                if self.__col_names[j].split('.')[0].lower() not in in_common:
                    self.__col_names[j] = in_common_original[0] + '.' + i[0]


    def prefixerAttributs(self, description):
        """
        Ajoute le préfixe de la table à chaque attribut de la requête (nom de table ou alias)
        :param description: liste des attributs de la requête
        :return: liste des attributs de la requête avec préfixe
        """
        latt = copy.deepcopy(self.__db.dbAttributs)
        col_names = []
        for att in description:
            if att in latt:
                t = latt[att]
                for tbl in self.sqlTables:
                    if tbl[0] in t:
                        latt[att].remove(tbl[0])
                        col_names.append(self.getAlias(tbl[0]) + "." + att)
                        break
            else :
                col_names.append(att)
        return col_names

    def execute(self):
        """
        Exécute la requête
        :return:
        """
        log = get_logger("sql")
        if self.__str is None:
            raise SQLException("La requête n'est pas renseignée.")
        elif self.__db is None:
            raise SQLException("La base de donnée n'est pas renseignée.")
        elif self.__str == "":
            raise SQLException("La requête est vide.")
        else:
            if self.debug: print('Exécution de la requête : ', self.__str)
            (description, self.__data) = self.__db.execute(self,self.verbose)

            if self.__db.getType() == 'pgsql':
                self.__col_names = self.prefixerAttributs([a.name for a in description])
                #self.__col_names = [str(att.name) for att in description]
                # Vérification du nom des colonnes.
                #self.__sqlNameColumnVerif(description)
            else:  # MySQL ou SQLite où on ne peut pas identifier les tables de tuples !
                #self.__col_names = [self.__addPrefix(des[0]) for des in description]
                self.__col_names = self.prefixerAttributs([a[0] for a in description])

                for (i, t) in enumerate(self.__data):
                    self.__data[i] = list(t)
                    # Vérification du nom des colonnes.
                    #self.__sqlNameColumnVerif(description)
                ## détection des colonnes avec même nom. Si c'est le cas, suppression de la colonne en double.
                toDelete = []
                for (i, c) in enumerate(self.__col_names):
                    unique = True
                    for j in range(i + 1, len(self.__col_names)):
                        a = self.__col_names[j]
                        if (a == c) and (self.__colonnes_egales(i, j)):
                            toDelete.append((c, j))
                            unique = False
                if self.debug and len(toDelete) > 0:
                    log.debug(f"Colonnes dupliquées : {toDelete}")

                toDelete.reverse()
                for (c, i) in toDelete:
                    del self.__col_names[i]
                    for j in self.__data:
                        del j[i]

    def __colonnes_egales(self, a, b):
        """
        Détermine si la colonne a est égale à la colonne b dans self.__data
        :param a: colonne a
        :param b: colonne b
        :return: bool
        """
        egale = False
        for i in self.__data:
            egale = egale or i[a] == i[b]
        return egale

    def getTable(self):
        return self.__col_names, self.__data



    def valider_requete_complete(self, parsed):
        """
        Valide plusieurs règles sur une requête SQL.
        """
        erreurs = []

        try:
            # Règle 1: SELECT * avec GROUP BY
            if isinstance(parsed, exp.Select):
                a_group_by = parsed.args.get('group') is not None
                a_select_etoile = any(isinstance(e, exp.Star) for e in parsed.expressions)

                if a_select_etoile and a_group_by:
                    erreurs.append("'SELECT *' n'est pas autorisé avec 'GROUP BY'")

                # Règle 2: JOIN sans ON/USING
                joins = list(parsed.find_all(exp.Join))
                for join in joins:
                    a_on = join.args.get('on') is not None
                    a_using = join.args.get('using') is not None

                    if not (a_on or a_using):
                        table = join.this
                        table_name = table.name if hasattr(table, 'name') else str(table)
                        erreurs.append(f"'JOIN' sur '{table_name}' sans clause 'ON' ou 'USING'")

                # Règle 3: Attributs du GROUP BY dans la projection
                if a_group_by and not a_select_etoile:
                    group_by_node = parsed.args.get('group')

                    # Extraire les colonnes du GROUP BY
                    colonnes_group_by = set()
                    for expr in group_by_node.expressions:
                        # Obtenir le nom complet de la colonne (avec ou sans table)
                        col_sql = expr.sql()
                        # Ajouter aussi juste le nom de colonne sans préfixe
                        if isinstance(expr, exp.Column):
                            colonnes_group_by.add( (col_sql,expr.name) )
                        else:
                            colonnes_group_by.add( (col_sql, None) )

                    # Extraire les colonnes de la projection (hors fonctions d'agrégation)
                    colonnes_projection = set()
                    for expr in parsed.expressions:
                        # Ignorer les fonctions d'agrégation (COUNT, SUM, AVG, etc.)
                        if isinstance(expr, exp.AggFunc):
                            continue

                        # Parcourir les colonnes dans l'expression
                        for col in expr.find_all(exp.Column):
                            col_sql = col.sql()
                            colonnes_projection.add(col_sql)
                            colonnes_projection.add(col.name)

                    # Vérifier que chaque colonne du GROUP BY est dans la projection
                    for (cg1, cg2) in colonnes_group_by:
                        if cg1 not in colonnes_projection and cg2 not in colonnes_projection:
                            erreurs.append(
                                f"La colonne '{cg1}' du 'GROUP BY' doit être dans la projection"
                                )
            else:
                erreurs.append("La requête proposée n'est pas une requête 'SELECT'")

            if erreurs:
                raise SQLQueryException(self.verbose, "Erreurs de validation:\n- " + "\n- ".join(erreurs),
                                        self, None, self.__db.name, self.__db, output = self.output)

            return True

        except errors.ParseError as e:
            raise ValueError(f"Erreur de syntaxe SQL: {e}")




    def stringToQuery(self):
        log = get_logger("sql")
        try:
            stmt = parse_one(self.__str)
            if self.first:
                self.valider_requete_complete(stmt)
        except errors.ParseError as e:
            raise SQLQueryException(self.verbose, f"Erreur de syntaxe SQL: {e}",
                                    self, None, self.__db.name, self.__db, output=self.output)

        self.select = stmt.expressions

        # print(', '.join([str(x) for x in self.select]))
        self.distinct = stmt.args["distinct"] is not None

        self.sqlTables = []
        self.from_all = [stmt.find(From)]
        for t in self.from_all[0].find_all(exp.Table):
            if t.alias:
                self.sqlTables.append((t.this.this, str(t.alias)))
            else:
                self.sqlTables.append((t.this.this, None))
        self.from_join = None
        if 'joins' in stmt.args:
            joins = stmt.args["joins"]
            self.from_all.append(joins)
            for j in joins:
                for t in j.find_all(exp.Table):
                    if t.alias:
                        self.sqlTables.append((t.this.this, str(t.alias)))
                    else:
                        self.sqlTables.append((t.this.this, None))
            self.from_join = str(self.from_all[0]) + ' ' + ' '.join([str(j) for j in joins])
        else:
            self.from_join = str(self.from_all[0])

        self.where = stmt.find(Where)

        self.group_by = stmt.find(Group)
        if self.group_by:
            self.group = [str(x) for x in self.group_by]
        else:
            self.group = None

        self.having = stmt.find(Having)

        self.order = stmt.find(Order)
        self.limit = stmt.find(Limit)
        self.offset = stmt.find(Offset)

        return stmt

    def __parcoursFrom(self, smt, deep=0):
        """
        Prends la requête principale et renvoie une liste de sous-requêtes didactiques
        :param smt: La requête principale sous forme de string.
        :return: La liste des requêtes didactiques et alias de la requête.
        """
        log = get_logger("sql")
        if isinstance(smt, Select):
            if self.debug: log.debug('\t' * deep, f"--> Select : {smt}")
            l = []
            l += self.__parcoursFrom(smt.args['from'], deep + 1)
            if "joins" in smt.args:
                joins = smt.args["joins"]
                req = f"Select * {smt.args['from']}"
                for j in joins:
                    l += self.__parcoursFrom(j, deep + 1)
                    req += f' {j}'
                    l += [f'{req} ; --(Sel)']
            if self.debug: log.debug('\t' * deep, f"<-- Select...{l}")
            return l
        elif isinstance(smt, From):  # ok
            if self.debug: log.debug('\t' * deep, f"--> From : {smt}")
            l = self.__parcoursFrom(smt.this, deep + 1)
            if self.debug: log.debug('\t' * deep, f"<-- From...{l}")
            return l
        elif isinstance(smt, Table):  # ok
            if self.debug: log.debug('\t' * deep, f"--> Table : {smt.this}")
            l = [f'Select * From {smt.this} ; --(Tab)']
            rep = f'Select * From {smt.this}'
            if "joins" in smt.args:
                joins = smt.args["joins"]
                for j in joins:
                    l += self.__parcoursFrom(j, deep + 1)
                    rep += f' {j}'
                    l += [f'{rep} ; --(TaJ)']
            if self.debug: log.debug('\t' * deep, f"<-- Table...{l}")
            return l
        elif isinstance(smt, Join):  # ok
            if self.debug: log.debug('\t' * deep, f"--> Join : {smt}")
            l = self.__parcoursFrom(smt.this, deep + 1)
            if self.debug: log.debug('\t' * deep, f"<-- Join...{l}")
            return l
        elif isinstance(smt, Subquery):
            if self.debug: log.debug('\t' * deep, f"--> Subquery : {smt.this}")
            l = self.__parcoursFrom(smt.this, deep + 1)
            rep = f'Select * From ({smt.this})'
            if "joins" in smt.args:
                joins = smt.args["joins"]
                for j in joins:
                    l += self.__parcoursFrom(j, deep + 1)
                    rep += f' {j}'
                    l += [f'{rep} ; --(Sub)']
            if self.debug: log.debug('\t' * deep, f"<-- Subquery...{l}")
            return l
        else:
            if self.debug: log.debug(f"==> Unknown Smt {type(smt)} : {smt} ")

    def __corriger_casse(self, chaine, termes_reference):
        """
        Version qui préserve les identifiants SQL avec points et alias.
        """
        # Créer le mapping insensible à la casse
        mapping = {terme.lower(): terme for terme in termes_reference}

        # Pattern pour capturer les mots, y compris avec préfixes (e.nom, t1.id, etc.)
        pattern = r'\b([a-zA-Z_]\w*\.)?([a-zA-Z_]\w*)\b'

        def replacer(match):
            prefixe = match.group(1) or ''  # e. ou t1. ou rien
            mot = match.group(2)
            mot_lower = mot.lower()

            # Corriger le mot principal
            mot_corrige = mapping.get(mot_lower, mot)

            return prefixe + mot_corrige

        resultat = re.sub(pattern, replacer, chaine, flags=re.IGNORECASE)
        return resultat


    def sbs_sql(self):
        """
        Créer les différentes requêtes SQL (qui s'éxécutent directement) et 
        les renvoie dans une liste.
        :return: La liste de toutes les requêtes SQL.
        """

        if self.debug:
            print(f"==> sbs_sql() : {self.__str}")
            print(f"==> sbs_sql() : {self.sqlTables}")
            print(f"==> sbs_sql() : {self.__db.dbTables}")

        log = get_logger("sql")

        smt = self.stringToQuery()

        sql_lst = []

        if self.distinct:
            cls_distinct = ' Distinct '
        else:
            cls_distinct = ''
        cls_select_bis = ''
        if self.select is not None:
            cls_select = ', '.join([str(x) for x in self.select])
        else:
            cls_select = ''

        cls_from = ' ' + self.from_join

        if self.where is not None:
            cls_where = ' ' + str(self.where)
        else:
            cls_where = ''

        if self.group is not None:
            att_list = []
            for (t, a) in self.sqlTables:
                (id_t, des) = self.__db.dbTables[t]
                for att in des:
                    att_list.append(f"{self.getAlias(t)}.{att[0]}")
            cls_select_bis = ', '.join(att_list)

            lgp = []
            for x in self.group:
                if '.' not in x:
                    for (t, a) in self.sqlTables:
                        (id_t, l) = self.__db.dbTables[t]
                        for y in l:
                            if x == y[0]:
                                lgp.append(self.getAlias(t) + '.' + x)
                else:
                    lgp.append(x)

            txt_group = ', '.join(lgp)
            cls_group_by = ' Group By ' + txt_group
            cls_group_by2 = ' Group By ' + ', '.join(self.group)
            cls_group_by_bis = ' Order By ' + txt_group
        else:
            cls_group_by = ''
            cls_group_by2 = ''
            cls_group_by_bis = ''
            txt_group = ''

        if self.having is not None:
            cls_having = ' ' + str(self.having)
            if cls_where == '':
                cls_where_tmp = ' Where (' + txt_group + ') in (select ' + txt_group + cls_from + cls_where + cls_group_by + cls_having + ')'
            else:
                cls_where_tmp = cls_where + ' and (' + txt_group + ') in (select ' + txt_group + cls_from + cls_where + cls_group_by + cls_having + ')'
        else:
            cls_having = ''
            cls_where_tmp = cls_where

        if self.order is not None:
            cls_order_by = ' ' + str(self.order)
        else:
            cls_order_by = ''

        if self.limit is not None:
            cls_limit = ' ' + str(self.limit)
        else:
            cls_limit = ''

        if self.offset is not None:
            cls_offset = ' ' + str(self.offset)
        else:
            cls_offset = ''

        sql_str = 'select ' + cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + cls_limit + cls_offset + ' ;'

        # Affichage des tables sources
        # et construction du FROM

        if self.debug: log.debug('Gestion du From :')
        lfrom = self.__parcoursFrom(smt)
        for s in lfrom:
            sql_lst.append(SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                               str=s,
                               name='§1-FROM§ ' + bold_substring(sql_str, s[14:-10]), debug=self.debug,
                               verbose=self.verbose, step_by_step=self.step_by_step))

        # WHERE
        if self.where is not None:
            loc_str = 'select * ' + cls_from + cls_where + ' ;'
            if self.debug: log.debug('Gestion du Where :', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(), str=loc_str,
                    name='§2-WHERE§ ' + bold_substring(sql_str, cls_from + cls_where), debug=self.debug,
                    verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # GROUP BY
        if self.group is not None:
            loc_str = 'select  ' + cls_select_bis + cls_from + cls_where + cls_group_by_bis + ' ;'
            if self.debug: log.debug('Gestion du Group By (1) : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§3-GROUP BY ' + txt_group + '§ ' + bold_substring(sql_str,
                                                                            cls_from + cls_where + cls_group_by),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # HAVING
        if self.having is not None:
            loc_str = 'select  ' + cls_select_bis + cls_from + cls_where_tmp + cls_group_by_bis + ' ;'
            if self.debug: log.debug('Gestion du Having : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§4-GROUP BY ' + txt_group + ' HAVING§ ' + bold_substring(sql_str,
                                                                                   cls_from + cls_where + cls_group_by + cls_having),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # SELECT
        loc_str = 'select ' + cls_select + cls_from + cls_where + cls_group_by + cls_having + ' ;'
        if self.debug: log.debug('Gestion du Select : ', loc_str)
        s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                str=loc_str,
                name='§5-SELECT§ ' + bold_substring(sql_str,
                                                    cls_select + cls_from + cls_where + cls_group_by + cls_having),
                debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
        s.setSQLTables(self.sqlTables)
        sql_lst.append(s)

        # DISTINCT
        if self.distinct:
            loc_str = 'select ' + cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + ' ;'
            if self.debug: log.debug('Gestion du Distinct : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§6-DISTINCT§ ' + bold_substring(sql_str,
                                                          cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # ORDER BY
        if self.order is not None:
            loc_str = 'select ' + cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + ' ;'
            if self.debug: log.debug('Gestion du Order By : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§7-ORDER BY§ ' + bold_substring(sql_str,
                                                          cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # LIMIT
        if self.limit is not None:
            loc_str = 'select ' + cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + cls_limit + ' ;'
            if self.debug: log.debug('Gestion du Limit : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§8-LIMIT§ ' + bold_substring(sql_str,
                                                       cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + cls_limit),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        # OFFSET
        if self.offset is not None:
            loc_str = 'select ' + cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + cls_limit + cls_offset + ' ;'
            if self.debug: log.debug('Gestion du Offset : ', loc_str)
            s = SQL(db=self.__db.getDBCon(), dbtype=self.__db.getType(),
                    str=loc_str,
                    name='§9-OFFSET§ ' + bold_substring(sql_str,
                                                        cls_distinct + cls_select + cls_from + cls_where + cls_group_by + cls_having + cls_order_by + cls_limit + cls_offset),
                    debug=self.debug, verbose=self.verbose, step_by_step=self.step_by_step)
            s.setSQLTables(self.sqlTables)
            sql_lst.append(s)

        if self.debug:
            for s in sql_lst:
                print(f"{highlight_sql_keywords(str(s))}")
        return sql_lst

    def __key(self, tbl):
        k = []
        for att, isKey, isKKey in tbl:
            if isKey: k.append(att)
        return k

    def __notkey(self, tbl):
        k = []
        for att, isKey, isKKey in tbl:
            if not isKey: k.append(att)
        return k

    def printTable(self, gb: list | None, stp=0, prec: list | None = None) -> list:
        """
        Affiche une table sur le terminal sous la forme d'un tableau.

        returns:
           une liste de tables (un ou deux selon le cas) de la forme (id, col, rows, dif)
           où :
           - id est le type d'affichage (entre 0 et 3)
           - col est la liste des colonnes
           - rows est la liste des lignes
           - dif est la liste des différences avec la table précédente
        """
        s = []
        if gb is not None:

            # On vérifie que les attributs du group-by sont bien dans les colonnes
            gb2 = []
            for i in gb:
                ok = False
                if i not in self.__col_names:  # L'attibut du group-by n'est pas dans les colonnes
                    spl = i.split(".")
                    if len(spl) == 2:  # S'il est préfixé, on recherche la table correspondante
                        i = spl[1]
                        for tb in self.sqlTables:
                            if tb[1] == spl[0]:
                                if tb[0] + "." + i in self.__col_names:
                                    gb2.append(tb[0] + "." + i)
                                    ok = True
                                    break
                            elif tb[0] == spl[0]:
                                if tb[1] + "." + i in self.__col_names:
                                    gb2.append(tb[1] + "." + i)
                                    ok = True
                                    break
                    else:
                        i = spl[0]
                        tbl = None

                    # on regarde s'il est un suffixe d'une colonne
                    if not ok:
                        for a in self.__col_names:
                            if a.endswith(i):
                                gb2.append(a)
                                break
                else:  # L'attribut du group-by est dans les colonnes
                    gb2.append(i)
            if self.debug:
                print(gb)
                print(gb2)
                print(self.__col_names)
            rows = group_table_as_rows(self.__col_names, self.__data, group_cols=gb2)

            if stp == 4:
                dif = lignes_disparues4(prec, rows)
                s.append((3, [self.__col_names, prec, dif]))
                s.append((0, None))
            else:
                self.__data = rows
            s.append((3, [self.__col_names, rows, None]))
        else:
            if stp in [2, 6, 8]:
                dif = lignes_disparues2(prec, self.__data)
                s.append((2, [self.__col_names, prec, dif]))
                s.append((0, None))
            s.append((2, [self.__col_names, self.__data, None]))

        s.append((0, f"Nombre de tuples : {len(self.__data)}"))
        return s

    def table(self, prec=[]) -> list:
        if self.debug:
            print('+'*80)
            print(f"table {self.__str}")
            print(f"table {self.name}")
            print(f"colonnes {self.__col_names}")
        s = []
        log = get_logger("sql")
        if (self.__data is None or self.__col_names is None):
            if self.debug:
                log.debug('---> No data or column names found. SQL query is executed')
            self.execute()
        if self.debug:
            log.debug(self.name)
        s.append((10, f"{delEntete(self.name, '§')}"))
        if self.debug: log.debug(self.__str)
        step = re.search(r'\§(\d)\-(.+)\§\s(.*)$', self.name)
        stnb = int(step[1])
        if stnb in [1, 2]:  # From et Where
            s.extend(self.printTable(None, stnb, prec))
        elif stnb in [3, 4]:  # Group-By et Having
            gp = re.search(r'GROUP BY\s+(.+?)(\sHAVING)?$', step[2])
            if self.__db.getType() == 'pgsql':
                lgp = []
                for att in gp[1].split(','):
                    if '.' in att:
                        tatt = att.split('.')
                        for (t, a) in self.sqlTables:
                            if a == tatt[0].strip().lower():
                                lgp.append(a + '.' + tatt[1].strip())
                            elif t.lower() == tatt[0].strip().lower():
                                lgp.append(att.strip().lower())
                    else:
                        for (t, a) in self.sqlTables:
                            (id_t, l) = self.__db.dbTables[t]
                            for x in l:
                                if x[0] == att.strip():
                                    if a is None:
                                        lgp.append(t + '.' + att.strip())
                                    else:
                                        lgp.append(a + '.' + att.strip())
                                    break
                if self.debug: log.debug(lgp)
                s.extend(self.printTable(lgp, stnb, prec))
            else:
                lgp = [x.strip() for x in gp[1].split(',')]
                if self.debug: log.debug(lgp)
                s.extend(self.printTable(lgp, stnb, prec))
        else:  # Select, Distinct, Order By, Limit, Offset
            s.extend(self.printTable(None, stnb, prec))
        return s

    def sbs(self) -> (int, list):
        """Retourne la liste des étapes de la requête SQL
        et le nombre d'étapes"""
        log = get_logger("SQL")
        alltabs = self.sbs_sql()
        l = []
        prec = []  # pour gérer la visualisation des suppressions (Where, Having et Limit)
        nb_stp = len(alltabs)
        for i, s in enumerate(alltabs):
            if self.debug: log.debug("sbs: %s" % s)
            l.append((i, s.table(prec)))
            prec = s.__data
        return nb_stp, l

    def buildStdCorrection(self, setHelp, sol, output='txt'):
        rep = ""
        self.cmp = self.similaire(sol)
        ok = self.cmp == 4
        #print(f"cmp: {self.cmp} ; ok: {ok}")
        if not ok and sol is not None:
            hint = ""
            match self.cmp:
                case 0:
                    rep ="❌ La requête proposée n'est pas correcte. Elle ne renvoie pas les mêmes résultats que la requête attendue."
                    if setHelp and sol.com:
                        hint =f"\n\n💡✨ {sol.com}"
                case 1:
                    rep ="⚠️ La requête renvoie les mêmes résultats que la requête attendue, mais lignes et colonnes ne sont pas dans le même ordre."
                case 2:
                    rep ="⚠️ La requête renvoie les mêmes résultats que la requête attendue, mais les lignes ne sont pas dans le même ordre."
                case 3:
                    rep ="⚠️ La requête renvoie les mêmes résultats que la requête attendue, mais les colonnes ne sont pas dans le même ordre."
            if output == 'txt':
                rep += (hint if hint else "") + "\n"
            elif output == 'html':
                rep = f"<p class='error'>{rep}</p>"+ (f"<p class='error'>{hint}</p>\n" if hint else "\n")
            elif output == 'md':
                rep += (hint if hint else "") + "\n"
            else:
                pass
        elif ok and sol is not None:
            rep = "✅ La requête renvoie les mêmes résultats que la requête attendue."
            hint = "\n ⚠️ Vérifiez que la requête répond bien à la demande."
            if output == 'txt':
                rep += (hint if hint else "") + "\n"
            elif output == 'html':
                rep = f"<p class='success'>{rep}</p>"+ (f"<p class='success'>{hint}</p>\n" if hint else "\n")
            elif output == 'md':
                rep += (hint if hint else "") + "\n"
            else:
                pass
        else:
            pass  # print("⚠️ Pas de correction disponible pour cette requête.")
        return rep

#################################################################
#################################################################
#################################################################

if __name__ == "__main__":
    pass
