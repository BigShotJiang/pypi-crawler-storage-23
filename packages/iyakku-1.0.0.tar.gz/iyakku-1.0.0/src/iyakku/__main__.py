"""Entry point for running Iyakku via `python -m iyakku`."""
from iyakku.launcher import main

if __name__ == "__main__":
    main()
