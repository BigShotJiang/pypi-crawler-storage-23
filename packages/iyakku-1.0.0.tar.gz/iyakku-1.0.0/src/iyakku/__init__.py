"""Iyakku - Remote media controller."""
__version__ = "1.0.0"
