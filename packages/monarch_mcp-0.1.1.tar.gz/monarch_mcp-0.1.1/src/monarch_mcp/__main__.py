"""Allow running the package with `python -m monarch_mcp`."""

from monarch_mcp.server import main

main()
