#! /usr/bin/env bash

function bluer_ai_git_get_remote() {
    git remote -v
}
