#! /usr/bin/env bash

function test_bluer_ai_watch() {
    bluer_ai_watch count=3,~clear,seconds=1 ls
}
