from easymcserver.ui.menus import main_menu


def main(test: bool = False):
    main_menu(test=test)


if __name__ == "__main__":
    main(test=False)
