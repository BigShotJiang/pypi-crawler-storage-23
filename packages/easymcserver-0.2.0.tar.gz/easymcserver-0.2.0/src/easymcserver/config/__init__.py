"""Config and properties utilities."""

__all__ = ["server_properties", "auto_start_stop_java"]
