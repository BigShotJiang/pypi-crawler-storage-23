"""
Technical Analysis Module

Organized by category:
- crossovers: crossover, crossunder, crossed
- indicators: rma, sma, ema, atr, rsi, dmi, adx, macd, bbands, supertrend, renko
- pivots: detect_pivots, detect_pivot_lows, detect_pivot_highs, pivothigh, pivotlow,
          pivot_structure
- helpers: HasBarIndex protocol, TradingHelpers class
"""

from .crossovers import crossover, crossunder, crossed
from .indicators import rma, sma, ema, atr, rsi, dmi, adx, macd, bbands, supertrend, renko
from .pivots import (
    detect_pivots, detect_pivot_lows, detect_pivot_highs,
    pivothigh, pivotlow, pivot_structure,
)
from .helpers import HasBarIndex, TradingHelpers

__all__ = [
    'crossover', 'crossunder', 'crossed',
    'rma', 'sma', 'ema', 'atr', 'rsi', 'dmi', 'adx', 'macd',
    'bbands', 'supertrend', 'renko',
    'detect_pivots', 'detect_pivot_lows', 'detect_pivot_highs',
    'pivothigh', 'pivotlow', 'pivot_structure',
    'HasBarIndex', 'TradingHelpers',
]
