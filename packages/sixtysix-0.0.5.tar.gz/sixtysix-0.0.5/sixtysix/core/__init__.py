# Core building blocks — domain models, params, series, decorators, registry.
# Imported by indicator.py and strategy.py; re-exported via sixtysix/__init__.py.
