"""
SixtySix - Framework for Building Trading Strategies and Technical Indicators

Quick Start - Strategies:
    from sixtysix import strategy, computed, param, persistent, Line, Signal

    @strategy(name='sma_crossover', display_name='SMA Crossover')
    class SMACrossover:
        fast = param.number(default=20, min=5, max=100)
        slow = param.number(default=50, min=10, max=200)

        @computed
        def fast_sma(self, df):
            return df['close'].rolling(self.fast).mean()

        @computed
        def slow_sma(self, df):
            return df['close'].rolling(self.slow).mean()

        def plot(self, df):
            return [
                Line(y=self.fast_sma(df), color='#3b82f6'),
                Line(y=self.slow_sma(df), color='#f97316'),
            ]

        def on_bar(self, df):
            if self.ta.crossover(self.fast_sma(df), self.slow_sma(df)):
                return self.buy()

Quick Start - Indicators:
    from sixtysix import indicator, param, Line

    @indicator(name='sma', display_name='SMA', type='overlay')
    class SMA:
        period = param.number(default=20, min=1, max=500)
        color = param.color(default='#2962ff')

        def plot(self, df):
            sma = df['close'].rolling(self.period).mean()
            return [Line(y=sma, color=self.color, line_width=2)]
"""

__version__ = '0.0.5'

# =============================================================================
# Plot Components
# =============================================================================
from .core.plot import (
    # Type aliases
    SeriesLike,
    ColorLike,
    PlotComponent,
    # Literal types
    LineDash,
    ScatterShape,
    PositionMode,
    TextAlign,
    TextBaseline,
    # Components
    Line,
    Scatter,
    Bar,
    HBar,
    HLine,
    Fill,
    Segment,
    Marker,
    SignalPlot,
    Label,
    # Panel system
    Panel,
    PlotResult,
    # Serialization
    extract_plot_data,
    extract_plot_data_with_panels,
)

# =============================================================================
# Parameters
# =============================================================================
from .core.params import (
    ParamValue,
    SelectOption,
    ConfigParam,
    InputParam,
    param,
    StrategyConfig,
)

# =============================================================================
# Types (now in core/indicator.py)
# =============================================================================
from .core.indicator import (
    StyleValue,
    RenderComponent,
    IndicatorConfig,
    IndicatorResult,
)

# =============================================================================
# Domain Models
# =============================================================================
from .core.domain import (
    Signal,
    SignalType,
    SignalDict,
    PositionSide,
    PositionInfo,
    TradingContext,
    SizingMode,
    Trade,
    TradeDict,
    OpenTrade,
    OpenTradeDict,
    Order,
    OrderSide,
    OrderType,
    OrderStatus,
    OrderDict,
    Position,
    PositionDict,
    AccountBalance,
    AccountBalanceDict,
)

# =============================================================================
# Indicators
# =============================================================================
from .core.indicator import (
    IndicatorInfoDict,
    ConfigParamDict,
    IndicatorResponseDict,
    INDICATOR_REGISTRY,
    indicator,
    Indicator,
    IndicatorRef,
    use_indicator,
    get_indicator,
    get_available_indicators,
    get_indicator_info,
    get_all_indicators,
)

# =============================================================================
# Decorators
# =============================================================================
from .core.decorators import (
    ComputedValue,
    Persistent,
    persistent,
    computed,
)

# =============================================================================
# Strategies
# =============================================================================
from .core.strategy import (
    SignalLike,
    OnBarResult,
    StrategyInfoDict,
    StrategyConfigParamDict,
    StrategyResponseDict,
    STRATEGY_REGISTRY,
    compute_mtf_bar_indices,
    strategy,
    Strategy,
    get_strategy,
    get_available_strategies,
    get_strategy_info,
    get_all_strategies,
)

# =============================================================================
# Trading Utilities
# =============================================================================
from .core.ta import TradingHelpers

# =============================================================================
# Auto-Discovery
# =============================================================================
from .core.registry import discover_modules

__all__ = [
    # Version
    '__version__',

    # Plot Components
    'SeriesLike',
    'ColorLike',
    'PlotComponent',
    'LineDash',
    'ScatterShape',
    'PositionMode',
    'TextAlign',
    'TextBaseline',
    'Line',
    'Scatter',
    'Bar',
    'HBar',
    'HLine',
    'Fill',
    'Segment',
    'Marker',
    'SignalPlot',
    'Label',
    'Panel',
    'PlotResult',
    'extract_plot_data',
    'extract_plot_data_with_panels',

    # Parameters
    'ParamValue',
    'SelectOption',
    'ConfigParam',
    'InputParam',
    'param',
    'StrategyConfig',

    # Types
    'StyleValue',
    'RenderComponent',
    'IndicatorConfig',

    # Domain Models
    'Signal',
    'SignalType',
    'SignalDict',
    'PositionSide',
    'PositionInfo',
    'TradingContext',
    'SizingMode',
    'Trade',
    'TradeDict',
    'OpenTrade',
    'OpenTradeDict',
    'Order',
    'OrderSide',
    'OrderType',
    'OrderStatus',
    'OrderDict',
    'Position',
    'PositionDict',
    'AccountBalance',
    'AccountBalanceDict',

    # Indicators
    'IndicatorInfoDict',
    'ConfigParamDict',
    'IndicatorResponseDict',
    'INDICATOR_REGISTRY',
    'indicator',
    'Indicator',
    'IndicatorRef',
    'use_indicator',
    'get_indicator',
    'get_available_indicators',
    'get_indicator_info',
    'get_all_indicators',
    'IndicatorResult',

    # Decorators
    'ComputedValue',
    'Persistent',
    'persistent',
    'computed',

    # Strategies
    'SignalLike',
    'OnBarResult',
    'StrategyInfoDict',
    'StrategyConfigParamDict',
    'StrategyResponseDict',
    'STRATEGY_REGISTRY',
    'compute_mtf_bar_indices',
    'strategy',
    'Strategy',
    'get_strategy',
    'get_available_strategies',
    'get_strategy_info',
    'get_all_strategies',

    # Trading Utilities
    'TradingHelpers',

    # Auto-Discovery
    'discover_modules',
]
