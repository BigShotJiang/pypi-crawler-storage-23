# -*- coding: utf-8 -*-

from abc import abstractmethod
from ddans.common.type import ALL_DEPLOYS, ALL_ROOMS
from ddans.native.system import ContentType, NSystem
from ddans.native.hook import NHook
from ddans.domain.regex import Regex
from ddans.terminal import Terminal
from ddans.native.log import NLog
from ddans.module.args_parser import ArgsParser


class Cmd(object):

    def __init__(self, cmd='', desc=''):
        self._cmd = cmd
        self._desc = desc
        self._parser = ArgsParser()

    @property
    def cmd(self):
        return self._cmd or ''

    @property
    def desc(self):
        return self._desc or ''

    @property
    def parser(self):
        return self._parser

    def add_argument(self,
                     action: str,
                     short: str = '',
                     type=str,
                     help=None,
                     default=None):
        self.parser.add_argument(action, short, type, help, default)

    def add_help_argument(self):
        self._parser.add_argument("help", "h", type=bool, help="帮助信息")

    def show_usage(self):
        if self.cmd_valid("h", "help"):
            self.parser.usage()
            return True
        return False

    def cmd_value(self, *args, default=None):
        return self.parser.get_value(*args, default=default)

    def cmd_has(self, key):
        return key in self.parser.actions

    def cmd_valid(self, *args):
        return self.parser.get_value(*args, default=False)

    def cmd_export(self, str: ContentType):
        filename = self.parser.get_value(">", default="")
        if not NHook.isvalid_str(filename):
            return
        _, res = NHook.to(NSystem.write_file, str, filename)
        if NHook.isvalid_str(res):
            NLog.success(f">> {res}")

    @abstractmethod
    def exec(self):
        pass

    @staticmethod
    def select_platform():
        return Terminal.select("请选择平台", ["windows", "mac", "linux"])

    @staticmethod
    def select_win_arch():
        return Terminal.select("请选择arch", ["x64", "ia32"])

    @staticmethod
    def select_arch():
        return Terminal.select("请选择arch", ["x64", "arm64"])

    @staticmethod
    def select_deploy():
        return Terminal.select("选择服务器", ALL_DEPLOYS)

    @staticmethod
    def select_room():
        return Terminal.select("请选择机房", ALL_ROOMS)

    @staticmethod
    def select_needupload():
        return Terminal.select_ok("正式上传")

    @staticmethod
    def input_version(title: str = "请输入版本号 (1.0.0): ", default: str = None):
        return Terminal.input_text(title,
                                   pattern=Regex.version,
                                   default=default)

    @staticmethod
    def input_build_version(title: str = "请输入修正号 (0-99): "):
        return Terminal.input_text(title, pattern=Regex.number, default="0")

    @staticmethod
    def input_number(title: str = "请输入数字: ", default="0"):
        return Terminal.input_text(title,
                                   pattern=Regex.number,
                                   default=default)

    @staticmethod
    def select_tempupload():
        return Terminal.select_ok("临时上传")

    @staticmethod
    def select_rebuildresource():
        return Terminal.select_ok("编译资源")

    @staticmethod
    def is_true(cmd):
        if cmd == '1' or cmd is True:
            return True
        else:
            return False
