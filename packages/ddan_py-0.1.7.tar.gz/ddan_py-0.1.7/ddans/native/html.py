# -*- coding: utf-8 -*-

import string
from typing import Dict, List, Literal, Optional, Union

from ddans.common.type import Element
from ddans.native.hook import NHook


class NHtml:

    @staticmethod
    def list(list: List[str],
             style: Optional[Dict[str, str | int]] = None,
             el: Literal["ol", "ul"] = "ul",
             type: Literal["1", "i", "a", "A", "i", "I"] = "1"):
        if not NHook.isvalid(list, List) or len(list) <= 0:
            return ""
        content = NHtml.line(list, style, el='li')
        attribute = None if el == 'ul' else {"type": type}
        return NHtml.element(content, el, style, attribute)

    @staticmethod
    def line(content: Union[str, List[str]],
             style: Optional[Dict[str, str | int]] = None,
             attribute: Optional[Dict[str, str]] = None,
             order: Optional[Literal["numeric", "alpha", "chinese"]] = None,
             el: Element = "p"):
        # text-indent: 2em 段落首行缩进两个汉字
        if isinstance(content, str):
            content = [content]

        if not NHook.isvalid(content, List):
            return ""

        result = ""
        for idx, item in enumerate(content):
            prefix = NHtml.order(idx, order)
            result += NHtml.element(f"{prefix}{item}", el, style, attribute)
        return result

    @staticmethod
    def link(href: str, text: str = None):
        url = href or ''
        return NHtml.element(text or url, 'a', attribute={'href': url})

    @staticmethod
    def element(content: str,
                el: Element,
                style: Optional[Dict[str, str | int]] = None,
                attribute: Optional[Dict[str, str]] = None):
        el = el or 'p'
        content = content or ''

        # 创建CSS样式字符串
        style_str = ""
        if style:
            for key, value in style.items():
                style_str += f"{key}: {value};"

        attribute_str = ""
        if attribute:
            for key, value in attribute.items():
                attribute_str += f" {key}='{value}' "

        result = f"<{el} style='{style_str}'{attribute_str}>" if style_str \
            else f"<{el}{attribute_str}>"
        result += f"{content}"
        result += f"</{el}>"
        return result

    @staticmethod
    def order(idx: int,
              order: Literal["numeric", "alpha", "chinese"] = None) -> str:
        if not isinstance(idx, int):
            return ""
        if order == "numeric":
            result = f"{idx + 1}. "
        elif order == "alpha":
            result = f"{string.ascii_lowercase[idx % 26]}. "
        elif order == "chinese":
            result = f"{NHook.number_to_chinese[idx]}、"
        else:
            result = ""
        return result

    @staticmethod
    def markdown_html(content: str, title: str = None):
        return (f"""<!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, \
                    initial-scale=1">
                <link rel="stylesheet" \
                    href="https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.2.0/github-markdown.min.css">
                <title>{title or ''}</title>
            </head>
            <body>
            <article class="markdown-body">
            {content or ''}
            </article>
            </body>
            </html>
        """)
