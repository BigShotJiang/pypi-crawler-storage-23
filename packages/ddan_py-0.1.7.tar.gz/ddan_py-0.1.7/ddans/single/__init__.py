"""Singleton utilities module"""

from .emailer import *
from .gitter import *
from .globaler import *
from .logging import *
from .manager import *
from .net import *
from .worker import *
