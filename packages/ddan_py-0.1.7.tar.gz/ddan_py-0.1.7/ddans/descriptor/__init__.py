"""Descriptor module"""

from .singleton import *
from .static import *
