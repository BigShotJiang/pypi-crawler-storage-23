"""Configuration module"""


from .config import *
from .id import *
from .locale import *
from .time import *
