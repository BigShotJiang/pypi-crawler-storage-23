# -*- coding: utf-8 -*-
from typing import Any, Callable, Literal, Optional, TypeVar, TypedDict

T = TypeVar('T', bound=Optional[Any])

Callback = Callable[..., T]

Element = Literal["p", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "html", 'a',
                  'div', 'span', 'text', 'image', 'video', "body"]

ALL_ROOMS = ["default", "cn", "sgp", "us"]
RoomType = Literal["default", "cn", "sgp", "dc", "us"]

ALL_DEPLOYS = ["test", "prod"]
DeployType = Literal["test", "prod"]


class DataSizeResult(TypedDict):
    total: int
    desc: str
    gb: int
    mb: int
    kb: int
    b: int


class UrlData(TypedDict):
    href: str
    url: str
    path: str
    host: str
    query: str
    scheme: str
    origin: str
    params: dict
