"""Data module"""

from .color import *
