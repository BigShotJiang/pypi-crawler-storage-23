"""
Enum de parsers disponíveis para lojas.
"""

from enum import Enum
from notify_utils.parsers.stores_parser import (
    MazeAPIJSONParser,
    NikeAPIGatewayJSONParser,
    BelezaNaWebHTMLParser,
    SephoraAPIJSONParser,
    NewEraAPIJSONParser,
    HavanHTMLParser,
    KabumAPIJSONParser
)
from notify_utils.parsers.magalu_html_parser import MagazineLuizaHTMLParser


class StoresParserEnum(Enum):
    """
    Enum com todos os parsers disponíveis.

    Cada valor é a **classe** do parser correspondente (não uma instância).
    Use ParserFactory.get_parser() para obter uma instância pronta para uso.
    Isso evita que dependências opcionais (ex: beautifulsoup4) causem
    ImportError ao importar o módulo, mesmo que o parser não seja utilizado.

    Parsers disponíveis:
    - NIKE_APIGATEWAY_JSON: Parser para API Gateway da Nike (JSON)
    - MAZE_API_JSON: Parser para API da Maze Shop (JSON)
    - BELEZA_NA_WEB_HTML: Parser para Beleza na Web (HTML) - requer beautifulsoup4
    - SEPHORA_API_JSON: Parser para API Linx Impulse da Sephora Brasil (JSON)
    - MAGALU_HTML: Parser para Magazine Luiza (HTML com __NEXT_DATA__)
    - NEW_ERA_API_JSON: Parser para API da New Era Brasil (JSON)
    - HAVAN_HTML: Parser para Havan (HTML Magento 2) - requer beautifulsoup4
    - KABUM_API_JSON: Parser para API da KaBuM! (JSON)

    Exemplo:
        >>> from notify_utils.parsers import ParserFactory, StoresParserEnum
        >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
        >>> products = parser.from_json(json_data)
        >>>
        >>> # Para Beleza na Web (HTML) - requer: pip install beautifulsoup4 lxml
        >>> parser_html = ParserFactory.get_parser(StoresParserEnum.BELEZA_NA_WEB_HTML)
        >>> products_html = parser_html.from_html(html_data)
        >>>
        >>> # Para Sephora (JSON - expande SKUs)
        >>> parser_sephora = ParserFactory.get_parser(StoresParserEnum.SEPHORA_API_JSON)
        >>> products_sephora = parser_sephora.from_json(sephora_data)
    """

    NIKE_APIGATEWAY_JSON = NikeAPIGatewayJSONParser
    MAZE_API_JSON = MazeAPIJSONParser
    BELEZA_NA_WEB_HTML = BelezaNaWebHTMLParser
    SEPHORA_API_JSON = SephoraAPIJSONParser
    MAGALU_HTML = MagazineLuizaHTMLParser
    NEW_ERA_API_JSON = NewEraAPIJSONParser
    HAVAN_HTML = HavanHTMLParser
    KABUM_API_JSON = KabumAPIJSONParser
