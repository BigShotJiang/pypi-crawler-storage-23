"""
Factory para obter parsers de lojas.
"""

from notify_utils.parsers.stores_parser import ParserError
from notify_utils.parsers.stores_parser_enum import StoresParserEnum
from notify_utils.parsers.stores_parser_interface import StoresParserInterface


class ParserFactory:
    """
    Factory para obter instâncias de parsers de lojas.

    O StoresParserEnum armazena as classes dos parsers (não instâncias).
    Este factory instancia o parser solicitado em O(1), sem loop.

    Uso:
        >>> from notify_utils.parsers import ParserFactory, StoresParserEnum
        >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
        >>> products = parser.from_json(api_response)

    Vantagens:
    - Desacoplamento: código não precisa conhecer classes concretas
    - Extensibilidade: novos parsers via StoresParserEnum
    - Type hints: retorna StoresParserInterface
    - Performance: acesso O(1) direto via parser_type.value()
    """

    @staticmethod
    def get_parser(parser_type: StoresParserEnum) -> StoresParserInterface:
        """
        Retorna instância do parser solicitado.

        Args:
            parser_type: Tipo do parser (valor de StoresParserEnum)

        Returns:
            Instância do parser implementando StoresParserInterface

        Raises:
            ParserError: Se ocorrer erro ao instanciar o parser
                         (ex: dependência opcional não instalada)

        Example:
            >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
            >>> isinstance(parser, StoresParserInterface)
            True
        """
        try:
            return parser_type.value()
        except ImportError as e:
            raise ParserError(
                f"Dependência necessária não instalada para {parser_type.name}: {e}"
            ) from e
        except Exception as e:
            raise ParserError(
                f"Erro ao instanciar parser {parser_type.name}: {e}"
            ) from e
