"""
Parser para Magazine Luiza - Extração de produtos do HTML com __NEXT_DATA__.

Extrai produtos embedded no JSON __NEXT_DATA__ do Magazine Luiza.
O JSON contém lista completa de produtos com preços, SKUs e metadados.

Estrutura JSON esperada:
    props.pageProps.data.search.products[]: Lista de produtos
    Cada produto contém:
        - id: string (SKU)
        - title: string (nome)
        - price: dict (bestPrice, fullPrice, discount)
        - seller: dict (id, sku)
        - brand: dict (label, slug)
        - image: string (URL template)
        - url: string (caminho relativo)
        - available: bool

Uso:
    from notify_utils import ParserFactory, StoresParserEnum

    # Obter parser
    parser = ParserFactory.get_parser(StoresParserEnum.MAGALU_HTML)

    # Ler HTML
    with open('magalu.html', 'r', encoding='utf-8') as f:
        html = f.read()

    # Extrair produtos
    products = parser.from_html(html)

    for product in products:
        print(f"{product.name}: R$ {product.current_price_float:.2f}")

Características:
    - Parse híbrido: extrai JSON embedded do script __NEXT_DATA__
    - Preço atual: usa bestPrice (melhor preço disponível)
    - Preço antigo: usa fullPrice se maior que bestPrice
    - URLs relativas convertidas para absolutas (magazinevoce.com.br)
    - Ignora produtos com bestPrice <= 0 ou indisponíveis
    - Suporta imagens com template {w}x{h}
    - Extrai marca e SKU do seller

Autor: Claude Code
Data: 2026-02-09
"""

import re
import logging
from typing import Optional
from notify_utils.models import Coupon, Product
from notify_utils.parsers.stores_parser_interface import StoresParserInterface
from notify_utils.parsers.stores_parser import ParserError
from notify_utils.parser import parse_price

try:
    import orjson as _json_lib
except ImportError:
    import json as _json_lib  # type: ignore[no-redef]

logger = logging.getLogger(__name__)


class MagazineLuizaHTMLParser(StoresParserInterface):
    """
    Parser para Magazine Luiza - extrai produtos do __NEXT_DATA__ JSON embedded.

    Características:
        - Parse de JSON embedded no HTML (<script id="__NEXT_DATA__">)
        - Preço atual: bestPrice (melhor preço disponível)
        - Preço antigo: fullPrice (se maior que bestPrice)
        - URLs relativas → absolutas
        - Deduplicação automática por SKU
        - Validações: ignora bestPrice <= 0 ou produtos indisponíveis
    """

    BASE_URL = "https://www.magazinevoce.com.br"

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Magazine Luiza usa HTML, não JSON direto.
        Use from_html() para extrair produtos.
        """
        raise ParserError(
            "Magazine Luiza usa HTML com JSON embedded. Use from_html() em vez de from_json()."
        )

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos do HTML Magazine Luiza parseando __NEXT_DATA__ JSON.

        Args:
            html_data: Conteúdo HTML da página de produtos

        Returns:
            Lista de produtos únicos (deduplicados por SKU)

        Raises:
            ParserError: Se JSON não encontrado ou inválido
        """
        if not html_data or not html_data.strip():
            logger.warning("HTML vazio recebido")
            return []

        try:
            # Extrair JSON do __NEXT_DATA__
            json_data = self._extract_next_data(html_data)

            # Navegar até produtos
            products_data = self._get_products_from_json(json_data)

            # Converter para objetos Product
            products = []
            seen_skus = set()

            for product_data in products_data:
                try:
                    product = self._parse_product(product_data)

                    # Deduplicação por SKU
                    if product.sku in seen_skus:
                        logger.debug(f"SKU duplicado ignorado: {product.sku}")
                        continue

                    products.append(product)
                    seen_skus.add(product.sku)

                except (ValueError, KeyError, TypeError) as e:
                    logger.warning(f"Erro ao parsear produto: {e}")
                    continue

            logger.info(
                f"✅ Magazine Luiza: {len(products)} produtos extraídos "
                f"({len(products_data) - len(products)} ignorados)"
            )

            return products

        except ParserError:
            raise
        except Exception as e:
            raise ParserError(f"Erro ao parsear HTML Magazine Luiza: {e}") from e

    def _extract_next_data(self, html: str) -> dict:
        """
        Extrai JSON do script tag <script id="__NEXT_DATA__">.

        Args:
            html: Conteúdo HTML completo

        Returns:
            Dicionário com dados JSON parseados

        Raises:
            ParserError: Se __NEXT_DATA__ não encontrado ou JSON inválido
        """
        # Regex para capturar JSON do __NEXT_DATA__
        pattern = r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>'
        match = re.search(pattern, html, re.DOTALL)

        if not match:
            raise ParserError("__NEXT_DATA__ não encontrado no HTML")

        json_str = match.group(1)

        try:
            return _json_lib.loads(json_str)
        except Exception as e:
            raise ParserError(f"Erro ao parsear __NEXT_DATA__ JSON: {e}") from e

    def _get_products_from_json(self, json_data: dict) -> list[dict]:
        """
        Navega estrutura JSON até lista de produtos.

        Estrutura esperada:
            props.pageProps.data.search.products

        Args:
            json_data: Dicionário parseado do __NEXT_DATA__

        Returns:
            Lista de dicionários com dados de produtos

        Raises:
            ParserError: Se estrutura não encontrada
        """
        try:
            return json_data["props"]["pageProps"]["data"]["search"]["products"]
        except KeyError as e:
            raise ParserError(
                f"Estrutura JSON inválida: chave {e} não encontrada. "
                "Esperado: props.pageProps.data.search.products"
            ) from e

    def _parse_product(self, data: dict) -> Product:
        """
        Converte dicionário JSON em objeto Product.

        Args:
            data: Dicionário com dados do produto

        Returns:
            Objeto Product preenchido

        Raises:
            ValueError: Se produto inválido (sem preço, indisponível)
            KeyError: Se campos obrigatórios ausentes
        """
        # Campos obrigatórios
        product_id = str(data["id"])
        title = data["title"].strip()
        available = data.get("available", False)

        # Validação: produto disponível
        if not available:
            raise ValueError(f"Produto {product_id} indisponível")

        # Preços
        price_data = data.get("price", {})
        best_price_str = price_data.get("bestPrice", "0")
        full_price_str = price_data.get("fullPrice", "0")

        # Parse de preços (strings → float)
        current_price = parse_price(best_price_str)
        full_price = parse_price(full_price_str)

        # Validação: preço válido
        if current_price <= 0:
            raise ValueError(f"Produto {product_id} com bestPrice inválido: {current_price}")

        # Preço antigo: só usa fullPrice se for maior que bestPrice
        old_price = full_price if full_price > current_price else 0.0

        # Seller e SKU
        seller_data = data.get("seller", {})
        sku = seller_data.get("sku", product_id)
        seller_name = seller_data.get("description", "")  # Ex: "Magalu", "Loja Parceira"

        # URLs
        image_url = self._make_absolute_image_url(data.get("image", ""))
        product_url = self._make_absolute_url(data.get("url", ""))

        coupon = None
        offer_tags = seller_data.get('tags', [])

        best_coupon_data = None
        max_discount = 0

        for tag in offer_tags:
            if tag.get('type') == 'coupon':
                discount_value = tag.get('discountValue', 0)
                if discount_value > max_discount:
                    max_discount = discount_value
                    best_coupon_data = tag

        if best_coupon_data:
            coupon = Coupon(
                        code=best_coupon_data.get('code', ''),
                        discount_type=best_coupon_data.get('discountType', 'percentage'),
                        discount_value=best_coupon_data.get('discountValue', 0),
                        message=best_coupon_data.get('message', ''),
                        start_date=best_coupon_data.get('startDate'),
                        end_date=best_coupon_data.get('endDate')
                    )


        return Product(
            product_id=product_id,
            name=title,
            current_price_float=current_price,
            old_price_float=old_price,
            available=available,
            url=product_url,
            image_url=image_url,
            sku=sku,
            marketplace_name="Magazine Luiza",
            seller=seller_name if seller_name else "Magazine Luiza",
            coupon=coupon
        )

    def _make_absolute_url(self, url: str) -> str:
        """
        Converte URL relativa em absoluta.

        Args:
            url: URL relativa (ex: /magazineslnd/produto/p/123/...)

        Returns:
            URL completa (https://www.magazinevoce.com.br/magazineslnd/...)
        """
        if not url or not url.strip():
            return ""

        url = url.strip()

        # Já é absoluta
        if url.startswith("http://") or url.startswith("https://"):
            return url

        # Relativa: adicionar base
        if url.startswith("/"):
            return f"{self.BASE_URL}{url}"

        return f"{self.BASE_URL}/{url}"

    def _make_absolute_image_url(self, url: str) -> str:
        """
        Converte URL de imagem em absoluta.

        Magazine Luiza usa template: {w}x{h} (largura x altura).
        Substitui por tamanho padrão 500x500.

        Args:
            url: URL template (ex: https://a-static.mlcdn.com.br/{w}x{h}/image.jpg)

        Returns:
            URL completa com dimensões (https://...500x500/image.jpg)
        """
        if not url or not url.strip():
            return ""

        url = url.strip()

        # Adicionar https: se falta protocolo
        if url.startswith("//"):
            url = f"https:{url}"

        # Substituir templates de tamanho
        url = url.replace("{w}", "500").replace("{h}", "500")

        return url

    def is_last_page(self, response: Optional["ResponseData"] = None) -> bool:
        """
        Detecta se é a última página de produtos (para paginação).

        Magazine Luiza:
            - Retorna 404 Not Found se página inexistente
            - Retorna lista vazia de produtos se fim da paginação

        Args:
            response: Objeto ResponseData com status_code e body

        Returns:
            True se última página, False caso contrário
        """
        if response is None:
            return False
        
        url = response.url or ""

        if 'validate.perfdrive.com' in url:
            logger.info("🛑 Pagina anti-bot detectada: redirecionamento para validate.perfdrive.com")
            return False

        # 404 = página não existe
        if response.is_not_found():
            logger.info("🛑 Última página detectada: 404 Not Found")
            return True

        # Tentar parsear produtos do HTML

        if response.status_code == 302:
            logger.info("🛑 Última página detectada: 302 Redirect")
            return True

        if response.status_code == 200 and 'page=' in url:
            content_type = response.headers.get("Content-Type", "") or response.headers.get("content-type", "")
            if not content_type:
                logger.warning("⚠️  Content-Type ausente na resposta")
                return False

            if "text/html" not in content_type:
                logger.warning(f"⚠️  Content-Type inesperado: {content_type}")
                return False

        try:
            if response.body:
                json_data = self._extract_next_data(response.body)
                products = self._get_products_from_json(json_data)

                # Sem produtos = fim da paginação
                if not products:
                    logger.info("🛑 Última página detectada: 0 produtos encontrados")
                    return True

        except ParserError:
            # Se __NEXT_DATA__ não existe, considerar última página
            logger.warning("⚠️  __NEXT_DATA__ não encontrado - assumindo última página")
            return True
        except Exception as e:
            logger.error(f"❌ Erro ao verificar última página: {e}")

        return False
