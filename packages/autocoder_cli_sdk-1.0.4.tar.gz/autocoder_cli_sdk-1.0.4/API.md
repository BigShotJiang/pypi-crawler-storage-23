# AutoCoder CLI SDK（Python）API 使用文档

本文档面向 `autocoder_cli_sdk` 的**使用者**，按当前实现说明如何在 Python 中调用 `auto-coder.run`（或内部 SDK）完成查询/代码生成、会话管理、批量并发、诊断与进程中止。

> 说明：本 SDK 的核心 `query()` **返回的是（异步）生成器**，你需要用 `for` / `async for` 迭代获取结果。若你想“一次拿到完整字符串/模型”，请使用 `quick_query()` / `json_query()`。

## 安装与前置条件

### 安装

```bash
pip install autocoder-cli-sdk
```

如果你在本仓库开发/调试，也可以在 `cli-sdks/python/` 下用可编辑安装（示例）：

```bash
pip install -e .
```

### 前置条件：两种运行模式

SDK 会自动选择底层运行方式：

- **内部 SDK 模式（优先）**：当运行环境中可导入 `autocoder.sdk` 相关模块时，SDK 会直接调用内部 API（通常更快，依赖更少的进程管理）。
- **Subprocess 模式（回退）**：当无法导入内部模块时，SDK 会通过子进程调用 `auto-coder.run` 命令。

你可以用 `AutoCoderClient.check_availability()` 查看当前环境可用性。

> 如果你不是在 AutoCoder 主仓库的同一 Python 环境里运行，通常会走 **Subprocess 模式**，因此需要确保 `auto-coder.run` 在 PATH 中可用。

## 快速开始

### 同步：最简文本查询（默认）

```python
from autocoder_cli_sdk import AutoCoderClient

client = AutoCoderClient()

for line in client.query("创建一个Python函数：计算斐波那契数列"):
    print(line)
```

### 同步：一次拿到完整文本（推荐）

```python
from autocoder_cli_sdk import AutoCoderClient

client = AutoCoderClient()

text = client.quick_query("创建一个Python函数：计算斐波那契数列")
print(text)
```

### 同步：结构化 JSON（Pydantic 模型）

```python
from autocoder_cli_sdk import AutoCoderClient

client = AutoCoderClient()

resp = client.json_query("解释 Python 的生成器（请给出示例）")
if resp.has_errors:
    print("发生错误：", resp.error_messages)
else:
    print(resp.final_result)
```

### 异步：文本查询

```python
import asyncio
from autocoder_cli_sdk import AsyncAutoCoderClient


async def main():
    async with AsyncAutoCoderClient() as client:
        async for line in client.query("创建一个排序函数"):
            print(line)


asyncio.run(main())
```

### 异步：一次拿到完整文本/JSON

```python
import asyncio
from autocoder_cli_sdk import AsyncAutoCoderClient


async def main():
    async with AsyncAutoCoderClient() as client:
        text = await client.quick_query("创建一个 Python 类：BankAccount")
        print(text[:200])

        resp = await client.json_query("解释什么是递归")
        print(resp.final_result[:200])


asyncio.run(main())
```

## 核心概念

### `output_format`：输出格式与 `query()` 的返回类型

`QueryOptions.output_format` / `SDKConfig.default_output_format` 支持：

- **`"text"`（默认）**：`query()` 逐行 `yield str`
- **`"json"`**：`query()` 通常只 `yield` **一个** `QueryResponseModel`
- **`"stream-json"`**：用于事件流场景，`query()` 最终 `yield` 一个 `QueryResponseModel`（其中 `events` 为逐行解析到的事件列表；是否可用取决于底层模式与 `auto-coder.run` 支持情况）

你可以用 `isinstance(item, str)` / `isinstance(item, QueryResponseModel)` 做分支处理。

### `input_format`：输入格式（主要用于 `query_from_file()`）

`QueryOptions.input_format` 支持 `text/json/stream-json`。当前实现中：

- **`text`**：直接把文件内容作为 prompt
- **`json`**：会尝试从 JSON 中提取 prompt（优先级如下）：
  - `{"prompt": "..."}`
  - `{"message": {"content": "..."}}`
  - `{"message": "..."}`
  - 否则回退为原始文件内容
- 其他（含 `stream-json`）：不做处理，原样作为 prompt

### 配置优先级：`QueryOptions` 覆盖 `SDKConfig`

典型用法是：

- 用 `SDKConfig` 设置全局默认值（模型、默认工作目录、默认权限模式、默认输出格式等）
- 用 `QueryOptions` 覆盖单次查询行为（例如本次使用 JSON 输出、临时切换模型、开启 verbose 等）

SDK 内部会把 `QueryOptions` 与 `SDKConfig` 合并，并在执行前进行参数校验（不合法会抛 `ValidationError`）。

### 会话（Session）

会话用于多轮对话，让后续 prompt 能继承上下文。

- **同步**：`with client.session(session_id=None) as session: ...`
  - `session.query(...)` 返回 generator
  - `session.quick_query(...)` / `session.json_query(...)` 返回完整结果
- **异步**：`async with client.session(session_id=None) as session: ...`
  - `session.query(...)` 返回 async generator（需要 `async for`）

会话上下文会自动处理：

- 第一次查询：可选写入 `session_id`（用于恢复）
- 后续查询：自动设置 `continue_session=True`

### 进程控制（abort）

在 Subprocess 模式下，SDK 会启动 `auto-coder.run` 子进程：

- **同步**：`client.abort()` / `client.abort_force()` / `client.is_running()`
- **异步**：`await client.abort()` / `await client.abort_force()` / `client.is_running`

> 重要：同一个客户端实例在 Subprocess 模式下通常一次只能运行一个子进程查询。若你需要并行，建议创建多个客户端实例，或改用内部 SDK 模式（若可用）。

## API 参考（按导出 API）

以下按 `autocoder_cli_sdk/__init__.py` 导出的公共 API 进行说明。

### 1) `AutoCoderClient`（同步客户端）

导入：

```python
from autocoder_cli_sdk import AutoCoderClient
```

#### `AutoCoderClient(config: SDKConfig | None = None)`

- **作用**：创建同步客户端
- **参数**：
  - `config`：全局默认配置；不传则使用 `SDKConfig()` 默认值
- **异常**：
  - 当内部 SDK 不可用、且找不到 `auto-coder.run` 时抛 `AutoCoderError`

#### `query(prompt: str, options: QueryOptions | None = None) -> Generator[str | QueryResponseModel, None, None]`

- **作用**：执行一次查询/生成，返回 generator
- **返回**：
  - `output_format="text"`：逐行 `yield str`
  - `output_format="json"` / `"stream-json"`：通常只 `yield` 一个 `QueryResponseModel`
- **常用写法**：

```python
from autocoder_cli_sdk import AutoCoderClient, QueryOptions, QueryResponseModel

client = AutoCoderClient()

for item in client.query("创建一个Python类", QueryOptions(output_format="json")):
    if isinstance(item, QueryResponseModel):
        print(item.final_result)
```

#### `quick_query(prompt: str, **kwargs) -> str`

- **作用**：便利方法，等价于以文本格式执行 `query()` 并把所有行拼接成一个字符串返回
- **kwargs**：会被用于构造 `QueryOptions(output_format="text", **kwargs)`
- **异常**：参数校验失败会抛 `ValidationError`；底层执行失败可能抛 `ExecutionError` / `AutoCoderError`

#### `json_query(prompt: str, **kwargs) -> QueryResponseModel`

- **作用**：便利方法，等价于以 JSON 格式执行 `query()` 并返回 `QueryResponseModel`
- **kwargs**：会被用于构造 `QueryOptions(output_format="json", **kwargs)`
- **重要**：当底层执行失败时，可能会返回 `has_errors=True` 的 `QueryResponseModel`（也可能抛异常，取决于失败发生阶段）

#### `query_from_file(file_path: str, options: QueryOptions | None = None) -> Generator[str | QueryResponseModel, None, None]`

- **作用**：从文件读取 prompt（支持 `input_format` 处理），然后执行 `query()`
- **参数**：
  - `file_path`：UTF-8 文本文件路径
  - `options`：可设置 `input_format` / `output_format` 等

#### `configure(config_dict: dict[str, str]) -> ConfigResponseModel`

- **作用**：调用 `auto-coder.run config key=value ...` 配置底层 CLI（在内部 SDK 模式下也会走对应配置入口）
- **参数**：
  - `config_dict` 不能为空；为空会返回 `success=False` 的响应模型
- **返回**：`ConfigResponseModel`

#### `session(session_id: str | None = None) -> ContextManager[SessionContext]`

- **作用**：创建会话上下文（多轮对话）
- **用法**：

```python
from autocoder_cli_sdk import AutoCoderClient

client = AutoCoderClient()

with client.session() as session:
    a = session.quick_query("创建一个 User 类")
    b = session.quick_query("为 User 类添加邮箱校验方法")  # 自动 continue
    print(a[:100], b[:100])
```

#### `get_version() -> str`

- **作用**：获取 AutoCoder 版本（内部 SDK 模式下读 `autocoder.version.__version__`；否则执行 `auto-coder.run --version`）

#### `check_availability() -> dict[str, bool]`

返回：

- `sdk_available`：内部 SDK 是否可用
- `subprocess_available`：`auto-coder.run` 是否可执行
- `version_available`：是否能获取到非 `unknown` 的版本

#### `is_running() -> bool` / `abort() -> bool` / `abort_force() -> bool`

- **作用**：查询子进程运行状态，或中止当前子进程
- **备注**：只对 Subprocess 模式（或内部实现使用子进程时）有意义

### 2) `AsyncAutoCoderClient`（异步客户端）

导入：

```python
from autocoder_cli_sdk import AsyncAutoCoderClient
```

#### `AsyncAutoCoderClient(config: SDKConfig | None = None)`

创建异步客户端（需要配合 `async with` 使用，以便初始化/释放线程池等资源）。

#### `async with AsyncAutoCoderClient(...) as client: ...`

- **作用**：初始化异步运行环境

#### `query(prompt: str, options: QueryOptions | None = None) -> AsyncGenerator[str | QueryResponseModel, None]`

- **作用**：执行异步查询，返回 async generator
- **用法**：

```python
from autocoder_cli_sdk import AsyncAutoCoderClient, QueryOptions

async with AsyncAutoCoderClient() as client:
    async for line in client.query("创建一个Python函数", QueryOptions(output_format="text")):
        print(line)
```

#### `quick_query(prompt: str, **kwargs) -> Awaitable[str]`

收集 `query(..., output_format="text")` 的所有行并拼接返回。

#### `json_query(prompt: str, **kwargs) -> Awaitable[QueryResponseModel]`

返回 `QueryResponseModel`。

#### `batch_query(prompts: list[str], options: QueryOptions | None = None, max_concurrency: int = 3) -> list[list[str] | QueryResponseModel]`

- **作用**：批量查询，并发受 `max_concurrency` 控制
- **返回**：
  - 当 `output_format="text"`（默认）时，每个 prompt 对应一个 `list[str]`（按行收集）
  - 当 `output_format="json"` 时，每个 prompt 对应一个 `QueryResponseModel`
- **注意**：
  - 在 **Subprocess 模式** 下，同一客户端实例通常无法同时跑多个子进程查询；若你确实要并发，建议创建多个客户端实例，或将 `max_concurrency=1`。

#### `session(session_id: str | None = None) -> AsyncContextManager[AsyncSessionContext]`

用法：

```python
from autocoder_cli_sdk import AsyncAutoCoderClient

async with AsyncAutoCoderClient() as client:
    async with client.session() as session:
        async for line in session.query("创建一个 User 类"):
            print(line)
```

#### `configure(...) -> Awaitable[ConfigResponseModel]` / `get_version() -> Awaitable[str]`

与同步版本语义一致。

#### `client.is_running: bool` / `await abort()` / `await abort_force()`

异步版本的运行状态与中止操作。

### 3) 配置与选项：`SDKConfig` / `QueryOptions`

导入：

```python
from autocoder_cli_sdk import SDKConfig, QueryOptions
```

#### `SDKConfig`（全局默认配置）

字段（节选）：

- `default_model: str | None`
- `default_max_turns: int`（默认 10000）
- `default_permission_mode: "manual" | "acceptEdits"`
- `default_output_format: "text" | "json" | "stream-json"`
- `verbose: bool`
- `default_cwd: str | None`（若不传，会在初始化时设为当前工作目录）
- `system_prompt_path: str | None`（SDK 会尝试读取该文件内容并填充到 `QueryOptions.system_prompt`）
- `command_path: str`（默认 `"auto-coder.run"`，auto-coder.run 命令路径）
- `python_path: str | None`（Python 解释器路径，设置后命令变为 `[python_path, command_path, ...]`）
- `include_rules: bool`
- `default_allowed_tools: list[str] | None`

方法：

- `build_command_prefix() -> list[str]`：构建命令前缀。若设置了 `python_path`，返回 `[python_path, command_path]`，否则返回 `[command_path]`

#### `QueryOptions`（单次查询选项）

常用字段：

- `model`
- `max_turns`
- `system_prompt`
- `system_prompt_path`
- `output_format` / `input_format`
- `verbose`
- `cwd`（必须存在，否则 `validate()` 会抛 `ValidationError`）
- `session_id` / `continue_session`
- `allowed_tools`
- `permission_mode`
- `include_rules` / `pr` / `is_sub_agent`
- `async_mode` 及其相关字段（`split_mode` / `delimiter` / `min_level` / `max_level` / `workdir` / `from_branch` / `bg_mode` / `task_prefix` / `worktree_name`）

示例：

```python
from autocoder_cli_sdk import AutoCoderClient, SDKConfig, QueryOptions

config = SDKConfig(default_model="gpt-4", verbose=True)
client = AutoCoderClient(config)

opts = QueryOptions(
    output_format="json",
    max_turns=20,
    permission_mode="acceptEdits",
    include_rules=True,
)

resp = client.json_query("创建一个带类型提示的 Python 类", **opts.__dict__)
print(resp.final_result[:200])
```

自定义命令路径示例：

```python
from autocoder_cli_sdk import AutoCoderClient, SDKConfig

# 指定 auto-coder.run 的自定义路径
config = SDKConfig(command_path="/usr/local/bin/auto-coder.run")
client = AutoCoderClient(config)

# 同时指定 Python 解释器路径
config = SDKConfig(
    command_path="/opt/autocoder/auto-coder.run",
    python_path="/usr/bin/python3.11",
)
client = AutoCoderClient(config)
# 此时实际命令为: /usr/bin/python3.11 /opt/autocoder/auto-coder.run ...
```

### 4) Pydantic 响应模型

导入：

```python
from autocoder_cli_sdk import (
    QueryResponseModel,
    StreamEventModel,
    QuerySummaryModel,
    ConfigResponseModel,
)
```

#### `QueryResponseModel`

字段：

- `events: list[StreamEventModel]`
- `summary: QuerySummaryModel`
- `session_id: str | None`
- `execution_time: float | None`

常用属性：

- `final_result: str`：从最后一个 `completion`（或某些 `tool_call`）事件中提取最终结果
- `all_content: str`：拼接所有 `content` 事件的 `content`
- `has_errors: bool`
- `error_messages: list[str]`

#### `StreamEventModel`

- `event_type: str`：常见包括 `start/content/tool_call/completion/error/end`
- `data: StreamEventData`：事件数据（允许 extra 字段）

#### 其他导出但不一定会直接用到的 Pydantic 模型

以下模型同样会从包中导出（见 `autocoder_cli_sdk/__init__.py`），主要用于更细粒度地表达某些事件/响应，当前 SDK 的解析逻辑通常以 `StreamEventModel` 为主：

- `StreamEventData`
- `VersionResponseModel`
- `CompletionEventModel`
- `ContentEventModel`
- `ErrorEventModel`
- `StartEventModel`
- `EndEventModel`

> 注意：当前 `get_version()` 返回的是 `str`，并不会返回 `VersionResponseModel`。

### Dataclass 模型（内部/兼容性用途为主）

导入：

```python
from autocoder_cli_sdk import QueryResult, StreamEvent, ConfigResult, SessionInfo
```

这些 dataclass 目前更偏向“内部表示/历史兼容”，在当前实现中：

- `AutoCoderClient.query()` / `AsyncAutoCoderClient.query()` **不会直接返回 `QueryResult`**
- 文本/JSON 输出分别对应 `str` / `QueryResponseModel`

如果你在二次封装 SDK、或需要在自己的代码里表达“事件/结果”的中间状态，这些模型仍然可用：

- `StreamEvent`：带 `content`/`is_content` 等便捷属性
- `QueryResult`：包含 `success/content/error/events/metadata` 等字段
- `ConfigResult`：配置结果的 dataclass 版本
- `SessionInfo`：会话信息结构

### 诊断工具

导入：

```python
from autocoder_cli_sdk import run_diagnostics, print_diagnostics, get_recommendations
```

- `run_diagnostics(verbose: bool = False) -> dict`
- `print_diagnostics(results: dict) -> None`
- `get_recommendations(results: dict) -> list[str]`

示例：

```python
from autocoder_cli_sdk import run_diagnostics, get_recommendations

results = run_diagnostics(verbose=False)
for rec in get_recommendations(results):
    print("-", rec)
```

> Windows 说明：诊断中对命令路径的探测可能使用 `which`，在部分 Windows 环境中不可用；这不影响 SDK 的核心查询能力。

### 进程管理器（高级）

导入：

```python
from autocoder_cli_sdk import ProcessManager, AsyncProcessManager
```

通常你不需要直接操作它们（客户端已经内置并使用），但在你需要“更底层”的进程生命周期控制时可以使用：

- `ProcessManager`：同步子进程管理（启动、流式读取输出、中止、等待完成）
- `AsyncProcessManager`：异步子进程管理

> 注意：它们主要用于管理 `auto-coder.run` 子进程。在内部 SDK 模式下，可能不会涉及子进程执行。

### 版本信息

导入：

```python
from autocoder_cli_sdk import __version__
```

- `__version__`：SDK 自身版本号（与包发布版本一致）

### 异常类型

导入：

```python
from autocoder_cli_sdk import AutoCoderError, ValidationError, ExecutionError
```

- `AutoCoderError`：SDK 基础异常
- `ValidationError`：参数校验失败（如 `output_format` 非法、`cwd` 不存在等）
- `ExecutionError`：执行失败（包含 `exit_code` 与 `output` 字段，具体填充取决于失败来源）

错误处理示例：

```python
from autocoder_cli_sdk import AutoCoderClient, AutoCoderError, ValidationError, ExecutionError

client = AutoCoderClient()

try:
    text = client.quick_query("创建一个函数")
    print(text[:200])
except ValidationError as e:
    print("参数错误：", e)
except ExecutionError as e:
    print("执行失败：", e, "exit_code=", e.exit_code)
except AutoCoderError as e:
    print("SDK错误：", e)
```

## FAQ

### 1) 为什么 `query()` 不是直接返回字符串？

因为 `query()` 设计为 generator/async generator，便于：

- 实时处理输出（文本逐行）
- 在长任务中途可中止（abort）
- 统一承载 text/json/stream-json 等多种输出格式

若你想直接拿到最终结果，请用 `quick_query()` / `json_query()`。

### 2) JSON 查询失败时为什么没有抛异常？

当底层输出可被解析为事件模型时，SDK 可能会返回一个 `QueryResponseModel`，并在其中包含 `error` 事件（此时 `has_errors=True`）。你应当按 `has_errors`/`error_messages` 判断并处理。

### 3) 并发怎么做？

- Subprocess 模式下，一个客户端实例通常只能跑一个子进程；并发请创建多个客户端实例，或把 `max_concurrency=1`。
- 内部 SDK 模式下通常更适合并发（取决于内部实现）。

