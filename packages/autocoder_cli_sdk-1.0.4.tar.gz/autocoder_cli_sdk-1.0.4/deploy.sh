#!/bin/bash

set -euo pipefail

# 项目名称（pip 包名）
project="autocoder-cli-sdk"

usage() {
  cat <<'USAGE'
Usage: bash deploy.sh [options]

Options:
  -b, --bump <level>     Bump level: major | minor | patch | none (default: patch)
  -v, --version <x.y.z>  Specify exact version (takes precedence over bump)
  -m, --mode <mode>      Mode: release | dev | test (default: release)
      release            Upload to PyPI
      dev                No upload, only build and tag
      test               Upload to TestPyPI
      --no-bump          Alias of --bump none
  -h, --help             Show this help and exit

Environment variables (optional, CLI has higher priority):
  BUMP, VERSION, MODE
USAGE
}

# 版本号变更级别：支持 major / minor / patch / none（默认：patch）
#   BUMP=none     — 不修改版本号，使用当前版本直接构建发布
#   VERSION=x.y.z — 指定具体版本号（优先级高于 BUMP）
BUMP=${BUMP:-"patch"}
VERSION=${VERSION:-""}
MODE=${MODE:-"release"}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -b|--bump)
      if [[ -z "${2:-}" ]]; then
        echo "ERROR: --bump requires a value"
        usage
        exit 1
      fi
      BUMP="${2}"
      shift 2
      ;;
    -v|--version)
      if [[ -z "${2:-}" ]]; then
        echo "ERROR: --version requires a value"
        usage
        exit 1
      fi
      VERSION="${2}"
      shift 2
      ;;
    -m|--mode)
      if [[ -z "${2:-}" ]]; then
        echo "ERROR: --mode requires a value"
        usage
        exit 1
      fi
      MODE="${2}"
      shift 2
      ;;
    --no-bump)
      BUMP="none"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      usage
      exit 1
      ;;
  esac
done

case "${MODE}" in
  release|dev|test)
    ;;
  *)
    echo "ERROR: --mode must be 'release', 'dev' or 'test' (got '${MODE}')"
    usage
    exit 1
    ;;
esac

# 检查是否在正确的目录
if [[ ! -f "pyproject.toml" ]]; then
  echo "ERROR: 请在 cli-sdks/python 目录下运行此脚本"
  exit 1
fi

export BUMP VERSION MODE
echo "Bump level: ${BUMP}, Specified version: ${VERSION:-<auto>}, Mode: ${MODE}"

# 计算并回写新版本到 pyproject.toml 与 autocoder_cli_sdk/__init__.py
version=$(
python - <<'PY'
import os
import re
import sys
from pathlib import Path

root = Path.cwd()
pyproject = root / "pyproject.toml"
init_py = root / "autocoder_cli_sdk" / "__init__.py"

if not pyproject.exists():
    print("ERROR: pyproject.toml not found", file=sys.stderr)
    sys.exit(1)

text = pyproject.read_text(encoding="utf-8")
m = re.search(r'^version\s*=\s*"(\d+)\.(\d+)\.(\d+)"\s*$', text, flags=re.M)
if not m:
    print("ERROR: Cannot find version in pyproject.toml", file=sys.stderr)
    sys.exit(1)

major, minor, patch = map(int, m.groups())
current_version = f"{major}.{minor}.{patch}"

specified_version = os.environ.get("VERSION", "").strip()
bump = os.environ.get("BUMP", "patch").lower()

if specified_version:
    vm = re.match(r'^(\d+)\.(\d+)\.(\d+)$', specified_version)
    if not vm:
        print(f"ERROR: Invalid version format '{specified_version}', expected x.y.z", file=sys.stderr)
        sys.exit(1)
    new_version = specified_version
elif bump == "none":
    new_version = current_version
elif bump == "major":
    major, minor, patch = major + 1, 0, 0
    new_version = f"{major}.{minor}.{patch}"
elif bump == "minor":
    minor, patch = minor + 1, 0
    new_version = f"{major}.{minor}.{patch}"
else:
    patch = patch + 1
    new_version = f"{major}.{minor}.{patch}"

if new_version != current_version:
    new_text = re.sub(
        r'(?m)^version\s*=\s*".*"\s*$',
        f'version = "{new_version}"',
        text,
    )
    pyproject.write_text(new_text, encoding="utf-8")

    if init_py.exists():
        init_text = init_py.read_text(encoding="utf-8")
        init_new = re.sub(
            r"(?m)^__version__\s*=\s*['\"][^'\"]+['\"]\s*$",
            f'__version__ = "{new_version}"',
            init_text,
        )
        if init_new == init_text:
            if not init_text.endswith("\n"):
                init_text += "\n"
            init_new = init_text + f'__version__ = "{new_version}"\n'
        init_py.write_text(init_new, encoding="utf-8")

print(new_version)
PY
)
echo "Version: $version"

# 使用 black（若可用）格式化被修改的 Python 文件
if command -v black >/dev/null 2>&1; then
  black -q autocoder_cli_sdk/__init__.py 2>/dev/null || true
fi

# 将版本号更新的文件加入提交（BUMP=none 且未指定版本时跳过提交）
if [[ "${BUMP}" != "none" ]] || [[ -n "${VERSION}" ]]; then
  git add pyproject.toml autocoder_cli_sdk/__init__.py 2>/dev/null || true
  git commit -m "bump: v${version}" || echo "No changes to commit"
else
  echo "No bump, skip version commit"
fi

# 清理 dist 目录
echo "Clean dist"
rm -rf ./dist

# 卸载当前安装的项目版本
echo "Uninstall ${project}"
pip uninstall -y "${project}" 2>/dev/null || true

# 构建项目（优先使用 uv，否则 python -m build）
if command -v uv >/dev/null 2>&1; then
  echo "Build ${project} ${version} (uv)"
  uv build
else
  echo "Build ${project} ${version}"
  python -m build
fi

# 本地安装为可编辑模式
pip install -e .

# 发布模式下的操作
if [[ "${MODE}" == "release" ]]; then
  git tag -f "v${version}"
  git push
  git push origin "v${version}"
  echo "Upload ${project} ${version} to PyPI"
  twine upload dist/*
elif [[ "${MODE}" == "test" ]]; then
  git tag -f "v${version}"
  echo "Upload ${project} ${version} to TestPyPI"
  twine upload --repository testpypi dist/*
  echo "Tag v${version}"
  echo "TestPyPI: https://test.pypi.org/project/${project}/${version}/"
  echo "Test install: pip install -i https://test.pypi.org/simple/ ${project}==${version}"
else
  echo "Dev mode, no upload"
  git tag -f "v${version}"
  echo "Tag v${version}"
  echo "Install package path: ./dist/${project}-${version}-py3-none-any.whl"
fi
