"""Allow running as: python -m xen"""
from xen.cli import main

main()
