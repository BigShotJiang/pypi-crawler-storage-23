# -*- coding: utf-8 -*-
"""
Contains the package version information
"""

__version__ = "1.1.29"
