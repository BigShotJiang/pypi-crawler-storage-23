import abc


class AtomMapper(metaclass=abc.ABCMeta):
    ...