"""
Shared Event Schema for Antaris Analytics Suite 2.0
Provides unified telemetrics structure across all packages.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from pydantic import BaseModel, Field, ConfigDict


class EventType(str, Enum):
    """Standard event types across all packages."""
    # Memory events
    MEMORY_INGEST = "memory.ingest"
    MEMORY_SEARCH = "memory.search"
    MEMORY_RETRIEVE = "memory.retrieve"
    MEMORY_CONSOLIDATE = "memory.consolidate"
    MEMORY_DECAY = "memory.decay"
    
    # Router events
    ROUTER_CLASSIFY = "router.classify"
    ROUTER_ROUTE = "router.route"
    ROUTER_FALLBACK = "router.fallback"
    ROUTER_ADAPT = "router.adapt"
    
    # Guard events
    GUARD_SCAN = "guard.scan"
    GUARD_ALLOW = "guard.allow"
    GUARD_DENY = "guard.deny"
    GUARD_MODIFY = "guard.modify"
    GUARD_ESCALATE = "guard.escalate"
    
    # Context events
    CONTEXT_BUILD = "context.build"
    CONTEXT_COMPRESS = "context.compress"
    CONTEXT_BUDGET = "context.budget"
    CONTEXT_OPTIMIZE = "context.optimize"
    
    # Pipeline events
    PIPELINE_START = "pipeline.start"
    PIPELINE_COMPLETE = "pipeline.complete"
    PIPELINE_ERROR = "pipeline.error"
    PIPELINE_DRY_RUN = "pipeline.dry_run"


class ConfidenceBasis(str, Enum):
    """Standardized confidence basis across packages."""
    PATTERN_MATCH = "pattern_match"
    ML_CLASSIFIER = "ml_classifier"
    RULE_BASED = "rule_based"
    KEYWORD_DENSITY = "keyword_density"
    BEHAVIORAL_SIGNAL = "behavioral_signal"
    STATISTICAL_MODEL = "statistical_model"
    COMPOSITE = "composite"
    HUMAN_VERIFIED = "human_verified"


class PerformanceMetrics(BaseModel):
    """Performance metrics for telemetrics tracking."""
    latency_ms: Optional[float] = None
    tokens_processed: Optional[int] = None
    cost_usd: Optional[float] = None
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None
    throughput_ops_sec: Optional[float] = None


class AntarisEvent(BaseModel):
    """
    Universal event schema for Antaris Suite 2.0 telemetrics.
    
    This schema enables cross-package intelligence and optimization.
    Every package emits events in this format for unified analysis.
    """
    # Core identification
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    session_id: str
    
    # Event classification
    module: str = Field(..., description="Package name: memory|router|guard|context|pipeline")
    event_type: EventType
    
    # Performance tracking
    performance: Optional[PerformanceMetrics] = None
    
    # Confidence and reasoning
    confidence: Optional[float] = Field(None, ge=0.0, le=1.0)
    basis: Optional[ConfidenceBasis] = None
    evidence: List[str] = Field(default_factory=list)
    
    # Event payload (module-specific data)
    payload: Dict[str, Any] = Field(default_factory=dict)
    
    # Cross-package intelligence
    correlations: List[str] = Field(default_factory=list, description="Related event IDs")
    triggers: List[str] = Field(default_factory=list, description="Events this event triggered")
    
    # Context and tracing
    user_id: Optional[str] = None
    conversation_id: Optional[str] = None
    agent_id: Optional[str] = None
    trace_id: Optional[str] = None
    
    model_config = ConfigDict()


class EventEmitter:
    """
    Base class for emitting standardized events.
    All Antaris packages inherit from this for consistent telemetrics.
    """
    
    def __init__(self, module_name: str, session_id: str):
        self.module_name = module_name
        self.session_id = session_id
        self._event_handlers: List[callable] = []
    
    def add_handler(self, handler: callable) -> None:
        """Add an event handler (telemetrics sink)."""
        self._event_handlers.append(handler)
    
    def emit_event(
        self,
        event_type: EventType,
        confidence: Optional[float] = None,
        basis: Optional[ConfidenceBasis] = None,
        evidence: Optional[List[str]] = None,
        payload: Optional[Dict[str, Any]] = None,
        performance: Optional[PerformanceMetrics] = None,
        correlations: Optional[List[str]] = None,
        **kwargs
    ) -> AntarisEvent:
        """Emit a standardized event with telemetrics."""
        
        event = AntarisEvent(
            session_id=self.session_id,
            module=self.module_name,
            event_type=event_type,
            confidence=confidence,
            basis=basis,
            evidence=evidence or [],
            payload=payload or {},
            performance=performance,
            correlations=correlations or [],
            **kwargs
        )
        
        # Send to all registered handlers
        for handler in self._event_handlers:
            try:
                handler(event)
            except Exception as e:
                # Don't let telemetrics failures break the main flow
                print(f"Telemetrics handler error: {e}")
        
        return event


# Convenience functions for quick event creation
def memory_event(
    session_id: str,
    event_type: EventType,
    **kwargs
) -> AntarisEvent:
    """Quick memory event creation."""
    return AntarisEvent(
        session_id=session_id,
        module="memory",
        event_type=event_type,
        **kwargs
    )


def router_event(
    session_id: str,
    event_type: EventType,
    **kwargs
) -> AntarisEvent:
    """Quick router event creation.""" 
    return AntarisEvent(
        session_id=session_id,
        module="router",
        event_type=event_type,
        **kwargs
    )


def guard_event(
    session_id: str,
    event_type: EventType,
    **kwargs
) -> AntarisEvent:
    """Quick guard event creation."""
    return AntarisEvent(
        session_id=session_id,
        module="guard",
        event_type=event_type,
        **kwargs
    )


def context_event(
    session_id: str,
    event_type: EventType,
    **kwargs
) -> AntarisEvent:
    """Quick context event creation."""
    return AntarisEvent(
        session_id=session_id,
        module="context",
        event_type=event_type,
        **kwargs
    )


# Export key classes and functions
__all__ = [
    "AntarisEvent",
    "EventType", 
    "ConfidenceBasis",
    "PerformanceMetrics",
    "EventEmitter",
    "memory_event",
    "router_event", 
    "guard_event",
    "context_event"
]