"""
Resource management for TurkicNLP.

Handles model/FST discovery, downloading, caching, and registry.
"""
