What is included in the SupOpNumTools package
#############################################

   
