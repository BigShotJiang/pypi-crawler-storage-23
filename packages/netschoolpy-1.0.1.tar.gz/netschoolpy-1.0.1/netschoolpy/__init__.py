"""netschoolpy — асинхронный клиент для «Сетевого города»."""

from .client import NetSchool

__all__ = ["NetSchool"]
