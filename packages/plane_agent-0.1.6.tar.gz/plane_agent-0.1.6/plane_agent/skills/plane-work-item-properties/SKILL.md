---
description: Tools for managing Plane work item properties.
tags: [work-item-properties]
name: plane-work-item-properties
tools:
- list_work_item_properties
- create_work_item_property
- retrieve_work_item_properties
- update_work_item_property
- delete_work_item_property
---
# plane-work-item-properties

Tools for managing Plane work item properties.

## Tools
- list_work_item_properties
- create_work_item_property
- retrieve_work_item_properties
- update_work_item_property
- delete_work_item_property
