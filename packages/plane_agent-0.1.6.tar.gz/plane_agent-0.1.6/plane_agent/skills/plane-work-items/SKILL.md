---
description: Tools for managing Plane work items.
tags: [work-items]
name: plane-work-items
tools:
- list_work_items
- create_work_item
- retrieve_work_item
- retrieve_work_item_by_identifier
- update_work_item
- delete_work_item
- search_work_items
---
# plane-work-items

Tools for managing Plane work items.

## Tools
- list_work_items
- create_work_item
- retrieve_work_item
- retrieve_work_item_by_identifier
- update_work_item
- delete_work_item
- search_work_items
