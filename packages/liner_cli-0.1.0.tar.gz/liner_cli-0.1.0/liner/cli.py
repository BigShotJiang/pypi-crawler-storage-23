"""@title LINER CLI
@notice Command-line line counter with filtering, Git integration, report exports, and watch mode.
@dev This module intentionally keeps all CLI behavior in one place for packaging and script entrypoints.
"""

import argparse
import csv
import json
import os
import subprocess
import sys
import time
from fnmatch import fnmatch
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

APP_NAME = "LINER"
DEFAULT_ENCODINGS = "utf-8,cp1251,latin-1"


def supports_color(stream) -> bool:
    """
    @notice Detect whether ANSI color output should be enabled.
    @param stream Output stream being written to.
    @return True when colors are supported and not disabled by NO_COLOR.
    """
    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(stream, "isatty") and stream.isatty()


def colorize(text: str, code: str, enabled: bool) -> str:
    """
    @notice Wrap text with ANSI style code when colors are enabled.
    @param text Raw text.
    @param code ANSI color/style code.
    @param enabled Toggle for coloring.
    @return Styled or raw text.
    """
    if not enabled:
        return text
    return "\033[{}m{}\033[0m".format(code, text)


def scale_ascii_art(lines: List[str], factor: int = 2) -> List[str]:
    """
    @notice Scale ASCII art horizontally and vertically.
    @param lines Base art lines.
    @param factor Integer scale factor.
    @return Scaled art lines.
    """
    scaled: List[str] = []
    for line in lines:
        grown = "".join(ch * factor for ch in line)
        for _ in range(factor):
            scaled.append(grown)
    return scaled


def rainbow_text(text: str, enabled: bool) -> str:
    """
    @notice Apply rainbow ANSI colors per non-space character.
    @param text Input text.
    @param enabled Toggle for coloring.
    @return Rainbow or raw text.
    """
    if not enabled:
        return text

    colors = ["31", "33", "32", "36", "34", "35"]
    out: List[str] = []
    idx = 0
    for ch in text:
        if ch.isspace():
            out.append(ch)
            continue
        out.append("\033[{}m{}\033[0m".format(colors[idx % len(colors)], ch))
        idx += 1
    return "".join(out)


def banner(enabled: bool) -> str:
    """
    @notice Build the large LINER banner.
    @param enabled Toggle for ANSI colors.
    @return Multiline banner text.
    """
    base_art = [
        "##         ######   ##    ## ######## ########  ",
        "##           ##     ###   ## ##       ##     ## ",
        "##           ##     ####  ## ##       ##     ## ",
        "##           ##     ## ## ## ######   ########  ",
        "##           ##     ##  #### ##       ##   ##   ",
        "##           ##     ##   ### ##       ##    ##  ",
        "########   ######   ##    ## ######## ##     ## ",
    ]
    art = scale_ascii_art(base_art, factor=2)
    palette = ["31", "33", "32", "36", "34", "35"]
    return "\n".join(colorize(line, palette[i % len(palette)], enabled) for i, line in enumerate(art))


def usage_text() -> str:
    """
    @notice Return structured usage text shown by --usage and parser errors.
    @return Human-readable usage guide.
    """
    return """Quick Usage

line [targets ...] [options]

Targets:
  files and/or folders (space-separated)
  if no target is provided, current directory is scanned

Core options:
  --folder PATH            Scan folder recursively
  --ext py,js,ts           Filter by extensions
  --exclude p1,p2,*.min.js Exclude paths by patterns
  --max-depth N            Limit recursion depth
  --hidden                 Include hidden files/folders
  --follow-symlinks        Follow symlinks with cycle protection

Output options:
  --sort lines|name|path   Sort output rows
  --top N                  Keep only top N rows after sorting
  --total-only             Print only totals
  --by-ext                 Show extension summary
  --by-ext-all             Extension summary over full set before --top
  --json                   Save JSON report to ./linerN.json
  --csv                    CSV output to stdout

Git options:
  --gitignore              Respect .gitignore
  --changed MODE           MODE: staged | unstaged | all

Runtime options:
  --encoding E1,E2,E3      Decoding fallback order
  --watch                  Re-run when results change
  --interval SEC           Polling interval for watch mode
  --banner                 Print LINER banner before output
  --usage                  Show this structured usage page

Examples:
  line src tests --ext py --exclude .git,node_modules
  line . --sort lines --top 20 --by-ext
  line . --gitignore --changed unstaged --total-only
  line . --json
"""


def print_usage(stream=None) -> None:
    """
    @notice Print branded usage page to target stream.
    @param stream Optional output stream (defaults to stdout).
    """
    if stream is None:
        stream = sys.stdout
    enabled = supports_color(stream)
    stream.write(banner(enabled) + "\n")
    stream.write("\n" + rainbow_text("LINER: fast line counter for files and folders", enabled) + "\n\n")
    stream.write(usage_text() + "\n")


class LinerArgumentParser(argparse.ArgumentParser):
    """
    @notice Custom ArgumentParser that renders branded help and error screens.
    @dev Keeps UX consistent across --help and invalid commands.
    """
    def print_help(self, file=None) -> None:
        """
        @notice Print branded help screen.
        @param file Output stream.
        """
        if file is None:
            file = sys.stdout
        enabled = supports_color(file)
        file.write(banner(enabled) + "\n")
        file.write("\n" + rainbow_text("LINER: fast line counter for files and folders", enabled) + "\n\n")
        super().print_help(file)

    def error(self, message: str) -> None:
        """
        @notice Print branded parse error screen and exit.
        @param message Parser error message.
        """
        enabled = supports_color(sys.stderr)
        sys.stderr.write(banner(enabled) + "\n")
        sys.stderr.write("\n" + rainbow_text("LINER: invalid command usage", enabled) + "\n")
        sys.stderr.write(colorize("Error: {}\n\n".format(message), "31", enabled))
        sys.stderr.write(usage_text() + "\n")
        self.exit(2)


def parse_csv_arg(value: Optional[str]) -> List[str]:
    """
    @notice Parse comma-separated CLI values into a cleaned list.
    @param value Comma-separated string.
    @return List of trimmed tokens.
    """
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def normalize_exts(ext_arg: Optional[str]) -> Optional[Set[str]]:
    """
    @notice Normalize extension filter values to lowercase .ext form.
    @param ext_arg Comma-separated extension list.
    @return Set of normalized extensions or None.
    """
    raw = parse_csv_arg(ext_arg)
    if not raw:
        return None

    exts: Set[str] = set()
    for item in raw:
        ext = item.lower()
        if not ext.startswith("."):
            ext = "." + ext
        exts.add(ext)
    return exts


def parse_encodings(value: Optional[str]) -> List[str]:
    """
    @notice Parse encoding fallback chain.
    @param value Optional comma-separated encodings.
    @return Encoding list with defaults when omitted.
    """
    encodings = parse_csv_arg(value)
    if not encodings:
        return ["utf-8", "cp1251", "latin-1"]
    return encodings


def is_hidden_relative(rel_path: Path) -> bool:
    """
    @notice Check whether relative path contains hidden segment.
    @param rel_path Relative path to inspect.
    @return True when any segment starts with dot.
    """
    for part in rel_path.parts:
        if part.startswith(".") and part not in (".", ".."):
            return True
    return False


def should_exclude(path_obj: Path, rel_path: Path, exclude_patterns: List[str]) -> bool:
    """
    @notice Match path against exclude glob patterns.
    @param path_obj Full candidate path.
    @param rel_path Path relative to scan root.
    @param exclude_patterns Glob patterns.
    @return True when candidate must be skipped.
    """
    if not exclude_patterns:
        return False

    rel = rel_path.as_posix()
    parts = rel_path.parts

    for pattern in exclude_patterns:
        if fnmatch(path_obj.name, pattern):
            return True
        if fnmatch(rel, pattern):
            return True
        for part in parts:
            if fnmatch(part, pattern):
                return True
    return False


def walk_directory(
    root: Path,
    max_depth: Optional[int],
    include_hidden: bool,
    exclude_patterns: List[str],
    follow_symlinks: bool,
) -> List[Path]:
    """
    @notice Recursively collect files from directory with filters.
    @param root Root scan path.
    @param max_depth Optional recursion limit.
    @param include_hidden Include hidden entries.
    @param exclude_patterns Exclusion globs.
    @param follow_symlinks Follow symlinked directories.
    @return Unique list of file paths.
    """
    files: List[Path] = []
    visited_dirs: Set[Tuple[int, int]] = set()

    def _walk(current: Path, depth: int) -> None:
        """
        @notice Internal helper.
        """
        if follow_symlinks:
            try:
                stat_obj = current.stat()
            except OSError:
                return
            key = (stat_obj.st_dev, stat_obj.st_ino)
            if key in visited_dirs:
                return
            visited_dirs.add(key)

        try:
            entries = list(current.iterdir())
        except OSError:
            return

        for entry in entries:
            rel = entry.relative_to(root)

            if not include_hidden and is_hidden_relative(rel):
                continue
            if should_exclude(entry, rel, exclude_patterns):
                continue

            is_symlink = entry.is_symlink()
            if is_symlink and not follow_symlinks:
                continue

            try:
                is_dir = entry.is_dir()
            except OSError:
                continue

            if is_dir:
                if max_depth is None or depth < max_depth:
                    _walk(entry, depth + 1)
            else:
                files.append(entry.resolve())

    _walk(root, 0)
    return files


def file_matches_ext(path_obj: Path, exts: Optional[Set[str]]) -> bool:
    """
    @notice Check extension filter match.
    @param path_obj Candidate file.
    @param exts Allowed extensions.
    @return True when file should be included.
    """
    return exts is None or path_obj.suffix.lower() in exts


def run_git(repo_root: Path, args: List[str]) -> Tuple[int, str]:
    """
    @notice Execute git command in repository root.
    @param repo_root Repository root path.
    @param args Git argument list.
    @return Tuple of exit code and stdout text.
    """
    result = subprocess.run(
        ["git", "-C", str(repo_root)] + args,
        capture_output=True,
        text=True,
    )
    return result.returncode, result.stdout.strip()


def find_repo_root(start: Path) -> Optional[Path]:
    """
    @notice Resolve git top-level directory for given path.
    @param start Path inside repo.
    @return Repository root or None if not a git repo.
    """
    result = subprocess.run(
        ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    return Path(result.stdout.strip()).resolve()


def get_changed_paths(repo_root: Path, mode: str) -> Set[Path]:
    """
    @notice Collect changed file paths according to mode.
    @param repo_root Repository root.
    @param mode One of staged|unstaged|all.
    @return Set of absolute changed file paths.
    """
    changed_rel: Set[str] = set()

    if mode in ("staged", "all"):
        _, out = run_git(repo_root, ["diff", "--name-only", "--cached", "--diff-filter=ACMR"])
        changed_rel.update([line for line in out.splitlines() if line])

    if mode in ("unstaged", "all"):
        _, out = run_git(repo_root, ["diff", "--name-only", "--diff-filter=ACMR"])
        changed_rel.update([line for line in out.splitlines() if line])

        _, out_untracked = run_git(repo_root, ["ls-files", "--others", "--exclude-standard"])
        changed_rel.update([line for line in out_untracked.splitlines() if line])

    result: Set[Path] = set()
    for rel in changed_rel:
        path_obj = (repo_root / rel).resolve()
        if path_obj.exists() and path_obj.is_file():
            result.add(path_obj)
    return result


def apply_gitignore_filter(files: List[Path], repo_root: Path) -> List[Path]:
    """
    @notice Remove files ignored by .gitignore rules.
    @param files Candidate files.
    @param repo_root Repository root.
    @return Filtered file list.
    """
    rel_map: Dict[str, Path] = {}
    keep_outside_repo: List[Path] = []

    for path_obj in files:
        try:
            rel = path_obj.resolve().relative_to(repo_root).as_posix()
            rel_map[rel] = path_obj
        except ValueError:
            keep_outside_repo.append(path_obj)

    if not rel_map:
        return sorted(set(files))

    stdin_data = "\n".join(sorted(rel_map.keys())) + "\n"
    result = subprocess.run(
        ["git", "-C", str(repo_root), "check-ignore", "--stdin"],
        input=stdin_data,
        capture_output=True,
        text=True,
    )

    ignored_rel = set(line.strip() for line in result.stdout.splitlines() if line.strip())
    filtered = [rel_map[rel] for rel in rel_map if rel not in ignored_rel]
    filtered.extend(keep_outside_repo)
    return sorted(set(filtered))


def collect_candidates(
    input_paths: List[Path],
    max_depth: Optional[int],
    include_hidden: bool,
    exclude_patterns: List[str],
    follow_symlinks: bool,
) -> List[Path]:
    """
    @notice Expand input targets into concrete file list.
    @param input_paths User-supplied files/folders.
    @param max_depth Optional recursion depth.
    @param include_hidden Include hidden entries.
    @param exclude_patterns Exclusion globs.
    @param follow_symlinks Follow symlinked dirs.
    @return Unique absolute file list.
    """
    files: List[Path] = []

    for path_obj in input_paths:
        expanded = path_obj.expanduser()
        if not expanded.is_absolute():
            expanded = (Path.cwd() / expanded).resolve()
        else:
            expanded = expanded.resolve()

        if not expanded.exists():
            print("Not found: {}".format(expanded), file=sys.stderr)
            continue

        if expanded.is_file():
            rel = Path(expanded.name)
            if not include_hidden and is_hidden_relative(rel):
                continue
            if should_exclude(expanded, rel, exclude_patterns):
                continue
            files.append(expanded)
            continue

        if expanded.is_dir():
            files.extend(
                walk_directory(
                    root=expanded,
                    max_depth=max_depth,
                    include_hidden=include_hidden,
                    exclude_patterns=exclude_patterns,
                    follow_symlinks=follow_symlinks,
                )
            )

    return sorted(set(files))


def count_lines_with_fallback(path_obj: Path, encodings: List[str]) -> Tuple[int, str]:
    """
    @notice Count lines trying multiple encodings in order.
    @param path_obj File to read.
    @param encodings Preferred encoding chain.
    @return Tuple of line count and encoding actually used.
    """
    for enc in encodings:
        try:
            with path_obj.open("r", encoding=enc, errors="strict") as file_obj:
                return sum(1 for _ in file_obj), enc
        except (UnicodeDecodeError, LookupError):
            continue

    fallback = encodings[0] if encodings else "utf-8"
    with path_obj.open("r", encoding=fallback, errors="ignore") as file_obj:
        return sum(1 for _ in file_obj), fallback + "(ignore)"


def extension_key(path_obj: Path) -> str:
    """
    @notice Build canonical extension key for report grouping.
    @param path_obj File path.
    @return Lowercase extension or [no_ext].
    """
    return path_obj.suffix.lower() if path_obj.suffix else "[no_ext]"


def sort_records(records: List[Dict[str, object]], sort_key: str) -> List[Dict[str, object]]:
    """
    @notice Sort file records by selected field.
    @param records Report rows.
    @param sort_key lines|name|path.
    @return Sorted rows.
    """
    if sort_key == "lines":
        return sorted(records, key=lambda row: int(row["lines"]), reverse=True)
    if sort_key == "name":
        return sorted(records, key=lambda row: str(Path(str(row["path"])).name).lower())
    return sorted(records, key=lambda row: str(row["path"]).lower())


def aggregate_by_ext(records: List[Dict[str, object]]) -> List[Dict[str, object]]:
    """
    @notice Aggregate records by extension.
    @param records File rows.
    @return List of extension summary rows.
    """
    by_ext: Dict[str, Dict[str, int]] = {}
    for item in records:
        ext = str(item["extension"])
        by_ext.setdefault(ext, {"files": 0, "lines": 0})
        by_ext[ext]["files"] += 1
        by_ext[ext]["lines"] += int(item["lines"])

    return [
        {
            "extension": ext,
            "files": data["files"],
            "lines": data["lines"],
        }
        for ext, data in sorted(by_ext.items(), key=lambda pair: pair[0])
    ]


def build_report(args: argparse.Namespace) -> Dict[str, object]:
    """
    @notice Build full report payload from parsed arguments.
    @param args Parsed CLI arguments.
    @return Dictionary with records, totals, summaries and signature.
    """
    inputs: List[Path] = []
    if args.folder:
        inputs.append(Path(args.folder))
    for target in args.targets:
        inputs.append(Path(target))
    if not inputs:
        inputs = [Path.cwd()]

    exts = normalize_exts(args.ext)
    exclude_patterns = parse_csv_arg(args.exclude)
    encodings = parse_encodings(args.encoding)

    candidates = collect_candidates(
        input_paths=inputs,
        max_depth=args.max_depth,
        include_hidden=args.hidden,
        exclude_patterns=exclude_patterns,
        follow_symlinks=args.follow_symlinks,
    )

    candidates = [p for p in candidates if file_matches_ext(p, exts)]

    repo_root = find_repo_root(Path.cwd())

    if args.gitignore:
        if repo_root is None:
            print("Warning: --gitignore requested but current path is not inside a git repository.", file=sys.stderr)
        else:
            candidates = apply_gitignore_filter(candidates, repo_root)

    if args.changed:
        if repo_root is None:
            raise SystemExit("Error: --changed requires running inside a git repository.")
        changed_set = get_changed_paths(repo_root, args.changed)
        candidates = [p for p in candidates if p in changed_set]

    errors: List[str] = []
    all_records: List[Dict[str, object]] = []

    for file_path in candidates:
        try:
            lines, used_encoding = count_lines_with_fallback(file_path, encodings)
        except Exception as exc:
            errors.append("{} ({})".format(file_path, exc))
            continue

        all_records.append(
            {
                "path": str(file_path),
                "lines": lines,
                "encoding": used_encoding,
                "extension": extension_key(file_path),
            }
        )

    all_records = sort_records(all_records, args.sort)
    all_by_ext = aggregate_by_ext(all_records)

    selected_records = all_records
    if args.top is not None:
        selected_records = all_records[: args.top]

    selected_by_ext = aggregate_by_ext(selected_records)

    totals = {
        "files": len(selected_records),
        "lines": sum(int(item["lines"]) for item in selected_records),
    }

    signature = tuple((row["path"], row["lines"]) for row in selected_records)

    return {
        "records": selected_records,
        "all_records": all_records,
        "errors": errors,
        "totals": totals,
        "by_ext": all_by_ext if args.by_ext_all else selected_by_ext,
        "signature": signature,
    }


def print_text(report: Dict[str, object], args: argparse.Namespace) -> None:
    """
    @notice Render report as human-readable terminal text.
    @param report Computed report.
    @param args Parsed CLI arguments.
    """
    records = report["records"]
    totals = report["totals"]

    if report["errors"]:
        for err in report["errors"]:
            print("Read error: {}".format(err), file=sys.stderr)

    if totals["files"] == 0:
        print("No matching files found.")
        return

    if not args.total_only:
        print("Lines      Path")
        print("-" * 72)
        for row in records:
            print("{:>8}   {}".format(row["lines"], row["path"]))

    print("\nSummary")
    print("-" * 72)
    print("Total files : {}".format(totals["files"]))
    print("Total lines : {}".format(totals["lines"]))

    if args.by_ext:
        print("\nBy Extension")
        print("-" * 72)
        for row in report["by_ext"]:
            print("{:>10}   files: {:>6}   lines: {:>8}".format(row["extension"], row["files"], row["lines"]))


def json_payload(report: Dict[str, object], args: argparse.Namespace) -> Dict[str, object]:
    """
    @notice Build JSON payload object from report.
    @param report Computed report.
    @param args Parsed CLI arguments.
    @return JSON-serializable dict.
    """
    payload = {
        "totals": report["totals"],
        "files": [] if args.total_only else report["records"],
        "errors": report["errors"],
    }
    if args.by_ext:
        payload["by_ext"] = report["by_ext"]
    return payload


def next_json_path(base_dir: Path) -> Path:
    """
    @notice Allocate next available linerN.json filename.
    @param base_dir Output directory.
    @return Non-existing JSON path.
    """
    idx = 1
    while True:
        candidate = base_dir / "liner{}.json".format(idx)
        if not candidate.exists():
            return candidate
        idx += 1


def write_json_report(report: Dict[str, object], args: argparse.Namespace) -> Path:
    """
    @notice Write JSON payload to current directory file.
    @param report Computed report.
    @param args Parsed CLI arguments.
    @return Written JSON path.
    """
    out_path = next_json_path(Path.cwd())
    payload = json_payload(report, args)
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return out_path


def print_csv(report: Dict[str, object], args: argparse.Namespace) -> None:
    """
    @notice Render report as CSV to stdout.
    @param report Computed report.
    @param args Parsed CLI arguments.
    """
    writer = csv.writer(sys.stdout)
    writer.writerow(["type", "path", "extension", "lines", "file_count", "encoding"])

    if not args.total_only:
        for row in report["records"]:
            writer.writerow(["file", row["path"], row["extension"], row["lines"], "", row["encoding"]])

    if args.by_ext:
        for row in report["by_ext"]:
            writer.writerow(["ext", "", row["extension"], row["lines"], row["files"], ""])

    writer.writerow(["total", "", "", report["totals"]["lines"], report["totals"]["files"], ""])


def render_report(report: Dict[str, object], args: argparse.Namespace) -> None:
    """
    @notice Dispatch output renderer by selected format.
    @param report Computed report.
    @param args Parsed CLI arguments.
    """
    if args.json:
        out_path = write_json_report(report, args)
        print("JSON report saved: {}".format(out_path))
    elif args.csv:
        print_csv(report, args)
    else:
        print_text(report, args)


def build_parser() -> argparse.ArgumentParser:
    """
    @notice Construct CLI parser and argument groups.
    @return Configured parser instance.
    """
    description = "Count lines in files and folders with filtering, Git, and structured output."
    epilog = "Run `line --usage` for the full structured usage page."
    parser = LinerArgumentParser(
        prog="line",
        description=description,
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument("targets", nargs="*", help="Files or folders to scan.")

    scan_group = parser.add_argument_group("Scan")
    scan_group.add_argument("--folder", help="Folder to scan recursively.")
    scan_group.add_argument("--ext", help="Comma-separated extensions, e.g. py,js,ts")
    scan_group.add_argument("--exclude", help="Comma-separated exclude patterns.")
    scan_group.add_argument("--max-depth", type=int, default=None, help="Maximum recursion depth (0 = root files only).")
    scan_group.add_argument("--hidden", action="store_true", help="Include hidden files and folders.")
    scan_group.add_argument("--follow-symlinks", action="store_true", help="Follow symlinks with cycle protection.")

    output_group = parser.add_argument_group("Output")
    output_group.add_argument("--sort", choices=["lines", "name", "path"], default="path", help="Sort output records.")
    output_group.add_argument("--top", type=int, default=None, help="Show only top N records after sorting.")
    output_group.add_argument("--total-only", action="store_true", help="Show totals only.")
    output_group.add_argument("--by-ext", action="store_true", help="Show summary by extension.")
    output_group.add_argument("--by-ext-all", action="store_true", help="Compute extension summary before --top truncation.")
    output_group.add_argument("--json", action="store_true", help="Save JSON output to ./linerN.json")
    output_group.add_argument("--csv", action="store_true", help="Output CSV to stdout.")

    git_group = parser.add_argument_group("Git")
    git_group.add_argument("--gitignore", action="store_true", help="Respect .gitignore rules when inside a git repo.")
    git_group.add_argument("--changed", choices=["staged", "unstaged", "all"], default=None, help="Count only changed files.")

    runtime_group = parser.add_argument_group("Runtime")
    runtime_group.add_argument("--encoding", default=DEFAULT_ENCODINGS, help="Comma-separated encoding fallback list.")
    runtime_group.add_argument("--watch", action="store_true", help="Watch for changes and re-run when results change.")
    runtime_group.add_argument("--interval", type=float, default=1.0, help="Watch polling interval in seconds.")
    runtime_group.add_argument("--banner", action="store_true", help="Print colored LINER banner and continue.")
    runtime_group.add_argument("--usage", action="store_true", help="Show the structured usage page.")

    return parser


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """
    @notice Parse and validate command-line arguments.
    @param argv Optional explicit argv list.
    @return Validated argparse namespace.
    """
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.json and args.csv:
        parser.error("Use only one output format: --json or --csv.")
    if args.max_depth is not None and args.max_depth < 0:
        parser.error("--max-depth must be >= 0.")
    if args.top is not None and args.top < 0:
        parser.error("--top must be >= 0.")
    if args.interval <= 0:
        parser.error("--interval must be > 0.")

    return args


def run_once(args: argparse.Namespace) -> Tuple[Dict[str, object], int]:
    """
    @notice Execute one report cycle and return exit code.
    @param args Parsed CLI arguments.
    @return Tuple of report and process exit code.
    """
    report = build_report(args)
    render_report(report, args)
    return report, 0 if report["totals"]["files"] else 1


def run_watch(args: argparse.Namespace) -> int:
    """
    @notice Run watch loop and print on signature changes.
    @param args Parsed CLI arguments.
    @return Process exit code.
    """
    print("Watching for changes... Press Ctrl+C to stop.", file=sys.stderr)
    last_signature: Optional[Tuple[Tuple[object, object], ...]] = None

    try:
        while True:
            report = build_report(args)
            signature = report["signature"]
            if signature != last_signature:
                if last_signature is not None:
                    print("\n=== Updated: {} ===".format(time.strftime("%Y-%m-%d %H:%M:%S")))
                render_report(report, args)
                last_signature = signature
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nStopped.", file=sys.stderr)
        return 0


def main(argv: Optional[List[str]] = None) -> int:
    """
    @notice Primary CLI entrypoint logic.
    @param argv Optional explicit argv list.
    @return Process exit code.
    """
    args = parse_args(argv)

    if args.usage:
        print_usage()
        return 0

    if args.banner:
        print(banner(supports_color(sys.stdout)))

    if args.watch:
        return run_watch(args)

    _, code = run_once(args)
    return code


def main_entry() -> None:
    """
    @notice Console-script wrapper for setup entrypoint.
    @dev Raises SystemExit with main() code.
    """
    raise SystemExit(main())
