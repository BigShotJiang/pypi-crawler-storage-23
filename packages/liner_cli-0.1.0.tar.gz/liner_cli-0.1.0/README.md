# LINER

LINER is a fast, Git-aware command-line line counter for files and folders.

## Features

- recursive folder scanning
- extension and glob filtering
- hidden files toggle
- symlink traversal with loop protection
- Git-aware modes (`--gitignore`, `--changed`)
- structured outputs (`--csv`, `--json`)
- watch mode for iterative workflows
- branded help/usage/error screens

## License

This project is licensed under the **MIT License**.
See [LICENSE](LICENSE).

## Installation

## Option A: Local launcher (simple)

```bash
cp ~/Desktop/code_util_py/line.py ~/.local/bin/line
chmod +x ~/.local/bin/line
```

Then ensure `~/.local/bin` is in `PATH` (see OS-specific section below).

## Option B: Install as Python package

```bash
cd ~/Desktop/code_util_py
python3 -m pip install .
```

## Option C: Install globally as CLI via pipx (recommended for users)

```bash
pipx install liner-cli
```

`pipx` installs CLI tools in isolated environments and exposes commands in `PATH`.

## PATH Setup by OS

## macOS (zsh)

1. Add local bin and user script dir:

```bash
echo 'export PATH="$HOME/.local/bin:$HOME/Library/Python/3.9/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

2. If using `pipx`:

```bash
pipx ensurepath
```

3. Verify:

```bash
which line
line --help
```

## Linux (bash/zsh)

1. Add local bin and user script dir:

```bash
echo 'export PATH="$HOME/.local/bin:$HOME/.local/share/pipx/venvs:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

If you use zsh, write to `~/.zshrc` instead.

2. If using `pipx`:

```bash
pipx ensurepath
```

3. Verify:

```bash
which line
line --help
```

## Windows (PowerShell)

1. Typical user script directories:
- `%APPDATA%\Python\Python39\Scripts`
- `%USERPROFILE%\.local\bin` (if you use that layout)
- `%USERPROFILE%\.local\pipx\bin` (for pipx)

2. Add for current user:

```powershell
[Environment]::SetEnvironmentVariable(
  "Path",
  $env:Path + ";$env:APPDATA\\Python\\Python39\\Scripts;$env:USERPROFILE\\.local\\pipx\\bin",
  "User"
)
```

3. Restart terminal and verify:

```powershell
where line
line --help
```

## Quick Start

```bash
line --usage
line src tests --ext py,js --exclude node_modules,.git
line . --sort lines --top 20 --by-ext
line . --gitignore --changed unstaged --total-only
line . --json
```

## Output Modes

## Text

```bash
line src --ext py --sort lines --top 10
```

## CSV (stdout)

```bash
line src --ext py --csv
```

## JSON (file output)

```bash
line src --ext py --json
```

When `--json` is used, LINER writes a file in current working directory:
- `./liner1.json`
- `./liner2.json`
- ...

This avoids overwriting previous reports.

## Help and Usage UX

- `line --help`: full parser help + LINER banner
- `line --usage`: structured usage screen + LINER banner
- invalid args (for example `line -folder .`): branded error + structured usage

## Is publishing to community really that simple?

Short answer: **technically yes, operationally there are a few important steps**.

Minimal publication flow:

1. Prepare metadata (`pyproject.toml`, version, license, README, classifiers).
2. Build distributions.
3. Validate distributions.
4. Upload to TestPyPI.
5. Test installation from TestPyPI.
6. Upload to PyPI.
7. Create release notes/tag in GitHub.

## Publish to PyPI (recommended flow)

## 1. Build

```bash
cd ~/Desktop/code_util_py
python3 -m pip install -U build twine
python3 -m build
```

## 2. Validate artifacts

```bash
python3 -m twine check dist/*
```

## 3. Upload to TestPyPI first

```bash
python3 -m twine upload --repository testpypi dist/*
```

## 4. Install test package from TestPyPI

```bash
python3 -m pip install -i https://test.pypi.org/simple/ liner-cli
line --help
```

## 5. Upload to PyPI

```bash
python3 -m twine upload dist/*
```

## 6. Recommend install method for users

```bash
pipx install liner-cli
```

## Important notes

- PyPI package name must be unique.
- Use API tokens for Twine auth (not password).
- Keep semver-style versions and increment every release.
- Add CI for tests/build before uploading.

## Command Reference

Detailed options and examples:
- [docs/COMMANDS.md](docs/COMMANDS.md)

## Development

```bash
cd ~/Desktop/code_util_py
python3 -m venv .venv
.venv/bin/pip install -U pip pytest
.venv/bin/pip install -e .
.venv/bin/pytest -q
```

## Compatibility

- Python `>=3.9`
- macOS and Linux tested
- Windows supported with correct PATH setup
