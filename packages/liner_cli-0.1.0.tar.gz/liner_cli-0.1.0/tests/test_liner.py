import json
import subprocess
from pathlib import Path

import pytest

from liner import cli


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_ext_exclude_and_max_depth(tmp_path, monkeypatch):
    write(tmp_path / "a.py", "1\n2\n")
    write(tmp_path / "b.js", "1\n")
    write(tmp_path / "node_modules" / "skip.py", "1\n")
    write(tmp_path / "nested" / "inner.py", "1\n")

    monkeypatch.chdir(tmp_path)
    report = cli.build_report(
        cli.parse_args([
            ".",
            "--ext",
            "py",
            "--exclude",
            "node_modules",
            "--max-depth",
            "0",
        ])
    )

    paths = [Path(r["path"]).name for r in report["records"]]
    assert paths == ["a.py"]


def test_hidden_flag(tmp_path, monkeypatch):
    write(tmp_path / ".env", "k=v\n")
    write(tmp_path / "normal.txt", "x\n")

    monkeypatch.chdir(tmp_path)

    without_hidden = cli.build_report(cli.parse_args(["."]))
    with_hidden = cli.build_report(cli.parse_args([".", "--hidden"]))

    names_without = {Path(r["path"]).name for r in without_hidden["records"]}
    names_with = {Path(r["path"]).name for r in with_hidden["records"]}

    assert ".env" not in names_without
    assert ".env" in names_with


def test_json_output_writes_file(tmp_path, monkeypatch, capsys):
    write(tmp_path / "one.txt", "a\n")
    monkeypatch.chdir(tmp_path)

    args = cli.parse_args([".", "--json"])
    report, _ = cli.run_once(args)
    out = capsys.readouterr().out

    assert "JSON report saved:" in out
    json_files = sorted(tmp_path.glob("liner*.json"))
    assert len(json_files) == 1

    payload = json.loads(json_files[0].read_text(encoding="utf-8"))
    assert payload["totals"]["files"] == report["totals"]["files"]
    assert payload["totals"]["lines"] == report["totals"]["lines"]


def test_csv_output(tmp_path, monkeypatch, capsys):
    write(tmp_path / "one.txt", "a\n")
    monkeypatch.chdir(tmp_path)

    args = cli.parse_args([".", "--csv"])
    cli.run_once(args)
    out = capsys.readouterr().out

    assert "type,path,extension,lines,file_count,encoding" in out
    assert "total" in out


def test_by_ext_all_with_top(tmp_path, monkeypatch):
    write(tmp_path / "a.py", "1\n2\n3\n")
    write(tmp_path / "b.js", "1\n")
    monkeypatch.chdir(tmp_path)

    top_only = cli.build_report(cli.parse_args([".", "--sort", "lines", "--top", "1", "--by-ext"]))
    top_all = cli.build_report(
        cli.parse_args([".", "--sort", "lines", "--top", "1", "--by-ext", "--by-ext-all"])
    )

    assert len(top_only["by_ext"]) == 1
    assert len(top_all["by_ext"]) == 2


def test_changed_unstaged_in_git_repo(tmp_path, monkeypatch):
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    write(tmp_path / "tracked.txt", "one\n")
    subprocess.run(["git", "add", "tracked.txt"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "-c", "user.name=Test", "-c", "user.email=test@example.com", "commit", "-m", "init"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )

    write(tmp_path / "tracked.txt", "one\ntwo\n")
    write(tmp_path / "new.txt", "x\n")

    monkeypatch.chdir(tmp_path)
    report = cli.build_report(cli.parse_args([".", "--changed", "unstaged"]))
    names = {Path(row["path"]).name for row in report["records"]}

    assert "tracked.txt" in names
    assert "new.txt" in names


def test_watch_smoke(monkeypatch):
    calls = {"count": 0}

    def fake_build_report(_args):
        calls["count"] += 1
        return {
            "records": [{"path": "a", "lines": 1, "encoding": "utf-8", "extension": ".txt"}],
            "all_records": [{"path": "a", "lines": 1, "encoding": "utf-8", "extension": ".txt"}],
            "errors": [],
            "totals": {"files": 1, "lines": 1},
            "by_ext": [{"extension": ".txt", "files": 1, "lines": 1}],
            "signature": (("a", 1),),
        }

    def fake_sleep(_):
        raise KeyboardInterrupt

    monkeypatch.setattr(cli, "build_report", fake_build_report)
    monkeypatch.setattr(cli.time, "sleep", fake_sleep)

    args = cli.parse_args([".", "--watch"])
    code = cli.run_watch(args)

    assert code == 0
    assert calls["count"] >= 1


def test_usage_page(capsys):
    code = cli.main(["--usage"])
    out = capsys.readouterr().out

    assert code == 0
    assert "LINER" in out
    assert "Quick Usage" in out


def test_invalid_argument_uses_custom_usage(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main(["-folder", "."])

    err = capsys.readouterr().err
    assert exc.value.code == 2
    assert "LINER" in err
    assert "Quick Usage" in err
    assert "unrecognized arguments" in err
