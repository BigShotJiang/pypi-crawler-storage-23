import argparse
from typing import Any

from ..common.config import load_config_file as load_config_file
from ..common.exceptions import ConfigurationError as ConfigurationError
from ..common.exceptions import ScanError as ScanError
from .scanner import ValiqorScanner as ValiqorScanner

def run_scan(args: argparse.Namespace, config: dict[str, Any]) -> int: ...
def cmd_scan(args: argparse.Namespace) -> int: ...
def add_scanner_commands(subparsers) -> None: ...
