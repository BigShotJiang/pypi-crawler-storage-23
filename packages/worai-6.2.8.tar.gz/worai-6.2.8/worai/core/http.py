"""Shared HTTP defaults and helpers."""

from __future__ import annotations

from worai import __version__

DEFAULT_CHROME_VERSION = "145.0.7632.76"


def get_project_version() -> str:
    return __version__ or "0.0.0"


def build_default_user_agent() -> str:
    version_value = get_project_version()
    return (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        f"Chrome/{DEFAULT_CHROME_VERSION} Safari/537.36 "
        f"WLBot/worai-{version_value} (contact: support@wordlift.io)"
    )


DEFAULT_USER_AGENT = build_default_user_agent()
