"""Sonic — Multi-currency settlement engine with cryptographic receipt attestation.

Install levels::

    pip install sonic-sdk              # Client only (httpx + pydantic)
    pip install sonic-sdk[engine]      # + core engine, receipt builder, finality
    pip install sonic-sdk[server]      # + FastAPI server, DB, Redis

Client usage::

    from sonic.client import SonicClient, AsyncSonicClient

    sonic = SonicClient(base_url="https://api.sonic.tower.dev", api_key="sonic_live_...")
    payment = sonic.create_payment(amount="100.00", currency="USD", idempotency_key="inv-123")

Engine usage (requires ``sonic-sdk[engine]``)::

    from sonic import Transaction, TxState
    tx = Transaction(tx_id="tx-001", merchant_id="m-acme")
    event = tx.advance(TxState.RECEIVABLE_DETECTED, amount=100.00, currency="USD")

Division: Tower Technologies, Brooks Holdings Inc.
"""

from __future__ import annotations

from sonic._version import __version__

# Client — always available (base install)
from sonic.client import (
    AsyncSonicClient,
    SonicClient,
    SonicError,
    SonicNotFound,
    SonicConflict,
    SonicAuthError,
)

__all__ = [
    "__version__",
    # Client (always available)
    "SonicClient",
    "AsyncSonicClient",
    "SonicError",
    "SonicNotFound",
    "SonicConflict",
    "SonicAuthError",
]

# Engine — available with sonic-sdk[engine]
try:
    from sonic.core.engine import Transaction, TxState, TxEvent, InvalidTransition, TRANSITIONS
    from sonic.core.receipt_builder import SonicReceipt, ReceiptChain, canonical_hash
    from sonic.core.finality_gate import (
        FinalityGate,
        FinalityPolicy,
        FinalityStatus,
        DEFAULT_POLICIES,
    )
    from sonic.core.treasury import Treasury, ConversionQuote
    from sonic.core.payout_executor import PayoutExecutor, PayoutInstruction, PayoutResult
    from sonic.events.types import EventType
    from sonic.events.emitter import EventEmitter

    __all__ += [
        "Transaction", "TxState", "TxEvent", "InvalidTransition", "TRANSITIONS",
        "SonicReceipt", "ReceiptChain", "canonical_hash",
        "FinalityGate", "FinalityPolicy", "FinalityStatus", "DEFAULT_POLICIES",
        "Treasury", "ConversionQuote",
        "PayoutExecutor", "PayoutInstruction", "PayoutResult",
        "EventType", "EventEmitter",
    ]
except ImportError:
    pass

# SBN — available when sbn-sdk is installed
try:
    from sonic.sbn.client import SonicSbnClient, SbnClient, SbnError, SbnQuotaExceeded
    from sonic.sbn.attester import SbnAttester
    from sonic.sbn.receipt_coupler import ReceiptCoupler
    from sonic.sbn.frontier import SONIC_FRONTIER

    __all__ += [
        "SonicSbnClient", "SbnClient", "SbnError", "SbnQuotaExceeded",
        "SbnAttester", "ReceiptCoupler", "SONIC_FRONTIER",
    ]
except ImportError:
    pass

# Config — available with sonic-sdk[engine]
try:
    from sonic.config import SonicSettings, settings

    __all__ += ["SonicSettings", "settings"]
except ImportError:
    pass

# Execution layer — available when pgdag is installed
try:
    from sonic.execution import (
        SONIC_TEMPLATES,
        settlement_flow_template,
        stream_lifecycle_template,
        epoch_coupling_template,
        receipt_verification_template,
        settlement_flow_steps,
        stream_lifecycle_steps,
        epoch_coupling_steps,
        receipt_verification_steps,
    )

    __all__ += [
        "SONIC_TEMPLATES",
        "settlement_flow_template", "stream_lifecycle_template",
        "epoch_coupling_template", "receipt_verification_template",
        "settlement_flow_steps", "stream_lifecycle_steps",
        "epoch_coupling_steps", "receipt_verification_steps",
    ]
except ImportError:
    pass
