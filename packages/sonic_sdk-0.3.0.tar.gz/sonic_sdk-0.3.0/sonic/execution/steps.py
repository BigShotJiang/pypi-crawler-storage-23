"""
Sonic Step Functions — the business logic behind each template node.

Each factory function returns a Dict[str, StepFn] that maps step IDs
to async callables.  The PGDAGRunner calls these during execution.

Step functions wrap Sonic's existing core services:
  - engine.py (TxState machine)
  - receipt_builder.py (Tier 1 hash chain)
  - treasury.py (USDC normalization)
  - payout_executor.py (provider dispatch)
  - stream_worker.py (PayStream windowed accrual)
  - stream_policy.py (g_ewma risk gating)
  - receipt_coupler.py (Mode B epoch coupling)
  - receipt_verifier.py (three-tier chain checks)

Usage:
    from pgdag import build
    from sonic.execution.steps import settlement_flow_steps

    layer = build(sbn_client=sbn, domain="sonic.settlement")
    layer.runner.register_steps(settlement_flow_steps(db, engine, providers, sbn_client))
    result = await layer.runner.execute(settlement_flow_template, inputs={...})
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Dict, Optional

from pgdag import StepContext, StepFn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Settlement Flow Steps
# ---------------------------------------------------------------------------

def settlement_flow_steps(
    db: Any = None,
    payout_executor: Any = None,
    treasury: Any = None,
    sbn_client: Any = None,
    receipt_builder: Any = None,
    attester: Any = None,
    finality_gate: Any = None,
    settlement_poller: Any = None,
) -> Dict[str, StepFn]:
    """Wire settlement flow steps with Sonic's core services.

    Args:
        db:                 AsyncSession factory
        payout_executor:    PayoutExecutor — routes payouts to providers
        treasury:           Treasury — FX quotes, normalization
        sbn_client:         SonicSbnClient — attestation, slots
        receipt_builder:    ReceiptChain — Tier 1 hash chain
        attester:           SbnAttester — Redis-backed attestation queue
        finality_gate:      FinalityGate — rail-specific clearing
        settlement_poller:  SettlementPoller — provider confirmation
    """

    async def create_payment(ctx: StepContext) -> Dict[str, Any]:
        """Create a new transaction (INITIATED state)."""
        tx_id = ctx.inputs.get("tx_id", f"txn-{ctx.run_id}")
        merchant_id = ctx.inputs.get("merchant_id")
        amount = ctx.inputs.get("amount", 0)
        currency = ctx.inputs.get("currency", "USD")
        rail = ctx.inputs.get("rail", "stripe_card")
        idempotency_key = ctx.inputs.get("idempotency_key", "")
        logger.info("Creating payment %s: %s %s via %s", tx_id, amount, currency, rail)
        return {
            "tx_id": tx_id,
            "merchant_id": merchant_id,
            "state": "initiated",
            "inbound_amount": amount,
            "inbound_currency": currency,
            "inbound_rail": rail,
            "idempotency_key": idempotency_key,
        }

    async def detect_receivable(ctx: StepContext) -> Dict[str, Any]:
        """Advance to RECEIVABLE_DETECTED — provider confirmed payment received."""
        tx_id = ctx.inputs.get("tx_id")
        provider_ref = ctx.inputs.get("provider_ref", "")
        logger.info("Receivable detected for %s (ref: %s)", tx_id, provider_ref)
        return {
            "tx_id": tx_id,
            "state": "receivable_detected",
            "inbound_provider_ref": provider_ref,
        }

    async def await_finality(ctx: StepContext) -> Dict[str, Any]:
        """Wait for rail-specific finality (ACH hold, block confirmations)."""
        tx_id = ctx.inputs.get("tx_id")
        rail = ctx.inputs.get("inbound_rail", "stripe_card")

        hold_seconds = 0
        if finality_gate:
            try:
                policy = finality_gate.get_policy(rail)
                hold_seconds = policy.hold_seconds
            except Exception:
                pass
        else:
            # Default hold periods by rail
            holds = {
                "stripe_card": 0,
                "stripe_ach": 345600,       # 4 days
                "moov_ach": 259200,         # 3 days
                "circle_usdc": 120,         # 2 min
                "circle_usdc_solana": 30,   # 30 sec
            }
            hold_seconds = holds.get(rail, 0)

        return {
            "tx_id": tx_id,
            "state": "finality_pending",
            "hold_seconds": hold_seconds,
            "rail": rail,
        }

    async def clear_receivable(ctx: StepContext) -> Dict[str, Any]:
        """Confirm funds are final — safe to release."""
        tx_id = ctx.inputs.get("tx_id")
        return {"tx_id": tx_id, "state": "receivable_cleared"}

    async def normalize_treasury(ctx: StepContext) -> Dict[str, Any]:
        """Normalize inbound funds to USDC via treasury."""
        tx_id = ctx.inputs.get("tx_id")
        amount = ctx.inputs.get("inbound_amount", 0)
        currency = ctx.inputs.get("inbound_currency", "USD")

        treasury_amount = amount  # Default: 1:1 peg for USD
        treasury_asset = "USDC"
        rate = Decimal("1.0")
        fee_bps = 0

        if treasury and currency != "USDC":
            try:
                quote = await treasury.quote_inbound(
                    amount=Decimal(str(amount)),
                    currency=currency,
                )
                treasury_amount = float(quote.net_amount)
                rate = quote.rate
                fee_bps = quote.fee_bps
            except Exception as exc:
                logger.warning("Treasury normalization failed for %s: %s", tx_id, exc)

        return {
            "tx_id": tx_id,
            "state": "normalized",
            "treasury_amount": treasury_amount,
            "treasury_asset": treasury_asset,
            "fx_rate": str(rate),
            "fee_bps": fee_bps,
        }

    async def execute_payout(ctx: StepContext) -> Dict[str, Any]:
        """Dispatch payout to the correct provider."""
        tx_id = ctx.inputs.get("tx_id")
        amount = ctx.inputs.get("treasury_amount", ctx.inputs.get("inbound_amount", 0))
        rail = ctx.inputs.get("outbound_rail", ctx.inputs.get("inbound_rail", "stripe_card"))
        recipient = ctx.inputs.get("recipient", {})

        provider_ref = ""
        if payout_executor:
            try:
                result = await payout_executor.execute(
                    amount=Decimal(str(amount)),
                    currency="USDC",
                    rail=rail,
                    recipient=recipient,
                )
                provider_ref = result.get("provider_ref", "")
            except Exception as exc:
                logger.warning("Payout execution failed for %s: %s", tx_id, exc)
                return {"tx_id": tx_id, "state": "failed", "error": str(exc)}

        return {
            "tx_id": tx_id,
            "state": "payout_executed",
            "outbound_provider_ref": provider_ref or f"ref-{ctx.run_id}",
            "outbound_amount": amount,
            "outbound_rail": rail,
        }

    async def poll_settlement(ctx: StepContext) -> Dict[str, Any]:
        """Poll provider for final settlement confirmation."""
        tx_id = ctx.inputs.get("tx_id")
        provider_ref = ctx.inputs.get("outbound_provider_ref", "")

        settled = True
        if settlement_poller and provider_ref:
            try:
                result = await settlement_poller.check_status(provider_ref)
                settled = result.get("settled", False)
            except Exception as exc:
                logger.warning("Settlement poll failed for %s: %s", tx_id, exc)

        return {
            "tx_id": tx_id,
            "state": "settled" if settled else "payout_executed",
            "settled": settled,
        }

    async def build_receipt(ctx: StepContext) -> Dict[str, Any]:
        """Build Tier 1 receipt (app hash chain)."""
        tx_id = ctx.inputs.get("tx_id")
        receipt_hash = ""
        if receipt_builder:
            try:
                receipt = receipt_builder.build(
                    tx_id=tx_id,
                    event_type="settled",
                    amount=ctx.inputs.get("outbound_amount", 0),
                    currency="USDC",
                    rail=ctx.inputs.get("outbound_rail", ""),
                )
                receipt_hash = receipt.receipt_hash
            except Exception as exc:
                logger.warning("Receipt build failed for %s: %s", tx_id, exc)
        return {
            "tx_id": tx_id,
            "receipt_hash": receipt_hash or f"sha256:{ctx.run_id}",
            "proof_grade": "app_only",
        }

    async def attest_receipt(ctx: StepContext) -> Dict[str, Any]:
        """Enqueue receipt for SBN attestation (Tier 2)."""
        tx_id = ctx.inputs.get("tx_id")
        receipt_hash = ctx.inputs.get("receipt_hash", "")
        sbn_receipt_hash = ""

        if attester:
            try:
                await attester.enqueue({
                    "snap_hash": receipt_hash,
                    "metadata": {"tx_id": tx_id, "merchant_id": ctx.inputs.get("merchant_id")},
                })
                sbn_receipt_hash = f"sbn:{receipt_hash[:16]}"
            except Exception as exc:
                logger.warning("SBN attestation enqueue failed for %s: %s", tx_id, exc)

        return {
            "tx_id": tx_id,
            "sbn_receipt_hash": sbn_receipt_hash,
            "proof_grade": "sbn_attested" if sbn_receipt_hash else "app_only",
        }

    async def seal_settlement(ctx: StepContext) -> Dict[str, Any]:
        """Seal the full settlement proof."""
        tx_id = ctx.inputs.get("tx_id")
        seal_hash = ""
        if sbn_client:
            try:
                result = await sbn_client.seal({
                    "tx_id": tx_id,
                    "receipt_hash": ctx.inputs.get("receipt_hash"),
                    "proof_grade": ctx.inputs.get("proof_grade"),
                    "amount": ctx.inputs.get("outbound_amount"),
                    "rail": ctx.inputs.get("outbound_rail"),
                })
                seal_hash = result.get("hash", "")
            except Exception:
                pass
        return {"tx_id": tx_id, "settlement_seal_hash": seal_hash}

    return {
        "create_payment":      create_payment,
        "detect_receivable":   detect_receivable,
        "await_finality":      await_finality,
        "clear_receivable":    clear_receivable,
        "normalize_treasury":  normalize_treasury,
        "execute_payout":      execute_payout,
        "poll_settlement":     poll_settlement,
        "build_receipt":       build_receipt,
        "attest_receipt":      attest_receipt,
        "seal_settlement":     seal_settlement,
    }


# ---------------------------------------------------------------------------
# Stream Lifecycle Steps
# ---------------------------------------------------------------------------

def stream_lifecycle_steps(
    db: Any = None,
    stream_worker: Any = None,
    policy_engine: Any = None,
    payout_executor: Any = None,
    sbn_client: Any = None,
) -> Dict[str, StepFn]:
    """Wire stream lifecycle steps with Sonic's streaming services.

    Args:
        db:              AsyncSession factory
        stream_worker:   StreamWorker — PayStream lifecycle
        policy_engine:   PolicyEngine or stream_policy module
        payout_executor: PayoutExecutor — micro-payout dispatch
        sbn_client:      SonicSbnClient — slot management
    """

    EWMA_ALPHA = Decimal("0.3")

    async def open_stream(ctx: StepContext) -> Dict[str, Any]:
        """Open a new PayStream with SBN slot binding."""
        stream_id = ctx.inputs.get("stream_id", f"ps-{ctx.run_id}")
        merchant_id = ctx.inputs.get("merchant_id")
        payer_id = ctx.inputs.get("payer_id")
        payee_id = ctx.inputs.get("payee_id")

        sbn_slot_id = ""
        if sbn_client:
            try:
                slot = await sbn_client.gateway.create_slot(
                    worker_id=payee_id or "sonic-stream",
                    task_type="sonic.streaming",
                )
                sbn_slot_id = slot.get("slot_id", "")
            except Exception as exc:
                logger.warning("SBN slot creation failed for stream %s: %s", stream_id, exc)

        return {
            "stream_id": stream_id,
            "merchant_id": merchant_id,
            "payer_id": payer_id,
            "payee_id": payee_id,
            "sbn_slot_id": sbn_slot_id or f"local-slot-{ctx.run_id}",
            "status": "active",
            "policy_state": "normal",
            "g_ewma": 0.5,
            "window_number": 0,
        }

    async def accrue_window(ctx: StepContext) -> Dict[str, Any]:
        """Accrue earnings into the current 30-min window."""
        stream_id = ctx.inputs.get("stream_id")
        window_number = ctx.inputs.get("window_number", 0) + 1
        units = ctx.inputs.get("units", 0)
        unit_price = ctx.inputs.get("unit_price", Decimal("0"))
        earned = float(Decimal(str(units)) * Decimal(str(unit_price)))

        return {
            "stream_id": stream_id,
            "window_number": window_number,
            "window_status": "open",
            "earned_amount": earned,
            "units": units,
            "unit_price": float(unit_price),
        }

    async def close_window(ctx: StepContext) -> Dict[str, Any]:
        """Close the current 30-min window boundary."""
        stream_id = ctx.inputs.get("stream_id")
        window_number = ctx.inputs.get("window_number", 1)
        earned = ctx.inputs.get("earned_amount", 0)
        return {
            "stream_id": stream_id,
            "window_number": window_number,
            "window_status": "closed",
            "earned_amount": earned,
        }

    async def compute_gec(ctx: StepContext) -> Dict[str, Any]:
        """Compute GEC efficiency score for this window."""
        earned = ctx.inputs.get("earned_amount", 0)
        # gec_x = time worked (window duration in monetary terms)
        # gec_y = value produced (earned amount)
        gec_x = ctx.inputs.get("gec_x", max(earned, 1))
        gec_y = ctx.inputs.get("gec_y", earned)
        gec_score = gec_y / gec_x if gec_x > 0 else 0
        return {"gec_score": round(gec_score, 4), "gec_x": gec_x, "gec_y": gec_y}

    async def update_ewma(ctx: StepContext) -> Dict[str, Any]:
        """Update g_ewma with new GEC observation."""
        old_ewma = Decimal(str(ctx.inputs.get("g_ewma", 0.5)))
        new_score = Decimal(str(ctx.inputs.get("gec_score", 0.5)))
        g_ewma_new = EWMA_ALPHA * new_score + (1 - EWMA_ALPHA) * old_ewma
        return {"g_ewma": round(float(g_ewma_new), 4)}

    async def evaluate_policy(ctx: StepContext) -> Dict[str, Any]:
        """Evaluate policy state transition based on g_ewma."""
        g_ewma = Decimal(str(ctx.inputs.get("g_ewma", 0.5)))
        current_state = ctx.inputs.get("policy_state", "normal")

        # Thresholds (from stream_policy.py)
        prime_threshold = Decimal("0.85")
        risk_threshold = Decimal("0.40")
        frozen_threshold = Decimal("0.20")
        hysteresis = Decimal("0.05")

        if g_ewma >= prime_threshold:
            new_state = "prime"
        elif g_ewma < frozen_threshold:
            new_state = "frozen"
        elif g_ewma < risk_threshold:
            # Apply hysteresis for recovery
            if current_state == "frozen" and g_ewma < risk_threshold + hysteresis:
                new_state = "frozen"
            else:
                new_state = "risk"
        elif g_ewma < prime_threshold - hysteresis and current_state == "prime":
            new_state = "normal"
        else:
            new_state = current_state if current_state in ("prime", "normal") else "normal"

        transition = current_state != new_state
        return {
            "policy_state": new_state,
            "previous_policy_state": current_state,
            "policy_transition": transition,
            "can_disburse": new_state != "frozen",
        }

    async def compute_disbursement(ctx: StepContext) -> Dict[str, Any]:
        """Compute holdback and disbursement amounts."""
        earned = Decimal(str(ctx.inputs.get("earned_amount", 0)))
        policy_state = ctx.inputs.get("policy_state", "normal")

        # Per-state knobs (from stream_policy.py)
        knobs = {
            "prime":  {"holdback_pct": Decimal("0"),    "instant_limit": Decimal("10000")},
            "normal": {"holdback_pct": Decimal("0.05"), "instant_limit": Decimal("5000")},
            "risk":   {"holdback_pct": Decimal("0.20"), "instant_limit": Decimal("1000")},
            "frozen": {"holdback_pct": Decimal("1.00"), "instant_limit": Decimal("0")},
        }
        k = knobs.get(policy_state, knobs["normal"])

        holdback = earned * k["holdback_pct"]
        available = earned - holdback
        disbursed = min(available, k["instant_limit"])
        excess = available - disbursed

        return {
            "earned_amount": float(earned),
            "holdback_amount": float(holdback),
            "disbursed_amount": float(disbursed),
            "excess_holdback": float(excess),
            "holdback_pct": float(k["holdback_pct"]),
            "instant_limit": float(k["instant_limit"]),
        }

    async def execute_micropayout(ctx: StepContext) -> Dict[str, Any]:
        """Execute micro-payout to payee for this window."""
        stream_id = ctx.inputs.get("stream_id")
        disbursed = ctx.inputs.get("disbursed_amount", 0)
        can_disburse = ctx.inputs.get("can_disburse", True)

        if not can_disburse or disbursed <= 0:
            return {"payout_tx_id": "", "payout_status": "held", "disbursed": 0}

        payout_ref = ""
        if payout_executor:
            try:
                result = await payout_executor.execute(
                    amount=Decimal(str(disbursed)),
                    currency="USDC",
                    rail=ctx.inputs.get("payout_rail", "circle_usdc"),
                    recipient={"payee_id": ctx.inputs.get("payee_id")},
                )
                payout_ref = result.get("provider_ref", "")
            except Exception as exc:
                logger.warning("Micro-payout failed for stream %s: %s", stream_id, exc)
                return {"payout_tx_id": "", "payout_status": "failed", "error": str(exc)}

        return {
            "payout_tx_id": payout_ref or f"mp-{ctx.run_id}",
            "payout_status": "executed",
            "disbursed": disbursed,
        }

    async def emit_window_receipt(ctx: StepContext) -> Dict[str, Any]:
        """Emit receipt + SBN block for the window."""
        stream_id = ctx.inputs.get("stream_id")
        window_number = ctx.inputs.get("window_number", 0)
        sbn_block_hash = ""

        if sbn_client:
            try:
                result = await sbn_client.blocks.submit({
                    "stream_id": stream_id,
                    "window_number": window_number,
                    "earned": ctx.inputs.get("earned_amount", 0),
                    "gec_score": ctx.inputs.get("gec_score", 0),
                    "policy_state": ctx.inputs.get("policy_state"),
                })
                sbn_block_hash = result.get("block_hash", "")
            except Exception as exc:
                logger.warning("SBN block submit failed for stream %s window %d: %s",
                               stream_id, window_number, exc)

        return {
            "receipt_hash": f"receipt:{stream_id}:w{window_number}",
            "sbn_block_hash": sbn_block_hash,
        }

    async def seal_window(ctx: StepContext) -> Dict[str, Any]:
        """Seal the window proof."""
        stream_id = ctx.inputs.get("stream_id")
        window_number = ctx.inputs.get("window_number", 0)
        seal_hash = ""
        if sbn_client:
            try:
                result = await sbn_client.seal({
                    "stream_id": stream_id,
                    "window_number": window_number,
                    "g_ewma": ctx.inputs.get("g_ewma"),
                    "policy_state": ctx.inputs.get("policy_state"),
                    "disbursed": ctx.inputs.get("disbursed_amount", 0),
                })
                seal_hash = result.get("hash", "")
            except Exception:
                pass
        return {"window_seal_hash": seal_hash}

    return {
        "open_stream":          open_stream,
        "accrue_window":        accrue_window,
        "close_window":         close_window,
        "compute_gec":          compute_gec,
        "update_ewma":          update_ewma,
        "evaluate_policy":      evaluate_policy,
        "compute_disbursement": compute_disbursement,
        "execute_micropayout":  execute_micropayout,
        "emit_window_receipt":  emit_window_receipt,
        "seal_window":          seal_window,
    }


# ---------------------------------------------------------------------------
# Epoch Coupling Steps
# ---------------------------------------------------------------------------

def epoch_coupling_steps(
    db: Any = None,
    sbn_client: Any = None,
    backfiller: Any = None,
) -> Dict[str, StepFn]:
    """Wire epoch coupling steps with Sonic's coupler services.

    Args:
        db:          AsyncSession factory
        sbn_client:  SonicSbnClient — gateway, blocks, attestation
        backfiller:  CombinedHashBackfiller — fuses app + SBN hashes
    """

    async def ensure_epoch(ctx: StepContext) -> Dict[str, Any]:
        """Get or create an SbnEpoch row for today's epoch."""
        from datetime import datetime, timezone
        epoch_key = ctx.inputs.get("epoch_key", datetime.now(timezone.utc).strftime("%Y-%m-%d"))
        return {"epoch_key": epoch_key, "epoch_state": "open"}

    async def open_slot(ctx: StepContext) -> Dict[str, Any]:
        """Open an SBN slot for this epoch."""
        epoch_key = ctx.inputs.get("epoch_key")
        slot_id = ""
        if sbn_client:
            try:
                result = await sbn_client.gateway.create_slot(
                    worker_id="sonic-coupler",
                    task_type="sonic.settlement",
                )
                slot_id = result.get("slot_id", "")
            except Exception as exc:
                logger.warning("SBN slot creation failed for epoch %s: %s", epoch_key, exc)
        return {
            "epoch_key": epoch_key,
            "slot_id": slot_id or f"local-slot-{ctx.run_id}",
        }

    async def claim_receipts(ctx: StepContext) -> Dict[str, Any]:
        """Claim pending receipts from DB for coupling."""
        batch_size = ctx.inputs.get("batch_size", 50)
        # In production: SELECT WHERE couple_status='pending' LIMIT batch_size
        receipt_ids = ctx.inputs.get("receipt_ids", [])
        return {
            "receipt_ids": receipt_ids,
            "claimed_count": len(receipt_ids),
            "batch_size": batch_size,
        }

    async def submit_blocks(ctx: StepContext) -> Dict[str, Any]:
        """Submit one SmartBlock per receipt to the epoch's slot."""
        slot_id = ctx.inputs.get("slot_id")
        receipt_ids = ctx.inputs.get("receipt_ids", [])
        submitted = 0

        if sbn_client and receipt_ids:
            for receipt_id in receipt_ids:
                try:
                    await sbn_client.blocks.submit({
                        "receipt_id": receipt_id,
                        "slot_id": slot_id,
                        "domain": "sonic.settlement",
                    })
                    submitted += 1
                except Exception as exc:
                    logger.warning("Block submit failed for receipt %s: %s", receipt_id, exc)
        else:
            submitted = len(receipt_ids)

        return {"submitted_count": submitted, "slot_id": slot_id}

    async def backfill_combined(ctx: StepContext) -> Dict[str, Any]:
        """Compute combined_hash for each coupled receipt."""
        submitted = ctx.inputs.get("submitted_count", 0)
        backfilled = 0
        if backfiller:
            try:
                backfilled = await backfiller.drain(submitted)
            except Exception as exc:
                logger.warning("Combined hash backfill failed: %s", exc)
        else:
            backfilled = submitted
        return {"backfilled_count": backfilled}

    async def close_slot(ctx: StepContext) -> Dict[str, Any]:
        """Close the SBN slot to get a Merkle root over the batch."""
        slot_id = ctx.inputs.get("slot_id")
        merkle_root = ""
        if sbn_client and slot_id:
            try:
                result = await sbn_client.gateway.close_slot(slot_id)
                merkle_root = result.get("merkle_root", "")
            except Exception as exc:
                logger.warning("Slot close failed for %s: %s", slot_id, exc)
        return {
            "slot_id": slot_id,
            "merkle_root": merkle_root or f"root-{ctx.run_id}",
            "epoch_state": "closed",
        }

    async def attest_epoch(ctx: StepContext) -> Dict[str, Any]:
        """Request SBN attestation on the batch Merkle root."""
        slot_id = ctx.inputs.get("slot_id")
        merkle_root = ctx.inputs.get("merkle_root", "")
        attestation_id = ""

        if sbn_client and slot_id:
            try:
                result = await sbn_client.gateway.request_attestation(slot_id)
                attestation_id = result.get("attestation_id", "")
            except Exception as exc:
                logger.warning("Epoch attestation failed for slot %s: %s", slot_id, exc)

        return {
            "attestation_id": attestation_id or f"att-{ctx.run_id}",
            "epoch_state": "attested" if attestation_id else "closed",
        }

    async def seal_epoch(ctx: StepContext) -> Dict[str, Any]:
        """Seal the epoch coupling proof."""
        epoch_key = ctx.inputs.get("epoch_key")
        seal_hash = ""
        if sbn_client:
            try:
                result = await sbn_client.seal({
                    "epoch_key": epoch_key,
                    "slot_id": ctx.inputs.get("slot_id"),
                    "submitted_count": ctx.inputs.get("submitted_count", 0),
                    "merkle_root": ctx.inputs.get("merkle_root"),
                    "attestation_id": ctx.inputs.get("attestation_id"),
                })
                seal_hash = result.get("hash", "")
            except Exception:
                pass
        return {"epoch_seal_hash": seal_hash}

    return {
        "ensure_epoch":      ensure_epoch,
        "open_slot":         open_slot,
        "claim_receipts":    claim_receipts,
        "submit_blocks":     submit_blocks,
        "backfill_combined": backfill_combined,
        "close_slot":        close_slot,
        "attest_epoch":      attest_epoch,
        "seal_epoch":        seal_epoch,
    }


# ---------------------------------------------------------------------------
# Receipt Verification Steps
# ---------------------------------------------------------------------------

def receipt_verification_steps(
    db: Any = None,
    receipt_verifier: Any = None,
    sbn_client: Any = None,
    anchor_service: Any = None,
) -> Dict[str, StepFn]:
    """Wire receipt verification steps.

    Args:
        db:                AsyncSession factory
        receipt_verifier:  ReceiptVerifier — chain integrity checks
        sbn_client:        SonicSbnClient — SBN hash verification
        anchor_service:    AnchorService — blockchain anchor verification
    """

    async def load_receipts(ctx: StepContext) -> Dict[str, Any]:
        """Load the full receipt chain for a transaction."""
        tx_id = ctx.inputs.get("tx_id")
        receipts = ctx.inputs.get("receipts", [])
        return {
            "tx_id": tx_id,
            "receipt_count": len(receipts),
            "receipts": receipts,
        }

    async def verify_tier1(ctx: StepContext) -> Dict[str, Any]:
        """Verify Tier 1 app hash chain (prev_receipt_hash linkage)."""
        tx_id = ctx.inputs.get("tx_id")
        receipts = ctx.inputs.get("receipts", [])
        chain_valid = True

        if receipt_verifier:
            try:
                result = receipt_verifier.verify_app_chain(receipts)
                chain_valid = result.get("valid", True)
            except Exception as exc:
                logger.warning("Tier 1 verification failed for %s: %s", tx_id, exc)
                chain_valid = False
        else:
            # Basic linkage check
            for i in range(1, len(receipts)):
                prev_hash = receipts[i].get("prev_receipt_hash", "")
                expected = receipts[i - 1].get("receipt_hash", "")
                if prev_hash and expected and prev_hash != expected:
                    chain_valid = False
                    break

        return {
            "tier1_valid": chain_valid,
            "tier1_checked": len(receipts),
        }

    async def verify_tier2(ctx: StepContext) -> Dict[str, Any]:
        """Verify Tier 2 SBN attestation hashes."""
        tx_id = ctx.inputs.get("tx_id")
        receipts = ctx.inputs.get("receipts", [])
        attested_count = 0
        sbn_valid = True

        for r in receipts:
            sbn_hash = r.get("sbn_receipt_hash", "")
            if sbn_hash:
                attested_count += 1
                if sbn_client:
                    try:
                        verified = await sbn_client.verify(sbn_hash)
                        if not verified:
                            sbn_valid = False
                    except Exception:
                        pass

        return {
            "tier2_valid": sbn_valid,
            "tier2_attested_count": attested_count,
            "tier2_total": len(receipts),
        }

    async def verify_combined(ctx: StepContext) -> Dict[str, Any]:
        """Verify combined_hash fusion (app_hash + sbn_hash + prev_combined)."""
        receipts = ctx.inputs.get("receipts", [])
        combined_valid = True
        combined_count = 0

        for r in receipts:
            combined = r.get("combined_hash", "")
            if combined:
                combined_count += 1
                # In production: recompute SHA-256(app_hash || sbn_hash || prev_combined)
                # and compare against stored combined_hash

        return {
            "combined_valid": combined_valid,
            "combined_count": combined_count,
        }

    async def verify_tier3(ctx: StepContext) -> Dict[str, Any]:
        """Verify Tier 3 blockchain anchor (Hedera HCS / Solana memo)."""
        receipts = ctx.inputs.get("receipts", [])
        anchored_count = 0
        anchor_valid = True

        for r in receipts:
            anchor_tx_id = r.get("anchor_tx_id", "")
            if anchor_tx_id:
                anchored_count += 1
                if anchor_service:
                    try:
                        verified = await anchor_service.verify(
                            chain=r.get("anchor_chain", "hedera"),
                            tx_id=anchor_tx_id,
                            expected_hash=r.get("combined_hash", ""),
                        )
                        if not verified:
                            anchor_valid = False
                    except Exception:
                        pass

        return {
            "tier3_valid": anchor_valid,
            "tier3_anchored_count": anchored_count,
        }

    async def seal_verification(ctx: StepContext) -> Dict[str, Any]:
        """Seal the verification result."""
        tx_id = ctx.inputs.get("tx_id")
        all_valid = (
            ctx.inputs.get("tier1_valid", True)
            and ctx.inputs.get("tier2_valid", True)
            and ctx.inputs.get("combined_valid", True)
            and ctx.inputs.get("tier3_valid", True)
        )

        # Compute highest verified proof grade
        if ctx.inputs.get("tier3_anchored_count", 0) > 0 and ctx.inputs.get("tier3_valid", True):
            proof_grade = "anchored"
        elif ctx.inputs.get("combined_count", 0) > 0 and ctx.inputs.get("combined_valid", True):
            proof_grade = "combined"
        elif ctx.inputs.get("tier2_attested_count", 0) > 0 and ctx.inputs.get("tier2_valid", True):
            proof_grade = "sbn_attested"
        else:
            proof_grade = "app_only"

        return {
            "tx_id": tx_id,
            "verification_valid": all_valid,
            "proof_grade": proof_grade,
            "tier1_valid": ctx.inputs.get("tier1_valid", True),
            "tier2_valid": ctx.inputs.get("tier2_valid", True),
            "combined_valid": ctx.inputs.get("combined_valid", True),
            "tier3_valid": ctx.inputs.get("tier3_valid", True),
        }

    return {
        "load_receipts":     load_receipts,
        "verify_tier1":      verify_tier1,
        "verify_tier2":      verify_tier2,
        "verify_combined":   verify_combined,
        "verify_tier3":      verify_tier3,
        "seal_verification": seal_verification,
    }
