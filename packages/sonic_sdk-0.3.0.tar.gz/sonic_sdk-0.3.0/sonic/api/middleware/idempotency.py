"""Idempotency middleware — exactly-once outcome semantics.

Uses Redis to store request → response mappings by idempotency key.
If the same key is seen again, return the cached response without
re-executing the operation.
"""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Default TTL for idempotency keys: 24 hours
DEFAULT_TTL = 86400


class IdempotencyStore:
    """Redis-backed idempotency key store."""

    def __init__(self, redis_client: Any, ttl: int = DEFAULT_TTL):
        self._redis = redis_client
        self._ttl = ttl
        self._prefix = "sonic:idempotency:"

    async def check(self, key: str) -> dict[str, Any] | None:
        """Check if this idempotency key has been seen before.

        Returns the cached response if found, None otherwise.
        """
        raw = await self._redis.get(f"{self._prefix}{key}")
        if raw:
            logger.debug("Idempotency hit: %s", key)
            return json.loads(raw)
        return None

    async def store(self, key: str, response: dict[str, Any]) -> None:
        """Store the response for this idempotency key."""
        await self._redis.setex(
            f"{self._prefix}{key}",
            self._ttl,
            json.dumps(response),
        )

    async def exists(self, key: str) -> bool:
        """Check if key exists without retrieving value."""
        return bool(await self._redis.exists(f"{self._prefix}{key}"))
