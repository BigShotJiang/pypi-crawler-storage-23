"""Phase 4.3 — Multi-tenant rate limiting with per-plan tiers.

Tiers:
  - free:       60 req/min, 1000 req/day
  - growth:     300 req/min, 50000 req/day
  - enterprise: 1000 req/min, unlimited
"""

from __future__ import annotations

import logging
import time
from typing import Any

logger = logging.getLogger("sonic.rate_limit.tenant")

# Plan tier definitions: (requests_per_minute, requests_per_day)
TIER_LIMITS: dict[str, tuple[int, int]] = {
    "free": (60, 1_000),
    "growth": (300, 50_000),
    "enterprise": (1_000, 1_000_000),  # Effectively unlimited
}


class TenantRateLimiter:
    """Redis-backed per-merchant rate limiter with plan tiers."""

    def __init__(self, redis: Any | None = None):
        self._redis = redis

    async def check(self, merchant_id: str, plan: str = "free") -> tuple[bool, dict]:
        """Check if a request is allowed under the merchant's plan tier.

        Returns (allowed, headers) where headers contains rate limit info.
        """
        if not self._redis:
            return True, {}  # Fail open if no Redis

        rpm_limit, daily_limit = TIER_LIMITS.get(plan, TIER_LIMITS["free"])
        now = int(time.time())
        minute_key = f"sonic:tenant_rl:{merchant_id}:min:{now // 60}"
        day_key = f"sonic:tenant_rl:{merchant_id}:day:{now // 86400}"

        pipe = self._redis.pipeline()
        pipe.incr(minute_key)
        pipe.expire(minute_key, 120)  # 2 min TTL
        pipe.incr(day_key)
        pipe.expire(day_key, 172800)  # 2 day TTL
        results = await pipe.execute()

        minute_count = results[0]
        day_count = results[2]

        headers = {
            "X-RateLimit-Plan": plan,
            "X-RateLimit-Limit-Minute": str(rpm_limit),
            "X-RateLimit-Remaining-Minute": str(max(0, rpm_limit - minute_count)),
            "X-RateLimit-Limit-Day": str(daily_limit),
            "X-RateLimit-Remaining-Day": str(max(0, daily_limit - day_count)),
        }

        if minute_count > rpm_limit or day_count > daily_limit:
            return False, headers

        return True, headers
