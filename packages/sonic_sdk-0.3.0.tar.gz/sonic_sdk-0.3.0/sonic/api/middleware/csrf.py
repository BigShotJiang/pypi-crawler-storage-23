"""CSRF protection middleware — double-submit cookie pattern.

For API-key and Bearer-token authenticated endpoints, CSRF is not a concern
because browsers cannot automatically attach custom headers. This middleware
protects cookie-based dashboard/admin sessions.

How it works:
  1. On any non-safe request (POST, PATCH, DELETE), if the request carries
     cookies (indicating a browser session), the middleware checks that the
     ``X-CSRF-Token`` header matches the ``sonic_csrf`` cookie value.
  2. On first response, the middleware sets a ``sonic_csrf`` cookie with a
     random token that JavaScript can read and attach to subsequent requests.

Requests with ``Authorization: Bearer`` or ``x-sonic-api-key`` headers are
exempt — they use non-cookie auth and are inherently CSRF-safe.
"""

from __future__ import annotations

import logging
import secrets

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)

_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
_CSRF_COOKIE = "sonic_csrf"
_CSRF_HEADER = "x-csrf-token"
_TOKEN_LENGTH = 32


class CsrfMiddleware(BaseHTTPMiddleware):
    """Double-submit cookie CSRF protection for browser-based sessions."""

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Skip for safe (read-only) methods
        if request.method in _SAFE_METHODS:
            response = await call_next(request)
            self._ensure_csrf_cookie(request, response)
            return response

        # Skip for non-cookie auth (API key or Bearer token)
        if request.headers.get("x-sonic-api-key") or (
            request.headers.get("authorization", "").startswith("Bearer ")
        ):
            return await call_next(request)

        # For state-changing requests with cookies, validate CSRF
        csrf_cookie = request.cookies.get(_CSRF_COOKIE)
        csrf_header = request.headers.get(_CSRF_HEADER)

        if not csrf_cookie or not csrf_header:
            return JSONResponse(
                status_code=403,
                content={"detail": "CSRF token missing"},
            )

        if not secrets.compare_digest(csrf_cookie, csrf_header):
            return JSONResponse(
                status_code=403,
                content={"detail": "CSRF token mismatch"},
            )

        response = await call_next(request)
        return response

    def _ensure_csrf_cookie(self, request: Request, response: Response) -> None:
        """Set the CSRF cookie if not already present."""
        if _CSRF_COOKIE not in request.cookies:
            token = secrets.token_urlsafe(_TOKEN_LENGTH)
            response.set_cookie(
                _CSRF_COOKIE,
                token,
                httponly=False,  # JS must be able to read it
                secure=True,
                samesite="strict",
                max_age=86400,  # 24h
                path="/",
            )
