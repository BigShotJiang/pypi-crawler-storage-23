"""Sonic API key authentication — Argon2id hashing.

API keys are generated with cryptographic randomness and stored
as Argon2id hashes (memory-hard, resistant to GPU/ASIC attacks).

Verification uses constant-time comparison via the argon2-cffi
library's built-in verify. Falls back to SHA-256 HMAC comparison
for keys hashed before the Argon2 upgrade (migration path).
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
from typing import Any

API_KEY_PREFIX = "sonic_live_"
API_KEY_TEST_PREFIX = "sonic_test_"

# Argon2id is the preferred hasher. Falls back to SHA-256 if not installed.
try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError

    _ph = PasswordHasher(
        time_cost=2,        # 2 iterations
        memory_cost=65536,  # 64 MB
        parallelism=1,      # 1 thread (safe for async)
        hash_len=32,
        salt_len=16,
    )
    _ARGON2_AVAILABLE = True
except ImportError:
    _ARGON2_AVAILABLE = False


def generate_api_key(*, test: bool = False) -> tuple[str, str]:
    """Generate a new API key.

    Returns (full_key, key_hash) — store only the hash.
    Uses Argon2id if available, falls back to SHA-256.
    """
    prefix = API_KEY_TEST_PREFIX if test else API_KEY_PREFIX
    secret = secrets.token_urlsafe(32)
    full_key = f"{prefix}{secret}"

    if _ARGON2_AVAILABLE:
        key_hash = _ph.hash(full_key)
    else:
        key_hash = hashlib.sha256(full_key.encode()).hexdigest()

    return full_key, key_hash


def verify_api_key(provided_key: str, stored_hash: str) -> bool:
    """Verify API key against stored hash.

    Supports both Argon2id hashes (preferred) and legacy SHA-256
    hashes for backward compatibility during migration.
    """
    if _ARGON2_AVAILABLE and stored_hash.startswith("$argon2"):
        try:
            return _ph.verify(stored_hash, provided_key)
        except (VerifyMismatchError, VerificationError):
            return False
    else:
        # Legacy SHA-256 fallback (constant-time via hmac.compare_digest)
        provided_hash = hashlib.sha256(provided_key.encode()).hexdigest()
        return hmac.compare_digest(provided_hash, stored_hash)


def needs_rehash(stored_hash: str) -> bool:
    """Check if a stored hash should be upgraded to Argon2id.

    Returns True for legacy SHA-256 hashes when Argon2 is available,
    or for Argon2 hashes with outdated parameters.
    """
    if not _ARGON2_AVAILABLE:
        return False

    if not stored_hash.startswith("$argon2"):
        return True  # Legacy SHA-256 hash

    return _ph.check_needs_rehash(stored_hash)
