"""Webhook endpoints — provider callbacks and merchant webhook config.

Security hardening:
  - Stripe: HMAC-SHA256 signature + timestamp freshness (reject > 5 min)
  - Moov: HMAC-SHA256 signature + Redis dedup via event ID
  - Circle: HMAC-SHA256 signature + Redis dedup via event ID
  - All: Webhook event IDs stored in Redis with TTL to prevent replay
  - SSRF: Merchant webhook URLs validated against internal IP ranges
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import logging
import time
from typing import Any
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import (
    get_db,
    get_merchant,
    get_emitter,
    get_attester,
    get_finality_gate,
    get_redis,
)
from sonic.config import settings
from sonic.core.engine import Transaction, TxState
from sonic.core.finality_gate import FinalityStatus
from sonic.logging import tx_id_var, merchant_id_var
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.metrics import TX_STATE_TRANSITIONS, WEBHOOK_RECEIVED, WEBHOOK_PROCESSING_DURATION, RECEIPT_TOTAL
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

log = logging.getLogger("sonic.webhooks")

router = APIRouter()

# Maximum age for webhook timestamps (5 minutes)
WEBHOOK_TIMESTAMP_TOLERANCE = 300
# TTL for webhook dedup keys in Redis (24 hours)
WEBHOOK_DEDUP_TTL = 86400

# RFC 1918 / link-local / loopback ranges blocked for SSRF
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),  # AWS metadata
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


async def _check_webhook_dedup(redis: Any, provider: str, event_id: str) -> bool:
    """Check if this webhook event has already been processed.

    Returns True if duplicate (should be rejected), False if new.
    """
    if not redis or not event_id:
        return False

    key = f"sonic:webhook:dedup:{provider}:{event_id}"
    was_set = await redis.set(key, "1", ex=WEBHOOK_DEDUP_TTL, nx=True)
    # SET NX returns True if key was set (new event), None if already exists (replay)
    return was_set is None


def _validate_webhook_url(url: str) -> None:
    """Validate a merchant webhook URL against SSRF attacks.

    Blocks internal/private IP ranges that could be used to probe
    internal services (AWS metadata, internal APIs, etc.).
    """
    parsed = urlparse(url)
    hostname = parsed.hostname

    if not hostname:
        raise ValueError("Invalid URL: no hostname")

    # Try to parse as IP address directly
    try:
        addr = ipaddress.ip_address(hostname)
        for network in _BLOCKED_NETWORKS:
            if addr in network:
                raise ValueError(f"Webhook URL points to blocked network range")
    except ValueError as exc:
        if "blocked network" in str(exc):
            raise
        # Not an IP address — it's a hostname, check for common internal names
        blocked_hostnames = {"localhost", "metadata.google.internal", "169.254.169.254"}
        if hostname.lower() in blocked_hostnames:
            raise ValueError("Webhook URL points to blocked hostname")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

async def _load_tx_by_provider_ref(
    db: AsyncSession, provider_ref: str
) -> TransactionRecord | None:
    """Look up a transaction by its inbound provider reference."""
    result = await db.execute(
        select(TransactionRecord).where(
            TransactionRecord.inbound_provider_ref == provider_ref
        )
    )
    return result.scalar_one_or_none()


async def _get_prev_receipt_hash(db: AsyncSession, tx_id: str) -> str | None:
    result = await db.execute(
        select(ReceiptRecord.receipt_hash)
        .where(ReceiptRecord.tx_id == tx_id)
        .order_by(ReceiptRecord.sequence.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def _advance_and_persist(
    *,
    db: AsyncSession,
    record: TransactionRecord,
    target_state: TxState,
    provider_name: str,
    provider_ref: str | None,
    emitter: Any,
    attester: Any,
    event_type: EventType,
    extra_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Advance the state machine, build a receipt, persist, emit events."""
    tx_id_var.set(record.id)
    merchant_id_var.set(record.merchant_id)
    tx = Transaction(
        tx_id=record.id,
        merchant_id=record.merchant_id,
        state=TxState(record.state),
        inbound_amount=record.inbound_amount,
        inbound_currency=record.inbound_currency,
        inbound_rail=record.inbound_rail,
        sequence=record.sequence,
    )

    event = tx.advance(
        target_state,
        amount=record.inbound_amount,
        currency=record.inbound_currency,
        rail=record.inbound_rail,
        provider_ref=provider_ref,
    )

    record.state = target_state.value
    record.sequence = tx.sequence

    prev_hash = await _get_prev_receipt_hash(db, record.id)
    chain = ReceiptChain()
    chain._last_hash = prev_hash
    receipt = chain.build(event, merchant_id=record.merchant_id, direction="inbound")

    db.add(ReceiptRecord(
        receipt_id=receipt.receipt_id,
        tx_id=record.id,
        event_type=receipt.event_type,
        sequence=receipt.sequence,
        amount=receipt.amount,
        currency=receipt.currency,
        rail=receipt.rail,
        direction=receipt.direction,
        receipt_hash=receipt.receipt_hash,
        prev_receipt_hash=receipt.prev_receipt_hash,
        idempotency_key=receipt.idempotency_key,
        merchant_id=record.merchant_id,
    ))

    db.add(EventLog(
        tx_id=record.id,
        event_type=event_type.value,
        from_state=event.from_state.value,
        to_state=target_state.value,
        merchant_id=record.merchant_id,
        provider=provider_name,
        provider_ref=provider_ref,
        receipt_hash=receipt.receipt_hash,
        payload=extra_payload,
    ))

    await db.commit()

    TX_STATE_TRANSITIONS.labels(
        from_state=event.from_state.value, to_state=target_state.value, provider=provider_name,
    ).inc()
    RECEIPT_TOTAL.labels(tier="tier1").inc()

    # SBN attestation (non-blocking)
    if attester is not None:
        try:
            await attester.enqueue(receipt)
        except Exception:
            log.warning("SBN enqueue failed for receipt %s", receipt.receipt_id, exc_info=True)

    # Emit event (non-blocking)
    try:
        await emitter.emit(event_type, {
            "tx_id": record.id,
            "merchant_id": record.merchant_id,
            "state": target_state.value,
            "provider_ref": provider_ref,
            "receipt_hash": receipt.receipt_hash,
        })
    except Exception:
        log.warning("Event emission failed for tx %s", record.id, exc_info=True)

    return {"tx_id": record.id, "state": target_state.value, "receipt_hash": receipt.receipt_hash}


async def _maybe_auto_normalize(
    *,
    db: AsyncSession,
    record: TransactionRecord,
    result: dict[str, Any],
    emitter: Any,
    attester: Any,
) -> dict[str, Any]:
    """If auto_normalize is on and we just reached RECEIVABLE_CLEARED, run normalization."""
    if not settings.auto_normalize:
        return result
    if result["state"] != TxState.RECEIVABLE_CLEARED.value:
        return result

    # Refresh the record so attributes are loaded after the previous commit
    await db.refresh(record)

    from sonic.core.normalizer import Normalizer
    from sonic.core.treasury import Treasury

    normalizer = Normalizer(Treasury(base_asset=settings.base_treasury_asset))
    try:
        norm_result = await normalizer.normalize(
            db=db, record=record, emitter=emitter, attester=attester,
        )
        if norm_result:
            log.info("Auto-normalized tx %s → %s", record.id, norm_result["state"])
            return norm_result
    except Exception:
        log.warning("Auto-normalize failed for tx %s", record.id, exc_info=True)

    return result


# ---------------------------------------------------------------------------
# Stripe webhook
# ---------------------------------------------------------------------------

_STRIPE_EVENT_MAP: dict[str, tuple[TxState, EventType]] = {
    "payment_intent.succeeded": (TxState.FINALITY_PENDING, EventType.FINALITY_PENDING),
    "payment_intent.payment_failed": (TxState.FAILED, EventType.PAYMENT_FAILED),
    "charge.captured": (TxState.FINALITY_PENDING, EventType.FINALITY_PENDING),
    "charge.refunded": (TxState.REVERSED, EventType.RECEIVABLE_REVERSED),
    "charge.dispute.created": (TxState.REVERSED, EventType.RECEIVABLE_REVERSED),
}


def _verify_stripe_signature(payload: bytes, sig_header: str, secret: str) -> dict[str, Any]:
    """Verify Stripe webhook signature with timestamp freshness check.

    Stripe signs with HMAC-SHA256 using the format:
        t=<timestamp>,v1=<signature>

    Rejects events older than WEBHOOK_TIMESTAMP_TOLERANCE seconds.
    """
    parts = dict(item.split("=", 1) for item in sig_header.split(",") if "=" in item)
    timestamp = parts.get("t", "")
    expected_sig = parts.get("v1", "")

    if not timestamp or not expected_sig:
        raise ValueError("Invalid Stripe signature header")

    # Timestamp freshness check — reject stale webhooks
    try:
        event_time = int(timestamp)
        age = abs(time.time() - event_time)
        if age > WEBHOOK_TIMESTAMP_TOLERANCE:
            raise ValueError(f"Webhook timestamp too old ({int(age)}s)")
    except (ValueError, OverflowError) as exc:
        if "too old" in str(exc):
            raise
        raise ValueError("Invalid Stripe timestamp") from exc

    signed_payload = f"{timestamp}.".encode() + payload
    computed = hmac.new(
        secret.encode(), signed_payload, hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(computed, expected_sig):
        raise ValueError("Stripe signature mismatch")

    return json.loads(payload)


@router.post("/webhooks/stripe")
async def stripe_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    finality_gate: Any = Depends(get_finality_gate),
    redis: Any = Depends(get_redis),
):
    """Handle Stripe webhook events (payment confirmations, disputes, etc.)."""
    _start = time.perf_counter()
    body = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    if not settings.stripe_webhook_secret:
        log.error("Stripe webhook secret not configured")
        raise HTTPException(status_code=500, detail="Webhook configuration error")

    try:
        event_data = _verify_stripe_signature(body, sig_header, settings.stripe_webhook_secret)
    except ValueError as exc:
        log.warning("Stripe signature verification failed: %s", exc)
        WEBHOOK_RECEIVED.labels(provider="stripe", outcome="rejected").inc()
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Replay protection via event ID dedup
    stripe_event_id = event_data.get("id", "")
    if await _check_webhook_dedup(redis, "stripe", stripe_event_id):
        log.info("Stripe webhook replay detected: event=%s", stripe_event_id)
        WEBHOOK_RECEIVED.labels(provider="stripe", outcome="duplicate").inc()
        return {"status": "duplicate", "event_id": stripe_event_id}

    event_type_str = event_data.get("type", "")
    mapping = _STRIPE_EVENT_MAP.get(event_type_str)
    if mapping is None:
        log.debug("Ignoring unhandled Stripe event type: %s", event_type_str)
        return {"status": "ignored", "event_type": event_type_str}

    target_state, sonic_event_type = mapping

    obj = event_data.get("data", {}).get("object", {})
    provider_ref = obj.get("id", "")

    record = await _load_tx_by_provider_ref(db, provider_ref)
    if record is None:
        log.warning("Stripe webhook: no transaction for provider_ref=%s", provider_ref)
        return {"status": "no_match", "provider_ref": provider_ref}

    if target_state == TxState.FINALITY_PENDING:
        rail = record.inbound_rail
        finality = finality_gate.evaluate(rail, provider_confirmed=True)
        if finality == FinalityStatus.FINAL:
            target_state = TxState.RECEIVABLE_CLEARED
            sonic_event_type = EventType.RECEIVABLE_CLEARED

    result = await _advance_and_persist(
        db=db,
        record=record,
        target_state=target_state,
        provider_name="stripe",
        provider_ref=provider_ref,
        emitter=emitter,
        attester=attester,
        event_type=sonic_event_type,
        extra_payload={"stripe_event": event_type_str},
    )

    # Auto-normalize if we just reached RECEIVABLE_CLEARED
    result = await _maybe_auto_normalize(
        db=db, record=record, result=result, emitter=emitter, attester=attester,
    )

    WEBHOOK_RECEIVED.labels(provider="stripe", outcome="processed").inc()
    WEBHOOK_PROCESSING_DURATION.labels(provider="stripe").observe(time.perf_counter() - _start)
    log.info(
        "Stripe webhook processed",
        extra={"tx_id": result["tx_id"], "event": event_type_str, "to_state": result["state"], "provider": "stripe"},
    )
    return {"status": "processed", **result}


# ---------------------------------------------------------------------------
# Moov webhook
# ---------------------------------------------------------------------------

_MOOV_STATUS_MAP: dict[str, tuple[TxState, EventType]] = {
    "completed": (TxState.FINALITY_PENDING, EventType.FINALITY_PENDING),
    "failed": (TxState.FAILED, EventType.PAYMENT_FAILED),
    "returned": (TxState.REVERSED, EventType.RECEIVABLE_REVERSED),
    "canceled": (TxState.FAILED, EventType.PAYMENT_FAILED),
}


def _verify_moov_signature(payload: bytes, sig_header: str, secret: str) -> bool:
    """Verify Moov webhook HMAC-SHA256 signature."""
    computed = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, sig_header)


@router.post("/webhooks/moov")
async def moov_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    finality_gate: Any = Depends(get_finality_gate),
    redis: Any = Depends(get_redis),
):
    """Handle Moov webhook events (ACH transfer status updates)."""
    _start = time.perf_counter()
    body = await request.body()
    sig_header = request.headers.get("x-moov-signature", "")

    if not settings.moov_api_key:
        log.error("Moov webhook secret not configured")
        raise HTTPException(status_code=500, detail="Webhook configuration error")

    if not sig_header:
        log.warning("Moov webhook missing signature header")
        raise HTTPException(status_code=400, detail="Missing signature")

    if not _verify_moov_signature(body, sig_header, settings.moov_api_key):
        log.warning("Moov signature verification failed")
        WEBHOOK_RECEIVED.labels(provider="moov", outcome="rejected").inc()
        raise HTTPException(status_code=400, detail="Invalid signature")

    event_data = json.loads(body)

    # Replay protection via event ID
    moov_event_id = event_data.get("eventID", "") or event_data.get("id", "")
    if await _check_webhook_dedup(redis, "moov", moov_event_id):
        log.info("Moov webhook replay detected: event=%s", moov_event_id)
        WEBHOOK_RECEIVED.labels(provider="moov", outcome="duplicate").inc()
        return {"status": "duplicate", "event_id": moov_event_id}

    transfer = event_data.get("data", event_data)
    transfer_status = transfer.get("status", "").lower()
    provider_ref = transfer.get("transferID", "") or transfer.get("id", "")

    mapping = _MOOV_STATUS_MAP.get(transfer_status)
    if mapping is None:
        log.debug("Ignoring unhandled Moov status: %s", transfer_status)
        return {"status": "ignored", "moov_status": transfer_status}

    target_state, sonic_event_type = mapping

    record = await _load_tx_by_provider_ref(db, provider_ref)
    if record is None:
        log.warning("Moov webhook: no transaction for provider_ref=%s", provider_ref)
        return {"status": "no_match", "provider_ref": provider_ref}

    if target_state == TxState.FINALITY_PENDING:
        finality = finality_gate.evaluate("moov_ach", provider_confirmed=True)
        if finality == FinalityStatus.FINAL:
            target_state = TxState.RECEIVABLE_CLEARED
            sonic_event_type = EventType.RECEIVABLE_CLEARED

    result = await _advance_and_persist(
        db=db,
        record=record,
        target_state=target_state,
        provider_name="moov",
        provider_ref=provider_ref,
        emitter=emitter,
        attester=attester,
        event_type=sonic_event_type,
        extra_payload={"moov_status": transfer_status},
    )

    # Auto-normalize if we just reached RECEIVABLE_CLEARED
    result = await _maybe_auto_normalize(
        db=db, record=record, result=result, emitter=emitter, attester=attester,
    )

    WEBHOOK_RECEIVED.labels(provider="moov", outcome="processed").inc()
    WEBHOOK_PROCESSING_DURATION.labels(provider="moov").observe(time.perf_counter() - _start)
    log.info(
        "Moov webhook processed",
        extra={"tx_id": result["tx_id"], "moov_status": transfer_status, "to_state": result["state"], "provider": "moov"},
    )
    return {"status": "processed", **result}


# ---------------------------------------------------------------------------
# Circle webhook
# ---------------------------------------------------------------------------

_CIRCLE_STATUS_MAP: dict[str, tuple[TxState, EventType]] = {
    "complete": (TxState.FINALITY_PENDING, EventType.FINALITY_PENDING),
    "confirmed": (TxState.FINALITY_PENDING, EventType.FINALITY_PENDING),
    "failed": (TxState.FAILED, EventType.PAYMENT_FAILED),
}


def _verify_circle_signature(payload: bytes, sig_header: str, secret: str) -> bool:
    """Verify Circle webhook HMAC-SHA256 signature."""
    computed = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, sig_header)


@router.post("/webhooks/circle")
async def circle_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    finality_gate: Any = Depends(get_finality_gate),
    redis: Any = Depends(get_redis),
):
    """Handle Circle webhook events (USDC transfer confirmations)."""
    _start = time.perf_counter()
    body = await request.body()
    sig_header = request.headers.get("x-circle-signature", "")

    if not settings.circle_api_key:
        log.error("Circle webhook secret not configured")
        raise HTTPException(status_code=500, detail="Webhook configuration error")

    if not sig_header:
        log.warning("Circle webhook missing signature header")
        raise HTTPException(status_code=400, detail="Missing signature")

    if not _verify_circle_signature(body, sig_header, settings.circle_api_key):
        log.warning("Circle signature verification failed")
        WEBHOOK_RECEIVED.labels(provider="circle", outcome="rejected").inc()
        raise HTTPException(status_code=400, detail="Invalid signature")

    event_data = json.loads(body)

    # Replay protection via event ID
    circle_event_id = event_data.get("id", "") or event_data.get("notificationId", "")
    if await _check_webhook_dedup(redis, "circle", circle_event_id):
        log.info("Circle webhook replay detected: event=%s", circle_event_id)
        WEBHOOK_RECEIVED.labels(provider="circle", outcome="duplicate").inc()
        return {"status": "duplicate", "event_id": circle_event_id}

    notification = event_data.get("data", event_data)
    transfer_status = (notification.get("status", "") or "").lower()
    provider_ref = notification.get("id", "")
    confirmations = notification.get("blockchain", {}).get("confirmations")
    chain_name = notification.get("blockchain", {}).get("chain", "")

    mapping = _CIRCLE_STATUS_MAP.get(transfer_status)
    if mapping is None:
        log.debug("Ignoring unhandled Circle status: %s", transfer_status)
        return {"status": "ignored", "circle_status": transfer_status}

    target_state, sonic_event_type = mapping

    record = await _load_tx_by_provider_ref(db, provider_ref)
    if record is None:
        log.warning("Circle webhook: no transaction for provider_ref=%s", provider_ref)
        return {"status": "no_match", "provider_ref": provider_ref}

    rail = "circle_usdc_solana" if "sol" in chain_name.lower() else "circle_usdc"
    finality = finality_gate.evaluate(
        rail,
        provider_confirmed=True,
        confirmations=int(confirmations) if confirmations is not None else None,
    )
    if finality == FinalityStatus.FINAL:
        target_state = TxState.RECEIVABLE_CLEARED
        sonic_event_type = EventType.RECEIVABLE_CLEARED

    result = await _advance_and_persist(
        db=db,
        record=record,
        target_state=target_state,
        provider_name="circle",
        provider_ref=provider_ref,
        emitter=emitter,
        attester=attester,
        event_type=sonic_event_type,
        extra_payload={
            "circle_status": transfer_status,
            "confirmations": confirmations,
            "chain": chain_name,
        },
    )

    # Auto-normalize if we just reached RECEIVABLE_CLEARED
    result = await _maybe_auto_normalize(
        db=db, record=record, result=result, emitter=emitter, attester=attester,
    )

    WEBHOOK_RECEIVED.labels(provider="circle", outcome="processed").inc()
    WEBHOOK_PROCESSING_DURATION.labels(provider="circle").observe(time.perf_counter() - _start)
    log.info(
        "Circle webhook processed",
        extra={"tx_id": result["tx_id"], "circle_status": transfer_status, "to_state": result["state"], "provider": "circle"},
    )
    return {"status": "processed", **result}


# ---------------------------------------------------------------------------
# Merchant webhook configuration
# ---------------------------------------------------------------------------

class WebhookRegisterRequest(BaseModel):
    url: str = Field(..., description="HTTPS URL to receive Sonic events")
    events: list[str] = Field(
        default=["payment.*", "settlement.*"],
        description="Event patterns to subscribe to",
    )


class WebhookRegisterResponse(BaseModel):
    merchant_id: str
    webhook_url: str
    events: list[str]
    status: str = "registered"


@router.post("/merchants/{merchant_id}/webhooks", response_model=WebhookRegisterResponse)
async def register_merchant_webhook(
    merchant_id: str,
    body: WebhookRegisterRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Register a webhook URL for a merchant to receive Sonic events."""
    if merchant.id != merchant_id:
        raise HTTPException(status_code=403, detail="Cannot register webhooks for another merchant")

    if not body.url.startswith("https://"):
        raise HTTPException(status_code=422, detail="Webhook URL must use HTTPS")

    # SSRF protection — block internal IP ranges
    try:
        _validate_webhook_url(body.url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    db.add(EventLog(
        tx_id=f"webhook_config_{merchant_id}",
        event_type="merchant.webhook.registered",
        merchant_id=merchant_id,
        payload={
            "url": body.url,
            "events": body.events,
        },
    ))
    await db.commit()

    log.info("Webhook registered: merchant=%s url=%s events=%s", merchant_id, body.url, body.events)

    return WebhookRegisterResponse(
        merchant_id=merchant_id,
        webhook_url=body.url,
        events=body.events,
    )
