"""Dashboard authentication — login, register, token refresh."""

from __future__ import annotations

import hashlib
import hmac
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

import jwt as pyjwt

from sonic.api.deps import get_db
from sonic.config import settings
from sonic.models.user import DashboardUser

router = APIRouter(prefix="/auth", tags=["auth"])

# --- Argon2 for password hashing ---
try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError

    _ph = PasswordHasher(time_cost=2, memory_cost=65536, parallelism=1, hash_len=32, salt_len=16)
    _ARGON2_AVAILABLE = True
except ImportError:
    _ARGON2_AVAILABLE = False


# --- Password helpers ---


def _hash_password(password: str) -> str:
    if _ARGON2_AVAILABLE:
        return _ph.hash(password)
    return hashlib.sha256(password.encode()).hexdigest()


def _verify_password(password: str, stored_hash: str) -> bool:
    if _ARGON2_AVAILABLE and stored_hash.startswith("$argon2"):
        try:
            return _ph.verify(stored_hash, password)
        except (VerifyMismatchError, VerificationError):
            return False
    provided_hash = hashlib.sha256(password.encode()).hexdigest()
    return hmac.compare_digest(provided_hash, stored_hash)


# --- JWT helpers ---


def _create_token(
    user_id: str,
    role: str,
    merchant_id: str | None,
    expires_delta: timedelta,
    *,
    token_type: str = "access",
) -> str:
    now = datetime.now(timezone.utc)
    secret = (
        settings.jwt_refresh_secret
        if token_type == "refresh"
        else settings.jwt_secret
    )
    payload = {
        "sub": user_id,
        "role": role,
        "merchant_id": merchant_id,
        "type": token_type,
        "iat": now,
        "exp": now + expires_delta,
    }
    return pyjwt.encode(payload, secret, algorithm=settings.jwt_algorithm)


# --- JWT auth dependency (used by /me and importable by other modules) ---


async def get_current_user(
    authorization: str = Header(...),
    db: AsyncSession = Depends(get_db),
) -> DashboardUser:
    """Extract and verify JWT Bearer token, return authenticated user."""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    token = authorization[7:]
    try:
        payload = pyjwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except pyjwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except pyjwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

    # Reject refresh tokens used as access tokens
    if payload.get("type") not in (None, "access"):
        raise HTTPException(status_code=401, detail="Invalid token type")

    user_id = payload.get("sub")
    result = await db.execute(select(DashboardUser).where(DashboardUser.id == user_id))
    user = result.scalar_one_or_none()

    if user is None or user.status != "active":
        raise HTTPException(status_code=401, detail="User not found or disabled")

    return user


# --- Request / response schemas ---


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str = "merchant"
    merchant_id: str | None = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserInfo(BaseModel):
    id: str
    email: str
    name: str
    role: str
    merchant_id: str | None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserInfo


class RefreshRequest(BaseModel):
    refresh_token: str


# --- Endpoints ---


@router.post("/register", response_model=TokenResponse)
async def register(body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    """Register a new dashboard user."""
    if len(body.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")

    existing = await db.execute(select(DashboardUser).where(DashboardUser.email == body.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    if body.role not in ("merchant", "admin"):
        raise HTTPException(status_code=400, detail="Role must be 'merchant' or 'admin'")

    # Admin self-registration is disabled in non-development environments
    if body.role == "admin" and settings.environment != "development":
        raise HTTPException(status_code=403, detail="Admin registration is not allowed — contact an existing admin")

    if body.role == "merchant" and not body.merchant_id:
        raise HTTPException(status_code=400, detail="merchant_id required for merchant role")

    user = DashboardUser(
        id=f"user_{uuid.uuid4().hex[:16]}",
        email=body.email,
        password_hash=_hash_password(body.password),
        name=body.name,
        role=body.role,
        merchant_id=body.merchant_id,
    )
    db.add(user)
    await db.commit()

    access_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(seconds=settings.jwt_expiry_seconds),
    )
    refresh_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(days=7),
        token_type="refresh",
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.jwt_expiry_seconds,
        user=UserInfo(
            id=user.id, email=user.email, name=user.name,
            role=user.role, merchant_id=user.merchant_id,
        ),
    )


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Authenticate with email + password, receive JWT tokens."""
    result = await db.execute(select(DashboardUser).where(DashboardUser.email == body.email))
    user = result.scalar_one_or_none()

    if user is None or not _verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if user.status != "active":
        raise HTTPException(status_code=403, detail="Account is disabled")

    access_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(seconds=settings.jwt_expiry_seconds),
    )
    refresh_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(days=7),
        token_type="refresh",
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.jwt_expiry_seconds,
        user=UserInfo(
            id=user.id, email=user.email, name=user.name,
            role=user.role, merchant_id=user.merchant_id,
        ),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    """Exchange a refresh token for a new access + refresh token pair."""
    try:
        payload = pyjwt.decode(
            body.refresh_token, settings.jwt_refresh_secret, algorithms=[settings.jwt_algorithm]
        )
    except pyjwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Refresh token expired")
    except pyjwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Not a refresh token")

    user_id = payload.get("sub")
    result = await db.execute(select(DashboardUser).where(DashboardUser.id == user_id))
    user = result.scalar_one_or_none()

    if user is None or user.status != "active":
        raise HTTPException(status_code=401, detail="User not found or disabled")

    access_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(seconds=settings.jwt_expiry_seconds),
    )
    refresh_token = _create_token(
        user.id, user.role, user.merchant_id,
        timedelta(days=7),
        token_type="refresh",
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.jwt_expiry_seconds,
        user=UserInfo(
            id=user.id, email=user.email, name=user.name,
            role=user.role, merchant_id=user.merchant_id,
        ),
    )


@router.get("/me", response_model=UserInfo)
async def me(user: DashboardUser = Depends(get_current_user)):
    """Return the currently authenticated dashboard user."""
    return UserInfo(
        id=user.id, email=user.email, name=user.name,
        role=user.role, merchant_id=user.merchant_id,
    )
