"""API key management — rotate, revoke, list keys, view usage."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db, get_merchant
from sonic.api.middleware.auth import generate_api_key
from sonic.config import settings
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant

router = APIRouter()


class ApiKeyInfo(BaseModel):
    prefix: str
    status: str  # active | grace_period | revoked
    created_hint: str  # "Current key" or "Previous key (grace period)"
    grace_period_expires: str | None = None


class ApiKeyListResponse(BaseModel):
    merchant_id: str
    keys: list[ApiKeyInfo]


class ApiKeyRotateResponse(BaseModel):
    merchant_id: str
    new_api_key: str
    new_api_key_prefix: str
    grace_period_hours: int
    previous_key_valid_until: str


class ApiKeyRevokeResponse(BaseModel):
    merchant_id: str
    message: str


class ApiKeyUsageResponse(BaseModel):
    merchant_id: str
    total_requests_24h: int
    total_requests_7d: int
    last_used: str | None = None


@router.get("/merchants/me/api-keys", response_model=ApiKeyListResponse)
async def list_api_keys(
    merchant: Merchant = Depends(get_merchant),
):
    """List active API keys for the authenticated merchant."""
    keys = []

    # Current key
    keys.append(ApiKeyInfo(
        prefix=merchant.api_key_prefix,
        status="active",
        created_hint="Current key",
    ))

    # Previous key (if in grace period)
    if merchant.prev_api_key_hash and merchant.key_rotated_at:
        grace_end = merchant.key_rotated_at + timedelta(hours=settings.api_key_rotation_grace_hours)
        now = datetime.now(timezone.utc)
        if now <= grace_end:
            keys.append(ApiKeyInfo(
                prefix=merchant.prev_api_key_prefix or "unknown",
                status="grace_period",
                created_hint="Previous key (grace period)",
                grace_period_expires=grace_end.isoformat(),
            ))

    return ApiKeyListResponse(merchant_id=merchant.id, keys=keys)


@router.post("/merchants/me/api-keys/rotate", response_model=ApiKeyRotateResponse)
async def rotate_api_key(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Rotate the merchant's API key.

    Generates a new key. The current key moves to grace period
    and remains valid for the configured duration (default 72h).
    The new key is returned exactly once.
    """
    new_key, new_hash = generate_api_key()

    # Move current key to previous (grace period)
    merchant.prev_api_key_hash = merchant.api_key_hash
    merchant.prev_api_key_prefix = merchant.api_key_prefix
    merchant.key_rotated_at = datetime.now(timezone.utc)

    # Install new key
    merchant.api_key_hash = new_hash
    merchant.api_key_prefix = new_key[:20]

    # Log the rotation event
    db.add(EventLog(
        tx_id=f"key_rotation_{merchant.id}",
        event_type="merchant.api_key.rotated",
        merchant_id=merchant.id,
        payload={"new_prefix": new_key[:20]},
    ))

    await db.commit()

    grace_until = merchant.key_rotated_at + timedelta(hours=settings.api_key_rotation_grace_hours)

    return ApiKeyRotateResponse(
        merchant_id=merchant.id,
        new_api_key=new_key,
        new_api_key_prefix=new_key[:20],
        grace_period_hours=settings.api_key_rotation_grace_hours,
        previous_key_valid_until=grace_until.isoformat(),
    )


@router.post("/merchants/me/api-keys/revoke", response_model=ApiKeyRevokeResponse)
async def revoke_previous_key(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Immediately revoke the previous API key (end grace period early)."""
    if not merchant.prev_api_key_hash:
        raise HTTPException(status_code=404, detail="No previous key to revoke")

    merchant.prev_api_key_hash = None
    merchant.prev_api_key_prefix = None
    merchant.key_rotated_at = None

    db.add(EventLog(
        tx_id=f"key_revoke_{merchant.id}",
        event_type="merchant.api_key.revoked",
        merchant_id=merchant.id,
    ))

    await db.commit()

    return ApiKeyRevokeResponse(
        merchant_id=merchant.id,
        message="Previous key revoked immediately",
    )


@router.get("/merchants/me/api-keys/usage", response_model=ApiKeyUsageResponse)
async def get_api_key_usage(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Get API key usage statistics for the merchant."""
    now = datetime.now(timezone.utc)

    # Count events in last 24h
    result_24h = await db.execute(
        select(func.count())
        .select_from(EventLog)
        .where(
            EventLog.merchant_id == merchant.id,
            EventLog.timestamp >= now - timedelta(hours=24),
        )
    )
    total_24h = result_24h.scalar_one()

    # Count events in last 7 days
    result_7d = await db.execute(
        select(func.count())
        .select_from(EventLog)
        .where(
            EventLog.merchant_id == merchant.id,
            EventLog.timestamp >= now - timedelta(days=7),
        )
    )
    total_7d = result_7d.scalar_one()

    # Last event timestamp
    result_last = await db.execute(
        select(EventLog.timestamp)
        .where(EventLog.merchant_id == merchant.id)
        .order_by(EventLog.timestamp.desc())
        .limit(1)
    )
    last_ts = result_last.scalar_one_or_none()

    return ApiKeyUsageResponse(
        merchant_id=merchant.id,
        total_requests_24h=total_24h,
        total_requests_7d=total_7d,
        last_used=last_ts.isoformat() if last_ts else None,
    )
