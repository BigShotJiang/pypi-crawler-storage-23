"""Phase 4.3 — FX quote locking: hold a rate for N minutes before execution."""

from __future__ import annotations

import secrets
import time
from datetime import datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from sonic.api.deps import get_merchant
from sonic.models.merchant import Merchant

router = APIRouter()

# In-memory quote store (production would use Redis with TTL)
_fx_quotes: dict[str, dict] = {}

# Simulated FX rates (production would call a real FX provider)
_FX_RATES: dict[str, Decimal] = {
    "USD/USDC": Decimal("1.000"),
    "USDC/USD": Decimal("1.000"),
    "EUR/USDC": Decimal("1.080"),
    "USDC/EUR": Decimal("0.926"),
    "GBP/USDC": Decimal("1.260"),
    "USDC/GBP": Decimal("0.794"),
    "USD/EUR": Decimal("0.926"),
    "EUR/USD": Decimal("1.080"),
    "USD/GBP": Decimal("0.794"),
    "GBP/USD": Decimal("1.260"),
}


class FxQuoteRequest(BaseModel):
    from_currency: str = Field(..., max_length=4)
    to_currency: str = Field(..., max_length=4)
    amount: Decimal = Field(..., gt=0)
    lock_seconds: int = Field(default=300, ge=30, le=1800, description="Seconds to hold the quote (30s-30min)")


class FxQuoteResponse(BaseModel):
    quote_id: str
    from_currency: str
    to_currency: str
    from_amount: str
    to_amount: str
    rate: str
    locked_until: str
    merchant_id: str


class FxExecuteRequest(BaseModel):
    quote_id: str


class FxExecuteResponse(BaseModel):
    quote_id: str
    status: str
    from_amount: str
    to_amount: str
    rate: str
    executed_at: str


@router.post("/fx/quote", response_model=FxQuoteResponse)
async def create_fx_quote(
    body: FxQuoteRequest,
    merchant: Merchant = Depends(get_merchant),
):
    """Request an FX quote with rate locking.

    The quoted rate is held for the specified duration (default 5 minutes).
    Execute the quote before it expires to guarantee the rate.
    """
    pair = f"{body.from_currency}/{body.to_currency}"
    rate = _FX_RATES.get(pair)
    if rate is None:
        raise HTTPException(status_code=400, detail=f"Unsupported currency pair: {pair}")

    to_amount = body.amount * rate
    quote_id = f"fxq_{secrets.token_urlsafe(16)}"
    locked_until = time.time() + body.lock_seconds

    _fx_quotes[quote_id] = {
        "merchant_id": merchant.id,
        "from_currency": body.from_currency,
        "to_currency": body.to_currency,
        "from_amount": body.amount,
        "to_amount": to_amount,
        "rate": rate,
        "locked_until": locked_until,
        "executed": False,
    }

    return FxQuoteResponse(
        quote_id=quote_id,
        from_currency=body.from_currency,
        to_currency=body.to_currency,
        from_amount=str(body.amount),
        to_amount=str(to_amount.quantize(Decimal("0.000001"))),
        rate=str(rate),
        locked_until=datetime.fromtimestamp(locked_until, tz=timezone.utc).isoformat(),
        merchant_id=merchant.id,
    )


@router.post("/fx/execute", response_model=FxExecuteResponse)
async def execute_fx_quote(
    body: FxExecuteRequest,
    merchant: Merchant = Depends(get_merchant),
):
    """Execute a previously locked FX quote."""
    quote = _fx_quotes.get(body.quote_id)
    if not quote:
        raise HTTPException(status_code=404, detail="Quote not found")
    if quote["merchant_id"] != merchant.id:
        raise HTTPException(status_code=403, detail="Quote belongs to another merchant")
    if quote["executed"]:
        raise HTTPException(status_code=400, detail="Quote already executed")
    if time.time() > quote["locked_until"]:
        raise HTTPException(status_code=410, detail="Quote expired — request a new quote")

    quote["executed"] = True

    return FxExecuteResponse(
        quote_id=body.quote_id,
        status="executed",
        from_amount=str(quote["from_amount"]),
        to_amount=str(quote["to_amount"].quantize(Decimal("0.000001"))),
        rate=str(quote["rate"]),
        executed_at=datetime.now(timezone.utc).isoformat(),
    )
