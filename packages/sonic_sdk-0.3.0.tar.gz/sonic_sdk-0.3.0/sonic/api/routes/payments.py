"""Payment endpoints — accept inbound payments."""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant, get_emitter, get_attester, get_idempotency
from sonic.core.engine import Transaction, TxState
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.metrics import TX_CREATED
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

log = logging.getLogger("sonic.payments")

router = APIRouter()


class PaymentRequest(BaseModel):
    amount: Decimal = Field(..., gt=0, description="Payment amount")
    currency: str = Field(..., min_length=3, max_length=4, description="ISO currency code")
    rail: str = Field(default="stripe_card", description="Payment rail")
    customer_ref: str | None = Field(default=None, description="Customer-facing reference")
    idempotency_key: str = Field(..., description="Client-provided idempotency key")
    metadata: dict | None = None


class PaymentResponse(BaseModel):
    tx_id: str
    status: str
    receipt_hash: str | None = None
    message: str = "Payment initiated"


@router.post("/payments", response_model=PaymentResponse, status_code=201)
async def create_payment(
    body: PaymentRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    idempotency_store: Any = Depends(get_idempotency),
):
    """Accept an inbound payment.

    Creates a transaction, advances through INITIATED -> RECEIVABLE_DETECTED,
    builds the first receipt in the chain, and returns a tx_id for tracking.

    Provider capture (Stripe charge, Circle transfer, etc.) runs async --
    the webhook callback advances the state machine further.
    """
    # Idempotency check -- return cached response if this key was already processed
    if idempotency_store is not None:
        cached = await idempotency_store.check(body.idempotency_key)
        if cached is not None:
            return PaymentResponse(**cached)

    # Build in-memory transaction and advance state machine
    tx = Transaction(
        tx_id="",  # Will use DB-generated ID
        merchant_id=merchant.id,
        inbound_amount=body.amount,
        inbound_currency=body.currency.upper(),
        inbound_rail=body.rail,
    )

    # Persist the transaction record
    record = TransactionRecord(
        merchant_id=merchant.id,
        state=TxState.INITIATED.value,
        inbound_amount=body.amount,
        inbound_currency=body.currency.upper(),
        inbound_rail=body.rail,
        customer_ref=body.customer_ref,
        idempotency_key=body.idempotency_key,
    )
    db.add(record)
    await db.flush()  # Get the generated tx_id

    # Advance: INITIATED -> RECEIVABLE_DETECTED
    tx.tx_id = record.id
    event = tx.advance(
        TxState.RECEIVABLE_DETECTED,
        amount=body.amount,
        currency=body.currency.upper(),
        rail=body.rail,
        idempotency_key=body.idempotency_key,
    )

    record.state = TxState.RECEIVABLE_DETECTED.value
    record.sequence = tx.sequence

    # Build receipt for this event
    chain = ReceiptChain()
    receipt = chain.build(event, merchant_id=merchant.id, direction="inbound")

    receipt_record = ReceiptRecord(
        receipt_id=receipt.receipt_id,
        tx_id=record.id,
        event_type=receipt.event_type,
        sequence=receipt.sequence,
        amount=receipt.amount,
        currency=receipt.currency,
        rail=receipt.rail,
        direction=receipt.direction,
        receipt_hash=receipt.receipt_hash,
        prev_receipt_hash=receipt.prev_receipt_hash,
        idempotency_key=receipt.idempotency_key,
        merchant_id=merchant.id,
    )
    db.add(receipt_record)

    # Append to audit log
    db.add(EventLog(
        tx_id=record.id,
        event_type=EventType.RECEIVABLE_DETECTED.value,
        from_state=TxState.INITIATED.value,
        to_state=TxState.RECEIVABLE_DETECTED.value,
        merchant_id=merchant.id,
        provider=body.rail.split("_")[0],
        idempotency_key=body.idempotency_key,
        receipt_hash=receipt.receipt_hash,
        payload={
            "amount": str(body.amount),
            "currency": body.currency.upper(),
            "rail": body.rail,
        },
    ))

    await db.commit()
    await db.refresh(record)

    TX_CREATED.labels(rail=body.rail, currency=body.currency.upper()).inc()
    log.info(
        "Payment created: tx=%s merchant=%s amount=%s %s via %s",
        record.id, merchant.id, body.amount, body.currency, body.rail,
    )

    # Enqueue SBN attestation (non-blocking)
    if attester is not None:
        try:
            await attester.enqueue(receipt)
        except Exception:
            log.warning("SBN attestation enqueue failed for receipt %s", receipt.receipt_id, exc_info=True)

    # Emit event to internal bus (non-blocking)
    try:
        await emitter.emit(EventType.RECEIVABLE_DETECTED, {
            "tx_id": record.id,
            "merchant_id": merchant.id,
            "amount": str(body.amount),
            "currency": body.currency.upper(),
            "rail": body.rail,
            "receipt_hash": receipt.receipt_hash,
        })
    except Exception:
        log.warning("Event emission failed for tx %s", record.id, exc_info=True)

    response_data = {
        "tx_id": record.id,
        "status": record.state,
        "receipt_hash": receipt.receipt_hash,
        "message": "Payment initiated -- awaiting provider confirmation",
    }

    # Cache the response for idempotency
    if idempotency_store is not None:
        try:
            await idempotency_store.store(body.idempotency_key, response_data)
        except Exception:
            log.warning("Idempotency store failed for key %s", body.idempotency_key, exc_info=True)

    return PaymentResponse(**response_data)
