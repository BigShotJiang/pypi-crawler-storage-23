"""Merchant onboarding and management endpoints."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant as get_merchant_dep
from sonic.api.middleware.auth import generate_api_key
from sonic.models.merchant import Merchant

router = APIRouter()


class MerchantCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    email: str
    business_type: str = Field(default="smb", description="smb | enterprise")
    default_payout_currency: str = Field(default="USD")
    default_payout_rail: str = Field(default="stripe_card")
    metadata: dict | None = None


class MerchantResponse(BaseModel):
    merchant_id: str
    name: str
    email: str
    business_type: str
    default_payout_currency: str
    default_payout_rail: str
    anchor_chain: str | None = None
    hedera_topic_id: str | None = None
    solana_program_id: str | None = None
    api_key_prefix: str | None = None
    api_key: str | None = None  # Only returned on creation
    status: str = "active"


class MerchantUpdateRequest(BaseModel):
    default_payout_currency: Optional[str] = None
    default_payout_rail: Optional[str] = None
    anchor_chain: Optional[str] = None
    hedera_topic_id: Optional[str] = None
    solana_program_id: Optional[str] = None


def _merchant_to_response(merchant: Merchant, api_key: str | None = None) -> MerchantResponse:
    return MerchantResponse(
        merchant_id=merchant.id,
        name=merchant.name,
        email=merchant.email,
        business_type=merchant.business_type,
        default_payout_currency=merchant.default_payout_currency,
        default_payout_rail=merchant.default_payout_rail,
        anchor_chain=merchant.anchor_chain,
        hedera_topic_id=merchant.hedera_topic_id,
        solana_program_id=merchant.solana_program_id,
        api_key_prefix=merchant.api_key_prefix,
        api_key=api_key,
        status=merchant.status,
    )


@router.post("/merchants", response_model=MerchantResponse, status_code=201)
async def create_merchant(
    body: MerchantCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Onboard a new merchant.

    Returns the API key exactly once — callers must store it.
    Sonic only persists the hash.
    """
    existing = await db.execute(
        select(Merchant).where(Merchant.email == body.email, Merchant.deleted_at.is_(None))
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Merchant with this email already exists")

    full_key, key_hash = generate_api_key(
        test=(body.metadata or {}).get("test", False),
    )

    merchant = Merchant(
        name=body.name,
        email=body.email,
        business_type=body.business_type,
        default_payout_currency=body.default_payout_currency,
        default_payout_rail=body.default_payout_rail,
        api_key_hash=key_hash,
        api_key_prefix=full_key[:20],
    )

    db.add(merchant)
    await db.commit()
    await db.refresh(merchant)

    return _merchant_to_response(merchant, api_key=full_key)


@router.get("/merchants/me", response_model=MerchantResponse)
async def get_own_merchant(
    merchant: Merchant = Depends(get_merchant_dep),
):
    """Get the authenticated merchant's own details."""
    return _merchant_to_response(merchant)


@router.patch("/merchants/me", response_model=MerchantResponse)
async def update_own_merchant(
    body: MerchantUpdateRequest,
    merchant: Merchant = Depends(get_merchant_dep),
    db: AsyncSession = Depends(get_db),
):
    """Update the authenticated merchant's settings."""
    updates = body.model_dump(exclude_unset=True)

    if "anchor_chain" in updates and updates["anchor_chain"] not in (None, "hedera", "solana"):
        raise HTTPException(status_code=400, detail="anchor_chain must be 'hedera', 'solana', or null")

    for field, value in updates.items():
        setattr(merchant, field, value)

    await db.commit()
    await db.refresh(merchant)

    return _merchant_to_response(merchant)


class KeyRotationResponse(BaseModel):
    merchant_id: str
    new_api_key: str
    new_api_key_prefix: str
    grace_period_hours: int
    previous_key_valid_until: str


class IpAllowlistRequest(BaseModel):
    cidrs: list[str] = Field(
        ...,
        description="List of CIDR ranges (e.g. ['10.0.0.0/8', '203.0.113.5/32']). Empty list disables.",
        max_length=20,
    )


class IpAllowlistResponse(BaseModel):
    merchant_id: str
    ip_allowlist: list[str]


@router.post("/merchants/me/rotate-key", response_model=KeyRotationResponse)
async def rotate_api_key(
    merchant: Merchant = Depends(get_merchant_dep),
    db: AsyncSession = Depends(get_db),
):
    """Rotate the merchant's API key.

    Generates a new key and moves the current key to prev_api_key_hash
    with a configurable grace period (default 72h). During the grace period,
    both the old and new keys are accepted.

    The new key is returned exactly once — callers must store it.
    """
    from sonic.config import settings

    new_key, new_hash = generate_api_key()

    # Move current key to previous (grace period)
    merchant.prev_api_key_hash = merchant.api_key_hash
    merchant.key_rotated_at = datetime.now(timezone.utc)

    # Install new key
    merchant.api_key_hash = new_hash
    merchant.api_key_prefix = new_key[:20]

    await db.commit()

    from datetime import timedelta
    grace_until = merchant.key_rotated_at + timedelta(hours=settings.api_key_rotation_grace_hours)

    return KeyRotationResponse(
        merchant_id=merchant.id,
        new_api_key=new_key,
        new_api_key_prefix=new_key[:20],
        grace_period_hours=settings.api_key_rotation_grace_hours,
        previous_key_valid_until=grace_until.isoformat(),
    )


@router.put("/merchants/me/ip-allowlist", response_model=IpAllowlistResponse)
async def set_ip_allowlist(
    body: IpAllowlistRequest,
    merchant: Merchant = Depends(get_merchant_dep),
    db: AsyncSession = Depends(get_db),
):
    """Set IP allowlist for API key authentication.

    When set, API key requests from IPs not in the allowlist are rejected.
    Pass an empty list to disable the allowlist.
    """
    import ipaddress

    # Validate each CIDR
    for cidr in body.cidrs:
        try:
            ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            raise HTTPException(
                status_code=422,
                detail=f"Invalid CIDR: {cidr}",
            )

    merchant.ip_allowlist = ",".join(body.cidrs) if body.cidrs else None
    await db.commit()

    return IpAllowlistResponse(
        merchant_id=merchant.id,
        ip_allowlist=body.cidrs,
    )


@router.get("/merchants/{merchant_id}", response_model=MerchantResponse)
async def get_merchant(
    merchant_id: str,
    caller: Merchant = Depends(get_merchant_dep),
    db: AsyncSession = Depends(get_db),
):
    """Get merchant details (authenticated — merchants can only view their own profile)."""
    if caller.id != merchant_id:
        raise HTTPException(status_code=403, detail="Cannot view another merchant's details")

    return _merchant_to_response(caller)


class MerchantDeleteResponse(BaseModel):
    merchant_id: str
    status: str
    deleted_at: str


@router.delete("/merchants/me", response_model=MerchantDeleteResponse)
async def soft_delete_merchant(
    merchant: Merchant = Depends(get_merchant_dep),
    db: AsyncSession = Depends(get_db),
):
    """Soft-delete the authenticated merchant.

    Sets deleted_at and status to 'deleted'. The merchant record is preserved
    for audit trails and receipt chain integrity, but API key auth will be
    rejected for soft-deleted merchants.
    """
    now = datetime.now(timezone.utc)
    merchant.deleted_at = now
    merchant.status = "deleted"
    await db.commit()

    return MerchantDeleteResponse(
        merchant_id=merchant.id,
        status="deleted",
        deleted_at=now.isoformat(),
    )
