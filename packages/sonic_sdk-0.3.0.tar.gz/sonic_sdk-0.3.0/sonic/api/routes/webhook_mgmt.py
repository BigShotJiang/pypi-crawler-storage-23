"""Webhook management — CRUD for merchant webhook endpoints, delivery history, replay."""

from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db, get_merchant
from sonic.api.routes.webhooks import _validate_webhook_url
from sonic.models.merchant import Merchant
from sonic.models.webhook_endpoint import WebhookDelivery, WebhookEndpoint

router = APIRouter()


# --- Schemas ---


class WebhookEndpointCreate(BaseModel):
    url: str = Field(..., description="HTTPS URL to receive Sonic events")
    description: str | None = Field(default=None, max_length=255)
    events: list[str] = Field(
        default=["*"],
        description="Event patterns to subscribe to (e.g. 'payment.*', 'payout.executed')",
    )


class WebhookEndpointUpdate(BaseModel):
    url: str | None = None
    description: str | None = None
    events: list[str] | None = None
    status: str | None = Field(default=None, pattern="^(active|paused)$")


class WebhookEndpointResponse(BaseModel):
    id: str
    merchant_id: str
    url: str
    description: str | None
    events: list[str]
    status: str
    secret: str | None = None  # Only returned on creation
    created_at: str
    updated_at: str


class WebhookEndpointListResponse(BaseModel):
    endpoints: list[WebhookEndpointResponse]
    total: int


class WebhookDeliveryResponse(BaseModel):
    id: str
    endpoint_id: str
    event_type: str
    status: str
    status_code: int | None
    attempts: int
    created_at: str
    last_attempt_at: str | None


class WebhookDeliveryListResponse(BaseModel):
    deliveries: list[WebhookDeliveryResponse]
    total: int
    has_more: bool


class WebhookReplayResponse(BaseModel):
    delivery_id: str
    status: str
    message: str


# --- Helpers ---


def _endpoint_to_response(ep: WebhookEndpoint, include_secret: bool = False) -> WebhookEndpointResponse:
    return WebhookEndpointResponse(
        id=ep.id,
        merchant_id=ep.merchant_id,
        url=ep.url,
        description=ep.description,
        events=ep.events.split(",") if ep.events else ["*"],
        status=ep.status,
        secret=ep.secret if include_secret else None,
        created_at=ep.created_at.isoformat(),
        updated_at=ep.updated_at.isoformat(),
    )


# --- Endpoints ---


@router.post("/merchants/me/webhooks", response_model=WebhookEndpointResponse, status_code=201)
async def create_webhook_endpoint(
    body: WebhookEndpointCreate,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Create a new webhook endpoint for the merchant."""
    if not body.url.startswith("https://"):
        raise HTTPException(status_code=422, detail="Webhook URL must use HTTPS")

    try:
        _validate_webhook_url(body.url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    # Limit endpoints per merchant
    count_result = await db.execute(
        select(func.count())
        .select_from(WebhookEndpoint)
        .where(
            WebhookEndpoint.merchant_id == merchant.id,
            WebhookEndpoint.status != "disabled",
        )
    )
    if count_result.scalar_one() >= 10:
        raise HTTPException(status_code=400, detail="Maximum 10 webhook endpoints per merchant")

    signing_secret = f"whsec_{secrets.token_urlsafe(32)}"

    endpoint = WebhookEndpoint(
        merchant_id=merchant.id,
        url=body.url,
        description=body.description,
        events=",".join(body.events),
        secret=signing_secret,
    )
    db.add(endpoint)
    await db.commit()
    await db.refresh(endpoint)

    return _endpoint_to_response(endpoint, include_secret=True)


@router.get("/merchants/me/webhooks", response_model=WebhookEndpointListResponse)
async def list_webhook_endpoints(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """List all webhook endpoints for the merchant."""
    result = await db.execute(
        select(WebhookEndpoint)
        .where(
            WebhookEndpoint.merchant_id == merchant.id,
            WebhookEndpoint.status != "disabled",
        )
        .order_by(WebhookEndpoint.created_at.desc())
    )
    endpoints = result.scalars().all()

    return WebhookEndpointListResponse(
        endpoints=[_endpoint_to_response(ep) for ep in endpoints],
        total=len(endpoints),
    )


@router.get("/merchants/me/webhooks/{endpoint_id}", response_model=WebhookEndpointResponse)
async def get_webhook_endpoint(
    endpoint_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Get a specific webhook endpoint."""
    result = await db.execute(
        select(WebhookEndpoint).where(
            WebhookEndpoint.id == endpoint_id,
            WebhookEndpoint.merchant_id == merchant.id,
        )
    )
    endpoint = result.scalar_one_or_none()
    if not endpoint:
        raise HTTPException(status_code=404, detail="Webhook endpoint not found")

    return _endpoint_to_response(endpoint)


@router.patch("/merchants/me/webhooks/{endpoint_id}", response_model=WebhookEndpointResponse)
async def update_webhook_endpoint(
    endpoint_id: str,
    body: WebhookEndpointUpdate,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Update a webhook endpoint."""
    result = await db.execute(
        select(WebhookEndpoint).where(
            WebhookEndpoint.id == endpoint_id,
            WebhookEndpoint.merchant_id == merchant.id,
        )
    )
    endpoint = result.scalar_one_or_none()
    if not endpoint:
        raise HTTPException(status_code=404, detail="Webhook endpoint not found")

    if body.url is not None:
        if not body.url.startswith("https://"):
            raise HTTPException(status_code=422, detail="Webhook URL must use HTTPS")
        try:
            _validate_webhook_url(body.url)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
        endpoint.url = body.url

    if body.description is not None:
        endpoint.description = body.description
    if body.events is not None:
        endpoint.events = ",".join(body.events)
    if body.status is not None:
        endpoint.status = body.status

    await db.commit()
    await db.refresh(endpoint)

    return _endpoint_to_response(endpoint)


@router.delete("/merchants/me/webhooks/{endpoint_id}")
async def delete_webhook_endpoint(
    endpoint_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Delete (disable) a webhook endpoint."""
    result = await db.execute(
        select(WebhookEndpoint).where(
            WebhookEndpoint.id == endpoint_id,
            WebhookEndpoint.merchant_id == merchant.id,
        )
    )
    endpoint = result.scalar_one_or_none()
    if not endpoint:
        raise HTTPException(status_code=404, detail="Webhook endpoint not found")

    endpoint.status = "disabled"
    await db.commit()

    return {"status": "deleted", "id": endpoint_id}


@router.get("/merchants/me/webhooks/{endpoint_id}/deliveries", response_model=WebhookDeliveryListResponse)
async def list_webhook_deliveries(
    endpoint_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    status: Optional[str] = Query(default=None),
):
    """List delivery history for a webhook endpoint."""
    # Verify ownership
    ep_result = await db.execute(
        select(WebhookEndpoint.id).where(
            WebhookEndpoint.id == endpoint_id,
            WebhookEndpoint.merchant_id == merchant.id,
        )
    )
    if not ep_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Webhook endpoint not found")

    query = select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint_id)
    count_query = select(func.count()).select_from(WebhookDelivery).where(
        WebhookDelivery.endpoint_id == endpoint_id
    )

    if status:
        query = query.where(WebhookDelivery.status == status)
        count_query = count_query.where(WebhookDelivery.status == status)

    total = (await db.execute(count_query)).scalar_one()

    result = await db.execute(
        query.order_by(WebhookDelivery.created_at.desc()).offset(offset).limit(limit)
    )
    deliveries = result.scalars().all()

    return WebhookDeliveryListResponse(
        deliveries=[
            WebhookDeliveryResponse(
                id=d.id,
                endpoint_id=d.endpoint_id,
                event_type=d.event_type,
                status=d.status,
                status_code=d.status_code,
                attempts=d.attempts,
                created_at=d.created_at.isoformat(),
                last_attempt_at=d.last_attempt_at.isoformat() if d.last_attempt_at else None,
            )
            for d in deliveries
        ],
        total=total,
        has_more=(offset + limit) < total,
    )


@router.post("/merchants/me/webhooks/deliveries/{delivery_id}/replay", response_model=WebhookReplayResponse)
async def replay_webhook_delivery(
    delivery_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Replay a failed webhook delivery."""
    result = await db.execute(
        select(WebhookDelivery).where(
            WebhookDelivery.id == delivery_id,
            WebhookDelivery.merchant_id == merchant.id,
        )
    )
    delivery = result.scalar_one_or_none()
    if not delivery:
        raise HTTPException(status_code=404, detail="Webhook delivery not found")

    if delivery.status == "delivered":
        raise HTTPException(status_code=400, detail="Delivery already succeeded — no replay needed")

    # Reset for retry
    delivery.status = "pending"
    delivery.attempts = 0
    delivery.last_attempt_at = None
    await db.commit()

    return WebhookReplayResponse(
        delivery_id=delivery_id,
        status="queued",
        message="Delivery queued for replay",
    )
