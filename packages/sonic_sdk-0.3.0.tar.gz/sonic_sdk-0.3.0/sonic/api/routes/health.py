"""Health, metrics, and version endpoints."""

from __future__ import annotations

import asyncio
import logging
import platform
from datetime import datetime, timezone

from fastapi import APIRouter, Request
from fastapi.responses import PlainTextResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from sqlalchemy import text

from sonic._version import __version__
from sonic.models.base import async_session_factory

logger = logging.getLogger("sonic.health")

router = APIRouter()

# Max seconds to wait for each component check before reporting it as timed-out.
_CHECK_TIMEOUT = 3.0


@router.get("/health")
async def health_check():
    """Liveness probe — always returns ok if the process is running."""
    return {"status": "ok", "service": "sonic"}


@router.get("/health/version")
async def version_info():
    """Return build/version metadata for the running instance."""
    return {
        "service": "sonic",
        "version": __version__,
        "python": platform.python_version(),
        "started_at": _STARTED_AT,
    }


_STARTED_AT = datetime.now(timezone.utc).isoformat()


@router.get("/metrics", include_in_schema=False)
async def metrics_endpoint():
    """Prometheus metrics scrape endpoint."""
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@router.get("/health/ready")
async def readiness_check(request: Request):
    """Readiness probe — checks database, Redis, SBN, providers, and queues.

    Each component check is bounded by a timeout so that a single slow
    dependency cannot block the probe indefinitely.
    """
    components: dict[str, str] = {}
    queues: dict[str, int] = {}

    # Database
    try:
        async with asyncio.timeout(_CHECK_TIMEOUT):
            async with async_session_factory() as session:
                await session.execute(text("SELECT 1"))
        components["database"] = "ok"
    except TimeoutError:
        logger.warning("Health: database check timed out (%.1fs)", _CHECK_TIMEOUT)
        components["database"] = "timeout"
    except Exception as exc:
        logger.warning("Health: database check failed: %s", exc)
        components["database"] = "unavailable"

    # Redis
    redis = getattr(request.app.state, "redis", None)
    if redis is not None:
        try:
            async with asyncio.timeout(_CHECK_TIMEOUT):
                await redis.ping()
            components["redis"] = "ok"
        except TimeoutError:
            logger.warning("Health: redis check timed out (%.1fs)", _CHECK_TIMEOUT)
            components["redis"] = "timeout"
        except Exception as exc:
            logger.warning("Health: redis check failed: %s", exc)
            components["redis"] = "unavailable"
    else:
        components["redis"] = "not_configured"

    # SBN
    sbn = getattr(request.app.state, "sbn", None)
    if sbn is not None and sbn.active:
        try:
            async with asyncio.timeout(_CHECK_TIMEOUT):
                healthy = await sbn.health()
            components["sbn"] = "ok" if healthy else "degraded"
        except TimeoutError:
            logger.warning("Health: SBN check timed out (%.1fs)", _CHECK_TIMEOUT)
            components["sbn"] = "timeout"
        except Exception:
            components["sbn"] = "degraded"
    else:
        components["sbn"] = "not_configured"

    # Per-provider health
    providers = getattr(request.app.state, "providers", {})
    provider_status: dict[str, str] = {}
    seen_providers: dict[int, str] = {}  # pid -> status from first check
    for rail, provider in providers.items():
        # Skip duplicate provider objects (e.g. stripe_card and stripe_ach share an instance)
        pid = id(provider)
        if pid in seen_providers:
            provider_status[rail] = seen_providers[pid]
            continue
        try:
            async with asyncio.timeout(_CHECK_TIMEOUT):
                healthy = await provider.health()
            status = "ok" if healthy else "degraded"
        except TimeoutError:
            status = "timeout"
        except Exception:
            status = "unavailable"
        seen_providers[pid] = status
        provider_status[rail] = status
    if provider_status:
        components["providers"] = (
            "ok" if all(v == "ok" for v in provider_status.values()) else "degraded"
        )

    # SBN attestation queue depth
    attester = getattr(request.app.state, "attester", None)
    if attester is not None:
        try:
            queues["sbn_attestation"] = await attester.queue_depth()
            queues["sbn_dlq"] = await attester.dlq_depth()
        except Exception:
            pass

    # Anchor queue depth
    anchor_service = getattr(request.app.state, "anchor_service", None)
    if anchor_service is not None:
        try:
            queues["anchor"] = await anchor_service.queue_depth()
        except Exception:
            pass

    # Float guard health
    float_guard = getattr(request.app.state, "float_guard", None)
    if float_guard is not None:
        try:
            async with asyncio.timeout(_CHECK_TIMEOUT):
                fh = await float_guard.get_float_health()
            components["float_guard"] = fh.get("status", "unknown")
            queues["float_committed"] = fh.get("total_committed", 0)
        except TimeoutError:
            components["float_guard"] = "timeout"
        except Exception:
            components["float_guard"] = "unavailable"

    all_ok = all(v in ("ok", "not_configured", "healthy") for v in components.values())
    result: dict = {
        "status": "ok" if all_ok else "degraded",
        "components": components,
    }
    if provider_status:
        result["providers"] = provider_status
    if queues:
        result["queues"] = queues
    return result
