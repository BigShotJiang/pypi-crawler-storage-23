"""Self-service merchant registration — combined merchant + dashboard user creation."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db
from sonic.api.middleware.auth import generate_api_key
from sonic.api.routes.auth import _hash_password, _create_token
from sonic.config import settings
from sonic.models.merchant import Merchant
from sonic.models.user import DashboardUser

router = APIRouter(prefix="/register", tags=["registration"])


class MerchantRegistrationRequest(BaseModel):
    """Self-service merchant registration: creates merchant account + dashboard user."""
    business_name: str = Field(..., min_length=1, max_length=255)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    contact_name: str = Field(..., min_length=1, max_length=255)
    business_type: str = Field(default="smb", pattern="^(smb|enterprise)$")


class MerchantRegistrationResponse(BaseModel):
    merchant_id: str
    user_id: str
    email: str
    business_name: str
    api_key: str
    api_key_prefix: str
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


@router.post("/merchant", response_model=MerchantRegistrationResponse, status_code=201)
async def register_merchant(
    body: MerchantRegistrationRequest,
    db: AsyncSession = Depends(get_db),
):
    """Self-service merchant registration.

    Creates both a merchant account and a dashboard user in a single
    atomic operation. Returns an API key (shown once) and JWT tokens
    for immediate dashboard access.
    """
    # Check for existing merchant with same email
    existing_merchant = await db.execute(
        select(Merchant).where(Merchant.email == body.email, Merchant.deleted_at.is_(None))
    )
    if existing_merchant.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="A merchant with this email already exists")

    # Check for existing dashboard user
    existing_user = await db.execute(
        select(DashboardUser).where(DashboardUser.email == body.email)
    )
    if existing_user.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    # Generate API key
    full_key, key_hash = generate_api_key()

    # Create merchant
    merchant = Merchant(
        name=body.business_name,
        email=body.email,
        business_type=body.business_type,
        api_key_hash=key_hash,
        api_key_prefix=full_key[:20],
    )
    db.add(merchant)
    await db.flush()  # Get merchant.id before creating user

    # Create dashboard user linked to merchant
    user = DashboardUser(
        id=f"user_{uuid.uuid4().hex[:16]}",
        email=body.email,
        password_hash=_hash_password(body.password),
        name=body.contact_name,
        role="merchant",
        merchant_id=merchant.id,
    )
    db.add(user)
    await db.commit()

    # Generate tokens
    access_token = _create_token(
        user.id, user.role, merchant.id,
        timedelta(seconds=settings.jwt_expiry_seconds),
    )
    refresh_token = _create_token(
        user.id, user.role, merchant.id,
        timedelta(days=7),
        token_type="refresh",
    )

    return MerchantRegistrationResponse(
        merchant_id=merchant.id,
        user_id=user.id,
        email=body.email,
        business_name=body.business_name,
        api_key=full_key,
        api_key_prefix=full_key[:20],
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.jwt_expiry_seconds,
    )
