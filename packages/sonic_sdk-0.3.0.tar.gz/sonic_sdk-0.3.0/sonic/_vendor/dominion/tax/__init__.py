"""Dominion tax — user-programmable tax code registry and validation.

Taxes are a HARD STOP. No tax codes configured = no payroll operations.
This is not configurable — it is a policy enforcement point.
"""

from .registry import TaxCodeRegistry, TaxCode, TaxJurisdiction, WithholdingRule

__all__ = [
    "TaxCodeRegistry",
    "TaxCode",
    "TaxJurisdiction",
    "WithholdingRule",
]
