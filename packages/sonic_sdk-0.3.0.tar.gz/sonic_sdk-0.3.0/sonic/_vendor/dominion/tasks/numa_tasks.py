"""
Periodic NUMA reporting task.

Runs on a Celery beat schedule. Pushes operational telemetry
to NUMA for regime evaluation and frontier health monitoring.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict

logger = logging.getLogger(__name__)


def _get_celery_app():
    from services.celery_app import app
    return app


celery = _get_celery_app()


@celery.task(
    name="dominion.tasks.numa_tasks.report_to_numa",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    queue="dominion.numa",
)
def report_to_numa(self) -> Dict[str, Any]:
    """Push aggregated operational telemetry to NUMA."""
    return asyncio.get_event_loop().run_until_complete(_report_to_numa_async())


async def _report_to_numa_async() -> Dict[str, Any]:
    from ..db.session import get_session_factory
    from ..repos.float_repo import FloatRepo
    from ..repos.tax_repo import TaxRepo

    factory = get_session_factory()
    async with factory() as session:
        float_repo = FloatRepo(session)
        tax_repo = TaxRepo(session)

        committed = await float_repo.total_committed()
        tax_health = await tax_repo.health_summary()

        report = {
            "frontier_id": "finance.payroll",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "float": {
                "total_committed": committed,
            },
            "tax": tax_health,
            "source": "periodic_report",
        }

        try:
            from ..sbn_client import DominionSbnClient
            async with DominionSbnClient() as sbn:
                if sbn.active:
                    sbn.request_attestation(report)
                    logger.info("NUMA report submitted: committed=%.2f", committed)
                    return {"reported": True, "committed": committed}
        except Exception as exc:
            logger.warning("NUMA report failed, queuing to DLQ: %s", exc)
            from ..repos.dlq_repo import DLQRepo
            dlq = DLQRepo(session)
            await dlq.enqueue(
                operation="attestation",
                payload=report,
                error_message=str(exc),
            )
            await session.commit()
            return {"reported": False, "dlq_enqueued": True}

        return {"reported": False, "reason": "sbn_inactive"}
