"""
Dead-letter queue retry task.

Processes failed SBN submissions with exponential backoff.
Runs on a Celery beat schedule (every 30 seconds).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


def _get_celery_app():
    from services.celery_app import app
    return app


celery = _get_celery_app()


@celery.task(
    name="dominion.tasks.dlq_tasks.process_dead_letters",
    bind=True,
    max_retries=0,  # This task manages its own retries via DLQ status
    queue="dominion.dlq",
)
def process_dead_letters(self) -> Dict[str, Any]:
    """Fetch retryable items and attempt resubmission."""
    return asyncio.get_event_loop().run_until_complete(_process_dead_letters_async())


async def _process_dead_letters_async() -> Dict[str, Any]:
    from ..db.session import get_session_factory
    from ..repos.dlq_repo import DLQRepo

    factory = get_session_factory()
    async with factory() as session:
        dlq = DLQRepo(session)
        items = await dlq.get_retryable(limit=25)

        if not items:
            return {"processed": 0}

        succeeded = 0
        failed = 0

        for item in items:
            await dlq.mark_retrying(item.id)
            await session.commit()

            try:
                await _retry_operation(item.operation, item.payload)
                await dlq.mark_succeeded(item.id)
                await session.commit()
                succeeded += 1
                logger.info(
                    "DLQ item %s (%s) succeeded on retry %d",
                    item.id, item.operation, item.retry_count + 1,
                )
            except Exception as exc:
                await dlq.mark_failed(item.id, str(exc))
                await session.commit()
                failed += 1
                logger.warning(
                    "DLQ item %s (%s) failed retry %d: %s",
                    item.id, item.operation, item.retry_count + 1, exc,
                )

        return {"processed": len(items), "succeeded": succeeded, "failed": failed}


async def _retry_operation(operation: str, payload: dict) -> None:
    """Retry a single DLQ item based on its operation type."""
    from ..sbn_client import DominionSbnClient

    async with DominionSbnClient() as sbn:
        if not sbn.active:
            raise RuntimeError("SBN client inactive — cannot retry")

        if operation == "seal":
            sbn.seal(payload)
        elif operation == "attestation":
            sbn.request_attestation(payload)
        elif operation == "gec_compute":
            sbn.raw.gec.compute(**payload)
        elif operation == "workflow":
            sbn.create_workflow(
                domain=payload.get("domain", ""),
                name=payload.get("name", ""),
                nodes=payload.get("nodes", []),
                edges=payload.get("edges", []),
            )
        elif operation == "block":
            sbn.create_block(payload)
        else:
            raise ValueError(f"Unknown DLQ operation: {operation}")
