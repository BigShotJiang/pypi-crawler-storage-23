"""
Periodic GEC emission task.

Runs on a Celery beat schedule. Computes aggregate GEC metrics
from recent journal entries and emits them to the SBN gateway.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

logger = logging.getLogger(__name__)


def _get_celery_app():
    """Late import to avoid circular dependency."""
    from services.celery_app import app
    return app


celery = _get_celery_app()


@celery.task(
    name="dominion.tasks.gec_tasks.emit_gec_metrics",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    queue="dominion.gec",
)
def emit_gec_metrics(self) -> Dict[str, Any]:
    """Compute and emit periodic GEC efficiency metrics.

    Aggregates payout success/total from the last emission window
    and submits to SBN via DominionSbnClient.
    """
    return asyncio.get_event_loop().run_until_complete(_emit_gec_metrics_async())


async def _emit_gec_metrics_async() -> Dict[str, Any]:
    from ..db.session import get_session_factory
    from ..repos.journal_repo import JournalRepo
    from ..gec_interface.payload_builder import build_dominion_gec_payload

    factory = get_session_factory()
    async with factory() as session:
        repo = JournalRepo(session)
        since = datetime.now(timezone.utc) - timedelta(minutes=15)

        # Count successful vs total payouts in window
        completed = await repo.query(event_type="payout_completed", since=since, limit=10_000)
        submitted = await repo.query(event_type="payout_submitted", since=since, limit=10_000)
        failed = await repo.query(event_type="payout_failed", since=since, limit=10_000)

        y = len(completed)
        x = len(submitted) + len(completed) + len(failed)

        if x == 0:
            logger.debug("No payouts in window — skipping GEC emission")
            return {"skipped": True, "reason": "no_payouts_in_window"}

        payload = build_dominion_gec_payload(y=y, x=x)

        # Compute GEC via SBN's POST /api/gec/compute endpoint
        # (the payload dict is already the correct request shape)
        try:
            from ..sbn_client import DominionSbnClient
            async with DominionSbnClient() as sbn:
                if sbn.active:
                    result = sbn.raw.gec.compute(**payload)
                    logger.info(
                        "GEC computed via SBN: y=%d x=%d gec0=%s",
                        y, x, result.get("gec0") if result else "n/a",
                    )
                    return {"emitted": True, "y": y, "x": x, "gec_result": result}
        except Exception as exc:
            logger.warning("GEC compute failed, queuing to DLQ: %s", exc)
            # Enqueue to dead-letter for retry
            from ..repos.dlq_repo import DLQRepo
            dlq = DLQRepo(session)
            await dlq.enqueue(
                operation="gec_compute",
                payload=payload,
                error_message=str(exc),
            )
            await session.commit()
            return {"emitted": False, "dlq_enqueued": True}

        return {"emitted": False, "reason": "sbn_inactive"}
