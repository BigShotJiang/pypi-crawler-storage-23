"""
Dominion async database session factory.

Follows the Sonic pattern: async engine + async_sessionmaker.
Supports both Postgres (prod) and SQLite+aiosqlite (dev/test).
"""

from __future__ import annotations

import os
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from .config import dominion_database_url

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def _build_engine(url: str) -> AsyncEngine:
    kwargs: dict = {
        "pool_pre_ping": True,
        "echo": os.getenv("DOMINION_DB_ECHO", "").lower() in ("1", "true"),
    }

    if not url.startswith("sqlite"):
        pool_size = os.getenv("DOMINION_DB_POOL_SIZE")
        max_overflow = os.getenv("DOMINION_DB_MAX_OVERFLOW")
        if pool_size:
            kwargs["pool_size"] = int(pool_size)
        if max_overflow:
            kwargs["max_overflow"] = int(max_overflow)

    return create_async_engine(url, **kwargs)


def get_engine() -> AsyncEngine:
    """Return (and lazily create) the async engine."""
    global _engine
    if _engine is None:
        _engine = _build_engine(dominion_database_url())
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    """Return (and lazily create) the session factory."""
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
        )
    return _session_factory


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency-injectable async session generator."""
    factory = get_session_factory()
    async with factory() as session:
        yield session


async def configure_engine(database_url: str | None = None) -> None:
    """Replace the engine (e.g. for testing with a fresh DB)."""
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
    url = database_url or dominion_database_url()
    _engine = _build_engine(url)
    _session_factory = async_sessionmaker(
        _engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
