"""
Dominion Sonic Client — HTTP interface to the Sonic settlement engine.

Sonic handles the actual money movement: fiat rails (ACH, RTP, FedNow),
crypto rails (USDC, XLM, XRPL, HBAR), and hybrid settlement.

This client translates Dominion payout instructions into Sonic API calls
and tracks settlement status via polling or webhook callbacks.

Endpoints consumed:
- POST /v1/payments                         — create inbound payment
- POST /v1/payouts                          — execute outbound payout
- GET  /v1/receipts/{id}                    — retrieve settlement receipts
- GET  /v1/verify/{hash}                    — verify receipt chain integrity
- GET  /v1/health                           — Sonic service health
- POST /v1/pay-streams                      — open a PayStream
- POST /v1/pay-streams/{id}/accrue          — record work earnings
- POST /v1/pay-streams/{id}/close-window    — trigger micro-payout
- POST /v1/pay-streams/{id}/pause           — manual pause
- POST /v1/pay-streams/{id}/resume          — resume from pause
- POST /v1/pay-streams/{id}/freeze          — policy-driven freeze
- POST /v1/pay-streams/{id}/unfreeze        — resume from freeze
- POST /v1/pay-streams/{id}/close           — terminal close + reconciliation
- POST /v1/pay-streams/{id}/release-holdback — release held amounts
- GET  /v1/pay-streams/{id}                 — query stream state
- GET  /v1/pay-streams/{id}/windows         — window history
- GET  /v1/pay-streams                      — list streams
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class SonicPayoutRequest:
    """A payout request for Sonic execution."""
    tx_id: Optional[str] = None
    recipient_id: str = ""
    amount: Decimal = Decimal("0")
    currency: str = "USD"
    rail: str = "stripe_transfer"
    idempotency_key: str = field(default_factory=lambda: f"dom_{uuid.uuid4().hex[:16]}")
    fallback_rails: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class SonicPayoutResult:
    """Result from a Sonic payout execution."""
    success: bool = False
    tx_id: str = ""
    status: str = ""
    provider_ref: Optional[str] = None
    receipt_hash: Optional[str] = None
    error: Optional[str] = None
    retryable: bool = False
    raw_response: Optional[Dict[str, Any]] = None


@dataclass
class SonicPaymentRequest:
    """An inbound payment creation request."""
    amount: Decimal = Decimal("0")
    currency: str = "USD"
    rail: str = "stripe_card"
    customer_ref: Optional[str] = None
    idempotency_key: str = field(default_factory=lambda: f"dom_{uuid.uuid4().hex[:16]}")
    metadata: Optional[Dict[str, Any]] = None


# ------------------------------------------------------------------
# PayStream dataclasses
# ------------------------------------------------------------------


@dataclass
class PayStreamOpenRequest:
    """Request to open a Sonic PayStream for windowed accrual streaming."""
    payer_id: str = ""
    payee_id: str = ""
    currency: str = "USD"
    rail: str = "stripe_transfer"
    rate_amount: Decimal = Decimal("0")
    rate_unit: str = "per_window"
    cadence_seconds: int = 1800
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class PayStreamState:
    """Snapshot of a Sonic PayStream's current state."""
    pay_stream_id: str = ""
    status: str = ""
    policy_state: str = ""
    payer_id: str = ""
    payee_id: str = ""
    currency: str = ""
    rail: str = ""
    rate_amount: str = "0"
    cadence_seconds: int = 1800
    g_ewma: str = "0.5"
    total_earned: str = "0"
    total_disbursed: str = "0"
    total_held: str = "0"
    window_count: int = 0
    sbn_slot_id: Optional[str] = None
    created_at: str = ""
    closed_at: Optional[str] = None
    raw_response: Optional[Dict[str, Any]] = None


@dataclass
class PayStreamResult:
    """Generic result wrapper for PayStream mutation operations."""
    success: bool = False
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    retryable: bool = False


class DominionSonicClient:
    """HTTP client for the Sonic settlement engine.

    All methods are non-blocking wrappers around Sonic's REST API.
    Failed calls never raise — they return error results so the
    router can decide how to handle (retry, hold, escalate).

    Parameters
    ----------
    base_url:
        Sonic API base URL (e.g. ``http://localhost:8000``).
    api_key:
        Sonic merchant API key (``sonic_live_...`` or ``sonic_test_...``).
    merchant_id:
        Dominion's merchant ID in Sonic.
    timeout:
        HTTP request timeout in seconds.
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8000",
        api_key: str = "",
        merchant_id: str = "",
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._merchant_id = merchant_id
        self._timeout = timeout
        self._http: Any = None

        try:
            import httpx
            self._http = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=timeout,
                headers={
                    "x-sonic-api-key": api_key,
                    "Content-Type": "application/json",
                    "User-Agent": "dominion-sonic-client/1.0",
                },
            )
            logger.info("Sonic client initialised: %s (merchant: %s)", base_url, merchant_id)
        except ImportError:
            logger.warning("httpx not installed — Sonic client unavailable")

    @property
    def active(self) -> bool:
        return self._http is not None

    # ------------------------------------------------------------------
    # Payouts (outbound — Dominion's primary use case)
    # ------------------------------------------------------------------

    async def execute_payout(self, request: SonicPayoutRequest) -> SonicPayoutResult:
        """Execute an outbound payout via Sonic.

        Maps to ``POST /v1/payouts``.

        If the primary rail fails and fallback_rails are specified,
        Sonic's PayoutExecutor handles the failover internally.
        """
        if not self.active:
            return SonicPayoutResult(
                success=False,
                error="Sonic client not initialised",
                retryable=True,
            )

        payload: Dict[str, Any] = {
            "recipient_id": request.recipient_id,
            "amount": str(request.amount),
            "currency": request.currency,
            "rail": request.rail,
            "idempotency_key": request.idempotency_key,
        }
        if request.tx_id:
            payload["tx_id"] = request.tx_id
        if request.fallback_rails:
            payload["fallback_rails"] = request.fallback_rails
        if request.metadata:
            payload["metadata"] = request.metadata

        try:
            response = await self._http.post("/v1/payouts", json=payload)

            if response.status_code in (200, 201):
                data = response.json()
                return SonicPayoutResult(
                    success=True,
                    tx_id=data.get("tx_id", ""),
                    status=data.get("payout_status", data.get("status", "")),
                    provider_ref=data.get("provider_ref"),
                    receipt_hash=data.get("receipt_hash"),
                    raw_response=data,
                )

            error_detail = response.text
            return SonicPayoutResult(
                success=False,
                error=f"Sonic returned {response.status_code}: {error_detail}",
                retryable=response.status_code >= 500,
                raw_response={"status_code": response.status_code, "body": error_detail},
            )

        except Exception as exc:
            logger.warning("Sonic payout request failed: %s", exc, exc_info=True)
            return SonicPayoutResult(
                success=False,
                error=str(exc),
                retryable=True,
            )

    # ------------------------------------------------------------------
    # Payments (inbound — for Dominion's treasury operations)
    # ------------------------------------------------------------------

    async def create_payment(self, request: SonicPaymentRequest) -> Optional[Dict[str, Any]]:
        """Create an inbound payment via Sonic.

        Maps to ``POST /v1/payments``.
        """
        if not self.active:
            return None

        payload: Dict[str, Any] = {
            "amount": str(request.amount),
            "currency": request.currency,
            "rail": request.rail,
            "idempotency_key": request.idempotency_key,
        }
        if request.customer_ref:
            payload["customer_ref"] = request.customer_ref
        if request.metadata:
            payload["metadata"] = request.metadata

        try:
            response = await self._http.post("/v1/payments", json=payload)
            if response.status_code in (200, 201):
                return response.json()
            logger.warning("Sonic payment creation failed: %d", response.status_code)
            return None
        except Exception:
            logger.warning("Sonic payment request failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Receipts
    # ------------------------------------------------------------------

    async def get_receipts(self, tx_id: str) -> List[Dict[str, Any]]:
        """Retrieve all settlement receipts for a transaction."""
        if not self.active:
            return []
        try:
            response = await self._http.get(f"/v1/receipts/{tx_id}")
            if response.status_code == 200:
                data = response.json()
                return data if isinstance(data, list) else data.get("receipts", [])
            return []
        except Exception:
            logger.warning("Sonic receipt fetch failed for %s", tx_id, exc_info=True)
            return []

    async def verify_receipt(self, receipt_hash: str) -> Optional[Dict[str, Any]]:
        """Verify a Sonic receipt chain via public endpoint."""
        if not self.active:
            return None
        try:
            response = await self._http.get(f"/v1/verify/{receipt_hash}")
            if response.status_code == 200:
                return response.json()
            return None
        except Exception:
            logger.warning("Sonic receipt verify failed for %s", receipt_hash, exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    async def health(self) -> bool:
        """Check if Sonic is reachable and healthy."""
        if not self.active:
            return False
        try:
            response = await self._http.get("/v1/health")
            return response.status_code == 200
        except Exception:
            logger.warning("Sonic health check failed", exc_info=True)
            return False

    # ------------------------------------------------------------------
    # PayStream lifecycle (windowed accrual streaming)
    # ------------------------------------------------------------------

    async def open_pay_stream(self, request: PayStreamOpenRequest) -> PayStreamState:
        """Open a Sonic PayStream for windowed accrual streaming.

        Maps to ``POST /v1/pay-streams``.

        Opens a streaming session where earnings accumulate in 30-min
        windows.  Sonic manages risk policy, micro-payouts, and SBN
        batch attestation.
        """
        if not self.active:
            return PayStreamState(status="error", raw_response={"error": "Sonic client not initialised"})

        payload: Dict[str, Any] = {
            "payer_id": request.payer_id,
            "payee_id": request.payee_id,
            "currency": request.currency,
            "rail": request.rail,
            "rate_amount": str(request.rate_amount),
            "rate_unit": request.rate_unit,
            "cadence_seconds": request.cadence_seconds,
        }
        if request.metadata:
            payload["metadata"] = request.metadata

        try:
            response = await self._http.post("/v1/pay-streams", json=payload)

            if response.status_code in (200, 201):
                data = response.json()
                return PayStreamState(
                    pay_stream_id=data.get("pay_stream_id", ""),
                    status=data.get("status", ""),
                    policy_state=data.get("policy_state", ""),
                    payer_id=data.get("payer_id", ""),
                    payee_id=data.get("payee_id", ""),
                    currency=data.get("currency", ""),
                    rail=data.get("rail", ""),
                    rate_amount=data.get("rate_amount", "0"),
                    cadence_seconds=data.get("cadence_seconds", 1800),
                    g_ewma=data.get("g_ewma", "0.5"),
                    total_earned=data.get("total_earned", "0"),
                    total_disbursed=data.get("total_disbursed", "0"),
                    total_held=data.get("total_held", "0"),
                    window_count=data.get("window_count", 0),
                    sbn_slot_id=data.get("sbn_slot_id"),
                    created_at=data.get("created_at", ""),
                    raw_response=data,
                )

            logger.warning("Sonic open_pay_stream failed: %d", response.status_code)
            return PayStreamState(
                status="error",
                raw_response={"status_code": response.status_code, "body": response.text},
            )
        except Exception as exc:
            logger.warning("Sonic open_pay_stream request failed: %s", exc, exc_info=True)
            return PayStreamState(status="error", raw_response={"error": str(exc)})

    async def accrue_pay_stream(
        self,
        pay_stream_id: str,
        units: Decimal,
        unit_price: Optional[Decimal] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> PayStreamResult:
        """Record work earnings into the stream's current window.

        Maps to ``POST /v1/pay-streams/{id}/accrue``.
        """
        if not self.active:
            return PayStreamResult(error="Sonic client not initialised", retryable=True)

        payload: Dict[str, Any] = {"units": str(units)}
        if unit_price is not None:
            payload["unit_price"] = str(unit_price)
        if metadata:
            payload["metadata"] = metadata

        return await self._pay_stream_post(f"/v1/pay-streams/{pay_stream_id}/accrue", payload)

    async def close_pay_stream_window(
        self,
        pay_stream_id: str,
        gec_y: int = 0,
        gec_x: int = 0,
    ) -> PayStreamResult:
        """Close the current window and trigger a micro-payout.

        Maps to ``POST /v1/pay-streams/{id}/close-window``.

        GEC y/x values feed into Sonic's g_ewma policy engine which
        determines the stream's risk state (PRIME/NORMAL/RISK/FROZEN).
        """
        if not self.active:
            return PayStreamResult(error="Sonic client not initialised", retryable=True)

        payload: Dict[str, Any] = {"gec_y": gec_y, "gec_x": gec_x}
        return await self._pay_stream_post(f"/v1/pay-streams/{pay_stream_id}/close-window", payload)

    async def pause_pay_stream(self, pay_stream_id: str) -> PayStreamState:
        """Manually pause a stream (no payouts until resumed).

        Maps to ``POST /v1/pay-streams/{id}/pause``.
        """
        return await self._pay_stream_state_post(f"/v1/pay-streams/{pay_stream_id}/pause")

    async def resume_pay_stream(self, pay_stream_id: str) -> PayStreamState:
        """Resume a paused stream (opens a new window).

        Maps to ``POST /v1/pay-streams/{id}/resume``.
        """
        return await self._pay_stream_state_post(f"/v1/pay-streams/{pay_stream_id}/resume")

    async def freeze_pay_stream(self, pay_stream_id: str, reason: str = "") -> PayStreamResult:
        """Policy-driven freeze (100% holdback, SBN interruption proof).

        Maps to ``POST /v1/pay-streams/{id}/freeze``.
        """
        if not self.active:
            return PayStreamResult(error="Sonic client not initialised", retryable=True)

        payload: Dict[str, Any] = {"reason": reason} if reason else {}
        return await self._pay_stream_post(f"/v1/pay-streams/{pay_stream_id}/freeze", payload)

    async def unfreeze_pay_stream(self, pay_stream_id: str) -> PayStreamState:
        """Resume from a policy freeze (opens new SBN slot).

        Maps to ``POST /v1/pay-streams/{id}/unfreeze``.
        """
        return await self._pay_stream_state_post(f"/v1/pay-streams/{pay_stream_id}/unfreeze")

    async def close_pay_stream(self, pay_stream_id: str) -> PayStreamResult:
        """Terminal close with reconciliation and merkle root.

        Maps to ``POST /v1/pay-streams/{id}/close``.
        """
        if not self.active:
            return PayStreamResult(error="Sonic client not initialised", retryable=True)

        return await self._pay_stream_post(f"/v1/pay-streams/{pay_stream_id}/close", {})

    async def release_pay_stream_holdback(self, pay_stream_id: str) -> PayStreamResult:
        """Release all policy-held amounts as a micro-payout.

        Maps to ``POST /v1/pay-streams/{id}/release-holdback``.
        """
        if not self.active:
            return PayStreamResult(error="Sonic client not initialised", retryable=True)

        return await self._pay_stream_post(f"/v1/pay-streams/{pay_stream_id}/release-holdback", {})

    # ------------------------------------------------------------------
    # PayStream queries
    # ------------------------------------------------------------------

    async def get_pay_stream(self, pay_stream_id: str) -> Optional[PayStreamState]:
        """Query the current state of a PayStream.

        Maps to ``GET /v1/pay-streams/{id}``.
        """
        if not self.active:
            return None
        try:
            response = await self._http.get(f"/v1/pay-streams/{pay_stream_id}")
            if response.status_code == 200:
                data = response.json()
                return PayStreamState(
                    pay_stream_id=data.get("pay_stream_id", pay_stream_id),
                    status=data.get("status", ""),
                    policy_state=data.get("policy_state", ""),
                    payer_id=data.get("payer_id", ""),
                    payee_id=data.get("payee_id", ""),
                    currency=data.get("currency", ""),
                    rail=data.get("rail", ""),
                    rate_amount=data.get("rate_amount", "0"),
                    cadence_seconds=data.get("cadence_seconds", 1800),
                    g_ewma=data.get("g_ewma", "0.5"),
                    total_earned=data.get("total_earned", "0"),
                    total_disbursed=data.get("total_disbursed", "0"),
                    total_held=data.get("total_held", "0"),
                    window_count=data.get("window_count", 0),
                    sbn_slot_id=data.get("sbn_slot_id"),
                    created_at=data.get("created_at", ""),
                    closed_at=data.get("closed_at"),
                    raw_response=data,
                )
            return None
        except Exception:
            logger.warning("Sonic get_pay_stream failed for %s", pay_stream_id, exc_info=True)
            return None

    async def list_pay_stream_windows(
        self,
        pay_stream_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List accrual windows for a PayStream.

        Maps to ``GET /v1/pay-streams/{id}/windows``.
        """
        if not self.active:
            return []
        try:
            response = await self._http.get(
                f"/v1/pay-streams/{pay_stream_id}/windows",
                params={"limit": limit, "offset": offset},
            )
            if response.status_code == 200:
                data = response.json()
                return data if isinstance(data, list) else data.get("windows", [])
            return []
        except Exception:
            logger.warning("Sonic list_pay_stream_windows failed for %s", pay_stream_id, exc_info=True)
            return []

    async def list_pay_streams(
        self,
        status: Optional[str] = None,
        payee_id: Optional[str] = None,
        payer_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """List PayStreams with optional filters.

        Maps to ``GET /v1/pay-streams``.
        """
        if not self.active:
            return {"streams": [], "total": 0}
        try:
            params: Dict[str, Any] = {"limit": limit, "offset": offset}
            if status:
                params["status"] = status
            if payee_id:
                params["payee_id"] = payee_id
            if payer_id:
                params["payer_id"] = payer_id

            response = await self._http.get("/v1/pay-streams", params=params)
            if response.status_code == 200:
                return response.json()
            return {"streams": [], "total": 0}
        except Exception:
            logger.warning("Sonic list_pay_streams failed", exc_info=True)
            return {"streams": [], "total": 0}

    # ------------------------------------------------------------------
    # PayStream internal helpers
    # ------------------------------------------------------------------

    async def _pay_stream_post(self, url: str, payload: Dict[str, Any]) -> PayStreamResult:
        """Generic POST → PayStreamResult helper."""
        try:
            response = await self._http.post(url, json=payload)

            if response.status_code in (200, 201):
                return PayStreamResult(success=True, data=response.json())

            return PayStreamResult(
                success=False,
                error=f"Sonic returned {response.status_code}: {response.text}",
                retryable=response.status_code >= 500,
            )
        except Exception as exc:
            logger.warning("Sonic PayStream request failed (%s): %s", url, exc, exc_info=True)
            return PayStreamResult(success=False, error=str(exc), retryable=True)

    async def _pay_stream_state_post(self, url: str) -> PayStreamState:
        """POST with no body → PayStreamState helper (pause/resume/unfreeze)."""
        if not self.active:
            return PayStreamState(status="error", raw_response={"error": "Sonic client not initialised"})
        try:
            response = await self._http.post(url, json={})

            if response.status_code in (200, 201):
                data = response.json()
                return PayStreamState(
                    pay_stream_id=data.get("pay_stream_id", ""),
                    status=data.get("status", ""),
                    policy_state=data.get("policy_state", ""),
                    g_ewma=data.get("g_ewma", "0.5"),
                    total_earned=data.get("total_earned", "0"),
                    total_disbursed=data.get("total_disbursed", "0"),
                    total_held=data.get("total_held", "0"),
                    window_count=data.get("window_count", 0),
                    sbn_slot_id=data.get("sbn_slot_id"),
                    raw_response=data,
                )

            return PayStreamState(
                status="error",
                raw_response={"status_code": response.status_code, "body": response.text},
            )
        except Exception as exc:
            logger.warning("Sonic PayStream state request failed (%s): %s", url, exc, exc_info=True)
            return PayStreamState(status="error", raw_response={"error": str(exc)})

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    async def execute_payout_batch(
        self,
        requests: List[SonicPayoutRequest],
    ) -> List[SonicPayoutResult]:
        """Execute multiple payouts. Each is individually tracked."""
        results = []
        for req in requests:
            result = await self.execute_payout(req)
            results.append(result)
        return results

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()

    async def __aenter__(self) -> DominionSonicClient:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()
