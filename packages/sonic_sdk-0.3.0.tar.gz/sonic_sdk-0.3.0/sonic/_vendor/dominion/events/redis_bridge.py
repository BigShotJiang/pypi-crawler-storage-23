"""
Redis-backed event bridge — replaces in-memory DominionAgentBridge buffers.

Two patterns coexist:
  1. Pub/Sub channels — real-time, fire-and-forget notifications
  2. Redis Streams — durable ordered log with consumer groups for the agent

The bridge also persists the latest batch/float snapshots in Redis keys
so the agent can read them without polling the DB.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None  # type: ignore[assignment]

from .channels import (
    ALL_CHANNELS,
    CHANNEL_BATCH_COMPLETE,
    CHANNEL_FLOAT_UPDATE,
    CHANNEL_MILESTONE,
    CHANNEL_NUMA_HINT,
    CHANNEL_SONIC_SETTLEMENT,
    CHANNEL_SONIC_STREAM,
    CHANNEL_TAX_HOLD,
    KEY_LATEST_BATCH,
    KEY_LATEST_FLOAT,
    KEY_TAX_HEALTH,
    STREAM_BRIDGE_EVENTS,
)


class RedisBridge:
    """Async Redis bridge for Dominion ↔ Agent communication.

    Falls back gracefully to no-op if Redis is unavailable —
    the system degrades to the DB-backed DomBridgeEvent table.
    """

    CONSUMER_GROUP = "dominion_agent"
    STREAM_MAX_LEN = 10_000

    def __init__(self, redis_url: str | None = None):
        self._redis_url = redis_url
        self._client: Optional[Any] = None
        self._active = False

    async def connect(self) -> bool:
        """Initialize Redis connection. Returns True if connected."""
        if aioredis is None:
            logger.warning("redis.asyncio not available — bridge running in DB-only mode")
            return False
        if self._redis_url is None:
            from ..db.config import dominion_redis_url
            self._redis_url = dominion_redis_url()
        try:
            self._client = aioredis.from_url(
                self._redis_url,
                decode_responses=True,
            )
            await self._client.ping()
            # Ensure stream consumer group exists
            try:
                await self._client.xgroup_create(
                    STREAM_BRIDGE_EVENTS,
                    self.CONSUMER_GROUP,
                    id="0",
                    mkstream=True,
                )
            except Exception:
                pass  # BUSYGROUP — consumer group already exists, expected on restart
            self._active = True
            logger.info("Redis bridge connected: %s", self._redis_url)
            return True
        except Exception:
            logger.warning("Redis connection failed — bridge in DB-only mode", exc_info=True)
            self._active = False
            return False

    @property
    def active(self) -> bool:
        return self._active

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._active = False

    # ----- Publishing -----

    async def publish_event(
        self,
        channel: str,
        event_type: str,
        data: Dict[str, Any],
    ) -> None:
        """Publish to pub/sub channel AND append to durable stream."""
        if not self._active:
            return

        envelope = {
            "type": event_type,
            "data": json.dumps(data),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        try:
            # Pub/sub (real-time)
            await self._client.publish(channel, json.dumps(envelope))
            # Stream (durable)
            await self._client.xadd(
                STREAM_BRIDGE_EVENTS,
                envelope,
                maxlen=self.STREAM_MAX_LEN,
            )
        except Exception:
            logger.warning("Redis publish failed for %s", channel, exc_info=True)

    async def push_batch_complete(self, summary: Dict[str, Any]) -> None:
        await self._set_state(KEY_LATEST_BATCH, summary)
        await self.publish_event(CHANNEL_BATCH_COMPLETE, "batch_complete", summary)

    async def push_float_update(self, health: Dict[str, Any]) -> None:
        await self._set_state(KEY_LATEST_FLOAT, health)
        await self.publish_event(CHANNEL_FLOAT_UPDATE, "float_update", health)

    async def push_milestone_event(self, data: Dict[str, Any]) -> None:
        await self.publish_event(CHANNEL_MILESTONE, "milestone_event", data)

    async def push_tax_hold(self, data: Dict[str, Any]) -> None:
        await self.publish_event(CHANNEL_TAX_HOLD, "tax_hold", data)

    async def push_sonic_settlement(self, data: Dict[str, Any]) -> None:
        await self.publish_event(CHANNEL_SONIC_SETTLEMENT, "sonic_settlement", data)

    async def push_sonic_stream_event(self, data: Dict[str, Any]) -> None:
        await self.publish_event(CHANNEL_SONIC_STREAM, "sonic_stream_event", data)

    async def push_numa_hint(self, data: Dict[str, Any]) -> None:
        await self.publish_event(CHANNEL_NUMA_HINT, "numa_hint", data)

    # ----- Agent reads -----

    async def get_latest_batch(self) -> Dict[str, Any] | None:
        return await self._get_state(KEY_LATEST_BATCH)

    async def get_latest_float(self) -> Dict[str, Any] | None:
        return await self._get_state(KEY_LATEST_FLOAT)

    async def get_tax_health(self) -> Dict[str, Any] | None:
        return await self._get_state(KEY_TAX_HEALTH)

    async def drain_events(
        self,
        consumer_name: str = "agent-0",
        count: int = 100,
    ) -> List[Dict[str, Any]]:
        """Read pending events from the durable stream (consumer group)."""
        if not self._active:
            return []

        try:
            messages = await self._client.xreadgroup(
                self.CONSUMER_GROUP,
                consumer_name,
                {STREAM_BRIDGE_EVENTS: ">"},
                count=count,
            )
            events = []
            for _, entries in messages:
                for msg_id, fields in entries:
                    event = {
                        "id": msg_id,
                        "type": fields.get("type", ""),
                        "data": json.loads(fields.get("data", "{}")),
                        "timestamp": fields.get("timestamp", ""),
                    }
                    events.append(event)
                    # ACK immediately
                    await self._client.xack(
                        STREAM_BRIDGE_EVENTS, self.CONSUMER_GROUP, msg_id,
                    )
            return events
        except Exception:
            logger.warning("Redis stream read failed", exc_info=True)
            return []

    # ----- Internal helpers -----

    async def _set_state(self, key: str, data: Dict[str, Any]) -> None:
        if not self._active:
            return
        try:
            await self._client.set(key, json.dumps(data), ex=3600)
        except Exception:
            logger.warning("Redis SET failed for %s", key, exc_info=True)

    async def _get_state(self, key: str) -> Dict[str, Any] | None:
        if not self._active:
            return None
        try:
            raw = await self._client.get(key)
            return json.loads(raw) if raw else None
        except Exception:
            logger.warning("Redis GET failed for %s", key, exc_info=True)
            return None
