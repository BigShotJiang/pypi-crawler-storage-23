"""
Dominion Translation Rules — NUMA signal → payroll action matrix.

Following the GridOperatorAgent pattern from tower-agent, this module
defines the complete mapping from metallic regimes and CSK conditions
to Dominion payroll actions.

The DominionAgent evaluates these rules on every tick against current
NUMA frontier state.  Each rule produces an actionable suggestion:
- Low priority: surface to operator for manual review
- High priority + sufficient trust: auto-execute via SnapChore attestation

Rule structure:
    (metallic_regime, condition) → (action, params, auto_execute_threshold)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass(frozen=True, slots=True)
class DominionTranslationRule:
    """A NUMA signal → Dominion payroll action translation rule.

    Mirrors the GridOperatorAgent's ``TranslationRule`` but uses
    payroll-domain actions and conditions.
    """
    rule_id: str
    metallic_regime: str          # gold, silver, bronze, iron, or * for any
    condition: str                # domain condition identifier
    action: str                   # Dominion action to suggest/execute
    params: Dict[str, Any] = field(default_factory=dict)
    auto_execute_at_trust: float = 1.0  # 0.0 = always fire, 1.0 = never auto
    priority: float = 0.5
    description: str = ""


# ---------------------------------------------------------------------------
# REGIME-BASED RULES
# ---------------------------------------------------------------------------

DOMINION_TRANSLATION_RULES: List[DominionTranslationRule] = [

    # ── Gold regime — expansion, surplus float, high efficiency ──────

    DominionTranslationRule(
        rule_id="gold_enable_streaming",
        metallic_regime="gold",
        condition="float_surplus",
        action="enable_streaming_payouts",
        params={"rails": ["rtp", "fednow", "usdc_sol"], "min_trust": 0.7},
        auto_execute_at_trust=0.7,
        priority=0.8,
        description="Gold regime with surplus float — enable real-time pay streaming.",
    ),
    DominionTranslationRule(
        rule_id="gold_batch_milestones",
        metallic_regime="gold",
        condition="milestone_cluster",
        action="batch_milestone_release",
        params={"max_batch_size": 50, "include_performance": True},
        auto_execute_at_trust=0.6,
        priority=0.7,
        description="Gold regime with milestone cluster — batch-release eligible milestones.",
    ),
    DominionTranslationRule(
        rule_id="gold_bonus_multiplier",
        metallic_regime="gold",
        condition="max_compression",
        action="activate_bonus_multiplier",
        params={"multiplier_min": 1.05, "multiplier_max": 1.15, "duration_hours": 48},
        auto_execute_at_trust=0.9,
        priority=0.9,
        description=(
            "Maximum compression on finance.payroll — activate compression yield bonus "
            "for top-performing workers."
        ),
    ),
    DominionTranslationRule(
        rule_id="gold_expand_crypto_locks",
        metallic_regime="gold",
        condition="crypto_lock_demand",
        action="open_contract_locks",
        params={"chains": ["xrpl", "xlm", "usdc_sol"], "max_new_locks": 20},
        auto_execute_at_trust=0.8,
        priority=0.6,
        description="Gold regime with crypto demand — open new contract lock slots.",
    ),

    # ── Silver regime — steady state, optimize ──────────────────────

    DominionTranslationRule(
        rule_id="silver_standard_batch",
        metallic_regime="silver",
        condition="standard_cycle",
        action="process_normal_batch",
        params={"batch_priority": "normal"},
        auto_execute_at_trust=0.5,
        priority=0.5,
        description="Silver regime on standard cycle — process payroll normally.",
    ),
    DominionTranslationRule(
        rule_id="silver_suggest_milestone",
        metallic_regime="silver",
        condition="worker_streak",
        action="suggest_milestone_bonus",
        params={"bonus_min": 25, "bonus_max": 100, "streak_length": 5},
        auto_execute_at_trust=0.6,
        priority=0.6,
        description="Silver regime with worker consistency — suggest performance milestone.",
    ),
    DominionTranslationRule(
        rule_id="silver_optimize_rails",
        metallic_regime="silver",
        condition="fee_optimization_available",
        action="suggest_rail_optimization",
        params={"compare_rails": ["ach", "rtp", "push_to_debit"]},
        auto_execute_at_trust=1.0,  # Never auto — operator reviews rail changes
        priority=0.5,
        description="Silver regime — suggest cheaper payout rails to improve margins.",
    ),

    # ── Bronze regime — caution, conserve float ─────────────────────

    DominionTranslationRule(
        rule_id="bronze_throttle_streaming",
        metallic_regime="bronze",
        condition="float_pressure",
        action="throttle_streaming",
        params={"reduce_to_pct": 50, "reason": "Bronze regime with float pressure"},
        auto_execute_at_trust=0.8,
        priority=0.7,
        description="Bronze regime with float stress — reduce streaming volume by 50%.",
    ),
    DominionTranslationRule(
        rule_id="bronze_hold_milestones",
        metallic_regime="bronze",
        condition="float_critical",
        action="hold_non_essential_milestones",
        params={"hold_types": ["performance", "custom"], "preserve_types": ["time_based"]},
        auto_execute_at_trust=0.7,
        priority=0.8,
        description=(
            "Bronze regime with critical float — hold performance/custom milestones, "
            "preserve time-based obligations."
        ),
    ),
    DominionTranslationRule(
        rule_id="bronze_fee_review",
        metallic_regime="bronze",
        condition="fee_squeeze",
        action="suggest_payout_rail_review",
        params={"direction": "cost_reduction", "reason": "Bronze regime margin pressure"},
        auto_execute_at_trust=1.0,  # Never auto — operator reviews
        priority=0.6,
        description="Bronze regime with fee pressure — suggest reviewing payout rail costs.",
    ),
    DominionTranslationRule(
        rule_id="bronze_pause_crypto_locks",
        metallic_regime="bronze",
        condition="float_pressure",
        action="pause_new_contract_locks",
        params={"reason": "Float conservation in bronze regime"},
        auto_execute_at_trust=0.8,
        priority=0.7,
        description="Bronze regime — pause new crypto contract lock creation.",
    ),

    # ── Iron regime — emergency, always escalate ────────────────────

    DominionTranslationRule(
        rule_id="iron_freeze",
        metallic_regime="iron",
        condition="any",
        action="escalate_freeze_payouts",
        params={
            "severity": "critical",
            "reason": "Iron regime — immediate human review required.",
            "preserve_in_flight": True,
        },
        auto_execute_at_trust=0.0,  # Always fire immediately
        priority=1.0,
        description=(
            "IRON REGIME — freeze all new payouts, preserve in-flight settlements, "
            "escalate to human operator immediately."
        ),
    ),

    # ── CSK dimension rules (any regime) ────────────────────────────

    DominionTranslationRule(
        rule_id="csk_R_low",
        metallic_regime="*",
        condition="csk_R_below_threshold",
        action="alert_float_rebalance",
        params={"dimension": "R", "threshold": 0.55},
        auto_execute_at_trust=1.0,
        priority=0.8,
        description="CSK Resources (R) below threshold — alert for treasury float rebalancing.",
    ),
    DominionTranslationRule(
        rule_id="csk_E_low",
        metallic_regime="*",
        condition="csk_E_below_threshold",
        action="alert_tax_api_degraded",
        params={"dimension": "E", "threshold": 0.55},
        auto_execute_at_trust=1.0,
        priority=0.7,
        description="CSK Exchange (E) below threshold — tax API or compliance feed degraded.",
    ),
    DominionTranslationRule(
        rule_id="csk_H_low",
        metallic_regime="*",
        condition="csk_H_below_threshold",
        action="alert_calculation_variance",
        params={"dimension": "H", "threshold": 0.55},
        auto_execute_at_trust=0.8,
        priority=0.7,
        description="CSK Homeostasis (H) below threshold — calculation drift or ledger instability.",
    ),
    DominionTranslationRule(
        rule_id="csk_S_low",
        metallic_regime="*",
        condition="csk_S_below_threshold",
        action="alert_schema_integrity",
        params={"dimension": "S", "threshold": 0.55},
        auto_execute_at_trust=1.0,
        priority=0.6,
        description="CSK Structure (S) below threshold — schema validation or field completeness issues.",
    ),
    DominionTranslationRule(
        rule_id="csk_D_low",
        metallic_regime="*",
        condition="csk_D_below_threshold",
        action="suggest_multi_entity_expansion",
        params={"dimension": "D", "threshold": 0.55},
        auto_execute_at_trust=1.0,
        priority=0.5,
        description=(
            "CSK Diversity (D) below threshold — single-entity or single-currency risk. "
            "Suggest expanding multi-entity / multi-jurisdiction coverage."
        ),
    ),

    # ── Tax-specific rules (any regime) ─────────────────────────────

    DominionTranslationRule(
        rule_id="tax_codes_missing",
        metallic_regime="*",
        condition="no_tax_codes",
        action="block_all_payouts",
        params={"severity": "critical", "reason": "No active tax codes — payroll halted."},
        auto_execute_at_trust=0.0,  # Always fire — non-negotiable
        priority=1.0,
        description="HARD STOP — no tax codes configured. All payouts blocked until resolved.",
    ),
    DominionTranslationRule(
        rule_id="tax_codes_expiring",
        metallic_regime="*",
        condition="tax_codes_near_expiry",
        action="alert_tax_renewal",
        params={"days_warning": 30},
        auto_execute_at_trust=1.0,
        priority=0.9,
        description="Tax codes expiring within 30 days — alert for renewal before hard stop.",
    ),
    DominionTranslationRule(
        rule_id="tax_api_degraded",
        metallic_regime="*",
        condition="tax_api_error_rate_high",
        action="alert_manual_tax_review",
        params={"error_rate_threshold": 0.10},
        auto_execute_at_trust=1.0,
        priority=0.8,
        description="Tax API error rate above 10% — suggest manual review of withholding calculations.",
    ),

    # ── Interaction pattern rules ───────────────────────────────────

    DominionTranslationRule(
        rule_id="interaction_resource_starvation",
        metallic_regime="*",
        condition="csk_interaction_resource_starvation",
        action="alert_treasury_pipeline",
        params={"pattern": "resource_starvation", "dimensions": ["R", "E"]},
        auto_execute_at_trust=1.0,
        priority=0.8,
        description="CSK interaction: R + E both low — treasury pipeline needs attention.",
    ),
    DominionTranslationRule(
        rule_id="interaction_structural_drift",
        metallic_regime="*",
        condition="csk_interaction_structural_drift",
        action="alert_ledger_reconciliation",
        params={"pattern": "structural_drift", "dimensions": ["S", "H"]},
        auto_execute_at_trust=1.0,
        priority=0.7,
        description="CSK interaction: S + H both low — ledger drift, run reconciliation.",
    ),
]
