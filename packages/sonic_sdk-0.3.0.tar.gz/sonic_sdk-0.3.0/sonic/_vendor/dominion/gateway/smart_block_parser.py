"""
SmartBlockParser — Native SBN format parser for Smart Block completions.

When a Smart Block closes on the network, it carries:
- Completion proof (SnapChore hash)
- Worker identity
- Yield metrics (y, x) for GEC
- Optional CSK telemetry
- Payout parameters

This parser extracts the payout-relevant data and produces
PayoutInstructions that are fully SBN-native (no legacy_mode flag).

Note: SBN uses different hash field names depending on the endpoint:
- ``POST /api/blocks`` response: ``data.hash``
- ``GET /api/blocks/{id}`` response: ``snapchore_hash``
The parser handles both.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def _extract_block_hash(block_payload: Dict[str, Any]) -> Optional[str]:
    """Extract the block hash from an SBN block payload.

    Handles both ``snapchore_hash`` (GET response) and ``hash``
    (POST response / nested ``data`` wrapper).
    """
    h = block_payload.get("snapchore_hash")
    if h:
        return h
    h = block_payload.get("hash")
    if h:
        return h
    data = block_payload.get("data", {})
    if isinstance(data, dict):
        return data.get("hash")
    return None


class SmartBlockParser:
    """
    Parse Smart Block completion events into PayoutInstructions.

    Unlike LegacyAdapter, this produces instructions with:
    - SnapChore hash attached
    - GEC metrics carried forward
    - Trust scores from the block's attestation chain
    """

    def parse_completion(
        self,
        block_payload: Dict[str, Any],
    ) -> Optional[Any]:
        """
        Parse a single Smart Block completion into a PayoutInstruction.

        Returns None if the block is not payout-eligible (e.g., still open,
        or missing required fields).
        """
        from ..core.router import PayoutInstruction

        # Extract payout fields from the Smart Block payload
        payout_data = block_payload.get("payout", {})
        if not payout_data:
            return None

        worker_id = payout_data.get("worker_id", "")
        amount = float(payout_data.get("amount", 0))
        if not worker_id or amount <= 0:
            return None

        block_hash = _extract_block_hash(block_payload)

        return PayoutInstruction(
            worker_id=worker_id,
            smart_block_hash=block_hash,
            amount=amount,
            currency=payout_data.get("currency", "USD"),
            tx_type=payout_data.get("tx_type", "push_to_debit"),
            routing_source=payout_data.get("routing_source", ""),
            destination=payout_data.get("destination", ""),
            metadata={
                "legacy_mode": False,
                "smart_block": True,
                "block_hash": block_hash,
                "gec_metrics": block_payload.get("metrics", {}).get("gec"),
                "trust_score": block_payload.get("trust_score"),
            },
        )

    def parse_batch(
        self,
        block_payloads: List[Dict[str, Any]],
    ) -> List[Any]:
        """Parse multiple Smart Block completions, filtering out non-eligible."""
        instructions = []
        for payload in block_payloads:
            instr = self.parse_completion(payload)
            if instr is not None:
                instructions.append(instr)
        return instructions
