"""Dominion gateway — legacy system translation to Smart Block format."""

from .legacy_adapter import LegacyAdapter, LegacyRecord
from .smart_block_parser import SmartBlockParser

__all__ = ["LegacyAdapter", "LegacyRecord", "SmartBlockParser"]
