"""
LegacyAdapter — Translates legacy HR/timecard data into Smart Block format.

Supported input sources:
- CSV upload (payroll exports → Smart Block objects)
- API mapping (SAP, QuickBooks, ADP, etc.)
- Manual entry / admin interface

When legacy_mode=True:
- Trust score defaults to 1.0 (static)
- Compression rules are relaxed
- No reflex scoring unless worker record is upgraded to SBN

The adapter produces PayoutInstruction objects that the DominionRouter
can process identically to native Smart Block completions.
"""

from __future__ import annotations

import csv
import io
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class LegacyRecord:
    """A single payroll record from a legacy source."""
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    worker_id: str = ""
    worker_name: str = ""
    amount: float = 0.0
    currency: str = "USD"
    hours_worked: float = 0.0
    pay_rate: float = 0.0
    department: str = ""
    pay_period_start: Optional[str] = None
    pay_period_end: Optional[str] = None
    deductions: float = 0.0
    source_system: str = ""         # "csv", "sap", "quickbooks", etc.
    raw_data: Dict[str, Any] = field(default_factory=dict)


class LegacyAdapter:
    """
    Converts legacy payroll data into Dominion-native PayoutInstructions.

    Usage:
        adapter = LegacyAdapter(legacy_mode=True)
        records = adapter.parse_csv(csv_content)
        instructions = adapter.to_payout_instructions(records)
    """

    def __init__(self, legacy_mode: bool = True):
        self._legacy_mode = legacy_mode

    def parse_csv(self, content: str) -> List[LegacyRecord]:
        """
        Parse a CSV payroll export into LegacyRecords.

        Expected columns (flexible mapping):
        worker_id, worker_name, amount, currency, hours_worked,
        pay_rate, department, pay_period_start, pay_period_end, deductions
        """
        records: List[LegacyRecord] = []
        reader = csv.DictReader(io.StringIO(content))

        for row in reader:
            record = LegacyRecord(
                worker_id=row.get("worker_id", row.get("employee_id", "")),
                worker_name=row.get("worker_name", row.get("name", "")),
                amount=float(row.get("amount", row.get("gross_pay", 0))),
                currency=row.get("currency", "USD"),
                hours_worked=float(row.get("hours_worked", row.get("hours", 0))),
                pay_rate=float(row.get("pay_rate", row.get("rate", 0))),
                department=row.get("department", row.get("dept", "")),
                pay_period_start=row.get("pay_period_start", row.get("period_start")),
                pay_period_end=row.get("pay_period_end", row.get("period_end")),
                deductions=float(row.get("deductions", 0)),
                source_system="csv",
                raw_data=dict(row),
            )
            records.append(record)

        return records

    def to_payout_instructions(
        self,
        records: List[LegacyRecord],
        routing_source: str = "",
    ) -> List[Any]:
        """
        Convert LegacyRecords into PayoutInstructions for the router.

        In legacy_mode, metadata carries default trust and a legacy flag
        so downstream systems know this data is not SBN-native.
        """
        from ..core.router import PayoutInstruction

        instructions = []
        for record in records:
            net = record.amount - record.deductions
            instr = PayoutInstruction(
                worker_id=record.worker_id,
                amount=net,
                currency=record.currency,
                routing_source=routing_source,
                metadata={
                    "legacy_mode": self._legacy_mode,
                    "source_system": record.source_system,
                    "department": record.department,
                    "hours_worked": record.hours_worked,
                    "pay_rate": record.pay_rate,
                    "gross_amount": record.amount,
                    "deductions": record.deductions,
                    "default_trust": 1.0 if self._legacy_mode else None,
                },
            )
            instructions.append(instr)

        return instructions
