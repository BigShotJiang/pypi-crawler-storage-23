"""
Dominion SBN Client — unified interface to the SmartBlocks Network.

Wraps the SBN Python SDK (``SbnClient``) for all network operations
that Dominion needs:

- SnapChore: seal payout receipts, verify block proofs
- Lattice: register and drive payroll workflow DAGs
- Gateway: submit GEC efficiency events, request attestation
- Console: manage webhooks, project metadata
- Blocks: emit SmartBlocks for payout lifecycle events

This is Dominion's single point of contact with SBN.  Every other
module imports this client rather than touching the SDK directly.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Mapping, Optional, Sequence

logger = logging.getLogger(__name__)


class DominionSbnClient:
    """Dominion's SBN SDK wrapper.

    Initialises the underlying ``SbnClient`` and exposes domain-specific
    helpers.  All methods are thin wrappers that translate Dominion
    concepts into SBN SDK calls.

    Parameters
    ----------
    base_url:
        SBN API base URL (e.g. ``https://api.smartblocks.network``).
    api_key:
        SBN API key for authentication.
    project_id:
        The SBN project that owns Dominion's frontier and workflows.
    tenant_id:
        Optional multi-tenant context.
    tier:
        Dominion tier (1/2/3).  Tier 1 disables all SBN calls.
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8090",
        api_key: str = "",
        project_id: str = "",
        tenant_id: Optional[str] = None,
        tier: int = 1,
    ) -> None:
        self._project_id = project_id
        self._tier = tier
        self._client: Any = None

        if tier >= 2 and api_key:
            try:
                from sbn import SbnClient

                self._client = SbnClient(
                    base_url=base_url,
                    tenant_id=tenant_id,
                )
                self._client.authenticate_api_key(api_key)
                logger.info("SBN client initialised for project %s (tier %d)", project_id, tier)
            except ImportError:
                logger.warning("sbn-sdk not installed — SBN integration disabled")

    @property
    def active(self) -> bool:
        """True if the SBN SDK is available and tier >= 2."""
        return self._client is not None and self._tier >= 2

    @property
    def raw(self) -> Any:
        """Access the underlying ``SbnClient`` for advanced use."""
        return self._client

    # ------------------------------------------------------------------
    # SnapChore
    # ------------------------------------------------------------------

    def seal(self, payload: Dict[str, Any]) -> Optional[str]:
        """Seal a payload via SnapChore and return the hash.

        Returns ``None`` if tier < 2 or SBN is unreachable.
        """
        if not self.active:
            return None
        try:
            result = self._client.snapchore.capture(payload)
            return result.get("snap_hash") or result.get("hash")
        except Exception:
            logger.warning("SnapChore seal failed", exc_info=True)
            return None

    def verify(self, snap_hash: str) -> Optional[Dict[str, Any]]:
        """Verify a SnapChore hash."""
        if not self.active:
            return None
        try:
            return self._client.snapchore.verify(snap_hash)
        except Exception:
            logger.warning("SnapChore verify failed for %s", snap_hash, exc_info=True)
            return None

    def seal_chain(self, chain_id: str, payload: Dict[str, Any]) -> Optional[str]:
        """Append to an existing SnapChore chain."""
        if not self.active:
            return None
        try:
            result = self._client.snapchore.chain_append(chain_id=chain_id, payload=payload)
            return result.get("snap_hash") or result.get("hash")
        except Exception:
            logger.warning("SnapChore chain append failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Lattice (Workflow DAGs)
    # ------------------------------------------------------------------

    def create_workflow(
        self,
        *,
        name: str,
        nodes: Sequence[Mapping[str, Any]],
        edges: Optional[Sequence[Mapping[str, Any]]] = None,
        topology: str = "dag",
        gec_frontier: Optional[Mapping[str, Any]] = None,
        meta: Optional[Mapping[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Register a Lattice workflow DAG."""
        if not self.active:
            return None
        try:
            return self._client.lattice.create_workflow(
                domain="finance.payroll",
                name=name,
                nodes=nodes,
                edges=edges,
                topology=topology,
                gec_frontier=gec_frontier,
                meta=meta,
            )
        except Exception:
            logger.warning("Lattice workflow creation failed", exc_info=True)
            return None

    def get_execution_order(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """Get topological execution order for a workflow."""
        if not self.active:
            return None
        try:
            return self._client.lattice.get_execution_order(workflow_id)
        except Exception:
            logger.warning("Lattice execution order fetch failed", exc_info=True)
            return None

    def get_ready_steps(
        self,
        workflow_id: str,
        completed: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Get steps ready for execution given completed set."""
        if not self.active:
            return []
        try:
            return self._client.lattice.get_ready_steps(workflow_id, completed=completed)
        except Exception:
            logger.warning("Lattice ready-steps fetch failed", exc_info=True)
            return []

    def activate_workflow(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """Activate a workflow for execution."""
        if not self.active:
            return None
        try:
            return self._client.lattice.activate_workflow(workflow_id)
        except Exception:
            logger.warning("Lattice workflow activation failed", exc_info=True)
            return None

    def create_edge(
        self,
        *,
        source_id: str,
        target_id: str,
        edge_type: str,
        weight: float = 1.0,
        meta: Optional[Mapping[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Create a cross-workflow edge."""
        if not self.active:
            return None
        try:
            return self._client.lattice.create_edge(
                source_id=source_id,
                target_id=target_id,
                edge_type=edge_type,
                weight=weight,
                meta=meta,
            )
        except Exception:
            logger.warning("Lattice edge creation failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Gateway (attestation + GEC events)
    # ------------------------------------------------------------------

    def request_attestation(self, summary: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Submit a GEC efficiency event for attestation."""
        if not self.active:
            return None
        try:
            return self._client.gateway.request_attestation(summary)
        except Exception:
            logger.warning("Gateway attestation request failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Blocks
    # ------------------------------------------------------------------

    def create_block(
        self,
        *,
        domain: str = "finance.payroll",
        payload: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """Create a SmartBlock for a payout lifecycle event."""
        if not self.active:
            return None
        try:
            return self._client.blocks.create(domain=domain, payload=payload)
        except Exception:
            logger.warning("Block creation failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Console (webhooks)
    # ------------------------------------------------------------------

    def register_webhook(
        self,
        *,
        url: str,
        events: List[str],
        secret: str = "",
    ) -> Optional[Dict[str, Any]]:
        """Register a webhook endpoint for SBN events."""
        if not self.active:
            return None
        try:
            return self._client.console.create_webhook(
                project_id=self._project_id,
                url=url,
                events=events,
                secret=secret,
            )
        except Exception:
            logger.warning("Webhook registration failed", exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        if self._client is not None:
            self._client.close()

    def __enter__(self) -> DominionSbnClient:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()
