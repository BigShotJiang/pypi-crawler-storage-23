"""
DominionCSKProvider — Application-level CSK computation for payroll.

This is where Dominion lights up the CSK pipeline.  The network provides
the *analysis* engine (lambda_aggregate, k_from_csk, csk_decision_layer),
but only the application knows what S, H, D, R, E mean in its domain.

For finance.payroll:
  S (Structure)    — Schema/ledger integrity, field completeness
  H (Homeostasis)  — Balance stability, reconciliation drift between runs
  D (Diversity)    — Multi-entity, multi-currency, multi-tax handling
  R (Resources)    — Float health, compute efficiency, batch throughput
  E (Exchange)     — Tax API response quality, compliance feed freshness

Each dimension is computed from operational telemetry per batch, then
attached to the GEC payload before SnapChore hashing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class BatchTelemetry:
    """Operational metrics collected during a payout batch."""
    # Structure signals
    records_submitted: int = 0
    records_schema_valid: int = 0
    fields_complete: int = 0
    fields_total: int = 0

    # Homeostasis signals
    ledger_balance_delta: float = 0.0     # Drift from previous reconciliation
    calculation_variance: float = 0.0      # Stddev of per-employee calc diffs

    # Diversity signals
    unique_entities: int = 1
    unique_currencies: int = 1
    unique_tax_jurisdictions: int = 1
    total_possible_entities: int = 1

    # Resource signals (from FloatGuard)
    float_utilization_ratio: float = 1.0   # available / required
    batch_duration_ms: int = 0
    batch_duration_budget_ms: int = 1000

    # Exchange signals
    tax_api_success_rate: float = 1.0      # Successful calls / total calls
    compliance_data_age_seconds: int = 0   # How stale is the compliance data?
    compliance_data_max_age: int = 3600    # Acceptable staleness threshold


class DominionCSKProvider:
    """
    Computes the five CSK dimensions from payroll batch telemetry.

    Each dimension returns a value in [0, 1] where:
      1.0 = optimal health in this dimension
      0.0 = critical degradation

    The provider is stateless — give it telemetry, get back a CSK vector.
    Historical anchors (for H drift detection) are tracked externally.
    """

    def compute(self, telemetry: BatchTelemetry) -> Dict[str, float]:
        """Compute the full CSK vector from batch telemetry."""
        return {
            "S": self._structure(telemetry),
            "H": self._homeostasis(telemetry),
            "D": self._diversity(telemetry),
            "R": self._resources(telemetry),
            "E": self._exchange(telemetry),
        }

    def _structure(self, t: BatchTelemetry) -> float:
        """S — Schema/ledger integrity.

        Blends schema validation pass rate with field completeness.
        Both matter: a record can be schema-valid but missing optional
        fields that affect accuracy downstream.
        """
        schema_rate = (
            t.records_schema_valid / t.records_submitted
            if t.records_submitted > 0 else 1.0
        )
        field_rate = (
            t.fields_complete / t.fields_total
            if t.fields_total > 0 else 1.0
        )
        # Weighted blend: schema integrity matters more
        return min(1.0, max(0.0, 0.7 * schema_rate + 0.3 * field_rate))

    def _homeostasis(self, t: BatchTelemetry) -> float:
        """H — Balance stability between runs.

        Low variance and small ledger drift = stable system.
        Uses an exponential decay: small drift scores high, large drift
        drops rapidly toward 0.
        """
        import math
        # Normalise drift: 0 drift → 1.0, large drift → 0.0
        drift_score = math.exp(-abs(t.ledger_balance_delta) * 10.0)
        # Normalise variance: low → 1.0, high → 0.0
        variance_score = 1.0 / (1.0 + t.calculation_variance)
        return min(1.0, max(0.0, 0.5 * drift_score + 0.5 * variance_score))

    def _diversity(self, t: BatchTelemetry) -> float:
        """D — Multi-entity handling breadth.

        Measures how much of the possible entity/currency/tax space
        this batch actually exercises.  Higher coverage = the system
        is being tested across more edge cases.
        """
        entity_ratio = (
            t.unique_entities / t.total_possible_entities
            if t.total_possible_entities > 0 else 1.0
        )
        # Currency and jurisdiction add bonus diversity
        diversity_bonus = min(1.0, (t.unique_currencies + t.unique_tax_jurisdictions) / 10.0)
        return min(1.0, max(0.0, 0.6 * entity_ratio + 0.4 * diversity_bonus))

    def _resources(self, t: BatchTelemetry) -> float:
        """R — Float health and compute efficiency.

        Blends treasury liquidity (from FloatGuard) with processing
        speed relative to budget.
        """
        float_score = min(1.0, max(0.0, t.float_utilization_ratio))
        speed_score = (
            1.0 - min(1.0, t.batch_duration_ms / max(1, t.batch_duration_budget_ms))
            if t.batch_duration_budget_ms > 0 else 1.0
        )
        # Float health is weighted higher — money availability trumps speed
        return min(1.0, max(0.0, 0.7 * float_score + 0.3 * speed_score))

    def _exchange(self, t: BatchTelemetry) -> float:
        """E — Integration quality with external feeds.

        Tax API reliability and compliance data freshness.  Stale
        compliance data degrades exchange quality even if APIs respond.
        """
        api_score = min(1.0, max(0.0, t.tax_api_success_rate))
        freshness = (
            1.0 - min(1.0, t.compliance_data_age_seconds / max(1, t.compliance_data_max_age))
        )
        return min(1.0, max(0.0, 0.6 * api_score + 0.4 * freshness))
