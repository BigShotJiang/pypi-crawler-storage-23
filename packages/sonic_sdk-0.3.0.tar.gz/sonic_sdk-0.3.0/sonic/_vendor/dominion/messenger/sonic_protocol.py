"""
DominionMessenger — Encodes and sends payout messages to Sonic.

Message format follows the Sonic settlement engine protocol.
Uses DominionSonicClient for actual execution rather than raw HTTP.

Supports:
- Atomic single-destination payouts
- Atomic multi-destination splits (team projects, tax withholding)
- Conditional execution (pay IF other block closes)
- Rollback triggers (for disputed completions)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional


class TxType(str, Enum):
    PUSH_TO_DEBIT = "push_to_debit"     # Fiat: ACH/RTP/FedNow
    WALLET_PAYOUT = "wallet_payout"     # Crypto: direct wallet transfer
    MULTI_SPLIT = "multi_split"         # Atomic multi-destination
    CONDITIONAL = "conditional"         # Contingent on another event
    ROLLBACK = "rollback"               # Reversal flow


@dataclass
class PayoutMessage:
    """A Sonic-compatible payout message."""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    worker_id: str = ""
    amount: float = 0.0
    currency: str = "USD"
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    reason: str = "payout"
    tx_type: TxType = TxType.PUSH_TO_DEBIT
    routing_source: str = ""
    destination: str = ""               # Bank token or wallet address

    # Multi-split destinations (for MULTI_SPLIT tx_type)
    split_destinations: Optional[List[Dict[str, Any]]] = None

    # Conditional execution (for CONDITIONAL tx_type)
    condition_block_hash: Optional[str] = None
    condition_deadline: Optional[datetime] = None

    # Security
    encrypted: bool = False
    signature: Optional[str] = None
    hedera_anchor: Optional[str] = None  # Hedera timestamp anchor

    def to_sonic_format(self) -> Dict[str, Any]:
        """Serialize to the Sonic wire format."""
        msg = {
            "message_id": self.message_id,
            "worker_id": self.worker_id,
            "amount": str(self.amount),
            "currency": self.currency,
            "timestamp": self.timestamp.isoformat(),
            "reason": self.reason,
            "tx_type": self.tx_type.value,
            "routing_source": self.routing_source,
            "destination": self.destination,
        }
        if self.split_destinations:
            msg["split_destinations"] = self.split_destinations
        if self.condition_block_hash:
            msg["condition"] = {
                "block_hash": self.condition_block_hash,
                "deadline": self.condition_deadline.isoformat() if self.condition_deadline else None,
            }
        if self.hedera_anchor:
            msg["hedera_anchor"] = self.hedera_anchor
        return msg


class DominionMessenger:
    """
    Builds and sends payout messages via DominionSonicClient.

    Messages are:
    1. Serialized to Sonic wire format
    2. Sent to Sonic via DominionSonicClient.execute_payout()

    The messenger handles message construction.  Actual settlement
    is delegated to Sonic's state machine.
    """

    def __init__(
        self,
        sonic_client: Optional[Any] = None,
        tier: int = 1,
    ):
        self._sonic = sonic_client      # DominionSonicClient
        self._tier = tier

    async def send(self, message: PayoutMessage) -> Dict[str, Any]:
        """
        Send a payout message to Sonic via the client.

        Returns Sonic's payout result.
        """
        if self._sonic is not None and self._sonic.active:
            from ..sonic_client import SonicPayoutRequest

            rail = self._tx_type_to_rail(message.tx_type)
            req = SonicPayoutRequest(
                recipient_id=message.destination or message.worker_id,
                amount=Decimal(str(message.amount)),
                currency=message.currency,
                rail=rail,
                metadata={
                    "dominion_message_id": message.message_id,
                    "worker_id": message.worker_id,
                    "reason": message.reason,
                    "tx_type": message.tx_type.value,
                },
            )

            result = await self._sonic.execute_payout(req)
            return {
                "status": "completed" if result.success else "failed",
                "message_id": message.message_id,
                "sonic_tx_id": result.tx_id,
                "provider_ref": result.provider_ref,
                "receipt_hash": result.receipt_hash,
                "error": result.error,
            }

        return {"status": "pending", "message_id": message.message_id}

    async def send_batch(self, messages: List[PayoutMessage]) -> List[Dict[str, Any]]:
        """Send a batch of payout messages to Sonic."""
        results = []
        for msg in messages:
            result = await self.send(msg)
            results.append(result)
        return results

    @staticmethod
    def _tx_type_to_rail(tx_type: TxType) -> str:
        """Map TxType to Sonic rail."""
        mapping = {
            TxType.PUSH_TO_DEBIT: "stripe_transfer",
            TxType.WALLET_PAYOUT: "circle_usdc",
            TxType.MULTI_SPLIT: "stripe_transfer",
            TxType.CONDITIONAL: "stripe_transfer",
            TxType.ROLLBACK: "stripe_transfer",
        }
        return mapping.get(tx_type, "stripe_transfer")
