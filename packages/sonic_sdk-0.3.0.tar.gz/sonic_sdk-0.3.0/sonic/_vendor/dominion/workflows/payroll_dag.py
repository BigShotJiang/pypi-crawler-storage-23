"""
PayrollWorkflow — Deep Lattice DAG for the full payout lifecycle.

The payroll DAG models every step from instruction submission through
settlement and audit sealing. Each node is a discrete, trackable step
with dependencies enforced by Lattice's topological execution engine.

Topology: DAG (not series) — supports parallel branches for:
- milestone resolution + deduction application + stream open
- SnapChore seal + receipt creation + GEC emission (post-settlement)

The DAG is registered with SBN Lattice on startup and instantiated
per payout batch.  Dominion's router drives execution by querying
``get_ready_steps()`` and advancing nodes as they complete.

GEC frontier: finance.payroll (c_max=0.98)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DAG Node Definitions
# ---------------------------------------------------------------------------

PAYROLL_DAG_NODES: List[Dict[str, Any]] = [
    {
        "step_id": "submit",
        "name": "Accept Payout Instruction",
        "description": "Receive and validate payout instruction from Grid or legacy import.",
        "meta": {"step_type": "ingestion"},
    },
    {
        "step_id": "tax_validate",
        "name": "Tax Code Validation",
        "description": (
            "HARD STOP — verify worker has active tax codes in all assigned jurisdictions. "
            "No codes = payout blocked, event logged."
        ),
        "meta": {"step_type": "validation", "hard_stop": True},
    },
    {
        "step_id": "float_check",
        "name": "Float Liquidity Check",
        "description": "Validate treasury float via FloatGuard. Gate: HEALTHY or THROTTLED passes.",
        "meta": {"step_type": "validation"},
    },
    {
        "step_id": "calculate",
        "name": "Payout Calculation",
        "description": (
            "Run PayoutCalculator: base amount, trust modifier, compression yield. "
            "Produces PayoutBreakdown."
        ),
        "meta": {"step_type": "computation"},
    },
    # --- Parallel branch: post-calculation, pre-execution ---
    {
        "step_id": "milestone_resolve",
        "name": "Milestone Resolution",
        "description": "Check and trigger due milestones (time-based, performance). Add bonus to breakdown.",
        "meta": {"step_type": "computation"},
    },
    {
        "step_id": "deduction_apply",
        "name": "Apply Tax Withholding",
        "description": "Compute and apply all tax withholdings from TaxCodeRegistry. Deduct from net.",
        "meta": {"step_type": "computation"},
    },
    {
        "step_id": "stream_open",
        "name": "PayStream Open",
        "description": (
            "If streaming eligible: open a Sonic PayStream for windowed accrual. "
            "Otherwise: single batch payment via execute_payout."
        ),
        "meta": {"step_type": "execution"},
    },
    # --- Convergence: execution ---
    {
        "step_id": "execute",
        "name": "Sonic Execution",
        "description": "Submit payout to Sonic settlement engine via DominionSonicClient.",
        "meta": {"step_type": "execution"},
    },
    {
        "step_id": "settle",
        "name": "Await Settlement",
        "description": "Wait for Sonic settlement confirmation (webhook or poll).",
        "meta": {"step_type": "confirmation"},
    },
    # --- Parallel branch: post-settlement ---
    {
        "step_id": "seal",
        "name": "SnapChore Seal",
        "description": "Seal the payout event via SBN SnapChore for tamper-evident audit.",
        "meta": {"step_type": "attestation"},
    },
    {
        "step_id": "receipt_create",
        "name": "Create Worker Receipt",
        "description": "Generate cryptographic payout receipt for the worker.",
        "meta": {"step_type": "attestation"},
    },
    {
        "step_id": "gec_emit",
        "name": "GEC Efficiency Emission",
        "description": "Emit y/x efficiency event to SBN pipeline with optional CSK vector.",
        "meta": {"step_type": "analytics"},
    },
    {
        "step_id": "journal_log",
        "name": "Vault Journal Entry",
        "description": "Write payout event to the append-only audit journal.",
        "meta": {"step_type": "audit"},
    },
]


# ---------------------------------------------------------------------------
# DAG Edge Definitions
# ---------------------------------------------------------------------------

PAYROLL_DAG_EDGES: List[Dict[str, Any]] = [
    # Linear spine: submit → tax → float → calculate
    {"source_id": "submit", "target_id": "tax_validate", "edge_type": "sequence"},
    {"source_id": "tax_validate", "target_id": "float_check", "edge_type": "sequence"},
    {"source_id": "float_check", "target_id": "calculate", "edge_type": "sequence"},

    # Parallel branch: calculate fans out to 3 nodes
    {"source_id": "calculate", "target_id": "milestone_resolve", "edge_type": "fork"},
    {"source_id": "calculate", "target_id": "deduction_apply", "edge_type": "fork"},
    {"source_id": "calculate", "target_id": "stream_open", "edge_type": "fork"},

    # Convergence: all 3 must complete before execute
    {"source_id": "milestone_resolve", "target_id": "execute", "edge_type": "join"},
    {"source_id": "deduction_apply", "target_id": "execute", "edge_type": "join"},
    {"source_id": "stream_open", "target_id": "execute", "edge_type": "join"},

    # Execute → settle (linear)
    {"source_id": "execute", "target_id": "settle", "edge_type": "sequence"},

    # Post-settlement parallel fan-out
    {"source_id": "settle", "target_id": "seal", "edge_type": "fork"},
    {"source_id": "settle", "target_id": "receipt_create", "edge_type": "fork"},
    {"source_id": "settle", "target_id": "gec_emit", "edge_type": "fork"},
    {"source_id": "settle", "target_id": "journal_log", "edge_type": "fork"},
]


# ---------------------------------------------------------------------------
# Workflow Manager
# ---------------------------------------------------------------------------

@dataclass
class WorkflowStepResult:
    """Result of executing a single workflow step."""
    step_id: str = ""
    success: bool = False
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    snapchore_hash: Optional[str] = None
    completed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class PayrollWorkflow:
    """Manages a single payroll workflow instance through its Lattice DAG.

    On instantiation, registers the DAG with SBN Lattice (if tier >= 2).
    Drives execution by querying ready steps and advancing nodes.

    Parameters
    ----------
    sbn_client:
        DominionSbnClient for Lattice API calls.
    workflow_name:
        Human-readable name for this workflow instance.
    """

    def __init__(
        self,
        sbn_client: Any = None,
        workflow_name: str = "payroll_batch",
    ) -> None:
        self._sbn = sbn_client
        self._workflow_name = workflow_name
        self._workflow_id: Optional[str] = None
        self._completed_steps: List[str] = []
        self._step_results: Dict[str, WorkflowStepResult] = {}
        self._instance_id = str(uuid.uuid4())

    @property
    def workflow_id(self) -> Optional[str]:
        return self._workflow_id

    @property
    def completed_steps(self) -> List[str]:
        return list(self._completed_steps)

    @property
    def step_results(self) -> Dict[str, WorkflowStepResult]:
        return dict(self._step_results)

    async def register(self) -> Optional[str]:
        """Register the payroll DAG with SBN Lattice.

        Returns the workflow_id or None if SBN is unavailable.
        """
        if self._sbn is None or not self._sbn.active:
            logger.info("SBN unavailable — workflow runs in local mode")
            self._workflow_id = f"local_{self._instance_id}"
            return self._workflow_id

        from ..gec_interface.frontier_config import DOMINION_FRONTIER

        result = self._sbn.create_workflow(
            name=f"{self._workflow_name}_{self._instance_id[:8]}",
            nodes=PAYROLL_DAG_NODES,
            edges=PAYROLL_DAG_EDGES,
            topology="dag",
            gec_frontier=DOMINION_FRONTIER,
            meta={
                "instance_id": self._instance_id,
                "product": "dominion",
                "version": "2.0",
            },
        )
        if result:
            self._workflow_id = result.get("workflow_id") or result.get("id")
            logger.info("Payroll workflow registered: %s", self._workflow_id)
        else:
            self._workflow_id = f"local_{self._instance_id}"
            logger.warning("Lattice registration failed — using local workflow ID")

        return self._workflow_id

    async def activate(self) -> bool:
        """Activate the workflow for execution."""
        if self._sbn is None or not self._sbn.active or not self._workflow_id:
            return True  # Local mode: always active
        result = self._sbn.activate_workflow(self._workflow_id)
        return result is not None

    async def get_ready_steps(self) -> List[str]:
        """Get step IDs ready for execution based on current completion state."""
        if self._sbn is not None and self._sbn.active and self._workflow_id:
            steps = self._sbn.get_ready_steps(self._workflow_id, completed=self._completed_steps)
            return [s.get("step_id", s.get("id", s.get("node_id", ""))) for s in steps]

        # Local DAG traversal fallback
        return self._local_ready_steps()

    async def complete_step(self, step_id: str, result: WorkflowStepResult) -> None:
        """Mark a step as completed with its result."""
        result.step_id = step_id
        self._step_results[step_id] = result
        if result.success:
            self._completed_steps.append(step_id)
            logger.info("Workflow step completed: %s", step_id)
        else:
            logger.warning("Workflow step failed: %s — %s", step_id, result.error)

    async def is_complete(self) -> bool:
        """True if all steps have been completed successfully."""
        all_ids = {n["step_id"] for n in PAYROLL_DAG_NODES}
        return all_ids == set(self._completed_steps)

    # ------------------------------------------------------------------
    # Cross-workflow edges
    # ------------------------------------------------------------------

    async def link_to_grid_slot(self, slot_id: str) -> None:
        """Create a Lattice edge from a Grid slot to this payroll workflow."""
        if self._sbn is None or not self._sbn.active or not self._workflow_id:
            return
        self._sbn.create_edge(
            source_id=slot_id,
            target_id=self._workflow_id,
            edge_type="triggers_payroll",
            meta={"product": "dominion", "instance": self._instance_id},
        )

    async def link_to_sonic_tx(self, sonic_tx_id: str) -> None:
        """Create a Lattice edge from this workflow to a Sonic transaction."""
        if self._sbn is None or not self._sbn.active or not self._workflow_id:
            return
        self._sbn.create_edge(
            source_id=self._workflow_id,
            target_id=sonic_tx_id,
            edge_type="settles_via",
            meta={"product": "dominion", "instance": self._instance_id},
        )

    # ------------------------------------------------------------------
    # Local fallback DAG traversal
    # ------------------------------------------------------------------

    def _local_ready_steps(self) -> List[str]:
        """Compute ready steps locally when Lattice is unavailable."""
        completed = set(self._completed_steps)
        all_ids = {n["step_id"] for n in PAYROLL_DAG_NODES}

        # Build dependency map: target → set of sources
        deps: Dict[str, set] = {n["step_id"]: set() for n in PAYROLL_DAG_NODES}
        for edge in PAYROLL_DAG_EDGES:
            deps[edge["target_id"]].add(edge["source_id"])

        ready = []
        for node_id in all_ids:
            if node_id in completed:
                continue
            if deps[node_id].issubset(completed):
                ready.append(node_id)
        return ready
