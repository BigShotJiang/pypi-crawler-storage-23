"""Dominion workflows — Lattice DAG definitions for payroll lifecycle."""

from .payroll_dag import PayrollWorkflow, PAYROLL_DAG_NODES, PAYROLL_DAG_EDGES

__all__ = ["PayrollWorkflow", "PAYROLL_DAG_NODES", "PAYROLL_DAG_EDGES"]
