"""
Dominion Stillpoint Client — HTTP interface to the Stillpoint treasury engine.

Stillpoint is the float/treasury management system that provides:
- Float health monitoring (FRHI, health bands, buffer pools)
- Float commitment protocol (commit/release/expire lifecycle)
- Headroom checks (pre-flight payout feasibility)

In Tier 3 deployments, Dominion delegates float management to Stillpoint
instead of tracking it locally. This provides centralised treasury visibility
across all consumers (Dominion, Sonic, Chase, etc.).

Endpoints consumed:
- GET  /float/health     — treasury health (FRHI, bands, consumer status)
- POST /float/headroom   — check if a payout amount has headroom
- POST /float/commit     — reserve float for an in-flight payout
- POST /float/release    — free reserved float after settlement

Fail-safe: This client never raises exceptions into the caller.
All methods return typed result objects with ``success`` flags.
On timeout or network error, the caller should fall back to local
float management.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class HeadroomResult:
    """Result of a Stillpoint headroom check."""
    success: bool = False
    approved: bool = False
    headroom_after: float = 0.0
    health_band_after: str = ""
    error: Optional[str] = None


@dataclass
class CommitResult:
    """Result of a Stillpoint float commit."""
    success: bool = False
    commitment_id: Optional[int] = None
    available_after: float = 0.0
    expires_at: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ReleaseResult:
    """Result of a Stillpoint float release."""
    success: bool = False
    released_amount: float = 0.0
    available_after: float = 0.0
    error: Optional[str] = None


class DominionStillpointClient:
    """HTTP client for the Stillpoint treasury engine.

    Follows the same fail-safe pattern as DominionSonicClient:
    never raises into the caller, returns typed result objects.

    Parameters
    ----------
    base_url:
        Stillpoint API base URL (e.g. ``http://stillpoint:9005``).
    hmac_secret:
        HMAC-SHA256 shared secret for request signing.
        Must match Stillpoint's ``STILLPOINT_HMAC_SECRET``.
    source:
        Consumer identifier sent with every commitment (default: ``dominion``).
    timeout:
        HTTP timeout in seconds (default: 10s — treasury checks should be fast).
    """

    def __init__(
        self,
        *,
        base_url: str = "",
        hmac_secret: str = "",
        source: str = "dominion",
        timeout: float = 10.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._hmac_secret = hmac_secret
        self._source = source
        self._timeout = timeout
        self._http: Any = None

        if not base_url:
            logger.debug("Stillpoint client disabled (no base_url)")
            return

        try:
            import httpx

            self._http = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=timeout,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "dominion-stillpoint-client/1.0",
                },
            )
            logger.info("Stillpoint client initialised: %s", base_url)
        except ImportError:
            logger.warning("httpx not installed — Stillpoint client unavailable")

    @property
    def active(self) -> bool:
        """True if the HTTP client is initialised and a base URL was provided."""
        return self._http is not None

    def _sign_request(self, body: bytes) -> Dict[str, str]:
        """Compute HMAC-SHA256 signature headers for request signing."""
        if not self._hmac_secret:
            return {}
        timestamp = str(int(time.time()))
        message = f"{timestamp}.{body.decode()}"
        signature = hmac.new(
            self._hmac_secret.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        return {
            "X-Stillpoint-Signature": signature,
            "X-Stillpoint-Timestamp": timestamp,
        }

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    async def health(self) -> bool:
        """Check if Stillpoint is reachable and healthy.

        Returns True if GET /float/health returns 200, False on any error.
        """
        if not self.active:
            return False
        try:
            response = await self._http.get("/float/health")
            return response.status_code == 200
        except Exception:
            logger.warning("Stillpoint health check failed", exc_info=True)
            return False

    # ------------------------------------------------------------------
    # Headroom
    # ------------------------------------------------------------------

    async def check_headroom(
        self,
        amount: float,
        currency: str = "USD",
    ) -> HeadroomResult:
        """Check if a payout amount has headroom in Stillpoint's treasury.

        Maps to POST /float/headroom.
        """
        if not self.active:
            return HeadroomResult(error="Stillpoint client not active")
        try:
            import json

            body = json.dumps({"amount": amount, "currency": currency}).encode()
            headers = self._sign_request(body)

            response = await self._http.post(
                "/float/headroom",
                content=body,
                headers=headers,
            )

            if response.status_code == 200:
                data = response.json()
                return HeadroomResult(
                    success=True,
                    approved=data.get("approved", False),
                    headroom_after=data.get("headroom_after", 0.0),
                    health_band_after=data.get("health_band_after", ""),
                )

            return HeadroomResult(
                error=f"Stillpoint headroom check returned {response.status_code}",
            )
        except Exception as exc:
            logger.warning("Stillpoint headroom check failed: %s", exc)
            return HeadroomResult(error=str(exc))

    # ------------------------------------------------------------------
    # Commit / Release
    # ------------------------------------------------------------------

    async def commit_float(
        self,
        instruction_id: str,
        amount: float,
        currency: str = "USD",
        *,
        pay_stream_id: Optional[str] = None,
        stream_window_seq: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CommitResult:
        """Reserve float in Stillpoint for an in-flight payout.

        Maps to POST /float/commit.
        """
        if not self.active:
            return CommitResult(error="Stillpoint client not active")
        try:
            import json

            payload: Dict[str, Any] = {
                "instruction_id": instruction_id,
                "amount": amount,
                "currency": currency,
                "source": self._source,
            }
            if pay_stream_id is not None:
                payload["pay_stream_id"] = pay_stream_id
            if stream_window_seq is not None:
                payload["stream_window_seq"] = stream_window_seq
            if metadata:
                payload["metadata"] = metadata

            body = json.dumps(payload).encode()
            headers = self._sign_request(body)

            response = await self._http.post(
                "/float/commit",
                content=body,
                headers=headers,
            )

            if response.status_code == 201:
                data = response.json()
                return CommitResult(
                    success=True,
                    commitment_id=data.get("commitment_id"),
                    available_after=data.get("available_after_commitment", 0.0),
                    expires_at=data.get("expires_at"),
                )

            # 422 = insufficient float, 423 = frozen, 409 = duplicate, etc.
            detail = ""
            try:
                detail = str(response.json().get("detail", ""))
            except Exception:
                pass
            return CommitResult(
                error=f"Stillpoint commit returned {response.status_code}: {detail}",
            )
        except Exception as exc:
            logger.warning("Stillpoint commit failed: %s", exc)
            return CommitResult(error=str(exc))

    async def release_float(
        self,
        instruction_id: str,
        reason: str = "settlement_confirmed",
        confirmation_data: Optional[Dict[str, Any]] = None,
    ) -> ReleaseResult:
        """Release committed float in Stillpoint after settlement.

        Maps to POST /float/release.
        """
        if not self.active:
            return ReleaseResult(error="Stillpoint client not active")
        try:
            import json

            payload: Dict[str, Any] = {
                "instruction_id": instruction_id,
                "reason": reason,
            }
            if confirmation_data:
                payload["confirmation_data"] = confirmation_data

            body = json.dumps(payload).encode()
            headers = self._sign_request(body)

            response = await self._http.post(
                "/float/release",
                content=body,
                headers=headers,
            )

            if response.status_code == 200:
                data = response.json()
                return ReleaseResult(
                    success=True,
                    released_amount=data.get("released_amount", 0.0),
                    available_after=data.get("available_after_release", 0.0),
                )

            detail = ""
            try:
                detail = str(response.json().get("detail", ""))
            except Exception:
                pass
            return ReleaseResult(
                error=f"Stillpoint release returned {response.status_code}: {detail}",
            )
        except Exception as exc:
            logger.warning("Stillpoint release failed: %s", exc)
            return ReleaseResult(error=str(exc))
