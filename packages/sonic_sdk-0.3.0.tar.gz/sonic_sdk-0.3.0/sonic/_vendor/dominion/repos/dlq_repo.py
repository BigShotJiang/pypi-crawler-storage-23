"""Async repository for the Dominion dead-letter queue."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.models import DomDeadLetter


class DLQRepo:
    """Manages failed SBN submissions queued for retry.

    Retry schedule: exponential backoff (30s, 60s, 120s, 240s, 480s).
    After max_retries, status flips to ``exhausted``.
    """

    BACKOFF_BASE = 30  # seconds

    def __init__(self, session: AsyncSession):
        self._session = session

    async def enqueue(
        self,
        *,
        operation: str,
        payload: Dict[str, Any],
        error_message: str = "",
        max_retries: int = 5,
    ) -> DomDeadLetter:
        now = datetime.now(timezone.utc)
        row = DomDeadLetter(
            id=uuid.uuid4(),
            operation=operation,
            payload=payload,
            error_message=error_message,
            max_retries=max_retries,
            status="pending",
            next_retry_at=now + timedelta(seconds=self.BACKOFF_BASE),
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def get_retryable(self, limit: int = 50) -> List[DomDeadLetter]:
        """Fetch items ready for retry (next_retry_at <= now)."""
        now = datetime.now(timezone.utc)
        stmt = (
            select(DomDeadLetter)
            .where(DomDeadLetter.status.in_(["pending", "retrying"]))
            .where(DomDeadLetter.next_retry_at <= now)
            .order_by(DomDeadLetter.next_retry_at)
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def mark_retrying(self, dlq_id: uuid.UUID) -> None:
        await self._session.execute(
            update(DomDeadLetter)
            .where(DomDeadLetter.id == dlq_id)
            .values(
                status="retrying",
                last_attempt_at=datetime.now(timezone.utc),
            )
        )
        await self._session.flush()

    async def mark_succeeded(self, dlq_id: uuid.UUID) -> None:
        await self._session.execute(
            update(DomDeadLetter)
            .where(DomDeadLetter.id == dlq_id)
            .values(status="succeeded", last_attempt_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    async def mark_failed(self, dlq_id: uuid.UUID, error: str) -> None:
        """Increment retry count.  Transition to ``exhausted`` if limit hit."""
        stmt = select(DomDeadLetter).where(DomDeadLetter.id == dlq_id)
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()
        if row is None:
            return

        row.retry_count += 1
        row.error_message = error
        row.last_attempt_at = datetime.now(timezone.utc)

        if row.retry_count >= row.max_retries:
            row.status = "exhausted"
            row.next_retry_at = None
        else:
            delay = self.BACKOFF_BASE * (2 ** row.retry_count)
            row.next_retry_at = datetime.now(timezone.utc) + timedelta(seconds=delay)
            row.status = "pending"

        await self._session.flush()

    async def count_by_status(self) -> Dict[str, int]:
        from sqlalchemy import func
        stmt = (
            select(DomDeadLetter.status, func.count())
            .group_by(DomDeadLetter.status)
        )
        result = await self._session.execute(stmt)
        return dict(result.all())
