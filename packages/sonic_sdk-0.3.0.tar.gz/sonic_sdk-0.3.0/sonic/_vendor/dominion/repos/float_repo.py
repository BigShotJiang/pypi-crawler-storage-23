"""Async repository for float commitments."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.models import DomFloatCommitment


class FloatRepo:
    """Replaces the in-memory ``FloatGuard._committed`` scalar.

    Each in-flight payout gets an individual commitment row.
    The total committed amount is ``SUM(amount) WHERE status = 'committed'``.
    """

    def __init__(self, session: AsyncSession):
        self._session = session

    async def commit(
        self,
        instruction_id: str,
        amount: float,
        currency: str = "USD",
    ) -> DomFloatCommitment:
        row = DomFloatCommitment(
            id=uuid.uuid4(),
            instruction_id=instruction_id,
            amount=amount,
            currency=currency,
            status="committed",
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def release(self, instruction_id: str) -> None:
        await self._session.execute(
            update(DomFloatCommitment)
            .where(DomFloatCommitment.instruction_id == instruction_id)
            .where(DomFloatCommitment.status == "committed")
            .values(status="released", released_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    async def settle(self, instruction_id: str) -> None:
        await self._session.execute(
            update(DomFloatCommitment)
            .where(DomFloatCommitment.instruction_id == instruction_id)
            .where(DomFloatCommitment.status == "committed")
            .values(status="settled", released_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    async def total_committed(self, currency: str = "USD") -> float:
        stmt = (
            select(func.coalesce(func.sum(DomFloatCommitment.amount), 0.0))
            .where(DomFloatCommitment.status == "committed")
            .where(DomFloatCommitment.currency == currency)
        )
        result = await self._session.execute(stmt)
        return float(result.scalar())
