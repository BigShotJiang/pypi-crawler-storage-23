"""Async repository for Milestones."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.models import DomMilestone


class MilestoneRepo:
    """Replaces the in-memory ``MilestoneScheduler._milestones`` dict."""

    def __init__(self, session: AsyncSession):
        self._session = session

    async def create(
        self,
        *,
        milestone_id: str,
        worker_id: str,
        milestone_type: str,
        description: str = "",
        bonus_amount: float = 0.0,
        currency: str = "USD",
        trigger_at: datetime | None = None,
        gec0_threshold: float | None = None,
        trust_threshold: float | None = None,
        contract_lock_id: str | None = None,
        metadata: dict | None = None,
    ) -> DomMilestone:
        row = DomMilestone(
            id=uuid.uuid4(),
            milestone_id=milestone_id,
            worker_id=worker_id,
            milestone_type=milestone_type,
            description=description,
            bonus_amount=bonus_amount,
            currency=currency,
            status="scheduled",
            trigger_at=trigger_at,
            gec0_threshold=gec0_threshold,
            trust_threshold=trust_threshold,
            contract_lock_id=contract_lock_id,
            metadata_=metadata or {},
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def get(self, milestone_id: str) -> DomMilestone | None:
        stmt = select(DomMilestone).where(DomMilestone.milestone_id == milestone_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_scheduled_for_worker(self, worker_id: str) -> List[DomMilestone]:
        stmt = (
            select(DomMilestone)
            .where(DomMilestone.worker_id == worker_id)
            .where(DomMilestone.status == "scheduled")
            .order_by(DomMilestone.trigger_at.asc().nullslast())
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def mark_eligible(self, milestone_id: str) -> None:
        await self._session.execute(
            update(DomMilestone)
            .where(DomMilestone.milestone_id == milestone_id)
            .where(DomMilestone.status == "scheduled")
            .values(status="eligible", resolved_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    async def mark_paid(self, milestone_id: str) -> None:
        await self._session.execute(
            update(DomMilestone)
            .where(DomMilestone.milestone_id == milestone_id)
            .values(status="paid", resolved_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    async def get_due_time_based(
        self, worker_id: str, now: datetime | None = None,
    ) -> List[DomMilestone]:
        """Return scheduled time-based milestones whose trigger_at <= now."""
        now = now or datetime.now(timezone.utc)
        stmt = (
            select(DomMilestone)
            .where(DomMilestone.worker_id == worker_id)
            .where(DomMilestone.status == "scheduled")
            .where(DomMilestone.milestone_type == "time_based")
            .where(DomMilestone.trigger_at <= now)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
