"""
PayStreamAdapter — Thin delegation layer to Sonic's PayStream API.

Replaces the client-side FiatStreamer/CryptoStreamer pattern with
server-side streaming owned by Sonic.  The fiat-vs-crypto distinction
collapses into a ``rail`` parameter on the PayStream itself.

Sonic manages:
  - Windowed accrual (30-min default cadence)
  - g_ewma risk policy (PRIME/NORMAL/RISK/FROZEN)
  - Micro-payout disbursement per window close
  - SBN batch attestation
  - Holdback and release logic

Dominion's role:
  - Open a stream when a payout is streaming-eligible
  - Feed accrual events as work is completed
  - React to stream lifecycle webhooks (window closed, policy changed)
  - Store pay_stream_id on DomReceipt for audit linkage
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, List, Optional

from ..sonic_client import (
    DominionSonicClient,
    PayStreamOpenRequest,
    PayStreamResult,
    PayStreamState,
)

logger = logging.getLogger(__name__)


@dataclass
class StreamOpenResult:
    """Result of opening a PayStream via Sonic."""
    success: bool = False
    pay_stream_id: str = ""
    status: str = ""
    policy_state: str = ""
    sbn_slot_id: Optional[str] = None
    error: Optional[str] = None


@dataclass
class AccrualResult:
    """Result of recording work earnings into a stream."""
    success: bool = False
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    retryable: bool = False


@dataclass
class WindowCloseResult:
    """Result of closing a stream window (triggers micro-payout)."""
    success: bool = False
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    retryable: bool = False


class PayStreamAdapter:
    """Adapter that delegates streaming to Sonic's PayStream API.

    Replaces FiatStreamer and CryptoStreamer.  Instead of decomposing
    a payout into micro-payments client-side, this adapter opens a
    server-side PayStream in Sonic and lets Sonic handle the windowed
    accrual, risk policy, and micro-payout lifecycle.

    Parameters
    ----------
    sonic_client:
        An initialised DominionSonicClient instance.
    default_cadence_seconds:
        Default window duration (seconds).  Sonic default is 1800 (30 min).
    default_rail:
        Default payment rail (e.g. ``stripe_transfer``, ``moov_ach``,
        ``circle_usdc``).
    """

    def __init__(
        self,
        sonic_client: DominionSonicClient,
        *,
        default_cadence_seconds: int = 1800,
        default_rail: str = "stripe_transfer",
    ) -> None:
        self._sonic = sonic_client
        self._default_cadence = default_cadence_seconds
        self._default_rail = default_rail

    @property
    def active(self) -> bool:
        """True if the underlying Sonic client is initialised."""
        return self._sonic.active

    # ------------------------------------------------------------------
    # Open / close lifecycle
    # ------------------------------------------------------------------

    async def open_stream(
        self,
        payer_id: str,
        payee_id: str,
        rate_amount: Decimal,
        *,
        currency: str = "USD",
        rail: Optional[str] = None,
        rate_unit: str = "per_window",
        cadence_seconds: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> StreamOpenResult:
        """Open a Sonic PayStream.

        Returns a StreamOpenResult with the ``pay_stream_id`` that must
        be stored on the DomReceipt and passed to subsequent accrual
        and close calls.
        """
        if not self.active:
            return StreamOpenResult(
                success=False,
                error="Sonic client not initialised",
            )

        request = PayStreamOpenRequest(
            payer_id=payer_id,
            payee_id=payee_id,
            currency=currency,
            rail=rail or self._default_rail,
            rate_amount=rate_amount,
            rate_unit=rate_unit,
            cadence_seconds=cadence_seconds or self._default_cadence,
            metadata=metadata,
        )

        state = await self._sonic.open_pay_stream(request)

        if state.status == "error":
            error_msg = ""
            if state.raw_response:
                error_msg = str(state.raw_response.get("error", state.raw_response))
            return StreamOpenResult(
                success=False,
                error=error_msg or "Failed to open PayStream",
            )

        logger.info(
            "PayStream opened: %s (payee=%s, rail=%s, cadence=%ds)",
            state.pay_stream_id,
            payee_id,
            rail or self._default_rail,
            cadence_seconds or self._default_cadence,
        )

        return StreamOpenResult(
            success=True,
            pay_stream_id=state.pay_stream_id,
            status=state.status,
            policy_state=state.policy_state,
            sbn_slot_id=state.sbn_slot_id,
        )

    async def close_stream(self, pay_stream_id: str) -> PayStreamResult:
        """Terminal close with reconciliation and merkle root."""
        result = await self._sonic.close_pay_stream(pay_stream_id)
        if result.success:
            logger.info("PayStream closed: %s", pay_stream_id)
        else:
            logger.warning("PayStream close failed: %s — %s", pay_stream_id, result.error)
        return result

    # ------------------------------------------------------------------
    # Accrual (feed work earnings into the stream)
    # ------------------------------------------------------------------

    async def accrue(
        self,
        pay_stream_id: str,
        units: Decimal,
        *,
        unit_price: Optional[Decimal] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AccrualResult:
        """Record work earnings into the stream's current window.

        Called as work is completed (per task, per hour, per block).
        Sonic accumulates these into the current 30-min window.
        """
        result = await self._sonic.accrue_pay_stream(
            pay_stream_id,
            units=units,
            unit_price=unit_price,
            metadata=metadata,
        )

        return AccrualResult(
            success=result.success,
            data=result.data,
            error=result.error,
            retryable=result.retryable,
        )

    async def close_window(
        self,
        pay_stream_id: str,
        *,
        gec_y: int = 0,
        gec_x: int = 0,
    ) -> WindowCloseResult:
        """Close the current window and trigger a micro-payout.

        GEC y/x values feed into Sonic's g_ewma policy engine.
        """
        result = await self._sonic.close_pay_stream_window(
            pay_stream_id,
            gec_y=gec_y,
            gec_x=gec_x,
        )

        return WindowCloseResult(
            success=result.success,
            data=result.data,
            error=result.error,
            retryable=result.retryable,
        )

    # ------------------------------------------------------------------
    # Pause / resume / freeze
    # ------------------------------------------------------------------

    async def pause(self, pay_stream_id: str) -> PayStreamState:
        """Manually pause the stream (no payouts until resumed)."""
        return await self._sonic.pause_pay_stream(pay_stream_id)

    async def resume(self, pay_stream_id: str) -> PayStreamState:
        """Resume a paused stream (opens a new window)."""
        return await self._sonic.resume_pay_stream(pay_stream_id)

    async def freeze(self, pay_stream_id: str, reason: str = "") -> PayStreamResult:
        """Policy-driven freeze (100% holdback)."""
        return await self._sonic.freeze_pay_stream(pay_stream_id, reason=reason)

    async def unfreeze(self, pay_stream_id: str) -> PayStreamState:
        """Resume from a policy freeze."""
        return await self._sonic.unfreeze_pay_stream(pay_stream_id)

    async def release_holdback(self, pay_stream_id: str) -> PayStreamResult:
        """Release all policy-held amounts as a micro-payout."""
        return await self._sonic.release_pay_stream_holdback(pay_stream_id)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    async def get_state(self, pay_stream_id: str) -> Optional[PayStreamState]:
        """Query the current state of a PayStream."""
        return await self._sonic.get_pay_stream(pay_stream_id)

    async def list_windows(
        self,
        pay_stream_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List accrual windows for a PayStream."""
        return await self._sonic.list_pay_stream_windows(
            pay_stream_id, limit=limit, offset=offset,
        )

    async def list_streams(
        self,
        *,
        status: Optional[str] = None,
        payee_id: Optional[str] = None,
        payer_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """List PayStreams with optional filters."""
        return await self._sonic.list_pay_streams(
            status=status,
            payee_id=payee_id,
            payer_id=payer_id,
            limit=limit,
            offset=offset,
        )

    # ------------------------------------------------------------------
    # Convenience: open from PayoutBreakdown
    # ------------------------------------------------------------------

    async def open_from_breakdown(
        self,
        payer_id: str,
        worker_id: str,
        breakdown: Any,
        *,
        rail: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> StreamOpenResult:
        """Open a PayStream from a PayoutBreakdown (convenience wrapper).

        Uses the breakdown's net_amount as the rate_amount and
        currency from the breakdown.  The breakdown must have
        ``streaming_eligible == True``.
        """
        if not getattr(breakdown, "streaming_eligible", False):
            return StreamOpenResult(
                success=False,
                error="Payout is not streaming-eligible",
            )

        stream_meta = {
            "dominion_source": "payout_breakdown",
            "base_amount": getattr(breakdown, "base_amount", 0),
            "trust_modifier": getattr(breakdown, "trust_modifier", 1.0),
            "compression_yield": getattr(breakdown, "compression_yield", 0),
        }
        if metadata:
            stream_meta.update(metadata)

        return await self.open_stream(
            payer_id=payer_id,
            payee_id=worker_id,
            rate_amount=Decimal(str(getattr(breakdown, "net_amount", 0))),
            currency=getattr(breakdown, "currency", "USD"),
            rail=rail,
            metadata=stream_meta,
        )
