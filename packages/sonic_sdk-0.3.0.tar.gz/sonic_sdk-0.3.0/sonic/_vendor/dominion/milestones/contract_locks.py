"""
ContractLock — Future-dated crypto smart contract locks for milestone payouts.

For crypto-denominated milestones, Dominion can lock funds in a
time-locked smart contract that releases automatically at the
milestone timestamp.  This guarantees zero-lag execution for
on-chain payouts.

Supported chains: XRPL, XLM, HBAR, USDC (ERC-20 / Solana SPL).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional


class LockStatus(str, Enum):
    PENDING = "pending"           # Lock created, not yet on-chain
    LOCKED = "locked"             # Funds locked on-chain
    RELEASED = "released"         # Milestone triggered, funds released
    EXPIRED = "expired"           # Lock expired without trigger
    CANCELLED = "cancelled"       # Manually cancelled


@dataclass
class ContractLock:
    """A time-locked smart contract for a milestone payout."""
    lock_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    milestone_id: str = ""
    worker_id: str = ""
    amount: float = 0.0
    currency: str = "USDC"
    chain: str = "xrpl"           # xrpl, xlm, hbar, erc20, solana
    release_at: Optional[datetime] = None
    destination_wallet: str = ""
    status: LockStatus = LockStatus.PENDING
    tx_hash: Optional[str] = None       # On-chain transaction hash
    snapchore_hash: Optional[str] = None  # SBN attestation of lock creation
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_releasable(self) -> bool:
        """Can this lock be released now?"""
        if self.status != LockStatus.LOCKED:
            return False
        if self.release_at is None:
            return False
        return datetime.now(timezone.utc) >= self.release_at
