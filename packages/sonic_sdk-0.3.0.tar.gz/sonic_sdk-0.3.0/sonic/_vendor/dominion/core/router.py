"""
DominionRouter — Main runtime orchestrator.

All payout instructions enter here.  The router:
1. Validates tax codes (hard stop) via TaxCodeRegistry
2. Parses Smart Block completions
3. Calculates eligible payout via PayoutCalculator
4. Validates liquidity via FloatGuard
5. Resolves milestones via MilestoneScheduler
6. Executes settlement via DominionSonicClient
7. Seals receipts via DominionSbnClient (SnapChore)
8. Emits GEC efficiency metrics via SBN SDK
9. Drives execution through Lattice payroll DAG

Every step is SnapChore-attestable (Tier 2+) and tracked
in the Lattice workflow DAG.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional

from .calculator import PayoutCalculator, PayoutBreakdown
from .float_guard import FloatGuard, FloatStatus

logger = logging.getLogger(__name__)


class PayoutStatus(str, Enum):
    PENDING = "pending"
    TAX_HOLD = "tax_hold"           # Hard stop — no tax codes
    VALIDATED = "validated"         # FloatGuard approved
    MILESTONE_APPLIED = "milestone_applied"
    SUBMITTED = "submitted"         # Sent to Sonic
    COMPLETED = "completed"         # Sonic confirmed
    HELD = "held"                   # FloatGuard hold
    FAILED = "failed"


@dataclass
class PayoutInstruction:
    """A single payout instruction derived from a Smart Block completion."""
    instruction_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    worker_id: str = ""
    smart_block_hash: Optional[str] = None
    amount: float = 0.0
    currency: str = "USD"
    tx_type: str = "push_to_debit"
    routing_source: str = ""
    destination: str = ""           # Bank token or wallet address
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class PayoutResult:
    """Result of processing a payout instruction through the router."""
    instruction_id: str = ""
    status: PayoutStatus = PayoutStatus.PENDING
    breakdown: Optional[PayoutBreakdown] = None
    float_status: Optional[FloatStatus] = None
    sonic_tx_id: Optional[str] = None
    sonic_receipt_hash: Optional[str] = None
    snapchore_hash: Optional[str] = None
    gec_metrics: Optional[Dict[str, Any]] = None
    tax_withheld: float = 0.0
    error: Optional[str] = None
    processed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class DominionRouter:
    """
    Main payout orchestration engine.

    Coordinates the full payout pipeline via the Lattice payroll DAG:
    submit → tax_validate → float_check → calculate →
    [milestone | deduction | stream] → execute → settle →
    [seal | receipt | gec_emit | journal_log]

    GEC integration:
      y = payouts processed successfully
      x = payouts submitted
      domain = "finance.payroll"
    """

    def __init__(
        self,
        calculator: PayoutCalculator,
        float_guard: FloatGuard,
        sbn_client: Optional[Any] = None,
        sonic_client: Optional[Any] = None,
        tax_registry: Optional[Any] = None,
        tier: int = 1,
    ):
        self._calculator = calculator
        self._float_guard = float_guard
        self._sbn = sbn_client         # DominionSbnClient
        self._sonic = sonic_client      # DominionSonicClient
        self._tax = tax_registry        # TaxCodeRegistry
        self._tier = tier

    async def process_batch(
        self,
        instructions: List[PayoutInstruction],
    ) -> List[PayoutResult]:
        """
        Process a batch of payout instructions through the full pipeline.

        Returns one PayoutResult per instruction.  GEC metrics are computed
        across the batch: y = successful count, x = total submitted.
        """
        results: List[PayoutResult] = []
        successful = 0

        for instruction in instructions:
            result = await self._process_single(instruction)
            if result.status == PayoutStatus.COMPLETED:
                successful += 1
            results.append(result)

        # Emit GEC metrics for the batch (Tier 2+)
        if self._tier >= 2:
            gec_payload = self._build_gec_payload(
                y=successful,
                x=len(instructions),
            )
            for r in results:
                r.gec_metrics = gec_payload

            # Emit to SBN via SDK
            await self._emit_gec(gec_payload)

        return results

    async def _process_single(
        self,
        instruction: PayoutInstruction,
    ) -> PayoutResult:
        """Process a single payout instruction through the pipeline."""
        result = PayoutResult(instruction_id=instruction.instruction_id)

        # 1. TAX VALIDATION (hard stop)
        if self._tax is not None:
            tax_result = self._tax.validate_worker(
                instruction.worker_id,
                instruction.amount,
            )
            if not tax_result.valid:
                result.status = PayoutStatus.TAX_HOLD
                result.error = "; ".join(tax_result.errors)
                logger.warning(
                    "TAX HOLD for worker %s: %s",
                    instruction.worker_id,
                    result.error,
                )
                return result

            # Apply tax withholdings to instruction metadata
            result.tax_withheld = tax_result.total_withheld
            instruction.metadata["tax_withholdings"] = [
                {
                    "tax_type": w.tax_type.value,
                    "amount": w.withheld_amount,
                    "rate": w.effective_rate,
                }
                for w in tax_result.withholdings
            ]
            instruction.metadata["net_after_tax"] = tax_result.net_after_tax

        # 2. Calculate payout breakdown (trust modifiers, compression yield)
        breakdown = self._calculator.calculate(instruction)
        result.breakdown = breakdown

        # Apply tax deduction to net amount
        if result.tax_withheld > 0:
            breakdown.deductions = result.tax_withheld
            breakdown.net_amount = breakdown.net_amount - result.tax_withheld

        # 3. Validate liquidity via FloatGuard
        liquidity = await self._float_guard.check(
            amount=breakdown.net_amount,
            currency=instruction.currency,
            routing_source=instruction.routing_source,
        )
        result.float_status = liquidity.status

        if liquidity.status == FloatStatus.BLOCKED:
            result.status = PayoutStatus.HELD
            result.error = f"FloatGuard hold: {liquidity.reason}"
            return result

        result.status = PayoutStatus.VALIDATED

        # 4. Submit to Sonic for settlement
        if self._sonic is not None and self._sonic.active:
            from ..sonic_client import SonicPayoutRequest

            payout_req = SonicPayoutRequest(
                recipient_id=instruction.destination or instruction.worker_id,
                amount=Decimal(str(breakdown.net_amount)),
                currency=instruction.currency,
                rail=self._tx_type_to_rail(instruction.tx_type),
                metadata={
                    "dominion_instruction_id": instruction.instruction_id,
                    "worker_id": instruction.worker_id,
                    "smart_block_hash": instruction.smart_block_hash,
                },
            )

            sonic_result = await self._sonic.execute_payout(payout_req)

            if sonic_result.success:
                result.status = PayoutStatus.COMPLETED
                result.sonic_tx_id = sonic_result.tx_id
                result.sonic_receipt_hash = sonic_result.receipt_hash
            else:
                if sonic_result.retryable:
                    result.status = PayoutStatus.SUBMITTED
                    result.error = f"Sonic pending: {sonic_result.error}"
                else:
                    result.status = PayoutStatus.FAILED
                    result.error = f"Sonic failed: {sonic_result.error}"
                return result
        else:
            # No Sonic client — mark as completed in local mode
            result.status = PayoutStatus.COMPLETED
            logger.info(
                "Sonic unavailable — payout completed locally (instruction %s)",
                instruction.instruction_id,
            )

        # 5. Seal via SnapChore (Tier 2+)
        if self._sbn is not None and self._sbn.active:
            seal_payload = {
                "type": "dominion_payout",
                "instruction_id": instruction.instruction_id,
                "worker_id": instruction.worker_id,
                "amount": breakdown.net_amount,
                "currency": instruction.currency,
                "tax_withheld": result.tax_withheld,
                "sonic_tx_id": result.sonic_tx_id,
                "status": result.status.value,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            result.snapchore_hash = self._sbn.seal(seal_payload)

        return result

    async def _emit_gec(self, gec_payload: Dict[str, Any]) -> None:
        """Compute GEC via SBN's ``POST /api/gec/compute`` endpoint.

        The *gec_payload* dict is already shaped as a valid GEC compute
        request (built by ``build_dominion_gec_payload``).  We pass it
        directly to the SDK rather than wrapping it in an attestation
        envelope.
        """
        if self._sbn is None or not self._sbn.active:
            return
        try:
            self._sbn.raw.gec.compute(**gec_payload)
        except Exception:
            logger.warning("GEC compute failed (non-blocking)", exc_info=True)

    def _build_gec_payload(self, y: int, x: int) -> Dict[str, Any]:
        """Build the ``POST /api/gec/compute`` request payload."""
        from ..gec_interface.payload_builder import build_dominion_gec_payload
        return build_dominion_gec_payload(y=y, x=x)

    @staticmethod
    def _tx_type_to_rail(tx_type: str) -> str:
        """Map Dominion tx_type to Sonic rail identifier."""
        rail_map = {
            "push_to_debit": "stripe_transfer",
            "ach": "moov_ach",
            "rtp": "stripe_transfer",
            "fednow": "stripe_transfer",
            "wallet_payout": "circle_usdc",
            "xrpl": "circle_usdc",
            "xlm": "circle_usdc",
            "hbar": "circle_usdc",
            "usdc": "circle_usdc",
        }
        return rail_map.get(tx_type, "stripe_transfer")
