"""
PayoutCalculator — Compression yield, trust modifiers, and bonus triggers.

Runs the core payout math:
- Base amount from Smart Block completion
- Trust modifier (dynamic in Tier 3, static 1.0 in Tier 1/2)
- Compression yield (efficiency bonus from GEC scoring)
- Streaming decomposition (for real-time pay)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class PayoutBreakdown:
    """Detailed breakdown of a calculated payout."""
    base_amount: float = 0.0
    trust_modifier: float = 1.0           # 0.0–1.0, from NUMA (Tier 3)
    compression_yield: float = 0.0        # Bonus from GEC efficiency
    milestone_bonus: float = 0.0          # From MilestoneManager
    deductions: float = 0.0               # Tax withholding, garnishments, etc.
    net_amount: float = 0.0
    currency: str = "USD"
    streaming_eligible: bool = False      # Can this be streamed vs. batched?
    stream_intervals: Optional[int] = None  # Number of streaming intervals
    pay_stream_id: Optional[str] = None   # Sonic PayStream ID (set after stream_open)
    sbn_slot_id: Optional[str] = None     # SBN slot ID from Sonic stream session
    calculation_metadata: Dict[str, Any] = field(default_factory=dict)
    calculated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class PayoutCalculator:
    """
    Stateless payout calculator.

    In Tier 1 (legacy): trust_modifier = 1.0, no compression yield.
    In Tier 2 (attested): trust_modifier = 1.0, compression yield from GEC.
    In Tier 3 (agent): trust_modifier from NUMA, full compression yield.
    """

    def __init__(
        self,
        tier: int = 1,
        default_trust: float = 1.0,
        compression_rate: float = 0.0,
    ):
        self._tier = tier
        self._default_trust = default_trust
        self._compression_rate = compression_rate

    def calculate(
        self,
        instruction: Any,
        trust_score: Optional[float] = None,
        gec0_score: Optional[float] = None,
    ) -> PayoutBreakdown:
        """
        Calculate the full payout breakdown for an instruction.

        Parameters
        ----------
        instruction:
            A PayoutInstruction with base amount and metadata.
        trust_score:
            NUMA-derived trust modifier (Tier 3 only). None → default.
        gec0_score:
            Current GEC₀ for this worker/project. Drives compression yield.
        """
        base = float(instruction.amount)

        # Trust modifier — static in Tier 1/2, NUMA-driven in Tier 3
        trust = trust_score if (trust_score is not None and self._tier >= 3) else self._default_trust

        # Compression yield — reward for high GEC efficiency (Tier 2+)
        compression = 0.0
        if self._tier >= 2 and gec0_score is not None and self._compression_rate > 0:
            compression = base * self._compression_rate * gec0_score

        net = (base * trust) + compression

        return PayoutBreakdown(
            base_amount=base,
            trust_modifier=trust,
            compression_yield=compression,
            net_amount=net,
            currency=getattr(instruction, "currency", "USD"),
            streaming_eligible=self._is_streaming_eligible(base, trust),
            calculation_metadata={
                "tier": self._tier,
                "trust_source": "numa" if trust_score is not None else "default",
                "compression_rate": self._compression_rate,
            },
        )

    def stream_payout(
        self,
        breakdown: PayoutBreakdown,
        interval_seconds: int = 60,
        duration_seconds: int = 3600,
    ) -> List[Dict[str, Any]]:
        """
        Decompose a payout into streaming intervals.

        .. deprecated::
            Use ``PayStreamAdapter.open_from_breakdown()`` instead.
            Sonic now owns windowed accrual streaming server-side.
            This method is retained for backward compatibility only.
        """
        import warnings
        warnings.warn(
            "stream_payout() is deprecated. Use PayStreamAdapter.open_from_breakdown() "
            "to delegate streaming to Sonic's PayStream API.",
            DeprecationWarning,
            stacklevel=2,
        )
        if not breakdown.streaming_eligible:
            return [{"amount": breakdown.net_amount, "interval": 0, "type": "batch"}]

        num_intervals = max(1, duration_seconds // interval_seconds)
        per_interval = breakdown.net_amount / num_intervals

        return [
            {
                "amount": round(per_interval, 6),
                "interval": i,
                "interval_seconds": interval_seconds,
                "type": "stream",
            }
            for i in range(num_intervals)
        ]

    def _is_streaming_eligible(self, amount: float, trust: float) -> bool:
        """Workers with high trust and sufficient amount qualify for streaming."""
        return trust >= 0.7 and amount >= 10.0
