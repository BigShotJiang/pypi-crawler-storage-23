"""Interfaces for capturing SnapChore hardware telemetry and system metadata."""

from __future__ import annotations

import hashlib
import os
import platform
import random
import time as _time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Mapping, Optional

try:
    from core.env import current_environment, is_secure_environment
except ImportError:
    # Standalone mode — inline the tiny helpers so snapchore-core has zero SBN deps.
    _SECURE_ENVS = {"prod", "production", "staging", "stage"}

    def current_environment() -> str:  # type: ignore[misc]
        raw = os.getenv("ENVIRONMENT") or os.getenv("SB_ENV") or os.getenv("SNAPCHORE_ENV")
        return (raw.strip().lower() if raw else "dev") or "dev"

    def is_secure_environment(value: str | None = None) -> bool:  # type: ignore[misc]
        env = (value.strip().lower() if value else current_environment())
        return env in _SECURE_ENVS

from ..logging import trace


# ---------------------------------------------------------------------------
# System metadata collection (stdlib only — no external deps)
# ---------------------------------------------------------------------------

def _collect_system_meta() -> Dict[str, Any]:
    """Collect real system metadata from the host using only the stdlib.

    Every field is deterministic for a given host+process, except for
    ``boot_relative_ns`` which anchors the capture to a monotonic clock
    position (temporal binding).
    """

    # Hardware fingerprint: SHA-256 of the MAC-derived node ID.
    # uuid.getnode() returns an int derived from the network interface MAC
    # address, which is stable across reboots on the same machine.
    import uuid as _uuid

    raw_node = _uuid.getnode()
    hw_fingerprint = hashlib.sha256(str(raw_node).encode()).hexdigest()

    # Hostname hash: we never expose the raw hostname in telemetry.
    hostname_hash = hashlib.sha256(platform.node().encode()).hexdigest()

    # Memory info (best-effort, Linux-specific /proc/meminfo fallback).
    mem_total_kb: Optional[int] = None
    try:
        with open("/proc/meminfo", "r") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    mem_total_kb = int(line.split()[1])
                    break
    except Exception:
        pass  # non-Linux or restricted environment

    return {
        "os": platform.system(),
        "os_release": platform.release(),
        "os_version": platform.version(),
        "arch": platform.machine(),
        "python_version": platform.python_version(),
        "hostname_hash": hostname_hash,
        "hw_fingerprint": hw_fingerprint,
        "cpu_count": os.cpu_count(),
        "pid": os.getpid(),
        "mem_total_kb": mem_total_kb,
        "boot_relative_ns": _time.monotonic_ns(),
    }


# ---------------------------------------------------------------------------
# Snapshot dataclass
# ---------------------------------------------------------------------------

@dataclass
class SnapChoreDeviceSnapshot:
    """Container for simulated or real device sensor data."""

    timestamp: datetime
    lat: float
    lon: float
    altitude_m: float
    accuracy_m: float
    speed_mps: float
    camera_hash: str
    expected_hash: Optional[str]
    imu: Mapping[str, float]
    battery_pct: float
    is_charging: bool
    orientation: str
    device_id: str
    environment: str
    system_meta: Dict[str, Any] = field(default_factory=dict)
    stubbed: bool = False
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_payload(self) -> Dict[str, Any]:
        """Return a dict ready to be consumed by the validator pipeline."""

        payload: Dict[str, Any] = {
            "device_timestamp": self.timestamp,
            "device_lat": self.lat,
            "device_lon": self.lon,
            "expected_hash": self.expected_hash,
            "gps": {
                "lat": self.lat,
                "lon": self.lon,
                "altitude_m": self.altitude_m,
                "accuracy_m": self.accuracy_m,
                "speed_mps": self.speed_mps,
            },
            "camera": {"hash": self.camera_hash},
            "imu": dict(self.imu),
            "battery": {
                "level_pct": round(self.battery_pct, 2),
                "is_charging": self.is_charging,
            },
            "orientation": self.orientation,
            "device_id": self.device_id,
            "environment": self.environment,
            "system_meta": dict(self.system_meta),
            "stubbed_capture": self.stubbed,
        }
        payload.update(self.extra)
        return payload

    def to_logging_meta(self) -> Dict[str, Any]:
        """Produce JSON-friendly metadata for structured logging."""

        imu_payload = {
            key: round(value, 6) if isinstance(value, (int, float)) else value
            for key, value in self.imu.items()
        }
        return {
            "device_id": self.device_id,
            "environment": self.environment,
            "stubbed_capture": self.stubbed,
            "timestamp": self.timestamp.isoformat(),
            "camera_hash": self.camera_hash,
            "expected_hash": self.expected_hash,
            "battery_level_pct": round(self.battery_pct, 2),
            "orientation": self.orientation,
            "gps": {
                "lat": round(self.lat, 6),
                "lon": round(self.lon, 6),
                "altitude_m": round(self.altitude_m, 3),
                "accuracy_m": round(self.accuracy_m, 3),
                "speed_mps": round(self.speed_mps, 3),
            },
            "imu": imu_payload,
            "system_meta": {
                k: v for k, v in self.system_meta.items()
                # Omit the monotonic marker from logs — it's only useful
                # inside the canonical hash surface.
                if k != "boot_relative_ns"
            },
            **self.extra,
        }


# ---------------------------------------------------------------------------
# Device interface
# ---------------------------------------------------------------------------

class SnapChoreDeviceInterface:
    """High level interface responsible for building hardware capture payloads."""

    def __init__(self, *, simulate: Optional[bool] = None, rng: Optional[random.Random] = None) -> None:
        env = current_environment()
        default_simulation = not is_secure_environment(env)
        self._simulate = default_simulation if simulate is None else simulate
        self._environment = env
        self._rng = rng or random.Random()
        self._device_id = "snapchore-sim" if self._simulate else _derive_device_id()

    @property
    def simulate(self) -> bool:
        return self._simulate

    def capture(self) -> Dict[str, Any]:
        """Capture telemetry from the device or emit a simulated payload."""

        if self._simulate:
            snapshot = self._build_simulated_snapshot(stub=False)
        else:
            snapshot = self._capture_real_snapshot()

        payload = snapshot.to_payload()
        trace(
            "snapchore.device.capture",
            snapshot.camera_hash,
            meta={**snapshot.to_logging_meta(), "simulate": self._simulate},
        )
        return payload

    # ------------------------------------------------------------------
    # Simulation helpers
    # ------------------------------------------------------------------
    def _build_simulated_snapshot(self, *, stub: bool) -> SnapChoreDeviceSnapshot:
        now = datetime.now()
        lat_variation = self._rng.uniform(-0.0007, 0.0007)
        lon_variation = self._rng.uniform(-0.0007, 0.0007)
        base_lat = 39.2904
        base_lon = -76.6122
        lat = base_lat + lat_variation
        lon = base_lon + lon_variation

        altitude = 12.0 + self._rng.uniform(-1.5, 1.5)
        accuracy = max(1.0, self._rng.gauss(3.0, 0.75))
        speed = max(0.0, self._rng.gauss(0.5, 0.25))

        imu_payload = {
            "accel_x": self._rng.uniform(-0.02, 0.02),
            "accel_y": self._rng.uniform(-0.02, 0.02),
            "accel_z": 9.81 + self._rng.uniform(-0.05, 0.05),
            "gyro_x": self._rng.uniform(-0.01, 0.01),
            "gyro_y": self._rng.uniform(-0.01, 0.01),
            "gyro_z": self._rng.uniform(-0.01, 0.01),
        }

        orientation = self._rng.choice(["portrait", "landscape", "flat"])
        battery_pct = max(5.0, min(100.0, self._rng.gauss(78.0, 10.0)))
        is_charging = battery_pct < 40.0 and self._rng.random() < 0.25

        camera_hash = f"cam-{self._rng.randrange(1, 2 ** 32):08x}"

        # Simulated system metadata mirrors the real schema with fake values.
        sim_system_meta: Dict[str, Any] = {
            "os": "SimOS",
            "os_release": "0.0.0-sim",
            "os_version": "simulated",
            "arch": "sim64",
            "python_version": platform.python_version(),  # keep real for compat
            "hostname_hash": f"sim_{self._rng.randrange(1, 2 ** 32):08x}",
            "hw_fingerprint": f"sim_hw_{self._rng.randrange(1, 2 ** 64):016x}",
            "cpu_count": 4,
            "pid": os.getpid(),
            "mem_total_kb": 8_388_608,
            "boot_relative_ns": _time.monotonic_ns(),
        }

        # Derive expected_hash from the simulated system_meta fields,
        # exactly as _capture_real_snapshot does — authenticate_moment
        # re-derives this hash and compares, so a mock string will fail.
        stable_parts = "|".join([
            sim_system_meta["hw_fingerprint"],
            sim_system_meta["hostname_hash"],
            sim_system_meta["os"],
            sim_system_meta["arch"],
            str(sim_system_meta["cpu_count"]),
        ])
        expected_hash = hashlib.sha256(stable_parts.encode()).hexdigest()

        extra: Dict[str, Any] = {
            "simulation": True,
            "stubbed_source": stub,
        }

        return SnapChoreDeviceSnapshot(
            timestamp=now,
            lat=lat,
            lon=lon,
            altitude_m=altitude,
            accuracy_m=accuracy,
            speed_mps=speed,
            camera_hash=camera_hash,
            expected_hash=expected_hash,
            imu=imu_payload,
            battery_pct=battery_pct,
            is_charging=is_charging,
            orientation=orientation,
            device_id=self._device_id,
            environment=self._environment,
            system_meta=sim_system_meta,
            stubbed=stub,
            extra=extra,
        )

    # ------------------------------------------------------------------
    # Real system capture
    # ------------------------------------------------------------------
    def _capture_real_snapshot(self) -> SnapChoreDeviceSnapshot:
        """Collect real system metadata and available device telemetry.

        Device-level sensors (GPS, IMU, camera) are populated with sentinel
        values when running on a server host.  The *system_meta* section is
        always populated with real data from the Python stdlib.
        """

        now = datetime.now(timezone.utc)
        sys_meta = _collect_system_meta()

        # Derive a deterministic expected_hash from the stable system
        # properties so that verify can compare without external state.
        stable_parts = "|".join([
            sys_meta.get("hw_fingerprint", ""),
            sys_meta.get("hostname_hash", ""),
            sys_meta.get("os", ""),
            sys_meta.get("arch", ""),
            str(sys_meta.get("cpu_count", "")),
        ])
        expected_hash = hashlib.sha256(stable_parts.encode()).hexdigest()

        # Server hosts do not have GPS/IMU/camera — mark as absent.
        return SnapChoreDeviceSnapshot(
            timestamp=now,
            lat=0.0,
            lon=0.0,
            altitude_m=0.0,
            accuracy_m=-1.0,   # sentinel: no GPS fix
            speed_mps=0.0,
            camera_hash="none",
            expected_hash=expected_hash,
            imu={
                "accel_x": 0.0, "accel_y": 0.0, "accel_z": 0.0,
                "gyro_x": 0.0, "gyro_y": 0.0, "gyro_z": 0.0,
            },
            battery_pct=-1.0,  # sentinel: no battery
            is_charging=False,
            orientation="server",
            device_id=self._device_id,
            environment=self._environment,
            system_meta=sys_meta,
            stubbed=False,
            extra={"server_capture": True},
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _derive_device_id() -> str:
    """Produce a stable, privacy-safe device identifier from hardware traits."""

    import uuid as _uuid

    raw = f"{_uuid.getnode()}|{platform.node()}|{platform.machine()}"
    return f"sbn-{hashlib.sha256(raw.encode()).hexdigest()[:16]}"


__all__ = ["SnapChoreDeviceInterface", "SnapChoreDeviceSnapshot", "_collect_system_meta"]
