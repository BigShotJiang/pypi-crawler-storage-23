"""SnapChore validation: verify that a captured snapshot is authentic.

Supports three input types:
  - ``image``:   EXIF metadata + device GPS cross-check.
  - ``snapshot``: Legacy system-hash comparison.
  - ``system``:  Full system-metadata validation (OS, arch, hw_fingerprint,
                 hostname_hash) plus time-drift tolerance.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_DEFAULT_DRIFT_SEC = 120


def _env_drift_sec(fallback: int = _DEFAULT_DRIFT_SEC) -> int:
    """Return time-drift tolerance from ``SB_SNAPCHORE_TIME_DRIFT_SEC`` or *fallback*."""
    raw = os.environ.get("SB_SNAPCHORE_TIME_DRIFT_SEC")
    if raw is not None:
        try:
            return int(raw)
        except (ValueError, TypeError):
            logger.warning("Invalid SB_SNAPCHORE_TIME_DRIFT_SEC=%r, using %s", raw, fallback)
    return fallback


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_snap(
    meta: Dict[str, Any],
    device_data: Dict[str, Any],
    time_drift_sec: int | None = None,
    geo_drift_m: int = 100,
    input_type: str = "image",
) -> Dict[str, Any]:
    """Validate a SnapChore capture payload.

    Parameters
    ----------
    meta:
        Metadata extracted from the source artifact (EXIF for images, or
        ``snapchore_context`` for system captures).
    device_data:
        Device telemetry payload as returned by
        ``SnapChoreDeviceInterface.capture()``.
    time_drift_sec:
        Maximum allowed difference in seconds between the metadata timestamp
        and the device timestamp.
    geo_drift_m:
        Maximum allowed distance in metres between the image GPS coordinates
        and the device GPS coordinates (image mode only).
    input_type:
        One of ``"image"``, ``"snapshot"``, or ``"system"``.

    Returns
    -------
    dict with keys ``time_check``, ``geo_check`` (or ``system_check``),
    ``valid``, and ``snapshot_hash``.
    """

    if time_drift_sec is None:
        time_drift_sec = _env_drift_sec()

    if input_type == "system":
        return _validate_system(meta, device_data, time_drift_sec=time_drift_sec)

    result: Dict[str, Any] = {
        "time_check": False,
        "geo_check": False,
        "valid": False,
        "snapshot_hash": None,
    }

    # Time Check
    try:
        time_key = "DateTime" if input_type == "image" else "timestamp"
        time_str = meta.get(time_key, "")
        if not time_str:
            raise ValueError(f"No {time_key} in metadata")

        if input_type == "image":
            input_time = datetime.strptime(time_str, "%Y:%m:%d %H:%M:%S")
        else:
            from dateutil import parser as date_parser
            input_time = date_parser.parse(time_str)

        device_time = device_data["device_timestamp"]
        time_diff = abs((device_time - input_time).total_seconds())
        result["time_check"] = time_diff <= time_drift_sec
    except Exception as e:
        logger.warning("Time check failed: %s", e)

    # Geo or System Hash Check
    try:
        if input_type == "image":
            from geopy.distance import distance

            gps = meta.get("GPSInfo", {})
            if not gps:
                raise ValueError("No GPSInfo in metadata")
            lat_dms = gps.get("GPSLatitude", ((0, 1), (0, 1), (0, 1)))
            lon_dms = gps.get("GPSLongitude", ((0, 1), (0, 1), (0, 1)))

            def rational_to_float(r):  # type: ignore[no-untyped-def]
                return r[0] / r[1] if r[1] != 0 else 0.0

            img_lat = rational_to_float(lat_dms[0]) + rational_to_float(lat_dms[1]) / 60 + rational_to_float(lat_dms[2]) / 3600
            img_lon = rational_to_float(lon_dms[0]) + rational_to_float(lon_dms[1]) / 60 + rational_to_float(lon_dms[2]) / 3600
            device_lat = device_data["device_lat"]
            device_lon = device_data["device_lon"]

            dist = distance((img_lat, img_lon), (device_lat, device_lon)).meters
            result["geo_check"] = dist <= geo_drift_m
        else:
            expected_hash = device_data.get("expected_hash")
            snapshot_hash = meta.get("system_hash")
            result["geo_check"] = (snapshot_hash == expected_hash) if expected_hash and snapshot_hash else False
    except Exception as e:
        logger.warning("Geo/System check failed: %s", e)

    result["valid"] = result["time_check"] and result["geo_check"]

    if result["valid"]:
        snap_data = json.dumps(meta, sort_keys=True) + json.dumps(device_data, default=str, sort_keys=True)
        result["snapshot_hash"] = hashlib.sha256(snap_data.encode()).hexdigest()

    return result


# ---------------------------------------------------------------------------
# System snapshot validation
# ---------------------------------------------------------------------------

def _validate_system(
    captured: Dict[str, Any],
    reference: Dict[str, Any],
    *,
    time_drift_sec: int | None = None,
) -> Dict[str, Any]:
    """Validate a system-type capture against reference device data.

    ``captured`` is the ``snapchore_context`` dict that was embedded in the
    block at sign time.  ``reference`` is a freshly-collected device payload
    (or the same payload re-loaded from the persisted block for self-check).

    Checks performed:
      1. **time_check** — device_timestamp within ``time_drift_sec`` of now.
      2. **system_check** — hw_fingerprint, hostname_hash, os, and arch match
         between captured and reference.
      3. **expected_hash_check** — the ``expected_hash`` derived from system
         properties matches.
    """

    if time_drift_sec is None:
        time_drift_sec = _env_drift_sec()

    result: Dict[str, Any] = {
        "time_check": False,
        "system_check": False,
        "expected_hash_check": False,
        "valid": False,
        "snapshot_hash": None,
        "mismatches": [],
    }

    # --- 1. Time drift ---------------------------------------------------
    try:
        cap_ts = captured.get("device_timestamp")
        if isinstance(cap_ts, str):
            from dateutil import parser as date_parser
            cap_ts = date_parser.parse(cap_ts)
        if isinstance(cap_ts, datetime):
            now = datetime.now(timezone.utc)
            if cap_ts.tzinfo is None:
                cap_ts = cap_ts.replace(tzinfo=timezone.utc)
            drift = abs((now - cap_ts).total_seconds())
            result["time_check"] = drift <= time_drift_sec
        else:
            logger.warning("system_validate: device_timestamp not a datetime (%s)", type(cap_ts))
    except Exception as exc:
        logger.warning("system_validate time_check failed: %s", exc)

    # --- 2. System property match ----------------------------------------
    cap_sys = captured.get("system_meta") or {}
    ref_sys = reference.get("system_meta") or {}

    # Fields that MUST be identical between capture and reference to confirm
    # the block was produced on the same host/environment.
    _STABLE_FIELDS = ("hw_fingerprint", "hostname_hash", "os", "arch")

    mismatches = []
    for fld in _STABLE_FIELDS:
        cap_val = cap_sys.get(fld)
        ref_val = ref_sys.get(fld)
        if cap_val is None and ref_val is None:
            continue  # both absent — acceptable
        if cap_val != ref_val:
            mismatches.append({"field": fld, "captured": cap_val, "reference": ref_val})

    result["system_check"] = len(mismatches) == 0
    result["mismatches"] = mismatches

    # --- 3. Expected hash ------------------------------------------------
    cap_expected = captured.get("expected_hash")
    ref_expected = reference.get("expected_hash")
    if cap_expected and ref_expected:
        result["expected_hash_check"] = cap_expected == ref_expected
    elif cap_expected:
        # Re-derive from reference system_meta and compare.
        stable_parts = "|".join([
            ref_sys.get("hw_fingerprint", ""),
            ref_sys.get("hostname_hash", ""),
            ref_sys.get("os", ""),
            ref_sys.get("arch", ""),
            str(ref_sys.get("cpu_count", "")),
        ])
        derived = hashlib.sha256(stable_parts.encode()).hexdigest()
        result["expected_hash_check"] = cap_expected == derived

    # --- Overall verdict -------------------------------------------------
    result["valid"] = (
        result["time_check"]
        and result["system_check"]
        and result["expected_hash_check"]
    )

    if result["valid"]:
        snap_data = (
            json.dumps(captured, sort_keys=True, default=str)
            + json.dumps(reference, sort_keys=True, default=str)
        )
        result["snapshot_hash"] = hashlib.sha256(snap_data.encode()).hexdigest()

    return result


def validate_system_context(block_payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Convenience: validate the ``snapchore_context`` embedded in a block.

    Performs a self-check by collecting fresh system metadata from the current
    host and comparing it against the captured context.  This is useful for
    server-side attestation flows where the signing host IS the system being
    authenticated.

    Returns the validation result dict, or ``None`` if no context is present.
    """

    context = block_payload.get("snapchore_context")
    if not context or not isinstance(context, dict):
        return None

    from .capture import SnapChoreDeviceInterface

    env_val = os.getenv("SB_SNAPCHORE_TIME_DRIFT_SEC")
    drift = 300  # default for cross-reference (two-capture) validation
    if env_val is not None:
        try:
            drift = int(env_val)
        except (ValueError, TypeError):
            pass

    fresh = SnapChoreDeviceInterface(simulate=False).capture()
    return _validate_system(context, fresh, time_drift_sec=drift)


# ---------------------------------------------------------------------------
# Single-capture moment authentication
# ---------------------------------------------------------------------------

_STABLE_SYSTEM_FIELDS = ("hw_fingerprint", "hostname_hash", "os", "arch")

# Default time-drift tolerance for system-level sealing.  Capture and
# authentication happen in the same seal() call so drift is typically
# sub-second.  10 s is generous enough for any reasonable system load.
_DEFAULT_SYSTEM_DRIFT_SEC = 10


def authenticate_moment(
    captured_context: Dict[str, Any],
    *,
    time_drift_sec: Optional[int] = None,
) -> Dict[str, Any]:
    """Authenticate a single device capture as a moment in time.

    Unlike ``validate_system_context`` (which collects a *second* capture for
    cross-reference), this function validates the captured context against
    ``now()`` and re-derives the ``expected_hash`` from the stable fields
    within the same capture for self-consistency.  One capture, one call.

    This is the canonical entry point for moment authentication — used by
    ``SmartBlockBase.sign()``, ``SmartBlock.seal()``, and ``BitBlock.seal()``.

    Parameters
    ----------
    captured_context:
        The ``snapchore_context`` dict as returned by
        ``SnapChoreDeviceInterface.capture()``.
    time_drift_sec:
        Maximum allowed age of the capture in seconds.  If ``None``,
        reads ``SB_SNAPCHORE_TIME_DRIFT_SEC`` from the environment
        (default: 10 seconds for system-level sealing).

    Returns
    -------
    dict with keys:
        ``time_check``  — bool, capture timestamp within drift of now.
        ``consistency_check`` — bool, expected_hash matches re-derivation.
        ``valid`` — bool, all checks passed.
        ``snapshot_hash`` — str or None, the *moment hash*: a deterministic
            digest of the authenticated capture.  Present only when valid.
    """

    if time_drift_sec is None:
        env_val = os.getenv("SB_SNAPCHORE_TIME_DRIFT_SEC")
        if env_val is not None:
            try:
                time_drift_sec = int(env_val)
            except (ValueError, TypeError):
                logger.warning(
                    "Invalid SB_SNAPCHORE_TIME_DRIFT_SEC=%r — using default %ds",
                    env_val, _DEFAULT_SYSTEM_DRIFT_SEC,
                )
                time_drift_sec = _DEFAULT_SYSTEM_DRIFT_SEC
        else:
            time_drift_sec = _DEFAULT_SYSTEM_DRIFT_SEC

    result: Dict[str, Any] = {
        "time_check": False,
        "consistency_check": False,
        "valid": False,
        "snapshot_hash": None,
    }

    # --- 1. Time freshness against now() ---------------------------------
    try:
        cap_ts = captured_context.get("device_timestamp")
        if isinstance(cap_ts, str):
            from dateutil import parser as date_parser
            cap_ts = date_parser.parse(cap_ts)
        if isinstance(cap_ts, datetime):
            now = datetime.now(timezone.utc)
            if cap_ts.tzinfo is None:
                cap_ts = cap_ts.replace(tzinfo=timezone.utc)
            drift = abs((now - cap_ts).total_seconds())
            result["time_check"] = drift <= time_drift_sec
        else:
            logger.warning("authenticate_moment: device_timestamp not a datetime (%s)", type(cap_ts))
    except Exception as exc:
        logger.warning("authenticate_moment time_check failed: %s", exc)

    # --- 2. Self-consistency of expected_hash ----------------------------
    cap_sys = captured_context.get("system_meta") or {}
    cap_expected = captured_context.get("expected_hash")

    if cap_expected:
        stable_parts = "|".join([
            cap_sys.get("hw_fingerprint", ""),
            cap_sys.get("hostname_hash", ""),
            cap_sys.get("os", ""),
            cap_sys.get("arch", ""),
            str(cap_sys.get("cpu_count", "")),
        ])
        derived = hashlib.sha256(stable_parts.encode()).hexdigest()
        result["consistency_check"] = (cap_expected == derived)
    else:
        # No expected_hash in context — cannot verify consistency.
        logger.warning("authenticate_moment: no expected_hash in captured context")

    # --- 3. Verdict ------------------------------------------------------
    result["valid"] = result["time_check"] and result["consistency_check"]

    if result["valid"]:
        # The moment hash: a deterministic digest of the authenticated
        # capture.  This is the value that enters the seal surface —
        # transitively time-bound without raw timestamps in the hash.
        moment_data = json.dumps(captured_context, sort_keys=True, default=str)
        result["snapshot_hash"] = hashlib.sha256(moment_data.encode()).hexdigest()

    return result
