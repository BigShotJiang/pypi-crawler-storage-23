"""SnapChore specific logging helpers."""

from __future__ import annotations

from typing import Any, Mapping, MutableMapping, Optional

try:  # pragma: no cover - defensive fallback for optional dependency
    from app.obs import logging as obs_logging  # type: ignore
except Exception:  # pragma: no cover - executed only when observability is unavailable
    obs_logging = None  # type: ignore[assignment]


def _ensure_mapping(name: str, value: Any) -> MutableMapping[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return {str(key): val for key, val in value.items()}
    raise TypeError(f"{name} must be a mapping when provided")


def trace(event: str, snapchore_hash: Optional[str], /, **context: Any) -> None:
    """Emit a structured SnapChore observability event.

    Parameters
    ----------
    event:
        Name of the structured event to emit.
    snapchore_hash:
        Hash representing the capture payload that should be associated with the
        log line. The value is forwarded to the observability pipeline so that
        downstream systems can attribute telemetry back to the originating
        device capture.
    **context:
        Additional keyword arguments are forwarded to the observability logger.
        ``meta`` must be a mapping when supplied. ``severity`` defaults to
        ``"info"`` when omitted.
    """

    severity = str(context.pop("severity", "info"))
    meta = _ensure_mapping("meta", context.pop("meta", None))

    payload: MutableMapping[str, Any] = {str(key): value for key, value in context.items()}
    payload["snapchore_hash"] = snapchore_hash

    if obs_logging is not None:
        snapchore_logger = getattr(obs_logging, "log_snapchore_event", None)
        if callable(snapchore_logger):
            snapchore_logger(event, severity=severity, meta=meta, **payload)
            return

        severity_key = severity.lower()
        fallback = {
            "warning": getattr(obs_logging, "log_warning", None),
            "error": getattr(obs_logging, "log_error", None),
        }.get(severity_key, getattr(obs_logging, "log_info", None))

        if callable(fallback):
            fallback(
                event,
                component="snapchore.capture",
                meta=meta,
                **payload,
            )
            return

    import logging

    logger = logging.getLogger("snapchore")
    logger.log(
        getattr(logging, severity.upper(), logging.INFO),
        "%s | %s",
        event,
        {"snapchore_hash": snapchore_hash, **meta, **payload},
    )


__all__ = ["trace"]

