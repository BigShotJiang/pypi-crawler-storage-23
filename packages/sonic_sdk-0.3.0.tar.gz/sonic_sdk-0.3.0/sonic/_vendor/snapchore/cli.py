"""SnapChore CLI — hash, seal, verify, and chain from the command line.

Usage::

    # Hash arbitrary JSON
    snapchore hash '{"model": "gpt-4", "tokens": 1500}'
    echo '{"x": 1}' | snapchore hash -

    # Seal a SmartBlock
    snapchore seal --domain ai.inference '{"tokens": 1500}'

    # Verify a hash
    snapchore verify '{"tokens": 1500}' <hash>

    # Verify a sealed block (JSON file or stdin)
    snapchore verify-block block.json

    # Chain operations
    snapchore chain create
    snapchore chain create --id my-chain
    snapchore chain append <chain-id> <block-hash>
    snapchore chain show <chain-id>
    snapchore chain verify <chain-id>
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from . import (
    SmartBlock,
    SnapChoreChain,
    snapchore_capture,
    snapchore_verify,
    snapchore_hash,
    CANON_VERSION,
    __version__,
)


def _read_json(source: str) -> dict:
    """Read JSON from a string, file path, or stdin (when source is '-')."""
    if source == "-":
        raw = sys.stdin.read()
    elif source.startswith("{") or source.startswith("["):
        raw = source
    else:
        # Treat as file path
        with open(source) as f:
            raw = f.read()
    return json.loads(raw)


def _json_out(obj: dict) -> None:
    """Pretty-print JSON to stdout."""
    json.dump(obj, sys.stdout, indent=2, default=str)
    sys.stdout.write("\n")


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


def cmd_hash(args: argparse.Namespace) -> int:
    """Compute SnapChore hash of JSON input."""
    data = _read_json(args.input)
    h = snapchore_capture(data)
    if h is None:
        print("error: failed to compute hash", file=sys.stderr)
        return 1
    if args.json:
        _json_out({"hash": h, "canon_version": CANON_VERSION})
    else:
        print(h)
    return 0


def cmd_seal(args: argparse.Namespace) -> int:
    """Seal a SmartBlock from JSON payload."""
    payload = _read_json(args.input)
    block = SmartBlock(
        domain=args.domain,
        block_type=args.type,
        payload=payload,
    )
    block.seal()
    d = block.to_dict()
    if args.output:
        with open(args.output, "w") as f:
            json.dump(d, f, indent=2, default=str)
            f.write("\n")
        print(f"sealed: {d['snapchore_hash']}")
        print(f"wrote:  {args.output}")
    else:
        _json_out(d)
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    """Verify a payload against an expected hash."""
    data = _read_json(args.input)
    ok = snapchore_verify(data, args.hash)
    if args.json:
        recomputed = snapchore_capture(data) or ""
        _json_out({
            "valid": ok,
            "expected_hash": args.hash,
            "recomputed_hash": recomputed,
        })
    else:
        if ok:
            print("VALID")
        else:
            recomputed = snapchore_capture(data) or ""
            print(f"INVALID  expected={args.hash}  got={recomputed}")
    return 0 if ok else 1


def cmd_verify_block(args: argparse.Namespace) -> int:
    """Verify a serialized SmartBlock's integrity."""
    data = _read_json(args.input)
    block = SmartBlock.from_dict(data)
    ok = block.verify()
    if args.json:
        _json_out({
            "valid": ok,
            "block_id": block.id,
            "snapchore_hash": block.snapchore_hash,
        })
    else:
        if ok:
            print(f"VALID  block={block.id}  hash={block.snapchore_hash}")
        else:
            print(f"INVALID  block={block.id}")
    return 0 if ok else 1


# In-memory chain store for CLI session (chain files for persistence)
_cli_chains: dict[str, SnapChoreChain] = {}


def _load_chain_file(path: str) -> Optional[SnapChoreChain]:
    """Load a chain from a JSON file."""
    try:
        with open(path) as f:
            data = json.load(f)
        return SnapChoreChain.from_dict(data)
    except FileNotFoundError:
        return None


def _save_chain_file(path: str, chain: SnapChoreChain) -> None:
    """Save a chain to a JSON file."""
    with open(path, "w") as f:
        json.dump(chain.to_dict(), f, indent=2, default=str)
        f.write("\n")


def cmd_chain(args: argparse.Namespace) -> int:
    """Chain sub-commands: create, append, show, verify."""
    sub = args.chain_cmd

    if sub == "create":
        chain = SnapChoreChain(chain_id=args.id)
        outfile = args.output or f"{chain.chain_id}.chain.json"
        _save_chain_file(outfile, chain)
        print(f"chain_id: {chain.chain_id}")
        print(f"file:     {outfile}")
        return 0

    if sub == "append":
        chain_file = args.chain_file
        chain = _load_chain_file(chain_file)
        if chain is None:
            print(f"error: chain file not found: {chain_file}", file=sys.stderr)
            return 1
        entry = chain.append_raw(
            block_hash=args.block_hash,
            event_type=args.event_type,
            block_id=args.block_id,
        )
        _save_chain_file(chain_file, chain)
        if args.json:
            _json_out(entry.to_dict())
        else:
            print(f"appended: index={entry.index}  chain_hash={entry.chain_hash}")
        return 0

    if sub == "show":
        chain_file = args.chain_file
        chain = _load_chain_file(chain_file)
        if chain is None:
            print(f"error: chain file not found: {chain_file}", file=sys.stderr)
            return 1
        _json_out(chain.to_dict())
        return 0

    if sub == "verify":
        chain_file = args.chain_file
        chain = _load_chain_file(chain_file)
        if chain is None:
            print(f"error: chain file not found: {chain_file}", file=sys.stderr)
            return 1
        ok = chain.verify()
        if args.json:
            break_at = chain.find_break() if not ok else None
            _json_out({"valid": ok, "length": len(chain), "break_at": break_at})
        else:
            if ok:
                print(f"VALID  length={len(chain)}  head={chain.head_hash}")
            else:
                break_at = chain.find_break()
                print(f"INVALID  break_at={break_at}  length={len(chain)}")
        return 0 if ok else 1

    print(f"unknown chain command: {sub}", file=sys.stderr)
    return 1


def cmd_version(args: argparse.Namespace) -> int:
    """Print version info."""
    _json_out({
        "snapchore": __version__,
        "canon_version": CANON_VERSION,
    })
    return 0


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="snapchore",
        description="SnapChore — cryptographic integrity for stateful events",
    )
    parser.add_argument("--version", action="store_true", help="Show version")
    sub = parser.add_subparsers(dest="command")

    # hash
    p_hash = sub.add_parser("hash", help="Compute SnapChore hash")
    p_hash.add_argument("input", help="JSON string, file path, or '-' for stdin")
    p_hash.add_argument("--json", action="store_true", help="Output as JSON object")

    # seal
    p_seal = sub.add_parser("seal", help="Seal a SmartBlock")
    p_seal.add_argument("input", help="JSON payload (string, file, or '-')")
    p_seal.add_argument("--domain", default="general", help="Block domain")
    p_seal.add_argument("--type", default="event", help="Block type")
    p_seal.add_argument("-o", "--output", help="Write sealed block to file")

    # verify
    p_verify = sub.add_parser("verify", help="Verify payload against hash")
    p_verify.add_argument("input", help="JSON payload (string, file, or '-')")
    p_verify.add_argument("hash", help="Expected SnapChore hash")
    p_verify.add_argument("--json", action="store_true", help="Output as JSON object")

    # verify-block
    p_vblock = sub.add_parser("verify-block", help="Verify a sealed SmartBlock")
    p_vblock.add_argument("input", help="Block JSON (file or '-')")
    p_vblock.add_argument("--json", action="store_true", help="Output as JSON object")

    # chain
    p_chain = sub.add_parser("chain", help="Chain operations")
    chain_sub = p_chain.add_subparsers(dest="chain_cmd")

    p_cc = chain_sub.add_parser("create", help="Create a new chain")
    p_cc.add_argument("--id", default=None, help="Custom chain ID")
    p_cc.add_argument("-o", "--output", help="Output file (default: <chain-id>.chain.json)")

    p_ca = chain_sub.add_parser("append", help="Append hash to chain")
    p_ca.add_argument("chain_file", help="Chain JSON file")
    p_ca.add_argument("block_hash", help="Block hash to append")
    p_ca.add_argument("--event-type", default="block_sealed", help="Event type")
    p_ca.add_argument("--block-id", default=None, help="Optional block ID")
    p_ca.add_argument("--json", action="store_true", help="Output as JSON")

    p_cs = chain_sub.add_parser("show", help="Show chain state")
    p_cs.add_argument("chain_file", help="Chain JSON file")

    p_cv = chain_sub.add_parser("verify", help="Verify chain integrity")
    p_cv.add_argument("chain_file", help="Chain JSON file")
    p_cv.add_argument("--json", action="store_true", help="Output as JSON")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.version:
        return cmd_version(args)

    if not args.command:
        parser.print_help()
        return 0

    dispatch = {
        "hash": cmd_hash,
        "seal": cmd_seal,
        "verify": cmd_verify,
        "verify-block": cmd_verify_block,
        "chain": cmd_chain,
        "version": cmd_version,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 1
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
