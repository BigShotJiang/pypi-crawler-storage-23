"""SnapChoreChain — a linked sequence of hashes forming a tamper-evident ledger.

Each entry in the chain includes the hash of the previous entry, creating
a Merkle-like structure that proves ordering and completeness.

Example::

    from snapchore import SnapChoreChain, SmartBlock

    chain = SnapChoreChain()

    block = SmartBlock(domain="ai.inference", payload={"tokens": 1500})
    block.seal()
    chain.append(block)

    block2 = SmartBlock(domain="ai.inference", payload={"tokens": 2300})
    block2.seal()
    chain.append(block2)

    assert chain.verify()
    assert len(chain) == 2
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..serialize import canonical_serialize


class ChainEntry:
    """A single entry in a SnapChoreChain."""

    __slots__ = (
        "index", "event_type", "block_hash", "previous_chain_hash",
        "chain_hash", "timestamp", "block_id", "metadata",
    )

    def __init__(
        self,
        *,
        index: int,
        event_type: str,
        block_hash: str,
        previous_chain_hash: Optional[str],
        block_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> None:
        self.index = index
        self.event_type = event_type
        self.block_hash = block_hash
        self.previous_chain_hash = previous_chain_hash
        self.block_id = block_id
        self.metadata = metadata or {}
        self.timestamp = timestamp or datetime.now(timezone.utc).isoformat()

        # Compute chain hash: H(index || event_type || block_hash || previous_chain_hash || timestamp)
        surface = canonical_serialize({
            "index": self.index,
            "event_type": self.event_type,
            "block_hash": self.block_hash,
            "previous_chain_hash": self.previous_chain_hash or "genesis",
            "timestamp": self.timestamp,
        })
        self.chain_hash = hashlib.sha256(surface.encode("utf-8")).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "event_type": self.event_type,
            "block_hash": self.block_hash,
            "block_id": self.block_id,
            "previous_chain_hash": self.previous_chain_hash,
            "chain_hash": self.chain_hash,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChainEntry":
        entry = cls(
            index=data["index"],
            event_type=data["event_type"],
            block_hash=data["block_hash"],
            previous_chain_hash=data.get("previous_chain_hash"),
            block_id=data.get("block_id"),
            metadata=data.get("metadata", {}),
            timestamp=data.get("timestamp"),
        )
        # Verify chain_hash matches
        if entry.chain_hash != data.get("chain_hash"):
            raise ValueError(
                f"Chain hash mismatch at index {data['index']}: "
                f"computed {entry.chain_hash}, stored {data.get('chain_hash')}"
            )
        return entry


class SnapChoreChain:
    """A tamper-evident, ordered sequence of SnapChore events.

    Each entry's hash includes the previous entry's hash, forming a chain
    that proves ordering and completeness. Any modification to an earlier
    entry invalidates all subsequent chain hashes.

    Parameters
    ----------
    chain_id : str, optional
        Unique identifier for this chain. Auto-generated if not provided.
    """

    def __init__(self, chain_id: Optional[str] = None) -> None:
        import uuid
        self.chain_id = chain_id or str(uuid.uuid4())
        self._entries: List[ChainEntry] = []
        self.created_at = datetime.now(timezone.utc).isoformat()

    def __len__(self) -> int:
        return len(self._entries)

    def __getitem__(self, index: int) -> ChainEntry:
        return self._entries[index]

    @property
    def head(self) -> Optional[ChainEntry]:
        """The most recent entry, or None if the chain is empty."""
        return self._entries[-1] if self._entries else None

    @property
    def head_hash(self) -> Optional[str]:
        """The chain hash of the most recent entry."""
        return self._entries[-1].chain_hash if self._entries else None

    def append(
        self,
        block: Any,
        *,
        event_type: str = "block_sealed",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ChainEntry:
        """Append a SmartBlock (or any object with .snapchore_hash and .id) to the chain.

        Parameters
        ----------
        block
            Must have ``snapchore_hash`` (str) and ``id`` (str) attributes.
        event_type
            Classification of the event (e.g. "block_sealed", "metrics_updated").
        metadata
            Optional metadata to attach to this chain entry.

        Returns
        -------
        ChainEntry
            The newly created chain entry.
        """
        block_hash = getattr(block, "snapchore_hash", None)
        if not block_hash:
            raise ValueError("Block must be sealed (have a snapchore_hash) before appending to chain")

        block_id = getattr(block, "id", None)

        entry = ChainEntry(
            index=len(self._entries),
            event_type=event_type,
            block_hash=block_hash,
            previous_chain_hash=self.head_hash,
            block_id=str(block_id) if block_id else None,
            metadata=metadata,
        )
        self._entries.append(entry)
        return entry

    def append_raw(
        self,
        *,
        block_hash: str,
        event_type: str = "event",
        block_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ChainEntry:
        """Append a raw hash to the chain without requiring a SmartBlock object."""
        entry = ChainEntry(
            index=len(self._entries),
            event_type=event_type,
            block_hash=block_hash,
            previous_chain_hash=self.head_hash,
            block_id=block_id,
            metadata=metadata,
        )
        self._entries.append(entry)
        return entry

    def verify(self) -> bool:
        """Verify the entire chain's integrity.

        Returns True if every entry's chain_hash is valid and properly
        linked to its predecessor.
        """
        for i, entry in enumerate(self._entries):
            # Verify index ordering
            if entry.index != i:
                return False

            # Verify previous_chain_hash linkage
            expected_prev = self._entries[i - 1].chain_hash if i > 0 else None
            if entry.previous_chain_hash != expected_prev:
                return False

            # Recompute chain hash
            surface = canonical_serialize({
                "index": entry.index,
                "event_type": entry.event_type,
                "block_hash": entry.block_hash,
                "previous_chain_hash": entry.previous_chain_hash or "genesis",
                "timestamp": entry.timestamp,
            })
            recomputed = hashlib.sha256(surface.encode("utf-8")).hexdigest()
            if recomputed != entry.chain_hash:
                return False

        return True

    def find_break(self) -> Optional[int]:
        """Find the first broken link in the chain.

        Returns the index of the first entry where integrity fails,
        or None if the chain is intact.
        """
        for i, entry in enumerate(self._entries):
            expected_prev = self._entries[i - 1].chain_hash if i > 0 else None
            if entry.previous_chain_hash != expected_prev:
                return i

            surface = canonical_serialize({
                "index": entry.index,
                "event_type": entry.event_type,
                "block_hash": entry.block_hash,
                "previous_chain_hash": entry.previous_chain_hash or "genesis",
                "timestamp": entry.timestamp,
            })
            recomputed = hashlib.sha256(surface.encode("utf-8")).hexdigest()
            if recomputed != entry.chain_hash:
                return i

        return None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the entire chain."""
        return {
            "chain_id": self.chain_id,
            "created_at": self.created_at,
            "length": len(self._entries),
            "head_hash": self.head_hash,
            "entries": [e.to_dict() for e in self._entries],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SnapChoreChain":
        """Reconstruct a chain from a dictionary."""
        chain = cls(chain_id=data.get("chain_id"))
        chain.created_at = data.get("created_at", chain.created_at)
        for entry_data in data.get("entries", []):
            entry = ChainEntry.from_dict(entry_data)
            chain._entries.append(entry)
        return chain

    def __repr__(self) -> str:
        h = self.head_hash[:12] + "..." if self.head_hash else "empty"
        return f"SnapChoreChain(id={self.chain_id[:8]}..., len={len(self)}, head={h})"
