"""Structured JSON logging configuration for Sonic.

Configures the Python logging subsystem to emit JSON lines with:
  - timestamp, level, logger name, message
  - request_id, tx_id, merchant_id correlation from contextvars
  - exc_info formatted inline when present
  - automatic secret redaction for API keys, tokens, and credentials

Call ``setup_logging()`` once at application startup (before any log calls).
"""

from __future__ import annotations

import logging
import re
import sys
from contextvars import ContextVar

from pythonjsonlogger.json import JsonFormatter

# Correlation IDs propagated across async tasks for the current request.
request_id_var: ContextVar[str] = ContextVar("request_id", default="-")
tx_id_var: ContextVar[str] = ContextVar("tx_id", default="-")
merchant_id_var: ContextVar[str] = ContextVar("merchant_id", default="-")

# Patterns that should be redacted in log output.
_SECRET_PATTERNS = [
    re.compile(r"(sk_(?:live|test)_)\w{8,}", re.IGNORECASE),      # Stripe keys
    re.compile(r"(UCIR|SAND)[\w-]{16,}", re.IGNORECASE),           # Circle keys
    re.compile(r"(sonic_key_)\w{8,}", re.IGNORECASE),              # Sonic API keys
    re.compile(r"(Bearer\s+)[\w\-_.]{20,}", re.IGNORECASE),        # JWT tokens
    re.compile(r"(eyJ[\w\-_.]{20,})", re.IGNORECASE),              # Raw JWTs
    re.compile(r"(:\/\/[^:]+:)[^@]+(@)", re.IGNORECASE),           # URL credentials
]

_REDACTED = "[REDACTED]"


def _redact(text: str) -> str:
    """Replace known secret patterns with a redacted placeholder."""
    for pattern in _SECRET_PATTERNS:
        text = pattern.sub(lambda m: m.group(1) + _REDACTED if m.lastindex else _REDACTED, text)
    return text


class _ContextFilter(logging.Filter):
    """Injects correlation context vars into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get()  # type: ignore[attr-defined]
        record.tx_id = tx_id_var.get()  # type: ignore[attr-defined]
        record.merchant_id = merchant_id_var.get()  # type: ignore[attr-defined]
        return True


class _RedactionFilter(logging.Filter):
    """Redacts known secret patterns from log messages and args."""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: _redact(str(v)) if isinstance(v, str) else v for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(
                    _redact(str(a)) if isinstance(a, str) else a for a in record.args
                )
        if isinstance(record.msg, str):
            record.msg = _redact(record.msg)
        return True


def setup_logging(*, level: str = "INFO", json_output: bool = True) -> None:
    """Configure the root logger for structured output.

    Args:
        level: Root log level (DEBUG, INFO, WARNING, ERROR).
        json_output: If True, emit JSON lines. If False, use a human-readable
                     format (useful for local development with ``SONIC_DEBUG``).
    """
    root = logging.getLogger()

    # Prevent duplicate setup if called more than once.
    if getattr(root, "_sonic_configured", False):
        return
    root._sonic_configured = True  # type: ignore[attr-defined]

    root.setLevel(level)

    handler = logging.StreamHandler(sys.stdout)

    if json_output:
        formatter = JsonFormatter(
            fmt="%(asctime)s %(levelname)s %(name)s %(request_id)s %(tx_id)s %(merchant_id)s %(message)s",
            rename_fields={"asctime": "timestamp", "levelname": "level", "name": "logger"},
            datefmt="%Y-%m-%dT%H:%M:%S%z",
        )
    else:
        formatter = logging.Formatter(
            fmt="%(asctime)s %(levelname)-8s [%(request_id)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )

    handler.setFormatter(formatter)
    handler.addFilter(_ContextFilter())
    handler.addFilter(_RedactionFilter())

    # Replace any existing handlers on root to avoid duplicate output.
    root.handlers = [handler]
