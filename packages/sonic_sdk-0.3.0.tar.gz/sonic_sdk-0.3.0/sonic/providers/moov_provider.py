"""Moov provider adapter — ACH transfers and bank payouts."""

from __future__ import annotations

import logging
import time
from decimal import Decimal
from typing import Any

import httpx

from sonic.providers.base import BaseProvider, ProviderError
from sonic.metrics import PROVIDER_LATENCY

logger = logging.getLogger(__name__)

MOOV_BASE_URL = "https://api.moov.io"


class MoovProvider(BaseProvider):
    """Handles Moov ACH transfers and wallet payouts."""

    def __init__(self, api_key: str, account_id: str):
        self._api_key = api_key
        self._account_id = account_id

    @property
    def name(self) -> str:
        return "moov"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    async def send_payout(
        self,
        *,
        recipient_id: str,
        amount: Decimal,
        currency: str,
        idempotency_key: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a Moov transfer."""
        _start = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(
                    f"{MOOV_BASE_URL}/accounts/{self._account_id}/transfers",
                    headers={
                        **self._headers(),
                        "X-Idempotency-Key": idempotency_key,
                    },
                    json={
                        "destination": {"accountID": recipient_id},
                        "amount": {
                            "value": int(amount * 100),
                            "currency": currency.upper(),
                        },
                        "metadata": metadata or {},
                    },
                )

            if resp.status_code >= 400:
                logger.error("Moov send_payout failed: HTTP %s — %s", resp.status_code, resp.text)
                raise ProviderError(
                    "moov",
                    "Payout request failed",
                    retryable=resp.status_code >= 500,
                )

            data = resp.json()
            return {"ref": data.get("transferID", ""), "status": data.get("status", "pending")}
        finally:
            PROVIDER_LATENCY.labels(provider="moov", operation="send_payout").observe(time.perf_counter() - _start)

    async def check_status(self, provider_ref: str) -> dict[str, Any]:
        _start = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{MOOV_BASE_URL}/accounts/{self._account_id}/transfers/{provider_ref}",
                    headers=self._headers(),
                )

            if resp.status_code >= 400:
                logger.error("Moov check_status failed: HTTP %s — %s", resp.status_code, resp.text)
                raise ProviderError("moov", "Status check failed")

            data = resp.json()
            return {"ref": provider_ref, "status": data.get("status", "unknown")}
        finally:
            PROVIDER_LATENCY.labels(provider="moov", operation="check_status").observe(time.perf_counter() - _start)

    async def health(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{MOOV_BASE_URL}/ping",
                    headers=self._headers(),
                )
            return resp.status_code < 500
        except Exception:
            return False
