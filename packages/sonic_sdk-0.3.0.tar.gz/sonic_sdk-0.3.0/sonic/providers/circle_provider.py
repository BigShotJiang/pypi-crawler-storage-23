"""Circle provider adapter — USDC on/off ramp."""

from __future__ import annotations

import logging
import time
import uuid
from decimal import Decimal
from typing import Any

import httpx

from sonic.providers.base import BaseProvider, ProviderError
from sonic.metrics import PROVIDER_LATENCY

logger = logging.getLogger(__name__)

CIRCLE_URLS = {
    "sandbox": "https://api-sandbox.circle.com",
    "production": "https://api.circle.com",
}


class CircleProvider(BaseProvider):
    """Handles Circle USDC payouts and on-chain transfers."""

    def __init__(self, api_key: str, environment: str = "sandbox"):
        self._api_key = api_key
        self._base_url = CIRCLE_URLS.get(environment, CIRCLE_URLS["sandbox"])

    @property
    def name(self) -> str:
        return "circle"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    async def send_payout(
        self,
        *,
        recipient_id: str,
        amount: Decimal,
        currency: str,
        idempotency_key: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send USDC payout via Circle."""
        _start = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(
                    f"{self._base_url}/v1/payouts",
                    headers=self._headers(),
                    json={
                        "idempotencyKey": idempotency_key,
                        "destination": {
                            "type": "blockchain",
                            "id": recipient_id,
                        },
                        "amount": {
                            "amount": str(amount),
                            "currency": currency.upper(),
                        },
                        "metadata": {
                            "beneficiaryEmail": (metadata or {}).get("email", ""),
                        },
                    },
                )

            if resp.status_code >= 400:
                logger.error("Circle send_payout failed: HTTP %s — %s", resp.status_code, resp.text)
                raise ProviderError(
                    "circle",
                    "Payout request failed",
                    retryable=resp.status_code >= 500,
                )

            data = resp.json().get("data", {})
            return {"ref": data.get("id", ""), "status": data.get("status", "pending")}
        finally:
            PROVIDER_LATENCY.labels(provider="circle", operation="send_payout").observe(time.perf_counter() - _start)

    async def check_status(self, provider_ref: str) -> dict[str, Any]:
        _start = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{self._base_url}/v1/payouts/{provider_ref}",
                    headers=self._headers(),
                )

            if resp.status_code >= 400:
                logger.error("Circle check_status failed: HTTP %s — %s", resp.status_code, resp.text)
                raise ProviderError("circle", "Status check failed")

            data = resp.json().get("data", {})
            return {"ref": provider_ref, "status": data.get("status", "unknown")}
        finally:
            PROVIDER_LATENCY.labels(provider="circle", operation="check_status").observe(time.perf_counter() - _start)

    async def health(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{self._base_url}/ping",
                    headers=self._headers(),
                )
            return resp.status_code == 200
        except Exception:
            return False
