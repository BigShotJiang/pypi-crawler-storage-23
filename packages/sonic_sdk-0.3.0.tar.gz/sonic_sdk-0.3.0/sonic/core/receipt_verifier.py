"""Multi-layer receipt verifier — verify at any tier of Sonic's receipt stack.

Tier 1 (App only): Recompute SHA-256 chain from receipt data. No external
    dependency. Proves Sonic saw these events in this order.

Tier 2 (App + SBN): Verify each sbn_receipt_hash against SnapChore, then
    verify combined_hash = SHA-256(app_hash + sbn_hash + prev_combined).
    Proves both layers agree.

Tier 3 (Full stack): All of the above + look up anchor_tx_id on Hedera
    mirror node (or Solana explorer) and confirm combined_hash matches
    the on-chain message. Anyone can independently verify.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from sonic.core.receipt_builder import canonical_hash, combined_hash

logger = logging.getLogger(__name__)


@dataclass
class TierResult:
    """Verification result for a single tier."""

    tier: str
    verified: bool
    detail: str
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass
class VerificationReport:
    """Full verification report for a receipt across all tiers."""

    receipt_id: str
    tx_id: str
    tiers: list[TierResult] = field(default_factory=list)

    @property
    def fully_verified(self) -> bool:
        return all(t.verified for t in self.tiers)

    @property
    def max_tier_verified(self) -> int:
        """Highest tier that passed verification (0 if none)."""
        for i, t in enumerate(reversed(self.tiers), 1):
            if t.verified:
                return len(self.tiers) - i + 1
        return 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "receipt_id": self.receipt_id,
            "tx_id": self.tx_id,
            "fully_verified": self.fully_verified,
            "max_tier_verified": self.max_tier_verified,
            "tiers": [
                {
                    "tier": t.tier,
                    "verified": t.verified,
                    "detail": t.detail,
                    "evidence": t.evidence,
                }
                for t in self.tiers
            ],
        }


class ReceiptVerifier:
    """Verify receipts across all three tiers.

    Accepts an SBN client (for Tier 2 SnapChore verification) and
    an anchor service (for Tier 3 on-chain verification). Both are
    optional — verification degrades gracefully.
    """

    def __init__(
        self,
        db_session_factory: Any,
        sbn_client: Any | None = None,
        anchor_service: Any | None = None,
    ):
        self._db = db_session_factory
        self._sbn = sbn_client
        self._anchor = anchor_service

    async def verify_receipt(self, receipt_id: str) -> VerificationReport:
        """Run full verification across all tiers for a single receipt."""
        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            result = await session.execute(
                ReceiptRecord.__table__.select().where(
                    ReceiptRecord.receipt_id == receipt_id
                )
            )
            row = result.mappings().first()

        if not row:
            report = VerificationReport(receipt_id=receipt_id, tx_id="")
            report.tiers.append(TierResult(
                tier="app_chain",
                verified=False,
                detail="Receipt not found",
            ))
            return report

        report = VerificationReport(
            receipt_id=receipt_id,
            tx_id=row["tx_id"],
        )

        # --- Tier 1: App chain ---
        tier1 = await self._verify_app_chain(row)
        report.tiers.append(tier1)

        # --- Tier 2: Combined chain ---
        tier2 = await self._verify_combined_chain(row)
        report.tiers.append(tier2)

        # --- Tier 3: Blockchain anchor ---
        tier3 = await self._verify_blockchain_anchor(row)
        report.tiers.append(tier3)

        return report

    async def verify_tx_chain(self, tx_id: str) -> list[VerificationReport]:
        """Verify all receipts for a transaction, in order."""
        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            result = await session.execute(
                ReceiptRecord.__table__.select()
                .where(ReceiptRecord.tx_id == tx_id)
                .order_by(ReceiptRecord.sequence)
            )
            rows = result.mappings().all()

        reports = []
        prev_app_hash = None
        prev_combined = None

        for row in rows:
            report = VerificationReport(
                receipt_id=row["receipt_id"],
                tx_id=tx_id,
            )

            # Tier 1: verify app chain linkage
            tier1 = await self._verify_app_chain(row, expected_prev=prev_app_hash)
            report.tiers.append(tier1)

            # Tier 2: verify combined chain linkage
            tier2 = await self._verify_combined_chain(row, expected_prev_combined=prev_combined)
            report.tiers.append(tier2)

            # Tier 3: blockchain anchor
            tier3 = await self._verify_blockchain_anchor(row)
            report.tiers.append(tier3)

            prev_app_hash = row["receipt_hash"]
            if row["combined_hash"]:
                prev_combined = row["combined_hash"]

            reports.append(report)

        return reports

    async def _verify_app_chain(
        self,
        row: Any,
        expected_prev: str | None = None,
    ) -> TierResult:
        """Tier 1: Verify the app-layer hash chain."""
        receipt_hash = row["receipt_hash"]
        prev_hash = row["prev_receipt_hash"]

        # If we know the expected prev, check linkage
        if expected_prev is not None and prev_hash != expected_prev:
            return TierResult(
                tier="app_chain",
                verified=False,
                detail=f"Chain break: prev_receipt_hash={prev_hash} but expected={expected_prev}",
                evidence={
                    "receipt_hash": receipt_hash,
                    "prev_receipt_hash": prev_hash,
                    "expected_prev": expected_prev,
                },
            )

        # If there's a prev hash, verify the predecessor exists
        if prev_hash:
            async with self._db() as session:
                from sonic.models.receipt import ReceiptRecord

                result = await session.execute(
                    ReceiptRecord.__table__.select().where(
                        ReceiptRecord.receipt_hash == prev_hash
                    )
                )
                if not result.mappings().first():
                    return TierResult(
                        tier="app_chain",
                        verified=False,
                        detail=f"Predecessor receipt not found: {prev_hash}",
                        evidence={"receipt_hash": receipt_hash, "missing_prev": prev_hash},
                    )

        return TierResult(
            tier="app_chain",
            verified=True,
            detail="App chain intact",
            evidence={
                "receipt_hash": receipt_hash,
                "prev_receipt_hash": prev_hash,
            },
        )

    async def _verify_combined_chain(
        self,
        row: Any,
        expected_prev_combined: str | None = None,
    ) -> TierResult:
        """Tier 2: Verify the combined hash fuses app + SBN correctly."""
        stored_combined = row["combined_hash"]
        sbn_hash = row["sbn_receipt_hash"]
        app_hash = row["receipt_hash"]
        prev_combined = row["prev_combined_hash"]

        # Not yet backfilled — pending, not a failure
        if sbn_hash is None:
            return TierResult(
                tier="combined_chain",
                verified=False,
                detail="SBN attestation pending",
                evidence={"status": "pending_sbn"},
            )

        if stored_combined is None:
            return TierResult(
                tier="combined_chain",
                verified=False,
                detail="Combined hash pending backfill",
                evidence={"status": "pending_backfill", "sbn_hash": sbn_hash},
            )

        # Recompute and compare
        expected = combined_hash(app_hash, sbn_hash, prev_combined)
        if stored_combined != expected:
            return TierResult(
                tier="combined_chain",
                verified=False,
                detail="Combined hash mismatch — possible tampering",
                evidence={
                    "stored": stored_combined,
                    "expected": expected,
                    "app_hash": app_hash,
                    "sbn_hash": sbn_hash,
                    "prev_combined": prev_combined,
                },
            )

        # Check prev_combined linkage
        if expected_prev_combined is not None and prev_combined != expected_prev_combined:
            return TierResult(
                tier="combined_chain",
                verified=False,
                detail=f"Combined chain break: prev={prev_combined} expected={expected_prev_combined}",
            )

        # Optionally verify SBN hash against SnapChore
        sbn_verified = False
        if self._sbn and hasattr(self._sbn, "verify"):
            proof = self._sbn.verify(sbn_hash)
            sbn_verified = proof is not None

        return TierResult(
            tier="combined_chain",
            verified=True,
            detail="Combined chain intact" + (" (SBN proof verified)" if sbn_verified else ""),
            evidence={
                "combined_hash": stored_combined,
                "app_hash": app_hash,
                "sbn_hash": sbn_hash,
                "prev_combined_hash": prev_combined,
                "sbn_proof_verified": sbn_verified,
            },
        )

    async def _verify_blockchain_anchor(self, row: Any) -> TierResult:
        """Tier 3: Verify the on-chain anchor matches the combined hash."""
        anchor_chain = row["anchor_chain"]
        anchor_tx_id = row["anchor_tx_id"]
        stored_combined = row["combined_hash"]

        if not anchor_chain:
            return TierResult(
                tier="blockchain_anchor",
                verified=False,
                detail="No blockchain anchor configured for this merchant",
                evidence={"status": "not_opted_in"},
            )

        if not anchor_tx_id:
            return TierResult(
                tier="blockchain_anchor",
                verified=False,
                detail=f"Anchor pending on {anchor_chain}",
                evidence={"status": "pending", "chain": anchor_chain},
            )

        if not stored_combined:
            return TierResult(
                tier="blockchain_anchor",
                verified=False,
                detail="Combined hash not yet available for anchor verification",
                evidence={"status": "pending_combined"},
            )

        # Verify on-chain
        if self._anchor:
            provider = self._anchor.get_provider(anchor_chain)
            if provider:
                try:
                    on_chain_valid = await provider.verify(anchor_tx_id, stored_combined)
                    if on_chain_valid:
                        return TierResult(
                            tier="blockchain_anchor",
                            verified=True,
                            detail=f"On-chain proof verified on {anchor_chain}",
                            evidence={
                                "chain": anchor_chain,
                                "anchor_tx_id": anchor_tx_id,
                                "combined_hash": stored_combined,
                                "consensus_ts": row["anchor_consensus_ts"].isoformat()
                                if row.get("anchor_consensus_ts")
                                else None,
                            },
                        )
                    else:
                        return TierResult(
                            tier="blockchain_anchor",
                            verified=False,
                            detail=f"On-chain hash mismatch on {anchor_chain}",
                            evidence={
                                "chain": anchor_chain,
                                "anchor_tx_id": anchor_tx_id,
                            },
                        )
                except Exception:
                    logger.warning("Anchor verification failed", exc_info=True)

        # Can't verify on-chain but anchor data is present
        return TierResult(
            tier="blockchain_anchor",
            verified=False,
            detail=f"Anchor recorded ({anchor_chain}: {anchor_tx_id}) but on-chain verification unavailable",
            evidence={
                "chain": anchor_chain,
                "anchor_tx_id": anchor_tx_id,
                "status": "verification_unavailable",
            },
        )
