"""Settlement poller — advances PAYOUT_EXECUTED → SETTLED via provider status checks.

Runs as a background task in the drain loop. For each transaction stuck in
PAYOUT_EXECUTED, the poller queries the payout provider to check if the
transfer has reached final settlement.

Provider terminal-success statuses:
  - Stripe: "paid"
  - Moov: "completed"
  - Circle: "complete", "confirmed"
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.core.engine import Transaction, TxState
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.metrics import TX_STATE_TRANSITIONS
from sonic.models.event_log import EventLog
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

logger = logging.getLogger(__name__)

# Provider statuses that mean the payout has fully settled
_SETTLED_STATUSES = frozenset({
    "paid",         # Stripe
    "completed",    # Moov
    "complete",     # Circle
    "confirmed",    # Circle (blockchain confirmed)
    "settled",      # Generic
})


class SettlementPoller:
    """Polls payout providers to advance PAYOUT_EXECUTED → SETTLED."""

    def __init__(
        self,
        db_session_factory: Any,
        providers: dict[str, Any],
        emitter: Any,
        attester: Any | None = None,
    ) -> None:
        self._db = db_session_factory
        self._providers = providers
        self._emitter = emitter
        self._attester = attester

    async def poll(self, max_batch: int = 20) -> int:
        """Check PAYOUT_EXECUTED transactions and settle those confirmed by providers.

        Returns the number of transactions advanced to SETTLED.
        """
        async with self._db() as db:
            result = await db.execute(
                select(TransactionRecord)
                .where(TransactionRecord.state == TxState.PAYOUT_EXECUTED.value)
                .limit(max_batch)
            )
            records = result.scalars().all()

        if not records:
            return 0

        settled_count = 0
        for record in records:
            try:
                advanced = await self._check_and_settle(record)
                if advanced:
                    settled_count += 1
            except Exception:
                logger.warning(
                    "Settlement check failed for tx %s", record.id, exc_info=True
                )

        if settled_count:
            logger.info("Settlement poller: %d/%d transactions settled", settled_count, len(records))

        return settled_count

    async def _check_and_settle(self, record: TransactionRecord) -> bool:
        """Check a single transaction's payout status and settle if confirmed."""
        rail = record.outbound_rail
        provider_ref = record.outbound_provider_ref

        if not rail or not provider_ref:
            logger.debug(
                "Skipping tx %s: missing rail=%s or provider_ref=%s",
                record.id, rail, provider_ref,
            )
            return False

        provider = self._providers.get(rail)
        if not provider:
            logger.debug("No provider for rail %s (tx %s)", rail, record.id)
            return False

        # Query provider for current status
        try:
            status_resp = await provider.check_status(provider_ref)
        except Exception as exc:
            logger.debug(
                "Provider %s check_status failed for %s: %s",
                rail, provider_ref, exc,
            )
            return False

        payout_status = (status_resp.get("status", "") or "").lower()
        if payout_status not in _SETTLED_STATUSES:
            return False

        # Provider confirms settlement — advance the state machine
        async with self._db() as db:
            # Re-load within session to avoid stale state
            fresh = await db.execute(
                select(TransactionRecord).where(TransactionRecord.id == record.id)
            )
            record = fresh.scalar_one_or_none()
            if not record or record.state != TxState.PAYOUT_EXECUTED.value:
                return False

            tx = Transaction(
                tx_id=record.id,
                merchant_id=record.merchant_id,
                state=TxState(record.state),
                inbound_amount=record.inbound_amount,
                inbound_currency=record.inbound_currency,
                inbound_rail=record.inbound_rail,
                sequence=record.sequence,
            )

            event = tx.advance(
                TxState.SETTLED,
                provider_ref=provider_ref,
                rail=rail,
            )

            record.state = TxState.SETTLED.value
            record.sequence = tx.sequence

            # Build receipt
            prev_result = await db.execute(
                select(ReceiptRecord.receipt_hash)
                .where(ReceiptRecord.tx_id == record.id)
                .order_by(ReceiptRecord.sequence.desc())
                .limit(1)
            )
            prev_hash = prev_result.scalar_one_or_none()

            chain = ReceiptChain()
            chain._last_hash = prev_hash
            receipt = chain.build(
                event, merchant_id=record.merchant_id, direction="outbound"
            )

            db.add(ReceiptRecord(
                receipt_id=receipt.receipt_id,
                tx_id=record.id,
                event_type=receipt.event_type,
                sequence=receipt.sequence,
                amount=receipt.amount,
                currency=receipt.currency,
                rail=receipt.rail,
                direction=receipt.direction,
                receipt_hash=receipt.receipt_hash,
                prev_receipt_hash=receipt.prev_receipt_hash,
                idempotency_key=receipt.idempotency_key,
                merchant_id=record.merchant_id,
            ))

            db.add(EventLog(
                tx_id=record.id,
                event_type=EventType.SETTLEMENT_COMPLETE.value,
                from_state=TxState.PAYOUT_EXECUTED.value,
                to_state=TxState.SETTLED.value,
                merchant_id=record.merchant_id,
                provider=rail,
                provider_ref=provider_ref,
                receipt_hash=receipt.receipt_hash,
                payload={"provider_status": payout_status},
            ))

            await db.commit()

        # Metrics
        TX_STATE_TRANSITIONS.labels(
            from_state=TxState.PAYOUT_EXECUTED.value,
            to_state=TxState.SETTLED.value,
            provider=rail,
        ).inc()

        # SBN attestation (non-blocking)
        if self._attester is not None:
            try:
                await self._attester.enqueue(receipt)
            except Exception:
                logger.warning(
                    "SBN enqueue failed for settlement receipt %s",
                    receipt.receipt_id,
                    exc_info=True,
                )

        # Emit event (non-blocking)
        if self._emitter is not None:
            try:
                await self._emitter.emit(EventType.SETTLEMENT_COMPLETE, {
                    "tx_id": record.id,
                    "merchant_id": record.merchant_id,
                    "state": TxState.SETTLED.value,
                    "provider_ref": provider_ref,
                    "receipt_hash": receipt.receipt_hash,
                })
            except Exception:
                logger.warning(
                    "Event emission failed for settlement of tx %s",
                    record.id,
                    exc_info=True,
                )

        logger.info(
            "Settled tx %s via %s (provider_ref=%s, status=%s)",
            record.id, rail, provider_ref, payout_status,
        )
        return True
