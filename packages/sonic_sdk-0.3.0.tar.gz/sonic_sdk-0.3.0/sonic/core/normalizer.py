"""Normalizer — converts inbound funds to the treasury base asset (USDC).

Handles the RECEIVABLE_CLEARED → NORMALIZING → NORMALIZED state transitions,
populating treasury_amount and treasury_asset on the transaction record.

When auto_normalize is enabled (default), this runs automatically after
webhooks advance a transaction to RECEIVABLE_CLEARED.  Can also be triggered
manually via the admin API.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.core.engine import Transaction, TxState
from sonic.core.receipt_builder import ReceiptChain
from sonic.core.treasury import Treasury
from sonic.events.types import EventType
from sonic.metrics import TX_STATE_TRANSITIONS
from sonic.models.event_log import EventLog
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

logger = logging.getLogger(__name__)


class Normalizer:
    """Normalize inbound payments to the treasury base asset.

    For same-currency (e.g. USDC → USDC), this is a zero-fee passthrough.
    For USD → USDC, a 1:1 peg rate is used automatically.
    For other currencies, an explicit ``rate`` must be supplied.
    """

    def __init__(self, treasury: Treasury) -> None:
        self._treasury = treasury

    async def normalize(
        self,
        *,
        db: AsyncSession,
        record: TransactionRecord,
        emitter: Any = None,
        attester: Any = None,
        rate: Decimal | None = None,
    ) -> dict[str, Any] | None:
        """Run full normalization: RECEIVABLE_CLEARED → NORMALIZING → NORMALIZED.

        Returns dict with tx_id, state, treasury_amount, receipt_hashes.
        Returns None if normalization cannot proceed (missing rate for
        exotic currencies).
        """
        if record.state != TxState.RECEIVABLE_CLEARED.value:
            raise ValueError(
                f"Cannot normalize tx {record.id}: state is {record.state}, "
                f"expected {TxState.RECEIVABLE_CLEARED.value}"
            )

        # Default USD → USDC at 1:1 peg
        if rate is None and record.inbound_currency.upper() == "USD":
            rate = Decimal("1")

        # Pre-flight: get quote before any state changes
        try:
            quote = self._treasury.quote_inbound(
                record.inbound_amount,
                record.inbound_currency,
                rate=rate,
            )
        except ValueError as exc:
            logger.info(
                "Skipping normalization for tx %s: %s", record.id, exc
            )
            return None

        # Build the transaction object from the record
        tx = Transaction(
            tx_id=record.id,
            merchant_id=record.merchant_id,
            state=TxState(record.state),
            inbound_amount=record.inbound_amount,
            inbound_currency=record.inbound_currency,
            inbound_rail=record.inbound_rail,
            sequence=record.sequence,
        )

        # Load previous receipt hash for chaining
        prev_result = await db.execute(
            select(ReceiptRecord.receipt_hash)
            .where(ReceiptRecord.tx_id == record.id)
            .order_by(ReceiptRecord.sequence.desc())
            .limit(1)
        )
        prev_hash = prev_result.scalar_one_or_none()

        chain = ReceiptChain()
        chain._last_hash = prev_hash

        # --- Step 1: RECEIVABLE_CLEARED → NORMALIZING ---
        event_1 = tx.advance(TxState.NORMALIZING)
        record.state = TxState.NORMALIZING.value
        record.sequence = tx.sequence

        receipt_1 = chain.build(
            event_1, merchant_id=record.merchant_id, direction="inbound"
        )
        db.add(ReceiptRecord(
            receipt_id=receipt_1.receipt_id,
            tx_id=record.id,
            event_type=receipt_1.event_type,
            sequence=receipt_1.sequence,
            amount=receipt_1.amount,
            currency=receipt_1.currency,
            rail=receipt_1.rail,
            direction=receipt_1.direction,
            receipt_hash=receipt_1.receipt_hash,
            prev_receipt_hash=receipt_1.prev_receipt_hash,
            idempotency_key=receipt_1.idempotency_key,
            merchant_id=record.merchant_id,
        ))
        db.add(EventLog(
            tx_id=record.id,
            event_type=EventType.NORMALIZE_STARTED.value,
            from_state=event_1.from_state.value,
            to_state=TxState.NORMALIZING.value,
            merchant_id=record.merchant_id,
            provider="treasury",
            receipt_hash=receipt_1.receipt_hash,
        ))

        # --- Step 2: Persist treasury conversion ---
        record.treasury_amount = quote.net_amount
        record.treasury_asset = quote.to_currency

        # --- Step 3: NORMALIZING → NORMALIZED ---
        event_2 = tx.advance(
            TxState.NORMALIZED,
            amount=quote.net_amount,
            currency=quote.to_currency,
        )
        record.state = TxState.NORMALIZED.value
        record.sequence = tx.sequence

        receipt_2 = chain.build(
            event_2, merchant_id=record.merchant_id, direction="inbound"
        )
        db.add(ReceiptRecord(
            receipt_id=receipt_2.receipt_id,
            tx_id=record.id,
            event_type=receipt_2.event_type,
            sequence=receipt_2.sequence,
            amount=receipt_2.amount,
            currency=receipt_2.currency,
            rail=receipt_2.rail,
            direction=receipt_2.direction,
            receipt_hash=receipt_2.receipt_hash,
            prev_receipt_hash=receipt_2.prev_receipt_hash,
            idempotency_key=receipt_2.idempotency_key,
            merchant_id=record.merchant_id,
        ))
        db.add(EventLog(
            tx_id=record.id,
            event_type=EventType.NORMALIZE_COMPLETED.value,
            from_state=event_2.from_state.value,
            to_state=TxState.NORMALIZED.value,
            merchant_id=record.merchant_id,
            provider="treasury",
            receipt_hash=receipt_2.receipt_hash,
            payload={
                "from_currency": quote.from_currency,
                "to_currency": quote.to_currency,
                "rate": str(quote.rate),
                "fee_bps": quote.fee_bps,
                "gross_amount": str(quote.gross_amount),
                "net_amount": str(quote.net_amount),
                "fee_amount": str(quote.fee_amount),
            },
        ))

        await db.commit()

        # --- Metrics ---
        TX_STATE_TRANSITIONS.labels(
            from_state=TxState.RECEIVABLE_CLEARED.value,
            to_state=TxState.NORMALIZING.value,
            provider="treasury",
        ).inc()
        TX_STATE_TRANSITIONS.labels(
            from_state=TxState.NORMALIZING.value,
            to_state=TxState.NORMALIZED.value,
            provider="treasury",
        ).inc()

        # --- Emit events (non-blocking) ---
        if emitter is not None:
            for evt_type, receipt in [
                (EventType.NORMALIZE_STARTED, receipt_1),
                (EventType.NORMALIZE_COMPLETED, receipt_2),
            ]:
                try:
                    await emitter.emit(evt_type, {
                        "tx_id": record.id,
                        "merchant_id": record.merchant_id,
                        "state": record.state,
                        "receipt_hash": receipt.receipt_hash,
                    })
                except Exception:
                    logger.warning(
                        "Event emission failed for %s", evt_type, exc_info=True
                    )

        # --- SBN attestation (non-blocking) ---
        if attester is not None:
            for receipt in [receipt_1, receipt_2]:
                try:
                    await attester.enqueue(receipt)
                except Exception:
                    logger.warning(
                        "SBN enqueue failed for receipt %s",
                        receipt.receipt_id,
                        exc_info=True,
                    )

        logger.info(
            "Normalized tx %s: %s %s → %s %s (rate=%s, fee=%sbps)",
            record.id,
            record.inbound_amount,
            record.inbound_currency,
            quote.net_amount,
            quote.to_currency,
            quote.rate,
            quote.fee_bps,
        )

        return {
            "tx_id": record.id,
            "state": TxState.NORMALIZED.value,
            "treasury_amount": str(quote.net_amount),
            "treasury_asset": quote.to_currency,
            "receipt_hashes": [receipt_1.receipt_hash, receipt_2.receipt_hash],
        }
