"""Blockchain anchoring — Tier 3 of Sonic's immutable receipt stack."""
