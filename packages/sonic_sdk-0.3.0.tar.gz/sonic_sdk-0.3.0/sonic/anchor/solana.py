"""Solana Memo anchor provider — alternative to Hedera HCS.

Writes the combined receipt hash as a Solana Memo transaction.
More expensive per-tx than Hedera HCS but available for merchants
already in the Solana ecosystem (e.g., Circle USDC on Solana).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from sonic.anchor.base import AnchorError, AnchorProvider, AnchorResult
from sonic.config import settings

logger = logging.getLogger(__name__)

try:
    from solders.keypair import Keypair  # type: ignore[import-untyped]
    from solders.pubkey import Pubkey  # type: ignore[import-untyped]
    from solana.rpc.async_api import AsyncClient as SolanaClient  # type: ignore[import-untyped]
    from solana.transaction import Transaction as SolanaTransaction  # type: ignore[import-untyped]
    from spl.memo.instructions import create_memo  # type: ignore[import-untyped]

    _SOLANA_SDK = True
except ImportError:
    _SOLANA_SDK = False


class SolanaAnchorProvider(AnchorProvider):
    """Anchor receipts via Solana Memo transactions.

    Each anchor creates a Memo instruction containing the combined_hash
    and metadata. The transaction signature serves as the verifiable
    proof on Solana explorers.
    """

    def __init__(
        self,
        rpc_url: str | None = None,
        payer_key: str | None = None,
    ):
        self._rpc_url = rpc_url or settings.solana_rpc_url
        self._payer_key = payer_key or settings.solana_payer_key
        self._client: Any = None
        self._payer: Any = None

        if _SOLANA_SDK and self._payer_key:
            try:
                self._payer = Keypair.from_base58_string(self._payer_key)
                self._client = SolanaClient(self._rpc_url)
                logger.info("Solana anchor initialized: rpc=%s", self._rpc_url)
            except Exception:
                logger.warning("Solana SDK initialization failed", exc_info=True)
                self._client = None
        elif not _SOLANA_SDK:
            logger.info("Solana SDK not installed — Solana anchoring unavailable")

    @property
    def chain_name(self) -> str:
        return "solana"

    @property
    def active(self) -> bool:
        return self._client is not None and self._payer is not None

    async def submit(
        self,
        combined_hash: str,
        *,
        receipt_id: str,
        tx_id: str,
        merchant_id: str,
        topic_id: str | None = None,
    ) -> AnchorResult:
        """Submit combined hash as a Solana Memo transaction."""
        if not self.active:
            raise AnchorError("solana", "Solana client not initialized")

        memo_content = json.dumps({
            "v": 1,
            "h": combined_hash,
            "r": receipt_id,
            "t": tx_id,
            "m": merchant_id,
            "ts": datetime.now(timezone.utc).isoformat(),
        }, separators=(",", ":"))

        try:
            memo_ix = create_memo(
                memo_content.encode(),
                signer=self._payer.pubkey(),
            )

            tx = SolanaTransaction()
            tx.add(memo_ix)

            recent_blockhash = await self._client.get_latest_blockhash()
            tx.recent_blockhash = recent_blockhash.value.blockhash

            tx.sign(self._payer)
            result = await self._client.send_transaction(tx, self._payer)

            signature = str(result.value)

            logger.info(
                "Solana anchor: sig=%s hash=%s",
                signature[:16] + "...",
                combined_hash[:16] + "...",
            )

            return AnchorResult(
                chain="solana",
                tx_id=signature,
                consensus_ts=datetime.now(timezone.utc),
                raw={"signature": signature, "memo": memo_content},
            )

        except Exception as exc:
            raise AnchorError("solana", str(exc)) from exc

    async def verify(self, anchor_tx_id: str, expected_hash: str) -> bool:
        """Verify a Solana anchor by fetching the transaction."""
        if not self.active:
            return False

        try:
            from solders.signature import Signature

            result = await self._client.get_transaction(
                Signature.from_string(anchor_tx_id),
                encoding="jsonParsed",
            )

            if result.value is None:
                return False

            # Look through log messages for the memo containing our hash
            logs = result.value.transaction.meta.log_messages or []
            for log_msg in logs:
                if expected_hash in log_msg:
                    return True

            return False

        except Exception:
            logger.warning("Solana verify failed for %s", anchor_tx_id, exc_info=True)
            return False

    async def health(self) -> bool:
        if not self.active:
            return False
        try:
            result = await self._client.get_health()
            return result.value == "ok"
        except Exception:
            return False
