"""Base interface for blockchain anchor providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass
class AnchorResult:
    """Result from a successful blockchain anchor."""

    chain: str  # "hedera" | "solana"
    tx_id: str  # HCS sequence number or Solana signature
    consensus_ts: datetime | None  # Hedera consensus timestamp (Solana: slot time)
    raw: dict[str, Any] | None = None  # Full provider response


class AnchorProvider(ABC):
    """Abstract interface for blockchain anchor backends."""

    @property
    @abstractmethod
    def chain_name(self) -> str:
        """Identifier for this chain: 'hedera' or 'solana'."""
        ...

    @abstractmethod
    async def submit(
        self,
        combined_hash: str,
        *,
        receipt_id: str,
        tx_id: str,
        merchant_id: str,
        topic_id: str | None = None,
    ) -> AnchorResult:
        """Submit a combined hash to the blockchain.

        Raises ``AnchorError`` on failure.
        """
        ...

    @abstractmethod
    async def verify(self, anchor_tx_id: str, expected_hash: str) -> bool:
        """Verify that an anchor transaction contains the expected hash."""
        ...

    @abstractmethod
    async def health(self) -> bool:
        """Check if the anchor provider is reachable."""
        ...


class AnchorError(Exception):
    """Raised when a blockchain anchor operation fails."""

    def __init__(self, chain: str, detail: str):
        self.chain = chain
        self.detail = detail
        super().__init__(f"Anchor error ({chain}): {detail}")
