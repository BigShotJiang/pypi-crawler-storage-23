"""Tower Agent adapter — the contract between Sonic and the operator dashboard.

Tower Agent receives NUMA signals, distills them, and translates them
into settlement-specific suggestions via translation rules. Sonic
provides the adapter surface: dashboard data, action execution, events.

Nobody talks to NUMA. Tower Agent is the air gap.

The adapter follows the same pattern as Stillpoint and Dominion:
  1. Dashboard descriptor defines WHAT to render (Tower Agent owns this)
  2. Dashboard snapshot serves DATA matching the descriptor's data_keys
  3. Action execution handles operator actions Tower Agent suggests
  4. Event stream pushes real-time updates to the dashboard

Data keys in this module map 1:1 to widgets in Tower Agent's
SONIC_DASHBOARD descriptor.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Dashboard data keys — what Tower Agent's descriptor reads
# ---------------------------------------------------------------------------

class DataKey(str, Enum):
    """Every data_key the Sonic dashboard descriptor references.

    Tower Agent defines widgets that read from section_data[data_key].
    We serve the data matching these keys.
    """
    BRIEF = "brief"
    SETTLEMENT_HEALTH = "settlement_health"
    STREAM_ACTIVITY = "stream_activity"
    FLOAT_STATUS = "float_status"
    PROVIDER_HEALTH = "provider_health"
    BATCH_PAYOUTS = "batch_payouts"
    SUGGESTIONS = "suggestions"
    TRANSLATION_LOG = "translation_log"


# ---------------------------------------------------------------------------
# Action definitions — what the operator can do
# ---------------------------------------------------------------------------

class ActionDisposition(str, Enum):
    EXECUTE = "execute"       # runs immediately
    SUGGEST = "suggest"       # display as suggestion, operator decides
    ESCALATE = "escalate"     # danger action, requires confirmation


@dataclass(frozen=True)
class ActionDef:
    """An operator action Tower Agent can suggest or the operator can invoke."""
    action_id: str
    label: str
    description: str
    disposition: ActionDisposition
    requires_confirmation: bool = False
    available_in_regimes: list[str] = field(default_factory=lambda: ["*"])
    blocked_in_regimes: list[str] = field(default_factory=list)


# The 7 actions Tower Agent's descriptor defines for Sonic
SONIC_ACTIONS: dict[str, ActionDef] = {
    "pause_settlements": ActionDef(
        action_id="pause_settlements",
        label="Pause Settlements",
        description="Emergency pause the settlement engine. No new payouts will process.",
        disposition=ActionDisposition.ESCALATE,
        requires_confirmation=True,
    ),
    "resume_settlements": ActionDef(
        action_id="resume_settlements",
        label="Resume Settlements",
        description="Resume the settlement engine after a pause.",
        disposition=ActionDisposition.EXECUTE,
        requires_confirmation=True,
    ),
    "pause_stream": ActionDef(
        action_id="pause_stream",
        label="Pause Stream",
        description="Pause a specific PayStream session.",
        disposition=ActionDisposition.EXECUTE,
    ),
    "resume_stream": ActionDef(
        action_id="resume_stream",
        label="Resume Stream",
        description="Resume a paused PayStream session.",
        disposition=ActionDisposition.EXECUTE,
    ),
    "retry_failed_payout": ActionDef(
        action_id="retry_failed_payout",
        label="Retry Payout",
        description="Re-queue a failed payout for processing.",
        disposition=ActionDisposition.EXECUTE,
    ),
    "trigger_health_check": ActionDef(
        action_id="trigger_health_check",
        label="Health Check",
        description="Force a full readiness probe of all settlement components.",
        disposition=ActionDisposition.EXECUTE,
    ),
    "escalate_to_manual": ActionDef(
        action_id="escalate_to_manual",
        label="Escalate to Manual",
        description="Flag settlement state for manual operator review. Critical.",
        disposition=ActionDisposition.ESCALATE,
        requires_confirmation=True,
    ),
}


# ---------------------------------------------------------------------------
# Event definitions — what the dashboard subscribes to
# ---------------------------------------------------------------------------

class EventKind(str, Enum):
    """Real-time event types the dashboard subscribes to via WebSocket."""
    SETTLEMENT_COMPLETE = "settlement_complete"
    PAYOUT_FAILED = "payout_failed"
    STREAM_STATE_CHANGE = "stream_state_change"
    FLOAT_ALERT = "float_alert"
    PROVIDER_DEGRADED = "provider_degraded"
    ESCALATION = "escalation"


class EventPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class DashboardEvent:
    """An event pushed to the dashboard via WebSocket."""
    kind: EventKind
    data: dict[str, Any]
    refresh_widgets: list[str]
    priority: EventPriority = EventPriority.NORMAL
    toast: bool = False
    sound: bool = False
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "data": self.data,
            "refresh_widgets": self.refresh_widgets,
            "priority": self.priority.value,
            "toast": self.toast,
            "sound": self.sound,
            "timestamp": self.timestamp.isoformat(),
        }


# ---------------------------------------------------------------------------
# Event → widget refresh mapping
# ---------------------------------------------------------------------------

EVENT_REFRESH_MAP: dict[EventKind, list[str]] = {
    EventKind.SETTLEMENT_COMPLETE: ["settlement_panel", "brief_card", "batch_table"],
    EventKind.PAYOUT_FAILED: ["settlement_panel", "brief_card", "suggestion_feed"],
    EventKind.STREAM_STATE_CHANGE: ["stream_panel", "brief_card"],
    EventKind.FLOAT_ALERT: ["float_gauge", "brief_card"],
    EventKind.PROVIDER_DEGRADED: ["provider_panel", "brief_card", "suggestion_feed"],
    EventKind.ESCALATION: ["brief_card", "settlement_panel", "suggestion_feed"],
}


# ---------------------------------------------------------------------------
# Dashboard snapshot shape
# ---------------------------------------------------------------------------

@dataclass
class DashboardSnapshot:
    """Full snapshot for initial render — everything the frontend needs."""
    product_id: str = "sonic"
    regime: str = "unknown"
    regime_label: str = ""
    headline: str = ""
    health_score: float = 0.0
    section_data: dict[str, Any] = field(default_factory=dict)
    suggestions: list[dict[str, Any]] = field(default_factory=list)
    suggestion_count: int = 0
    escalation_required: bool = False
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        return {
            "product_id": self.product_id,
            "regime": self.regime,
            "regime_label": self.regime_label,
            "headline": self.headline,
            "health_score": self.health_score,
            "section_data": self.section_data,
            "suggestions": self.suggestions,
            "suggestion_count": self.suggestion_count,
            "escalation_required": self.escalation_required,
            "generated_at": self.generated_at.isoformat(),
        }


# ---------------------------------------------------------------------------
# Action request/response
# ---------------------------------------------------------------------------

@dataclass
class ActionRequest:
    """Incoming action execution request from Tower Agent or operator."""
    action: str
    params: dict[str, Any] = field(default_factory=dict)
    confirmed: bool = False


@dataclass
class ActionResult:
    """Result of executing an action."""
    action: str
    status: str           # "success" | "failed" | "blocked" | "unavailable"
    detail: str = ""
    receipt_hash: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "status": self.status,
            "detail": self.detail,
            "receipt_hash": self.receipt_hash,
            "data": self.data,
        }


# ---------------------------------------------------------------------------
# Metallic regime labels (from NUMA via Tower Agent)
# ---------------------------------------------------------------------------

METALLIC_LABELS: dict[str, str] = {
    "gold": "Expansion",
    "silver": "Stable",
    "bronze": "Contraction",
    "iron": "Critical",
    "unknown": "Initializing",
}


def regime_headline(regime: str, health_score: float) -> str:
    """Generate the dashboard headline from regime and health."""
    label = METALLIC_LABELS.get(regime, "Unknown")
    pct = round(health_score * 100)
    return f"Settlement engine in {regime} regime — {pct}% throughput"


def make_event(
    kind: EventKind,
    data: dict[str, Any],
    priority: EventPriority = EventPriority.NORMAL,
    toast: bool = False,
    sound: bool = False,
) -> DashboardEvent:
    """Convenience factory for building dashboard events with auto-refresh mapping."""
    refresh = EVENT_REFRESH_MAP.get(kind, [])
    return DashboardEvent(
        kind=kind,
        data=data,
        refresh_widgets=refresh,
        priority=priority,
        toast=toast,
        sound=sound,
    )


__all__ = [
    "DataKey",
    "ActionDisposition",
    "ActionDef",
    "SONIC_ACTIONS",
    "DashboardSnapshot",
    "ActionRequest",
    "ActionResult",
    "EventKind",
    "EventPriority",
    "DashboardEvent",
    "EVENT_REFRESH_MAP",
    "METALLIC_LABELS",
    "regime_headline",
    "make_event",
]
