"""Checkout session model — hosted checkout for website integration."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class CheckoutSession(Base):
    __tablename__ = "checkout_sessions"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"cs_{uuid.uuid4().hex[:24]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Payment details
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    currency: Mapped[str] = mapped_column(String(4), nullable=False, default="USD")
    rail: Mapped[str | None] = mapped_column(String(32))  # None = let customer choose

    # Session state: open -> completed | expired | cancelled
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")

    # Redirect URLs
    success_url: Mapped[str] = mapped_column(Text, nullable=False)
    cancel_url: Mapped[str | None] = mapped_column(Text)

    # Customer-facing
    customer_ref: Mapped[str | None] = mapped_column(String(128))
    description: Mapped[str | None] = mapped_column(String(500))

    # Link to created transaction (once payment is made)
    tx_id: Mapped[str | None] = mapped_column(String(64))

    # Link to payment link (if session was created from one)
    payment_link_id: Mapped[str | None] = mapped_column(String(64))

    # Metadata
    metadata_json: Mapped[str | None] = mapped_column(Text)  # JSON blob

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )

    __table_args__ = (
        Index("ix_checkout_sessions_merchant_status", "merchant_id", "status"),
        Index("ix_checkout_sessions_payment_link", "payment_link_id"),
    )
