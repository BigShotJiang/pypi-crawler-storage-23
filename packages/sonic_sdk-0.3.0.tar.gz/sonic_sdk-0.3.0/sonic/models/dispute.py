"""Dispute / chargeback model — tracks transaction disputes and resolution."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Numeric, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class Dispute(Base):
    __tablename__ = "disputes"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"disp_{uuid.uuid4().hex[:16]}"
    )
    tx_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Dispute details
    reason: Mapped[str] = mapped_column(String(64), nullable=False)  # fraud | duplicate | not_received | other
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    currency: Mapped[str] = mapped_column(String(4), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)

    # Resolution
    status: Mapped[str] = mapped_column(
        String(16), default="open"
    )  # open | under_review | won | lost | closed
    resolved_by: Mapped[str | None] = mapped_column(String(64))  # admin user ID
    resolution_note: Mapped[str | None] = mapped_column(Text)

    # Provider reference (if dispute originated from provider)
    provider: Mapped[str | None] = mapped_column(String(32))
    provider_dispute_id: Mapped[str | None] = mapped_column(String(128))

    # Evidence / metadata
    evidence: Mapped[dict | None] = mapped_column(JSONB)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        Index("ix_disputes_merchant_status", "merchant_id", "status"),
        Index("ix_disputes_status_created", "status", "created_at"),
    )
