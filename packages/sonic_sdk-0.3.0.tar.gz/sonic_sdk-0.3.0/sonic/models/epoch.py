"""SBN Epoch model — tracks settlement epoch slots for the coupler agent.

Each epoch maps to a single SBN slot. Receipts within the epoch
are submitted as SmartBlocks to that slot. When the epoch closes,
the slot's Merkle root becomes the batch proof.

States: open → closing → closed → attested → failed
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class SbnEpoch(Base):
    __tablename__ = "sbn_epochs"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: str(uuid.uuid4())
    )

    # Epoch identity — e.g. "2026-02-24" or "2026-02-24:merchant:merch_abc"
    epoch_key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)

    # SBN slot linkage
    slot_id: Mapped[str | None] = mapped_column(String(64))

    # Lifecycle state
    state: Mapped[str] = mapped_column(String(16), nullable=False, default="open")
    # open     — accepting SmartBlock submissions
    # closing  — close_slot() in progress
    # closed   — slot closed, have Merkle root
    # attested — batch attestation complete
    # failed   — terminal error

    # Timestamps
    opened_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # SBN artifacts
    close_receipt_id: Mapped[str | None] = mapped_column(String(64))
    attestation_receipt_id: Mapped[str | None] = mapped_column(String(64))
    merkle_root: Mapped[str | None] = mapped_column(String(128))

    # Error tracking
    last_error: Mapped[str | None] = mapped_column(Text)

    __table_args__ = (
        Index("ix_sbn_epochs_state", "state"),
        Index("ix_sbn_epochs_epoch_key", "epoch_key"),
    )
