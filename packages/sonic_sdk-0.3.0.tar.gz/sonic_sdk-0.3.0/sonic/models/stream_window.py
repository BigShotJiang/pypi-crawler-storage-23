"""StreamWindow model — 30-minute labor-block accrual windows.

Each window represents one labor block within a PayStream. Windows track:
- Accrued earnings (work events → units × price)
- Disbursement amount (what was actually paid out)
- Holdback amount (retained per policy)
- GEC score for this window (feeds g_ewma)
- SBN block hash (proof of this window's accrual)
- Policy state at time of close

Windows are the atomic unit of the accrual-first data flow:
  work events → window accrual → window close → micro-payout → receipt
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class StreamWindow(Base):
    __tablename__ = "stream_windows"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"sw_{uuid.uuid4().hex[:24]}"
    )
    pay_stream_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Window identity
    window_number: Mapped[int] = mapped_column(Integer, nullable=False)
    epoch_key: Mapped[str] = mapped_column(String(64), nullable=False)  # YYYY-MM-DD

    # Window timing
    window_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    window_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # State: open | closed | skipped (frozen/paused during this window)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")

    # Accrual — what was earned in this window
    units: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    unit_price: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    earned_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )

    # Disbursement — what was paid out for this window
    disbursed_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    holdback_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )

    # Currency
    currency: Mapped[str] = mapped_column(String(4), nullable=False, default="USD")

    # GEC score for this window (y/x = efficiency)
    gec_y: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # successful
    gec_x: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # submitted
    gec_score: Mapped[Decimal] = mapped_column(
        Numeric(10, 6), nullable=False, default=Decimal("0")
    )

    # Policy state when window was closed
    policy_state_at_close: Mapped[str | None] = mapped_column(String(16))

    # SBN proof
    sbn_block_hash: Mapped[str | None] = mapped_column(String(128))
    sbn_slot_id: Mapped[str | None] = mapped_column(String(64))

    # Receipt linkage
    receipt_hash: Mapped[str | None] = mapped_column(String(128))
    payout_tx_id: Mapped[str | None] = mapped_column(String(64))

    # Metadata
    work_events_json: Mapped[str | None] = mapped_column(Text)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    __table_args__ = (
        Index("ix_stream_windows_stream_number", "pay_stream_id", "window_number"),
        Index("ix_stream_windows_stream_epoch", "pay_stream_id", "epoch_key"),
        Index("ix_stream_windows_status", "status", postgresql_where="status = 'open'"),
    )
