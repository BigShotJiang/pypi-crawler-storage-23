"""SQLAlchemy base and session factory."""

from __future__ import annotations

import logging

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from sonic.config import settings

logger = logging.getLogger(__name__)


class Base(DeclarativeBase):
    pass


# Build connection args with optional TLS enforcement
_connect_args: dict = {}
if settings.db_require_ssl:
    _connect_args["ssl"] = True
    logger.info("Database TLS enforced (db_require_ssl=True)")

# asyncpg prepared-statement cache lives in connect_args
if settings.db_statement_cache_size >= 0:
    _connect_args["statement_cache_size"] = settings.db_statement_cache_size

engine = create_async_engine(
    settings.database_url,
    pool_size=settings.db_pool_size,
    max_overflow=settings.db_max_overflow,
    pool_recycle=settings.db_pool_recycle,
    pool_pre_ping=settings.db_pool_pre_ping,
    pool_timeout=settings.db_pool_timeout,
    echo=settings.debug,
    connect_args=_connect_args,
)

async_session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


# --- Read replica (optional) ---
# When database_read_url is configured, read-heavy endpoints use this engine
# to offload traffic from the primary. Falls back to primary if not set.

if settings.database_read_url:
    _read_connect_args: dict = {}
    if settings.db_require_ssl:
        _read_connect_args["ssl"] = True
    if settings.db_statement_cache_size >= 0:
        _read_connect_args["statement_cache_size"] = settings.db_statement_cache_size

    read_engine = create_async_engine(
        settings.database_read_url,
        pool_size=settings.db_pool_size,
        max_overflow=settings.db_max_overflow,
        pool_recycle=settings.db_pool_recycle,
        pool_pre_ping=settings.db_pool_pre_ping,
        pool_timeout=settings.db_pool_timeout,
        echo=settings.debug,
        connect_args=_read_connect_args,
    )
    logger.info("Read replica engine configured (%s)", settings.database_read_url.split("@")[-1])
else:
    read_engine = engine  # Fallback: reads go to primary

read_session_factory = async_sessionmaker(read_engine, class_=AsyncSession, expire_on_commit=False)
