"""Webhook endpoint model — merchant-configured endpoints for event delivery."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Index, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class WebhookEndpoint(Base):
    __tablename__ = "webhook_endpoints"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"whep_{uuid.uuid4().hex[:16]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    url: Mapped[str] = mapped_column(String(2048), nullable=False)
    description: Mapped[str | None] = mapped_column(String(255))
    events: Mapped[str] = mapped_column(
        Text, default="*", nullable=False
    )  # Comma-separated event patterns (e.g. "payment.*,payout.*")
    secret: Mapped[str] = mapped_column(String(255), nullable=False)  # HMAC signing secret
    status: Mapped[str] = mapped_column(
        String(16), default="active"
    )  # active | paused | disabled

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        Index("ix_webhook_endpoints_merchant_status", "merchant_id", "status"),
    )


class WebhookDelivery(Base):
    __tablename__ = "webhook_deliveries"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"whdel_{uuid.uuid4().hex[:16]}"
    )
    endpoint_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict | None] = mapped_column(JSONB)

    # Delivery result
    status_code: Mapped[int | None] = mapped_column()  # HTTP status code from merchant
    response_body: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(
        String(16), default="pending"
    )  # pending | delivered | failed
    attempts: Mapped[int] = mapped_column(default=0)
    last_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    __table_args__ = (
        Index("ix_webhook_deliveries_endpoint_created", "endpoint_id", "created_at"),
        Index("ix_webhook_deliveries_merchant_created", "merchant_id", "created_at"),
        Index("ix_webhook_deliveries_status", "status"),
    )
