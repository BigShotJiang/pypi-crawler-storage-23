"""Receipt model — Sonic's three-tier immutable receipt chain.

Tier 1: App chain (receipt_hash, prev_receipt_hash) — always populated.
Tier 2: Combined chain (combined_hash, prev_combined_hash) — backfilled
        after SBN attestation fuses app + network hashes.
Tier 3: Blockchain anchor (anchor_*) — opt-in per-merchant on-chain proof.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class ReceiptRecord(Base):
    __tablename__ = "receipts"

    receipt_id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    tx_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    sequence: Mapped[int] = mapped_column(nullable=False)

    # Settlement data
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    currency: Mapped[str] = mapped_column(String(4), nullable=False)
    rail: Mapped[str] = mapped_column(String(32), nullable=False)
    direction: Mapped[str] = mapped_column(String(10), nullable=False)  # inbound | outbound

    # Tier 1 — App chain integrity (always populated, never blocks)
    receipt_hash: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    prev_receipt_hash: Mapped[str | None] = mapped_column(String(128))

    # Provenance
    idempotency_key: Mapped[str] = mapped_column(String(128), nullable=False)
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    # Tier 2 — SBN coupling (nullable until attestation completes)
    sbn_receipt_hash: Mapped[str | None] = mapped_column(String(128))
    sbn_attested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Coupler fields (Mode B: slot-based batch coupling)
    sbn_block_id: Mapped[str | None] = mapped_column(String(64))
    sbn_block_hash: Mapped[str | None] = mapped_column(String(128))
    sbn_slot_id: Mapped[str | None] = mapped_column(String(64))
    sbn_attested_receipt_id: Mapped[str | None] = mapped_column(String(64))
    coupled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    couple_status: Mapped[str | None] = mapped_column(String(20), default="pending")  # pending|coupled|failed|stream_coupled
    epoch_key: Mapped[str | None] = mapped_column(String(64), index=True)

    # Tier 2 — Combined chain (nullable until SBN attestation backfills)
    combined_hash: Mapped[str | None] = mapped_column(String(128))
    prev_combined_hash: Mapped[str | None] = mapped_column(String(128))

    # Tier 3 — Blockchain anchor (nullable, opt-in per merchant)
    anchor_chain: Mapped[str | None] = mapped_column(String(16))  # "hedera" | "solana"
    anchor_tx_id: Mapped[str | None] = mapped_column(String(128))  # HCS seq or Solana sig
    anchor_consensus_ts: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    anchored_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    @property
    def proof_grade(self) -> str:
        """Product-visible proof grade derived from which tiers are populated.

        Lane A (optimistic / immediate availability):
          "app_only"  — Tier 1 only: receipt exists in app chain, no external proof yet.

        Lane B (attested / final):
          "sbn_attested" — Tier 2: SBN has attested this receipt (coupled or stream_coupled).
          "combined"     — Tier 2+: Combined hash fuses app + SBN chains.
          "anchored"     — Tier 3: On-chain anchor provides blockchain finality.

        Consumers can use this to distinguish "available balance" (app_only)
        from "final balance" (sbn_attested+).
        """
        if self.anchor_tx_id:
            return "anchored"
        if self.combined_hash:
            return "combined"
        if self.sbn_receipt_hash or self.couple_status in ("coupled", "stream_coupled"):
            return "sbn_attested"
        return "app_only"

    __table_args__ = (
        Index("ix_receipts_tx_sequence", "tx_id", "sequence"),
        Index("ix_receipts_merchant_ts", "merchant_id", "timestamp"),
        Index("ix_receipts_sbn_pending", "sbn_receipt_hash", postgresql_where="sbn_receipt_hash IS NULL"),
        Index("ix_receipts_combined_pending", "combined_hash", postgresql_where="combined_hash IS NULL AND sbn_receipt_hash IS NOT NULL"),
        Index("ix_receipts_anchor_pending", "anchor_chain", postgresql_where="anchor_chain IS NOT NULL AND anchor_tx_id IS NULL AND combined_hash IS NOT NULL"),
        Index("ix_receipts_couple_pending", "couple_status", postgresql_where="couple_status = 'pending'"),
    )
