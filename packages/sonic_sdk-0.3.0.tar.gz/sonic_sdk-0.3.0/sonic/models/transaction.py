"""Transaction model — persistent representation of the settlement state machine."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class TransactionRecord(Base):
    __tablename__ = "transactions"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"txn_{uuid.uuid4().hex[:24]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    state: Mapped[str] = mapped_column(String(32), nullable=False, default="initiated")
    sequence: Mapped[int] = mapped_column(default=0)

    # Inbound
    inbound_amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    inbound_currency: Mapped[str] = mapped_column(String(4), nullable=False)
    inbound_rail: Mapped[str] = mapped_column(String(32), nullable=False)
    inbound_provider_ref: Mapped[str | None] = mapped_column(String(128))

    # Treasury (post-normalization)
    treasury_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    treasury_asset: Mapped[str] = mapped_column(String(8), default="USDC")

    # Outbound
    outbound_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 6))
    outbound_currency: Mapped[str | None] = mapped_column(String(4))
    outbound_rail: Mapped[str | None] = mapped_column(String(32))
    outbound_provider_ref: Mapped[str | None] = mapped_column(String(128))

    # Customer-facing
    customer_ref: Mapped[str | None] = mapped_column(String(128))
    idempotency_key: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    # Archival: set when transaction is moved to cold storage / archive partition
    archived_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), default=None
    )

    __table_args__ = (
        Index("ix_transactions_merchant_state", "merchant_id", "state"),
        Index("ix_transactions_merchant_created", "merchant_id", "created_at"),
    )
