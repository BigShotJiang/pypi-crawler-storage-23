"""Payment link model — reusable, shareable payment URLs."""

from __future__ import annotations

import secrets
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


def _generate_slug() -> str:
    return secrets.token_urlsafe(8)


class PaymentLink(Base):
    __tablename__ = "payment_links"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"pl_{uuid.uuid4().hex[:16]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    slug: Mapped[str] = mapped_column(String(32), nullable=False, unique=True, default=_generate_slug)

    # Payment details
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    currency: Mapped[str] = mapped_column(String(4), nullable=False, default="USD")
    rail: Mapped[str | None] = mapped_column(String(32))  # None = let customer choose
    description: Mapped[str | None] = mapped_column(String(500))

    # Where to redirect after payment
    success_url: Mapped[str | None] = mapped_column(Text)

    # Status: active | inactive
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="active")

    # Usage tracking
    total_payments: Mapped[int] = mapped_column(default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    __table_args__ = (
        Index("ix_payment_links_merchant_status", "merchant_id", "status"),
    )
