"""Sonic-specific SBN integration layer.

Thin adapters that wrap the official ``sbn-sdk`` package with
Sonic-specific behaviour (error mapping, submit pipeline, config).

For raw SDK access, import directly from ``sbn``::

    from sbn import SbnClient as RawSbnClient, AgentClient

For Sonic-flavoured access::

    from sonic.sbn.client import SonicSbnClient, SbnError, SbnQuotaExceeded
"""

from __future__ import annotations
