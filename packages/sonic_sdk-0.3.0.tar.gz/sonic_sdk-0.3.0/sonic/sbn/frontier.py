"""Sonic GEC frontier configuration.

Defines the default frontier ID used by Sonic settlement
for GEC efficiency calculations on SBN.
"""

from __future__ import annotations

from sonic.config import settings

# The GEC frontier ID used for Sonic settlement blocks.
# Configured via SONIC_SBN_FRONTIER_ID env var.
SONIC_FRONTIER = settings.sbn_frontier_id
