"""Mode B Receipt Coupler — slot-based batch coupling of Sonic receipts to SBN.

For each settlement epoch (daily UTC by default), the coupler:

  1. Opens an SBN slot (via ``gateway.create_slot``)
  2. Submits one SmartBlock per Sonic receipt (via ``blocks.submit``)
  3. Closes the slot to get a Merkle root (via ``gateway.close_slot``)
  4. Requests attestation on the slot summary (via ``gateway.request_attestation``)
  5. Writes back coupling fields into Sonic DB

All operations are idempotent: the coupler can be restarted safely.
Epoch state is tracked in the ``sbn_epochs`` table.

The coupler uses ``SonicSbnClient`` (not AgentClient) because it needs
``blocks.submit()`` which is only available on the full client.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from sonic.config import settings

logger = logging.getLogger(__name__)


def _current_epoch_key() -> str:
    """Compute the current epoch key based on configured boundary."""
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%d")


class ReceiptCoupler:
    """Couples Sonic receipts to SBN using slot-based batch attestation (Mode B).

    This is the main coupler agent. It can run as:
    - A background worker inside the FastAPI lifespan (drain loop)
    - A standalone daemon process

    Architecture:
    - One SBN slot per epoch (daily UTC by default)
    - Each receipt becomes a SmartBlock in the slot
    - Slot close produces a Merkle root over the batch
    - Optional attestation provides quorum proof over the batch
    """

    def __init__(
        self,
        sbn_client: Any,
        db_session_factory: Any,
        *,
        combined_backfiller: Any | None = None,
    ) -> None:
        self._sbn = sbn_client  # Sonic SbnClient wrapper
        self._db = db_session_factory
        self._backfiller = combined_backfiller

    # ── Epoch management ────────────────────────────────────────────────

    async def _ensure_epoch(self, epoch_key: str) -> dict[str, Any]:
        """Get or create the epoch record + SBN slot.

        Returns the epoch row as a dict.
        """
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            result = await session.execute(
                SbnEpoch.__table__.select().where(SbnEpoch.epoch_key == epoch_key)
            )
            epoch = result.mappings().first()

            if epoch and epoch["slot_id"]:
                return dict(epoch)

            # Create epoch record if it doesn't exist
            if not epoch:
                import uuid

                epoch_id = str(uuid.uuid4())
                await session.execute(
                    SbnEpoch.__table__.insert().values(
                        id=epoch_id,
                        epoch_key=epoch_key,
                        state="open",
                        opened_at=datetime.now(timezone.utc),
                    )
                )
                await session.commit()

                result = await session.execute(
                    SbnEpoch.__table__.select().where(SbnEpoch.epoch_key == epoch_key)
                )
                epoch = result.mappings().first()

            epoch = dict(epoch)

            # Open SBN slot if we don't have one yet
            if not epoch.get("slot_id") and self._sbn.active:
                try:
                    slot = self._sbn.sdk.gateway.create_slot(
                        worker_id=settings.coupler_worker_id,
                        task_type=settings.coupler_task_type,
                        metadata={"epoch_key": epoch_key, "source": "sonic-coupler"},
                    )
                    await session.execute(
                        SbnEpoch.__table__.update()
                        .where(SbnEpoch.epoch_key == epoch_key)
                        .values(slot_id=slot.id)
                    )
                    await session.commit()
                    epoch["slot_id"] = slot.id
                    logger.info("Opened SBN slot %s for epoch %s", slot.id, epoch_key)
                except Exception:
                    logger.warning(
                        "Failed to create SBN slot for epoch %s", epoch_key, exc_info=True
                    )
                    await session.execute(
                        SbnEpoch.__table__.update()
                        .where(SbnEpoch.epoch_key == epoch_key)
                        .values(state="failed", last_error="slot creation failed")
                    )
                    await session.commit()

            return epoch

    # ── Block payload construction ──────────────────────────────────────

    def _build_block_payload(self, receipt_row: dict[str, Any]) -> dict[str, Any]:
        """Build the SmartBlock payload for a single Sonic receipt."""
        amount = receipt_row["amount"]
        if isinstance(amount, Decimal):
            amount = str(amount)

        return {
            "type": "finance",
            "domain": settings.coupler_domain,
            "actions": [
                {
                    "action": "settlement_receipt",
                    "reinforced": False,
                    "score": 1.0,
                }
            ],
            "events": {
                "total": 1,
                "hostile": 0,
                "neutral": 0,
                "friendly": 1,
            },
            "metadata": {
                "sonic_receipt_id": receipt_row["receipt_id"],
                "sonic_receipt_hash": receipt_row["receipt_hash"],
                "epoch_key": receipt_row.get("epoch_key", ""),
                "amount": amount,
                "currency": receipt_row["currency"],
                "network": receipt_row["rail"],
                "merchant_id": receipt_row["merchant_id"],
                "tx_id": receipt_row["tx_id"],
                "version": "sonic-receipt.v1",
            },
        }

    # ── Step 2: Submit blocks to slot ───────────────────────────────────

    async def _submit_receipt_block(
        self,
        receipt_row: dict[str, Any],
        slot_id: str,
    ) -> dict[str, Any] | None:
        """Submit a single receipt as a SmartBlock to the epoch slot.

        Returns the block response or None on failure.
        """
        if not self._sbn.active:
            return None

        payload = self._build_block_payload(receipt_row)

        try:
            block = self._sbn.sdk.blocks.submit(
                slot_id=slot_id,
                payload=payload,
                domain=settings.coupler_domain,
                metadata={"source": "sonic-coupler", "receipt_id": receipt_row["receipt_id"]},
            )
            return block
        except Exception:
            logger.warning(
                "Failed to submit block for receipt %s to slot %s",
                receipt_row["receipt_id"],
                slot_id,
                exc_info=True,
            )
            return None

    # ── Step 3: Close epoch ─────────────────────────────────────────────

    async def close_epoch(self, epoch_key: str) -> dict[str, Any] | None:
        """Close the SBN slot for an epoch.

        Idempotent: if already closed, returns the existing closure data.
        """
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            result = await session.execute(
                SbnEpoch.__table__.select().where(SbnEpoch.epoch_key == epoch_key)
            )
            epoch = result.mappings().first()

            if not epoch:
                return None

            # Already closed or attested
            if epoch["state"] in ("closed", "attested"):
                return dict(epoch)

            slot_id = epoch["slot_id"]
            if not slot_id:
                return None

            # Mark as closing
            await session.execute(
                SbnEpoch.__table__.update()
                .where(SbnEpoch.epoch_key == epoch_key)
                .values(state="closing")
            )
            await session.commit()

        # Close the SBN slot
        if not self._sbn.active:
            return None

        try:
            closure = self._sbn.sdk.gateway.close_slot(slot_id)
        except Exception:
            logger.warning("Failed to close slot %s for epoch %s", slot_id, epoch_key, exc_info=True)
            async with self._db() as session:
                from sonic.models.epoch import SbnEpoch

                await session.execute(
                    SbnEpoch.__table__.update()
                    .where(SbnEpoch.epoch_key == epoch_key)
                    .values(state="failed", last_error="slot close failed")
                )
                await session.commit()
            return None

        # Persist closure
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            await session.execute(
                SbnEpoch.__table__.update()
                .where(SbnEpoch.epoch_key == epoch_key)
                .values(
                    state="closed",
                    close_receipt_id=closure.receipt_id,
                    closed_at=closure.closed_at or datetime.now(timezone.utc),
                )
            )
            await session.commit()

        logger.info(
            "Epoch %s closed: slot=%s receipt=%s",
            epoch_key,
            slot_id,
            closure.receipt_id,
        )
        return {
            "epoch_key": epoch_key,
            "slot_id": slot_id,
            "close_receipt_id": closure.receipt_id,
            "state": "closed",
        }

    # ── Step 4: Attest epoch ────────────────────────────────────────────

    async def attest_epoch(self, epoch_key: str) -> dict[str, Any] | None:
        """Request attestation on the closed epoch's slot summary.

        Idempotent: if already attested, returns existing data.
        """
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            result = await session.execute(
                SbnEpoch.__table__.select().where(SbnEpoch.epoch_key == epoch_key)
            )
            epoch = result.mappings().first()

            if not epoch or epoch["state"] == "attested":
                return dict(epoch) if epoch else None

            if epoch["state"] != "closed":
                return None

            slot_id = epoch["slot_id"]
            close_receipt_id = epoch["close_receipt_id"]

        if not self._sbn.active or not slot_id:
            return None

        try:
            # Plain dict per POST /attest schema (Agent SDK Developer Guide)
            summary = {
                "slot_id": slot_id,
                "snap_hash": close_receipt_id or f"sha256:{epoch_key}",
                "snap_version": "1",
                "metadata": {"epoch_key": epoch_key, "source": "sonic-coupler"},
            }
            attestation = self._sbn.sdk.gateway.request_attestation(summary)
            attestation_receipt_id = attestation.get("receipt_id") or attestation.get("id", "")
        except Exception:
            logger.warning("Attestation failed for epoch %s", epoch_key, exc_info=True)
            return None

        # Persist attestation
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            await session.execute(
                SbnEpoch.__table__.update()
                .where(SbnEpoch.epoch_key == epoch_key)
                .values(
                    state="attested",
                    attestation_receipt_id=attestation_receipt_id,
                )
            )
            await session.commit()

        logger.info(
            "Epoch %s attested: receipt=%s",
            epoch_key,
            attestation_receipt_id,
        )

        # Step 5: Backfill proof grade on coupled receipts
        await self._backfill_attestation(epoch_key, attestation_receipt_id)

        return {
            "epoch_key": epoch_key,
            "attestation_receipt_id": attestation_receipt_id,
            "state": "attested",
        }

    async def _backfill_attestation(
        self, epoch_key: str, attestation_receipt_id: str
    ) -> int:
        """Backfill attestation receipt ID onto all coupled receipts in the epoch."""
        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            result = await session.execute(
                ReceiptRecord.__table__.update()
                .where(
                    ReceiptRecord.epoch_key == epoch_key,
                    ReceiptRecord.couple_status == "coupled",
                )
                .values(sbn_attested_receipt_id=attestation_receipt_id)
            )
            await session.commit()
            count = result.rowcount
            if count:
                logger.info("Backfilled attestation on %d receipts for epoch %s", count, epoch_key)
            return count

    # ── Main drain cycle ────────────────────────────────────────────────

    async def drain(self, max_batch: int | None = None) -> int:
        """Process pending receipts for the current epoch.

        1. Ensure epoch + slot exist
        2. Claim pending receipts
        3. Submit each as a SmartBlock to the slot
        4. Update coupling fields

        Returns the count of receipts coupled.
        """
        if not settings.coupler_enabled or not self._sbn.active:
            return 0

        batch_size = max_batch or settings.coupler_batch_size
        epoch_key = _current_epoch_key()

        # Step 1: ensure epoch + slot
        epoch = await self._ensure_epoch(epoch_key)
        slot_id = epoch.get("slot_id")
        if not slot_id:
            return 0

        if epoch.get("state") not in ("open", None):
            return 0

        # Step 2: claim pending receipts
        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            result = await session.execute(
                ReceiptRecord.__table__.select()
                .where(ReceiptRecord.couple_status == "pending")
                .limit(batch_size)
            )
            rows = result.mappings().all()

        if not rows:
            return 0

        # Step 3: submit each receipt as a SmartBlock
        coupled = 0
        for row in rows:
            row_dict = dict(row)
            row_dict["epoch_key"] = epoch_key

            block = await self._submit_receipt_block(row_dict, slot_id)
            if block is None:
                # Mark as failed
                async with self._db() as session:
                    from sonic.models.receipt import ReceiptRecord

                    await session.execute(
                        ReceiptRecord.__table__.update()
                        .where(ReceiptRecord.receipt_id == row_dict["receipt_id"])
                        .values(couple_status="failed")
                    )
                    await session.commit()
                continue

            # Step 4: persist coupling fields
            block_id = block.get("id", "")
            block_hash = block.get("hash", "")
            sbn_hash = block_hash

            async with self._db() as session:
                from sonic.models.receipt import ReceiptRecord

                await session.execute(
                    ReceiptRecord.__table__.update()
                    .where(ReceiptRecord.receipt_id == row_dict["receipt_id"])
                    .values(
                        sbn_block_id=block_id,
                        sbn_block_hash=block_hash,
                        sbn_slot_id=slot_id,
                        sbn_receipt_hash=sbn_hash,
                        sbn_attested_at=datetime.now(timezone.utc),
                        coupled_at=datetime.now(timezone.utc),
                        couple_status="coupled",
                        epoch_key=epoch_key,
                    )
                )
                await session.commit()

            # Trigger combined hash backfill
            if self._backfiller and sbn_hash:
                try:
                    await self._backfiller.enqueue(row_dict["receipt_id"], sbn_hash)
                except Exception:
                    logger.warning(
                        "Combined backfill enqueue failed for receipt %s",
                        row_dict["receipt_id"],
                        exc_info=True,
                    )

            coupled += 1

        logger.info(
            "Coupled %d/%d receipts for epoch %s (slot %s)",
            coupled,
            len(rows),
            epoch_key,
            slot_id,
        )
        return coupled

    # ── Epoch lifecycle helpers ─────────────────────────────────────────

    async def maybe_close_previous_epochs(self) -> int:
        """Close any open epochs from previous days.

        Called periodically by the drain loop. Only closes epochs
        whose epoch_key < today (i.e., the day has passed).
        """
        today = _current_epoch_key()
        closed = 0

        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch

            result = await session.execute(
                SbnEpoch.__table__.select()
                .where(SbnEpoch.state == "open", SbnEpoch.epoch_key < today)
            )
            stale_epochs = result.mappings().all()

        for epoch in stale_epochs:
            closure = await self.close_epoch(epoch["epoch_key"])
            if closure:
                # Also attest
                await self.attest_epoch(epoch["epoch_key"])
                closed += 1

        return closed

    async def epoch_health(self) -> dict[str, Any]:
        """Return current epoch status for health checks."""
        epoch_key = _current_epoch_key()
        async with self._db() as session:
            from sonic.models.epoch import SbnEpoch
            from sonic.models.receipt import ReceiptRecord

            epoch_result = await session.execute(
                SbnEpoch.__table__.select().where(SbnEpoch.epoch_key == epoch_key)
            )
            epoch = epoch_result.mappings().first()

            pending_result = await session.execute(
                ReceiptRecord.__table__.select()
                .where(ReceiptRecord.couple_status == "pending")
            )
            pending_count = len(pending_result.mappings().all())

        return {
            "epoch_key": epoch_key,
            "epoch_state": epoch["state"] if epoch else "not_started",
            "slot_id": epoch["slot_id"] if epoch else None,
            "pending_receipts": pending_count,
            "coupler_enabled": settings.coupler_enabled,
            "sbn_active": self._sbn.active,
        }
