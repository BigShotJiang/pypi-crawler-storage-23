from .prioritycomparison import priocomp
