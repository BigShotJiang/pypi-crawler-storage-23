# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

from pypnm.lib.compression.manager import CompressionManager

__all__ = ["CompressionManager"]
