"Example for entangle"


# %% collections ------------------------------------------------------
import collections
# %% os ---------------------------------------------------------------
import os
# %% sys --------------------------------------------------------------
import sys
# %% imports collections os sys docstring------------------------------
import json
import typing
print("Imported modules, now going to print some text")
if True:
    print('Some long', 'text to ', 'see how', 'parameters',
          ' will', ' be', 'spread', 'over', 'multiple lines')

print(os.getcwd())
print(sys.executable)


# %% foo imports-------------------------------------------------------
print("Trying foo again")
def foo(): print('function foo() called')


# %% bar foo-----------------------------------------------------------
print("Running in cell bar, calling foo()")
foo()
def bar(): print('function bar() called')


# %% eof foo-----------------------------------------------------------
print("Running in eof")
# end-of-file ---------------------------------------------------------

