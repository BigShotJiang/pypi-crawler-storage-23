'entangle your own docstring here'


# %% imports ----------------------------------------------------------
import json
import typing
print("Imported some modules")


# %% foo imports-------------------------------------------------------
print("Running in cell foo")


def foo(): print('function foo() called')


# %% bar foo-----------------------------------------------------------
print("Running in cell bar, calling foo()")

foo()


def bar(): print('function bar() called')


# %% eof bar-----------------------------------------------------------
print("Running in eof")
# end-of-file ---------------------------------------------------------

