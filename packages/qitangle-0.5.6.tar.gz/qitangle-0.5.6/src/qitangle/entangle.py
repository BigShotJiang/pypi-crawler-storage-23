# This file is generated - do not edit
"""Entangle - entangles code from ipython notebook cells to python .py files"""

import os
import collections
import typing
import logging
import argparse
import autopep8

from IPython.core.magic import Magics, magics_class, cell_magic, line_cell_magic, line_magic
from qitangle import split_line_args, extract_module_filepath, run_fixer

__all__ = [
    "CodeCell", "entangle_all_cells", "load_ipython_extension"
]

syslog = logging.getLogger(__name__)

CodeText_T = str
Label_T = str
Dependency_T = str


class CodeCell(typing.NamedTuple):
    """Passive object with code, label and dependencies attributes"""
    code: CodeText_T
    label: Label_T
    dependencies: list[Dependency_T]


CodeCellCollection_T = dict[str, CodeCell]
CodeCellIterator_T = typing.Iterator[CodeCell]


def entangle_all_cells(
    cell_collection: CodeCellCollection_T
) -> CodeCellIterator_T:
    """ Entangles a collection of code cells (depth first tree visit)"""

    collection = cell_collection.copy()

    def _entangle_cell(current_label) -> CodeCellIterator_T:
        """ visit cell depencies and cell """

        current_cell = collection.pop(current_label)

        for dependency in current_cell.dependencies:
            if dependency in collection:
                yield from _entangle_cell(dependency)

        yield current_cell

    while collection:
        yield from _entangle_cell(next(iter(collection)))


def entangle_cells_for(

    cell_collection: CodeCellCollection_T,
    *only_these_labels: Label_T

) -> CodeCellIterator_T:
    """ Entangles a collection of code cells for selected labels only"""

    collection = cell_collection.copy()

    def _entangle_cells(*_labels) -> CodeCellIterator_T:
        """ visit cell depencies and cell """
        if not _labels:
            return

        head, *tail = _labels
        if head in collection:
            current_cell = collection.pop(head)
            yield from _entangle_cells(*current_cell.dependencies)
            yield current_cell

        if tail:
            yield from _entangle_cells(*tail)

    yield from _entangle_cells(*only_these_labels)


_missing_dependency_T = collections.namedtuple(
    "missing_dependency", ["label", "dependency"])


def missing_dependencies(
    cell_sequence: typing.Iterable[CodeCell]
) -> typing.Iterator[_missing_dependency_T]:

    seen = set()
    for cell in cell_sequence:
        seen.add(cell.label)
        for dependency in cell.dependencies:
            if dependency not in seen:
                yield _missing_dependency_T(cell.label, dependency)


CodeCellSequenceProcessor_T = typing.Callable[[
    CodeCellIterator_T], CodeCellIterator_T]


class CellCollection(typing.NamedTuple):
    update: typing.Callable[[str, str, list[str]], CodeCellIterator_T]
    travel: typing.Callable[[
        CodeCellSequenceProcessor_T], CodeCellIterator_T]


def create_cell_collection() -> CellCollection:

    logger = logging.getLogger(__name__)

    cell_collection = CodeCellCollection_T()
    cell_collection['docstring'] = CodeCell(
        "'entangle your own docstring here'", 'docstring', [])
    limbo = set[Label_T]()

    def recover() -> CodeCellIterator_T:
        for cell in entangle_all_cells(cell_collection):
            if cell.label in limbo:
                if not any(missing_dependencies(
                        entangle_cells_for(cell_collection, cell.label))):
                    yield cell
                    limbo.remove(cell.label)
                    logger.debug(f"recovered {cell.label}")

    def update_collection(

            code: CodeText_T,
            label: Label_T,
            dependencies: list[Dependency_T]

    ) -> CodeCellIterator_T:
        syslog.debug(
            f"{'updating' if label in cell_collection else 'inserting'} {label} {dependencies}")
        cell_collection[label] = CodeCell(
            code, label, list(set(dependencies)))

        limbo.add(label)
        yield from recover()

    def travel_collection(

            visit_sequence: CodeCellSequenceProcessor_T,
            *labels: Label_T

    ) -> CodeCellIterator_T:

        if labels:
            yield from visit_sequence(entangle_cells_for(cell_collection, *labels))

        else:
            yield from visit_sequence(entangle_all_cells(cell_collection))

    return CellCollection(update_collection, travel_collection)


CodeCellTextReader_T = typing.Callable[[
    typing.Iterator[str]], CodeCellIterator_T]


def create_cell_importer(

    filename: FilePath_T,
    # cell_creator:CodeCellTextReader_T,

) -> typing.Callable[[typing.Iterator[Label_T]], Code]:

    def line_reader():
        with open(filename, "rt") as fp:
            for line in fp.readlines():
                yield line

    def render_cells(lines):
        code = list()
        label = 'docstring'
        dependencies = []

        def yield_cell(code, label, dependencies):
            yield CodeCell(
                ''.join(code),
                label,
                [d for d in dependencies if d]
            )

        for line in lines:
            l = line.split('# %% ')
            if len(l) < 2:
                code.append(line)
            else:
                yield from yield_cell(code, label, dependencies)
                label, *dependencies = l[1].rstrip('-\n').split(' ')
                code = list()
        if code:
            yield from yield_cell(code, label, dependencies)

    def reader(missing_labels: typing.Iterator[str] = [
    ]) -> CodeCellIterator_T:
        missing = set(missing_labels)
        if not missing:
            yield from render_cells(line_reader())
        else:
            for cell in render_cells(line_reader()):
                if cell.label in missing:
                    yield cell
                    missing.remove(cell.label)

    return reader


FilePath_T = str
CodeCellTextTransformer_T = typing.Callable[[CodeCell], CodeText_T]


def create_export_cell_code_visitor(
        no_header: bool = None) -> CodeCellTextTransformer_T:
    next_cell_has_no_header = bool(no_header)

    def cell_to_text(cell: CodeCell) -> str:
        nonlocal next_cell_has_no_header
        if next_cell_has_no_header:
            next_cell_has_no_header = False
            return f'{cell.code}\n\n'
        else:
            return f'\n# %% {cell.label} {' '.join(cell.dependencies)}'.ljust(
                72, '-') + f'\n{cell.code}{"\n" if len(cell.code.splitlines()) > 1 else ""}'

    return cell_to_text


def create_file_writer(
        filepath: FilePath_T,
        cell_process: CodeCellTextTransformer_T = lambda c: str(c.code),
        post_process: typing.Callable[[
            FilePath_T], None] = lambda f: None,

) -> CodeCellSequenceProcessor_T:

    os.makedirs(os.path.split(filepath)[0], exist_ok=True)

    def write_sequence(
            code_cells: CodeCellIterator_T) -> CodeCellIterator_T:

        with open(filepath, 'w') as f:
            for cell in code_cells:
                f.write(cell_process(cell))
                yield cell

        post_process(filepath)

    return write_sequence


def create_export_test_visitor(
        report: typing.Callable) -> CodeCellTextTransformer_T:
    seen_cells = set[Label_T]()

    def visit(cell: CodeCell) -> str:
        nonlocal seen_cells

        seen_cells.add(cell.label)
        missing_dependencies = set(cell.dependencies) - seen_cells

        report(cell.label, *missing_dependencies)

    def travel(code_cells: CodeCellIterator_T) -> CodeCellIterator_T:
        for cell in code_cells:
            visit(cell)
            yield cell

    return travel


def create_cell_analysis_traveler(

        unused_cells: set[Label_T],
        missing_deps: set[Label_T]

) -> CodeCellSequenceProcessor_T:

    seen_cells = set[Label_T]()

    def visit(cell: CodeCell):
        nonlocal unused_cells, missing_deps, seen_cells

        seen_cells.add(cell.label)
        unused_cells.add(cell.label)

        deps = set(cell.dependencies)
        unused_cells -= deps
        missing_deps |= (deps - seen_cells)

    def travel(code_cells: CodeCellIterator_T) -> CodeCellIterator_T:
        for cell in code_cells:
            visit(cell)
            yield cell

    return travel


def create_entangler_creation_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(
        f'%tangle',
        exit_on_error=False,
        add_help=True,
        suggest_on_error=True)
    parser.add_argument(
        '-s',
        '--stdlib',
        help='generate missing stdlib import cells',
        action='store_true')
    parser.add_argument(
        '-p',
        '--preload',
        help='import missing cells from exported file',
        action='store_true')
    parser.add_argument(
        '-f',
        '--fix',
        help='Fix/reFormat when adding code on all cells',
        action='store_true')
    parser.add_argument(
        '-l',
        '--lib',
        action='store',
        help='lib directory name if not in module-path',
        default="")
    parser.add_argument(
        'modulepath',
        nargs='?',
        help='module path notation for export')

    return parser


def create_entangler_line_argument_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(
        f'%tangle',
        exit_on_error=False,
        add_help=True,
        suggest_on_error=True)
    parser.add_argument(
        '-r',
        '--report',
        help='report unused and missing dependencies',
        action='store_true')
    parser.add_argument(
        '-m',
        '--missing',
        help='list missing dependencies',
        action='store_true')
    parser.add_argument(
        '-e',
        '--export',
        help='export code cells',
        action='store_true')
    parser.add_argument(
        '-f',
        '--fix',
        help='Fix/reFormat code after tangling',
        action='store_true')
    parser.add_argument(
        'labels',
        nargs='*',
        help='the labels of code cells (all if omitted)')

    return parser


def create_entangler_cell_argument_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(
        f'%%entangle',
        exit_on_error=False,
        add_help=True,
        suggest_on_error=True)
    parser.add_argument(
        '-f',
        '--fix',
        help='Fix/reFormat code',
        action='store_true')
    parser.add_argument(
        'label',
        nargs='?',
        help='the label for the code cell')
    parser.add_argument(
        'dependencies',
        nargs='*',
        help='the dependencies for the code cell')

    return parser


_stdlib_labels = set([
    "abc", "annotationlib", "antigravity", "argparse", "array", "ast",
    "asyncio", "atexit", "base64", "bdb", "binascii", "bisect",
    "builtins", "bz2", "cProfile", "calendar", "cmath", "cmd", "code",
    "codecs", "codeop", "collections", "colorsys", "compileall",
    "compression", "concurrent", "configparser", "contextlib",
    "contextvars", "copy", "copyreg", "csv", "ctypes", "curses",
    "dataclasses", "datetime", "dbm", "decimal", "difflib", "dis",
    "doctest", "email", "encodings", "ensurepip", "enum", "errno",
    "faulthandler", "filecmp", "fileinput", "fnmatch", "fractions",
    "ftplib", "functools", "gc", "genericpath", "getopt", "getpass",
    "gettext", "glob", "graphlib", "gzip", "hashlib", "heapq",
    "hmac", "html", "http", "idlelib", "imaplib", "importlib",
    "inspect", "io", "ipaddress", "itertools", "json", "keyword",
    "linecache", "locale", "logging", "lzma", "mailbox", "marshal",
    "math", "mimetypes", "mmap", "modulefinder", "msvcrt",
    "multiprocessing", "netrc", "nt", "ntpath", "nturl2path",
    "numbers", "opcode", "operator", "optparse", "os", "pathlib", "pdb",
    "pickle", "pickletools", "pip", "pkgutil", "platform", "plistlib",
    "poplib", "posixpath", "pprint", "profile", "pstats", "pty",
    "pyclbr", "pydoc", "pyexpat", "queue", "quopri", "random", "re",
    "reprlib", "rlcompleter", "runpy", "sched", "secrets", "select",
    "selectors", "shelve", "shlex", "shutil", "signal", "site",
    "smtplib", "socket", "socketserver", "sqlite3", "ssl", "stat",
    "statistics", "string", "stringprep", "struct", "subprocess",
    "symtable", "sys", "sysconfig", "tabnanny", "tarfile", "tempfile",
    "textwrap", "this", "threading", "time", "timeit", "tkinter",
    "token", "tokenize", "tomllib", "trace", "traceback", "tracemalloc",
    "tty", "turtle", "turtledemo", "types", "typing", "unicodedata",
    "unittest", "urllib", "uuid", "venv", "warnings", "wave", "weakref",
    "webbrowser", "winreg", "winsound", "wsgiref", "xml", "xmlrpc",
    "xxsubtype", "zipapp", "zipfile", "zipimport", "zlib", "zoneinfo"
])


def stdlib_imports(
        missing_labels: typing.Iterator[Label_T]) -> CodeCellIterator_T:
    "yield missing cells to import modules from the python standard lib"

    for label in missing_labels:
        if label in _stdlib_labels:
            yield CodeCell(f'import {label}', label, [])


def all_stdlib_cells() -> CodeCellIterator_T:
    for label in _stdlib_labels:
        yield CodeCell('', label, ["docstring"])


@magics_class
class TangleMagic(Magics):

    def __init__(self, shell, **kwargs):
        super(TangleMagic, self).__init__(shell)

        self.cell_parser = create_entangler_cell_argument_parser()
        self.line_parser = create_entangler_line_argument_parser()
        self.create_parser = create_entangler_creation_parser()

        self.fix = kwargs.get("fix", False)
        self.stdlib = kwargs.get("stdlib", False)
        self.filename = kwargs.get("filename", "")

        self.collection = create_cell_collection()
        self.shadow_collection = create_cell_collection()

    def parse_args(self, parser: ArgumentParser, line: str):
        try:
            return parser.parse_args(split_line_args(line))
        except Exception as err:
            logging.getLogger(__name__).exception(
                f"Yikes, something ({err}) went wrong parsing your input...",
                exc_info=False)

        # parser.print_help()

    def update_collection(self, cell, label, dependencies, fix):
        yield from self.collection.update(
            autopep8.fix_code(
                cell, options=dict(
                    ignore=['E402'])) if (
                fix or self.fix) else cell,
            label, dependencies
        )

        yield from self.add_missing()

    def export_collection(self, fix, *labels):
        collections.deque(self.collection.travel(
            create_file_writer(
                self.filename,
                create_export_cell_code_visitor(True),
                run_fixer if fix else lambda f: None,
            ),
            *labels
        ), 0)

    def test_missing(self, *labels):

        def report(label, *missing):
            left_kol = f"{label:<20}"
            right_kol = ""
            for dep in missing:
                if len(right_kol) + len(dep) < 39:
                    right_kol = " ".join([right_kol, dep])
                else:
                    print(f"{left_kol} - {right_kol}")
                    left_kol = f"{' ':<20}"
                    right_kol = f"{dep}"
            if right_kol:
                print(f"{left_kol} - {right_kol}")

        collections.deque(self.collection.travel(
            create_export_test_visitor(report),
            *labels
        ), 0)

    def list_collection(self, *labels):
        """Lists missing dependencies and unused cells"""
        unused_cells = set[Label_T]()
        missing_deps = set[Label_T]()

        collections.deque(self.collection.travel(
            create_cell_analysis_traveler(unused_cells, missing_deps),
            *labels
        ), 0)

        if unused_cells:
            print("Cells not used as dependency:")
            print(unused_cells)
        if missing_deps:
            print("Missing dependencies:")
            print(missing_deps)

    def add_missing(self, *labels):

        def missing(cell_sequence):
            seen = set()
            for cell in cell_sequence:
                seen.add(cell.label)
                for dependency in cell.dependencies:
                    if dependency not in seen:
                        yield dependency

        def add_missing_stdlib_imports(cell_sequence):
            yield from stdlib_imports(missing(cell_sequence))

        if self.stdlib:
            for cell in self.collection.travel(
                    add_missing_stdlib_imports, *labels):
                yield from self.collection.update(
                    cell.code, cell.label, cell.dependencies
                )

    @line_magic
    def tangle(self, line):
        # Line operation -> controls

        if self.filename:
            if line:
                try:
                    args = self.parse_args(self.line_parser, line)

                    if args.export:
                        self.export_collection(args.fix, *args.labels)

                    elif args.report:
                        self.list_collection(*args.labels)

                    elif args.missing:
                        self.test_missing(*args.labels)

                    else:
                        self.line_parser.print_help()

                except BaseException:
                    pass

            else:
                self.line_parser.print_help()
                print(f"module file is {self.filename}")
                print(
                    f"{'--format is enabled,' if self.fix else ''}{'--stdlib is enabled' if self.stdlib else ''}")

        else:
            try:
                args = self.parse_args(self.create_parser, line)
            except BaseException:
                pass

            if args is not None and args.modulepath is not None:
                self.filename = extract_module_filepath(
                    args.modulepath, args.lib)
                self.fix = args.fix
                self.stdlib = args.stdlib

                if args.preload:
                    for cell in create_cell_importer(self.filename)():
                        for c in self.update_collection(
                                cell.code.rstrip().lstrip(),
                                cell.label, cell.dependencies,
                                self.fix):

                            try:
                                self.shell.run_cell(c.code)

                            except Exception as err:
                                syslog.exception(
                                    f"Caught exception {err}\n")

                print("Tangle args:", args)
                print(f"Export setup for {self.filename}")
                print(f"module file is {self.filename}")
                print(
                    f"{'--format is enabled,' if self.fix else ''}{'--stdlib is enabled' if self.stdlib else ''}")

            else:
                self.create_parser.print_help()

    @cell_magic
    def entangle(self, line: str, cell: str):
        "Entangles a code cell"
        try:
            args = self.parse_args(self.cell_parser, line)
        except BaseException:
            pass

        if args is not None and args.label:
            for c in self.update_collection(
                    cell.rstrip().lstrip(),
                    args.label, args.dependencies,
                    args.fix):

                try:
                    self.shell.run_cell(c.code)

                except Exception as err:
                    syslog.exception(f"Caught exception {err}\n")

        else:
            self.cell_parser.print_help()


def load_ipython_extension(ipython):
    ipython.register_magics(TangleMagic)
