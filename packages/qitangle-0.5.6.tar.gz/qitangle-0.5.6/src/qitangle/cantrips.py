"""Cantrips - basic magic to bootstrap the nicer stuff"""

import sys, os, errno, autopep8, argparse, typing
from IPython.core.magic import Magics, magics_class, cell_magic, line_magic
from qitangle import project_root, extract_module_filepath, split_line_args, run_fixer

class CantripsMagicWriter(typing.NamedTuple):
    write: typing.Callable

def create_exportfile_argparser():

    parser  = argparse.ArgumentParser(prog='cantrips', description='Cantrips - set_exportfile: prepare to export to a file speciifed by libfolder and python module-path', epilog='See [Custom IPython Magic](https://ipython.readthedocs.io/en/stable/config/custommagics.html) documentation')

    parser.add_argument('libfolder', help='the root folder for the code', default='')
    parser.add_argument('modulepath', help='the module path')
    parser.add_argument('-f', '--format', help='Format code using autopep8', action='store_true')
    parser.add_argument('-w', '--write', help='Write to a new file (default appends)', action='store_true')

    return parser

def create_writer(line_args):
    parser = create_exportfile_argparser()
    if isinstance(line_args, str):
        args = line_args.split(' ')
    else:
        args = line_args.copy()

    parsed_args = parser.parse_args(split_line_args(line_args))

    filepath =  extract_module_filepath(parsed_args.modulepath, parsed_args.libfolder)

    if parsed_args.write:
        with open(filepath, 'w') as f:
            f.write("# This file is generated - do not edit\n")

    def write_straight(cell_code):
        with open(filepath, 'a') as f:
            f.write(cell_code)

    def write_fixed(cell_code):
        write_straight(cell_code)
        run_fixer(filepath)

    return CantripsMagicWriter(
        write_fixed if parsed_args.format else write_straight
    )

@magics_class
class CantripsMagic(Magics):

    @line_magic
    def default_export(self, line):
        """Sets the export file path"""
        self.writer = create_writer(line)

    @cell_magic
    def export(self, line, cell):
        """Execute & Write cell content"""
        self.shell.run_cell(cell)
        self.writer.write(cell)

def load_ipython_extension(ipython):
    ipython.register_magics(CantripsMagic)

__all__ = ['load_ipython_extension']
