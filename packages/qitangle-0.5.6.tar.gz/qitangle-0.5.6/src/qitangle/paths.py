"""Paths - filenames and paths"""

import sys, os, errno
import tomllib, typing

def path_parents(path:str)->typing.Iterable[str]:
    """Iterate over the parent directories of path."""

    head, tail = os.path.split(path)
    while tail:
        yield head
        head, tail = os.path.split(head)


def project_root(*sentinels) -> str:
    """
        Find a root directory for the current working directory 
        (a) the nearest ancestor containing any of the sentinels or 
        (b) the nearest ancestor to join the python executable path

        Throws a FileNotFoundError if neither (a) nor (b) is found

    """

    if not sentinels:
        return project_root('.git', '.venv', 'pyproject.toml')
       
    python_exe_path_set = set(path_parents(os.path.abspath(sys.executable)))

    def is_root(head):
        return (
            head in python_exe_path_set 
            or any( (os.path.exists(os.path.join(head, sentinel)) for sentinel in sentinels))
        )

    cwd = os.path.abspath(os.getcwd())        
    while cwd:

        if(is_root(cwd)):
            return cwd            

        cwd, tail = os.path.split(cwd)


    raise FileNotFoundError(
        errno.ENOENT, 
        os.strerror(errno.ENOENT), 
        cwd
    )


def extract_module_filepath(modulepath:str, libname:str=str("")) -> str:
    """
        Figures out the filepath to use for a dotted module-path in 
        combination with a libname. Uses pyproject.toml if no libname 
        is given. May bark exceptions at you.
    
    """

    project_path = project_root("pyproject.toml")
    module_parts = modulepath.split('.')
        
    if not libname:
        with open(os.path.join(project_path, "pyproject.toml"), "rb") as f:
            pyproject = tomllib.load(f)
        
            libname = pyproject.get('tool', {}).get('flit',{}).get('module',{}).get(
                'name', pyproject.get('project',{}).get('name', module_parts[0]))

    libpath = os.path.join(project_path, libname)
    if not os.path.isdir(libpath):
        libpath = os.path.join(project_path, "src", libname)

    assert os.path.isdir(libpath), f"Deduced {libpath} for modules but it was not found!"

    if libname and libname == module_parts[0]:
        module_parts.pop(0)

    return  os.path.join(
        libpath,
        *module_parts
    ) + '.py'
