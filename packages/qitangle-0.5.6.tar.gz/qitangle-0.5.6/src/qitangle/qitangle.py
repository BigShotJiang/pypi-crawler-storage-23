"""QiTangle - Tangle Quarto IPython code cells into source files"""



# %% typing docstring--------------------------------------------------
import typing

# %% collections docstring---------------------------------------------
import collections

# %% codecell typing---------------------------------------------------
CodeText_T = str
Label_T = str
Dependency_T = str


class CodeCell(typing.NamedTuple):
    """Passive object with code, label and dependencies attributes"""
    code: CodeText_T
    label: Label_T
    dependencies: list[Dependency_T]


# %% codecell_iterator_t codecell--------------------------------------
# Generic typedef for codecell iterators
CodeCellIterator_T = typing.Iterator[CodeCell]


# %% codecell_visitor_t codecell_iterator_t codecell-------------------
# Generic typedef for codecell iterators
CodeCellVisitor_T = typing.Callable[[CodeCellIterator_T], CodeCellIterator_T]


# %% codecell_collection_t codecell_iterator_t codecell----------------
# typedef for codecell collection
CodeCellCollection_T = dict[str, CodeCell]

# typdef for functions creating generators / iterators on a codecell collection
CodeCellTraveller_T = typing.Callable[[
    CodeCellCollection_T], CodeCellIterator_T]


# %% entangle_collection codecell_collection_t-------------------------
def entangle_collection(cell_collection: CodeCellCollection_T) -> CodeCellIterator_T:
    """ Entangles a collection of code cells (depth first tree visit)"""

    collection = cell_collection.copy()

    def _entangle_cell(current_label) -> CodeCellIterator_T:
        """ visit cell depencies and cell """

        current_cell = collection.pop(current_label)

        for dependency in current_cell.dependencies:
            if dependency in collection:
                yield from _entangle_cell(dependency)

        if current_cell.code:
            yield current_cell

    while collection:
        yield from _entangle_cell(next(iter(collection)))


# %% entangle_only_for codecell----------------------------------------
def entangle_only_for(

    cell_collection: CodeCellCollection_T,
    *only_these_labels: Label_T

) -> CodeCellIterator_T:
    """ Entangles a collection of code cells for selected labels only"""

    collection = cell_collection.copy()

    def _entangle_cells(*_labels) -> CodeCellIterator_T:
        """ visit cell depencies and cell """
        if not _labels:
            return

        head, *tail = _labels

        if head in collection:
            current_cell = collection.pop(head)

            yield from _entangle_cells(*current_cell.dependencies)

            if cell.code:
                yield current_cell

        if tail:
            yield from _entangle_cells(*tail)

    yield from _entangle_cells(*only_these_labels)


# %% validate_cell_sequence codecell-----------------------------------
def validate_cell_sequence(
    cell_sequence: CodeCellIterator_T
) -> CodeCellIterator_T:

    seen = set()
    for cell in cell_sequence:
        if cell.code:
            seen.add(cell.label)
        for dependency in cell.dependencies:
            if dependency not in seen:
                yield cell


# %% collection_manager codecell_iterator_t codecell_collection_t codecell_visitor_t
class CollectionManager(typing.NamedTuple):
    update: typing.Callable[[str, str, list[str]], CodeCellIterator_T]
    travel: typing.Callable[[CodeCellVisitor_T], CodeCellIterator_T]


# %% create_collection_manager entangle_collection collection_manager entangle_only_for
def create_collection_manager(
    initial_cells: CodeCellIterator_T = (_ for _ in ())
) -> CollectionManager:

    logger = logging.getLogger(__name__)

    cell_collection = CodeCellCollection_T()
    failed = set[Label_T]()

    cell_collection["docstring"] = CodeCell('', 'docstring', [])
    cell_collection['license'] = CodeCell('', 'license', ['docstring'])
    _default_deps = set(cell_collection.keys())

    cell_collection.update(
        {c.label: c for c in initial_cells if c.label not in cell_collection})

    def recover_failed() -> CodeCellIterator_T:
        for cell in entangle_collection(cell_collection):
            if cell.label in failed:
                if not any(validate_cell_sequence(
                        entangle_cells_for(cell_collection, cell.label))):
                    failed.remove(cell.label)
                    yield cell

    def update_collection(

            code: CodeText_T,
            label: Label_T,
            dependencies: list[Dependency_T]

    ) -> CodeCellIterator_T:

        _deps = _default_deps | set(dependencies)
        cell_collection[label] = CodeCell(code, label, list(_deps))

        failed.add(label)
        yield from recover_failed()

    def travel_collection(

            visit_sequence: CodeCellVisitor_T,
            *labels: Label_T

    ) -> CodeCellIterator_T:

        if labels:
            yield from visit_sequence(entangle_only_for(cell_collection, *labels))

        else:
            yield from visit_sequence(entangle_collection(cell_collection))

    return CollectionManager(
        update=update_collection,
        travel=travel_collection
    )


# %% os docstring------------------------------------------------------
import os

# %% errno os----------------------------------------------------------
import errno

# %% tomllib errno-----------------------------------------------------
import tomllib

# %% path_parents os---------------------------------------------------
def path_parents(path: str) -> typing.Iterable[str]:
    """Iterate over the parent directories of path."""

    head, tail = os.path.split(path)
    while tail:
        yield head
        head, tail = os.path.split(head)


# %% project_root os errno path_parents--------------------------------
def project_root(*sentinels) -> str:
    """
        Find a root directory for the current working directory 
        (a) the nearest ancestor containing any of the sentinels or 
        (b) the nearest ancestor to join the python executable path

        Throws a FileNotFoundError if neither (a) nor (b) is found

    """

    if not sentinels:
        return project_root('.git', '.venv', 'pyproject.toml')

    python_exe_path_set = set(path_parents(os.path.abspath(sys.executable)))

    def is_root(head):
        return (
            head in python_exe_path_set
            or any((os.path.exists(os.path.join(head, sentinel)) for sentinel in sentinels))
        )

    cwd = os.path.abspath(os.getcwd())
    while cwd:

        if (is_root(cwd)):
            return cwd

        cwd, tail = os.path.split(cwd)

    raise FileNotFoundError(
        errno.ENOENT,
        os.strerror(errno.ENOENT),
        cwd
    )


# %% extract_module_filepath os project_root tomllib-------------------
def extract_module_filepath(modulepath: str, libname: str = str("")) -> str:
    """
        Figures out the filepath to use for a dotted module-path in 
        combination with a libname. Uses pyproject.toml if no libname 
        is given. May bark exceptions at you.

    """

    project_path = project_root("pyproject.toml")
    module_parts = modulepath.split('.')

    if not libname:
        with open(os.path.join(project_path, "pyproject.toml"), "rb") as f:
            pyproject = tomllib.load(f)

            libname = pyproject.get('tool', {}).get('flit', {}).get('module', {}).get(
                'name', pyproject.get('project', {}).get('name', module_parts[0]))

    libpath = os.path.join(project_path, libname)
    if not os.path.isdir(libpath):
        libpath = os.path.join(project_path, "src", libname)

    assert os.path.isdir(
        libpath), f"Deduced {libpath} for modules but it was not found!"

    if libname and libname == module_parts[0]:
        module_parts.pop(0)

    return os.path.join(
        libpath,
        *module_parts
    ) + '.py'

