"""QiTangle - IPython magic to tangle (quarto) code cells into python source files"""

__version__ = "0.5.6"
__all__ = ["split_line_args", "project_root", "extract_module_filepath", "run_fixer", "load_ipython_extension"]

import os, sys, subprocess, typing
from qitangle.paths import project_root, extract_module_filepath


def split_line_args(line_args) -> typing.Iterable[str]:
    """Split line_args into a list of strings, filters out empty strings."""

    assert isinstance(line_args, str), f"Expected a string, got {type(line_args)}"
    return filter(lambda x: bool(x), line_args.split(' '))


def run_fixer(filepath: str) -> None:
    """Run autopep8 reformatter on the file at `filepath`."""

    try:
        rr = subprocess.run([
            str(sys.executable), '-m',
            'autopep8',
            '-i',
            '--ignore', 'E402', 'E714',
            filepath,
        ],
            cwd=os.path.dirname(filepath),
            check=False, capture_output=True
        )
        print(rr.stdout.decode('utf-8'))
        print(rr.stderr.decode('utf-8'))

    except Exception as err:
        print(f"Exception while reformatting {filepath}: {err}")


from qitangle.entangle import load_ipython_extension



