from __future__ import annotations

from importlib import metadata
import json
from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PACKAGE_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

import cf_basic_signal


def _find_entry_point(name: str):
    distribution = metadata.distribution("cf-basic-signal")
    for entry_point in distribution.entry_points:
        if entry_point.group != "cogniflow.steps":
            continue
        if entry_point.name == name:
            return entry_point
    raise AssertionError(f"Entry point {name!r} not found in cogniflow.steps.")


def _package_root() -> Path:
    return Path(cf_basic_signal.__file__).resolve().parent


def _distribution_version() -> str:
    try:
        return metadata.version("cf-basic-signal")
    except metadata.PackageNotFoundError:
        return cf_basic_signal.__version__


def test_distribution_metadata_matches_packaged_module() -> None:
    assert _distribution_version() == cf_basic_signal.__version__

    entry_point = _find_entry_point("cf.basic.signal")
    assert entry_point.value == "cf_basic_signal:steps.jsonld"


def test_steps_manifest_is_packaged_with_expected_step_package_identity() -> None:
    manifest_path = _package_root() / "steps.jsonld"
    assert manifest_path.is_file()

    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    graph = document.get("@graph")
    assert isinstance(graph, list)

    package_node = next(
        node
        for node in graph
        if isinstance(node, dict) and node.get("@id") == "cfbs:BasicSignalPackage"
    )
    assert package_node["cf:packageId"] == "cf.basic.signal"
    assert package_node["cf:packageVersion"] == cf_basic_signal.__version__


def test_native_plugin_artifact_is_packaged_under_manifest_bin_path() -> None:
    manifest_path = _package_root() / "steps.jsonld"
    document = json.loads(manifest_path.read_text(encoding="utf-8"))
    graph = document.get("@graph")
    assert isinstance(graph, list)

    plugin_node = next(
        node
        for node in graph
        if isinstance(node, dict) and node.get("@id") == "cfbs:BasicSignalPlugin"
    )
    plugin_dir = _package_root() / plugin_node["cf:artifactPath"]
    assert plugin_dir.is_dir()

    plugin_candidates = [
        path
        for path in plugin_dir.iterdir()
        if path.is_file()
        and path.name.startswith(plugin_node["cf:pluginName"])
        and path.suffix.lower() in {".dll", ".pyd", ".so", ".dylib"}
    ]
    assert plugin_candidates, f"No packaged plugin artifact found under {plugin_dir}"
