# cf_basic_signal certification

Certification is performed via the `cf-pipeline-cert` CLI using the operation contracts embedded in `steps.jsonld` (cf:operationContract).

## How to reproduce

```bash
set PYTHONPATH=sandcastle/cf_pipeline/cf_pipeline_cert/src;sandcastle/cf_basic_steps/cf_basic_signal/src
cf-pipeline-cert validate src/cf_basic_signal
cf-pipeline-cert certify src/cf_basic_signal --self-signed
```

This runs contract-based tests (200 random datasets per operation by default) and updates `src/cf_basic_signal/steps.jsonld` with a `cf:pluginCertificate` block on the plugin artifact node.

## Contracted operations

- `fifo_window_buffer` -> `kind: fifo_window` (ensures output window equals the tail of the input sequence with the declared window size).
- `average` -> `kind: mean` with `averageMethod=arithmetic` (checks arithmetic mean, permutation/translation/scale invariance, and matches a reference implementation).

## Result

The current certificate marks the two contracted operations as `passed`. The certificate payload is embedded under `cf:pluginCertificate` in `steps.jsonld`.
