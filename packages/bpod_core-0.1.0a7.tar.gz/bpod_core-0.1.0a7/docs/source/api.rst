API Reference
=============

.. autosummary::
   :toctree: api
   :template: custom-module-template.rst
   :recursive:

   bpod_core
