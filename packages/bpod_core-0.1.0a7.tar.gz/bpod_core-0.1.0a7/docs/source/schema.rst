JSON Schema
===========

.. jsonschema:: ../../schema/statemachine.json
   :lift_description:
   :lift_definitions:
   :auto_reference:
   :auto_target:
