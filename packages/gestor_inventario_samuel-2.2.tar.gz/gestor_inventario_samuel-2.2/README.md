# Gestor de Inventario

Un gestor de inventario creado con GTK3 y SQLite.

## Instalación

Podes instalar este paquete usando pip:

```bash
pip install .
```

## Uso

Unha vez instalado, podes executar a aplicación co comando:

```bash
xestor-inventario
```
