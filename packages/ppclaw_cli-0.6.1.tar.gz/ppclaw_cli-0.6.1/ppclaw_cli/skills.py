"""OpenClaw workspace bootstrap files for PPIO sandbox environment.

Instead of skills (which require the model to actively read them),
these files are deployed as workspace bootstrap files (AGENTS.md,
TOOLS.md) that OpenClaw injects directly into the context window
on every agent turn — making them reliably visible to any model.
"""

from .sandbox import SandboxManager
from .utils import print_info, print_success

WORKSPACE_PATH = "/home/user/.openclaw/workspace"

# ---------------------------------------------------------------------------
# AGENTS.md — Operating instructions injected into every turn.
#
# Combines the default OpenClaw AGENTS.md template with sandbox-specific
# rules that prevent the model from breaking the environment.
# ---------------------------------------------------------------------------

AGENTS_MD = """\
# AGENTS.md - Your Workspace

This folder is home. Treat it that way.

## Every Session

Before doing anything else:

1. Read `SOUL.md` — this is who you are
2. Read `USER.md` — this is who you're helping
3. Read `memory/YYYY-MM-DD.md` (today + yesterday) for recent context
4. **If in MAIN SESSION** (direct chat with your human): Also read `MEMORY.md`

Don't ask permission. Just do it.

## PPIO Agent Sandbox — Critical Rules

You are running inside a **PPIO Agent Sandbox** — a lightweight cloud
container with no init system and no process supervisor.

### Gateway Management (READ THIS CAREFULLY)

- **NEVER** use `systemctl`, `service`, or any init-system command — they do
  not exist here.
- **NEVER** use `kill`, `pkill`, or `killall` on the gateway process — there
  is no restart mechanism; the gateway will stay dead and you will lose all
  connectivity **including this Web UI session**.
- **ALWAYS** use the built-in **gateway** tool for configuration changes and
  restarts:

  | Action | Tool | What it does |
  |--------|------|--------------|
  | Partial config update | `config.patch` | Merges changes, auto-triggers hot reload or restart |
  | Full config replace | `config.apply` | Replaces entire config, auto-triggers restart |
  | Graceful restart | `restart` | Sends SIGUSR1 for in-process restart |

- The gateway supports **hot reload** for most config fields (channels, agents,
  models, skills, sessions, tools). No restart needed.
- Only `gateway.*` fields (port, bind, auth, TLS) require a restart, and
  `config.patch` / `config.apply` handle that automatically.

### Configuration

- Config file: `~/.openclaw/openclaw.json`
  (set via `OPENCLAW_CONFIG_PATH` environment variable)
- Format: **JSON5**
- **Always** use the gateway tool `config.patch` for partial updates — this
  is the safest method.
- Do **not** manually edit the config file and then try to restart the
  gateway.

### Environment Facts

| Path | Purpose |
|------|---------|
| `/home/user` | Home directory (user `user`, not root) |
| `~/.openclaw/` | OpenClaw state directory |
| `~/.openclaw/openclaw.json` | Gateway config |
| `~/.openclaw/workspace/` | Agent workspace (this directory) |

- Gateway listens on port **18789**, exposed through the PPIO public-URL
  proxy.
- Outbound internet is available (Telegram API, Discord API, npm, etc.).
- No process supervisor — if the gateway dies it will **not** auto-restart.

### What to Do If Something Goes Wrong

1. Check gateway health: `openclaw gateway health`
2. Check logs: `openclaw logs --follow`
3. Run diagnostics: `openclaw doctor`
4. If the gateway is unhealthy, use the `restart` gateway tool (SIGUSR1).
5. If the gateway is dead, there is no way to restart it from inside.
   The user must re-launch from the host CLI.

## Memory

You wake up fresh each session. These files are your continuity:

* **Daily notes:** `memory/YYYY-MM-DD.md` (create `memory/` if needed) — raw logs of what happened
* **Long-term:** `MEMORY.md` — your curated memories

Capture what matters. Decisions, context, things to remember.

### Write It Down - No "Mental Notes"

* Memory is limited — if you want to remember something, WRITE IT TO A FILE.
* "Mental notes" don't survive session restarts. Files do.
* When someone says "remember this" — update `memory/YYYY-MM-DD.md` or relevant file.

## Safety

* Don't exfiltrate private data. Ever.
* Don't run destructive commands without asking.
* When in doubt, ask.
"""

# ---------------------------------------------------------------------------
# TOOLS.md — Tool notes and channel setup guides, injected every turn.
# ---------------------------------------------------------------------------

TOOLS_MD = """\
# TOOLS.md - Tools & Channel Setup

## How to Apply Config Changes

**Always** use the `gateway` tool with `config.patch` to update config.

Example — enable Telegram:

```
config.patch raw='{ "channels": { "telegram": { "enabled": true, "botToken": "TOKEN" } } }'
```

This merges changes into existing config and triggers hot reload.
No restart needed for channel changes.

**Never** manually edit the config file and then try to restart the
gateway with `kill`, `systemctl`, or shell commands. Use `config.patch`.

---

## Telegram

### Prerequisites

1. Chat with **@BotFather** on Telegram.
2. Run `/newbot`, follow the prompts, copy the bot token.

### Minimal Config (via config.patch)

```json5
{
  channels: {
    telegram: {
      enabled: true,
      botToken: "123456:ABC-DEF",
      dmPolicy: "pairing",
    },
  },
}
```

### DM Access Control (`dmPolicy`)

| Value | Behavior |
|-------|----------|
| `"pairing"` (default) | Unknown senders receive a one-time code to approve |
| `"allowlist"` | Only numeric user IDs listed in `allowFrom` |
| `"open"` | Allow all DMs (requires `allowFrom: ["*"]`) |
| `"disabled"` | Ignore all DMs |

### Open DM Example

```json5
{
  channels: {
    telegram: {
      enabled: true,
      botToken: "TOKEN",
      dmPolicy: "open",
      allowFrom: ["*"],
    },
  },
}
```

### Group Support

```json5
{
  channels: {
    telegram: {
      groupPolicy: "open",
      groups: { "*": { requireMention: true } },
    },
  },
}
```

Specific group, open, no mention required:

```json5
{
  channels: {
    telegram: {
      groups: {
        "-1001234567890": {
          groupPolicy: "open",
          requireMention: false,
        },
      },
    },
  },
}
```

### Telegram Tips

- If `requireMention: false`, disable privacy via BotFather `/setprivacy`,
  then remove and re-add bot to group.
- Find user ID: DM the bot, check logs with `openclaw logs --follow` for
  `from.id`.
- Or call the Bot API directly:
  `curl https://api.telegram.org/bot<TOKEN>/getUpdates`
- Streaming is enabled by default (`partial` mode).
- Pairing codes expire after **1 hour**.

### Pairing Approval

When a user DMs the bot with `dmPolicy: "pairing"`, they receive a code.

1. **From the host CLI** (recommended):
   `ppclaw-cli pair approve <SANDBOX_ID> --channel telegram --code <CODE>`
2. **From the sandbox shell**:
   `openclaw pairing approve telegram <CODE>`
3. **List pending requests**:
   `openclaw pairing list telegram`

---

## Discord

### Prerequisites

1. Go to **Discord Developer Portal** → New Application.
2. **Bot** → Add Bot → copy token.
3. Enable intents: **Message Content Intent**, **Server Members Intent**.
4. **OAuth2 URL Generator**: scopes `bot` + `applications.commands`.
5. Bot permissions: View Channels, Send Messages, Read Message History,
   Embed Links, Attach Files, Add Reactions (optional).
6. Add bot to your server via the generated OAuth2 URL.

### Minimal Config

```json5
{
  channels: {
    discord: {
      enabled: true,
      token: "YOUR_BOT_TOKEN",
    },
  },
}
```

### Guild (Server) Setup

```json5
{
  channels: {
    discord: {
      groupPolicy: "allowlist",
      guilds: {
        "SERVER_ID": {
          requireMention: true,
          users: ["YOUR_USER_ID"],
        },
      },
    },
  },
}
```

### No-Mention Mode (private server)

```json5
{
  channels: {
    discord: {
      guilds: {
        "SERVER_ID": { requireMention: false },
      },
    },
  },
}
```

### Discord Tips

- Enable **Developer Mode** in Discord (Settings → Advanced) to copy IDs.
- DM the bot to trigger pairing, then approve the code.
- Use `openclaw channels status --probe` to verify permissions.

---

## Slack

```json5
{
  channels: {
    slack: {
      enabled: true,
      botToken: "xoxb-...",
      appToken: "xapp-...",
      signingSecret: "...",
    },
  },
}
```

---

## WhatsApp

```json5
{
  channels: {
    whatsapp: {
      enabled: true,
      allowFrom: ["+15555550123"],
    },
  },
}
```

Then run `openclaw channels login whatsapp` for QR code.

---

## Other Supported Channels

| Channel | Config key | Notes |
|---------|-----------|-------|
| Signal | `channels.signal` | Requires signal-cli |
| iMessage | `channels.imessage` | macOS only (BlueBubbles for remote) |
| Google Chat | `channels.googlechat` | Service account required |
| Mattermost | `channels.mattermost` | Bot token + server URL |
| MS Teams | `channels.msteams` | Azure Bot registration |
| IRC | `channels.irc` | Server + channel config |
| LINE | `channels.line` | Channel access token |
| Matrix | `channels.matrix` | Homeserver + access token |
| Nostr | `channels.nostr` | Private key |

---

## Troubleshooting

### Channel not appearing in `openclaw status`

1. Verify config: use `config.get` gateway tool.
2. Check logs: `openclaw logs --follow`.
3. Most channel changes hot-apply without restart.

### Config change not taking effect

- Use `config.patch` (auto-handles reload/restart).
- Run `openclaw doctor` for config validation errors.

### Pairing codes not working

- Codes expire after **1 hour**.
- List pending: `openclaw pairing list <channel>`
- Approve: `openclaw pairing approve <channel> <CODE>`

### Bot not responding in groups

- Telegram: check BotFather privacy mode (`/setprivacy`).
- Discord: verify intents are enabled in Developer Portal.
- Check `requireMention` setting and `groupPolicy`.
- Review logs: `openclaw logs --follow`.

### Network / API errors

- Telegram: set `channels.telegram.proxy` if behind a proxy.
- Discord: set `channels.discord.proxy` for HTTP proxy.
- DNS issues: try `channels.telegram.network.autoSelectFamily: false`.
"""


def deploy_workspace_files(manager: SandboxManager):
    """Deploy workspace bootstrap files (AGENTS.md, TOOLS.md) to the sandbox.

    These files are injected directly into the agent's context window on
    every turn, ensuring reliable visibility regardless of model type.
    Must be called before the first user message triggers bootstrapping.
    """
    manager.run_command(
        "mkdir -p {ws} && chmod 755 {ws}".format(ws=WORKSPACE_PATH),
        timeout=10,
    )

    for name, content in [("AGENTS.md", AGENTS_MD), ("TOOLS.md", TOOLS_MD)]:
        filepath = "{ws}/{name}".format(ws=WORKSPACE_PATH, name=name)
        manager.write_file(filepath, content)
        manager.run_command("chmod 644 {f}".format(f=filepath), timeout=10)

    print_success("Workspace bootstrap files deployed (AGENTS.md, TOOLS.md)")
