from __future__ import annotations

import copy
import json
from html import escape
from pathlib import Path
from string import Template
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from otto.telegram import TelegramBot
from urllib.parse import urlencode

from aiohttp import web

from otto import __version__
from otto.config import (
    CONFIG_FILE,
    OTTO_HOME,
    AgentConfig,
    BotAuthConfig,
    BotConfig,
    ChannelConfig,
    Config,
    ConfigError,
    UserConfig,
    WorkspaceConfig,
    load_config,
    save_config,
)

_MASKED_TOKEN = "********"
_LOG_LEVEL_OPTIONS = ("debug", "info", "warning", "error", "critical")
_BOOTSTRAP_OPTIONS = ("first_user", "disabled")


# === HTML Template ===

_PAGE_TEMPLATE = Template(
    """<!DOCTYPE html>
<html lang="en">
<head>
    <title>Otto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background: #0a0a0a; color: #e5e5e5;
            max-width: 640px; margin: 0 auto; padding: 16px;
        }
        h1 { font-size: 1.5rem; font-weight: 600; margin-bottom: 16px; }
        h2 { font-size: 1.1rem; font-weight: 500; margin-bottom: 12px; color: #ccc; }

        .card {
            background: #1a1a1a; border: 1px solid #222;
            border-radius: 8px; padding: 16px; margin-bottom: 16px;
        }

        .status-hero { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .status-dot {
            width: 10px; height: 10px; border-radius: 50%;
            display: inline-block; flex-shrink: 0;
        }
        .status-dot.running { background: #22c55e; box-shadow: 0 0 6px #22c55e; }
        .status-dot.stopped { background: #ef4444; box-shadow: 0 0 6px #ef4444; }
        .status-label { font-size: 1.1rem; font-weight: 500; }
        .status-meta { color: #888; font-size: 0.85rem; margin-top: 8px; }
        .status-meta span { margin-right: 16px; }
        .status-actions { margin-top: 12px; }

        label { display: block; margin-top: 12px; font-size: 0.85rem; color: #999; }
        input, select {
            width: 100%; padding: 8px 10px; margin-top: 4px;
            background: #111; border: 1px solid #333; border-radius: 4px;
            color: #e5e5e5; font-size: 0.95rem;
        }
        input:focus, select:focus { outline: none; border-color: #555; }
        select option { background: #111; color: #e5e5e5; }

        fieldset { border: none; margin: 0; padding: 0; }
        legend { font-size: 0.9rem; color: #888; margin-bottom: 4px; margin-top: 12px; }

        .btn {
            display: inline-block; padding: 8px 20px; border: none;
            border-radius: 4px; font-size: 0.9rem; cursor: pointer;
            text-decoration: none; color: #fff; margin-right: 8px;
        }
        .btn-primary { background: #2563eb; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-danger { background: #dc2626; }
        .btn-danger:hover { background: #b91c1c; }
        .btn-green { background: #16a34a; }
        .btn-green:hover { background: #15803d; }

        .success { color: #22c55e; margin-bottom: 12px; }
        .error { color: #ef4444; margin-bottom: 12px; }
        .hint { color: #666; font-size: 0.85rem; }

        .inline { display: inline-flex; align-items: center; gap: 6px; margin-top: 8px; }
        .inline input { width: auto; margin-top: 0; }
        code { background: #222; padding: 2px 6px; border-radius: 3px; font-size: 0.85rem; }

        .version { color: #444; font-size: 0.75rem; text-align: center; margin-top: 24px; }
    </style>
    <script>
        function toggleToken() {
            var f = document.getElementById("telegram_token");
            f.type = f.type === "password" ? "text" : "password";
        }
        function doAction(endpoint) {
            fetch(endpoint, {method: "POST"}).then(function() {
                window.location.reload();
            });
        }
    </script>
</head>
<body>
    <h1>Otto</h1>
    $status_message
    $status_hero
    $config_section
    $setup_section
    <p class="version">Otto v$version</p>
</body>
</html>
"""
)


# === Config Server ===


class ConfigServer:
    def __init__(
        self,
        config: Config,
        host: str = "127.0.0.1",
        port: int = 7070,
        bots: list[TelegramBot] | None = None,
    ):
        if host != "127.0.0.1":
            raise ValueError("ConfigServer only allows host=127.0.0.1 for local-only access.")
        self._config = config
        self._host = host
        self._port = port
        self._bots = bots or []
        self._app: web.Application | None = None
        self._runner: web.AppRunner | None = None
        self._site: web.BaseSite | None = None

    def _build_app(self) -> web.Application:
        app = web.Application()
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/auth/callback", self._handle_openai_callback)
        app.router.add_get("/oauth2callback", self._handle_google_callback)
        app.router.add_post("/config", self._handle_save)
        app.router.add_get("/health", self._handle_health)
        app.router.add_get("/status", self._handle_status)
        app.router.add_post("/start", self._handle_start)
        app.router.add_post("/stop", self._handle_stop)
        app.router.add_post("/setup", self._handle_setup)
        app.router.add_post("/bots/{alias}/start", self._handle_bot_start)
        app.router.add_post("/bots/{alias}/stop", self._handle_bot_stop)
        return app

    async def start(self) -> None:
        """Start the HTTP server."""
        if self._runner is not None:
            return

        self._app = self._build_app()
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, self._host, self._port)
        await self._site.start()

    async def stop(self) -> None:
        """Stop the HTTP server."""
        if self._runner is None:
            return
        await self._runner.cleanup()
        self._runner = None
        self._site = None
        self._app = None

    # === Request Handlers ===

    async def _handle_index(self, request: web.Request) -> web.Response:
        status = _clean_str(request.query.get("status"))
        message = _clean_str(request.query.get("message"))
        html = self._render_index_html(status, message)
        return web.Response(text=html, content_type="text/html")

    async def _handle_openai_callback(self, request: web.Request) -> web.Response:
        return await self._handle_oauth_callback(request, provider="openai")

    async def _handle_google_callback(self, request: web.Request) -> web.Response:
        return await self._handle_oauth_callback(request, provider="google")

    async def _handle_oauth_callback(self, request: web.Request, *, provider: str) -> web.Response:
        code = _clean_str(request.query.get("code"))
        state = _clean_str(request.query.get("state"))

        if not code or not state:
            html = _render_callback_result_html(
                success=False, message="Missing authorization code or state."
            )
            return web.Response(status=400, text=html, content_type="text/html")

        expected_state = _load_expected_state(provider)
        if expected_state and state != expected_state:
            html = _render_callback_result_html(success=False, message="State mismatch.")
            return web.Response(status=400, text=html, content_type="text/html")

        try:
            _write_auth_callback(provider=provider, code=code, state=state)
        except OSError:
            html = _render_callback_result_html(
                success=False, message="Failed to persist OAuth callback."
            )
            return web.Response(status=500, text=html, content_type="text/html")

        html = _render_callback_result_html(
            success=True, message="Authentication successful. Return to your terminal."
        )
        return web.Response(text=html, content_type="text/html")

    async def _handle_save(self, request: web.Request) -> web.StreamResponse:
        data = await request.post()
        try:
            updated = self._build_updated_config(data)
            save_config(updated, CONFIG_FILE)
            self._config = load_config(CONFIG_FILE)
        except (ConfigError, ValueError) as exc:
            raise web.HTTPFound(location=self._redirect_location("error", str(exc))) from exc

        raise web.HTTPFound(location=self._redirect_location("success", "Configuration saved."))

    async def _handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok", "version": __version__})

    async def _handle_status(self, request: web.Request) -> web.Response:
        running, pid = _daemon_status()
        model = self._config.agent.model
        provider = model.split("/", 1)[0] if "/" in model else "unknown"
        workspace_mode, workspace_root = _workspace_status(self._config)

        bot_statuses = []
        for bot in self._bots:
            bot_running = (
                bot._app is not None and bot._app.updater is not None and bot._app.updater.running
            )
            bot_statuses.append(
                {
                    "alias": bot.alias,
                    "running": bot_running,
                }
            )

        return web.json_response(
            {
                "running": running,
                "pid": pid,
                "model": model,
                "provider": provider,
                "workspace_mode": workspace_mode,
                "workspace_root": str(workspace_root),
                "bots": bot_statuses,
            }
        )

    async def _handle_bot_start(self, request: web.Request) -> web.Response:
        alias = request.match_info["alias"]
        bot = next((b for b in self._bots if b.alias == alias), None)
        if not bot:
            return web.json_response({"error": "Bot not found"}, status=404)

        if bot._app is None or bot._app.updater is None or not bot._app.updater.running:
            await bot.start()
            return web.json_response({"status": "started", "bot": alias})
        return web.json_response({"status": "already running", "bot": alias})

    async def _handle_bot_stop(self, request: web.Request) -> web.Response:
        alias = request.match_info["alias"]
        bot = next((b for b in self._bots if b.alias == alias), None)
        if not bot:
            return web.json_response({"error": "Bot not found"}, status=404)

        if bot._app is not None and bot._app.updater is not None and bot._app.updater.running:
            await bot.stop()
            return web.json_response({"status": "stopped", "bot": alias})
        return web.json_response({"status": "not running", "bot": alias})

    async def _handle_start(self, request: web.Request) -> web.StreamResponse:
        try:
            import otto.daemon as daemon_mod

            if not daemon_mod.is_running():
                from otto.cli import _spawn_background

                _spawn_background()
        except Exception as exc:
            raise web.HTTPFound(
                location=self._redirect_location("error", f"Start failed: {exc}")
            ) from exc
        raise web.HTTPFound(location=self._redirect_location("success", "Otto started."))

    async def _handle_stop(self, request: web.Request) -> web.StreamResponse:
        try:
            import otto.daemon as daemon_mod

            if daemon_mod.is_running():
                daemon_mod.stop_daemon()
        except Exception as exc:
            raise web.HTTPFound(
                location=self._redirect_location("error", f"Stop failed: {exc}")
            ) from exc
        raise web.HTTPFound(location=self._redirect_location("success", "Otto stopped."))

    async def _handle_setup(self, request: web.Request) -> web.StreamResponse:
        from otto.cli import (
            DEFAULT_MODEL,
            _provider_env_var,
            _provider_from_model,
        )
        from otto.config import ensure_dirs

        data = await request.post()
        model = _clean_str(data.get("model")) or DEFAULT_MODEL
        telegram_token = _clean_str(data.get("telegram_token"))
        owner_name = _clean_str(data.get("owner_name")) or "owner"
        owner_tid_raw = _clean_str(data.get("owner_telegram_id"))

        if not telegram_token:
            raise web.HTTPFound(
                location=self._redirect_location("error", "Telegram token is required.")
            )

        try:
            provider = _provider_from_model(model)
        except SystemExit:
            raise web.HTTPFound(
                location=self._redirect_location(
                    "error", "Model must be in 'provider/name' format."
                )
            )

        owner_tid: int | None = None
        if owner_tid_raw:
            try:
                owner_tid = int(owner_tid_raw)
            except ValueError:
                raise web.HTTPFound(
                    location=self._redirect_location("error", "Telegram user ID must be a number.")
                )

        env_var = _provider_env_var(provider)
        secrets: dict[str, str] = {"TELEGRAM_BOT_TOKEN": telegram_token}
        if env_var:
            api_key = _clean_str(data.get("api_key"))
            if api_key:
                secrets[env_var] = api_key

        try:
            ensure_dirs()
            env_file = OTTO_HOME / ".env"
            env_lines = [f"{k}={v}" for k, v in secrets.items() if v]
            env_file.write_text("\n".join(env_lines) + "\n", encoding="utf-8")
            env_file.chmod(0o600)

            users = [UserConfig(name=owner_name, telegram_id=owner_tid)]
            bots = [
                BotConfig(
                    name="default",
                    model=None,
                    auth=BotAuthConfig(
                        owner=owner_name,
                        allowed_users=[owner_name],
                        bootstrap="first_user",
                    ),
                    workspace=WorkspaceConfig(root=Path("~").expanduser()),
                    channels=[
                        ChannelConfig(type="telegram", token="${TELEGRAM_BOT_TOKEN}"),
                    ],
                )
            ]
            config = Config(
                agent=AgentConfig(model=model),
                log_level="info",
                env_file=".env",
                users=users,
                bots=bots,
            )
            save_config(config, CONFIG_FILE)
            CONFIG_FILE.chmod(0o644)
            self._config = load_config(CONFIG_FILE)
        except Exception as exc:
            raise web.HTTPFound(
                location=self._redirect_location("error", f"Setup failed: {exc}")
            ) from exc

        raise web.HTTPFound(location=self._redirect_location("success", "Setup complete!"))

    # === Rendering ===

    def _render_index_html(self, status: str, message: str) -> str:
        status_message = _render_status_message(status, message)
        has_config = CONFIG_FILE.exists()
        running, pid = _daemon_status()

        model = self._config.agent.model
        provider = model.split("/", 1)[0] if "/" in model else "unknown"
        workspace_mode, workspace_root = _workspace_status(self._config)

        status_hero = self._render_status_hero(
            running, pid, model, provider, workspace_mode, workspace_root
        )

        bot_section = ""
        if running and self._bots:
            bot_section = self._render_bots_section()

        if has_config:
            config_section = self._render_config_form()
            setup_section = ""
        else:
            config_section = ""
            setup_section = _render_setup_wizard()

        return _PAGE_TEMPLATE.substitute(
            status_message=status_message,
            status_hero=status_hero,
            config_section=f"{bot_section}{config_section}",
            setup_section=setup_section,
            version=escape(__version__, quote=True),
        )

    def _render_bots_section(self) -> str:
        rows = []
        for bot in self._bots:
            bot_running = (
                bot._app is not None and bot._app.updater is not None and bot._app.updater.running
            )
            dot_class = "running" if bot_running else "stopped"
            action_btn = ""
            if bot_running:
                action_btn = f'<button class="btn btn-danger btn-sm" type="button" onclick="doAction(\'/bots/{bot.alias}/stop\')">Stop</button>'
            else:
                action_btn = f'<button class="btn btn-green btn-sm" type="button" onclick="doAction(\'/bots/{bot.alias}/start\')">Start</button>'

            rows.append(
                f"""<div class="bot-row" style="display:flex; align-items:center; justify-content:space-between; padding: 8px 0; border-bottom: 1px solid #222;">
                <div style="display:flex; align-items:center; gap:8px">
                    <span class="status-dot {dot_class}" style="width:8px; height:8px"></span>
                    <span>{escape(bot.alias)}</span>
                </div>
                <div>{action_btn}</div>
            </div>"""
            )

        return f"""<div class="card">
        <h2>Bots</h2>
        {"".join(rows)}
    </div>"""

    def _render_status_hero(
        self,
        running: bool,
        pid: int | None,
        model: str,
        provider: str,
        workspace_mode: str,
        workspace_root: Path,
    ) -> str:
        dot_class = "running" if running else "stopped"
        label = "Running" if running else "Stopped"
        pid_text = f" (PID {pid})" if running and pid else ""

        if running:
            action_btn = (
                '<button class="btn btn-danger" type="button" '
                "onclick=\"doAction('/stop')\">Stop</button>"
            )
        else:
            action_btn = (
                '<button class="btn btn-green" type="button" '
                "onclick=\"doAction('/start')\">Start</button>"
            )

        return f"""<div class="card">
        <div class="status-hero">
            <span class="status-dot {dot_class}"></span>
            <span class="status-label">{escape(label)}{escape(pid_text)}</span>
        </div>
        <div class="status-meta">
            <span>Model: {escape(model, quote=True)}</span>
            <span>Provider: {escape(provider, quote=True)}</span>
            <span>Workspace mode: {escape(workspace_mode, quote=True)}</span>
            <span>Workspace root: {escape(str(workspace_root), quote=True)}</span>
        </div>
        <div class="status-actions">{action_btn}</div>
    </div>"""

    def _render_config_form(self) -> str:
        if self._config.bots:
            return self._render_config_form_new()
        return self._render_config_form_legacy()

    def _render_config_form_legacy(self) -> str:
        tg = self._config.telegram
        owner_id = "" if tg is None or tg.owner_id is None else str(tg.owner_id)
        allowed_users = "" if tg is None else ", ".join(str(uid) for uid in tg.allowed_users)
        tg_token = tg.token if tg else ""
        tg_bootstrap = tg.bootstrap if tg else "first_user"
        workdir = str(self._config.workdir) if self._config.workdir else "~"

        return f"""<div class="card">
        <h2>Configuration</h2>
        <form method="post" action="/config">
            <input type="hidden" name="_schema" value="legacy">
            <fieldset>
                <legend>General</legend>
                <label for="log_level">Log level</label>
                <select id="log_level" name="log_level">{_render_options(_LOG_LEVEL_OPTIONS, self._config.log_level)}</select>
                <label for="workdir">Working directory</label>
                <input id="workdir" name="workdir" type="text" value="{escape(workdir, quote=True)}" required>
            </fieldset>
            <fieldset>
                <legend>Telegram</legend>
                <label for="telegram_token">Token</label>
                <input id="telegram_token" name="telegram_token" type="password" value="{_MASKED_TOKEN if tg_token else ""}">
                <label class="inline">
                    <input type="checkbox" onclick="toggleToken()"> Reveal
                </label>
                <label for="owner_id">Owner ID</label>
                <input id="owner_id" name="owner_id" type="text" value="{escape(owner_id, quote=True)}">
                <label for="allowed_users">Allowed users</label>
                <input id="allowed_users" name="allowed_users" type="text" value="{escape(allowed_users, quote=True)}">
                <label for="bootstrap">Bootstrap</label>
                <select id="bootstrap" name="bootstrap">{_render_options(_BOOTSTRAP_OPTIONS, tg_bootstrap)}</select>
            </fieldset>
            <fieldset>
                <legend>Agent</legend>
                <label for="model">Model</label>
                <input id="model" name="model" type="text" value="{escape(self._config.agent.model, quote=True)}" required>
            </fieldset>
            <button class="btn btn-primary" type="submit" style="margin-top:16px">Save</button>
        </form>
    </div>"""

    def _render_config_form_new(self) -> str:
        users_html = ""
        for idx, user in enumerate(self._config.users):
            tid = "" if user.telegram_id is None else str(user.telegram_id)
            users_html += f"""
                <div style="border-bottom:1px solid #222; padding:8px 0;">
                    <label for="user_{idx}_name">Name</label>
                    <input id="user_{idx}_name" name="user_{idx}_name" type="text" value="{escape(user.name, quote=True)}" required>
                    <label for="user_{idx}_telegram_id">Telegram user ID</label>
                    <input id="user_{idx}_telegram_id" name="user_{idx}_telegram_id" type="text" value="{escape(tid, quote=True)}">
                </div>"""

        bots_html = ""
        for idx, bot in enumerate(self._config.bots):
            bot_model = bot.model or ""
            owner = bot.auth.owner
            allowed = ", ".join(bot.auth.allowed_users)
            bootstrap = bot.auth.bootstrap

            channels_html = ""
            for ch_idx, ch in enumerate(bot.channels):
                ch_token_display = _MASKED_TOKEN if ch.token else ""
                channels_html += f"""
                    <div style="margin-left:12px; border-left:2px solid #333; padding-left:12px; margin-top:8px;">
                        <label for="bot_{idx}_ch_{ch_idx}_type">Channel type</label>
                        <input id="bot_{idx}_ch_{ch_idx}_type" name="bot_{idx}_ch_{ch_idx}_type" type="text" value="{escape(ch.type, quote=True)}" readonly>
                        <label for="bot_{idx}_ch_{ch_idx}_token">Token</label>
                        <input id="bot_{idx}_ch_{ch_idx}_token" name="bot_{idx}_ch_{ch_idx}_token" type="password" value="{escape(ch_token_display, quote=True)}">
                    </div>"""

            bots_html += f"""
                <div style="border-bottom:1px solid #222; padding:8px 0;">
                    <label for="bot_{idx}_name">Bot name</label>
                    <input id="bot_{idx}_name" name="bot_{idx}_name" type="text" value="{escape(bot.name, quote=True)}" required>
                    <label for="bot_{idx}_model">Model override</label>
                    <input id="bot_{idx}_model" name="bot_{idx}_model" type="text" value="{escape(bot_model, quote=True)}" placeholder="(uses global model)">
                    <label for="bot_{idx}_owner">Auth owner</label>
                    <input id="bot_{idx}_owner" name="bot_{idx}_owner" type="text" value="{escape(owner, quote=True)}" required>
                    <label for="bot_{idx}_allowed">Allowed users</label>
                    <input id="bot_{idx}_allowed" name="bot_{idx}_allowed" type="text" value="{escape(allowed, quote=True)}">
                    <label for="bot_{idx}_bootstrap">Bootstrap</label>
                    <select id="bot_{idx}_bootstrap" name="bot_{idx}_bootstrap">{_render_options(_BOOTSTRAP_OPTIONS, bootstrap)}</select>
                    {channels_html}
                </div>"""

        return f"""<div class="card">
        <h2>Configuration</h2>
        <form method="post" action="/config">
            <input type="hidden" name="_schema" value="new">
            <input type="hidden" name="_user_count" value="{len(self._config.users)}">
            <input type="hidden" name="_bot_count" value="{len(self._config.bots)}">
            <fieldset>
                <legend>General</legend>
                <label for="log_level">Log level</label>
                <select id="log_level" name="log_level">{_render_options(_LOG_LEVEL_OPTIONS, self._config.log_level)}</select>
            </fieldset>
            <fieldset>
                <legend>Agent</legend>
                <label for="model">Model</label>
                <input id="model" name="model" type="text" value="{escape(self._config.agent.model, quote=True)}" required>
            </fieldset>
            <fieldset>
                <legend>Users</legend>
                {users_html}
            </fieldset>
            <fieldset>
                <legend>Bots</legend>
                {bots_html}
            </fieldset>
            <button class="btn btn-primary" type="submit" style="margin-top:16px">Save</button>
        </form>
    </div>"""

    def _build_updated_config(self, form_data: dict[str, Any]) -> Config:
        schema = _clean_str(form_data.get("_schema"))
        if schema == "new":
            return self._build_updated_config_new(form_data)
        return self._build_updated_config_legacy(form_data)

    def _build_updated_config_legacy(self, form_data: dict[str, Any]) -> Config:
        from otto.config import TelegramConfig

        log_level = _clean_str(form_data.get("log_level")) or self._config.log_level
        workdir_raw = _clean_str(form_data.get("workdir")) or str(self._config.workdir)
        model = _clean_str(form_data.get("model")) or self._config.agent.model

        tg = self._config.telegram
        bootstrap = _clean_str(form_data.get("bootstrap")) or (tg.bootstrap if tg else "first_user")
        if bootstrap not in _BOOTSTRAP_OPTIONS:
            raise ValueError("bootstrap must be either 'first_user' or 'disabled'.")

        owner_raw = _clean_str(form_data.get("owner_id"))
        owner_id = _parse_optional_int(owner_raw, field_name="owner_id")
        allowed_users = _parse_allowed_users(_clean_str(form_data.get("allowed_users")))

        token_input = _clean_str(form_data.get("telegram_token"))
        token_unchanged = token_input in {"", _MASKED_TOKEN}
        current_token = tg.token if tg else ""
        token_for_runtime = current_token if token_unchanged else token_input

        raw_values = self._copy_raw_values()
        if not isinstance(raw_values.get("telegram"), dict):
            raw_values["telegram"] = {}
        current_raw_token = raw_values["telegram"].get("token", current_token)
        token_for_file = current_raw_token if token_unchanged else token_input

        raw_values["log_level"] = log_level
        raw_values["workdir"] = workdir_raw
        raw_values["telegram"]["token"] = token_for_file
        raw_values["telegram"]["owner_id"] = owner_id
        raw_values["telegram"]["allowed_users"] = allowed_users
        raw_values["telegram"]["bootstrap"] = bootstrap
        raw_values["agent"]["model"] = model
        if self._config.env_file is not None:
            raw_values["env_file"] = self._config.env_file
        else:
            raw_values.pop("env_file", None)

        updated = Config(
            telegram=TelegramConfig(
                token=token_for_runtime,
                owner_id=owner_id,
                allowed_users=allowed_users,
                bootstrap=bootstrap,
            ),
            agent=AgentConfig(model=model),
            log_level=log_level,
            workdir=Path(workdir_raw).expanduser(),
            env_file=self._config.env_file,
        )
        object.__setattr__(updated, "_raw_values", raw_values)
        return updated

    def _build_updated_config_new(self, form_data: dict[str, Any]) -> Config:
        log_level = _clean_str(form_data.get("log_level")) or self._config.log_level
        model = _clean_str(form_data.get("model")) or self._config.agent.model

        user_count = int(_clean_str(form_data.get("_user_count")) or "0")
        bot_count = int(_clean_str(form_data.get("_bot_count")) or "0")

        users: list[UserConfig] = []
        for idx in range(user_count):
            name = _clean_str(form_data.get(f"user_{idx}_name"))
            if not name:
                continue
            tid_raw = _clean_str(form_data.get(f"user_{idx}_telegram_id"))
            tid = _parse_optional_int(tid_raw, field_name=f"user_{idx}_telegram_id")
            users.append(UserConfig(name=name, telegram_id=tid))

        bots: list[BotConfig] = []
        for idx in range(bot_count):
            bot_name = _clean_str(form_data.get(f"bot_{idx}_name"))
            if not bot_name:
                continue
            bot_model = _clean_str(form_data.get(f"bot_{idx}_model")) or None
            owner = _clean_str(form_data.get(f"bot_{idx}_owner"))
            allowed_raw = _clean_str(form_data.get(f"bot_{idx}_allowed"))
            allowed = (
                [s.strip() for s in allowed_raw.split(",") if s.strip()] if allowed_raw else []
            )
            bootstrap = _clean_str(form_data.get(f"bot_{idx}_bootstrap")) or "disabled"
            if bootstrap not in _BOOTSTRAP_OPTIONS:
                raise ValueError("bootstrap must be either 'first_user' or 'disabled'.")

            # Preserve existing bot workspace
            old_bot = self._config.bots[idx] if idx < len(self._config.bots) else None
            workspace = (
                old_bot.workspace if old_bot else WorkspaceConfig(root=Path("~").expanduser())
            )

            # Rebuild channels, preserving raw token values (e.g. ${VAR} refs)
            channels: list[ChannelConfig] = []
            raw_bots = getattr(self._config, "_raw_values", {})
            raw_bots_list = raw_bots.get("bots", []) if isinstance(raw_bots, dict) else []
            raw_bot_entry = (
                raw_bots_list[idx]
                if isinstance(raw_bots_list, list)
                and idx < len(raw_bots_list)
                and isinstance(raw_bots_list[idx], dict)
                else {}
            )
            raw_channels = raw_bot_entry.get("channels", [])
            if not isinstance(raw_channels, list):
                raw_channels = []
            if old_bot:
                for ch_idx, old_ch in enumerate(old_bot.channels):
                    ch_token_input = _clean_str(form_data.get(f"bot_{idx}_ch_{ch_idx}_token"))
                    ch_token_unchanged = ch_token_input in {"", _MASKED_TOKEN}
                    if ch_token_unchanged:
                        # Prefer raw value (preserves ${VAR} refs), fall back to runtime
                        raw_ch = (
                            raw_channels[ch_idx]
                            if ch_idx < len(raw_channels) and isinstance(raw_channels[ch_idx], dict)
                            else {}
                        )
                        ch_token = raw_ch.get("token", old_ch.token)
                    else:
                        ch_token = ch_token_input
                    channels.append(
                        ChannelConfig(
                            type=old_ch.type,
                            token=ch_token,
                            enabled=old_ch.enabled,
                            port=old_ch.port,
                        )
                    )
            else:
                channels = []

            bots.append(
                BotConfig(
                    name=bot_name,
                    model=bot_model,
                    auth=BotAuthConfig(
                        owner=owner,
                        allowed_users=allowed,
                        bootstrap=bootstrap,
                    ),
                    workspace=workspace,
                    channels=channels,
                )
            )

        raw_values = self._copy_raw_values()
        raw_values["log_level"] = log_level
        raw_values["agent"]["model"] = model
        # Clear old users/bots from raw_values so save_config uses the
        # updated Config dataclass values instead of stale raw data.
        raw_values.pop("users", None)
        raw_values.pop("bots", None)
        if self._config.env_file is not None:
            raw_values["env_file"] = self._config.env_file
        else:
            raw_values.pop("env_file", None)

        updated = Config(
            agent=AgentConfig(model=model),
            log_level=log_level,
            env_file=self._config.env_file,
            users=users,
            bots=bots,
        )
        object.__setattr__(updated, "_raw_values", raw_values)
        return updated

    def _copy_raw_values(self) -> dict[str, Any]:
        existing = getattr(self._config, "_raw_values", {})
        values = copy.deepcopy(existing) if isinstance(existing, dict) else {}
        if not isinstance(values.get("agent"), dict):
            values["agent"] = {}
        return values

    @staticmethod
    def _redirect_location(status: str, message: str) -> str:
        return "/?" + urlencode({"status": status, "message": message})


# === Helpers ===


def _clean_str(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _normalize_workspace_mode(value: Any) -> str:
    if isinstance(value, str):
        mode = value.strip().lower()
        if mode in {"default", "strict"}:
            return mode
    return "default"


def _coerce_path(value: Any) -> Path | None:
    if isinstance(value, Path):
        path = value.expanduser()
    elif isinstance(value, str) and value.strip():
        path = Path(value.strip()).expanduser()
    else:
        return None
    if not path.is_absolute():
        path = Path.cwd() / path
    return path


def _workspace_status(config: Any) -> tuple[str, Path]:
    workspace = getattr(config, "workspace", None)
    mode = _normalize_workspace_mode(getattr(workspace, "mode", "default"))

    fallback_root = _coerce_path(getattr(config, "workdir", None)) or Path.cwd()
    workspace_root = _coerce_path(getattr(workspace, "root", None)) or fallback_root
    return mode, workspace_root


def _parse_optional_int(value: str, *, field_name: str) -> int | None:
    if value == "":
        return None
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{field_name} must be an integer.") from exc


def _parse_allowed_users(value: str) -> list[int]:
    if value == "":
        return []
    parsed: list[int] = []
    for item in value.split(","):
        text = item.strip()
        if text == "":
            continue
        try:
            parsed.append(int(text))
        except ValueError as exc:
            raise ValueError("allowed_users must be a comma-separated list of integers.") from exc
    return parsed


def _render_options(options: tuple[str, ...], selected: str) -> str:
    rendered: list[str] = []
    if selected and selected not in options:
        escaped = escape(selected, quote=True)
        rendered.append(f'<option value="{escaped}" selected>{escape(selected)}</option>')
    for option in options:
        option_escaped = escape(option, quote=True)
        is_selected = " selected" if option == selected else ""
        rendered.append(f'<option value="{option_escaped}"{is_selected}>{escape(option)}</option>')
    return "".join(rendered)


def _render_status_message(status: str, message: str) -> str:
    if not message:
        return ""
    if status == "success":
        class_name = "success"
    elif status == "error":
        class_name = "error"
    else:
        class_name = "hint"
    return f'<p class="{class_name}">{escape(message)}</p>'


def _auth_callback_file(provider: str) -> Path:
    return OTTO_HOME / "config" / f"auth_callback_{provider}.json"


def _load_expected_state(provider: str) -> str | None:
    callback_file = _auth_callback_file(provider)
    if not callback_file.exists():
        return None

    try:
        payload = json.loads(callback_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    if not isinstance(payload, dict):
        return None

    expected_state = payload.get("expected_state")
    if isinstance(expected_state, str) and expected_state.strip():
        return expected_state.strip()

    # Backwards-compatible fallback: a pre-seeded callback file may store "state"
    # before "code" is known.
    if "code" in payload:
        return None

    state = payload.get("state")
    if isinstance(state, str) and state.strip():
        return state.strip()
    return None


def _write_auth_callback(*, provider: str, code: str, state: str) -> None:
    callback_file = _auth_callback_file(provider)
    callback_file.parent.mkdir(parents=True, exist_ok=True)
    callback_file.write_text(
        json.dumps({"code": code, "state": state}),
        encoding="utf-8",
    )


def _render_callback_result_html(*, success: bool, message: str) -> str:
    symbol = "&#10003;" if success else "&#10005;"
    symbol_class = "symbol success" if success else "symbol error"
    status_line = "Authentication successful" if success else "Authentication failed"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Otto Authentication</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: system-ui, -apple-system, sans-serif;
            background: #0a0a0a;
            color: #e5e5e5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }}
        .card {{
            width: 100%;
            max-width: 520px;
            text-align: center;
            background: #1a1a1a;
            border: 1px solid #222;
            border-radius: 10px;
            padding: 32px 24px;
        }}
        .symbol {{
            font-size: 44px;
            line-height: 1;
            margin-bottom: 12px;
        }}
        .symbol.success {{ color: #22c55e; }}
        .symbol.error {{ color: #ef4444; }}
        .status {{ color: #a3a3a3; margin-bottom: 8px; }}
        .message {{ font-size: 1.05rem; }}
    </style>
</head>
<body>
    <div class="card">
        <div class="{symbol_class}">{symbol}</div>
        <p class="status">{escape(status_line)}</p>
        <p class="message">{escape(message)}</p>
    </div>
</body>
</html>"""


def _daemon_status() -> tuple[bool, int | None]:
    """Return (running, pid) using lazy daemon import."""
    try:
        import otto.daemon as daemon_mod

        running = daemon_mod.is_running()
        if running:
            pid_path = daemon_mod._pid_file()
            try:
                pid = int(pid_path.read_text(encoding="utf-8").strip())
            except (ValueError, FileNotFoundError):
                pid = None
            return True, pid
        return False, None
    except Exception:
        return False, None


def _render_setup_wizard() -> str:
    from otto.cli import DEFAULT_MODEL

    return f"""<div class="card">
        <h2>Setup</h2>
        <p class="hint" style="margin-bottom:12px">No configuration found. Set up Otto to get started.</p>
        <form method="post" action="/setup">
            <label for="setup_model">Model</label>
            <input id="setup_model" name="model" type="text" value="{escape(DEFAULT_MODEL, quote=True)}">
            <label for="setup_telegram_token">Telegram bot token</label>
            <input id="setup_telegram_token" name="telegram_token" type="text" placeholder="123456:ABC-DEF..." required>
            <label for="setup_owner_name">Owner name <span class="hint">(optional)</span></label>
            <input id="setup_owner_name" name="owner_name" type="text" placeholder="owner" value="owner">
            <label for="setup_owner_telegram_id">Telegram user ID <span class="hint">(optional)</span></label>
            <input id="setup_owner_telegram_id" name="owner_telegram_id" type="text" placeholder="Your Telegram user ID">
            <label for="setup_api_key">Provider API key <span class="hint">(optional)</span></label>
            <input id="setup_api_key" name="api_key" type="text" placeholder="sk-...">
            <button class="btn btn-primary" type="submit" style="margin-top:16px">Set up Otto</button>
        </form>
    </div>"""
