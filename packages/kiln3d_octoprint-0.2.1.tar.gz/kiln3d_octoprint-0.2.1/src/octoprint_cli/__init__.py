"""OctoPrint CLI - Agent-friendly command-line interface for OctoPrint."""

__version__ = "0.1.0"
