const s=["home","search","artists","albums","tracks","playlists","audiobooks","podcasts","radios","browse","settings"];export{s as D};
