#!/usr/bin/env python3
"""
Parsl-based cluster parallelization for RNAhybrid shard runs.
- Fully Python (scatter/gather)
- Supports Slurm (and can be adapted to PBS/LSF/SGE)
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple

import parsl
from parsl import python_app, bash_app
from parsl.config import Config
from parsl.executors import HighThroughputExecutor
from parsl.providers import SlurmProvider
from parsl.launchers import SrunLauncher
from parsl.addresses import address_by_hostname


def parsl_slurm_config(
    *,
    partition: str,
    account: Optional[str],
    walltime: str,
    nodes_per_block: int,
    tasks_per_node: int,
    cpus_per_task: int,
    mem_per_node_gb: int,
    max_blocks: int,
    worker_init: str = "",
) -> Config:
    """
    Create a Parsl config that submits blocks (jobs) to Slurm.
    Each worker will run tasks; tasks are 1 shard -> 1 RNAhybrid command.
    """
    sched_opts = []
    if account:
        sched_opts.append(f"#SBATCH -A {account}")
    sched_opts.append(f"#SBATCH -p {partition}")
    sched_opts.append(f"#SBATCH --nodes={nodes_per_block}")
    sched_opts.append(f"#SBATCH --ntasks-per-node={tasks_per_node}")
    sched_opts.append(f"#SBATCH --cpus-per-task={cpus_per_task}")
    sched_opts.append(f"#SBATCH --mem={mem_per_node_gb}G")
    sched_opts.append(f"#SBATCH -t {walltime}")

    return Config(
        executors=[
            HighThroughputExecutor(
                label="htex_slurm",
                address=address_by_hostname(),
                max_workers=tasks_per_node,  # per node
                provider=SlurmProvider(
                    launcher=SrunLauncher(),
                    partition=partition,
                    account=account,
                    walltime=walltime,
                    nodes_per_block=nodes_per_block,
                    init_blocks=1,
                    min_blocks=0,
                    max_blocks=max_blocks,
                    scheduler_options="\n".join(sched_opts),
                    worker_init=worker_init,
                ),
            )
        ],
        strategy=None,
    )


@bash_app
def run_rnahybrid_shard(
    shard_fa: str,
    sirnas_fa: str,
    out_txt: str,
    rnahybrid_bin: str = "RNAhybrid",
    rnahybrid_args: str = "",
    stdout: str = parsl.AUTO_LOGNAME,
    stderr: str = parsl.AUTO_LOGNAME,
):
    """
    Run RNAhybrid for a single shard fasta. Writes output file.
    """
    # NOTE: adjust flags to exactly match how you already call RNAhybrid
    # Example uses: RNAhybrid -t <targets> -q <sirnas>
    cmd = (
        f"set -euo pipefail; "
        f"{rnahybrid_bin} {rnahybrid_args} -t {shard_fa} -q {sirnas_fa} > {out_txt}"
    )
    return cmd


def run_cluster_rnahybrid(
    *,
    shard_fastas: List[str],
    sirnas_fa: str,
    out_dir: str,
    rnahybrid_args: str,
    slurm_partition: str,
    slurm_account: Optional[str],
    walltime: str = "02:00:00",
    nodes_per_block: int = 1,
    tasks_per_node: int = 32,
    cpus_per_task: int = 1,
    mem_per_node_gb: int = 8,
    max_blocks: int = 10,
    worker_init: str = "",
) -> List[str]:
    """
    Submit all shards to the cluster via Parsl, wait, and return list of output paths.
    """
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)

    cfg = parsl_slurm_config(
        partition=slurm_partition,
        account=slurm_account,
        walltime=walltime,
        nodes_per_block=nodes_per_block,
        tasks_per_node=tasks_per_node,
        cpus_per_task=cpus_per_task,
        mem_per_node_gb=mem_per_node_gb,
        max_blocks=max_blocks,
        worker_init=worker_init,
    )

    parsl.load(cfg)

    futures = []
    out_paths = []
    for i, shard in enumerate(shard_fastas, 1):
        out_txt = str(out_dir_p / f"out_{i}.txt")
        out_paths.append(out_txt)
        futures.append(
            run_rnahybrid_shard(
                shard_fa=shard,
                sirnas_fa=sirnas_fa,
                out_txt=out_txt,
                rnahybrid_args=rnahybrid_args,
            )
        )

    # Wait for completion (raises if any task failed)
    for fut in futures:
        fut.result()

    parsl.dfk().cleanup()
    parsl.clear()

    return out_paths