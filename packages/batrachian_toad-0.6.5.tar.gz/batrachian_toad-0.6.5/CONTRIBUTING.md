# Guide to Contributing

Thank you for your interesting in improving Toad!

If you are thinking of fixing a bug or contributing a feature, please open a Discussion first.
You will be asked for a link to the discussion when you contribute a PR.

TODO: add technical help
