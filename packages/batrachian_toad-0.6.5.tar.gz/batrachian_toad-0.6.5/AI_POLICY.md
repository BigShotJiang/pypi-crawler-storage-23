# AI Policy

This project accepts AI PRs (it would by hypocritical not to), as long as the following guidelines are met:

- The Pull Request MUST fill in the repository's pull request template.
- The Pull Request MUST link to a issue or discussion where a solution has been approved by a maintainer (@willmcgugan).
