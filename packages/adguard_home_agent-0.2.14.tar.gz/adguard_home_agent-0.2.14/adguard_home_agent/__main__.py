#!/usr/bin/python
# coding: utf-8
from adguard_home_agent.adguard_agent import agent_server

if __name__ == "__main__":
    agent_server()
