"""
CVEFinder CLI - Official command-line interface for CVEFinder.io
"""

__version__ = "1.0.0"
__author__ = "CVEFinder.io"
__license__ = "MIT"
