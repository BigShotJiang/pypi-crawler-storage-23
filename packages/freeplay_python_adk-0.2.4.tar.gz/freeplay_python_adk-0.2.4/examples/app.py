from freeplay_python_adk.freeplay_observability_plugin import (
    FreeplayObservabilityPlugin,
)
from google.adk.apps import App

from examples.research_agent import root_agent

app = App(
    name="examples",
    root_agent=root_agent,
    plugins=[FreeplayObservabilityPlugin()],
)
