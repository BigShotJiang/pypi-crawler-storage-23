import pdoc

pdoc.pdoc(
    "src/lactationcurve",
    output_directory="docs",
)
