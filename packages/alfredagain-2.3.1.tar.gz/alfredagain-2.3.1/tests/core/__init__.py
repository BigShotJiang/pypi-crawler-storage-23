"""Core tests — exercise alfred package with StubDomainConfig (no kitchen dependency)."""
