from .qrfast import *

__doc__ = qrfast.__doc__
if hasattr(qrfast, "__all__"):
    __all__ = qrfast.__all__