"""
UnsupportedConversion exception.
"""

from typing import Optional, Any, Dict
import ctypes
import traceback

from .base_exception import NutrientException

class UnsupportedConversion(NutrientException):
    """
    Exception raised for UnsupportedConversion errors.
    
    This exception is raised when specific error conditions occur
    during SDK operations related to UnsupportedConversion.
    
    Attributes:
        error_code: Numeric error code from the native SDK
        error_source: Source location where the error occurred
        stack_trace: Python stack trace at the point of error
    
    Example:
        >>> try:
        ...     # Some SDK operation
        ...     pass
        ... except UnsupportedConversion as e:
        ...     print(f"Error: {e}")
        ...     print(f"Error code: {e.error_code}")
    """
    
    def __init__(
        self,
        message: str,
        error_code: Optional[int] = None,
        error_source: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize UnsupportedConversion.
        
        Args:
            message: The error message
            error_code: Optional numeric error code
            error_source: Optional source location of the error
            **kwargs: Additional keyword arguments passed to base class
        """
        super().__init__(message, error_code=error_code, error_source=error_source, **kwargs)
        self._stack_trace = traceback.format_stack()
    
    @property
    def stack_trace(self) -> str:
        """
        Get the Python stack trace at the point where the exception was created.
        
        Returns:
            The formatted stack trace as a string
        """
        return ''.join(self._stack_trace)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the exception to a dictionary representation.
        
        Returns:
            Dictionary containing all exception attributes
        """
        return super().to_dict()
    
    def __str__(self) -> str:
        """String representation of the exception."""
        return super().__str__()
    
    def __repr__(self) -> str:
        """Detailed representation of the exception."""
        attrs = []
        attrs.append(f"message={repr(str(self))}")
        if self.error_code is not None:
            attrs.append(f"error_code={self.error_code}")
        if self.error_source:
            attrs.append(f"error_source={repr(self.error_source)}")
        return f"UnsupportedConversion({', '.join(attrs)})"

    @classmethod
    def from_error_info(cls, error_info: 'ErrorInfo') -> 'UnsupportedConversion':
        """
        Create an exception instance from native error information.
        
        Args:
            error_info: Error information from native SDK
            
        Returns:
            A new UnsupportedConversion instance
        """
        message = error_info.message.decode('utf-8') if error_info.message else "Unknown error"
        source = error_info.source.decode('utf-8') if error_info.source else None
        
        return cls(
            message=message,
            error_code=error_info.code,
            error_source=source
        )

__all__ = ['UnsupportedConversion']

