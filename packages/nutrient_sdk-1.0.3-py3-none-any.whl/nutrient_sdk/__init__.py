"""Nutrient SDK for Python."""

__version__ = "1.0.0"
__author__ = "Nutrient"
__license__ = "Commercial"

from .base_exception import (
    NutrientException,
    SDKError,
    InitializationError,
    LicenseError,
    DocumentError,
    ConversionError,
    ValidationError,
    IOError,
    MemoryError,
    TimeoutError,
    NotImplementedError,
    PermissionError,
    ErrorInfo,
    handle_native_error
)

from .iexporter import IExporter, IExporterBase

from .alreadyopenforeditionexception import AlreadyOpenForEditionException
from .barcodeexception import BarcodeException
from .barcodeinvaliddataexception import BarcodeInvalidDataException
from .barcodeinvalidnotnumericdataexception import BarcodeInvalidNotNumericDataException
from .barcodeinvalidlengthexception import BarcodeInvalidLengthException
from .barcodeinvalidstartexception import BarcodeInvalidStartException
from .barcodeinvalidstopexception import BarcodeInvalidStopException
from .barcodeinvalidtypeexception import BarcodeInvalidTypeException
from .barcodeinvalidwidthexception import BarcodeInvalidWidthException
from .exportexception import ExportException
from .featureunlicensedexception import FeatureUnLicensedException
from .filenotfoundexception import FileNotFoundException
from .incompatibletypeexception import IncompatibleTypeException
from .indexoutofboundsexception import IndexOutOfBoundsException
from .invalidargumentexception import InvalidArgumentException
from .invalidlicenseexception import InvalidLicenseException
from .invalidsettingsexception import InvalidSettingsException
from .invalidstateexception import InvalidStateException
from .invalidtemplateexception import InvalidTemplateException
from .nulloremptyparameterexception import NullOrEmptyParameterException
from .nutrientargumentnullexception import NutrientArgumentNullException
from .unsupportedconversion import UnsupportedConversion
from .sdkexception import SdkException
from .visionexception import VisionException

from .sdksettings import SdkSettings
from .license import License
from .internallogic import InternalLogic
from .document import Document
from .digitalsignatureoptions import DigitalSignatureOptions
from .pdfsigner import PdfSigner
from .signatureappearance import SignatureAppearance
from .timestampconfiguration import TimestampConfiguration
from .htmlexporter import HtmlExporter
from .imageexporter import ImageExporter
from .markdownexporter import MarkdownExporter
from .pdfexporter import PdfExporter
from .presentationexporter import PresentationExporter
from .spreadsheetexporter import SpreadsheetExporter
from .svgexporter import SvgExporter
from .wordexporter import WordExporter
from .pdfeditor import PdfEditor
from .wordeditor import WordEditor
from .pdfpage import PdfPage
from .pdfpagecollection import PdfPageCollection
from .pdfcheckboxfield import PdfCheckBoxField
from .pdfformfield import PdfFormField
from .pdfcomboboxfield import PdfComboBoxField
from .pdfformfieldcollection import PdfFormFieldCollection
from .pdflistboxfield import PdfListBoxField
from .pdfpushbuttonfield import PdfPushButtonField
from .pdfradiobuttonfield import PdfRadioButtonField
from .pdfsignaturefield import PdfSignatureField
from .pdftextfield import PdfTextField
from .pdfannotation import PdfAnnotation
from .pdfannotationcollection import PdfAnnotationCollection
from .pdflinkannotation import PdfLinkAnnotation
from .pdfmarkupannotation import PdfMarkupAnnotation
from .pdffreetextannotation import PdfFreeTextAnnotation
from .pdfwidgetannotation import PdfWidgetAnnotation
from .pdfstampannotation import PdfStampAnnotation
from .pdfredactannotation import PdfRedactAnnotation
from .pdfshapeannotation import PdfShapeAnnotation
from .pdflineannotation import PdfLineAnnotation
from .pdfcircleannotation import PdfCircleAnnotation
from .pdfsquareannotation import PdfSquareAnnotation
from .pdftextannotation import PdfTextAnnotation
from .pdfhighlightannotation import PdfHighlightAnnotation
from .pdfunderlineannotation import PdfUnderlineAnnotation
from .pdfstrikeoutannotation import PdfStrikeOutAnnotation
from .pdfsquigglyannotation import PdfSquigglyAnnotation
from .vision import Vision
from .color import Color
from .aiaugmentersettings import AiAugmenterSettings
from .cadsettings import CadSettings
from .documentsettings import DocumentSettings
from .claudeapisettings import ClaudeApiSettings
from .pdfmetadata import PdfMetadata
from .contentextractionsettings import ContentExtractionSettings
from .documentlayoutjsonexportsettings import DocumentLayoutJsonExportSettings
from .conversionsettings import ConversionSettings
from .customvlmapisettings import CustomVlmApiSettings
from .deskewsettings import DeskewSettings
from .finalizersettings import FinalizerSettings
from .htmlsettings import HtmlSettings
from .imagesettings import ImageSettings
from .inferencelayoutsettings import InferenceLayoutSettings
from .jbig2settings import Jbig2Settings
from .jpegsettings import JpegSettings
from .ocrsettings import OcrSettings
from .openaiapiendpointsettings import OpenAIApiEndpointSettings
from .openailanguagesdetectionsettings import OpenAILanguagesDetectionSettings
from .openaipicturealtsettings import OpenAIPictureAltSettings
from .opensettings import OpenSettings
from .pdfpagesettings import PdfPageSettings
from .pdfsettings import PdfSettings
from .presentationsettings import PresentationSettings
from .readingordersettings import ReadingOrderSettings
from .segmentersettings import SegmenterSettings
from .spreadsheetsettings import SpreadsheetSettings
from .tablerecognitionsettings import TableRecognitionSettings
from .tiffsettings import TiffSettings
from .visiondescriptorsettings import VisionDescriptorSettings
from .visionsettings import VisionSettings
from .vlmocrtextfusersettings import VlmOcrTextFuserSettings
from .wordsdetectionsettings import WordsDetectionSettings
from .wordsettings import WordSettings

from .jsonexportcontent import JsonExportContent
from .jsonexportformat import JsonExportFormat
from .vlmclassificationstrategy import VlmClassificationStrategy
from .htmllayouttype import HtmlLayoutType
from .descriptionlevel import DescriptionLevel
from .imagesettingmode import ImageSettingMode
from .vlmprovider import VlmProvider
from .imageexportformat import ImageExportFormat
from .pagecachemode import PageCacheMode
from .visionfeatures import VisionFeatures
from .opensettingsmode import OpenSettingsMode
from .visionengine import VisionEngine
from .renderinglayoutmode import RenderingLayoutMode
from .documentformat import DocumentFormat
from .documentmarkupmode import DocumentMarkupMode
from .unitmode import UnitMode
from .implicitconversion import ImplicitConversion
from .pdfpagesizes import PdfPageSizes
from .pdfconformance import PdfConformance
from .pdfsettingsmode import PdfSettingsMode
from .documenttype import DocumentType
from .pdfsavepreferences import PdfSavePreferences
from .signaturehashalgorithm import SignatureHashAlgorithm
from .pdfcompression import PdfCompression
from .textdirection import TextDirection
from .tiffcompression import TiffCompression
from .pdfformfieldtype import PdfFormFieldType
from .pdfborderstyle import PdfBorderStyle
from .pdfrubberstampicon import PdfRubberStampIcon
from .pdflineendingstyle import PdfLineEndingStyle

from .sdk_loader import (
    initialize_sdk,
    shutdown_sdk,
    get_sdk_version,
    is_sdk_initialized,
    SDKError
)

__all__ = [
    'initialize_sdk',
    'shutdown_sdk',
    'get_sdk_version',
    'is_sdk_initialized',
    'NutrientException',
    'SDKError',
    'InitializationError',
    'LicenseError',
    'DocumentError',
    'ConversionError',
    'ValidationError',
    'IOError',
    'MemoryError',
    'TimeoutError',
    'NotImplementedError',
    'PermissionError',
    'ErrorInfo',
    'handle_native_error',
    'IExporter',
    'IExporterBase',
    'AlreadyOpenForEditionException',
    'BarcodeException',
    'BarcodeInvalidDataException',
    'BarcodeInvalidNotNumericDataException',
    'BarcodeInvalidLengthException',
    'BarcodeInvalidStartException',
    'BarcodeInvalidStopException',
    'BarcodeInvalidTypeException',
    'BarcodeInvalidWidthException',
    'ExportException',
    'FeatureUnLicensedException',
    'FileNotFoundException',
    'IncompatibleTypeException',
    'IndexOutOfBoundsException',
    'InvalidArgumentException',
    'InvalidLicenseException',
    'InvalidSettingsException',
    'InvalidStateException',
    'InvalidTemplateException',
    'NullOrEmptyParameterException',
    'NutrientArgumentNullException',
    'UnsupportedConversion',
    'SdkException',
    'VisionException',
    'SdkSettings',
    'License',
    'InternalLogic',
    'Document',
    'DigitalSignatureOptions',
    'PdfSigner',
    'SignatureAppearance',
    'TimestampConfiguration',
    'HtmlExporter',
    'ImageExporter',
    'MarkdownExporter',
    'PdfExporter',
    'PresentationExporter',
    'SpreadsheetExporter',
    'SvgExporter',
    'WordExporter',
    'PdfEditor',
    'WordEditor',
    'PdfPage',
    'PdfPageCollection',
    'PdfCheckBoxField',
    'PdfFormField',
    'PdfComboBoxField',
    'PdfFormFieldCollection',
    'PdfListBoxField',
    'PdfPushButtonField',
    'PdfRadioButtonField',
    'PdfSignatureField',
    'PdfTextField',
    'PdfAnnotation',
    'PdfAnnotationCollection',
    'PdfLinkAnnotation',
    'PdfMarkupAnnotation',
    'PdfFreeTextAnnotation',
    'PdfWidgetAnnotation',
    'PdfStampAnnotation',
    'PdfRedactAnnotation',
    'PdfShapeAnnotation',
    'PdfLineAnnotation',
    'PdfCircleAnnotation',
    'PdfSquareAnnotation',
    'PdfTextAnnotation',
    'PdfHighlightAnnotation',
    'PdfUnderlineAnnotation',
    'PdfStrikeOutAnnotation',
    'PdfSquigglyAnnotation',
    'Vision',
    'Color',
    'AiAugmenterSettings',
    'CadSettings',
    'DocumentSettings',
    'ClaudeApiSettings',
    'PdfMetadata',
    'ContentExtractionSettings',
    'DocumentLayoutJsonExportSettings',
    'ConversionSettings',
    'CustomVlmApiSettings',
    'DeskewSettings',
    'FinalizerSettings',
    'HtmlSettings',
    'ImageSettings',
    'InferenceLayoutSettings',
    'Jbig2Settings',
    'JpegSettings',
    'OcrSettings',
    'OpenAIApiEndpointSettings',
    'OpenAILanguagesDetectionSettings',
    'OpenAIPictureAltSettings',
    'OpenSettings',
    'PdfPageSettings',
    'PdfSettings',
    'PresentationSettings',
    'ReadingOrderSettings',
    'SegmenterSettings',
    'SpreadsheetSettings',
    'TableRecognitionSettings',
    'TiffSettings',
    'VisionDescriptorSettings',
    'VisionSettings',
    'VlmOcrTextFuserSettings',
    'WordsDetectionSettings',
    'WordSettings',
    'JsonExportContent',
    'JsonExportFormat',
    'VlmClassificationStrategy',
    'HtmlLayoutType',
    'DescriptionLevel',
    'ImageSettingMode',
    'VlmProvider',
    'ImageExportFormat',
    'PageCacheMode',
    'VisionFeatures',
    'OpenSettingsMode',
    'VisionEngine',
    'RenderingLayoutMode',
    'DocumentFormat',
    'DocumentMarkupMode',
    'UnitMode',
    'ImplicitConversion',
    'PdfPageSizes',
    'PdfConformance',
    'PdfSettingsMode',
    'DocumentType',
    'PdfSavePreferences',
    'SignatureHashAlgorithm',
    'PdfCompression',
    'TextDirection',
    'TiffCompression',
    'PdfFormFieldType',
    'PdfBorderStyle',
    'PdfRubberStampIcon',
    'PdfLineEndingStyle',
]

_initialized = False

def _auto_initialize():
    global _initialized
    if not _initialized:
        try:
            initialize_sdk()
            _initialized = True
        except SDKError as e:
            import warnings
            warnings.warn(f"Failed to auto-initialize Nutrient SDK: {e}", RuntimeWarning)

import os
if not os.environ.get('NUTRIENT_NO_AUTO_INIT'):
    _auto_initialize()

import atexit

def _cleanup():
    global _initialized
    if _initialized:
        try:
            shutdown_sdk()
            _initialized = False
        except:
            pass  # Ignore errors during cleanup

atexit.register(_cleanup)