"""
VlmOcrTextFuserSettings module.
"""

import ctypes
import os
import sys
from typing import Optional, Any, Union
from enum import Enum
from pathlib import Path
from importlib import import_module
from .base_exception import NutrientException, ErrorInfo as NativeErrorInfo, handle_native_error
from . import sdk_helpers
from . import sdk_loader

sdk_loader.initialize_sdk()
_lib = sdk_loader.get_library_handle()


class VlmOcrTextFuserSettingsError(NutrientException):
    """Exception raised by VlmOcrTextFuserSettings operations."""
    pass

_lib.BridgeVlmOcrTextFuserSettingsGetLastErrorCode.restype = ctypes.c_int
_lib.BridgeVlmOcrTextFuserSettingsGetLastErrorCode.argtypes = []

_lib.BridgeVlmOcrTextFuserSettingsGetLastErrorMessage.restype = ctypes.c_void_p
_lib.BridgeVlmOcrTextFuserSettingsGetLastErrorMessage.argtypes = []

_lib.BridgeVlmOcrTextFuserSettingsFreeErrorString.restype = None
_lib.BridgeVlmOcrTextFuserSettingsFreeErrorString.argtypes = [ctypes.c_void_p]

_lib.BridgeVlmOcrTextFuserSettingsGetEnabled.restype = ctypes.c_bool
_lib.BridgeVlmOcrTextFuserSettingsGetEnabled.argtypes = [ctypes.c_void_p]

_lib.BridgeVlmOcrTextFuserSettingsSetEnabledBoolean.restype = None
_lib.BridgeVlmOcrTextFuserSettingsSetEnabledBoolean.argtypes = [ctypes.c_void_p, ctypes.c_bool]


class VlmOcrTextFuserSettings:
    """
    Merged view of VlmOcrTextFuserSettings, combining immutable defaults, SDK overrides, and document overrides. Property writes automatically target the appropriate level (document if available, otherwise SDK).
    """

    def __init__(self):
        """Cannot instantiate VlmOcrTextFuserSettings directly. Use static factory methods instead."""
        raise TypeError("VlmOcrTextFuserSettings cannot be instantiated directly. Use static factory methods to obtain instances.")

    def _check_error(self):
        error_code = _lib.BridgeVlmOcrTextFuserSettingsGetLastErrorCode()
        if error_code != 0:
            self._raise_native_error(error_code, "VlmOcrTextFuserSettings")

    @staticmethod
    def _raise_native_error(error_code: int, source: str) -> None:
        message_ptr = _lib.BridgeVlmOcrTextFuserSettingsGetLastErrorMessage()
        if message_ptr:
            message = ctypes.string_at(message_ptr).decode('utf-8', errors='replace')
            _lib.BridgeVlmOcrTextFuserSettingsFreeErrorString(message_ptr)
        else:
            message = "Unknown error"

        error_info = NativeErrorInfo()
        error_info.code = error_code
        error_info.message = message.encode('utf-8', errors='replace')[:1023]
        error_info.source = source.encode('utf-8', errors='replace')[:255]
        error_info.details = f"VlmOcrTextFuserSettings: {message}".encode('utf-8', errors='replace')[:2047]
        handle_native_error(error_info, default_exception_class=VlmOcrTextFuserSettingsError)
    
    def _ensure_not_closed(self):
        if self._closed:
            raise ValueError("VlmOcrTextFuserSettings instance has been closed")

    @classmethod
    def _from_handle(cls, handle):
        if not handle:
            return None  # Null handle means object not found or null return
        instance = cls.__new__(cls)
        instance._handle = handle
        instance._closed = False
        return instance

    def get_enabled(self) -> bool:
        """
        Gets the Enabled property.

        Returns:
            bool: The value of the Enabled property.

        Raises:
            VlmOcrTextFuserSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        result = _lib.BridgeVlmOcrTextFuserSettingsGetEnabled(self._handle)
        self._check_error()
        return result

    def set_enabled(self, value: bool) -> None:
        """
        Sets the Enabled property.

        Args:
            value (bool)

        Returns:
            None: The result of the operation

        Raises:
            VlmOcrTextFuserSettingsError: If the operation fails
        """
        self._ensure_not_closed()

        _lib.BridgeVlmOcrTextFuserSettingsSetEnabledBoolean(self._handle, value)
        self._check_error()

    @property
    def enabled(self) -> bool:
        """
        Gets the Enabled property.

        Returns:
            bool: The value of the Enabled property.
        """
        return self.get_enabled()

    @enabled.setter
    def enabled(self, value: bool) -> None:
        """
        Sets the enabled.

        Args:
            value (bool): The value to set.
        """
        self.set_enabled(value)


