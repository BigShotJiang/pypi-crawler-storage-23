"""Progress tracking utilities for parallel execution."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed, Future
from dataclasses import dataclass
from multiprocessing import cpu_count
from typing import Any, TypeVar
from collections.abc import Callable

import pandas as pd

# Optional rich progress bar support
try:
    from rich.progress import (
        Progress,
        SpinnerColumn,
        TextColumn,
        BarColumn,
        TimeElapsedColumn,
        TimeRemainingColumn,
        MofNCompleteColumn,
    )

    HAS_RICH = True
except ImportError:
    HAS_RICH = False


T = TypeVar("T")


@dataclass
class ChunkInfo:
    """Information about a data chunk."""

    chunk_id: int
    start_row: int
    end_row: int
    size: int


@dataclass
class ExecutionStats:
    """Statistics from parallel execution."""

    total_chunks: int
    total_rows: int
    workers_used: int
    chunks_completed: int
    chunks_failed: int
    memory_mb: float


class ProgressTracker:
    """Track progress of parallel operations."""

    def __init__(self, show_progress: bool = True, console: Any = None):
        """Initialize progress tracker.

        Args:
            show_progress: Whether to show progress bar
            console: Rich console instance (optional)
        """
        self.show_progress = show_progress and HAS_RICH
        self.console = console

    def track_chunks(
        self,
        chunks: list[pd.DataFrame],
        process_func: Callable[[pd.DataFrame], T],
        description: str = "Processing",
        max_workers: int | None = None,
    ) -> list[T]:
        """Process chunks with progress tracking.

        Args:
            chunks: List of DataFrame chunks
            process_func: Function to apply to each chunk
            description: Description for progress bar
            max_workers: Number of workers

        Returns:
            List of results from each chunk
        """
        workers = max_workers or cpu_count()
        total = len(chunks)

        if self.show_progress:
            return self._track_with_progress(
                chunks, process_func, description, workers, total
            )
        else:
            return self._track_without_progress(chunks, process_func, workers)

    def _track_with_progress(
        self,
        chunks: list[pd.DataFrame],
        process_func: Callable[[pd.DataFrame], T],
        description: str,
        workers: int,
        total: int,
    ) -> list[T]:
        """Process with rich progress bar."""
        results: list[T] = [None] * total  # type: ignore

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=self.console,
        ) as progress:
            task = progress.add_task(description, total=total)

            with ProcessPoolExecutor(max_workers=workers) as executor:
                # Submit all tasks
                future_to_idx: dict[Future, int] = {
                    executor.submit(process_func, chunk): i
                    for i, chunk in enumerate(chunks)
                }

                # Collect results as they complete
                for future in as_completed(future_to_idx):
                    idx = future_to_idx[future]
                    try:
                        results[idx] = future.result()
                    except Exception as e:
                        # Store exception info
                        results[idx] = e  # type: ignore
                    progress.update(task, advance=1)

        return results

    def _track_without_progress(
        self,
        chunks: list[pd.DataFrame],
        process_func: Callable[[pd.DataFrame], T],
        workers: int,
    ) -> list[T]:
        """Process without progress bar."""
        results: list[T] = [None] * len(chunks)  # type: ignore

        with ProcessPoolExecutor(max_workers=workers) as executor:
            future_to_idx = {
                executor.submit(process_func, chunk): i
                for i, chunk in enumerate(chunks)
            }

            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    results[idx] = e  # type: ignore

        return results


class EnhancedParallelExecutor:
    """Enhanced parallel executor with progress tracking and memory management."""

    def __init__(
        self,
        max_workers: int | None = None,
        chunk_size: int = 100000,
        show_progress: bool = True,
        memory_limit_mb: float | None = None,
    ):
        """Initialize enhanced parallel executor.

        Args:
            max_workers: Number of worker processes (default: CPU count)
            chunk_size: Rows per chunk
            show_progress: Show progress bar
            memory_limit_mb: Memory limit per worker in MB
        """
        self.max_workers = max_workers or cpu_count()
        self.chunk_size = chunk_size
        self.show_progress = show_progress
        self.memory_limit_mb = memory_limit_mb
        self._stats: ExecutionStats | None = None

    @property
    def stats(self) -> ExecutionStats | None:
        """Get execution statistics from last run."""
        return self._stats

    def execute_parallel(
        self,
        df: pd.DataFrame,
        func: Callable[[pd.DataFrame], T],
        description: str = "Validating",
        **kwargs: Any,
    ) -> list[T]:
        """Execute function in parallel across chunks.

        Args:
            df: DataFrame to process
            func: Function to apply to each chunk
            description: Description for progress bar
            **kwargs: Additional arguments for func

        Returns:
            List of results from each chunk
        """
        # Compute memory usage once (deep=True is expensive)
        memory_mb = float(df.memory_usage(deep=True).sum() / (1024 * 1024))

        # Auto-configure based on data size
        workers = self._configure_workers(memory_mb)
        chunk_size = self._calculate_chunk_size_from_memory(df, memory_mb)

        # Split into chunks
        chunks = self._split_dataframe(df, chunk_size)

        # Track progress
        tracker = ProgressTracker(show_progress=self.show_progress)

        # Wrap function with kwargs if needed
        wrapped_func: Callable[[pd.DataFrame], T]
        if kwargs:
            def _wrapper(chunk: pd.DataFrame) -> T:
                """Apply the function to a chunk with bound keyword arguments."""
                return func(chunk, **kwargs)
            wrapped_func = _wrapper
        else:
            wrapped_func = func

        results = tracker.track_chunks(
            chunks, wrapped_func, description=description, max_workers=workers
        )

        # Update stats (reuse cached memory_mb)
        self._stats = ExecutionStats(
            total_chunks=len(chunks),
            total_rows=len(df),
            workers_used=workers,
            chunks_completed=sum(1 for r in results if not isinstance(r, Exception)),
            chunks_failed=sum(1 for r in results if isinstance(r, Exception)),
            memory_mb=memory_mb,
        )

        return results

    def _split_dataframe(
        self, df: pd.DataFrame, chunk_size: int
    ) -> list[pd.DataFrame]:
        """Split DataFrame into chunks.

        Args:
            df: DataFrame to split
            chunk_size: Rows per chunk

        Returns:
            List of DataFrame chunks
        """
        chunks = []
        num_chunks = (len(df) + chunk_size - 1) // chunk_size

        for i in range(num_chunks):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, len(df))
            chunks.append(df.iloc[start_idx:end_idx])

        return chunks

    def _calculate_chunk_size(self, df: pd.DataFrame) -> int:
        """Calculate optimal chunk size based on data and memory.

        Args:
            df: DataFrame to process

        Returns:
            Optimal chunk size
        """
        return self._calculate_chunk_size_from_memory(
            df, self.estimate_memory_usage(df)
        )

    def _calculate_chunk_size_from_memory(
        self, df: pd.DataFrame, memory_mb: float
    ) -> int:
        """Calculate optimal chunk size using pre-computed memory.

        Args:
            df: DataFrame to process
            memory_mb: Pre-computed memory usage in MB

        Returns:
            Optimal chunk size
        """
        if self.memory_limit_mb is None:
            return self.chunk_size

        # Estimate bytes per row from pre-computed total
        mb_per_row = memory_mb / max(len(df), 1)

        # Calculate rows that fit in memory limit
        if mb_per_row > 0:
            max_rows = int(self.memory_limit_mb / mb_per_row)
            return min(max(1000, max_rows), self.chunk_size)

        return self.chunk_size

    @staticmethod
    def estimate_memory_usage(df: pd.DataFrame) -> float:
        """Estimate memory usage of DataFrame in MB.

        Args:
            df: DataFrame to estimate

        Returns:
            Estimated memory in MB
        """
        return float(df.memory_usage(deep=True).sum() / (1024 * 1024))

    def auto_configure_workers(self, df: pd.DataFrame) -> int:
        """Auto-configure number of workers based on data size.

        Args:
            df: DataFrame to process

        Returns:
            Recommended number of workers
        """
        return self._configure_workers(self.estimate_memory_usage(df))

    def _configure_workers(self, memory_mb: float) -> int:
        """Configure workers using pre-computed memory.

        Args:
            memory_mb: Pre-computed memory usage in MB

        Returns:
            Recommended number of workers
        """
        available_cpus = self.max_workers

        # Heuristic: Use fewer workers for very large DataFrames
        # to avoid memory pressure
        if memory_mb > 5000:  # >5GB
            return max(2, available_cpus // 4)
        elif memory_mb > 1000:  # >1GB
            return max(2, available_cpus // 2)
        elif memory_mb > 100:  # >100MB
            return available_cpus
        else:
            # Small data, use fewer workers to avoid overhead
            return max(1, min(4, available_cpus))


def parallel_apply(
    df: pd.DataFrame,
    func: Callable[[pd.DataFrame], T],
    chunk_size: int = 100000,
    max_workers: int | None = None,
    show_progress: bool = True,
    description: str = "Processing",
) -> list[T]:
    """Convenient function to apply a function in parallel.

    Args:
        df: DataFrame to process
        func: Function to apply
        chunk_size: Rows per chunk
        max_workers: Number of workers
        show_progress: Show progress bar
        description: Description for progress bar

    Returns:
        List of results

    Example:
        >>> def validate_chunk(chunk):
        ...     return len(chunk[chunk['value'] > 0])
        >>> results = parallel_apply(df, validate_chunk, show_progress=True)
        >>> total_valid = sum(results)
    """
    executor = EnhancedParallelExecutor(
        max_workers=max_workers,
        chunk_size=chunk_size,
        show_progress=show_progress,
    )
    return executor.execute_parallel(df, func, description=description)


__all__ = [
    "ChunkInfo",
    "ExecutionStats",
    "ProgressTracker",
    "EnhancedParallelExecutor",
    "parallel_apply",
]
