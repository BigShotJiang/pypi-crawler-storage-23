"""Rule factory for creating rule instances from configuration."""

from datacheck.config import RuleConfig
from datacheck.exceptions import RuleDefinitionError


class RuleFactory:
    """Factory for creating rule instances from configuration."""

    @staticmethod
    def create_rules(rule_config: RuleConfig) -> list:
        """Create rule instances from configuration.

        Args:
            rule_config: Rule configuration

        Returns:
            List of Rule instances

        Raises:
            RuleDefinitionError: If rule configuration is invalid
        """
        # Lazy imports to avoid circular imports
        from datacheck.rules.null_rules import NotNullRule
        from datacheck.rules.numeric_rules import (
            MinMaxRule, NonNegativeRule, PositiveRule, RangeRule,
        )
        from datacheck.rules.string_rules import AllowedValuesRule, LengthRule, RegexRule
        from datacheck.rules.temporal_rules import (
            DateFormatValidRule, MaxAgeRule,
            NoFutureTimestampsRule, TimestampRangeRule,
        )
        from datacheck.rules.composite_rules import (
            BooleanRule, DataTypeRule, ForeignKeyExistsRule, SumEqualsRule,
            UniqueCombinationRule, UniqueRule,
        )

        rules: list = []
        explicitly_disabled = False  # set when a rule is knowingly skipped (rule: false)

        for rule_type, rule_params in rule_config.rules.items():
            try:
                if rule_type == "not_null":
                    if rule_params:
                        rules.append(NotNullRule(rule_config.name, rule_config.column))
                    else:
                        explicitly_disabled = True

                elif rule_type == "min":
                    rules.append(
                        MinMaxRule(
                            f"{rule_config.name}_min",
                            rule_config.column,
                            min_value=rule_params,
                        )
                    )

                elif rule_type == "max":
                    rules.append(
                        MinMaxRule(
                            f"{rule_config.name}_max",
                            rule_config.column,
                            max_value=rule_params,
                        )
                    )

                elif rule_type == "unique":
                    if rule_params:
                        rules.append(UniqueRule(rule_config.name, rule_config.column))
                    else:
                        explicitly_disabled = True

                elif rule_type == "regex":
                    rules.append(
                        RegexRule(rule_config.name, rule_config.column, pattern=rule_params)
                    )

                elif rule_type == "allowed_values":
                    rules.append(
                        AllowedValuesRule(
                            rule_config.name, rule_config.column, allowed_values=rule_params
                        )
                    )

                elif rule_type == "type":
                    rules.append(
                        DataTypeRule(
                            rule_config.name, rule_config.column, expected_type=rule_params
                        )
                    )

                elif rule_type == "min_length":
                    rules.append(
                        LengthRule(
                            rule_config.name,
                            rule_config.column,
                            min_length=rule_params,
                        )
                    )

                elif rule_type == "max_length":
                    rules.append(
                        LengthRule(
                            rule_config.name,
                            rule_config.column,
                            max_length=rule_params,
                        )
                    )

                # Freshness rules
                elif rule_type == "max_age":
                    rules.append(
                        MaxAgeRule(
                            rule_config.name,
                            rule_config.column,
                            duration=rule_params,
                        )
                    )

                elif rule_type == "timestamp_range" or rule_type == "date_range":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "timestamp_range/date_range rule must be a dictionary with 'min' and 'max'"
                        )
                    rules.append(
                        TimestampRangeRule(
                            rule_config.name,
                            rule_config.column,
                            min_timestamp=rule_params["min"],
                            max_timestamp=rule_params["max"],
                        )
                    )

                elif rule_type == "no_future_timestamps":
                    if rule_params:
                        rules.append(
                            NoFutureTimestampsRule(rule_config.name, rule_config.column)
                        )
                    else:
                        explicitly_disabled = True

                elif rule_type == "date_format_valid":
                    rules.append(
                        DateFormatValidRule(
                            rule_config.name,
                            rule_config.column,
                            format_string=rule_params,
                        )
                    )

                elif rule_type == "date_format":
                    # Handle both dict format {"format": "%Y-%m-%d"} and string format
                    if isinstance(rule_params, dict):
                        fmt = rule_params.get("format", "%Y-%m-%d")
                    else:
                        fmt = rule_params or "%Y-%m-%d"
                    rules.append(
                        DateFormatValidRule(
                            rule_config.name,
                            rule_config.column,
                            format_string=fmt,
                        )
                    )

                # Relationship rules
                elif rule_type == "unique_combination":
                    if not isinstance(rule_params, list):
                        raise RuleDefinitionError(
                            "unique_combination rule must be a list of column names"
                        )
                    rules.append(
                        UniqueCombinationRule(
                            rule_config.name,
                            rule_config.column,
                            columns=rule_params,
                        )
                    )

                elif rule_type == "foreign_key_exists":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "foreign_key_exists rule must be a dictionary with "
                            "'reference_data' (list of dicts) and 'reference_column'"
                        )
                    import pandas as _pd
                    ref_data = rule_params.get("reference_data")
                    ref_column = rule_params.get("reference_column")
                    if ref_data is None or ref_column is None:
                        raise RuleDefinitionError(
                            "foreign_key_exists requires 'reference_data' and 'reference_column'"
                        )
                    reference_df = _pd.DataFrame(ref_data)
                    rules.append(
                        ForeignKeyExistsRule(
                            rule_config.name,
                            rule_config.column,
                            reference_df=reference_df,
                            reference_column=ref_column,
                        )
                    )

                elif rule_type == "sum_equals":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "sum_equals rule must be a dictionary with "
                            "'column_a', 'column_b', and optional 'tolerance'"
                        )
                    col_a = rule_params.get("column_a")
                    col_b = rule_params.get("column_b")
                    if not col_a or not col_b:
                        raise RuleDefinitionError(
                            "sum_equals requires 'column_a' and 'column_b'"
                        )
                    rules.append(
                        SumEqualsRule(
                            rule_config.name,
                            rule_config.column,
                            column_a=col_a,
                            column_b=col_b,
                            tolerance=rule_params.get("tolerance", 0.01),
                        )
                    )

                elif rule_type == "positive":
                    if rule_params:
                        rules.append(PositiveRule(rule_config.name, rule_config.column))
                    else:
                        explicitly_disabled = True

                elif rule_type == "non_negative":
                    if rule_params:
                        rules.append(NonNegativeRule(rule_config.name, rule_config.column))
                    else:
                        explicitly_disabled = True

                elif rule_type == "range":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "range rule must be a dictionary with 'min' and 'max'"
                        )
                    min_val = rule_params.get("min")
                    max_val = rule_params.get("max")
                    if min_val is None or max_val is None:
                        raise RuleDefinitionError(
                            "range rule requires both 'min' and 'max'"
                        )
                    rules.append(
                        RangeRule(rule_config.name, rule_config.column, min_value=min_val, max_value=max_val)
                    )

                elif rule_type == "boolean":
                    if rule_params:
                        rules.append(BooleanRule(rule_config.name, rule_config.column))
                    else:
                        explicitly_disabled = True

            except (RuleDefinitionError, TypeError, ValueError) as e:
                raise RuleDefinitionError(
                    f"Error creating {rule_type} rule for '{rule_config.name}': {e}"
                ) from e

        if not rules and not explicitly_disabled:
            raise RuleDefinitionError(
                f"No valid rules created for check '{rule_config.name}'"
            )

        return rules
