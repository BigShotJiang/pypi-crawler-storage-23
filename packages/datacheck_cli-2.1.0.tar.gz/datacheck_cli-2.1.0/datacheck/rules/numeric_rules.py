"""Numeric validation rules."""

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import RuleResult
from datacheck.rules.base import Rule


def _ensure_numeric(series: pd.Series) -> pd.Series:
    """Cast decimal columns to float64 so numeric checks work.

    Handles two cases:
    - Arrow-backed decimal128 (pd.ArrowDtype): ``is_numeric_dtype()`` returns
      False, and numpy arithmetic raises ArrowTypeError.
    - Object-dtype with Python ``decimal.Decimal`` values: produced by plain
      ``pd.read_parquet()`` for Parquet decimal128 columns. ``is_numeric_dtype()``
      returns False, and numpy ops fail on Decimal/float mixing.
    """
    try:
        import pyarrow as pa

        if isinstance(series.dtype, pd.ArrowDtype) and pa.types.is_decimal(
            series.dtype.pyarrow_dtype
        ):
            return series.astype("float64")
    except Exception:
        pass
    # Handle object dtype containing Python decimal.Decimal objects
    if series.dtype == object:
        try:
            import decimal
            first_valid = series.dropna()
            if len(first_valid) > 0 and isinstance(first_valid.iloc[0], decimal.Decimal):
                return pd.to_numeric(series, errors="coerce")
        except Exception:
            pass
    return series


class MinMaxRule(Rule):
    """Rule to check numeric values are within min/max bounds."""

    def __init__(
        self, name: str, column: str, min_value: float | None = None, max_value: float | None = None
    ) -> None:
        """Initialize MinMaxRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)

        Raises:
            RuleDefinitionError: If neither min nor max is specified
        """
        super().__init__(name, column)
        if min_value is None and max_value is None:
            raise RuleDefinitionError("MinMaxRule requires at least min or max value")
        self.min_value = min_value
        self.max_value = max_value

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that numeric values are within bounds.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Determine rule type and check name
            rule_type = "min_max"
            check_name = self.name.removesuffix("_min").removesuffix("_max")
            if self.name.endswith("_min"):
                rule_type = "min"
            elif self.name.endswith("_max"):
                rule_type = "max"

            # Filter out null values (they should be caught by not_null rule)
            non_null_mask = df[self.column].notna()
            data = _ensure_numeric(df[self.column][non_null_mask])

            # Check if data is numeric
            if not pd.api.types.is_numeric_dtype(data):
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error=f"Column '{self.column}' is not numeric",
                    rule_type=rule_type,
                    check_name=check_name,
                )

            # Build violation mask — use PyArrow compute for Arrow-backed columns
            # (single fused call avoids intermediate boolean Series allocations)
            try:
                import pyarrow.compute as pc

                arr = data.array._pa_array  # raises AttributeError for numpy-backed
                if self.min_value is not None and self.max_value is not None:
                    violations_pa = pc.or_(
                        pc.less(arr, self.min_value), pc.greater(arr, self.max_value)
                    )
                elif self.min_value is not None:
                    violations_pa = pc.less(arr, self.min_value)
                else:
                    violations_pa = pc.greater(arr, self.max_value)
                # Use .values to get positional numpy array (avoids label-alignment
                # issues when data.index is non-sequential, e.g. after sampling)
                violations_mask = pd.Series(
                    violations_pa.to_pandas().values, index=data.index, dtype=bool
                )
            except (AttributeError, TypeError, ImportError):
                # Fallback for numpy-backed arrays
                if self.min_value is not None and self.max_value is not None:
                    violations_mask = (data < self.min_value) | (data > self.max_value)
                elif self.min_value is not None:
                    violations_mask = data < self.min_value
                else:
                    violations_mask = data > self.max_value

            violation_indices = data.index[violations_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type=rule_type,
                    check_name=check_name,
                )

            # Get failed values and create reasons (capped at 100 for memory)
            failed_values = data.loc[violation_indices]
            sample_vals = failed_values.iloc[:100]
            if self.min_value is not None and self.max_value is not None:
                reasons = [
                    f"Below minimum: {self.min_value}" if v < self.min_value
                    else f"Exceeds maximum: {self.max_value}"
                    for v in sample_vals
                ]
            elif self.min_value is not None:
                reasons = [f"Below minimum: {self.min_value}"] * len(sample_vals)
            else:
                reasons = [f"Exceeds maximum: {self.max_value}"] * len(sample_vals)

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type=rule_type,
                check_name=check_name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            # Determine rule type and check name for error case
            rule_type = "min_max"
            check_name = self.name.removesuffix("_min").removesuffix("_max")
            if self.name.endswith("_min"):
                rule_type = "min"
            elif self.name.endswith("_max"):
                rule_type = "max"

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing min/max rule: {e}",
                rule_type=rule_type,
                check_name=check_name,
            )
# Convenience classes for clearer API
class MinRule(MinMaxRule):
    """Rule to check numeric values are above a minimum."""

    def __init__(self, name: str, column: str, min_value: float) -> None:
        """Initialize MinRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=min_value, max_value=None)


class MaxRule(MinMaxRule):
    """Rule to check numeric values are below a maximum."""

    def __init__(self, name: str, column: str, max_value: float) -> None:
        """Initialize MaxRule.

        Args:
            name: Name of the rule
            column: Column to validate
            max_value: Maximum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=None, max_value=max_value)


class RangeRule(MinMaxRule):
    """Rule to check numeric values are within a range."""

    def __init__(self, name: str, column: str, min_value: float, max_value: float) -> None:
        """Initialize RangeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=min_value, max_value=max_value)


class NonNegativeRule(MinMaxRule):
    """Rule to check all numeric values are >= 0."""

    def __init__(self, name: str, column: str) -> None:
        super().__init__(name, column, min_value=0)


class PositiveRule(Rule):
    """Rule to check all numeric values are strictly > 0."""

    def validate(self, df: pd.DataFrame) -> RuleResult:
        try:
            self._check_column_exists(df)
            total_rows = len(df)
            non_null_mask = df[self.column].notna()
            data = _ensure_numeric(df[self.column][non_null_mask])
            if not pd.api.types.is_numeric_dtype(data):
                return RuleResult(
                    rule_name=self.name, column=self.column, passed=False,
                    total_rows=total_rows, rule_type="positive", check_name=self.name,
                    error=f"Column '{self.column}' is not numeric",
                )
            violations_mask = data <= 0
            violation_indices = data.index[violations_mask]
            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name, column=self.column, passed=True,
                    total_rows=total_rows, failed_rows=0,
                    rule_type="positive", check_name=self.name,
                )
            failed_values = data.loc[violation_indices]
            reasons = [
                f"Value {v} is not positive (must be > 0)" for v in failed_values.iloc[:100]
            ]
            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )
            return RuleResult(
                rule_name=self.name, column=self.column, passed=False,
                total_rows=total_rows, failed_rows=len(violation_indices),
                failure_details=failure_detail, rule_type="positive", check_name=self.name,
            )
        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name, column=self.column, passed=False,
                total_rows=len(df), rule_type="positive", check_name=self.name,
                error=f"Error executing positive rule: {e}",
            )


