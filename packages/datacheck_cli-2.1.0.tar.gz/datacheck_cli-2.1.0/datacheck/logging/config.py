"""Logging configuration for DataCheck."""

import logging
import sys
from collections.abc import MutableMapping
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from datacheck.logging.filters import SensitiveDataFilter
from datacheck.logging.formatters import ConsoleFormatter, JsonFormatter

# Flag to track if logging has been configured
_logging_configured = False

# Default logger name
LOGGER_NAME = "datacheck"


def configure_logging(
    level: str = "INFO",
    format_type: str = "console",
    log_file: str | None = None,
    enable_file_rotation: bool = True,
    max_bytes: int = 10_485_760,  # 10MB
    backup_count: int = 5,
    mask_sensitive: bool = True,
    colorize: bool = True,
) -> None:
    """Configure structured logging for DataCheck.

    This function sets up the logging system with the specified configuration.
    It should be called once at application startup.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_type: Output format ("console" or "json")
        log_file: Path to log file (None for stdout only)
        enable_file_rotation: Enable log file rotation
        max_bytes: Max file size before rotation (default: 10MB)
        backup_count: Number of backup files to keep
        mask_sensitive: Mask sensitive data (passwords, tokens, etc.)
        colorize: Enable ANSI colors in console output

    Example:
        # Console logging (development)
        >>> configure_logging(level="DEBUG", format_type="console")

        # JSON logging to file (production)
        >>> configure_logging(
        ...     level="INFO",
        ...     format_type="json",
        ...     log_file="/var/log/datacheck/validation.log"
        ... )

        # Quiet mode
        >>> configure_logging(level="WARNING")
    """
    global _logging_configured

    # Get numeric log level
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Get root datacheck logger
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(numeric_level)

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    # Create formatter based on format_type
    if format_type.lower() == "json":
        formatter: logging.Formatter = JsonFormatter()
    else:
        formatter = ConsoleFormatter(colorize=colorize)

    # Create console handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)

    # Add sensitive data filter if enabled
    if mask_sensitive:
        console_handler.addFilter(SensitiveDataFilter())

    logger.addHandler(console_handler)

    # Create file handler if log_file specified
    if log_file:
        log_path = Path(log_file)

        # Create parent directories if needed
        log_path.parent.mkdir(parents=True, exist_ok=True)

        if enable_file_rotation:
            file_handler: logging.Handler = RotatingFileHandler(
                filename=str(log_path),
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding="utf-8",
            )
        else:
            file_handler = logging.FileHandler(
                filename=str(log_path),
                encoding="utf-8",
            )

        file_handler.setLevel(numeric_level)

        # Always use JSON formatter for file output for easier parsing
        file_handler.setFormatter(JsonFormatter())

        if mask_sensitive:
            file_handler.addFilter(SensitiveDataFilter())

        logger.addHandler(file_handler)

    # Don't propagate to root logger
    logger.propagate = False

    _logging_configured = True


def get_logger(name: str) -> logging.Logger:
    """Get a configured logger instance.

    Args:
        name: Logger name (usually __name__)

    Returns:
        Configured logger instance

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("validation_started", extra={"rows": 10000})
    """
    # Ensure logging is configured with defaults if not already
    if not _logging_configured:
        configure_logging()

    # Create child logger under datacheck namespace
    if name.startswith(LOGGER_NAME):
        logger_name = name
    else:
        logger_name = f"{LOGGER_NAME}.{name}"

    return logging.getLogger(logger_name)


class LoggerAdapter(logging.LoggerAdapter):
    """Logger adapter with built-in context support.

    Allows adding persistent context to all log messages from this logger.

    Example:
        >>> logger = get_logger(__name__)
        >>> adapter = LoggerAdapter(logger, {"request_id": "abc-123"})
        >>> adapter.info("processing")  # Includes request_id in all logs
    """

    def process(
        self, msg: str, kwargs: MutableMapping[str, Any]
    ) -> tuple[str, MutableMapping[str, Any]]:
        """Process log message, adding context.

        Args:
            msg: Log message
            kwargs: Keyword arguments

        Returns:
            Processed message and kwargs
        """
        # Merge extra context
        extra = kwargs.get("extra", {})
        if isinstance(extra, dict) and isinstance(self.extra, dict):
            extra.update(self.extra)
        kwargs["extra"] = extra

        return msg, kwargs


def create_logger_with_context(name: str, **context: Any) -> LoggerAdapter:
    """Create a logger with persistent context.

    Args:
        name: Logger name
        **context: Context key-value pairs to include in all logs

    Returns:
        LoggerAdapter with context

    Example:
        >>> logger = create_logger_with_context(
        ...     __name__,
        ...     trace_id="abc-123",
        ...     component="validator"
        ... )
        >>> logger.info("processing")  # Includes trace_id and component
    """
    base_logger = get_logger(name)
    return LoggerAdapter(base_logger, context)


def reset_logging() -> None:
    """Reset logging configuration.

    Useful for testing or reconfiguration.
    """
    global _logging_configured

    logger = logging.getLogger(LOGGER_NAME)
    logger.handlers.clear()
    logger.setLevel(logging.NOTSET)

    _logging_configured = False
