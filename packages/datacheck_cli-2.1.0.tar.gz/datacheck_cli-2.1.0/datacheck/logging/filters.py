"""Filters for logging, including sensitive data masking."""

import copy
import logging
import re
from typing import Any

# Redaction placeholder
REDACTED = "***REDACTED***"

# Patterns to detect sensitive keys
SENSITIVE_KEY_PATTERNS: dict[str, re.Pattern[str]] = {
    "password": re.compile(r"password", re.IGNORECASE),
    "passwd": re.compile(r"passwd", re.IGNORECASE),
    "pwd": re.compile(r"\bpwd\b", re.IGNORECASE),
    "token": re.compile(r"token", re.IGNORECASE),
    "api_key": re.compile(r"api[_\-]?key", re.IGNORECASE),
    "apikey": re.compile(r"apikey", re.IGNORECASE),
    "secret": re.compile(r"secret", re.IGNORECASE),
    "auth": re.compile(r"auth(?:orization)?", re.IGNORECASE),
    "credentials": re.compile(r"credentials?", re.IGNORECASE),
    "private_key": re.compile(r"private[_\-]?key", re.IGNORECASE),
    "access_key": re.compile(r"access[_\-]?key", re.IGNORECASE),
    "bearer": re.compile(r"bearer", re.IGNORECASE),
    "jwt": re.compile(r"\bjwt\b", re.IGNORECASE),
    "session": re.compile(r"session[_\-]?(?:id|key|token)?", re.IGNORECASE),
    "cookie": re.compile(r"cookie", re.IGNORECASE),
}

# Patterns to detect sensitive values in strings
SENSITIVE_VALUE_PATTERNS: dict[str, re.Pattern[str]] = {
    # Credit card numbers (various formats)
    "credit_card": re.compile(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b"),
    # Social Security Numbers
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    # Bearer tokens
    "bearer_token": re.compile(r"Bearer\s+[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+"),
    # API keys (common patterns)
    "api_key_pattern": re.compile(r"\b(?:sk|pk|api)[_\-][A-Za-z0-9]{20,}\b"),
    # AWS access key IDs
    "aws_access_key": re.compile(r"\bAKIA[A-Z0-9]{16}\b"),
    # Connection strings with passwords
    "connection_string": re.compile(
        r"(?:password|pwd)=([^;]+)", re.IGNORECASE
    ),
}


def is_sensitive_key(key: str) -> bool:
    """Check if a key name indicates sensitive data.

    Args:
        key: Key name to check

    Returns:
        True if key matches a sensitive pattern

    Example:
        >>> is_sensitive_key("password")
        True
        >>> is_sensitive_key("username")
        False
    """
    if not isinstance(key, str):
        return False

    for pattern in SENSITIVE_KEY_PATTERNS.values():
        if pattern.search(key):
            return True
    return False


def mask_string_value(value: str) -> str:
    """Mask sensitive patterns found within string values.

    Args:
        value: String to check and mask

    Returns:
        String with sensitive patterns replaced

    Example:
        >>> mask_string_value("My SSN is 123-45-6789")
        'My SSN is ***REDACTED***'
        >>> mask_string_value("Card: 1234-5678-9012-3456")
        'Card: ***REDACTED***'
    """
    if not isinstance(value, str):
        return value

    masked = value

    # Mask connection string passwords
    masked = SENSITIVE_VALUE_PATTERNS["connection_string"].sub(
        lambda m: f"password={REDACTED}", masked
    )

    # Mask other patterns
    for name, pattern in SENSITIVE_VALUE_PATTERNS.items():
        if name == "connection_string":
            continue  # Already handled
        masked = pattern.sub(REDACTED, masked)

    return masked


def mask_value(value: Any, depth: int = 0, max_depth: int = 10) -> Any:
    """Recursively mask sensitive data in a value.

    Args:
        value: Value to mask (can be dict, list, or scalar)
        depth: Current recursion depth
        max_depth: Maximum recursion depth to prevent infinite loops

    Returns:
        Masked value

    Example:
        >>> mask_value({"password": "secret", "user": "john"})
        {'password': '***REDACTED***', 'user': 'john'}
    """
    if depth > max_depth:
        return value

    if isinstance(value, dict):
        return {
            k: (
                REDACTED
                if is_sensitive_key(str(k))
                else mask_value(v, depth + 1, max_depth)
            )
            for k, v in value.items()
        }
    elif isinstance(value, list):
        return [mask_value(item, depth + 1, max_depth) for item in value]
    elif isinstance(value, tuple):
        return tuple(mask_value(item, depth + 1, max_depth) for item in value)
    elif isinstance(value, str):
        return mask_string_value(value)
    else:
        return value


def mask_sensitive_data(
    logger: Any, method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Structlog processor to mask sensitive data in log events.

    This processor automatically redacts sensitive information from logs,
    including passwords, tokens, API keys, credit card numbers, etc.

    Args:
        logger: Logger instance (unused, required by structlog)
        method_name: Log method name (unused, required by structlog)
        event_dict: Event dictionary to process

    Returns:
        Event dictionary with sensitive data masked

    Example:
        Input:  {"password": "secret123", "user": "john"}
        Output: {"password": "***REDACTED***", "user": "john"}

        Used as a structlog processor:
        >>> processors = [..., mask_sensitive_data, ...]
    """
    # Create a deep copy to avoid modifying the original
    masked_dict = copy.deepcopy(event_dict)

    for key, value in list(masked_dict.items()):
        if is_sensitive_key(str(key)):
            masked_dict[key] = REDACTED
        else:
            masked_dict[key] = mask_value(value)

    return masked_dict


class SensitiveDataFilter(logging.Filter):
    """Standard library logging filter for masking sensitive data.

    This filter can be added to any logging handler to automatically
    mask sensitive information in log messages.

    Example:
        >>> handler = logging.StreamHandler()
        >>> handler.addFilter(SensitiveDataFilter())
        >>> logger.addHandler(handler)
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """Filter log record, masking sensitive data.

        Args:
            record: Log record to filter

        Returns:
            True (always allows record, just modifies it)
        """
        # Mask the message
        if record.msg and isinstance(record.msg, str):
            record.msg = mask_string_value(record.msg)

        # Mask arguments
        if record.args:
            if isinstance(record.args, dict):
                record.args = mask_value(record.args)
            elif isinstance(record.args, tuple):
                record.args = tuple(mask_value(arg) for arg in record.args)

        return True
