"""SARIF 2.1.0 exporter for validation results.

SARIF (Static Analysis Results Interchange Format) is the standard consumed
by GitHub Code Scanning. Exporting results as SARIF allows data quality
failures to appear in the GitHub Security tab alongside code analysis results.

Since DataCheck failures are column-level aggregates (not tied to a specific
source code line), results use ``logicalLocations`` rather than
``physicalLocation``. This means failures appear in the Security tab, not
as inline PR annotations.

Reference: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from datacheck.results import ValidationSummary


_SARIF_SCHEMA = "https://schemastore.azurewebsites.net/schemas/json/sarif-2.1.0.json"
_DATACHECK_VERSION = "2.1.0"
_DATACHECK_INFO_URI = "https://github.com/squrtech/datacheck"

# DataCheck severity → SARIF level mapping
_SEVERITY_MAP: dict[str, str] = {
    "error": "error",
    "warning": "warning",
    "info": "note",
}


class SarifExporter:
    """Exporter for SARIF 2.1.0 output of validation results.

    Produces a valid SARIF 2.1.0 JSON document that GitHub Code Scanning
    can consume. Only failed rules (and rules with execution errors) are
    included — passed rules are omitted per the SARIF convention.
    """

    @staticmethod
    def export(
        summary: ValidationSummary,
        output_path: str | Path | None = None,
        elapsed: float | None = None,
        source_info: str | None = None,
    ) -> str:
        """Export validation results to SARIF 2.1.0 JSON format.

        Args:
            summary: ValidationSummary to export
            output_path: Optional file path to write the SARIF JSON
            elapsed: Validation elapsed time in seconds
            source_info: Human-readable description of the data source

        Returns:
            SARIF JSON string
        """
        sarif = SarifExporter._build_sarif(summary, elapsed=elapsed, source_info=source_info)
        sarif_json = json.dumps(sarif, indent=2)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(sarif_json, encoding="utf-8")

        return sarif_json

    @staticmethod
    def _build_sarif(
        summary: ValidationSummary,
        elapsed: float | None = None,
        source_info: str | None = None,
    ) -> dict[str, Any]:
        """Build the SARIF 2.1.0 document structure."""
        rules = SarifExporter._build_rules(summary)
        results = SarifExporter._build_results(summary)

        end_time = datetime.now(timezone.utc)
        end_time_str = end_time.strftime("%Y-%m-%dT%H:%M:%SZ")

        invocation: dict[str, Any] = {
            "executionSuccessful": not summary.has_errors,
            "endTimeUtc": end_time_str,
        }
        if elapsed is not None:
            from datetime import timedelta
            start_time = end_time - timedelta(seconds=elapsed)
            invocation["startTimeUtc"] = start_time.strftime("%Y-%m-%dT%H:%M:%SZ")

        run: dict[str, Any] = {
            "tool": {
                "driver": {
                    "name": "DataCheck",
                    "version": _DATACHECK_VERSION,
                    "informationUri": _DATACHECK_INFO_URI,
                    "rules": rules,
                }
            },
            "results": results,
            "invocations": [invocation],
        }
        if source_info:
            run["automationDetails"] = {"description": {"text": source_info}}

        return {
            "$schema": _SARIF_SCHEMA,
            "version": "2.1.0",
            "runs": [run],
        }

    @staticmethod
    def _build_rules(summary: ValidationSummary) -> list[dict[str, Any]]:
        """Build the SARIF rules list from all results (not just failures).

        Each unique rule_name becomes one SARIF rule entry. Passed rules are
        included so that the rule registry is complete.

        Args:
            summary: ValidationSummary containing all rule results

        Returns:
            List of SARIF rule descriptor objects
        """
        seen: set[str] = set()
        rules: list[dict[str, Any]] = []

        for result in summary.results:
            if result.rule_name in seen:
                continue
            seen.add(result.rule_name)

            level = _SEVERITY_MAP.get(result.severity, "error")
            rule_label = result.rule_type or result.rule_name
            description = f"{rule_label} check on column '{result.column}'"

            rules.append({
                "id": result.rule_name,
                "shortDescription": {"text": description},
                "defaultConfiguration": {"level": level},
                "helpUri": _DATACHECK_INFO_URI,
            })

        return rules

    @staticmethod
    def _build_results(summary: ValidationSummary) -> list[dict[str, Any]]:
        """Build the SARIF results list (failures and execution errors only).

        Passed rules are skipped — SARIF only lists findings, not passes.

        Args:
            summary: ValidationSummary containing all rule results

        Returns:
            List of SARIF result objects
        """
        sarif_results: list[dict[str, Any]] = []

        for result in summary.results:
            if result.passed and not result.has_error:
                continue

            level = _SEVERITY_MAP.get(result.severity, "error")

            if result.has_error:
                msg = (
                    f"Column '{result.column}': rule execution error"
                    + (f" — {result.error}" if result.error else "")
                )
                level = "error"
            else:
                rate = (
                    result.failed_rows / result.total_rows * 100
                    if result.total_rows > 0
                    else 0.0
                )
                rule_label = result.rule_type or result.rule_name
                msg = (
                    f"Column '{result.column}': {result.failed_rows:,} of "
                    f"{result.total_rows:,} rows failed {rule_label} check "
                    f"({rate:.2f}%)"
                )

            sarif_results.append({
                "ruleId": result.rule_name,
                "level": level,
                "message": {"text": msg},
                "locations": [
                    {
                        "logicalLocations": [
                            {"name": result.column, "kind": "column"}
                        ]
                    }
                ],
            })

        return sarif_results


__all__ = ["SarifExporter"]
