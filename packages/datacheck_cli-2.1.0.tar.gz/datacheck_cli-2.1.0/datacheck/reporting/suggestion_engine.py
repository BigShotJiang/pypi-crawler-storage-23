"""Suggestion engine for actionable validation recommendations.

Analyzes validation failures and provides context-aware suggestions
for fixing data quality issues.
"""

from dataclasses import dataclass, field
from typing import Any

from datacheck.results import RuleResult, ValidationSummary


@dataclass
class Suggestion:
    """A data quality improvement suggestion.

    Attributes:
        rule_name: Name of the rule that generated this suggestion
        column: Column the suggestion applies to
        severity: Severity level (high, medium, low)
        message: Human-readable suggestion message
        action: Recommended action to take
        sample_fixes: Example fixes for sample failures
        impact: Estimated impact of fixing this issue
    """

    rule_name: str
    column: str
    severity: str
    message: str
    action: str
    sample_fixes: list[dict[str, Any]] = field(default_factory=list)
    impact: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary representation of suggestion
        """
        return {
            "rule_name": self.rule_name,
            "column": self.column,
            "severity": self.severity,
            "message": self.message,
            "action": self.action,
            "sample_fixes": self.sample_fixes,
            "impact": self.impact,
        }


class SuggestionEngine:
    """Engine for generating actionable suggestions from validation failures.

    Analyzes validation results and provides context-aware recommendations
    for improving data quality.
    """

    # Severity thresholds based on failure rate
    HIGH_SEVERITY_THRESHOLD = 25.0  # > 25% failure rate
    MEDIUM_SEVERITY_THRESHOLD = 5.0  # > 5% failure rate

    # Rule-specific suggestion generators
    RULE_SUGGESTIONS: dict[str, dict[str, str]] = {
        "not_null": {
            "message": "Missing values detected in required column",
            "action": "Add default values, implement data pipeline validation, or review data source",
        },
        "unique": {
            "message": "Duplicate values found in column that should be unique",
            "action": "Implement deduplication logic or review upstream data sources for duplicates",
        },
        "min": {
            "message": "Values below minimum threshold",
            "action": "Add validation at data entry points or implement floor function in ETL",
        },
        "max": {
            "message": "Values exceed maximum threshold",
            "action": "Add validation at data entry points or implement ceiling function in ETL",
        },
        "regex": {
            "message": "Values do not match expected pattern",
            "action": "Review data format requirements and add pattern validation at source",
        },
        "allowed_values": {
            "message": "Values outside allowed set",
            "action": "Update allowed values list or fix data source to only emit valid values",
        },
        "type": {
            "message": "Invalid data types detected",
            "action": "Add type coercion in ETL or fix data source schema",
        },
        "length": {
            "message": "String length outside acceptable range",
            "action": "Add length validation at data entry or implement truncation in ETL",
        },
        "max_age": {
            "message": "Data exceeds maximum age threshold",
            "action": "Check data pipeline freshness or increase refresh frequency",
        },
        "no_future_timestamps": {
            "message": "Future timestamps detected",
            "action": "Fix timezone handling or validate timestamps at entry",
        },
        "timestamp_range": {
            "message": "Timestamps outside expected range",
            "action": "Review timestamp validation logic and data source",
        },
        "date_format_valid": {
            "message": "Invalid date formats detected",
            "action": "Standardize dates to match the expected format at the source or add date parsing logic",
        },
        "foreign_key_exists": {
            "message": "Orphan records detected (missing foreign key references)",
            "action": "Add referential integrity constraints or clean orphan records",
        },
        "sum_equals": {
            "message": "Sum validation failed",
            "action": "Review calculation logic or investigate missing/duplicate records",
        },
        "unique_combination": {
            "message": "Duplicate combinations detected",
            "action": "Add composite unique constraint or implement deduplication",
        },
    }

    def __init__(self) -> None:
        """Initialize suggestion engine."""
        self._suggestions: list[Suggestion] = []

    def analyze(self, summary: ValidationSummary) -> list[Suggestion]:
        """Analyze validation summary and generate suggestions.

        Args:
            summary: ValidationSummary to analyze

        Returns:
            List of suggestions sorted by severity
        """
        self._suggestions = []

        # Analyze failed rules
        for result in summary.get_failed_results():
            suggestion = self._analyze_failure(result)
            if suggestion:
                self._suggestions.append(suggestion)

        # Analyze error rules
        for result in summary.get_error_results():
            suggestion = self._analyze_error(result)
            if suggestion:
                self._suggestions.append(suggestion)

        # Sort by severity (high first)
        severity_order = {"high": 0, "medium": 1, "low": 2}
        self._suggestions.sort(key=lambda s: severity_order.get(s.severity, 3))

        return self._suggestions

    def _analyze_failure(self, result: RuleResult) -> Suggestion | None:
        """Analyze a single failed rule result.

        Args:
            result: Failed RuleResult to analyze

        Returns:
            Suggestion for the failure, or None if no suggestion
        """
        if result.total_rows == 0:
            return None

        # Calculate failure rate
        failure_rate = (result.failed_rows / result.total_rows) * 100

        # Determine severity
        severity = self._get_severity(failure_rate)

        # Get rule-specific suggestion
        rule_type = result.rule_type or self._infer_rule_type(result.rule_name)
        suggestion_info = self.RULE_SUGGESTIONS.get(rule_type, {})

        message = suggestion_info.get(
            "message", f"Validation failed for rule '{result.rule_name}'"
        )
        action = suggestion_info.get(
            "action", "Review the validation rule and fix non-compliant data"
        )

        # Generate sample fixes
        sample_fixes = self._generate_sample_fixes(result, rule_type)

        # Estimate impact
        impact = self._estimate_impact(result, failure_rate)

        return Suggestion(
            rule_name=result.rule_name,
            column=result.column,
            severity=severity,
            message=message,
            action=action,
            sample_fixes=sample_fixes,
            impact=impact,
        )

    def _analyze_error(self, result: RuleResult) -> Suggestion | None:
        """Analyze a rule that encountered an error.

        Args:
            result: Error RuleResult to analyze

        Returns:
            Suggestion for the error, or None if no suggestion
        """
        return Suggestion(
            rule_name=result.rule_name,
            column=result.column,
            severity="high",
            message=f"Rule execution error: {result.error}",
            action="Review rule configuration and ensure column exists with correct data type",
            sample_fixes=[],
            impact="Cannot validate until error is resolved",
        )

    def _get_severity(self, failure_rate: float) -> str:
        """Determine severity level based on failure rate.

        Args:
            failure_rate: Percentage of rows that failed

        Returns:
            Severity level (high, medium, low)
        """
        if failure_rate > self.HIGH_SEVERITY_THRESHOLD:
            return "high"
        elif failure_rate > self.MEDIUM_SEVERITY_THRESHOLD:
            return "medium"
        else:
            return "low"

    def _infer_rule_type(self, rule_name: str) -> str:
        """Infer rule type from rule name.

        Args:
            rule_name: Name of the rule

        Returns:
            Inferred rule type
        """
        rule_name_lower = rule_name.lower()

        # Check for known patterns
        type_patterns = {
            "not_null": ["not_null", "notnull", "required"],
            "unique": ["unique"],
            "min": ["min_", "minimum"],
            "max": ["max_", "maximum"],
            "regex": ["regex", "pattern"],
        }

        for rule_type, patterns in type_patterns.items():
            for pattern in patterns:
                if pattern in rule_name_lower:
                    return rule_type

        return "unknown"

    def _generate_sample_fixes(
        self, result: RuleResult, rule_type: str
    ) -> list[dict[str, Any]]:
        """Generate sample fix suggestions for failed values.

        Args:
            result: RuleResult containing failure details
            rule_type: Type of the rule

        Returns:
            List of sample fix dictionaries
        """
        fixes: list[dict[str, Any]] = []

        if not result.failure_details:
            return fixes

        details = result.failure_details

        # Limit to 5 sample fixes
        num_samples = min(5, len(details.sample_values))

        for i in range(num_samples):
            value = details.sample_values[i] if i < len(details.sample_values) else None
            reason = (
                details.sample_reasons[i] if i < len(details.sample_reasons) else ""
            )

            fix = {
                "original_value": str(value) if value is not None else "NULL",
                "issue": reason,
                "suggested_fix": self._suggest_fix_for_value(value, rule_type, reason),
            }
            fixes.append(fix)

        return fixes

    def _suggest_fix_for_value(
        self, value: Any, rule_type: str, reason: str
    ) -> str:
        """Suggest a specific fix for a failed value.

        Args:
            value: The failed value
            rule_type: Type of the rule
            reason: Reason for failure

        Returns:
            Suggested fix string
        """
        import math
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return "Replace with appropriate default value or NULL handling"

        value_str = str(value)

        if rule_type in ("min", "max"):
            return f"Adjust value or investigate data source for '{value_str}'"

        elif rule_type == "not_null":
            return "Replace NULL with default value or mark record for review"

        elif rule_type == "unique":
            return "Remove duplicate or assign unique identifier"

        elif rule_type == "date_format_valid":
            # Extract the specific expected format from the failure reason
            # Reason format: "Value '...' does not match format '%Y-%m-%d'"
            if "does not match format '" in reason:
                fmt = reason.split("does not match format '")[-1].rstrip("'")
                return f"Convert to expected format: {fmt}"
            return "Convert to the expected date format specified in the rule"

        return "Review and correct the value"

    def _estimate_impact(self, result: RuleResult, failure_rate: float) -> str:
        """Estimate the impact of fixing this validation issue.

        Args:
            result: RuleResult with failure details
            failure_rate: Percentage of rows that failed

        Returns:
            Impact description string
        """
        affected_rows = result.failed_rows

        if failure_rate > 50:
            return f"Critical: {affected_rows:,} rows ({failure_rate:.1f}%) affected - major data quality issue"
        elif failure_rate > 25:
            return f"High: {affected_rows:,} rows ({failure_rate:.1f}%) affected - significant data issue"
        elif failure_rate > 5:
            return f"Medium: {affected_rows:,} rows ({failure_rate:.1f}%) affected - moderate data issue"
        else:
            return f"Low: {affected_rows:,} rows ({failure_rate:.1f}%) affected - minor cleanup needed"


__all__ = [
    "Suggestion",
    "SuggestionEngine",
]
