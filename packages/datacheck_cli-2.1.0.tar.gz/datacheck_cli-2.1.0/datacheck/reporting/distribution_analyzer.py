"""Distribution analysis for validation failures.

Provides statistical analysis and visualization data for numeric
validation failures to help understand data quality issues.
"""

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from datacheck.results import RuleResult, ValidationSummary


@dataclass
class DistributionStats:
    """Statistical summary of a numeric distribution.

    Attributes:
        column: Column name
        rule_name: Name of the rule analyzed
        count: Number of values
        mean: Mean of values
        std: Standard deviation
        min_val: Minimum value
        max_val: Maximum value
        percentiles: Dictionary of percentile values (25, 50, 75, 90, 95, 99)
        histogram_bins: Bin edges for histogram
        histogram_counts: Counts per histogram bin
        outlier_count: Number of statistical outliers (beyond 3 std)
        skewness: Skewness of distribution
        kurtosis: Kurtosis of distribution
    """

    column: str
    rule_name: str
    count: int
    mean: float
    std: float
    min_val: float
    max_val: float
    percentiles: dict[str, float] = field(default_factory=dict)
    histogram_bins: list[float] = field(default_factory=list)
    histogram_counts: list[int] = field(default_factory=list)
    outlier_count: int = 0
    skewness: float = 0.0
    kurtosis: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary representation of distribution stats
        """
        return {
            "column": self.column,
            "rule_name": self.rule_name,
            "count": self.count,
            "mean": round(self.mean, 4) if not np.isnan(self.mean) else None,
            "std": round(self.std, 4) if not np.isnan(self.std) else None,
            "min": round(self.min_val, 4) if not np.isnan(self.min_val) else None,
            "max": round(self.max_val, 4) if not np.isnan(self.max_val) else None,
            "percentiles": {k: round(v, 4) for k, v in self.percentiles.items()},
            "histogram": {
                "bins": [round(b, 4) for b in self.histogram_bins],
                "counts": self.histogram_counts,
            },
            "outlier_count": self.outlier_count,
            "skewness": round(self.skewness, 4) if not np.isnan(self.skewness) else None,
            "kurtosis": round(self.kurtosis, 4) if not np.isnan(self.kurtosis) else None,
        }


@dataclass
class FailureDistribution:
    """Analysis of failures across different dimensions.

    Attributes:
        rule_name: Name of the rule
        column: Column analyzed
        total_failures: Total number of failures
        failure_rate: Percentage of rows that failed
        value_distribution: Distribution stats if numeric
        category_counts: Counts by category for categorical data
        temporal_pattern: Pattern over time if datetime column exists
    """

    rule_name: str
    column: str
    total_failures: int
    failure_rate: float
    value_distribution: DistributionStats | None = None
    category_counts: dict[str, int] = field(default_factory=dict)
    temporal_pattern: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary representation of failure distribution
        """
        result: dict[str, Any] = {
            "rule_name": self.rule_name,
            "column": self.column,
            "total_failures": self.total_failures,
            "failure_rate": round(self.failure_rate, 2),
        }

        if self.value_distribution:
            result["value_distribution"] = self.value_distribution.to_dict()

        if self.category_counts:
            result["category_counts"] = self.category_counts

        if self.temporal_pattern:
            result["temporal_pattern"] = self.temporal_pattern

        return result


class DistributionAnalyzer:
    """Analyzer for validation failure distributions.

    Provides statistical analysis of failed values to help understand
    patterns in data quality issues.
    """

    DEFAULT_HISTOGRAM_BINS = 10

    def __init__(self, num_bins: int = DEFAULT_HISTOGRAM_BINS) -> None:
        """Initialize distribution analyzer.

        Args:
            num_bins: Number of bins for histograms (default: 10)
        """
        self.num_bins = num_bins

    def analyze_summary(
        self, summary: ValidationSummary, df: pd.DataFrame | None = None
    ) -> list[FailureDistribution]:
        """Analyze all failures in a validation summary.

        Args:
            summary: ValidationSummary to analyze
            df: Optional DataFrame for additional analysis

        Returns:
            List of FailureDistribution objects
        """
        distributions: list[FailureDistribution] = []

        for result in summary.get_failed_results():
            dist = self.analyze_result(result, df)
            if dist:
                distributions.append(dist)

        return distributions

    def analyze_result(
        self, result: RuleResult, df: pd.DataFrame | None = None
    ) -> FailureDistribution | None:
        """Analyze a single failed rule result.

        Args:
            result: RuleResult to analyze
            df: Optional DataFrame for additional analysis

        Returns:
            FailureDistribution or None if analysis not possible
        """
        if result.total_rows == 0:
            return None

        failure_rate = (result.failed_rows / result.total_rows) * 100

        # Create base distribution
        distribution = FailureDistribution(
            rule_name=result.rule_name,
            column=result.column,
            total_failures=result.failed_rows,
            failure_rate=failure_rate,
        )

        # Analyze failure values if available
        if result.failure_details and result.failure_details.sample_values:
            values = result.failure_details.sample_values

            # Check if values are numeric
            numeric_values = self._extract_numeric_values(values)
            if len(numeric_values) >= 3:  # Need at least 3 values for stats
                distribution.value_distribution = self._compute_distribution_stats(
                    numeric_values, result.column, result.rule_name
                )
            else:
                # Analyze as categorical
                distribution.category_counts = self._count_categories(values)

        return distribution

    def analyze_numeric_column(
        self, series: pd.Series, column_name: str, rule_name: str = ""
    ) -> DistributionStats:
        """Analyze a numeric pandas Series.

        Args:
            series: Pandas Series with numeric data
            column_name: Name of the column
            rule_name: Name of the associated rule

        Returns:
            DistributionStats for the series
        """
        # Remove NaN values
        clean_series = series.dropna()

        if len(clean_series) == 0:
            return DistributionStats(
                column=column_name,
                rule_name=rule_name,
                count=0,
                mean=float("nan"),
                std=float("nan"),
                min_val=float("nan"),
                max_val=float("nan"),
            )

        values = clean_series.to_numpy(dtype=float)
        return self._compute_distribution_stats(values, column_name, rule_name)

    def _compute_distribution_stats(
        self, values: np.ndarray, column: str, rule_name: str
    ) -> DistributionStats:
        """Compute distribution statistics for numeric values.

        Args:
            values: Numpy array of numeric values
            column: Column name
            rule_name: Rule name

        Returns:
            DistributionStats object
        """
        # Basic statistics
        count = len(values)
        mean = float(np.mean(values))
        std = float(np.std(values))
        min_val = float(np.min(values))
        max_val = float(np.max(values))

        # Percentiles
        percentiles = {
            "p25": float(np.percentile(values, 25)),
            "p50": float(np.percentile(values, 50)),
            "p75": float(np.percentile(values, 75)),
            "p90": float(np.percentile(values, 90)),
            "p95": float(np.percentile(values, 95)),
            "p99": float(np.percentile(values, 99)),
        }

        # Histogram
        hist_counts, bin_edges = np.histogram(values, bins=self.num_bins)
        histogram_bins = [float(b) for b in bin_edges]
        histogram_counts = [int(c) for c in hist_counts]

        # Outliers (beyond 3 standard deviations)
        if std > 0:
            lower_bound = mean - 3 * std
            upper_bound = mean + 3 * std
            outlier_count = int(np.sum((values < lower_bound) | (values > upper_bound)))
        else:
            outlier_count = 0

        # Skewness and kurtosis
        skewness = self._compute_skewness(values, mean, std)
        kurtosis = self._compute_kurtosis(values, mean, std)

        return DistributionStats(
            column=column,
            rule_name=rule_name,
            count=count,
            mean=mean,
            std=std,
            min_val=min_val,
            max_val=max_val,
            percentiles=percentiles,
            histogram_bins=histogram_bins,
            histogram_counts=histogram_counts,
            outlier_count=outlier_count,
            skewness=skewness,
            kurtosis=kurtosis,
        )

    def _compute_skewness(
        self, values: np.ndarray, mean: float, std: float
    ) -> float:
        """Compute skewness of distribution.

        Args:
            values: Numpy array of values
            mean: Mean of values
            std: Standard deviation

        Returns:
            Skewness value
        """
        if std == 0 or len(values) < 3:
            return 0.0

        n = len(values)
        m3 = np.mean((values - mean) ** 3)
        skew = m3 / (std**3)

        # Apply bias correction
        return float(skew * np.sqrt(n * (n - 1)) / (n - 2))

    def _compute_kurtosis(
        self, values: np.ndarray, mean: float, std: float
    ) -> float:
        """Compute excess kurtosis of distribution.

        Args:
            values: Numpy array of values
            mean: Mean of values
            std: Standard deviation

        Returns:
            Excess kurtosis value
        """
        if std == 0 or len(values) < 4:
            return 0.0

        n = len(values)
        m4 = np.mean((values - mean) ** 4)
        kurt = m4 / (std**4) - 3  # Excess kurtosis

        # Apply bias correction
        return float(((n - 1) * ((n + 1) * kurt + 6)) / ((n - 2) * (n - 3)))

    def _extract_numeric_values(self, values: list[Any]) -> np.ndarray:
        """Extract numeric values from a list of mixed types.

        Args:
            values: List of values (may be mixed types)

        Returns:
            Numpy array of numeric values
        """
        numeric: list[float] = []

        for v in values:
            if v is None:
                continue
            try:
                if isinstance(v, bool):
                    continue
                num = float(v)
                if not np.isnan(num) and not np.isinf(num):
                    numeric.append(num)
            except (ValueError, TypeError):
                continue

        return np.array(numeric)

    def _count_categories(self, values: list[Any]) -> dict[str, int]:
        """Count occurrences of each category.

        Args:
            values: List of categorical values

        Returns:
            Dictionary mapping category to count
        """
        counts: dict[str, int] = {}

        for v in values:
            key = str(v) if v is not None else "NULL"
            # Truncate long keys
            if len(key) > 50:
                key = key[:47] + "..."
            counts[key] = counts.get(key, 0) + 1

        # Sort by count descending, limit to top 20
        sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:20]
        return dict(sorted_counts)

    def generate_ascii_histogram(
        self, stats: DistributionStats, width: int = 40
    ) -> list[str]:
        """Generate ASCII histogram for terminal display.

        Args:
            stats: DistributionStats to visualize
            width: Maximum width of histogram bars (default: 40)

        Returns:
            List of strings representing the histogram
        """
        if not stats.histogram_counts:
            return ["No data available for histogram"]

        max_count = max(stats.histogram_counts)
        if max_count == 0:
            return ["No data available for histogram"]

        lines: list[str] = []

        for i, count in enumerate(stats.histogram_counts):
            # Calculate bar width
            bar_width = int((count / max_count) * width) if max_count > 0 else 0

            # Format bin range
            bin_start = stats.histogram_bins[i]
            bin_end = stats.histogram_bins[i + 1]

            # Create bar
            bar = "#" * bar_width
            lines.append(f"{bin_start:>10.2f} - {bin_end:<10.2f} | {bar} ({count})")

        return lines


__all__ = [
    "DistributionStats",
    "FailureDistribution",
    "DistributionAnalyzer",
]
