"""DataCheck - A linter for data pipelines."""

from datacheck.engine import ValidationEngine
from datacheck.exceptions import (
    ColumnNotFoundError,
    ConfigurationError,
    DataCheckError,
    DataLoadError,
    EmptyDatasetError,
    RuleDefinitionError,
    UnsupportedFormatError,
    ValidationError,
)
from datacheck.loader import (
    CSVLoader,
    DataLoader,
    DatabaseLoader,
    LoaderFactory,
    ParquetLoader,
)
from datacheck.output import JSONExporter, OutputFormatter
from datacheck.schema import (
    BaselineManager,
    SchemaComparator,
    SchemaDetector,
)

__version__ = "2.1.0"
__author__ = "Squrtech"
__email__ = "contact@squrtech.com"

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    # Exceptions
    "DataCheckError",
    "ConfigurationError",
    "ValidationError",
    "DataLoadError",
    "RuleDefinitionError",
    "UnsupportedFormatError",
    "ColumnNotFoundError",
    "EmptyDatasetError",
    # Loaders
    "DataLoader",
    "CSVLoader",
    "ParquetLoader",
    "DatabaseLoader",
    "LoaderFactory",
    # Engine
    "ValidationEngine",
    # Output
    "OutputFormatter",
    "JSONExporter",
    # Schema
    "SchemaDetector",
    "SchemaComparator",
    "BaselineManager",
]
