"""Configuration management for DataCheck.

Provides config validation, parsing, generation, and CLI tools.
"""

# Original config module classes (for backward compatibility)
from datacheck.config.loader import (
    ConfigLoader,
    NotificationsConfig,
    RuleConfig,
    ValidationConfig,
)

# New config management classes
from datacheck.config.schema import CONFIG_SCHEMA
from datacheck.config.validator import ConfigValidator
from datacheck.config.parser import ConfigParser
from datacheck.config.source import SourceConfig, load_sources
from datacheck.config.templates import (
    TEMPLATES_DIR,
    get_template_path,
    list_templates,
    load_template,
)

__all__ = [
    # Original exports (backward compatibility)
    "ConfigLoader",
    "NotificationsConfig",
    "RuleConfig",
    "ValidationConfig",
    # New config management
    "CONFIG_SCHEMA",
    "ConfigValidator",
    "ConfigParser",
    # Source management
    "SourceConfig",
    "load_sources",
    # Templates
    "TEMPLATES_DIR",
    "get_template_path",
    "list_templates",
    "load_template",
]
