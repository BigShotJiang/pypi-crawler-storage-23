"""Sample data generators for DataCheck templates.

Each generator produces realistic CSV data that matches the validation rules
in the corresponding template.  The data is designed to:

- Pass all validation checks when run with the matching template config
- Use realistic distributions (Gaussian, uniform) for numeric columns
- Demonstrate every major rule type across the six templates

Default sample count is 1 000 rows.
"""

import csv
import random
import string
from datetime import date, timedelta
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _gauss(mu: float, sigma: float, lo: float = float("-inf"), hi: float = float("inf")) -> float:
    """Clamped Gaussian sample."""
    return _clamp(random.gauss(mu, sigma), lo, hi)


def _random_string(length: int = 8, chars: str = string.ascii_uppercase + string.digits) -> str:
    return "".join(random.choice(chars) for _ in range(length))


def _random_email(domains: tuple[str, ...] = ("gmail.com", "yahoo.com", "outlook.com", "company.com")) -> str:
    first = _random_string(5, string.ascii_lowercase)
    last = _random_string(5, string.ascii_lowercase)
    return f"{first}.{last}@{random.choice(domains)}"


def _random_date(start: date, end: date) -> str:
    delta = (end - start).days
    return (start + timedelta(days=random.randint(0, delta))).strftime("%Y-%m-%d")


def _random_datetime(start: date, end: date) -> str:
    delta = (end - start).days
    d = start + timedelta(days=random.randint(0, delta))
    h = random.randint(0, 23)
    m = random.randint(0, 59)
    s = random.randint(0, 59)
    return f"{d.strftime('%Y-%m-%d')} {h:02d}:{m:02d}:{s:02d}"


def _random_uuid() -> str:
    h = "0123456789abcdef"
    def seg(n: int) -> str:
        return "".join(random.choice(h) for _ in range(n))
    return f"{seg(8)}-{seg(4)}-4{seg(3)}-{random.choice('89ab')}{seg(3)}-{seg(12)}"


def _next_business_day(d: date) -> date:
    """Advance d until it lands on a weekday."""
    while d.weekday() >= 5:
        d += timedelta(days=1)
    return d


def _random_business_date(start: date, end: date) -> str:
    delta = (end - start).days
    d = start + timedelta(days=random.randint(0, delta))
    d = _next_business_day(d)
    return d.strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Template generators
# ---------------------------------------------------------------------------

def generate_basic_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the basic template.

    Columns exercised:
        id, name, email, created_at, status, age, score, is_verified
    Rules demonstrated:
        not_null, unique, type, positive, range, regex,
        allowed_values, min_length, max_length, boolean, date_range,
        no_future_timestamps
    """
    statuses = ["active", "inactive", "pending"]
    today = date.today()
    start = date(2022, 1, 1)
    data = []

    for i in range(1, num_rows + 1):
        # score ~ N(60, 15), clamped 0-100
        score = round(_gauss(60, 15, 0.0, 100.0), 2)
        # age ~ uniform 18-80
        age = random.randint(18, 80)

        data.append({
            "id":           i,
            "name":         f"{_random_string(4, string.ascii_uppercase)}{_random_string(4, string.ascii_lowercase)}",
            "email":        _random_email(),
            "created_at":   _random_date(start, today - timedelta(days=1)),
            "status":       random.choice(statuses),
            "age":          age,
            "score":        score,
            "is_verified":  random.choice([True, False]),
        })

    return data


def generate_ecommerce_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the ecommerce template.

    Rules demonstrated:
        not_null, unique, type, positive, non_negative, range, min, max,
        regex, allowed_values, min_length, max_length, boolean,
        no_future_timestamps, date_range, unique_combination
    """
    order_statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "refunded"]
    payment_methods = ["credit_card", "debit_card", "paypal", "bank_transfer", "cash_on_delivery", "gift_card"]
    currencies = ["USD", "EUR", "GBP", "CAD", "AUD"]
    today = date.today()
    start = date(2022, 1, 1)
    data = []

    for i in range(1, num_rows + 1):
        quantity = random.randint(1, 50)
        # unit_price ~ N(50, 15), clamped 0.99-499.99
        unit_price = round(_gauss(50, 15, 0.99, 499.99), 2)
        discount_pct = round(random.uniform(0, 30), 2)  # 0-30%, non_negative
        total_price = round(quantity * unit_price * (1 - discount_pct / 100), 2)
        order_dt = _random_datetime(start, today - timedelta(days=1))

        data.append({
            "order_id":        f"ORD-{i:08d}",
            "customer_id":     f"CUST-{random.randint(10000, 99999)}",
            "product_sku":     f"{_random_string(3, string.ascii_uppercase)}-{random.randint(10000, 99999)}",
            "product_name":    f"Product {_random_string(6, string.ascii_letters)}",
            "quantity":        quantity,
            "unit_price":      unit_price,
            "total_price":     total_price,
            "discount_pct":    discount_pct,
            "order_status":    random.choice(order_statuses),
            "payment_method":  random.choice(payment_methods),
            "shipping_address": f"{random.randint(1, 9999)} {_random_string(8, string.ascii_letters)} St",
            "postal_code":     f"{random.randint(10000, 99999)}",
            "order_date":      order_dt,
            "customer_email":  _random_email(),
            "currency":        random.choice(currencies),
            "is_gift":         random.choice([True, False]),
        })

    return data


def generate_finance_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the finance template.

    Rules demonstrated:
        not_null, unique, type, range, regex, allowed_values,
        max_age, boolean, no_future_timestamps, unique_combination
    """
    tx_types = ["credit", "debit", "transfer", "payment", "refund", "withdrawal", "deposit", "fee"]
    statuses = ["pending", "processing", "completed", "failed", "cancelled", "reversed"]
    currencies = ["USD", "EUR", "GBP", "JPY", "CAD"]
    today = date.today()
    start = date(2023, 1, 1)   # within 2 years for max_age check
    data = []

    for i in range(1, num_rows + 1):
        tx_type = random.choice(tx_types)
        # amount: credits positive, debits negative, mix ~ N(0, 5000)
        raw = round(_gauss(0, 5000, -50000, 50000), 2)
        if tx_type in ("credit", "deposit", "refund"):
            amount = abs(raw)
        elif tx_type in ("debit", "withdrawal", "fee", "payment"):
            amount = -abs(raw)
        else:
            amount = raw

        tx_d = start + timedelta(days=random.randint(0, (today - start).days - 1))
        tx_date = _random_datetime(start, tx_d)
        # settlement always on a business day, 1-3 days after transaction
        settle_d = _next_business_day(tx_d + timedelta(days=random.randint(1, 3)))

        # risk_score ~ N(500, 150), clamped 0-1000
        risk_score = round(_gauss(500, 150, 0.0, 1000.0), 2)

        data.append({
            "transaction_id":  f"TXN-{i:010d}",
            "account_id":      f"ACC-{random.randint(100000, 999999)}",
            "amount":          amount,
            "currency":        random.choice(currencies),
            "transaction_type": tx_type,
            "status":          random.choice(statuses),
            "transaction_date": tx_date,
            "settlement_date": settle_d.strftime("%Y-%m-%d"),
            "risk_score":      risk_score,
            "is_flagged":      random.choice([True, False, False, False, False]),  # ~20% flagged
            "merchant_id":     f"MER-{random.randint(100000, 999999)}",
            "batch_id":        f"BATCH-{tx_d.strftime('%Y%m%d')}-{random.randint(100, 999)}",
        })

    return data


def generate_healthcare_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the healthcare template.

    Rules demonstrated:
        not_null, unique, type, positive, range, regex, allowed_values,
        min_length, max_length, timestamp_range, no_future_timestamps,
        unique_combination, boolean
    """
    genders = ["M", "F", "O"]
    # ICD-10 codes
    diagnoses = ["J06.9", "I10", "E11.9", "M54.5", "F32.9", "J45.909", "K21.0", "N39.0",
                 "R05", "Z00.00", "I25.10", "G43.909"]
    procedures = ["99213", "99214", "99215", "99203", "99204", "99205"]
    today = date.today()
    start = date(2023, 1, 1)
    data = []

    for i in range(1, num_rows + 1):
        admission = start + timedelta(days=random.randint(0, (today - start).days - 14))
        discharge = admission + timedelta(days=random.randint(1, 14))

        # vitals with realistic distributions
        bp_sys  = round(_gauss(120, 15, 70, 200))
        bp_dia  = round(_gauss(80,  10, 40, 130))
        hr      = round(_gauss(75,  12, 30, 200))
        temp_f  = round(_gauss(98.6, 0.8, 95.0, 107.0), 1)

        birth_year = random.randint(1940, 2006)
        dob = f"{birth_year}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}"

        data.append({
            "patient_id":    f"MRN-{i:08d}",
            "date_of_birth": dob,
            "gender":        random.choice(genders),
            "diagnosis_code":     random.choice(diagnoses),
            "procedure_code":     random.choice(procedures),
            "admission_date":     admission.strftime("%Y-%m-%d"),
            "discharge_date":     discharge.strftime("%Y-%m-%d"),
            "facility_id":        f"FAC-{random.randint(100, 999)}",
            "bp_systolic":        bp_sys,
            "bp_diastolic":       bp_dia,
            "heart_rate":         hr,
            "temperature_f":      temp_f,
            "is_insured":         random.choice([True, True, True, False]),  # 75% insured
            "provider_npi":       f"{random.randint(1000000000, 9999999999)}",
        })

    return data


def generate_saas_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the saas template.

    Rules demonstrated:
        not_null, unique, type, positive, non_negative, boolean,
        regex, allowed_values, min_length, max_length,
        date_range, no_future_timestamps, max_age,
        unique_combination
    """
    plans   = ["free", "starter", "professional", "business", "enterprise"]
    statuses = ["active", "trialing", "past_due", "cancelled", "paused"]
    roles   = ["owner", "admin", "member", "viewer", "guest"]
    today   = date.today()
    start   = date(2021, 1, 1)
    last_login_lo = today - timedelta(days=364)  # within past year
    data = []

    for _i in range(1, num_rows + 1):
        plan = random.choice(plans)
        # mrr: 0 for free, else gauss(300, 200) clamped to [1, 5000]
        mrr = 0 if plan == "free" else round(_gauss(300, 200, 1, 5000), 2)
        seats = 1 if plan in ("free", "starter") else random.randint(2, 200)
        # api_calls_30d: non_negative integer, gauss(5000, 3000) clamped [0, 100000]
        api_calls = max(0, round(_gauss(5000, 3000, 0, 100000)))
        # storage_gb: non_negative, gauss(20, 15) clamped [0, 500]
        storage_gb = round(_gauss(20, 15, 0, 500), 2)

        created_dt  = start + timedelta(days=random.randint(0, (today - start).days - 30))
        last_login  = last_login_lo + timedelta(days=random.randint(0, 363))
        trial_end   = (created_dt + timedelta(days=14)).strftime("%Y-%m-%d")

        data.append({
            "user_id":         _random_uuid(),
            "organization_id": _random_uuid(),
            "email":           _random_email(),
            "username":        f"usr_{_random_string(6, string.ascii_lowercase + string.digits)}",
            "plan":            plan,
            "status":          random.choice(statuses),
            "role":            random.choice(roles),
            "created_at":      created_dt.strftime("%Y-%m-%d"),
            "last_login_at":   last_login.strftime("%Y-%m-%d"),
            "mrr":             mrr,
            "seat_count":      seats,
            "api_calls_30d":   api_calls,
            "storage_gb":      storage_gb,
            "is_active":       random.choice([True, True, True, False]),  # 75% active
            "trial_end_date":  trial_end,
        })

    return data


def generate_iot_data(num_rows: int = 1000) -> list[dict[str, Any]]:
    """Generate sample data for the iot template.

    Rules demonstrated:
        not_null, unique (record_id), type, positive, non_negative, range,
        regex, allowed_values, timestamp_range, no_future_timestamps,
        unique_combination (device_id + timestamp)
    """
    device_ids   = [f"DEV-{_random_string(8, '0123456789ABCDEF')}" for _ in range(50)]
    quality_flags = ["good", "warning", "error"]
    sensor_types  = ["temperature", "humidity", "pressure", "motion", "light", "gas"]
    protocols     = ["mqtt", "http", "coap", "websocket"]
    today = date.today()
    start = date(2024, 1, 1)
    used_combos: set[tuple[str, str]] = set()
    data: list[dict[str, Any]] = []
    i = 0

    while len(data) < num_rows:
        i += 1
        device_id = random.choice(device_ids)
        ts_d = start + timedelta(days=random.randint(0, (today - start).days - 1))
        h = random.randint(0, 23)
        m_min = random.randint(0, 59)
        s_sec = random.randint(0, 59)
        timestamp = f"{ts_d.strftime('%Y-%m-%d')} {h:02d}:{m_min:02d}:{s_sec:02d}"

        combo = (device_id, timestamp)
        if combo in used_combos:
            continue
        used_combos.add(combo)

        # temperature ~ N(22, 5), clamped -10 to 50
        temperature = round(_gauss(22, 5, -10.0, 50.0), 2)
        # humidity ~ uniform(20, 80)
        humidity    = round(random.uniform(20.0, 80.0), 2)
        # pressure ~ N(1013, 20), clamped 900-1100
        pressure    = round(_gauss(1013, 20, 900.0, 1100.0), 2)
        # battery_level: positive int, 1-100
        battery     = random.randint(1, 100)
        # rssi: negative, -110 to -20
        rssi        = random.randint(-110, -20)
        # lat/lon within USA bounds
        lat  = round(random.uniform(24.0, 49.0), 6)
        lon  = round(random.uniform(-125.0, -66.0), 6)
        alt  = round(random.uniform(0.0, 3000.0), 1)

        data.append({
            "record_id":    i,
            "device_id":    device_id,
            "sensor_id":    f"SENS-{random.randint(1000, 9999)}",
            "timestamp":    timestamp,
            "temperature":  temperature,
            "humidity":     humidity,
            "pressure":     pressure,
            "battery_level": battery,
            "rssi":         rssi,
            "latitude":     lat,
            "longitude":    lon,
            "altitude":     alt,
            "quality_flag": random.choice(quality_flags),
            "sensor_type":  random.choice(sensor_types),
            "protocol":     random.choice(protocols),
        })

    return data


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

GENERATORS: dict[str, Any] = {
    "basic":       generate_basic_data,
    "ecommerce":   generate_ecommerce_data,
    "healthcare":  generate_healthcare_data,
    "finance":     generate_finance_data,
    "saas":        generate_saas_data,
    "iot":         generate_iot_data,
}

DEFAULT_FILENAMES: dict[str, str] = {
    "basic":       "data.csv",
    "ecommerce":   "orders.csv",
    "healthcare":  "patients.csv",
    "finance":     "transactions.csv",
    "saas":        "users.csv",
    "iot":         "sensor_data.csv",
}

DEFAULT_ROWS: dict[str, int] = {
    "basic":       1000,
    "ecommerce":   1000,
    "healthcare":  1000,
    "finance":     1000,
    "saas":        1000,
    "iot":         1000,
}


def generate_sample_data(
    template: str,
    output_path: Path | str,
    num_rows: int | None = None,
) -> Path:
    """Generate sample data for a template and save to CSV.

    Args:
        template: Template name (basic, ecommerce, healthcare, finance, saas, iot)
        output_path: Path where the CSV file will be saved
        num_rows: Number of sample rows to generate (defaults to 1 000)

    Returns:
        Path to the generated CSV file

    Raises:
        ValueError: If template is not recognised
    """
    if template not in GENERATORS:
        raise ValueError(f"Unknown template: {template}. Available: {', '.join(GENERATORS.keys())}")

    if num_rows is None:
        num_rows = DEFAULT_ROWS.get(template, 1000)

    data = GENERATORS[template](num_rows)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if data:
        fieldnames = list(data[0].keys())
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)

    return output_path


def get_default_filename(template: str) -> str:
    """Get the default data filename for a template."""
    return DEFAULT_FILENAMES.get(template, "data.csv")
