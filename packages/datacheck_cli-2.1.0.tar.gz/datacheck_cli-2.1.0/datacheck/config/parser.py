"""Configuration parser with environment variable support."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml

from datacheck.exceptions import ConfigurationError


class ConfigParser:
    """Parse configuration with environment variable substitution.

    Supports:
    - ${VAR} - Required environment variable
    - ${VAR:-default} - Environment variable with default value
    - Config inheritance via 'extends' key

    Example:
        >>> parser = ConfigParser()
        >>> config = parser.load("config.yaml")
        >>> # With DB_HOST=localhost in environment:
        >>> # host: ${DB_HOST} becomes host: localhost
    """

    # Pattern to match ${VAR} or ${VAR:-default}
    ENV_VAR_PATTERN = re.compile(r"\$\{([^}]+)\}")

    def load(
        self,
        config_path: str | Path,
        resolve_env: bool = True,
        resolve_extends: bool = True,
    ) -> dict[str, Any]:
        """
        Load and parse config file.

        Args:
            config_path: Path to config file
            resolve_env: Whether to substitute environment variables
            resolve_extends: Whether to resolve config inheritance

        Returns:
            Parsed config dictionary with env vars substituted

        Raises:
            ConfigurationError: If config file doesn't exist or required
                environment variable is missing
            yaml.YAMLError: If YAML is invalid
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise ConfigurationError(f"Config file not found: {config_path}")

        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        if config is None:
            return {}

        # Substitute environment variables
        if resolve_env:
            config = self._substitute_env_vars(config)

        # Handle inheritance
        if resolve_extends and "extends" in config:
            config = self._handle_inheritance(config, config_path)

        result: dict[str, Any] = config
        return result

    def load_string(
        self, yaml_string: str, base_path: str | Path | None = None
    ) -> dict[str, Any]:
        """
        Load config from YAML string.

        Args:
            yaml_string: YAML content as string
            base_path: Base path for resolving 'extends' paths

        Returns:
            Parsed config dictionary
        """
        config = yaml.safe_load(yaml_string)

        if config is None:
            return {}

        # Substitute environment variables
        config = self._substitute_env_vars(config)

        # Handle inheritance
        if "extends" in config and base_path:
            config = self._handle_inheritance(config, Path(base_path))

        result: dict[str, Any] = config
        return result

    def _substitute_env_vars(self, obj: Any) -> Any:
        """
        Recursively substitute environment variables.

        Args:
            obj: Object to process (dict, list, or string)

        Returns:
            Object with env vars substituted
        """
        if isinstance(obj, str):
            return self._substitute_string(obj)
        elif isinstance(obj, dict):
            return {k: self._substitute_env_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._substitute_env_vars(item) for item in obj]
        else:
            return obj

    def _substitute_string(self, value: str) -> str:
        """
        Substitute environment variables in string.

        Supports:
        - ${VAR} - Required variable (returns empty string if not set)
        - ${VAR:-default} - Variable with default value

        Args:
            value: String with possible ${VAR} placeholders

        Returns:
            String with variables substituted
        """

        def replacer(match: re.Match) -> str:
            """Replace a single ${VAR} or ${VAR:-default} match with its resolved value."""
            var_expr = match.group(1)

            # Check for default value syntax: ${VAR:-default}
            if ":-" in var_expr:
                var_name, default_value = var_expr.split(":-", 1)
                var_name = var_name.strip()
                default_value = default_value.strip()
                return os.getenv(var_name, default_value)
            else:
                # Variable without default - return empty string if not set
                var_name = var_expr.strip()
                return os.getenv(var_name, "")

        return self.ENV_VAR_PATTERN.sub(replacer, value)

    def _handle_inheritance(
        self, config: dict[str, Any], config_path: Path
    ) -> dict[str, Any]:
        """
        Handle config inheritance (extends).

        Args:
            config: Current config with 'extends' key
            config_path: Path to current config file

        Returns:
            Merged config with inheritance applied
        """
        extends_path = config["extends"]

        # Resolve relative path based on current config location
        if not Path(extends_path).is_absolute():
            extends_path = config_path.parent / extends_path

        extends_path = Path(extends_path)

        if not extends_path.exists():
            raise ConfigurationError(
                f"Extended config not found: {extends_path} "
                f"(referenced from {config_path})"
            )

        # Load base config (recursively handles its own inheritance)
        base_config = self.load(extends_path)

        # Create copy of current config without 'extends'
        current_config = {k: v for k, v in config.items() if k != "extends"}

        # Deep merge: current config overrides base config
        merged = self._deep_merge(base_config, current_config)

        return merged

    def _deep_merge(
        self, base: dict[str, Any], override: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Deep merge two dictionaries.

        Rules:
        - Override values replace base values
        - Nested dicts are merged recursively
        - Lists are extended (appended)

        Args:
            base: Base dictionary
            override: Override dictionary

        Returns:
            Merged dictionary
        """
        result = base.copy()

        for key, value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                # Recursively merge nested dicts
                result[key] = self._deep_merge(result[key], value)
            elif (
                key in result
                and isinstance(result[key], list)
                and isinstance(value, list)
            ):
                # Extend lists
                result[key] = result[key] + value
            else:
                # Override value
                result[key] = value

        return result

    def resolve_extends(self, config_path: str | Path) -> list[Path]:
        """
        Get the chain of extended config files.

        Useful for debugging inheritance.

        Args:
            config_path: Path to config file

        Returns:
            List of config paths in inheritance order (base first)
        """
        config_path = Path(config_path)
        chain: list[Path] = []

        current_path = config_path
        visited: set[Path] = set()

        while current_path:
            if current_path in visited:
                raise ConfigurationError(f"Circular inheritance detected: {current_path}")

            visited.add(current_path)
            chain.insert(0, current_path)

            with open(current_path, encoding="utf-8") as f:
                config = yaml.safe_load(f)

            if config and "extends" in config:
                extends_path = config["extends"]
                if not Path(extends_path).is_absolute():
                    extends_path = current_path.parent / extends_path
                current_path = Path(extends_path)
            else:
                break

        return chain

    def get_env_vars(self, config_path: str | Path) -> dict[str, str | None]:
        """
        Get all environment variables referenced in config.

        Args:
            config_path: Path to config file

        Returns:
            Dict of variable names to default values (None if no default)
        """
        config_path = Path(config_path)

        with open(config_path, encoding="utf-8") as f:
            content = f.read()

        # Find all ${VAR} or ${VAR:-default} patterns
        matches = self.ENV_VAR_PATTERN.findall(content)

        env_vars: dict[str, str | None] = {}
        for match in matches:
            # Extract variable name and default value
            if ":-" in match:
                var_name, default_value = match.split(":-", 1)
                var_name = var_name.strip()
                default_value = default_value.strip()
                env_vars[var_name] = default_value
            else:
                var_name = match.strip()
                env_vars[var_name] = None

        return env_vars


__all__ = ["ConfigParser"]
