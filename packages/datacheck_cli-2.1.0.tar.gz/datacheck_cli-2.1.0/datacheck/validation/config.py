"""Configuration parsing for validation rules."""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

import pandas as pd

from datacheck.validation.rules import (
    Rule,
    Severity,
    NotNullRule,
    UniqueRule,
    RangeRule,
    RegexRule,
    EnumRule,
    LengthRule,
    TypeRule,
    MaxAgeRule,
    TimestampRangeRule,
    NoFutureTimestampsRule,
    DateFormatValidRule,
    ForeignKeyExistsRule,
    SumEqualsRule,
    UniqueCombinationRule,
)
from datacheck.exceptions import ConfigurationError


@dataclass
class RuleConfig:
    """Configuration for a single validation rule."""
    rule_type: str
    columns: list[str] | None = None
    severity: str = "error"
    name: str | None = None
    params: dict[str, Any] = field(default_factory=dict)


def load_config(path: str | Path) -> dict[str, Any]:
    """Load configuration from a YAML file.

    Args:
        path: Path to YAML config file

    Returns:
        Parsed configuration dictionary

    Raises:
        ConfigurationError: If file not found or invalid YAML
    """
    path = Path(path)

    if not path.exists():
        raise ConfigurationError(f"Config file not found: {path}")

    try:
        with open(path) as f:
            config = yaml.safe_load(f)
            return config or {}
    except yaml.YAMLError as e:
        raise ConfigurationError(f"Invalid YAML in config file: {e}")


def parse_severity(severity_str: str) -> Severity:
    """Parse severity string to Severity enum.

    Args:
        severity_str: Severity string (error, warning, info)

    Returns:
        Severity enum value
    """
    severity_map = {
        "error": Severity.ERROR,
        "warning": Severity.WARNING,
        "info": Severity.INFO,
    }
    return severity_map.get(severity_str.lower(), Severity.ERROR)


def parse_rule_config(rule_dict: dict[str, Any]) -> RuleConfig:
    """Parse a single rule configuration.

    Args:
        rule_dict: Dictionary with rule configuration

    Returns:
        RuleConfig object
    """
    rule_type = rule_dict.get("type") or rule_dict.get("rule")
    if not rule_type:
        raise ConfigurationError("Rule must have 'type' or 'rule' field")

    columns = rule_dict.get("columns")
    if isinstance(columns, str):
        columns = [columns]

    severity = rule_dict.get("severity", "error")
    name = rule_dict.get("name")

    # Extract rule-specific parameters
    excluded_keys = {"type", "rule", "columns", "severity", "name"}
    params = {k: v for k, v in rule_dict.items() if k not in excluded_keys}

    return RuleConfig(
        rule_type=rule_type,
        columns=columns,
        severity=severity,
        name=name,
        params=params,
    )


def create_rule_from_config(rule_config: RuleConfig) -> Rule:
    """Create a Rule instance from RuleConfig.

    Args:
        rule_config: Rule configuration

    Returns:
        Rule instance

    Raises:
        ConfigurationError: If rule type is unknown
    """
    severity = parse_severity(rule_config.severity)
    rule_type = rule_config.rule_type.lower().replace("_", "").replace("-", "")

    # Map rule types to classes
    if rule_type in ("notnull", "notnulls", "required"):
        return NotNullRule(
            columns=rule_config.columns,
            severity=severity,
            name=rule_config.name or "not_null",
        )

    elif rule_type in ("unique", "distinct"):
        return UniqueRule(
            columns=rule_config.columns,
            severity=severity,
            name=rule_config.name or "unique",
        )

    elif rule_type in ("range", "between"):
        return RangeRule(
            columns=rule_config.columns,
            min_value=rule_config.params.get("min"),
            max_value=rule_config.params.get("max"),
            severity=severity,
            name=rule_config.name or "range",
        )

    elif rule_type in ("regex", "pattern", "match"):
        pattern = rule_config.params.get("pattern", ".*")
        return RegexRule(
            columns=rule_config.columns,
            pattern=pattern,
            severity=severity,
            name=rule_config.name or "regex",
        )

    elif rule_type in ("type", "dtype"):
        expected_type = rule_config.params.get("expected") or rule_config.params.get("value", "string")
        return TypeRule(
            columns=rule_config.columns,
            expected_type=expected_type,
            severity=severity,
            name=rule_config.name or "type",
        )

    elif rule_type in ("enum", "isin", "allowed", "values"):
        values = rule_config.params.get("values", [])
        if isinstance(values, str):
            values = [v.strip() for v in values.split(",")]
        return EnumRule(
            columns=rule_config.columns,
            allowed_values=set(values),
            severity=severity,
            name=rule_config.name or "enum",
        )

    elif rule_type in ("length", "strlen"):
        return LengthRule(
            columns=rule_config.columns,
            min_length=rule_config.params.get("min"),
            max_length=rule_config.params.get("max"),
            severity=severity,
            name=rule_config.name or "length",
        )

    elif rule_type in ("minlength",):
        # CLI shorthand: min_length: 3 → LengthRule(min_length=3)
        val = rule_config.params.get("value")
        return LengthRule(
            columns=rule_config.columns,
            min_length=val,
            severity=severity,
            name=rule_config.name or "length",
        )

    elif rule_type in ("maxlength",):
        # CLI shorthand: max_length: 50 → LengthRule(max_length=50)
        val = rule_config.params.get("value")
        return LengthRule(
            columns=rule_config.columns,
            max_length=val,
            severity=severity,
            name=rule_config.name or "length",
        )

    elif rule_type in ("allowedvalues",):
        # CLI alias: allowed_values → EnumRule
        values = rule_config.params.get("values", [])
        if isinstance(values, str):
            values = [v.strip() for v in values.split(",")]
        return EnumRule(
            columns=rule_config.columns,
            allowed_values=set(values),
            severity=severity,
            name=rule_config.name or "enum",
        )

    elif rule_type in ("dateformat",):
        # CLI alias: date_format → DateFormatValidRule
        fmt = rule_config.params.get("format", "%Y-%m-%d")
        return DateFormatValidRule(
            columns=rule_config.columns,
            format_string=fmt,
            severity=severity,
            name=rule_config.name or "date_format_valid",
        )

    elif rule_type in ("daterange",):
        # CLI alias: date_range → TimestampRangeRule
        return TimestampRangeRule(
            columns=rule_config.columns,
            min_timestamp=rule_config.params.get("min", "2000-01-01"),
            max_timestamp=rule_config.params.get("max", "2099-12-31"),
            severity=severity,
            name=rule_config.name or "timestamp_range",
        )

    # Temporal
    elif rule_type in ("maxage", "freshness"):
        return MaxAgeRule(
            columns=rule_config.columns,
            duration=rule_config.params.get("duration", "24h"),
            severity=severity,
            name=rule_config.name or "max_age",
        )

    elif rule_type in ("timestamprange",):
        return TimestampRangeRule(
            columns=rule_config.columns,
            min_timestamp=rule_config.params.get("min", "2000-01-01"),
            max_timestamp=rule_config.params.get("max", "2099-12-31"),
            severity=severity,
            name=rule_config.name or "timestamp_range",
        )

    elif rule_type in ("nofuturetimestamps", "nofuture"):
        return NoFutureTimestampsRule(
            columns=rule_config.columns,
            severity=severity,
            name=rule_config.name or "no_future_timestamps",
        )

    elif rule_type in ("dateformatvalid", "dateformat"):
        return DateFormatValidRule(
            columns=rule_config.columns,
            format_string=rule_config.params.get("format", "%Y-%m-%d"),
            severity=severity,
            name=rule_config.name or "date_format_valid",
        )

    # Relationship / Composite
    elif rule_type in ("foreignkeyexists", "foreignkey", "fk"):
        ref_data = rule_config.params.get("reference_data")
        ref_column = rule_config.params.get("reference_column", "")
        reference_df = pd.DataFrame(ref_data) if ref_data else pd.DataFrame()
        return ForeignKeyExistsRule(
            columns=rule_config.columns,
            reference_df=reference_df,
            reference_column=ref_column,
            severity=severity,
            name=rule_config.name or "foreign_key_exists",
        )

    elif rule_type in ("sumequals", "sum"):
        return SumEqualsRule(
            column=rule_config.params.get("target_column", ""),
            column_a=rule_config.params.get("column_a", ""),
            column_b=rule_config.params.get("column_b", ""),
            tolerance=rule_config.params.get("tolerance", 0.01),
            severity=severity,
            name=rule_config.name or "sum_equals",
        )

    elif rule_type in ("uniquecombination", "compositeunique"):
        return UniqueCombinationRule(
            columns=rule_config.columns,
            severity=severity,
            name=rule_config.name or "unique_combination",
        )

    else:
        raise ConfigurationError(f"Unknown rule type: {rule_config.rule_type}")


def _convert_cli_check_to_rules(check: dict[str, Any]) -> list[Rule]:
    """Convert a single CLI-format check into validation API Rule instances.

    CLI format (checks-based, single column per check):
        - name: id_check
          column: id
          rules:
            not_null: true
            unique: true
            min: 0

    This function creates one Rule per rule-type entry, all targeting
    the same column wrapped in a list for the multi-column API.

    Args:
        check: A single check dictionary from CLI-format YAML

    Returns:
        List of Rule instances
    """
    column = check.get("column")
    check_name = check.get("name", "check")
    check_rules = check.get("rules", {})

    if not column:
        raise ConfigurationError(f"Check '{check_name}' missing 'column' field")
    if not check_rules:
        raise ConfigurationError(f"Check '{check_name}' missing 'rules' field")

    columns = [column]
    rules: list[Rule] = []

    for rule_type, rule_params in check_rules.items():
        # Skip disabled rules (e.g. not_null: false)
        if rule_params is False:
            continue

        # Build a RuleConfig and delegate to create_rule_from_config
        params: dict[str, Any] = {}

        if rule_type in ("min", "max"):
            # CLI uses separate min/max keys; map to RangeRule
            # Collect both if present
            min_val = check_rules.get("min")
            max_val = check_rules.get("max")
            # Avoid duplicating — only create on the first of min/max encountered
            if rule_type == "max" and "min" in check_rules:
                continue  # Already handled when we hit "min"
            rc = RuleConfig(
                rule_type="range",
                columns=columns,
                name=check_name,
                params={"min": min_val, "max": max_val},
            )
            rules.append(create_rule_from_config(rc))
            continue

        if isinstance(rule_params, dict):
            params = rule_params
        elif isinstance(rule_params, list):
            params = {"values": rule_params}
        elif rule_params is not True and rule_params is not None:
            # Scalar value — map to the appropriate param based on rule type
            scalar_param_map = {
                "regex": "pattern",
                "type": "expected",
                "max_age": "duration",
                "date_format_valid": "format",
                "allowed_values": "values",
            }
            param_key = scalar_param_map.get(rule_type, "value")
            if rule_type == "allowed_values" and isinstance(rule_params, list):
                params = {"values": rule_params}
            else:
                params = {param_key: rule_params}

        rc = RuleConfig(
            rule_type=rule_type,
            columns=columns,
            name=check_name,
            params=params,
        )
        try:
            rules.append(create_rule_from_config(rc))
        except ConfigurationError as e:
            # Skip template-only directives (e.g. use_snippet) that aren't
            # real rule types rather than failing the entire config load.
            if "Unknown rule type" in str(e):
                continue
            raise
        except Exception as e:
            raise ConfigurationError(
                f"Error creating rule '{rule_type}' for check '{check_name}': {e}"
            )

    return rules


def parse_rules_config(config: dict[str, Any]) -> list[Rule]:
    """Parse rules from a configuration dictionary.

    Supports both config formats:

    **CLI format** (checks-based, used by ``datacheck validate``):
        checks:
          - name: id_check
            column: id
            rules:
              not_null: true
              unique: true

    **Python API format** (rules-based):
        rules:
          - type: not_null
            columns: [id]
            severity: error

    The format is auto-detected based on whether the config contains
    a ``checks`` key (CLI format) or a ``rules`` key (API format).

    Args:
        config: Configuration dictionary

    Returns:
        List of Rule instances
    """
    rules: list[Rule] = []

    # Auto-detect format: CLI uses "checks", Python API uses "rules"
    checks_config = config.get("checks")
    rules_config = config.get("rules") or config.get("validation", {}).get("rules", [])

    # CLI format: checks-based
    if checks_config and isinstance(checks_config, list):
        for check in checks_config:
            try:
                check_rules = _convert_cli_check_to_rules(check)
                rules.extend(check_rules)
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(
                    f"Error parsing check '{check.get('name', '?')}': {e}"
                )
        return rules

    # Python API format: rules-based
    if rules_config:
        for rule_dict in rules_config:
            try:
                rule_config = parse_rule_config(rule_dict)
                rule = create_rule_from_config(rule_config)
                rules.append(rule)
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing rule: {e}")

    return rules


def generate_config_template() -> str:
    """Generate a template configuration file.

    Returns:
        YAML string with example configuration
    """
    template = """# DataCheck Validation Configuration
# Version: 1.0

# Source configuration (optional)
source:
  type: local  # local, s3, gs, az
  path: data.csv

# Validation rules
rules:
  # Check for null values
  - type: not_null
    columns: [id, name]
    severity: error

  # Check for unique values
  - type: unique
    columns: [id]
    severity: error

  # Check numeric range
  - type: range
    columns: [age]
    min: 0
    max: 150
    severity: warning

  # Check pattern (regex)
  - type: regex
    columns: [email]
    pattern: "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\\\.[a-zA-Z0-9-.]+$"
    severity: error

  # Check allowed values
  - type: enum
    columns: [status]
    values: [active, inactive, pending]
    severity: error

  # Check string length
  - type: length
    columns: [username]
    min: 3
    max: 50
    severity: warning

  # Check data type
  - type: type
    columns: [created_at]
    expected: datetime
    severity: info

# Output configuration
output:
  format: table  # table, json, html
  # file: report.json  # Optional output file
"""
    return template
