"""Validation rules for the DataCheck Python API.

This module provides multi-column, severity-aware rule wrappers around the
engine rules in ``datacheck.rules``. All validation logic is implemented once
in the engine layer; this module adapts that logic for the programmatic
Python API (multi-column support, severity levels, builder pattern).

Both the CLI (YAML-driven) and the Python API now share the same underlying
validation logic, ensuring consistent behavior across both interfaces.
"""
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import pandas as pd

from datacheck.results import RuleResult as EngineRuleResult

# Engine rule imports — single source of truth for validation logic
from datacheck.rules.null_rules import NotNullRule as _EngineNotNullRule
from datacheck.rules.composite_rules import (
    DataTypeRule as _EngineDataTypeRule,
    ForeignKeyExistsRule as _EngineForeignKeyExistsRule,
    SumEqualsRule as _EngineSumEqualsRule,
    UniqueCombinationRule as _EngineUniqueCombinationRule,
    UniqueRule as _EngineUniqueRule,
)
from datacheck.rules.numeric_rules import (
    MinMaxRule as _EngineMinMaxRule,
)
from datacheck.rules.string_rules import (
    AllowedValuesRule as _EngineAllowedValuesRule,
    LengthRule as _EngineLengthRule,
    RegexRule as _EngineRegexRule,
)
from datacheck.rules.temporal_rules import (
    MaxAgeRule as _EngineMaxAgeRule,
    TimestampRangeRule as _EngineTimestampRangeRule,
    NoFutureTimestampsRule as _EngineNoFutureTimestampsRule,
    DateFormatValidRule as _EngineDateFormatValidRule,
)


class Severity(Enum):
    """Severity levels for validation rules."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class RuleResult:
    """Result of a single rule validation."""
    rule_name: str
    column: str | None
    passed: bool
    severity: Severity
    message: str
    failed_count: int = 0
    total_count: int = 0
    failed_rows: list[int] = field(default_factory=list)
    failed_values: list[Any] = field(default_factory=list)

    @property
    def pass_rate(self) -> float:
        """Calculate pass rate as percentage."""
        if self.total_count == 0:
            return 100.0
        return ((self.total_count - self.failed_count) / self.total_count) * 100


def _engine_to_api_result(
    engine_result: EngineRuleResult,
    severity: Severity,
    rule_type_label: str | None = None,
) -> RuleResult:
    """Convert an engine RuleResult to a validation API RuleResult."""
    label = rule_type_label or engine_result.rule_type or engine_result.rule_name

    if engine_result.error:
        message = engine_result.error
    elif engine_result.passed:
        message = f"Column '{engine_result.column}' passed {label} check"
    else:
        failed = engine_result.failed_rows
        message = (
            f"Column '{engine_result.column}' has {failed} "
            f"failing rows ({label})"
        )

    failed_rows: list[int] = []
    failed_values: list[Any] = []
    if engine_result.failure_details:
        failed_rows = engine_result.failure_details.sample_failures[:100]
        failed_values = engine_result.failure_details.sample_values[:20]

    return RuleResult(
        rule_name=engine_result.rule_name,
        column=engine_result.column,
        passed=engine_result.passed,
        severity=severity,
        message=message,
        failed_count=engine_result.failed_rows,
        total_count=engine_result.total_rows,
        failed_rows=failed_rows,
        failed_values=failed_values,
    )


class Rule(ABC):
    """Abstract base class for validation rules."""

    def __init__(
        self,
        name: str,
        columns: list[str] | None = None,
        severity: Severity = Severity.ERROR,
        description: str | None = None,
    ):
        """Initialize rule.

        Args:
            name: Rule name/identifier
            columns: Columns to apply rule to (None for all columns)
            severity: Severity level for failures
            description: Optional description of the rule
        """
        self.name = name
        self.columns = columns
        self.severity = severity
        self.description = description or self._default_description()

    @abstractmethod
    def _default_description(self) -> str:
        """Return default description for the rule."""
        pass

    @abstractmethod
    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        """Validate the dataframe against this rule.

        Args:
            df: DataFrame to validate

        Returns:
            List of RuleResult objects
        """
        pass

    def _get_columns(self, df: pd.DataFrame) -> list[str]:
        """Get columns to validate."""
        if self.columns:
            return [c for c in self.columns if c in df.columns]
        return list(df.columns)


# ---------------------------------------------------------------------------
# Null / Uniqueness
# ---------------------------------------------------------------------------

class NotNullRule(Rule):
    """Rule to check for null/missing values.

    Delegates to ``datacheck.rules.null_rules.NotNullRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "not_null",
    ):
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return "Check that values are not null"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineNotNullRule(name=self.name, column=col)
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "not_null")
            )
        return results


class UniqueRule(Rule):
    """Rule to check for unique values.

    Delegates to ``datacheck.rules.composite_rules.UniqueRule``.
    Null values are excluded from duplicate checking.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "unique",
    ):
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return "Check that values are unique"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineUniqueRule(name=self.name, column=col)
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "unique")
            )
        return results


# ---------------------------------------------------------------------------
# Numeric
# ---------------------------------------------------------------------------

class RangeRule(Rule):
    """Rule to check values are within a range.

    Delegates to ``datacheck.rules.numeric_rules.MinMaxRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        min_value: int | float | None = None,
        max_value: int | float | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "range",
    ):
        self.min_value = min_value
        self.max_value = max_value
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        parts = []
        if self.min_value is not None:
            parts.append(f">= {self.min_value}")
        if self.max_value is not None:
            parts.append(f"<= {self.max_value}")
        return f"Check that values are {' and '.join(parts)}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            if not pd.api.types.is_numeric_dtype(df[col]):
                continue
            engine_rule = _EngineMinMaxRule(
                name=self.name, column=col,
                min_value=self.min_value, max_value=self.max_value,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "range")
            )
        return results


# ---------------------------------------------------------------------------
# String / Pattern
# ---------------------------------------------------------------------------

class RegexRule(Rule):
    """Rule to check values match a regex pattern.

    Delegates to ``datacheck.rules.string_rules.RegexRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        pattern: str = ".*",
        severity: Severity = Severity.ERROR,
        name: str = "regex",
    ):
        self.pattern = pattern
        self._compiled = re.compile(pattern)
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check that values match pattern: {self.pattern}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineRegexRule(
                name=self.name, column=col, pattern=self.pattern,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "regex")
            )
        return results


class EnumRule(Rule):
    """Rule to check values are in an allowed set.

    Delegates to ``datacheck.rules.string_rules.AllowedValuesRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        allowed_values: set[Any] | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "enum",
    ):
        self.allowed_values = set(allowed_values) if allowed_values else set()
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        values_str = ", ".join(str(v) for v in list(self.allowed_values)[:5])
        if len(self.allowed_values) > 5:
            values_str += ", ..."
        return f"Check that values are in: [{values_str}]"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineAllowedValuesRule(
                name=self.name, column=col,
                allowed_values=list(self.allowed_values),
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "enum")
            )
        return results


class LengthRule(Rule):
    """Rule to check string length.

    Delegates to ``datacheck.rules.string_rules.LengthRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        min_length: int | None = None,
        max_length: int | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "length",
    ):
        self.min_length = min_length
        self.max_length = max_length
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        parts = []
        if self.min_length is not None:
            parts.append(f"min_length={self.min_length}")
        if self.max_length is not None:
            parts.append(f"max_length={self.max_length}")
        return f"Check string length ({', '.join(parts)})"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineLengthRule(
                name=self.name, column=col,
                min_length=self.min_length, max_length=self.max_length,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "length")
            )
        return results


# ---------------------------------------------------------------------------
# Type checking
# ---------------------------------------------------------------------------

class TypeRule(Rule):
    """Rule to check column data types.

    Delegates to ``datacheck.rules.composite_rules.DataTypeRule``.
    """

    VALID_TYPES = {
        "string": (str, object),
        "int": (int, "int64", "int32"),
        "float": (float, "float64", "float32"),
        "bool": (bool, "bool"),
        "datetime": ("datetime64[ns]",),
        "date": ("datetime64[ns]",),
    }

    def __init__(
        self,
        columns: list[str] | None = None,
        expected_type: str = "string",
        severity: Severity = Severity.ERROR,
        name: str = "type",
    ):
        self.expected_type = expected_type.lower()
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check that column type is {self.expected_type}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        # Map validation API type names to engine type names
        engine_type = self.expected_type
        if engine_type == "datetime":
            engine_type = "date"
        for col in self._get_columns(df):
            engine_rule = _EngineDataTypeRule(
                name=self.name, column=col, expected_type=engine_type,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "type")
            )
        return results


# ---------------------------------------------------------------------------
# Temporal
# ---------------------------------------------------------------------------

class MaxAgeRule(Rule):
    """Rule to check data freshness.

    Delegates to ``datacheck.rules.temporal_rules.MaxAgeRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        duration: str = "24h",
        severity: Severity = Severity.ERROR,
        name: str = "max_age",
    ):
        self.duration = duration
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check data is not older than {self.duration}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineMaxAgeRule(
                name=self.name, column=col, duration=self.duration,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "max_age")
            )
        return results


class TimestampRangeRule(Rule):
    """Rule to check timestamps are within a range.

    Delegates to ``datacheck.rules.temporal_rules.TimestampRangeRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        min_timestamp: str = "2000-01-01",
        max_timestamp: str = "2099-12-31",
        severity: Severity = Severity.ERROR,
        name: str = "timestamp_range",
    ):
        self.min_timestamp = min_timestamp
        self.max_timestamp = max_timestamp
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check timestamps between {self.min_timestamp} and {self.max_timestamp}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineTimestampRangeRule(
                name=self.name, column=col,
                min_timestamp=self.min_timestamp,
                max_timestamp=self.max_timestamp,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "timestamp_range")
            )
        return results


class NoFutureTimestampsRule(Rule):
    """Rule to check no timestamps are in the future.

    Delegates to ``datacheck.rules.temporal_rules.NoFutureTimestampsRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "no_future_timestamps",
    ):
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return "Check that no timestamps are in the future"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineNoFutureTimestampsRule(
                name=self.name, column=col,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "no_future_timestamps")
            )
        return results


class DateFormatValidRule(Rule):
    """Rule to check date format validity.

    Delegates to ``datacheck.rules.temporal_rules.DateFormatValidRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        format_string: str = "%Y-%m-%d",
        severity: Severity = Severity.ERROR,
        name: str = "date_format_valid",
    ):
        self.format_string = format_string
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check dates match format {self.format_string}"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineDateFormatValidRule(
                name=self.name, column=col, format_string=self.format_string,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "date_format_valid")
            )
        return results


# ---------------------------------------------------------------------------
# Relationship / Composite
# ---------------------------------------------------------------------------

class ForeignKeyExistsRule(Rule):
    """Rule to check referential integrity against a reference dataset.

    Delegates to ``datacheck.rules.composite_rules.ForeignKeyExistsRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        reference_df: pd.DataFrame | None = None,
        reference_column: str = "",
        severity: Severity = Severity.ERROR,
        name: str = "foreign_key_exists",
    ):
        self.reference_df = reference_df if reference_df is not None else pd.DataFrame()
        self.reference_column = reference_column
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        return f"Check that values exist in reference column '{self.reference_column}'"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        results = []
        for col in self._get_columns(df):
            engine_rule = _EngineForeignKeyExistsRule(
                name=self.name, column=col,
                reference_df=self.reference_df,
                reference_column=self.reference_column,
            )
            engine_result = engine_rule.validate(df)
            results.append(
                _engine_to_api_result(engine_result, self.severity, "foreign_key_exists")
            )
        return results


class SumEqualsRule(Rule):
    """Rule to check that sum of two columns equals a target column.

    Delegates to ``datacheck.rules.composite_rules.SumEqualsRule``.
    """

    def __init__(
        self,
        column: str = "",
        column_a: str = "",
        column_b: str = "",
        tolerance: float = 0.01,
        severity: Severity = Severity.ERROR,
        name: str = "sum_equals",
    ):
        self.target_column = column
        self.column_a = column_a
        self.column_b = column_b
        self.tolerance = tolerance
        super().__init__(name=name, columns=[column] if column else None, severity=severity)

    def _default_description(self) -> str:
        return (
            f"Check that {self.column_a} + {self.column_b} = {self.target_column} "
            f"(tolerance: {self.tolerance})"
        )

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        engine_rule = _EngineSumEqualsRule(
            name=self.name, column=self.target_column,
            column_a=self.column_a, column_b=self.column_b,
            tolerance=self.tolerance,
        )
        engine_result = engine_rule.validate(df)
        return [_engine_to_api_result(engine_result, self.severity, "sum_equals")]


class UniqueCombinationRule(Rule):
    """Rule to check that combination of columns is unique.

    Delegates to ``datacheck.rules.composite_rules.UniqueCombinationRule``.
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        severity: Severity = Severity.ERROR,
        name: str = "unique_combination",
    ):
        super().__init__(name=name, columns=columns, severity=severity)

    def _default_description(self) -> str:
        cols = ", ".join(self.columns or [])
        return f"Check that combination of [{cols}] is unique"

    def validate(self, df: pd.DataFrame) -> list[RuleResult]:
        cols = self._get_columns(df)
        if not cols:
            return []
        # Use first column as the reporting column
        engine_rule = _EngineUniqueCombinationRule(
            name=self.name, column=cols[0], columns=cols,
        )
        engine_result = engine_rule.validate(df)
        return [_engine_to_api_result(engine_result, self.severity, "unique_combination")]

