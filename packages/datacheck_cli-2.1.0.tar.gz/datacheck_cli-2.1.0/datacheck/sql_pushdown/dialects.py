"""SQL dialect definitions for multi-database aggregate pushdown.

Each Dialect subclass encapsulates the SQL syntax differences for one database
engine: identifier quoting, type casts, string functions, aggregate functions,
temporal expressions, and the set of rules that can be pushed down.

Usage::

    from datacheck.sql_pushdown.dialects import get_dialect

    dialect = get_dialect("mysql")   # → MySQLDialect or None if unsupported
    if dialect:
        sql = builder.build_query(table, where, limit, checks, dialect)
"""

from __future__ import annotations


# ── Base pushable-rule set (supported by every dialect) ───────────────────────
# Rules that rely on dialect-specific functions (regex, percentile, max_age)
# are added per-dialect in their pushable_rules property.
_BASE_RULES: frozenset[str] = frozenset(
    {
        "not_null",
        "boolean",
        "min",
        "max",
        "range",
        "positive",
        "non_negative",
        "allowed_values",
        "unique",
        "unique_combination",
        "sum_equals",
        "min_length",
        "max_length",
        "no_future_timestamps",
        "timestamp_range",
        "date_range",
    }
)


class Dialect:
    """Abstract SQL dialect.  Subclasses override only what differs."""

    name: str = ""

    # ── Identifier quoting ────────────────────────────────────────────────────

    def q(self, name: str) -> str:
        """Return a safely quoted database identifier."""
        return '"' + name.replace('"', '""') + '"'

    # ── Type casts ────────────────────────────────────────────────────────────

    def cast_to_text(self, col: str) -> str:
        """Expression that casts *col* (already quoted) to a text/string type."""
        return f"CAST({col} AS VARCHAR)"

    # ── String functions ──────────────────────────────────────────────────────

    def str_length(self, col: str) -> str:
        """Character-length expression for *col*."""
        return f"LENGTH({col})"

    # ── Temporal expressions ──────────────────────────────────────────────────

    def current_timestamp(self) -> str:
        """SQL expression for the current wall-clock timestamp."""
        return "CURRENT_TIMESTAMP"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* is older than *duration*.

        Returns *None* if the dialect cannot express this in SQL (the rule then
        falls back to the Python path).  The base implementation uses the
        standard ``INTERVAL '…'`` syntax supported by PostgreSQL, Redshift, and
        Snowflake.
        """
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        ts = self.current_timestamp()
        return f"{col} < {ts} - INTERVAL '{interval}'"

    def _duration_to_interval_str(self, duration: str) -> str | None:
        """Convert a duration token (e.g. ``'24h'``) to a standard interval string."""
        s = str(duration).strip().lower()
        unit_map = {"m": "minutes", "h": "hours", "d": "days", "w": "weeks"}
        if s and s[-1] in unit_map:
            return f"{s[:-1]} {unit_map[s[-1]]}"
        return None

    # ── Regex ──────────────────────────────────────────────────────────────────

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        """Inner CASE condition that is TRUE when *col* does NOT match *pattern*.

        Returns *None* if the dialect has no native regex operator.
        """
        return None  # subclasses override

    # ── Concatenation helpers ─────────────────────────────────────────────────

    def sep1(self) -> str:
        """SQL expression for the CHR(1) / CHAR(1) separator used in multi-column
        uniqueness checks.  It is a non-printable control character that is
        effectively never present in real data values."""
        return "CHR(1)"

    # ── LIMIT / TOP ────────────────────────────────────────────────────────────

    def top_clause(self, n: int | None) -> str:
        """Token inserted after SELECT (SQL Server ``TOP n``).  Empty for most DBs."""
        return ""

    def limit_clause(self, n: int | None) -> str:
        """Trailing ``LIMIT n`` clause.  Empty for SQL Server (uses TOP instead)."""
        return f" LIMIT {n}" if n is not None else ""

    # ── Pushable rule set ──────────────────────────────────────────────────────

    @property
    def pushable_rules(self) -> frozenset[str]:
        """Set of rule types that this dialect can handle in SQL."""
        return _BASE_RULES


# ── Concrete dialect implementations ──────────────────────────────────────────

class PostgreSQLDialect(Dialect):
    """PostgreSQL (and any PostgreSQL-wire-compatible DB)."""

    name = "postgresql"

    def q(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def cast_to_text(self, col: str) -> str:
        # PostgreSQL cast operator — also works for ENUM, UUID, etc.
        return f"{col}::text"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "NOW()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        return f"{col} < NOW() - INTERVAL '{interval}'"

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # !~ is the case-sensitive "does not match regex" operator in PostgreSQL.
        # Cast to text so non-text columns (enums, UUIDs) are handled correctly.
        p = pattern.replace("'", "''")
        return f"{col}::text !~ '{p}'"

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age"})


class RedshiftDialect(PostgreSQLDialect):
    """Amazon Redshift — fully PostgreSQL-compatible SQL dialect."""

    name = "redshift"
    # PERCENTILE_CONT syntax is identical to PostgreSQL in Redshift.
    # All other methods inherited from PostgreSQLDialect without change.


class MySQLDialect(Dialect):
    """MySQL 8.0+ / MariaDB."""

    name = "mysql"

    def q(self, name: str) -> str:
        return "`" + name.replace("`", "``") + "`"

    def cast_to_text(self, col: str) -> str:
        return f"CAST({col} AS CHAR)"

    def str_length(self, col: str) -> str:
        # CHAR_LENGTH counts Unicode code points; LENGTH counts bytes.
        return f"CHAR_LENGTH({col})"

    def current_timestamp(self) -> str:
        return "NOW()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # MySQL INTERVAL syntax: NOW() - INTERVAL 24 HOUR  (no quotes, unit unquoted)
        s = str(duration).strip().lower()
        unit_map = {"m": "MINUTE", "h": "HOUR", "d": "DAY", "w": "WEEK"}
        if s and s[-1] in unit_map:
            return f"{col} < NOW() - INTERVAL {s[:-1]} {unit_map[s[-1]]}"
        return None

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # MySQL REGEXP operator performs case-insensitive matching by default.
        p = pattern.replace("'", "''")
        return f"{col} NOT REGEXP '{p}'"

    def sep1(self) -> str:
        return "CHAR(1)"

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age"})


class MSSQLDialect(Dialect):
    """Microsoft SQL Server (T-SQL)."""

    name = "mssql"

    def q(self, name: str) -> str:
        return "[" + name.replace("]", "]]") + "]"

    def cast_to_text(self, col: str) -> str:
        return f"CAST({col} AS NVARCHAR(MAX))"

    def str_length(self, col: str) -> str:
        # SQL Server uses LEN(), not LENGTH().
        return f"LEN({col})"

    def sep1(self) -> str:
        return "CHAR(1)"

    def current_timestamp(self) -> str:
        return "GETDATE()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # T-SQL: DATEADD(unit, -n, GETDATE())
        s = str(duration).strip().lower()
        unit_map = {"m": "minute", "h": "hour", "d": "day", "w": "week"}
        if s and s[-1] in unit_map:
            return f"{col} < DATEADD({unit_map[s[-1]]}, -{s[:-1]}, GETDATE())"
        return None

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # SQL Server has no native regex operator.
        return None

    def top_clause(self, n: int | None) -> str:
        # SQL Server uses SELECT TOP N instead of LIMIT.
        return f"TOP {n} " if n is not None else ""

    def limit_clause(self, n: int | None) -> str:
        # No LIMIT in T-SQL — rows are bounded by TOP in the SELECT clause.
        return ""

    @property
    def pushable_rules(self) -> frozenset[str]:
        # No regex (no native operator), no percentile (window function only).
        return _BASE_RULES | frozenset({"max_age"})


class SnowflakeDialect(Dialect):
    """Snowflake Data Cloud."""

    name = "snowflake"

    def q(self, name: str) -> str:
        # Snowflake uses double-quotes for case-sensitive identifiers.
        return '"' + name.replace('"', '""') + '"'

    def cast_to_text(self, col: str) -> str:
        return f"TO_VARCHAR({col})"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "CURRENT_TIMESTAMP()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # Snowflake supports standard INTERVAL '…' syntax.
        interval = self._duration_to_interval_str(duration)
        if interval is None:
            return None
        return f"{col} < CURRENT_TIMESTAMP() - INTERVAL '{interval}'"

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # Snowflake REGEXP_LIKE(subject, pattern) — negate for violations.
        p = pattern.replace("'", "''")
        return f"NOT REGEXP_LIKE({col}, '{p}')"

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age"})


class BigQueryDialect(Dialect):
    """Google BigQuery (Standard SQL)."""

    name = "bigquery"

    def q(self, name: str) -> str:
        # BigQuery uses backtick-quoted identifiers; escape embedded backticks.
        return "`" + name.replace("\\", "\\\\").replace("`", "\\`") + "`"

    def cast_to_text(self, col: str) -> str:
        return f"CAST({col} AS STRING)"

    def str_length(self, col: str) -> str:
        return f"LENGTH({col})"

    def current_timestamp(self) -> str:
        return "CURRENT_TIMESTAMP()"

    def age_violation_expr(self, col: str, duration: str) -> str | None:
        # BigQuery: TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL n UNIT)
        s = str(duration).strip().lower()
        unit_map = {"m": "MINUTE", "h": "HOUR", "d": "DAY", "w": "WEEK"}
        if s and s[-1] in unit_map:
            return (
                f"{col} < TIMESTAMP_SUB(CURRENT_TIMESTAMP(),"
                f" INTERVAL {s[:-1]} {unit_map[s[-1]]})"
            )
        return None

    def regex_violation_expr(self, col: str, pattern: str) -> str | None:
        # BigQuery REGEXP_CONTAINS(value, regexp) — negate for violations.
        # The r'' prefix is cosmetic in the generated SQL string.
        p = pattern.replace("'", "''")
        return f"NOT REGEXP_CONTAINS({col}, r'{p}')"

    @property
    def pushable_rules(self) -> frozenset[str]:
        return _BASE_RULES | frozenset({"regex", "max_age"})


# ── Dialect registry ──────────────────────────────────────────────────────────

_DIALECT_MAP: dict[str, Dialect] = {
    "postgresql": PostgreSQLDialect(),
    "redshift":   RedshiftDialect(),
    "mysql":      MySQLDialect(),
    "mssql":      MSSQLDialect(),
    "snowflake":  SnowflakeDialect(),
    "bigquery":   BigQueryDialect(),
}

# Source types for which SQL pushdown is available.
PUSHDOWN_CAPABLE_TYPES: frozenset[str] = frozenset(_DIALECT_MAP)


def get_dialect(source_type: str) -> Dialect | None:
    """Return the SQL dialect for *source_type*, or ``None`` if pushdown is not supported."""
    return _DIALECT_MAP.get(source_type)


__all__ = [
    "Dialect",
    "PostgreSQLDialect",
    "RedshiftDialect",
    "MySQLDialect",
    "MSSQLDialect",
    "SnowflakeDialect",
    "BigQueryDialect",
    "PUSHDOWN_CAPABLE_TYPES",
    "get_dialect",
]
