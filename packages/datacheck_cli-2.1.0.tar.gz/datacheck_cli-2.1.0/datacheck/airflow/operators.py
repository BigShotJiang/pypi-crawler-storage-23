"""Airflow operators for DataCheck validation.

Provides two operators for enforcing validation rules in Airflow DAGs:

- DataCheckOperator: Enforce validation rules against configured data sources
- DataCheckSchemaOperator: Enforce schema contracts against saved baselines
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from collections.abc import Sequence

if TYPE_CHECKING:
    import pandas as pd
from pathlib import Path

try:
    from airflow.models import BaseOperator
    from airflow.utils.decorators import apply_defaults
    from airflow.exceptions import AirflowException

    AIRFLOW_AVAILABLE = True
except ImportError:
    # Create mock classes for testing without Airflow
    AIRFLOW_AVAILABLE = False

    import logging

    class BaseOperator:
        """Mock BaseOperator for when Airflow is not installed."""

        def __init__(self, task_id: str, **kwargs):
            """Initialize mock BaseOperator with a task ID and optional attributes."""
            self.task_id = task_id
            self.log = logging.getLogger(f"datacheck.{task_id}")
            for key, value in kwargs.items():
                setattr(self, key, value)

        def execute(self, context: dict[str, Any]) -> Any:
            """Execute the operator (must be overridden by subclasses)."""
            raise NotImplementedError

        def __rshift__(self, other):
            """Support >> operator for task dependencies."""
            return other

        def __lshift__(self, other):
            """Support << operator for task dependencies."""
            return self

    def apply_defaults(func):
        """Mock decorator."""
        return func

    class AirflowException(Exception):
        """Mock AirflowException."""

        pass


class DataCheckOperator(BaseOperator):
    """Operator for running DataCheck validation in Airflow DAGs.

    Uses the full ValidationEngine to run config-based rules against
    data from files or named database sources. Supports sampling,
    parallel execution, and quality thresholds.

    Data source resolution (in order):
        1. ``file_path`` — validate a local or cloud file
        2. ``source_name`` — validate a named source from sources.yaml
        3. Config default — uses ``source`` or ``data_source`` from config

    Examples:
        Validate a file::

            DataCheckOperator(
                task_id="validate_orders",
                config_path="/config/checks.yaml",
                file_path="/data/orders_{{ ds }}.parquet",
            )

        Validate a database table::

            DataCheckOperator(
                task_id="validate_orders",
                config_path="/config/checks.yaml",
                sources_file="/config/sources.yaml",
                source_name="production_db",
                table="orders",
                where="created_at >= '{{ ds }}'",
            )

        With quality thresholds::

            DataCheckOperator(
                task_id="validate_orders",
                config_path="/config/checks.yaml",
                file_path="/data/orders.parquet",
                min_pass_rate=95.0,
                fail_on_error=True,
            )

    Attributes:
        config_path: Path to the DataCheck validation config YAML
        file_path: Path to a data file (CSV, Parquet)
        sources_file: Path to named sources YAML file
        source_name: Named source to validate
        table: Database table name override
        where: SQL WHERE clause for filtering
        query: Custom SQL query (alternative to table)
        parallel: Enable multi-core validation
        workers: Number of worker processes
        min_pass_rate: Minimum rule pass rate to succeed (0-100)
        fail_on_error: Whether to fail the Airflow task on validation failure
        push_results: Whether to push results to XCom
    """

    template_fields: Sequence[str] = (
        "config_path",
        "file_path",
        "sources_file",
        "source_name",
        "table",
        "where",
        "query",
    )
    template_ext: Sequence[str] = (".yaml", ".yml")
    ui_color = "#4CAF50"
    ui_fgcolor = "#FFFFFF"

    @apply_defaults
    def __init__(
        self,
        config_path: str,
        file_path: str | None = None,
        sources_file: str | None = None,
        source_name: str | None = None,
        table: str | None = None,
        where: str | None = None,
        query: str | None = None,
        parallel: bool = False,
        workers: int | None = None,
        min_pass_rate: float = 0.0,
        fail_on_error: bool = True,
        push_results: bool = True,
        **kwargs,
    ):
        """Initialize DataCheckOperator.

        Args:
            config_path: Path to DataCheck validation config YAML (required)
            file_path: Path to data file (CSV, Parquet)
            sources_file: Path to sources YAML file (overrides config)
            source_name: Named source from sources.yaml
            table: Database table name (for database sources)
            where: WHERE clause for filtering (for database sources)
            query: Custom SQL query (alternative to table)
            parallel: Enable parallel execution
            workers: Number of worker processes (default: CPU count)
            min_pass_rate: Minimum pass rate percentage (0-100, 0 = disabled)
            fail_on_error: Whether to raise AirflowException on failure
            push_results: Whether to push results to XCom
            **kwargs: Additional arguments passed to BaseOperator
        """
        super().__init__(**kwargs)
        self.config_path = config_path
        self.file_path = file_path
        self.sources_file = sources_file
        self.source_name = source_name
        self.table = table
        self.where = where
        self.query = query
        self.parallel = parallel
        self.workers = workers
        self.min_pass_rate = min_pass_rate
        self.fail_on_error = fail_on_error
        self.push_results = push_results

    def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """Execute DataCheck validation.

        Args:
            context: Airflow context dictionary

        Returns:
            Validation results dictionary

        Raises:
            AirflowException: If validation fails and fail_on_error is True
        """
        from datacheck.engine import ValidationEngine

        self.log.info(
            f"Running DataCheck validation: config={self.config_path}, "
            f"file={self.file_path}, source={self.source_name}"
        )

        # Initialize engine
        try:
            engine = ValidationEngine(
                config_path=self.config_path,
                sources_file=self.sources_file,
                parallel=self.parallel,
                workers=self.workers,
            )
        except Exception as e:
            raise AirflowException(f"Failed to initialize ValidationEngine: {e}")

        # Run validation based on data source
        try:
            if self.file_path:
                # File-based validation
                summary = engine.validate_file(self.file_path)
            elif self.source_name or engine.config.source:
                # Named source validation
                summary = engine.validate_sources(
                    source_name=self.source_name,
                    table=self.table,
                    where=self.where,
                    query=self.query,
                )
            elif engine.config.data_source is not None:
                # Inline data_source from config
                config_dir = Path(self.config_path).parent
                source_path = config_dir / engine.config.data_source.path
                summary = engine.validate_file(str(source_path))
            else:
                raise AirflowException(
                    "No data source specified. Provide file_path, "
                    "source_name, or a config with data_source/sources_file."
                )
        except AirflowException:
            raise
        except Exception as e:
            raise AirflowException(f"Validation error: {e}")

        # Calculate pass rate
        pass_rate = (
            summary.passed_rules / summary.total_rules * 100
            if summary.total_rules > 0
            else 100.0
        )

        # Check thresholds
        has_thresholds = self.min_pass_rate > 0
        met_pass_rate = pass_rate >= self.min_pass_rate

        # Build results
        results = {
            "config_path": self.config_path,
            "file_path": self.file_path,
            "source": self.source_name,
            "table": self.table,
            "passed": summary.all_passed,
            "pass_rate": pass_rate,
            "total_rules": summary.total_rules,
            "passed_rules": summary.passed_rules,
            "failed_rules": summary.failed_rules,
            "timestamp": context.get("ts"),
        }

        if has_thresholds:
            results["met_pass_rate_threshold"] = met_pass_rate

        # Push to XCom
        if self.push_results:
            context["ti"].xcom_push(key="validation_results", value=results)
            context["ti"].xcom_push(key="passed", value=summary.all_passed)
            context["ti"].xcom_push(key="pass_rate", value=pass_rate)

        self.log.info(
            f"Validation completed — "
            f"{summary.passed_rules}/{summary.total_rules} rules passed "
            f"({pass_rate:.1f}%)"
        )

        # Handle failures
        if self.fail_on_error:
            if has_thresholds:
                # Threshold mode: fail only if thresholds breached
                if not met_pass_rate:
                    raise AirflowException(
                        f"Pass rate {pass_rate:.1f}% below threshold "
                        f"{self.min_pass_rate}%"
                    )
            else:
                # Strict mode: fail if any error-severity rule failed
                if not summary.all_passed:
                    failed = [
                        r.rule_name for r in summary.results if not r.passed
                    ]
                    raise AirflowException(
                        f"Validation failed. "
                        f"Failed rules: {', '.join(failed)}"
                    )

        return results


class DataCheckSchemaOperator(BaseOperator):
    """Operator for detecting schema changes in Airflow DAGs.

    Uses DataCheck's SchemaDetector and SchemaComparator to track
    schema evolution. Compares current data schema against a saved
    baseline. If no baseline exists, captures one automatically.

    Data is loaded using DataCheck's LoaderFactory (supports CSV,
    Parquet) or from named sources for database connections.

    Examples:
        Compare file schema against baseline::

            DataCheckSchemaOperator(
                task_id="schema_check",
                file_path="/data/orders_{{ ds }}.parquet",
                baseline_name="orders",
                fail_on_breaking=True,
            )  # Supports CSV, Parquet, or named database sources

        Compare database table schema::

            DataCheckSchemaOperator(
                task_id="schema_check",
                sources_file="/config/sources.yaml",
                source_name="production_db",
                table="orders",
                baseline_name="orders",
            )

    Attributes:
        file_path: Path to a data file
        sources_file: Path to named sources YAML file
        source_name: Named source to check
        table: Database table name
        query: Custom SQL query (alternative to table)
        baseline_name: Name for the schema baseline
        baseline_dir: Directory to store baseline files
        fail_on_breaking: Whether to fail on breaking schema changes
        push_results: Whether to push results to XCom
    """

    template_fields: Sequence[str] = (
        "file_path",
        "sources_file",
        "source_name",
        "table",
        "query",
        "baseline_name",
    )
    template_ext: Sequence[str] = (".yaml", ".yml")
    ui_color = "#9C27B0"
    ui_fgcolor = "#FFFFFF"

    @apply_defaults
    def __init__(
        self,
        file_path: str | None = None,
        sources_file: str | None = None,
        source_name: str | None = None,
        table: str | None = None,
        query: str | None = None,
        baseline_name: str = "baseline",
        baseline_dir: str = ".datacheck/schemas",
        fail_on_breaking: bool = True,
        push_results: bool = True,
        **kwargs,
    ):
        """Initialize DataCheckSchemaOperator.

        Args:
            file_path: Path to data file (CSV, Parquet)
            sources_file: Path to sources YAML file
            source_name: Named source from sources.yaml
            table: Database table name (for database sources)
            query: Custom SQL query (alternative to table)
            baseline_name: Name for the schema baseline (default: "baseline")
            baseline_dir: Directory to store baseline files
            fail_on_breaking: Whether to raise AirflowException on breaking changes
            push_results: Whether to push results to XCom
            **kwargs: Additional arguments passed to BaseOperator
        """
        super().__init__(**kwargs)
        self.file_path = file_path
        self.sources_file = sources_file
        self.source_name = source_name
        self.table = table
        self.query = query
        self.baseline_name = baseline_name
        self.baseline_dir = baseline_dir
        self.fail_on_breaking = fail_on_breaking
        self.push_results = push_results

    def _load_data(self) -> pd.DataFrame:
        """Load data from file or named source.

        Returns:
            DataFrame loaded from the configured data source

        Raises:
            AirflowException: If no data source is configured or loading fails
        """

        if self.file_path:
            from datacheck.loader import LoaderFactory

            return LoaderFactory.load(self.file_path)

        if self.source_name and self.sources_file:
            from datacheck.config.source import load_sources
            from datacheck.connectors.factory import load_source_data

            sources = load_sources(self.sources_file)
            if self.source_name not in sources:
                raise AirflowException(
                    f"Source '{self.source_name}' not found. "
                    f"Available: {', '.join(sorted(sources.keys()))}"
                )
            return load_source_data(sources[self.source_name], table=self.table, query=self.query)

        raise AirflowException(
            "No data source specified. Provide file_path, "
            "or source_name with sources_file."
        )

    def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """Execute schema detection and comparison.

        If a baseline exists, compares the current schema against it
        and reports changes. If no baseline exists, captures one.

        Args:
            context: Airflow context dictionary

        Returns:
            Schema comparison results dictionary

        Raises:
            AirflowException: If breaking changes detected and fail_on_breaking is True
        """
        from datacheck.schema import SchemaDetector, SchemaComparator, BaselineManager

        self.log.info(
            f"Running schema check: file={self.file_path}, "
            f"source={self.source_name}, baseline={self.baseline_name}"
        )

        # Load data
        try:
            df = self._load_data()
        except AirflowException:
            raise
        except Exception as e:
            raise AirflowException(f"Failed to load data: {e}")

        # Detect current schema
        detector = SchemaDetector()
        source_label = self.file_path or self.source_name or "unknown"
        current_schema = detector.detect(
            df, name=self.baseline_name, source=source_label
        )

        # Manage baseline
        manager = BaselineManager(baseline_dir=self.baseline_dir)

        if manager.baseline_exists(self.baseline_name):
            # Compare against existing baseline
            baseline = manager.load_baseline(self.baseline_name)
            comparator = SchemaComparator()
            comparison = comparator.compare(baseline, current_schema)

            results = {
                "mode": "compare",
                "baseline_name": self.baseline_name,
                "is_compatible": comparison.is_compatible,
                "compatibility_level": comparison.compatibility_level.value,
                "total_changes": len(comparison.changes),
                "breaking_changes": len(comparison.breaking_changes),
                "warning_changes": len(comparison.warning_changes),
                "safe_changes": len(comparison.safe_changes),
                "changes": [
                    {
                        "type": c.change_type.value,
                        "message": c.message,
                        "compatibility": c.compatibility.value,
                    }
                    for c in comparison.changes
                ],
                "columns": current_schema.column_names,
                "row_count": current_schema.row_count,
                "timestamp": context.get("ts"),
            }

            if comparison.changes:
                for change in comparison.changes:
                    self.log.info(
                        f"Schema change: {change.message} "
                        f"[{change.compatibility.value}]"
                    )
            else:
                self.log.info("No schema changes detected")

            # Push to XCom
            if self.push_results:
                context["ti"].xcom_push(key="schema_results", value=results)
                context["ti"].xcom_push(
                    key="schema_compatible", value=comparison.is_compatible
                )

            # Fail on breaking changes
            if not comparison.is_compatible and self.fail_on_breaking:
                breaking = [c.message for c in comparison.breaking_changes]
                raise AirflowException(
                    f"Breaking schema changes detected: {'; '.join(breaking)}"
                )

        else:
            # No baseline exists — capture one
            manager.save_baseline(current_schema, name=self.baseline_name)
            manager.save_to_history(current_schema)

            results = {
                "mode": "capture",
                "baseline_name": self.baseline_name,
                "is_compatible": True,
                "total_changes": 0,
                "breaking_changes": 0,
                "columns": current_schema.column_names,
                "row_count": current_schema.row_count,
                "timestamp": context.get("ts"),
            }

            self.log.info(
                f"Schema baseline '{self.baseline_name}' captured "
                f"({len(current_schema.column_names)} columns)"
            )

            if self.push_results:
                context["ti"].xcom_push(key="schema_results", value=results)
                context["ti"].xcom_push(key="schema_compatible", value=True)

        return results
