"""Validation engine orchestration."""

from pathlib import Path
from typing import Any

import pandas as pd

import warnings

from datacheck.config import ConfigLoader, ValidationConfig
from datacheck.exceptions import ConfigurationError, DataLoadError, ValidationError
from datacheck.loader import LoaderFactory
from datacheck.results import RuleResult, ValidationSummary
from datacheck.rules import RuleFactory


def _collect_needed_columns(checks: list) -> set[str] | None:
    """Return the set of column names needed by all checks.

    Handles multi-column rules (unique_combination, sum_equals) by
    inspecting their rule parameter values.
    """
    cols: set[str] = set()
    for check in checks:
        if check.column:
            cols.add(check.column)
        # Extract extra columns referenced in multi-column rule configs
        for rule_type, rule_value in check.rules.items():
            if rule_type == "unique_combination" and isinstance(rule_value, list):
                cols.update(str(c) for c in rule_value)
            elif rule_type == "sum_equals" and isinstance(rule_value, dict):
                for key in ("column_a", "column_b"):
                    if key in rule_value:
                        cols.add(str(rule_value[key]))
    return cols or None


class ValidationEngine:
    """Engine for orchestrating data validation.

    The ValidationEngine coordinates the entire validation process:
    1. Loads data from various sources (CSV, Parquet, databases)
    2. Loads and parses validation configuration
    3. Creates rule instances from configuration
    4. Executes all rules against the data
    5. Aggregates results into a summary
    """

    def __init__(
        self,
        config: ValidationConfig | None = None,
        config_path: str | Path | None = None,
        parallel: bool = False,
        workers: int | None = None,
        chunk_size: int | None = None,
        show_progress: bool = True,
        notifier: Any = None,
        sources_file: str | Path | None = None,
    ) -> None:
        """Initialize validation engine.

        Args:
            config: Pre-loaded validation configuration (optional)
            config_path: Path to configuration file (optional)
            parallel: Enable parallel execution (default: False)
            workers: Number of worker processes (default: CPU count)
            chunk_size: Rows per chunk for parallel processing (default: 100000)
            show_progress: Show progress bar during parallel execution (default: True)
            notifier: Optional notifier instance (e.g., SlackNotifier) to send results
            sources_file: Path to sources YAML file (overrides config sources_file)

        Raises:
            ConfigurationError: If neither config nor config_path provided, or both provided
        """
        if config is not None and config_path is not None:
            raise ConfigurationError("Cannot provide both config and config_path")

        if config is None and config_path is None:
            # Try to auto-discover config file
            found_config = ConfigLoader.find_config()
            if found_config is None:
                raise ConfigurationError(
                    "No configuration provided and no config file found. "
                    "Searched for: .datacheck.yaml, .datacheck.yml, datacheck.yaml, datacheck.yml"
                )
            config_path = found_config

        if config_path is not None:
            self.config = ConfigLoader.load(config_path)
            self._config_dir = Path(config_path).parent
        else:
            self.config = config  # type: ignore
            self._config_dir = Path.cwd()

        # Store parallel execution settings
        self.parallel = parallel
        self.workers = workers
        self.chunk_size = chunk_size or 100000
        self.show_progress = show_progress

        # Store notifier for sending results
        self.notifier = notifier

        # Load sources if configured
        self._sources: dict[str, Any] | None = None
        effective_sources_file = sources_file or self.config.sources_file
        if effective_sources_file:
            self._load_sources(effective_sources_file)

    def _load_sources(self, sources_file: str | Path) -> None:
        """Load named sources from a YAML file.

        Args:
            sources_file: Path to the sources YAML file (absolute or relative to config dir)
        """
        from datacheck.config.source import load_sources

        sources_path = Path(sources_file)
        if not sources_path.is_absolute():
            sources_path = self._config_dir / sources_path

        self._sources = load_sources(sources_path)

    @property
    def sources(self) -> dict[str, Any] | None:
        """Get loaded source configurations."""
        return self._sources

    def validate_file(
        self,
        file_path: str | Path,
        **loader_kwargs: Any,
    ) -> ValidationSummary:
        """Validate a data file against configured rules.

        Args:
            file_path: Path to the data file to validate
            **loader_kwargs: Additional arguments passed to the data loader.

        Returns:
            ValidationSummary with aggregated results

        Raises:
            DataLoadError: If data cannot be loaded
            ValidationError: If validation fails unexpectedly
        """
        # Collect columns referenced by rules for column pruning (Parquet + CSV)
        file_str = str(file_path)
        if file_str.endswith((".parquet", ".pq", ".csv")) and "columns" not in loader_kwargs:
            columns_needed = _collect_needed_columns(self.config.checks)
            if columns_needed:
                loader_kwargs["columns"] = sorted(columns_needed)

        # Load data
        try:
            df = LoaderFactory.load(file_path, **loader_kwargs)
        except DataLoadError:
            raise
        except Exception as e:
            raise DataLoadError(f"Unexpected error loading data: {e}") from e

        # Validate the loaded data
        summary = self.validate_dataframe(df)

        # Send notification if notifier configured
        if self.notifier:
            try:
                self.notifier.send_summary(summary)
            except Exception as e:
                # Log error but don't fail validation
                warnings.warn(f"Failed to send notification: {e}", RuntimeWarning, stacklevel=2)

        return summary

    def validate_dataframe(self, df: pd.DataFrame) -> ValidationSummary:
        """Validate a DataFrame against configured rules.

        Args:
            df: DataFrame to validate

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ValidationError: If validation fails unexpectedly
        """
        # Build mapping from check name to severity
        severity_map: dict[str, str] = {}
        for check_config in self.config.checks:
            severity_map[check_config.name] = check_config.severity

        # Collect all rules first
        all_rules = []
        for check_config in self.config.checks:
            try:
                rules = RuleFactory.create_rules(check_config)
                all_rules.extend(rules)
            except Exception as e:
                # If rule creation fails, create error result directly
                error_result = RuleResult(
                    rule_name=check_config.name,
                    column=check_config.column,
                    passed=False,
                    total_rows=len(df),
                    error=f"Error creating rules: {e}",
                    severity=check_config.severity,
                )
                # Return early with error if rule creation fails
                return ValidationSummary(results=[error_result])

        use_parallel = self.parallel and len(df) > 10000

        # Execute rules (parallel or sequential)
        if use_parallel:
            from datacheck.parallel import ParallelExecutor

            executor = ParallelExecutor(
                workers=self.workers,
                chunk_size=self.chunk_size,
                show_progress=self.show_progress,
            )
            results = executor.validate_parallel(df, all_rules)
        else:
            # Sequential execution
            results = []
            for rule in all_rules:
                try:
                    result = rule.validate(df)
                    results.append(result)
                except Exception as e:
                    error_result = RuleResult(
                        rule_name=rule.name,
                        column=rule.column,
                        passed=False,
                        total_rows=len(df),
                        error=f"Unexpected error executing rule: {e}",
                    )
                    results.append(error_result)

        # Apply severity from check config to results
        for result in results:
            # check_name contains the original check name
            check_name = result.check_name or result.rule_name
            # Remove only the trailing suffix that factory may add (_min, _max)
            base_name = check_name.removesuffix("_min").removesuffix("_max")
            if base_name in severity_map:
                result.severity = severity_map[base_name]
            elif check_name in severity_map:
                result.severity = severity_map[check_name]

        return ValidationSummary(
            results=results,
            total_rows=len(df),
            total_columns=len(df.columns),
        )

    def validate_sources(
        self,
        source_name: str | None = None,
        table: str | None = None,
        where: str | None = None,
        query: str | None = None,
    ) -> ValidationSummary:
        """Validate data using named source definitions.

        Groups checks by their source, loads data per source, and runs
        the appropriate checks against each dataset.

        Args:
            source_name: Source name override (overrides config source)
            table: Table name override (overrides config table)
            where: WHERE clause for database sources
            query: Custom SQL query for database sources

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ConfigurationError: If sources not loaded or source not found
            DataLoadError: If data loading fails
        """
        from datacheck.config.source import SourceConfig
        from datacheck.connectors.factory import load_source_data

        if self._sources is None:
            raise ConfigurationError(
                "No sources loaded. Specify 'sources_file' in config or via --sources-file"
            )

        # Resolve default source/table from config
        default_source = source_name or self.config.source
        default_table = table or self.config.table

        # Group checks by their effective source
        source_checks: dict[str, list[Any]] = {}
        for check in self.config.checks:
            effective_source = check.source or default_source
            if not effective_source:
                raise ConfigurationError(
                    f"Check '{check.name}' has no source defined. "
                    "Set a top-level 'source' or per-check 'source' in config."
                )
            source_checks.setdefault(effective_source, []).append(check)

        # Pre-validate: verify all sources exist and connections work
        # before running any checks.  This gives a single clear error
        # instead of repeating "connection failed" for every check.
        connection_errors: list[str] = []
        for src_name in source_checks:
            if src_name not in self._sources:
                connection_errors.append(
                    f"Source '{src_name}' not found in sources file. "
                    f"Available sources: {', '.join(sorted(self._sources.keys()))}"
                )
                continue

            source_config: SourceConfig = self._sources[src_name]

            if source_config.is_database:
                # Test database connectivity
                try:
                    from datacheck.connectors.factory import create_connector

                    connector = create_connector(source_config)
                    connector.connect()
                    connector.disconnect()
                except Exception as e:
                    connection_errors.append(
                        f"Source '{src_name}' ({source_config.type}): "
                        f"Connection failed — {e}"
                    )
            elif source_config.is_file:
                # Test file accessibility
                from pathlib import Path as _Path

                file_path = source_config.connection.get("path", "")
                if file_path and not _Path(file_path).exists():
                    connection_errors.append(
                        f"Source '{src_name}' ({source_config.type}): "
                        f"File not found — {file_path}"
                    )

        if connection_errors:
            raise DataLoadError(
                "Source connectivity check failed:\n  - "
                + "\n  - ".join(connection_errors)
            )

        # Validate each source's checks
        all_results: list[RuleResult] = []
        _total_rows = 0
        _total_columns = 0
        for src_name, checks in source_checks.items():

            source_config = self._sources[src_name]

            # Determine table for this group of checks
            # All checks in this group share the same source, but may have different tables
            # We need to sub-group by table for database sources
            if source_config.is_database:
                table_checks: dict[str | None, list[Any]] = {}
                for check in checks:
                    effective_table = check.table or default_table
                    table_checks.setdefault(effective_table, []).append(check)

                # SQL aggregate pushdown — activates for all supported DB types
                # when no custom --query is used.
                from datacheck.sql_pushdown.dialects import get_dialect
                _dialect = get_dialect(source_config.type) if not query else None

                if _dialect is not None:
                    from datacheck.connectors.factory import create_connector
                    from datacheck.sql_pushdown.builder import SqlAggregateBuilder

                    _builder = SqlAggregateBuilder()
                    _connector = create_connector(source_config)
                    with _connector:
                        for tbl, tbl_checks in table_checks.items():
                            try:
                                if tbl is None:
                                    raise DataLoadError(
                                        f"Source '{src_name}' is a database source — "
                                        "either 'table' or 'query' must be specified"
                                    )
                                pushable, non_pushable = _builder.partition_checks(
                                    tbl_checks, _dialect
                                )

                                # SQL pushdown — zero data transfer
                                if pushable:
                                    _sql = _builder.build_query(
                                        tbl, where, pushable, _dialect
                                    )
                                    _pd_result = _connector.execute_query(_sql)
                                    _pd_row: dict[str, Any] = {str(k): v for k, v in _pd_result.iloc[0].to_dict().items()}
                                    _sql_results = _builder.parse_results(_pd_row, pushable)
                                    all_results.extend(_sql_results)
                                    if not non_pushable:
                                        _total_rows += int(_pd_row.get("_total_rows") or 0)

                                # Python path — only for non-pushable checks
                                if non_pushable:
                                    if tbl:
                                        _load_kw: dict[str, Any] = {"where": where}
                                        _needed_cols = _collect_needed_columns(non_pushable)
                                        if _needed_cols is not None:
                                            _load_kw["columns"] = _needed_cols
                                        df = _connector.load_table(tbl, **_load_kw)
                                    else:
                                        raise DataLoadError(
                                            f"Source '{src_name}' is a database source — "
                                            "either 'table' or 'query' must be specified"
                                        )
                                    _total_rows += len(df)
                                    _total_columns = max(_total_columns, len(df.columns))
                                    results = self._run_checks(df, non_pushable)
                                    all_results.extend(results)

                            except DataLoadError:
                                raise
                            except Exception as e:
                                for check in tbl_checks:
                                    all_results.append(RuleResult(
                                        rule_name=check.name,
                                        column=check.column,
                                        passed=False,
                                        total_rows=0,
                                        error=f"Failed to load data from source '{src_name}': {e}",
                                    ))
                                continue

                else:
                    # Unsupported DB type for pushdown, or custom --query: load-all path
                    for tbl, tbl_checks in table_checks.items():
                        try:
                            df = load_source_data(
                                source_config,
                                table=tbl,
                                where=where,
                                query=query,
                            )
                        except DataLoadError:
                            raise  # propagate so caller maps to exit code 3
                        except Exception as e:
                            # Create error results for non-DataLoadError failures
                            for check in tbl_checks:
                                all_results.append(RuleResult(
                                    rule_name=check.name,
                                    column=check.column,
                                    passed=False,
                                    total_rows=0,
                                    error=f"Failed to load data from source '{src_name}': {e}",
                                ))
                            continue

                        _total_rows += len(df)
                        _total_columns = max(_total_columns, len(df.columns))
                        results = self._run_checks(df, tbl_checks)
                        all_results.extend(results)
            else:
                # File/cloud sources — load once, run all checks
                try:
                    df = load_source_data(source_config)
                except Exception as e:
                    for check in checks:
                        all_results.append(RuleResult(
                            rule_name=check.name,
                            column=check.column,
                            passed=False,
                            total_rows=0,
                            error=f"Failed to load data from source '{src_name}': {e}",
                        ))
                    continue

                _total_rows += len(df)
                _total_columns = max(_total_columns, len(df.columns))
                results = self._run_checks(df, checks)
                all_results.extend(results)

        # Apply severity from check config to results (same as validate_dataframe)
        severity_map: dict[str, str] = {}
        for check_config in self.config.checks:
            severity_map[check_config.name] = check_config.severity
        for result in all_results:
            check_name = result.check_name or result.rule_name
            base_name = check_name.removesuffix("_min").removesuffix("_max")
            if base_name in severity_map:
                result.severity = severity_map[base_name]
            elif check_name in severity_map:
                result.severity = severity_map[check_name]

        summary = ValidationSummary(
            results=all_results,
            total_rows=_total_rows,
            total_columns=_total_columns,
        )

        # Send notification if notifier configured
        if self.notifier:
            try:
                self.notifier.send_summary(summary)
            except Exception as e:
                warnings.warn(
                    f"Failed to send notification: {e}", RuntimeWarning, stacklevel=2
                )

        return summary

    def _run_checks(
        self, df: pd.DataFrame, checks: list[Any]
    ) -> list[RuleResult]:
        """Run a set of checks against a DataFrame.

        Args:
            df: DataFrame to validate
            checks: List of RuleConfig objects

        Returns:
            List of RuleResult objects
        """
        results: list[RuleResult] = []
        for check_config in checks:
            try:
                rules = RuleFactory.create_rules(check_config)
                for rule in rules:
                    try:
                        result = rule.validate(df)
                        results.append(result)
                    except Exception as e:
                        results.append(RuleResult(
                            rule_name=rule.name,
                            column=rule.column,
                            passed=False,
                            total_rows=len(df),
                            error=f"Unexpected error executing rule: {e}",
                        ))
            except Exception as e:
                results.append(RuleResult(
                    rule_name=check_config.name,
                    column=check_config.column,
                    passed=False,
                    total_rows=len(df),
                    error=f"Error creating rules: {e}",
                ))
        return results

    def validate(
        self,
        file_path: str | Path | None = None,
        df: pd.DataFrame | None = None,
        **loader_kwargs: Any,
    ) -> ValidationSummary:
        """Validate data from either a file or DataFrame.

        Args:
            file_path: Path to the data file (optional)
            df: DataFrame to validate (optional)
            **loader_kwargs: Additional arguments passed to the data loader

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ValidationError: If neither file_path nor df provided, or both provided
            DataLoadError: If data cannot be loaded from file
        """
        if file_path is not None and df is not None:
            raise ValidationError("Cannot provide both file_path and df")

        if file_path is None and df is None:
            raise ValidationError("Must provide either file_path or df")

        if file_path is not None:
            return self.validate_file(file_path, **loader_kwargs)
        else:
            assert df is not None
            return self.validate_dataframe(df)



__all__ = [
    "ValidationEngine",
]
