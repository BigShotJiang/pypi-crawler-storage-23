"""Schema detection from DataFrames."""

import warnings

import pandas as pd

from datacheck.schema.models import ColumnSchema, ColumnType, TableSchema


class SchemaDetector:
    """Detect schema from pandas DataFrame."""

    @staticmethod
    def detect(
        df: pd.DataFrame,
        name: str = "dataset",
        source: str | None = None,
    ) -> TableSchema:
        """
        Detect schema from DataFrame.

        Args:
            df: DataFrame to analyze
            name: Name for the schema
            source: Source identifier (file path, table name, etc.)

        Returns:
            TableSchema object

        Example:
            >>> detector = SchemaDetector()
            >>> schema = detector.detect(df, name="customers", source="customers.csv")
        """
        columns = []

        for position, col_name in enumerate(df.columns):
            col_data = df[col_name]

            # Detect column type
            dtype = SchemaDetector._detect_column_type(col_data)

            # Calculate statistics
            null_count = int(col_data.isnull().sum())
            null_percentage = null_count / len(df) if len(df) > 0 else 0.0
            try:
                unique_count = int(col_data.nunique())
            except (TypeError, NotImplementedError, Exception):
                # Complex Arrow types (list, struct, map) are not hashable
                unique_count = -1

            # Create column schema
            col_schema = ColumnSchema(
                name=str(col_name),
                dtype=dtype,
                nullable=(null_count > 0),
                position=position,
                unique_values=unique_count,
                null_percentage=null_percentage,
            )

            columns.append(col_schema)

        return TableSchema(
            name=name,
            columns=columns,
            row_count=len(df),
            source=source,
        )

    @staticmethod
    def _detect_column_type(series: pd.Series) -> ColumnType:
        """
        Detect column type from pandas Series.

        Args:
            series: pandas Series

        Returns:
            ColumnType enum value
        """
        dtype_str = str(series.dtype).lower()

        # Integer types
        if "int" in dtype_str:
            return ColumnType.INTEGER

        # Float types (including "double[pyarrow]")
        if "float" in dtype_str or "double" in dtype_str:
            return ColumnType.FLOAT

        # Boolean
        if "bool" in dtype_str:
            return ColumnType.BOOLEAN

        # Datetime (including "timestamp[ns][pyarrow]" etc.)
        if "datetime" in dtype_str or "timestamp" in dtype_str:
            return ColumnType.DATETIME

        # Date (timedelta or period)
        if "date" in dtype_str and "datetime" not in dtype_str:
            return ColumnType.DATE

        # String/object - check if actually dates
        if dtype_str in ("object", "str") or dtype_str.startswith("string"):
            return SchemaDetector._infer_object_type(series)

        # Category
        if "category" in dtype_str:
            return ColumnType.STRING

        return ColumnType.UNKNOWN

    @staticmethod
    def _infer_object_type(series: pd.Series) -> ColumnType:
        """
        Infer type for object dtype columns.

        Args:
            series: pandas Series with object dtype

        Returns:
            Inferred ColumnType
        """
        # Get non-null sample
        non_null = series.dropna()
        if len(non_null) == 0:
            return ColumnType.STRING

        # Sample for type detection (limit to 100 for performance)
        sample = non_null.head(100)

        # Check if all values are strings
        if all(isinstance(v, str) for v in sample):
            # Try to detect if it's actually a datetime string
            # Suppress pandas warnings about format inference
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning, message="Could not infer format")
                warnings.filterwarnings("ignore", category=FutureWarning)
                try:
                    pd.to_datetime(sample, errors="raise")
                    return ColumnType.DATETIME
                except (ValueError, TypeError):
                    # Retry with utc=True for mixed-timezone strings
                    try:
                        pd.to_datetime(sample, errors="raise", utc=True)
                        return ColumnType.DATETIME
                    except (ValueError, TypeError):
                        pass

                # Try to detect if it's a date string (short format without time component)
                try:
                    _ = pd.to_datetime(sample, errors="raise")
                    # If successful, check if it looks like a date-only pattern
                    sample_str = str(sample.iloc[0])
                    if len(sample_str) <= 10 and "-" in sample_str:
                        return ColumnType.DATE
                except (ValueError, TypeError, AttributeError):
                    # Date parsing failed; continue with string type detection
                    pass

            return ColumnType.STRING

        # Check for boolean-like values
        bool_values = {True, False, "true", "false", "True", "False", "1", "0"}
        try:
            if all(v in bool_values for v in sample):
                return ColumnType.BOOLEAN
        except TypeError:
            pass  # unhashable values (e.g. dicts from JSONB) cannot be booleans

        # Check for numeric strings
        try:
            pd.to_numeric(sample, errors="raise")
            # Check if integers
            if all(float(v).is_integer() for v in sample if v is not None):
                return ColumnType.INTEGER
            return ColumnType.FLOAT
        except (ValueError, TypeError):
            pass

        return ColumnType.STRING

    @staticmethod
    def from_dataframe(
        df: pd.DataFrame,
        name: str = "dataset",
        source: str | None = None,
    ) -> TableSchema:
        """
        Alias for detect() method.

        Args:
            df: DataFrame to analyze
            name: Name for the schema
            source: Source identifier

        Returns:
            TableSchema object
        """
        return SchemaDetector.detect(df, name=name, source=source)
