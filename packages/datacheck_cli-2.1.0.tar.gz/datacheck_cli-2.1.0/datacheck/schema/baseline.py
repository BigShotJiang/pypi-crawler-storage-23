"""Manage baseline schemas."""

import json
from datetime import datetime
from pathlib import Path

from datacheck.schema.models import TableSchema


class BaselineManager:
    """Manage schema baselines."""

    DEFAULT_BASELINE_DIR = ".datacheck/schemas"

    def __init__(self, baseline_dir: str | Path | None = None):
        """
        Initialize baseline manager.

        Args:
            baseline_dir: Directory to store schema files
        """
        if baseline_dir is None:
            baseline_dir = self.DEFAULT_BASELINE_DIR

        self.baseline_dir = Path(baseline_dir)
        self.baseline_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir = self.baseline_dir / "history"
        self.history_dir.mkdir(exist_ok=True)

    def save_baseline(
        self,
        schema: TableSchema,
        name: str = "baseline",
    ) -> Path:
        """
        Save schema as baseline.

        Args:
            schema: TableSchema to save
            name: Baseline name

        Returns:
            Path to saved file
        """
        filepath = self.baseline_dir / f"{name}.json"

        with open(filepath, "w") as f:
            json.dump(schema.to_dict(), f, indent=2)

        return filepath

    def load_baseline(self, name: str = "baseline") -> TableSchema | None:
        """
        Load baseline schema.

        Args:
            name: Baseline name

        Returns:
            TableSchema or None if not found
        """
        filepath = self.baseline_dir / f"{name}.json"

        if not filepath.exists():
            return None

        with open(filepath) as f:
            data = json.load(f)

        return TableSchema.from_dict(data)

    def baseline_exists(self, name: str = "baseline") -> bool:
        """
        Check if baseline exists.

        Args:
            name: Baseline name

        Returns:
            True if baseline exists
        """
        filepath = self.baseline_dir / f"{name}.json"
        return filepath.exists()

    def delete_baseline(self, name: str = "baseline") -> bool:
        """
        Delete baseline.

        Args:
            name: Baseline name

        Returns:
            True if deleted, False if not found
        """
        filepath = self.baseline_dir / f"{name}.json"

        if filepath.exists():
            filepath.unlink()
            return True

        return False

    def list_baselines(self) -> list[str]:
        """
        List all baseline names.

        Returns:
            List of baseline names (without .json extension)
        """
        baselines = []
        for filepath in self.baseline_dir.glob("*.json"):
            if filepath.is_file() and filepath.parent == self.baseline_dir:
                baselines.append(filepath.stem)

        return sorted(baselines)

    def save_to_history(self, schema: TableSchema) -> Path:
        """
        Save schema to history.

        Args:
            schema: TableSchema to save

        Returns:
            Path to saved file
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = self.history_dir / f"schema_{timestamp}.json"

        with open(filepath, "w") as f:
            json.dump(schema.to_dict(), f, indent=2)

        return filepath

    def load_from_history(self, filename: str) -> TableSchema | None:
        """
        Load schema from history.

        Args:
            filename: History file name (with or without .json)

        Returns:
            TableSchema or None if not found
        """
        if not filename.endswith(".json"):
            filename = f"{filename}.json"

        filepath = self.history_dir / filename

        if not filepath.exists():
            return None

        with open(filepath) as f:
            data = json.load(f)

        return TableSchema.from_dict(data)

    def list_history(self, limit: int | None = None) -> list[Path]:
        """
        List all schemas in history.

        Args:
            limit: Maximum number of entries to return

        Returns:
            List of schema file paths, sorted by date (newest first)
        """
        schemas = sorted(self.history_dir.glob("schema_*.json"), reverse=True)

        if limit is not None:
            schemas = schemas[:limit]

        return schemas

    def clear_history(self) -> int:
        """
        Clear all history files.

        Returns:
            Number of files deleted
        """
        count = 0
        for filepath in self.history_dir.glob("schema_*.json"):
            filepath.unlink()
            count += 1

        return count

    def get_history_count(self) -> int:
        """
        Get number of history entries.

        Returns:
            Number of history files
        """
        return len(list(self.history_dir.glob("schema_*.json")))
