"""Amazon Redshift data warehouse connector."""

import logging
from typing import Any

import pandas as pd

try:
    import psycopg2
    from psycopg2 import Error as Psycopg2Error

    PSYCOPG2_AVAILABLE = True
except ImportError:
    PSYCOPG2_AVAILABLE = False

try:
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError

    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class RedshiftConnector(DatabaseConnector):
    """Amazon Redshift data warehouse connector.

    Connects to Redshift using psycopg2 (PostgreSQL-compatible) and loads data
    into pandas DataFrames. Supports both standard password authentication
    and IAM authentication.

    Example:
        >>> # Standard authentication
        >>> connector = RedshiftConnector(
        ...     host='my-cluster.abc123.us-east-1.redshift.amazonaws.com',
        ...     database='analytics',
        ...     user='admin',
        ...     password='mypassword'
        ... )
        >>> with connector:
        ...     df = connector.load_table("customers")

        >>> # IAM authentication
        >>> connector = RedshiftConnector(
        ...     host='my-cluster.abc123.us-east-1.redshift.amazonaws.com',
        ...     database='analytics',
        ...     user='iam_user',
        ...     cluster_identifier='my-cluster',
        ...     region='us-east-1',
        ...     iam_auth=True
        ... )
    """

    def __init__(
        self,
        host: str,
        database: str,
        user: str,
        password: str | None = None,
        port: int = 5439,
        cluster_identifier: str | None = None,
        region: str | None = None,
        iam_auth: bool = False,
        schema: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Redshift connector.

        Args:
            host: Redshift cluster endpoint
            database: Database name
            user: Username
            password: Password (not required if using IAM auth)
            port: Port (default: 5439)
            cluster_identifier: Cluster identifier (required for IAM auth)
            region: AWS region (required for IAM auth)
            iam_auth: Use IAM authentication
            schema: Default schema name
            **kwargs: Additional connection parameters

        Raises:
            DataLoadError: If psycopg2 is not installed, or if IAM auth
                          is requested but boto3 is not installed
        """
        if not PSYCOPG2_AVAILABLE:
            raise DataLoadError(
                "Redshift connector dependencies are not installed. "
                "Install with: pip install 'datacheck[redshift]'"
            )

        if iam_auth and not BOTO3_AVAILABLE:
            raise DataLoadError(
                "boto3 is required for IAM authentication but is not installed. "
                "Install with: pip install 'datacheck[redshift]'"
            )

        # Build connection string for base class
        connection_string = f"redshift://{host}:{port}/{database}"
        super().__init__(connection_string)

        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.cluster_identifier = cluster_identifier
        self.region = region
        self.iam_auth = iam_auth
        self.schema = schema or "public"
        self.kwargs = kwargs
        self.connection: Any | None = None

    def connect(self) -> None:
        """Establish connection to Redshift.

        For IAM auth, uses boto3 to get temporary credentials.

        Raises:
            DataLoadError: If connection fails
        """
        try:
            # Get password (either provided or from IAM)
            effective_password = self.password

            if self.iam_auth:
                effective_password = self._get_iam_credentials()

            # Build connection parameters
            conn_params: dict[str, Any] = {
                "host": self.host,
                "port": self.port,
                "dbname": self.database,
                "user": self.user,
                "password": effective_password,
                "sslmode": "require",  # Always use SSL for Redshift
            }

            # Add any extra kwargs
            conn_params.update(self.kwargs)

            # Establish connection
            self.connection = psycopg2.connect(**conn_params)
            self._is_connected = True
            logger.info(f"Connected to Redshift: {self.host}")

        except Psycopg2Error as e:
            raise DataLoadError(f"Failed to connect to Redshift: {e}") from e
        except (BotoCoreError, ClientError) as e:
            raise DataLoadError(f"IAM authentication failed: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error connecting to Redshift: {e}") from e

    def _get_iam_credentials(self) -> str:
        """Get temporary credentials using IAM authentication.

        Returns:
            Temporary password from IAM

        Raises:
            DataLoadError: If IAM authentication fails
        """
        if not self.cluster_identifier:
            raise DataLoadError(
                "cluster_identifier is required for IAM authentication"
            )
        if not self.region:
            raise DataLoadError("region is required for IAM authentication")

        try:
            client = boto3.client("redshift", region_name=self.region)

            response = client.get_cluster_credentials(
                DbUser=self.user,
                DbName=self.database,
                ClusterIdentifier=self.cluster_identifier,
                AutoCreate=False,
            )

            return response["DbPassword"]

        except (BotoCoreError, ClientError) as e:
            raise DataLoadError(f"Failed to get IAM credentials: {e}") from e

    def disconnect(self) -> None:
        """Close Redshift connection."""
        if self.connection:
            try:
                self.connection.close()
                logger.info("Redshift connection closed successfully")
            except Exception as e:
                logger.warning(f"Error closing Redshift connection: {e}")
            finally:
                self._is_connected = False
                self.connection = None

    def load_table(
        self,
        table_name: str,
        where: str | None = None,
        limit: int | None = None,
        schema: str | None = None,
        sample_rate: float | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from Redshift table.

        Args:
            table_name: Table name
            where: Optional WHERE clause (without 'WHERE' keyword)
            limit: Optional row limit
            schema: Schema name (overrides default)
            sample_rate: Sample fraction 0.0-1.0 (uses RANDOM())

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If not connected or table loading fails

        Note:
            Redshift doesn't support TABLESAMPLE. We use RANDOM() instead.

        Example:
            df = connector.load_table('customers')
            df = connector.load_table('customers', sample_rate=0.1)
            df = connector.load_table('customers', where="status = 'active'")
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Redshift. Call connect() first.")

        self._validate_table_name(table_name)

        try:
            # Build fully qualified table name
            effective_schema = schema or self.schema
            if "." in table_name:
                full_table_name = table_name
            elif effective_schema:
                full_table_name = f"{effective_schema}.{table_name}"
            else:
                full_table_name = table_name

            # Build query (table_name validated by _validate_table_name above)
            if columns:
                col_list = ", ".join(f'"{c}"' for c in sorted(columns))
                query_parts = [f'SELECT {col_list} FROM {full_table_name}']  # nosec B608
            else:
                query_parts = [f"SELECT * FROM {full_table_name}"]  # nosec B608

            # Build WHERE conditions
            conditions = []

            # Add sampling using RANDOM()
            # Redshift doesn't support TABLESAMPLE, so we use WHERE RANDOM() < rate
            if sample_rate is not None:
                if not 0.0 < sample_rate <= 1.0:
                    raise DataLoadError(
                        f"Invalid sample_rate: {sample_rate}. Must be between 0.0 and 1.0"
                    )
                conditions.append(f"RANDOM() < {sample_rate}")

            # Add WHERE clause
            if where:
                self._validate_where_clause(where)
                conditions.append(f"({where})")

            if conditions:
                query_parts.append(" WHERE " + " AND ".join(conditions))

            # Add LIMIT
            if limit:
                if not isinstance(limit, int) or limit <= 0:
                    raise DataLoadError(
                        f"Invalid limit: {limit}. Must be a positive integer."
                    )
                query_parts.append(f" LIMIT {int(limit)}")

            query = "".join(query_parts)
            logger.debug(f"Executing Redshift query: {query}")

            # Execute query
            df = pd.read_sql_query(query, self.connection)
            return df

        except DataLoadError:
            raise
        except Psycopg2Error as e:
            raise DataLoadError(f"Failed to load table '{table_name}': {e}") from e
        except Exception as e:
            raise DataLoadError(
                f"Unexpected error loading table '{table_name}': {e}"
            ) from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute custom SQL query on Redshift.

        Args:
            query: SQL query to execute

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If not connected or query execution fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Redshift. Call connect() first.")

        try:
            df = pd.read_sql_query(query, self.connection)
            return df
        except Psycopg2Error as e:
            raise DataLoadError(f"Failed to execute query: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error executing query: {e}") from e

    def load_table_info(
        self, table_name: str, schema: str | None = None
    ) -> pd.DataFrame:
        """Load Redshift table metadata (columns, types, encoding, etc.).

        Args:
            table_name: Table name
            schema: Schema name

        Returns:
            DataFrame with column information
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Redshift. Call connect() first.")

        self._validate_table_name(table_name)
        effective_schema = schema or self.schema

        query = """
            SELECT
                column_name,
                data_type,
                character_maximum_length,
                is_nullable,
                column_default
            FROM information_schema.columns
            WHERE table_schema = %s
            AND table_name = %s
            ORDER BY ordinal_position
        """

        try:
            return pd.read_sql_query(query, self.connection, params=[effective_schema, table_name])
        except Psycopg2Error as e:
            raise DataLoadError(f"Failed to get table info: {e}") from e

    def list_tables(self, schema: str | None = None) -> list[str]:
        """List tables in a schema.

        Args:
            schema: Schema name (optional, uses default if not provided)

        Returns:
            List of table names
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to Redshift. Call connect() first.")

        effective_schema = schema or self.schema

        query = """
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = %s
            AND table_type = 'BASE TABLE'
            ORDER BY table_name
        """

        try:
            df = pd.read_sql_query(query, self.connection, params=[effective_schema])
            return df["table_name"].tolist()
        except Psycopg2Error as e:
            raise DataLoadError(f"Failed to list tables: {e}") from e


__all__ = ["RedshiftConnector"]
