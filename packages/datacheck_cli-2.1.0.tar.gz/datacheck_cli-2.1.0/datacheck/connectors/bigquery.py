"""Google BigQuery data warehouse connector."""

import logging
import re
from typing import Any

import pandas as pd

try:
    from google.cloud import bigquery
    from google.cloud.exceptions import GoogleCloudError
    from google.oauth2 import service_account

    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False
    bigquery = None  # type: ignore[assignment]

from datacheck.connectors.base import DatabaseConnector
from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class BigQueryConnector(DatabaseConnector):
    """Google BigQuery data warehouse connector.

    Connects to BigQuery and loads data into pandas DataFrames.

    Example:
        >>> # Using service account
        >>> connector = BigQueryConnector(
        ...     project_id='my-project',
        ...     dataset_id='analytics',
        ...     credentials_path='/path/to/service-account.json'
        ... )
        >>> with connector:
        ...     df = connector.load_table("customers")

        >>> # Using default credentials (ADC)
        >>> connector = BigQueryConnector(
        ...     project_id='my-project',
        ...     dataset_id='analytics'
        ... )
    """

    # BigQuery allows hyphens in table/dataset names
    _TABLE_NAME_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.-]*(\.[a-zA-Z_][a-zA-Z0-9_-]*)*$")

    def __init__(
        self,
        project_id: str,
        dataset_id: str | None = None,
        credentials_path: str | None = None,
        location: str = "US",
        **kwargs: Any,
    ) -> None:
        """Initialize BigQuery connector.

        Args:
            project_id: GCP project ID
            dataset_id: Default dataset ID
            credentials_path: Path to service account JSON file
                             (if None, uses Application Default Credentials)
            location: BigQuery location (default: 'US')
            **kwargs: Additional client parameters

        Raises:
            DataLoadError: If google-cloud-bigquery is not installed
        """
        if not BIGQUERY_AVAILABLE:
            raise DataLoadError(
                "BigQuery connector dependencies are not installed. "
                "Install with: pip install 'datacheck[bigquery]'"
            )

        # Build connection string for base class
        connection_string = f"bigquery://{project_id}/{dataset_id or ''}"
        super().__init__(connection_string)

        self.project_id = project_id
        self.dataset_id = dataset_id
        self.credentials_path = credentials_path
        self.location = location
        self.kwargs = kwargs
        self.client: Any | None = None  # bigquery.Client

    def connect(self) -> None:
        """Establish connection to BigQuery.

        Raises:
            DataLoadError: If connection fails
        """
        try:
            # Build credentials
            credentials = None
            if self.credentials_path:
                credentials = service_account.Credentials.from_service_account_file(
                    self.credentials_path,
                    scopes=["https://www.googleapis.com/auth/bigquery"],
                )

            # Create client
            self.client = bigquery.Client(
                project=self.project_id,
                credentials=credentials,
                location=self.location,
                **self.kwargs,
            )
            self._is_connected = True
            logger.info(f"Connected to BigQuery project: {self.project_id}")

        except GoogleCloudError as e:
            raise DataLoadError(f"Failed to connect to BigQuery: {e}") from e
        except FileNotFoundError as e:
            raise DataLoadError(
                f"Credentials file not found: {self.credentials_path}"
            ) from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error connecting to BigQuery: {e}") from e

    def disconnect(self) -> None:
        """Close BigQuery client.

        Note: BigQuery client doesn't require explicit closing,
        but we set to None for consistency.
        """
        if self.client:
            try:
                self.client.close()
                logger.info("BigQuery client closed successfully")
            except Exception as e:
                logger.warning(f"Error closing BigQuery client: {e}")
            finally:
                self._is_connected = False
                self.client = None

    def load_table(
        self,
        table_name: str,
        where: str | None = None,
        limit: int | None = None,
        dataset_id: str | None = None,
        sample_rate: float | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from BigQuery table.

        Args:
            table_name: Table name
            where: Optional WHERE clause (without 'WHERE' keyword)
            limit: Optional row limit
            dataset_id: Dataset ID (overrides default)
            sample_rate: Sample fraction 0.0-1.0 (uses TABLESAMPLE SYSTEM)

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If not connected or table loading fails

        Example:
            df = connector.load_table('customers')
            df = connector.load_table('customers', sample_rate=0.1)
            df = connector.load_table('customers', where="created_at > '2024-01-01'")
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to BigQuery. Call connect() first.")

        self._validate_table_name(table_name)

        try:
            # Build fully qualified table name: project.dataset.table
            effective_dataset = dataset_id or self.dataset_id
            if not effective_dataset:
                raise DataLoadError(
                    "Dataset ID not specified. Provide dataset_id parameter or set default."
                )

            # Use backticks for BigQuery table references
            full_table_name = f"`{self.project_id}.{effective_dataset}.{table_name}`"

            # Build query (table_name validated by _validate_table_name above)
            if columns:
                col_list = ", ".join(f"`{c}`" for c in sorted(columns))
                query_parts = [f"SELECT {col_list} FROM {full_table_name}"]  # nosec B608
            else:
                query_parts = [f"SELECT * FROM {full_table_name}"]  # nosec B608

            # Add sampling clause (BigQuery specific)
            # TABLESAMPLE comes after FROM clause
            if sample_rate is not None:
                if not 0.0 < sample_rate <= 1.0:
                    raise DataLoadError(
                        f"Invalid sample_rate: {sample_rate}. Must be between 0.0 and 1.0"
                    )
                percentage = sample_rate * 100
                query_parts.append(f" TABLESAMPLE SYSTEM ({percentage} PERCENT)")

            # Add WHERE clause
            if where:
                self._validate_where_clause(where)
                query_parts.append(f" WHERE {where}")

            # Add LIMIT
            if limit:
                if not isinstance(limit, int) or limit <= 0:
                    raise DataLoadError(
                        f"Invalid limit: {limit}. Must be a positive integer."
                    )
                query_parts.append(f" LIMIT {int(limit)}")

            query = "".join(query_parts)
            logger.debug(f"Executing BigQuery query: {query}")

            # Execute query
            query_job = self.client.query(query)
            df = query_job.to_dataframe()
            return df

        except DataLoadError:
            raise
        except GoogleCloudError as e:
            raise DataLoadError(f"Failed to load table '{table_name}': {e}") from e
        except Exception as e:
            raise DataLoadError(
                f"Unexpected error loading table '{table_name}': {e}"
            ) from e

    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute custom SQL query on BigQuery.

        Args:
            query: SQL query string (standard SQL)

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If not connected or query execution fails
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to BigQuery. Call connect() first.")

        try:
            query_job = self.client.query(query)
            df = query_job.to_dataframe()
            return df
        except GoogleCloudError as e:
            raise DataLoadError(f"Failed to execute query: {e}") from e
        except Exception as e:
            raise DataLoadError(f"Unexpected error executing query: {e}") from e

    def load_table_schema(
        self, table_name: str, dataset_id: str | None = None
    ) -> dict[str, Any]:
        """Load table schema information.

        Args:
            table_name: Table name
            dataset_id: Dataset ID (optional)

        Returns:
            Dict with schema information
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to BigQuery. Call connect() first.")

        effective_dataset = dataset_id or self.dataset_id
        if not effective_dataset:
            raise DataLoadError("Dataset ID not specified.")

        try:
            table_ref = f"{self.project_id}.{effective_dataset}.{table_name}"
            table = self.client.get_table(table_ref)

            return {
                "table_id": table.table_id,
                "project": table.project,
                "dataset_id": table.dataset_id,
                "num_rows": table.num_rows,
                "num_bytes": table.num_bytes,
                "created": table.created.isoformat() if table.created else None,
                "modified": table.modified.isoformat() if table.modified else None,
                "schema": [
                    {
                        "name": field.name,
                        "type": field.field_type,
                        "mode": field.mode,
                        "description": field.description,
                    }
                    for field in table.schema
                ],
            }
        except GoogleCloudError as e:
            raise DataLoadError(f"Failed to get table schema: {e}") from e

    def list_tables(self, dataset_id: str | None = None) -> list[str]:
        """List tables in a dataset.

        Args:
            dataset_id: Dataset ID (optional, uses default if not provided)

        Returns:
            List of table names
        """
        if not self.is_connected:
            raise DataLoadError("Not connected to BigQuery. Call connect() first.")

        effective_dataset = dataset_id or self.dataset_id
        if not effective_dataset:
            raise DataLoadError("Dataset ID not specified.")

        try:
            dataset_ref = f"{self.project_id}.{effective_dataset}"
            tables = self.client.list_tables(dataset_ref)
            return [table.table_id for table in tables]
        except GoogleCloudError as e:
            raise DataLoadError(f"Failed to list tables: {e}") from e


__all__ = ["BigQueryConnector"]
