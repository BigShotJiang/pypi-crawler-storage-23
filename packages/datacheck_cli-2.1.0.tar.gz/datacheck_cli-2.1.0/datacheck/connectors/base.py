"""Base classes for database connectors."""

import re
from abc import ABC, abstractmethod

import pandas as pd

from datacheck.exceptions import DataLoadError


class DatabaseConnector(ABC):
    """Abstract base class for database connectors.

    This class defines the interface that all database connectors must implement.
    Connectors handle connection management, query execution, and data loading.

    Example:
        >>> connector = PostgreSQLConnector("postgresql://localhost/mydb")
        >>> connector.connect()
        >>> df = connector.load_table("users")
        >>> connector.disconnect()
    """

    def __init__(self, connection_string: str) -> None:
        """Initialize database connector.

        Args:
            connection_string: Database connection string (e.g., postgresql://user:pass@host/db)
        """
        self.connection_string = connection_string
        self.connection: object | None = None
        self._is_connected = False

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to database.

        Raises:
            DataLoadError: If connection fails
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close database connection."""
        pass

    @abstractmethod
    def load_table(
        self,
        table_name: str,
        where: str | None = None,
        limit: int | None = None,
        columns: set[str] | None = None,
    ) -> pd.DataFrame:
        """Load data from a database table.

        Args:
            table_name: Name of the table to load
            where: Optional WHERE clause (without 'WHERE' keyword)
            limit: Optional row limit
            columns: Optional set of column names to load. When provided,
                     generates SELECT col1, col2 instead of SELECT *.
                     Pass None to load all columns.

        Returns:
            DataFrame containing table data

        Raises:
            DataLoadError: If table loading fails
        """
        pass

    @abstractmethod
    def execute_query(self, query: str) -> pd.DataFrame:
        """Execute a SQL query and return results.

        Args:
            query: SQL query to execute

        Returns:
            DataFrame containing query results

        Raises:
            DataLoadError: If query execution fails
        """
        pass

    def __enter__(self) -> "DatabaseConnector":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: object) -> bool:
        """Context manager exit - ensures cleanup.

        Returns:
            False to propagate exceptions (does not suppress them)
        """
        self.disconnect()
        return False  # Don't suppress exceptions

    @property
    def is_connected(self) -> bool:
        """Check if connector is connected to database."""
        return self._is_connected

    _TABLE_NAME_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*$")

    _DANGEROUS_WHERE_PATTERNS = [
        (r";\s*(DROP|DELETE|INSERT|UPDATE|CREATE|ALTER|EXEC|EXECUTE|TRUNCATE|GRANT|REVOKE)\s", "SQL command injection"),
        (r"--", "SQL comment injection"),
        (r"/\*.*\*/", "SQL comment block"),
        (r"xp_cmdshell", "Command execution attempt"),
        (r"UNION\s+(ALL\s+)?SELECT", "UNION injection"),
        (r"INTO\s+(OUTFILE|DUMPFILE)", "File writing attempt"),
        (r"LOAD_FILE\s*\(", "File reading attempt"),
        (r"BENCHMARK\s*\(", "Timing attack attempt"),
        (r"SLEEP\s*\(", "Timing attack attempt"),
        (r"WAITFOR\s+DELAY", "Timing attack attempt"),
    ]

    def _validate_table_name(self, table_name: str) -> None:
        """Validate table name to prevent SQL injection.

        Args:
            table_name: Table name to validate

        Raises:
            DataLoadError: If table name contains invalid characters
        """
        if not self._TABLE_NAME_PATTERN.match(table_name):
            raise DataLoadError(
                f"Invalid table name '{table_name}'. "
                "Table names must contain only alphanumeric characters, underscores, dots, and hyphens."
            )

    def _validate_where_clause(self, where: str) -> None:
        """Validate WHERE clause for dangerous SQL injection patterns.

        Args:
            where: WHERE clause to validate

        Raises:
            DataLoadError: If dangerous pattern detected
        """
        for pattern, description in self._DANGEROUS_WHERE_PATTERNS:
            if re.search(pattern, where, re.IGNORECASE):
                raise DataLoadError(
                    f"Potentially dangerous SQL pattern detected in WHERE clause: {description}. "
                    "Use the 'filters' parameter instead for safe filtering."
                )
