from vibe_check.utils.config import load_config

__all__ = ["load_config"]
