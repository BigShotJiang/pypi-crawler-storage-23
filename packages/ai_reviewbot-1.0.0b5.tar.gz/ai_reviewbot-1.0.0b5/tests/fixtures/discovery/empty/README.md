# Empty Project

A minimal project with no CI or configuration files.
