# Task 4.3: Documentation

| Поле | Значення |
|------|----------|
| **Фаза** | 4 — Polish |
| **Оцінка** | 1-2 години |

## Що робимо

Оновити README, додати examples, оновити ROADMAP.

## Deliverables

- README.md: секція "Discovery" з описом feature
- `examples/.reviewbot.md` — приклад конфіга
- ROADMAP.md: оновити з реальним прогресом
- CHANGELOG.md: entry для beta release
