# Task 3.3: Discovery Comment

| Поле | Значення |
|------|----------|
| **Фаза** | 3 — Integration |
| **Оцінка** | 1-2 години |
| **Залежності** | 3.2 |
| **Файли** | `discovery/orchestrator.py` або `core/formatter.py` |

## Що робимо

Формат Discovery коментаря в MR — проєктний аналіз + питання.
Постити перед рев'ю. Тихий режим: нема gaps → не постити.

## Очікуваний результат

Readable markdown з: stack, CI status, skip/focus, questions.
