"""Unit tests for collie."""
