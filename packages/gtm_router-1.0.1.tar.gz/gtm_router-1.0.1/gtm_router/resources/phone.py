"""Single-record phone operations."""

from __future__ import annotations

from typing import Any

from ..client import HttpClient


class PhoneResource:
    def __init__(self, client: HttpClient):
        self._client = client

    def find(
        self,
        *,
        email: str | None = None,
        linkedin_url: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        domain: str | None = None,
        mode: str = "fastest",
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"mode": mode}
        if email:
            body["email"] = email
        if linkedin_url:
            body["linkedin_url"] = linkedin_url
        if first_name:
            body["first_name"] = first_name
        if last_name:
            body["last_name"] = last_name
        if domain:
            body["domain"] = domain

        return self._client.request("POST", "/phone/find", json_body=body)
