"""Single-record email operations."""

from __future__ import annotations

from typing import Any

from ..client import HttpClient


class EmailResource:
    def __init__(self, client: HttpClient):
        self._client = client

    def find(
        self,
        *,
        first_name: str,
        last_name: str,
        domain: str,
        mode: str = "fastest",
        verify: bool = False,
    ) -> dict[str, Any]:
        return self._client.request(
            "POST",
            "/email/find",
            json_body={
                "first_name": first_name,
                "last_name": last_name,
                "domain": domain,
                "mode": mode,
                "verify": verify,
            },
        )

    def verify(self, *, email: str, mode: str = "fastest") -> dict[str, Any]:
        return self._client.request(
            "POST",
            "/email/verify",
            json_body={"email": email, "mode": mode},
        )
