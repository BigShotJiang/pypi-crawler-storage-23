from .bulk import BulkResource
from .email import EmailResource
from .phone import PhoneResource
from .account import AccountResource

__all__ = ["BulkResource", "EmailResource", "PhoneResource", "AccountResource"]
