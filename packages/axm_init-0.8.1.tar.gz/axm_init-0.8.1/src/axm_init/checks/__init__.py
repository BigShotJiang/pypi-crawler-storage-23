"""Audit check functions registry."""

from __future__ import annotations
