"""AXM Core package."""

__all__: list[str] = []
