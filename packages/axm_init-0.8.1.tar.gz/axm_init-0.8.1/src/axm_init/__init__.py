"""AXM - Axiom eXtensible Manager.

The deterministic CLI for Python project governance.
"""

from axm_init._version import __version__

__all__ = ["__version__"]
