"""Placeholder — project models removed (dead code cleanup).

ProjectConfig and ProjectMetadata were unused in source code.
Re-add when scaffolding pipeline uses typed project inputs.
"""
