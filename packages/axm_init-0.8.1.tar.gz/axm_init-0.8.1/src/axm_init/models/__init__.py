"""AXM Models package."""

from axm_init.models.results import ReserveResult, ScaffoldResult

__all__ = [
    "ReserveResult",
    "ScaffoldResult",
]
