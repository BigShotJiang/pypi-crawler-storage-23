"""AXM Adapters package."""

from axm_init.adapters.filesystem import FileSystemAdapter

__all__ = [
    "FileSystemAdapter",
]
