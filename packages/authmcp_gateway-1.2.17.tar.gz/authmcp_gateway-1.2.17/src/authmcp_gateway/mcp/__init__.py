"""MCP Gateway module - Multi-server proxy and routing."""
