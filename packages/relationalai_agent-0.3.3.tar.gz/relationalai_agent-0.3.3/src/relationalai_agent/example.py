"""Example usage of the Agent SDK."""

import asyncio
from relationalai_agent import Agent
from relationalai import semantics as rai
from relationalai.semantics import define, select

model = rai.Model("test")
Concept, Relationship = model.Concept, model.Relationship

Person = Concept("Person")
define(
    Person.new(name="Joe", age=74),
    Person.new(name="Bob", age=40),
    Person.new(name="Jane", age=10),
)

Adult = Concept("Adult", extends=[Person])
# This derives the relationship between Person and Adult
# saying that every person over 18 is an adult
define(Adult(Person)).where(Person.age >= 18)

select(Adult.name, Adult.age).inspect()


# Note: In production, config would come from pyrel
# from relationalai.clients.config import Config


async def example_await_pattern():
    """Example: Simple await pattern for quick queries."""
    config = {}  # Placeholder - would be Config() from pyrel
    agent = Agent(config)

    # Optional: add context
    agent.use(model)
    # agent.use(model, table1, table2)

    # Ask and await
    question = agent.ask("Who are the adults?")
    response = await question

    print(f"Got {len(response.results)} results")
    for result in response.results:
        print(f"  Result: {result.type}")
        if result.type == "prose":
            print(f"  Text: {result.text}")


async def example_streaming_pattern():
    """Example: Streaming pattern for progress tracking."""
    config = {}
    agent = Agent(config)

    question = agent.ask("Analyze customer demographics")
    stream = question.stream()

    async for event in stream:
        match event.type:
            case "plan":
                print(f"Plan: {len(event.tasks)} tasks")
            case "task_start":
                print(f"Starting: {event.task_id}")
            case "result":
                print(f"Result: {event.result.type}")
            case "error":
                print(f"Error: {event.error_message}")

    # After streaming, access accumulated results
    print(f"Total results: {len(stream.results)}")


if __name__ == "__main__":
    print("Agent SDK Examples")
    print("==================\n")

    print("Example 1: Await pattern")
    asyncio.run(example_await_pattern())

    print("\nExample 2: Streaming pattern")
    asyncio.run(example_streaming_pattern())
