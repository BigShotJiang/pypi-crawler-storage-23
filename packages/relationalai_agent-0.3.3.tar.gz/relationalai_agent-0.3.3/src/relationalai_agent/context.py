"""Context management for the Agent SDK.

This module handles context items - both raw pyrel objects and ECS components.
It isolates all direct dependencies on the relationalai package.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# Import pyrel types
from relationalai.semantics import (
    Concept as PyrelConcept,
    Model as PyrelModel,
    Relationship as PyrelRelation,
    Table as PyrelTable,
)

# Import agent-shared types
from relationalai_agent_shared import AgentContextItem

if TYPE_CHECKING:
    from .agent import Agent

from .model_fragment import PyRelModelFragment

# Context items can be raw pyrel objects, ECS components, or PyRelModelFragments
RawContextItem = PyrelConcept | PyrelRelation | PyrelTable | PyrelModel
ContextItem = RawContextItem | AgentContextItem | PyRelModelFragment


class AgentContext:
    """Context manager for agent context items.

    Allows temporary context addition with automatic cleanup via context manager protocol.
    """

    def __init__(self, agent: Agent, fragment: PyRelModelFragment):
        self._agent = agent
        self._fragment = fragment

    def drop(self) -> None:
        """Remove the fragment from the agent's context stack."""
        self._agent.drop(self._fragment)

    def __enter__(self) -> AgentContext:
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb) -> None:
        self.drop()
