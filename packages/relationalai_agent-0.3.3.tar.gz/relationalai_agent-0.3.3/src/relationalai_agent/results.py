"""SDK-specific result extensions with client-side helpers.

These classes extend the agent-shared result types with client-side functionality
like fetch(), provenance tracking, and confidence scoring.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

# Import base types from agent-shared
from relationalai_agent_shared import (
    DataResult as SharedDataResult,
    ProseResult as SharedProseResult,
)


class ProvenanceEntry(BaseModel):
    """Entry in result provenance chain."""

    pass


class ResultMixin:
    """Mixin providing client-side helpers for result types."""

    data: Any | None = None  # Optional inline data from server

    async def fetch(self) -> Any:
        """Fetch the result data.

        If data is inlined, returns it immediately.
        Otherwise raises NotImplementedError for deferred fetching.
        """
        if self.data is not None:
            return self.data
        raise NotImplementedError(
            "This version of the SDK does not support fetching deferred result data. "
            "Result data must be inlined in the response."
        )

    @property
    def provenance(self) -> list[ProvenanceEntry]:
        """Get provenance information for this result."""
        # TODO v0.1: Implement provenance tracking
        return []

    @property
    def confidence(self) -> float:
        """Get confidence score for this result (0.0 to 1.0)."""
        # TODO v0.1: Calculate confidence from provenance/events
        return 0.0


class DataResult(ResultMixin, SharedDataResult):
    """SDK DataResult with client-side helpers."""

    pass


class ProseResult(ResultMixin, SharedProseResult):
    """SDK ProseResult with client-side helpers."""

    async def fetch(self) -> str:
        """Fetch the result text.

        For prose results, text is always inlined.
        """
        return self.text


# Type alias for SDK results
Result = DataResult | ProseResult
