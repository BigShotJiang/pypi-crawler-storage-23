"""Authentication interface — thin wrapper around upstream TokenHandler.

Single callsite for the upstream ``relationalai.auth.token_handler.TokenHandler``.
All other modules import ``TokenHandler`` from here instead of reaching into the
upstream package directly. If the upstream module isn't available (e.g. pyrel
doesn't ship ``relationalai.auth`` yet), a stub is provided so the SDK can still
be imported — token-dependent features will fail at call time, not import time.
"""

from __future__ import annotations

from typing import Any

try:
    from relationalai.auth.token_handler import (
        TokenHandler as _UpstreamTokenHandler,
    )

    class TokenHandler(_UpstreamTokenHandler):  # type: ignore[misc]
        """Re-export of upstream TokenHandler."""

        pass

except Exception:

    class TokenHandler:  # type: ignore[no-redef]
        """Stub when upstream ``relationalai.auth`` is unavailable."""

        @classmethod
        def from_config(cls, config: Any) -> TokenHandler:
            raise NotImplementedError(
                "relationalai.auth.token_handler is not installed — "
                "pass a pre-issued token string instead"
            )

        def get_ingress_token(self, endpoint: str) -> str:
            raise NotImplementedError(
                "relationalai.auth.token_handler is not installed — "
                "pass a pre-issued token string instead"
            )
