from __future__ import annotations

import json
import httpx
from typing import AsyncIterator

from pydantic import ValidationError

from .auth import TokenHandler
from relationalai_agent_shared import (
    AskRequest,
    CapabilityConfig,
    ErrorEvent,
    ExecuteCodeEvent,
    ModelFragment,
    PlanEvent,
    Quotas,
    StatusEvent,
    StreamEventType,
    TaskEndEvent,
    TaskStartEvent,
)

from .events import ResultEvent


async def create_sse_stream(
    endpoint: str,
    question: str,
    capabilities: CapabilityConfig | None,
    quotas: Quotas | None,
    context: ModelFragment,
    token_handler: TokenHandler | None = None,
) -> AsyncIterator[StreamEventType]:
    """Create SSE stream consuming /ask endpoint."""
    # Create AskRequest with ModelFragment context
    request = AskRequest(
        question=question,
        capabilities=capabilities,
        quotas=quotas,
        context=context,
    )

    headers: dict[str, str] = {"Accept": "text/event-stream"}
    if token_handler is not None:
        # See relevant SF documentation:
        #   https://docs.snowflake.com/en/developer-guide/snowflake-ml/inference/stable-endpoints-api-reference#authorization-security
        #   https://docs.snowflake.com/en/developer-guide/snowpark-container-services/tutorials/advanced/tutorial-8-access-public-endpoint-programmatically#send-request-using-curl
        token = token_handler.get_ingress_token(endpoint)
        headers["Authorization"] = f'Snowflake Token="{token}"'

    request_body = request.model_dump(mode="json", by_alias=True, exclude_none=True)

    async with httpx.AsyncClient(timeout=300.0) as client:
        async with client.stream(
            "POST",
            endpoint,
            json=request_body,
            headers=headers,
        ) as response:
            response.raise_for_status()

            async for line in response.aiter_lines():
                if not line or not line.startswith("data: "):
                    continue

                data = line[6:]  # Strip "data: " prefix
                try:
                    event_dict = json.loads(data)
                    event = _parse_event(event_dict)
                    if event:
                        yield event
                except json.JSONDecodeError:
                    continue


EVENT_TYPES = {
    "plan": PlanEvent,
    "task_start": TaskStartEvent,
    "task_end": TaskEndEvent,
    "result": ResultEvent,
    "error": ErrorEvent,
    "status": StatusEvent,
    "execute_code": ExecuteCodeEvent,
}


def _parse_event(data: dict) -> StreamEventType | None:
    """Parse SSE event dict into typed event object."""
    event_type = data.get("type") or data.get("event_type")
    if not event_type:
        return None
    event_class = EVENT_TYPES.get(event_type)
    try:
        return event_class(**data) if event_class else None
    except (ValidationError, ValueError) as e:
        # Intermediate results (interpretation, query_plan, etc.) are filtered
        # to None by ResultEvent.convert_result() and pass through fine.
        # Log unexpected validation errors for debugging.
        print(f"[agent-sdk] Failed to parse {event_type} event: {e}")
        return None
