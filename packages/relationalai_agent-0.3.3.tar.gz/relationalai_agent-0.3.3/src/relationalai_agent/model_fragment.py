"""PyRel-specific ModelFragment extension with SDK metadata."""

from __future__ import annotations

from uuid import UUID

from pydantic import PrivateAttr
from relationalai.semantics import (
    Concept as PyrelConcept,
    Relationship as PyrelRelation,
)
from relationalai_agent_shared import ModelFragment
from relationalai_agent_shared.ecs import Concept


class PyRelModelFragment(ModelFragment):
    """Extended ModelFragment with PyRel-specific metadata.

    Adds SDK-level tracking for:
    - Raw PyRel objects (for execute_code namespace)
    - Parent concept names (for lazy resolution)

    These are PrivateAttr and not serialized, maintaining wire compatibility
    with the base ModelFragment class.
    """

    # Raw PyRel objects for code execution (not serialized over wire)
    # Maps name -> original PyRel Concept/Relationship object
    _raw_pyrel_objects: dict[str, PyrelConcept | PyrelRelation] = PrivateAttr(
        default_factory=dict
    )

    # Parent concept names for lazy resolution (not serialized)
    # Maps concept EID -> list of parent concept names
    _parent_names_by_eid: dict[UUID, list[str]] = PrivateAttr(default_factory=dict)

    def resolve_parent_eids(self, concept: Concept) -> list[UUID]:
        """Resolve parent concept names to EIDs within this fragment.

        Args:
            concept: The concept whose parents to resolve

        Returns:
            List of parent EIDs found in this fragment (silently skips missing)
        """
        parent_names = self._parent_names_by_eid.get(concept.eid, [])
        return [
            self.concepts[name.lower()].eid
            for name in parent_names
            if name.lower() in self.concepts
        ]

    def resolve_all_parents(self) -> None:
        """Resolve all parent names to EIDs and populate concept.parent_eids.

        Called by Agent.get_effective_context() before wire transmission.
        Mutates concepts in-place to populate their parent_eids from _parent_names_by_eid.
        """
        for concept in self.concepts.values():
            parent_eids = self.resolve_parent_eids(concept)
            if parent_eids:
                concept.parent_eids = parent_eids

    def merge(self, other: ModelFragment) -> PyRelModelFragment:
        """Merge another fragment into this one, with other taking precedence.

        Args:
            other: Fragment to merge, whose values override this fragment's

        Returns:
            New PyRelModelFragment with merged contents

        Note:
            If other is also a PyRelModelFragment, merges SDK metadata too.
        """
        merged_concepts = {**self.concepts, **other.concepts}
        merged_relationships = {**self.relationships, **other.relationships}
        merged_sources = {**self.sources, **other.sources}

        result = PyRelModelFragment(
            concepts=merged_concepts,
            relationships=merged_relationships,
            sources=merged_sources,
        )

        # Merge SDK metadata if available
        if isinstance(other, PyRelModelFragment):
            result._raw_pyrel_objects = {
                **self._raw_pyrel_objects,
                **other._raw_pyrel_objects,
            }
            result._parent_names_by_eid = {
                **self._parent_names_by_eid,
                **other._parent_names_by_eid,
            }
        else:
            result._raw_pyrel_objects = self._raw_pyrel_objects.copy()
            result._parent_names_by_eid = self._parent_names_by_eid.copy()

        # Resolve parent names to EIDs after merge
        result.resolve_all_parents()

        return result
