"""Converters for transforming pyrel objects to ECS components.

This module provides conversion functions to transform objects from the relationalai
package (pyrel) into the ECS components defined in agent-shared. This allows users
to pass native pyrel objects to the SDK, which then converts them for transmission
to the server.
"""

from __future__ import annotations
from uuid import UUID

from relationalai.semantics import (
    Concept as PyrelConcept,
    Model as PyrelModel,
    Relationship as PyrelRelation,
    Table as PyrelTable,
)

from relationalai_agent.model_fragment import PyRelModelFragment
from relationalai_agent_shared.ecs import (
    Column,
    Concept as ECSConcept,
    Relationship as ECSRelationship,
    RelationField as ECSRelationField,
    Source as ECSSource,
)
from relationalai_agent_shared.ecs.model import (
    Transaction,
    _active_transaction,
)


class _NoCommitTransaction(Transaction):
    """A Transaction that can be entered/exited synchronously.

    FIXME: This exists because ECS .create() requires an active transaction,
    but the converter never needs to commit. The real fix is decoupling
    entity creation from the transaction/relation store.
    """

    def __enter__(self):
        existing = _active_transaction.get()
        if existing is not None:
            existing.depth += 1
            return existing
        self._token = _active_transaction.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        active = _active_transaction.get()
        if active is not self:
            if active is not None:
                active.depth -= 1
            return
        if self.depth > 0:
            self.depth -= 1
            return
        # Apply changesets to relation store (in-memory only, no persistence)
        # so computed_field getters can read the data back during serialization.
        try:
            if exc_type is None:
                for relation_id, changes in self.changesets.items():
                    instance = self.model._relations.get(relation_id)
                    if instance is None:
                        from relationalai_agent_shared.ecs.registry import (
                            _RELATION_REGISTRY,
                        )

                        template_instance = _RELATION_REGISTRY.get(relation_id)
                        if template_instance is None:
                            continue  # skip unknown relations silently
                        relation_class = type(template_instance)
                        instance = relation_class()
                        instance.model_id = self.model.id
                        self.model._relations[relation_id] = instance

                    for change in changes:
                        change.apply(instance)
        finally:
            if hasattr(self, "_token"):
                _active_transaction.reset(self._token)


def from_pyrel_concept(concept: PyrelConcept) -> ECSConcept:
    """Convert a pyrel Concept to an ECS Concept component.

    Args:
        concept: PyRel Concept object

    Returns:
        ECS Concept component

    Note:
        - parent_eids are always empty here; parent names are tracked separately
          in PyRelModelFragment._parent_names_by_eid for lazy resolution
        - Use PyRelModelFragment.resolve_parent_eids() to resolve parent names to EIDs
    """
    return ECSConcept.create(
        name=concept._name,
        description="",  # PyRel concepts don't have descriptions
        parent_eids=[],  # Parent resolution is lazy (via PyRelModelFragment)
    )


def from_pyrel_relationship(rel: PyrelRelation) -> ECSRelationship:
    """Convert a pyrel Relationship to an ECS Relationship component.

    Args:
        rel: PyRel Relationship object

    Returns:
        ECS Relationship component
    """
    # Convert PyRel fields to ECS RelationField format
    fields = [ECSRelationField(name=f.name, type=f.type._name) for f in rel._fields]

    return ECSRelationship.create(
        name=rel._short_name,
        fields=fields,
    )


def from_pyrel_table(table: PyrelTable) -> ECSSource:
    """Convert a pyrel Table to an ECS Source component.

    Args:
        table: PyRel Table object (created via model.Table(fqn))

    Returns:
        ECS Source component
    """
    fqn = table._name  # e.g. "DB.SCHEMA.TABLE"
    parts = fqn.split(".")

    if len(parts) >= 3:
        database, schema, table_name = parts[-3], parts[-2], parts[-1]
    elif len(parts) == 2:
        database, schema, table_name = "", parts[-2], parts[-1]
    else:
        database, schema, table_name = "", "", fqn

    # Extract columns from the table's known columns if available
    columns: list[Column] = []
    if hasattr(table, "_known_columns") and table._known_columns:
        columns = [
            Column(name=name, type="String")  # type info not available from Table
            for name in table._known_columns
        ]

    return ECSSource.create(
        fqn=fqn,
        database=database,
        schema=schema,
        table_name=table_name,
        columns=columns,
    )


def fragment_from_pyrel(
    *items: PyrelConcept
    | PyrelRelation
    | PyrelTable
    | PyrelTable
    | PyrelModel
    | PyRelModelFragment
    | ECSConcept
    | ECSRelationship
    | ECSSource,
) -> PyRelModelFragment:
    """Convert PyRel objects to PyRelModelFragment with both ECS and raw objects.

    Must be called within an active Model + Transaction context.
    """
    concepts: dict[str, ECSConcept] = {}
    relationships: dict[str, ECSRelationship] = {}
    sources: dict[str, ECSSource] = {}
    raw_objects: dict[str, PyrelConcept | PyrelRelation] = {}
    parent_names: dict[UUID, list[str]] = {}

    for item in items:
        if isinstance(item, PyrelModel):
            # Extract all concepts and relationships from Model
            for concept in item.concepts:
                ecs = from_pyrel_concept(concept)
                concepts[ecs.name.lower()] = ecs
                raw_objects[concept._name] = concept

                # Capture parent names for lazy resolution
                if hasattr(concept, "_extends") and concept._extends:
                    parent_names[ecs.eid] = [p._name for p in concept._extends]

            for rel in item.relationships:
                ecs = from_pyrel_relationship(rel)
                relationships[ecs.name.lower()] = ecs
                raw_objects[rel._short_name] = rel

        elif isinstance(item, PyrelTable):
            # Table check must come before Concept — Table is a subclass of Concept
            ecs = from_pyrel_table(item)
            sources[ecs.fqn] = ecs

        elif isinstance(item, PyrelConcept):
            ecs = from_pyrel_concept(item)
            concepts[ecs.name.lower()] = ecs
            raw_objects[item._name] = item

            # Capture parent names for lazy resolution
            if hasattr(item, "_extends") and item._extends:
                parent_names[ecs.eid] = [p._name for p in item._extends]

        elif isinstance(item, PyrelRelation):
            ecs = from_pyrel_relationship(item)
            relationships[ecs.name.lower()] = ecs
            raw_objects[item._short_name] = item

        elif isinstance(item, PyRelModelFragment):
            # Merge existing fragment
            concepts.update(item.concepts)
            relationships.update(item.relationships)
            sources.update(item.sources)
            raw_objects.update(item._raw_pyrel_objects)
            parent_names.update(item._parent_names_by_eid)

        elif isinstance(item, ECSConcept):
            # Already an ECS component - add directly
            concepts[item.name.lower()] = item

        elif isinstance(item, ECSRelationship):
            # Already an ECS component - add directly
            relationships[item.name.lower()] = item

        elif isinstance(item, ECSSource):
            # Already an ECS component - add directly
            sources[item.fqn] = item

        else:
            raise TypeError(f"Unknown type for fragment conversion: {type(item)}")

    fragment = PyRelModelFragment(
        concepts=concepts,
        relationships=relationships,
        sources=sources,
    )
    # Set private attributes after construction (required for PrivateAttr)
    fragment._raw_pyrel_objects = raw_objects
    fragment._parent_names_by_eid = parent_names

    # We attempt to resolve after every way a fragment is created, including merging, which simulates lazy resolution
    fragment.resolve_all_parents()

    return fragment
