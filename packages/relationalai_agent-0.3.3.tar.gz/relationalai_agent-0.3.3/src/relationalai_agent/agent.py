from __future__ import annotations

from typing import Any, AsyncIterator, Sequence, Generator
from pydantic import BaseModel

from .auth import TokenHandler


# Import agent-shared Pydantic types
from relationalai_agent_shared import (
    CapabilityConfig,
    ExecuteCodeEvent,
    Quotas,
    StreamEventType,
)
from relationalai_agent_shared.ecs.model import Model as ECSModel

# Import SDK-specific types with client-side helpers
from .context import AgentContext, ContextItem
from .converters import fragment_from_pyrel, _NoCommitTransaction
from .events import ResultEvent
from .results import DataResult
from .model_fragment import PyRelModelFragment
from .results import Result
from .config import AgentConfig


################################################################################
# Usage
################################################################################


class UsageTracker(BaseModel):
    name: str
    value: Any


class Usage(BaseModel):
    # TODO v0.1: Track usage from StatusEvents
    trackers: list[UsageTracker] = []


################################################################################
# Response
################################################################################


class Response:
    def __init__(self):
        self.results: list[Result] = []
        self.usage: Usage = Usage()


class StreamResponse(Response):
    def __init__(
        self, event_stream: AsyncIterator[StreamEventType], agent: Agent | None = None
    ):
        super().__init__()
        self._stream = event_stream
        self._agent = agent

    def __aiter__(self) -> AsyncIterator[StreamEventType]:
        return self

    async def __anext__(self) -> StreamEventType:
        event = await self._stream.__anext__()
        if isinstance(event, ResultEvent):
            if event.result is not None:
                self.results.append(event.result)
        elif isinstance(event, ExecuteCodeEvent) and self._agent:
            # Automatically execute code with agent's PyRel context
            print(
                f"\n--- ExecuteCodeEvent ({event.language}) ---\n{event.code}\n--- end generated code ---\n"
            )
            pyrel_result = self._agent.execute_code(event.code, event.language)
            # Convert PyRel result to DataResult and accumulate
            if pyrel_result is not None:
                df = pyrel_result.to_df()
                data_result = DataResult(data=df.to_dict(orient="records"))
                self.results.append(data_result)
                event._executed_result = pyrel_result  # type: ignore
        return event


class Question:
    def __init__(
        self,
        question: str,
        endpoint: str,
        capabilities: CapabilityConfig | None,
        quotas: Quotas | None,
        context: PyRelModelFragment,
        agent: Agent | None = None,
        token_handler: TokenHandler | None = None,
    ):
        self._question = question
        self._endpoint = endpoint
        self._capabilities = capabilities
        self._quotas = quotas
        self._context = context
        self._agent = agent
        self._token_handler = token_handler
        self._cached_response: Response | None = None

    def __await__(self) -> Generator[Any, None, Response]:
        return self._get_response().__await__()

    async def _get_response(self) -> Response:
        if self._cached_response:
            return self._cached_response

        response = Response()
        stream = self.stream()
        async for _event in stream:
            pass  # StreamResponse accumulates state

        response.results = stream.results
        response.usage = stream.usage
        self._cached_response = response
        return response

    def stream(self) -> StreamResponse:
        """Get or create the stream response - cached after first call."""
        if not hasattr(self, "_stream_response"):
            from .transport import create_sse_stream

            event_stream = create_sse_stream(
                self._endpoint,
                self._question,
                self._capabilities,
                self._quotas,
                self._context,
                token_handler=self._token_handler,
            )
            # FIXME: ECS computed properties need a model context for
            # model_dump() serialization. Wrap the stream so the agent's
            # model is active when the generator body runs.
            if self._agent and self._agent._ecs_model:
                event_stream = _wrap_with_model(event_stream, self._agent._ecs_model)
            self._stream_response = StreamResponse(event_stream, agent=self._agent)
        return self._stream_response


async def _wrap_with_model(
    stream: AsyncIterator[StreamEventType], model: ECSModel
) -> AsyncIterator[StreamEventType]:
    """Wrap an async stream so it runs inside an ECS model context."""
    with model:
        async for event in stream:
            yield event


################################################################################
# Agent
################################################################################


class Agent:
    def __init__(
        self,
        config: AgentConfig,
        capabilities: CapabilityConfig | None = None,
        quotas: Quotas | None = None,
    ) -> None:
        self._config = config
        self._capabilities = capabilities or config.capabilities
        self._quotas = quotas or config.quotas
        self._context: list[
            PyRelModelFragment
        ] = []  # Store fragments, not individual items
        self._endpoint = config.endpoint
        self._token_handler = config.token_handler

        # FIXME: ECS components use computed properties backed by relation stores
        # that require an active Model context. This model holds the relation data
        # for fragments created by this agent. It must be entered as a context
        # manager around any code that reads/writes ECS computed properties.
        self._ecs_model = ECSModel(id=f"__agent_{id(self)}__")

    def _try_resolve_token_handler(self, context: tuple[ContextItem, ...]) -> None:
        """Auto-resolve a TokenHandler from pyrel context items if one wasn't provided.

        Walks the context items looking for a pyrel Config (via Model or
        Concept/Relationship._model) and creates a TokenHandler from it.
        This lets users skip explicit token_handler config when their
        raiconfig.toml already has direct-access auth configured.
        """
        if self._token_handler is not None:
            return

        from relationalai.semantics import (
            Concept as PyrelConcept,
            Model as PyrelModel,
            Relationship as PyrelRelation,
        )

        for item in context:
            config = None
            if isinstance(item, PyrelModel):
                config = item._config
            elif isinstance(item, (PyrelConcept, PyrelRelation)) and item._model:
                config = item._model._config

            if config is not None:
                try:
                    self._token_handler = TokenHandler.from_config(config)
                except Exception:
                    pass  # No direct-access auth configured — that's fine
                return

    def use(self, *context: ContextItem) -> AgentContext:
        """Add context items to the agent.

        Context items can be either raw pyrel objects (Concept, Relationship, Table, Model)
        or wrapped Pydantic models from agent-shared. Raw pyrel objects are automatically
        converted to wrapped Pydantic models.

        Args:
            *context: Variable number of context items (raw or wrapped)

        Returns:
            AgentContext that can be used to drop the context items later
        """
        self._try_resolve_token_handler(context)

        # Convert all items to ModelFragment (handles all PyRel types and Model extraction)
        with self._ecs_model, _NoCommitTransaction(self._ecs_model):
            fragment = fragment_from_pyrel(*context)

        # Add fragment to context stack
        self._context.append(fragment)

        return AgentContext(self, fragment)

    def get_effective_context(self) -> PyRelModelFragment:
        """Merge all context fragments into a single composite fragment.

        Returns:
            Composite PyRelModelFragment containing all concepts, relationships, and sources
            from the context stack, with later fragments overriding earlier ones.
        """
        if not self._context:
            return PyRelModelFragment(concepts={}, relationships={}, sources={})

        # Reduce the stack by merging left to right
        # Note: merge() automatically resolves parent names to EIDs
        result = self._context[0]
        for fragment in self._context[1:]:
            result = result.merge(fragment)

        return result

    def drop(self, fragment: PyRelModelFragment) -> None:
        """Remove a fragment from the context stack.

        Args:
            fragment: The PyRelModelFragment to remove
        """
        if fragment in self._context:
            self._context.remove(fragment)

    def execute_code(self, code: str, language: str = "python") -> Any:
        """Execute code with PyRel model context.

        This is called automatically when ExecuteCodeEvent is received during streaming.
        The code should assign results to a variable named 'result'.

        Args:
            code: Python code to execute
            language: Programming language (currently only 'python' supported)

        Returns:
            The value of the 'result' variable after execution, or None
        """
        if language != "python":
            raise ValueError(f"Unsupported language: {language}")

        # Get merged context with proper override semantics
        effective_context = self.get_effective_context()
        namespace = dict(effective_context._raw_pyrel_objects)

        # Add query functions
        from relationalai.semantics import select, where, count, per, sum, avg, min, max

        namespace.update(
            {
                "select": select,
                "where": where,
                "count": count,
                "per": per,
                "sum": sum,
                "avg": avg,
                "mean": avg,  # Alias for avg
                "min": min,
                "max": max,
            }
        )

        # Execute the code
        exec(code, namespace)

        # Return the result variable
        return namespace.get("result")

    def ask(
        self,
        question: str,
        *,
        capabilities: CapabilityConfig | None = None,
        quotas: Quotas | None = None,
        context: Sequence[ContextItem] | None = None,
    ) -> Question:
        effective_capabilities = capabilities or self._capabilities
        effective_quotas = quotas or self._quotas
        # Get agent's merged context
        effective_context = self.get_effective_context()
        # Merge with any additional context items provided to this call
        if context:
            with self._ecs_model, _NoCommitTransaction(self._ecs_model):
                additional_fragment = fragment_from_pyrel(*context)
            effective_context = effective_context.merge(additional_fragment)
        return Question(
            question,
            self._endpoint,
            effective_capabilities,
            effective_quotas,
            effective_context,
            agent=self,
            token_handler=self._token_handler,
        )
