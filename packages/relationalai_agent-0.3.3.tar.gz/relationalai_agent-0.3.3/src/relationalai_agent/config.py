"""Configuration for pyrel agent SDK.

This module provides configuration for agent-level defaults including
quotas and capabilities. Intended to be nested in pyrel's root config.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .auth import TokenHandler
from relationalai_agent_shared import CapabilityConfig, Quotas


class AgentConfig(BaseModel):
    """Agent configuration with defaults for quotas and capabilities.

    This configuration allows you to set agent-level defaults that will be
    applied to all requests unless explicitly overridden.

    Example usage in pyrel config:
        [agent]
        endpoint = "http://localhost:8000/ask"

        [agent.capabilities]
        query = true
        optimize = false
        predict = false
        visualize = false

        [agent.quotas]
        max_execution_time = 300  # seconds
        max_llm_tokens = 100000
        max_llm_calls = 50
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Server endpoint
    endpoint: str = Field(
        default="http://localhost:8000/ask",
        description="Model server endpoint URL",
    )

    # Default capabilities
    capabilities: CapabilityConfig = Field(
        default_factory=CapabilityConfig,
        description="Default capabilities for agent requests",
    )

    # Default quotas
    quotas: Quotas = Field(
        default_factory=Quotas,
        description="Default resource quotas for agent requests",
    )

    # Authentication
    token_handler: TokenHandler | None = Field(
        default=None,
        description="Token handler for SPCS authentication. When set, auth headers are added to SSE requests.",
    )
