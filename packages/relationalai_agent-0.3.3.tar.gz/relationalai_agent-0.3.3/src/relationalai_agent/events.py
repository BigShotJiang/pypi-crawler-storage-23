"""SDK-specific event types with result conversion.

This module provides SDK-specific event types that convert agent-shared results
to SDK results with client-side helpers.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field, field_validator

# Import base event from agent-shared
from relationalai_agent_shared import (
    ResultEvent as SharedResultEvent,
    Result as SharedResult,
)

# Import SDK results with helpers
from .results import DataResult, ProseResult, Result


class ResultEvent(SharedResultEvent):
    """SDK ResultEvent that converts results to SDK types with helpers."""

    type: Literal["result"] = Field(default="result", frozen=True)
    result: Result | None  # SDK result type with helpers, None for filtered intermediates

    @field_validator("result", mode="before")
    @classmethod
    def convert_result(cls, value: SharedResult | dict) -> Result | None:
        """Convert agent-shared result to SDK result with helpers.

        Returns None for intermediate result types (interpretation, query_plan, etc.)
        that the SDK doesn't surface to callers.
        """
        if isinstance(value, dict):
            result_type = value.get("type")
            if result_type == "data":
                return DataResult(**value)
            elif result_type == "prose":
                return ProseResult(**value)
            else:
                # Intermediate results (interpretation, query_plan, etc.) — skip
                return None

        if hasattr(value, "type"):
            if value.type == "data":
                return DataResult(**value.model_dump())
            elif value.type == "prose":
                return ProseResult(**value.model_dump())

        return None
