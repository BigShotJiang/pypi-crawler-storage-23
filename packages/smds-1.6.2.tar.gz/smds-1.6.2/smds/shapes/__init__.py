from .base_shape import BaseShape

__all__ = ["BaseShape"]
