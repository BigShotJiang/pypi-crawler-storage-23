"""Dashboard contract tests.

Verify that API response shapes match what the static dashboard (app.js) expects.

Known mismatches in app.js (tracked for follow-up fix):
- app.js reads `job.stdout` but API returns `stdout_tail`
- app.js reads `job.stderr` but API returns `stderr_tail`
- app.js reads `job.assigned_gpus` but API returns `scheduled_gpus`
"""

from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from radix_edge.db import init_db, close_db
from radix_local.app import create_local_app


@pytest.fixture
def local_app():
    init_db()
    app = create_local_app()
    yield app
    close_db()


@pytest_asyncio.fixture
async def client(local_app):
    transport = ASGITransport(app=local_app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac


class TestSystemEndpointContract:
    """Verify /v1/system returns all fields the dashboard reads."""

    @pytest.mark.asyncio
    async def test_system_has_all_dashboard_fields(self, client):
        resp = await client.get("/v1/system")
        assert resp.status_code == 200
        data = resp.json()

        # Fields read by app.js: fetchSystemInfo()
        required_fields = {"platform", "python", "docker_available", "nvidia_smi_available", "mode", "version"}
        assert required_fields.issubset(data.keys()), f"Missing fields: {required_fields - data.keys()}"

    @pytest.mark.asyncio
    async def test_system_field_types(self, client):
        data = (await client.get("/v1/system")).json()
        assert isinstance(data["platform"], str)
        assert isinstance(data["python"], str)
        assert isinstance(data["docker_available"], bool)
        assert isinstance(data["nvidia_smi_available"], bool)
        assert isinstance(data["mode"], str)
        assert isinstance(data["version"], str)


class TestJobsListContract:
    """Verify /v1/jobs returns the shape the dashboard expects."""

    @pytest.mark.asyncio
    async def test_jobs_list_is_dict_with_jobs_key(self, client):
        resp = await client.get("/v1/jobs")
        assert resp.status_code == 200
        data = resp.json()
        assert "jobs" in data
        assert isinstance(data["jobs"], list)

    @pytest.mark.asyncio
    async def test_submitted_job_has_required_fields(self, client):
        """Submit a job and verify the list response contains all dashboard fields."""
        submit_resp = await client.post("/v1/jobs", json={
            "image": "ubuntu:22.04",
            "num_gpus": 1,
            "priority": 5,
            "user_id": "test-user",
        })
        assert submit_resp.status_code == 201

        resp = await client.get("/v1/jobs")
        jobs = resp.json()["jobs"]
        assert len(jobs) >= 1

        job = jobs[0]
        # Fields the dashboard reads in renderJobs()
        dashboard_fields = {"job_id", "status", "image", "num_gpus", "priority", "created_at", "scheduled_gpus"}
        assert dashboard_fields.issubset(job.keys()), f"Missing fields: {dashboard_fields - job.keys()}"

        # Verify correct field names (NOT the old mismatched names)
        assert "stdout_tail" in job  # NOT "stdout"
        assert "stderr_tail" in job  # NOT "stderr"
        assert "scheduled_gpus" in job  # NOT "assigned_gpus"


class TestJobDetailContract:
    """Verify /v1/jobs/{id} returns the shape the dashboard expects."""

    @pytest.mark.asyncio
    async def test_job_detail_fields(self, client):
        submit_resp = await client.post("/v1/jobs", json={"image": "ubuntu:22.04"})
        job_id = submit_resp.json()["job_id"]

        resp = await client.get(f"/v1/jobs/{job_id}")
        assert resp.status_code == 200
        job = resp.json()

        # Core fields
        assert "job_id" in job
        assert "status" in job
        assert "image" in job

        # Output fields (correct names)
        assert "stdout_tail" in job
        assert "stderr_tail" in job
        assert "exit_code" in job
        assert "error_message" in job
        assert "runtime_seconds" in job


class TestGpusListContract:
    """Verify /v1/gpus returns the shape the dashboard expects."""

    @pytest.mark.asyncio
    async def test_gpus_list_structure(self, client):
        resp = await client.get("/v1/gpus")
        assert resp.status_code == 200
        data = resp.json()
        assert "gpus" in data
        assert isinstance(data["gpus"], list)

    @pytest.mark.asyncio
    async def test_gpu_fields_if_present(self, client):
        """If GPUs are detected, verify field names match dashboard expectations."""
        resp = await client.get("/v1/gpus")
        gpus = resp.json()["gpus"]
        if not gpus:
            pytest.skip("No GPUs detected — cannot verify field names")

        gpu = gpus[0]
        dashboard_fields = {
            "gpu_index", "name", "memory_total_mb", "memory_used_mb",
            "utilization_pct", "temperature_c", "status",
        }
        assert dashboard_fields.issubset(gpu.keys()), f"Missing fields: {dashboard_fields - gpu.keys()}"


class TestBrainConfigContract:
    """Verify /v1/config/brain returns the shape the dashboard expects."""

    @pytest.mark.asyncio
    async def test_brain_config_returns_dict(self, client):
        resp = await client.get("/v1/config/brain")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, dict)

        # BrainParams fields the dashboard renders
        expected_params = {"tau", "alpha", "ema_beta"}
        assert expected_params.issubset(data.keys()), f"Missing params: {expected_params - data.keys()}"
