"""Tests for the Radix Local CLI commands."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from radix_local.cli.main import app

runner = CliRunner()


class TestStart:
    """Tests for the start command."""

    def test_help(self):
        result = runner.invoke(app, ["start", "--help"])
        assert result.exit_code == 0
        assert "Start the Radix Local server" in result.output

    @patch("radix_local.config.ensure_local_defaults")
    @patch("radix_local.app.create_local_app")
    @patch("uvicorn.run")
    def test_start_default_port(self, mock_uvicorn_run, mock_create_app, mock_defaults):
        mock_app = MagicMock()
        mock_create_app.return_value = mock_app
        result = runner.invoke(app, ["start", "--no-browser", "--no-tray"])
        assert result.exit_code == 0
        mock_defaults.assert_called_once()
        mock_uvicorn_run.assert_called_once_with(
            mock_app, host="127.0.0.1", port=8080, log_level="info"
        )

    @patch("radix_local.config.ensure_local_defaults")
    @patch("radix_local.app.create_local_app")
    @patch("uvicorn.run")
    def test_start_custom_port(self, mock_uvicorn_run, mock_create_app, mock_defaults):
        mock_app = MagicMock()
        mock_create_app.return_value = mock_app
        result = runner.invoke(app, ["start", "--port", "9999", "--no-browser", "--no-tray"])
        assert result.exit_code == 0
        mock_uvicorn_run.assert_called_once_with(
            mock_app, host="127.0.0.1", port=9999, log_level="info"
        )

    @patch("radix_local.config.ensure_local_defaults")
    @patch("radix_local.app.create_local_app")
    @patch("uvicorn.run")
    def test_start_no_browser_flag(self, mock_uvicorn_run, mock_create_app, mock_defaults):
        mock_create_app.return_value = MagicMock()
        result = runner.invoke(app, ["start", "--no-browser", "--no-tray"])
        assert result.exit_code == 0
        # with --no-browser the browser-opening thread isn't started at all


class TestOpen:
    """Tests for the open command."""

    def test_help(self):
        result = runner.invoke(app, ["open", "--help"])
        assert result.exit_code == 0
        assert "Open the Radix Local dashboard" in result.output

    @patch("radix_local.cli.main.webbrowser")
    def test_open_default_port(self, mock_wb):
        result = runner.invoke(app, ["open"])
        assert result.exit_code == 0
        mock_wb.open.assert_called_once_with("http://localhost:8080")

    @patch("radix_local.cli.main.webbrowser")
    def test_open_custom_port(self, mock_wb):
        result = runner.invoke(app, ["open", "--port", "9999"])
        assert result.exit_code == 0
        mock_wb.open.assert_called_once_with("http://localhost:9999")


class TestDoctor:
    """Tests for the doctor command."""

    def test_help(self):
        result = runner.invoke(app, ["doctor", "--help"])
        assert result.exit_code == 0
        assert "Check prerequisites" in result.output

    @patch("radix_local.cli.main.subprocess.run")
    @patch("radix_local.cli.main.shutil.which")
    def test_doctor_all_present(self, mock_which, mock_run):
        mock_which.side_effect = lambda cmd: f"/usr/bin/{cmd}"
        mock_run.return_value = MagicMock(returncode=0, stdout="NVIDIA RTX 4090\n")
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 0
        assert "OK" in result.output

    @patch("radix_local.cli.main.subprocess.run")
    @patch("radix_local.cli.main.shutil.which")
    def test_doctor_no_docker(self, mock_which, mock_run):
        def which_side_effect(cmd):
            if cmd == "docker":
                return None
            return f"/usr/bin/{cmd}"

        mock_which.side_effect = which_side_effect
        mock_run.return_value = MagicMock(returncode=0, stdout="NVIDIA RTX 4090\n")
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 0
        assert "MISSING" in result.output

    @patch("radix_local.cli.main.subprocess.run")
    @patch("radix_local.cli.main.shutil.which")
    def test_doctor_no_gpu(self, mock_which, mock_run):
        def which_side_effect(cmd):
            if cmd == "nvidia-smi":
                return None
            return f"/usr/bin/{cmd}"

        mock_which.side_effect = which_side_effect
        mock_run.return_value = MagicMock(returncode=0)
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 0
        assert "NOT FOUND" in result.output

    @patch("radix_local.cli.main.subprocess.run")
    @patch("radix_local.cli.main.shutil.which")
    def test_doctor_docker_not_running(self, mock_which, mock_run):
        mock_which.side_effect = lambda cmd: f"/usr/bin/{cmd}"
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 0
        assert "NOT RUNNING" in result.output
