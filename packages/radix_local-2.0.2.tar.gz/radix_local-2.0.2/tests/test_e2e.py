"""End-to-end lifecycle tests for Radix Local.

These tests exercise the full application through the HTTP API
using the real app with an in-memory database.
"""

from __future__ import annotations

import asyncio

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from radix_edge.db import init_db, close_db
from radix_local import __version__
from radix_local.app import create_local_app


@pytest.fixture
def local_app():
    init_db()
    app = create_local_app()
    yield app
    close_db()


@pytest_asyncio.fixture
async def client(local_app):
    transport = ASGITransport(app=local_app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac


class TestJobLifecycle:
    """Full job lifecycle: submit -> query -> cancel."""

    @pytest.mark.asyncio
    async def test_submit_query_cancel(self, client):
        # Submit a job
        submit_resp = await client.post("/v1/jobs", json={
            "image": "ubuntu:22.04",
            "num_gpus": 1,
            "priority": 5,
            "user_id": "e2e-test",
        })
        assert submit_resp.status_code == 201
        job_id = submit_resp.json()["job_id"]
        assert job_id.startswith("job-")

        # Query the job
        get_resp = await client.get(f"/v1/jobs/{job_id}")
        assert get_resp.status_code == 200
        job = get_resp.json()
        assert job["status"] == "queued"
        assert job["image"] == "ubuntu:22.04"
        assert job["user_id"] == "e2e-test"

        # Cancel the job
        cancel_resp = await client.delete(f"/v1/jobs/{job_id}")
        assert cancel_resp.status_code == 200
        assert cancel_resp.json()["status"] == "cancelled"

        # Verify it's cancelled
        verify_resp = await client.get(f"/v1/jobs/{job_id}")
        assert verify_resp.json()["status"] == "cancelled"

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_job(self, client):
        resp = await client.delete("/v1/jobs/job-does-not-exist")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_get_nonexistent_job(self, client):
        resp = await client.get("/v1/jobs/job-does-not-exist")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_double_cancel(self, client):
        """Cancelling an already-cancelled job should return 409."""
        submit_resp = await client.post("/v1/jobs", json={"image": "ubuntu:22.04"})
        job_id = submit_resp.json()["job_id"]

        # First cancel succeeds
        resp1 = await client.delete(f"/v1/jobs/{job_id}")
        assert resp1.status_code == 200

        # Second cancel returns 409 (terminal state)
        resp2 = await client.delete(f"/v1/jobs/{job_id}")
        assert resp2.status_code == 409


class TestGpuEndpoint:
    """GPU listing endpoint tests."""

    @pytest.mark.asyncio
    async def test_gpu_list_returns_200(self, client):
        resp = await client.get("/v1/gpus")
        assert resp.status_code == 200
        data = resp.json()
        assert "gpus" in data
        assert isinstance(data["gpus"], list)


class TestSystemEndpoint:
    """System info endpoint E2E tests."""

    @pytest.mark.asyncio
    async def test_system_reflects_local_mode(self, client):
        resp = await client.get("/v1/system")
        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "local"
        assert data["version"] == __version__

    @pytest.mark.asyncio
    async def test_system_platform_is_nonempty(self, client):
        data = (await client.get("/v1/system")).json()
        assert len(data["platform"]) > 0
        assert len(data["python"]) > 0


class TestHealthCascade:
    """Verify that health and system endpoints both work together."""

    @pytest.mark.asyncio
    async def test_healthz_and_system_both_work(self, client):
        health_resp = await client.get("/healthz")
        system_resp = await client.get("/v1/system")

        assert health_resp.status_code == 200
        assert health_resp.json()["status"] == "healthy"
        assert system_resp.status_code == 200
        assert system_resp.json()["mode"] == "local"


class TestConcurrentSubmissions:
    """Test concurrent job submissions."""

    @pytest.mark.asyncio
    async def test_concurrent_job_submit(self, client):
        """Submit 5 jobs concurrently — all should succeed."""
        async def submit_job(idx):
            resp = await client.post("/v1/jobs", json={
                "image": f"test-image-{idx}",
                "user_id": f"user-{idx}",
            })
            return resp

        responses = await asyncio.gather(*[submit_job(i) for i in range(5)])
        for resp in responses:
            assert resp.status_code == 201

        # Verify all 5 jobs appear in the list
        list_resp = await client.get("/v1/jobs")
        jobs = list_resp.json()["jobs"]
        assert len(jobs) >= 5


class TestJobFiltering:
    """Test job list filtering."""

    @pytest.mark.asyncio
    async def test_filter_by_status(self, client):
        # Submit then cancel a job
        resp = await client.post("/v1/jobs", json={"image": "ubuntu:22.04"})
        job_id = resp.json()["job_id"]
        await client.delete(f"/v1/jobs/{job_id}")

        # Submit another job (stays queued)
        await client.post("/v1/jobs", json={"image": "ubuntu:22.04"})

        # Filter for queued jobs
        queued_resp = await client.get("/v1/jobs?status=queued")
        queued_jobs = queued_resp.json()["jobs"]
        assert all(j["status"] == "queued" for j in queued_jobs)

        # Filter for cancelled jobs
        cancelled_resp = await client.get("/v1/jobs?status=cancelled")
        cancelled_jobs = cancelled_resp.json()["jobs"]
        assert all(j["status"] == "cancelled" for j in cancelled_jobs)

    @pytest.mark.asyncio
    async def test_filter_by_user(self, client):
        await client.post("/v1/jobs", json={"image": "ubuntu:22.04", "user_id": "alice"})
        await client.post("/v1/jobs", json={"image": "ubuntu:22.04", "user_id": "bob"})

        alice_resp = await client.get("/v1/jobs?user_id=alice")
        alice_jobs = alice_resp.json()["jobs"]
        assert all(j["user_id"] == "alice" for j in alice_jobs)
