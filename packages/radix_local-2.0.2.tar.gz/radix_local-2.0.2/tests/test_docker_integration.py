"""Docker integration tests for Radix Local.

These tests build and run the actual Docker image. They are SKIPPED by default
and only run when RADIX_DOCKER_TESTS=1 is set. They require Docker to be
installed and running.

Usage:
    RADIX_DOCKER_TESTS=1 pytest radix-local/tests/test_docker_integration.py -v
"""

from __future__ import annotations

import os
import subprocess
import time

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("RADIX_DOCKER_TESTS"),
    reason="Set RADIX_DOCKER_TESTS=1 to run Docker integration tests",
)

IMAGE_NAME = "radix-local-test"
CONTAINER_NAME = "radix-local-test-container"
HOST_PORT = 18080  # Use a non-standard port to avoid conflicts


@pytest.fixture(scope="module")
def docker_image():
    """Build the Docker image once for all tests in this module."""
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    result = subprocess.run(
        ["docker", "build", "-t", IMAGE_NAME, "-f", "radix-local/Dockerfile", "."],
        cwd=repo_root,
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert result.returncode == 0, f"Docker build failed:\n{result.stderr}"
    yield IMAGE_NAME
    # Cleanup image
    subprocess.run(["docker", "rmi", IMAGE_NAME], capture_output=True)


@pytest.fixture
def docker_container(docker_image):
    """Start a container and wait for it to become healthy."""
    # Remove any leftover container with the same name
    subprocess.run(
        ["docker", "rm", "-f", CONTAINER_NAME],
        capture_output=True,
    )

    # Start the container
    result = subprocess.run(
        [
            "docker", "run", "-d",
            "--name", CONTAINER_NAME,
            "-p", f"{HOST_PORT}:8080",
            docker_image,
        ],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"Docker run failed:\n{result.stderr}"

    # Wait for healthy (up to 30 seconds)
    for _ in range(30):
        health = subprocess.run(
            ["docker", "inspect", "--format={{.State.Health.Status}}", CONTAINER_NAME],
            capture_output=True,
            text=True,
        )
        if "healthy" in health.stdout:
            break
        time.sleep(1)
    else:
        logs = subprocess.run(
            ["docker", "logs", CONTAINER_NAME],
            capture_output=True,
            text=True,
        )
        pytest.fail(f"Container did not become healthy within 30s.\nLogs:\n{logs.stdout}\n{logs.stderr}")

    yield CONTAINER_NAME

    # Cleanup
    subprocess.run(["docker", "rm", "-f", CONTAINER_NAME], capture_output=True)


class TestContainerHealth:
    """Test that the containerized app starts and serves correctly."""

    def test_healthcheck(self, docker_container):
        """Container healthcheck endpoint returns 200."""
        import httpx

        resp = httpx.get(f"http://localhost:{HOST_PORT}/healthz", timeout=5)
        assert resp.status_code == 200
        assert resp.json()["status"] == "healthy"

    def test_system_info(self, docker_container):
        """System info endpoint returns mode=local."""
        import httpx

        resp = httpx.get(f"http://localhost:{HOST_PORT}/v1/system", timeout=5)
        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "local"
        assert len(data["version"]) > 0


class TestContainerSecurity:
    """Test container security properties."""

    def test_runs_as_nonroot(self, docker_container):
        """Container should run as the 'radix' user, not root."""
        result = subprocess.run(
            ["docker", "exec", docker_container, "whoami"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert result.stdout.strip() == "radix"


class TestContainerLifecycle:
    """Test container start/stop behavior."""

    def test_graceful_shutdown(self, docker_container):
        """Container should stop gracefully within 10 seconds on SIGTERM."""
        result = subprocess.run(
            ["docker", "stop", "-t", "10", docker_container],
            capture_output=True,
            text=True,
            timeout=15,
        )
        assert result.returncode == 0

        # Verify container is stopped
        inspect = subprocess.run(
            ["docker", "inspect", "--format={{.State.Status}}", docker_container],
            capture_output=True,
            text=True,
        )
        assert "exited" in inspect.stdout
