tobiko.shell.files
------------------

.. automodule:: tobiko.shell.files
    :members:
    :imported-members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
