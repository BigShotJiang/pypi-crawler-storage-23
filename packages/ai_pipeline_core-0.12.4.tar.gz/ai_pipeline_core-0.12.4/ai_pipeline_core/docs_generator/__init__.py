"""AI-focused documentation generator."""
