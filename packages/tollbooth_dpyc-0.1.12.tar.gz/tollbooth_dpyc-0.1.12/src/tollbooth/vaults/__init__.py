"""Built-in VaultBackend implementations for tollbooth-dpyc."""

from tollbooth.vaults.thebrain import TheBrainVault

__all__ = ["TheBrainVault"]
