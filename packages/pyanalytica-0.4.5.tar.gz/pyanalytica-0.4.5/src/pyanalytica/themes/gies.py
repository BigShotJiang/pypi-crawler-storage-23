"""Gies College of Business theme."""

from pyanalytica.core.theme import GIES_THEME as theme
