"""Minimal grayscale theme."""

from pyanalytica.core.theme import MINIMAL_THEME as theme
