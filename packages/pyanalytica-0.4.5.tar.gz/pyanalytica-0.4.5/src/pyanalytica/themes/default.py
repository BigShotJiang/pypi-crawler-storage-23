"""Default colorblind-safe theme."""

from pyanalytica.core.theme import DEFAULT_THEME as theme
