"""PyAnalytica ui modules module."""
