"""PyAnalytica ui modules data module."""
