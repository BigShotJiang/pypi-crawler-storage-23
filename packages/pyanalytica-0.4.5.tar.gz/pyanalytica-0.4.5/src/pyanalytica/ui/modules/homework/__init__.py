"""Homework UI modules (Phase 4)."""
