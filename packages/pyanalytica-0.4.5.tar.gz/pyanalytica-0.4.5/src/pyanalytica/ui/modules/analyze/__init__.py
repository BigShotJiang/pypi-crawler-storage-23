"""PyAnalytica ui modules analyze module."""
