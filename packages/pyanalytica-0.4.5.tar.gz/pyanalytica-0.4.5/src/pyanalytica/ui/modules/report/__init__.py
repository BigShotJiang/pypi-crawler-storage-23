"""Report UI modules (Phase 4)."""

from pyanalytica.ui.modules.report import mod_report_builder  # noqa: F401
