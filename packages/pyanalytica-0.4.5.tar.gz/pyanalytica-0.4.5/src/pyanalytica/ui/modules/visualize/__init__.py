"""PyAnalytica ui modules visualize module."""
