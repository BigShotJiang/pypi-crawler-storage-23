"""PyAnalytica ui modules explore module."""
