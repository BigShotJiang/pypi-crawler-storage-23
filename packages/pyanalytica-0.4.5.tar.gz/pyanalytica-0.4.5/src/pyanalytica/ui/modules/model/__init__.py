"""PyAnalytica ui modules model module."""
