"""AI assistant UI modules (Phase 5)."""
