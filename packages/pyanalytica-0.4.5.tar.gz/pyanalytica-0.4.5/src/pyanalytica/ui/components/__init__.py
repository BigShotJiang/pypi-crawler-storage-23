"""PyAnalytica ui components module."""
