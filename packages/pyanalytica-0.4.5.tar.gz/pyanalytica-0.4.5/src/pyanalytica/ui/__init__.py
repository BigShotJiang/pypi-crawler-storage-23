"""PyAnalytica ui module."""
