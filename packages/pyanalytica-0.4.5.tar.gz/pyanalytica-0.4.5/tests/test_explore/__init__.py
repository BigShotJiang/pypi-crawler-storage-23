"""Explore module tests."""
