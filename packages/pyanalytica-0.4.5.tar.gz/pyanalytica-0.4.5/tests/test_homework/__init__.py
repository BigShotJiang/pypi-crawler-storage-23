"""Homework module tests."""
