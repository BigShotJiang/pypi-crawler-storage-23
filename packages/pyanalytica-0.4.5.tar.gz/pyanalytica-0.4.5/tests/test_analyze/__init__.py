"""Analyze module tests."""
