"""Report module tests."""
