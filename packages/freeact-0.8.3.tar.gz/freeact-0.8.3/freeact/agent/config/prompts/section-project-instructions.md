## Project Instructions

Follow these instructions when they are relevant to the current task.

<project-instructions>
{content}
</project-instructions>
