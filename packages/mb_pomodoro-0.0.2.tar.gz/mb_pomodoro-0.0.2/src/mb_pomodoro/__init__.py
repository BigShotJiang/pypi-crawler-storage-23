"""mb-pomodoro — macOS Pomodoro timer with a CLI-first workflow."""
