"""Pounce API client — typed wrapper for the v2 Entity API.

Supports all v2 endpoints. For new/undocumented endpoints, use the
generic ``request()`` method so you never need to wait for an SDK update.
"""

from __future__ import annotations

import os
from typing import Any, Optional

import httpx


API_BASE = "https://api.pounce.ch"
V2_PREFIX = "/api/v1/v2"


class RateLimitInfo:
    """Rate limit metadata from response headers."""

    def __init__(self, headers: httpx.Headers) -> None:
        self.remaining = int(headers.get("x-ratelimit-remaining", -1))
        self.credits_used = int(headers.get("x-credits-used", 0))

    def __repr__(self) -> str:
        return f"RateLimitInfo(remaining={self.remaining}, credits_used={self.credits_used})"


class PounceError(Exception):
    """Raised when the Pounce API returns an error."""

    def __init__(self, status_code: int, detail: Any) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Pounce API error {status_code}: {detail}")


class PounceClient:
    """Synchronous client for the Pounce v2 Entity API.

    Usage::

        from pounce_agent_data import PounceClient

        client = PounceClient(api_key="your_key")
        results, rate = client.search(q="AI companies", country="CH", limit=10)
        for company in results["items"]:
            print(company["canonical_name"], company["primary_domain"])

    For any endpoint not covered by a convenience method, use ``request()``::

        data, rate = client.request("GET", "/entities/export", params={"country": "CH", "format": "csv"})
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key or os.environ.get("POUNCE_API_KEY", "")
        self._base_url = (base_url or os.environ.get("POUNCE_API_BASE", API_BASE)).rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": "pounce-agent-data/2.1.0 python",
            },
            timeout=timeout,
        )

    def request(self, method: str, path: str, **kwargs: Any) -> tuple[Any, RateLimitInfo]:
        """Generic request against any v2 endpoint.

        ``path`` is relative to the v2 prefix, e.g. ``/entities/search``.
        Accepts any keyword arguments that ``httpx.Client.request`` supports
        (``params``, ``json``, ``content``, etc.).
        """
        response = self._client.request(method, f"{V2_PREFIX}{path}", **kwargs)
        rate = RateLimitInfo(response.headers)
        if response.status_code >= 400:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise PounceError(response.status_code, detail)
        return response.json(), rate

    # ── Search & Discovery ───────────────────────────────────────────────

    def search(
        self,
        q: Optional[str] = None,
        country: Optional[str] = None,
        city: Optional[str] = None,
        category: Optional[str] = None,
        founded_min: Optional[int] = None,
        founded_max: Optional[int] = None,
        first_seen_after: Optional[str] = None,
        first_seen_before: Optional[str] = None,
        employee_range: Optional[str] = None,
        has_domain: Optional[bool] = None,
        sort: Optional[str] = None,
        limit: int = 25,
        offset: int = 0,
        **extra_params: Any,
    ) -> tuple[dict, RateLimitInfo]:
        """Search companies with filters (1 credit)."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if q:
            params["q"] = q
        if country:
            params["country"] = country.upper()
        if city:
            params["city"] = city
        if category:
            params["category"] = category
        if founded_min is not None:
            params["founded_min"] = founded_min
        if founded_max is not None:
            params["founded_max"] = founded_max
        if first_seen_after:
            params["first_seen_after"] = first_seen_after
        if first_seen_before:
            params["first_seen_before"] = first_seen_before
        if employee_range:
            params["employee_range"] = employee_range
        if has_domain is not None:
            params["has_domain"] = str(has_domain).lower()
        if sort:
            params["sort"] = sort
        params.update(extra_params)
        return self.request("GET", "/entities/search", params=params)

    def semantic_search(
        self,
        query: str,
        country: Optional[str] = None,
        limit: int = 25,
    ) -> tuple[dict, RateLimitInfo]:
        """AI semantic search by natural language (2 credits)."""
        body: dict[str, Any] = {"query": query, "limit": limit}
        if country:
            body["country"] = country.upper()
        return self.request("POST", "/entities/search/semantic", json=body)

    def autocomplete(self, q: str, limit: int = 10) -> tuple[dict, RateLimitInfo]:
        """Fast name autocomplete (0 credits)."""
        return self.request("GET", "/entities/autocomplete", params={"q": q, "limit": limit})

    def lookup(self, domain: str) -> tuple[dict, RateLimitInfo]:
        """Look up a company by domain (1 credit)."""
        return self.request("GET", "/entities/lookup", params={"domain": domain})

    # ── Entity Detail ────────────────────────────────────────────────────

    def detail(self, entity_id: int) -> tuple[dict, RateLimitInfo]:
        """Get full company profile by ID (1 credit)."""
        return self.request("GET", f"/entities/{entity_id}")

    def officers(self, entity_id: int) -> tuple[dict, RateLimitInfo]:
        """List company officers (1 credit)."""
        return self.request("GET", f"/entities/{entity_id}/officers")

    def changes(self, entity_id: int) -> tuple[dict, RateLimitInfo]:
        """Entity change timeline (1 credit, Developer+)."""
        return self.request("GET", f"/entities/{entity_id}/changes")

    def similar(self, entity_id: int, limit: int = 10) -> tuple[dict, RateLimitInfo]:
        """Find similar entities via vector search (2 credits)."""
        return self.request("POST", f"/entities/{entity_id}/similar", json={"limit": limit})

    # ── Bulk & Export ────────────────────────────────────────────────────

    def bulk_lookup(self, domains: list[str]) -> tuple[dict, RateLimitInfo]:
        """Bulk lookup by domains, max 100 (1 credit per found)."""
        return self.request("POST", "/entities/bulk", json={"domains": domains[:100]})

    def export(self, **params: Any) -> tuple[dict, RateLimitInfo]:
        """Export as CSV/JSON (5 credits, Developer+)."""
        return self.request("GET", "/entities/export", params=params)

    # ── Matching ─────────────────────────────────────────────────────────

    def match_score(self, entity_a_id: int, entity_b_id: int) -> tuple[dict, RateLimitInfo]:
        """Compute match score between two companies (3 credits, Business+)."""
        return self.request(
            "POST", "/matching/score",
            json={"entity_a_id": entity_a_id, "entity_b_id": entity_b_id},
        )

    # ── Analytics ────────────────────────────────────────────────────────

    def analytics_overview(self) -> tuple[dict, RateLimitInfo]:
        """Platform-wide statistics & country coverage (1 credit, Developer+)."""
        return self.request("GET", "/analytics/overview")

    def analytics_countries(self) -> tuple[dict, RateLimitInfo]:
        """Entity counts per country (1 credit, Developer+)."""
        return self.request("GET", "/analytics/countries")

    def analytics_sectors(self, country: Optional[str] = None) -> tuple[dict, RateLimitInfo]:
        """Top sectors for a country (1 credit, Developer+)."""
        params: dict[str, Any] = {}
        if country:
            params["country"] = country.upper()
        return self.request("GET", "/analytics/sectors", params=params)

    def analytics_formations(self, country: Optional[str] = None) -> tuple[dict, RateLimitInfo]:
        """Entity formation trends over time (1 credit, Developer+)."""
        params: dict[str, Any] = {}
        if country:
            params["country"] = country.upper()
        return self.request("GET", "/analytics/formations", params=params)

    def analytics_geography(self, country: Optional[str] = None) -> tuple[dict, RateLimitInfo]:
        """Entity density by city (1 credit, Developer+)."""
        params: dict[str, Any] = {}
        if country:
            params["country"] = country.upper()
        return self.request("GET", "/analytics/geography", params=params)

    # ── Webhooks ─────────────────────────────────────────────────────────

    def create_webhook(self, url: str, events: list[str], filters: Optional[dict] = None) -> tuple[dict, RateLimitInfo]:
        """Register a webhook URL (0 credits, Developer+)."""
        body: dict[str, Any] = {"url": url, "events": events}
        if filters:
            body["filters"] = filters
        return self.request("POST", "/webhooks", json=body)

    def list_webhooks(self) -> tuple[dict, RateLimitInfo]:
        """List registered webhooks (0 credits, Developer+)."""
        return self.request("GET", "/webhooks")

    def delete_webhook(self, webhook_id: str) -> tuple[dict, RateLimitInfo]:
        """Delete a webhook (0 credits)."""
        return self.request("DELETE", f"/webhooks/{webhook_id}")

    def test_webhook(self, webhook_id: str) -> tuple[dict, RateLimitInfo]:
        """Send a test event to a webhook (0 credits)."""
        return self.request("POST", f"/webhooks/{webhook_id}/test")

    # ── Stats ────────────────────────────────────────────────────────────

    def stats(self) -> tuple[dict, RateLimitInfo]:
        """Get public platform statistics (free, no auth)."""
        response = self._client.get(f"{V2_PREFIX}/stats")
        rate = RateLimitInfo(response.headers)
        return response.json(), rate

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> PounceClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
