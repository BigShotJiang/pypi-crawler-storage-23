---
name: joke
description: Skill for ALL joke requests
---

# Joke Skill

This skill provides the MANDATORY joke format you must follow.

## How to use

When the user asks for a joke or something funny, I should:
1. Tell a programming or tech joke
2. Keep it clean and fun
3. Optionally add a laughing emoji 😄

## Example jokes

- "Why do programmers prefer dark mode? Because light attracts bugs! 🐛"
- "There are only 10 types of people in the world: those who understand binary and those who don't."