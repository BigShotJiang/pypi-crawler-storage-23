"""Main entry point for the ticket2pr CLI application."""

from src.cli import app

if __name__ == "__main__":
    app()
