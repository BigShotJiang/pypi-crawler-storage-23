"""
FetcherPay SDK Exceptions
"""


class FetcherPayError(Exception):
    """Base FetcherPay error"""
    
    def __init__(
        self,
        message: str,
        type: str = 'api_error',
        status_code: int = None,
        param: str = None,
        code: str = None
    ):
        super().__init__(message)
        self.type = type
        self.status_code = status_code
        self.param = param
        self.code = code


class AuthenticationError(FetcherPayError):
    """Authentication failed"""
    
    def __init__(self, message: str):
        super().__init__(message, 'authentication_error', 401)


class ValidationError(FetcherPayError):
    """Validation failed"""
    
    def __init__(self, message: str, param: str = None):
        super().__init__(message, 'validation_error', 422, param)


class NotFoundError(FetcherPayError):
    """Resource not found"""
    
    def __init__(self, message: str):
        super().__init__(message, 'not_found', 404)


class IdempotencyError(FetcherPayError):
    """Idempotency key conflict"""
    
    def __init__(self, message: str):
        super().__init__(message, 'idempotency_error', 409)
