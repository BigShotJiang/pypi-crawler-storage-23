"""
FetcherPay SDK Types
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum


class PaymentStatus(str, Enum):
    PENDING = 'pending'
    AUTHORIZED = 'authorized'
    PROCESSING = 'processing'
    SETTLED = 'settled'
    FAILED = 'failed'
    CANCELLED = 'cancelled'
    REFUNDED = 'refunded'
    PARTIALLY_REFUNDED = 'partially_refunded'


class Rail(str, Enum):
    AUTO = 'auto'
    ACH = 'ach'
    RTP = 'rtp'
    CARD = 'card'
    CRYPTO = 'crypto'


class AccountType(str, Enum):
    ASSET = 'asset'
    LIABILITY = 'liability'
    REVENUE = 'revenue'
    EXPENSE = 'expense'
    EQUITY = 'equity'


@dataclass
class Fee:
    amount: int
    rate: str


@dataclass
class TimelineEvent:
    status: str
    timestamp: str
    detail: str


@dataclass
class Refund:
    id: str
    payment_id: str
    amount: int
    reason: Optional[str]
    status: str
    created_at: str


@dataclass
class Payment:
    id: str
    object: str
    status: PaymentStatus
    amount: int
    currency: str
    rail: str
    rail_selected: str
    description: Optional[str]
    source: Dict[str, Any]
    destination: Dict[str, Any]
    fee: Optional[Fee]
    timeline: List[TimelineEvent]
    ledger_entry_ids: List[str]
    refunds: List[Refund]
    idempotency_key: Optional[str]
    metadata: Dict[str, Any]
    created_at: str
    updated_at: str


@dataclass
class PaymentMethod:
    id: str
    object: str
    type: str
    status: str
    bank_account: Optional[Dict[str, Any]]
    card: Optional[Dict[str, Any]]
    usdc_wallet: Optional[Dict[str, Any]]
    metadata: Dict[str, Any]
    created_at: str


@dataclass
class LedgerBalance:
    pending: int
    posted: int
    available: int


@dataclass
class LedgerAccount:
    id: str
    object: str
    name: str
    type: AccountType
    currency: str
    balance: LedgerBalance
    metadata: Dict[str, Any]
    created_at: str
    updated_at: str


@dataclass
class LedgerEntry:
    id: str
    object: str
    journal_id: str
    account_id: str
    payment_id: Optional[str]
    entry_type: str
    amount: int
    currency: str
    status: str
    description: Optional[str]
    metadata: Dict[str, Any]
    created_at: str


@dataclass
class WebhookEndpoint:
    id: str
    object: str
    url: str
    events: List[str]
    status: str
    secret: str
    metadata: Dict[str, Any]
    created_at: str


@dataclass
class ListResponse:
    data: List[Any]
    has_more: bool
    next_cursor: Optional[str]


# Request types
CreatePaymentRequest = Dict[str, Any]
CreatePaymentMethodRequest = Dict[str, Any]
CreateWebhookRequest = Dict[str, Any]
