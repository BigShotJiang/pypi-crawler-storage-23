"""
FetcherPay Python SDK
One API. Every Rail.

Example:
    >>> from fetcherpay import FetcherPay
    >>> 
    >>> client = FetcherPay(
    ...     api_key='fp_test_your_key',
    ...     environment='sandbox'
    ... )
    >>> 
    >>> payment = client.payments.create(
    ...     amount=10000,
    ...     currency='USD',
    ...     source={'payment_method_id': 'pm_123'},
    ...     destination={'payment_method_id': 'pm_456'}
    ... )
    >>> print(payment.id)
"""

from .client import FetcherPay
from .exceptions import (
    FetcherPayError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
)
from .types import (
    Payment,
    PaymentMethod,
    LedgerAccount,
    LedgerEntry,
    WebhookEndpoint,
    CreatePaymentRequest,
)

__version__ = '1.0.0'
__all__ = [
    'FetcherPay',
    'FetcherPayError',
    'AuthenticationError',
    'ValidationError',
    'NotFoundError',
    'Payment',
    'PaymentMethod',
    'LedgerAccount',
    'LedgerEntry',
    'WebhookEndpoint',
    'CreatePaymentRequest',
]
