"""
Webhooks API
"""

from typing import Optional, List, Dict, Any


class WebhooksAPI:
    """Webhooks API client"""
    
    def __init__(self, client):
        self.client = client
    
    def create(
        self,
        url: str,
        events: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None
    ) -> dict:
        """
        Create a webhook endpoint
        
        Args:
            url: Endpoint URL
            events: List of events to subscribe to
            metadata: Optional metadata
            idempotency_key: Idempotency key
        """
        data = {'url': url}
        
        if events:
            data['events'] = events
        if metadata:
            data['metadata'] = metadata
        
        return self.client._request(
            'POST',
            '/webhooks',
            json=data,
            idempotency_key=idempotency_key
        )
    
    def retrieve(self, webhook_id: str) -> dict:
        """Retrieve a webhook endpoint"""
        return self.client._request('GET', f'/webhooks/{webhook_id}')
    
    def list(
        self,
        limit: int = 25,
        cursor: Optional[str] = None
    ) -> dict:
        """List webhook endpoints"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        
        return self.client._request('GET', '/webhooks', params=params)
    
    def update(
        self,
        webhook_id: str,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> dict:
        """Update a webhook endpoint"""
        data = {}
        if url:
            data['url'] = url
        if events:
            data['events'] = events
        if metadata:
            data['metadata'] = metadata
        
        return self.client._request('PUT', f'/webhooks/{webhook_id}', json=data)
    
    def delete(self, webhook_id: str) -> None:
        """Delete a webhook endpoint"""
        self.client._request('DELETE', f'/webhooks/{webhook_id}')
