"""
Payment Methods API
"""

from typing import Optional, Dict, Any


class PaymentMethodsAPI:
    """Payment Methods API client"""
    
    def __init__(self, client):
        self.client = client
    
    def create(
        self,
        type: str,
        bank_account: Optional[Dict[str, Any]] = None,
        card: Optional[Dict[str, Any]] = None,
        usdc_wallet: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None
    ) -> dict:
        """
        Create a payment method
        
        Args:
            type: 'bank_account', 'card', or 'usdc_wallet'
            bank_account: Bank account details
            card: Card details
            usdc_wallet: USDC wallet details
            metadata: Optional metadata
            idempotency_key: Idempotency key
        """
        data = {'type': type}
        
        if bank_account:
            data['bank_account'] = bank_account
        if card:
            data['card'] = card
        if usdc_wallet:
            data['usdc_wallet'] = usdc_wallet
        if metadata:
            data['metadata'] = metadata
        
        return self.client._request(
            'POST',
            '/payment-methods',
            json=data,
            idempotency_key=idempotency_key
        )
    
    def retrieve(self, payment_method_id: str) -> dict:
        """Retrieve a payment method"""
        return self.client._request('GET', f'/payment-methods/{payment_method_id}')
    
    def list(
        self,
        limit: int = 25,
        cursor: Optional[str] = None,
        type: Optional[str] = None
    ) -> dict:
        """List payment methods"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        if type:
            params['type'] = type
        
        return self.client._request('GET', '/payment-methods', params=params)
    
    def delete(self, payment_method_id: str) -> None:
        """Delete a payment method"""
        self.client._request('DELETE', f'/payment-methods/{payment_method_id}')
