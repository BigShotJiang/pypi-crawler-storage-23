"""
Ledger API
"""

from typing import Optional


class LedgerAPI:
    """Ledger API client"""
    
    def __init__(self, client):
        self.client = client
    
    def list_accounts(
        self,
        limit: int = 25,
        cursor: Optional[str] = None,
        type: Optional[str] = None
    ) -> dict:
        """List ledger accounts"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        if type:
            params['type'] = type
        
        return self.client._request('GET', '/ledger/accounts', params=params)
    
    def retrieve_account(self, account_id: str) -> dict:
        """Retrieve a ledger account"""
        return self.client._request('GET', f'/ledger/accounts/{account_id}')
    
    def list_entries(
        self,
        limit: int = 25,
        cursor: Optional[str] = None,
        account_id: Optional[str] = None,
        payment_id: Optional[str] = None
    ) -> dict:
        """List ledger entries"""
        params = {'limit': limit}
        if cursor:
            params['cursor'] = cursor
        if account_id:
            params['account_id'] = account_id
        if payment_id:
            params['payment_id'] = payment_id
        
        return self.client._request('GET', '/ledger/entries', params=params)
    
    def retrieve_entry(self, entry_id: str) -> dict:
        """Retrieve a ledger entry"""
        return self.client._request('GET', f'/ledger/entries/{entry_id}')
