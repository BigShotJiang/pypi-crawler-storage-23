API Reference
=============

This page documents the complete AgentArmor public API, auto-generated from
source code docstrings.

Top-Level API
-------------

.. automodule:: agentarmor
   :members:
   :undoc-members:
   :show-inheritance:

Core Engine
-----------

.. automodule:: agentarmor.core
   :members:
   :undoc-members:
   :show-inheritance:

Hooks & Context Objects
-----------------------

.. automodule:: agentarmor.hooks
   :members:
   :undoc-members:
   :show-inheritance:

Exceptions
----------

.. automodule:: agentarmor.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

Pricing
-------

.. automodule:: agentarmor.pricing
   :members:
   :undoc-members:
   :show-inheritance:

Budget Module
-------------

.. automodule:: agentarmor.modules.budget
   :members:
   :undoc-members:
   :show-inheritance:

Shield Module
-------------

.. automodule:: agentarmor.modules.shield
   :members:
   :undoc-members:
   :show-inheritance:

Filter Module
-------------

.. automodule:: agentarmor.modules.filter
   :members:
   :undoc-members:
   :show-inheritance:

Recorder Module
---------------

.. automodule:: agentarmor.modules.recorder
   :members:
   :undoc-members:
   :show-inheritance:
