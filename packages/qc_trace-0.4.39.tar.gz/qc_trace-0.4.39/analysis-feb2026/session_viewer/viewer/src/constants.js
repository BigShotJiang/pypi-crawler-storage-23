export const SRC = {
  claude_code: { dot: 'bg-[#E8926C]',   badge: 'bg-[#FDF0EB] text-[#C4633E] ring-1 ring-[#E8926C]/30',   label: 'Claude Code' },
  codex_cli:   { dot: 'bg-[#10A37F]',   badge: 'bg-[#E6F7F2] text-[#0D7D61] ring-1 ring-[#10A37F]/30',   label: 'Codex CLI' },
  gemini_cli:  { dot: 'bg-[#4285F4]',   badge: 'bg-[#E8F0FE] text-[#1A5DC8] ring-1 ring-[#4285F4]/30',   label: 'Gemini CLI' },
  cursor:      { dot: 'bg-[#7B61FF]',   badge: 'bg-[#F0ECFF] text-[#5B45CC] ring-1 ring-[#7B61FF]/30',   label: 'Cursor' },
};
export const SRC_DEFAULT = { dot: 'bg-gray-400', badge: 'bg-gray-50 text-gray-600 ring-1 ring-gray-200', label: 'Unknown' };

export const MSG = {
  user:        { bg: 'bg-blue-50/60',    border: 'border-l-blue-400',    label: 'text-blue-600' },
  assistant:   { bg: 'bg-emerald-50/60',  border: 'border-l-emerald-400', label: 'text-emerald-600' },
  tool_call:   { bg: 'bg-amber-50/50',    border: 'border-l-amber-400',   label: 'text-amber-600' },
  tool_result: { bg: 'bg-slate-50',        border: 'border-l-slate-300',   label: 'text-slate-500' },
  thinking:    { bg: 'bg-violet-50/50',    border: 'border-l-violet-300',  label: 'text-violet-500' },
  system:      { bg: 'bg-gray-50',         border: 'border-l-gray-300',    label: 'text-gray-400' },
};

export const CODEX_TAGS = new Set(['INSTRUCTIONS', 'environment_context', 'repository_context',
  'git_diff', 'git_status', 'file_contents', 'exec_command', 'command',
  'approval_policy', 'context', 'output', 'cwd', 'shell',
  'permissions instructions']);

export const COMPACTION_SIG = 'This session is being continued from a previous conversation';

export const INTERRUPTION_CLAUDE_SIG = "The user doesn't want to proceed with this tool use";
export const INTERRUPTION_CODEX_SIG = '<turn_aborted>';
