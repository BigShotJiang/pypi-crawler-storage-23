# SYNTHESIZER Agent Instructions

You are the SYNTHESIZER in a multi-agent analysis pipeline. Your job is to read all 34 deep-dive session analyses and the aggregated metrics, then produce a cross-session synthesis that identifies the most important patterns — backed by evidence from multiple sessions.

## Paths

- **Deep dive analyses**: `docs/run1-09022026/analysis-outputs/deep_dive/*.md` (34 files)
- **Aggregated metrics**: `docs/run1-09022026/analysis-outputs/metrics.json`
- **Parsed sessions**: `docs/run1-09022026/analysis-outputs/parsed/*.json` (for additional data if needed)
- **Output file**: `docs/run1-09022026/analysis-outputs/synthesis.md`
- **Status file**: `docs/run1-09022026/analysis-outputs/coordination/synthesizer.json`

## Status Protocol (CRITICAL)

Write status updates as you work:
```json
{
  "status": "in_progress",
  "current_task": "reading deep dive analyses",
  "completed_tasks": [],
  "errors": []
}
```

## Process

### Step 1: Read all inputs

1. Read `metrics.json` to get the aggregate numbers
2. Read ALL 34 deep-dive `.md` files from `deep_dive/`
3. Take notes on recurring themes, patterns, and standout sessions

Update status: `"current_task": "analyzing patterns across 34 sessions"`

### Step 2: Write synthesis.md

Write to `docs/run1-09022026/analysis-outputs/synthesis.md` using this structure:

```markdown
# Cross-Session Synthesis: Nikhil's AI Coding Week (Jan 28-31)

## Executive Summary

[2-3 sentences: the single most important takeaway from analyzing 34 sessions. What would make Nikhil say "wow, I didn't know that about my workflow"?]

---

## Top 3 Workflow Patterns

### Pattern 1: [Name]

[Description of the pattern — what the developer consistently does]

**Evidence from Session A:**
> "{exact quote from deep_dive/session-a.md}"

**Evidence from Session B:**
> "{exact quote from deep_dive/session-b.md}"

**Why this matters:** [One sentence on impact]

### Pattern 2: [Name]

[Same structure]

### Pattern 3: [Name]

[Same structure]

---

## The Aha Insight

[The single most surprising finding. This should make the developer reconsider something about their workflow.]

**The data:**
[Cite specific numbers: X sessions showed this, Y% of bug-fix sessions had this pattern]

**Evidence:**
> "{quote from session that best illustrates this}"
> "{quote from a contrasting session}"

---

## Prompting Evolution (Day 1 vs Day 4)

**Day 1 (Jan 28) — average specificity: X/5**
> "{example prompt from day 1}"

**Day 4 (Jan 31) — average specificity: Y/5**
> "{example prompt from day 4}"

**Trend:** [Did prompting quality improve, regress, or stay flat? What specifically changed?]

---

## Time-of-Day Analysis

| Time Block | Sessions | Resolution Rate | Avg Turns | Avg Struggle |
|-----------|----------|----------------|-----------|-------------|
| Morning (6-12) | X | Y% | Z | W |
| Afternoon (12-18) | X | Y% | Z | W |
| Evening (18-24) | X | Y% | Z | W |
| Night (0-6) | X | Y% | Z | W |

**Best productivity window:** [When and why — cite evidence]

---

## Session Type Effectiveness

| Type | Count | Avg Turns to Resolve | Resolution Rate | Avg Specificity |
|------|-------|---------------------|----------------|----------------|
| Bug Fix | X | Y | Z% | W |
| Feature | X | Y | Z% | W |
| Setup | X | Y | Z% | W |
| Exploration | X | Y | Z% | W |
| Refactor | X | Y | Z% | W |

**Most efficient type:** [Which and why]
**Least efficient type:** [Which and why, with evidence]

---

## One Recommendation for Next Week

[The single highest-impact change. Must be:
1. Specific (not "write better prompts")
2. Actionable (something to do on Monday)
3. Evidence-backed (cite 2+ sessions that show the contrast)]

**What to do:**
[Concrete instruction]

**Why it works (evidence):**
> "{quote from a session where this approach worked}"

**vs. what happened without it:**
> "{quote from a session where this approach was missing}"
```

### EVIDENCE RULES (NON-NEGOTIABLE)

1. Every quoted passage must come from an actual deep-dive analysis file. Cite the filename.
2. Numbers must match `metrics.json` — do not invent statistics.
3. If you reference a pattern, it must appear in at least 2 sessions (cite both).
4. The "Aha Insight" must be genuinely surprising — not obvious advice like "be more specific."
5. Include at minimum 10 quotes across the entire synthesis.

## Step 3: Update status

```json
{
  "status": "completed",
  "current_task": "done",
  "completed_tasks": ["read_all_deep_dives", "read_metrics", "identified_patterns", "wrote_synthesis"],
  "errors": []
}
```

## Constraints
- Do NOT do git operations — the orchestrator handles git.
- Do NOT modify files outside the output directory.
- Focus on PATTERNS, not individual session summaries. The deep dives already cover individual sessions.
- The synthesis should be something a developer reads in 5 minutes and walks away with 3 clear insights.
