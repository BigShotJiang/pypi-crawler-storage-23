#!/bin/bash
# Launch 4 Claude Code agents in tmux grid, each in its own worktree with its own prompt

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROMPTS_DIR="$SCRIPT_DIR"

# Worktree paths
WT_FOUNDATION="/home/sagar/trace-wt-foundation"
WT_A1A5="/home/sagar/trace-wt-a1a5"
WT_A6A10="/home/sagar/trace-wt-a6a10"
WT_LLM="/home/sagar/trace-wt-llm"

SESSION="analyzers-$$"

# Create 4-pane tmux grid (2x2)
tmux new-session -d -s "$SESSION" -c "$WT_FOUNDATION"
tmux split-window -h -t "$SESSION" -c "$WT_A1A5"
tmux split-window -v -t "$SESSION" -c "$WT_A6A10"
tmux select-pane -t "$SESSION" -L
tmux split-window -v -t "$SESSION" -c "$WT_LLM"
tmux select-layout -t "$SESSION" tiled

# Get pane IDs in order
PANES=($(tmux list-panes -t "$SESSION" -F '#{pane_id}'))

# Map: pane -> prompt file
PROMPT_FILES=(
    "$PROMPTS_DIR/prompt-foundation.md"
    "$PROMPTS_DIR/prompt-a1a5.md"
    "$PROMPTS_DIR/prompt-a6a10.md"
    "$PROMPTS_DIR/prompt-llm.md"
)

LABELS=(
    "FOUNDATION"
    "A1-A5"
    "A6-A10"
    "LLM+CROSS"
)

# Launch claude --dangerously-skip-permissions with prompt in each pane
for i in "${!PANES[@]}"; do
    pane="${PANES[$i]}"
    prompt_file="${PROMPT_FILES[$i]}"
    label="${LABELS[$i]}"

    # Send the claude command with prompt piped from file
    tmux send-keys -t "$pane" "cat '${prompt_file}' | claude --dangerously-skip-permissions -p -" C-m
done

echo "Launched tmux session: $SESSION"
echo "  Pane 0 (top-left):     FOUNDATION  -> $WT_FOUNDATION"
echo "  Pane 1 (top-right):    A1-A5       -> $WT_A1A5"
echo "  Pane 2 (bottom-left):  LLM+CROSS   -> $WT_LLM"
echo "  Pane 3 (bottom-right): A6-A10      -> $WT_A6A10"
echo ""
echo "Attach with: tmux attach -t $SESSION"

tmux attach-session -t "$SESSION"
