# Agent State

## HARD CONSTRAINT — DO NOT IGNORE
- ALL analysis MUST filter to org LIKE 'pratilipi%' ONLY
- Update compute_dashboard_data.py and ALL scripts to add WHERE s.org LIKE 'pratilipi%'
- Re-run analysis to regenerate all JSON files with this filter
- This is a privacy constraint — do NOT analyze other orgs' data

## DATA VALIDATION — CHECK DATE RANGES
- The user suspects we are only analyzing 3-4 days of data but there should be MORE
- Analysis agent: RUN this query first and print results: SELECT org, COUNT(*), MIN(first_seen)::date, MAX(last_updated)::date FROM sessions WHERE org LIKE 'pratilipi%' GROUP BY org
- Verify the full date range is being used — do NOT accidentally filter by date
- If the local DB only has a subset, flag it in the output and AGENT_STATE.md
- Make sure overview.json reflects the actual date range and session count

## DATA CAVEAT — COMMIT DETECTION IS UNRELIABLE — DROP IT
- Commit detection is a noisy signal — STOP using it entirely
- Not all developers run git commit/push through the AI CLI — many commit manually
- Do NOT show commit counts, commit rates, "shipped vs wasted", or any commit-based metric
- Remove all commit-related insights, charts, and framing from the dashboard
- Do NOT use commits to judge developer productivity or waste

## SESSION TIME = ASSISTANT RESPONSE TIME (NOT WALL CLOCK)
- Session duration MUST be calculated as the SUM of assistant response times (time between user message and assistant reply)
- Do NOT use first_seen to last_updated — that's wall clock time and includes idle/abandoned periods
- A 67-hour "session" is a dev who left and came back days later — NOT 67 hours of work
- For each message pair, compute: assistant_timestamp - user_timestamp = response time
- Sum all response times in a session = actual AI interaction time
- If timestamps are not granular enough, use inter-message gaps < 30 minutes as a fallback
- Discard gaps > 30 minutes as idle/abandoned
- ALL session duration metrics, charts, and insights must use this methodology
- Add a tooltip/caveat explaining the methodology: "Session time = sum of AI response times, excluding idle gaps > 30 min"
- Deduct 2 points from reviewer satisfaction score for using wall clock time

## STRICTLY NO EMOJIS
- Do NOT use any emojis anywhere in the dashboard — no icons, no unicode symbols, no emoji characters
- Deduct 1 point from reviewer satisfaction score if any emojis are found
- Use text labels and CSS styling instead

## TIME DISPLAY — IST TOGGLE
- All timestamps in the dashboard must have an IST toggle (UTC <-> IST)
- Default to IST (UTC+5:30) since the team is in India
- Add a toggle button in the dashboard header to switch between UTC and IST
- Hourly activity charts, session timelines, session table — all must respect this toggle

## MANDATORY: USE OPENAI FOR QUALITATIVE ANALYSIS
- OPENAI_API_KEY is set in .local.env — load it with dotenv
- Use it for qualitative analysis: session arc narratives, prompt effectiveness scoring, intent classification, tacit knowledge extraction, self-correction root cause analysis
- Reference notebooks/003-focused-analytics/003-qualitative-report.py for patterns (LLM calls with disk caching, gpt-4o-mini)
- The reviewer will DEDUCT 2 points if qualitative analysis is still missing after this iteration
- You MUST write a new script (e.g. qualitative_analysis.py) that calls gpt-4o-mini
- Reference: notebooks/003-focused-analytics/003-qualitative-report.py for disk caching pattern
- Output: qualitative_insights.json, session_narratives.json

## COST TRANSPARENCY — NO BUDGET ASSUMPTIONS
- Do NOT say "74% of your entire AI budget" or assume knowledge of the team's budget
- Show raw numbers: total cost, cost per developer, cost per session
- Frame as "your Codex CLI spend is $X/session vs Claude Code at $Y/session" — factual comparison, not budget framing
- All cost calculations must show methodology (e.g. "based on Anthropic API pricing: $X/1M input tokens, $Y/1M output tokens")
- Add an info tooltip on every cost metric explaining how it was calculated
- Show the pricing assumptions used (model, token rates) in an "Assumptions" section or footer

## ANALYSIS ASSUMPTIONS — DISCLOSE EVERYTHING
- Add a dedicated "Methodology & Assumptions" section (collapsible) to the dashboard
- List: date range analyzed, number of sessions, org filter, pricing model used, how session time is calculated, what "active time" means, what "idle" means, how intent classification works, how cost is computed
- If the local DB only has 3-4 days of data, say so prominently — do not let the reader assume this is months of data
- Every insight card should be defensible — if challenged, the methodology must be clear

## CHART HOVER/TOOLTIP THEME — MUST MATCH DARK THEME
- All Recharts tooltip contentStyle must match the dark theme
- Use: background: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#e2e8f0'
- Do NOT use default white/light tooltips — they break the dark theme
- Check ALL chart components for consistent tooltip styling

## NLP PREPROCESSING — STRIP INSTRUCTION TAGS
- Codex CLI messages contain `<INSTRUCTION>...</INSTRUCTION>` system tags that are NOT user prompts
- Before ANY NLP analysis (intent classification, prompt effectiveness, tacit knowledge), strip these tags
- Use regex: re.sub(r'<INSTRUCTION>.*?</INSTRUCTION>', '', text, flags=re.DOTALL)
- Also strip other system tags: `<TOOL_CALL>`, `<SYSTEM>`, etc.
- Apply stopword filtering for word frequency / n-gram analysis
- Failing to strip these will produce garbage NLP results (e.g. "INSTRUCTION" as top keyword)

## QUALITATIVE INSIGHTS MUST BE UNIQUE — NOT REHASHING METRICS
- The AI/qualitative section must provide insights that CANNOT be derived from heuristic analysis
- BAD examples: "Developer X had 50 sessions" (that's just a count), "Codex is more expensive" (that's in cost section already)
- GOOD examples: "Developer X tends to abandon sessions when hitting TypeScript errors — 6 of 8 abandoned sessions involved type mismatches", "The team's prompts become increasingly vague after 4pm IST", "Developer Y's most productive pattern is starting with a specific file path in the prompt"
- The qualitative section should read like a behavioral analyst's report, not a metrics dashboard
- Each finding must cite specific evidence (session IDs, prompt snippets, patterns)
- Deduct 2 points if qualitative insights are just rephrased versions of quantitative metrics

## Status: ITERATION_8_FRONTEND_COMPLETE
## Iteration: 16
## Phase: 5 new frontend components consuming all remaining unconsumed data (CLI comparison, learning curves, token growth, active time, qualitative insights)
## Reviewer Verdict: Pending

## What exists:
- 9 JSON data files in analysis-14022026/output/ AND dashboard/public/data/ (added qualitative_insights.json)
- **Full dashboard running on localhost:5173** with 25+ sections across 15 nav tabs
- Sticky nav with scroll-spy + scroll progress bar + **IST/UTC toggle**, dark theme, Recharts, Framer Motion, 15 nav tabs
- **All values now data-driven** — no hardcoded metrics in Hero, Insights, SessionDistribution, or WorkflowPatterns
- **All chart_data.json datasets now consumed** — cli_comparison, learning_curves, token_growth, active_time, session_narratives, prompt_effectiveness (via QualitativeInsights)
- **qualitative_insights.json fully consumed** — LLM intent classification, tacit knowledge patterns, developer assessments, key findings

## Dashboard sections (in order):
1. **Hero** — Headline with active hours + zero_edit_pct from data + executive_summary + cost_context + 6 KPI cards (active AI time)
2. **Insights** — Data-driven red_flags array + 4 featured + secondary insight cards
2b. **Recommendations** *(NEW iter 7 FE)* — 5 prioritized action items from overview.json recommendations
3. **Tool Breakdown** — Tool categories bar, CLI source donut, hourly activity bar (**IST toggle now works**)
4. **Tool Frequency** — Top 20 tools as animated bars + most edited/read files
5. **Session Distribution** — Duration histogram + scatter plot with quadrant labels (no emojis) + wall-clock caveat
6. **Session Arcs** *(NEW iter 5 FE)* — Donut chart + ranked progress bars for 7 session patterns
7. **Workflow Patterns** — Top 10 workflow trigrams, AI response time histogram + stats, efficiency score distribution
8. **Intent Distribution** — Intent classification bar, per-developer stacked bar, duration breakdown donut
9. **Cost Concentration** *(NEW iter 5 FE)* — Top 10 most expensive sessions bar chart + token waste (edit vs no-edit) per dev
9b. **Repo Costs** *(NEW iter 7 FE)* — Per-repo cost breakdown bar chart + percentage bars
9c. **Session Deep Dives** *(NEW iter 7 FE)* — Expandable cards for most expensive sessions with opening prompts + tool usage
10. **Cost Breakdown** — Annualized cost projection, per-dev cost bar, spend concentration bars (NO commit pie), industry benchmark, savings opportunities
11. **Hourly Productivity** *(NEW iter 5 FE)* — ComposedChart: sessions + edits + edit rate % by hour, respects IST toggle
12. **Daily Heatmap** — Per-developer, per-day session heatmap with color intensity + totals
13. **Session Timeline** — Interactive Gantt chart with day selector, per-user rows
14. **Developer Profiles** — Expandable cards with radar charts, CLI breakdown, persona, cost, developer_summary, **session arcs per dev, avg first prompt length, active time, work schedule** *(enhanced iter 7 FE)*
15. **Wasted Reads** — Top 10 re-read files bar + impact callout
16. **Struggle Signals** — Files edited 25+ times, animated bars
17. **Session Table** — Sortable/filterable table of all sessions
18. **CLI Comparison** *(NEW iter 8 FE)* — 426x cost premium headline, cost/session bar chart, radar capability profile, per-CLI stat cards, cost share vs session share bars
19. **Learning Curves** *(NEW iter 8 FE)* — Per-developer daily cost and edit trends, trend badges (improving/worsening/stable), "all devs getting more expensive" headline
20. **Token Growth** *(NEW iter 8 FE)* — 44 accelerating sessions, per-CLI acceleration rates, median tokens/msg comparison, context window pressure callout
21. **Active Time Breakdown** *(NEW iter 8 FE)* — "Only 52% of AI time is real work", per-developer active vs idle stacked bars, active session duration histogram
22. **Qualitative Insights** *(NEW iter 8 FE)* — LLM-generated key findings, prompt intent classification bars, tacit knowledge patterns, per-developer AI assessments

## JSON consumed (comprehensive):
- overview.json -> Hero (executive_summary, cost_context, KPIs, zero_edit_pct, active_time), Recommendations (recommendations), CostBreakdown, Footer
- insights.json -> Insights (red_flags array + all insights)
- chart_data.json -> ToolBreakdown (IST toggle), SessionDistribution, IntentDistribution, DailyHeatmap, WorkflowPatterns, SessionArcs, HourlyProductivity, CostConcentration, RepoCosts (repo_costs), SessionDeepDives (session_deepdives)
- developer_profiles.json -> DeveloperProfiles (developer_summary, session_arcs per dev, avg_first_prompt_length, active_hours, work_schedule)
- tool_analysis.json -> StruggleSignals, ToolFrequency
- sessions_timeline.json -> SessionTimeline
- session_metrics.json -> SessionTable
- cost_by_developer.json -> CostBreakdown (including savings_opportunities), DeveloperProfiles

## Not yet consumed:
- chart_data.json `developer_comparison` -> radar data (using computed maxValues instead)
- chart_data.json `work_patterns` -> per-dev schedule (partially via developer_profiles work_schedule text)
- chart_data.json `error_cascades` -> tool failure rates (0.05% failure rate — not compelling enough to visualize)

## Newly consumed in iter 8:
- chart_data.json `cli_comparison` -> CLIComparison (426x headline, bar chart, radar, stat cards)
- chart_data.json `learning_curves` -> LearningCurves (daily cost/edit trends, trend badges)
- chart_data.json `token_growth` -> TokenGrowth (acceleration rates, per-CLI comparison)
- chart_data.json `active_time` -> ActiveTimeBreakdown (52% active rate, per-dev stacked bars, histogram)
- chart_data.json `session_narratives` -> SessionDeepDives (LLM narrative per expanded session)
- qualitative_insights.json -> QualitativeInsights (full new component: findings, intent classification, tacit knowledge, dev summaries)
- overview.json `total_savings_potential` -> Recommendations ($1,485/mo savings banner)
- overview.json `recommendations` `estimated_savings_monthly` + `effort` -> Recommendations (per-item savings badges)
- insights.json `codex_dominant` red flag -> Insights (auto-rendered via dynamic red_flags)

## Data validated (iter 5):
- Local DB has 327 sessions: pratilipi-platform (223) + pratilipi-ai (104)
- Date range: Feb 10-13, 2026 (3.3 days)
- This IS the full dataset in the local DB -- no data is being missed

## Changes this iteration (Iter 8 frontend):
1. **CLIComparison.tsx** (NEW) — "One CLI costs 426x more per session", cost/session bar chart, radar capability profile, per-CLI stat cards, cost share vs session share bars
2. **LearningCurves.tsx** (NEW) — Per-developer daily cost + edits trend lines, trend badges (improving/worsening/stable), "every dev getting more expensive" headline
3. **TokenGrowth.tsx** (NEW) — 44 accelerating sessions, per-CLI acceleration rate bars, median tokens/msg comparison, actionable callout
4. **ActiveTimeBreakdown.tsx** (NEW) — "Only 52% of AI time is real work", 4 KPI cards, per-dev active vs idle stacked bars, active time histogram
5. **QualitativeInsights.tsx** (NEW) — LLM key findings cards, prompt intent classification bars with vague/ambitious stats, tacit knowledge patterns, per-developer AI assessment cards
6. **SessionDeepDives.tsx** (ENHANCED) — Now shows LLM-generated narrative per session from both chart_data and qualitative_insights.json
7. **Recommendations.tsx** (ENHANCED) — Now shows $1,485/mo total savings banner, per-item estimated savings badges + effort labels, critical priority styling
8. **App.tsx** — 3 new nav tabs (CLI, Trends, Qualitative), 15 total tabs, compact nav sizing for fit
9. Clean TypeScript build (zero errors), dev server running on :5173
