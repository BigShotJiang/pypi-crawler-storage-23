export interface A01Interruptions {
  total_interrupts: number;
  sessions_with_interrupts: number;
  total_sessions: number;
  per_session: A01Session[];
}
export interface A01Session {
  session_id: string;
  interrupt_count: number;
  first_interrupt_position_pct: number | null;
  interrupt_position_bucket: string | null;
  session_recovered: boolean;
}

export interface A02Autonomy {
  global_max_streak: number;
  sessions_with_tools: number;
  total_sessions: number;
  per_session: A02Session[];
}
export interface A02Session {
  session_id: string;
  tool_calls_per_user_msg: number;
  max_tool_streak: number;
  avg_tool_streak: number;
  autonomous_segments: number;
  user_intervention_rate: number;
}

export interface A03PromptSignals {
  total_sessions: number;
  sessions_with_error_paste: number;
  sessions_with_url: number;
  sessions_with_terse: number;
  per_session: A03Session[];
}
export interface A03Session {
  session_id: string;
  has_error_paste: boolean;
  has_log_paste: boolean;
  has_url: boolean;
  has_structured_data: boolean;
  has_code_paste: boolean;
  has_terminal_output: boolean;
  prompt_is_terse: boolean;
  first_prompt_char_len: number;
}

export interface A04SessionOutcomes {
  sessions_with_edits: number;
  sessions_with_commits: number;
  sessions_with_tests: number;
  total_sessions: number;
  per_session: A04Session[];
}
export interface A04Session {
  session_id: string;
  has_edits: boolean;
  edit_count: number;
  files_edited: number;
  has_git_commit: boolean;
  has_git_push: boolean;
  has_test_run: boolean;
  has_test_pass_after_fail: boolean;
  session_ended_with_user_msg: boolean;
  git_operations: Record<string, number>;
}

export interface A05UndoRevert {
  sessions_with_undo: number;
  sessions_with_git_revert: number;
  sessions_with_ai_correction: number;
  total_sessions: number;
  per_session: A05Session[];
}
export interface A05Session {
  session_id: string;
  user_requested_undo: boolean;
  undo_request_count: number;
  git_revert_in_session: boolean;
  ai_self_corrected: boolean;
  ai_self_correction_count: number;
}

export interface A06AiClarification {
  total_clarifications: number;
  sessions_with_clarification: number;
  total_sessions: number;
  per_session: A06Session[];
}
export interface A06Session {
  session_id: string;
  clarification_count?: number;
  has_clarification?: boolean;
}

export interface A07ConversationDynamics {
  total_sessions: number;
  per_session: A07Session[];
}
export interface A07Session {
  session_id: string;
  session_start: string | null;
  total_turns: number;
  avg_ai_msgs_per_turn: number;
  deepest_turn: number;
  user_to_ai_char_ratio: number;
  session_duration_min: number;
  wall_duration_min: number | null;
  avg_gap_between_user_msgs_sec: number;
  longest_gap_sec: number;
}

export interface A08SessionLinkage {
  total_sessions: number;
  continuation_sessions: number;
  sequential_sessions: number;
  parallel_sessions: number;
  per_session: A08Session[];
}
export interface A08Session {
  session_id: string;
  is_continuation: boolean;
  compaction_count: number;
  time_gap_to_prev_session_min: number | null;
  is_sequential: boolean;
  has_parallel_sessions: boolean;
  parallel_same_repo: boolean;
}

export interface A09ToolProfile {
  total_sessions: number;
  per_session: A09Session[];
}
export interface A09Session {
  session_id: string;
  explore_count: number;
  edit_count: number;
  shell_count: number;
  plan_count: number;
  delegation_count: number;
  web_count: number;
  mcp_count: number;
  explore_edit_ratio: number;
  unique_tools_used: number;
  dominant_tool_category: string | null;
}

export interface A10ErrorDetection {
  total_shell_errors: number;
  sessions_with_errors: number;
  sessions_with_cascades: number;
  total_sessions: number;
  per_session: A10Session[];
}
export interface A10Session {
  session_id: string;
  shell_error_count: number;
  consecutive_shell_errors: number;
  error_cascade_count: number;
  error_then_user_rescue: boolean;
}

export interface C01DeveloperProfile {
  total_sessions: number;
  profile: {
    session_count: number;
    sessions_per_active_day: number;
    preferred_source: string;
    avg_prompts_per_session: number;
    avg_first_prompt_length: number;
    interrupt_rate: number;
    undo_rate: number;
    edit_session_pct: number;
    commit_session_pct: number;
    avg_autonomy_ratio: number;
    exploration_tendency: number;
    total_cost_usd: number;
  };
}

export interface WeekData {
  iso_week: string;
  sessions_count: number;
  edit_sessions_pct: number;
  interrupt_rate: number;
  avg_session_cost: number;
  total_cost: number;
  source_distribution: Record<string, number>;
}

export interface C02TeamTrends {
  total_sessions: number;
  weeks: WeekData[];
}

export interface AllData {
  a01_interruptions: A01Interruptions;
  a02_autonomy: A02Autonomy;
  a03_prompt_signals: A03PromptSignals;
  a04_session_outcomes: A04SessionOutcomes;
  a05_undo_revert: A05UndoRevert;
  a06_ai_clarification: A06AiClarification;
  a07_conversation_dynamics: A07ConversationDynamics;
  a08_session_linkage: A08SessionLinkage;
  a09_tool_profile: A09ToolProfile;
  a10_error_detection: A10ErrorDetection;
  c01_developer_profile: C01DeveloperProfile;
  c02_team_trends: C02TeamTrends;
}
