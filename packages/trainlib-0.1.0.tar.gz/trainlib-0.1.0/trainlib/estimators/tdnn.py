import logging
from collections.abc import Generator

import torch
import torch.nn.functional as F
from torch import nn, Tensor
from torch.optim import Optimizer
from torch.nn.utils.parametrizations import weight_norm

logger: logging.Logger = logging.getLogger(__name__)


class TDNNLayer(nn.Module):
    """
    Time delay neural network layer.

    Built on torch Conv1D layers, with additional support for automatic
    padding.
    """

    def __init__(
        self,
        input_channels: int,
        output_channels: int,
        kernel_size: int = 3,
        dilation: int = 1,
        lookahead: int = 0,
        pad: bool = True,
    ) -> None:
        """
        Implements a fast TDNN layer via `torch.Conv1d`.

        Note that we're restricted to the kernel shapes producible by `Conv1d`
        objects, implying (primarily) that the kernel must be symmetric and
        have equal spacing.

        For example, the symmetric but non-uniform context [-3, -2, 0, +2, +3]
        cannot be represented, while [-6, -3, 0, 3, 6] can. A few other kernel
        examples:

        kernel_size=3; dilation=1 -> [-1, 0, 1]
        kernel_size=3; dilation=3 -> [-3, 0, 3]
        kernel_size=4; dilation=2 -> [-3, -1, 1, 3]

        By default, the TDNN layer left pads the input to ensure the output has
        the same sequence length as the original input. For example, with a
        kernel size of 3 (dilation of 1) and sequence length of T=3, the
        sequence will be left padded with 2 zeros:

        [0, 0, 1, 1, 1] -> [x1, x2, x3]

        If a lookahead is specified, some number of those left zeros will be
        moved to the right. If lookahead=1, for instance, indicating 1
        additional "future frame" of context, padding will look like

        [0, 1, 1, 1, 0] -> [x1, x2, x3]

        The output x_i now sees through time step i+1.

        Parameters:
            input_channels: number of input channels
            output_channels: number of channels produced by the temporal
                convolution
            kernel_size: total size of the kernel
            dilation: dilation of receptive field, i.e., the size of the gaps
            lookahead: number of allowed lookahead frames
            pad: whether the input should be padded, producing an output with
                the same sequence length as the input
        """

        super().__init__()

        self.td_conv: nn.Module = weight_norm(
            nn.Conv1d(
                input_channels,
                output_channels,
                kernel_size=kernel_size,
                dilation=dilation,
            )
        )

        self.pad: bool = pad
        self.lookahead = lookahead
        self.receptive_field: int = (kernel_size - 1) * dilation + 1

        assert (
            self.lookahead < self.receptive_field
        ), "Lookahead cannot exceed receptive field"

    def forward(self, x: Tensor) -> Tensor:
        """
        Dimension definitions:

        - B: batch size
        - Di: input dimension at single time step (aka input channels)
        - Do: output dimension at single time step (aka output channels)
        - T: sequence length

        Parameters:
            x: input tensor, shaped [B, Di, T] (optionally w/o a batch dim)

        Returns:
            tensor shaped [B, Do, T-kernel_size]
        """

        # pad according to receptive field and lookahead s.t. output
        # shape [B, *, T]
        if self.pad:
            x = F.pad(
                x,
                (self.receptive_field - self.lookahead - 1, self.lookahead)
            )

        return self.td_conv(x)
