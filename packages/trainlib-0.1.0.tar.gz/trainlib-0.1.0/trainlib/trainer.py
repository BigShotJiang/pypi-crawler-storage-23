import os
import time
import logging
from io import BytesIO
from copy import deepcopy
from typing import Any, Self
from pathlib import Path
from collections import defaultdict
from collections.abc import Callable

import torch
from tqdm import tqdm
from torch import cuda, Tensor
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter

from trainlib.dataset import BatchedDataset
from trainlib.estimator import Estimator, EstimatorKwargs
from trainlib.transform import Transform
from trainlib.util.type import (
    SplitKwargs,
    LoaderKwargs,
    BalanceKwargs,
)
from trainlib.util.module import ModelWrapper

logger: logging.Logger = logging.getLogger(__name__)


class Trainer[I, K: EstimatorKwargs]:
    """
    Training interface for updating ``Estimators`` with ``Datasets``.
    """

    def __init__(
        self,
        estimator: Estimator[K],
        device: str | None = None,
        chkpt_dir: str = "chkpt/",
        tblog_dir: str = "tblog/",
    ) -> None:
        """
        Parameters:
            estimator: `Estimator` model object
            device: device on which to carry out training
        """

        self.device: str
        if device is None:
            self.device = "cuda" if cuda.is_available() else "cpu"
        else:
            self.device = device

        logger.info(f"> Trainer device: {self.device}")
        if self.device.startswith("cuda"):
            if torch.cuda.is_available():
                # extra cuda details
                logger.info(f"| > {cuda.device_count()=}")
                logger.info(f"| > {cuda.current_device()=}")
                logger.info(f"| > {cuda.get_device_name()=}")
                logger.info(f"| > {cuda.get_device_capability()=}")

                # memory info (in GB)
                gb = 1024**3
                memory_allocated = cuda.memory_allocated() / gb
                memory_reserved = cuda.memory_reserved() / gb
                memory_total = cuda.get_device_properties(0).total_memory / gb

                logger.info("| > CUDA memory:")
                logger.info(f"| >   {memory_total=:.2f}GB")
                logger.info(f"| >   {memory_reserved=:.2f}GB")
                logger.info(f"| >   {memory_allocated=:.2f}GB")
            else:
                logger.warning("| > CUDA device specified but not available")
        else:
            logger.info("| > Using CPU device - no additional device info")

        self.estimator = estimator
        self.estimator.to(self.device)

        self.chkpt_dir = Path(chkpt_dir).resolve()
        self.tblog_dir = Path(tblog_dir).resolve()

        self.reset()

    def reset(self) -> None:
        """
        Set base tracking parameters.
        """

        self._step: int = 0
        self._epoch: int = 0
        self._summary: dict[str, list[tuple[float, int]]] = defaultdict(list)

        self._val_loss = float("inf")
        self._best_val_loss = float("inf")
        self._stagnant_epochs = 0
        self._best_model_state_dict: dict[str, Any] = {}

    def train(
        self,
        dataset: BatchedDataset[..., ..., I],
        batch_estimator_map: Callable[[I, Self], K],
        lr: float = 1e-3,
        eps: float = 1e-8,
        max_grad_norm: float | None = None,
        max_epochs: int = 10,
        stop_after_epochs: int = 5,
        batch_size: int = 256,
        val_frac: float = 0.1,
        train_transform: Transform | None = None,
        val_transform: Transform | None = None,
        dataset_split_kwargs: SplitKwargs | None = None,
        dataset_balance_kwargs: BalanceKwargs | None = None,
        dataloader_kwargs: LoaderKwargs | None = None,
        summarize_every: int = 1,
        chkpt_every: int = 1,
        resume_latest: bool = False,
        summary_writer: SummaryWriter | None = None,
    ) -> Estimator:
        """
        Note: this method attempts to implement a general scheme for passing
        needed items to the estimator's loss function from the dataloader. The
        abstract `Estimator` base only requires the model output be provided
        for any given loss calculation, but concrete estimators will often
        require additional arguments (e.g., labels or length masks, as
        is the case with sequential models). In any case, this method defers
        any further logic to the `loss` method of the underlying estimator, so
        one should take care to synchronize the sample structure with `dataset`
        to match that expected by `self.estimator.loss(...)`.

        On batch_estimator_map:

        Dataloader collate functions are responsible for mapping a collection
        of items into an item of collections, roughly speaking. If items are
        tuples of tensors,

        [
            ( [1, 1], [1, 1] ),
            ( [2, 2], [2, 2] ),
            ( [3, 3], [3, 3] ),
        ]

        the collate function maps back into the item skeleton, producing a
        single tuple of (stacked) tensors

        ( [[1, 1],
           [2, 2],
           [3, 3]],

          [[1, 1],
           [2, 2],
           [3, 3]] )

        This function should map from batches (which should be *item shaped*,
        i.e., have an `I` skeleton, even if stacked items may be different on
        the inside) into estimator keyword arguments (type `K`).

        Parameters:
            lr: learning rate (default: 1e-3)
            eps: adam EPS (default: 1e-8)
            max_epochs: maximum number of training epochs
            stop_after_epochs: number of epochs with stagnant validation losses
                to allow before early stopping. If training stops earlier, the
                parameters for the best recorded validation score are loaded
                into the estimator before the method returns. If
                `stop_after_epochs >= max_epochs`, the estimator will train
                over all epochs and return as is, irrespective of validation
                scores.
            batch_size: size of batch to use when training on the provided
                dataset
            val_split_frac: fraction of dataset to use for validation
            chkpt_every: how often model checkpoints should be saved
            resume_latest: resume training from the latest available checkpoint
                in the `chkpt_dir`
        """

        logger.info("> Begin train loop:")
        logger.info(f"| > {lr=}")
        logger.info(f"| > {eps=}")
        logger.info(f"| > {max_epochs=}")
        logger.info(f"| > {batch_size=}")
        logger.info(f"| > {val_frac=}")
        logger.info(f"| > {chkpt_every=}")
        logger.info(f"| > {resume_latest=}")
        logger.info(f"| > with device: {self.device}")
        logger.info(f"| > core count: {os.cpu_count()}")

        writer: SummaryWriter
        dir_prefix = str(int(time.time()))
        if summary_writer is None:
            writer = SummaryWriter(f"{self.tblog_dir}")
        else:
            writer = summary_writer

        train_loader, val_loader = self.get_dataloaders(
            dataset,
            batch_size,
            val_frac=val_frac,
            train_transform=train_transform,
            val_transform=val_transform,
            dataset_split_kwargs=dataset_split_kwargs,
            dataset_balance_kwargs=dataset_balance_kwargs,
            dataloader_kwargs=dataloader_kwargs,
        )

        optimizers = self.estimator.optimizers(lr=lr, eps=eps)

        self._step = 0
        self._epoch = 1  # start from 1 for logging convenience
        while self._epoch <= max_epochs and not self._converged(
            self._epoch, stop_after_epochs
        ):
            print(f"Training epoch {self._epoch}/{max_epochs}...")
            print(f"Stagnant epochs {self._stagnant_epochs}/{stop_after_epochs}...")

            epoch_start_time = time.time()
            train_loss_sums = []
            self.estimator.train()
            with tqdm(train_loader, unit="batch") as train_epoch:
                for i, batch_data in enumerate(train_epoch):
                    est_kwargs = batch_estimator_map(batch_data, self)
                    inputs = est_kwargs["inputs"]

                    # one-time logging
                    if self._step == 0:
                        writer.add_graph(ModelWrapper(self.estimator), est_kwargs)

                    # once-per-epoch logging
                    if i == 0:
                        self.estimator.epoch_write(
                            writer,
                            step=self._step,
                            val=False,
                            **est_kwargs
                        )

                    train_losses = self.estimator.loss(**est_kwargs)
                    train_loss_items = []
                    for o_idx, optimizer in enumerate(optimizers):
                        optimizer.zero_grad()
                        train_loss = next(train_losses)

                        if len(train_loss_sums) <= o_idx:
                            train_loss_sums.append(0.0)

                        train_loss_item = train_loss.item()
                        train_loss_sums[o_idx] += train_loss_item
                        train_loss_items.append(train_loss_item)

                        train_loss.backward()

                        # clip gradients for optimizer's parameters
                        if max_grad_norm is not None:
                            opt_params = self._get_optimizer_parameters(optimizer)
                            clip_grad_norm_(opt_params, max_norm=max_grad_norm)

                        optimizer.step()

                    self._step += len(inputs)

                    for train_loss_item, train_loss_sum in zip(
                        train_loss_items,
                        train_loss_sums,
                        strict=True,
                    ):
                        train_epoch.set_postfix(loss=f"{train_loss_sum/(i+1):8.2f}")
                        self._add_summary_item("train_loss", train_loss_item)

                    estimator_metrics = self.estimator.metrics(**est_kwargs)
                    for metric_name, metric_value in estimator_metrics.items():
                        self._add_summary_item(f"train_{metric_name}", metric_value)

                self.estimator.epoch_step()

                for li, train_loss_sum in enumerate(train_loss_sums):
                    self._add_summary_item(
                        f"train_loss{li}_epoch", train_loss_sum / len(train_loader)
                    )

            if val_frac > 0:
                val_loss_sums = []
                self.estimator.eval()
                with tqdm(val_loader, unit="batch") as val_epoch:
                    for i, batch_data in enumerate(val_epoch):
                        est_kwargs = batch_estimator_map(batch_data, self)
                        inputs = est_kwargs["inputs"]

                        # once-per-epoch logging
                        if i == 0:
                            self.estimator.epoch_write(
                                writer,
                                step=self._step,
                                val=True,
                                **est_kwargs
                            )

                        val_losses = self.estimator.loss(**est_kwargs)
                        val_loss_items = []
                        for o_idx in range(len(optimizers)):
                            val_loss = next(val_losses)

                            if len(val_loss_sums) <= o_idx:
                                val_loss_sums.append(0.0)

                            val_loss_item = val_loss.item()
                            val_loss_sums[o_idx] += val_loss_item
                            val_loss_items.append(val_loss_item)

                        for val_loss_item, val_loss_sum in zip(
                            val_loss_items,
                            val_loss_sums,
                            strict=True,
                        ):
                            val_epoch.set_postfix(loss=f"{val_loss_sum/(i+1):8.2f}")
                            self._add_summary_item("val_loss", val_loss_item)

                        estimator_metrics = self.estimator.metrics(**est_kwargs)
                        for metric_name, metric_value in estimator_metrics.items():
                            self._add_summary_item(f"val_{metric_name}", metric_value)

                    for li, val_loss_sum in enumerate(val_loss_sums):
                        self._add_summary_item(
                            f"val_loss{li}_epoch", val_loss_sum / len(val_loader)
                        )

                    # convergence of multiple losses may be ambiguous
                    self._val_loss = sum(val_loss_sums) / len(val_loader)

            self._add_summary_item("epoch_time_sec", time.time() - epoch_start_time)

            if self._epoch % summarize_every == 0:
                self._summarize(writer, self._epoch)

            # save checkpoint
            if self._epoch % chkpt_every == 0:
                self.save_model(
                    self._epoch, self.chkpt_dir, dir_prefix
                )

            self._epoch += 1

        return self.estimator

    def _converged(self, epoch: int, stop_after_epochs: int) -> bool:
        converged = False

        if epoch == 1 or self._val_loss < self._best_val_loss:
            self._best_val_loss = self._val_loss
            self._stagnant_epochs = 0
            self._best_model_state_dict = deepcopy(self.estimator.state_dict())
        else:
            self._stagnant_epochs += 1

        if self._stagnant_epochs >= stop_after_epochs:
            self.estimator.load_state_dict(self._best_model_state_dict)
            converged = True

        return converged

    @staticmethod
    def get_dataloaders(
        dataset: BatchedDataset,
        batch_size: int,
        val_frac: float = 0.1,
        train_transform: Transform | None = None,
        val_transform: Transform | None = None,
        dataset_split_kwargs: SplitKwargs | None = None,
        dataset_balance_kwargs: BalanceKwargs | None = None,
        dataloader_kwargs: LoaderKwargs | None = None,
    ) -> tuple[DataLoader, DataLoader]:
        """
        Create training and validation dataloaders for the provided dataset.
        """

        if dataset_split_kwargs is None:
            dataset_split_kwargs = {}

        if dataset_balance_kwargs is not None:
            dataset.balance(**dataset_balance_kwargs)

        if val_frac <= 0:
            dataset.post_transform = train_transform
            train_loader_kwargs: LoaderKwargs = {
                "batch_size": min(batch_size, len(dataset)),
                "num_workers": 0,
                "shuffle": True,
            }
            if dataloader_kwargs is not None:
                train_loader_kwargs: LoaderKwargs = {
                    **train_loader_kwargs,
                    **dataloader_kwargs
                }

            return (
                DataLoader(dataset, **train_loader_kwargs),
                DataLoader(Dataset())
            )

        train_dataset, val_dataset = dataset.split(
            [1 - val_frac, val_frac],
            **dataset_split_kwargs,
        )

        # Dataset.split() returns light Subset objects of shallow copies of the
        # underlying dataset; can change the transform attribute of both splits
        # w/o overwriting
        train_dataset.post_transform = train_transform
        val_dataset.post_transform = val_transform

        train_loader_kwargs: LoaderKwargs = {
            "batch_size": min(batch_size, len(train_dataset)),
            "num_workers": 0,
            "shuffle": True,
        }
        val_loader_kwargs: LoaderKwargs = {
            "batch_size": min(batch_size, len(val_dataset)),
            "num_workers": 0,
            "shuffle": True,  # shuffle to prevent homogeneous val batches
        }

        if dataloader_kwargs is not None:
            train_loader_kwargs = {**train_loader_kwargs, **dataloader_kwargs}
            val_loader_kwargs = {**val_loader_kwargs, **dataloader_kwargs}

        train_loader = DataLoader(train_dataset, **train_loader_kwargs)
        val_loader = DataLoader(val_dataset, **val_loader_kwargs)

        return train_loader, val_loader

    def _summarize(self, writer: SummaryWriter, epoch: int) -> None:
        """
        Flush the training summary to the TB summary writer.
        """

        summary_values = defaultdict(list)
        for name, records in self._summary.items():
            for value, step in records:
                writer.add_scalar(name, value, step)
                summary_values[name].append(value)

        print(f"==== Epoch [{epoch}] summary ====")
        for name, values in summary_values.items():
            mean_value = torch.tensor(values).mean().item()
            print(f"> ({len(values)}) {name} :: {mean_value:.2f}")

        writer.flush()
        self._summary = defaultdict(list)

    def _get_optimizer_parameters(
        self,
        optimizer: torch.optim.Optimizer,
    ) -> list[Tensor]:
        return [
            param
            for param_group in optimizer.param_groups
            for param in param_group["params"]
            if param.grad is not None
        ]

    def _add_summary_item(self, name: str, value: float) -> None:
        self._summary[name].append((value, self._step))

    def save_model(
        self,
        epoch: int,
        chkpt_dir: str | Path,
        dir_prefix: str,
    ) -> None:
        """
        Save a model checkpoint.
        """

        model_buff = BytesIO()
        torch.save(self.estimator.state_dict(), model_buff)
        model_buff.seek(0)

        model_class = self.estimator.__class__.__name__
        chkpt_name = f"m_{model_class}-e_{epoch}.pth"

        chkpt_dir = Path(chkpt_dir, dir_prefix)
        chkpt_path = Path(chkpt_dir, chkpt_name)

        chkpt_dir.mkdir(parents=True, exist_ok=True)
        chkpt_path.write_bytes(model_buff.getvalue())

    def load_model(
        self,
        epoch: int,
        chkpt_dir: str,
    ) -> None:
        """
        Load a model checkpoint from a given epoch.

        Note that this assumes the model was saved via `Trainer.save_model()`,
        and the estimator provided to this `Trainer` instance matches the
        architecture of the checkpoint model being loaded.
        """

        model_class = self.estimator.__class__.__name__
        chkpt_name = f"m_{model_class}-e_{epoch}.pth"
        chkpt_path = Path(chkpt_dir, chkpt_name)

        model_buff = BytesIO(chkpt_path.read_bytes())
        model_buff.seek(0)

        model_dict = torch.load(model_buff, weights_only=True)
        self.estimator.load_state_dict(model_dict)
