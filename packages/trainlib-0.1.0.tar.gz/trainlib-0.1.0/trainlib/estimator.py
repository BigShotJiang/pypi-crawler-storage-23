"""
Development note

I'd rather lay out bare args and kwargs in the estimator methods, but the
allowed variance in subclasses makes this difficult. To ease the pain of typing
coordination with datasets, `loss()` / `forward()` / `metrics()` specify their
arguments through a TypedDict. This makes those signatures more portable, and
can bound type variables in other places.

In theory, even the single tensor input base currently in place could be
relaxed given the allowed variability in dataset / dataloader outputs. The
default collate function in the PyTorch `DataLoader` source leaves types like
strings and bytes unchanged, so not all kinds of data are batched into a
`Sequence`, let alone a tensor. Nevertheless, estimators are `nn.Module`
derivatives, so it's at minimum a safe assumption we'll need at least one
tensor (or *should* have one).
"""

import logging
from typing import Unpack, TypedDict
from collections.abc import Generator

from torch import nn, Tensor
from torch.optim import Optimizer
from torch.utils.tensorboard import SummaryWriter

from trainlib.util.type import OptimizerKwargs

logger: logging.Logger = logging.getLogger(__name__)


class EstimatorKwargs(TypedDict):
    inputs: Tensor


class Estimator[Kw: EstimatorKwargs](nn.Module):
    """
    Estimator base class.

    All methods that raise ``NotImplementedErrors`` are directly invoked in the
    ``Trainer.train(...)`` loop.

    Note the flexibility afforded to the signatures of `forward()`, `loss()`,
    and `metrics()` methods, which should generally have identical sets of
    arguments in inheriting classes. The base class is generic to a type `K`,
    which should be a `TypedDict` for inheriting classes (despite not being
    enforceable as an upper bound) that reflects the keyword argument
    structure for these methods.

    For instance, in a sequence prediction model with labels and masking, you
    might have something like:

    .. code-block:: python

        class PredictorKwargs(TypedDict, total=False):
            labels: list[Tensor]
            lengths: Tensor
            mask: Tensor

        class SequencePredictor(Estimator[PredictorKwargs]):
            def forward(
                self,
                input: Tensor,
                **kwargs: Unpack[PredictorKwargs],
            ) -> tuple[Tensor, ...]:
                ...

            def loss(
                self,
                input: Tensor,
                **kwargs: Unpack[PredictorKwargs],
            ) -> Generator[Tensor]:
                ...

            def metrics(
                self,
                input: Tensor,
                **kwargs: Unpack[PredictorKwargs],
            ) -> dict[str, float]:
                ...

    While `loss` and `metrics` should leverage the full set of keyword
    arguments, `forward` may not (e.g., in the example above, it shouldn't use
    `labels`).

    Subclasses of `SequencePredictor` should then be generic over subtypes of
    `PredictorKwargs`.
    """

    def forward(
        self,
        **kwargs: Unpack[Kw],
    ) -> tuple[Tensor, ...]:
        raise NotImplementedError

    def loss(
        self,
        **kwargs: Unpack[Kw],
    ) -> Generator:
        """
        Compute model loss for the given input.

        Note that the loss is implemented as a generator to support
        multi-objective estimator setups. That is, losses can be yielded in
        sequence, allowing for a training loop to propagate model parameter
        updates before the next loss function is calculated. For instance, in a
        GAN-like setup, one might first emit the D-loss, update D parameters,
        then compute the G-loss (*depending* on the updated D parameters). Such
        a scheme is not otherwise possible without bringing the intermediate
        parameter update "in house" (breaking a separation of duties with the
        train loop).
        """

        raise NotImplementedError

    def metrics(
        self,
        **kwargs: Unpack[Kw],
    ) -> dict[str, float]:
        """
        Compute metrics for the given input.
        """

        raise NotImplementedError

    def optimizers(
        self,
        **kwargs: Unpack[OptimizerKwargs],
    ) -> tuple[Optimizer, ...]:
        """
        Get optimizers for the estimator to use in training loops.

        Example providing a singular Adam-based optimizer:

        .. code-block:: python

            def optimizers(...):
                optimizer = torch.optim.AdamW(
                    self.parameters(),
                    lr=1e-3,
                    eps=1e-8,
                )
                return (optimizer,)
        """

        raise NotImplementedError

    def epoch_step(self) -> None:
        """
        Step epoch-dependent model state.

        This method should not include optimization of primary model
        parameters; that should be left to external optimizers. Instead, this
        method should step forward things like internal hyperparameter
        schedules in accordance with the expected call rate (e.g., every
        epoch).
        """

        raise NotImplementedError

    def epoch_write(
        self,
        writer: SummaryWriter,
        step: int | None = None,
        val: bool = False,
        **kwargs: Unpack[Kw],
    ) -> None:
        """
        Write epoch-dependent Tensorboard items.

        If implemented, this should supplement that which is provided in
        ``metrics()``. Tensors provided as ``input`` should include raw
        training/validation data; examples include writing raw embeddings,
        canonical visualizations of the samples (e.g., previewing images), etc.

        Parameters:
            input: batch of tensors from the current epoch
            writer: tensorboard writer instance
            step: current step in the optimization loop
            val: whether input is a validation sample
        """

        raise NotImplementedError

    def log_arch(self) -> None:
        """
        Log Estimator architecture details.
        """

        logger.info(f"> Estimator :: {self.__class__.__name__}")

        num_params = sum(
            p.numel() for p in self.parameters() if p.requires_grad
        )
        logger.info(f"| > # model parameters: {num_params}")
