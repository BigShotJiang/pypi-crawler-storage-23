import torch
from torch import nn


class ModelWrapper(nn.Module):
    def __init__(self, model: nn.Module) -> None:
        super().__init__()
        self.model = model

    #def forward(self, inputs, **kwargs): 
        #return self.model(**{"inputs": inputs, **kwargs})
    def forward(self, kwargs): 
        return self.model(**kwargs)


def get_grad_norm(model: nn.Module, p: int = 2) -> float:
    norm = 0
    for param in model.parameters():
        if not param.requires_grad or param.grad is None:
            continue
        grad_item = torch.abs(param.grad).pow(p).sum().item()
        norm += float(grad_item)

    return norm ** (1 / p)

