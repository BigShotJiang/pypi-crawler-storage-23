from typing import Any

from colorama import Style


def color_text(text: str, *colorama_args: Any) -> str:
    return f"{''.join(colorama_args)}{text}{Style.RESET_ALL}"

