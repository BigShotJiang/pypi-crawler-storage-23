from typing import Any, TypedDict
from collections.abc import Callable, Iterable

from torch import Tensor
from torch.utils.data.sampler import Sampler

from mema.dataset import BatchedDataset


class LoaderKwargs(TypedDict, total=False):
    batch_size: int
    shuffle: bool
    sampler: Sampler | Iterable | None
    batch_sampler: Sampler[list] | Iterable[list] | None
    num_workers: int
    collate_fn: Callable[[list], Any]
    pin_memory: bool
    drop_last: bool
    timeout: float
    worker_init_fn: Callable[[int], None]
    multiprocessing_context: object
    generator: object
    prefetch_factor: int
    persistent_workers: bool
    pin_memory_device: str
    in_order: bool


class SplitKwargs(TypedDict, total=False):
    dataset: BatchedDataset | None
    by_attr: str | list[str | None] | None
    shuffle_strata: bool


class BalanceKwargs(TypedDict, total=False):
    by_attr: str | list[str | None] | None
    split_min_sizes: list[int] | None
    split_max_sizes: list[int] | None
    shuffle_strata: bool


class OptimizerKwargs(TypedDict, total=False):
    lr: float | Tensor
    betas: tuple[float | Tensor, float | Tensor]
    eps: float
    weight_decay: float
    amsgrad: bool
    maximize: bool
    foreach: bool | None
    capturable: bool
    differentiable: bool
    fused: bool | None
