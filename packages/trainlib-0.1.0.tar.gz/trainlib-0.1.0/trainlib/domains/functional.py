from collections.abc import Callable, Iterator, Sequence

from trainlib.domain import Domain


class SimulatorDomain[P, R](Domain[int, R]):
    """
    Base simulator domain, generic to arbitrary callables.

    Note: we don't store simulation results here; that's left to a downstream
    object, like a `BatchedDataset`, to cache if needed. We also don't subclass
    `SequenceDataset` because the item getter type doesn't align: we accept an
    `int` in the parameter list, but don't return the items directly from that
    collection (we transform them first).
    """

    def __init__(
        self,
        simulator: Callable[[P], R],
        parameters: Sequence[P],
    ) -> None:
        self.simulator = simulator
        self.parameters = parameters

    def __getitem__(self, uri: int) -> R:
        return self.simulator(self.parameters[uri])

    def __iter__(self) -> Iterator[int]:
        return iter(range(len(self.parameters)))

    def __len__(self) -> int:
        return len(self.parameters)


class SimulatorPredictiveDomain[P, R](Domain[int, tuple[R, ...]]):
    def __init__(
        self,
        simulator: Callable[[P], R],
        parameters: Sequence[P],
        predictives: Sequence[Callable[[R], R]],
    ) -> None:
        self.simulator = simulator
        self.parameters = parameters
        self.predictives = predictives

    def __getitem__(self, uri: int) -> tuple[R, ...]:
        sample = self.simulator(self.parameters[uri])

        return (
            sample,
            *(p(sample) for p in self.predictives)
        )

    def __iter__(self) -> Iterator[int]:
        return iter(range(len(self.parameters)))

    def __len__(self) -> int:
        return len(self.parameters)
