from pathlib import Path
from collections.abc import Iterator

from mema.domain import Domain


class DiskDomain(Domain[Path, bytes]):
    def __init__(
        self,
        root: Path,
        extensions: list[str] | None = None,
    ) -> None:
        """
        Parameters:
            extensions: list of file extensions to filter for when determining
                data file paths to read. This is a whitelist, except when left
                as ``None`` (which is default), in which case all extensions
                all allowed.
        """

        self.root = root
        self.extensions = extensions

    def __getitem__(self, uri: Path) -> bytes:
        return uri.read_bytes()

    def __iter__(self) -> Iterator[Path]:
        return (
            path for path in self.root.iterdir()
            if path.is_file() and (
                self.extensions is None
                or path.suffix in self.extensions
            )
        )

    def __len__(self) -> int:
        return sum(1 for _ in iter(self))
