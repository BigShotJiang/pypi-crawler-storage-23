from io import BytesIO
from abc import abstractmethod
from typing import Any, NamedTuple
from pathlib import Path
from zipfile import ZipFile

from mema.dataset import HomogenousDataset
from mema.domains.disk import DiskDomain


class DiskDataset[T: NamedTuple](HomogenousDataset[Path, bytes, T]):
    """
    The following line is to satisfy the type checker, which

    1. Can't recognize an appropriately re-typed constructor arg like
        
       def __init__(
           self,
           domain: DiskDomain,
           ...
        ): ...

       This *does* match the parent generic for the U=Path, R=bytes context

       def __init__(
           self,
           domain: Domain[U, R],
           ...
        ): ...

       but the type checker doesn't see this.

    2. "Lifted" type variables out of generics can't be used as upper bounds,
       at least not without throwing type checker warnings (thanks to PEP695).
       So I'm not allowed to have

       ```
       class BatchedDataset[U, R, D: Domain[U, R]]:
           ...
       ```

       which could bring appropriately dynamic typing for ``Domain``s, but is
       not a sufficiently concrete upper bound.

    So: we settle for a class-level type declaration, which despite not being
    technically appropriately scoped, it's not harming anything and satisfies
    ``ty`` type checks downstream (e.g., when we access ``DiskDomain.root``.
    """

    domain: DiskDomain


class PackedDataset(DiskDataset):
    """
    Packed dataset.

    Currently out of commission - not compatible with latest dataset
    definitions. Will require a zipped disk domain

    Requires a specific dataset storage structure on the root data path:

    <data-path>/data/*-i<batch-num>-b<batch-size>
    <data-path>/meta/*-i<batch-num>-b<batch-size>

    That is, all data are compacted into core data (`data/`) and metadata
    (`meta/`) subdirectories. Compatible out-of-the-box with datasets written
    with a `Packer`.
    """

    def _get_uri_groups(self) -> list[tuple[Path, ...]]:
        data_root = Path(self.domain.root, "data")
        meta_root = Path(self.domain.root, "meta")

        data_file_paths = data_root.iterdir()
        meta_file_paths = meta_root.iterdir()

        return list(zip(data_file_paths, meta_file_paths, strict=True))

    def _process_batch_data(
        self,
        batch_data: tuple[bytes, ...],
        batch_index: int,
    ) -> list[tuple[bytes, ...]]:
        data_bytes, meta_bytes = batch_data

        meta_batch = self._unpack_meta(meta_bytes)
        data_batch = self._unpack_data(data_bytes, meta_batch)

        # zip up batch partial batch items into a single batch iterable
        # composed of item tuples
        batch_items = [
            (*ba, *bm)  # pyre-ignore[60]
            for ba, bm in zip(data_batch, meta_batch, strict=True)
        ]

        # apply transform to batch items if provided
        if self.load_transform:
            batch_items = list(map(self.load_transform, batch_items))

        return batch_items

    @abstractmethod
    def _unpack_data(
        self,
        batch_data_bytes: bytes,
        batch_meta: list[tuple[Any, ...]],
    ) -> list[tuple[Any, ...]]:
        """
        Load and unpack batch data.

        This method should be the inverse of an affiliated
        `Packer`'s `pack_data_bytes()`:

        <data list> -> pack   -> to bytes   -> blob
        <data list> <- unpack <- from bytes <- blob

        Returns:
            iterable of (partial) item tuples w/ data content
        """

        raise NotImplementedError

    @abstractmethod
    def _unpack_meta(self, batch_meta_bytes: bytes) -> list[tuple[Any, ...]]:
        """
        Load and unpack batch metadata.

        This method should be the inverse of an affiliated
        `Packer`'s `pack_meta_bytes()`:

        <data list> -> pack   -> to bytes   -> blob
        <data list> <- unpack <- from bytes <- blob

        Returns:
            iterable of (partial) item tuples w/ meta content
        """

        raise NotImplementedError


class ZippedDataset(DiskDataset):
    """
    Dataset with samples stored in ZIP files.

    This dataset base is primarily used as the type of input dataset for a
    `Packer` object. This is compatible with most raw dataset structures,
    reading down arbitrarily packaged ZIP files and "re-batching" during
    access.
    """

    item_header: tuple[str, ...] = ("bytes",)

    def _get_uri_groups(self) -> list[tuple[str, ...]]:
        zip_file_paths: list[str] = [
            str(path)
            for path in Path(self.data_path).iterdir()
            if path.suffix == ".zip"
        ]        

        # will just zip a single list yielding 1-tuples (to match type sig)
        return list(zip(zip_file_paths))

    def _process_batch_data(
        self,
        batch_data: tuple[bytes, ...],
        batch_index: int,
    ) -> list[tuple[bytes, ...]]:
        items = []
        batch_zip_file = ZipFile(BytesIO(batch_data[0]))

        for zname in batch_zip_file.namelist():
            if Path(zname).suffix not in self.extensions:
                continue

            with batch_zip_file.open(zname, "r") as zfile:
                items.append((zfile.read(), zname))

        return list(items)

