"""
Leaving the following here in case we return for some specifics in the future.
At an earlier stage, we had a few specifically typed datasets/domains for
in-memory structures, but these are almost entirely redundant with the generic
``SequenceDomain`` definition: the general retrieval and iteration behaviors
there are fairly universal and can be type-tailored without new class
definitions (unless you really want a new hierarchy).

The following were design notes on a dict/named tuple list-based dataset.

Dataset from list of (dict) records.

This is designed such that a "batch" is just a single record in the base
list. Each URI group is a singleton index tuple, which grabs its single
corresponding record in the domain when read.

One could alternatively have the entire record list be a single batch, and
have a single URI group with N null references. The null reference would
need to be the sole URI for the domain definition, and ``.read(null)``
would always return the entire list. Everything will then be handled as
expected: in ``get_item()``,

- ``._get_batch_for_item(item_index)`` maps to the singleton batch
- ``.get_batch(batch_index)[index_in_batch]`` simply indexes directly in
  the record list

This is pretty unnatural, since now a batch as returned by
``.read_resources()`` will be N references to the entire record list. It
nevertheless sidesteps full list reconstruction and allows the propagation
of direct indexing, so it has that in its corner.

Another viable approach (least preferred): have a single batch, but where
URIs map to individual row indices. In some respects, this is the most
intuitive interpretation of "batch" and how we'd map to items, but it's the
*least efficient* because the batch logic of ``BatchedDataset`` will
*reconstruct the entire record list*. In ``.read_resources()``, we have

```
return tuple(self.domain.read(uri) for uri in uri_group)
```

So, despite being a natural interpretation, it pulls apart the domain "too
well" and rebuilds it in-house. This makes sense when resources are
external (e.g., files on disk, data over network), but when already
part of the Python process, that model is wasteful.

Note: inheriting datasets will need to implement an appropriate
``_item_header``. This will be trivial for consistent datasets, since it'll
just be the keys of any of the dict records.

Left to define:

+ ``_process_item_data()``: map T to final tuple



class RecordDataset[T: NamedTuple](HomogenousDataset[int, T, T]):

    domain: TupleListDomain[T]

    def _process_batch_data(
        self,
        batch_data: T,
        batch_index: int,
    ) -> list[T]:
        Produce collection of item tuples.

        Note: no interaction with ``item_tuple`` is needed given batches are
        already singular ``item_tuple`` shaped items.

        return [batch_data]
"""

from typing import Unpack

import torch.nn.functional as F
from torch import Tensor

from trainlib.domain import SequenceDomain
from trainlib.dataset import TupleDataset, DatasetKwargs


class SlidingWindowDataset[T: Tensor](TupleDataset[T]):
    def __init__(
        self,
        domain: SequenceDomain[tuple[T, ...]],
        lookback: int,
        offset: int = 0,
        lookahead: int = 1,
        num_windows: int = 1,
        **kwargs: Unpack[DatasetKwargs],
    ) -> None:
        self.lookback = lookback
        self.offset = offset
        self.lookahead = lookahead
        self.num_windows = num_windows

        super().__init__(domain, **kwargs)

    def _process_batch_data(
        self,
        batch_data: tuple[T, ...],
        batch_index: int,
    ) -> list[tuple[T, ...]]:
        """
        Backward pads first sequence over (lookback-1) length, and steps the
        remaining items forward by the lookahead.

        Batch data:

            (Tensor[C1, T], ..., Tensor[CN, T])

        + lookback determines window size; pad left to create lookback size
          with the first element at the right:

          |-lookback-|
          [0 ... 0 T0]

          `lookback` is strictly positive, unbounded.

        + offset shifts the first such window forward. `0 <= offset < L`;
          think of it as the number of additional non-padded items we
          slide into the window from the right. At its largest value of `L-1`,
          we'll have L-sized windows with `T0` as the leftmost element.

          offset=2 
          [0 ... T0 T1 T2]
          |---lookback---|

          In effect, the index of the rightmost item of the first window
          will be equal to the value of `offset`. There are `T - offset`
          total possible windows over a given sequence (regardless of
          lookback).

        + lookahead determines the offset of the "label" slices from the
          first index, regardless of any value of `offset`.

          lookahead=3
          [0 ... 0 T0] T1 T2 [T3]
          |-lookback-|

          0 [0 .. T0 T1] T2 T3 [T4]
            |-lookback-|

          There are `T - lookahead` allowed slices, assuming the lookahead
          exceeds the offset.

        To get windows starting with the first index at the left: we first set
        out window size (call it L), determined by `lookback`. Then the
        rightmost index we want will be `L-1`, which determines our `offset`
        setting.

        lookahead=L, offset=L-1
        [ T_0 ... T_{L-1} ]

        To get a one-step lookahead in front of that rightmost item, the
        `lookahead` can be set to the index of the first label we want:

        lookback=L, offset=L-1   lookahead=L
        [ T_0 ... T_{L-1} ]      [ T_L ]

        """

        if self.pre_transform is not None:
            batch_data = self.pre_transform(batch_data)

        lb = self.lookback
        off = min(self.offset, lb-1)
        la = self.lookahead

        ws = []
        for t in batch_data[:self.num_windows]:
            # for window sized `lb`, we pad with `lb-1` zeros. We then take off
            # the amount of our offset, which in the extreme cases does no
            # padding.
            xip = F.pad(t, ((lb-1) - off, 0))

            # extract sliding windows over the padded tensor
            # unfold(-1, lb, 1) slides over the last dim, 1 step at a time, for
            # `lb`-sized windows. We turn (C_i, pad+T) shape into 
            # (C_i, T-offset, lb), giving `T-offset` total `lb` windows.
            wi = xip.unfold(-1, lb, 1)

            # (C_i, T-offset, lb) -> (T-offset, C_i, lb)
            wi = wi.permute(1, 0, 2)

            # if lookahead exceeds offset, there are some windows for which we
            # won't be able to assign a lookahead label. Cut those off here
            if la - off > 0:
                wi = wi[:-(la-off)]

            ws.append(wi)

        ys = []
        for t in batch_data[self.num_windows:]:
            # tensors (C_i, T) shaped, align with lookahead, giving a 
            # (C_i, T-lookahead)
            y = t[:, la:]

            # (C_i, T-lookahead) -> (T-lookahead, C_i)
            y = y.permute(1, 0)

            # cut off any elements if offset exceeds lookahead
            if off - la > 0:
                y = y[:-(off-la)]

            ys.append(y)

        return list(zip(*ws, *ys, strict=True))

