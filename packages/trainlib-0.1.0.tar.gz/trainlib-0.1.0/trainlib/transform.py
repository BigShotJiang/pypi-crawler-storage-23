class Transform[I]:
    """
    Dataset transform base class.

    In places that directly reference a base ``Transform[I]``, a hint
    ``Callable[[I], I]`` would suffice. This class exists to allow nominal
    checks for purpose-built transforms.
    """

    def __call__(self, item: I) -> I:
        raise NotImplementedError
