## Python 适配

使用 pytest 运行测试。
