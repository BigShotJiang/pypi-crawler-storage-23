# Copyright © 2025 Oracle and/or its affiliates.
#
# This software is under the Apache License 2.0
# (LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0) or Universal Permissive License
# (UPL) 1.0 (LICENSE-UPL or https://oss.oracle.com/licenses/upl), at your option.

from typing import List

from pyagentspec.serialization import ComponentDeserializationPlugin, ComponentSerializationPlugin

from .agent import ExtendedAgent, agent_deserialization_plugin, agent_serialization_plugin
from .contextprovider import (
    PluginConstantContextProvider,
    PluginContextProvider,
    PluginFlowContextProvider,
    PluginToolContextProvider,
    contextprovider_deserialization_plugin,
    contextprovider_serialization_plugin,
)
from .datastores.plugin import (
    wayflowcore_datastore_deserialization_plugin,
    wayflowcore_datastore_serialization_plugin,
)
from .embeddingmodels import (
    PluginEmbeddingConfig,
    PluginOciGenAiEmbeddingConfig,
    PluginOllamaEmbeddingConfig,
    PluginOpenAiCompatibleEmbeddingConfig,
    PluginOpenAiEmbeddingConfig,
    PluginVllmEmbeddingConfig,
    embeddingmodel_deserialization_plugin,
    embeddingmodel_serialization_plugin,
)
from .flow import ExtendedFlow, flow_deserialization_plugin, flow_serialization_plugin
from .managerworkers import (
    PluginManagerWorkers,
    managerworkers_deserialization_plugin,
    managerworkers_serialization_plugin,
)
from .mcp import (
    PluginMCPToolBox,
    PluginMCPToolSpec,
    PluginSSETransport,
    mcp_deserialization_plugin,
    mcp_serialization_plugin,
)
from .messagelist import PluginImageContent, PluginMessage, PluginTextContent
from .nodes import (
    ExtendedLlmNode,
    ExtendedMapNode,
    ExtendedParallelFlowNode,
    ExtendedParallelMapNode,
    ExtendedToolNode,
    PluginCatchExceptionNode,
    PluginChoiceNode,
    PluginConstantValuesNode,
    PluginExtractNode,
    PluginGetChatHistoryNode,
    PluginInputMessageNode,
    PluginOutputMessageNode,
    PluginReadVariableNode,
    PluginRegexNode,
    PluginRetryNode,
    PluginTemplateNode,
    PluginWriteVariableNode,
    nodes_deserialization_plugin,
    nodes_serialization_plugin,
)
from .outputparser import (
    PluginJsonOutputParser,
    PluginOutputParser,
    PluginPythonToolOutputParser,
    PluginReactToolOutputParser,
    PluginRegexOutputParser,
    PluginToolOutputParser,
    outputparser_deserialization_plugin,
    outputparser_serialization_plugin,
)
from .swarm import PluginSwarm, swarm_deserialization_plugin, swarm_serialization_plugin
from .template import (
    PluginPromptTemplate,
    prompttemplate_deserialization_plugin,
    prompttemplate_serialization_plugin,
)
from .tools import (
    PluginToolBox,
    PluginToolRequest,
    PluginToolResult,
    tools_deserialization_plugin,
    tools_serialization_plugin,
)
from .transforms import (
    PluginAppendTrailingSystemMessageToUserMessageTransform,
    PluginCoalesceSystemMessagesTransform,
    PluginMessageTransform,
    PluginReactMergeToolRequestAndCallsTransform,
    PluginRemoveEmptyNonUserMessageTransform,
    PluginSwarmToolRequestAndCallsTransform,
    messagetransform_deserialization_plugin,
    messagetransform_serialization_plugin,
)

all_serialization_plugin: List[ComponentSerializationPlugin] = [
    agent_serialization_plugin,
    swarm_serialization_plugin,
    managerworkers_serialization_plugin,
    mcp_serialization_plugin,
    tools_serialization_plugin,
    nodes_serialization_plugin,
    flow_serialization_plugin,
    contextprovider_serialization_plugin,
    wayflowcore_datastore_serialization_plugin,
    messagetransform_serialization_plugin,
    prompttemplate_serialization_plugin,
    outputparser_serialization_plugin,
    embeddingmodel_serialization_plugin,
]


all_deserialization_plugin: List[ComponentDeserializationPlugin] = [
    agent_deserialization_plugin,
    swarm_deserialization_plugin,
    managerworkers_deserialization_plugin,
    mcp_deserialization_plugin,
    tools_deserialization_plugin,
    nodes_deserialization_plugin,
    flow_deserialization_plugin,
    contextprovider_deserialization_plugin,
    wayflowcore_datastore_deserialization_plugin,
    messagetransform_deserialization_plugin,
    prompttemplate_deserialization_plugin,
    outputparser_deserialization_plugin,
    embeddingmodel_deserialization_plugin,
]


__all__ = [
    "PluginSSETransport",
    "PluginMCPToolBox",
    "PluginMCPToolSpec",
    "mcp_serialization_plugin",
    "mcp_deserialization_plugin",
    "PluginSwarm",
    "swarm_serialization_plugin",
    "swarm_deserialization_plugin",
    "managerworkers_serialization_plugin",
    "managerworkers_deserialization_plugin",
    "ExtendedAgent",
    "agent_serialization_plugin",
    "agent_deserialization_plugin",
    "PluginToolRequest",
    "PluginToolResult",
    "PluginToolBox",
    "tools_serialization_plugin",
    "tools_deserialization_plugin",
    "PluginCatchExceptionNode",
    "ExtendedToolNode",
    "ExtendedLlmNode",
    "ExtendedMapNode",
    "PluginExtractNode",
    "PluginInputMessageNode",
    "PluginOutputMessageNode",
    "PluginChoiceNode",
    "PluginTemplateNode",
    "PluginRegexNode",
    "PluginWriteVariableNode",
    "PluginReadVariableNode",
    "PluginConstantValuesNode",
    "PluginGetChatHistoryNode",
    "PluginRetryNode",
    "ExtendedParallelFlowNode",
    "ExtendedParallelMapNode",
    "nodes_serialization_plugin",
    "nodes_deserialization_plugin",
    "ExtendedFlow",
    "flow_serialization_plugin",
    "flow_deserialization_plugin",
    "PluginConstantContextProvider",
    "PluginContextProvider",
    "PluginFlowContextProvider",
    "PluginToolContextProvider",
    "contextprovider_serialization_plugin",
    "contextprovider_deserialization_plugin",
    "PluginAppendTrailingSystemMessageToUserMessageTransform",
    "PluginMessageTransform",
    "PluginCoalesceSystemMessagesTransform",
    "PluginRemoveEmptyNonUserMessageTransform",
    "PluginReactMergeToolRequestAndCallsTransform",
    "PluginSwarmToolRequestAndCallsTransform",
    "messagetransform_serialization_plugin",
    "messagetransform_deserialization_plugin",
    "PluginPromptTemplate",
    "prompttemplate_deserialization_plugin",
    "prompttemplate_serialization_plugin",
    "PluginOutputParser",
    "PluginPythonToolOutputParser",
    "PluginJsonOutputParser",
    "PluginToolOutputParser",
    "PluginReactToolOutputParser",
    "PluginRegexOutputParser",
    "outputparser_serialization_plugin",
    "outputparser_deserialization_plugin",
    "PluginMessage",
    "PluginTextContent",
    "PluginImageContent",
    "wayflowcore_datastore_serialization_plugin",
    "wayflowcore_datastore_deserialization_plugin",
    "PluginManagerWorkers",
    "PluginAppendTrailingSystemMessageToUserMessageTransform",
    "PluginCoalesceSystemMessagesTransform",
    "PluginMessageTransform",
    "PluginReactMergeToolRequestAndCallsTransform",
    "PluginRemoveEmptyNonUserMessageTransform",
    "messagetransform_deserialization_plugin",
    "messagetransform_serialization_plugin",
    "PluginEmbeddingConfig",
    "PluginVllmEmbeddingConfig",
    "PluginOllamaEmbeddingConfig",
    "PluginOciGenAiEmbeddingConfig",
    "PluginOpenAiCompatibleEmbeddingConfig",
    "PluginOpenAiEmbeddingConfig",
    "embeddingmodel_deserialization_plugin",
    "embeddingmodel_serialization_plugin",
    "all_deserialization_plugin",
    "all_serialization_plugin",
]
