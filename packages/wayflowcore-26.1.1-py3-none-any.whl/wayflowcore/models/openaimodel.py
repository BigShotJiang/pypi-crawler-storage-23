# Copyright © 2025 Oracle and/or its affiliates.
#
# This software is under the Apache License 2.0
# (LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0) or Universal Permissive License
# (UPL) 1.0 (LICENSE-UPL or https://oss.oracle.com/licenses/upl), at your option.

import os
from typing import Any, Dict, Optional

from wayflowcore._metadata import MetadataType

from .llmgenerationconfig import LlmGenerationConfig
from .openaiapitype import OpenAIAPIType
from .openaicompatiblemodel import OPEN_API_KEY, OpenAICompatibleModel


class OpenAIModel(OpenAICompatibleModel):
    def __init__(
        self,
        model_id: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        generation_config: Optional[LlmGenerationConfig] = None,
        proxy: Optional[str] = None,
        api_type: OpenAIAPIType = OpenAIAPIType.CHAT_COMPLETIONS,
        __metadata_info__: Optional[MetadataType] = None,
        id: Optional[str] = None,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> None:
        """
        Model powered by OpenAI.

        Parameters
        ----------
        model_id:
            Name of the model to use
        api_key:
            API key for the OpenAI endpoint. Overrides existing ``OPENAI_API_KEY`` environment variable.
        generation_config:
            default parameters for text generation with this model
        proxy:
            proxy to access the remote model under VPN
        api_type:
            OpenAI API type to use. Currently supports Responses and Chat Completions API.
            Uses Completions API if not specified
        id:
            ID of the component.
        name:
            Name of the component.
        description:
            Description of the component.


        .. important::
            When running under Oracle VPN, the connection to the OCIGenAI service requires to run the model without any proxy.
            Therefore, make sure not to have any of ``http_proxy`` or ``HTTP_PROXY`` environment variables setup,
            or unset them with ``unset http_proxy HTTP_PROXY``. Please also ensure that the ``OPENAI_API_KEY`` is set beforehand
            to access this model. A list of available OpenAI models can be found at the following
            link: `OpenAI Models <https://platform.openai.com/docs/models>`_

        Examples
        --------
        >>> from wayflowcore.models import LlmModelFactory
        >>> OPENAI_CONFIG = {
        ...     "model_type": "openai",
        ...     "model_id": "gpt-4o-mini",
        ... }
        >>> llm = LlmModelFactory.from_config(OPENAI_CONFIG)  # doctest: +SKIP

        Notes
        -----
        When running with Oracle VPN, you need to specify a https proxy, either globally or at the model level:

        >>> OPENAI_CONFIG = {
        ...    "model_type": "openai",
        ...    "model_id": "gpt-4o-mini",
        ...    "proxy": "<PROXY_ADDRESS>",
        ... }  # doctest: +SKIP
        """

        if api_key is None and OPEN_API_KEY not in os.environ:
            raise ValueError(f'Missing "{OPEN_API_KEY}" environment variable or input `api_key`')

        self.proxy = proxy
        super().__init__(
            model_id=model_id,
            base_url="https://api.openai.com",
            proxy=proxy,
            api_key=api_key if api_key is not None else os.environ[OPEN_API_KEY],
            generation_config=generation_config,
            supports_structured_generation=True,
            supports_tool_calling=True,
            api_type=api_type,
            id=id,
            __metadata_info__=__metadata_info__,
            name=name,
            description=description,
        )

    @property
    def config(self) -> Dict[str, Any]:
        # proxy and api_key parameters are not serialized on purpose
        return {
            "model_type": "openai",
            "model_id": self.model_id,
            "generation_config": (
                self.generation_config.to_dict() if self.generation_config is not None else None
            ),
        }
