{{ '{% docs ' ~ doc_name ~ ' %}' }}
## `{{ relation_name }}` table

### 📝 Details

...

### 📚 External docs

...

{{ '{% enddocs %}' }}
