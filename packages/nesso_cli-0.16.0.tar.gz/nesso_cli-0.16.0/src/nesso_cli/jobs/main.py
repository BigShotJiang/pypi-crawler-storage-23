"""Main entry point for job-related commands."""

import typer


app = typer.Typer()
