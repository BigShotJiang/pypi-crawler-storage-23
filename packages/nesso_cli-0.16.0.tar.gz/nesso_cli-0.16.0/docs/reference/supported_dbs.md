# Supported databases

Below is a list of currently supported databases:

- trino
- redshift
- databricks
- sqlserver
- postgres
- duckdb

These can be specified when installing `nesso models`, eg. like so: `pip install .[trino]`.
