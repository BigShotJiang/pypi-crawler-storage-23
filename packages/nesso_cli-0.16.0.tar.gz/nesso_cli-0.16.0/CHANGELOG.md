# Changelog - nesso CLI

To see the changelog, have a look at the [Releases](https://github.com/dyvenia/nesso-cli/releases) page.
