"""
Tallyfy SDK - A modular Python SDK for Tallyfy API
"""

from .core import TallyfySDK, TallyfyError
from .models import *
from .validation import validate_id, validate_positive_int, validate_string
from .user_management import UserManager, UserManagement
from .task_management import TaskManager, TaskManagement
from .template_management import TemplateManager, TemplateManagement
from .form_fields_management import FormFieldManager, FormFieldManagement
from .organization_management import OrganizationManager, OrganizationManagement
from .thread_management import ThreadManager
from .group_management import GroupManager
from .tag_management import TagManager
from .folder_management import FolderManager

__version__ = "1.1.0"
__all__ = [
    "TallyfySDK",
    "TallyfyError",
    "UserManager",
    "UserManagement",
    "TaskManager",
    "TaskManagement",
    "TemplateManager",
    "TemplateManagement",
    "FormFieldManager",
    "FormFieldManagement",
    "OrganizationManager",
    "OrganizationManagement",
    "ThreadManager",
    "GroupManager",
    "TagManager",
    "FolderManager",
    "validate_id",
    "validate_positive_int",
    "validate_string",
]