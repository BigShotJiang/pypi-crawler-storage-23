# Changelog

All notable changes to the Tallyfy SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [Unreleased]

### Added
-

### Changed
-

### Fixed
-

## [1.1.0] - 2026-02-21

### Added
- **GroupManager** (`sdk.groups`) — full CRUD for organization groups: `get_groups`, `get_group`, `create_group`, `update_group`, `delete_group`
- **TagManager** (`sdk.tags`) — full CRUD for organization tags: `get_tags`, `get_tag`, `create_tag`, `update_tag`, `delete_tag`
- **FolderManager** (`sdk.folders`) — full CRUD for organization folders: `get_folders`, `get_folder`, `create_folder`, `update_folder`, `delete_folder`
- **ThreadManager** (`sdk.threads`) — task comment CRUD: `add_task_comment`, `get_task_comments`, `update_task_comment`, `delete_task_comment`
- **Process lifecycle methods**: `get_process`, `update_process` (name/summary/starred), `archive_process`
- **Task lifecycle methods**: `complete_task`, `reopen_task`, `update_task`
- **`launch_process`** — create a new process run from a template with assignees, name, summary, and due dates
- **`tallyfy/validation.py`** — centralized input validation module:
  - `validate_id()` — strict allowlist (`[a-zA-Z0-9_-]`), 255-char max; blocks path traversal and URL injection in all ID parameters
  - `validate_positive_int()` — ensures positive integer; rejects booleans, floats, zero, negatives
  - `validate_string()` — non-empty check with configurable max length (default 10,000)
- `Group`, `Tag`, `Folder` data models added to `tallyfy/models.py`
- `validate_id`, `validate_positive_int`, `validate_string` exported from the top-level `tallyfy` package

### Changed
- All manager `_validate_*` methods across `task_management`, `user_management`, `template_management`, `form_fields_management`, `group_management`, `tag_management`, `folder_management`, and `thread_management` now delegate to the shared validators in `validation.py`
- `BaseSDK._build_url` percent-encodes every path segment via `urllib.parse.quote` (defense-in-depth against path traversal)
- `Tag` model: `color` and `type` fields are now `Optional`; added `auto_generated` field
- `Folder` model: added `parent_id`, `total`, `position`, `folder_type` fields

### Fixed
- `update_group` now fetches current group state before PUT (API requires all fields; partial update was causing 422)
- `create_group` validates that `description` is non-empty (API rejects blank strings with 422)
- Step update requests now always include `title` to satisfy API requirements
- Step creation payload now includes `checklist_id` when provided


## [1.0.18] - 2026-01-29

### Changed
- Improved response handling for list-based endpoints across all management modules
- Added `_count` support and unified `from_list` class methods to list model classes
- Refactored user and guest retrieval to handle varied API response formats


## [1.0.17] - 2026-01-25

### Added
- `UsersList` and `GuestsList` response models with `from_list` class methods and `count` property

### Changed
- Refactored user and guest retrieval to use structured list models instead of raw dicts

### Infrastructure
- Use `PAT_TOKEN` in release workflow to trigger PyPI publish
- Added `workflow_dispatch` trigger to `build-whl.yml`


## [1.0.16] - 2026-01-21

### Added
- Pagination support for user, guest, and task queries
- Release `Makefile` for streamlined publishing

### Fixed
- Repository URLs corrected in `setup.py`

### Infrastructure
- Updated GitHub Actions workflow for release automation


## [1.0.15] - 2026-01-21

### Added
- Pagination support groundwork for list endpoints


## [1.0.14] - 2025-11-14

### Changed
- **BREAKING**: Refactored user management from monolithic to modular architecture
  - `user_management.py` → `user_management/` package with specialized modules
  - New `UserManager` class replaces `UserManagement` (backward compatible alias maintained)
  - Improved separation of concerns with dedicated retrieval and invitation modules

### Added
- **Enhanced User Management Features**:
  - `get_user_by_email()` - Find users by email address with exact matching
  - `get_guest_by_email()` - Find guests by email address with exact matching
  - `search_members_by_name()` - Fuzzy search for users and guests by name
  - `get_all_organization_members()` - Convenience method to get users and guests in one call
  - `invite_multiple_users()` - Batch invitation support with default role/message handling
  - `resend_invitation()` - Resend invitations with custom messaging
  - `get_invitation_template_message()` - Generate customized invitation messages
  - `validate_invitation_data()` - Validate invitation data before sending

- **Modular Architecture Improvements**:
  - `user_management/base.py` - Common validation and error handling
  - `user_management/retrieval.py` - User and guest retrieval operations
  - `user_management/invitation.py` - User invitation operations with enhanced features
  - Direct access to specialized modules via `sdk.users.retrieval` and `sdk.users.invitation`

### Improved
- **Enhanced Validation**: Comprehensive email validation with regex patterns
- **Better Error Handling**: Context-aware error messages with operation details
- **Query Parameter Handling**: Flexible parameter building with proper boolean conversion
- **Code Organization**: Clear separation between retrieval and invitation concerns
- **Type Safety**: Enhanced type hints and validation across all user operations

### Fixed
- **Python Keyword Conflicts**: Resolved issues with `with` keyword in query parameters
- **Import Compatibility**: Maintained full backward compatibility while enabling new functionality

### Deprecated
- `UserManagement` class name (use `UserManager` instead, though alias is maintained)

## [1.0.0] - 2025-06-25

### Added
- Initial release of Tallyfy SDK
- Complete user management functionality
- Task management with natural language processing
- Template management with automation support
- Form field management with AI-powered suggestions
- Comprehensive data models with type safety
- Error handling with automatic retry logic
- Session management and connection pooling
- Full API coverage for Tallyfy platform

### Features
- **User Management**: Organization members, guests, and invitations
- **Task Management**: Personal tasks, process tasks, and natural language creation
- **Template Management**: Template CRUD, automation rules, and health assessment
- **Form Fields**: Dynamic form field management with AI suggestions
- **Search**: Universal search across processes, templates, and tasks
- **Natural Language Processing**: Date extraction and task parsing
- **Error Handling**: Comprehensive error handling with detailed response data
- **Type Safety**: Full dataclass models with type hints

### Dependencies
- requests>=2.25.0
- typing-extensions>=4.0.0 (Python < 3.8)

### Development
- Python 3.7+ support
- Comprehensive test suite
- Type checking with mypy
- Code formatting with black
- Linting with flake8
