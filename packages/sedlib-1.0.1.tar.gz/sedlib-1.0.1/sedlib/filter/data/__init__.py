# Package data directory for filter module

