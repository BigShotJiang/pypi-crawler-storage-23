#!/usr/bin/env python

"""Filter class for managing photometric filters."""

from .core import Filter
