"""Metrics time-series connector for MoaT-Link."""

from __future__ import annotations

from moat.lib.config import register as _register

__all__: list[str] = []

_register(__name__)
