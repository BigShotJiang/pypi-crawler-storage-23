"""
SQLAlchemy Base Configuration

Base class for all database models.
"""

from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
