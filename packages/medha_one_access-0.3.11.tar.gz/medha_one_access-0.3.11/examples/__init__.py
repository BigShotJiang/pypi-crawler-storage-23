"""
MedhaOne Access Control Examples

Example code showing different usage patterns.
"""
