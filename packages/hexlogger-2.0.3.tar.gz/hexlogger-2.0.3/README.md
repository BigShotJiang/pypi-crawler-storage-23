A premium, zero-dependency Python console logging library with beautiful colored output, multiple themes, gradient text, panels, tables, progress bars, and spinners.

---


```bash
pip install hexlogger
```

---


```python
import hexlogger

hexlogger.success(" BOT READY ")
hexlogger.info("Logged in as: MyBot#1234")
hexlogger.info("Bot Name: MyBot")
hexlogger.info("Bot ID: 987654321098765432")
hexlogger.info("Shards: 4")
hexlogger.info("Connected to: 128 guilds")
hexlogger.info("Connected to: 94,210 users")
hexlogger.warn("Rate limit hit on /api/messages")
hexlogger.error("Failed to fetch guild: 403 Forbidden")
hexlogger.critical("Shard 2 disconnected unexpectedly")
hexlogger.fatal("Token invalidated — shutting down")
```

**Output:**
```
[-(14:30:00)-] [ ● ] SUCCESS »   BOT READY
[-(14:30:00)-] [ ● ] INFO »  Logged in as: MyBot#1234
[-(14:30:00)-] [ ● ] INFO »  Bot Name: MyBot
[-(14:30:00)-] [ ● ] INFO »  Bot ID: 987654321098765432
[-(14:30:00)-] [ ● ] INFO »  Shards: 4
[-(14:30:00)-] [ ● ] INFO »  Connected to: 128 guilds
[-(14:30:00)-] [ ● ] INFO »  Connected to: 94,210 users
[-(14:30:00)-] [ ● ] WARNING »  Rate limit hit on /api/messages
[-(14:30:00)-] [ ● ] ERROR »  Failed to fetch guild: 403 Forbidden
[-(14:30:00)-] [ ● ] CRITICAL »  Shard 2 disconnected unexpectedly
[-(14:30:00)-] [ ● ] FATAL »  Token invalidated — shutting down
```

---


| Function | Level |
|---|---|
| `trace(msg)` | TRACE |
| `debug(msg)` | DEBUG |
| `info(msg)` | INFO |
| `success(msg)` | SUCCESS |
| `warn(msg)` / `warning(msg)` | WARNING |
| `error(msg)` | ERROR |
| `critical(msg)` | CRITICAL |
| `fatal(msg)` | FATAL |

---


Nine display styles are available. All styles respond to the active theme for color. Switch styles with `hexlogger.setstyle(name)`.


```python
hexlogger.setstyle("default")
```

```
[-(14:30:00)-] [ ● ] SUCCESS »   BOT READY
[-(14:30:00)-] [ ● ] INFO »  Logged in as: MyBot#1234
[-(14:30:00)-] [ ● ] INFO »  Bot Name: MyBot
[-(14:30:00)-] [ ● ] INFO »  Bot ID: 987654321098765432
[-(14:30:00)-] [ ● ] INFO »  Shards: 4
[-(14:30:00)-] [ ● ] INFO »  Connected to: 128 guilds
[-(14:30:00)-] [ ● ] INFO »  Connected to: 94,210 users
[-(14:30:00)-] [ ● ] WARNING »  Rate limit hit on /api/messages
[-(14:30:00)-] [ ● ] ERROR »  Failed to fetch guild: 403 Forbidden
[-(14:30:00)-] [ ● ] CRITICAL »  Shard 2 disconnected unexpectedly
[-(14:30:00)-] [ ● ] FATAL »  Token invalidated — shutting down
```


```python
hexlogger.setstyle("box")
```

```
┃ 14:30:00 │ ✓ SUCCESS  │  BOT READY
┃ 14:30:00 │ ℹ INFO     │ Logged in as: MyBot#1234
┃ 14:30:00 │ ℹ INFO     │ Bot Name: MyBot
┃ 14:30:00 │ ℹ INFO     │ Bot ID: 987654321098765432
┃ 14:30:00 │ ℹ INFO     │ Shards: 4
┃ 14:30:00 │ ℹ INFO     │ Connected to: 128 guilds
┃ 14:30:00 │ ℹ INFO     │ Connected to: 94,210 users
┃ 14:30:00 │ ⚠ WARNING  │ Rate limit hit on /api/messages
┃ 14:30:00 │ ✗ ERROR    │ Failed to fetch guild: 403 Forbidden
┃ 14:30:00 │ ☠ CRITICAL │ Shard 2 disconnected unexpectedly
┃ 14:30:00 │ 💀 FATAL    │ Token invalidated — shutting down
```


```python
hexlogger.setstyle("modern")
```

```
14:30:00  ✓ SUCCESS   BOT READY
14:30:00  ℹ INFO  Logged in as: MyBot#1234
14:30:00  ℹ INFO  Bot Name: MyBot
14:30:00  ℹ INFO  Bot ID: 987654321098765432
14:30:00  ℹ INFO  Shards: 4
14:30:00  ℹ INFO  Connected to: 128 guilds
14:30:00  ℹ INFO  Connected to: 94,210 users
14:30:00  ⚠ WARNING  Rate limit hit on /api/messages
14:30:00  ✗ ERROR  Failed to fetch guild: 403 Forbidden
14:30:00  ☠ CRITICAL  Shard 2 disconnected unexpectedly
14:30:00  💀 FATAL  Token invalidated — shutting down
```


```python
hexlogger.setstyle("bracket")
```

```
[14:30:00] [SUCCESS]  BOT READY
[14:30:00] [INFO] Logged in as: MyBot#1234
[14:30:00] [INFO] Bot Name: MyBot
[14:30:00] [INFO] Bot ID: 987654321098765432
[14:30:00] [INFO] Shards: 4
[14:30:00] [INFO] Connected to: 128 guilds
[14:30:00] [INFO] Connected to: 94,210 users
[14:30:00] [WARNING] Rate limit hit on /api/messages
[14:30:00] [ERROR] Failed to fetch guild: 403 Forbidden
[14:30:00] [CRITICAL] Shard 2 disconnected unexpectedly
[14:30:00] [FATAL] Token invalidated — shutting down
```


```python
hexlogger.setstyle("arrow")
```

```
14:30:00 ▸ SUCCESS ▸  BOT READY
14:30:00 ▸ INFO ▸ Logged in as: MyBot#1234
14:30:00 ▸ INFO ▸ Bot Name: MyBot
14:30:00 ▸ INFO ▸ Bot ID: 987654321098765432
14:30:00 ▸ INFO ▸ Shards: 4
14:30:00 ▸ INFO ▸ Connected to: 128 guilds
14:30:00 ▸ INFO ▸ Connected to: 94,210 users
14:30:00 ▸ WARNING ▸ Rate limit hit on /api/messages
14:30:00 ▸ ERROR ▸ Failed to fetch guild: 403 Forbidden
14:30:00 ▸ CRITICAL ▸ Shard 2 disconnected unexpectedly
14:30:00 ▸ FATAL ▸ Token invalidated — shutting down
```


```python
hexlogger.setstyle("pipe")
```

```
▌ 14:30:00 | SUCCESS  |  BOT READY
▌ 14:30:00 | INFO     | Logged in as: MyBot#1234
▌ 14:30:00 | INFO     | Bot Name: MyBot
▌ 14:30:00 | INFO     | Bot ID: 987654321098765432
▌ 14:30:00 | INFO     | Shards: 4
▌ 14:30:00 | INFO     | Connected to: 128 guilds
▌ 14:30:00 | INFO     | Connected to: 94,210 users
▌ 14:30:00 | WARNING  | Rate limit hit on /api/messages
▌ 14:30:00 | ERROR    | Failed to fetch guild: 403 Forbidden
▌ 14:30:00 | CRITICAL | Shard 2 disconnected unexpectedly
▌ 14:30:00 | FATAL    | Token invalidated — shutting down
```


```python
hexlogger.setstyle("tag")
```

```
14:30:00  SUCCESS   BOT READY
14:30:00  INFO  Logged in as: MyBot#1234
14:30:00  INFO  Bot Name: MyBot
14:30:00  INFO  Bot ID: 987654321098765432
14:30:00  INFO  Shards: 4
14:30:00  INFO  Connected to: 128 guilds
14:30:00  INFO  Connected to: 94,210 users
14:30:00  WARNING  Rate limit hit on /api/messages
14:30:00  ERROR  Failed to fetch guild: 403 Forbidden
14:30:00  CRITICAL  Shard 2 disconnected unexpectedly
14:30:00  FATAL  Token invalidated — shutting down
```

> Each level label renders with a distinct background color in the terminal.


```python
hexlogger.setstyle("dots")
```

```
✓ 14:30:00 · SUCCESS ·  BOT READY
ℹ 14:30:00 · INFO · Logged in as: MyBot#1234
ℹ 14:30:00 · INFO · Bot Name: MyBot
ℹ 14:30:00 · INFO · Bot ID: 987654321098765432
ℹ 14:30:00 · INFO · Shards: 4
ℹ 14:30:00 · INFO · Connected to: 128 guilds
ℹ 14:30:00 · INFO · Connected to: 94,210 users
⚠ 14:30:00 · WARNING · Rate limit hit on /api/messages
✗ 14:30:00 · ERROR · Failed to fetch guild: 403 Forbidden
☠ 14:30:00 · CRITICAL · Shard 2 disconnected unexpectedly
💀 14:30:00 · FATAL · Token invalidated — shutting down
```


```python
hexlogger.setstyle("clean")
```

```
  14:30:00  SUCCESS    BOT READY
  14:30:00  INFO      Logged in as: MyBot#1234
  14:30:00  INFO      Bot Name: MyBot
  14:30:00  INFO      Bot ID: 987654321098765432
  14:30:00  INFO      Shards: 4
  14:30:00  INFO      Connected to: 128 guilds
  14:30:00  INFO      Connected to: 94,210 users
  14:30:00  WARNING   Rate limit hit on /api/messages
  14:30:00  ERROR     Failed to fetch guild: 403 Forbidden
  14:30:00  CRITICAL  Shard 2 disconnected unexpectedly
  14:30:00  FATAL     Token invalidated — shutting down
```

---


Six built-in themes control the colors applied to every style. Themes do not affect the structure of the output — only the palette.

```python
hexlogger.settheme("default")   # Soft blue/green palette
hexlogger.settheme("neon")      # Vivid cyan/magenta palette
hexlogger.settheme("minimal")   # Muted grays, abbreviated labels
hexlogger.settheme("hacker")    # Green-on-black matrix palette
hexlogger.settheme("sunset")    # Warm orange/red palette
hexlogger.settheme("ocean")     # Deep blue/teal palette
```

The `minimal` theme also uses abbreviated level labels:

```
[-(14:30:00)-] [ ● ] OK »   BOT READY
[-(14:30:00)-] [ ● ] INF »  Logged in as: MyBot#1234
[-(14:30:00)-] [ ● ] INF »  Bot Name: MyBot
[-(14:30:00)-] [ ● ] INF »  Bot ID: 987654321098765432
[-(14:30:00)-] [ ● ] INF »  Shards: 4
[-(14:30:00)-] [ ● ] INF »  Connected to: 128 guilds
[-(14:30:00)-] [ ● ] INF »  Connected to: 94,210 users
[-(14:30:00)-] [ ● ] WRN »  Rate limit hit on /api/messages
[-(14:30:00)-] [ ● ] ERR »  Failed to fetch guild: 403 Forbidden
[-(14:30:00)-] [ ● ] CRT »  Shard 2 disconnected unexpectedly
[-(14:30:00)-] [ ● ] FTL »  Token invalidated — shutting down
```


```python
from hexlogger import rgb

hexlogger._config.add_theme("mytheme", {
    "timestamp": rgb(0, 100, 200),
    "bracket":   rgb(0, 80, 160),
    "dot":       rgb(0, 200, 255),
    "separator": rgb(0, 150, 200),
    "debug":     rgb(100, 180, 255),
    "info":      rgb(0, 200, 255),
    "success":   rgb(0, 255, 200),
    "warning":   rgb(255, 200, 0),
    "error":     rgb(255, 80, 80),
    "critical":  rgb(255, 0, 50),
    "fatal":     rgb(200, 0, 0),
    "trace":     rgb(100, 150, 200),
    "divider":   rgb(0, 60, 100),
    "label_debug":    "DEBUG",
    "label_info":     "INFO",
    "label_success":  "SUCCESS",
    "label_warning":  "WARNING",
    "label_error":    "ERROR",
    "label_critical": "CRITICAL",
    "label_fatal":    "FATAL",
    "label_trace":    "TRACE",
})

hexlogger.settheme("mytheme")
```

---



```python
hexlogger.divider()
hexlogger.divider(char="═", length=80)
```

```
────────────────────────────────────────────────────────────
```


```python
hexlogger.section("RESULTS")
hexlogger.rule("Settings", char="═")
hexlogger.blank(2)
```

```
══════════════════════════ RESULTS ═══════════════════════════
```


```python
hexlogger.banner("HexLogger\nv3.0.0")
```

```
╔═══════════════╗
║   HexLogger   ║
║    v3.0.0     ║
╚═══════════════╝
```


```python
hexlogger.panel(
    "Server: online\nPing: 42ms\nUptime: 99.9%",
    title="Status",
    style="rounded"
)
```

```
╭─ Status ──────────────────────────────────────╮
│ Server: online                                │
│ Ping: 42ms                                    │
│ Uptime: 99.9%                                 │
╰───────────────────────────────────────────────╯
```

Available panel styles: `rounded`, `sharp`, `double`, `heavy`, `ascii`


```python
hexlogger.box("Deployment complete.", style="double", align="center")
```

```
╔═════════════════════════╗
║   Deployment complete.  ║
╚═════════════════════════╝
```

Available box styles: `rounded`, `sharp`, `double`, `heavy`, `ascii`, `stars`, `dashes`


```python
hexlogger.table(
    headers=["Name", "Status", "Ping"],
    rows=[
        ["Server 1", "Online",  "12ms"],
        ["Server 2", "Offline", "---"],
        ["Server 3", "Online",  "45ms"],
    ]
)
```

```
╭──────────┬─────────┬──────╮
│ Name     │ Status  │ Ping │
├──────────┼─────────┼──────┤
│ Server 1 │ Online  │ 12ms │
│ Server 2 │ Offline │ ---  │
│ Server 3 │ Online  │ 45ms │
╰──────────┴─────────┴──────╯
```


```python
hexlogger.pair("Logged in as", "MyBot#1234")
hexlogger.pair("Bot ID",       "987654321098765432")
hexlogger.pair("Guilds",       "128")
hexlogger.pair("Users",        "94,210")
```

```
  Logged in as: MyBot#1234
  Bot ID: 987654321098765432
  Guilds: 128
  Users: 94,210
```

---


```python
hexlogger.gprint("Hello World!", (255, 0, 100), (100, 0, 255))
hexlogger.rbprint("Rainbow text!")

text  = hexlogger.gtext("Custom gradient", (0, 255, 200), (255, 0, 100))
multi = hexlogger.mgtext("Multi-stop", [(255,0,0), (0,255,0), (0,0,255)])
```


```python
from hexlogger import bold, italic, uline, clr, Colors

print(bold("Bold text"))
print(italic("Italic text"))
print(uline("Underlined text"))
print(clr("Cyan text", Colors.CYAN))
```


```python
from hexlogger import rgb, bgrgb, hexclr, bghex

color    = rgb(255, 128, 0)
bg       = bgrgb(30, 30, 30)
from_hex = hexclr("#FF8800")
bg_hex_  = bghex("#1E1E1E")
```

---


```python
import time

bar = hexlogger.Progress(total=100, label="Downloading", width=40)
for i in range(100):
    time.sleep(0.05)
    bar.update()
```

```
Downloading │████████████████████░░░░░░░░░░░░░░░░░░░│  52.0% (52/100) [2.6s / ETA 2.4s]
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `total` | int | — | Total number of steps |
| `width` | int | `30` | Bar width in characters |
| `label` | str | `"Progress"` | Label displayed before the bar |
| `fill` | str | `"█"` | Fill character |
| `empty` | str | `"░"` | Empty character |
| `color` | str | theme | Bar color |

---


```python
import time

with hexlogger.Spinner("Loading data...", style="dots"):
    time.sleep(3)

spinner = hexlogger.Spinner("Processing...", style="circle")
spinner.start()
time.sleep(2)
spinner.stop("Done!")
```

```
⠹ Loading data...
```

Available styles: `dots`, `line`, `arrow`, `bounce`, `box`, `circle`

---


```python
import time

with hexlogger.Timer("Database query"):
    time.sleep(1.5)

timer = hexlogger.Timer("API call")
timer.start()
elapsed = timer.stop()
```

---


```python
hexlogger.settheme("neon")
hexlogger.setstyle("modern")
hexlogger.setlog("app.log")
hexlogger.setlevel("warning")

hexlogger._config.time_format = "%Y-%m-%d %H:%M:%S"
hexlogger._config.show_time   = False
```


Only messages at or above the configured level are printed.

```python
hexlogger.setlevel("trace")
hexlogger.setlevel("debug")
hexlogger.setlevel("info")
hexlogger.setlevel("warning")
hexlogger.setlevel("error")
hexlogger.setlevel("critical")
hexlogger.setlevel("fatal")
```

---


- Zero dependencies
- 6 built-in themes with full custom theme support
- 9 display styles
- RGB, background, and hex color helpers
- Gradient and rainbow text
- Panels, tables, banners, and boxes
- Progress bars with ETA
- Animated spinners in 6 styles
- Timer utility
- File logging with automatic ANSI stripping
- Thread-safe output
- Windows console compatible
- Python 3.7+

---


MIT License — Created by Itz Montage