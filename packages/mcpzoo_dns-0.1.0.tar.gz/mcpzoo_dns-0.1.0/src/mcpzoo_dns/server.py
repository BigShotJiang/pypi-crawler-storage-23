import socket
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("dns")

@mcp.tool()
def dns_lookup(domain: str) -> str:
    """查询域名的基础 A/AAAA 记录（使用本地 DNS）。"""
    try:
        # 获取所有地址信息
        addr_info = socket.getaddrinfo(domain, None)
        ips = set()
        for info in addr_info:
            ip = info[4][0]
            ips.add(ip)
            
        return f"[{domain}] 解析结果:\n" + "\n".join(sorted(ips))
    except socket.gaierror as e:
        return f"解析失败: {e}"
    except Exception as e:
        return f"查询错误: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
