# mcpzoo-dns

> DNS 查询 — 查询域名的 DNS 解析记录

## Installation

```bash
uvx mcpzoo-dns
```

## uvx JSON

```json
{
  "mcpServers": {
    "dns": {
      "args": ["mcpzoo-dns"],
      "command": "uvx"
    }
  }
}
```
