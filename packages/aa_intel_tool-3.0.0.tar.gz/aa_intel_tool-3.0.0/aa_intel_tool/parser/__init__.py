"""
Initialise the parser
"""
