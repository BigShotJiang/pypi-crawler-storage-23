"""fork — Fork a file you don't own into your account."""

from . import Arg, Command, register

cmd = register(Command(
    name="fork",
    description="Copy someone else's file into your account with a new key.",
    args=(
        Arg("key",
            "Key of the file to fork.",
            required=True),
    ),
))


def run(shell, args_str):
    """Fork a file into your account."""
    import requests
    from cli.session import api_get, api_post, check_auth

    if not check_auth(shell):
        return

    key = args_str.strip()
    if not key:
        shell.poutput("usage: fork <key>")
        return

    if "/" in key:
        key = key.rstrip("/").rsplit("/", 1)[-1]

    resp = api_get(f"/api/v1/keys/{key}/")
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    url = data.get("download_url")
    if not url:
        shell.poutput("  error: no download URL")
        return

    r = requests.get(url)
    if r.status_code != 200:
        shell.poutput(f"  download failed ({r.status_code})")
        return

    fname = data.get("filename", f"{key}.bin")
    folder = shell.cwd.strip("/")
    resp2 = api_post("/api/v1/keys/",
                     files={"file": (fname, r.content)},
                     data={"folder": folder})
    if resp2.status_code in (200, 201):
        d = resp2.json()
        shell.poutput(f"  forked: {d['url']}  ({fname})")
    else:
        shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
