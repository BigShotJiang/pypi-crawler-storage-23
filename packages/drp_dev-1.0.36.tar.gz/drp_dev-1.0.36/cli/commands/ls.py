"""ls — List files and folders."""

from . import Arg, Command, register

cmd = register(Command(
    name="ls",
    description="List files and folders.",
    args=(
        Arg("path",
            "Drive path to list. Defaults to current directory.",
            default="."),
        Arg("--export",
            "Output as JSON for scripting.",
            type="bool"),
        Arg("--sort",
            "Sort by field.",
            choices=("name", "size", "exp")),
    ),
))


def run(shell, args_str):
    """List files and folders."""
    import json as _json
    from cli.session import api_get, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    export = "--export" in args
    sort_field = None
    for i, a in enumerate(args):
        if a == "--sort" and i + 1 < len(args):
            sort_field = args[i + 1]

    # Determine remote path
    path = shell.cwd.strip("/")
    for a in args:
        if not a.startswith("-"):
            if a != ".":
                path = a.strip("/")
            break

    params = {}
    if path:
        params["path"] = path

    resp = api_get("/api/v1/folders/", params=params)
    if resp.status_code != 200:
        shell.poutput(f"error: {resp.json().get('error', resp.status_code)}")
        return

    data = resp.json()
    folders = data.get("folders", [])
    files = data.get("files", [])

    if export:
        shell.poutput(_json.dumps(data, indent=2, default=str))
        return

    if sort_field == "name":
        folders.sort(key=lambda f: f["name"])
        files.sort(key=lambda f: f["filename"])
    elif sort_field == "size":
        files.sort(key=lambda f: f.get("filesize", 0), reverse=True)

    if not folders and not files:
        shell.poutput("  (empty)")
        return

    for f in folders:
        shell.poutput(f"  \033[34m{f['name']}/\033[0m")

    for f in files:
        size = f.get("filesize", 0)
        key = f.get("key", "")
        enc = " \033[33m[enc]\033[0m" if f.get("encrypted") else ""
        shell.poutput(f"  {f['filename']:<30s}  {_fmt_size(size):>8s}  {key}{enc}")


def _fmt_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f}{unit}" if unit == "B" else f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"
