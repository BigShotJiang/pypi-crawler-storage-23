"""cp — Copy files between the real filesystem and the drive, or within the drive."""

from . import Arg, Command, register

cmd = register(Command(
    name="cp",
    description="Copy files between the real filesystem and the drive, or within the drive.",
    shell_only=True,
    args=(
        Arg("src",
            "Source path. Prefix ./ for local files; bare names are drive paths.",
            required=True, type="path"),
        Arg("dest",
            "Destination path. ./ for local; bare names are drive paths.",
            required=True, type="path"),
    ),
))


def run(shell, args_str):
    """Copy files between the local filesystem and the drive."""
    import os
    import requests
    from cli.session import api_get, api_post, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if len(args) < 2:
        shell.poutput("usage: cp <src> <dest>")
        shell.poutput("  prefix ./ for local paths; bare names are drive paths")
        return

    src, dest = args[0], args[1]
    src_local = src.startswith("./") or src.startswith("/") or os.path.exists(
        os.path.join(shell.local_cwd, src))
    dest_local = dest.startswith("./") or dest.startswith("/")

    if src_local and not dest_local:
        # Local → drive (same as up)
        path = os.path.join(shell.local_cwd, src) if not os.path.isabs(src) else src
        if not os.path.exists(path):
            shell.poutput(f"  file not found: {src}")
            return
        fname = os.path.basename(path)
        folder = shell.cwd.strip("/")
        with open(path, "rb") as f:
            resp = api_post("/api/v1/keys/", files={"file": (fname, f)},
                            data={"folder": folder})
        if resp.status_code in (200, 201):
            d = resp.json()
            shell.poutput(f"  uploaded: {d['url']}")
        else:
            shell.poutput(f"  error: {resp.json().get('error', resp.status_code)}")

    elif not src_local and dest_local:
        # Drive → local (same as get)
        key = _find_key(shell, src)
        if not key:
            shell.poutput(f"  not found: {src}")
            return
        resp = api_get(f"/api/v1/keys/{key}/")
        if resp.status_code != 200:
            shell.poutput(f"  error: {resp.json().get('error', resp.status_code)}")
            return
        data = resp.json()
        url = data.get("download_url")
        if not url:
            shell.poutput("  no download URL")
            return
        r = requests.get(url, stream=True)
        dest_path = dest if os.path.isabs(dest) else os.path.join(shell.local_cwd, dest)
        if os.path.isdir(dest_path):
            dest_path = os.path.join(dest_path, data.get("filename", key))
        with open(dest_path, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        shell.poutput(f"  saved: {dest_path}")

    elif not src_local and not dest_local:
        # Drive → drive: download then re-upload
        key = _find_key(shell, src)
        if not key:
            shell.poutput(f"  not found: {src}")
            return
        resp = api_get(f"/api/v1/keys/{key}/")
        if resp.status_code != 200:
            shell.poutput(f"  error: {resp.json().get('error', resp.status_code)}")
            return
        data = resp.json()
        url = data.get("download_url")
        if not url:
            shell.poutput("  no download URL")
            return
        r = requests.get(url)
        fname = data.get("filename", key)
        folder = shell.cwd.strip("/")
        resp2 = api_post("/api/v1/keys/", files={"file": (fname, r.content)},
                         data={"folder": folder, "key": dest})
        if resp2.status_code in (200, 201):
            d = resp2.json()
            shell.poutput(f"  copied: {d['url']}")
        else:
            shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
    else:
        shell.poutput("  local-to-local copy not supported — use system cp")


def _find_key(shell, ref):
    """Resolve a ref (key or filename) to a key."""
    if "." in ref and len(ref) > 6:
        from cli.session import api_get
        path = shell.cwd.strip("/")
        params = {"path": path} if path else {}
        resp = api_get("/api/v1/folders/", params=params)
        if resp.status_code == 200:
            for f in resp.json().get("files", []):
                if f.get("filename") == ref:
                    return f.get("key")
    return ref
