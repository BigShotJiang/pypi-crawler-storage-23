"""up — Upload a file, directory, glob, or text."""

from . import Arg, Command, register

cmd = register(Command(
    name="up",
    description="Upload a file, directory, glob, or text.",
    args=(
        Arg("target",
            "Local file path, glob (\"*.py\"), - for stdin, or literal text with --text.",
            required=True, type="path"),
        Arg("-k/--key",
            "Custom key. Format: [a-zA-Z0-9_-]{1,64}. Rejected if taken."),
        Arg("--expires",
            "Key expiry: 7d, 24h, 30m. Capped at plan max. Defaults to plan max.",
            type="duration"),
        Arg("--publish",
            "List the file on /explore/ and your profile.",
            type="bool"),
        Arg("--burn",
            "Invalidate the key after the first view.",
            type="bool"),
        Arg("--password",
            "Require a password to access the key. Starter/Pro only.",
            type="passphrase"),
        Arg("--encryption-key",
            "Client-side AES encryption before upload. Server never sees plaintext.",
            type="passphrase"),
        Arg("--tag",
            "Add a tag. Repeatable: --tag python --tag snippet.",
            repeatable=True),
        Arg("--text",
            "Treat target as literal text content, not a filename.",
            type="bool"),
        Arg("--fork",
            "Fork the result immediately after uploading.",
            type="bool"),
    ),
))


def run(shell, args_str):
    """Upload a file, directory, glob, or text."""
    import glob
    import os
    from cli.session import api_post, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if not args:
        shell.poutput("usage: up <file|text> [--key KEY] [--expires DURATION] [--text] ...")
        return

    # Parse flags
    flags = {}
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--key", "-k") and i + 1 < len(args):
            flags["key"] = args[i + 1]; i += 2
        elif a == "--expires" and i + 1 < len(args):
            flags["expires"] = args[i + 1]; i += 2
        elif a == "--password" and i + 1 < len(args):
            flags["password"] = args[i + 1]; i += 2
        elif a == "--tag" and i + 1 < len(args):
            flags.setdefault("tags", []).append(args[i + 1]); i += 2
        elif a == "--publish":
            flags["publish"] = True; i += 1
        elif a == "--burn":
            flags["burn"] = True; i += 1
        elif a == "--text":
            flags["text_mode"] = True; i += 1
        elif a == "--encryption-key" and i + 1 < len(args):
            flags["encryption_key"] = args[i + 1]; i += 2
        else:
            positional.append(a); i += 1

    target = " ".join(positional)
    if not target:
        shell.poutput("no target specified")
        return

    folder = shell.cwd.strip("/") or ""

    if flags.get("text_mode") or target == "-":
        # Text upload
        if target == "-":
            import sys
            text = sys.stdin.read()
        else:
            text = target
        payload = {
            "text": text,
            "folder": folder,
            "key": flags.get("key", ""),
            "expires": flags.get("expires", ""),
            "burn": flags.get("burn", False),
            "publish": flags.get("publish", False),
            "password": flags.get("password", ""),
            "tags": flags.get("tags", []),
        }
        resp = api_post("/api/v1/keys/", json=payload)
    else:
        # File upload — expand globs
        paths = glob.glob(target)
        if not paths:
            # Check relative to local_cwd
            full = os.path.join(shell.local_cwd, target)
            paths = glob.glob(full)
        if not paths:
            shell.poutput(f"file not found: {target}")
            return

        for path in sorted(paths):
            if os.path.isdir(path):
                # Upload each file in directory
                for root, _dirs, filenames in os.walk(path):
                    for fname in filenames:
                        fpath = os.path.join(root, fname)
                        _upload_file(shell, fpath, flags, folder)
            else:
                _upload_file(shell, path, flags, folder)
        return

    if resp.status_code in (200, 201):
        d = resp.json()
        shell.poutput(f"  {d['url']}  ({d['filename']}, {d.get('filesize', 0)} bytes)")
    else:
        shell.poutput(f"  error: {resp.json().get('error', resp.status_code)}")


def _upload_file(shell, path, flags, folder):
    """Upload a single file."""
    import os
    from cli.session import api_post

    fname = os.path.basename(path)
    with open(path, "rb") as f:
        files = {"file": (fname, f)}
        data = {
            "folder": folder,
            "key": flags.get("key", ""),
            "expires": flags.get("expires", ""),
            "burn": "true" if flags.get("burn") else "",
            "publish": "true" if flags.get("publish") else "",
            "password": flags.get("password", ""),
            "tags": ",".join(flags.get("tags", [])),
        }
        resp = api_post("/api/v1/keys/", files=files, data=data)

    if resp.status_code in (200, 201):
        d = resp.json()
        shell.poutput(f"  {d['url']}  ({fname}, {d.get('filesize', 0)} bytes)")
    else:
        shell.poutput(f"  error uploading {fname}: {resp.json().get('error', resp.status_code)}")
