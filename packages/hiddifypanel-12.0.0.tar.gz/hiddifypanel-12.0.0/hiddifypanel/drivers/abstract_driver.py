

class DriverABS:
    def get_all_usage(self): pass
    def get_enabled_users(self): pass
    def add_client(self, user): pass
    def remove_client(self, user): pass

    def is_enabled(self) -> bool: return False
