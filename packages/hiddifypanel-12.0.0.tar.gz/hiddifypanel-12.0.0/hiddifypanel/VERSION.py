# import importlib.metadata
from datetime import datetime

__version__ = '12.0.0'
__release_time__= datetime.strptime('2026-02-21T17:29:31','%Y-%m-%dT%H:%M:%S')
is_released_version=True
