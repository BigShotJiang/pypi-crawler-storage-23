#!/opt/hiddify-manager/.venv313/bin/python

from hiddifypanel import create_app_wsgi

app =  create_app_wsgi()  # noqa
