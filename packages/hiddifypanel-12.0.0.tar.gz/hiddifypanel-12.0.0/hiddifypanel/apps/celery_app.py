from hiddifypanel.celery import init_app_no_flask

celery_app=init_app_no_flask()