from hiddifypanel.base import create_celery_app

celery_app=create_celery_app()