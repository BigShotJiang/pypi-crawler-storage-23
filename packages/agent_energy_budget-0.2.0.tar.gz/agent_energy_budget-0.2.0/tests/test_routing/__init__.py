"""Test package for adaptive model routing enhancements (E10.2)."""
from __future__ import annotations
