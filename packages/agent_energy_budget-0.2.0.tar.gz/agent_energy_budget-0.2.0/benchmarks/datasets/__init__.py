"""Synthetic datasets for agent-energy-budget benchmarks."""
