"""Integration adapters for agent-energy-budget.

Optional third-party integrations. Install extras to enable:

    pip install agent-energy-budget[litellm]
"""
