"""pb-spec (Plan-Build Spec) - A CLI tool for managing AI coding assistant skills."""

from pb_spec.versioning import get_version

__version__ = get_version()
