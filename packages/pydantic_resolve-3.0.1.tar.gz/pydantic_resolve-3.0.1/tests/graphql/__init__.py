"""测试用的固定装置（fixtures）"""
