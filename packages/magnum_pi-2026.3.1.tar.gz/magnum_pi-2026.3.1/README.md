# magnum-pi

I know what you're thinking, and you're right.

Your Magnum Energy MS-Series inverter/charger has been broadcasting its secrets on a proprietary RS-485 bus since the day it was installed. Every 100 milliseconds, it transmits DC voltage, AC output, fault codes, battery temperature, charger state — the full dossier. The remote panel answers back with your configured setpoints. The AGS and BMK chime in from the back seat with generator status and battery state-of-charge. All of it flowing across two wires at 19200 baud, unencrypted, no authentication, just trust.

Someone needs to investigate. That's what `magnum-pi` does.

```
╭──────────────────────────────────╮
│   ╭───────────────╮              │
│   ╰──╮         ╭──╯   MAGNUM    │
│      ╰─────────╯      P . I .   │
│                                  │
│  Private Investigator for        │
│  Magnum Energy RS-485 Networks   │
╰──────────────────────────────────╯
```

Async Python library for reading and writing to the Magnum Network bus using any standard RS-485 adapter (USB dongles, Pi HATs, FTDI cables). Built on asyncio with Pydantic models, typed enums, and proper gap-based protocol framing.

## Install

```bash
pip install magnum-pi
```

## Quick start

```python
from magnum_pi import MagnumBus

async with MagnumBus("/dev/ttyUSB0") as bus:
    async for cycle in bus.listen():
        if cycle.inverter:
            print(f"{cycle.inverter.status.name} {cycle.inverter.dc_volts}V")
```

## CLI

```bash
magnum-pi sniff              # Raw hex dump
magnum-pi monitor --pretty   # Decoded live dashboard
magnum-pi send --inverter toggle  # Send commands
```

## Prior art

[pymagnum](https://github.com/CharlesGodwin/pymagnum) by Charles Godwin (BSD-3) — the original Python implementation that established the packet identification heuristics and scaling factors this library builds upon.
