"""magnum-pi: Private Investigator for Magnum Energy RS-485 networks.

Prior art: pymagnum by Charles Godwin (BSD-3), which established the packet
identification heuristics and scaling factors this library builds upon.
"""

__version__ = "2026.03.01"

from magnum_pi.bus import MagnumBus
from magnum_pi.cycle import BusCycle, CycleTracker, PacketType
from magnum_pi.framer import GapFramer
from magnum_pi.models import (
    AGSCountsPacket,
    AGSMode,
    AGSStatus,
    AGSStatusPacket,
    BatteryType,
    BMKFault,
    BMKPacket,
    InverterFault,
    InverterModel,
    InverterPacket,
    InverterStatus,
    RemotePacket,
    RTRPacket,
    StackMode,
)
from magnum_pi.transport import MockTransport, Transport

__all__ = [
    "__version__",
    "MagnumBus",
    "BusCycle",
    "CycleTracker",
    "GapFramer",
    "PacketType",
    "AGSCountsPacket",
    "AGSMode",
    "AGSStatus",
    "AGSStatusPacket",
    "BatteryType",
    "BMKFault",
    "BMKPacket",
    "InverterFault",
    "InverterModel",
    "InverterPacket",
    "InverterStatus",
    "RemotePacket",
    "RTRPacket",
    "StackMode",
    "MockTransport",
    "Transport",
]
