"""MagnumBus — main async interface to a Magnum Energy RS-485 network.

This is the primary user-facing API. It ties together the transport,
framer, and cycle tracker to provide a clean async interface for
reading device state and sending commands.
"""

import asyncio
import logging
from collections.abc import AsyncIterator

from magnum_pi.cycle import BusCycle, CycleTracker
from magnum_pi.framer import GapFramer
from magnum_pi.models.inverter import InverterPacket
from magnum_pi.models.bmk import BMKPacket
from magnum_pi.models.remote import RemotePacket
from magnum_pi.transport.base import Transport
from magnum_pi.transport.serial import SerialTransport, find_serial_device

log = logging.getLogger(__name__)

# Cycle boundary detection: if the gap between packets exceeds this,
# we treat it as a new cycle. The master cycle is ~100ms; typical
# inter-packet gaps within a cycle are 2-15ms.
CYCLE_GAP_MS = 35.0


class MagnumBus:
    """Async interface to a Magnum Energy RS-485 network.

    Usage:
        bus = MagnumBus("/dev/ttyUSB0")
        await bus.connect()
        async for cycle in bus.listen():
            print(cycle.inverter)
        await bus.close()

    Or as an async context manager:
        async with MagnumBus("/dev/ttyUSB0") as bus:
            cycle = await bus.read_cycle()
    """

    def __init__(
        self,
        device: str | None = None,
        baudrate: int = 19200,
        transport: Transport | None = None,
        gap_ms: float = 2.0,
    ):
        """Initialize the bus.

        Args:
            device: Serial device path. Auto-detected if None.
            baudrate: Serial baud rate (always 19200 for Magnum).
            transport: Optional pre-configured transport (for testing).
            gap_ms: Inter-character gap threshold for packet framing.
        """
        self._device = device
        self._baudrate = baudrate
        self._transport = transport
        self._framer = GapFramer(gap_ms=gap_ms)
        self._tracker = CycleTracker()
        self._cycle_queue: asyncio.Queue[BusCycle] = asyncio.Queue(maxsize=64)
        self._processor_task: asyncio.Task | None = None
        self._connected = False

        # Most recent state for quick access
        self._last_inverter: InverterPacket | None = None
        self._last_bmk: BMKPacket | None = None
        self._last_remote: RemotePacket | None = None

    async def connect(self) -> None:
        """Open the transport and start processing packets."""
        if self._connected:
            return

        if self._transport is None:
            device = self._device or find_serial_device()
            if device is None:
                raise RuntimeError(
                    "No serial device found. Specify a device path or "
                    "connect an RS-485 adapter."
                )
            self._transport = SerialTransport(device, self._baudrate)

        self._framer.bind()
        self._transport.set_data_handler(self._framer.data_received)
        await self._transport.open()
        self._connected = True
        self._processor_task = asyncio.create_task(self._process_packets())

    async def close(self) -> None:
        """Stop processing and close the transport."""
        self._connected = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass
            self._processor_task = None
        if self._transport:
            await self._transport.close()
            self._transport = None  # Prevent zombie writes

    async def __aenter__(self) -> "MagnumBus":
        await self.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def read_cycle(self) -> BusCycle:
        """Read one complete bus cycle.

        Blocks until a full cycle is available. A cycle is considered
        complete when a new inverter packet arrives (starting the next cycle)
        or when the cycle gap timeout fires.
        """
        return await self._cycle_queue.get()

    async def listen(self) -> AsyncIterator[BusCycle]:
        """Continuously yield bus cycles."""
        while self._connected:
            try:
                cycle = await asyncio.wait_for(self._cycle_queue.get(), timeout=1.0)
                yield cycle
            except asyncio.TimeoutError:
                continue

    async def send_remote_packet(self, packet: RemotePacket) -> None:
        """Transmit a Remote packet.

        The packet is serialized and written to the transport. For proper
        bus arbitration, this should be timed to the slave response window
        (~10ms after the inverter packet ends). In practice, the inverter
        is tolerant of out-of-window transmissions.
        """
        if not self._transport:
            raise RuntimeError("Not connected")
        data = packet.to_bytes(self._tracker.voltage_multiplier)
        await self._transport.write(data)

    @property
    def inverter(self) -> InverterPacket | None:
        """Most recent inverter state."""
        return self._last_inverter

    @property
    def bmk(self) -> BMKPacket | None:
        """Most recent BMK state."""
        return self._last_bmk

    @property
    def remote(self) -> RemotePacket | None:
        """Most recent remote state."""
        return self._last_remote

    @property
    def voltage_multiplier(self) -> int:
        """Current voltage multiplier (1/2/4 for 12V/24V/48V systems)."""
        return self._tracker.voltage_multiplier

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def _process_packets(self) -> None:
        """Main packet processing loop.

        Reads packets from the framer, identifies them, and groups
        them into cycles. A new cycle starts when an inverter-like
        packet arrives while the current cycle already has data.

        The key insight: we must detect the cycle boundary BEFORE parsing
        the new packet into the cycle, otherwise the completed cycle
        contains the next cycle's inverter packet.
        """
        try:
            while self._connected:
                try:
                    packet = await self._framer.read_packet()

                    # Pre-check: does this look like a new cycle's inverter?
                    is_cycle_boundary = (
                        self._tracker.current_cycle.raw_packets
                        and self._looks_like_inverter(packet)
                    )

                    if is_cycle_boundary:
                        completed = self._tracker.new_cycle()
                        self._emit_cycle(completed)

                    self._tracker.identify_and_parse(packet)

                    # Update convenience references
                    cycle = self._tracker.current_cycle
                    if cycle.inverter:
                        self._last_inverter = cycle.inverter
                    if cycle.bmk:
                        self._last_bmk = cycle.bmk
                    if cycle.remote:
                        self._last_remote = cycle.remote

                except asyncio.CancelledError:
                    raise  # Let cancellation propagate
                except Exception:
                    log.exception("Error processing packet — skipping")
                    continue

        except asyncio.CancelledError:
            # Emit whatever we have
            cycle = self._tracker.new_cycle()
            if cycle.raw_packets:
                self._emit_cycle(cycle)

    def _looks_like_inverter(self, data: bytes) -> bool:
        """Quick heuristic: is this packet likely an inverter packet?

        Checks length and revision byte (byte 10, non-zero for inverters).
        This is used for cycle boundary detection before full parsing.
        """
        if len(data) < 14:
            return False
        # Header-identified packets are never inverter
        if data[0] in (0x81, 0x91, 0xA1, 0xA2, 0xD1, 0xC1, 0xC2, 0xC3):
            return False
        # Check revision byte — non-zero indicates inverter
        if data[10] == 0:
            return False
        # Match against known inverter if we've seen one
        if self._tracker._inverter_revision is not None:
            return data[10] == self._tracker._inverter_revision
        return True

    def _emit_cycle(self, cycle: BusCycle) -> None:
        """Put a completed cycle on the output queue."""
        if cycle.raw_packets:
            if self._cycle_queue.full():
                try:
                    self._cycle_queue.get_nowait()  # Drop oldest
                except asyncio.QueueEmpty:
                    pass
                log.warning("Cycle queue full — dropped oldest cycle")
            self._cycle_queue.put_nowait(cycle)
            log.debug("Cycle emitted with %d packets", len(cycle.raw_packets))
