"""Pydantic models for Magnum Energy RS-485 packet types."""

from magnum_pi.models.enums import (
    AGSMode,
    AGSStatus,
    BatteryType,
    BMKFault,
    InverterFault,
    InverterModel,
    InverterStatus,
    StackMode,
)
from magnum_pi.models.inverter import InverterPacket
from magnum_pi.models.remote import RemotePacket
from magnum_pi.models.bmk import BMKPacket
from magnum_pi.models.ags import AGSStatusPacket, AGSCountsPacket
from magnum_pi.models.rtr import RTRPacket
from magnum_pi.models.scaling import scale_vac_cutout, decode_msb_time, encode_msb_time

__all__ = [
    "AGSMode",
    "AGSStatus",
    "AGSStatusPacket",
    "AGSCountsPacket",
    "BatteryType",
    "BMKFault",
    "BMKPacket",
    "InverterFault",
    "InverterModel",
    "InverterPacket",
    "InverterStatus",
    "RemotePacket",
    "RTRPacket",
    "StackMode",
    "scale_vac_cutout",
    "decode_msb_time",
    "encode_msb_time",
]
