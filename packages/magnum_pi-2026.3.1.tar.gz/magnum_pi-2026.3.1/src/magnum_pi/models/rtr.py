"""Router/Remote Terminal (RTR) packet model.

Minimal 2-byte packet with header 0x91 and a revision byte.
"""

from pydantic import BaseModel


class RTRPacket(BaseModel):
    """RTR packet (header 0x91, 2 bytes)."""

    revision: float  # raw / 10

    @classmethod
    def from_bytes(cls, data: bytes) -> "RTRPacket":
        if len(data) < 2:
            raise ValueError(f"RTR packet too short: {len(data)} bytes (need 2)")
        if data[0] != 0x91:
            raise ValueError(f"Not an RTR packet: header 0x{data[0]:02X} != 0x91")

        return cls(revision=round(data[1] / 10.0, 1))

    def to_bytes(self) -> bytes:
        return bytes([0x91, int(self.revision * 10)])
