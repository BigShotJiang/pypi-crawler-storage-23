"""Value scaling functions and lookup tables for Magnum RS-485 protocol.

The Magnum protocol uses various non-linear encodings and lookup tables
for certain fields. This module centralizes all scaling logic so packet
models can stay clean.
"""

# VAC cutout lookup table: raw byte value -> AC voltage threshold.
# The relationship is non-linear, so a lookup table is the only correct approach.
_VAC_CUTOUT_TABLE: list[tuple[int, int]] = [
    (0, 0),       # Disabled
    (110, 60),
    (122, 65),
    (135, 70),
    (145, 75),
    (155, 80),    # Default
    (165, 85),
    (175, 90),
    (182, 95),
    (190, 100),
    (255, 255),   # EMS override (ignores AC input)
]

# Build reverse lookup for encoding
_VAC_CUTOUT_REVERSE: dict[int, int] = {v: r for r, v in _VAC_CUTOUT_TABLE}


def scale_vac_cutout(raw: int) -> int:
    """Convert raw VAC cutout byte to AC voltage threshold.

    Uses nearest-match interpolation for values not in the table.
    """
    if raw == 0:
        return 0
    if raw == 255:
        return 255

    # Find the closest entry
    best_raw, best_vac = _VAC_CUTOUT_TABLE[0]
    for table_raw, table_vac in _VAC_CUTOUT_TABLE:
        if abs(raw - table_raw) < abs(raw - best_raw):
            best_raw = table_raw
            best_vac = table_vac
    return best_vac


def encode_vac_cutout(vac: int) -> int:
    """Convert AC voltage threshold back to raw byte value."""
    if vac in _VAC_CUTOUT_REVERSE:
        return _VAC_CUTOUT_REVERSE[vac]
    # Find nearest VAC value
    closest = min(_VAC_CUTOUT_REVERSE.keys(), key=lambda v: abs(v - vac))
    return _VAC_CUTOUT_REVERSE[closest]


def decode_msb_time(raw: int) -> int:
    """Decode MSB time encoding to seconds.

    Used for AGS start/stop delays, warm-up, cool-down.
    If MSB is set (bit 7), lower 7 bits are minutes.
    Otherwise, the value is seconds.
    """
    if raw & 0x80:
        return (raw & 0x7F) * 60
    return raw


def encode_msb_time(seconds: int) -> int:
    """Encode seconds to MSB time format.

    Uses seconds directly if <= 127, otherwise converts to minutes.
    """
    if seconds <= 127:
        return seconds
    minutes = seconds // 60
    if minutes <= 127:
        return 0x80 | minutes
    return 0x80 | 127  # Cap at 127 minutes


def decode_quarter_hour_time(raw: int) -> tuple[int, int]:
    """Decode 15-minute interval time to (hours, minutes).

    Used for AGS start/stop times, quiet times, exercise schedules.
    """
    total_minutes = raw * 15
    return (total_minutes // 60, total_minutes % 60)


def encode_quarter_hour_time(hours: int, minutes: int) -> int:
    """Encode (hours, minutes) to 15-minute interval value."""
    total_minutes = hours * 60 + minutes
    return total_minutes // 15
