"""Inverter (master) packet model.

The inverter transmits every ~100ms as the bus master. Core packet is 14 bytes
(bytes 0-13), extended packet adds 7 more bytes (14-20) for MS rev 4.0+.
"""

from pydantic import BaseModel

from magnum_pi.models.enums import (
    InverterFault,
    InverterModel,
    InverterStatus,
    StackMode,
)


class InverterPacket(BaseModel):
    """Decoded inverter/master packet.

    Core fields (bytes 0-13) are always present.
    Extended fields (bytes 14-20) are None for pre-rev-4.0 firmware.
    """

    # Core fields (bytes 0-13)
    status: InverterStatus
    fault: InverterFault
    dc_volts: float          # Scaled: raw / 10.0
    dc_amps: int             # Direct
    ac_volts_out: int        # RMS output, 0-150 VAC
    ac_volts_in: int         # Peak input, 0-255 VAC
    inverter_led: bool
    charger_led: bool
    revision: float          # raw / 10.0
    battery_temp_c: int      # 0-150 C
    transformer_temp_c: int  # 0-150 C
    fet_temp_c: int          # 0-150 C

    # Extended fields (bytes 14-20, MS rev 4.0+)
    model: InverterModel | None = None
    stack_mode: StackMode | None = None
    ac_amps_in: int | None = None
    ac_amps_out: int | None = None
    ac_freq_hz: float | None = None  # raw / 10.0

    @classmethod
    def from_bytes(cls, data: bytes) -> "InverterPacket":
        """Parse raw bytes into an InverterPacket.

        Accepts 16-byte (classic) or 21-byte (extended) packets.
        22-byte packets are truncated to 21 (communication artifact).
        """
        if len(data) == 22:
            data = data[:21]

        if len(data) < 14:
            raise ValueError(f"Inverter packet too short: {len(data)} bytes (need >= 14)")

        # Core fields: big-endian 16-bit for dc_volts and dc_amps
        try:
            status = InverterStatus(data[0])
        except ValueError:
            status = InverterStatus.UNKNOWN

        try:
            fault = InverterFault(data[1])
        except ValueError:
            fault = InverterFault.UNKNOWN
        dc_volts_raw = (data[2] << 8) | data[3]
        dc_amps_raw = (data[4] << 8) | data[5]

        kwargs: dict = {
            "status": status,
            "fault": fault,
            "dc_volts": dc_volts_raw / 10.0,
            "dc_amps": dc_amps_raw,
            "ac_volts_out": data[6],
            "ac_volts_in": data[7],
            "inverter_led": data[8] != 0,
            "charger_led": data[9] != 0,
            "revision": data[10] / 10.0,
            "battery_temp_c": data[11],
            "transformer_temp_c": data[12],
            "fet_temp_c": data[13],
        }

        # Extended fields (21-byte packet)
        if len(data) >= 21:
            try:
                kwargs["model"] = InverterModel(data[14])
            except ValueError:
                kwargs["model"] = None
            try:
                kwargs["stack_mode"] = StackMode(data[15])
            except ValueError:
                kwargs["stack_mode"] = None
            kwargs["ac_amps_in"] = data[16]
            kwargs["ac_amps_out"] = data[17]
            ac_freq_raw = (data[18] << 8) | data[19]
            kwargs["ac_freq_hz"] = ac_freq_raw / 10.0

        return cls(**kwargs)

    def to_bytes(self) -> bytes:
        """Serialize to wire format.

        Produces 21-byte packet if extended fields are present, 16-byte otherwise.
        """
        dc_volts_raw = int(self.dc_volts * 10)
        buf = bytearray(14)
        buf[0] = self.status.value
        buf[1] = self.fault.value
        buf[2] = (dc_volts_raw >> 8) & 0xFF
        buf[3] = dc_volts_raw & 0xFF
        buf[4] = (self.dc_amps >> 8) & 0xFF
        buf[5] = self.dc_amps & 0xFF
        buf[6] = self.ac_volts_out
        buf[7] = self.ac_volts_in
        buf[8] = 0x01 if self.inverter_led else 0x00
        buf[9] = 0x01 if self.charger_led else 0x00
        buf[10] = int(self.revision * 10)
        buf[11] = self.battery_temp_c
        buf[12] = self.transformer_temp_c
        buf[13] = self.fet_temp_c

        if self.model is not None:
            ext = bytearray(7)
            ext[0] = self.model.value
            ext[1] = self.stack_mode.value if self.stack_mode is not None else 0
            ext[2] = self.ac_amps_in or 0
            ext[3] = self.ac_amps_out or 0
            ac_freq_raw = int((self.ac_freq_hz or 0) * 10)
            ext[4] = (ac_freq_raw >> 8) & 0xFF
            ext[5] = ac_freq_raw & 0xFF
            ext[6] = 0x00  # Reserved
            buf.extend(ext)

        return bytes(buf)
