"""Remote (slave) packet model.

The remote panel responds ~10ms after the inverter master packet. Base fields
occupy bytes 0-15. For 21-byte packets, bytes 16-20 carry multiplexed
footer data identified by byte 20.
"""

from pydantic import BaseModel, Field, model_validator

from magnum_pi.models.enums import AGSMode, BatteryType, RemoteFooterType
from magnum_pi.models.scaling import (
    decode_msb_time,
    decode_quarter_hour_time,
    encode_msb_time,
    encode_quarter_hour_time,
    scale_vac_cutout,
)


class RemoteBase(BaseModel):
    """Base remote packet fields (bytes 0-15), always present.

    Note: eq_toggle uses bits 1+3 (0x0A) of byte 0. Since bit 1 is also
    charger_toggle, enabling EQ inherently sets the charger toggle bit.
    The model enforces this: when eq_toggle is True, charger_toggle must
    also be True (or will be set automatically).
    """

    # Byte 0: control flags
    inverter_toggle: bool = False   # Bit 0
    charger_toggle: bool = False    # Bit 1
    eq_toggle: bool = False         # Bits 1+3 (0x0A)

    search_watts: int = Field(default=5, ge=0, le=50)
    battery_size_ah: int = Field(default=400, ge=0, le=2550)  # raw * 10, max 255 * 10
    battery_type: BatteryType | None = BatteryType.FLOODED  # Byte 3 (if <= 100)
    custom_absorb_v: float | None = None                     # Byte 3 (if > 100, scaled)
    charger_amps_pct: int = Field(default=80, ge=0, le=100)
    shore_amps: int = Field(default=30, ge=-128, le=127)  # signed byte
    revision: float = 0.0           # Byte 6: raw / 10
    parallel_threshold: int = Field(default=0, ge=0, le=150)  # low nibble * 10
    force_disable_refloat: bool = False  # Byte 7 bit 4
    force_silent: bool = False           # Byte 7 bit 5
    force_float: bool = False            # Byte 7 bit 6
    force_bulk: bool = False             # Byte 7 bit 7
    ags_mode: AGSMode = AGSMode.OFF      # Byte 8
    lbco_v: float = Field(default=10.0, ge=0.0)  # Actual voltage, scaled by multiplier in from_bytes/to_bytes
    vac_cutout: int = Field(default=80, ge=0, le=255)
    vac_cutout_raw: int = Field(default=155, ge=0, le=255)
    float_v: float = Field(default=13.2, ge=0.0)  # scaled by multiplier, can be larger for 24V/48V
    eq_offset_v: float = Field(default=1.2, ge=0.0, le=25.5)
    absorb_time_hr: float = Field(default=2.0, ge=0.0, le=25.5)
    hours: int = Field(default=0, ge=0, le=255)    # 0-23 for BASE footer; raw byte when footer reuses bytes 14-15
    minutes: int = Field(default=0, ge=0, le=255)  # 0-59 for BASE footer; raw byte when footer reuses bytes 14-15

    @model_validator(mode='after')
    def eq_implies_charger_toggle(self) -> 'RemoteBase':
        """EQ toggle requires charger toggle bit (they share bit 1)."""
        if self.eq_toggle and not self.charger_toggle:
            self.charger_toggle = True
        return self


class RemoteFooterAGSLegacy(BaseModel):
    """Footer 0xA0: AGS legacy config (ME-RC rev 1.5+)."""

    gen_run_time_hr: float = 2.0     # Byte 16: raw / 10
    start_temp_f: int = 0            # Byte 17: degrees F
    start_vdc: float = 11.0          # Byte 18: raw / 10 (12V nominal)
    quiet_time: int = 0              # Byte 19


class RemoteFooterAGSExtA(BaseModel):
    """Footer 0xA1: AGS time-based start/stop."""

    start_hour: int = 0
    start_minute: int = 0
    stop_hour: int = 0
    stop_minute: int = 0
    vdc_stop: float = 14.4           # raw / 10 (12V nominal)
    volt_start_delay_s: int = 120    # MSB time decoded to seconds
    volt_stop_delay_s: int = 120
    max_run_hr: float = 12.0         # raw / 10


class RemoteFooterAGSExtB(BaseModel):
    """Footer 0xA2: AGS current-based start/stop."""

    soc_start_pct: int = 0
    soc_stop_pct: int = 90
    amp_start: int = 0
    amp_start_delay_s: int = 120
    amp_stop: int = 5
    amp_stop_delay_s: int = 120


class RemoteFooterAGSExtC(BaseModel):
    """Footer 0xA3: AGS quiet time and exercise."""

    quiet_begin_hour: int = 20
    quiet_begin_minute: int = 0
    quiet_end_hour: int = 10
    quiet_end_minute: int = 0
    exercise_days: int = 0
    exercise_start_hour: int = 8
    exercise_start_minute: int = 0
    exercise_runtime_hr: float = 1.0
    topoff_min: int = 0


class RemoteFooterAGSExtD(BaseModel):
    """Footer 0xA4: AGS warm-up and cool-down."""

    warmup_s: int = 60    # MSB time decoded to seconds
    cooldown_s: int = 60


class RemoteFooterBMK(BaseModel):
    """Footer 0x80: BMK configuration."""

    battery_efficiency_pct: int = 0  # 0 = auto tracking
    reset_command: int = 0           # 0=normal, 1-4=reset types
    bmk_battery_size_ah: int = 400   # raw * 10


class RemotePacket(BaseModel):
    """Complete remote packet with optional footer."""

    base: RemoteBase
    footer_type: RemoteFooterType = RemoteFooterType.BASE
    ags_legacy: RemoteFooterAGSLegacy | None = None
    ags_ext_a: RemoteFooterAGSExtA | None = None
    ags_ext_b: RemoteFooterAGSExtB | None = None
    ags_ext_c: RemoteFooterAGSExtC | None = None
    ags_ext_d: RemoteFooterAGSExtD | None = None
    bmk: RemoteFooterBMK | None = None

    @classmethod
    def from_bytes(cls, data: bytes, voltage_multiplier: int = 1) -> "RemotePacket":
        """Parse raw bytes into a RemotePacket.

        voltage_multiplier scales 12V-nominal values (1 for 12V, 2 for 24V, 4 for 48V).
        """
        if len(data) == 22:
            data = data[:21]
        if len(data) < 16:
            raise ValueError(f"Remote packet too short: {len(data)} bytes (need >= 16)")

        base = _parse_base(data, voltage_multiplier)

        footer_type = RemoteFooterType.BASE
        kwargs: dict = {"base": base, "footer_type": footer_type}

        if len(data) >= 21:
            footer_byte = data[20]
            try:
                footer_type = RemoteFooterType(footer_byte)
            except ValueError:
                footer_type = RemoteFooterType.BASE
            kwargs["footer_type"] = footer_type

            if footer_type == RemoteFooterType.AGS_LEGACY:
                kwargs["ags_legacy"] = _parse_footer_a0(data, voltage_multiplier)
            elif footer_type == RemoteFooterType.AGS_EXT_A:
                kwargs["ags_ext_a"] = _parse_footer_a1(data, voltage_multiplier)
            elif footer_type == RemoteFooterType.AGS_EXT_B:
                kwargs["ags_ext_b"] = _parse_footer_a2(data)
            elif footer_type == RemoteFooterType.AGS_EXT_C:
                kwargs["ags_ext_c"] = _parse_footer_a3(data)
            elif footer_type == RemoteFooterType.AGS_EXT_D:
                kwargs["ags_ext_d"] = _parse_footer_a4(data)
            elif footer_type == RemoteFooterType.BMK:
                kwargs["bmk"] = _parse_footer_80(data)

        return cls(**kwargs)

    def to_bytes(self, voltage_multiplier: int = 1) -> bytes:
        """Serialize to wire format (always 21 bytes)."""
        buf = bytearray(21)
        b = self.base

        # Byte 0: control flags
        ctrl = 0
        if b.inverter_toggle:
            ctrl |= 0x01
        if b.charger_toggle:
            ctrl |= 0x02
        if b.eq_toggle:
            ctrl |= 0x0A
        buf[0] = ctrl

        buf[1] = b.search_watts
        buf[2] = b.battery_size_ah // 10

        # Byte 3: battery type or custom absorb voltage
        if b.custom_absorb_v is not None and b.custom_absorb_v > 0:
            buf[3] = int(b.custom_absorb_v * 10 / voltage_multiplier)
        elif b.battery_type is not None:
            buf[3] = b.battery_type.value
        else:
            buf[3] = BatteryType.FLOODED.value

        buf[4] = b.charger_amps_pct
        buf[5] = b.shore_amps & 0xFF
        buf[6] = int(b.revision * 10)

        # Byte 7: parallel threshold (low nibble) + force flags (high nibble)
        byte7 = (b.parallel_threshold // 10) & 0x0F
        if b.force_disable_refloat:
            byte7 |= 0x10
        if b.force_silent:
            byte7 |= 0x20
        if b.force_float:
            byte7 |= 0x40
        if b.force_bulk:
            byte7 |= 0x80
        buf[7] = byte7

        buf[8] = b.ags_mode.value
        buf[9] = int(b.lbco_v * 10 / voltage_multiplier)
        buf[10] = b.vac_cutout_raw
        buf[11] = int(b.float_v * 10 / voltage_multiplier)
        buf[12] = int(b.eq_offset_v * 10)
        buf[13] = int(b.absorb_time_hr * 10)

        # Bytes 14-15 default to hours/minutes
        buf[14] = b.hours
        buf[15] = b.minutes

        # Footer
        buf[20] = self.footer_type.value

        if self.footer_type == RemoteFooterType.AGS_LEGACY and self.ags_legacy:
            f = self.ags_legacy
            buf[16] = int(f.gen_run_time_hr * 10)
            buf[17] = f.start_temp_f
            buf[18] = int(f.start_vdc * 10 / voltage_multiplier)
            buf[19] = f.quiet_time

        elif self.footer_type == RemoteFooterType.AGS_EXT_A and self.ags_ext_a:
            f = self.ags_ext_a
            buf[14] = encode_quarter_hour_time(f.start_hour, f.start_minute)
            buf[15] = encode_quarter_hour_time(f.stop_hour, f.stop_minute)
            buf[16] = int(f.vdc_stop * 10 / voltage_multiplier)
            buf[17] = encode_msb_time(f.volt_start_delay_s)
            buf[18] = encode_msb_time(f.volt_stop_delay_s)
            buf[19] = int(f.max_run_hr * 10)

        elif self.footer_type == RemoteFooterType.AGS_EXT_B and self.ags_ext_b:
            f = self.ags_ext_b
            buf[14] = f.soc_start_pct
            buf[15] = f.soc_stop_pct
            buf[16] = f.amp_start
            buf[17] = encode_msb_time(f.amp_start_delay_s)
            buf[18] = f.amp_stop
            buf[19] = encode_msb_time(f.amp_stop_delay_s)

        elif self.footer_type == RemoteFooterType.AGS_EXT_C and self.ags_ext_c:
            f = self.ags_ext_c
            buf[14] = encode_quarter_hour_time(f.quiet_begin_hour, f.quiet_begin_minute)
            buf[15] = encode_quarter_hour_time(f.quiet_end_hour, f.quiet_end_minute)
            buf[16] = f.exercise_days
            buf[17] = encode_quarter_hour_time(f.exercise_start_hour, f.exercise_start_minute)
            buf[18] = int(f.exercise_runtime_hr * 10)
            buf[19] = f.topoff_min

        elif self.footer_type == RemoteFooterType.AGS_EXT_D and self.ags_ext_d:
            f = self.ags_ext_d
            buf[14] = encode_msb_time(f.warmup_s)
            buf[15] = encode_msb_time(f.cooldown_s)

        elif self.footer_type == RemoteFooterType.BMK and self.bmk:
            f = self.bmk
            buf[16] = f.battery_efficiency_pct
            buf[17] = f.reset_command
            buf[18] = f.bmk_battery_size_ah // 10

        return bytes(buf)


def _parse_base(data: bytes, multiplier: int) -> RemoteBase:
    """Parse base remote fields from bytes 0-15."""
    ctrl = data[0]
    inverter_toggle = bool(ctrl & 0x01)
    charger_toggle = bool(ctrl & 0x02)
    eq_toggle = (ctrl & 0x0A) == 0x0A

    # Byte 3: battery type vs custom absorb
    byte3 = data[3]
    battery_type: BatteryType | None = None
    custom_absorb: float | None = None
    if byte3 > 100:
        custom_absorb = byte3 * multiplier / 10.0
    else:
        try:
            battery_type = BatteryType(byte3)
        except ValueError:
            battery_type = None

    # Byte 7: parallel + force flags
    byte7 = data[7]
    parallel = (byte7 & 0x0F) * 10

    # Byte 5 is signed in pymagnum's struct format
    shore_amps = data[5]
    if shore_amps > 127:
        shore_amps = shore_amps - 256

    vac_raw = data[10]

    return RemoteBase(
        inverter_toggle=inverter_toggle,
        charger_toggle=charger_toggle,
        eq_toggle=eq_toggle,
        search_watts=data[1],
        battery_size_ah=data[2] * 10,
        battery_type=battery_type,
        custom_absorb_v=custom_absorb,
        charger_amps_pct=data[4],
        shore_amps=shore_amps,
        revision=data[6] / 10.0,
        parallel_threshold=parallel,
        force_disable_refloat=bool(byte7 & 0x10),
        force_silent=bool(byte7 & 0x20),
        force_float=bool(byte7 & 0x40),
        force_bulk=bool(byte7 & 0x80),
        ags_mode=AGSMode(data[8]) if data[8] in AGSMode.__members__.values() else AGSMode.OFF,
        lbco_v=data[9] * multiplier / 10.0,
        vac_cutout=scale_vac_cutout(vac_raw),
        vac_cutout_raw=vac_raw,
        float_v=data[11] * multiplier / 10.0,
        eq_offset_v=data[12] / 10.0,
        absorb_time_hr=data[13] / 10.0,
        hours=data[14] if len(data) > 14 else 0,
        minutes=data[15] if len(data) > 15 else 0,
    )


def _parse_footer_a0(data: bytes, multiplier: int) -> RemoteFooterAGSLegacy:
    return RemoteFooterAGSLegacy(
        gen_run_time_hr=data[16] / 10.0,
        start_temp_f=data[17],
        start_vdc=data[18] * multiplier / 10.0,
        quiet_time=data[19],
    )


def _parse_footer_a1(data: bytes, multiplier: int) -> RemoteFooterAGSExtA:
    sh, sm = decode_quarter_hour_time(data[14])
    eh, em = decode_quarter_hour_time(data[15])
    return RemoteFooterAGSExtA(
        start_hour=sh,
        start_minute=sm,
        stop_hour=eh,
        stop_minute=em,
        vdc_stop=data[16] * multiplier / 10.0,
        volt_start_delay_s=decode_msb_time(data[17]),
        volt_stop_delay_s=decode_msb_time(data[18]),
        max_run_hr=data[19] / 10.0,
    )


def _parse_footer_a2(data: bytes) -> RemoteFooterAGSExtB:
    return RemoteFooterAGSExtB(
        soc_start_pct=data[14],
        soc_stop_pct=data[15],
        amp_start=data[16],
        amp_start_delay_s=decode_msb_time(data[17]),
        amp_stop=data[18],
        amp_stop_delay_s=decode_msb_time(data[19]),
    )


def _parse_footer_a3(data: bytes) -> RemoteFooterAGSExtC:
    qbh, qbm = decode_quarter_hour_time(data[14])
    qeh, qem = decode_quarter_hour_time(data[15])
    # Byte 16 is exercise_days (direct), byte 17 is exercise start time (quarter-hour)
    esh, esm = decode_quarter_hour_time(data[17])
    return RemoteFooterAGSExtC(
        quiet_begin_hour=qbh,
        quiet_begin_minute=qbm,
        quiet_end_hour=qeh,
        quiet_end_minute=qem,
        exercise_days=data[16],
        exercise_start_hour=esh,
        exercise_start_minute=esm,
        exercise_runtime_hr=data[18] / 10.0,
        topoff_min=data[19],
    )


def _parse_footer_a4(data: bytes) -> RemoteFooterAGSExtD:
    return RemoteFooterAGSExtD(
        warmup_s=decode_msb_time(data[14]),
        cooldown_s=decode_msb_time(data[15]),
    )


def _parse_footer_80(data: bytes) -> RemoteFooterBMK:
    return RemoteFooterBMK(
        battery_efficiency_pct=data[16],
        reset_command=data[17],
        bmk_battery_size_ah=data[18] * 10,
    )
