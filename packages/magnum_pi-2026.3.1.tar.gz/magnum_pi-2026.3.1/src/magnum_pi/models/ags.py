"""Auto Generator Start (AGS) packet models.

The AGS transmits two packet types directly on the bus:
- 0xA1 (status): 6 bytes with operational state, temp, runtime, voltage
- 0xA2 (counts): 6 bytes with days since last run, SOC, total runtime
"""

from pydantic import BaseModel

from magnum_pi.models.enums import AGSStatus


class AGSStatusPacket(BaseModel):
    """AGS status packet (header 0xA1, 6 bytes).

    Sent by AGS every 4th remote cycle (~10ms after remote).
    """

    status: AGSStatus
    revision: float        # raw / 10
    temp_f: int            # Fahrenheit (protocol native unit)
    runtime_hr: float      # raw / 10
    vdc: float             # raw / 10 (12V nominal, needs multiplier)

    @property
    def temp_c(self) -> float:
        """Temperature converted to Celsius."""
        return round((self.temp_f - 32) * 5 / 9, 1)

    @classmethod
    def from_bytes(cls, data: bytes, voltage_multiplier: int = 1) -> "AGSStatusPacket":
        if len(data) < 6:
            raise ValueError(f"AGS status packet too short: {len(data)} bytes (need 6)")
        if data[0] != 0xA1:
            raise ValueError(f"Not an AGS status packet: header 0x{data[0]:02X} != 0xA1")

        try:
            status = AGSStatus(data[1])
        except ValueError:
            status = AGSStatus.NOT_CONNECTED

        return cls(
            status=status,
            revision=round(data[2] / 10.0, 1),
            temp_f=data[3],
            runtime_hr=round(data[4] / 10.0, 1),
            vdc=round(data[5] / 10.0 * voltage_multiplier, 1),
        )

    def to_bytes(self, voltage_multiplier: int = 1) -> bytes:
        buf = bytearray(6)
        buf[0] = 0xA1
        buf[1] = self.status.value
        buf[2] = int(self.revision * 10)
        buf[3] = self.temp_f
        buf[4] = int(self.runtime_hr * 10)
        buf[5] = int(self.vdc * 10 / voltage_multiplier)
        return bytes(buf)


class AGSCountsPacket(BaseModel):
    """AGS counts/extended packet (header 0xA2, 6 bytes)."""

    days_since_last_run: int
    days_since_full_soc: int
    total_runtime: int       # Aggregate value

    @classmethod
    def from_bytes(cls, data: bytes) -> "AGSCountsPacket":
        if len(data) < 6:
            raise ValueError(f"AGS counts packet too short: {len(data)} bytes (need 6)")
        if data[0] != 0xA2:
            raise ValueError(f"Not an AGS counts packet: header 0x{data[0]:02X} != 0xA2")

        return cls(
            days_since_last_run=data[1],
            days_since_full_soc=data[2],
            total_runtime=(data[3] << 8) | data[4],
        )

    def to_bytes(self) -> bytes:
        buf = bytearray(6)
        buf[0] = 0xA2
        buf[1] = self.days_since_last_run
        buf[2] = self.days_since_full_soc
        buf[3] = (self.total_runtime >> 8) & 0xFF
        buf[4] = self.total_runtime & 0xFF
        buf[5] = 0x00
        return bytes(buf)
