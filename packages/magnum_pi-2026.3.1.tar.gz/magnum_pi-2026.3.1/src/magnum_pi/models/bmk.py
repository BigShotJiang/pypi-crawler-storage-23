"""Battery Monitor Kit (BMK) packet model.

The BMK transmits directly on the bus with header byte 0x81.
It provides high-resolution battery voltage (0.01V) and signed current (0.1A).
"""

from pydantic import BaseModel

from magnum_pi.models.enums import BMKFault


class BMKPacket(BaseModel):
    """Decoded BMK battery monitor packet (header 0x81).

    18 bytes from pymagnum's BMK_81 format, or up to 21 from protocol spec.
    The BMK provides higher precision voltage (0.01V vs inverter's 0.1V)
    and signed current (positive = charging, negative = discharging).
    """

    soc_pct: int                  # State of charge 0-100%, 255 = calculating
    dc_volts: float               # 0.01V resolution
    dc_amps: float                # 0.1A resolution, signed
    min_volts: float              # 0.01V resolution
    max_volts: float              # 0.01V resolution
    amp_hours: int                # Cumulative, signed
    amp_hour_trip: float          # 0.1 AH resolution
    amp_hours_out: float          # Cumulative discharge, * 100
    revision: float               # raw / 10
    fault: BMKFault

    @classmethod
    def from_bytes(cls, data: bytes) -> "BMKPacket":
        """Parse BMK packet bytes (expects header byte 0x81 at position 0)."""
        if len(data) < 18:
            raise ValueError(f"BMK packet too short: {len(data)} bytes (need >= 18)")

        if data[0] != 0x81:
            raise ValueError(f"Not a BMK packet: header 0x{data[0]:02X} != 0x81")

        soc = data[1]

        # 16-bit big-endian unsigned for voltage
        dc_volts_raw = (data[2] << 8) | data[3]

        # 16-bit big-endian signed for current
        dc_amps_raw = (data[4] << 8) | data[5]
        if dc_amps_raw > 32767:
            dc_amps_raw -= 65536

        min_volts_raw = (data[6] << 8) | data[7]
        max_volts_raw = (data[8] << 8) | data[9]

        # Amp hours: 16-bit signed
        amph_raw = (data[10] << 8) | data[11]
        if amph_raw > 32767:
            amph_raw -= 65536

        amph_trip_raw = (data[12] << 8) | data[13]
        amph_out_raw = (data[14] << 8) | data[15]

        revision_raw = data[16]

        try:
            fault = BMKFault(data[17])
        except ValueError:
            fault = BMKFault.RESERVED

        return cls(
            soc_pct=soc,
            dc_volts=round(dc_volts_raw / 100.0, 2),
            dc_amps=round(dc_amps_raw / 10.0, 1),
            min_volts=round(min_volts_raw / 100.0, 2),
            max_volts=round(max_volts_raw / 100.0, 2),
            amp_hours=amph_raw,
            amp_hour_trip=round(amph_trip_raw / 10.0, 1),
            amp_hours_out=round(amph_out_raw * 100.0, 2),
            revision=round(revision_raw / 10.0, 1),
            fault=fault,
        )

    def to_bytes(self) -> bytes:
        """Serialize to wire format (18 bytes)."""
        buf = bytearray(18)
        buf[0] = 0x81

        buf[1] = self.soc_pct

        dc_volts_raw = int(self.dc_volts * 100)
        buf[2] = (dc_volts_raw >> 8) & 0xFF
        buf[3] = dc_volts_raw & 0xFF

        dc_amps_raw = int(self.dc_amps * 10)
        if dc_amps_raw < 0:
            dc_amps_raw += 65536
        buf[4] = (dc_amps_raw >> 8) & 0xFF
        buf[5] = dc_amps_raw & 0xFF

        min_v_raw = int(self.min_volts * 100)
        buf[6] = (min_v_raw >> 8) & 0xFF
        buf[7] = min_v_raw & 0xFF

        max_v_raw = int(self.max_volts * 100)
        buf[8] = (max_v_raw >> 8) & 0xFF
        buf[9] = max_v_raw & 0xFF

        amph_raw = self.amp_hours
        if amph_raw < 0:
            amph_raw += 65536
        buf[10] = (amph_raw >> 8) & 0xFF
        buf[11] = amph_raw & 0xFF

        trip_raw = int(self.amp_hour_trip * 10)
        buf[12] = (trip_raw >> 8) & 0xFF
        buf[13] = trip_raw & 0xFF

        out_raw = int(self.amp_hours_out / 100.0)
        buf[14] = (out_raw >> 8) & 0xFF
        buf[15] = out_raw & 0xFF

        buf[16] = int(self.revision * 10)
        buf[17] = self.fault.value

        return bytes(buf)
