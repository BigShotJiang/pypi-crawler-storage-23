"""Enumerations for Magnum Energy RS-485 protocol fields.

All values sourced from the Magnum Networking Communications Protocol
specification (2009-10-15) and validated against pymagnum v2.0.8.
"""

from enum import IntEnum


class InverterStatus(IntEnum):
    """Inverter operating mode (master packet byte 0)."""

    UNKNOWN = -1
    STANDBY = 0x00
    EQ = 0x01
    FLOAT = 0x02
    ABSORB = 0x04
    BULK = 0x08
    BATSAVER = 0x09
    CHARGE = 0x10
    OFF = 0x20
    INVERT = 0x40
    INVERTER_STANDBY = 0x50
    SEARCH = 0x80

    @property
    def is_charging(self) -> bool:
        return self in (
            self.EQ, self.FLOAT, self.ABSORB, self.BULK,
            self.BATSAVER, self.CHARGE,
        )

    @property
    def is_inverting(self) -> bool:
        return self in (self.INVERT, self.SEARCH)


class InverterFault(IntEnum):
    """Inverter fault codes (master packet byte 1)."""

    UNKNOWN = -1
    NONE = 0x00
    STUCK_RELAY = 0x01
    DC_OVERLOAD = 0x02
    AC_OVERLOAD = 0x03
    DEAD_BAT = 0x04
    BACKFEED = 0x05
    LOW_BAT = 0x08
    HIGH_BAT = 0x09
    HIGH_AC_VOLTS = 0x0A
    BAD_BRIDGE = 0x10
    NTC_FAULT = 0x12
    FET_OVERLOAD = 0x13
    INTERNAL_FAULT4 = 0x14
    STACKER_MODE_FAULT = 0x16
    STACKER_NO_CLK_FAULT = 0x17
    STACKER_CLK_PH_FAULT = 0x18
    STACKER_PH_LOSS_FAULT = 0x19
    OVER_TEMP = 0x20
    RELAY_FAULT = 0x21
    CHARGER_FAULT = 0x80
    HIGH_BAT_TEMP = 0x81
    OPEN_SELCO_TCO = 0x90
    CB3_OPEN_FAULT = 0x91


class InverterModel(IntEnum):
    """Inverter model IDs (extended packet byte 14).

    Naming convention: Family + Watts + Voltage suffix.
    Models <= 50 are 12V, 51-107 are 24V, 108+ are 48V.
    """

    MM612 = 0x06
    MM612_AE = 0x07
    MM1212 = 0x08
    MMS1012 = 0x09
    MM1012E = 0x0A
    MM1512 = 0x0B
    MMS912E = 0x0C
    ME1512 = 0x0F
    ME2012 = 0x14
    RD2212 = 0x15
    ME2512 = 0x19
    ME3112 = 0x1E
    MS2012 = 0x23
    MS1512E = 0x24
    MS2012E = 0x28
    MSH3012M = 0x2C
    MS2812 = 0x2D
    MS2712E = 0x2F
    MM1324E = 0x35
    MM1524 = 0x36
    RD1824 = 0x37
    RD2624E = 0x3B
    RD2824 = 0x3F
    RD4024E = 0x45
    RD3924 = 0x4A
    MS4124E = 0x5A
    MS2024 = 0x5B
    MSH4024M = 0x67
    MSH4024RE = 0x68
    MS4024 = 0x69
    MS4024AE = 0x6A
    MS4024PAE = 0x6B
    MS4448AE = 0x6F
    MS3748AEJ = 0x70
    MS4048 = 0x72
    MS4448PAE = 0x73
    MS3748PAEJ = 0x74
    MS4348PE = 0x75

    @property
    def voltage_multiplier(self) -> int:
        """Battery voltage multiplier based on nominal system voltage.

        12V models: 1x, 24V models: 2x, 48V models: 4x.
        Used to scale battery voltage readings from 12V-nominal values.
        """
        if self.value <= 50:
            return 1
        elif self.value <= 107:
            return 2
        else:
            return 4

    @property
    def nominal_voltage(self) -> int:
        return 12 * self.voltage_multiplier


class StackMode(IntEnum):
    """Stacking configuration (extended packet byte 15)."""

    STANDALONE = 0x00
    PARALLEL_MASTER = 0x01
    PARALLEL_SLAVE = 0x02
    SERIES_MASTER = 0x04
    SERIES_SLAVE = 0x08


class BatteryType(IntEnum):
    """Battery chemistry selection (remote packet byte 3).

    Values > 100 indicate custom charge profile where the value
    represents the absorption voltage (scaled by multiplier / 10).
    """

    GEL = 2
    FLOODED = 4
    AGM = 8
    AGM2 = 10


class AGSMode(IntEnum):
    """Auto Generator Start mode (remote packet byte 8)."""

    OFF = 0
    ENABLE = 1
    TEST = 2
    ENABLE_QUIET = 4
    ON = 5  # AGS rev 5.0+ only


class AGSStatus(IntEnum):
    """AGS operational status (AGS packet byte 1).

    Status codes from the protocol spec and pymagnum.
    """

    NOT_CONNECTED = 0
    OFF = 1
    READY = 2
    MANUAL_RUN = 3
    AC_IN = 4
    IN_QUIET_TIME = 5
    START_TEST = 6
    START_TEMP = 7
    START_VOLTAGE = 8
    FAULT_START_TEST = 9
    FAULT_START_TEMP = 10
    FAULT_START_VOLTAGE = 11
    START_TOD = 12
    START_SOC = 13
    START_EXERCISE = 14
    FAULT_START_TOD = 15
    FAULT_START_SOC = 16
    FAULT_START_EXERCISE = 17
    START_AMP = 18
    START_TOPOFF = 19
    # 20 is not defined in pymagnum
    FAULT_START_AMP = 21
    FAULT_TOPOFF = 22
    # 23 is not defined in pymagnum
    FAULT_MAX_RUN = 24
    GEN_RUN_FAULT = 25
    GEN_WARM_UP = 26
    GEN_COOL_DOWN = 27

    @property
    def is_running(self) -> bool:
        return self in (
            self.MANUAL_RUN, self.START_TEST, self.START_TEMP,
            self.START_VOLTAGE, self.START_TOD, self.START_SOC,
            self.START_EXERCISE, self.START_AMP, self.START_TOPOFF,
            self.GEN_WARM_UP, self.GEN_COOL_DOWN,
        )

    @property
    def is_fault(self) -> bool:
        return self in (
            self.FAULT_START_TEST, self.FAULT_START_TEMP,
            self.FAULT_START_VOLTAGE, self.FAULT_START_TOD,
            self.FAULT_START_SOC, self.FAULT_START_EXERCISE,
            self.FAULT_START_AMP, self.FAULT_TOPOFF,
            self.FAULT_MAX_RUN, self.GEN_RUN_FAULT,
        )


class BMKFault(IntEnum):
    """Battery Monitor Kit fault codes (BMK packet last byte)."""

    RESERVED = 0
    NORMAL = 1
    FAULT_START = 2


class RemoteFooterType(IntEnum):
    """Footer identifier byte (remote packet byte 20).

    Determines the meaning of bytes 14-19 in the 21-byte remote packet.
    """

    BASE = 0x00       # No footer (bytes 14-15 = hours/minutes)
    BMK = 0x80        # BMK configuration
    AGS_LEGACY = 0xA0  # AGS base config (ME-RC rev 1.5+)
    AGS_EXT_A = 0xA1   # AGS extended A (ME-ARC, AGS rev 5.0+)
    AGS_EXT_B = 0xA2   # AGS extended B
    AGS_EXT_C = 0xA3   # AGS extended C
    AGS_EXT_D = 0xA4   # AGS extended D
