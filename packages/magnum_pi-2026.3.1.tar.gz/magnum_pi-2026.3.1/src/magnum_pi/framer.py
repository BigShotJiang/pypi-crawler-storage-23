"""Gap-based packet framer for the Magnum RS-485 protocol.

The Magnum protocol has no delimiters, no length prefix, and no CRC.
Packets are framed entirely by inter-character silence: ~0.5ms between
bytes within a packet, ~2ms+ gap between packets. At 19200 baud, each
byte takes ~520us (10 bits: start + 8 data + stop).

The framer buffers incoming bytes and emits a complete packet whenever
the gap timer fires without new data arriving.
"""

import asyncio
import logging
from collections.abc import Callable

log = logging.getLogger(__name__)


class GapFramer:
    """Buffers incoming bytes, emits complete packets on silence detection.

    The gap threshold should be set between the intra-packet byte time (~0.5ms)
    and the inter-packet gap (~2ms). A value of 1.5-2.0ms works well for
    19200 baud Magnum traffic.
    """

    def __init__(self, gap_ms: float = 2.0):
        self._buffer = bytearray()
        self._gap_ms = gap_ms
        self._timer: asyncio.TimerHandle | None = None
        self._packet_queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=128)
        self._on_packet: Callable[[bytes], None] | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind(self, loop: asyncio.AbstractEventLoop | None = None) -> None:
        """Bind to an event loop. Must be called before data_received."""
        self._loop = loop or asyncio.get_running_loop()

    def data_received(self, data: bytes) -> None:
        """Feed raw bytes from the transport.

        Called by the transport layer whenever bytes arrive from the serial port.
        Resets the gap timer on every call — when data stops arriving for
        gap_ms, the accumulated buffer is emitted as a complete packet.
        """
        self._buffer.extend(data)

        if self._timer is not None:
            self._timer.cancel()

        loop = self._loop or asyncio.get_running_loop()
        self._timer = loop.call_later(self._gap_ms / 1000.0, self._emit_packet)

    def _emit_packet(self) -> None:
        """Gap detected — emit buffered bytes as a complete packet."""
        self._timer = None
        if not self._buffer:
            return

        packet = bytes(self._buffer)
        self._buffer.clear()

        if self._packet_queue.full():
            log.warning("Packet queue full (maxsize=%d) — dropping packet (%d bytes)",
                        self._packet_queue.maxsize, len(packet))
            return

        self._packet_queue.put_nowait(packet)
        log.debug("Packet emitted (%d bytes)", len(packet))

        if self._on_packet:
            self._on_packet(packet)

    async def read_packet(self) -> bytes:
        """Await the next complete packet."""
        return await self._packet_queue.get()

    def read_packet_nowait(self) -> bytes | None:
        """Return a packet if available, else None."""
        try:
            return self._packet_queue.get_nowait()
        except asyncio.QueueEmpty:
            return None

    def set_callback(self, callback: Callable[[bytes], None] | None) -> None:
        """Set optional synchronous callback invoked on each emitted packet."""
        self._on_packet = callback

    @property
    def pending_count(self) -> int:
        """Number of packets waiting in the queue."""
        return self._packet_queue.qsize()

    def flush(self) -> bytes | None:
        """Force-emit current buffer contents (if any) and return them."""
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None
        if self._buffer:
            packet = bytes(self._buffer)
            self._buffer.clear()
            self._packet_queue.put_nowait(packet)
            return packet
        return None
