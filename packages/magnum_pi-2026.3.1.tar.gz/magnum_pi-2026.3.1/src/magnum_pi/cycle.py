"""Bus cycle tracker for the Magnum RS-485 network.

The Magnum bus operates on a ~100ms master cycle:
1. Inverter (master) transmits its status packet
2. ~10ms later, the remote (slave) responds
3. Additional devices (AGS, BMK, RTR) may transmit after the remote

Packet identification uses a combination of:
- Position in the cycle (first = inverter, second = remote)
- Header byte for directly-addressed devices (0x81=BMK, 0x91=RTR, 0xA1/0xA2=AGS)
- Packet length as a secondary discriminator
"""

import logging
from enum import Enum, auto

from magnum_pi.models.ags import AGSCountsPacket, AGSStatusPacket
from magnum_pi.models.bmk import BMKPacket
from magnum_pi.models.inverter import InverterPacket
from magnum_pi.models.remote import RemotePacket
from magnum_pi.models.rtr import RTRPacket

log = logging.getLogger(__name__)


class PacketType(Enum):
    """Identified packet type within a bus cycle."""

    INVERTER = auto()
    REMOTE = auto()
    AGS_STATUS = auto()
    AGS_COUNTS = auto()
    BMK = auto()
    RTR = auto()
    UNKNOWN = auto()


class BusCycle:
    """A complete set of packets from one ~100ms bus cycle.

    Collects all packets seen between two cycle boundaries and provides
    typed access to each device's data.
    """

    def __init__(self) -> None:
        self.inverter: InverterPacket | None = None
        self.remote: RemotePacket | None = None
        self.ags_status: AGSStatusPacket | None = None
        self.ags_counts: AGSCountsPacket | None = None
        self.bmk: BMKPacket | None = None
        self.rtr: RTRPacket | None = None
        self.raw_packets: list[tuple[PacketType, bytes]] = []
        self.unknown_packets: list[bytes] = []

    @property
    def has_inverter(self) -> bool:
        return self.inverter is not None

    def to_dict(self) -> dict:
        """Serialize all present devices to a dictionary."""
        result: dict = {}
        if self.inverter:
            result["inverter"] = self.inverter.model_dump()
        if self.remote:
            result["remote"] = {
                "base": self.remote.base.model_dump(),
                "footer_type": self.remote.footer_type.name,
            }
            # Include active footer
            for attr in ("ags_legacy", "ags_ext_a", "ags_ext_b",
                         "ags_ext_c", "ags_ext_d", "bmk"):
                footer = getattr(self.remote, attr)
                if footer is not None:
                    result["remote"][attr] = footer.model_dump()
        if self.ags_status:
            result["ags_status"] = self.ags_status.model_dump()
        if self.ags_counts:
            result["ags_counts"] = self.ags_counts.model_dump()
        if self.bmk:
            result["bmk"] = self.bmk.model_dump()
        if self.rtr:
            result["rtr"] = self.rtr.model_dump()
        return result


class CycleTracker:
    """Identifies packets within a bus cycle and maintains state.

    Tracks the inverter model (and thus voltage multiplier) from the first
    inverter packet seen. Uses per-instance state rather than global class
    variables to support monitoring multiple inverters.
    """

    def __init__(self) -> None:
        self._inverter_revision: float | None = None
        self._inverter_model_id: int | None = None
        self._voltage_multiplier: int = 1
        self._packet_index: int = 0  # Position within current cycle
        self._current_cycle = BusCycle()

    @property
    def voltage_multiplier(self) -> int:
        return self._voltage_multiplier

    @property
    def inverter_model_id(self) -> int | None:
        return self._inverter_model_id

    def new_cycle(self) -> BusCycle:
        """Start a new cycle, returning the completed one."""
        completed = self._current_cycle
        self._current_cycle = BusCycle()
        self._packet_index = 0
        return completed

    def identify_and_parse(self, data: bytes) -> PacketType:
        """Identify a packet's type and parse it into the current cycle.

        Returns the identified PacketType.
        """
        ptype = self._identify(data)
        self._parse_into_cycle(ptype, data)
        self._current_cycle.raw_packets.append((ptype, data))
        self._packet_index += 1
        return ptype

    @property
    def current_cycle(self) -> BusCycle:
        return self._current_cycle

    def _identify(self, data: bytes) -> PacketType:
        """Determine packet type from header byte, length, and position.

        Priority: header byte > length heuristics > cycle position.
        """
        if not data:
            return PacketType.UNKNOWN

        header = data[0]
        length = len(data)

        # Header-identified packets (unambiguous)
        if header == 0x81 and length >= 18:
            return PacketType.BMK
        if header == 0x91 and length == 2:
            return PacketType.RTR
        if header == 0xA1 and length == 6:
            return PacketType.AGS_STATUS
        if header == 0xA2 and length == 6:
            return PacketType.AGS_COUNTS

        # Position-based identification for 16/21-byte packets
        if length in (16, 21, 22):
            if self._packet_index == 0:
                return self._identify_as_inverter_or_remote(data)
            elif self._packet_index == 1:
                return PacketType.REMOTE

        return PacketType.UNKNOWN

    def _identify_as_inverter_or_remote(self, data: bytes) -> PacketType:
        """Disambiguate the first packet in a cycle.

        The first 21-byte packet could be inverter or remote.
        We use byte 10 (revision) as the key discriminator:
        - Inverter revision is always non-zero
        - For subsequent cycles, we match against the stored revision/model
        """
        if len(data) < 14:
            return PacketType.UNKNOWN

        revision = data[10]

        # First inverter seen — learn its identity
        if self._inverter_revision is None:
            if revision != 0:
                self._inverter_revision = revision
                if len(data) >= 21:
                    self._inverter_model_id = data[14]
                return PacketType.INVERTER
            return PacketType.REMOTE

        # Subsequent: match against known inverter
        if revision == self._inverter_revision:
            if len(data) >= 21 and self._inverter_model_id is not None:
                if data[14] == self._inverter_model_id:
                    return PacketType.INVERTER
            else:
                return PacketType.INVERTER

        return PacketType.REMOTE

    def _parse_into_cycle(self, ptype: PacketType, data: bytes) -> None:
        """Parse the packet and store it in the current cycle."""
        try:
            if ptype == PacketType.INVERTER:
                inv = InverterPacket.from_bytes(data)
                self._current_cycle.inverter = inv
                # Learn voltage multiplier from model
                if inv.model is not None and self._inverter_model_id is None:
                    self._inverter_model_id = inv.model.value
                    self._voltage_multiplier = inv.model.voltage_multiplier
                    log.debug("Learned voltage multiplier=%d from model %s",
                              self._voltage_multiplier, inv.model.name)

            elif ptype == PacketType.REMOTE:
                self._current_cycle.remote = RemotePacket.from_bytes(
                    data, self._voltage_multiplier
                )

            elif ptype == PacketType.AGS_STATUS:
                self._current_cycle.ags_status = AGSStatusPacket.from_bytes(
                    data, self._voltage_multiplier
                )

            elif ptype == PacketType.AGS_COUNTS:
                self._current_cycle.ags_counts = AGSCountsPacket.from_bytes(data)

            elif ptype == PacketType.BMK:
                self._current_cycle.bmk = BMKPacket.from_bytes(data)

            elif ptype == PacketType.RTR:
                self._current_cycle.rtr = RTRPacket.from_bytes(data)

            else:
                self._current_cycle.unknown_packets.append(data)

        except Exception as e:
            log.warning("Failed to parse %s packet (%d bytes): %s — %s  hex=%s",
                        ptype.name, len(data), type(e).__name__, e, data.hex())
            self._current_cycle.unknown_packets.append(data)
