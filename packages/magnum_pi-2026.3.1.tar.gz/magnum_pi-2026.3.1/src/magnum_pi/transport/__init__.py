"""Transport abstractions for RS-485 communication."""

from magnum_pi.transport.base import Transport
from magnum_pi.transport.mock import MockTransport

__all__ = ["Transport", "MockTransport"]
