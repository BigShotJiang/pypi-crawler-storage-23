"""Mock transport for testing without hardware.

Supports three modes:
1. Manual: push packets via inject() for controlled test scenarios
2. File replay: load captured hex dumps in pymagnum's allpackets.txt format
3. Cycle loop: continuously replay a set of packets with realistic timing
"""

import asyncio
from collections.abc import Callable
from pathlib import Path


class MockTransport:
    """In-memory transport for testing.

    Packets are injected programmatically and delivered to the data handler
    with configurable inter-packet delays to simulate bus timing.
    """

    def __init__(self, inter_packet_ms: float = 5.0):
        self._inter_packet_ms = inter_packet_ms
        self._data_handler: Callable[[bytes], None] | None = None
        self._is_open = False
        self._replay_task: asyncio.Task | None = None
        self._packets: list[bytes] = []
        self._written: list[bytes] = []  # Captures write() calls for assertions

    async def open(self) -> None:
        self._is_open = True

    async def close(self) -> None:
        self._is_open = False
        if self._replay_task:
            self._replay_task.cancel()
            try:
                await self._replay_task
            except asyncio.CancelledError:
                pass
            self._replay_task = None

    async def write(self, data: bytes) -> None:
        if not self._is_open:
            raise RuntimeError("Transport not open")
        self._written.append(data)

    def set_data_handler(self, handler: Callable[[bytes], None]) -> None:
        self._data_handler = handler

    @property
    def is_open(self) -> bool:
        return self._is_open

    @property
    def written_packets(self) -> list[bytes]:
        """All data passed to write(), for test assertions."""
        return list(self._written)

    def inject(self, packet: bytes) -> None:
        """Immediately deliver a packet to the data handler.

        Simulates bytes arriving on the wire with no gap between them,
        followed by a natural gap (the framer's gap timer will fire).
        """
        if self._data_handler:
            self._data_handler(packet)

    def load_packets(self, packets: list[bytes]) -> None:
        """Queue packets for replay via start_replay()."""
        self._packets = list(packets)

    def load_hex_file(self, path: str | Path) -> None:
        """Load packets from a pymagnum-style hex dump file.

        Expected format (one per line):
            Length:NN TYPE =>HEXDATA
        Lines starting with # are comments.
        """
        path = Path(path)
        packets: list[bytes] = []
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=>" not in line:
                continue
            hex_data = line.split("=>")[1].strip()
            try:
                packets.append(bytes.fromhex(hex_data))
            except ValueError:
                continue
        self._packets = packets

    async def start_replay(self, loop: bool = False) -> None:
        """Replay loaded packets with inter-packet delays.

        If loop=True, replays continuously until close() is called.
        """
        if not self._packets:
            return
        self._replay_task = asyncio.create_task(self._replay_loop(loop))

    async def _replay_loop(self, loop: bool) -> None:
        try:
            while True:
                for packet in self._packets:
                    if not self._is_open:
                        return
                    self.inject(packet)
                    await asyncio.sleep(self._inter_packet_ms / 1000.0)
                if not loop:
                    break
        except asyncio.CancelledError:
            pass


def load_test_packets() -> list[bytes]:
    """Load the built-in sample packets from pymagnum testdata."""
    sample_file = Path(__file__).parent.parent.parent.parent / "tests" / "testdata" / "allpackets.txt"
    if sample_file.exists():
        transport = MockTransport()
        transport.load_hex_file(sample_file)
        return transport._packets
    return []
