"""Serial port transport using pyserial-asyncio.

Wraps a real RS-485 serial device for async I/O. The transport handles
opening/closing the port and shuttling bytes between the serial port
and the framer via the data handler callback.
"""

import asyncio
import glob
import logging
from collections.abc import Callable

import serial_asyncio

log = logging.getLogger(__name__)


def find_serial_device() -> str | None:
    """Auto-detect a likely RS-485 serial device.

    Checks common device paths in priority order. Returns the first
    path that exists, or None.
    """
    candidates = [
        "/dev/ttyUSB*",     # USB-to-RS485 dongles (most common)
        "/dev/ttyAMA*",     # Pi 3/5 UART (Waveshare HAT)
        "/dev/ttyS0",       # Pi 4 UART (Waveshare HAT)
        "/dev/ttyACM*",     # USB CDC devices
    ]
    for pattern in candidates:
        matches = sorted(glob.glob(pattern))
        if matches:
            return matches[0]
    return None


class SerialTransport:
    """Async serial transport for RS-485 communication.

    Wraps pyserial-asyncio to provide non-blocking serial I/O.
    Direction control (DE/RE) is handled by the adapter hardware —
    this transport just reads and writes bytes.
    """

    def __init__(self, device: str, baudrate: int = 19200):
        self._device = device
        self._baudrate = baudrate
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._data_handler: Callable[[bytes], None] | None = None
        self._read_task: asyncio.Task | None = None
        self._is_open = False

    async def open(self) -> None:
        self._reader, self._writer = await serial_asyncio.open_serial_connection(
            url=self._device,
            baudrate=self._baudrate,
            bytesize=8,
            parity="N",
            stopbits=1,
            rtscts=False,
            dsrdtr=False,
        )
        self._is_open = True
        log.info("Connected to %s @ %d baud", self._device, self._baudrate)
        self._read_task = asyncio.create_task(self._read_loop())

    async def close(self) -> None:
        self._is_open = False
        log.info("Disconnecting from %s", self._device)
        if self._read_task:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
            self._read_task = None
        if self._writer:
            self._writer.close()
            self._writer = None
        self._reader = None

    async def write(self, data: bytes) -> None:
        if not self._writer:
            raise RuntimeError("Transport not open")
        self._writer.write(data)
        await self._writer.drain()

    def set_data_handler(self, handler: Callable[[bytes], None]) -> None:
        self._data_handler = handler

    @property
    def is_open(self) -> bool:
        return self._is_open

    async def _read_loop(self) -> None:
        """Continuously read from serial and dispatch to handler."""
        if self._reader is None:
            raise RuntimeError("Transport not open: reader is None")
        try:
            while self._is_open:
                # Read whatever is available (up to 256 bytes at a time).
                # Small reads are fine — the framer handles reassembly.
                data = await self._reader.read(256)
                if not data:
                    log.warning("Serial port returned EOF — device disconnected")
                    self._is_open = False
                    break
                if self._data_handler:
                    self._data_handler(data)
        except asyncio.CancelledError:
            pass
        except Exception:
            self._is_open = False
            raise
