"""Abstract transport protocol for RS-485 communication.

Any transport (serial, mock, file replay) implements this interface.
The bus layer programs to this protocol, not a concrete class.
"""

from typing import Protocol, runtime_checkable
from collections.abc import Callable


@runtime_checkable
class Transport(Protocol):
    """Transport interface for sending/receiving raw bytes."""

    async def open(self) -> None:
        """Open the transport connection."""
        ...

    async def close(self) -> None:
        """Close the transport connection."""
        ...

    async def write(self, data: bytes) -> None:
        """Write raw bytes to the transport."""
        ...

    def set_data_handler(self, handler: Callable[[bytes], None]) -> None:
        """Register a callback for incoming data.

        The handler is called with raw bytes as they arrive.
        It may be called from any thread — the handler should be
        thread-safe or dispatch to the event loop.
        """
        ...

    @property
    def is_open(self) -> bool:
        """Whether the transport is currently connected."""
        ...
