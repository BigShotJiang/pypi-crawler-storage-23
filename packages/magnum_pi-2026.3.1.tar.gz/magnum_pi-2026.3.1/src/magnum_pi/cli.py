"""CLI entry point for magnum-pi.

Commands:
    magnum-pi sniff       Raw hex dump of bus traffic
    magnum-pi monitor     Decoded live data (JSON lines)
    magnum-pi send        Send commands to the inverter
"""

import argparse
import asyncio
import json
import sys

from magnum_pi.bus import MagnumBus

BANNER = """\
╭──────────────────────────────────╮
│   ╭───────────────╮              │
│   ╰──╮         ╭──╯   MAGNUM    │
│      ╰─────────╯      P . I .   │
│                                  │
│  Private Investigator for        │
│  Magnum Energy RS-485 Networks   │
╰──────────────────────────────────╯"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="magnum-pi",
        description="Magnum Energy RS-485 bus tool",
        epilog=BANNER,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--device",
        "-d",
        help="Serial device path (auto-detected if omitted)",
    )
    parser.add_argument(
        "--baudrate",
        "-b",
        type=int,
        default=19200,
        help="Serial baud rate (default: 19200)",
    )

    sub = parser.add_subparsers(dest="command", help="Command to run")

    # sniff: raw hex dump
    sniff_p = sub.add_parser("sniff", help="Raw hex dump of bus traffic")
    sniff_p.add_argument(
        "--count",
        "-n",
        type=int,
        default=0,
        help="Number of packets to capture (0 = continuous)",
    )

    # monitor: decoded JSON
    mon_p = sub.add_parser("monitor", help="Decoded live data")
    mon_p.add_argument(
        "--pretty",
        "-p",
        action="store_true",
        help="Human-readable output instead of JSON lines",
    )
    mon_p.add_argument(
        "--count",
        "-n",
        type=int,
        default=0,
        help="Number of cycles to capture (0 = continuous)",
    )

    # send: transmit commands
    send_p = sub.add_parser("send", help="Send commands to inverter")
    send_group = send_p.add_mutually_exclusive_group(required=True)
    send_group.add_argument(
        "--inverter",
        choices=["toggle"],
        help="Toggle inverter power (on/off will be added in a future release)",
    )
    send_group.add_argument(
        "--charger",
        choices=["toggle"],
        help="Toggle charger (on/off will be added in a future release)",
    )
    send_p.add_argument(
        "--voltage",
        type=int,
        choices=[12, 24, 48],
        help="System voltage override (auto-detected from inverter model if omitted)",
    )

    return parser


async def cmd_sniff(args: argparse.Namespace) -> None:
    """Raw hex dump of bus traffic."""
    print("We're on the case...", file=sys.stderr)
    bus = MagnumBus(device=args.device, baudrate=args.baudrate)
    await bus.connect()
    count = 0
    try:
        async for cycle in bus.listen():
            for ptype, data in cycle.raw_packets:
                hex_str = data.hex().upper()
                print(f"[{ptype.name:12s}] ({len(data):2d}) {hex_str}")
                count += 1
                if args.count and count >= args.count:
                    return
    except KeyboardInterrupt:
        pass
    finally:
        await bus.close()
        print("Case closed.", file=sys.stderr)


async def cmd_monitor(args: argparse.Namespace) -> None:
    """Decoded live data output."""
    print("We're on the case...", file=sys.stderr)
    bus = MagnumBus(device=args.device, baudrate=args.baudrate)
    await bus.connect()
    count = 0
    try:
        async for cycle in bus.listen():
            data = cycle.to_dict()
            if not data:
                continue

            if args.pretty:
                _print_pretty(data)
            else:
                print(json.dumps(data, default=str))

            count += 1
            if args.count and count >= args.count:
                return
    except KeyboardInterrupt:
        pass
    finally:
        await bus.close()
        print("Case closed.", file=sys.stderr)


def _print_pretty(data: dict) -> None:
    """Human-readable dashboard output."""
    if "inverter" in data:
        inv = data["inverter"]
        print(
            f"  INV: {inv['status']} | {inv['dc_volts']:.1f}V {inv['dc_amps']}A"
            f" | AC out:{inv['ac_volts_out']}V in:{inv['ac_volts_in']}V"
            f" | Temps: bat={inv['battery_temp_c']}C xfmr={inv['transformer_temp_c']}C"
            f" fet={inv['fet_temp_c']}C"
        )
        if inv.get("fault") and inv["fault"] != "NONE":
            print(f"  FAULT: {inv['fault']}")

    if "bmk" in data:
        bmk = data["bmk"]
        print(
            f"  BMK: SOC={bmk['soc_pct']}% | {bmk['dc_volts']:.2f}V {bmk['dc_amps']:.1f}A"
            f" | range:{bmk['min_volts']:.2f}-{bmk['max_volts']:.2f}V"
        )

    if "ags_status" in data:
        ags = data["ags_status"]
        print(
            f"  AGS: {ags['status']} | {ags['vdc']:.1f}V | {ags['temp_f']}F"
            f" | runtime:{ags['runtime_hr']:.1f}h"
        )

    if "remote" in data:
        rem = data["remote"]["base"]
        print(
            f"  REM: shore={rem['shore_amps']}A float={rem['float_v']:.1f}V"
            f" lbco={rem['lbco_v']:.1f}V bat={rem['battery_size_ah']}Ah"
        )

    print("---")


async def cmd_send(args: argparse.Namespace) -> None:
    """Send a command packet."""
    from magnum_pi.models.remote import RemoteBase, RemotePacket

    print("We're on the case...", file=sys.stderr)
    bus = MagnumBus(device=args.device, baudrate=args.baudrate)
    await bus.connect()

    try:
        # Wait for at least one cycle to learn bus state
        await bus.read_cycle()

        print(f"Connected. System voltage multiplier: {bus.voltage_multiplier}x", file=sys.stderr)

        if bus.inverter is None:
            print("No inverter detected on bus. Aborting — cannot send safely.", file=sys.stderr)
            return

        # Voltage override warning (bus.py override coming in a follow-up)
        if args.voltage:
            expected_mult = args.voltage // 12
            if expected_mult != bus.voltage_multiplier:
                print(
                    f"Warning: --voltage {args.voltage} (mult={expected_mult}x) "
                    f"differs from detected multiplier ({bus.voltage_multiplier}x).",
                    file=sys.stderr,
                )
                print(
                    "Voltage override not yet wired to send path — using detected value for now.",
                    file=sys.stderr,
                )

        # Build the toggle kwargs
        base_kwargs: dict = {}
        if args.inverter == "toggle":
            base_kwargs["inverter_toggle"] = True
        elif args.charger == "toggle":
            base_kwargs["charger_toggle"] = True

        # Read current remote state to avoid overwriting config
        if bus.remote is not None:
            base = bus.remote.base.model_copy(update=base_kwargs)
        else:
            print("Warning: No remote state captured yet. Using defaults.", file=sys.stderr)
            base = RemoteBase(**base_kwargs)

        packet = RemotePacket(base=base)
        await bus.send_remote_packet(packet)
        print("Command sent.", file=sys.stderr)

    finally:
        await bus.close()


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        print(BANNER, file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    cmd_map = {
        "sniff": cmd_sniff,
        "monitor": cmd_monitor,
        "send": cmd_send,
    }

    try:
        asyncio.run(cmd_map[args.command](args))
    except KeyboardInterrupt:
        pass
    except RuntimeError as e:
        err_msg = str(e)
        if "No serial device" in err_msg or "serial" in err_msg.lower():
            print("I know what you're thinking, and you're right.", file=sys.stderr)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
