"""Tests for MagnumBus integration using mock transport."""

import asyncio

import pytest

from magnum_pi.bus import MagnumBus
from magnum_pi.cycle import PacketType
from magnum_pi.models.enums import InverterModel, InverterStatus
from magnum_pi.transport.mock import MockTransport
from conftest import SAMPLE_PACKETS


class TestMagnumBus:
    """Integration tests using mock transport with captured packets."""

    async def test_read_single_cycle(self):
        """Feed a complete cycle and verify decoded state."""
        transport = MockTransport(inter_packet_ms=5)
        bus = MagnumBus(transport=transport, gap_ms=15)

        await bus.connect()

        # Inject a cycle: inverter -> remote -> ags -> bmk -> rtr
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)  # Gap between packets
        transport.inject(SAMPLE_PACKETS["remote_a0"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["ags_a1"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["bmk_81"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["rtr_91"])
        await asyncio.sleep(0.020)

        # Start next cycle to flush the first
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)

        cycle = await asyncio.wait_for(bus.read_cycle(), timeout=1.0)

        assert cycle.has_inverter
        assert cycle.inverter is not None
        assert cycle.inverter.status == InverterStatus.INVERT
        assert cycle.inverter.model == InverterModel.MS4024PAE

        assert cycle.remote is not None
        assert cycle.ags_status is not None
        assert cycle.bmk is not None
        assert cycle.rtr is not None

        await bus.close()

    async def test_convenience_properties(self):
        """Bus should track most recent device state."""
        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)

        await bus.connect()

        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["bmk_81"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)

        await asyncio.wait_for(bus.read_cycle(), timeout=1.0)

        assert bus.inverter is not None
        assert bus.bmk is not None

        await bus.close()

    async def test_context_manager(self):
        """Async context manager should connect and close properly."""
        transport = MockTransport()
        async with MagnumBus(transport=transport, gap_ms=15) as bus:
            assert bus.is_connected
        assert not bus.is_connected

    async def test_send_remote_packet(self):
        """send_remote_packet should write serialized bytes to transport."""
        from magnum_pi.models.remote import RemoteBase, RemotePacket

        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)
        await bus.connect()

        packet = RemotePacket(base=RemoteBase(inverter_toggle=True))
        await bus.send_remote_packet(packet)

        assert len(transport.written_packets) == 1
        written = transport.written_packets[0]
        assert len(written) == 21
        assert written[0] & 0x01 == 1  # Inverter toggle bit set

        await bus.close()

    async def test_cycle_to_dict(self):
        """to_dict should produce a serializable dictionary."""
        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)
        await bus.connect()

        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["remote_a0"])
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)

        cycle = await asyncio.wait_for(bus.read_cycle(), timeout=1.0)
        data = cycle.to_dict()

        assert "inverter" in data
        assert "remote" in data
        assert data["inverter"]["dc_volts"] == pytest.approx(24.6, abs=0.1)

        await bus.close()


class TestBusResilience:
    """Tests for review fixes: queue bounds, disconnect, exception handling."""

    async def test_send_requires_connection(self):
        """send_remote_packet on a closed bus should raise RuntimeError."""
        from magnum_pi.models.remote import RemoteBase, RemotePacket

        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)
        await bus.connect()
        await bus.close()

        packet = RemotePacket(base=RemoteBase(inverter_toggle=True))
        with pytest.raises(RuntimeError, match="Not connected"):
            await bus.send_remote_packet(packet)

    async def test_transport_nulled_after_close(self):
        """After close(), _transport should be None to prevent zombie writes."""
        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)
        await bus.connect()
        await bus.close()
        assert bus._transport is None

    async def test_unknown_packet_handled_gracefully(self):
        """A packet with garbled data should not crash the processing loop."""
        transport = MockTransport()
        bus = MagnumBus(transport=transport, gap_ms=15)
        await bus.connect()

        # Inject a valid inverter, then a garbled packet, then another inverter
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)
        transport.inject(b"\xFF\xFE\xFD\xFC\xFB\xFA\xF9\xF8\xF7\xF6\xF5\xF4\xF3\xF2\xF1\xF0")
        await asyncio.sleep(0.020)
        transport.inject(SAMPLE_PACKETS["inverter_21"])
        await asyncio.sleep(0.020)

        # Should get a cycle despite the garbled packet
        cycle = await asyncio.wait_for(bus.read_cycle(), timeout=1.0)
        assert cycle.has_inverter

        await bus.close()


class TestMockTransport:
    """Test mock transport capabilities."""

    async def test_load_hex_file(self):
        """Load packets from pymagnum-format hex file."""
        import os
        testdata = os.path.join(os.path.dirname(__file__), "testdata", "allpackets.txt")
        if not os.path.exists(testdata):
            pytest.skip("testdata not available")

        transport = MockTransport()
        transport.load_hex_file(testdata)
        assert len(transport._packets) > 0

    async def test_inject_and_handler(self):
        """inject() should deliver bytes to data handler."""
        transport = MockTransport()
        received: list[bytes] = []
        transport.set_data_handler(lambda d: received.append(d))
        await transport.open()

        transport.inject(b"\x91\x20")
        assert len(received) == 1
        assert received[0] == b"\x91\x20"

        await transport.close()

    async def test_write_capture(self):
        """write() should capture data for test assertions."""
        transport = MockTransport()
        await transport.open()

        await transport.write(b"\x00\x01\x02")
        assert transport.written_packets == [b"\x00\x01\x02"]

        await transport.close()
