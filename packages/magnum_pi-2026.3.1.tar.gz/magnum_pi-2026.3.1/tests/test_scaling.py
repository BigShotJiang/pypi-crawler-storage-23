"""Tests for value scaling functions."""

import pytest

from magnum_pi.models.scaling import (
    decode_msb_time,
    decode_quarter_hour_time,
    encode_msb_time,
    encode_quarter_hour_time,
    encode_vac_cutout,
    scale_vac_cutout,
)


class TestVACCutout:
    """Test the non-linear VAC cutout lookup table."""

    def test_disabled(self):
        assert scale_vac_cutout(0) == 0

    def test_default_80v(self):
        assert scale_vac_cutout(155) == 80

    def test_ems_override(self):
        assert scale_vac_cutout(255) == 255

    def test_known_values(self):
        assert scale_vac_cutout(110) == 60
        assert scale_vac_cutout(135) == 70
        assert scale_vac_cutout(190) == 100

    def test_nearest_match(self):
        """Values between table entries should find the closest."""
        result = scale_vac_cutout(150)
        assert result in (75, 80)  # Between 145->75 and 155->80

    def test_encode_round_trip(self):
        for raw, vac in [(0, 0), (155, 80), (190, 100), (255, 255)]:
            assert encode_vac_cutout(vac) == raw


class TestMSBTime:
    """Test MSB time encoding (seconds vs minutes)."""

    def test_seconds_mode(self):
        assert decode_msb_time(30) == 30
        assert decode_msb_time(127) == 127

    def test_minutes_mode(self):
        assert decode_msb_time(0x85) == 5 * 60  # 5 minutes = 300 seconds
        assert decode_msb_time(0x80) == 0        # 0 minutes
        assert decode_msb_time(0xFF) == 127 * 60  # Max minutes

    def test_encode_seconds(self):
        assert encode_msb_time(30) == 30
        assert encode_msb_time(127) == 127

    def test_encode_minutes(self):
        assert encode_msb_time(300) == 0x85  # 5 minutes
        assert encode_msb_time(3600) == 0x80 | 60  # 60 minutes

    def test_round_trip(self):
        for seconds in [0, 30, 60, 120, 300, 3600]:
            encoded = encode_msb_time(seconds)
            decoded = decode_msb_time(encoded)
            # Round-trip preserves value (within minute resolution for large values)
            if seconds <= 127:
                assert decoded == seconds
            else:
                assert abs(decoded - seconds) < 60  # Within 1 minute


class TestQuarterHourTime:
    """Test 15-minute interval time encoding."""

    def test_midnight(self):
        assert decode_quarter_hour_time(0) == (0, 0)

    def test_8am(self):
        assert decode_quarter_hour_time(32) == (8, 0)

    def test_6pm(self):
        assert decode_quarter_hour_time(72) == (18, 0)

    def test_7am(self):
        assert decode_quarter_hour_time(28) == (7, 0)

    def test_encode_round_trip(self):
        for raw in [0, 28, 32, 72, 80, 95]:
            h, m = decode_quarter_hour_time(raw)
            assert encode_quarter_hour_time(h, m) == raw
