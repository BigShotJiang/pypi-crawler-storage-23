"""Tests for the gap-based packet framer."""

import asyncio

import pytest

from magnum_pi.framer import GapFramer


class TestGapFramer:
    """Test gap-based packet framing logic."""

    async def test_single_packet(self):
        """Bytes delivered in one chunk, gap fires, packet emitted."""
        framer = GapFramer(gap_ms=10)  # 10ms gap for test speed
        framer.bind()

        data = b"\x40\x00\x00\xF6\x00\x16"
        framer.data_received(data)

        # Wait for gap timer to fire
        await asyncio.sleep(0.015)

        packet = framer.read_packet_nowait()
        assert packet == data

    async def test_fragmented_delivery(self):
        """Bytes arriving in small chunks before gap should form one packet."""
        framer = GapFramer(gap_ms=20)
        framer.bind()

        # Deliver bytes in small chunks with < gap_ms between them
        framer.data_received(b"\x40\x00")
        await asyncio.sleep(0.005)  # 5ms < 20ms gap
        framer.data_received(b"\x00\xF6")
        await asyncio.sleep(0.005)
        framer.data_received(b"\x00\x16")

        # Wait for gap
        await asyncio.sleep(0.025)

        packet = framer.read_packet_nowait()
        assert packet == b"\x40\x00\x00\xF6\x00\x16"

    async def test_two_packets_with_gap(self):
        """Two packets separated by a gap should produce two separate packets."""
        framer = GapFramer(gap_ms=10)
        framer.bind()

        framer.data_received(b"\x40\x00\x00")
        await asyncio.sleep(0.015)  # Gap fires
        framer.data_received(b"\xA1\x02\x34")
        await asyncio.sleep(0.015)  # Gap fires

        p1 = framer.read_packet_nowait()
        p2 = framer.read_packet_nowait()
        assert p1 == b"\x40\x00\x00"
        assert p2 == b"\xA1\x02\x34"

    async def test_read_packet_awaits(self):
        """read_packet() should block until a packet is available."""
        framer = GapFramer(gap_ms=10)
        framer.bind()

        async def delayed_inject():
            await asyncio.sleep(0.02)
            framer.data_received(b"\x91\x20")
            # Wait for gap
            await asyncio.sleep(0.015)

        task = asyncio.create_task(delayed_inject())
        packet = await asyncio.wait_for(framer.read_packet(), timeout=0.1)
        assert packet == b"\x91\x20"
        await task

    async def test_flush(self):
        """flush() should force-emit current buffer."""
        framer = GapFramer(gap_ms=100)  # Long gap so timer won't fire
        framer.bind()

        framer.data_received(b"\x81\x4C")
        result = framer.flush()
        assert result == b"\x81\x4C"

    async def test_callback(self):
        """Synchronous callback should fire on each emitted packet."""
        framer = GapFramer(gap_ms=10)
        framer.bind()
        received: list[bytes] = []
        framer.set_callback(lambda p: received.append(p))

        framer.data_received(b"\x91\x20")
        await asyncio.sleep(0.015)

        assert len(received) == 1
        assert received[0] == b"\x91\x20"

    async def test_empty_buffer_no_emit(self):
        """No packet should be emitted if buffer is empty."""
        framer = GapFramer(gap_ms=10)
        framer.bind()
        assert framer.pending_count == 0
        result = framer.flush()
        assert result is None
