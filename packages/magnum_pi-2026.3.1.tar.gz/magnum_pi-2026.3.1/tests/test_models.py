"""Tests for packet model parsing and serialization.

Uses captured packets from the pymagnum testdata to verify our models
produce the same decoded values as the battle-tested reference implementation.
"""

import pytest

from magnum_pi.models.ags import AGSCountsPacket, AGSStatusPacket
from magnum_pi.models.bmk import BMKPacket
from magnum_pi.models.enums import (
    AGSStatus,
    BMKFault,
    InverterFault,
    InverterModel,
    InverterStatus,
    RemoteFooterType,
    StackMode,
)
from magnum_pi.models.inverter import InverterPacket
from magnum_pi.models.remote import RemoteBase, RemotePacket
from magnum_pi.models.rtr import RTRPacket
from conftest import SAMPLE_PACKETS


class TestInverterUnknownEnums:
    """Test graceful handling of unknown status/fault codes (Fix R2)."""

    def test_unknown_status_code(self):
        """Firmware sends a status byte not in our enum — should not crash."""
        data = bytearray(SAMPLE_PACKETS["inverter_21"])
        data[0] = 0x60  # Not a known InverterStatus
        pkt = InverterPacket.from_bytes(bytes(data))
        assert pkt.status == InverterStatus.UNKNOWN
        assert pkt.status.is_charging is False
        assert pkt.status.is_inverting is False

    def test_unknown_fault_code(self):
        """Firmware sends a fault byte not in our enum — should not crash."""
        data = bytearray(SAMPLE_PACKETS["inverter_21"])
        data[1] = 0xFE  # Not a known InverterFault
        pkt = InverterPacket.from_bytes(bytes(data))
        assert pkt.fault == InverterFault.UNKNOWN
        # All other fields should still parse correctly
        assert pkt.dc_volts == pytest.approx(24.6, abs=0.1)
        assert pkt.model == InverterModel.MS4024PAE


class TestInverterPacket:
    """Test inverter packet parsing against known values."""

    def test_parse_21_byte(self, inverter_bytes: bytes):
        """Parse the sample 21-byte inverter packet.

        Raw: 400000F60016770001003D1133246B010005025800
        Expected: INVERT mode, no fault, 24.6V, 22A, 119V out, etc.
        """
        pkt = InverterPacket.from_bytes(inverter_bytes)

        assert pkt.status == InverterStatus.INVERT
        assert pkt.fault == InverterFault.NONE
        assert pkt.dc_volts == pytest.approx(24.6, abs=0.1)
        assert pkt.dc_amps == 22
        assert pkt.ac_volts_out == 119
        assert pkt.ac_volts_in == 0
        assert pkt.inverter_led is True
        assert pkt.charger_led is False
        assert pkt.revision == pytest.approx(6.1, abs=0.1)
        assert pkt.battery_temp_c == 17
        assert pkt.transformer_temp_c == 51
        assert pkt.fet_temp_c == 36

        # Extended fields
        assert pkt.model == InverterModel.MS4024PAE
        assert pkt.stack_mode == StackMode.PARALLEL_MASTER
        assert pkt.ac_amps_in == 0
        assert pkt.ac_amps_out == 5
        assert pkt.ac_freq_hz == pytest.approx(60.0, abs=0.1)

    def test_round_trip(self, inverter_bytes: bytes):
        """Parse and re-serialize should produce identical bytes."""
        pkt = InverterPacket.from_bytes(inverter_bytes)
        reserialized = pkt.to_bytes()
        # Re-parse to verify equivalence
        pkt2 = InverterPacket.from_bytes(reserialized)
        assert pkt2.status == pkt.status
        assert pkt2.dc_volts == pytest.approx(pkt.dc_volts, abs=0.1)
        assert pkt2.model == pkt.model

    def test_short_packet_raises(self):
        assert pytest.raises(ValueError, InverterPacket.from_bytes, b"\x40\x00")

    def test_16_byte_packet(self):
        """16-byte (pre-rev-4.0) packet should have None for extended fields."""
        data = bytes.fromhex("400000F600167700010024113324")
        assert len(data) == 14
        pkt = InverterPacket.from_bytes(data)
        assert pkt.status == InverterStatus.INVERT
        assert pkt.model is None
        assert pkt.stack_mode is None
        assert pkt.ac_freq_hz is None

    def test_voltage_multiplier(self):
        """MS4024PAE (model ID 0x6B) should be 24V = 2x multiplier."""
        assert InverterModel.MS4024PAE.voltage_multiplier == 2
        assert InverterModel.MS2812.voltage_multiplier == 1
        assert InverterModel.MS4448PAE.voltage_multiplier == 4


class TestRemoteBaseValidation:
    """Test Pydantic field validators on RemoteBase (Fixes R1, S3, S5)."""

    def test_search_watts_out_of_range(self):
        """search_watts > 50 should be rejected by Pydantic."""
        from pydantic import ValidationError
        with pytest.raises(ValidationError):
            RemoteBase(search_watts=100)

    def test_shore_amps_signed_range(self):
        """shore_amps is a signed byte: -128 to 127."""
        from pydantic import ValidationError
        base = RemoteBase(shore_amps=-10)
        assert base.shore_amps == -10
        with pytest.raises(ValidationError):
            RemoteBase(shore_amps=200)

    def test_battery_size_max(self):
        """battery_size_ah max is 2550 (raw byte 255 * 10)."""
        from pydantic import ValidationError
        base = RemoteBase(battery_size_ah=2550)
        assert base.battery_size_ah == 2550
        with pytest.raises(ValidationError):
            RemoteBase(battery_size_ah=3000)

    def test_charger_amps_pct_range(self):
        from pydantic import ValidationError
        with pytest.raises(ValidationError):
            RemoteBase(charger_amps_pct=150)

    def test_eq_toggle_implies_charger_toggle(self):
        """Setting eq_toggle should auto-set charger_toggle (S5)."""
        base = RemoteBase(eq_toggle=True, charger_toggle=False)
        assert base.charger_toggle is True  # Auto-set by model_validator

    def test_lbco_voltage_multiplier_round_trip(self):
        """LBCO should be scaled by voltage multiplier like float_v (S3).

        On a 24V system: wire value 100 → lbco_v=20.0V (100 * 2 / 10).
        Re-serialize: 20.0 * 10 / 2 = 100. Round trip works.
        """
        data = bytearray(SAMPLE_PACKETS["remote_00"])
        data[9] = 100  # Raw LBCO byte
        pkt = RemotePacket.from_bytes(bytes(data), voltage_multiplier=2)
        assert pkt.base.lbco_v == pytest.approx(20.0, abs=0.1)

        # Round-trip: serialize and re-parse
        reserialized = pkt.to_bytes(voltage_multiplier=2)
        pkt2 = RemotePacket.from_bytes(reserialized, voltage_multiplier=2)
        assert pkt2.base.lbco_v == pytest.approx(20.0, abs=0.1)


class TestRemotePacket:
    """Test remote packet parsing for all footer types."""

    def test_parse_a0_footer(self, remote_a0_bytes: bytes):
        """Parse REMOTE_A0 (AGS legacy footer)."""
        pkt = RemotePacket.from_bytes(remote_a0_bytes)

        assert pkt.footer_type == RemoteFooterType.AGS_LEGACY
        assert pkt.base.search_watts == 0
        assert pkt.base.battery_size_ah == 400
        assert pkt.base.charger_amps_pct == 100
        assert pkt.base.shore_amps == 10
        assert pkt.ags_legacy is not None
        assert pkt.ags_legacy.gen_run_time_hr == pytest.approx(2.0, abs=0.1)

    def test_parse_a1_footer(self):
        data = SAMPLE_PACKETS["remote_a1"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.AGS_EXT_A
        assert pkt.ags_ext_a is not None

    def test_parse_a2_footer(self):
        data = SAMPLE_PACKETS["remote_a2"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.AGS_EXT_B
        assert pkt.ags_ext_b is not None
        assert pkt.ags_ext_b.soc_stop_pct == 85

    def test_parse_a3_footer(self):
        data = SAMPLE_PACKETS["remote_a3"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.AGS_EXT_C
        assert pkt.ags_ext_c is not None

    def test_parse_a4_footer(self):
        data = SAMPLE_PACKETS["remote_a4"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.AGS_EXT_D
        assert pkt.ags_ext_d is not None
        assert pkt.ags_ext_d.warmup_s == 30
        assert pkt.ags_ext_d.cooldown_s == 30

    def test_parse_bmk_footer(self):
        data = SAMPLE_PACKETS["remote_80"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.BMK
        assert pkt.bmk is not None
        assert pkt.bmk.bmk_battery_size_ah == 400

    def test_parse_base_no_footer(self):
        data = SAMPLE_PACKETS["remote_00"]
        pkt = RemotePacket.from_bytes(data)
        assert pkt.footer_type == RemoteFooterType.BASE

    def test_round_trip_a0(self, remote_a0_bytes: bytes):
        pkt = RemotePacket.from_bytes(remote_a0_bytes)
        reserialized = pkt.to_bytes()
        pkt2 = RemotePacket.from_bytes(reserialized)
        assert pkt2.footer_type == pkt.footer_type
        assert pkt2.base.shore_amps == pkt.base.shore_amps

    def test_short_packet_raises(self):
        assert pytest.raises(ValueError, RemotePacket.from_bytes, b"\x00\x00")

    def test_force_flags(self):
        """Test force flags in byte 7."""
        data = bytearray(SAMPLE_PACKETS["remote_00"])
        data[7] = 0xF0  # All force flags set
        pkt = RemotePacket.from_bytes(bytes(data))
        assert pkt.base.force_disable_refloat is True
        assert pkt.base.force_silent is True
        assert pkt.base.force_float is True
        assert pkt.base.force_bulk is True


class TestBMKPacket:
    """Test BMK battery monitor packet."""

    def test_parse(self, bmk_bytes: bytes):
        """Parse sample BMK packet.

        Raw: 814C09F1007407E00C08FF984FF000140A01
        Expected: SOC=76%, 25.29V, 0.0A, etc.
        """
        pkt = BMKPacket.from_bytes(bmk_bytes)

        # Raw: 814C 09F1 0074 07E0 0C08 FF98 4FF0 0014 0A 01
        # SOC=0x4C=76, VDC=0x09F1=2545→25.45V, ADC=0x0074=116→11.6A
        # MinV=0x07E0=2016→20.16V, MaxV=0x0C08=3080→30.80V
        assert pkt.soc_pct == 76
        assert pkt.dc_volts == pytest.approx(25.45, abs=0.01)
        assert pkt.dc_amps == pytest.approx(11.6, abs=0.1)
        assert pkt.min_volts == pytest.approx(20.16, abs=0.01)
        assert pkt.max_volts == pytest.approx(30.80, abs=0.01)
        assert pkt.fault == BMKFault.NORMAL

    def test_negative_current(self):
        """Test signed current parsing (discharge)."""
        data = bytearray(SAMPLE_PACKETS["bmk_81"])
        # Set current to -5.0A (0xFFCE = -50 as signed 16-bit)
        data[4] = 0xFF
        data[5] = 0xCE
        pkt = BMKPacket.from_bytes(bytes(data))
        assert pkt.dc_amps == pytest.approx(-5.0, abs=0.1)

    def test_round_trip(self, bmk_bytes: bytes):
        pkt = BMKPacket.from_bytes(bmk_bytes)
        reserialized = pkt.to_bytes()
        pkt2 = BMKPacket.from_bytes(reserialized)
        assert pkt2.soc_pct == pkt.soc_pct
        assert pkt2.dc_volts == pytest.approx(pkt.dc_volts, abs=0.01)

    def test_wrong_header_raises(self):
        data = b"\xA1" + b"\x00" * 17
        assert pytest.raises(ValueError, BMKPacket.from_bytes, data)


class TestAGSPackets:
    """Test AGS status and counts packets."""

    def test_parse_status(self, ags_a1_bytes: bytes):
        """Parse AGS status packet.

        Raw: A102343A007F
        Expected: READY status, revision 5.2, temp 58°F
        """
        pkt = AGSStatusPacket.from_bytes(ags_a1_bytes)
        assert pkt.status == AGSStatus.READY
        assert pkt.revision == pytest.approx(5.2, abs=0.1)
        assert pkt.temp_f == 58
        assert pkt.runtime_hr == pytest.approx(0.0, abs=0.1)
        assert pkt.vdc == pytest.approx(12.7, abs=0.1)

    def test_ags_temp_celsius(self, ags_a1_bytes: bytes):
        pkt = AGSStatusPacket.from_bytes(ags_a1_bytes)
        assert pkt.temp_c == pytest.approx(14.4, abs=0.5)

    def test_parse_counts(self):
        data = SAMPLE_PACKETS["ags_a2"]
        pkt = AGSCountsPacket.from_bytes(data)
        assert pkt.days_since_last_run == 0
        assert pkt.days_since_full_soc == 0

    def test_status_is_running(self):
        assert AGSStatus.MANUAL_RUN.is_running is True
        assert AGSStatus.READY.is_running is False

    def test_status_is_fault(self):
        assert AGSStatus.FAULT_MAX_RUN.is_fault is True
        assert AGSStatus.READY.is_fault is False


class TestRTRPacket:

    def test_parse(self, rtr_bytes: bytes):
        """Parse RTR packet. Raw: 9120. Expected: revision 3.2"""
        pkt = RTRPacket.from_bytes(rtr_bytes)
        assert pkt.revision == pytest.approx(3.2, abs=0.1)

    def test_round_trip(self, rtr_bytes: bytes):
        pkt = RTRPacket.from_bytes(rtr_bytes)
        assert pkt.to_bytes() == rtr_bytes
