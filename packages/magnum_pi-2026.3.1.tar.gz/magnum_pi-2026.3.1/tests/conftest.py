"""Shared fixtures for magnum-pi tests."""

import pytest

# Sample packets from pymagnum testdata (hex strings)
SAMPLE_PACKETS = {
    "inverter_21": bytes.fromhex("400000F60016770001003D1133246B010005025800"),
    "remote_a0": bytes.fromhex("00002808640A280000C89B840C14122014007300A0"),
    "remote_a1": bytes.fromhex("00002808640A280000C89B840C14600090787878A1"),
    "remote_a2": bytes.fromhex("00003C04500F170601C8A5860100465500781478A2"),
    "remote_a3": bytes.fromhex("00003C04500F170601C8A58601005E5F00240200A3"),
    "remote_a4": bytes.fromhex("00003C04500F170601C8A58601001E1E00000000A4"),
    "remote_80": bytes.fromhex("00002808640A280000C89B840C1412200000280080"),
    "remote_00": bytes.fromhex("00002808640A280000C89B840C1412200000000000"),
    "bmk_81": bytes.fromhex("814C09F1007407E00C08FF984FF000140A01"),
    "ags_a1": bytes.fromhex("A102343A007F"),
    "ags_a2": bytes.fromhex("A20000000000"),
    "rtr_91": bytes.fromhex("9120"),
}


@pytest.fixture
def inverter_bytes():
    return SAMPLE_PACKETS["inverter_21"]


@pytest.fixture
def remote_a0_bytes():
    return SAMPLE_PACKETS["remote_a0"]


@pytest.fixture
def bmk_bytes():
    return SAMPLE_PACKETS["bmk_81"]


@pytest.fixture
def ags_a1_bytes():
    return SAMPLE_PACKETS["ags_a1"]


@pytest.fixture
def rtr_bytes():
    return SAMPLE_PACKETS["rtr_91"]
