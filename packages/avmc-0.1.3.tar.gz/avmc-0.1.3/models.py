from dataclasses import dataclass, field


@dataclass
class MovieMetadata:
    title: str
    number: str
    studio: str = ""
    year: str = ""
    outline: str = ""
    runtime: str = ""
    director: str = ""
    actor: list[str] = field(default_factory=list)
    release: str = ""
    cover: str = ""
    tag: list[str] = field(default_factory=list)
    website: str = ""
    source: str = ""

    def is_valid(self) -> bool:
        return bool(self.title and self.number)
