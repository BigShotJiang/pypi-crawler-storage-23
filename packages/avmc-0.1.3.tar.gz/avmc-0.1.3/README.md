# AVMC

A standalone AV metadata capture tool (current source: `javbus`) with a clean pipeline.

## Features
- Accepts a single video file or a directory path.
- If a directory is provided, recursively scans video files and processes them one by one.
- Detects subtitle-style filenames and appends `-C` to output names.
- Organizes output as `success_output_folder/Actor1,Actor2,Actor3/Number` (or `success_output_folder/Number` when no actor).
- Optional subtitle badge on poster image.
- Uses local `config.json` by default; no dependency on parent project config.

## Project Structure
- `main.py`: CLI entry
- `pipeline.py`: scan + process pipeline
- `sources/javbus.py`: metadata scraper
- `io_ops.py`: image download/crop/badge, NFO writing, file move
- `config.json`: runtime config

## Installation
```bash
cd avmc
pip install -r requirements.txt
```

## Usage
Run as module:
```bash
python -m avmc /path/to/video_or_dir
```

Run as script:
```bash
python avmc/main.py /path/to/video_or_dir
```

Options:
- `-c, --config`: config file path (default: `avmc/config.json`)
- `-p, --proxy`: temporary proxy override (higher priority than config/env)
- `--debug`: dump raw HTML to `.adc_debug/`; keep source video in place and create a symlink in output
- `--poster-badge-only`: do not scrape metadata; only backup poster and add subtitle badge

If no path is provided, AVMC recursively scans the current directory.

## Config
Default config file: `avmc/config.json`

```json
{
  "success_output_folder": "output",
  "failed": {
    "move_enabled": false,
    "output_folder": "failed"
  },
  "proxy": {
    "proxy": "",
    "timeout": 10,
    "retry": 3
  },
  "javbus": {
    "cookie": "existmag=all"
  },
  "scan": {
    "escape_folders": ["output"]
  },
  "subtitle_badge": {
    "enabled": true,
    "backup_enabled": true
  },
  "image": {
    "jpeg_quality": 85,
    "optimize": true,
    "progressive": true
  }
}
```

## Subtitle Detection
Subtitle flag is inferred from filename patterns (case-insensitive), including compact forms like:
- `ABC123C`
- `ABC123CH`
- `ABC123CHS`
- `ABC123CHT`

When detected:
- output number becomes `NUMBER-C`
- NFO adds `中文字幕` tag/genre
- poster badge can be applied when enabled

## Notes
- If scraping fails, source video is kept in place by default.
- Set `failed.move_enabled=true` to move failed files into `failed.output_folder`.
- Image host may return 403 depending on network/proxy/cookie status.
- In `--poster-badge-only` mode, poster backup is always created before writing badge.

## Development
- See `AGENTS.md` for coding-agent execution rules in this folder.
