from abc import ABC, abstractmethod

from ..context import AppContext
from ..models import MovieMetadata


class Scraper(ABC):
    name: str

    @abstractmethod
    def fetch(self, number: str, ctx: AppContext) -> MovieMetadata | None:
        raise NotImplementedError
