from .base import Scraper
from .javbus import JavbusScraper


def build_scrapers() -> list[Scraper]:
    # Keep extensibility: append new scraper implementations here.
    return [JavbusScraper()]
