"""Clean implementation for AV Data Capture."""

from .main import run

__all__ = ["run"]
