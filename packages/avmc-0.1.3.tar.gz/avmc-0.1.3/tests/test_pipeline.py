import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from avmc.pipeline import CapturePipeline


class TestPipeline(unittest.TestCase):
    def test_subtitle_detection(self):
        self.assertTrue(CapturePipeline._has_subtitle(Path("ABC123C.mp4")))
        self.assertTrue(CapturePipeline._has_subtitle(Path("ABC-123-CHS.mkv")))
        self.assertFalse(CapturePipeline._has_subtitle(Path("ABC-123.mp4")))

    def test_failed_file_stays_when_move_disabled(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            video = base / "ABC-123.mp4"
            video.write_bytes(b"video")

            class _Cfg:
                @staticmethod
                def failed_move_enabled():
                    return False

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            pipeline._fetch = lambda number: None

            ok, out_dir, fail_path = pipeline._handle_one(video)

            self.assertFalse(ok)
            self.assertIsNone(out_dir)
            self.assertEqual(fail_path, video)
            self.assertTrue(video.exists())
            self.assertFalse((base / "failed").exists())

    def test_failed_file_moves_when_enabled(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            video = base / "ABC-123.mp4"
            video.write_bytes(b"video")

            class _Cfg:
                @staticmethod
                def failed_move_enabled():
                    return True

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            pipeline._fetch = lambda number: None

            ok, out_dir, fail_path = pipeline._handle_one(video)

            self.assertFalse(ok)
            self.assertIsNone(out_dir)
            self.assertEqual(fail_path, base / "failed" / "ABC-123.mp4")
            self.assertFalse(video.exists())
            self.assertTrue((base / "failed" / "ABC-123.mp4").exists())

    def test_collect_videos_ignores_parent_escape_folder_name(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            target = base / "output" / "work"
            target.mkdir(parents=True)
            keep = target / "ABC-123.mp4"
            keep.write_bytes(b"video")
            skipped = target / "output" / "DEF-123.mp4"
            skipped.parent.mkdir(parents=True)
            skipped.write_bytes(b"video")

            class _Cfg:
                @staticmethod
                def escape_folders():
                    return ["output"]

                @staticmethod
                def failed_move_enabled():
                    return False

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            videos = pipeline._collect_videos(target)

            self.assertEqual(videos, [keep])

    def test_collect_videos_keeps_deep_escape_folder_name(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            target = base / "work"
            target.mkdir(parents=True)
            deep = target / "a" / "output" / "DEF-123.mp4"
            deep.parent.mkdir(parents=True)
            deep.write_bytes(b"video")

            class _Cfg:
                @staticmethod
                def escape_folders():
                    return ["output"]

                @staticmethod
                def failed_move_enabled():
                    return False

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            videos = pipeline._collect_videos(target)

            self.assertEqual(videos, [deep])

    def test_collect_posters_filters_top_level_escape_folder(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            target = base / "work"
            target.mkdir(parents=True)
            keep = target / "ABC-123-poster.jpg"
            keep.write_bytes(b"img")
            skipped = target / "output" / "DEF-123-poster.jpg"
            skipped.parent.mkdir(parents=True)
            skipped.write_bytes(b"img")

            class _Cfg:
                @staticmethod
                def escape_folders():
                    return ["output"]

                @staticmethod
                def failed_move_enabled():
                    return False

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            posters = pipeline._collect_posters(target)

            self.assertEqual(posters, [keep])

    def test_run_poster_badge_only_applies_badge_without_fetch(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            poster = base / "ABC-123-poster.jpg"
            poster.write_bytes(b"img")

            class _Cfg:
                @staticmethod
                def escape_folders():
                    return []

                @staticmethod
                def failed_move_enabled():
                    return False

                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()
                debug = False

            pipeline = CapturePipeline(_Ctx())
            with patch("avmc.pipeline.apply_subtitle_badge") as mocked_badge:
                code = pipeline.run_poster_badge_only(base)

            self.assertEqual(code, 0)
            mocked_badge.assert_called_once_with(pipeline.ctx, poster, backup_enabled=True)


if __name__ == "__main__":
    unittest.main()
