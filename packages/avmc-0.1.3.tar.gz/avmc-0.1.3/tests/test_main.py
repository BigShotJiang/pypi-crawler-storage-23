import types
import unittest
from pathlib import Path
from unittest.mock import patch

from avmc.main import run


class TestMain(unittest.TestCase):
    def test_run_uses_cwd_when_file_arg_missing(self):
        args = types.SimpleNamespace(file="", config=None, proxy=None, debug=False, poster_badge_only=False)
        expected = Path.cwd()

        with patch("avmc.main.parse_args", return_value=args):
            with patch("avmc.context.build_context", return_value=object()) as mocked_ctx:
                with patch("avmc.pipeline.CapturePipeline") as mocked_pipeline:
                    mocked_pipeline.return_value.run.return_value = 0
                    code = run()

        self.assertEqual(code, 0)
        mocked_ctx.assert_called_once_with(None, proxy_override=None, debug=False)
        mocked_pipeline.return_value.run.assert_called_once_with(expected)

    def test_run_uses_poster_badge_mode(self):
        args = types.SimpleNamespace(file="", config=None, proxy=None, debug=False, poster_badge_only=True)
        expected = Path.cwd()

        with patch("avmc.main.parse_args", return_value=args):
            with patch("avmc.context.build_context", return_value=object()) as mocked_ctx:
                with patch("avmc.pipeline.CapturePipeline") as mocked_pipeline:
                    mocked_pipeline.return_value.run_poster_badge_only.return_value = 0
                    code = run()

        self.assertEqual(code, 0)
        mocked_ctx.assert_called_once_with(None, proxy_override=None, debug=False)
        mocked_pipeline.return_value.run_poster_badge_only.assert_called_once_with(expected)


if __name__ == "__main__":
    unittest.main()
