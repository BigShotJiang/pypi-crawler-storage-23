import tempfile
import unittest
from pathlib import Path

from avmc.io_ops import build_output_dir, link_video_reference, move_failed_video


class TestIoOps(unittest.TestCase):
    def test_build_output_dir_uses_actor_and_number(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            class _Cfg:
                @staticmethod
                def success_folder():
                    return str(base / "output")

            class _Ctx:
                config = _Cfg()

            out = build_output_dir(_Ctx(), ["Alice"], "MXGS-1417-C")
            self.assertEqual(out, base / "output" / "Alice" / "MXGS-1417-C")
            self.assertTrue(out.exists())

    def test_build_output_dir_without_actor_folder_when_empty(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            class _Cfg:
                @staticmethod
                def success_folder():
                    return str(base / "output")

            class _Ctx:
                config = _Cfg()

            out = build_output_dir(_Ctx(), [], "MXGS-1417")
            self.assertEqual(out, base / "output" / "MXGS-1417")
            self.assertTrue(out.exists())

    def test_build_output_dir_uses_first_three_actors(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            class _Cfg:
                @staticmethod
                def success_folder():
                    return str(base / "output")

            class _Ctx:
                config = _Cfg()

            out = build_output_dir(_Ctx(), ["A1", "A2", "A3", "A4"], "MXGS-1417")
            self.assertEqual(out, base / "output" / "A1,A2,A3" / "MXGS-1417")
            self.assertTrue(out.exists())

    def test_link_video_reference_creates_symlink(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            src = base / "SRC-001.mp4"
            out_dir = base / "output"
            out_dir.mkdir()
            src.write_bytes(b"video")

            link = link_video_reference(src, out_dir, "SRC-001")

            self.assertTrue(link.exists())
            self.assertTrue(link.is_symlink())
            self.assertEqual(link.resolve(), src.resolve())
            self.assertTrue(src.exists())

    def test_move_failed_video_moves_to_failed_dir(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            src = base / "SRC-001.mp4"
            src.write_bytes(b"video")

            class _Cfg:
                @staticmethod
                def failed_folder():
                    return str(base / "failed")

            class _Ctx:
                config = _Cfg()

            moved = move_failed_video(_Ctx(), src)

            self.assertEqual(moved, base / "failed" / "SRC-001.mp4")
            self.assertTrue(moved.exists())
            self.assertFalse(src.exists())

    def test_move_failed_video_avoids_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            src = base / "SRC-001.mp4"
            src.write_bytes(b"video")
            failed_dir = base / "failed"
            failed_dir.mkdir()
            (failed_dir / "SRC-001.mp4").write_bytes(b"old")

            class _Cfg:
                @staticmethod
                def failed_folder():
                    return str(failed_dir)

            class _Ctx:
                config = _Cfg()

            moved = move_failed_video(_Ctx(), src)

            self.assertEqual(moved, failed_dir / "SRC-001_1.mp4")
            self.assertTrue(moved.exists())
            self.assertFalse(src.exists())


if __name__ == "__main__":
    unittest.main()
