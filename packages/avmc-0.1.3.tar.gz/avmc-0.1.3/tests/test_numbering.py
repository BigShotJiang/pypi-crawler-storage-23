import unittest

from avmc.numbering import extract_number


class TestNumbering(unittest.TestCase):
    def test_compact_with_subtitle_suffix(self):
        self.assertEqual(extract_number("ABC123C.mp4"), "abc-123")
        self.assertEqual(extract_number("ABC123CHS.mkv"), "abc-123")

    def test_hyphenated(self):
        self.assertEqual(extract_number("SSIS-001.mp4"), "ssis-001")
        self.assertEqual(extract_number("SSIS-001-C.mp4"), "ssis-001")
        self.assertEqual(extract_number("ECR-0006.mp4"), "ecr-006")

    def test_compact_zero_padded_over_3_digits(self):
        self.assertEqual(extract_number("ECR0006.mp4"), "ecr-006")

    def test_invalid_name_raises(self):
        with self.assertRaises(ValueError):
            extract_number("my_holiday_video.mp4")


if __name__ == "__main__":
    unittest.main()
