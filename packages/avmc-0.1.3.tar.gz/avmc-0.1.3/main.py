import argparse
from pathlib import Path
import sys


if __package__ in (None, ""):
    # Support running directly: python /path/to/avmc/main.py
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def parse_args() -> argparse.Namespace:
    from avmc.settings import AppConfig

    parser = argparse.ArgumentParser(description="AV Data Capture (clean implementation)")
    parser.add_argument("file", nargs="?", default="", help="Video file or directory path")
    parser.add_argument(
        "-c",
        "--config",
        default=None,
        help=f"Config file path (default: {AppConfig.default_config_path()})",
    )
    parser.add_argument(
        "-p",
        "--proxy",
        default=None,
        help="Proxy address (example: 127.0.0.1:7890). Overrides config file when provided.",
    )
    parser.add_argument("--debug", action="store_true", help="Enable verbose debug logs and dump raw HTML.")
    parser.add_argument(
        "--poster-badge-only",
        action="store_true",
        help="Do not scrape metadata. Only backup poster and add subtitle badge.",
    )
    return parser.parse_args()


def run() -> int:
    args = parse_args()

    from avmc.context import build_context
    from avmc.pipeline import CapturePipeline

    ctx = build_context(args.config, proxy_override=args.proxy, debug=args.debug)
    pipeline = CapturePipeline(ctx)
    target = Path(args.file) if args.file else Path.cwd()
    if args.poster_badge_only:
        return pipeline.run_poster_badge_only(target)
    return pipeline.run(target)


def main() -> None:
    raise SystemExit(run())


if __name__ == "__main__":
    main()
