# zspdu

**zspdu** is a Python package and Robot Framework library for controlling Smart PDUs (Power Distribution Units) via USB serial interfaces.
It provides both a command‑line interface (CLI) and Robot Framework keywords for automation.

---

## Features

- List available serial ports
- Open and switch between ports
- Turn individual sockets ON/OFF
- Turn all sockets ON/OFF
- Read current measurements
- Close connections
- Usable as:
  - **CLI tool** (`zspdu`)
  - **Robot Framework library** (`Library    zspdu`)

---

## Installation

Clone the repository and install in editable mode:

git clone https://github.com/yourname/zspdu.git
cd zspdu
pip install -e .

This will install the package and register the `zspdu` CLI command.

---

## Command Line Usage

zspdu -l                # List all available serial ports
zspdu -o /dev/ttyUSB0   # Open specific port
zspdu -s /dev/ttyUSB1   # Switch to another port
zspdu --on 3            # Turn ON socket 3
zspdu --off 2           # Turn OFF socket 2
zspdu --on-all          # Turn ON all sockets
zspdu --off-all         # Turn OFF all sockets
zspdu -c                # Close current port
zspdu -v                # Show version

Running `zspdu` without arguments will display the help message.

---

## Robot Framework Usage

Import the library in your `.robot` test file:

*** Settings ***
Library    zspdu

*** Test Cases ***
Control PDU
    Turn Socket On    1
    ${current}=    Read Current
    Log    Current reading: ${current}
    Turn Socket Off    1
    Close PDU Connection

You can also pass arguments when importing:

*** Settings ***
Library    zspdu    port=/dev/ttyUSB1    baudrate=9600    sockets=4

---

## Device Information (from ZS12x0 USB PDU Manual)

### Variants
- **ZS1220**: 8‑port USB PDU (Part Number: ZS-PDU8-USB-P1B)
- **ZS1221**: 4‑port USB PDU (Part Number: ZS-PDU4-USB-P1B)

### Specifications
- Output Power Sockets: 4 or 8
- Power Supply: 240VAC, 15A
- Fuse Rating: 15A
- Max Current per Socket: 13A
- Total Load Capacity: 3kVA
- Relay Switching Life Expectancy: 50,000 cycles
- Current Sensing Range: up to 15A
- Control Port: USB2.0 Type‑B

### Serial Port Settings
- Baud Rate: 115200
- Data Bits: 8
- Stop Bit: 1
- Parity: None
- Flow Control: None

---

## Supported Serial Commands

- **V** → Get firmware version  
- **Ps** → Check if PDU is powered ON/OFF  
- **W<hex>** → Write multiple port states (bitmask in hex)  
- **R** → Read current port states (hex bitmask)  
- **S<n>** → Turn ON port *n* (Sa = all ports ON)  
- **C<n>** → Turn OFF port *n* (Ca = all ports OFF)  
- **PM** → Read total current consumption (mA)

> Each command must end with `\r\n`. Device responds with `OK` on success or `ER:<msg>` on failure. Commands are case‑insensitive.

---

## Development

Folder structure:

src/
└── zspdu/
    ├── __init__.py   # Robot Framework entry point
    ├── core.py       # ZSPDU class and PDUConfig
    ├── utils.py      # Helpers (get_serial_ports, get_default_port)
    └── cli.py        # CLI entry point

---

## License

MIT License  
Copyright (c) 2026 Ganesan Selvaraj

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
