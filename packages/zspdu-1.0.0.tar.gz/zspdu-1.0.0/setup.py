from setuptools import setup, find_packages

setup(
    name="zspdu",
    version="1.0.0",
    description="Control ZSPDU smart power distribution unit via serial port",
    author="Ganesan Selvaraj",
    author_email="ganesanluna@yahoo.in",
    url="https://github.com/ganesanluna/zspdu",
    license="MIT",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "pyserial",
        "pydantic",
        "robotframework"
    ],
    entry_points={
        "console_scripts": [
            "zspdu=zspdu.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)

