from .core import ZSPDU, PDUConfig
from .utils import get_default_port

class zspdu(ZSPDU):
    """Robot Framework library wrapper for ZSPDU."""

    def __init__(self, port=None, baudrate=115200, timeout=3, sockets=8):
        # Only store config, don’t open port yet
        port = port or get_default_port()
        self.config = PDUConfig(port=port, baudrate=baudrate, timeout=timeout, sockets=sockets)
        self.ser = None
        self.sockets = sockets
