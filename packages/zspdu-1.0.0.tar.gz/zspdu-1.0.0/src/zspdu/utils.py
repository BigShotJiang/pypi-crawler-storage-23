""" Custom library """
import serial.tools.list_ports

""" system library """
import platform
from typing import List

def get_serial_ports() -> List[str]:
    """
    Return a list of valid serial port device names.

    Returns:
        List[str]: A list of available serial port device paths
        (e.g., '/dev/ttyUSB0').
    """
    ports: List[str] = []
    for port in sorted(serial.tools.list_ports.comports()):
        if port.description != "n/a" and port.hwid != "n/a":
            ports.append(port.device)
    return ports

def get_default_port() -> str:
    system = platform.system().lower()
    if "linux" in system:
        return "/dev/ttyUSB0"
    elif "windows" in system:
        return "COM5"
    else:
        return "/dev/ttyUSB0"