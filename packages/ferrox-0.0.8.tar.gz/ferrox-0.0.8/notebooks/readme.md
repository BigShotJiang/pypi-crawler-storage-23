## Ferrox Workflow Scripts

These scripts are Ferrox-first ports of the highest-priority `matgenb` examples.
They intentionally replace `pymatgen` operations with `ferrox` where available.

If a direct Ferrox equivalent is not implemented yet, the script includes explicit
`TODO(ferrox)` markers that document what is still needed to reach 1-to-1 parity.

## CI HTML export pipeline

Tutorial scripts in this directory are converted and executed in CI, then exported
to HTML with embedded outputs (without tracking `.ipynb` files in git).

- Converter/export script: `scripts/build_tutorial_docs.py`
- GitHub Actions workflow: `.github/workflows/docs.yml`
- CI output directory: `docs/build/tutorials/` (ignored by git)

### Suggested reading order (zero -> hero)

- `01_getting_data_from_materials_project.py` - Fetch MP data and run first Ferrox analyses.
- `02_phase_diagram_with_materials_api.py` - Build composition/energy entry tables for phase analysis.
- `03_reaction_energies_with_materials_api.py` - Compute reaction-energy proxies from MP-derived energies.
- `04_structure_prediction_with_materials_api.py` - Prototype-level structure matching and candidate filtering.
- `05_surfaces_defects_xrd_workflow.py` - End-to-end surface/defect/XRD workflow composition.
- `06_high_throughput_defect_screening.py` - Scale defect generation and triage across many hosts.
- `07_md_ensembles_diffusion.py` - Compare MD ensembles and diffusion extraction workflows.
- `08_surface_science_end_to_end_benchmark.py` - Surface-heavy benchmarking workflow.
- `09_rust_vs_python_struct_benchmark.py` - Rust-core vs pure-Python scaling benchmark.
