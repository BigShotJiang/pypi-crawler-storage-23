"""Top-level package for fast-mcp-telegram.

Ensures 'src' is a proper package so entry point 'src.server:main' is importable
when installed via uvx/pip.
"""
