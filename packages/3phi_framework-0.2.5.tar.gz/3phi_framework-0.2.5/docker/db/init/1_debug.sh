# ./db/init/debug.sh
#!/bin/bash
echo "✅ DB INIT SCRIPT IS RUNNING"