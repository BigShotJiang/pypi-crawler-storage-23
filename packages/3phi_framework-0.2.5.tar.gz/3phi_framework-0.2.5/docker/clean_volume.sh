#!/bin/bash
rm -rf ./tmp/pgdata
mkdir ./tmp/pgdata
