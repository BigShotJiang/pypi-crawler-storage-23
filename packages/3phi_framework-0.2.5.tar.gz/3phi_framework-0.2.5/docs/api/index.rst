API Reference
=============

Controllers
-----------

Meta controller
~~~~~~~~~~~~~~~

.. automodule:: threephi_framework.controllers.meta
   :members:
   :undoc-members:
   :show-inheritance:

Topology controller
~~~~~~~~~~~~~~~~~~~

.. automodule:: threephi_framework.controllers.topology
   :members:
   :undoc-members:
   :show-inheritance:

Time Series controller
~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: threephi_framework.controllers.time_series
   :members:
   :undoc-members:
   :show-inheritance:
