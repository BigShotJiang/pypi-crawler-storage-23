dapr-ext-strands extension
=======================

|pypi|

.. |pypi| image:: https://badge.fury.io/py/dapr-ext-strands.svg
   :target: https://pypi.org/project/dapr-ext-strands/

This is the Dapr Session Manager for Strands Agents

Installation
------------

::

    pip install dapr-ext-strands

References
----------

* `Dapr <https://github.com/dapr/dapr>`_
* `Dapr Python-SDK <https://github.com/dapr/python-sdk>`_
