# Simple shim for mspms development.
import msprime.cli

if __name__ == "__main__":
    msprime.cli.mspms_main()
