# Simple shim for msp development.
import msprime.cli

if __name__ == "__main__":
    msprime.cli.msp_main()
