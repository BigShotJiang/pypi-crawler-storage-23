import os
import sys

cognit_path = os.path.dirname(os.path.abspath(__file__)) + "/../../.."
# This enables the test to be executed from the test folder
sys.path.append(cognit_path)
