"""Coflect: human-in-the-loop training framework."""

from coflect.version import __version__

__all__ = ["__version__"]
