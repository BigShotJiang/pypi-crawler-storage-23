"""Module runner for `python -m coflect.modules.hitl.forecast`."""

from coflect.modules.hitl.forecast.worker import main

if __name__ == "__main__":
    main()

