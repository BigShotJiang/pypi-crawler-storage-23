"""CPU-only forecast worker package for HITL review gating."""

