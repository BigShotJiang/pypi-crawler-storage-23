"""Module runner for `python -m coflect.modules.hitl.backend`."""

from coflect.modules.hitl.backend.app import main

if __name__ == "__main__":
    main()
