"""Backward-compatible wrapper for legacy `gradcam_tf` module name."""

from __future__ import annotations

from coflect.modules.hitl.xai_worker.livecam_tf import *  # noqa: F401,F403

