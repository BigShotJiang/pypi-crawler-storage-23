"""Backward-compatible wrapper for legacy `gradcam` module name."""

from __future__ import annotations

from coflect.modules.hitl.xai_worker.livecam import *  # noqa: F401,F403

