"""Shared HITL message and wire utilities."""
