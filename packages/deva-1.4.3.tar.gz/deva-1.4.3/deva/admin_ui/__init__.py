"""Admin modularized components."""
