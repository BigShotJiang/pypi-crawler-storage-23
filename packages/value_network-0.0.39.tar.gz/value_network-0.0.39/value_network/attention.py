import torch
from torch import nn, einsum
from einops import rearrange
from einops.layers.torch import Rearrange

def exists(v):
    return v is not None

def default(v, d):
    return v if exists(v) else d

class Attention(nn.Module):
    def __init__(
        self,
        dim,
        dim_context = None,
        heads = 8,
        dim_head = 64,
        dropout = 0.,
        norm_eps = 1e-6,
        gate_attn = False
    ):
        super().__init__()
        self.heads = heads
        self.scale = dim_head ** -0.5
        inner_dim = dim_head * heads

        self.norm = nn.LayerNorm(dim, eps = norm_eps)

        self.is_cross_attn = exists(dim_context)
        dim_context = default(dim_context, dim)
        self.norm_context = nn.LayerNorm(dim_context, eps = norm_eps) if self.is_cross_attn else None

        self.to_q = nn.Linear(dim, inner_dim)
        self.to_kv = nn.Linear(dim_context, inner_dim * 2)

        self.to_out_gates = nn.Sequential(
            nn.Linear(dim, heads),
            Rearrange('b ... h -> b h ... 1'),
            nn.Sigmoid()
        ) if gate_attn else None

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x, context = None):
        x = self.norm(x)

        if self.is_cross_attn:
            assert exists(context)
            context = self.norm_context(context)
        else:
            context = x

        q = self.to_q(x)
        k, v = self.to_kv(context).chunk(2, dim = -1)

        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), (q, k, v))

        sim = einsum('b h i d, b h j d -> b h i j', q, k) * self.scale
        attn = sim.softmax(dim = -1)

        out = einsum('b h i j, b h j d -> b h i d', attn, v)

        if exists(self.to_out_gates):
            out = out * self.to_out_gates(x)

        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)

def FeedForward(
    dim,
    dim_inner,
    norm_eps = 1e-6
):
    return nn.Sequential(
        nn.LayerNorm(dim, eps = norm_eps),
        nn.Linear(dim, dim_inner),
        nn.GELU(approximate = 'tanh'),
        nn.Linear(dim_inner, dim)
    )
