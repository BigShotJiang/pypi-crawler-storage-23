import torch
from torch import nn
from einops import repeat, rearrange
from einops.layers.torch import Reduce
from value_network.attention import Attention, FeedForward

class AttentionPool(nn.Module):
    def __init__(
        self,
        dim,
        heads = 8,
        dim_head = 64,
        norm_eps = 1e-6
    ):
        super().__init__()
        self.latent = nn.Parameter(torch.randn(dim) * 1e-2)
        self.attn = Attention(dim, dim_context=dim, heads=heads, dim_head=dim_head, norm_eps=norm_eps)

    def forward(self, tokens):
        batch = tokens.shape[0]
        query = repeat(self.latent, 'd -> b 1 d', b=batch)
        out = self.attn(query, context=tokens)
        return rearrange(out, 'b 1 d -> b d')

class PerceiverPool(nn.Module):
    def __init__(
        self,
        dim,
        depth = 2,
        num_queries = 32,
        heads = 8,
        dim_head = 64,
        mlp_dim = None,
        norm_eps = 1e-6
    ):
        super().__init__()
        mlp_dim = mlp_dim if mlp_dim is not None else dim * 4
        
        self.queries = nn.Parameter(torch.randn(num_queries, dim) * 1e-2)
        
        # initial cross attention from queries to input tokens
        self.cross_attn = Attention(dim, dim_context = dim, heads = heads, dim_head = dim_head, norm_eps = norm_eps)
        
        # self attention encoder blocks
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads = heads, dim_head = dim_head, norm_eps = norm_eps),
                FeedForward(dim = dim, dim_inner = mlp_dim, norm_eps = norm_eps)
            ]))
            
        self.norm = nn.LayerNorm(dim, eps = norm_eps)
        self.reduce = Reduce('b n d -> b d', 'mean')

    def forward(self, tokens):
        batch = tokens.shape[0]
        queries = repeat(self.queries, 'n d -> b n d', b = batch)
        
        # cross attend to tokens
        queries = self.cross_attn(queries, context = tokens) + queries
        
        # self attend encoder
        for attn, ff in self.layers:
            queries = attn(queries) + queries
            queries = ff(queries) + queries
            
        queries = self.norm(queries)
        
        # mean pool across queries
        return self.reduce(queries)
