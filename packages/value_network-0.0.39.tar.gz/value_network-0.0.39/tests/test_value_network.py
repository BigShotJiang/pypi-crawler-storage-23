import torch
import pytest
from value_network.value_network import (
    SigLIPValueNetwork,
    MSELossModule,
    HLGaussLossModule,
    CategoricalLossModule
)

param = pytest.mark.parametrize

def test_value_network_output_shape():
    batch = 2
    image_size = 224
    
    net = SigLIPValueNetwork(
        siglip_depth = 2,
        siglip_dim = 128,
        siglip_heads = 4,
        siglip_mlp_dim = 256
    )

    # Input shape: (batch, channels, height, width)
    images = torch.randn(batch, 3, image_size, image_size)
    
    output = net(images)
    
    assert output.shape == (batch,)
    print(f"Output shape: {output.shape}")

@param('multiple_targets', (False, True))
def test_value_network_mse_loss(multiple_targets):
    batch = 4
    image_size = 224
    
    net = SigLIPValueNetwork(
        siglip_depth = 1,
        siglip_dim = 64,
        siglip_heads = 2,
        siglip_mlp_dim = 128
    )
    
    images = torch.randn(batch, 3, image_size, image_size)
    
    if multiple_targets:
        targets = (torch.randn(batch), torch.randn(batch))
    else:
        targets = torch.randn(batch)

    output = net(images, targets = targets)

    if multiple_targets:
        loss = sum(output)
    else:
        loss = output

    loss.backward()

@param('strategy', ('mean', 'concat', 'attn_pool', 'perceiver_pool'))
def test_multiview_combine_strategies(strategy):
    batch = 2
    num_views = 3
    image_size = 224 # must be divisible by patch size (14)
    
    net = SigLIPValueNetwork(
        siglip_depth = 1,
        siglip_dim = 64,
        siglip_heads = 2,
        siglip_mlp_dim = 128,
        multiview_combine_strategy = strategy,
        num_views = num_views if strategy == 'concat' else None
    )
    
    # Input shape: (batch, views, channels, height, width)
    images = torch.randn(batch, num_views, 3, image_size, image_size)
    
    output = net(images)
    
    assert output.shape == (batch,)
    
    # Verify backward pass
    output.mean().backward()

def test_losses_consistency():
    dim = 64
    
    # Define modules to test
    modules = [
        MSELossModule(dim),
        HLGaussLossModule(dim, num_bins = 101, min_value = 0., max_value = 1.),
        CategoricalLossModule(dim, num_bins = 101, min_value = 0., max_value = 1., temperature = 0.001)
    ]
    
    # Test values
    targets = torch.linspace(0.1, 0.9, 9)
    
    for mod in modules:
        # Encode
        prob = mod.value_to_prob(targets)
        
        # Decode
        decoded = mod.decode(prob)
        
        # MSE is identity, others have small interpolation error
        if isinstance(mod, MSELossModule):
            assert torch.allclose(targets, decoded)
        else:
            assert torch.allclose(targets, decoded, atol = 1e-2)

def test_categorical_two_hot_consistency():
    dim = 64
    
    # 11 bins: 0.0, 0.1, ..., 1.0
    mod = CategoricalLossModule(dim, num_bins = 11, min_value = 0., max_value = 1., encoding = 'two_hot')
    
    # Values exactly on bins
    targets = torch.tensor([0.0, 0.5, 1.0])
    prob = mod.value_to_prob(targets)
    decoded = mod.decode(prob)
    assert torch.allclose(targets, decoded)
    
    # Values between bins (should result in exact expectation)
    targets = torch.tensor([0.05, 0.42, 0.99])
    prob = mod.value_to_prob(targets)
    decoded = mod.decode(prob)
    assert torch.allclose(targets, decoded)

def test_categorical_symexp_consistency():
    dim = 64
    
    # Large range for symexp test
    mod = CategoricalLossModule(dim, num_bins = 1001, min_value = -10., max_value = 10., use_symexp = True)
    
    targets = torch.tensor([-5.0, 0.0, 5.0])
    prob = mod.value_to_prob(targets)
    decoded = mod.decode(prob)
    
    # Error should be within bin resolution after sym_log/sym_exp
    assert torch.allclose(targets, decoded, atol = 1e-1)
