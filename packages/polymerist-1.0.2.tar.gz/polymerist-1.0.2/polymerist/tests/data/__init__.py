'''Reference data used to load or verify unit tests'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
