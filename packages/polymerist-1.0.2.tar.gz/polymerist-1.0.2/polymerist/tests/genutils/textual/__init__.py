'''Unit tests for `textual` package'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
