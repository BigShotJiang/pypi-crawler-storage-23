'''Unit tests for `pdb` package'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
