'''Unit tests for `maths` package'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
