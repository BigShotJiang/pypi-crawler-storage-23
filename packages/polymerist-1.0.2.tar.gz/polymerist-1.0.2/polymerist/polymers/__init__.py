'''Utilities for representing, building, and esimating chain proerties of polymers'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
