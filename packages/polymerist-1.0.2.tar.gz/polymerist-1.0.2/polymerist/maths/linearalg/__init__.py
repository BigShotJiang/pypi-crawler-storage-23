'''Custom linear algebra utilities not already supplied by a numeric processing library like numpy or scipy'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
