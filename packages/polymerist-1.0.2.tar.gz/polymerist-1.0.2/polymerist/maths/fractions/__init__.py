'''Tools for representing and calculating with fractions and other ratio-like objects'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
