'''Additional type-hinting and typechecking not provided by Python builtins'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
