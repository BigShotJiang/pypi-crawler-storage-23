'''Methods for evaluating the similarity of and inspecting the edits between sequences'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
