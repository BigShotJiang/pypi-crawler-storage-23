'''General-purpose utilities constructed only with Python builtins + numpy'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
