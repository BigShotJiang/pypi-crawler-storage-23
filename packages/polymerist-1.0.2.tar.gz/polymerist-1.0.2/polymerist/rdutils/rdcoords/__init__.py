'''RDKit Mol coordinate generation and coordinate transforms'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
