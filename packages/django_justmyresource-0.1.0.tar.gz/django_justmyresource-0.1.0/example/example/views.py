"""Views for example application."""

from __future__ import annotations

from django.http import HttpRequest
from django.http import HttpResponse
from django.shortcuts import render

from django_justmyresource.registry import get_registry


def home(request: HttpRequest) -> HttpResponse:
    """Display pack selector and icon grid.

    Shows a dropdown of all installed resource packs. When a pack is selected,
    displays all icons from that pack in a grid layout.
    """
    registry = get_registry()
    registry.discover()

    # Get all available packs
    packs = sorted(registry.list_packs())

    # Get selected pack from query parameter
    selected_pack = request.GET.get("pack", "")

    # If no pack selected and packs exist, default to first pack
    if not selected_pack and packs:
        selected_pack = packs[0]

    # Get resources for selected pack
    resources = []
    if selected_pack:
        try:
            resource_list = sorted(
                registry.list_resources(pack=selected_pack),
                key=lambda r: r.name,
            )
            # Format resource names for use in templates
            # Use qualified name format (dist/pack:resource) which is guaranteed to work
            resources = [
                {
                    "name": f"{selected_pack}:{r.name}",
                    "display_name": r.name,
                }
                for r in resource_list
            ]
        except Exception:
            # If pack doesn't exist or has issues, resources will be empty
            pass

    context = {
        "packs": packs,
        "selected_pack": selected_pack,
        "resources": resources,
    }

    return render(request, "home.html", context)

