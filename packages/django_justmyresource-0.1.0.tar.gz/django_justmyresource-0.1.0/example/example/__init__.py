"""Example Django application for django-justmyresource."""

