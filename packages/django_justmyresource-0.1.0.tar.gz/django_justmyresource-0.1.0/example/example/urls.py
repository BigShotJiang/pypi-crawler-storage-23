"""URL configuration for example project."""

from django.urls import path

from example.views import home

urlpatterns = [
    path("", home, name="home"),
]

