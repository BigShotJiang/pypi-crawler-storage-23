"""Django app configuration for JustMyResource."""

from __future__ import annotations

from django.apps import AppConfig


class JustMyResourceConfig(AppConfig):
    """App configuration for JustMyResource."""

    name = "django_justmyresource"
    verbose_name = "JustMyResource"

