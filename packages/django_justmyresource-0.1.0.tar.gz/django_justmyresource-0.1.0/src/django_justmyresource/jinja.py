"""Jinja2 integration for JustMyResource."""

from __future__ import annotations

from markupsafe import Markup

from django_justmyresource.renderer import render_svg


def icon(name: str, *, size: int | None = 24, **kwargs: object) -> Markup:
    """Render an SVG icon from a JustMyResource pack.

    Args:
        name: Resource name (e.g., "lucide:home" or "justmyresource-lucide/lucide:home").
        size: Optional size for width and height attributes. Defaults to 24.
        **kwargs: Additional HTML attributes to add to the SVG or path elements.

    Returns:
        Markup object containing the inline SVG.

    Example:
        from django_justmyresource.jinja import icon
        from jinja2 import Environment

        env = Environment()
        env.globals.update({"icon": icon})

        # In template:
        {{ icon("lucide:a-arrow-down", size=40, class="mr-4") }}
    """
    return Markup(render_svg(name, size=size, **kwargs))

