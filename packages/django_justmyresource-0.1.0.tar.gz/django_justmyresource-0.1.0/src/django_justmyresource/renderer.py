"""SVG rendering with attribute manipulation for JustMyResource."""

from __future__ import annotations

import functools
from copy import deepcopy
from xml.etree import ElementTree

from django_justmyresource.registry import get_registry

# Path-level attributes that should be applied to <path> elements, not <svg>
_PATH_ATTR_NAMES = frozenset(
    {
        "stroke-linecap",
        "stroke-linejoin",
        "vector-effect",
    }
)


class ResourceNotFoundError(Exception):
    """Raised when a resource cannot be found."""

    pass


class InvalidResourceTypeError(Exception):
    """Raised when a resource is not an SVG."""

    pass


@functools.lru_cache(maxsize=128)
def _load_svg(name: str) -> ElementTree.Element:
    """Load and parse SVG resource, caching the parsed ElementTree.

    Args:
        name: Resource name (e.g., "lucide:home" or "justmyresource-lucide/lucide:home").

    Returns:
        Parsed SVG ElementTree.Element.

    Raises:
        ResourceNotFoundError: If the resource cannot be found.
        InvalidResourceTypeError: If the resource is not an SVG.
    """
    registry = get_registry()
    try:
        resource = registry.get_resource(name)
    except ValueError as e:
        raise ResourceNotFoundError(f"Resource '{name}' not found: {e}") from e

    # Be lenient about content_type - some packs may not set it correctly
    # We'll try to parse as SVG and only fail if parsing fails
    # Check content_type as a hint, but don't fail on it alone
    if resource.content_type not in ("image/svg+xml", "application/octet-stream", "text/xml"):
        # If content_type is explicitly something else (like image/png), reject it
        raise InvalidResourceTypeError(
            f"Resource '{name}' is not an SVG (content_type: {resource.content_type}). "
            "Only SVG resources are supported for inline rendering."
        )

    # Decode SVG content
    # SVG files are always UTF-8, so decode manually if encoding is not set
    if resource.encoding is not None:
        try:
            svg_text = resource.text
        except ValueError as e:
            raise InvalidResourceTypeError(
                f"Resource '{name}' cannot be decoded as text: {e}. "
                "Only SVG resources are supported for inline rendering."
            ) from e
    else:
        # Encoding not set - assume UTF-8 for SVG files
        try:
            svg_text = resource.data.decode("utf-8")
        except UnicodeDecodeError as e:
            raise InvalidResourceTypeError(
                f"Resource '{name}' cannot be decoded as UTF-8: {e}. "
                "Only SVG resources are supported for inline rendering."
            ) from e

    # Parse SVG XML - this is the real test
    try:
        svg = ElementTree.fromstring(svg_text)
    except ElementTree.ParseError as e:
        raise InvalidResourceTypeError(
            f"Resource '{name}' contains invalid SVG XML: {e}. "
            "Only SVG resources are supported for inline rendering."
        ) from e

    # Remove namespace prefixes from tags (same as django-lucide)
    for node in svg.iter():
        node.tag = ElementTree.QName(
            str(node.tag).removeprefix("{http://www.w3.org/2000/svg}")
        )  # type: ignore[assignment]

    return svg


def render_svg(name: str, size: int | None = None, **kwargs: object) -> str:
    """Render an SVG resource with attribute manipulation.

    Args:
        name: Resource name (e.g., "lucide:home" or "justmyresource-lucide/lucide:home").
        size: Optional size for width and height attributes. If None, original size is preserved.
        **kwargs: Additional HTML attributes to add to the SVG or path elements.
            Underscores in attribute names are replaced with dashes.
            Path-level attributes (stroke-linecap, stroke-linejoin, vector-effect)
            are applied to <path> elements; all others are applied to <svg>.

    Returns:
        HTML string containing the inline SVG.

    Raises:
        ResourceNotFoundError: If the resource cannot be found.
        InvalidResourceTypeError: If the resource is not an SVG or contains invalid XML.
    """
    svg = deepcopy(_load_svg(name))

    # Apply size if specified
    if size is not None:
        svg.attrib["width"] = svg.attrib["height"] = str(size)

    # Separate SVG-level and path-level attributes
    svg_attrs: dict[str, str] = {}
    path_attrs: dict[str, str] = {}

    for raw_name, value in kwargs.items():
        # Convert underscores to dashes (e.g., data_test -> data-test)
        # Handle trailing underscore (Python keyword workaround, e.g., class_ -> class)
        if raw_name.endswith("_"):
            attr_name = raw_name[:-1].replace("_", "-")
        else:
            attr_name = raw_name.replace("_", "-")

        if attr_name in _PATH_ATTR_NAMES:
            path_attrs[attr_name] = str(value)
        else:
            svg_attrs[attr_name] = str(value)

    # Apply SVG-level attributes
    svg.attrib.update(svg_attrs)

    # Apply path-level attributes to all <path> elements
    if path_attrs:
        for path in svg.findall("path"):
            path.attrib.update(path_attrs)

    # Convert to string
    svg_string = ElementTree.tostring(svg, encoding="unicode")

    # Remove xmlns for inline SVG (same as django-lucide)
    svg_string = svg_string.replace(' xmlns="http://www.w3.org/2000/svg"', "", 1)

    return svg_string

