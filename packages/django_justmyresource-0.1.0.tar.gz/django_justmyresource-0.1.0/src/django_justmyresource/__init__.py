"""Django integration for JustMyResource resource discovery library."""

__version__ = "0.1.0"

__all__ = ["__version__"]

