"""Django-settings-aware registry singleton for JustMyResource."""

from __future__ import annotations

from django.conf import settings

from justmyresource import ResourceRegistry

# Global registry instance
_registry: ResourceRegistry | None = None


def get_registry() -> ResourceRegistry:
    """Get the Django-configured resource registry singleton.

    The registry is configured from Django settings:
    - JUSTMYRESOURCE_DEFAULT_PREFIX: Default prefix for bare-name lookups
    - JUSTMYRESOURCE_BLOCKLIST: Set of pack names to exclude (comma-separated string or list)
    - JUSTMYRESOURCE_PREFIX_MAP: Dict mapping alias -> qualified pack name

    Returns:
        Singleton ResourceRegistry instance configured from Django settings.
    """
    global _registry
    if _registry is None:
        # Parse settings
        default_prefix = getattr(settings, "JUSTMYRESOURCE_DEFAULT_PREFIX", None)
        blocklist = _parse_blocklist_setting(getattr(settings, "JUSTMYRESOURCE_BLOCKLIST", None))
        prefix_map = _parse_prefix_map_setting(
            getattr(settings, "JUSTMYRESOURCE_PREFIX_MAP", None)
        )

        _registry = ResourceRegistry(
            default_prefix=default_prefix,
            blocklist=blocklist,
            prefix_map=prefix_map,
        )

    return _registry


def _parse_blocklist_setting(blocklist: str | list[str] | set[str] | None) -> set[str] | None:
    """Parse blocklist from Django settings.

    Args:
        blocklist: Can be a comma-separated string, list, or set.

    Returns:
        Set of blocked pack names, or None if not set.
    """
    if blocklist is None:
        return None

    if isinstance(blocklist, str):
        return {name.strip() for name in blocklist.split(",") if name.strip()}
    elif isinstance(blocklist, (list, set)):
        return set(blocklist)
    else:
        return None


def _parse_prefix_map_setting(
    prefix_map: str | dict[str, str] | None,
) -> dict[str, str] | None:
    """Parse prefix_map from Django settings.

    Args:
        prefix_map: Can be a dict, or a comma-separated string like "alias1=dist1/pack1,alias2=dist2/pack2".

    Returns:
        Dictionary mapping alias -> qualified pack name, or None if not set.
    """
    if prefix_map is None:
        return None

    if isinstance(prefix_map, dict):
        return prefix_map
    elif isinstance(prefix_map, str):
        result = {}
        for entry in prefix_map.split(","):
            entry = entry.strip()
            if "=" in entry:
                alias, qualified_name = entry.split("=", 1)
                result[alias.strip()] = qualified_name.strip()
        return result if result else None
    else:
        return None

