"""Django template tags for JustMyResource."""

from __future__ import annotations

from django import template
from django.utils.safestring import SafeString
from django.utils.safestring import mark_safe

from django_justmyresource.renderer import render_svg

register = template.Library()


@register.simple_tag
def icon(name: str, *, size: int | None = 24, **kwargs: object) -> str:
    """Render an SVG icon from a JustMyResource pack.

    Args:
        name: Resource name (e.g., "lucide:home" or "justmyresource-lucide/lucide:home").
        size: Optional size for width and height attributes. Defaults to 24.
        **kwargs: Additional HTML attributes to add to the SVG or path elements.

    Returns:
        HTML string containing the inline SVG (marked as safe).

    Example:
        {% load justmyresource %}
        {% icon "lucide:a-arrow-down" size=40 class="mr-4" %}
    """
    # simple_tag's parsing loads passed strings as safe, but they aren't
    # Cast the SafeString's back to normal strings the only way possible, by
    # concatenating the empty string (same pattern as django-lucide).
    fixed_kwargs = {
        key: (value + "" if isinstance(value, SafeString) else value)
        for key, value in kwargs.items()
    }
    return mark_safe(render_svg(name, size=size, **fixed_kwargs))

