"""Django template tags for JustMyResource."""

