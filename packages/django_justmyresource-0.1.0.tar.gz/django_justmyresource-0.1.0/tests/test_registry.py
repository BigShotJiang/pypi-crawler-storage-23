"""Tests for Django-settings-aware registry."""

from __future__ import annotations

import django
from django.conf import settings

# Configure Django only if not already configured
if not settings.configured:
    settings.configure(
        SECRET_KEY="insecure",
        INSTALLED_APPS=["django_justmyresource"],
    )
    django.setup()

from django_justmyresource.registry import get_registry


def test_registry_singleton():
    """Test that get_registry returns a singleton."""
    registry1 = get_registry()
    registry2 = get_registry()

    assert registry1 is registry2


def test_registry_default_prefix():
    """Test registry configuration with default_prefix."""
    # Reset registry to test configuration
    from django_justmyresource import registry

    registry._registry = None  # type: ignore[attr-defined]

    settings.JUSTMYRESOURCE_DEFAULT_PREFIX = "lucide"
    registry1 = get_registry()

    # Reset again
    registry._registry = None  # type: ignore[attr-defined]
    settings.JUSTMYRESOURCE_DEFAULT_PREFIX = "heroicons"
    registry2 = get_registry()

    # They should be different instances due to different config
    assert registry1 is not registry2


def test_registry_blocklist_string():
    """Test registry configuration with blocklist as string."""
    from django_justmyresource import registry

    registry._registry = None  # type: ignore[attr-defined]

    settings.JUSTMYRESOURCE_BLOCKLIST = "pack1,pack2"
    reg = get_registry()

    # Verify blocklist was parsed
    assert reg._blocklist is not None
    assert "pack1" in reg._blocklist
    assert "pack2" in reg._blocklist


def test_registry_blocklist_list():
    """Test registry configuration with blocklist as list."""
    from django_justmyresource import registry

    registry._registry = None  # type: ignore[attr-defined]

    settings.JUSTMYRESOURCE_BLOCKLIST = ["pack1", "pack2"]
    reg = get_registry()

    # Verify blocklist was parsed
    assert reg._blocklist is not None
    assert "pack1" in reg._blocklist
    assert "pack2" in reg._blocklist


def test_registry_prefix_map_dict():
    """Test registry configuration with prefix_map as dict."""
    from django_justmyresource import registry

    registry._registry = None  # type: ignore[attr-defined]

    settings.JUSTMYRESOURCE_PREFIX_MAP = {"alias1": "dist1/pack1", "alias2": "dist2/pack2"}
    reg = get_registry()

    # Verify prefix_map was parsed
    assert reg._prefix_map is not None
    assert reg._prefix_map["alias1"] == "dist1/pack1"
    assert reg._prefix_map["alias2"] == "dist2/pack2"


def test_registry_prefix_map_string():
    """Test registry configuration with prefix_map as string."""
    from django_justmyresource import registry

    registry._registry = None  # type: ignore[attr-defined]

    settings.JUSTMYRESOURCE_PREFIX_MAP = "alias1=dist1/pack1,alias2=dist2/pack2"
    reg = get_registry()

    # Verify prefix_map was parsed
    assert reg._prefix_map is not None
    assert reg._prefix_map["alias1"] == "dist1/pack1"
    assert reg._prefix_map["alias2"] == "dist2/pack2"

