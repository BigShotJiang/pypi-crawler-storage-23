"""Tests for django-justmyresource."""

