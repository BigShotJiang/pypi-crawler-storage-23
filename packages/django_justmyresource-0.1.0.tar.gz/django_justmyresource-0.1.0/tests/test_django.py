"""Tests for Django template tag integration."""

from __future__ import annotations

from typing import Any

import django
from django.conf import settings
from django.template import Context
from django.template import Template

settings.configure(
    ROOT_URLCONF=__name__,  # Make this module the urlconf
    SECRET_KEY="insecure",
    TEMPLATES=[
        {
            "BACKEND": "django.template.backends.django.DjangoTemplates",
            "APP_DIRS": False,
        },
    ],
    INSTALLED_APPS=["django_justmyresource"],
)
urlpatterns: list[Any] = []
django.setup()


def test_icon_basic():
    """Test basic icon rendering."""
    template = Template('{% load justmyresource %}{% icon "lucide:a-arrow-down" %}')

    result = template.render(Context())

    # Should render SVG with default size
    assert result.startswith("<svg")
    assert 'width="24"' in result
    assert 'height="24"' in result


def test_icon_custom_size():
    """Test icon rendering with custom size."""
    template = Template(
        '{% load justmyresource %}{% icon "lucide:a-arrow-down" size=48 %}'
    )

    result = template.render(Context())

    assert 'width="48"' in result
    assert 'height="48"' in result


def test_icon_with_attributes():
    """Test icon rendering with additional attributes."""
    template = Template(
        '{% load justmyresource %}'
        + '{% icon "lucide:a-arrow-down" size=40 class="mr-4" %}'
    )

    result = template.render(Context())

    assert 'width="40"' in result
    assert 'class="mr-4"' in result


def test_icon_path_attributes():
    """Test icon rendering with path-level attributes."""
    template = Template(
        '{% load justmyresource %}'
        + '{% icon "lucide:a-arrow-down" stroke_linecap="butt" %}'
    )

    result = template.render(Context())

    # Path attributes should be applied to <path> elements
    assert "stroke-linecap" in result


def test_icon_size_none():
    """Test icon rendering with size=None."""
    template = Template(
        '{% load justmyresource %}{% icon "lucide:a-arrow-down" size=None %}'
    )

    result = template.render(Context())

    # Should still render SVG
    assert result.startswith("<svg")


def test_icon_with_data_attributes():
    """Test icon rendering with data attributes."""
    template = Template(
        '{% load justmyresource %}'
        + '{% icon "lucide:a-arrow-down" data_test="value" data_controller="test" %}'
    )

    result = template.render(Context())

    assert 'data-test="value"' in result
    assert 'data-controller="test"' in result

