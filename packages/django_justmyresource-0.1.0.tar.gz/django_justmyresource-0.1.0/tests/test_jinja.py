"""Tests for Jinja2 integration."""

from __future__ import annotations

import pytest

# Skip all tests if jinja2 is not available
jinja2 = pytest.importorskip("jinja2")

from jinja2 import DictLoader
from jinja2 import Environment

from django_justmyresource.jinja import icon


def make_environment(template_str: str) -> Environment:
    """Create a Jinja2 environment with icon function."""
    env = Environment(loader=DictLoader({"index": template_str}))
    env.globals.update(
        {
            "icon": icon,
        }
    )
    return env


def test_icon_basic():
    """Test basic icon rendering."""
    env = make_environment('{{ icon("lucide:a-arrow-down") }}')
    template = env.get_template("index")

    result = str(template.render())

    assert result.startswith("<svg")
    assert 'width="24"' in result
    assert 'height="24"' in result


def test_icon_custom_size():
    """Test icon rendering with custom size."""
    env = make_environment('{{ icon("lucide:a-arrow-down", size=48) }}')
    template = env.get_template("index")

    result = str(template.render())

    assert 'width="48"' in result
    assert 'height="48"' in result


def test_icon_with_attributes():
    """Test icon rendering with additional attributes."""
    env = make_environment(
        '{{ icon("lucide:a-arrow-down", size=40, class="mr-4") }}'
    )
    template = env.get_template("index")

    result = str(template.render())

    assert 'width="40"' in result
    assert 'class="mr-4"' in result


def test_icon_path_attributes():
    """Test icon rendering with path-level attributes."""
    env = make_environment(
        '{{ icon("lucide:a-arrow-down", stroke_linecap="butt") }}'
    )
    template = env.get_template("index")

    result = str(template.render())

    # Path attributes should be applied to <path> elements
    assert "stroke-linecap" in result


def test_icon_size_none():
    """Test icon rendering with size=None."""
    env = make_environment('{{ icon("lucide:a-arrow-down", size=None) }}')
    template = env.get_template("index")

    result = str(template.render())

    # Should still render SVG
    assert result.startswith("<svg")


def test_icon_with_data_attributes():
    """Test icon rendering with data attributes."""
    env = make_environment(
        '{{ icon("lucide:a-arrow-down", data_test="value", data_controller="test") }}'
    )
    template = env.get_template("index")

    result = str(template.render())

    assert 'data-test="value"' in result
    assert 'data-controller="test"' in result

