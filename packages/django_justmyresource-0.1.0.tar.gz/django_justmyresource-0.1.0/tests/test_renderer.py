"""Tests for SVG renderer."""

from __future__ import annotations

from xml.etree import ElementTree

import pytest

from django_justmyresource.renderer import (
    InvalidResourceTypeError,
    ResourceNotFoundError,
    _load_svg,
    render_svg,
)


def test_load_svg_success():
    """Test loading an SVG resource."""
    # This test assumes justmyresource-lucide is installed
    # If not available, we'll skip or mock
    try:
        svg = _load_svg("lucide:a-arrow-down")
        assert isinstance(svg, ElementTree.Element)
        assert svg.tag == ElementTree.QName("svg")
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_load_svg_not_found():
    """Test loading a non-existent resource."""
    with pytest.raises(ResourceNotFoundError) as excinfo:
        _load_svg("nonexistent-pack:nonexistent-icon")

    assert "not found" in str(excinfo.value).lower()


def test_render_svg_basic():
    """Test basic SVG rendering."""
    try:
        result = render_svg("lucide:a-arrow-down")
        assert result.startswith("<svg")
        assert 'width="24"' in result
        assert 'height="24"' in result
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_render_svg_custom_size():
    """Test SVG rendering with custom size."""
    try:
        result = render_svg("lucide:a-arrow-down", size=48)
        assert 'width="48"' in result
        assert 'height="48"' in result
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_render_svg_size_none():
    """Test SVG rendering with size=None."""
    try:
        result = render_svg("lucide:a-arrow-down", size=None)
        assert 'width=' not in result or 'width="24"' in result
        # Size=None should preserve original or not set width/height
        # The actual behavior depends on the SVG source
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_render_svg_with_attributes():
    """Test SVG rendering with additional attributes."""
    try:
        result = render_svg("lucide:a-arrow-down", class_="test-class", data_test="value")
        assert 'class="test-class"' in result
        assert 'data-test="value"' in result
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_render_svg_path_attributes():
    """Test SVG rendering with path-level attributes."""
    try:
        result = render_svg("lucide:a-arrow-down", stroke_linecap="butt")
        # Path attributes should be on <path> elements, not <svg>
        assert "stroke-linecap" in result
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")


def test_render_svg_no_xmlns():
    """Test that rendered SVG doesn't include xmlns."""
    try:
        result = render_svg("lucide:a-arrow-down")
        # Inline SVGs shouldn't have xmlns
        assert 'xmlns="http://www.w3.org/2000/svg"' not in result
    except ResourceNotFoundError:
        pytest.skip("justmyresource-lucide pack not available")

