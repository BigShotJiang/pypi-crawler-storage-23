"""Style, ColorPalette, Font, and Tooltip objects.

.. note::
    Full implementation is tracked in Phase 2 of the development plan.
"""

from __future__ import annotations
