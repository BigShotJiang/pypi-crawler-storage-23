"""Image, shape, and asset handling within .twbx packages.

.. note::
    Full implementation is tracked in Phase 1 of the development plan.
"""

from __future__ import annotations
