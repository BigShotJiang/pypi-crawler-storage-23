"""WorkbookDiff: semantic diff between two Tableau workbooks.

.. note::
    Full implementation is tracked in Phase 2 of the development plan.
"""

from __future__ import annotations
