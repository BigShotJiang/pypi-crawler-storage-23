"""Structural diff between two Tableau workbook XML trees.

.. note::
    Full implementation is tracked in Phase 6 of the development plan.
"""

from __future__ import annotations
