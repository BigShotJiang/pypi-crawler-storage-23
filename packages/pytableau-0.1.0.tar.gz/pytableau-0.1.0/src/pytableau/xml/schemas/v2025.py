"""Tableau 2025.x XML schema specifics.

.. note::
    Full implementation is tracked in Phase 1 of the development plan.
"""

from __future__ import annotations
