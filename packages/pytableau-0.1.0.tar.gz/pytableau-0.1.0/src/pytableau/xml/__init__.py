"""XML engine for pytableau.

Provides schema validation, safe XML mutation, and structural diffing for
Tableau workbook XML trees.
"""

from __future__ import annotations
