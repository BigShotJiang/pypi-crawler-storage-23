# pytableau

pytableau is a unified Python SDK for building and modifying Tableau workbooks.
Use it for read, mutate, and publish workflows.

- Parse and inspect `.twb`/`.twbx` files.
- Parameterize templates from built-in `.twb` files.
- Run worksheet and dashboard mutations.
- Publish and download workbooks from Tableau Server/Cloud.
- Generate `.twb` diffs and analyze schema patterns.

Visit the sections below to get started.
