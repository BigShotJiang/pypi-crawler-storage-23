from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .api import views as api_views
from . import views
from allianceauth.services.hooks import get_extension_logger

logger = get_extension_logger(__name__)

router = DefaultRouter()
router.register(r'filters', api_views.filters, basename="filters")
router.register(r'battle-reports', api_views.battlereports, basename='battle-reports')
router.register(r'battle-reports/<int:pk>/', api_views.battlereports, basename='battle-reports-patch')
router.register(r'killmails', api_views.compensations,basename='killmails')
# router.register(r'killmails/<int:pk>/',api_views.compensations, basename='killmails-update')


app_name = 'br_compensations'

logger.info("Создание urlpatterns для br_compensations")

urlpatterns = [
    path('api/', include(router.urls)),
    path('api/filter-term/find', api_views.filters_view),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/<str:filter>/', views.dashboard, name='dashboard'),
    path('reports/', views.reports, name='reports'),
    path('test/br/process', api_views.tests_view,name='br-process-test')
]

logger.info(f"Созданы urlpatterns: {urlpatterns}")