from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models import FilterEntity, BattleReport, KillCompensation
from eveuniverse.models import EveEntity
from django.contrib.auth.decorators import permission_required

logger = get_extension_logger(__name__)


class DashboardView(LoginRequiredMixin, PermissionRequiredMixin,TemplateView): 
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            if f.entity_type == FilterEntity.ALLIANCE:
                entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
            elif f.entity_type == FilterEntity.CORPORATION:
                entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
            elif f.entity_type == FilterEntity.CHARACTER:
                entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
            
            try:
                entry = EveEntity.objects.get(id=f.entity_id)
                
                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': entry.name,
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': entry.name,
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        if filter=='rejected':
            kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
            context['listTitle'] = 'Отмененные'
        elif filter=='complete' or filter =='accepted':
            kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
            context['listTitle'] = 'Выполненные'
        elif filter=='all':
            kills = KillCompensation.objects.all()
            context['listTitle'] = 'Все'
        else:
            kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
            context['listTitle'] = 'Текущие'    
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["killmails"] = kills.order_by('status', 'timestamp','-loss_value').all()
        
        return context


class BattleReportsView(LoginRequiredMixin,PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["reports"] = BattleReport.objects.all()
        context["form"] = AddBrForm()
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})
    
dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()