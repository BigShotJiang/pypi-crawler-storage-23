"""CLI for exploring Codex conversation history."""

from importlib import resources
import os
import re
import shutil
from pathlib import Path

import click

from .parser import (
    Message,
    ConversationSummary,
    find_conversations,
    get_file_size_human,
    parse_conversation,
    search_conversations,
    search_project,
    summarize_conversation,
)

# Default Codex sessions directory
DEFAULT_CODEX_DIR = Path.home() / ".codex" / "sessions"


def get_sessions_dir() -> Path:
    """Get the Codex sessions directory."""
    env_dir = os.environ.get("CODEX_HISTORY_DIR")
    if env_dir:
        return Path(env_dir)
    return DEFAULT_CODEX_DIR


def echo(text: str = "") -> None:
    """Print a line."""
    click.echo(text)


def print_table(headers: list[str], rows: list[list[str]]) -> None:
    """Print a simple tab-separated table."""
    for row in rows:
        for i, cell in enumerate(row):
            if cell is None:
                row[i] = ""
            else:
                row[i] = str(cell).replace("\t", " ").replace("\n", " ")
    click.echo("\t".join(headers))
    for row in rows:
        click.echo("\t".join(row))


def format_timestamp(dt) -> str:
    """Format a datetime for display."""
    if not dt:
        return "unknown"
    return dt.strftime("%Y-%m-%d %H:%M")


def truncate(text: str, max_len: int) -> str:
    """Truncate text with ellipsis."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def _build_catalog(sessions_dir: Path) -> list[dict]:
    """Build a session catalog with summary metadata."""
    catalog: list[dict] = []

    for conv_path in find_conversations(sessions_dir):
        try:
            summary = summarize_conversation(conv_path)
        except Exception:
            continue

        catalog.append(
            {
                "path": conv_path,
                "summary": summary,
                "cwd": summary.cwd,
                "mtime": conv_path.stat().st_mtime,
            }
        )

    return catalog


def _resolve_project_cwd(catalog: list[dict], project: str) -> str | None:
    """Resolve a project identifier to a concrete cwd from catalog."""
    if project.startswith("."):
        project = str(Path(project).resolve())

    target = project.rstrip("/")

    cwds = [item["cwd"] for item in catalog if item.get("cwd")]
    if not cwds:
        return None

    # Exact match.
    for cwd in cwds:
        if cwd == target:
            return cwd

    # Match resolved absolute path.
    try:
        resolved = str(Path(target).resolve())
        for cwd in cwds:
            if cwd == resolved:
                return cwd
    except Exception:
        pass

    # Match by leaf directory name or full suffix.
    for cwd in cwds:
        if Path(cwd).name == target:
            return cwd
        if cwd.endswith("/" + target):
            return cwd

    return None


def find_conversation_file(sessions_dir: Path, session_id: str) -> Path | None:
    """Find a conversation file by session ID (full or partial)."""
    # Check if it's a direct file path.
    input_path = Path(session_id)
    if input_path.exists() and input_path.is_file():
        return input_path

    conversations = find_conversations(sessions_dir)

    # Match against file stems first (fast path).
    for conv_path in conversations:
        stem = conv_path.stem
        if (
            stem == session_id
            or stem.startswith(session_id)
            or stem.endswith(session_id)
            or session_id in stem
        ):
            return conv_path

    # Fallback: parse the actual session IDs.
    for conv_path in conversations:
        try:
            summary = summarize_conversation(conv_path)
        except Exception:
            continue

        if summary.session_id == session_id or summary.session_id.startswith(
            session_id
        ):
            return conv_path

    return None


def summarize_tools(tools: list[str]) -> str:
    """Summarize a list of tool names into a compact string."""
    from collections import Counter

    counts = Counter(tools)
    parts = []
    for tool, count in counts.most_common():
        if count > 1:
            parts.append(f"{tool}×{count}")
        else:
            parts.append(tool)
    return ", ".join(parts)


def render_message(msg: Message, full: bool = False, show_tools: bool = True):
    """Render a message without rich formatting for LLM-friendly output."""
    if msg.role == "tool" and not show_tools:
        return

    header_parts = [msg.role.upper()]
    if msg.timestamp:
        header_parts.append(format_timestamp(msg.timestamp))
    if msg.model:
        header_parts.append(msg.model)
    if msg.is_sidechain:
        header_parts.append("sidechain")
    echo(" | ".join(header_parts))

    def echo_block(text: str) -> None:
        for line in text.splitlines() or [""]:
            echo(f"  {line}")

    for block in msg.blocks:
        if block.type == "text":
            text = block.text or ""
            if text.strip().startswith("<") and not full:
                if any(
                    tag in text
                    for tag in [
                        "<environment_context",
                        "<permissions instructions>",
                        "<turn_aborted>",
                    ]
                ):
                    echo_block("(system/context content)")
                    continue

            if not full and len(text) > 500:
                text = text[:500] + "\n... (truncated, use --full to see all)"
            echo_block(text)

        elif block.type == "tool_use" and show_tools:
            echo_block(f"TOOL: {block.tool_name}")
            if block.tool_input is not None and full:
                import json

                if isinstance(block.tool_input, (dict, list)):
                    input_str = json.dumps(block.tool_input, indent=2)
                else:
                    input_str = str(block.tool_input)

                if len(input_str) > 200:
                    input_str = input_str[:200] + "..."
                for line in input_str.splitlines():
                    echo_block(line)

        elif block.type == "tool_result" and show_tools:
            result_text = block.text or ""
            if not full and len(result_text) > 200:
                result_text = result_text[:200] + "..."
            echo_block(f"RESULT: {result_text}")

        elif block.type == "thinking":
            if full:
                text = block.text or ""
                if len(text) > 300:
                    text = text[:300] + "..."
                echo_block(f"THINKING: {text}")
            else:
                echo_block("THINKING: (hidden)")

    echo()


@click.group()
def cli():
    """Explore Codex conversation history.

    Use this tool to list, search, and view past Codex conversations.
    """
    pass


@cli.command()
@click.option(
    "--sort",
    type=click.Choice(["modified", "name", "conversations"]),
    default="modified",
    help="Sort projects by: modified (default), name, or conversations",
)
def projects(sort: str):
    """List all projects with conversation history."""
    from datetime import datetime

    sessions_dir = get_sessions_dir()

    if not sessions_dir.exists():
        echo(f"Directory not found: {sessions_dir}")
        return

    catalog = _build_catalog(sessions_dir)
    if not catalog:
        echo("No conversations found.")
        return

    project_data: dict[str, dict] = {}
    for item in catalog:
        cwd = item["cwd"] or "unknown"
        if cwd not in project_data:
            project_data[cwd] = {
                "name": cwd,
                "conversations": 0,
                "latest_mtime": item["mtime"],
            }

        project_data[cwd]["conversations"] += 1
        project_data[cwd]["latest_mtime"] = max(
            project_data[cwd]["latest_mtime"], item["mtime"]
        )

    rows_data = []
    for project in project_data.values():
        rows_data.append(
            {
                "name": project["name"],
                "conversations": project["conversations"],
                "latest_mtime": project["latest_mtime"],
                "latest_dt": datetime.fromtimestamp(project["latest_mtime"]),
            }
        )

    if sort == "modified":
        rows_data.sort(key=lambda p: p["latest_mtime"], reverse=True)
    elif sort == "name":
        rows_data.sort(key=lambda p: p["name"])
    elif sort == "conversations":
        rows_data.sort(key=lambda p: p["conversations"], reverse=True)

    rows = [
        [p["name"], str(p["conversations"]), format_timestamp(p["latest_dt"])]
        for p in rows_data
    ]
    print_table(["Project", "Conversations", "Last Modified"], rows)


@cli.command("list")
@click.argument("project", required=False)
@click.option("-n", "--limit", default=20, help="Number of conversations to show")
def list_conversations(project: str | None, limit: int):
    """List conversations in a project.

    PROJECT can be a full path, relative path, or project name suffix.
    """
    sessions_dir = get_sessions_dir()

    if not sessions_dir.exists():
        echo(f"Directory not found: {sessions_dir}")
        return

    conversation_paths: list[Path] = []
    summary_by_path: dict[Path, ConversationSummary] = {}

    if project:
        catalog = _build_catalog(sessions_dir)
        project_cwd = _resolve_project_cwd(catalog, project)
        if not project_cwd:
            echo(f"Project not found: {project}")
            echo("Tip: Use 'codex-history projects' to see available projects")
            return

        for item in catalog:
            if item["cwd"] == project_cwd:
                path = item["path"]
                summary_by_path[path] = item["summary"]
                conversation_paths.append(path)

        conversation_paths.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    else:
        conversation_paths = find_conversations(sessions_dir)

    if not conversation_paths:
        echo("No conversations found.")
        return

    rows = []
    for i, conv_path in enumerate(conversation_paths[:limit]):
        try:
            summary = summary_by_path.get(conv_path)
            if summary is None:
                summary = summarize_conversation(conv_path)

            title = truncate(summary.title, 50)
            msg_count = (
                f"{summary.user_message_count}u/{summary.assistant_message_count}a"
            )
            date = format_timestamp(summary.start_time)
            size = get_file_size_human(conv_path)
            rows.append(
                [str(i + 1), summary.session_id[:8], title, msg_count, size, date]
            )
        except Exception as e:
            rows.append([str(i + 1), conv_path.stem[:8], f"Error: {e}", "-", "-", "-"])

    echo(
        f"Conversations ({len(conversation_paths)} total, showing {min(limit, len(conversation_paths))})"
    )
    print_table(["#", "Session ID", "Title", "Messages", "Size", "Date"], rows)
    echo("Tip: Use 'codex-history view <session-id>' to view a conversation")


@cli.command()
@click.argument("session_id")
@click.option("-f", "--full", is_flag=True, help="Show full message content")
@click.option("--no-tools", is_flag=True, help="Hide tool use details")
@click.option("-n", "--limit", type=int, help="Limit number of messages shown")
@click.option("-o", "--offset", type=int, default=0, help="Skip first N messages")
def view(session_id: str, full: bool, no_tools: bool, limit: int | None, offset: int):
    """View a conversation by session ID.

    SESSION_ID can be a full ID, partial ID, or a file path.
    """
    sessions_dir = get_sessions_dir()

    conv_path = find_conversation_file(sessions_dir, session_id)
    if not conv_path:
        echo(f"Conversation not found: {session_id}")
        return

    conv = parse_conversation(conv_path)

    echo("Conversation Info")
    echo(f"Title: {conv.title}")
    echo(f"Session: {conv.session_id}")
    echo(f"Directory: {conv.cwd or 'unknown'}")
    echo(f"Branch: {conv.git_branch or 'unknown'}")
    echo(f"Version: {conv.version or 'unknown'}")
    echo(
        f"Time: {format_timestamp(conv.start_time)} - {format_timestamp(conv.end_time)}"
    )
    echo(
        f"Messages: {conv.user_message_count} user, {conv.assistant_message_count} assistant"
    )
    echo(f"Tool uses: {conv.tool_use_count}")

    if conv.summaries:
        echo()
        echo("Summaries:")
        for summary in conv.summaries:
            indented = summary.replace("\n", "\n  ")
            echo(f"- {indented}")

    messages = conv.messages[offset:]
    if limit:
        messages = messages[:limit]

    echo()
    echo(f"Messages (showing {len(messages)} of {len(conv.messages)}):")
    echo()

    for msg in messages:
        if msg.is_meta:
            continue

        render_message(msg, full=full, show_tools=not no_tools)


@cli.command()
@click.argument("query")
@click.option(
    "-p", "--project", default=None, help="Limit search to a specific project"
)
@click.option("-n", "--limit", default=10, help="Number of results to show")
def search(query: str, project: str | None, limit: int):
    """Search conversations for a query string.

    By default searches all conversations. Use --project to limit to a specific project.
    """
    sessions_dir = get_sessions_dir()

    if project:
        catalog = _build_catalog(sessions_dir)
        project_cwd = _resolve_project_cwd(catalog, project)
        if not project_cwd:
            echo(f"Project not found: {project}")
            echo("Tip: Use 'codex-history projects' to see available projects")
            return

        project_files = [item["path"] for item in catalog if item["cwd"] == project_cwd]
        results = search_project(project_files, query, limit)
    else:
        results = search_conversations(sessions_dir, query, limit)

    if not results:
        echo(f"No results found for: {query}")
        return

    echo(f"Found {len(results)} matches:")
    echo()

    for match in results:
        echo(f"{match.session_id[:8]} - {truncate(match.title, 40)}")
        echo(f"  {format_timestamp(match.timestamp)}")
        echo(f"  {match.snippet}")
        echo()


@cli.command()
@click.argument("session_id")
def summary(session_id: str):
    """Show a concise summary of a conversation."""
    sessions_dir = get_sessions_dir()

    conv_path = find_conversation_file(sessions_dir, session_id)
    if not conv_path:
        echo(f"Conversation not found: {session_id}")
        return

    conv = parse_conversation(conv_path)

    echo(f"Session: {conv.session_id}")
    echo(f"Title: {conv.title}")
    echo(f"Directory: {conv.cwd or 'unknown'}")
    echo(f"Time: {format_timestamp(conv.start_time)}")
    echo(
        f"Stats: {conv.user_message_count} user msgs, {conv.assistant_message_count} assistant msgs, {conv.tool_use_count} tool uses"
    )

    if conv.summaries:
        echo()
        echo("Stored Summaries:")
        for s in conv.summaries:
            indented = s.replace("\n", "\n  ")
            echo(f"- {indented}")

    echo()
    echo("Conversation Flow:")

    turn = 0
    pending_tools: list[str] = []

    for i, msg in enumerate(conv.messages):
        if msg.is_meta or msg.role == "tool":
            continue

        turn += 1
        if msg.role == "user":
            text = msg.text.strip()
            if text.startswith("<"):
                continue
            echo()
            echo(f"{turn}. User: {truncate(text, 100)}")

        elif msg.role == "assistant":
            if msg.tool_names:
                pending_tools.extend(msg.tool_names)

            text = msg.text.strip()
            if text:
                if pending_tools:
                    tool_summary = summarize_tools(pending_tools)
                    echo(f"  Tools: {tool_summary}")
                    pending_tools = []
                echo(f"  Assistant: {truncate(text, 100)}")

            next_msg = conv.messages[i + 1] if i + 1 < len(conv.messages) else None
            if pending_tools and (not next_msg or next_msg.role == "user"):
                tool_summary = summarize_tools(pending_tools)
                echo(f"  Tools: {tool_summary}")
                pending_tools = []


@cli.command()
@click.argument("session_id")
@click.option(
    "-f",
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
)
def export(session_id: str, output_format: str):
    """Export a conversation to a simpler format."""
    sessions_dir = get_sessions_dir()

    conv_path = find_conversation_file(sessions_dir, session_id)
    if not conv_path:
        echo(f"Conversation not found: {session_id}")
        return

    conv = parse_conversation(conv_path)

    if output_format == "json":
        import json

        messages: list[dict] = []
        output = {
            "session_id": conv.session_id,
            "title": conv.title,
            "cwd": conv.cwd,
            "git_branch": conv.git_branch,
            "start_time": conv.start_time.isoformat() if conv.start_time else None,
            "messages": messages,
        }

        for msg in conv.messages:
            if msg.is_meta:
                continue
            messages.append(
                {
                    "role": msg.role,
                    "text": msg.text,
                    "tools": msg.tool_names,
                    "timestamp": msg.timestamp.isoformat() if msg.timestamp else None,
                }
            )

        click.echo(json.dumps(output, indent=2))

    else:
        click.echo(f"# {conv.title}")
        click.echo(f"Session: {conv.session_id}")
        click.echo(f"Date: {format_timestamp(conv.start_time)}")
        click.echo(f"Directory: {conv.cwd}")
        click.echo()

        for msg in conv.messages:
            if msg.is_meta:
                continue

            role = "USER" if msg.role == "user" else "ASSISTANT"
            click.echo(f"## {role}")

            if msg.text:
                click.echo(msg.text)

            if msg.tool_names:
                click.echo(f"\n[Tools: {', '.join(msg.tool_names)}]")

            click.echo()


@cli.command()
@click.argument("session_id")
@click.option("-c", "--max-chars", default=8000, help="Maximum characters in output")
@click.option("--include-tools", is_flag=True, help="Include tool names in output")
def catchup(session_id: str, max_chars: int, include_tools: bool):
    """Generate a context summary for catching up in a new session."""
    sessions_dir = get_sessions_dir()

    conv_path = find_conversation_file(sessions_dir, session_id)
    if not conv_path:
        echo(f"Conversation not found: {session_id}")
        return

    conv = parse_conversation(conv_path)

    lines = []
    lines.append("# Previous Session Context")
    lines.append("")
    lines.append(f"**Session:** {conv.session_id}")
    lines.append(f"**Project:** {conv.cwd or 'unknown'}")
    lines.append(f"**Date:** {format_timestamp(conv.start_time)}")
    lines.append(
        f"**Messages:** {conv.user_message_count} user, {conv.assistant_message_count} assistant"
    )
    lines.append("")

    if conv.summaries:
        lines.append("## Stored Summaries")
        for s in conv.summaries:
            lines.append(s)
            lines.append("")

    lines.append("## Conversation Flow")
    lines.append("")

    current_length = len("\n".join(lines))
    turn = 0
    pending_tools: list[str] = []

    for i, msg in enumerate(conv.messages):
        if msg.is_meta or msg.role == "tool":
            continue

        if msg.role == "user":
            text = msg.text.strip()
            if text.startswith("<"):
                continue
            turn += 1
            entry = f"**User {turn}:** {truncate(text, 200)}"
            if current_length + len(entry) + 10 > max_chars:
                lines.append("... (truncated due to length limit)")
                break
            lines.append(entry)
            current_length += len(entry) + 1

        elif msg.role == "assistant":
            if msg.tool_names:
                pending_tools.extend(msg.tool_names)

            text = msg.text.strip()
            if text:
                if include_tools and pending_tools:
                    tool_summary = summarize_tools(pending_tools)
                    lines.append(f"  *Tools: {tool_summary}*")
                    pending_tools = []

                entry = f"  Assistant: {truncate(text, 300)}"
                if current_length + len(entry) + 10 > max_chars:
                    lines.append("... (truncated due to length limit)")
                    break
                lines.append(entry)
                current_length += len(entry) + 1

            next_msg = conv.messages[i + 1] if i + 1 < len(conv.messages) else None
            if (
                include_tools
                and pending_tools
                and (not next_msg or next_msg.role == "user")
            ):
                tool_summary = summarize_tools(pending_tools)
                lines.append(f"  *Tools: {tool_summary}*")
                pending_tools = []

        lines.append("")

    output = "\n".join(lines)
    output = re.sub(r"\n{3,}", "\n\n", output)
    click.echo(output)
    click.echo(f"\n({len(output)} characters)", err=True)


@cli.command("project-summary")
@click.argument("project")
@click.option("-n", "--limit", default=5, help="Number of recent conversations")
@click.option("-c", "--max-chars", default=6000, help="Maximum characters in output")
def project_summary(project: str, limit: int, max_chars: int):
    """Generate a summary of recent conversations in a project."""
    sessions_dir = get_sessions_dir()

    catalog = _build_catalog(sessions_dir)
    project_cwd = _resolve_project_cwd(catalog, project)
    if not project_cwd:
        echo(f"Project not found: {project}")
        echo("Tip: Use 'codex-history projects' to see available projects")
        return

    convos = [item["path"] for item in catalog if item["cwd"] == project_cwd][:limit]
    if not convos:
        echo("No conversations found.")
        return

    lines = []
    lines.append(f"# Project Summary: {project_cwd}")
    lines.append("")
    lines.append(f"Recent conversations ({len(convos)} shown):")
    lines.append("")

    current_length = len("\n".join(lines))

    for conv_path in convos:
        try:
            conv = parse_conversation(conv_path)

            entry_lines = []
            entry_lines.append(
                f"## {format_timestamp(conv.start_time)} - {conv.session_id[:8]}"
            )
            entry_lines.append(f"**Title:** {conv.title}")
            entry_lines.append(
                f"**Stats:** {conv.user_message_count}u/{conv.assistant_message_count}a msgs, {conv.tool_use_count} tools"
            )

            for msg in conv.messages:
                if msg.role == "user" and not msg.is_meta:
                    text = msg.text.strip()
                    if not text.startswith("<"):
                        entry_lines.append(f"**Started with:** {truncate(text, 150)}")
                        break

            for msg in reversed(conv.messages):
                if msg.role == "assistant" and msg.text.strip():
                    entry_lines.append(
                        f"**Last response:** {truncate(msg.text.strip(), 150)}"
                    )
                    break

            entry_lines.append("")

            entry = "\n".join(entry_lines)
            if current_length + len(entry) > max_chars:
                lines.append("... (more conversations truncated)")
                break
            lines.extend(entry_lines)
            current_length += len(entry)

        except Exception as e:
            lines.append(f"## {conv_path.stem[:8]} - Error: {e}")
            lines.append("")

    output = "\n".join(lines)
    click.echo(output)
    click.echo(f"\n({len(output)} characters)", err=True)


@cli.command("install-skill")
@click.option(
    "-d",
    "--dest",
    type=click.Path(),
    default=None,
    help="Destination directory (default: ~/.codex/skills)",
)
@click.option("-f", "--force", is_flag=True, help="Overwrite existing skill")
def install_skill(dest: str | None, force: bool):
    """Install the codex-history skill to ~/.codex/skills/."""
    if dest:
        dest_dir = Path(dest)
    else:
        dest_dir = Path.home() / ".codex" / "skills"

    skill_dest = dest_dir / "codex-history"

    if skill_dest.exists() and not force:
        echo(f"Skill already exists at {skill_dest}")
        echo("Use --force to overwrite")
        return

    import codex_history

    skill_source = Path(codex_history.__file__).parent / "skill"

    if not skill_source.is_dir():
        echo(f"Error: Bundled skill not found at {skill_source}")
        return

    dest_dir.mkdir(parents=True, exist_ok=True)

    if skill_dest.exists():
        shutil.rmtree(skill_dest)
        echo(f"Removed existing skill at {skill_dest}")

    shutil.copytree(skill_source, skill_dest)
    echo(f"Installed skill to {skill_dest}")


@cli.command()
def skill():
    """Print the bundled SKILL.md contents."""
    try:
        skill_text = (
            resources.files("codex_history")
            .joinpath("skill")
            .joinpath("SKILL.md")
            .read_text(encoding="utf-8")
        )
    except Exception as e:
        echo(f"Error reading bundled skill: {e}")
        return

    click.echo(skill_text, nl=False)


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
