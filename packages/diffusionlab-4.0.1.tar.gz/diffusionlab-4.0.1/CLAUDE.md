# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

**For code generation, documentation, and planning rules, see [AGENTS.md](AGENTS.md) and [README.md](README.md).**
