"""Generate llms.md and llms-full.md from the DiffusionLab package.

Walks the package tree, extracts docstrings from all public modules, classes,
and functions, and produces two Markdown files following the llms.txt spec
(https://llmstxt.org/):

- llms.md: concise summary with module listing
- llms-full.md: complete API reference with all docstrings
"""

import importlib
import inspect
import textwrap
import types as pytypes
import typing
from pathlib import Path

PACKAGE_NAME = "diffusionlab"
BASE_URL = "https://github.com/druvpai/DiffusionLab/blob/main"
PROJECT_DESCRIPTION = (
    "No-frills JAX library providing core abstractions for diffusion models."
)

# jaxtyping metaclass names that indicate a type alias (not a base like Float/PyTree).
_JAXTYPING_METACLASSES = {
    "_MetaAbstractArray",
    "_MetaAbstractDtype",
    "_MetaPyTree",
}
# Names imported *from* jaxtyping that are not user-defined aliases.
_JAXTYPING_BUILTINS = {"Float", "Int", "Bool", "Key", "PyTree", "Array"}


def _is_type_alias(name: str, obj: object) -> bool:
    """Return True if *obj* is a user-defined type alias (not a re-exported builtin).

    Detects jaxtyping parameterised types, ``types.UnionType``, and
    ``types.GenericAlias`` while filtering out jaxtyping builtins and other
    non-alias members.

    Args:
        name: The attribute name on the module.
        obj: The attribute value.

    Returns:
        Whether *obj* is a type alias.
    """
    if name.startswith("_"):
        return False
    meta = type(obj).__qualname__
    if meta in _JAXTYPING_METACLASSES and name not in _JAXTYPING_BUILTINS:
        return True
    return isinstance(obj, (pytypes.UnionType, pytypes.GenericAlias))


def collect_type_aliases(modules: list[str]) -> dict[int, str]:
    """Scan all *modules* for type aliases and return an identity-based map.

    Uses ``id(obj)`` as the key so that aliases with identical string
    representations (e.g. ``Time`` vs ``Scalar``) are distinguished correctly.

    Args:
        modules: Fully-qualified module names to scan.

    Returns:
        Mapping from ``id(alias_object)`` to alias name.
    """
    alias_map: dict[int, str] = {}
    for mod_name in modules:
        mod = importlib.import_module(mod_name)
        for name in dir(mod):
            obj = getattr(mod, name)
            if not _is_type_alias(name, obj):
                continue
            obj_id = id(obj)
            # On collision keep the first (alphabetically earlier) alias.
            if obj_id not in alias_map:
                alias_map[obj_id] = name
    return alias_map


def _format_annotation(ann: object, alias_map: dict[int, str]) -> str:
    """Format a single type annotation, substituting known aliases by identity.

    Handles direct matches, union types (``X | Y``), and generic types
    (``tuple[X, Y]``, ``list[X]``, ``Callable[[X], Y]``, etc.) recursively.

    Args:
        ann: The annotation object from ``inspect.Parameter.annotation``
            or ``inspect.Signature.return_annotation``.
        alias_map: Identity-based alias map from :func:`collect_type_aliases`.

    Returns:
        Formatted annotation string.
    """
    # Direct alias match (identity-based).
    if id(ann) in alias_map:
        return alias_map[id(ann)]

    # NoneType -> "None".
    if ann is type(None):
        return "None"

    # Union types: X | Y | ...
    if isinstance(ann, pytypes.UnionType):
        args = typing.get_args(ann)
        return " | ".join(_format_annotation(a, alias_map) for a in args)

    # Generic aliases: tuple[X, Y], list[X], Callable[[X], Y], etc.
    origin = typing.get_origin(ann)
    if origin is not None:
        args = typing.get_args(ann)
        if args:
            formatted_args = ", ".join(_format_annotation(a, alias_map) for a in args)
            origin_name = getattr(origin, "__qualname__", None) or getattr(
                origin, "__name__", str(origin)
            )
            return f"{origin_name}[{formatted_args}]"

    # Fallback to inspect's default formatting.
    return inspect.formatannotation(ann)


def simplify_signature(sig: inspect.Signature, alias_map: dict[int, str]) -> str:
    """Format an ``inspect.Signature`` with type aliases resolved by identity.

    Args:
        sig: The signature object.
        alias_map: Identity-based alias map from :func:`collect_type_aliases`.

    Returns:
        Formatted signature string with aliases substituted.
    """
    parts: list[str] = []
    for param in sig.parameters.values():
        ann = param.annotation
        s = param.name
        if ann is not inspect.Parameter.empty:
            s += f": {_format_annotation(ann, alias_map)}"
        if param.default is not inspect.Parameter.empty:
            s += f" = {param.default!r}"
        parts.append(s)

    result = f"({', '.join(parts)})"
    ret = sig.return_annotation
    if ret is not inspect.Signature.empty:
        result += f" -> {_format_annotation(ret, alias_map)}"
    return result


def discover_modules(package_name: str, root: Path) -> list[str]:
    """Walk the filesystem to find all Python modules under the package.

    Uses the filesystem instead of ``pkgutil.walk_packages`` so that implicit
    namespace packages (directories without ``__init__.py``) are discovered.

    Args:
        package_name: The top-level package name.
        root: Repository root directory containing the package.

    Returns:
        Sorted list of fully-qualified module names.
    """
    package_dir = root / package_name
    modules: list[str] = []
    for py_file in sorted(package_dir.rglob("*.py")):
        if py_file.name == "__init__.py":
            continue
        relative = py_file.relative_to(root).with_suffix("")
        dotted = ".".join(relative.parts)
        modules.append(dotted)
    return modules


def module_to_path(module_name: str) -> str:
    """Convert a dotted module name to a file path relative to the repo root.

    Args:
        module_name: Dotted module path (e.g. ``diffusionlab.models.mlp``).

    Returns:
        Relative file path string.
    """
    return module_name.replace(".", "/") + ".py"


def get_public_members(
    mod: object,
    module_name: str,
) -> list[tuple[str, object]]:
    """Return public classes and functions defined in a module.

    Args:
        mod: The imported module object.
        module_name: The fully-qualified module name (used to filter re-exports).

    Returns:
        List of ``(name, obj)`` pairs for public members.
    """
    return [
        (name, obj)
        for name, obj in inspect.getmembers(mod)
        if not name.startswith("_")
        and (inspect.isclass(obj) or inspect.isfunction(obj))
        and obj.__module__ == module_name
    ]


def get_public_methods(cls: type) -> list[tuple[str, object]]:
    """Return public methods defined directly on a class (not inherited).

    Includes dunder methods like ``__call__`` and ``__init__`` when they have
    docstrings, since these are part of the public API for dataclasses and
    callable objects.

    Args:
        cls: The class to inspect.

    Returns:
        List of ``(name, func)`` pairs for public methods.
    """
    methods: list[tuple[str, object]] = []
    for name, obj in inspect.getmembers(cls, predicate=inspect.isfunction):
        # Skip private methods except __init__ and __call__
        if name.startswith("_") and name not in ("__init__", "__call__"):
            continue
        # Only include methods defined on this class, not inherited
        if name not in cls.__dict__:
            continue
        methods.append((name, obj))
    return methods


def _get_signature_str(obj: object, alias_map: dict[int, str]) -> str:
    """Get the formatted signature string for a callable, with aliases applied.

    Args:
        obj: A class, function, or method.
        alias_map: Identity-based alias map from :func:`collect_type_aliases`.

    Returns:
        Formatted signature string, or empty string if unavailable.
    """
    try:
        sig = inspect.signature(obj)  # type: ignore[arg-type]
        return simplify_signature(sig, alias_map)
    except (ValueError, TypeError):
        return ""


def format_method_doc(
    name: str,
    func: object,
    alias_map: dict[int, str],
) -> str:
    """Format a single method with its signature and docstring.

    Args:
        name: Method name.
        func: The method object.
        alias_map: Identity-based alias map from :func:`collect_type_aliases`.

    Returns:
        Markdown-formatted documentation string.
    """
    sig = _get_signature_str(func, alias_map)
    header = f"#### `{name}{sig}`"
    doc = inspect.getdoc(func)
    if doc:
        return f"{header}\n\n{textwrap.dedent(doc)}"
    return header


def format_member_doc(
    name: str,
    obj: type | pytypes.FunctionType,
    alias_map: dict[int, str],
) -> str:
    """Format a single class or function with its docstring and methods.

    For classes, public methods (including ``__init__`` and ``__call__``) are
    listed as sub-sections beneath the class header.

    Args:
        name: Member name.
        obj: The class or function object.
        alias_map: Identity-based alias map from :func:`collect_type_aliases`.

    Returns:
        Markdown-formatted documentation string.
    """
    kind = "class" if inspect.isclass(obj) else "function"
    sig = _get_signature_str(obj, alias_map)

    header = f"### `{name}`\n\n**{kind}** `{name}{sig}`"
    doc = inspect.getdoc(obj)
    parts = [header]
    if doc:
        parts.append(textwrap.dedent(doc))

    if inspect.isclass(obj):
        methods = get_public_methods(obj)
        for method_name, method_func in methods:
            parts.append(format_method_doc(method_name, method_func, alias_map))

    return "\n\n".join(parts)


def generate_llms_txt(modules: list[str]) -> str:
    """Generate the concise llms.txt content.

    Args:
        modules: List of fully-qualified module names.

    Returns:
        llms.txt content string.
    """
    lines = [
        f"# {PACKAGE_NAME}",
        "",
        f"> {PROJECT_DESCRIPTION}",
        "",
        "## Modules",
        "",
    ]
    for mod_name in modules:
        mod = importlib.import_module(mod_name)
        members = get_public_members(mod, mod_name)
        if not members:
            continue
        path = module_to_path(mod_name)
        summary = ""
        mod_doc = inspect.getdoc(mod)
        if mod_doc:
            summary = f": {mod_doc.splitlines()[0]}"
        lines.append(f"- [{mod_name}]({BASE_URL}/{path}){summary}")

    lines.append("")
    return "\n".join(lines)


def generate_llms_full_txt(modules: list[str], readme_text: str) -> str:
    """Generate the comprehensive llms-full.txt content.

    Args:
        modules: List of fully-qualified module names.
        readme_text: Content of the project README.

    Returns:
        llms-full.txt content string.
    """
    alias_map = collect_type_aliases(modules)

    lines = [
        f"# {PACKAGE_NAME}",
        "",
        f"> {PROJECT_DESCRIPTION}",
        "",
        "## Overview",
        "",
        readme_text.strip(),
        "",
        "## API Reference",
        "",
    ]

    for mod_name in modules:
        mod = importlib.import_module(mod_name)
        members = get_public_members(mod, mod_name)
        if not members:
            continue

        lines.append(f"## `{mod_name}`")
        lines.append("")
        mod_doc = inspect.getdoc(mod)
        if mod_doc:
            lines.append(mod_doc)
            lines.append("")

        for name, obj in members:
            lines.append(format_member_doc(name, obj, alias_map))  # type: ignore[arg-type]
            lines.append("")

    return "\n".join(lines)


def main() -> None:
    """Entry point: generate llms.md and llms-full.md in the docs/ directory."""
    root = Path(__file__).resolve().parent.parent
    docs_dir = root / "docs"
    readme_text = (root / "README.md").read_text()

    modules = discover_modules(PACKAGE_NAME, root)

    (docs_dir / "llms.md").write_text(generate_llms_txt(modules))
    print("Generated docs/llms.md")

    (docs_dir / "llms-full.md").write_text(generate_llms_full_txt(modules, readme_text))

    print("Generated docs/llms-full.md")


if __name__ == "__main__":
    main()
