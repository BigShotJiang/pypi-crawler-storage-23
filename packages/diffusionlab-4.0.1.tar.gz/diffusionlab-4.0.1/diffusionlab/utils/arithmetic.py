"""Numerical arithmetic utilities."""

from jax import numpy as jnp

from diffusionlab.typing import Scalar


def clip_scalar(x: Scalar, eps: float) -> Scalar:
    """Clip scalar magnitude away from zero for numerical stability.

    Preserves the sign of the scalar while ensuring its absolute
    value is at least ``eps``. When ``eps`` is 0, this is a no-op.

    Args:
        x: The scalar value to clip.
        eps: Minimum absolute value.

    Returns:
        The clipped scalar.
    """
    return jnp.where(
        x >= 0,
        jnp.maximum(eps, x),
        jnp.minimum(-eps, x),
    )
