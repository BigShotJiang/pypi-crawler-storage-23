# {{project_name}} State

## Current Context

* **Active Phase:** Not started
* **Current Task:** None

## Resume Point

* **Last Completed:** None
* **Next Task:** None
* **Next Action:** None
* **Failure Reason:** None
* **Checkpoint:** None

## Completed Tasks
