"""Framework and agent integration adapters."""
