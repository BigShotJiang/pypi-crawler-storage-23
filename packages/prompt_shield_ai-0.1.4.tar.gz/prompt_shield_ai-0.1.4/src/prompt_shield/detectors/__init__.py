"""Built-in prompt injection detectors."""
