"""factq CLI entry point."""

from __future__ import annotations

import click

from factq import __version__


@click.group()
@click.version_option(version=__version__, prog_name="factq")
def main() -> None:
    """factq — Your LLM's Local Source of Truth."""


@main.command()
@click.argument("path", default=".")
def init(path: str) -> None:
    """Initialize factq in a project directory."""
    click.echo(f"Initializing factq in {path}...")


@main.command()
@click.argument("question")
def query(question: str) -> None:
    """Query the knowledge base."""
    click.echo(f"Querying: {question}")


@main.command()
@click.argument("path")
def save(path: str) -> None:
    """Save a verified finding to docs/."""
    click.echo(f"Saving to {path}...")


if __name__ == "__main__":
    main()
