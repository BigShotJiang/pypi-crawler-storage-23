"""factq — Your LLM's Local Source of Truth."""

__version__ = "0.1.0"
