# Architecture Decision Records

This directory contains Architecture Decision Records (ADRs) for the factq project.

## Index

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| [001](001-rlm-over-rag.md) | Use RLM over RAG for knowledge retrieval | Accepted | 2026-02-28 |

## Template

Use `TEMPLATE.md` when creating new ADRs. Number sequentially (e.g., `002-title.md`).
