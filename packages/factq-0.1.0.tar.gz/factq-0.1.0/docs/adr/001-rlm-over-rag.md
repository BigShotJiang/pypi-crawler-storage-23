# ADR-001: Use RLM Over RAG for Knowledge Retrieval

## Status

Accepted

## Context

Traditional RAG (Retrieval-Augmented Generation) requires embedding models (3-6 GB VRAM), vector databases, and chunk-based similarity search. This creates significant infrastructure overhead and produces results based on text similarity rather than verified truth.

The Recursive Language Model (RLM) paradigm (Zhang, Kraska, Khattab 2025) treats knowledge as variables to be explored programmatically. Instead of embedding and retrieving chunks, the LLM writes code to navigate, read, and cross-reference knowledge sources.

## Decision

factq uses RLM instead of RAG for knowledge retrieval and verification. The LLM generates Python code to:

1. Navigate the knowledge base structure
2. Read and parse relevant documents
3. Cross-reference multiple sources
4. Verify facts through executable code

Code execution happens in a sandboxed environment with five layers of security.

## Consequences

**Easier:**
- Zero VRAM overhead (no embedding models or vector databases)
- Deterministic verification (code either produces the answer or fails)
- Handles dependency chains that similarity search cannot follow
- Works fully offline with no cloud infrastructure

**Harder:**
- Requires a capable LLM backend for code generation
- Sandbox security must be maintained rigorously
- Latency is higher than vector similarity search for simple lookups (mitigated by KB cache)
