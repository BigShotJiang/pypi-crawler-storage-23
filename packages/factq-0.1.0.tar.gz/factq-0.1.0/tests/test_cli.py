"""Tests for the factq CLI."""

from __future__ import annotations

from click.testing import CliRunner

from factq.cli import main


def test_version() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_init_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["init"])
    assert result.exit_code == 0
    assert "Initializing factq" in result.output


def test_query_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["query", "What version of Python?"])
    assert result.exit_code == 0
    assert "Querying:" in result.output


def test_save_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["save", "docs/test.md"])
    assert result.exit_code == 0
    assert "Saving to" in result.output
