from imbue import mng


def test_import():
    assert mng
