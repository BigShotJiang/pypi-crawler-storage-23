# test-pkg

A minimal fixture package used by mcp-release-guardian tests.
