# Changelog

## [0.1.0] - 2024-01-01

- Initial release
