from setuptools import setup

setup(
    name="hashtools32",
    version="2.1.0",
    packages=["hashtools32"],  # явно указываем папку с кодом
    install_requires=["requests"],
)