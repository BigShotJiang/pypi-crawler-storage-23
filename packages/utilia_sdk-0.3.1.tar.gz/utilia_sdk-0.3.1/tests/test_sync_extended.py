"""Tests extendidos para la versión síncrona del SDK."""

from __future__ import annotations

import httpx
import pytest
import respx

from utilia_sdk import (
    AddMessageInput,
    CreateTicketInput,
    CreateTicketUser,
    TicketFilters,
    TicketStatus,
    UtiliaSDKSync,
)
from utilia_sdk.errors import ErrorCode, UtiliaSDKError

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestSyncTickets:
    """Tests de tickets con la versión síncrona."""

    def test_listar_tickets_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/tickets").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "tickets": [
                            {
                                "id": "t-1",
                                "ticketKey": "APP-0001",
                                "title": "Problema de pago",
                                "category": "PROBLEMA",
                                "priority": "ALTA",
                                "status": "OPEN",
                                "unreadByExternal": 2,
                                "createdAt": "2026-02-28T00:00:00Z",
                                "lastActivityAt": "2026-02-28T12:00:00Z",
                            }
                        ],
                        "pagination": {
                            "page": 1,
                            "limit": 20,
                            "total": 1,
                            "totalPages": 1,
                        },
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                result = sdk.tickets.list("user-1")

            assert len(result.data) == 1
            assert result.data[0].ticket_key == "APP-0001"
            assert result.pagination.total == 1

    def test_listar_tickets_con_filtros_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            route = mock_api.get("/external/v1/tickets").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "tickets": [],
                        "pagination": {
                            "page": 1,
                            "limit": 10,
                            "total": 0,
                            "totalPages": 0,
                        },
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                sdk.tickets.list(
                    "user-1", TicketFilters(status=TicketStatus.OPEN, limit=10)
                )

            request_url = str(route.calls[0].request.url)
            assert "userId=user-1" in request_url

    def test_obtener_ticket_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/tickets/t-1").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "id": "t-1",
                        "ticketKey": "APP-0001",
                        "title": "Problema",
                        "description": "Descripción del problema",
                        "category": "PROBLEMA",
                        "priority": "ALTA",
                        "status": "OPEN",
                        "createdAt": "2026-02-28T00:00:00Z",
                        "lastActivityAt": "2026-02-28T12:00:00Z",
                        "messages": [],
                        "attachments": [],
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                ticket = sdk.tickets.get("t-1", "user-1")

            assert ticket.id == "t-1"
            assert ticket.description == "Descripción del problema"

    def test_agregar_mensaje_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets/t-1/messages").mock(
                return_value=httpx.Response(
                    201,
                    json={
                        "id": "m-1",
                        "content": "Gracias por la respuesta",
                        "createdAt": "2026-02-28T13:00:00Z",
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                msg = sdk.tickets.add_message(
                    "t-1", "user-1", AddMessageInput(content="Gracias por la respuesta")
                )

            assert msg.id == "m-1"
            assert msg.content == "Gracias por la respuesta"

    def test_cerrar_ticket_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.patch("/external/v1/tickets/t-1/close").mock(
                return_value=httpx.Response(204)
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                sdk.tickets.close("t-1", "user-1")

    def test_reabrir_ticket_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.patch("/external/v1/tickets/t-1/reopen").mock(
                return_value=httpx.Response(204)
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                sdk.tickets.reopen("t-1", "user-1")

    def test_mensajes_no_leidos_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/tickets/unread-count").mock(
                return_value=httpx.Response(200, json={"count": 5})
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                unread = sdk.tickets.get_unread_count("user-1")

            assert unread.count == 5


class TestSyncUsers:
    """Tests de usuarios con la versión síncrona."""

    def test_listar_usuarios_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/users").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "users": [
                            {
                                "id": "u-1",
                                "appId": "a-1",
                                "externalId": "ext-1",
                                "email": "user@test.com",
                                "lastSeenAt": "2026-02-28T00:00:00Z",
                            }
                        ],
                        "pagination": {
                            "page": 1,
                            "limit": 20,
                            "total": 1,
                            "totalPages": 1,
                        },
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                result = sdk.users.list()

            assert len(result.data) == 1
            assert result.data[0].external_id == "ext-1"


class TestSyncErrors:
    """Tests de errores HTTP con la versión síncrona."""

    def test_error_401_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/files/quota").mock(
                return_value=httpx.Response(
                    401, json={"message": "API Key inválida"}
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key="bad", retry_attempts=1
            ) as sdk:
                with pytest.raises(UtiliaSDKError) as exc_info:
                    sdk.files.get_quota()

            assert exc_info.value.code == ErrorCode.UNAUTHORIZED

    def test_error_404_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/tickets/inexistente").mock(
                return_value=httpx.Response(
                    404, json={"message": "Ticket no encontrado"}
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                with pytest.raises(UtiliaSDKError) as exc_info:
                    sdk.tickets.get("inexistente", "user-1")

            assert exc_info.value.code == ErrorCode.NOT_FOUND

    def test_error_422_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets").mock(
                return_value=httpx.Response(
                    422, json={"message": "Error de validacion del servidor"}
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                with pytest.raises(UtiliaSDKError) as exc_info:
                    sdk.tickets.create(
                        CreateTicketInput(
                            user=CreateTicketUser(external_id="u-1"),
                            title="Titulo valido para el test",
                            description="Descripcion valida para pasar la validacion client-side",
                        )
                    )

            assert exc_info.value.code == ErrorCode.VALIDATION_ERROR
