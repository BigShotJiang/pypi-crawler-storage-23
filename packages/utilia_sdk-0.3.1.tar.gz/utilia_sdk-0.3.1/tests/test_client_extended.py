"""Tests extendidos para el cliente HTTP: 429, 5xx retry, x-request-id, build_sse_url."""

from __future__ import annotations

import httpx
import pytest
import respx

from utilia_sdk import UtiliaSDK
from utilia_sdk.errors import ErrorCode, UtiliaSDKError

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestHttpErrorCodes:
    """Tests para mapeo de códigos HTTP a ErrorCode."""

    async def test_error_429_rate_limited(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(
                429, json={"message": "Too many requests"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.RATE_LIMITED
        assert exc_info.value.status_code == 429
        assert exc_info.value.is_rate_limited is True
        assert exc_info.value.is_retryable is True

    async def test_error_502_bad_gateway(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(502, json={"message": "Bad Gateway"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.UNKNOWN
        assert exc_info.value.status_code == 502

    async def test_error_503_service_unavailable(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(503, json={"message": "Service Unavailable"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.status_code == 503

    async def test_error_504_gateway_timeout(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(504, json={"message": "Gateway Timeout"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.status_code == 504

    async def test_error_400_validation(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/test").mock(
            return_value=httpx.Response(
                400, json={"message": "Campo título es requerido"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.post("/test", {"bad": True})

        assert exc_info.value.code == ErrorCode.VALIDATION_ERROR
        assert "título" in exc_info.value.message


class TestRetryLogic:
    """Tests para lógica de reintentos."""

    async def test_retry_en_500(self, mock_api: respx.MockRouter) -> None:
        """Los errores 500+ deben reintentarse."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(500, json={"message": "Error interno"})
            return httpx.Response(200, json={"ok": True})

        mock_api.get("/test").mock(side_effect=side_effect)

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=3
        ) as sdk:
            result = await sdk._client.get("/test")

        assert result == {"ok": True}
        assert call_count == 3

    async def test_retry_en_429(self, mock_api: respx.MockRouter) -> None:
        """Los errores 429 deben reintentarse."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(429, json={"message": "Rate limit"})
            return httpx.Response(200, json={"ok": True})

        mock_api.get("/test").mock(side_effect=side_effect)

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=3
        ) as sdk:
            result = await sdk._client.get("/test")

        assert result == {"ok": True}
        assert call_count == 2

    async def test_no_retry_en_401(self, mock_api: respx.MockRouter) -> None:
        """Los errores 401 NO deben reintentarse."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return httpx.Response(401, json={"message": "Unauthorized"})

        mock_api.get("/test").mock(side_effect=side_effect)

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=3
        ) as sdk:
            with pytest.raises(UtiliaSDKError):
                await sdk._client.get("/test")

        # Solo 1 intento, sin reintentos
        assert call_count == 1

    async def test_no_retry_en_404(self, mock_api: respx.MockRouter) -> None:
        """Los errores 404 NO deben reintentarse."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            return httpx.Response(404, json={"message": "Not found"})

        mock_api.get("/test").mock(side_effect=side_effect)

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=3
        ) as sdk:
            with pytest.raises(UtiliaSDKError):
                await sdk._client.get("/test")

        assert call_count == 1

    async def test_reintentos_agotados(self, mock_api: respx.MockRouter) -> None:
        """Si se agotan los reintentos, lanza el último error."""
        mock_api.get("/test").mock(
            return_value=httpx.Response(500, json={"message": "Siempre falla"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=2
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.status_code == 500
        assert "Siempre falla" in exc_info.value.message


class TestRequestId:
    """Tests para el header x-request-id."""

    async def test_envia_x_request_id(self, mock_api: respx.MockRouter) -> None:
        route = mock_api.get("/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk._client.get("/test")

        request = route.calls[0].request
        request_id = request.headers.get("x-request-id")
        assert request_id is not None
        assert len(request_id) == 36  # UUID format

    async def test_request_id_unico_por_peticion(
        self, mock_api: respx.MockRouter
    ) -> None:
        route = mock_api.get("/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk._client.get("/test")
            await sdk._client.get("/test")

        id1 = route.calls[0].request.headers["x-request-id"]
        id2 = route.calls[1].request.headers["x-request-id"]
        assert id1 != id2


class TestBuildSseUrl:
    """Tests para construcción de URL SSE."""

    async def test_build_sse_url_basica(self) -> None:
        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            url = sdk._client.build_sse_url("/stream/job-1")

        assert url == f"{BASE_URL}/stream/job-1?apiKey={API_KEY}"

    async def test_build_sse_url_con_query_existente(self) -> None:
        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            url = sdk._client.build_sse_url("/stream/job-1?param=value")

        assert "param=value" in url
        assert "&apiKey=" in url

    async def test_build_sse_url_codifica_caracteres(self) -> None:
        """Verifica que la apiKey se codifica correctamente."""
        key_con_especiales = "key+with/special=chars"
        async with UtiliaSDK(
            base_url=BASE_URL, api_key=key_con_especiales, retry_attempts=1
        ) as sdk:
            url = sdk._client.build_sse_url("/stream/job-1")

        # Los caracteres especiales deben estar codificados
        assert "key+with/special=chars" not in url
        assert "key%2Bwith%2Fspecial%3Dchars" in url


class TestErrorProperties:
    """Tests para las propiedades del UtiliaSDKError."""

    async def test_error_contiene_request_id(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(
                404,
                json={"message": "No encontrado"},
                headers={"x-request-id": "server-req-123"},
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.request_id == "server-req-123"

    async def test_error_contiene_error_code(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.post("/test").mock(
            return_value=httpx.Response(
                422,
                json={
                    "message": "Título muy corto",
                    "errorCode": "TITLE_TOO_SHORT",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.post("/test", {})

        assert exc_info.value.error_code == "TITLE_TOO_SHORT"

    async def test_error_sin_json_body(self, mock_api: respx.MockRouter) -> None:
        """El servidor puede responder sin JSON (ej: nginx 502)."""
        mock_api.get("/test").mock(
            return_value=httpx.Response(502, text="Bad Gateway")
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        # Debe usar mensaje por defecto, no fallar al parsear
        assert exc_info.value.status_code == 502
