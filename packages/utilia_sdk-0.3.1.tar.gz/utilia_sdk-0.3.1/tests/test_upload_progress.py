"""Tests para el progreso de subida de archivos."""

from __future__ import annotations

import io

import httpx
import pytest
import respx

from utilia_sdk import UtiliaSDK, UtiliaSDKSync
from utilia_sdk._progress import ProgressFileWrapper, get_file_size

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestProgressFileWrapper:
    """Tests unitarios del ProgressFileWrapper."""

    def test_reporta_progreso_al_leer(self) -> None:
        data = b"x" * 100
        file_obj = io.BytesIO(data)
        progress_values: list[int] = []
        wrapper = ProgressFileWrapper(file_obj, 100, progress_values.append)

        wrapper.read(50)
        assert progress_values[-1] == 50

        wrapper.read(50)
        assert progress_values[-1] == 100

    def test_progreso_alcanza_100(self) -> None:
        data = b"x" * 77
        file_obj = io.BytesIO(data)
        progress_values: list[int] = []
        wrapper = ProgressFileWrapper(file_obj, 77, progress_values.append)

        wrapper.read(-1)  # Leer todo
        assert progress_values[-1] == 100

    def test_lectura_vacia_no_reporta(self) -> None:
        file_obj = io.BytesIO(b"")
        progress_values: list[int] = []
        wrapper = ProgressFileWrapper(file_obj, 0, progress_values.append)

        wrapper.read(-1)
        assert len(progress_values) == 0

    def test_name_property(self) -> None:
        file_obj = io.BytesIO(b"data")
        file_obj.name = "test.txt"
        wrapper = ProgressFileWrapper(file_obj, 4, lambda _: None)
        assert wrapper.name == "test.txt"


class TestGetFileSize:
    """Tests para get_file_size."""

    def test_tamano_correcto(self) -> None:
        data = b"x" * 42
        file_obj = io.BytesIO(data)
        assert get_file_size(file_obj) == 42

    def test_mantiene_posicion(self) -> None:
        file_obj = io.BytesIO(b"x" * 100)
        file_obj.seek(30)
        get_file_size(file_obj)
        assert file_obj.tell() == 30


class TestUploadWithProgress:
    """Tests de integracion del upload con progreso."""

    async def test_upload_con_progreso_async(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/files/upload").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "f-1",
                    "originalName": "test.txt",
                    "mimeType": "text/plain",
                    "size": 100,
                    "downloadUrl": "https://example.com/f-1",
                    "createdAt": "2026-03-01T00:00:00Z",
                },
            )
        )
        progress_values: list[int] = []

        async with UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
            result = await sdk.files.upload(
                io.BytesIO(b"x" * 100),
                name="test.txt",
                on_progress=progress_values.append,
            )

        assert result.id == "f-1"
        assert len(progress_values) > 0
        assert progress_values[-1] == 100

    async def test_upload_sin_progreso_async(self, mock_api: respx.MockRouter) -> None:
        """Retrocompatibilidad: upload sin on_progress sigue funcionando."""
        mock_api.post("/external/v1/files/upload").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "f-2",
                    "originalName": "test.txt",
                    "mimeType": "text/plain",
                    "size": 50,
                    "downloadUrl": "https://example.com/f-2",
                    "createdAt": "2026-03-01T00:00:00Z",
                },
            )
        )

        async with UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
            result = await sdk.files.upload(io.BytesIO(b"x" * 50), name="test.txt")

        assert result.id == "f-2"

    def test_upload_con_progreso_sync(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/files/upload").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "id": "f-3",
                        "originalName": "test.txt",
                        "mimeType": "text/plain",
                        "size": 100,
                        "downloadUrl": "https://example.com/f-3",
                        "createdAt": "2026-03-01T00:00:00Z",
                    },
                )
            )
            progress_values: list[int] = []

            with UtiliaSDKSync(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
                result = sdk.files.upload(
                    io.BytesIO(b"x" * 100),
                    name="test.txt",
                    on_progress=progress_values.append,
                )

            assert result.id == "f-3"
            assert len(progress_values) > 0
