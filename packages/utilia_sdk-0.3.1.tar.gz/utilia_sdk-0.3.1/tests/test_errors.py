"""Tests para el modulo de errores del SDK."""

from utilia_sdk.errors import ErrorCode, UtiliaSDKError


class TestErrorCode:
    """Tests para el enum ErrorCode."""

    def test_valores_del_enum(self) -> None:
        assert ErrorCode.UNAUTHORIZED == "UNAUTHORIZED"
        assert ErrorCode.FORBIDDEN == "FORBIDDEN"
        assert ErrorCode.NOT_FOUND == "NOT_FOUND"
        assert ErrorCode.RATE_LIMITED == "RATE_LIMITED"
        assert ErrorCode.VALIDATION_ERROR == "VALIDATION_ERROR"
        assert ErrorCode.NETWORK_ERROR == "NETWORK_ERROR"
        assert ErrorCode.UNKNOWN == "UNKNOWN"


class TestUtiliaSDKError:
    """Tests para la clase UtiliaSDKError."""

    def test_crear_error(self) -> None:
        error = UtiliaSDKError(ErrorCode.UNAUTHORIZED, "API Key invalida")
        assert error.code == ErrorCode.UNAUTHORIZED
        assert error.message == "API Key invalida"
        assert str(error) == "API Key invalida"
        assert error.timestamp is not None

    def test_is_rate_limited(self) -> None:
        error = UtiliaSDKError(ErrorCode.RATE_LIMITED, "Demasiadas peticiones")
        assert error.is_rate_limited is True
        assert error.is_unauthorized is False

    def test_is_unauthorized(self) -> None:
        error = UtiliaSDKError(ErrorCode.UNAUTHORIZED, "No autorizado")
        assert error.is_unauthorized is True
        assert error.is_rate_limited is False

    def test_is_retryable(self) -> None:
        assert UtiliaSDKError(ErrorCode.RATE_LIMITED, "").is_retryable is True
        assert UtiliaSDKError(ErrorCode.NETWORK_ERROR, "").is_retryable is True
        assert UtiliaSDKError(ErrorCode.UNAUTHORIZED, "").is_retryable is False
        assert UtiliaSDKError(ErrorCode.NOT_FOUND, "").is_retryable is False
        assert UtiliaSDKError(ErrorCode.VALIDATION_ERROR, "").is_retryable is False

    def test_to_dict(self) -> None:
        error = UtiliaSDKError(ErrorCode.NOT_FOUND, "No encontrado")
        d = error.to_dict()
        assert d["name"] == "UtiliaSDKError"
        assert d["code"] == "NOT_FOUND"
        assert d["message"] == "No encontrado"
        assert "timestamp" in d

    def test_repr(self) -> None:
        error = UtiliaSDKError(ErrorCode.UNKNOWN, "Error desconocido")
        assert "UNKNOWN" in repr(error)
        assert "Error desconocido" in repr(error)

    def test_hereda_de_exception(self) -> None:
        error = UtiliaSDKError(ErrorCode.FORBIDDEN, "Denegado")
        assert isinstance(error, Exception)
