"""Tests extendidos para el servicio de IA: transcripción asíncrona, tracking y report_error."""

from __future__ import annotations

import httpx
import respx

from utilia_sdk import (
    ReportClientErrorParams,
    TrackAiActionInput,
    TranscriptionJobStatus,
    UtiliaSDK,
    UtiliaSDKSync,
)

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestAiTranscriptionAsync:
    """Tests para transcripción asíncrona (audios largos)."""

    async def test_request_transcription(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets/ai-transcribe-async").mock(
            return_value=httpx.Response(200, json={"jobId": "tr-job-1"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            job_id = await sdk.ai.request_transcription("base64audio==", "audio.webm")

        assert job_id == "tr-job-1"

    async def test_get_transcription_status_completed(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.get("/external/v1/tickets/ai-transcribe/tr-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "completed",
                    "progress": 100,
                    "transcription": "Hola, necesito ayuda con mi pedido.",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            status = await sdk.ai.get_transcription_status("tr-1")

        assert isinstance(status, TranscriptionJobStatus)
        assert status.status == "completed"
        assert status.transcription == "Hola, necesito ayuda con mi pedido."
        assert status.progress == 100

    async def test_get_transcription_status_processing(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.get("/external/v1/tickets/ai-transcribe/tr-2").mock(
            return_value=httpx.Response(
                200,
                json={"status": "processing", "progress": 45},
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            status = await sdk.ai.get_transcription_status("tr-2")

        assert status.status == "processing"
        assert status.progress == 45
        assert status.transcription is None

    async def test_get_transcription_status_failed(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.get("/external/v1/tickets/ai-transcribe/tr-3").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "failed",
                    "error": "Formato de audio no soportado",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            status = await sdk.ai.get_transcription_status("tr-3")

        assert status.status == "failed"
        assert status.error == "Formato de audio no soportado"


class TestAiTracking:
    """Tests para tracking de acciones y reporte de errores."""

    async def test_track_ai_action(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets/ai-track-action").mock(
            return_value=httpx.Response(200, json={"tracked": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.ai.track_ai_action(
                TrackAiActionInput(
                    event_id="ev-123",
                    user_action="ACCEPTED_ALL",
                    fields_accepted=["title", "description", "category"],
                    time_to_decision_ms=2500,
                )
            )

        assert result["tracked"] is True

    async def test_track_ai_action_partial(self, mock_api: respx.MockRouter) -> None:
        route = mock_api.post("/external/v1/tickets/ai-track-action").mock(
            return_value=httpx.Response(200, json={"tracked": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.ai.track_ai_action(
                TrackAiActionInput(
                    event_id="ev-456",
                    user_action="ACCEPTED_PARTIAL",
                    fields_accepted=["title"],
                    fields_modified=["description"],
                    fields_rejected=["category"],
                )
            )

        # Verificar que se enviaron los alias camelCase
        import json

        body = json.loads(route.calls[0].request.content)
        assert body["eventId"] == "ev-456"
        assert body["userAction"] == "ACCEPTED_PARTIAL"
        assert body["fieldsAccepted"] == ["title"]

    async def test_report_error_silencioso(self, mock_api: respx.MockRouter) -> None:
        """report_error nunca debe lanzar excepciones."""
        mock_api.post("/external/v1/tickets/client-errors").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            # No debe lanzar excepción
            await sdk.ai.report_error(
                ReportClientErrorParams(
                    message="Error en el formulario",
                    stack="at form.py:10",
                    code="FORM_ERROR",
                    component="form",
                    endpoint="/api/tickets",
                    method="POST",
                )
            )

    async def test_report_error_falla_silenciosamente(
        self, mock_api: respx.MockRouter
    ) -> None:
        """Aunque el servidor falle, report_error NO lanza excepción."""
        mock_api.post("/external/v1/tickets/client-errors").mock(
            return_value=httpx.Response(500, json={"error": "Internal"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            # No debe lanzar excepción a pesar del 500
            await sdk.ai.report_error(
                ReportClientErrorParams(message="Error crítico")
            )


class TestAiSyncExtended:
    """Tests extendidos para la versión síncrona del servicio de IA."""

    def test_request_transcription_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets/ai-transcribe-async").mock(
                return_value=httpx.Response(200, json={"jobId": "tr-sync-1"})
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                job_id = sdk.ai.request_transcription("base64==", "audio.mp3")

            assert job_id == "tr-sync-1"

    def test_get_transcription_status_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/tickets/ai-transcribe/tr-s1").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "status": "completed",
                        "progress": 100,
                        "transcription": "Texto transcrito.",
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                status = sdk.ai.get_transcription_status("tr-s1")

            assert status.status == "completed"
            assert status.transcription == "Texto transcrito."

    def test_track_ai_action_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets/ai-track-action").mock(
                return_value=httpx.Response(200, json={"tracked": True})
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                result = sdk.ai.track_ai_action(
                    TrackAiActionInput(
                        event_id="ev-sync",
                        user_action="REJECTED",
                    )
                )

            assert result["tracked"] is True

    def test_report_error_sincrono_silencioso(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets/client-errors").mock(
                return_value=httpx.Response(500, json={"error": "fail"})
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                # No debe lanzar excepción
                sdk.ai.report_error(
                    ReportClientErrorParams(message="Error sync")
                )
