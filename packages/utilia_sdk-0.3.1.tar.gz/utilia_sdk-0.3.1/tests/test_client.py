"""Tests para el cliente HTTP del SDK."""

from __future__ import annotations

import httpx
import pytest
import respx

from utilia_sdk import UtiliaSDK
from utilia_sdk.errors import ErrorCode, UtiliaSDKError

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestUtiliaClient:
    """Tests para el cliente HTTP asincrono."""

    async def test_headers_correctos(self, mock_api: respx.MockRouter) -> None:
        """Verifica que se envien los headers de autenticacion."""
        route = mock_api.get("/test").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk._client.get("/test")

        request = route.calls[0].request
        assert request.headers["x-api-key"] == API_KEY

    async def test_error_401_unauthorized(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(
                401, json={"message": "API Key invalida"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key="bad-key", retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.UNAUTHORIZED

    async def test_error_403_rate_limited(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(
                403, json={"message": "Rate limit excedido"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.RATE_LIMITED

    async def test_error_403_forbidden(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(403, json={"message": "Acceso denegado"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.FORBIDDEN

    async def test_error_404_not_found(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(404, json={"message": "No encontrado"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.NOT_FOUND

    async def test_error_422_validation(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/test").mock(
            return_value=httpx.Response(
                422, json={"message": "Campo requerido"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.post("/test", {"bad": "data"})

        assert exc_info.value.code == ErrorCode.VALIDATION_ERROR

    async def test_error_500_servidor(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(500, json={"message": "Error interno"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(UtiliaSDKError) as exc_info:
                await sdk._client.get("/test")

        assert exc_info.value.code == ErrorCode.UNKNOWN

    async def test_respuesta_204_sin_contenido(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.patch("/test").mock(return_value=httpx.Response(204))

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk._client.patch("/test")

        assert result is None

    async def test_reintentos_con_error_recuperable(
        self, mock_api: respx.MockRouter
    ) -> None:
        """Verifica reintentos con backoff para errores recuperables."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(
                    403, json={"message": "Rate limit excedido"}
                )
            return httpx.Response(200, json={"ok": True})

        mock_api.get("/test").mock(side_effect=side_effect)

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=3
        ) as sdk:
            result = await sdk._client.get("/test")

        assert result == {"ok": True}
        assert call_count == 3

    async def test_context_manager(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/test").mock(
            return_value=httpx.Response(200, json={"data": "ok"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk._client.get("/test")
            assert result == {"data": "ok"}

    async def test_params_none_filtrados(self, mock_api: respx.MockRouter) -> None:
        """Verifica que los params con valor None se filtren."""
        route = mock_api.get("/test").mock(
            return_value=httpx.Response(200, json={})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk._client.get("/test", params={"a": "1", "b": None})

        request = route.calls[0].request
        assert "a=1" in str(request.url)
        assert "b=" not in str(request.url)
