"""Tests para la versión síncrona del SDK."""

from __future__ import annotations

import httpx
import respx

from utilia_sdk import (
    CreateTicketInput,
    CreateTicketUser,
    IdentifyUserInput,
    UtiliaSDKSync,
)

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestSyncSDK:
    """Tests para la versión síncrona del SDK."""

    def test_crear_ticket_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/tickets").mock(
                return_value=httpx.Response(
                    201,
                    json={
                        "id": "t-1",
                        "ticketKey": "APP-0001",
                        "title": "Test",
                        "status": "OPEN",
                        "createdAt": "2024-01-01T00:00:00Z",
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                ticket = sdk.tickets.create(
                    CreateTicketInput(
                        user=CreateTicketUser(external_id="u-1"),
                        title="Test de prueba",
                        description="Descripcion de prueba para el test",
                    )
                )

            assert ticket.id == "t-1"
            assert ticket.ticket_key == "APP-0001"

    def test_identificar_usuario_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/users/identify").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "id": "i-1",
                        "appId": "a-1",
                        "externalId": "u-1",
                        "email": "test@test.com",
                        "lastSeenAt": "2024-01-01T00:00:00Z",
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                user = sdk.users.identify(
                    IdentifyUserInput(external_id="u-1", email="test@test.com")
                )

            assert user.external_id == "u-1"

    def test_obtener_quota_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/files/quota").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "usedBytes": 1000,
                        "maxBytes": 1000000,
                        "maxFileSizeBytes": 50000,
                        "usagePercent": 0.1,
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                quota = sdk.files.get_quota()

            assert quota.used_bytes == 1000

    def test_context_manager_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/files/quota").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "usedBytes": 0,
                        "maxBytes": 1000000,
                        "maxFileSizeBytes": 50000,
                        "usagePercent": 0.0,
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                quota = sdk.files.get_quota()
                assert quota.max_bytes == 1000000


