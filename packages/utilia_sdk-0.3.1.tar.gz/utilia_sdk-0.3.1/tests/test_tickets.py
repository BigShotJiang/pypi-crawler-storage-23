"""Tests para el servicio de tickets."""

from __future__ import annotations

import httpx
import respx

from utilia_sdk import (
    AddMessageInput,
    CreateTicketInput,
    CreateTicketUser,
    TicketFilters,
    TicketStatus,
    UtiliaSDK,
)

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestTicketsService:
    """Tests para el servicio asincrono de tickets."""

    async def test_crear_ticket(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "ticket-1",
                    "ticketKey": "APP-0001",
                    "title": "Problema de prueba",
                    "status": "OPEN",
                    "createdAt": "2024-01-01T00:00:00Z",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            ticket = await sdk.tickets.create(
                CreateTicketInput(
                    user=CreateTicketUser(external_id="user-123"),
                    title="Problema de prueba",
                    description="Descripcion del problema de prueba",
                )
            )

        assert ticket.id == "ticket-1"
        assert ticket.ticket_key == "APP-0001"
        assert ticket.status == TicketStatus.OPEN

    async def test_listar_tickets(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/tickets").mock(
            return_value=httpx.Response(
                200,
                json={
                    "tickets": [
                        {
                            "id": "t-1",
                            "ticketKey": "APP-0001",
                            "title": "Ticket 1",
                            "category": "PROBLEMA",
                            "priority": "MEDIA",
                            "status": "OPEN",
                            "unreadByExternal": 2,
                            "createdAt": "2024-01-01T00:00:00Z",
                            "lastActivityAt": "2024-01-02T00:00:00Z",
                        }
                    ],
                    "pagination": {
                        "page": 1,
                        "limit": 20,
                        "total": 1,
                        "totalPages": 1,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.tickets.list("user-123")

        assert len(result.data) == 1
        assert result.data[0].ticket_key == "APP-0001"
        assert result.pagination.total == 1

    async def test_listar_tickets_con_filtros(
        self, mock_api: respx.MockRouter
    ) -> None:
        route = mock_api.get("/external/v1/tickets").mock(
            return_value=httpx.Response(
                200,
                json={
                    "tickets": [],
                    "pagination": {
                        "page": 2,
                        "limit": 10,
                        "total": 0,
                        "totalPages": 0,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.tickets.list(
                "user-123",
                TicketFilters(status=TicketStatus.OPEN, page=2, limit=10),
            )

        request = route.calls[0].request
        assert "userId=user-123" in str(request.url)
        assert "status=OPEN" in str(request.url)

    async def test_obtener_ticket(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/tickets/ticket-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "ticket-1",
                    "ticketKey": "APP-0001",
                    "title": "Problema",
                    "description": "Descripcion detallada",
                    "category": "PROBLEMA",
                    "priority": "ALTA",
                    "status": "OPEN",
                    "createdAt": "2024-01-01T00:00:00Z",
                    "lastActivityAt": "2024-01-02T00:00:00Z",
                    "messages": [
                        {
                            "id": "msg-1",
                            "content": "Hola",
                            "author": {
                                "type": "EXTERNAL",
                                "id": "user-123",
                                "name": "Juan",
                            },
                            "attachments": [],
                            "createdAt": "2024-01-01T00:00:00Z",
                        }
                    ],
                    "attachments": [],
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            ticket = await sdk.tickets.get("ticket-1", "user-123")

        assert ticket.id == "ticket-1"
        assert len(ticket.messages) == 1
        assert ticket.messages[0].author.type == "EXTERNAL"

    async def test_mensajes_no_leidos(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/tickets/unread-count").mock(
            return_value=httpx.Response(200, json={"count": 5})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.tickets.get_unread_count("user-123")

        assert result.count == 5

    async def test_agregar_mensaje(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets/ticket-1/messages").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "msg-2",
                    "content": "Gracias por responder",
                    "createdAt": "2024-01-03T00:00:00Z",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            msg = await sdk.tickets.add_message(
                "ticket-1",
                "user-123",
                AddMessageInput(content="Gracias por responder"),
            )

        assert msg.id == "msg-2"
        assert msg.content == "Gracias por responder"

    async def test_cerrar_ticket(self, mock_api: respx.MockRouter) -> None:
        mock_api.patch("/external/v1/tickets/ticket-1/close").mock(
            return_value=httpx.Response(204)
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.tickets.close("ticket-1", "user-123")

    async def test_reabrir_ticket(self, mock_api: respx.MockRouter) -> None:
        mock_api.patch("/external/v1/tickets/ticket-1/reopen").mock(
            return_value=httpx.Response(204)
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.tickets.reopen("ticket-1", "user-123")
