"""Tests para el servicio de archivos."""

from __future__ import annotations

import io

import httpx
import respx

from utilia_sdk import UtiliaSDK

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestFilesService:
    """Tests para el servicio asincrono de archivos."""

    async def test_subir_archivo(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/files/upload").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "file-1",
                    "originalName": "documento.pdf",
                    "mimeType": "application/pdf",
                    "size": 12345,
                    "downloadUrl": "https://cdn.utilia.ai/files/file-1",
                    "createdAt": "2024-01-01T00:00:00Z",
                },
            )
        )

        file_data = io.BytesIO(b"contenido del archivo")
        file_data.name = "documento.pdf"

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            uploaded = await sdk.files.upload(file_data, name="documento.pdf")

        assert uploaded.id == "file-1"
        assert uploaded.original_name == "documento.pdf"
        assert uploaded.mime_type == "application/pdf"
        assert uploaded.size == 12345

    async def test_obtener_url(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/files/file-1/url").mock(
            return_value=httpx.Response(
                200, json={"url": "https://cdn.utilia.ai/files/file-1"}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            url = await sdk.files.get_url("file-1")

        assert url == "https://cdn.utilia.ai/files/file-1"

    async def test_obtener_quota(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/files/quota").mock(
            return_value=httpx.Response(
                200,
                json={
                    "usedBytes": 5000000,
                    "maxBytes": 100000000,
                    "maxFileSizeBytes": 10000000,
                    "usagePercent": 5.0,
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            quota = await sdk.files.get_quota()

        assert quota.used_bytes == 5000000
        assert quota.max_bytes == 100000000
        assert quota.usage_percent == 5.0
