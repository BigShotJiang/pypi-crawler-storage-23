"""Tests para las validaciones client-side del SDK."""

from __future__ import annotations

import io

import pydantic
import pytest

from utilia_sdk import (
    AddMessageInput,
    CreateTicketInput,
    CreateTicketUser,
    IdentifyUserInput,
    ReportErrorInput,
)
from utilia_sdk.errors import UtiliaSDKError
from utilia_sdk.services.files import _prepare_upload


class TestTicketValidations:
    """Validaciones de tickets."""

    def test_ticket_title_too_short(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            CreateTicketInput(
                user=CreateTicketUser(external_id="u-1"),
                title="abc",
                description="Descripcion suficientemente larga para pasar",
            )

    def test_ticket_title_too_long(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            CreateTicketInput(
                user=CreateTicketUser(external_id="u-1"),
                title="x" * 501,
                description="Descripcion suficientemente larga para pasar",
            )

    def test_ticket_title_valid(self) -> None:
        ticket = CreateTicketInput(
            user=CreateTicketUser(external_id="u-1"),
            title="Titulo valido",
            description="Descripcion suficientemente larga para pasar",
        )
        assert ticket.title == "Titulo valido"

    def test_ticket_description_too_short(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            CreateTicketInput(
                user=CreateTicketUser(external_id="u-1"),
                title="Titulo valido",
                description="corto",
            )

    def test_message_content_empty(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            AddMessageInput(content="")

    def test_message_content_too_long(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            AddMessageInput(content="x" * 5001)

    def test_message_content_valid(self) -> None:
        msg = AddMessageInput(content="x" * 100)
        assert len(msg.content) == 100


class TestUserValidations:
    """Validaciones de usuarios."""

    def test_user_external_id_too_long(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            IdentifyUserInput(external_id="x" * 256)

    def test_user_email_invalid(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            IdentifyUserInput(external_id="u-1", email="not-an-email")

    def test_user_email_valid(self) -> None:
        user = IdentifyUserInput(external_id="u-1", email="user@test.com")
        assert user.email == "user@test.com"

    def test_user_email_none_valid(self) -> None:
        user = IdentifyUserInput(external_id="u-1", email=None)
        assert user.email is None

    def test_user_avatar_url_invalid(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            IdentifyUserInput(external_id="u-1", avatar_url="not-a-url")

    def test_user_avatar_url_valid(self) -> None:
        user = IdentifyUserInput(
            external_id="u-1", avatar_url="https://example.com/avatar.png"
        )
        assert user.avatar_url == "https://example.com/avatar.png"


class TestErrorValidations:
    """Validaciones de errores del sistema."""

    def test_error_message_empty(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            ReportErrorInput(message="  ", module="test")

    def test_error_module_empty(self) -> None:
        with pytest.raises(pydantic.ValidationError):
            ReportErrorInput(message="test", module="")

    def test_error_valid(self) -> None:
        error = ReportErrorInput(message="Error de prueba", module="checkout")
        assert error.message == "Error de prueba"
        assert error.module == "checkout"


class TestFileValidations:
    """Validaciones de archivos."""

    def test_file_name_too_long(self) -> None:
        file_data = io.BytesIO(b"contenido")
        with pytest.raises(UtiliaSDKError):
            _prepare_upload(file_data, name="x" * 256)
