"""Tests para el servicio de IA."""

from __future__ import annotations

import httpx
import pytest
import respx

from utilia_sdk import AiSuggestInput, GetSuggestionsOptions, UtiliaSDK

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestAiService:
    """Tests para el servicio asíncrono de IA."""

    async def test_request_suggestions(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-123"})
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            job_id = await sdk.ai.request_suggestions(
                AiSuggestInput(
                    user_id="user-123",
                    text="No puedo iniciar sesión",
                )
            )

        assert job_id == "job-123"

    async def test_get_suggestions_status(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/tickets/ai-suggest/job-123").mock(
            return_value=httpx.Response(
                200,
                json={
                    "status": "completed",
                    "progress": 100,
                    "result": {
                        "suggestions": {
                            "title": "Problema de inicio de sesión",
                            "description": "El usuario no puede acceder a su cuenta",
                            "category": "PROBLEMA",
                            "priority": "MEDIA",
                        }
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            status = await sdk.ai.get_suggestions_status("job-123")

        assert status.status == "completed"
        assert status.result is not None
        assert status.result.suggestions is not None
        assert status.result.suggestions.title == "Problema de inicio de sesión"

    async def test_transcribir(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/tickets/ai-transcribe").mock(
            return_value=httpx.Response(
                200, json={"transcription": "Hola, tengo un problema..."}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            text = await sdk.ai.transcribe("base64audio==", "audio.webm")

        assert text == "Hola, tengo un problema..."

    async def test_get_suggestions_polling(self, mock_api: respx.MockRouter) -> None:
        """Verifica que get_suggestions haga polling hasta completar."""
        call_count = 0

        def side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(
                    200,
                    json={"status": "pending", "progress": 0},
                )
            if call_count == 2:
                return httpx.Response(
                    200,
                    json={"status": "processing", "progress": 50},
                )
            return httpx.Response(
                200,
                json={
                    "status": "completed",
                    "progress": 100,
                    "result": {
                        "suggestions": {"title": "Título sugerido"},
                    },
                },
            )

        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-poll"})
        )
        mock_api.get("/external/v1/tickets/ai-suggest/job-poll").mock(
            side_effect=side_effect
        )

        progresses: list[int] = []

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.ai.get_suggestions(
                AiSuggestInput(user_id="u-1", text="Problema"),
                GetSuggestionsOptions(poll_interval=0.01, max_wait=5.0),
                on_progress=lambda p: progresses.append(p),
            )

        assert result is not None
        assert result.suggestions is not None
        assert result.suggestions.title == "Título sugerido"
        assert 0 in progresses
        assert 50 in progresses

    async def test_get_suggestions_timeout(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-slow"})
        )
        mock_api.get("/external/v1/tickets/ai-suggest/job-slow").mock(
            return_value=httpx.Response(
                200, json={"status": "processing", "progress": 10}
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(RuntimeError, match="Timeout"):
                await sdk.ai.get_suggestions(
                    AiSuggestInput(user_id="u-1", text="Problema"),
                    GetSuggestionsOptions(poll_interval=0.01, max_wait=0.05),
                )

    async def test_get_suggestions_failed(
        self, mock_api: respx.MockRouter
    ) -> None:
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-fail"})
        )
        mock_api.get("/external/v1/tickets/ai-suggest/job-fail").mock(
            return_value=httpx.Response(
                200,
                json={"status": "failed", "error": "Modelo no disponible"},
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            with pytest.raises(RuntimeError, match="Modelo no disponible"):
                await sdk.ai.get_suggestions(
                    AiSuggestInput(user_id="u-1", text="Problema"),
                    GetSuggestionsOptions(poll_interval=0.01),
                )


