"""Tests para abort() en streaming SSE."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
import respx

from utilia_sdk import UtiliaSDK, UtiliaSDKSync
from utilia_sdk.models.ai import AiJobResult, AiSuggestions, StreamSuggestionsHandle, SyncStreamSuggestionsHandle

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestStreamSuggestionsHandle:
    """Tests para stream_suggestions_handle() async."""

    async def test_completa_normalmente(self, mock_api: respx.MockRouter) -> None:
        """El handle debe resolver con el resultado cuando el stream completa."""
        # Mock del POST para request_suggestions
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-1"})
        )

        # Mock de stream_sse para emitir eventos
        async def fake_stream_sse(url, *, timeout=120.0, cancel_event=None):
            yield {"event": "progress", "progress": 50}
            yield {
                "event": "completed",
                "result": {
                    "suggestions": {"title": "Test", "description": "Desc"},
                    "analyticsEventId": "ev-1",
                },
            }

        async with UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
            with patch.object(sdk._client, "stream_sse", side_effect=fake_stream_sse):
                from utilia_sdk.models.ai import AiSuggestInput
                handle = await sdk.ai.stream_suggestions_handle(
                    AiSuggestInput(user_id="u-1", text="test")
                )

                assert isinstance(handle, StreamSuggestionsHandle)
                result = await handle.result

        assert result is not None
        assert result.suggestions is not None
        assert result.suggestions.title == "Test"

    async def test_abort_cancela_tarea(self, mock_api: respx.MockRouter) -> None:
        """Llamar abort() debe cancelar la tarea."""
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-2"})
        )

        async def fake_stream_sse(url, *, timeout=120.0, cancel_event=None):
            # Simular un stream largo que espera
            for i in range(100):
                if cancel_event is not None and cancel_event.is_set():
                    return
                yield {"event": "progress", "progress": i}
                await asyncio.sleep(0.01)

        async with UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
            with patch.object(sdk._client, "stream_sse", side_effect=fake_stream_sse):
                from utilia_sdk.models.ai import AiSuggestInput
                handle = await sdk.ai.stream_suggestions_handle(
                    AiSuggestInput(user_id="u-1", text="test")
                )

                # Esperar un poco y luego abortar
                await asyncio.sleep(0.05)
                handle.abort()

                result = await handle.result
                assert result is None

    async def test_stream_suggestions_original_no_cambia(self, mock_api: respx.MockRouter) -> None:
        """stream_suggestions() debe seguir funcionando igual."""
        mock_api.post("/external/v1/tickets/ai-suggest").mock(
            return_value=httpx.Response(200, json={"jobId": "job-3"})
        )

        async def fake_stream_sse(url, *, timeout=120.0, cancel_event=None):
            yield {
                "event": "completed",
                "result": {"suggestions": {"title": "OK"}},
            }

        async with UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1) as sdk:
            with patch.object(sdk._client, "stream_sse", side_effect=fake_stream_sse):
                from utilia_sdk.models.ai import AiSuggestInput
                result = await sdk.ai.stream_suggestions(
                    AiSuggestInput(user_id="u-1", text="test")
                )

        assert result is not None
        assert result.suggestions.title == "OK"
