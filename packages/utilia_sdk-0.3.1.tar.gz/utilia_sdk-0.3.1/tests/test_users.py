"""Tests para el servicio de usuarios."""

from __future__ import annotations

import httpx
import respx

from utilia_sdk import IdentifyUserInput, UtiliaSDK

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestUsersService:
    """Tests para el servicio asincrono de usuarios."""

    async def test_identificar_usuario(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/users/identify").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "internal-1",
                    "appId": "app-1",
                    "externalId": "user-123",
                    "email": "user@example.com",
                    "name": "Juan Perez",
                    "avatarUrl": None,
                    "metadata": {"plan": "premium"},
                    "lastSeenAt": "2024-01-01T00:00:00Z",
                    "_count": {"tickets": 3},
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            user = await sdk.users.identify(
                IdentifyUserInput(
                    external_id="user-123",
                    email="user@example.com",
                    name="Juan Perez",
                    metadata={"plan": "premium"},
                )
            )

        assert user.id == "internal-1"
        assert user.external_id == "user-123"
        assert user.email == "user@example.com"
        assert user.metadata == {"plan": "premium"}
        assert user.count is not None
        assert user.count.tickets == 3

    async def test_identificar_envia_camel_case(
        self, mock_api: respx.MockRouter
    ) -> None:
        """Verifica que el body se envie en camelCase."""
        route = mock_api.post("/external/v1/users/identify").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "i-1",
                    "appId": "a-1",
                    "externalId": "u-1",
                    "lastSeenAt": "2024-01-01T00:00:00Z",
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.users.identify(
                IdentifyUserInput(
                    external_id="u-1",
                    avatar_url="https://example.com/avatar.png",
                )
            )

        import json

        body = json.loads(route.calls[0].request.content)
        assert "externalId" in body
        assert "avatarUrl" in body
        assert "external_id" not in body

    async def test_listar_usuarios(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/users").mock(
            return_value=httpx.Response(
                200,
                json={
                    "users": [
                        {
                            "id": "i-1",
                            "appId": "a-1",
                            "externalId": "u-1",
                            "email": "a@b.com",
                            "name": "Ana",
                            "lastSeenAt": "2024-01-01T00:00:00Z",
                        },
                        {
                            "id": "i-2",
                            "appId": "a-1",
                            "externalId": "u-2",
                            "email": "c@d.com",
                            "name": "Carlos",
                            "lastSeenAt": "2024-01-02T00:00:00Z",
                        },
                    ],
                    "pagination": {
                        "page": 1,
                        "limit": 20,
                        "total": 2,
                        "totalPages": 1,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.users.list()

        assert len(result.data) == 2
        assert result.data[0].name == "Ana"
        assert result.pagination.total == 2

    async def test_listar_usuarios_con_paginacion(
        self, mock_api: respx.MockRouter
    ) -> None:
        route = mock_api.get("/external/v1/users").mock(
            return_value=httpx.Response(
                200,
                json={
                    "users": [],
                    "pagination": {
                        "page": 3,
                        "limit": 5,
                        "total": 12,
                        "totalPages": 3,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            await sdk.users.list(page=3, limit=5)

        request = route.calls[0].request
        assert "page=3" in str(request.url)
        assert "limit=5" in str(request.url)
