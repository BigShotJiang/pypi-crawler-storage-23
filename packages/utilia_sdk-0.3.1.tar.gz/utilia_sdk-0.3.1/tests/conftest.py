"""Fixtures compartidos para los tests del SDK."""

from __future__ import annotations

import pytest
import respx

from utilia_sdk import UtiliaSDK, UtiliaSDKSync

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


@pytest.fixture()
def mock_api() -> respx.MockRouter:
    """Router de respx para mockear peticiones HTTP."""
    with respx.mock(base_url=BASE_URL) as router:
        yield router


@pytest.fixture()
async def sdk() -> UtiliaSDK:
    """Instancia del SDK asincrono para tests."""
    client = UtiliaSDK(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1)
    yield client  # type: ignore[misc]
    await client.close()


@pytest.fixture()
def sync_sdk() -> UtiliaSDKSync:
    """Instancia del SDK sincrono para tests."""
    client = UtiliaSDKSync(base_url=BASE_URL, api_key=API_KEY, retry_attempts=1)
    yield client  # type: ignore[misc]
    client.close()
