"""Tests para el servicio de errores del sistema."""

from __future__ import annotations

import httpx
import respx

from utilia_sdk import (
    ErrorFilters,
    ErrorStats,
    ReportedError,
    ReportErrorInput,
    SystemErrorEntry,
    UtiliaSDK,
    UtiliaSDKSync,
)

BASE_URL = "https://test.utilia.ai/api"
API_KEY = "test-api-key-12345"


class TestErrorsService:
    """Tests para el servicio asíncrono de errores."""

    async def test_reportar_error_completo(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/errors/report").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "hash": "abc123def",
                    "deduplicated": False,
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.errors.report(
                ReportErrorInput(
                    message="TypeError: undefined is not a function",
                    module="checkout",
                    severity="high",
                    stack="at checkout.js:42",
                    file="checkout.js",
                    line=42,
                    function="processPayment",
                    endpoint="/api/payments",
                    method="POST",
                )
            )

        assert isinstance(result, ReportedError)
        assert result.success is True
        assert result.hash == "abc123def"
        assert result.deduplicated is False

    async def test_reportar_error_minimo(self, mock_api: respx.MockRouter) -> None:
        """Solo los campos requeridos (message y module)."""
        route = mock_api.post("/external/v1/errors/report").mock(
            return_value=httpx.Response(
                200,
                json={"success": True, "hash": "min123", "deduplicated": False},
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.errors.report(
                ReportErrorInput(message="Error genérico", module="app")
            )

        assert result.success is True
        # Verificar que no se envían campos None
        body = route.calls[0].request.content
        assert b"stack" not in body
        assert b"file" not in body

    async def test_reportar_error_deduplicado(self, mock_api: respx.MockRouter) -> None:
        mock_api.post("/external/v1/errors/report").mock(
            return_value=httpx.Response(
                200,
                json={"success": True, "hash": "dup456", "deduplicated": True},
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.errors.report(
                ReportErrorInput(
                    message="Error repetido", module="auth", severity="medium"
                )
            )

        assert result.deduplicated is True
        assert result.hash == "dup456"

    async def test_listar_errores_sin_filtros(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/errors").mock(
            return_value=httpx.Response(
                200,
                json={
                    "errors": [
                        {
                            "id": "err-1",
                            "hash": "h1",
                            "message": "NullPointerException",
                            "module": "users",
                            "severity": "critical",
                            "count": 15,
                            "firstOccurrence": "2026-01-01T00:00:00Z",
                            "lastOccurrence": "2026-02-28T12:00:00Z",
                            "resolved": False,
                        },
                        {
                            "id": "err-2",
                            "hash": "h2",
                            "message": "Timeout en DB",
                            "module": "database",
                            "severity": "high",
                            "count": 3,
                            "firstOccurrence": "2026-02-20T00:00:00Z",
                            "lastOccurrence": "2026-02-28T10:00:00Z",
                            "resolved": True,
                            "resolvedAt": "2026-02-28T11:00:00Z",
                        },
                    ],
                    "pagination": {
                        "page": 1,
                        "limit": 20,
                        "total": 2,
                        "totalPages": 1,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.errors.list()

        assert len(result.data) == 2
        assert result.pagination.total == 2

        err1 = result.data[0]
        assert isinstance(err1, SystemErrorEntry)
        assert err1.id == "err-1"
        assert err1.severity == "critical"
        assert err1.count == 15
        assert err1.resolved is False

        err2 = result.data[1]
        assert err2.resolved is True
        assert err2.resolved_at == "2026-02-28T11:00:00Z"

    async def test_listar_errores_con_filtros(self, mock_api: respx.MockRouter) -> None:
        route = mock_api.get("/external/v1/errors").mock(
            return_value=httpx.Response(
                200,
                json={
                    "errors": [],
                    "pagination": {
                        "page": 1,
                        "limit": 10,
                        "total": 0,
                        "totalPages": 0,
                    },
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            result = await sdk.errors.list(
                ErrorFilters(
                    severity=["critical", "high"],
                    module="checkout",
                    resolved=False,
                    limit=10,
                )
            )

        assert len(result.data) == 0
        # Verificar que los filtros se enviaron como params
        request_url = str(route.calls[0].request.url)
        assert "module=checkout" in request_url
        assert "limit=10" in request_url

    async def test_estadisticas(self, mock_api: respx.MockRouter) -> None:
        mock_api.get("/external/v1/errors/stats").mock(
            return_value=httpx.Response(
                200,
                json={
                    "total": 42,
                    "unresolved": 10,
                    "bySeverity": {
                        "critical": 2,
                        "high": 5,
                        "medium": 20,
                        "low": 15,
                    },
                    "byModule": {
                        "checkout": 12,
                        "auth": 8,
                        "users": 22,
                    },
                    "topErrors": [
                        {
                            "hash": "top1",
                            "message": "Error más frecuente",
                            "count": 22,
                            "severity": "medium",
                        },
                    ],
                },
            )
        )

        async with UtiliaSDK(
            base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
        ) as sdk:
            stats = await sdk.errors.stats()

        assert isinstance(stats, ErrorStats)
        assert stats.total == 42
        assert stats.unresolved == 10
        assert stats.by_severity["critical"] == 2
        assert stats.by_module["checkout"] == 12
        assert len(stats.top_errors) == 1
        assert stats.top_errors[0].count == 22


class TestErrorsSyncService:
    """Tests para el servicio síncrono de errores."""

    def test_reportar_error_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.post("/external/v1/errors/report").mock(
                return_value=httpx.Response(
                    200,
                    json={"success": True, "hash": "sync1", "deduplicated": False},
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                result = sdk.errors.report(
                    ReportErrorInput(message="Error sync", module="app")
                )

            assert result.success is True
            assert result.hash == "sync1"

    def test_listar_errores_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/errors").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "errors": [
                            {
                                "id": "e-sync",
                                "hash": "hs",
                                "message": "Error sync",
                                "module": "app",
                                "severity": "low",
                                "count": 1,
                                "firstOccurrence": "2026-02-28T00:00:00Z",
                                "lastOccurrence": "2026-02-28T00:00:00Z",
                                "resolved": False,
                            }
                        ],
                        "pagination": {
                            "page": 1,
                            "limit": 20,
                            "total": 1,
                            "totalPages": 1,
                        },
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                result = sdk.errors.list()

            assert len(result.data) == 1
            assert result.data[0].module == "app"

    def test_estadisticas_sincrono(self) -> None:
        with respx.mock(base_url=BASE_URL) as mock_api:
            mock_api.get("/external/v1/errors/stats").mock(
                return_value=httpx.Response(
                    200,
                    json={
                        "total": 5,
                        "unresolved": 2,
                        "bySeverity": {"low": 5},
                        "byModule": {"app": 5},
                        "topErrors": [],
                    },
                )
            )

            with UtiliaSDKSync(
                base_url=BASE_URL, api_key=API_KEY, retry_attempts=1
            ) as sdk:
                stats = sdk.errors.stats()

            assert stats.total == 5
            assert stats.unresolved == 2
