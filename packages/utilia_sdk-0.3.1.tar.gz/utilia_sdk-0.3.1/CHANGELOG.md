# Changelog

## 0.1.0 (2026-02-06)
- Lanzamiento inicial
- Soporte asíncrono (async/await) y síncrono
- Servicios: tickets, users, files, ai
- Validación con Pydantic v2
- Reintentos con backoff exponencial
- Type hints completos (mypy strict)
