"""
Cliente HTTP asíncrono para el SDK de UTILIA OS.

Maneja la comunicación con la API, incluyendo autenticación,
reintentos con backoff exponencial y mapeo de errores.
"""

from __future__ import annotations

import asyncio
import json as _json
import logging
import uuid
from collections.abc import AsyncGenerator
from typing import Any

import httpx

logger = logging.getLogger("utilia_sdk")

from utilia_sdk.errors import ErrorCode, UtiliaSDKError
from utilia_sdk.models.config import UtiliaSDKConfig


class UtiliaClient:
    """Cliente HTTP asíncrono base para comunicarse con la API de UTILIA OS.

    Implementa reintentos con backoff exponencial para errores recuperables
    (RATE_LIMITED y NETWORK_ERROR).
    """

    def __init__(self, config: UtiliaSDKConfig) -> None:
        self._config = config
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout,
            headers={
                "Content-Type": "application/json",
                "X-Api-Key": config.api_key,
            },
        )

    async def close(self) -> None:
        """Cierra la sesión HTTP."""
        await self._client.aclose()

    async def __aenter__(self) -> UtiliaClient:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # -- Métodos HTTP públicos --

    async def get(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición GET."""
        return await self._request("GET", url, params=params)

    async def post(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST."""
        return await self._request("POST", url, json=data, params=params)

    async def patch(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PATCH."""
        return await self._request("PATCH", url, json=data, params=params)

    async def put(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PUT."""
        return await self._request("PUT", url, json=data, params=params)

    async def delete(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición DELETE."""
        return await self._request("DELETE", url, params=params)

    async def post_form(
        self,
        url: str,
        files: dict[str, Any],
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST con multipart/form-data (para subir archivos)."""
        return await self._request("POST", url, files=files, data=data)

    def build_sse_url(self, path: str) -> str:
        """Construye URL completa para SSE con apiKey como query param."""
        from urllib.parse import quote

        base = self._config.base_url.rstrip("/")
        separator = "&" if "?" in path else "?"
        return f"{base}{path}{separator}apiKey={quote(self._config.api_key, safe='')}"

    async def stream_sse(
        self,
        url: str,
        *,
        timeout: float = 120.0,
        cancel_event: asyncio.Event | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Abre una conexión SSE y yield de cada evento parseado.

        Args:
            url: URL completa (generada con build_sse_url).
            timeout: Timeout máximo de la conexión en segundos.
            cancel_event: Evento asyncio para cancelar la lectura.

        Yields:
            Diccionarios con los datos de cada evento SSE.
        """
        async with httpx.AsyncClient(timeout=httpx.Timeout(timeout)) as sse_client:
            async with sse_client.stream("GET", url) as response:
                response.raise_for_status()
                buffer = ""
                async for chunk in response.aiter_text():
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_text, buffer = buffer.split("\n\n", 1)
                        parsed = _parse_sse_event(event_text)
                        if parsed is not None:
                            yield parsed
                        if cancel_event is not None and cancel_event.is_set():
                            return

    # -- Lógica interna --

    async def _request(
        self,
        method: str,
        url: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Ejecuta una petición HTTP con reintentos y backoff exponencial."""
        # Filtrar params None
        clean_params = (
            {k: v for k, v in params.items() if v is not None} if params else None
        )

        last_error: UtiliaSDKError | None = None

        for attempt in range(self._config.retry_attempts):
            try:
                if self._config.debug:
                    logger.debug("%s %s (intento %d)", method, url, attempt + 1)

                request_id = str(uuid.uuid4())
                extra_headers = {"x-request-id": request_id}

                # Si hay archivos, construir request sin Content-Type fijo
                # (httpx pone multipart/form-data automáticamente)
                if files is not None:
                    req = self._client.build_request(
                        method,
                        url,
                        params=clean_params,
                        files=files,
                        data=data,
                        headers=extra_headers,
                    )
                    # Eliminar el Content-Type: application/json del cliente base
                    if "content-type" in req.headers:
                        del req.headers["content-type"]
                    response = await self._client.send(req)
                else:
                    response = await self._client.request(
                        method,
                        url,
                        json=json,
                        params=clean_params,
                        headers=extra_headers,
                    )

                if self._config.debug:
                    logger.debug("Respuesta: %d %s", response.status_code, url)

                response.raise_for_status()

                if response.status_code == 204 or not response.content:
                    return None

                return response.json()

            except httpx.TimeoutException:
                last_error = UtiliaSDKError(
                    ErrorCode.NETWORK_ERROR,
                    "Timeout: la solicitud excedió el tiempo límite",
                )
            except httpx.ConnectError:
                last_error = UtiliaSDKError(
                    ErrorCode.NETWORK_ERROR,
                    "Error de conexión: no se pudo conectar con el servidor",
                )
            except httpx.HTTPStatusError as exc:
                last_error = self._handle_http_error(exc)
                status_code = exc.response.status_code
                is_retryable = (
                    last_error.is_retryable
                    or status_code >= 500
                    or status_code == 429
                )
                if not is_retryable:
                    raise last_error from exc

            # Backoff exponencial: 0.5s, 1s, 2s, ...
            if attempt < self._config.retry_attempts - 1:
                wait = (2**attempt) * 0.5
                await asyncio.sleep(wait)

        # Agotados los reintentos
        if last_error is None:
            raise RuntimeError("No error recorded after retries")
        raise last_error

    @staticmethod
    def _handle_http_error(exc: httpx.HTTPStatusError) -> UtiliaSDKError:
        """Convierte un error HTTP en un UtiliaSDKError con el código apropiado."""
        status = exc.response.status_code
        request_id = exc.response.headers.get("x-request-id")

        # Intentar extraer mensaje y errorCode de la respuesta
        message: str | None = None
        error_code: str | None = None
        try:
            body = exc.response.json()
            message = body.get("message") or body.get("error")
            error_code = body.get("errorCode")
        except Exception:
            pass

        common = {"status_code": status, "request_id": request_id, "error_code": error_code}

        if status == 401:
            return UtiliaSDKError(
                ErrorCode.UNAUTHORIZED,
                message or "API Key inválida o faltante",
                **common,
            )

        if status == 403:
            msg = (message or "").lower()
            if "rate limit" in msg:
                return UtiliaSDKError(
                    ErrorCode.RATE_LIMITED,
                    "Rate limit excedido. Intenta de nuevo más tarde.",
                    **common,
                )
            if "origen" in msg:
                return UtiliaSDKError(
                    ErrorCode.FORBIDDEN,
                    "Origen no permitido por CORS",
                    **common,
                )
            return UtiliaSDKError(
                ErrorCode.FORBIDDEN,
                message or "Acceso denegado",
                **common,
            )

        if status == 404:
            return UtiliaSDKError(
                ErrorCode.NOT_FOUND,
                message or "Recurso no encontrado",
                **common,
            )

        if status == 429:
            return UtiliaSDKError(
                ErrorCode.RATE_LIMITED,
                message or "Rate limit excedido. Intenta de nuevo mas tarde.",
                **common,
            )

        if status in (400, 422):
            return UtiliaSDKError(
                ErrorCode.VALIDATION_ERROR,
                message or "Error de validación en los datos enviados",
                **common,
            )

        if status in (500, 502, 503, 504):
            return UtiliaSDKError(
                ErrorCode.UNKNOWN,
                message or "Error interno del servidor",
                **common,
            )

        return UtiliaSDKError(
            ErrorCode.UNKNOWN,
            message or f"Error desconocido (HTTP {status})",
            **common,
        )


def _parse_sse_event(raw: str) -> dict[str, Any] | None:
    """Parsea un bloque de texto SSE y retorna el dict del campo data."""
    data_lines: list[str] = []
    for line in raw.split("\n"):
        stripped = line.strip()
        if stripped.startswith(":"):
            continue  # Comentario SSE / heartbeat
        if stripped.startswith("data:"):
            data_lines.append(stripped[5:].strip())
    if not data_lines:
        return None
    try:
        return _json.loads("\n".join(data_lines))
    except (ValueError, _json.JSONDecodeError):
        return None
