"""
Errores personalizados del SDK de UTILIA OS.

Define los codigos de error y la clase UtiliaSDKError para
identificar y manejar errores de forma estructurada.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    """Codigos de error del SDK."""

    UNAUTHORIZED = "UNAUTHORIZED"
    """API Key invalida o faltante."""

    FORBIDDEN = "FORBIDDEN"
    """Acceso denegado (app desactivada, CORS, etc)."""

    NOT_FOUND = "NOT_FOUND"
    """Recurso no encontrado."""

    RATE_LIMITED = "RATE_LIMITED"
    """Rate limit excedido."""

    VALIDATION_ERROR = "VALIDATION_ERROR"
    """Error de validacion en los datos enviados."""

    NETWORK_ERROR = "NETWORK_ERROR"
    """Error de conexion de red."""

    UNKNOWN = "UNKNOWN"
    """Error desconocido."""


class UtiliaSDKError(Exception):
    """Clase de error personalizada del SDK.

    Permite identificar el tipo de error y tomar acciones apropiadas.

    Attributes:
        code: Codigo del error para identificar el tipo.
        message: Mensaje descriptivo del error.
        timestamp: Momento en que ocurrio el error.
        status_code: Codigo de estado HTTP de la respuesta (si aplica).
        request_id: Identificador de la peticion devuelto por el servidor.
        error_code: Codigo de error de negocio devuelto por el backend.
    """

    def __init__(
        self,
        code: ErrorCode,
        message: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.timestamp = datetime.now(tz=timezone.utc)
        self.status_code = status_code
        self.request_id = request_id
        self.error_code = error_code

    def to_dict(self) -> dict[str, Any]:
        """Serializa el error a un diccionario."""
        return {
            "name": "UtiliaSDKError",
            "code": self.code.value,
            "errorCode": self.error_code,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
            "statusCode": self.status_code,
            "requestId": self.request_id,
        }

    @property
    def is_rate_limited(self) -> bool:
        """Verifica si el error es de tipo rate limit."""
        return self.code == ErrorCode.RATE_LIMITED

    @property
    def is_unauthorized(self) -> bool:
        """Verifica si el error es de autenticacion."""
        return self.code == ErrorCode.UNAUTHORIZED

    @property
    def is_retryable(self) -> bool:
        """Verifica si el error es recuperable (se puede reintentar)."""
        return self.code in (ErrorCode.RATE_LIMITED, ErrorCode.NETWORK_ERROR)

    def __repr__(self) -> str:
        parts = f"code={self.code.value!r}, message={self.message!r}"
        if self.error_code:
            parts += f", error_code={self.error_code!r}"
        return f"UtiliaSDKError({parts})"
