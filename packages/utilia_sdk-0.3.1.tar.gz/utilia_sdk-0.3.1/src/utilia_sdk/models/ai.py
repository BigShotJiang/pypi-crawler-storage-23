"""Modelos relacionados con funcionalidades de IA."""

from __future__ import annotations

import asyncio
import concurrent.futures
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class AiSuggestInput(BaseModel):
    """Entrada para solicitar sugerencias de IA."""

    model_config = ConfigDict(populate_by_name=True)

    user_id: str = Field(alias="userId")
    """ID externo del usuario."""
    text: str | None = None
    """Texto del problema a analizar (opcional si se envía audio)."""
    audio_base64: str | None = Field(default=None, alias="audioBase64")
    """Audio en base64 para transcribir (webm/mp4/mp3/wav)."""
    audio_filename: str | None = Field(default=None, alias="audioFilename")
    """Nombre del archivo de audio con extensión."""
    existing_fields: dict[str, str | None] | None = Field(
        default=None, alias="existingFields"
    )
    """Campos existentes del formulario para contexto."""
    images: list[ImageBase64] | None = None
    """Imágenes en base64 para análisis visual (opcional)."""


class AiSuggestions(BaseModel):
    """Sugerencias generadas por IA."""

    model_config = ConfigDict(populate_by_name=True)

    title: str | None = None
    """Título sugerido para el ticket."""
    description: str | None = None
    """Descripción sugerida."""
    category: str | None = None
    """Categoría sugerida (BUG, CONSULTA, SUGERENCIA)."""
    priority: str | None = None
    """Prioridad sugerida (BAJA, MEDIA, ALTA, CRITICA)."""


class AiJobResult(BaseModel):
    """Resultado de un job de IA."""

    model_config = ConfigDict(populate_by_name=True)

    transcription: str | None = None
    """Transcripción del audio (si se envió audio)."""
    suggestions: AiSuggestions | None = None
    """Sugerencias generadas."""
    analytics_event_id: str | None = Field(default=None, alias="analyticsEventId")
    """ID del evento de analytics para tracking de aceptación/rechazo."""


class AiJobStatus(BaseModel):
    """Estado del job de IA."""

    model_config = ConfigDict(populate_by_name=True)

    status: Literal["pending", "processing", "completed", "failed", "not_found"]
    """Estado actual del job."""
    progress: int | None = None
    """Progreso del job (0-100)."""
    result: AiJobResult | None = None
    """Resultado del job (disponible cuando status es 'completed')."""
    error: str | None = None
    """Mensaje de error (si status es 'failed')."""


class TrackAiActionInput(BaseModel):
    """Entrada para registrar la acción del usuario sobre sugerencias de IA."""

    model_config = ConfigDict(populate_by_name=True)

    event_id: str = Field(alias="eventId")
    """ID del evento de analytics a trackear."""
    user_action: Literal[
        "ACCEPTED_ALL", "ACCEPTED_PARTIAL", "REJECTED", "MODIFIED", "IGNORED"
    ] = Field(alias="userAction")
    """Acción del usuario sobre las sugerencias."""
    fields_accepted: list[str] | None = Field(default=None, alias="fieldsAccepted")
    """Campos aceptados por el usuario."""
    fields_modified: list[str] | None = Field(default=None, alias="fieldsModified")
    """Campos modificados por el usuario."""
    fields_rejected: list[str] | None = Field(default=None, alias="fieldsRejected")
    """Campos rechazados por el usuario."""
    time_to_decision_ms: int | None = Field(default=None, alias="timeToDecisionMs")
    """Tiempo en milisegundos desde que se mostraron las sugerencias hasta la decisión."""
    source: Literal["SDK_EXTERNAL", "WIDGET"] | None = None
    """Origen de la acción (automático: SDK_EXTERNAL por defecto)."""


@dataclass(frozen=True)
class GetSuggestionsOptions:
    """Opciones para el método get_suggestions con polling.

    Attributes:
        poll_interval: Intervalo de polling en segundos (default: 1.0).
        max_wait: Tiempo máximo de espera en segundos (default: 60.0).
    """

    poll_interval: float = field(default=1.0)
    max_wait: float = field(default=60.0)


class ImageBase64(BaseModel):
    """Imagen codificada en base64 para enviar a la IA."""

    model_config = ConfigDict(populate_by_name=True)

    base64: str
    """Contenido de la imagen en base64."""
    filename: str
    """Nombre del archivo de imagen."""
    mime_type: str = Field(alias="mimeType")
    """Tipo MIME de la imagen (ej: image/png)."""


class TranscriptionJobStatus(BaseModel):
    """Estado de un job de transcripción."""

    model_config = ConfigDict(populate_by_name=True)

    status: Literal["pending", "processing", "completed", "failed"]
    """Estado actual del job de transcripción."""
    progress: int | None = None
    """Progreso del job (0-100)."""
    transcription: str | None = None
    """Texto transcrito (disponible cuando status es 'completed')."""
    error: str | None = None
    """Mensaje de error (si status es 'failed')."""


class SseEvent(BaseModel):
    """Evento recibido por SSE durante streaming."""

    model_config = ConfigDict(populate_by_name=True)

    event: Literal["progress", "completed", "failed", "heartbeat"]
    """Tipo de evento SSE."""
    progress: int | None = None
    """Progreso actual (0-100)."""
    status: str | None = None
    """Estado descriptivo."""
    result: AiJobResult | None = None
    """Resultado final (disponible en evento 'completed')."""
    error: str | None = None
    """Mensaje de error (disponible en evento 'failed')."""


@dataclass(frozen=True)
class SseStreamOptions:
    """Opciones comunes para streaming vía SSE.

    Attributes:
        on_progress: Callback invocado en cada evento de progreso (recibe int 0-100).
        on_error: Callback invocado en caso de error.
        timeout: Tiempo máximo de espera en segundos (default: 120.0).
    """

    on_progress: Callable[[int], None] | None = field(default=None)
    on_error: Callable[[Exception], None] | None = field(default=None)
    timeout: float = field(default=120.0)


# Aliases para retrocompatibilidad
StreamSuggestionsOptions = SseStreamOptions
StreamTranscriptionOptions = SseStreamOptions


class ReportClientErrorParams(BaseModel):
    """Parámetros para reportar un error de cliente."""

    model_config = ConfigDict(populate_by_name=True)

    message: str
    """Mensaje descriptivo del error."""
    stack: str | None = None
    """Stack trace del error."""
    code: str | None = None
    """Código de error."""
    component: str | None = None
    """Componente donde ocurrió el error."""
    context: dict[str, Any] | None = None
    """Datos adicionales de contexto."""
    endpoint: str | None = None
    """Endpoint relacionado."""
    method: str | None = None
    """Método HTTP del endpoint."""
    request_id: str | None = Field(default=None, alias="requestId")
    """ID de la petición para trazabilidad."""
    url: str | None = None
    """URL donde ocurrió el error."""
    user_agent: str | None = Field(default=None, alias="userAgent")
    """User agent del navegador."""


@dataclass
class StreamSuggestionsHandle:
    """Handle para controlar el streaming de sugerencias con cancelación.

    Attributes:
        result: Tarea asyncio que resuelve con AiJobResult | None al completar.
        abort: Función para cancelar la operación SSE.
    """

    result: asyncio.Task[AiJobResult | None]
    abort: Callable[[], None]


@dataclass
class SyncStreamSuggestionsHandle:
    """Handle síncrono para controlar el streaming de sugerencias con cancelación.

    Attributes:
        result: Future que resuelve con AiJobResult | None al completar.
        abort: Función para cancelar la operación SSE.
    """

    result: concurrent.futures.Future[AiJobResult | None]
    abort: Callable[[], None]
