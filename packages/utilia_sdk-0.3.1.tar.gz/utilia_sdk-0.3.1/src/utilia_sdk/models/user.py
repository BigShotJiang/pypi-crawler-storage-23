"""Modelos relacionados con usuarios externos."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from utilia_sdk._constants import AVATAR_URL_MAX, EXTERNAL_ID_MAX
from utilia_sdk._validators import validate_email as _validate_email_fn
from utilia_sdk._validators import validate_url as _validate_url_fn


class IdentifyUserInput(BaseModel):
    """DTO para identificar/actualizar un usuario externo."""

    model_config = ConfigDict(populate_by_name=True)

    external_id: str = Field(alias="externalId")
    """ID unico del usuario en tu sistema (requerido)."""
    email: str | None = None
    """Email del usuario."""
    name: str | None = None
    """Nombre del usuario."""
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    """URL del avatar del usuario."""
    metadata: dict[str, Any] | None = None
    """Metadatos adicionales del usuario."""

    @field_validator("external_id")
    @classmethod
    def _validate_external_id(cls, v: str) -> str:
        if len(v) > EXTERNAL_ID_MAX:
            raise ValueError(f"externalId must be at most {EXTERNAL_ID_MAX} characters long (got {len(v)})")
        return v

    @field_validator("email")
    @classmethod
    def _validate_email(cls, v: str | None) -> str | None:
        if v is not None and not _validate_email_fn(v):
            raise ValueError(f'Invalid email format: "{v}"')
        return v

    @field_validator("avatar_url")
    @classmethod
    def _validate_avatar_url(cls, v: str | None) -> str | None:
        if v is not None:
            if not _validate_url_fn(v):
                raise ValueError(f'Invalid avatar URL: "{v}"')
            if len(v) > AVATAR_URL_MAX:
                raise ValueError(f"avatarUrl must be at most {AVATAR_URL_MAX} characters long (got {len(v)})")
        return v


class UserTicketCount(BaseModel):
    """Contadores relacionados con tickets."""

    tickets: int


class ExternalUser(BaseModel):
    """Usuario externo registrado."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    """ID interno en UTILIA OS."""
    app_id: str = Field(alias="appId")
    """ID de la aplicacion externa."""
    external_id: str = Field(alias="externalId")
    """ID del usuario en el sistema externo."""
    email: str | None = None
    """Email del usuario."""
    name: str | None = None
    """Nombre del usuario."""
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    """URL del avatar."""
    metadata: dict[str, Any] | None = None
    """Metadatos adicionales."""
    last_seen_at: str = Field(alias="lastSeenAt")
    """Ultima vez que el usuario estuvo activo."""
    count: UserTicketCount | None = Field(default=None, alias="_count")
    """Contadores relacionados."""
