"""Modelos relacionados con tickets de soporte."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from utilia_sdk._constants import (
    MESSAGE_CONTENT_MAX,
    MESSAGE_CONTENT_MIN,
    TICKET_DESCRIPTION_MIN,
    TICKET_TITLE_MAX,
    TICKET_TITLE_MIN,
)

from utilia_sdk.models.common import TicketCategory, TicketPriority, TicketStatus


class CreateTicketUser(BaseModel):
    """Datos del usuario para crear ticket."""

    model_config = ConfigDict(populate_by_name=True)

    external_id: str = Field(alias="externalId")
    """ID único del usuario en tu sistema."""
    email: str | None = None
    """Email del usuario (opcional)."""
    name: str | None = None
    """Nombre del usuario (opcional)."""
    metadata: dict[str, Any] | None = None
    """Metadatos adicionales del usuario (opcional)."""


class TicketContext(BaseModel):
    """Contexto adicional del ticket."""

    model_config = ConfigDict(populate_by_name=True)

    url: str | None = None
    """URL donde se originó el ticket."""
    app_version: str | None = Field(default=None, alias="appVersion")
    """Versión de la aplicación."""
    browser_info: str | None = Field(default=None, alias="browserInfo")
    """Información del navegador."""
    custom_data: dict[str, Any] | None = Field(default=None, alias="customData")
    """Datos personalizados adicionales."""


class TicketReporter(BaseModel):
    """Datos del reportador del ticket."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    """Nombre del reportador."""
    email: str | None = None
    """Email del reportador (opcional)."""


class CreateTicketInput(BaseModel):
    """DTO para crear un nuevo ticket."""

    model_config = ConfigDict(populate_by_name=True)

    user: CreateTicketUser
    """Datos del usuario que crea el ticket."""
    title: str
    """Título del ticket (5-500 caracteres)."""
    description: str
    """Descripción detallada (mínimo 10 caracteres)."""
    category: TicketCategory | None = None
    """Categoría del ticket."""
    priority: TicketPriority | None = None
    """Prioridad del ticket."""
    context: TicketContext | None = None
    """Contexto adicional."""
    attachment_ids: list[str] | None = Field(default=None, alias="attachmentIds")
    """IDs de archivos adjuntos (previamente subidos)."""

    @field_validator("title")
    @classmethod
    def _validate_title(cls, v: str) -> str:
        if len(v) < TICKET_TITLE_MIN:
            raise ValueError(f"title must be at least {TICKET_TITLE_MIN} characters long (got {len(v)})")
        if len(v) > TICKET_TITLE_MAX:
            raise ValueError(f"title must be at most {TICKET_TITLE_MAX} characters long (got {len(v)})")
        return v

    @field_validator("description")
    @classmethod
    def _validate_description(cls, v: str) -> str:
        if len(v) < TICKET_DESCRIPTION_MIN:
            raise ValueError(f"description must be at least {TICKET_DESCRIPTION_MIN} characters long (got {len(v)})")
        return v


class TicketFilters(BaseModel):
    """Filtros para listar tickets."""

    model_config = ConfigDict(populate_by_name=True)

    status: TicketStatus | None = None
    """Filtrar por estado."""
    page: int | None = None
    """Página actual (default: 1)."""
    limit: int | None = None
    """Elementos por página (default: 20, max: 100)."""


class AddMessageInput(BaseModel):
    """DTO para agregar un mensaje a un ticket."""

    model_config = ConfigDict(populate_by_name=True)

    content: str
    """Contenido del mensaje (1-5000 caracteres)."""
    attachment_ids: list[str] | None = Field(default=None, alias="attachmentIds")
    """IDs de archivos adjuntos (opcional)."""

    @field_validator("content")
    @classmethod
    def _validate_content(cls, v: str) -> str:
        if len(v) < MESSAGE_CONTENT_MIN:
            raise ValueError(f"content must be at least {MESSAGE_CONTENT_MIN} characters long (got {len(v)})")
        if len(v) > MESSAGE_CONTENT_MAX:
            raise ValueError(f"content must be at most {MESSAGE_CONTENT_MAX} characters long (got {len(v)})")
        return v


class CreatedTicket(BaseModel):
    """Respuesta al crear un ticket."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    """ID interno del ticket."""
    ticket_key: str = Field(alias="ticketKey")
    """Clave única del ticket (ej: APP-0001)."""
    title: str
    """Título del ticket."""
    status: TicketStatus
    """Estado inicial."""
    created_at: str = Field(alias="createdAt")
    """Fecha de creación."""


class TicketListItem(BaseModel):
    """Ticket en listado (versión resumida)."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    ticket_key: str = Field(alias="ticketKey")
    title: str
    category: TicketCategory
    priority: TicketPriority
    status: TicketStatus
    unread_by_external: int = Field(alias="unreadByExternal")
    """Número de mensajes no leídos por el usuario externo."""
    created_at: str = Field(alias="createdAt")
    last_activity_at: str = Field(alias="lastActivityAt")


class MessageAuthor(BaseModel):
    """Autor de un mensaje."""

    model_config = ConfigDict(populate_by_name=True)

    type: str
    """Tipo de autor: 'EXTERNAL' o 'INTERNAL'."""
    id: str
    """ID del autor (externalId o nombre de agente)."""
    name: str
    """Nombre visible del autor."""


class TicketAttachment(BaseModel):
    """Archivo adjunto."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    filename: str
    mime_type: str = Field(alias="mimeType")
    size: int


class TicketMessage(BaseModel):
    """Mensaje de un ticket."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    content: str
    author: MessageAuthor
    attachments: list[TicketAttachment]
    created_at: str = Field(alias="createdAt")


class TicketDetail(BaseModel):
    """Detalle completo de un ticket."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    ticket_key: str = Field(alias="ticketKey")
    title: str
    description: str
    category: TicketCategory
    priority: TicketPriority
    status: TicketStatus
    created_at: str = Field(alias="createdAt")
    last_activity_at: str = Field(alias="lastActivityAt")
    context: TicketContext | None = None
    """Contexto adicional del ticket (opcional)."""
    reporter: TicketReporter | None = None
    """Datos del reportador del ticket (opcional)."""
    messages: list[TicketMessage]
    """Lista de mensajes del ticket."""
    attachments: list[TicketAttachment]
    """Archivos adjuntos del ticket original."""


class CreatedMessage(BaseModel):
    """Respuesta al crear un mensaje."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    content: str
    created_at: str = Field(alias="createdAt")


class UnreadCount(BaseModel):
    """Conteo de mensajes no leídos."""

    model_config = ConfigDict(populate_by_name=True)

    count: int
