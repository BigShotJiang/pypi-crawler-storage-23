"""Modelos relacionados con archivos adjuntos."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class UploadedFile(BaseModel):
    """Respuesta al subir un archivo."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    """ID del archivo para usar en attachmentIds."""
    original_name: str = Field(alias="originalName")
    """Nombre original del archivo."""
    mime_type: str = Field(alias="mimeType")
    """Tipo MIME."""
    size: int
    """Tamano en bytes."""
    download_url: str = Field(alias="downloadUrl")
    """URL temporal de descarga."""
    created_at: str = Field(alias="createdAt")
    """Fecha de creacion."""


class FileQuota(BaseModel):
    """Informacion de quota de almacenamiento."""

    model_config = ConfigDict(populate_by_name=True)

    used_bytes: int = Field(alias="usedBytes")
    """Bytes usados."""
    max_bytes: int = Field(alias="maxBytes")
    """Bytes maximos permitidos."""
    max_file_size_bytes: int = Field(alias="maxFileSizeBytes")
    """Tamano maximo por archivo."""
    usage_percent: float = Field(alias="usagePercent")
    """Porcentaje de uso (0-100)."""
