"""Tipos comunes compartidos en el SDK."""

from __future__ import annotations

from enum import Enum
from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field


class TicketStatus(str, Enum):
    """Estados posibles de un ticket."""

    OPEN = "OPEN"
    IN_REVIEW = "IN_REVIEW"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class TicketCategory(str, Enum):
    """Categorias de ticket."""

    CONSULTA = "CONSULTA"
    PROBLEMA = "PROBLEMA"
    SUGERENCIA = "SUGERENCIA"
    OTRO = "OTRO"


class TicketPriority(str, Enum):
    """Niveles de prioridad de ticket."""

    BAJA = "BAJA"
    MEDIA = "MEDIA"
    ALTA = "ALTA"
    CRITICA = "CRITICA"


class PaginationMeta(BaseModel):
    """Metadatos de paginacion."""

    model_config = ConfigDict(populate_by_name=True)

    page: int
    limit: int
    total: int
    total_pages: int = Field(alias="totalPages")


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Respuesta paginada generica."""

    model_config = ConfigDict(populate_by_name=True)

    data: list[T]
    pagination: PaginationMeta
