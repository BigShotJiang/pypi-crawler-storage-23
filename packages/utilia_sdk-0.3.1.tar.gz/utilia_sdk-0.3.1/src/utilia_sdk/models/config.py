"""Configuracion del SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class UtiliaSDKConfig:
    """Configuracion para inicializar el SDK de UTILIA OS.

    Attributes:
        base_url: URL base de la API (ej: https://os.utilia.ai/api).
        api_key: API Key para autenticacion.
        timeout: Timeout en segundos (default: 30).
        retry_attempts: Numero de reintentos en caso de error (default: 3).
        debug: Habilitar logs de debug (default: False).
    """

    base_url: str
    api_key: str
    timeout: float = field(default=30.0)
    retry_attempts: int = field(default=3)
    debug: bool = field(default=False)
