"""Modelos relacionados con errores del sistema."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

ErrorSeverity = Literal["critical", "high", "medium", "low"]
ErrorHttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]


class ReportErrorInput(BaseModel):
    """Entrada para reportar un error desde una aplicación externa."""

    model_config = ConfigDict(populate_by_name=True)

    message: str
    """Mensaje descriptivo del error."""
    severity: ErrorSeverity | None = None
    """Severidad del error."""
    module: str
    """Módulo o componente donde ocurrió el error."""
    stack: str | None = None
    """Stack trace del error."""
    file: str | None = None
    """Archivo donde ocurrió el error."""
    line: int | None = None
    """Número de línea."""
    function: str | None = None
    """Función donde ocurrió el error."""
    endpoint: str | None = None
    """Endpoint relacionado con el error."""
    method: ErrorHttpMethod | None = None
    """Método HTTP del endpoint."""
    user_id: str | None = Field(default=None, alias="userId")
    """ID del usuario afectado."""
    request_id: str | None = Field(default=None, alias="requestId")
    """ID de la petición para trazabilidad."""
    context: dict[str, Any] | None = None
    """Datos adicionales de contexto."""

    @field_validator("message")
    @classmethod
    def _validate_message(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("message must not be empty")
        return v

    @field_validator("module")
    @classmethod
    def _validate_module(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("module must not be empty")
        return v


class ReportedError(BaseModel):
    """Respuesta al reportar un error."""

    model_config = ConfigDict(populate_by_name=True)

    success: bool
    """Indica si el error se registró correctamente."""
    hash: str
    """Hash único del error para deduplicación."""
    deduplicated: bool
    """Indica si el error ya existía (fue deduplicado)."""


class SystemErrorEntry(BaseModel):
    """Entrada de error del sistema."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    """ID único del registro de error."""
    hash: str
    """Hash del error para agrupación."""
    message: str
    """Mensaje del error."""
    module: str
    """Módulo donde ocurrió."""
    severity: ErrorSeverity
    """Severidad del error."""
    file: str | None = None
    """Archivo donde ocurrió."""
    line: int | None = None
    """Número de línea."""
    endpoint: str | None = None
    """Endpoint relacionado."""
    count: int
    """Número de ocurrencias."""
    first_occurrence: str = Field(alias="firstOccurrence")
    """Fecha de la primera ocurrencia."""
    last_occurrence: str = Field(alias="lastOccurrence")
    """Fecha de la última ocurrencia."""
    resolved: bool
    """Indica si el error está resuelto."""
    resolved_at: str | None = Field(default=None, alias="resolvedAt")
    """Fecha de resolución (si aplica)."""


class ErrorFilters(BaseModel):
    """Filtros para consultar errores."""

    model_config = ConfigDict(populate_by_name=True)

    severity: list[ErrorSeverity] | None = None
    """Filtrar por severidades."""
    module: str | None = None
    """Filtrar por módulo."""
    resolved: bool | None = None
    """Filtrar por estado de resolución."""
    limit: int | None = None
    """Límite de resultados."""
    offset: int | None = None
    """Desplazamiento para paginación."""
    from_date: str | None = Field(default=None, alias="from")
    """Fecha de inicio del rango."""
    to_date: str | None = Field(default=None, alias="to")
    """Fecha de fin del rango."""


class TopError(BaseModel):
    """Error más frecuente en estadísticas."""

    model_config = ConfigDict(populate_by_name=True)

    hash: str
    """Hash del error."""
    message: str
    """Mensaje del error."""
    count: int
    """Número de ocurrencias."""
    severity: str
    """Severidad del error."""


class ErrorStats(BaseModel):
    """Estadísticas de errores del sistema."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    """Total de errores registrados."""
    unresolved: int
    """Errores sin resolver."""
    by_severity: dict[str, int] = Field(alias="bySeverity")
    """Conteo de errores por severidad."""
    by_module: dict[str, int] = Field(alias="byModule")
    """Conteo de errores por módulo."""
    top_errors: list[TopError] = Field(alias="topErrors")
    """Errores más frecuentes."""
