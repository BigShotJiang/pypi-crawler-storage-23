"""Funciones de validacion del SDK."""

from __future__ import annotations

import re
import urllib.parse

from utilia_sdk.errors import ErrorCode, UtiliaSDKError

_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def validate_string_length(
    value: str,
    field_name: str,
    *,
    min_len: int | None = None,
    max_len: int | None = None,
) -> None:
    """Valida la longitud de un string.

    Lanza ``UtiliaSDKError`` con ``ErrorCode.VALIDATION_ERROR``
    si el valor no cumple los limites indicados.
    """
    if min_len is not None and len(value) < min_len:
        raise UtiliaSDKError(
            ErrorCode.VALIDATION_ERROR,
            f"{field_name} must be at least {min_len} characters long (got {len(value)})",
        )
    if max_len is not None and len(value) > max_len:
        raise UtiliaSDKError(
            ErrorCode.VALIDATION_ERROR,
            f"{field_name} must be at most {max_len} characters long (got {len(value)})",
        )


def validate_email(email: str) -> bool:
    """Valida el formato de un email.

    Returns:
        ``True`` si el email tiene un formato valido.
    """
    return bool(_EMAIL_RE.match(email))


_VALID_URL_SCHEMES = frozenset({"http", "https"})


def validate_url(url: str) -> bool:
    """Valida que una URL tenga scheme http/https y netloc.

    Returns:
        ``True`` si la URL es valida.
    """
    parsed = urllib.parse.urlparse(url)
    return parsed.scheme in _VALID_URL_SCHEMES and bool(parsed.netloc)
