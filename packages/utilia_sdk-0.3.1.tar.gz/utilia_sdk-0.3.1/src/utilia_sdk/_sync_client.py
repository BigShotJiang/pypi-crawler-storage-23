"""
Wrapper síncrono del cliente HTTP asíncrono.

Permite usar el SDK sin necesidad de async/await,
ejecutando las corrutinas en un event loop dedicado.
"""

from __future__ import annotations

import asyncio
import threading
from collections.abc import Generator
from typing import Any

import httpx

from utilia_sdk._client import UtiliaClient, _parse_sse_event
from utilia_sdk.models.config import UtiliaSDKConfig


class UtiliaSyncClient:
    """Cliente HTTP síncrono que envuelve al cliente asíncrono.

    Usa un event loop interno dedicado para ejecutar las operaciones.
    """

    def __init__(self, config: UtiliaSDKConfig) -> None:
        self._loop = asyncio.new_event_loop()
        self._async_client = UtiliaClient(config)

    def close(self) -> None:
        """Cierra la sesión HTTP y el event loop."""
        self._loop.run_until_complete(self._async_client.close())
        self._loop.close()

    def __enter__(self) -> UtiliaSyncClient:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def get(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición GET síncrona."""
        return self._loop.run_until_complete(self._async_client.get(url, params=params))

    def post(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST síncrona."""
        return self._loop.run_until_complete(
            self._async_client.post(url, data, params=params)
        )

    def patch(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PATCH síncrona."""
        return self._loop.run_until_complete(
            self._async_client.patch(url, data, params=params)
        )

    def put(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PUT síncrona."""
        return self._loop.run_until_complete(
            self._async_client.put(url, data, params=params)
        )

    def delete(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición DELETE síncrona."""
        return self._loop.run_until_complete(
            self._async_client.delete(url, params=params)
        )

    def post_form(
        self,
        url: str,
        files: dict[str, Any],
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST con multipart/form-data síncrona."""
        return self._loop.run_until_complete(
            self._async_client.post_form(url, files, data)
        )

    def build_sse_url(self, path: str) -> str:
        """Construye URL completa para SSE con apiKey como query param."""
        return self._async_client.build_sse_url(path)

    def stream_sse(
        self,
        url: str,
        *,
        timeout: float = 120.0,
        cancel_event: threading.Event | None = None,
    ) -> Generator[dict[str, Any], None, None]:
        """Abre una conexión SSE síncrona y yield de cada evento parseado.

        Args:
            url: URL completa (generada con build_sse_url).
            timeout: Timeout máximo de la conexión en segundos.
            cancel_event: Evento threading para cancelar la lectura.

        Yields:
            Diccionarios con los datos de cada evento SSE.
        """
        with httpx.Client(timeout=httpx.Timeout(timeout)) as sse_client:
            with sse_client.stream("GET", url) as response:
                response.raise_for_status()
                buffer = ""
                for chunk in response.iter_text():
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_text, buffer = buffer.split("\n\n", 1)
                        parsed = _parse_sse_event(event_text)
                        if parsed is not None:
                            yield parsed
                        if cancel_event is not None and cancel_event.is_set():
                            return
