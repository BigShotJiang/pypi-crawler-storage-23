"""
Servicio de usuarios externos.

Maneja las operaciones relacionadas con usuarios:
identificar/actualizar y listar.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from utilia_sdk.models.common import PaginatedResponse, PaginationMeta
from utilia_sdk.models.user import ExternalUser, IdentifyUserInput

if TYPE_CHECKING:
    from utilia_sdk._client import UtiliaClient
    from utilia_sdk._sync_client import UtiliaSyncClient

_BASE_PATH = "/external/v1/users"


class UsersService:
    """Servicio asincrono de usuarios externos."""

    def __init__(self, client: UtiliaClient) -> None:
        self._client = client

    async def identify(self, data: IdentifyUserInput) -> ExternalUser:
        """Identificar o actualizar un usuario externo.

        Si el usuario ya existe, actualiza sus datos.
        Si no existe, lo crea.

        Args:
            data: Datos del usuario.

        Returns:
            Usuario creado o actualizado.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/identify",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return ExternalUser.model_validate(raw)

    async def list(
        self, page: int = 1, limit: int = 20
    ) -> PaginatedResponse[ExternalUser]:
        """Listar usuarios de la aplicacion.

        Args:
            page: Pagina actual (default: 1).
            limit: Elementos por pagina (default: 20).

        Returns:
            Lista paginada de usuarios.
        """
        raw = await self._client.get(
            _BASE_PATH, params={"page": page, "limit": limit}
        )
        users = [ExternalUser.model_validate(u) for u in raw["users"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[ExternalUser](data=users, pagination=pagination)


class UsersSyncService:
    """Servicio sincrono de usuarios externos."""

    def __init__(self, client: UtiliaSyncClient) -> None:
        self._client = client

    def identify(self, data: IdentifyUserInput) -> ExternalUser:
        """Identificar o actualizar un usuario externo."""
        raw = self._client.post(
            f"{_BASE_PATH}/identify",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return ExternalUser.model_validate(raw)

    def list(
        self, page: int = 1, limit: int = 20
    ) -> PaginatedResponse[ExternalUser]:
        """Listar usuarios de la aplicacion."""
        raw = self._client.get(_BASE_PATH, params={"page": page, "limit": limit})
        users = [ExternalUser.model_validate(u) for u in raw["users"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[ExternalUser](data=users, pagination=pagination)
