"""
Servicio de archivos adjuntos.

Permite subir archivos para adjuntar a tickets,
obtener URLs de descarga y consultar la quota.
"""

from __future__ import annotations

import pathlib
from collections.abc import Callable
from typing import IO, TYPE_CHECKING, Any

from utilia_sdk._constants import FILE_NAME_MAX
from utilia_sdk._progress import ProgressFileWrapper, get_file_size
from utilia_sdk._validators import validate_string_length
from utilia_sdk.models.file import FileQuota, UploadedFile

if TYPE_CHECKING:
    from utilia_sdk._client import UtiliaClient
    from utilia_sdk._sync_client import UtiliaSyncClient

_BASE_PATH = "/external/v1/files"


def _wrap_with_progress(
    files: dict[str, Any],
    on_progress: Callable[[int], None],
) -> None:
    """Envuelve el archivo en files con ProgressFileWrapper. Modifica files in-place."""
    file_tuple = files["file"]
    file_obj = file_tuple[1]
    total = get_file_size(file_obj)
    files["file"] = (file_tuple[0], ProgressFileWrapper(file_obj, total, on_progress))


def _prepare_upload(
    file: IO[bytes] | pathlib.Path | str,
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, str] | None]:
    """Prepara los datos de subida de archivo.

    Returns:
        Tupla (files_dict, data_dict) para enviar con post_form.
    """
    import json as _json

    if name is not None:
        validate_string_length(name, "file name", max_len=FILE_NAME_MAX)

    # Resolver archivo
    filename: str
    if isinstance(file, (str, pathlib.Path)):
        path = pathlib.Path(file)
        file_obj: IO[bytes] = open(path, "rb")  # noqa: SIM115
        filename = name or path.name
    else:
        file_obj = file
        filename = name or str(getattr(file, "name", "file"))

    files: dict[str, Any] = {"file": (filename, file_obj)}

    data: dict[str, str] | None = None
    if name or metadata:
        data = {}
        if name:
            data["name"] = name
        if metadata:
            data["metadata"] = _json.dumps(metadata)

    return files, data


class FilesService:
    """Servicio asincrono de archivos adjuntos."""

    def __init__(self, client: UtiliaClient) -> None:
        self._client = client

    async def upload(
        self,
        file: IO[bytes] | pathlib.Path | str,
        *,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> UploadedFile:
        """Subir un archivo para adjuntar a tickets.

        Args:
            file: Archivo a subir (file-like, Path o ruta como string).
            name: Nombre personalizado para el archivo (opcional).
            metadata: Metadatos adicionales (opcional).
            on_progress: Callback de progreso que recibe porcentaje (0-100).

        Returns:
            Archivo subido con su ID.
        """
        files, data = _prepare_upload(file, name, metadata)
        if on_progress is not None:
            _wrap_with_progress(files, on_progress)

        try:
            raw = await self._client.post_form(
                f"{_BASE_PATH}/upload", files=files, data=data
            )
        finally:
            if isinstance(file, (str, pathlib.Path)):
                files["file"][1].close()

        return UploadedFile.model_validate(raw)

    async def get_url(self, file_id: str) -> str:
        """Obtener URL de descarga para un archivo.

        Args:
            file_id: ID del archivo.

        Returns:
            URL temporal de descarga.
        """
        raw = await self._client.get(f"{_BASE_PATH}/{file_id}/url")
        return raw["url"]  # type: ignore[no-any-return]

    async def get_quota(self) -> FileQuota:
        """Obtener informacion de quota de almacenamiento.

        Returns:
            Informacion de uso y limites.
        """
        raw = await self._client.get(f"{_BASE_PATH}/quota")
        return FileQuota.model_validate(raw)


class FilesSyncService:
    """Servicio sincrono de archivos adjuntos."""

    def __init__(self, client: UtiliaSyncClient) -> None:
        self._client = client

    def upload(
        self,
        file: IO[bytes] | pathlib.Path | str,
        *,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> UploadedFile:
        """Subir un archivo para adjuntar a tickets."""
        files, data = _prepare_upload(file, name, metadata)
        if on_progress is not None:
            _wrap_with_progress(files, on_progress)

        try:
            raw = self._client.post_form(
                f"{_BASE_PATH}/upload", files=files, data=data
            )
        finally:
            if isinstance(file, (str, pathlib.Path)):
                files["file"][1].close()

        return UploadedFile.model_validate(raw)

    def get_url(self, file_id: str) -> str:
        """Obtener URL de descarga para un archivo."""
        raw = self._client.get(f"{_BASE_PATH}/{file_id}/url")
        return raw["url"]  # type: ignore[no-any-return]

    def get_quota(self) -> FileQuota:
        """Obtener informacion de quota de almacenamiento."""
        raw = self._client.get(f"{_BASE_PATH}/quota")
        return FileQuota.model_validate(raw)
