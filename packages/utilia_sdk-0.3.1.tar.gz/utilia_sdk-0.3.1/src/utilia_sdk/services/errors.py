"""
Servicio de errores del sistema para el SDK de UTILIA OS.

Maneja operaciones de reporte, consulta y estadísticas de errores.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from utilia_sdk.models.common import PaginatedResponse, PaginationMeta
from utilia_sdk.models.error import (
    ErrorFilters,
    ErrorStats,
    ReportErrorInput,
    ReportedError,
    SystemErrorEntry,
)

if TYPE_CHECKING:
    from utilia_sdk._client import UtiliaClient
    from utilia_sdk._sync_client import UtiliaSyncClient

_BASE_PATH = "/external/v1/errors"


class ErrorsService:
    """Servicio asíncrono de errores del sistema."""

    def __init__(self, client: UtiliaClient) -> None:
        self._client = client

    async def report(self, data: ReportErrorInput) -> ReportedError:
        """Reporta un error del sistema con deduplicación automática.

        Args:
            data: Datos del error a reportar.

        Returns:
            Resultado con hash de deduplicación.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/report",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return ReportedError.model_validate(raw)

    async def list(
        self,
        filters: ErrorFilters | None = None,
    ) -> PaginatedResponse[SystemErrorEntry]:
        """Lista errores con filtros opcionales.

        Args:
            filters: Filtros opcionales (severidad, módulo, resuelto, fechas, paginación).

        Returns:
            Lista paginada de errores.
        """
        params: dict[str, Any] | None = None
        if filters is not None:
            params = filters.model_dump(by_alias=True, exclude_none=True)
        raw = await self._client.get(_BASE_PATH, params=params)
        errors = [SystemErrorEntry.model_validate(e) for e in raw["errors"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[SystemErrorEntry](data=errors, pagination=pagination)

    async def stats(self) -> ErrorStats:
        """Obtiene estadísticas agregadas de errores.

        Returns:
            Estadísticas con totales, por severidad, por módulo y top errores.
        """
        raw = await self._client.get(f"{_BASE_PATH}/stats")
        return ErrorStats.model_validate(raw)


class ErrorsSyncService:
    """Servicio síncrono de errores del sistema."""

    def __init__(self, client: UtiliaSyncClient) -> None:
        self._client = client

    def report(self, data: ReportErrorInput) -> ReportedError:
        """Reporta un error del sistema."""
        raw = self._client.post(
            f"{_BASE_PATH}/report",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return ReportedError.model_validate(raw)

    def list(
        self,
        filters: ErrorFilters | None = None,
    ) -> PaginatedResponse[SystemErrorEntry]:
        """Lista errores con filtros opcionales."""
        params: dict[str, Any] | None = None
        if filters is not None:
            params = filters.model_dump(by_alias=True, exclude_none=True)
        raw = self._client.get(_BASE_PATH, params=params)
        errors = [SystemErrorEntry.model_validate(e) for e in raw["errors"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[SystemErrorEntry](data=errors, pagination=pagination)

    def stats(self) -> ErrorStats:
        """Obtiene estadísticas agregadas de errores."""
        raw = self._client.get(f"{_BASE_PATH}/stats")
        return ErrorStats.model_validate(raw)
