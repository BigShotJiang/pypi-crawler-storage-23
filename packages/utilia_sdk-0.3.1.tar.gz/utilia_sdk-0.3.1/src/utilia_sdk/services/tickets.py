"""
Servicio de tickets de soporte.

Maneja todas las operaciones relacionadas con tickets:
crear, listar, obtener detalles, mensajes, cerrar y reabrir.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from utilia_sdk.models.common import PaginatedResponse, PaginationMeta
from utilia_sdk.models.ticket import (
    AddMessageInput,
    CreatedMessage,
    CreatedTicket,
    CreateTicketInput,
    TicketDetail,
    TicketFilters,
    TicketListItem,
    UnreadCount,
)

if TYPE_CHECKING:
    from utilia_sdk._client import UtiliaClient
    from utilia_sdk._sync_client import UtiliaSyncClient

_BASE_PATH = "/external/v1/tickets"


class TicketsService:
    """Servicio asincrono de tickets de soporte."""

    def __init__(self, client: UtiliaClient) -> None:
        self._client = client

    async def create(self, data: CreateTicketInput) -> CreatedTicket:
        """Crear un nuevo ticket de soporte.

        Args:
            data: Datos del ticket a crear.

        Returns:
            Ticket creado con su ID y clave unica.
        """
        raw = await self._client.post(
            _BASE_PATH,
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return CreatedTicket.model_validate(raw)

    async def list(
        self,
        user_id: str,
        filters: TicketFilters | None = None,
    ) -> PaginatedResponse[TicketListItem]:
        """Listar tickets de un usuario.

        Args:
            user_id: ID externo del usuario.
            filters: Filtros opcionales (status, paginacion).

        Returns:
            Lista paginada de tickets.
        """
        params: dict[str, Any] = {"userId": user_id}
        if filters:
            params.update(filters.model_dump(mode="json", by_alias=True, exclude_none=True))

        raw = await self._client.get(_BASE_PATH, params=params)
        tickets = [TicketListItem.model_validate(t) for t in raw["tickets"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[TicketListItem](data=tickets, pagination=pagination)

    async def get(self, ticket_id: str, user_id: str) -> TicketDetail:
        """Obtener detalle completo de un ticket.

        Args:
            ticket_id: ID del ticket.
            user_id: ID externo del usuario (para verificar acceso).

        Returns:
            Detalle del ticket con mensajes.
        """
        raw = await self._client.get(
            f"{_BASE_PATH}/{ticket_id}",
            params={"userId": user_id},
        )
        return TicketDetail.model_validate(raw)

    async def get_unread_count(self, user_id: str) -> UnreadCount:
        """Obtener conteo de mensajes no leidos para un usuario.

        Args:
            user_id: ID externo del usuario.

        Returns:
            Numero de mensajes no leidos.
        """
        raw = await self._client.get(
            f"{_BASE_PATH}/unread-count",
            params={"userId": user_id},
        )
        return UnreadCount.model_validate(raw)

    async def add_message(
        self,
        ticket_id: str,
        user_id: str,
        data: AddMessageInput,
    ) -> CreatedMessage:
        """Agregar un mensaje a un ticket existente.

        Args:
            ticket_id: ID del ticket.
            user_id: ID externo del usuario.
            data: Contenido del mensaje.

        Returns:
            Mensaje creado.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/{ticket_id}/messages",
            data.model_dump(by_alias=True, exclude_none=True),
            params={"userId": user_id},
        )
        return CreatedMessage.model_validate(raw)

    async def close(self, ticket_id: str, user_id: str) -> None:
        """Cerrar un ticket.

        Args:
            ticket_id: ID del ticket.
            user_id: ID externo del usuario.
        """
        await self._client.patch(
            f"{_BASE_PATH}/{ticket_id}/close",
            None,
            params={"userId": user_id},
        )

    async def reopen(self, ticket_id: str, user_id: str) -> None:
        """Reabrir un ticket cerrado.

        Args:
            ticket_id: ID del ticket.
            user_id: ID externo del usuario.
        """
        await self._client.patch(
            f"{_BASE_PATH}/{ticket_id}/reopen",
            None,
            params={"userId": user_id},
        )


class TicketsSyncService:
    """Servicio sincrono de tickets de soporte."""

    def __init__(self, client: UtiliaSyncClient) -> None:
        self._client = client

    def create(self, data: CreateTicketInput) -> CreatedTicket:
        """Crear un nuevo ticket de soporte."""
        raw = self._client.post(
            _BASE_PATH,
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return CreatedTicket.model_validate(raw)

    def list(
        self,
        user_id: str,
        filters: TicketFilters | None = None,
    ) -> PaginatedResponse[TicketListItem]:
        """Listar tickets de un usuario."""
        params: dict[str, Any] = {"userId": user_id}
        if filters:
            params.update(filters.model_dump(mode="json", by_alias=True, exclude_none=True))

        raw = self._client.get(_BASE_PATH, params=params)
        tickets = [TicketListItem.model_validate(t) for t in raw["tickets"]]
        pagination = PaginationMeta.model_validate(raw["pagination"])
        return PaginatedResponse[TicketListItem](data=tickets, pagination=pagination)

    def get(self, ticket_id: str, user_id: str) -> TicketDetail:
        """Obtener detalle completo de un ticket."""
        raw = self._client.get(
            f"{_BASE_PATH}/{ticket_id}",
            params={"userId": user_id},
        )
        return TicketDetail.model_validate(raw)

    def get_unread_count(self, user_id: str) -> UnreadCount:
        """Obtener conteo de mensajes no leidos para un usuario."""
        raw = self._client.get(
            f"{_BASE_PATH}/unread-count",
            params={"userId": user_id},
        )
        return UnreadCount.model_validate(raw)

    def add_message(
        self,
        ticket_id: str,
        user_id: str,
        data: AddMessageInput,
    ) -> CreatedMessage:
        """Agregar un mensaje a un ticket existente."""
        raw = self._client.post(
            f"{_BASE_PATH}/{ticket_id}/messages",
            data.model_dump(by_alias=True, exclude_none=True),
            params={"userId": user_id},
        )
        return CreatedMessage.model_validate(raw)

    def close(self, ticket_id: str, user_id: str) -> None:
        """Cerrar un ticket."""
        self._client.patch(
            f"{_BASE_PATH}/{ticket_id}/close",
            None,
            params={"userId": user_id},
        )

    def reopen(self, ticket_id: str, user_id: str) -> None:
        """Reabrir un ticket cerrado."""
        self._client.patch(
            f"{_BASE_PATH}/{ticket_id}/reopen",
            None,
            params={"userId": user_id},
        )
