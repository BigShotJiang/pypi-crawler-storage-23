"""
Servicio de IA para el SDK de UTILIA OS.

Proporciona funcionalidades de transcripción y sugerencias inteligentes
con soporte para polling asíncrono y síncrono.
"""

from __future__ import annotations

import asyncio
import threading
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from utilia_sdk.models.ai import (
    AiJobResult,
    AiJobStatus,
    AiSuggestInput,
    GetSuggestionsOptions,
    ReportClientErrorParams,
    SseEvent,
    SseStreamOptions,
    StreamSuggestionsHandle,
    StreamSuggestionsOptions,
    StreamTranscriptionOptions,
    SyncStreamSuggestionsHandle,
    TrackAiActionInput,
    TranscriptionJobStatus,
)

if TYPE_CHECKING:
    from utilia_sdk._client import UtiliaClient
    from utilia_sdk._sync_client import UtiliaSyncClient

_BASE_PATH = "/external/v1/tickets"


def _handle_sse_error(exc: Exception, opts: SseStreamOptions) -> None:
    """Gestiona errores en la conexión SSE: invoca callback y re-lanza."""
    if opts.on_error:
        opts.on_error(exc)
    if not isinstance(exc, RuntimeError):
        raise RuntimeError(f"Error en la conexión SSE: {exc}") from exc
    raise


def _build_report_error_payload(params: ReportClientErrorParams) -> dict[str, Any]:
    """Construye el payload para reportar un error de cliente."""
    return {
        "errors": [
            {
                "message": params.message,
                "stack": params.stack,
                "code": params.code,
                "severity": "low",
                "component": params.component or "sdk",
                "endpoint": params.endpoint,
                "method": params.method,
                "requestId": params.request_id,
                "url": params.url,
                "userAgent": params.user_agent,
            }
        ],
    }


class AiService:
    """Servicio asíncrono de IA para transcripción y sugerencias."""

    def __init__(self, client: UtiliaClient) -> None:
        self._client = client

    async def request_suggestions(self, data: AiSuggestInput) -> str:
        """Solicita sugerencias de IA de forma asíncrona.

        Retorna un jobId que se puede usar para consultar el estado.

        Args:
            data: Datos para generar sugerencias.

        Returns:
            ID del job para consultar estado.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/ai-suggest",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return raw["jobId"]  # type: ignore[no-any-return]

    async def get_suggestions_status(self, job_id: str) -> AiJobStatus:
        """Obtiene el estado de un job de sugerencias.

        Args:
            job_id: ID del job obtenido de request_suggestions.

        Returns:
            Estado actual del job.
        """
        raw = await self._client.get(f"{_BASE_PATH}/ai-suggest/{job_id}")
        return AiJobStatus.model_validate(raw)

    async def transcribe(self, audio_base64: str, audio_filename: str) -> str:
        """Transcribe audio a texto de forma síncrona.

        Usar solo para audios cortos (<30 segundos).

        Args:
            audio_base64: Audio codificado en base64.
            audio_filename: Nombre del archivo con extensión.

        Returns:
            Texto transcrito.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/ai-transcribe",
            {"audioBase64": audio_base64, "audioFilename": audio_filename},
        )
        return raw["transcription"]  # type: ignore[no-any-return]

    async def get_suggestions(
        self,
        data: AiSuggestInput,
        options: GetSuggestionsOptions | None = None,
        *,
        on_progress: Callable[[int], None] | None = None,
    ) -> AiJobResult | None:
        """Solicita sugerencias y espera el resultado con polling automático.

        Args:
            data: Datos para generar sugerencias.
            options: Opciones de polling.
            on_progress: Callback para reportar progreso (recibe int 0-100).

        Returns:
            Resultado con sugerencias y transcripción (si aplica).

        Raises:
            RuntimeError: Si el job falla o excede el timeout.
        """
        opts = options or GetSuggestionsOptions()

        job_id = await self.request_suggestions(data)
        start_time = time.monotonic()

        while (time.monotonic() - start_time) < opts.max_wait:
            status = await self.get_suggestions_status(job_id)

            if on_progress and status.progress is not None:
                on_progress(status.progress)

            if status.status == "completed":
                return status.result

            if status.status == "failed":
                raise RuntimeError(status.error or "Error al generar sugerencias")

            if status.status == "not_found":
                raise RuntimeError("Job no encontrado")

            await asyncio.sleep(opts.poll_interval)

        raise RuntimeError("Timeout: el job excedió el tiempo máximo de espera")

    async def track_ai_action(self, data: TrackAiActionInput) -> dict[str, Any]:
        """Registra la acción del usuario sobre sugerencias de IA.

        Args:
            data: Datos de la acción del usuario.

        Returns:
            Respuesta del servidor confirmando el registro.
        """
        return await self._client.post(  # type: ignore[no-any-return]
            f"{_BASE_PATH}/ai-track-action",
            data.model_dump(by_alias=True, exclude_none=True),
        )

    async def request_transcription(self, audio_base64: str, audio_filename: str) -> str:
        """Solicita transcripción asíncrona. Retorna un jobId.

        Para audios largos. Usar get_transcription_status() o
        stream_transcription() para obtener el resultado.

        Args:
            audio_base64: Audio codificado en base64.
            audio_filename: Nombre del archivo con extensión.

        Returns:
            ID del job para consultar estado.
        """
        raw = await self._client.post(
            f"{_BASE_PATH}/ai-transcribe-async",
            {"audioBase64": audio_base64, "audioFilename": audio_filename},
        )
        return raw["jobId"]  # type: ignore[no-any-return]

    async def get_transcription_status(self, job_id: str) -> TranscriptionJobStatus:
        """Obtiene el estado de un job de transcripción asíncrona.

        Args:
            job_id: ID del job obtenido de request_transcription.

        Returns:
            Estado actual del job de transcripción.
        """
        raw = await self._client.get(f"{_BASE_PATH}/ai-transcribe/{job_id}")
        return TranscriptionJobStatus.model_validate(raw)

    async def stream_suggestions(
        self,
        data: AiSuggestInput,
        options: SseStreamOptions | None = None,
    ) -> AiJobResult | None:
        """Solicita sugerencias y recibe resultado vía SSE en tiempo real.

        A diferencia del polling, este método abre una conexión SSE y
        recibe el resultado en cuanto está listo, sin esperas innecesarias.

        Args:
            data: Datos para generar sugerencias.
            options: Opciones de streaming (on_progress, on_error, timeout).

        Returns:
            Resultado con sugerencias y transcripción (si aplica).

        Raises:
            RuntimeError: Si el job falla o la conexión se cierra inesperadamente.
        """
        opts = options or SseStreamOptions()
        job_id = await self.request_suggestions(data)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-suggest/{job_id}/stream"
        )
        return await self._consume_sse_stream(
            sse_url, opts,
            extract_result=lambda e: e.result,
            default_error="Error al generar sugerencias",
        )

    async def stream_transcription(
        self,
        audio_base64: str,
        audio_filename: str,
        options: SseStreamOptions | None = None,
    ) -> str:
        """Solicita transcripción y recibe resultado vía SSE en tiempo real.

        Args:
            audio_base64: Audio codificado en base64.
            audio_filename: Nombre del archivo con extensión.
            options: Opciones de streaming (on_progress, on_error, timeout).

        Returns:
            Texto transcrito.

        Raises:
            RuntimeError: Si el job falla o la conexión se cierra inesperadamente.
        """
        opts = options or SseStreamOptions()
        job_id = await self.request_transcription(audio_base64, audio_filename)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-transcribe/{job_id}/stream"
        )
        return await self._consume_sse_stream(
            sse_url, opts,
            extract_result=lambda e: e.result.transcription if e.result and e.result.transcription else "",
            default_error="Error en la transcripción",
        )

    async def stream_suggestions_handle(
        self,
        data: AiSuggestInput,
        options: SseStreamOptions | None = None,
    ) -> StreamSuggestionsHandle:
        """Solicita sugerencias vía SSE con control de cancelación.

        A diferencia de stream_suggestions(), retorna un handle que permite
        abortar la operación con handle.abort(). El resultado se obtiene
        con await handle.result.

        Args:
            data: Datos para generar sugerencias.
            options: Opciones de streaming (on_progress, on_error, timeout).

        Returns:
            Handle con .result (awaitable) y .abort() para cancelar.
        """
        opts = options or SseStreamOptions()
        job_id = await self.request_suggestions(data)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-suggest/{job_id}/stream"
        )

        cancel_event = asyncio.Event()

        async def _run() -> AiJobResult | None:
            return await self._consume_sse_stream(
                sse_url,
                opts,
                extract_result=lambda e: e.result,
                default_error="Error al generar sugerencias",
                cancel_event=cancel_event,
            )

        task = asyncio.create_task(_run())

        def abort() -> None:
            cancel_event.set()

        return StreamSuggestionsHandle(result=task, abort=abort)

    async def report_error(self, params: ReportClientErrorParams) -> None:
        """Reporta un error del cliente al servidor.

        Este método NUNCA lanza excepciones. Los errores de reporte
        se ignoran silenciosamente para no afectar la aplicación.

        Args:
            params: Datos del error a reportar.
        """
        try:
            await self._client.post(
                f"{_BASE_PATH}/client-errors",
                _build_report_error_payload(params),
            )
        except Exception:
            pass  # Nunca fallar por un error de reporte

    async def _consume_sse_stream(
        self,
        sse_url: str,
        opts: SseStreamOptions,
        extract_result: Callable[[SseEvent], Any],
        default_error: str,
        cancel_event: asyncio.Event | None = None,
    ) -> Any:
        """Consume un stream SSE y retorna el resultado extraído."""
        try:
            async for event_data in self._client.stream_sse(
                sse_url, timeout=opts.timeout, cancel_event=cancel_event
            ):
                event = SseEvent.model_validate(event_data)
                if event.event == "progress":
                    if opts.on_progress and event.progress is not None:
                        opts.on_progress(event.progress)
                elif event.event == "completed":
                    return extract_result(event)
                elif event.event == "failed":
                    raise RuntimeError(event.error or default_error)
        except Exception as exc:
            _handle_sse_error(exc, opts)

        if cancel_event is not None and cancel_event.is_set():
            return None

        raise RuntimeError("La conexión SSE se cerró sin completar")


class AiSyncService:
    """Servicio síncrono de IA para transcripción y sugerencias."""

    def __init__(self, client: UtiliaSyncClient) -> None:
        self._client = client

    def request_suggestions(self, data: AiSuggestInput) -> str:
        """Solicita sugerencias de IA. Retorna un jobId."""
        raw = self._client.post(
            f"{_BASE_PATH}/ai-suggest",
            data.model_dump(by_alias=True, exclude_none=True),
        )
        return raw["jobId"]  # type: ignore[no-any-return]

    def get_suggestions_status(self, job_id: str) -> AiJobStatus:
        """Obtiene el estado de un job de sugerencias."""
        raw = self._client.get(f"{_BASE_PATH}/ai-suggest/{job_id}")
        return AiJobStatus.model_validate(raw)

    def transcribe(self, audio_base64: str, audio_filename: str) -> str:
        """Transcribe audio a texto."""
        raw = self._client.post(
            f"{_BASE_PATH}/ai-transcribe",
            {"audioBase64": audio_base64, "audioFilename": audio_filename},
        )
        return raw["transcription"]  # type: ignore[no-any-return]

    def get_suggestions(
        self,
        data: AiSuggestInput,
        options: GetSuggestionsOptions | None = None,
        *,
        on_progress: Callable[[int], None] | None = None,
    ) -> AiJobResult | None:
        """Solicita sugerencias y espera el resultado con polling automático."""
        opts = options or GetSuggestionsOptions()

        job_id = self.request_suggestions(data)
        start_time = time.monotonic()

        while (time.monotonic() - start_time) < opts.max_wait:
            status = self.get_suggestions_status(job_id)

            if on_progress and status.progress is not None:
                on_progress(status.progress)

            if status.status == "completed":
                return status.result

            if status.status == "failed":
                raise RuntimeError(status.error or "Error al generar sugerencias")

            if status.status == "not_found":
                raise RuntimeError("Job no encontrado")

            time.sleep(opts.poll_interval)

        raise RuntimeError("Timeout: el job excedió el tiempo máximo de espera")

    def track_ai_action(self, data: TrackAiActionInput) -> dict[str, Any]:
        """Registra la acción del usuario sobre sugerencias de IA.

        Args:
            data: Datos de la acción del usuario.

        Returns:
            Respuesta del servidor confirmando el registro.
        """
        return self._client.post(  # type: ignore[no-any-return]
            f"{_BASE_PATH}/ai-track-action",
            data.model_dump(by_alias=True, exclude_none=True),
        )

    def request_transcription(self, audio_base64: str, audio_filename: str) -> str:
        """Solicita transcripción asíncrona. Retorna un jobId."""
        raw = self._client.post(
            f"{_BASE_PATH}/ai-transcribe-async",
            {"audioBase64": audio_base64, "audioFilename": audio_filename},
        )
        return raw["jobId"]  # type: ignore[no-any-return]

    def get_transcription_status(self, job_id: str) -> TranscriptionJobStatus:
        """Obtiene el estado de un job de transcripción asíncrona."""
        raw = self._client.get(f"{_BASE_PATH}/ai-transcribe/{job_id}")
        return TranscriptionJobStatus.model_validate(raw)

    def stream_suggestions(
        self,
        data: AiSuggestInput,
        options: SseStreamOptions | None = None,
    ) -> AiJobResult | None:
        """Solicita sugerencias y recibe resultado vía SSE."""
        opts = options or SseStreamOptions()
        job_id = self.request_suggestions(data)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-suggest/{job_id}/stream"
        )
        return self._consume_sse_stream(
            sse_url, opts,
            extract_result=lambda e: e.result,
            default_error="Error al generar sugerencias",
        )

    def stream_transcription(
        self,
        audio_base64: str,
        audio_filename: str,
        options: SseStreamOptions | None = None,
    ) -> str:
        """Solicita transcripción y recibe resultado vía SSE."""
        opts = options or SseStreamOptions()
        job_id = self.request_transcription(audio_base64, audio_filename)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-transcribe/{job_id}/stream"
        )
        return self._consume_sse_stream(
            sse_url, opts,
            extract_result=lambda e: e.result.transcription if e.result and e.result.transcription else "",
            default_error="Error en la transcripción",
        )

    def stream_suggestions_handle(
        self,
        data: AiSuggestInput,
        options: SseStreamOptions | None = None,
    ) -> SyncStreamSuggestionsHandle:
        """Solicita sugerencias vía SSE con control de cancelación (síncrono).

        Returns:
            Handle con .result (Future) y .abort() para cancelar.
        """
        import concurrent.futures
        import threading

        opts = options or SseStreamOptions()
        job_id = self.request_suggestions(data)
        sse_url = self._client.build_sse_url(
            f"{_BASE_PATH}/ai-suggest/{job_id}/stream"
        )

        cancel_event = threading.Event()

        def _run() -> AiJobResult | None:
            return self._consume_sse_stream(
                sse_url,
                opts,
                extract_result=lambda e: e.result,
                default_error="Error al generar sugerencias",
                cancel_event=cancel_event,
            )

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = executor.submit(_run)
        future.add_done_callback(lambda _: executor.shutdown(wait=False))

        def abort() -> None:
            cancel_event.set()

        return SyncStreamSuggestionsHandle(result=future, abort=abort)

    def report_error(self, params: ReportClientErrorParams) -> None:
        """Reporta un error del cliente. Nunca lanza excepciones."""
        try:
            self._client.post(
                f"{_BASE_PATH}/client-errors",
                _build_report_error_payload(params),
            )
        except Exception:
            pass

    def _consume_sse_stream(
        self,
        sse_url: str,
        opts: SseStreamOptions,
        extract_result: Callable[[SseEvent], Any],
        default_error: str,
        cancel_event: threading.Event | None = None,
    ) -> Any:
        """Consume un stream SSE síncrono y retorna el resultado extraído."""
        try:
            for event_data in self._client.stream_sse(
                sse_url, timeout=opts.timeout, cancel_event=cancel_event
            ):
                event = SseEvent.model_validate(event_data)
                if event.event == "progress":
                    if opts.on_progress and event.progress is not None:
                        opts.on_progress(event.progress)
                elif event.event == "completed":
                    return extract_result(event)
                elif event.event == "failed":
                    raise RuntimeError(event.error or default_error)
        except Exception as exc:
            _handle_sse_error(exc, opts)

        if cancel_event is not None and cancel_event.is_set():
            return None

        raise RuntimeError("La conexión SSE se cerró sin completar")
