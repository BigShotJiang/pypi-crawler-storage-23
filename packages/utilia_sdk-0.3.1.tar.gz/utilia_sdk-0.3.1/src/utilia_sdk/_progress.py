"""Wrapper de archivo para reportar progreso de subida."""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import IO, Any


class ProgressFileWrapper:
    """Envuelve un file-like object para trackear bytes leidos.

    Intercepta llamadas a read() y reporta progreso via callback.
    El progreso se reporta como porcentaje entero (0-100).
    Solo invoca el callback cuando el porcentaje cambia.
    """

    def __init__(
        self,
        file_obj: IO[bytes],
        total_size: int,
        on_progress: Callable[[int], None],
    ) -> None:
        self._file = file_obj
        self._total = total_size
        self._read_bytes = 0
        self._on_progress = on_progress
        self._last_percent = -1

    def read(self, size: int = -1) -> bytes:
        data = self._file.read(size)
        if data:
            self._read_bytes += len(data)
            if self._total > 0:
                percent = min(100, round((self._read_bytes * 100) / self._total))
                if percent != self._last_percent:
                    self._last_percent = percent
                    self._on_progress(percent)
        return data

    @property
    def name(self) -> str:
        return getattr(self._file, "name", "file")

    def __getattr__(self, attr: str) -> Any:
        return getattr(self._file, attr)


def get_file_size(file_obj: IO[bytes]) -> int:
    """Obtiene el tamano total de un file-like object sin alterar la posicion.

    Retorna 0 si el stream no es seekable.
    """
    try:
        current_pos = file_obj.tell()
        file_obj.seek(0, os.SEEK_END)
        size = file_obj.tell()
        file_obj.seek(current_pos)
        return size
    except (OSError, AttributeError):
        return 0
