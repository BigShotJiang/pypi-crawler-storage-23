# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

pytest_plugins = [
    "data_designer.config.testing.fixtures",
    "data_designer.engine.testing.fixtures",
]
