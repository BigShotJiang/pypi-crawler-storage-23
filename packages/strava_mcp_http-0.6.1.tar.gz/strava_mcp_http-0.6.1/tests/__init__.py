# Test package for the Strava MCP server
