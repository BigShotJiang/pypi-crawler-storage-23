# Security Policy

This repository follows coordinated vulnerability disclosure.

## Reporting a Vulnerability

- Email: `hey@sanka.com`
- Preferred channel: GitHub Private Vulnerability Reporting (Security Advisories)
- Do not open public issues for security reports.

Please include:
- affected component/path
- impact and exploit scenario
- reproduction steps or PoC
- suggested mitigation (if available)

## Response Targets (SLA)

- Acknowledgement: within 2 business days
- Initial triage: within 7 business days
- Remediation target:
- Critical/High: 30 days
- Medium/Low: 90 days

## Disclosure Process

1. Private report received and triaged.
2. Fix is developed and validated privately.
3. Patch is released.
4. Security advisory is published with affected/fixed versions.

Details: `docs/oss-readiness/VULNERABILITY_DISCLOSURE.md`
