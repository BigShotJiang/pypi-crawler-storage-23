# Contributing

Thanks for contributing.

## Development Setup

- Run tests and CLI from repository root.

## Quality Gate

Before submitting a PR, run:

- `uv run ruff format --check --diff .`
- `uv run ruff check .`
- `uv run pytest tests/<target>.py -q`

## Commit and PR Rules

- Use Conventional Commits (`feat:`, `fix:`, `refactor:`).
- Keep changes focused and include rationale in PR description.
- For UI changes, include screenshots.
- For migrations/config changes, include rollout notes.

## Security Issues

Do not file public issues for vulnerabilities.  
See `SECURITY.md`.

## Developer Certificate of Origin (DCO)

This project uses DCO (no CLA).

By contributing, you certify:
- you have the right to submit the work under the project license
- you agree the contribution can be redistributed under the repository license

Add sign-off to each commit:

```bash
git commit -s -m "feat: your change"
```

This adds:

```text
Signed-off-by: Your Name <you@example.com>
```
