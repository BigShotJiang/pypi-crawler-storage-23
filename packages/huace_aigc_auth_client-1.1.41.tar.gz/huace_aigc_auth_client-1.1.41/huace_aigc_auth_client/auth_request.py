"""
认证请求封装模块
提供对 requests.request 和 httpx 的封装，自动添加认证信息和统计上报
"""
import time
import logging
from typing import Optional, Dict, Any, Union
import requests
from requests import Response

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False
    httpx = None

from .user_context import get_request_context, get_trace_id
from .api_stats_collector import get_api_stats_collector

logger = logging.getLogger(__name__)
def setLogger(log):
    """
    统一设置所有模块的 logger
    
    Args:
        log: logging.Logger 实例
    """
    global logger
    logger = log

def _report_stats(
    url: str,
    method: str,
    response: Optional[Response],
    response_time: float,
    error_message: Optional[str],
    request_context: Optional[Dict[str, Any]],
    headers: Optional[Dict[str, str]],
    params: Optional[Dict[str, Any]],
    json_data: Optional[Dict[str, Any]],
    form_data: Optional[Union[Dict[str, Any], str, bytes]]
):
    """
    上报统计信息到远程服务
    
    Args:
        url: 请求 URL
        method: HTTP 方法
        response: 响应对象
        response_time: 响应时间
        error_message: 错误信息
        request_context: 请求上下文
        params: 查询参数
        json_data: JSON 数据
        form_data: 表单数据
    """
    try:
        # 获取统计收集器
        collector = get_api_stats_collector()
        if not collector:
            return
        
        # 获取 token
        token = request_context.get('token') if request_context else None
        if not token:
            return
        
        # 解析 URL 获取路径
        from urllib.parse import urlparse
        parsed_url = urlparse(url)
        api_path = parsed_url.path or '/'
        # 带上协议和域名
        api_path = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path or '/'}"
        
        # 获取状态码
        status_code = response.status_code if response else 500
        
        # 构建请求参数（与 api_stats_collector 格式一致）
        request_params = {
            'query_params': params or {},
            'headers': headers
        }
        
        # 添加请求体数据
        if json_data:
            request_params['request_body'] = json_data
        elif isinstance(form_data, dict):
            request_params['form_params'] = form_data
        
        # 收集统计
        collector.collect(
            api_path=api_path,
            api_method=method.upper(),
            status_code=status_code,
            response_time=response_time,
            token=token,
            error_message=error_message,
            request_params=request_params
        )
        
    except Exception as e:
        # 静默失败，不影响主流程
        logger.debug(f"统计上报失败: {e}")

def auth_request(
    method: str,
    url: str,
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Union[Dict[str, Any], str, bytes]] = None,
    json: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    cookies: Optional[Dict[str, str]] = None,
    files: Optional[Dict[str, Any]] = None,
    auth: Optional[tuple] = None,
    timeout: Optional[Union[float, tuple]] = None,
    allow_redirects: bool = True,
    proxies: Optional[Dict[str, str]] = None,
    verify: Optional[Union[bool, str]] = None,
    stream: bool = False,
    cert: Optional[Union[str, tuple]] = None,
    **kwargs
) -> Response:
    """
    认证请求封装函数
    
    基本参数与 requests.request 一致，会自动从 request_context 中获取认证信息并添加到请求头
    
    Args:
        method: HTTP 方法 (GET, POST, PUT, DELETE 等)
        url: 请求 URL
        params: URL 查询参数
        data: 请求体数据 (form-data 或 raw)
        json: JSON 请求体数据
        headers: 请求头（会自动添加认证相关的头）
        cookies: Cookies
        files: 文件上传
        auth: HTTP 认证元组
        timeout: 超时时间（秒）
        allow_redirects: 是否允许重定向
        proxies: 代理配置
        verify: SSL 证书验证
        stream: 是否流式响应
        cert: 客户端证书
        **kwargs: 其他 requests.request 支持的参数
    
    Returns:
        Response: 响应对象
    
    自动添加的请求头（如果在 request_context 中存在）：
        - X-App-ID: 应用ID
        - X-App-Secret: 应用密钥
        - Authorization: Bearer token
        - x-real-ip: 客户端真实IP
        - user-agent: User Agent
        - X-Trace-ID: 追踪ID
    """
    # 初始化 headers
    if headers is None:
        headers = {}
    else:
        headers = headers.copy()  # 避免修改原始 headers
    
    # 从 request_context 获取认证信息
    request_context = get_request_context()
    
    if request_context:
        # 添加客户端IP
        ip_address = request_context.get('ip_address')
        if ip_address:
            headers['x-real-ip'] = ip_address
        
        # 添加 User Agent
        user_agent = request_context.get('user_agent')
        if user_agent:
            headers['user-agent'] = user_agent
    
    # 添加追踪ID
    trace_id = get_trace_id()
    if trace_id:
        headers['X-Trace-ID'] = trace_id
    
    # 记录开始时间
    start_time = time.time()
    response = None
    error_message = None
    
    try:
        # 执行请求
        logger.info(f"发起认证请求: {method} {url} with headers={headers} params={params} json={json} data={data}")
        response = requests.request(
            method=method,
            url=url,
            params=params,
            data=data,
            json=json,
            headers=headers,
            cookies=cookies,
            files=files,
            auth=auth,
            timeout=timeout,
            allow_redirects=allow_redirects,
            proxies=proxies,
            verify=verify,
            stream=stream,
            cert=cert,
            **kwargs
        )
        logger.info(f"认证请求响应: {method} {url} 状态码: {response.status_code}")
        return response
        
    except Exception as e:
        error_message = str(e)
        logger.error(f"认证请求失败: {method} {url} 错误: {error_message}")
        raise
        
    finally:
        # 计算响应时间
        response_time = time.time() - start_time
        
        # 上报统计信息
        _report_stats(
            url=url,
            method=method,
            response=response,
            response_time=response_time,
            error_message=error_message,
            request_context=request_context,
            headers=headers,
            params=params,
            json_data=json,
            form_data=data
        )

def auth_request_get(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    **kwargs
) -> Response:
    """
    GET 请求快捷方法
    
    Args:
        url: 请求 URL
        params: URL 查询参数
        headers: 请求头
        **kwargs: 其他 auth_request 支持的参数
    
    Returns:
        Response: 响应对象
    """
    return auth_request('GET', url, params=params, headers=headers, **kwargs)

def auth_request_post(
    url: str,
    data: Optional[Union[Dict[str, Any], str, bytes]] = None,
    json: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    **kwargs
) -> Response:
    """
    POST 请求快捷方法
    
    Args:
        url: 请求 URL
        data: 请求体数据 (form-data 或 raw)
        json: JSON 请求体数据
        params: URL 查询参数
        headers: 请求头
        **kwargs: 其他 auth_request 支持的参数
    
    Returns:
        Response: 响应对象
    """
    return auth_request('POST', url, data=data, json=json, params=params, headers=headers, **kwargs)


# ============ Session 封装（支持连接池） ============

class AuthSession(requests.Session):
    """
    认证 Session 类（支持连接池）
    
    继承 requests.Session，自动添加认证信息和统计上报
    支持连接池，提升性能
    
    使用示例：
        from huace_aigc_auth_client import AuthSession, set_request_context
        
        # 设置请求上下文
        set_request_context(
            app_id='your-app-id',
            app_secret='your-app-secret',
            token='user-token'
        )
        
        # 创建 Session（自动启用连接池）
        with AuthSession() as session:
            # GET 请求
            response = session.get('https://api.example.com/users')
            
            # POST 请求
            response = session.post(
                'https://api.example.com/users',
                json={'name': 'John'}
            )
    """
    
    def request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Union[Dict[str, Any], str, bytes]] = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        files: Optional[Dict[str, Any]] = None,
        auth: Optional[tuple] = None,
        timeout: Optional[Union[float, tuple]] = None,
        allow_redirects: bool = True,
        proxies: Optional[Dict[str, str]] = None,
        hooks: Optional[Dict[str, Any]] = None,
        stream: bool = False,
        verify: Optional[Union[bool, str]] = None,
        cert: Optional[Union[str, tuple]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> Response:
        """
        重写 request 方法，添加认证信息和统计上报
        """
        # 初始化 headers
        if headers is None:
            headers = {}
        else:
            headers = headers.copy()
        
        # 从 request_context 获取认证信息
        request_context = get_request_context()
        
        if request_context:
            # 添加应用ID
            app_id = request_context.get('app_id')
            if app_id is not None:
                headers['X-App-ID'] = str(app_id)
            
            # 添加应用密钥
            app_secret = request_context.get('app_secret')
            if app_secret:
                headers['X-App-Secret'] = app_secret
            
            # 添加认证令牌
            token = request_context.get('token')
            if token:
                headers['Authorization'] = f'Bearer {token}'
            
            # 添加客户端IP
            ip_address = request_context.get('ip_address')
            if ip_address:
                headers['x-real-ip'] = ip_address
            
            # 添加 User Agent
            user_agent = request_context.get('user_agent')
            if user_agent:
                headers['user-agent'] = user_agent
        
        # 添加追踪ID
        trace_id = get_trace_id()
        if trace_id:
            headers['X-Trace-ID'] = trace_id
        
        # 记录开始时间
        start_time = time.time()
        response = None
        error_message = None
        
        try:
            # 调用父类的 request 方法
            logger.info(f"AuthSession 发起请求: {method} {url} with headers={headers}")
            response = super().request(
                method=method,
                url=url,
                params=params,
                data=data,
                headers=headers,
                cookies=cookies,
                files=files,
                auth=auth,
                timeout=timeout,
                allow_redirects=allow_redirects,
                proxies=proxies,
                hooks=hooks,
                stream=stream,
                verify=verify,
                cert=cert,
                json=json,
            )
            logger.info(f"AuthSession 请求响应: {method} {url} 状态码: {response.status_code}")
            return response
            
        except Exception as e:
            error_message = str(e)
            logger.error(f"AuthSession 请求失败: {method} {url} 错误: {error_message}")
            raise
            
        finally:
            # 计算响应时间
            response_time = time.time() - start_time
            
            # 上报统计信息
            _report_stats(
                url=url,
                method=method,
                response=response,
                response_time=response_time,
                error_message=error_message,
                request_context=request_context,
                headers=headers,
                params=params,
                json_data=json,
                form_data=data
            )


# ============ HTTPX 异步请求封装 ============

if HTTPX_AVAILABLE:
    
    async def async_auth_httpx_request(
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Union[Dict[str, Any], str, bytes]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        files: Optional[Dict[str, Any]] = None,
        auth: Optional[tuple] = None,
        timeout: Optional[Union[float, httpx.Timeout]] = None,
        follow_redirects: bool = True,
        **kwargs
    ) -> httpx.Response:
        """
        异步认证请求封装函数（httpx）
        
        基本参数与 httpx.request 一致，会自动从 request_context 中获取认证信息并添加到请求头
        
        Args:
            method: HTTP 方法 (GET, POST, PUT, DELETE 等)
            url: 请求 URL
            params: URL 查询参数
            data: 请求体数据 (form-data 或 raw)
            json: JSON 请求体数据
            headers: 请求头（会自动添加认证相关的头）
            cookies: Cookies
            files: 文件上传
            auth: HTTP 认证元组
            timeout: 超时时间（秒）
            follow_redirects: 是否允许重定向
            **kwargs: 其他 httpx.request 支持的参数
        
        Returns:
            httpx.Response: 响应对象
        
        自动添加的请求头（如果在 request_context 中存在）：
            - X-App-ID: 应用ID
            - X-App-Secret: 应用密钥
            - Authorization: Bearer token
            - x-real-ip: 客户端真实IP
            - user-agent: User Agent
            - X-Trace-ID: 追踪ID
        """
        # 初始化 headers
        if headers is None:
            headers = {}
        else:
            headers = headers.copy()  # 避免修改原始 headers
        
        # 从 request_context 获取认证信息
        request_context = get_request_context()
        
        if request_context:
            # 添加应用ID
            app_id = request_context.get('app_id')
            if app_id is not None:
                headers['X-App-ID'] = str(app_id)
            
            # 添加应用密钥
            app_secret = request_context.get('app_secret')
            if app_secret:
                headers['X-App-Secret'] = app_secret
            
            # 添加认证令牌
            token = request_context.get('token')
            if token:
                headers['Authorization'] = f'Bearer {token}'
            
            # 添加客户端IP
            ip_address = request_context.get('ip_address')
            if ip_address:
                headers['x-real-ip'] = ip_address
            
            # 添加 User Agent
            user_agent = request_context.get('user_agent')
            if user_agent:
                headers['user-agent'] = user_agent
        
        # 添加追踪ID
        trace_id = get_trace_id()
        if trace_id:
            headers['X-Trace-ID'] = trace_id
        
        # 记录开始时间
        start_time = time.time()
        response = None
        error_message = None
        
        try:
            # 执行异步请求
            logger.info(f"发起异步认证请求: {method} {url} with headers={headers} params={params} json={json} data={data}")
            
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    params=params,
                    data=data,
                    json=json,
                    headers=headers,
                    cookies=cookies,
                    files=files,
                    auth=auth,
                    follow_redirects=follow_redirects,
                    **kwargs
                )
            
            logger.info(f"异步认证请求响应: {method} {url} 状态码: {response.status_code}")
            return response
            
        except Exception as e:
            error_message = str(e)
            logger.error(f"异步认证请求失败: {method} {url} 错误: {error_message}")
            raise
            
        finally:
            # 计算响应时间
            response_time = time.time() - start_time
            
            # 上报统计信息
            _report_stats(
                url=url,
                method=method,
                response=response,
                response_time=response_time,
                error_message=error_message,
                request_context=request_context,
                headers=headers,
                params=params,
                json_data=json,
                form_data=data
            )
    
    async def async_auth_httpx_request_get(
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> httpx.Response:
        """
        异步 GET 请求快捷方法
        
        Args:
            url: 请求 URL
            params: URL 查询参数
            headers: 请求头
            **kwargs: 其他 async_auth_httpx_request 支持的参数
        
        Returns:
            httpx.Response: 响应对象
        """
        return await async_auth_httpx_request('GET', url, params=params, headers=headers, **kwargs)
    
    async def async_auth_httpx_request_post(
        url: str,
        data: Optional[Union[Dict[str, Any], str, bytes]] = None,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> httpx.Response:
        """
        异步 POST 请求快捷方法
        
        Args:
            url: 请求 URL
            data: 请求体数据 (form-data 或 raw)
            json: JSON 请求体数据
            params: URL 查询参数
            headers: 请求头
            **kwargs: 其他 async_auth_httpx_request 支持的参数
        
        Returns:
            httpx.Response: 响应对象
        """
        return await async_auth_httpx_request('POST', url, data=data, json=json, params=params, headers=headers, **kwargs)
     
    class AsyncAuthClient:
        """
        异步认证客户端（httpx.AsyncClient 包装）
        
        提供可复用的异步 HTTP 客户端，自动处理认证信息和统计上报
        """
        
        def __init__(
            self,
            base_url: Optional[str] = None,
            timeout: Optional[Union[float, httpx.Timeout]] = None,
            follow_redirects: bool = True,
            **kwargs
        ):
            """
            初始化异步认证客户端
            
            Args:
                base_url: 基础 URL
                timeout: 超时配置
                follow_redirects: 是否允许重定向
                **kwargs: 其他 httpx.AsyncClient 支持的参数
            """
            self.base_url = base_url
            self.timeout = timeout
            self.follow_redirects = follow_redirects
            self.client_kwargs = kwargs
            self._client: Optional[httpx.AsyncClient] = None
        
        async def __aenter__(self):
            """进入异步上下文"""
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                follow_redirects=self.follow_redirects,
                **self.client_kwargs
            )
            return self
        
        async def __aexit__(self, exc_type, exc_val, exc_tb):
            """退出异步上下文"""
            if self._client:
                await self._client.aclose()
                self._client = None
        
        def _prepare_headers(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
            """准备请求头（添加认证信息）"""
            # 初始化 headers
            if headers is None:
                headers = {}
            else:
                headers = headers.copy()
            
            # 从 request_context 获取认证信息
            request_context = get_request_context()
            
            if request_context:
                # 添加应用ID
                app_id = request_context.get('app_id')
                if app_id is not None:
                    headers['X-App-ID'] = str(app_id)
                
                # 添加应用密钥
                app_secret = request_context.get('app_secret')
                if app_secret:
                    headers['X-App-Secret'] = app_secret
                
                # 添加认证令牌
                token = request_context.get('token')
                if token:
                    headers['Authorization'] = f'Bearer {token}'
                
                # 添加客户端IP
                ip_address = request_context.get('ip_address')
                if ip_address:
                    headers['x-real-ip'] = ip_address
                
                # 添加 User Agent
                user_agent = request_context.get('user_agent')
                if user_agent:
                    headers['user-agent'] = user_agent
            
            # 添加追踪ID
            trace_id = get_trace_id()
            if trace_id:
                headers['X-Trace-ID'] = trace_id
            
            return headers
        
        async def _request(
            self,
            method: str,
            url: str,
            **kwargs
        ) -> httpx.Response:
            """执行请求（内部方法）"""
            if self._client is None:
                raise RuntimeError("Client not initialized. Use 'async with AsyncAuthClient()' context manager.")
            
            # 准备 headers
            headers = kwargs.pop('headers', None)
            headers = self._prepare_headers(headers)
            
            # 提取参数用于统计
            params = kwargs.get('params')
            json_data = kwargs.get('json')
            form_data = kwargs.get('data')
            
            # 记录开始时间
            start_time = time.time()
            response = None
            error_message = None
            request_context = get_request_context()
            
            try:
                # 执行请求
                logger.info(f"AsyncAuthClient 发起请求: {method} {url} with headers={headers}")
                response = await self._client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    **kwargs
                )
                logger.info(f"AsyncAuthClient 请求响应: {method} {url} 状态码: {response.status_code}")
                return response
                
            except Exception as e:
                error_message = str(e)
                logger.error(f"AsyncAuthClient 请求失败: {method} {url} 错误: {error_message}")
                raise
                
            finally:
                # 计算响应时间
                response_time = time.time() - start_time
                
                # 上报统计信息
                full_url = str(self._client.build_request(method, url).url) if self._client else url
                _report_stats(
                    url=full_url,
                    method=method,
                    response=response,
                    response_time=response_time,
                    error_message=error_message,
                    request_context=request_context,
                    headers=headers,
                    params=params,
                    json_data=json_data,
                    form_data=form_data
                )
        
        async def get(self, url: str, **kwargs) -> httpx.Response:
            """GET 请求"""
            return await self._request('GET', url, **kwargs)
        
        async def post(self, url: str, **kwargs) -> httpx.Response:
            """POST 请求"""
            return await self._request('POST', url, **kwargs)
        
        async def put(self, url: str, **kwargs) -> httpx.Response:
            """PUT 请求"""
            return await self._request('PUT', url, **kwargs)
        
        async def delete(self, url: str, **kwargs) -> httpx.Response:
            """DELETE 请求"""
            return await self._request('DELETE', url, **kwargs)
        
        async def patch(self, url: str, **kwargs) -> httpx.Response:
            """PATCH 请求"""
            return await self._request('PATCH', url, **kwargs)
        
        async def head(self, url: str, **kwargs) -> httpx.Response:
            """HEAD 请求"""
            return await self._request('HEAD', url, **kwargs)
        
        async def options(self, url: str, **kwargs) -> httpx.Response:
            """OPTIONS 请求"""
            return await self._request('OPTIONS', url, **kwargs)


# ============ 使用示例 ============
"""
使用示例：

1. 基本使用（自动从 request_context 获取认证信息）：
    
    from huace_aigc_auth_client.auth_request import auth_request
    from huace_aigc_auth_client.user_context import set_request_context
    
    # 设置请求上下文
    set_request_context(
        app_id='your-app-id',
        app_secret='your-app-secret',
        token='user-access-token',
        ip_address='192.168.1.1',
        user_agent='Mozilla/5.0...',
        trace_id='trace-123'
    )
    
    # 发起请求（会自动添加认证信息）
    response = auth_request('GET', 'https://api.example.com/data')
    print(response.json())


2. 使用 AuthSession（支持连接池，推荐）：
    
    from huace_aigc_auth_client.auth_request import AuthSession
    from huace_aigc_auth_client.user_context import set_request_context
    
    # 设置请求上下文
    set_request_context(
        app_id='your-app-id',
        app_secret='your-app-secret',
        token='user-access-token'
    )
    
    # 使用 AuthSession（自动启用连接池）
    with AuthSession() as session:
        # GET 请求
        response = session.get('https://api.example.com/users', params={'page': 1})
        print(response.json())
        
        # POST 请求
        response = session.post(
            'https://api.example.com/users',
            json={'name': 'John', 'email': 'john@example.com'}
        )
        print(response.json())
        
        # 多个请求复用同一个连接池，性能更好
        for i in range(10):
            response = session.get(f'https://api.example.com/items/{i}')


3. 不使用上下文管理器的 AuthSession：
    
    from huace_aigc_auth_client.auth_request import AuthSession
    
    # 创建 Session
    session = AuthSession()
    
    try:
        response = session.get('https://api.example.com/users')
        print(response.json())
    finally:
        session.close()  # 手动关闭


4. 带参数的请求：
    
    # GET 请求带查询参数
    response = auth_request(
        'GET',
        'https://api.example.com/users',
        params={'page': 1, 'size': 10}
    )
    
    # POST 请求带 JSON 数据
    response = auth_request(
        'POST',
        'https://api.example.com/users',
        json={'name': 'John', 'email': 'john@example.com'}
    )
    
    # POST 请求带表单数据
    response = auth_request(
        'POST',
        'https://api.example.com/upload',
        data={'field1': 'value1', 'field2': 'value2'}
    )


5. 覆盖默认 headers：
    
    # 可以手动指定 headers，会与自动添加的 headers 合并
    response = auth_request(
        'GET',
        'https://api.example.com/data',
        headers={'Custom-Header': 'custom-value'}
    )


4. 与 API 统计收集器配合使用：
    
    from huace_aigc_auth_client.api_stats_collector import init_api_stats_collector
    from huace_aigc_auth_client.auth_request import auth_request
    from huace_aigc_auth_client.user_context import set_request_context
    
    # 初始化统计收集器
    init_api_stats_collector(
        api_url='http://auth.example.com/api/sdk',
        app_id='your-app-id',
        app_secret='your-app-secret',
        enabled=True
    )
    
    # 设置请求上下文
    set_request_context(
        app_id='your-app-id',
        app_secret='your-app-secret',
        token='user-access-token'
    )
    
    # 发起请求（会自动上报统计）
    response = auth_request('GET', 'https://api.example.com/data')


5. 使用 httpx 异步请求（需要安装 httpx）：
    
    from huace_aigc_auth_client.auth_request import async_auth_request, AsyncAuthClient
    from huace_aigc_auth_client.user_context import set_request_context
    import asyncio
    
    # 设置请求上下文
    set_request_context(
        app_id='your-app-id',
        app_secret='your-app-secret',
        token='user-access-token'
    )
    
    # 方式1：使用 async_auth_request 函数
    async def example1():
        response = await async_auth_request('GET', 'https://api.example.com/data')
        print(response.json())
    
    # 方式2：使用 AsyncAuthClient（推荐用于多个请求）
    async def example2():
        async with AsyncAuthClient(timeout=10.0) as client:
            # POST 请求带 JSON
            response = await client.post(
                'https://api.example.com/users',
                json={'name': 'John', 'email': 'john@example.com'}
            )
            print(response.json())
            
            # GET 请求带参数
            response = await client.get(
                'https://api.example.com/users',
                params={'page': 1, 'size': 10}
            )
            print(response.json())
    
    # 运行
    asyncio.run(example1())
    asyncio.run(example2())
"""
