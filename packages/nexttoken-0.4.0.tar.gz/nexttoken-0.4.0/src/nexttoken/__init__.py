"""NextToken SDK - Simple client for the NextToken Gateway."""

from .client import NextToken
from .email import Email
from .integrations import Integrations
from .search import Search

__version__ = "0.4.0"
__all__ = ["NextToken", "Email", "Integrations", "Search", "__version__"]
