#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# setup.py
# NodeModulesCleaner
# Melhorado para PyPI
#

from setuptools import setup, find_packages
import pathlib

# Diretório base
HERE = pathlib.Path(__file__).parent

# Long description a partir do README
LONG_DESC = (HERE / "README.md").read_text(encoding="utf-8")

# Metadados do projeto
setup(
    name="nodemodulescleaner",                          # Nome público no PyPI
    version="1.0.0.1",                                    # Versão sem sufixos extras
    author="Heitor Bisneto",
    author_email="heitor.bardemaker@live.com",
    description="Automatic cleanup of forgotten node_modules directories",
    long_description=LONG_DESC,
    long_description_content_type="text/markdown",
    url="https://github.com/hbisneto/NodeModulesCleaner",   # Página principal
    project_urls={
        "Homepage": "https://github.com/hbisneto/NodeModulesCleaner",
        "Repository": "https://github.com/hbisneto/NodeModulesCleaner.git",
        "Issues": "https://github.com/hbisneto/NodeModulesCleaner/issues",
    },
    # Pacotes Python
    packages=find_packages(where="."),

    # Scripts / Entrypoints
    entry_points={
        "console_scripts": [
            "nmc = nmc.cli:main",   # Gera comando "nmc"
        ],
    },

    # Requisitos
    install_requires=[
        # Se o projeto tem dependências, elas vão aqui
        # Ex: "tqdm>=4.0.0", "click>=8.0.0"
        "filesystempro==3.0.0.0",
    ],

    # Requisitos extras (testes, dev etc.)
    extras_require={
        "dev": ["pytest>=7.0.0"],   # Ferramentas de desenvolvimento
    },

    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: End Users/Desktop",
        "Topic :: Utilities",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],

    python_requires=">=3.10",   # Requer Python >= 3.10

    keywords=[
        "node_modules", "cleanup", "filesystem", "CLI", "disk-space",
        "automation", "python-tool", "directory-management"
    ],
    # Inclusão automática de arquivos extras no sdist/wheel
    include_package_data=True,
)