from crispy_forms.layout import Column


class Column1(Column):
    css_class = "col-md-1"


class Column2(Column):
    css_class = "col-md-2"


class Column3(Column):
    css_class = "col-md-3"


class Column4(Column):
    css_class = "col-md-4"


class Column5(Column):
    css_class = "col-md-5"


class Column6(Column):
    css_class = "col-md-6"


class Column7(Column):
    css_class = "col-md-7"


class Column8(Column):
    css_class = "col-md-8"


class Column9(Column):
    css_class = "col-md-9"


class Column10(Column):
    css_class = "col-md-10"


class Column11(Column):
    css_class = "col-md-11"


class Column12(Column):
    css_class = "col-md-12"
