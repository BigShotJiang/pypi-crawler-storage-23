"""Engine implementations for sageLLM Core.

DEPRECATED: This module contains legacy engine implementations.
Use LLMEngine from sagellm_core instead:

    from sagellm_core import LLMEngine, LLMEngineConfig

    config = LLMEngineConfig(
        model_path="Qwen/Qwen2-7B",
        backend_type="cuda",  # or "cpu", "ascend", "auto"
    )
    engine = LLMEngine(config)
    await engine.start()
    response = await engine.generate("Hello!")

Remaining engines:
- EmbeddingEngine: Embedding model inference (not yet migrated to LLMEngine)
"""

from __future__ import annotations

# Only EmbeddingEngine remains - others have been migrated to LLMEngine
from sagellm_core.engines.cpu_embedding import CPUEmbeddingEngine
from sagellm_core.engines.embedding import EmbeddingEngine, EmbeddingEngineConfig
from sagellm_core.engines.registry import (
    get_embedding_engine_class,
    list_embedding_backends,
    register_embedding_engine,
)

__all__ = [
    "CPUEmbeddingEngine",
    # Embedding engine (still needed for embedding-only models)
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
    "register_embedding_engine",
    "get_embedding_engine_class",
    "list_embedding_backends",
]
