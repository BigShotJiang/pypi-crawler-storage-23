"""Kernel injection framework for sageLLM.

This module provides the kernel injection infrastructure that enables
backend-specific kernels to be injected into model layers at runtime.

Components:
- KernelInjector: Injects kernels into model layers
- OperatorRegistry: Maintains kernel registrations
- KernelSpec: Specification for a registered kernel
- FusedKernelManager: Manages fused kernel integration (issue #39)

This addresses issue #36 and #39.
"""

from __future__ import annotations

from sagellm_core.kernel_injection.backend_bridge import BackendKernelRegistry
from sagellm_core.kernel_injection.fused_kernels import (
    FusedKernelManager,
    FusionConfig,
    FusionPattern,
    detect_fusion_opportunities,
)
from sagellm_core.kernel_injection.integration import (
    inject_kernels_into_model,
    register_backend_kernels,
    setup_kernel_injection,
)
from sagellm_core.kernel_injection.kernel_injector import (
    KernelInjectable,
    KernelInjector,
    KernelSpec,
    OperatorRegistry,
)

__all__ = [
    "KernelInjector",
    "OperatorRegistry",
    "KernelSpec",
    "KernelInjectable",
    "BackendKernelRegistry",
    "FusedKernelManager",
    "FusionConfig",
    "FusionPattern",
    "detect_fusion_opportunities",
    "setup_kernel_injection",
    "inject_kernels_into_model",
    "register_backend_kernels",
]
