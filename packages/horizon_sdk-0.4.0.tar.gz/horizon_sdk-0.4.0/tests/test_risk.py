"""Tests for the Rust risk pipeline."""

import pytest

from horizon._horizon import (
    Engine,
    OrderRequest,
    OrderSide,
    RiskConfig,
    Side,
)


@pytest.fixture
def engine():
    config = RiskConfig(
        max_position_per_market=100.0,
        max_portfolio_notional=1000.0,
        max_daily_drawdown_pct=5.0,
        max_order_size=50.0,
    )
    return Engine(risk_config=config)


def make_order(
    market_id="mkt_1",
    side=Side.Yes,
    order_side=OrderSide.Buy,
    size=10.0,
    price=0.55,
):
    return OrderRequest(
        market_id=market_id,
        side=side,
        order_side=order_side,
        size=size,
        price=price,
    )


class TestRiskChecks:
    def test_valid_order_passes(self, engine):
        order_id = engine.submit_order(make_order())
        assert order_id.startswith("p")

    def test_invalid_price_rejects(self, engine):
        with pytest.raises(RuntimeError, match="invalid price"):
            engine.submit_order(make_order(price=1.50))

    def test_zero_price_rejects(self, engine):
        with pytest.raises(RuntimeError, match="invalid price"):
            engine.submit_order(make_order(price=0.0))

    def test_oversized_order_rejects(self, engine):
        with pytest.raises(RuntimeError, match="invalid size"):
            engine.submit_order(make_order(size=60.0))

    def test_zero_size_rejects(self, engine):
        with pytest.raises(RuntimeError, match="invalid size"):
            engine.submit_order(make_order(size=0.0))

    def test_negative_size_rejects(self, engine):
        with pytest.raises(RuntimeError, match="invalid size"):
            engine.submit_order(make_order(size=-5.0))

    def test_kill_switch_rejects(self, engine):
        engine.activate_kill_switch("test")
        with pytest.raises(RuntimeError, match="kill switch"):
            engine.submit_order(make_order())

    def test_kill_switch_deactivate(self, engine):
        engine.activate_kill_switch("test")
        engine.deactivate_kill_switch()
        order_id = engine.submit_order(make_order())
        assert order_id.startswith("p")

    def test_duplicate_order_rejects(self, engine):
        engine.submit_order(make_order())
        with pytest.raises(RuntimeError, match="duplicate"):
            engine.submit_order(make_order())
