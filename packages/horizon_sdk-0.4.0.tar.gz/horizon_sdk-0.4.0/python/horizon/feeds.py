"""Feed wrappers for price data sources."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BinanceWS:
    """Binance WebSocket price feed.

    Usage: BinanceWS("btcusdt")
    """

    symbol: str
    _type: str = "binance_ws"


@dataclass
class RESTFeed:
    """Generic REST API price feed.

    Usage: RESTFeed("https://api.example.com/price", interval=5.0)
    """

    url: str
    interval: float = 5.0
    _type: str = "rest"


@dataclass
class PolymarketBook:
    """Polymarket orderbook feed.

    Usage: PolymarketBook("will-btc-hit-100k")
    """

    market_slug: str
    _type: str = "polymarket_book"


@dataclass
class KalshiBook:
    """Kalshi orderbook feed.

    Usage: KalshiBook("KXBTC-25FEB16")
    """

    ticker: str
    _type: str = "kalshi_book"
