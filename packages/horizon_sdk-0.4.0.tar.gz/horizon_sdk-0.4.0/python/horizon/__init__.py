"""Horizon - Prediction Market Trading SDK."""

__version__ = "0.4.0"

from horizon._horizon import (
    AlertLevel,
    ArbitrageOpportunity,
    ContingentOrder,
    Engine,
    EngineStatus,
    Event,
    EventArbitrageOpportunity,
    FeedSnapshot,
    Fill,
    Market,
    Order,
    OrderbookSnapshot,
    OrderRequest,
    OrderSide,
    OrderStatus,
    OrderType,
    Outcome,
    ParityResult,
    Position,
    Quote,
    RiskConfig,
    Side,
    SimPosition,
    SimulationResult,
    TimeInForce,
    TriggerType,
    # Kelly criterion functions (Rust, #[inline])
    edge,
    fractional_kelly,
    kelly,
    kelly_no,
    kelly_size,
    liquidity_adjusted_kelly,
    multi_kelly,
    # Signal functions (Rust, #[inline])
    combine_signals,
    ema,
    zscore,
    decay_weight,
    # Market making functions (Rust, #[inline])
    reservation_price,
    optimal_spread,
    competitive_spread,
    mm_size,
    estimate_volatility,
    # Monte Carlo simulation (Rust)
    monte_carlo,
)
from horizon.aggregator import AggregatedPrice, PriceAggregator
from horizon.alerts import (
    Alert,
    AlertManager,
    AlertType,
    DiscordChannel,
    LogChannel,
    TelegramChannel,
    WebhookChannel,
)
from horizon.algos import TWAP, VWAP, ExecAlgo, Iceberg
from horizon.calibration import CalibrationTracker
from horizon.context import Context
from horizon.discovery import discover_events, discover_markets, top_markets
from horizon.exchanges import Kalshi, Polymarket
from horizon.flow import (
    Holder,
    MarketFlow,
    Trade,
    WalletPosition as PolymarketPosition,
    WalletProfile,
    analyze_market_flow,
    get_market_trades,
    get_top_holders,
    get_wallet_positions,
    get_wallet_profile,
    get_wallet_trades,
    get_wallet_value,
)
from horizon.feeds import BinanceWS, KalshiBook, PolymarketBook, RESTFeed
from horizon.kelly_sizer import kelly_sizer, kelly_sizer_with_liquidity
from horizon.metrics import MetricsCollector, MetricsServer, update_engine_metrics
from horizon.backtest import backtest
from horizon.result import BacktestResult
from horizon.risk import Risk
from horizon.strategy import run
from horizon.signals import (
    Signal,
    signal_combiner,
    price_signal,
    imbalance_signal,
    spread_signal,
    momentum_signal,
    flow_signal,
)
from horizon.mm import market_maker
from horizon.simulate import simulate
from horizon.arb import ArbResult, arb_scanner, arb_sweep
from horizon.regime import regime_signal
from horizon.feed_guard import feed_guard, FeedHealthReport, FeedHealthStatus
from horizon.inventory_skew import inventory_skewer
from horizon.adaptive_spread import adaptive_spread, SpreadMetrics
from horizon.execution_tracker import execution_tracker, ExecQuality
from horizon.hedger import cross_hedger

__all__ = [
    # Version
    "__version__",
    # Core entry points
    "run",
    "backtest",
    "BacktestResult",
    # Rust types
    "Engine",
    "Side",
    "OrderSide",
    "OrderType",
    "TimeInForce",
    "OrderStatus",
    "AlertLevel",
    "Market",
    "Quote",
    "RiskConfig",
    "OrderRequest",
    "Order",
    "Position",
    "Fill",
    "EngineStatus",
    "FeedSnapshot",
    # Multi-outcome events
    "Outcome",
    "Event",
    "EventArbitrageOpportunity",
    # Python types
    "Context",
    "Risk",
    # Feeds
    "BinanceWS",
    "RESTFeed",
    "PolymarketBook",
    "KalshiBook",
    # Exchanges
    "Polymarket",
    "Kalshi",
    # Contingent orders
    "TriggerType",
    "ContingentOrder",
    # Execution algorithms
    "ExecAlgo",
    "TWAP",
    "VWAP",
    "Iceberg",
    # Kelly criterion (Rust)
    "kelly",
    "kelly_no",
    "fractional_kelly",
    "kelly_size",
    "multi_kelly",
    "liquidity_adjusted_kelly",
    "edge",
    # Kelly pipeline sizers
    "kelly_sizer",
    "kelly_sizer_with_liquidity",
    # Parity / Arbitrage
    "ParityResult",
    "ArbitrageOpportunity",
    # Calibration
    "CalibrationTracker",
    # Discovery
    "discover_markets",
    "discover_events",
    "top_markets",
    # Phase 4: Market Data + Monitoring
    "OrderbookSnapshot",
    "PriceAggregator",
    "AggregatedPrice",
    "AlertManager",
    "AlertType",
    "Alert",
    "WebhookChannel",
    "TelegramChannel",
    "DiscordChannel",
    "LogChannel",
    "MetricsCollector",
    "MetricsServer",
    "update_engine_metrics",
    # Flow analytics (Polymarket)
    "Trade",
    "PolymarketPosition",
    "Holder",
    "WalletProfile",
    "MarketFlow",
    "get_market_trades",
    "get_wallet_trades",
    "get_wallet_positions",
    "get_wallet_value",
    "get_top_holders",
    "get_wallet_profile",
    "analyze_market_flow",
    # Signal combination (Rust)
    "combine_signals",
    "ema",
    "zscore",
    "decay_weight",
    # Signal pipeline
    "Signal",
    "signal_combiner",
    "price_signal",
    "imbalance_signal",
    "spread_signal",
    "momentum_signal",
    "flow_signal",
    # Market making (Rust)
    "reservation_price",
    "optimal_spread",
    "competitive_spread",
    "mm_size",
    "estimate_volatility",
    # Market making pipeline
    "market_maker",
    # Monte Carlo simulation (Rust)
    "SimPosition",
    "SimulationResult",
    "monte_carlo",
    "simulate",
    # Arbitrage
    "ArbResult",
    "arb_scanner",
    "arb_sweep",
    # Regime detection
    "regime_signal",
    # Feed guard
    "feed_guard",
    "FeedHealthReport",
    "FeedHealthStatus",
    # Inventory skew
    "inventory_skewer",
    # Adaptive spread
    "adaptive_spread",
    "SpreadMetrics",
    # Execution tracker
    "execution_tracker",
    "ExecQuality",
    # Cross-market hedging
    "cross_hedger",
]


def quotes(fair: float, spread: float, size: float = 5.0) -> list[Quote]:
    """Helper to create a Quote from fair value and spread."""
    half = spread / 2
    return [Quote(bid=fair - half, ask=fair + half, size=size)]
