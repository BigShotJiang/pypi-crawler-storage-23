"""Context object injected into pipeline functions."""

from __future__ import annotations

import time as _time
from dataclasses import dataclass, field
from typing import Any

from horizon._horizon import EngineStatus, Event, Market, Position, Side


@dataclass
class FeedData:
    """Snapshot of a single feed."""

    price: float = 0.0
    timestamp: float = 0.0
    bid: float = 0.0
    ask: float = 0.0
    volume_24h: float = 0.0
    source: str = ""
    last_trade_size: float = 0.0
    last_trade_is_buy: bool = False

    def is_stale(self, max_age_secs: float = 30.0) -> bool:
        """Return True if the feed data is stale or has never been updated."""
        if self.timestamp <= 0:
            return True
        return (_time.time() - self.timestamp) > max_age_secs


@dataclass
class InventorySnapshot:
    """Current inventory state."""

    positions: list[Position] = field(default_factory=list)

    @property
    def net(self) -> float:
        """Net position across all markets (YES - NO)."""
        total = 0.0
        for pos in self.positions:
            if pos.side == Side.Yes:
                total += pos.size
            else:
                total -= pos.size
        return total

    def net_for_market(self, market_id: str) -> float:
        """Net position for a specific market (YES - NO)."""
        total = 0.0
        for pos in self.positions:
            if pos.market_id == market_id:
                if pos.side == Side.Yes:
                    total += pos.size
                else:
                    total -= pos.size
        return total

    def net_for_event(self, market_ids: list[str]) -> float:
        """Net position across all markets in an event."""
        total = 0.0
        ids = set(market_ids)
        for pos in self.positions:
            if pos.market_id in ids:
                if pos.side == Side.Yes:
                    total += pos.size
                else:
                    total -= pos.size
        return total

    def positions_for_event(self, market_ids: list[str]) -> list[Position]:
        """Filter positions for markets in an event."""
        ids = set(market_ids)
        return [p for p in self.positions if p.market_id in ids]


@dataclass
class Context:
    """Context injected into every pipeline function.

    Provides access to feeds, inventory, market info, engine status,
    and arbitrary user parameters.
    """

    feeds: dict[str, FeedData] = field(default_factory=dict)
    inventory: InventorySnapshot = field(default_factory=InventorySnapshot)
    market: Market | None = None
    event: Event | None = None
    status: EngineStatus | None = None
    params: dict[str, Any] = field(default_factory=dict)
