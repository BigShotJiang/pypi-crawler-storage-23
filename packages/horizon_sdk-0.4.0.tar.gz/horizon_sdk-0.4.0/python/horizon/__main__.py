"""Allow running as: python -m horizon"""

from horizon.cli import cli

cli()
