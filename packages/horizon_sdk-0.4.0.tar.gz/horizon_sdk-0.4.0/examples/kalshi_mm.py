"""Market maker on Kalshi (paper mode)."""

import math

import horizon as hz


def fair_value(ctx: hz.Context) -> float:
    btc_price = ctx.feeds.get("btc", hz.context.FeedData()).price or 100_000
    strike = 100_000
    vol = 0.6
    tte = 1 / 365  # 1 day to expiry
    if tte <= 0:
        return 1.0 if btc_price >= strike else 0.0
    d2 = (math.log(btc_price / strike) - 0.5 * vol**2 * tte) / (vol * math.sqrt(tte))
    return 0.5 * (1 + math.erf(d2 / math.sqrt(2)))


def quoter(ctx: hz.Context, fair: float) -> list[hz.Quote]:
    spread = 0.04
    return hz.quotes(fair, spread, size=10)


if __name__ == "__main__":
    hz.run(
        name="kalshi_mm",
        exchange=hz.Kalshi(api_key="demo_key"),
        markets=["KXBTC-25FEB16"],
        feeds={"btc": hz.BinanceWS("btcusdt")},
        pipeline=[fair_value, quoter],
        risk=hz.Risk(max_position=50),
        interval=1.0,
        mode="paper",
    )
