#!/usr/bin/env python3
"""
Tests for fexp.py

Run with:
    python fexp_test.py
    python -m pytest fexp_test.py -v
"""
import io
import json
import os
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

# Make sure we import from the local fexp.py
sys.path.insert(0, str(Path(__file__).parent))
from fexp import (
    _file_stat,
    _file_type,
    _relpath,
    _within_root,
    get_html_template,
    start_server,
    stop_server,
)


# ============================================================================
# Unit Tests: Path Utilities
# ============================================================================

class TestWithinRoot(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.root = Path(self.tmp)

    def test_root_itself(self):
        self.assertTrue(_within_root(self.root, self.root))

    def test_child_dir(self):
        child = self.root / "subdir"
        child.mkdir()
        self.assertTrue(_within_root(self.root, child))

    def test_nested_file(self):
        child = self.root / "a" / "b" / "c.txt"
        child.parent.mkdir(parents=True)
        child.touch()
        self.assertTrue(_within_root(self.root, child))

    def test_path_traversal_blocked(self):
        traversal = self.root / ".." / "etc"
        self.assertFalse(_within_root(self.root, traversal))

    def test_sibling_dir_with_shared_prefix_blocked(self):
        # /tmp/abc should NOT match root /tmp/ab
        root = Path(self.tmp) / "ab"
        root.mkdir()
        sibling = Path(self.tmp) / "abc"
        sibling.mkdir()
        self.assertFalse(_within_root(root, sibling))

    def test_nonexistent_child(self):
        nonexistent = self.root / "not_yet_created.txt"
        self.assertTrue(_within_root(self.root, nonexistent))

    def test_nonexistent_traversal_blocked(self):
        traversal = self.root / ".." / "secret" / "file.txt"
        self.assertFalse(_within_root(self.root, traversal))


class TestRelpath(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.root = Path(self.tmp)

    def test_root_returns_slash(self):
        self.assertEqual(_relpath(self.root, self.root), "/")

    def test_child_file(self):
        f = self.root / "hello.txt"
        f.touch()
        self.assertEqual(_relpath(self.root, f), "/hello.txt")

    def test_nested_path(self):
        d = self.root / "a" / "b"
        d.mkdir(parents=True)
        self.assertEqual(_relpath(self.root, d), "/a/b")

    def test_outside_root_returns_slash(self):
        outside = self.root.parent / "other"
        self.assertEqual(_relpath(self.root, outside), "/")


class TestFileType(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_directory(self):
        self.assertEqual(_file_type(Path(self.tmp)), "dir")

    def test_file(self):
        f = Path(self.tmp) / "foo.txt"
        f.touch()
        self.assertEqual(_file_type(f), "file")

    def test_nonexistent(self):
        self.assertEqual(_file_type(Path(self.tmp) / "ghost"), "unknown")


class TestFileStat(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_existing_file(self):
        f = Path(self.tmp) / "data.txt"
        f.write_bytes(b"hello")
        stat = _file_stat(f)
        self.assertEqual(stat["name"], "data.txt")
        self.assertEqual(stat["type"], "file")
        self.assertEqual(stat["size"], 5)
        self.assertIn("mtime", stat)

    def test_existing_dir(self):
        d = Path(self.tmp) / "subdir"
        d.mkdir()
        stat = _file_stat(d)
        self.assertEqual(stat["type"], "dir")

    def test_nonexistent_returns_unknown(self):
        stat = _file_stat(Path(self.tmp) / "ghost.txt")
        self.assertEqual(stat["type"], "unknown")
        self.assertNotIn("size", stat)


# ============================================================================
# Unit Tests: HTML Template
# ============================================================================

class TestHtmlTemplate(unittest.TestCase):
    def test_upload_enabled_has_onclick(self):
        html = get_html_template(allow_upload=True)
        self.assertIn("onclick=", html)
        self.assertNotIn("disabled", html)
        self.assertIn("#007bff", html)

    def test_upload_disabled_no_onclick(self):
        html = get_html_template(allow_upload=False)
        self.assertNotIn("onclick=", html)
        self.assertIn("disabled", html)
        self.assertIn("#cccccc", html)

    def test_no_unreplaced_placeholders(self):
        for flag in (True, False):
            html = get_html_template(allow_upload=flag)
            self.assertNotIn("{{", html)
            self.assertNotIn("}}", html)

    def test_returns_valid_html(self):
        html = get_html_template()
        self.assertIn("<!DOCTYPE html>", html)
        self.assertIn("</html>", html)


# ============================================================================
# Integration Tests: HTTP Server
# ============================================================================

class ServerTestBase(unittest.TestCase):
    """Base class that starts a real server against a temp directory."""

    allow_upload = False
    allow_cors = False

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.root = Path(cls.tmp)

        # Create some test fixtures
        (cls.root / "hello.txt").write_text("hello world")
        (cls.root / "data.bin").write_bytes(b"\x00\x01\x02\x03")
        (cls.root / "subdir").mkdir()
        (cls.root / "subdir" / "nested.txt").write_text("nested")

        cls.httpd, cls.thread = start_server(
            host="127.0.0.1",
            port=0,  # OS picks a free port
            root=str(cls.tmp),
            log_quiet=True,
            allow_upload=cls.allow_upload,
            allow_cors=cls.allow_cors,
        )
        cls.port = cls.httpd.server_address[1]
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.httpd)

    def get(self, path, **kwargs):
        url = self.base + path
        req = urllib.request.Request(url, **kwargs)
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, resp.headers, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.headers, e.read()

    def post(self, path, data, headers=None):
        url = self.base + path
        req = urllib.request.Request(url, data=data, method="POST")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, resp.headers, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.headers, e.read()

    def options(self, path):
        url = self.base + path
        req = urllib.request.Request(url, method="OPTIONS")
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, resp.headers, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.headers, e.read()


class TestDirectoryListing(ServerTestBase):
    def test_root_returns_html(self):
        status, headers, body = self.get("/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers.get("Content-Type", ""))
        self.assertIn(b"<!DOCTYPE html>", body)

    def test_subdir_returns_html(self):
        status, headers, body = self.get("/subdir")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers.get("Content-Type", ""))

    def test_root_json_listing(self):
        status, headers, body = self.get("/?json=1")
        self.assertEqual(status, 200)
        self.assertIn("application/json", headers.get("Content-Type", ""))
        data = json.loads(body)
        self.assertEqual(data["path"], "/")
        names = [item["name"] for item in data["items"]]
        self.assertIn("hello.txt", names)
        self.assertIn("subdir", names)

    def test_json_listing_dirs_sorted_first(self):
        status, _, body = self.get("/?json=1")
        items = json.loads(body)["items"]
        types = [item["type"] for item in items]
        # All dirs should come before files
        saw_file = False
        for t in types:
            if t == "file":
                saw_file = True
            if saw_file and t == "dir":
                self.fail("dir appeared after a file in listing")

    def test_json_listing_item_fields(self):
        status, _, body = self.get("/?json=1")
        items = json.loads(body)["items"]
        file_items = [i for i in items if i["name"] == "hello.txt"]
        self.assertEqual(len(file_items), 1)
        item = file_items[0]
        self.assertEqual(item["type"], "file")
        self.assertIn("size", item)
        self.assertIn("mtime", item)

    def test_nonexistent_dir_returns_404(self):
        status, _, body = self.get("/no_such_dir?json=1")
        self.assertEqual(status, 404)

    def test_content_length_matches_body(self):
        status, headers, body = self.get("/")
        self.assertEqual(int(headers.get("Content-Length")), len(body))


class TestFileDownload(ServerTestBase):
    def test_download_text_file(self):
        status, headers, body = self.get("/hello.txt")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"hello world")

    def test_download_binary_file(self):
        status, headers, body = self.get("/data.bin")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"\x00\x01\x02\x03")

    def test_download_nested_file(self):
        status, _, body = self.get("/subdir/nested.txt")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"nested")

    def test_content_type_text(self):
        status, headers, _ = self.get("/hello.txt")
        self.assertIn("text/plain", headers.get("Content-Type", ""))

    def test_content_length_matches_body(self):
        status, headers, body = self.get("/hello.txt")
        self.assertEqual(int(headers.get("Content-Length")), len(body))

    def test_nonexistent_file_returns_404(self):
        status, _, body = self.get("/ghost.txt")
        self.assertEqual(status, 404)
        data = json.loads(body)
        self.assertIn("error", data)

    def test_path_traversal_blocked(self):
        status, _, _ = self.get("/../etc/passwd")
        self.assertEqual(status, 400)


class TestOptionsRequest(ServerTestBase):
    def test_options_returns_204(self):
        status, _, _ = self.options("/")
        self.assertEqual(status, 204)


class TestCorsHeaders(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.httpd, _ = start_server(
            host="127.0.0.1",
            port=0,
            root=cls.tmp,
            log_quiet=True,
            allow_cors=True,
        )
        cls.port = cls.httpd.server_address[1]
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        stop_server(cls.httpd)

    def test_cors_headers_present(self):
        url = self.base + "/"
        with urllib.request.urlopen(url) as resp:
            self.assertEqual(resp.headers.get("Access-Control-Allow-Origin"), "*")

    def test_no_cors_without_flag(self):
        tmp = tempfile.mkdtemp()
        httpd, _ = start_server(
            host="127.0.0.1", port=0, root=tmp, log_quiet=True, allow_cors=False
        )
        port = httpd.server_address[1]
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/") as resp:
                self.assertIsNone(resp.headers.get("Access-Control-Allow-Origin"))
        finally:
            stop_server(httpd)


class TestUploadDisabled(ServerTestBase):
    allow_upload = False

    def test_post_returns_403(self):
        status, _, body = self.post(
            "/",
            data=b"ignored",
            headers={"Content-Type": "application/octet-stream"},
        )
        self.assertEqual(status, 403)
        data = json.loads(body)
        self.assertIn("Upload disabled", data["error"])


class TestUploadEnabled(ServerTestBase):
    allow_upload = True

    def _multipart_body(self, filename, content):
        boundary = b"----TestBoundary"
        body = (
            b"--" + boundary + b"\r\n"
            b'Content-Disposition: form-data; name="file"; filename="' + filename.encode() + b'"\r\n'
            b"Content-Type: text/plain\r\n"
            b"\r\n" +
            content + b"\r\n"
            b"--" + boundary + b"--\r\n"
        )
        ctype = "multipart/form-data; boundary=----TestBoundary"
        return body, ctype

    def test_raw_upload(self):
        content = b"raw file content"
        status, _, body = self.post(
            "/?filename=raw_upload.txt",
            data=content,
            headers={
                "Content-Type": "application/octet-stream",
                "Content-Length": str(len(content)),
            },
        )
        self.assertEqual(status, 201)
        data = json.loads(body)
        self.assertEqual(data["size"], len(content))
        uploaded = (self.root / "raw_upload.txt").read_bytes()
        self.assertEqual(uploaded, content)

    def test_multipart_upload(self):
        body, ctype = self._multipart_body("multi_upload.txt", b"multipart content")
        status, _, resp_body = self.post(
            "/",
            data=body,
            headers={"Content-Type": ctype, "Content-Length": str(len(body))},
        )
        self.assertEqual(status, 201)
        self.assertTrue((self.root / "multi_upload.txt").exists())

    def test_upload_conflict_without_overwrite(self):
        content = b"conflict test"
        # First upload
        self.post(
            "/?filename=conflict.txt",
            data=content,
            headers={"Content-Type": "application/octet-stream"},
        )
        # Second upload without overwrite
        status, _, body = self.post(
            "/?filename=conflict.txt",
            data=content,
            headers={"Content-Type": "application/octet-stream"},
        )
        self.assertEqual(status, 409)
        data = json.loads(body)
        self.assertIn("File exists", data["error"])

    def test_upload_overwrite(self):
        content1, content2 = b"original", b"overwritten"
        self.post(
            "/?filename=overwrite_me.txt",
            data=content1,
            headers={"Content-Type": "application/octet-stream"},
        )
        status, _, _ = self.post(
            "/?filename=overwrite_me.txt&overwrite=1",
            data=content2,
            headers={"Content-Type": "application/octet-stream"},
        )
        self.assertEqual(status, 201)
        self.assertEqual((self.root / "overwrite_me.txt").read_bytes(), content2)

    def test_upload_missing_filename_returns_400(self):
        status, _, body = self.post(
            "/",
            data=b"data",
            headers={"Content-Type": "application/octet-stream"},
        )
        self.assertEqual(status, 400)
        data = json.loads(body)
        self.assertIn("filename", data["error"])

    def test_upload_to_nonexistent_dir_returns_404(self):
        status, _, _ = self.post(
            "/no_such_dir?filename=file.txt",
            data=b"data",
            headers={"Content-Type": "application/octet-stream"},
        )
        self.assertEqual(status, 404)

    def test_upload_response_contains_path_and_size(self):
        content = b"check response"
        status, _, body = self.post(
            "/?filename=resp_check.txt",
            data=content,
            headers={"Content-Type": "application/octet-stream"},
        )
        data = json.loads(body)
        self.assertIn("path", data)
        self.assertEqual(data["size"], len(content))


class TestServerLifecycle(unittest.TestCase):
    def test_start_and_stop(self):
        tmp = tempfile.mkdtemp()
        httpd, thread = start_server(
            host="127.0.0.1", port=0, root=tmp, log_quiet=True
        )
        port = httpd.server_address[1]
        # Server should respond
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/") as resp:
            self.assertEqual(resp.status, 200)
        stop_server(httpd)
        thread.join(timeout=3)
        self.assertFalse(thread.is_alive())

    def test_stop_is_idempotent(self):
        tmp = tempfile.mkdtemp()
        httpd, _ = start_server(
            host="127.0.0.1", port=0, root=tmp, log_quiet=True
        )
        stop_server(httpd)
        stop_server(httpd)  # should not raise


if __name__ == "__main__":
    unittest.main(verbosity=2)
