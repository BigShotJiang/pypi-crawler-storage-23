#!/usr/bin/env python3
"""
fexp - A minimal HTTP file explorer CLI tool.

A single-file implementation for easy distribution and usage.
"""
import argparse
import email.parser
import email.policy
import io
import json
import mimetypes
import os
import re
import signal
import sys
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn
from typing import Optional, Tuple, Union
from urllib.parse import parse_qs, unquote, urlparse

__version__ = "1.0.0"
__all__ = ["__version__", "start_server", "stop_server", "main"]


# ============================================================================
# HTML Template
# ============================================================================

def get_html_template(allow_upload: bool = False) -> str:
    """Generate HTML template with dynamic upload button configuration."""
    # Prepare template placeholders based on upload permission
    disabled_attr = "" if allow_upload else "disabled"
    title_attr = "" if allow_upload else ' title="Use --upload to enable."'
    onclick_attr = 'onclick="document.getElementById(\'fileInput\').click()"' if allow_upload else ""
    cursor_style = "cursor: pointer;" if allow_upload else "cursor: not-allowed;"
    disabled_bg = "#007bff" if allow_upload else "#cccccc"
    hover_bg = "#0056b3" if allow_upload else "#cccccc"

    html_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fexp</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { padding: 12px; border-bottom: 1px solid #e0e0e0; display: flex; justify-content: space-between; align-items: center; }
        .breadcrumbs { font-size: 18px; color: #333; font-weight: 500; }
        .breadcrumbs a { color: #007bff; text-decoration: none; }
        .upload-btn { background: {{DISABLED_BG_PLACEHOLDER}}; color: white; border: none; padding: 8px 16px; border-radius: 4px; {{CURSOR_STYLE_PLACEHOLDER}} }
        .upload-btn:hover { background: {{HOVER_BG_PLACEHOLDER}}; }
        .list { font-size: 14px; padding-bottom: 10px; }
        .item { padding: 12px 15px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; text-decoration: none; }
        .item:hover { background: #f8f9fa; }
        .item-name { display: flex; align-items: center; gap: 8px; flex: 1; }
        .icon { width: 20px; text-align: center; }
        .item-info { font-size: 12px; color: #999; display: flex; gap: 15px; }
        .dir { color: #007bff; font-weight: 500; }
        .file { color: #333; }
        .loading { text-align: center; padding: 40px; color: #999; }
        input[type="file"] { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumbs" id="breadcrumbs"></div>
            <button class="upload-btn" {{DISABLED_ATTR_PLACEHOLDER}}{{TITLE_ATTR_PLACEHOLDER}} {{ONCLICK_ATTR_PLACEHOLDER}}>Upload File</button>
            <input type="file" id="fileInput" onchange="uploadFile(this.files[0])">
        </div>
        <div class="list" id="fileList">
            <div class="loading">Loading...</div>
        </div>
    </div>

    <script>
        const currentPath = location.pathname;
        const parts = currentPath.split('/').filter(p => p.length > 0);
        const breadcrumbs = document.getElementById('breadcrumbs');

        breadcrumbs.innerHTML = '';
        const rootLink = document.createElement('a');
        rootLink.href = '/';
        rootLink.textContent = 'root';
        breadcrumbs.appendChild(rootLink);

        let accumulatedPath = '';
        parts.forEach((part, i) => {
            accumulatedPath += '/' + part;
            breadcrumbs.appendChild(document.createTextNode(' / '));
            if (i < parts.length - 1) {
                const link = document.createElement('a');
                link.href = accumulatedPath;
                link.textContent = part;
                breadcrumbs.appendChild(link);
            } else {
                const span = document.createElement('span');
                span.textContent = part;
                breadcrumbs.appendChild(span);
            }
        });

        async function loadDirectory() {
            try {
                const res = await fetch(currentPath + '?json=1');
                const data = await res.json();
                renderItems(data.items);
            } catch (e) {
                document.getElementById('fileList').innerHTML = '<div class="loading">Failed to load.</div>';
            }
        }

        function renderItems(items) {
            const list = document.getElementById('fileList');
            list.innerHTML = '';

            if (currentPath !== '/') {
                const parent = document.createElement('a');
                parent.className = 'item';
                parent.setAttribute('href', currentPath.split('/').slice(0, -1).join('/') || '/');
                parent.innerHTML = `<div class="item-name dir"><span class="icon">📁</span>..</div>`;
                parent.onclick = () => location.href = currentPath.split('/').slice(0, -1).join('/') || '/';
                list.appendChild(parent);
            }

            items.forEach(item => {
                const div = document.createElement('a');
                div.className = 'item';
                div.setAttribute('href', `${currentPath.replace(/\\/$/, '')}/${item.name}`);
                if (item.type == 'file') {
                    div.setAttribute('target', '_blank');
                }

                const icon = item.type === 'dir' ? '📁' : '📄';
                const nameClass = item.type === 'dir' ? 'dir' : 'file';
                const size = item.type === 'file' ? formatSize(item.size) : '';
                const time = new Date(item.mtime * 1000).toLocaleString();

                div.innerHTML = `
                    <div class="item-name ${nameClass}">
                        <span class="icon">${icon}</span>
                        <span>${escapeHtml(item.name)}</span>
                    </div>
                    <div class="item-info">
                        ${size ? `<span>${size}</span>` : ''}
                        <span>${time}</span>
                    </div>
                `;

                list.appendChild(div);
            });
        }

        function escapeHtml(s) {
            return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        function formatSize(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KiB';
            if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MiB';
            return (bytes / 1024 / 1024 / 1024).toFixed(1) + ' GiB';
        }

        async function uploadFile(file) {
            if (!file) return;

            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch(currentPath, {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();
                if (res.ok) {
                    alert('Upload Success');
                    loadDirectory();
                } else {
                    alert('Upload Failed: ' + result.error);
                }
            } catch (e) {
                alert('Upload Failed: ' + e.message);
            }

            document.getElementById('fileInput').value = '';
        }

        loadDirectory();
    </script>
</body>
</html>
"""

    # Apply template replacements
    replacements = {
        '{{DISABLED_BG_PLACEHOLDER}}': disabled_bg,
        '{{HOVER_BG_PLACEHOLDER}}': hover_bg,
        '{{CURSOR_STYLE_PLACEHOLDER}}': cursor_style,
        '{{DISABLED_ATTR_PLACEHOLDER}}': disabled_attr,
        '{{TITLE_ATTR_PLACEHOLDER}}': title_attr,
        '{{ONCLICK_ATTR_PLACEHOLDER}}': onclick_attr,
    }

    result = html_template
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, value)

    return result


# ============================================================================
# Path & File Utilities
# ============================================================================


# ============================================================================
# Path & File Utilities
# ============================================================================

def _within_root(root: Path, target: Path) -> bool:
    """Check if target path is within root directory (security check)."""
    try:
        root_resolved = root.resolve()
        target_resolved = target.resolve()
        root_str = str(root_resolved)
        target_str = str(target_resolved)
        # Use os.sep suffix to prevent /foo/bar matching /foo/bar_extra
        return target_str == root_str or target_str.startswith(root_str + os.sep)
    except FileNotFoundError:
        # For non-existent paths, check the parent
        root_str = str(root.resolve())
        parent_str = str(target.resolve().parent)
        return parent_str == root_str or parent_str.startswith(root_str + os.sep)


def _relpath(root: Path, target: Path) -> str:
    """Get relative path from root, formatted as POSIX-style."""
    try:
        rel = target.resolve().relative_to(root.resolve()).as_posix()
        return "/" if rel == "." else "/" + rel
    except Exception:
        return "/"


def _file_type(item: Path) -> str:
    """Determine file type: 'dir', 'file', or 'unknown'."""
    is_dir = item.is_dir()
    is_file = item.is_file()
    return "dir" if is_dir else ("file" if is_file else "unknown")


def _file_stat(item: Path) -> dict:
    """Get file/directory metadata as a dictionary."""
    try:
        stat = item.stat()
        return {
            "name": item.name,
            "type": _file_type(item),
            "size": stat.st_size,
            "mtime": stat.st_mtime,
        }
    except FileNotFoundError:
        # Entry might have disappeared
        return {
            "name": item.name,
            "type": "unknown",
        }


# ============================================================================
# HTTP Request Handler
# ============================================================================

# ============================================================================
# HTTP Request Handler
# ============================================================================

def _parse_multipart_file(ctype: str, rfile, clen: int) -> Optional[Tuple[Optional[str], bytes]]:
    """
    Parse a multipart/form-data request and return (filename, file_bytes) for
    the first field named 'file', or None if not found.
    Uses the stdlib email module instead of the removed-in-3.13 cgi module.
    """
    body = rfile.read(clen) if clen > 0 else rfile.read()
    # Build a minimal email message so BytesParser can decode the multipart body
    raw = b"Content-Type: " + ctype.encode() + b"\r\n\r\n" + body
    msg = email.parser.BytesParser(policy=email.policy.compat32).parsebytes(raw)
    for part in msg.walk():
        cd = part.get("Content-Disposition", "")
        name_match = re.search(r'name="([^"]*)"', cd)
        if not name_match or name_match.group(1) != "file":
            continue
        filename_match = re.search(r'filename="([^"]*)"', cd)
        filename = filename_match.group(1) if filename_match else None
        return filename, part.get_payload(decode=True) or b""
    return None

class ApiHandler(BaseHTTPRequestHandler):
    """HTTP request handler for file explorer API."""

    # Class attributes (configured by start_server)
    root_dir: Path = Path.cwd()
    allow_cors: bool = False
    allow_upload: bool = False
    log_quiet: bool = False
    _html_cache: bytes = b""  # pre-generated at startup by start_server

    def log_message(self, format: str, *args):  # noqa: A003 - match BaseHTTPRequestHandler
        """Override to respect log_quiet setting."""
        if self.log_quiet:
            return
        return super().log_message(format, *args)

    # ---- Response Helpers ----

    def _send_cors(self):
        """Add CORS headers if enabled."""
        if self.allow_cors:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _send_json(self, status: int, obj: Union[dict, list]):
        """Send JSON response."""
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self._send_cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_html(self):
        """Send HTML template response."""
        self.send_response(200)
        self._send_cors()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(self._html_cache)))
        self.end_headers()
        self.wfile.write(self._html_cache)

    def _bad_request(self, message: str):
        """Send 400 Bad Request response."""
        self._send_json(HTTPStatus.BAD_REQUEST, {"error": message})

    def _not_found(self, message: str):
        """Send 404 Not Found response."""
        self._send_json(HTTPStatus.NOT_FOUND, {"error": message})

    # ---- HTTP Methods ----

    # ---- HTTP Methods ----

    def do_OPTIONS(self):  # noqa: N802 - match BaseHTTPRequestHandler
        """Handle OPTIONS request (CORS preflight)."""
        self.send_response(HTTPStatus.NO_CONTENT)
        self._send_cors()
        self.end_headers()

    def do_GET(self):  # noqa: N802 - match BaseHTTPRequestHandler
        """Handle GET request for files and directories."""
        parsed = urlparse(self.path)
        target = self._get_target(parsed.path)
        qs = parse_qs(parsed.query, keep_blank_values=True)

        if target is None:
            return self._bad_request("Invalid path")
        if target.is_dir():
            return self._handle_dir(target, qs)
        return self._handle_file(target, qs)

    def do_POST(self):  # noqa: N802 - match BaseHTTPRequestHandler
        """Handle POST request for file uploads."""
        parsed = urlparse(self.path)
        target = self._get_target(parsed.path)
        qs = parse_qs(parsed.query, keep_blank_values=True)
        return self._handle_upload(target, qs)

    # ---- Request Handlers ----

    def _get_target(self, raw_path: str) -> Optional[Path]:
        """Parse and validate URL path to filesystem path."""
        rel = Path("." if raw_path in ("", "/") else unquote(raw_path).lstrip("/"))
        target = (self.root_dir / rel)
        if not _within_root(self.root_dir, target):
            return None
        return target

    def _handle_dir(self, target: Path, qs: dict):
        """Handle directory listing request."""
        if target is None:
            return self._bad_request("Invalid path")
        if not target.exists():
            return self._not_found("Path does not exist")
        if not target.is_dir():
            return self._bad_request("Path is not a directory")

        # Return HTML if not requesting JSON
        if qs.get("json", ["0"])[0] in ("0", "false", "False"):
            return self._send_html()

        # Return JSON directory listing
        try:
            items = []
            with os.scandir(target) as it:
                for entry in it:
                    items.append(_file_stat(Path(entry.path)))
            items.sort(key=lambda x: (x.get("type") != "dir", x.get("name", "").lower()))
            return self._send_json(200, {
                "path": _relpath(self.root_dir, target),
                "items": items,
            })
        except PermissionError:
            return self._bad_request("Permission denied")

    def _handle_file(self, target: Path, qs: dict):
        """Handle file download request."""
        if target is None:
            return self._bad_request("Invalid path")
        if not target.exists():
            return self._not_found("File does not exist")
        if not target.is_file():
            return self._bad_request("Path is not a file")

        ctype, _ = mimetypes.guess_type(target.name)
        ctype = ctype or "application/octet-stream"

        # Open the file before sending headers, so PermissionError can still
        # be reported as a proper 400 response (not a double-response)
        try:
            f = open(target, "rb")
        except PermissionError:
            return self._bad_request("Permission denied")

        with f:
            self.send_response(200)
            self._send_cors()
            self.send_header("Content-Type", ctype)
            # Sanitize filename: strip newlines (header injection) and escape quotes
            safe_name = target.name.replace('\r', '').replace('\n', '').replace('"', '\\"')
            self.send_header("Content-Disposition", f"inline; filename=\"{safe_name}\"")
            self.send_header("Content-Length", str(os.fstat(f.fileno()).st_size))
            self.end_headers()

            # Stream file in chunks
            while True:
                chunk = f.read(64 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)

    def _handle_upload(self, target: Path, qs: dict):
        """Handle file upload request."""
        if not self.allow_upload:
            return self._send_json(HTTPStatus.FORBIDDEN, {"error": "Upload disabled"})

        # Validate destination directory
        if target is None:
            return self._bad_request("Invalid destination path")
        if not target.exists():
            return self._not_found("Destination does not exist")
        if not target.is_dir():
            return self._bad_request("Destination is not a directory")

        overwrite = qs.get("overwrite", ["0"])[0] not in ("0", "false", "False")
        ctype = self.headers.get("Content-Type", "")
        clen = int(self.headers.get("Content-Length", "0") or 0)

        if not ctype:
            return self._bad_request("Missing Content-Type")

        # Helper function to write stream to file in chunks
        def _write_to(dest_path: Path, src):
            with open(dest_path, "wb") as out:
                while True:
                    chunk = src.read(64 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)

        # Handle multipart/form-data upload
        if ctype.startswith("multipart/form-data"):
            item = _parse_multipart_file(ctype, self.rfile, clen)
            if item is None:
                return self._bad_request("Missing file field")

            filename, file_bytes = item
            filename = os.path.basename(filename or "upload.bin") or "upload.bin"

            dest_path = target / filename
            if dest_path.exists() and not overwrite:
                return self._send_json(
                    HTTPStatus.CONFLICT,
                    {"error": "File exists", "path": _relpath(self.root_dir, dest_path)}
                )

            try:
                _write_to(dest_path, io.BytesIO(file_bytes))
            except PermissionError:
                return self._bad_request("Permission denied")

            return self._send_json(HTTPStatus.CREATED, {
                "path": _relpath(self.root_dir, dest_path),
                "size": dest_path.stat().st_size,
            })

        # Handle raw bytes upload with filename in query string
        if ctype in ("application/octet-stream", "binary/octet-stream") or True:
            filename = qs.get("filename", [""])[0]
            filename = os.path.basename(filename)

            if not filename:
                return self._bad_request("Missing filename query parameter for raw upload")

            dest_path = target / filename
            if dest_path.exists() and not overwrite:
                return self._send_json(
                    HTTPStatus.CONFLICT,
                    {"error": "File exists", "path": _relpath(self.root_dir, dest_path)}
                )

            try:
                # Limited reader for Content-Length
                remaining = clen

                class _Src:
                    def __init__(self, rfile, n):
                        self.rfile = rfile
                        self.remaining = n

                    def read(self, n):
                        if self.remaining == 0:
                            return b""
                        to_read = n if self.remaining < 0 else min(n, self.remaining)
                        data = self.rfile.read(to_read)
                        if self.remaining >= 0:
                            self.remaining -= len(data)
                        return data

                _write_to(dest_path, _Src(self.rfile, remaining))
            except PermissionError:
                return self._bad_request("Permission denied")

            return self._send_json(HTTPStatus.CREATED, {
                "path": _relpath(self.root_dir, dest_path),
                "size": dest_path.stat().st_size,
            })


# ============================================================================
# Server Setup
# ============================================================================

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """ThreadingHTTPServer for Python 3.6 compatibility (added to stdlib in 3.7)."""
    daemon_threads = True


def start_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    root: Union[str, os.PathLike] = ".",
    log_quiet: bool = False,
    allow_upload: bool = False,
    allow_cors: bool = False,
):
    """
    Start the HTTP file explorer server.

    Args:
        host: Host address to bind to
        port: Port to listen on
        root: Root directory to serve
        log_quiet: Whether to suppress log output
        allow_upload: Whether to allow file uploads
        allow_cors: Whether to enable CORS headers

    Returns:
        Tuple of (HTTPServer instance, server thread)
    """
    root_path = Path(root).resolve()

    # Create custom handler with configured settings
    class _Handler(ApiHandler):
        pass

    _Handler.root_dir = root_path
    _Handler.log_quiet = log_quiet
    _Handler.allow_upload = allow_upload
    _Handler.allow_cors = allow_cors
    _Handler._html_cache = get_html_template(allow_upload=allow_upload).encode("utf-8")

    httpd = ThreadingHTTPServer((host, port), _Handler)

    def _serve():
        try:
            httpd.serve_forever()
        finally:
            httpd.server_close()

    t = threading.Thread(target=_serve, name="fexp-server", daemon=True)
    t.start()
    print(f"fexp server listening on http://{host}:{port} (root={root_path})")
    return httpd, t


def stop_server(httpd: ThreadingHTTPServer):
    """Stop the HTTP server gracefully."""
    try:
        httpd.shutdown()
    except Exception:
        pass


# ============================================================================
# CLI Interface
# ============================================================================

def parse_args(argv=None):
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="fexp",
        description="Start a minimal HTTP file explorer backend server.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port to listen on (default: 8765)"
    )
    parser.add_argument(
        "--root",
        default=str(Path.cwd()),
        help="Root directory to expose (default: current working directory)",
    )
    parser.add_argument(
        "--cors",
        action="store_true",
        help="Enable CORS headers (disabled by default)",
    )
    parser.add_argument(
        "--upload",
        action="store_true",
        help="Enable file upload API (default: disabled)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress log output",
    )
    return parser.parse_args(argv)


def main(argv=None):
    """Main entry point for the CLI."""
    args = parse_args(argv)

    httpd, thread = start_server(
        host=args.host,
        port=args.port,
        root=args.root,
        log_quiet=args.quiet,
        allow_upload=args.upload,
        allow_cors=args.cors,
    )

    def _shutdown(*_):
        """Signal handler for graceful shutdown."""
        stop_server(httpd)

    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    try:
        # Block until server thread stops
        thread.join()
    except KeyboardInterrupt:
        pass
    finally:
        stop_server(httpd)


if __name__ == "__main__":
    sys.exit(main())
