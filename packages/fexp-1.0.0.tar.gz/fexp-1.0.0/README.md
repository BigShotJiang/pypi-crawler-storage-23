# fexp

A minimal CLI to serve a simple HTTP backend for browsing and uploading files.

## Install

You can install `fexp` via pip:

```bash
pip install fexp
```

## CLI

```bash
fexp [--host HOST] [--port PORT] [--root ROOT] [--quiet] [--upload] [--cors]
```

- `--host` (default: 127.0.0.1)
- `--port` (default: 8765)
- `--root` root directory to expose (default: $PWD)
- `--quiet` disable logging output (default: false)
- `--upload` enable upload support (default: false)
- `--cors` enable CORS (default: false)

## Web UI

A minimal web UI is available at:

- `GET /path/to/dir` — opens a simple file manager page

Features:
- Navigate directories with breadcrumbs
- Click files to preview (text) or open in a new tab
- Upload files into the current directory (requires `--upload`)

## HTTP API

### List Directory

List the contents of a directory in JSON format:

```bash
GET /path/to/dir?json=1
```

**Response:**
```json
{
  "path": "/path/to/dir",
  "items": [
    {
      "name": "file.txt",
      "type": "file",
      "size": 1024,
      "mtime": 1234567890.0
    },
    {
      "name": "subdir",
      "type": "dir",
      "size": 4096,
      "mtime": 1234567890.0
    }
  ]
}
```

### Download File

Download a file:

```bash
GET /path/to/file.txt
```

The file will be served with the appropriate `Content-Type` header based on the file extension.

### Upload File (requires `--upload`)

Upload a file using multipart form data:

```bash
POST /path/to/destination/dir
Content-Type: multipart/form-data

# Form field name must be "file"
curl -X POST http://127.0.0.1:8765/dest/dir \
  -F "file=@/path/to/local/file.txt"
```

Upload a file using raw binary data:

```bash
POST /path/to/destination/dir?filename=file.txt
Content-Type: application/octet-stream

curl -X POST "http://127.0.0.1:8765/dest/dir?filename=file.txt" \
  --data-binary "@/path/to/local/file.txt"
```

**Optional Query Parameters:**
- `overwrite=1` — Overwrite existing files (default: `0`)

**Response (201 Created):**
```json
{
  "path": "/dest/dir/file.txt",
  "size": 1024
}
```

**Error Response (409 Conflict):**
```json
{
  "error": "File exists",
  "path": "/dest/dir/file.txt"
}
```

## License

MIT
