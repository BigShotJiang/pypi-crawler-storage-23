# cryptocom-tools-exchange

Exchange/market data tools for the Crypto.com Developer Platform.

## Installation

```bash
pip install cryptocom-tools-exchange
```

## Features

- **GetAllTickersTool**: Get all available exchange tickers
- **GetTickersTool**: Get ticker information for a specific trading instrument

All tools are read-only and require no signer/wallet.

## Usage

```python
import os
from cryptocom_tools_exchange import GetAllTickersTool, GetTickersTool

# Set your CDP API key
os.environ["CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"] = "your-api-key"

# Get all tickers
all_tickers_tool = GetAllTickersTool()
result = all_tickers_tool.invoke({})
print(result)

# Get a specific ticker
ticker_tool = GetTickersTool()
result = ticker_tool.invoke({"symbol": "CRO_USDT"})
print(result)
```

## How it works

These tools call the Crypto.com Developer Platform Exchange API via the
`crypto_com_developer_platform_client.Exchange` client. Authentication uses the
`CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY` environment variable (handled by
`cryptocom-tools-core`), and there is no on-chain RPC or ethers/web3 usage.

## Supported Instruments

The tools support various trading pairs including:
- `CRO_USDT`
- `BTC_USDT`
- `ETH_USDT`
- And many more...

Instrument names are automatically normalized (e.g., `cro-usdt`, `CRO/USDT` -> `CRO_USDT`).

## License

MIT
