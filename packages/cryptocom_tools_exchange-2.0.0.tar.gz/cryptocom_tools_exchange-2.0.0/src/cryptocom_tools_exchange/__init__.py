"""
Crypto.com Developer Platform Exchange Tools.

This package provides read-only tools for querying exchange/market data
from the Crypto.com Developer Platform.

Tools:
    - GetAllTickersTool: Get all available exchange tickers
    - GetTickersTool: Get ticker information for a specific trading instrument
    - GetTickerTool: Alias of GetTickersTool for backward compatibility
"""

from cryptocom_tools_exchange.read import (
    GetAllTickersInput,
    GetAllTickersTool,
    GetTickerInput,
    GetTickersTool,
    GetTickerTool,
    TickerResult,
)

__all__ = [
    # Results
    "TickerResult",
    # Tools
    "GetAllTickersInput",
    "GetAllTickersTool",
    "GetTickerInput",
    "GetTickerTool",
    "GetTickersTool",
]

__version__ = "0.1.0"
