"""GetAllTickersTool - Get all available exchange tickers."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel

from ._results import TickerResult


class GetAllTickersInput(BaseModel):
    """Input schema for GetAllTickersTool."""

    # No required parameters
    pass


class GetAllTickersTool(CDPTool):
    """
    Get all available exchange tickers.

    Example:
        tool = GetAllTickersTool()
        result = tool.invoke({})
    """

    name: str = "get_all_tickers"
    description: str = (
        "Get ALL tickers from the exchange (returns many results). "
        "Only use for market overview or listing available pairs. "
        "For a specific token price, use get_ticker instead."
    )
    args_schema: type[BaseModel] = GetAllTickersInput  # type: ignore[assignment]

    def _run(self) -> str:  # type: ignore[override]
        """Get all exchange tickers."""
        from crypto_com_developer_platform_client import Exchange

        try:
            response: Any = Exchange.get_all_tickers()

            # Handle response format
            if isinstance(response, dict):
                if response.get("status") == "Success" or "data" in response:
                    tickers_data = response.get("data", [])
                else:
                    tickers_data = []
            elif isinstance(response, list):
                tickers_data = response
            else:
                return f"All tickers: {response}"

            if not tickers_data:
                return "No tickers available"

            # Ensure tickers_data is a list for slicing
            tickers_list = list(tickers_data) if isinstance(tickers_data, list) else []

            results: list[str] = []
            for ticker in tickers_list[:10]:  # Limit to first 10
                if isinstance(ticker, dict):
                    # API uses camelCase: instrumentName, lastPrice, volume, priceChange
                    name = (
                        ticker.get("instrumentName") or ticker.get("instrument_name") or "Unknown"
                    )
                    price = ticker.get("lastPrice") or ticker.get("last_price") or 0.0
                    volume = ticker.get("volume") or ticker.get("volume_24h") or 0.0
                    change = ticker.get("priceChange") or ticker.get("price_change_24h") or 0.0

                    result = TickerResult(
                        instrument_name=str(name),
                        last_price=float(price) if price else 0.0,
                        volume_24h=float(volume) if volume else 0.0,
                        price_change_24h=float(change) * 100
                        if change
                        else 0.0,  # Convert to percentage
                    )
                    results.append(str(result))

            if results:
                return f"Found {len(tickers_data)} tickers:\n" + "\n".join(results)

            return f"All tickers: {len(tickers_data)} available"

        except Exception as e:
            return f"Error getting tickers: {e!s}"


__all__ = ["GetAllTickersInput", "GetAllTickersTool"]
