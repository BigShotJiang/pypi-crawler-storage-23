"""GetTickerTool - Get ticker information for a specific trading instrument."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, ConfigDict, Field

from ._results import TickerResult


class GetTickerInput(BaseModel):
    """Input schema for GetTickerTool."""

    model_config = ConfigDict(populate_by_name=True)

    instrument_name: str = Field(
        alias="symbol",
        description=(
            "Token symbol (e.g., 'CRO', 'BTC') or full trading pair "
            "(e.g., 'CRO_USDT'). Accepts 'symbol' as the input key."
        ),
    )
    quote_currency: str = Field(
        default="USDT",
        description="Quote currency for the pair (USDT, USDC, BTC, ETH). "
        "Only used when symbol is a simple token like 'CRO'.",
    )


class GetTickerTool(CDPTool):
    """
    Get ticker information for a specific trading instrument.

    Example:
        tool = GetTickerTool()
        result = tool.invoke({"symbol": "CRO_USDT"})
    """

    name: str = "get_ticker"
    description: str = (
        "Get current price and 24h stats for a specific token. "
        "Use this for price queries (e.g., 'CRO price', 'BTC price in USDC'). "
        "Accepts simple symbols like 'CRO' (defaults to USDT pair) or full pairs like 'CRO_USDT'."
    )
    args_schema: type[BaseModel] = GetTickerInput  # type: ignore[assignment]

    def _run(self, instrument_name: str, quote_currency: str = "USDT") -> str:  # type: ignore[override]
        """Get ticker information by instrument name."""
        from crypto_com_developer_platform_client import Exchange

        # Normalize instrument name
        normalized_name = self._normalize_instrument_name(instrument_name, quote_currency)

        try:
            response: Any = Exchange.get_ticker_by_instrument(normalized_name)

            # Handle response format
            if isinstance(response, dict):
                if response.get("status") == "Success" or "data" in response:
                    ticker_data = response.get("data", {})
                else:
                    ticker_data = response
            else:
                return f"Ticker information for {normalized_name}: {response}"

            if isinstance(ticker_data, dict):
                # API uses camelCase: instrumentName, lastPrice, volume, priceChange
                price = ticker_data.get("lastPrice") or ticker_data.get("last_price") or 0.0
                volume = ticker_data.get("volume") or ticker_data.get("volume_24h") or 0.0
                change = (
                    ticker_data.get("priceChange") or ticker_data.get("price_change_24h") or 0.0
                )

                result = TickerResult(
                    instrument_name=normalized_name,
                    last_price=float(price) if price else 0.0,
                    volume_24h=float(volume) if volume else 0.0,
                    price_change_24h=float(change) * 100
                    if change
                    else 0.0,  # Convert to percentage
                )
                return str(result)

            return f"Ticker information for {normalized_name}: {response}"

        except Exception as e:
            return f"Error getting ticker {normalized_name}: {e!s}"

    @staticmethod
    def _normalize_instrument_name(instrument_name: str, quote_currency: str = "USDT") -> str:
        """Normalize instrument name to expected format."""
        normalized = instrument_name.upper()
        for separator in ["-", "/", " "]:
            if separator in normalized:
                normalized = normalized.replace(separator, "_")
                break

        # Add quote currency if not already a full pair (has underscore)
        if "_" not in normalized:
            normalized = f"{normalized}_{quote_currency.upper()}"

        return normalized


class GetTickersTool(GetTickerTool):
    """
    Get ticker information for a specific trading instrument.

    This is an alias for GetTickerTool to match documentation naming.
    """


__all__ = ["GetTickerInput", "GetTickerTool", "GetTickersTool"]
