"""Shared result classes for exchange read tools."""

from __future__ import annotations

from dataclasses import dataclass

from cryptocom_tools_core import ToolResult


@dataclass
class TickerResult(ToolResult):
    """Result from exchange ticker tools."""

    instrument_name: str
    last_price: float
    volume_24h: float
    price_change_24h: float

    def _format_result(self) -> str:
        return (
            f"{self.instrument_name}: ${self.last_price:.4f} "
            f"({self.price_change_24h:+.2f}% 24h, Volume: {self.volume_24h:.2f})"
        )


__all__ = ["TickerResult"]
