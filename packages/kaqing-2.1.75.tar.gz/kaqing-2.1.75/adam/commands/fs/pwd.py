from adam.utils_apps.app_session import AppSession
from adam.commands.command import Command
from adam.commands.devices.devices import all_devices
from adam.utils_repl.repl_state import ReplState
from adam.utils_log import log, log_exc
from adam.utils_tabulize import tabulize

class Pwd(Command):
    COMMAND = 'pwd'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(Pwd, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return Pwd.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (_, state):
            with self.context(args) as (args, ctx):
                host = "unknown"
                with log_exc():
                    app_session: AppSession = AppSession.create('c3', 'c3')
                    host = app_session.host

                tabulize([device.pwd(state) for device in all_devices()] + [
                    f'',
                    f'HOST\t{host}',
                    f'NAMESPACE\t{state.namespace if state.namespace else "/"}',
                ], header='DEVICE\tLOCATION', separator='\t', ctx=ctx)
                log()

                return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, state: ReplState):
        return super().help(state, 'print current working directories')