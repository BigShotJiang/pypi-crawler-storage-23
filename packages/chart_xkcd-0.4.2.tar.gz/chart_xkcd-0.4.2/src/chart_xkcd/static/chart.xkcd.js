var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/dayjs/dayjs.min.js
var require_dayjs_min = __commonJS({
  "node_modules/dayjs/dayjs.min.js"(exports, module) {
    !(function(t, e) {
      "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
    })(exports, (function() {
      "use strict";
      var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y2 = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(t2) {
        var e3 = ["th", "st", "nd", "rd"], n2 = t2 % 100;
        return "[" + t2 + (e3[(n2 - 20) % 10] || e3[n2] || e3[0]) + "]";
      } }, m = function(t2, e3, n2) {
        var r2 = String(t2);
        return !r2 || r2.length >= e3 ? t2 : "" + Array(e3 + 1 - r2.length).join(n2) + t2;
      }, v = { s: m, z: function(t2) {
        var e3 = -t2.utcOffset(), n2 = Math.abs(e3), r2 = Math.floor(n2 / 60), i2 = n2 % 60;
        return (e3 <= 0 ? "+" : "-") + m(r2, 2, "0") + ":" + m(i2, 2, "0");
      }, m: function t2(e3, n2) {
        if (e3.date() < n2.date()) return -t2(n2, e3);
        var r2 = 12 * (n2.year() - e3.year()) + (n2.month() - e3.month()), i2 = e3.clone().add(r2, c), s2 = n2 - i2 < 0, u2 = e3.clone().add(r2 + (s2 ? -1 : 1), c);
        return +(-(r2 + (n2 - i2) / (s2 ? i2 - u2 : u2 - i2)) || 0);
      }, a: function(t2) {
        return t2 < 0 ? Math.ceil(t2) || 0 : Math.floor(t2);
      }, p: function(t2) {
        return { M: c, y: h, w: o, d: a, D: d, h: u, m: s, s: i, ms: r, Q: f }[t2] || String(t2 || "").toLowerCase().replace(/s$/, "");
      }, u: function(t2) {
        return void 0 === t2;
      } }, g = "en", D = {};
      D[g] = M;
      var p = "$isDayjsObject", S = function(t2) {
        return t2 instanceof _ || !(!t2 || !t2[p]);
      }, w = function t2(e3, n2, r2) {
        var i2;
        if (!e3) return g;
        if ("string" == typeof e3) {
          var s2 = e3.toLowerCase();
          D[s2] && (i2 = s2), n2 && (D[s2] = n2, i2 = s2);
          var u2 = e3.split("-");
          if (!i2 && u2.length > 1) return t2(u2[0]);
        } else {
          var a2 = e3.name;
          D[a2] = e3, i2 = a2;
        }
        return !r2 && i2 && (g = i2), i2 || !r2 && g;
      }, O = function(t2, e3) {
        if (S(t2)) return t2.clone();
        var n2 = "object" == typeof e3 ? e3 : {};
        return n2.date = t2, n2.args = arguments, new _(n2);
      }, b = v;
      b.l = w, b.i = S, b.w = function(t2, e3) {
        return O(t2, { locale: e3.$L, utc: e3.$u, x: e3.$x, $offset: e3.$offset });
      };
      var _ = (function() {
        function M2(t2) {
          this.$L = w(t2.locale, null, true), this.parse(t2), this.$x = this.$x || t2.x || {}, this[p] = true;
        }
        var m2 = M2.prototype;
        return m2.parse = function(t2) {
          this.$d = (function(t3) {
            var e3 = t3.date, n2 = t3.utc;
            if (null === e3) return /* @__PURE__ */ new Date(NaN);
            if (b.u(e3)) return /* @__PURE__ */ new Date();
            if (e3 instanceof Date) return new Date(e3);
            if ("string" == typeof e3 && !/Z$/i.test(e3)) {
              var r2 = e3.match($);
              if (r2) {
                var i2 = r2[2] - 1 || 0, s2 = (r2[7] || "0").substring(0, 3);
                return n2 ? new Date(Date.UTC(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2)) : new Date(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2);
              }
            }
            return new Date(e3);
          })(t2), this.init();
        }, m2.init = function() {
          var t2 = this.$d;
          this.$y = t2.getFullYear(), this.$M = t2.getMonth(), this.$D = t2.getDate(), this.$W = t2.getDay(), this.$H = t2.getHours(), this.$m = t2.getMinutes(), this.$s = t2.getSeconds(), this.$ms = t2.getMilliseconds();
        }, m2.$utils = function() {
          return b;
        }, m2.isValid = function() {
          return !(this.$d.toString() === l);
        }, m2.isSame = function(t2, e3) {
          var n2 = O(t2);
          return this.startOf(e3) <= n2 && n2 <= this.endOf(e3);
        }, m2.isAfter = function(t2, e3) {
          return O(t2) < this.startOf(e3);
        }, m2.isBefore = function(t2, e3) {
          return this.endOf(e3) < O(t2);
        }, m2.$g = function(t2, e3, n2) {
          return b.u(t2) ? this[e3] : this.set(n2, t2);
        }, m2.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, m2.valueOf = function() {
          return this.$d.getTime();
        }, m2.startOf = function(t2, e3) {
          var n2 = this, r2 = !!b.u(e3) || e3, f2 = b.p(t2), l2 = function(t3, e4) {
            var i2 = b.w(n2.$u ? Date.UTC(n2.$y, e4, t3) : new Date(n2.$y, e4, t3), n2);
            return r2 ? i2 : i2.endOf(a);
          }, $2 = function(t3, e4) {
            return b.w(n2.toDate()[t3].apply(n2.toDate("s"), (r2 ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e4)), n2);
          }, y3 = this.$W, M3 = this.$M, m3 = this.$D, v2 = "set" + (this.$u ? "UTC" : "");
          switch (f2) {
            case h:
              return r2 ? l2(1, 0) : l2(31, 11);
            case c:
              return r2 ? l2(1, M3) : l2(0, M3 + 1);
            case o:
              var g2 = this.$locale().weekStart || 0, D2 = (y3 < g2 ? y3 + 7 : y3) - g2;
              return l2(r2 ? m3 - D2 : m3 + (6 - D2), M3);
            case a:
            case d:
              return $2(v2 + "Hours", 0);
            case u:
              return $2(v2 + "Minutes", 1);
            case s:
              return $2(v2 + "Seconds", 2);
            case i:
              return $2(v2 + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, m2.endOf = function(t2) {
          return this.startOf(t2, false);
        }, m2.$set = function(t2, e3) {
          var n2, o2 = b.p(t2), f2 = "set" + (this.$u ? "UTC" : ""), l2 = (n2 = {}, n2[a] = f2 + "Date", n2[d] = f2 + "Date", n2[c] = f2 + "Month", n2[h] = f2 + "FullYear", n2[u] = f2 + "Hours", n2[s] = f2 + "Minutes", n2[i] = f2 + "Seconds", n2[r] = f2 + "Milliseconds", n2)[o2], $2 = o2 === a ? this.$D + (e3 - this.$W) : e3;
          if (o2 === c || o2 === h) {
            var y3 = this.clone().set(d, 1);
            y3.$d[l2]($2), y3.init(), this.$d = y3.set(d, Math.min(this.$D, y3.daysInMonth())).$d;
          } else l2 && this.$d[l2]($2);
          return this.init(), this;
        }, m2.set = function(t2, e3) {
          return this.clone().$set(t2, e3);
        }, m2.get = function(t2) {
          return this[b.p(t2)]();
        }, m2.add = function(r2, f2) {
          var d2, l2 = this;
          r2 = Number(r2);
          var $2 = b.p(f2), y3 = function(t2) {
            var e3 = O(l2);
            return b.w(e3.date(e3.date() + Math.round(t2 * r2)), l2);
          };
          if ($2 === c) return this.set(c, this.$M + r2);
          if ($2 === h) return this.set(h, this.$y + r2);
          if ($2 === a) return y3(1);
          if ($2 === o) return y3(7);
          var M3 = (d2 = {}, d2[s] = e, d2[u] = n, d2[i] = t, d2)[$2] || 1, m3 = this.$d.getTime() + r2 * M3;
          return b.w(m3, this);
        }, m2.subtract = function(t2, e3) {
          return this.add(-1 * t2, e3);
        }, m2.format = function(t2) {
          var e3 = this, n2 = this.$locale();
          if (!this.isValid()) return n2.invalidDate || l;
          var r2 = t2 || "YYYY-MM-DDTHH:mm:ssZ", i2 = b.z(this), s2 = this.$H, u2 = this.$m, a2 = this.$M, o2 = n2.weekdays, c2 = n2.months, f2 = n2.meridiem, h2 = function(t3, n3, i3, s3) {
            return t3 && (t3[n3] || t3(e3, r2)) || i3[n3].slice(0, s3);
          }, d2 = function(t3) {
            return b.s(s2 % 12 || 12, t3, "0");
          }, $2 = f2 || function(t3, e4, n3) {
            var r3 = t3 < 12 ? "AM" : "PM";
            return n3 ? r3.toLowerCase() : r3;
          };
          return r2.replace(y2, (function(t3, r3) {
            return r3 || (function(t4) {
              switch (t4) {
                case "YY":
                  return String(e3.$y).slice(-2);
                case "YYYY":
                  return b.s(e3.$y, 4, "0");
                case "M":
                  return a2 + 1;
                case "MM":
                  return b.s(a2 + 1, 2, "0");
                case "MMM":
                  return h2(n2.monthsShort, a2, c2, 3);
                case "MMMM":
                  return h2(c2, a2);
                case "D":
                  return e3.$D;
                case "DD":
                  return b.s(e3.$D, 2, "0");
                case "d":
                  return String(e3.$W);
                case "dd":
                  return h2(n2.weekdaysMin, e3.$W, o2, 2);
                case "ddd":
                  return h2(n2.weekdaysShort, e3.$W, o2, 3);
                case "dddd":
                  return o2[e3.$W];
                case "H":
                  return String(s2);
                case "HH":
                  return b.s(s2, 2, "0");
                case "h":
                  return d2(1);
                case "hh":
                  return d2(2);
                case "a":
                  return $2(s2, u2, true);
                case "A":
                  return $2(s2, u2, false);
                case "m":
                  return String(u2);
                case "mm":
                  return b.s(u2, 2, "0");
                case "s":
                  return String(e3.$s);
                case "ss":
                  return b.s(e3.$s, 2, "0");
                case "SSS":
                  return b.s(e3.$ms, 3, "0");
                case "Z":
                  return i2;
              }
              return null;
            })(t3) || i2.replace(":", "");
          }));
        }, m2.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, m2.diff = function(r2, d2, l2) {
          var $2, y3 = this, M3 = b.p(d2), m3 = O(r2), v2 = (m3.utcOffset() - this.utcOffset()) * e, g2 = this - m3, D2 = function() {
            return b.m(y3, m3);
          };
          switch (M3) {
            case h:
              $2 = D2() / 12;
              break;
            case c:
              $2 = D2();
              break;
            case f:
              $2 = D2() / 3;
              break;
            case o:
              $2 = (g2 - v2) / 6048e5;
              break;
            case a:
              $2 = (g2 - v2) / 864e5;
              break;
            case u:
              $2 = g2 / n;
              break;
            case s:
              $2 = g2 / e;
              break;
            case i:
              $2 = g2 / t;
              break;
            default:
              $2 = g2;
          }
          return l2 ? $2 : b.a($2);
        }, m2.daysInMonth = function() {
          return this.endOf(c).$D;
        }, m2.$locale = function() {
          return D[this.$L];
        }, m2.locale = function(t2, e3) {
          if (!t2) return this.$L;
          var n2 = this.clone(), r2 = w(t2, e3, true);
          return r2 && (n2.$L = r2), n2;
        }, m2.clone = function() {
          return b.w(this.$d, this);
        }, m2.toDate = function() {
          return new Date(this.valueOf());
        }, m2.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, m2.toISOString = function() {
          return this.$d.toISOString();
        }, m2.toString = function() {
          return this.$d.toUTCString();
        }, M2;
      })(), k = _.prototype;
      return O.prototype = k, [["$ms", r], ["$s", i], ["$m", s], ["$H", u], ["$W", a], ["$M", c], ["$y", h], ["$D", d]].forEach((function(t2) {
        k[t2[1]] = function(e3) {
          return this.$g(e3, t2[0], t2[1]);
        };
      })), O.extend = function(t2, e3) {
        return t2.$i || (t2(e3, _, O), t2.$i = true), O;
      }, O.locale = w, O.isDayjs = S, O.unix = function(t2) {
        return O(1e3 * t2);
      }, O.en = D[g], O.Ls = D, O.p = {}, O;
    }));
  }
});

// node_modules/d3-selection/src/namespaces.js
var xhtml = "http://www.w3.org/1999/xhtml";
var namespaces_default = {
  svg: "http://www.w3.org/2000/svg",
  xhtml,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};

// node_modules/d3-selection/src/namespace.js
function namespace_default(name) {
  var prefix = name += "", i = prefix.indexOf(":");
  if (i >= 0 && (prefix = name.slice(0, i)) !== "xmlns") name = name.slice(i + 1);
  return namespaces_default.hasOwnProperty(prefix) ? { space: namespaces_default[prefix], local: name } : name;
}

// node_modules/d3-selection/src/creator.js
function creatorInherit(name) {
  return function() {
    var document2 = this.ownerDocument, uri = this.namespaceURI;
    return uri === xhtml && document2.documentElement.namespaceURI === xhtml ? document2.createElement(name) : document2.createElementNS(uri, name);
  };
}
function creatorFixed(fullname) {
  return function() {
    return this.ownerDocument.createElementNS(fullname.space, fullname.local);
  };
}
function creator_default(name) {
  var fullname = namespace_default(name);
  return (fullname.local ? creatorFixed : creatorInherit)(fullname);
}

// node_modules/d3-selection/src/selector.js
function none() {
}
function selector_default(selector) {
  return selector == null ? none : function() {
    return this.querySelector(selector);
  };
}

// node_modules/d3-selection/src/selection/select.js
function select_default(select) {
  if (typeof select !== "function") select = selector_default(select);
  for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
    for (var group = groups[j], n = group.length, subgroup = subgroups[j] = new Array(n), node, subnode, i = 0; i < n; ++i) {
      if ((node = group[i]) && (subnode = select.call(node, node.__data__, i, group))) {
        if ("__data__" in node) subnode.__data__ = node.__data__;
        subgroup[i] = subnode;
      }
    }
  }
  return new Selection(subgroups, this._parents);
}

// node_modules/d3-selection/src/selectorAll.js
function empty() {
  return [];
}
function selectorAll_default(selector) {
  return selector == null ? empty : function() {
    return this.querySelectorAll(selector);
  };
}

// node_modules/d3-selection/src/selection/selectAll.js
function selectAll_default(select) {
  if (typeof select !== "function") select = selectorAll_default(select);
  for (var groups = this._groups, m = groups.length, subgroups = [], parents = [], j = 0; j < m; ++j) {
    for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
      if (node = group[i]) {
        subgroups.push(select.call(node, node.__data__, i, group));
        parents.push(node);
      }
    }
  }
  return new Selection(subgroups, parents);
}

// node_modules/d3-selection/src/matcher.js
function matcher_default(selector) {
  return function() {
    return this.matches(selector);
  };
}

// node_modules/d3-selection/src/selection/filter.js
function filter_default(match) {
  if (typeof match !== "function") match = matcher_default(match);
  for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
    for (var group = groups[j], n = group.length, subgroup = subgroups[j] = [], node, i = 0; i < n; ++i) {
      if ((node = group[i]) && match.call(node, node.__data__, i, group)) {
        subgroup.push(node);
      }
    }
  }
  return new Selection(subgroups, this._parents);
}

// node_modules/d3-selection/src/selection/sparse.js
function sparse_default(update) {
  return new Array(update.length);
}

// node_modules/d3-selection/src/selection/enter.js
function enter_default() {
  return new Selection(this._enter || this._groups.map(sparse_default), this._parents);
}
function EnterNode(parent, datum) {
  this.ownerDocument = parent.ownerDocument;
  this.namespaceURI = parent.namespaceURI;
  this._next = null;
  this._parent = parent;
  this.__data__ = datum;
}
EnterNode.prototype = {
  constructor: EnterNode,
  appendChild: function(child) {
    return this._parent.insertBefore(child, this._next);
  },
  insertBefore: function(child, next) {
    return this._parent.insertBefore(child, next);
  },
  querySelector: function(selector) {
    return this._parent.querySelector(selector);
  },
  querySelectorAll: function(selector) {
    return this._parent.querySelectorAll(selector);
  }
};

// node_modules/d3-selection/src/constant.js
function constant_default(x2) {
  return function() {
    return x2;
  };
}

// node_modules/d3-selection/src/selection/data.js
var keyPrefix = "$";
function bindIndex(parent, group, enter, update, exit, data) {
  var i = 0, node, groupLength = group.length, dataLength = data.length;
  for (; i < dataLength; ++i) {
    if (node = group[i]) {
      node.__data__ = data[i];
      update[i] = node;
    } else {
      enter[i] = new EnterNode(parent, data[i]);
    }
  }
  for (; i < groupLength; ++i) {
    if (node = group[i]) {
      exit[i] = node;
    }
  }
}
function bindKey(parent, group, enter, update, exit, data, key) {
  var i, node, nodeByKeyValue = {}, groupLength = group.length, dataLength = data.length, keyValues = new Array(groupLength), keyValue;
  for (i = 0; i < groupLength; ++i) {
    if (node = group[i]) {
      keyValues[i] = keyValue = keyPrefix + key.call(node, node.__data__, i, group);
      if (keyValue in nodeByKeyValue) {
        exit[i] = node;
      } else {
        nodeByKeyValue[keyValue] = node;
      }
    }
  }
  for (i = 0; i < dataLength; ++i) {
    keyValue = keyPrefix + key.call(parent, data[i], i, data);
    if (node = nodeByKeyValue[keyValue]) {
      update[i] = node;
      node.__data__ = data[i];
      nodeByKeyValue[keyValue] = null;
    } else {
      enter[i] = new EnterNode(parent, data[i]);
    }
  }
  for (i = 0; i < groupLength; ++i) {
    if ((node = group[i]) && nodeByKeyValue[keyValues[i]] === node) {
      exit[i] = node;
    }
  }
}
function data_default(value, key) {
  if (!value) {
    data = new Array(this.size()), j = -1;
    this.each(function(d) {
      data[++j] = d;
    });
    return data;
  }
  var bind = key ? bindKey : bindIndex, parents = this._parents, groups = this._groups;
  if (typeof value !== "function") value = constant_default(value);
  for (var m = groups.length, update = new Array(m), enter = new Array(m), exit = new Array(m), j = 0; j < m; ++j) {
    var parent = parents[j], group = groups[j], groupLength = group.length, data = value.call(parent, parent && parent.__data__, j, parents), dataLength = data.length, enterGroup = enter[j] = new Array(dataLength), updateGroup = update[j] = new Array(dataLength), exitGroup = exit[j] = new Array(groupLength);
    bind(parent, group, enterGroup, updateGroup, exitGroup, data, key);
    for (var i0 = 0, i1 = 0, previous, next; i0 < dataLength; ++i0) {
      if (previous = enterGroup[i0]) {
        if (i0 >= i1) i1 = i0 + 1;
        while (!(next = updateGroup[i1]) && ++i1 < dataLength) ;
        previous._next = next || null;
      }
    }
  }
  update = new Selection(update, parents);
  update._enter = enter;
  update._exit = exit;
  return update;
}

// node_modules/d3-selection/src/selection/exit.js
function exit_default() {
  return new Selection(this._exit || this._groups.map(sparse_default), this._parents);
}

// node_modules/d3-selection/src/selection/join.js
function join_default(onenter, onupdate, onexit) {
  var enter = this.enter(), update = this, exit = this.exit();
  enter = typeof onenter === "function" ? onenter(enter) : enter.append(onenter + "");
  if (onupdate != null) update = onupdate(update);
  if (onexit == null) exit.remove();
  else onexit(exit);
  return enter && update ? enter.merge(update).order() : update;
}

// node_modules/d3-selection/src/selection/merge.js
function merge_default(selection2) {
  for (var groups0 = this._groups, groups1 = selection2._groups, m0 = groups0.length, m1 = groups1.length, m = Math.min(m0, m1), merges = new Array(m0), j = 0; j < m; ++j) {
    for (var group0 = groups0[j], group1 = groups1[j], n = group0.length, merge = merges[j] = new Array(n), node, i = 0; i < n; ++i) {
      if (node = group0[i] || group1[i]) {
        merge[i] = node;
      }
    }
  }
  for (; j < m0; ++j) {
    merges[j] = groups0[j];
  }
  return new Selection(merges, this._parents);
}

// node_modules/d3-selection/src/selection/order.js
function order_default() {
  for (var groups = this._groups, j = -1, m = groups.length; ++j < m; ) {
    for (var group = groups[j], i = group.length - 1, next = group[i], node; --i >= 0; ) {
      if (node = group[i]) {
        if (next && node.compareDocumentPosition(next) ^ 4) next.parentNode.insertBefore(node, next);
        next = node;
      }
    }
  }
  return this;
}

// node_modules/d3-selection/src/selection/sort.js
function sort_default(compare) {
  if (!compare) compare = ascending;
  function compareNode(a, b) {
    return a && b ? compare(a.__data__, b.__data__) : !a - !b;
  }
  for (var groups = this._groups, m = groups.length, sortgroups = new Array(m), j = 0; j < m; ++j) {
    for (var group = groups[j], n = group.length, sortgroup = sortgroups[j] = new Array(n), node, i = 0; i < n; ++i) {
      if (node = group[i]) {
        sortgroup[i] = node;
      }
    }
    sortgroup.sort(compareNode);
  }
  return new Selection(sortgroups, this._parents).order();
}
function ascending(a, b) {
  return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
}

// node_modules/d3-selection/src/selection/call.js
function call_default() {
  var callback = arguments[0];
  arguments[0] = this;
  callback.apply(null, arguments);
  return this;
}

// node_modules/d3-selection/src/selection/nodes.js
function nodes_default() {
  var nodes = new Array(this.size()), i = -1;
  this.each(function() {
    nodes[++i] = this;
  });
  return nodes;
}

// node_modules/d3-selection/src/selection/node.js
function node_default() {
  for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
    for (var group = groups[j], i = 0, n = group.length; i < n; ++i) {
      var node = group[i];
      if (node) return node;
    }
  }
  return null;
}

// node_modules/d3-selection/src/selection/size.js
function size_default() {
  var size = 0;
  this.each(function() {
    ++size;
  });
  return size;
}

// node_modules/d3-selection/src/selection/empty.js
function empty_default() {
  return !this.node();
}

// node_modules/d3-selection/src/selection/each.js
function each_default(callback) {
  for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
    for (var group = groups[j], i = 0, n = group.length, node; i < n; ++i) {
      if (node = group[i]) callback.call(node, node.__data__, i, group);
    }
  }
  return this;
}

// node_modules/d3-selection/src/selection/attr.js
function attrRemove(name) {
  return function() {
    this.removeAttribute(name);
  };
}
function attrRemoveNS(fullname) {
  return function() {
    this.removeAttributeNS(fullname.space, fullname.local);
  };
}
function attrConstant(name, value) {
  return function() {
    this.setAttribute(name, value);
  };
}
function attrConstantNS(fullname, value) {
  return function() {
    this.setAttributeNS(fullname.space, fullname.local, value);
  };
}
function attrFunction(name, value) {
  return function() {
    var v = value.apply(this, arguments);
    if (v == null) this.removeAttribute(name);
    else this.setAttribute(name, v);
  };
}
function attrFunctionNS(fullname, value) {
  return function() {
    var v = value.apply(this, arguments);
    if (v == null) this.removeAttributeNS(fullname.space, fullname.local);
    else this.setAttributeNS(fullname.space, fullname.local, v);
  };
}
function attr_default(name, value) {
  var fullname = namespace_default(name);
  if (arguments.length < 2) {
    var node = this.node();
    return fullname.local ? node.getAttributeNS(fullname.space, fullname.local) : node.getAttribute(fullname);
  }
  return this.each((value == null ? fullname.local ? attrRemoveNS : attrRemove : typeof value === "function" ? fullname.local ? attrFunctionNS : attrFunction : fullname.local ? attrConstantNS : attrConstant)(fullname, value));
}

// node_modules/d3-selection/src/window.js
function window_default(node) {
  return node.ownerDocument && node.ownerDocument.defaultView || node.document && node || node.defaultView;
}

// node_modules/d3-selection/src/selection/style.js
function styleRemove(name) {
  return function() {
    this.style.removeProperty(name);
  };
}
function styleConstant(name, value, priority) {
  return function() {
    this.style.setProperty(name, value, priority);
  };
}
function styleFunction(name, value, priority) {
  return function() {
    var v = value.apply(this, arguments);
    if (v == null) this.style.removeProperty(name);
    else this.style.setProperty(name, v, priority);
  };
}
function style_default(name, value, priority) {
  return arguments.length > 1 ? this.each((value == null ? styleRemove : typeof value === "function" ? styleFunction : styleConstant)(name, value, priority == null ? "" : priority)) : styleValue(this.node(), name);
}
function styleValue(node, name) {
  return node.style.getPropertyValue(name) || window_default(node).getComputedStyle(node, null).getPropertyValue(name);
}

// node_modules/d3-selection/src/selection/property.js
function propertyRemove(name) {
  return function() {
    delete this[name];
  };
}
function propertyConstant(name, value) {
  return function() {
    this[name] = value;
  };
}
function propertyFunction(name, value) {
  return function() {
    var v = value.apply(this, arguments);
    if (v == null) delete this[name];
    else this[name] = v;
  };
}
function property_default(name, value) {
  return arguments.length > 1 ? this.each((value == null ? propertyRemove : typeof value === "function" ? propertyFunction : propertyConstant)(name, value)) : this.node()[name];
}

// node_modules/d3-selection/src/selection/classed.js
function classArray(string) {
  return string.trim().split(/^|\s+/);
}
function classList(node) {
  return node.classList || new ClassList(node);
}
function ClassList(node) {
  this._node = node;
  this._names = classArray(node.getAttribute("class") || "");
}
ClassList.prototype = {
  add: function(name) {
    var i = this._names.indexOf(name);
    if (i < 0) {
      this._names.push(name);
      this._node.setAttribute("class", this._names.join(" "));
    }
  },
  remove: function(name) {
    var i = this._names.indexOf(name);
    if (i >= 0) {
      this._names.splice(i, 1);
      this._node.setAttribute("class", this._names.join(" "));
    }
  },
  contains: function(name) {
    return this._names.indexOf(name) >= 0;
  }
};
function classedAdd(node, names) {
  var list = classList(node), i = -1, n = names.length;
  while (++i < n) list.add(names[i]);
}
function classedRemove(node, names) {
  var list = classList(node), i = -1, n = names.length;
  while (++i < n) list.remove(names[i]);
}
function classedTrue(names) {
  return function() {
    classedAdd(this, names);
  };
}
function classedFalse(names) {
  return function() {
    classedRemove(this, names);
  };
}
function classedFunction(names, value) {
  return function() {
    (value.apply(this, arguments) ? classedAdd : classedRemove)(this, names);
  };
}
function classed_default(name, value) {
  var names = classArray(name + "");
  if (arguments.length < 2) {
    var list = classList(this.node()), i = -1, n = names.length;
    while (++i < n) if (!list.contains(names[i])) return false;
    return true;
  }
  return this.each((typeof value === "function" ? classedFunction : value ? classedTrue : classedFalse)(names, value));
}

// node_modules/d3-selection/src/selection/text.js
function textRemove() {
  this.textContent = "";
}
function textConstant(value) {
  return function() {
    this.textContent = value;
  };
}
function textFunction(value) {
  return function() {
    var v = value.apply(this, arguments);
    this.textContent = v == null ? "" : v;
  };
}
function text_default(value) {
  return arguments.length ? this.each(value == null ? textRemove : (typeof value === "function" ? textFunction : textConstant)(value)) : this.node().textContent;
}

// node_modules/d3-selection/src/selection/html.js
function htmlRemove() {
  this.innerHTML = "";
}
function htmlConstant(value) {
  return function() {
    this.innerHTML = value;
  };
}
function htmlFunction(value) {
  return function() {
    var v = value.apply(this, arguments);
    this.innerHTML = v == null ? "" : v;
  };
}
function html_default(value) {
  return arguments.length ? this.each(value == null ? htmlRemove : (typeof value === "function" ? htmlFunction : htmlConstant)(value)) : this.node().innerHTML;
}

// node_modules/d3-selection/src/selection/raise.js
function raise() {
  if (this.nextSibling) this.parentNode.appendChild(this);
}
function raise_default() {
  return this.each(raise);
}

// node_modules/d3-selection/src/selection/lower.js
function lower() {
  if (this.previousSibling) this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function lower_default() {
  return this.each(lower);
}

// node_modules/d3-selection/src/selection/append.js
function append_default(name) {
  var create = typeof name === "function" ? name : creator_default(name);
  return this.select(function() {
    return this.appendChild(create.apply(this, arguments));
  });
}

// node_modules/d3-selection/src/selection/insert.js
function constantNull() {
  return null;
}
function insert_default(name, before) {
  var create = typeof name === "function" ? name : creator_default(name), select = before == null ? constantNull : typeof before === "function" ? before : selector_default(before);
  return this.select(function() {
    return this.insertBefore(create.apply(this, arguments), select.apply(this, arguments) || null);
  });
}

// node_modules/d3-selection/src/selection/remove.js
function remove() {
  var parent = this.parentNode;
  if (parent) parent.removeChild(this);
}
function remove_default() {
  return this.each(remove);
}

// node_modules/d3-selection/src/selection/clone.js
function selection_cloneShallow() {
  var clone = this.cloneNode(false), parent = this.parentNode;
  return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
}
function selection_cloneDeep() {
  var clone = this.cloneNode(true), parent = this.parentNode;
  return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
}
function clone_default(deep) {
  return this.select(deep ? selection_cloneDeep : selection_cloneShallow);
}

// node_modules/d3-selection/src/selection/datum.js
function datum_default(value) {
  return arguments.length ? this.property("__data__", value) : this.node().__data__;
}

// node_modules/d3-selection/src/selection/on.js
var filterEvents = {};
var event = null;
if (typeof document !== "undefined") {
  element = document.documentElement;
  if (!("onmouseenter" in element)) {
    filterEvents = { mouseenter: "mouseover", mouseleave: "mouseout" };
  }
}
var element;
function filterContextListener(listener, index, group) {
  listener = contextListener(listener, index, group);
  return function(event2) {
    var related = event2.relatedTarget;
    if (!related || related !== this && !(related.compareDocumentPosition(this) & 8)) {
      listener.call(this, event2);
    }
  };
}
function contextListener(listener, index, group) {
  return function(event1) {
    var event0 = event;
    event = event1;
    try {
      listener.call(this, this.__data__, index, group);
    } finally {
      event = event0;
    }
  };
}
function parseTypenames(typenames) {
  return typenames.trim().split(/^|\s+/).map(function(t) {
    var name = "", i = t.indexOf(".");
    if (i >= 0) name = t.slice(i + 1), t = t.slice(0, i);
    return { type: t, name };
  });
}
function onRemove(typename) {
  return function() {
    var on = this.__on;
    if (!on) return;
    for (var j = 0, i = -1, m = on.length, o; j < m; ++j) {
      if (o = on[j], (!typename.type || o.type === typename.type) && o.name === typename.name) {
        this.removeEventListener(o.type, o.listener, o.capture);
      } else {
        on[++i] = o;
      }
    }
    if (++i) on.length = i;
    else delete this.__on;
  };
}
function onAdd(typename, value, capture) {
  var wrap = filterEvents.hasOwnProperty(typename.type) ? filterContextListener : contextListener;
  return function(d, i, group) {
    var on = this.__on, o, listener = wrap(value, i, group);
    if (on) for (var j = 0, m = on.length; j < m; ++j) {
      if ((o = on[j]).type === typename.type && o.name === typename.name) {
        this.removeEventListener(o.type, o.listener, o.capture);
        this.addEventListener(o.type, o.listener = listener, o.capture = capture);
        o.value = value;
        return;
      }
    }
    this.addEventListener(typename.type, listener, capture);
    o = { type: typename.type, name: typename.name, value, listener, capture };
    if (!on) this.__on = [o];
    else on.push(o);
  };
}
function on_default(typename, value, capture) {
  var typenames = parseTypenames(typename + ""), i, n = typenames.length, t;
  if (arguments.length < 2) {
    var on = this.node().__on;
    if (on) for (var j = 0, m = on.length, o; j < m; ++j) {
      for (i = 0, o = on[j]; i < n; ++i) {
        if ((t = typenames[i]).type === o.type && t.name === o.name) {
          return o.value;
        }
      }
    }
    return;
  }
  on = value ? onAdd : onRemove;
  if (capture == null) capture = false;
  for (i = 0; i < n; ++i) this.each(on(typenames[i], value, capture));
  return this;
}

// node_modules/d3-selection/src/selection/dispatch.js
function dispatchEvent(node, type, params) {
  var window2 = window_default(node), event2 = window2.CustomEvent;
  if (typeof event2 === "function") {
    event2 = new event2(type, params);
  } else {
    event2 = window2.document.createEvent("Event");
    if (params) event2.initEvent(type, params.bubbles, params.cancelable), event2.detail = params.detail;
    else event2.initEvent(type, false, false);
  }
  node.dispatchEvent(event2);
}
function dispatchConstant(type, params) {
  return function() {
    return dispatchEvent(this, type, params);
  };
}
function dispatchFunction(type, params) {
  return function() {
    return dispatchEvent(this, type, params.apply(this, arguments));
  };
}
function dispatch_default(type, params) {
  return this.each((typeof params === "function" ? dispatchFunction : dispatchConstant)(type, params));
}

// node_modules/d3-selection/src/selection/index.js
var root = [null];
function Selection(groups, parents) {
  this._groups = groups;
  this._parents = parents;
}
function selection() {
  return new Selection([[document.documentElement]], root);
}
Selection.prototype = selection.prototype = {
  constructor: Selection,
  select: select_default,
  selectAll: selectAll_default,
  filter: filter_default,
  data: data_default,
  enter: enter_default,
  exit: exit_default,
  join: join_default,
  merge: merge_default,
  order: order_default,
  sort: sort_default,
  call: call_default,
  nodes: nodes_default,
  node: node_default,
  size: size_default,
  empty: empty_default,
  each: each_default,
  attr: attr_default,
  style: style_default,
  property: property_default,
  classed: classed_default,
  text: text_default,
  html: html_default,
  raise: raise_default,
  lower: lower_default,
  append: append_default,
  insert: insert_default,
  remove: remove_default,
  clone: clone_default,
  datum: datum_default,
  on: on_default,
  dispatch: dispatch_default
};

// node_modules/d3-selection/src/select.js
function select_default2(selector) {
  return typeof selector === "string" ? new Selection([[document.querySelector(selector)]], [document.documentElement]) : new Selection([[selector]], root);
}

// node_modules/d3-selection/src/sourceEvent.js
function sourceEvent_default() {
  var current = event, source;
  while (source = current.sourceEvent) current = source;
  return current;
}

// node_modules/d3-selection/src/point.js
function point_default(node, event2) {
  var svg = node.ownerSVGElement || node;
  if (svg.createSVGPoint) {
    var point3 = svg.createSVGPoint();
    point3.x = event2.clientX, point3.y = event2.clientY;
    point3 = point3.matrixTransform(node.getScreenCTM().inverse());
    return [point3.x, point3.y];
  }
  var rect = node.getBoundingClientRect();
  return [event2.clientX - rect.left - node.clientLeft, event2.clientY - rect.top - node.clientTop];
}

// node_modules/d3-selection/src/mouse.js
function mouse_default(node) {
  var event2 = sourceEvent_default();
  if (event2.changedTouches) event2 = event2.changedTouches[0];
  return point_default(node, event2);
}

// node_modules/d3-array/src/ascending.js
function ascending_default(a, b) {
  return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
}

// node_modules/d3-array/src/bisector.js
function bisector_default(f) {
  let delta = f;
  let compare = f;
  if (f.length === 1) {
    delta = (d, x2) => f(d) - x2;
    compare = ascendingComparator(f);
  }
  function left2(a, x2, lo, hi) {
    if (lo == null) lo = 0;
    if (hi == null) hi = a.length;
    while (lo < hi) {
      const mid = lo + hi >>> 1;
      if (compare(a[mid], x2) < 0) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }
  function right2(a, x2, lo, hi) {
    if (lo == null) lo = 0;
    if (hi == null) hi = a.length;
    while (lo < hi) {
      const mid = lo + hi >>> 1;
      if (compare(a[mid], x2) > 0) hi = mid;
      else lo = mid + 1;
    }
    return lo;
  }
  function center2(a, x2, lo, hi) {
    if (lo == null) lo = 0;
    if (hi == null) hi = a.length;
    const i = left2(a, x2, lo, hi - 1);
    return i > lo && delta(a[i - 1], x2) > -delta(a[i], x2) ? i - 1 : i;
  }
  return { left: left2, center: center2, right: right2 };
}
function ascendingComparator(f) {
  return (d, x2) => ascending_default(f(d), x2);
}

// node_modules/d3-array/src/number.js
function number_default(x2) {
  return x2 === null ? NaN : +x2;
}

// node_modules/d3-array/src/bisect.js
var ascendingBisect = bisector_default(ascending_default);
var bisectRight = ascendingBisect.right;
var bisectLeft = ascendingBisect.left;
var bisectCenter = bisector_default(number_default).center;
var bisect_default = bisectRight;

// node_modules/internmap/src/index.js
var InternMap = class extends Map {
  constructor(entries, key = keyof) {
    super();
    Object.defineProperties(this, { _intern: { value: /* @__PURE__ */ new Map() }, _key: { value: key } });
    if (entries != null) for (const [key2, value] of entries) this.set(key2, value);
  }
  get(key) {
    return super.get(intern_get(this, key));
  }
  has(key) {
    return super.has(intern_get(this, key));
  }
  set(key, value) {
    return super.set(intern_set(this, key), value);
  }
  delete(key) {
    return super.delete(intern_delete(this, key));
  }
};
function intern_get({ _intern, _key }, value) {
  const key = _key(value);
  return _intern.has(key) ? _intern.get(key) : value;
}
function intern_set({ _intern, _key }, value) {
  const key = _key(value);
  if (_intern.has(key)) return _intern.get(key);
  _intern.set(key, value);
  return value;
}
function intern_delete({ _intern, _key }, value) {
  const key = _key(value);
  if (_intern.has(key)) {
    value = _intern.get(value);
    _intern.delete(key);
  }
  return value;
}
function keyof(value) {
  return value !== null && typeof value === "object" ? value.valueOf() : value;
}

// node_modules/d3-array/src/ticks.js
var e10 = Math.sqrt(50);
var e5 = Math.sqrt(10);
var e2 = Math.sqrt(2);
function ticks_default(start, stop, count) {
  var reverse, i = -1, n, ticks, step;
  stop = +stop, start = +start, count = +count;
  if (start === stop && count > 0) return [start];
  if (reverse = stop < start) n = start, start = stop, stop = n;
  if ((step = tickIncrement(start, stop, count)) === 0 || !isFinite(step)) return [];
  if (step > 0) {
    let r0 = Math.round(start / step), r1 = Math.round(stop / step);
    if (r0 * step < start) ++r0;
    if (r1 * step > stop) --r1;
    ticks = new Array(n = r1 - r0 + 1);
    while (++i < n) ticks[i] = (r0 + i) * step;
  } else {
    step = -step;
    let r0 = Math.round(start * step), r1 = Math.round(stop * step);
    if (r0 / step < start) ++r0;
    if (r1 / step > stop) --r1;
    ticks = new Array(n = r1 - r0 + 1);
    while (++i < n) ticks[i] = (r0 + i) / step;
  }
  if (reverse) ticks.reverse();
  return ticks;
}
function tickIncrement(start, stop, count) {
  var step = (stop - start) / Math.max(0, count), power = Math.floor(Math.log(step) / Math.LN10), error = step / Math.pow(10, power);
  return power >= 0 ? (error >= e10 ? 10 : error >= e5 ? 5 : error >= e2 ? 2 : 1) * Math.pow(10, power) : -Math.pow(10, -power) / (error >= e10 ? 10 : error >= e5 ? 5 : error >= e2 ? 2 : 1);
}
function tickStep(start, stop, count) {
  var step0 = Math.abs(stop - start) / Math.max(0, count), step1 = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10)), error = step0 / step1;
  if (error >= e10) step1 *= 10;
  else if (error >= e5) step1 *= 5;
  else if (error >= e2) step1 *= 2;
  return stop < start ? -step1 : step1;
}

// node_modules/d3-array/src/range.js
function range_default(start, stop, step) {
  start = +start, stop = +stop, step = (n = arguments.length) < 2 ? (stop = start, start = 0, 1) : n < 3 ? 1 : +step;
  var i = -1, n = Math.max(0, Math.ceil((stop - start) / step)) | 0, range = new Array(n);
  while (++i < n) {
    range[i] = start + i * step;
  }
  return range;
}

// node_modules/d3-scale/src/init.js
function initRange(domain, range) {
  switch (arguments.length) {
    case 0:
      break;
    case 1:
      this.range(domain);
      break;
    default:
      this.range(range).domain(domain);
      break;
  }
  return this;
}

// node_modules/d3-scale/src/ordinal.js
var implicit = Symbol("implicit");
function ordinal() {
  var index = new InternMap(), domain = [], range = [], unknown = implicit;
  function scale(d) {
    let i = index.get(d);
    if (i === void 0) {
      if (unknown !== implicit) return unknown;
      index.set(d, i = domain.push(d) - 1);
    }
    return range[i % range.length];
  }
  scale.domain = function(_) {
    if (!arguments.length) return domain.slice();
    domain = [], index = new InternMap();
    for (const value of _) {
      if (index.has(value)) continue;
      index.set(value, domain.push(value) - 1);
    }
    return scale;
  };
  scale.range = function(_) {
    return arguments.length ? (range = Array.from(_), scale) : range.slice();
  };
  scale.unknown = function(_) {
    return arguments.length ? (unknown = _, scale) : unknown;
  };
  scale.copy = function() {
    return ordinal(domain, range).unknown(unknown);
  };
  initRange.apply(scale, arguments);
  return scale;
}

// node_modules/d3-scale/src/band.js
function band() {
  var scale = ordinal().unknown(void 0), domain = scale.domain, ordinalRange = scale.range, r0 = 0, r1 = 1, step, bandwidth, round = false, paddingInner = 0, paddingOuter = 0, align = 0.5;
  delete scale.unknown;
  function rescale() {
    var n = domain().length, reverse = r1 < r0, start = reverse ? r1 : r0, stop = reverse ? r0 : r1;
    step = (stop - start) / Math.max(1, n - paddingInner + paddingOuter * 2);
    if (round) step = Math.floor(step);
    start += (stop - start - step * (n - paddingInner)) * align;
    bandwidth = step * (1 - paddingInner);
    if (round) start = Math.round(start), bandwidth = Math.round(bandwidth);
    var values = range_default(n).map(function(i) {
      return start + step * i;
    });
    return ordinalRange(reverse ? values.reverse() : values);
  }
  scale.domain = function(_) {
    return arguments.length ? (domain(_), rescale()) : domain();
  };
  scale.range = function(_) {
    return arguments.length ? ([r0, r1] = _, r0 = +r0, r1 = +r1, rescale()) : [r0, r1];
  };
  scale.rangeRound = function(_) {
    return [r0, r1] = _, r0 = +r0, r1 = +r1, round = true, rescale();
  };
  scale.bandwidth = function() {
    return bandwidth;
  };
  scale.step = function() {
    return step;
  };
  scale.round = function(_) {
    return arguments.length ? (round = !!_, rescale()) : round;
  };
  scale.padding = function(_) {
    return arguments.length ? (paddingInner = Math.min(1, paddingOuter = +_), rescale()) : paddingInner;
  };
  scale.paddingInner = function(_) {
    return arguments.length ? (paddingInner = Math.min(1, _), rescale()) : paddingInner;
  };
  scale.paddingOuter = function(_) {
    return arguments.length ? (paddingOuter = +_, rescale()) : paddingOuter;
  };
  scale.align = function(_) {
    return arguments.length ? (align = Math.max(0, Math.min(1, _)), rescale()) : align;
  };
  scale.copy = function() {
    return band(domain(), [r0, r1]).round(round).paddingInner(paddingInner).paddingOuter(paddingOuter).align(align);
  };
  return initRange.apply(rescale(), arguments);
}
function pointish(scale) {
  var copy2 = scale.copy;
  scale.padding = scale.paddingOuter;
  delete scale.paddingInner;
  delete scale.paddingOuter;
  scale.copy = function() {
    return pointish(copy2());
  };
  return scale;
}
function point() {
  return pointish(band.apply(null, arguments).paddingInner(1));
}

// node_modules/d3-color/src/define.js
function define_default(constructor, factory, prototype) {
  constructor.prototype = factory.prototype = prototype;
  prototype.constructor = constructor;
}
function extend(parent, definition) {
  var prototype = Object.create(parent.prototype);
  for (var key in definition) prototype[key] = definition[key];
  return prototype;
}

// node_modules/d3-color/src/color.js
function Color() {
}
var darker = 0.7;
var brighter = 1 / darker;
var reI = "\\s*([+-]?\\d+)\\s*";
var reN = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*";
var reP = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*";
var reHex = /^#([0-9a-f]{3,8})$/;
var reRgbInteger = new RegExp(`^rgb\\(${reI},${reI},${reI}\\)$`);
var reRgbPercent = new RegExp(`^rgb\\(${reP},${reP},${reP}\\)$`);
var reRgbaInteger = new RegExp(`^rgba\\(${reI},${reI},${reI},${reN}\\)$`);
var reRgbaPercent = new RegExp(`^rgba\\(${reP},${reP},${reP},${reN}\\)$`);
var reHslPercent = new RegExp(`^hsl\\(${reN},${reP},${reP}\\)$`);
var reHslaPercent = new RegExp(`^hsla\\(${reN},${reP},${reP},${reN}\\)$`);
var named = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
define_default(Color, color, {
  copy(channels) {
    return Object.assign(new this.constructor(), this, channels);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: color_formatHex,
  // Deprecated! Use color.formatHex.
  formatHex: color_formatHex,
  formatHex8: color_formatHex8,
  formatHsl: color_formatHsl,
  formatRgb: color_formatRgb,
  toString: color_formatRgb
});
function color_formatHex() {
  return this.rgb().formatHex();
}
function color_formatHex8() {
  return this.rgb().formatHex8();
}
function color_formatHsl() {
  return hslConvert(this).formatHsl();
}
function color_formatRgb() {
  return this.rgb().formatRgb();
}
function color(format2) {
  var m, l;
  format2 = (format2 + "").trim().toLowerCase();
  return (m = reHex.exec(format2)) ? (l = m[1].length, m = parseInt(m[1], 16), l === 6 ? rgbn(m) : l === 3 ? new Rgb(m >> 8 & 15 | m >> 4 & 240, m >> 4 & 15 | m & 240, (m & 15) << 4 | m & 15, 1) : l === 8 ? rgba(m >> 24 & 255, m >> 16 & 255, m >> 8 & 255, (m & 255) / 255) : l === 4 ? rgba(m >> 12 & 15 | m >> 8 & 240, m >> 8 & 15 | m >> 4 & 240, m >> 4 & 15 | m & 240, ((m & 15) << 4 | m & 15) / 255) : null) : (m = reRgbInteger.exec(format2)) ? new Rgb(m[1], m[2], m[3], 1) : (m = reRgbPercent.exec(format2)) ? new Rgb(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, 1) : (m = reRgbaInteger.exec(format2)) ? rgba(m[1], m[2], m[3], m[4]) : (m = reRgbaPercent.exec(format2)) ? rgba(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, m[4]) : (m = reHslPercent.exec(format2)) ? hsla(m[1], m[2] / 100, m[3] / 100, 1) : (m = reHslaPercent.exec(format2)) ? hsla(m[1], m[2] / 100, m[3] / 100, m[4]) : named.hasOwnProperty(format2) ? rgbn(named[format2]) : format2 === "transparent" ? new Rgb(NaN, NaN, NaN, 0) : null;
}
function rgbn(n) {
  return new Rgb(n >> 16 & 255, n >> 8 & 255, n & 255, 1);
}
function rgba(r, g, b, a) {
  if (a <= 0) r = g = b = NaN;
  return new Rgb(r, g, b, a);
}
function rgbConvert(o) {
  if (!(o instanceof Color)) o = color(o);
  if (!o) return new Rgb();
  o = o.rgb();
  return new Rgb(o.r, o.g, o.b, o.opacity);
}
function rgb(r, g, b, opacity) {
  return arguments.length === 1 ? rgbConvert(r) : new Rgb(r, g, b, opacity == null ? 1 : opacity);
}
function Rgb(r, g, b, opacity) {
  this.r = +r;
  this.g = +g;
  this.b = +b;
  this.opacity = +opacity;
}
define_default(Rgb, rgb, extend(Color, {
  brighter(k) {
    k = k == null ? brighter : Math.pow(brighter, k);
    return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
  },
  darker(k) {
    k = k == null ? darker : Math.pow(darker, k);
    return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Rgb(clampi(this.r), clampi(this.g), clampi(this.b), clampa(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && (-0.5 <= this.g && this.g < 255.5) && (-0.5 <= this.b && this.b < 255.5) && (0 <= this.opacity && this.opacity <= 1);
  },
  hex: rgb_formatHex,
  // Deprecated! Use color.formatHex.
  formatHex: rgb_formatHex,
  formatHex8: rgb_formatHex8,
  formatRgb: rgb_formatRgb,
  toString: rgb_formatRgb
}));
function rgb_formatHex() {
  return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}`;
}
function rgb_formatHex8() {
  return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}${hex((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function rgb_formatRgb() {
  const a = clampa(this.opacity);
  return `${a === 1 ? "rgb(" : "rgba("}${clampi(this.r)}, ${clampi(this.g)}, ${clampi(this.b)}${a === 1 ? ")" : `, ${a})`}`;
}
function clampa(opacity) {
  return isNaN(opacity) ? 1 : Math.max(0, Math.min(1, opacity));
}
function clampi(value) {
  return Math.max(0, Math.min(255, Math.round(value) || 0));
}
function hex(value) {
  value = clampi(value);
  return (value < 16 ? "0" : "") + value.toString(16);
}
function hsla(h, s, l, a) {
  if (a <= 0) h = s = l = NaN;
  else if (l <= 0 || l >= 1) h = s = NaN;
  else if (s <= 0) h = NaN;
  return new Hsl(h, s, l, a);
}
function hslConvert(o) {
  if (o instanceof Hsl) return new Hsl(o.h, o.s, o.l, o.opacity);
  if (!(o instanceof Color)) o = color(o);
  if (!o) return new Hsl();
  if (o instanceof Hsl) return o;
  o = o.rgb();
  var r = o.r / 255, g = o.g / 255, b = o.b / 255, min2 = Math.min(r, g, b), max2 = Math.max(r, g, b), h = NaN, s = max2 - min2, l = (max2 + min2) / 2;
  if (s) {
    if (r === max2) h = (g - b) / s + (g < b) * 6;
    else if (g === max2) h = (b - r) / s + 2;
    else h = (r - g) / s + 4;
    s /= l < 0.5 ? max2 + min2 : 2 - max2 - min2;
    h *= 60;
  } else {
    s = l > 0 && l < 1 ? 0 : h;
  }
  return new Hsl(h, s, l, o.opacity);
}
function hsl(h, s, l, opacity) {
  return arguments.length === 1 ? hslConvert(h) : new Hsl(h, s, l, opacity == null ? 1 : opacity);
}
function Hsl(h, s, l, opacity) {
  this.h = +h;
  this.s = +s;
  this.l = +l;
  this.opacity = +opacity;
}
define_default(Hsl, hsl, extend(Color, {
  brighter(k) {
    k = k == null ? brighter : Math.pow(brighter, k);
    return new Hsl(this.h, this.s, this.l * k, this.opacity);
  },
  darker(k) {
    k = k == null ? darker : Math.pow(darker, k);
    return new Hsl(this.h, this.s, this.l * k, this.opacity);
  },
  rgb() {
    var h = this.h % 360 + (this.h < 0) * 360, s = isNaN(h) || isNaN(this.s) ? 0 : this.s, l = this.l, m2 = l + (l < 0.5 ? l : 1 - l) * s, m1 = 2 * l - m2;
    return new Rgb(
      hsl2rgb(h >= 240 ? h - 240 : h + 120, m1, m2),
      hsl2rgb(h, m1, m2),
      hsl2rgb(h < 120 ? h + 240 : h - 120, m1, m2),
      this.opacity
    );
  },
  clamp() {
    return new Hsl(clamph(this.h), clampt(this.s), clampt(this.l), clampa(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && (0 <= this.l && this.l <= 1) && (0 <= this.opacity && this.opacity <= 1);
  },
  formatHsl() {
    const a = clampa(this.opacity);
    return `${a === 1 ? "hsl(" : "hsla("}${clamph(this.h)}, ${clampt(this.s) * 100}%, ${clampt(this.l) * 100}%${a === 1 ? ")" : `, ${a})`}`;
  }
}));
function clamph(value) {
  value = (value || 0) % 360;
  return value < 0 ? value + 360 : value;
}
function clampt(value) {
  return Math.max(0, Math.min(1, value || 0));
}
function hsl2rgb(h, m1, m2) {
  return (h < 60 ? m1 + (m2 - m1) * h / 60 : h < 180 ? m2 : h < 240 ? m1 + (m2 - m1) * (240 - h) / 60 : m1) * 255;
}

// node_modules/d3-interpolate/src/basis.js
function basis(t12, v0, v1, v2, v3) {
  var t2 = t12 * t12, t3 = t2 * t12;
  return ((1 - 3 * t12 + 3 * t2 - t3) * v0 + (4 - 6 * t2 + 3 * t3) * v1 + (1 + 3 * t12 + 3 * t2 - 3 * t3) * v2 + t3 * v3) / 6;
}
function basis_default(values) {
  var n = values.length - 1;
  return function(t) {
    var i = t <= 0 ? t = 0 : t >= 1 ? (t = 1, n - 1) : Math.floor(t * n), v1 = values[i], v2 = values[i + 1], v0 = i > 0 ? values[i - 1] : 2 * v1 - v2, v3 = i < n - 1 ? values[i + 2] : 2 * v2 - v1;
    return basis((t - i / n) * n, v0, v1, v2, v3);
  };
}

// node_modules/d3-interpolate/src/basisClosed.js
function basisClosed_default(values) {
  var n = values.length;
  return function(t) {
    var i = Math.floor(((t %= 1) < 0 ? ++t : t) * n), v0 = values[(i + n - 1) % n], v1 = values[i % n], v2 = values[(i + 1) % n], v3 = values[(i + 2) % n];
    return basis((t - i / n) * n, v0, v1, v2, v3);
  };
}

// node_modules/d3-interpolate/src/constant.js
var constant_default2 = (x2) => () => x2;

// node_modules/d3-interpolate/src/color.js
function linear(a, d) {
  return function(t) {
    return a + t * d;
  };
}
function exponential(a, b, y2) {
  return a = Math.pow(a, y2), b = Math.pow(b, y2) - a, y2 = 1 / y2, function(t) {
    return Math.pow(a + t * b, y2);
  };
}
function gamma(y2) {
  return (y2 = +y2) === 1 ? nogamma : function(a, b) {
    return b - a ? exponential(a, b, y2) : constant_default2(isNaN(a) ? b : a);
  };
}
function nogamma(a, b) {
  var d = b - a;
  return d ? linear(a, d) : constant_default2(isNaN(a) ? b : a);
}

// node_modules/d3-interpolate/src/rgb.js
var rgb_default = (function rgbGamma(y2) {
  var color2 = gamma(y2);
  function rgb2(start, end) {
    var r = color2((start = rgb(start)).r, (end = rgb(end)).r), g = color2(start.g, end.g), b = color2(start.b, end.b), opacity = nogamma(start.opacity, end.opacity);
    return function(t) {
      start.r = r(t);
      start.g = g(t);
      start.b = b(t);
      start.opacity = opacity(t);
      return start + "";
    };
  }
  rgb2.gamma = rgbGamma;
  return rgb2;
})(1);
function rgbSpline(spline) {
  return function(colors) {
    var n = colors.length, r = new Array(n), g = new Array(n), b = new Array(n), i, color2;
    for (i = 0; i < n; ++i) {
      color2 = rgb(colors[i]);
      r[i] = color2.r || 0;
      g[i] = color2.g || 0;
      b[i] = color2.b || 0;
    }
    r = spline(r);
    g = spline(g);
    b = spline(b);
    color2.opacity = 1;
    return function(t) {
      color2.r = r(t);
      color2.g = g(t);
      color2.b = b(t);
      return color2 + "";
    };
  };
}
var rgbBasis = rgbSpline(basis_default);
var rgbBasisClosed = rgbSpline(basisClosed_default);

// node_modules/d3-interpolate/src/numberArray.js
function numberArray_default(a, b) {
  if (!b) b = [];
  var n = a ? Math.min(b.length, a.length) : 0, c = b.slice(), i;
  return function(t) {
    for (i = 0; i < n; ++i) c[i] = a[i] * (1 - t) + b[i] * t;
    return c;
  };
}
function isNumberArray(x2) {
  return ArrayBuffer.isView(x2) && !(x2 instanceof DataView);
}

// node_modules/d3-interpolate/src/array.js
function genericArray(a, b) {
  var nb = b ? b.length : 0, na = a ? Math.min(nb, a.length) : 0, x2 = new Array(na), c = new Array(nb), i;
  for (i = 0; i < na; ++i) x2[i] = value_default(a[i], b[i]);
  for (; i < nb; ++i) c[i] = b[i];
  return function(t) {
    for (i = 0; i < na; ++i) c[i] = x2[i](t);
    return c;
  };
}

// node_modules/d3-interpolate/src/date.js
function date_default(a, b) {
  var d = /* @__PURE__ */ new Date();
  return a = +a, b = +b, function(t) {
    return d.setTime(a * (1 - t) + b * t), d;
  };
}

// node_modules/d3-interpolate/src/number.js
function number_default2(a, b) {
  return a = +a, b = +b, function(t) {
    return a * (1 - t) + b * t;
  };
}

// node_modules/d3-interpolate/src/object.js
function object_default(a, b) {
  var i = {}, c = {}, k;
  if (a === null || typeof a !== "object") a = {};
  if (b === null || typeof b !== "object") b = {};
  for (k in b) {
    if (k in a) {
      i[k] = value_default(a[k], b[k]);
    } else {
      c[k] = b[k];
    }
  }
  return function(t) {
    for (k in i) c[k] = i[k](t);
    return c;
  };
}

// node_modules/d3-interpolate/src/string.js
var reA = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g;
var reB = new RegExp(reA.source, "g");
function zero(b) {
  return function() {
    return b;
  };
}
function one(b) {
  return function(t) {
    return b(t) + "";
  };
}
function string_default(a, b) {
  var bi = reA.lastIndex = reB.lastIndex = 0, am, bm, bs, i = -1, s = [], q = [];
  a = a + "", b = b + "";
  while ((am = reA.exec(a)) && (bm = reB.exec(b))) {
    if ((bs = bm.index) > bi) {
      bs = b.slice(bi, bs);
      if (s[i]) s[i] += bs;
      else s[++i] = bs;
    }
    if ((am = am[0]) === (bm = bm[0])) {
      if (s[i]) s[i] += bm;
      else s[++i] = bm;
    } else {
      s[++i] = null;
      q.push({ i, x: number_default2(am, bm) });
    }
    bi = reB.lastIndex;
  }
  if (bi < b.length) {
    bs = b.slice(bi);
    if (s[i]) s[i] += bs;
    else s[++i] = bs;
  }
  return s.length < 2 ? q[0] ? one(q[0].x) : zero(b) : (b = q.length, function(t) {
    for (var i2 = 0, o; i2 < b; ++i2) s[(o = q[i2]).i] = o.x(t);
    return s.join("");
  });
}

// node_modules/d3-interpolate/src/value.js
function value_default(a, b) {
  var t = typeof b, c;
  return b == null || t === "boolean" ? constant_default2(b) : (t === "number" ? number_default2 : t === "string" ? (c = color(b)) ? (b = c, rgb_default) : string_default : b instanceof color ? rgb_default : b instanceof Date ? date_default : isNumberArray(b) ? numberArray_default : Array.isArray(b) ? genericArray : typeof b.valueOf !== "function" && typeof b.toString !== "function" || isNaN(b) ? object_default : number_default2)(a, b);
}

// node_modules/d3-interpolate/src/round.js
function round_default(a, b) {
  return a = +a, b = +b, function(t) {
    return Math.round(a * (1 - t) + b * t);
  };
}

// node_modules/d3-scale/src/constant.js
function constants(x2) {
  return function() {
    return x2;
  };
}

// node_modules/d3-scale/src/number.js
function number(x2) {
  return +x2;
}

// node_modules/d3-scale/src/continuous.js
var unit = [0, 1];
function identity(x2) {
  return x2;
}
function normalize(a, b) {
  return (b -= a = +a) ? function(x2) {
    return (x2 - a) / b;
  } : constants(isNaN(b) ? NaN : 0.5);
}
function clamper(a, b) {
  var t;
  if (a > b) t = a, a = b, b = t;
  return function(x2) {
    return Math.max(a, Math.min(b, x2));
  };
}
function bimap(domain, range, interpolate) {
  var d0 = domain[0], d1 = domain[1], r0 = range[0], r1 = range[1];
  if (d1 < d0) d0 = normalize(d1, d0), r0 = interpolate(r1, r0);
  else d0 = normalize(d0, d1), r0 = interpolate(r0, r1);
  return function(x2) {
    return r0(d0(x2));
  };
}
function polymap(domain, range, interpolate) {
  var j = Math.min(domain.length, range.length) - 1, d = new Array(j), r = new Array(j), i = -1;
  if (domain[j] < domain[0]) {
    domain = domain.slice().reverse();
    range = range.slice().reverse();
  }
  while (++i < j) {
    d[i] = normalize(domain[i], domain[i + 1]);
    r[i] = interpolate(range[i], range[i + 1]);
  }
  return function(x2) {
    var i2 = bisect_default(domain, x2, 1, j) - 1;
    return r[i2](d[i2](x2));
  };
}
function copy(source, target) {
  return target.domain(source.domain()).range(source.range()).interpolate(source.interpolate()).clamp(source.clamp()).unknown(source.unknown());
}
function transformer() {
  var domain = unit, range = unit, interpolate = value_default, transform, untransform, unknown, clamp = identity, piecewise, output, input;
  function rescale() {
    var n = Math.min(domain.length, range.length);
    if (clamp !== identity) clamp = clamper(domain[0], domain[n - 1]);
    piecewise = n > 2 ? polymap : bimap;
    output = input = null;
    return scale;
  }
  function scale(x2) {
    return x2 == null || isNaN(x2 = +x2) ? unknown : (output || (output = piecewise(domain.map(transform), range, interpolate)))(transform(clamp(x2)));
  }
  scale.invert = function(y2) {
    return clamp(untransform((input || (input = piecewise(range, domain.map(transform), number_default2)))(y2)));
  };
  scale.domain = function(_) {
    return arguments.length ? (domain = Array.from(_, number), rescale()) : domain.slice();
  };
  scale.range = function(_) {
    return arguments.length ? (range = Array.from(_), rescale()) : range.slice();
  };
  scale.rangeRound = function(_) {
    return range = Array.from(_), interpolate = round_default, rescale();
  };
  scale.clamp = function(_) {
    return arguments.length ? (clamp = _ ? true : identity, rescale()) : clamp !== identity;
  };
  scale.interpolate = function(_) {
    return arguments.length ? (interpolate = _, rescale()) : interpolate;
  };
  scale.unknown = function(_) {
    return arguments.length ? (unknown = _, scale) : unknown;
  };
  return function(t, u) {
    transform = t, untransform = u;
    return rescale();
  };
}
function continuous() {
  return transformer()(identity, identity);
}

// node_modules/d3-format/src/formatDecimal.js
function formatDecimal_default(x2) {
  return Math.abs(x2 = Math.round(x2)) >= 1e21 ? x2.toLocaleString("en").replace(/,/g, "") : x2.toString(10);
}
function formatDecimalParts(x2, p) {
  if ((i = (x2 = p ? x2.toExponential(p - 1) : x2.toExponential()).indexOf("e")) < 0) return null;
  var i, coefficient = x2.slice(0, i);
  return [
    coefficient.length > 1 ? coefficient[0] + coefficient.slice(2) : coefficient,
    +x2.slice(i + 1)
  ];
}

// node_modules/d3-format/src/exponent.js
function exponent_default(x2) {
  return x2 = formatDecimalParts(Math.abs(x2)), x2 ? x2[1] : NaN;
}

// node_modules/d3-format/src/formatGroup.js
function formatGroup_default(grouping, thousands) {
  return function(value, width) {
    var i = value.length, t = [], j = 0, g = grouping[0], length = 0;
    while (i > 0 && g > 0) {
      if (length + g + 1 > width) g = Math.max(1, width - length);
      t.push(value.substring(i -= g, i + g));
      if ((length += g + 1) > width) break;
      g = grouping[j = (j + 1) % grouping.length];
    }
    return t.reverse().join(thousands);
  };
}

// node_modules/d3-format/src/formatNumerals.js
function formatNumerals_default(numerals) {
  return function(value) {
    return value.replace(/[0-9]/g, function(i) {
      return numerals[+i];
    });
  };
}

// node_modules/d3-format/src/formatSpecifier.js
var re = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function formatSpecifier(specifier) {
  if (!(match = re.exec(specifier))) throw new Error("invalid format: " + specifier);
  var match;
  return new FormatSpecifier({
    fill: match[1],
    align: match[2],
    sign: match[3],
    symbol: match[4],
    zero: match[5],
    width: match[6],
    comma: match[7],
    precision: match[8] && match[8].slice(1),
    trim: match[9],
    type: match[10]
  });
}
formatSpecifier.prototype = FormatSpecifier.prototype;
function FormatSpecifier(specifier) {
  this.fill = specifier.fill === void 0 ? " " : specifier.fill + "";
  this.align = specifier.align === void 0 ? ">" : specifier.align + "";
  this.sign = specifier.sign === void 0 ? "-" : specifier.sign + "";
  this.symbol = specifier.symbol === void 0 ? "" : specifier.symbol + "";
  this.zero = !!specifier.zero;
  this.width = specifier.width === void 0 ? void 0 : +specifier.width;
  this.comma = !!specifier.comma;
  this.precision = specifier.precision === void 0 ? void 0 : +specifier.precision;
  this.trim = !!specifier.trim;
  this.type = specifier.type === void 0 ? "" : specifier.type + "";
}
FormatSpecifier.prototype.toString = function() {
  return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type;
};

// node_modules/d3-format/src/formatTrim.js
function formatTrim_default(s) {
  out: for (var n = s.length, i = 1, i0 = -1, i1; i < n; ++i) {
    switch (s[i]) {
      case ".":
        i0 = i1 = i;
        break;
      case "0":
        if (i0 === 0) i0 = i;
        i1 = i;
        break;
      default:
        if (!+s[i]) break out;
        if (i0 > 0) i0 = 0;
        break;
    }
  }
  return i0 > 0 ? s.slice(0, i0) + s.slice(i1 + 1) : s;
}

// node_modules/d3-format/src/formatPrefixAuto.js
var prefixExponent;
function formatPrefixAuto_default(x2, p) {
  var d = formatDecimalParts(x2, p);
  if (!d) return x2 + "";
  var coefficient = d[0], exponent = d[1], i = exponent - (prefixExponent = Math.max(-8, Math.min(8, Math.floor(exponent / 3))) * 3) + 1, n = coefficient.length;
  return i === n ? coefficient : i > n ? coefficient + new Array(i - n + 1).join("0") : i > 0 ? coefficient.slice(0, i) + "." + coefficient.slice(i) : "0." + new Array(1 - i).join("0") + formatDecimalParts(x2, Math.max(0, p + i - 1))[0];
}

// node_modules/d3-format/src/formatRounded.js
function formatRounded_default(x2, p) {
  var d = formatDecimalParts(x2, p);
  if (!d) return x2 + "";
  var coefficient = d[0], exponent = d[1];
  return exponent < 0 ? "0." + new Array(-exponent).join("0") + coefficient : coefficient.length > exponent + 1 ? coefficient.slice(0, exponent + 1) + "." + coefficient.slice(exponent + 1) : coefficient + new Array(exponent - coefficient.length + 2).join("0");
}

// node_modules/d3-format/src/formatTypes.js
var formatTypes_default = {
  "%": (x2, p) => (x2 * 100).toFixed(p),
  "b": (x2) => Math.round(x2).toString(2),
  "c": (x2) => x2 + "",
  "d": formatDecimal_default,
  "e": (x2, p) => x2.toExponential(p),
  "f": (x2, p) => x2.toFixed(p),
  "g": (x2, p) => x2.toPrecision(p),
  "o": (x2) => Math.round(x2).toString(8),
  "p": (x2, p) => formatRounded_default(x2 * 100, p),
  "r": formatRounded_default,
  "s": formatPrefixAuto_default,
  "X": (x2) => Math.round(x2).toString(16).toUpperCase(),
  "x": (x2) => Math.round(x2).toString(16)
};

// node_modules/d3-format/src/identity.js
function identity_default(x2) {
  return x2;
}

// node_modules/d3-format/src/locale.js
var map = Array.prototype.map;
var prefixes = ["y", "z", "a", "f", "p", "n", "\xB5", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
function locale_default(locale3) {
  var group = locale3.grouping === void 0 || locale3.thousands === void 0 ? identity_default : formatGroup_default(map.call(locale3.grouping, Number), locale3.thousands + ""), currencyPrefix = locale3.currency === void 0 ? "" : locale3.currency[0] + "", currencySuffix = locale3.currency === void 0 ? "" : locale3.currency[1] + "", decimal = locale3.decimal === void 0 ? "." : locale3.decimal + "", numerals = locale3.numerals === void 0 ? identity_default : formatNumerals_default(map.call(locale3.numerals, String)), percent = locale3.percent === void 0 ? "%" : locale3.percent + "", minus = locale3.minus === void 0 ? "\u2212" : locale3.minus + "", nan = locale3.nan === void 0 ? "NaN" : locale3.nan + "";
  function newFormat(specifier) {
    specifier = formatSpecifier(specifier);
    var fill = specifier.fill, align = specifier.align, sign2 = specifier.sign, symbol = specifier.symbol, zero2 = specifier.zero, width = specifier.width, comma = specifier.comma, precision = specifier.precision, trim = specifier.trim, type = specifier.type;
    if (type === "n") comma = true, type = "g";
    else if (!formatTypes_default[type]) precision === void 0 && (precision = 12), trim = true, type = "g";
    if (zero2 || fill === "0" && align === "=") zero2 = true, fill = "0", align = "=";
    var prefix = symbol === "$" ? currencyPrefix : symbol === "#" && /[boxX]/.test(type) ? "0" + type.toLowerCase() : "", suffix = symbol === "$" ? currencySuffix : /[%p]/.test(type) ? percent : "";
    var formatType = formatTypes_default[type], maybeSuffix = /[defgprs%]/.test(type);
    precision = precision === void 0 ? 6 : /[gprs]/.test(type) ? Math.max(1, Math.min(21, precision)) : Math.max(0, Math.min(20, precision));
    function format2(value) {
      var valuePrefix = prefix, valueSuffix = suffix, i, n, c;
      if (type === "c") {
        valueSuffix = formatType(value) + valueSuffix;
        value = "";
      } else {
        value = +value;
        var valueNegative = value < 0 || 1 / value < 0;
        value = isNaN(value) ? nan : formatType(Math.abs(value), precision);
        if (trim) value = formatTrim_default(value);
        if (valueNegative && +value === 0 && sign2 !== "+") valueNegative = false;
        valuePrefix = (valueNegative ? sign2 === "(" ? sign2 : minus : sign2 === "-" || sign2 === "(" ? "" : sign2) + valuePrefix;
        valueSuffix = (type === "s" ? prefixes[8 + prefixExponent / 3] : "") + valueSuffix + (valueNegative && sign2 === "(" ? ")" : "");
        if (maybeSuffix) {
          i = -1, n = value.length;
          while (++i < n) {
            if (c = value.charCodeAt(i), 48 > c || c > 57) {
              valueSuffix = (c === 46 ? decimal + value.slice(i + 1) : value.slice(i)) + valueSuffix;
              value = value.slice(0, i);
              break;
            }
          }
        }
      }
      if (comma && !zero2) value = group(value, Infinity);
      var length = valuePrefix.length + value.length + valueSuffix.length, padding = length < width ? new Array(width - length + 1).join(fill) : "";
      if (comma && zero2) value = group(padding + value, padding.length ? width - valueSuffix.length : Infinity), padding = "";
      switch (align) {
        case "<":
          value = valuePrefix + value + valueSuffix + padding;
          break;
        case "=":
          value = valuePrefix + padding + value + valueSuffix;
          break;
        case "^":
          value = padding.slice(0, length = padding.length >> 1) + valuePrefix + value + valueSuffix + padding.slice(length);
          break;
        default:
          value = padding + valuePrefix + value + valueSuffix;
          break;
      }
      return numerals(value);
    }
    format2.toString = function() {
      return specifier + "";
    };
    return format2;
  }
  function formatPrefix2(specifier, value) {
    var f = newFormat((specifier = formatSpecifier(specifier), specifier.type = "f", specifier)), e = Math.max(-8, Math.min(8, Math.floor(exponent_default(value) / 3))) * 3, k = Math.pow(10, -e), prefix = prefixes[8 + e / 3];
    return function(value2) {
      return f(k * value2) + prefix;
    };
  }
  return {
    format: newFormat,
    formatPrefix: formatPrefix2
  };
}

// node_modules/d3-format/src/defaultLocale.js
var locale;
var format;
var formatPrefix;
defaultLocale({
  thousands: ",",
  grouping: [3],
  currency: ["$", ""]
});
function defaultLocale(definition) {
  locale = locale_default(definition);
  format = locale.format;
  formatPrefix = locale.formatPrefix;
  return locale;
}

// node_modules/d3-format/src/precisionFixed.js
function precisionFixed_default(step) {
  return Math.max(0, -exponent_default(Math.abs(step)));
}

// node_modules/d3-format/src/precisionPrefix.js
function precisionPrefix_default(step, value) {
  return Math.max(0, Math.max(-8, Math.min(8, Math.floor(exponent_default(value) / 3))) * 3 - exponent_default(Math.abs(step)));
}

// node_modules/d3-format/src/precisionRound.js
function precisionRound_default(step, max2) {
  step = Math.abs(step), max2 = Math.abs(max2) - step;
  return Math.max(0, exponent_default(max2) - exponent_default(step)) + 1;
}

// node_modules/d3-scale/src/tickFormat.js
function tickFormat(start, stop, count, specifier) {
  var step = tickStep(start, stop, count), precision;
  specifier = formatSpecifier(specifier == null ? ",f" : specifier);
  switch (specifier.type) {
    case "s": {
      var value = Math.max(Math.abs(start), Math.abs(stop));
      if (specifier.precision == null && !isNaN(precision = precisionPrefix_default(step, value))) specifier.precision = precision;
      return formatPrefix(specifier, value);
    }
    case "":
    case "e":
    case "g":
    case "p":
    case "r": {
      if (specifier.precision == null && !isNaN(precision = precisionRound_default(step, Math.max(Math.abs(start), Math.abs(stop))))) specifier.precision = precision - (specifier.type === "e");
      break;
    }
    case "f":
    case "%": {
      if (specifier.precision == null && !isNaN(precision = precisionFixed_default(step))) specifier.precision = precision - (specifier.type === "%") * 2;
      break;
    }
  }
  return format(specifier);
}

// node_modules/d3-scale/src/linear.js
function linearish(scale) {
  var domain = scale.domain;
  scale.ticks = function(count) {
    var d = domain();
    return ticks_default(d[0], d[d.length - 1], count == null ? 10 : count);
  };
  scale.tickFormat = function(count, specifier) {
    var d = domain();
    return tickFormat(d[0], d[d.length - 1], count == null ? 10 : count, specifier);
  };
  scale.nice = function(count) {
    if (count == null) count = 10;
    var d = domain();
    var i0 = 0;
    var i1 = d.length - 1;
    var start = d[i0];
    var stop = d[i1];
    var prestep;
    var step;
    var maxIter = 10;
    if (stop < start) {
      step = start, start = stop, stop = step;
      step = i0, i0 = i1, i1 = step;
    }
    while (maxIter-- > 0) {
      step = tickIncrement(start, stop, count);
      if (step === prestep) {
        d[i0] = start;
        d[i1] = stop;
        return domain(d);
      } else if (step > 0) {
        start = Math.floor(start / step) * step;
        stop = Math.ceil(stop / step) * step;
      } else if (step < 0) {
        start = Math.ceil(start * step) / step;
        stop = Math.floor(stop * step) / step;
      } else {
        break;
      }
      prestep = step;
    }
    return scale;
  };
  return scale;
}
function linear2() {
  var scale = continuous();
  scale.copy = function() {
    return copy(scale, linear2());
  };
  initRange.apply(scale, arguments);
  return linearish(scale);
}

// node_modules/d3-scale/src/nice.js
function nice(domain, interval) {
  domain = domain.slice();
  var i0 = 0, i1 = domain.length - 1, x0 = domain[i0], x1 = domain[i1], t;
  if (x1 < x0) {
    t = i0, i0 = i1, i1 = t;
    t = x0, x0 = x1, x1 = t;
  }
  domain[i0] = interval.floor(x0);
  domain[i1] = interval.ceil(x1);
  return domain;
}

// node_modules/d3-time/src/interval.js
var t0 = /* @__PURE__ */ new Date();
var t1 = /* @__PURE__ */ new Date();
function newInterval(floori, offseti, count, field) {
  function interval(date2) {
    return floori(date2 = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+date2)), date2;
  }
  interval.floor = function(date2) {
    return floori(date2 = /* @__PURE__ */ new Date(+date2)), date2;
  };
  interval.ceil = function(date2) {
    return floori(date2 = new Date(date2 - 1)), offseti(date2, 1), floori(date2), date2;
  };
  interval.round = function(date2) {
    var d0 = interval(date2), d1 = interval.ceil(date2);
    return date2 - d0 < d1 - date2 ? d0 : d1;
  };
  interval.offset = function(date2, step) {
    return offseti(date2 = /* @__PURE__ */ new Date(+date2), step == null ? 1 : Math.floor(step)), date2;
  };
  interval.range = function(start, stop, step) {
    var range = [], previous;
    start = interval.ceil(start);
    step = step == null ? 1 : Math.floor(step);
    if (!(start < stop) || !(step > 0)) return range;
    do
      range.push(previous = /* @__PURE__ */ new Date(+start)), offseti(start, step), floori(start);
    while (previous < start && start < stop);
    return range;
  };
  interval.filter = function(test) {
    return newInterval(function(date2) {
      if (date2 >= date2) while (floori(date2), !test(date2)) date2.setTime(date2 - 1);
    }, function(date2, step) {
      if (date2 >= date2) {
        if (step < 0) while (++step <= 0) {
          while (offseti(date2, -1), !test(date2)) {
          }
        }
        else while (--step >= 0) {
          while (offseti(date2, 1), !test(date2)) {
          }
        }
      }
    });
  };
  if (count) {
    interval.count = function(start, end) {
      t0.setTime(+start), t1.setTime(+end);
      floori(t0), floori(t1);
      return Math.floor(count(t0, t1));
    };
    interval.every = function(step) {
      step = Math.floor(step);
      return !isFinite(step) || !(step > 0) ? null : !(step > 1) ? interval : interval.filter(field ? function(d) {
        return field(d) % step === 0;
      } : function(d) {
        return interval.count(0, d) % step === 0;
      });
    };
  }
  return interval;
}

// node_modules/d3-time/src/millisecond.js
var millisecond = newInterval(function() {
}, function(date2, step) {
  date2.setTime(+date2 + step);
}, function(start, end) {
  return end - start;
});
millisecond.every = function(k) {
  k = Math.floor(k);
  if (!isFinite(k) || !(k > 0)) return null;
  if (!(k > 1)) return millisecond;
  return newInterval(function(date2) {
    date2.setTime(Math.floor(date2 / k) * k);
  }, function(date2, step) {
    date2.setTime(+date2 + step * k);
  }, function(start, end) {
    return (end - start) / k;
  });
};
var millisecond_default = millisecond;
var milliseconds = millisecond.range;

// node_modules/d3-time/src/duration.js
var durationSecond = 1e3;
var durationMinute = durationSecond * 60;
var durationHour = durationMinute * 60;
var durationDay = durationHour * 24;
var durationWeek = durationDay * 7;
var durationMonth = durationDay * 30;
var durationYear = durationDay * 365;

// node_modules/d3-time/src/second.js
var second = newInterval(function(date2) {
  date2.setTime(date2 - date2.getMilliseconds());
}, function(date2, step) {
  date2.setTime(+date2 + step * durationSecond);
}, function(start, end) {
  return (end - start) / durationSecond;
}, function(date2) {
  return date2.getUTCSeconds();
});
var second_default = second;
var seconds = second.range;

// node_modules/d3-time/src/minute.js
var minute = newInterval(function(date2) {
  date2.setTime(date2 - date2.getMilliseconds() - date2.getSeconds() * durationSecond);
}, function(date2, step) {
  date2.setTime(+date2 + step * durationMinute);
}, function(start, end) {
  return (end - start) / durationMinute;
}, function(date2) {
  return date2.getMinutes();
});
var minute_default = minute;
var minutes = minute.range;

// node_modules/d3-time/src/hour.js
var hour = newInterval(function(date2) {
  date2.setTime(date2 - date2.getMilliseconds() - date2.getSeconds() * durationSecond - date2.getMinutes() * durationMinute);
}, function(date2, step) {
  date2.setTime(+date2 + step * durationHour);
}, function(start, end) {
  return (end - start) / durationHour;
}, function(date2) {
  return date2.getHours();
});
var hour_default = hour;
var hours = hour.range;

// node_modules/d3-time/src/day.js
var day = newInterval(
  (date2) => date2.setHours(0, 0, 0, 0),
  (date2, step) => date2.setDate(date2.getDate() + step),
  (start, end) => (end - start - (end.getTimezoneOffset() - start.getTimezoneOffset()) * durationMinute) / durationDay,
  (date2) => date2.getDate() - 1
);
var day_default = day;
var days = day.range;

// node_modules/d3-time/src/week.js
function weekday(i) {
  return newInterval(function(date2) {
    date2.setDate(date2.getDate() - (date2.getDay() + 7 - i) % 7);
    date2.setHours(0, 0, 0, 0);
  }, function(date2, step) {
    date2.setDate(date2.getDate() + step * 7);
  }, function(start, end) {
    return (end - start - (end.getTimezoneOffset() - start.getTimezoneOffset()) * durationMinute) / durationWeek;
  });
}
var sunday = weekday(0);
var monday = weekday(1);
var tuesday = weekday(2);
var wednesday = weekday(3);
var thursday = weekday(4);
var friday = weekday(5);
var saturday = weekday(6);
var sundays = sunday.range;
var mondays = monday.range;
var tuesdays = tuesday.range;
var wednesdays = wednesday.range;
var thursdays = thursday.range;
var fridays = friday.range;
var saturdays = saturday.range;

// node_modules/d3-time/src/month.js
var month = newInterval(function(date2) {
  date2.setDate(1);
  date2.setHours(0, 0, 0, 0);
}, function(date2, step) {
  date2.setMonth(date2.getMonth() + step);
}, function(start, end) {
  return end.getMonth() - start.getMonth() + (end.getFullYear() - start.getFullYear()) * 12;
}, function(date2) {
  return date2.getMonth();
});
var month_default = month;
var months = month.range;

// node_modules/d3-time/src/year.js
var year = newInterval(function(date2) {
  date2.setMonth(0, 1);
  date2.setHours(0, 0, 0, 0);
}, function(date2, step) {
  date2.setFullYear(date2.getFullYear() + step);
}, function(start, end) {
  return end.getFullYear() - start.getFullYear();
}, function(date2) {
  return date2.getFullYear();
});
year.every = function(k) {
  return !isFinite(k = Math.floor(k)) || !(k > 0) ? null : newInterval(function(date2) {
    date2.setFullYear(Math.floor(date2.getFullYear() / k) * k);
    date2.setMonth(0, 1);
    date2.setHours(0, 0, 0, 0);
  }, function(date2, step) {
    date2.setFullYear(date2.getFullYear() + step * k);
  });
};
var year_default = year;
var years = year.range;

// node_modules/d3-time/src/utcMinute.js
var utcMinute = newInterval(function(date2) {
  date2.setUTCSeconds(0, 0);
}, function(date2, step) {
  date2.setTime(+date2 + step * durationMinute);
}, function(start, end) {
  return (end - start) / durationMinute;
}, function(date2) {
  return date2.getUTCMinutes();
});
var utcMinute_default = utcMinute;
var utcMinutes = utcMinute.range;

// node_modules/d3-time/src/utcHour.js
var utcHour = newInterval(function(date2) {
  date2.setUTCMinutes(0, 0, 0);
}, function(date2, step) {
  date2.setTime(+date2 + step * durationHour);
}, function(start, end) {
  return (end - start) / durationHour;
}, function(date2) {
  return date2.getUTCHours();
});
var utcHour_default = utcHour;
var utcHours = utcHour.range;

// node_modules/d3-time/src/utcDay.js
var utcDay = newInterval(function(date2) {
  date2.setUTCHours(0, 0, 0, 0);
}, function(date2, step) {
  date2.setUTCDate(date2.getUTCDate() + step);
}, function(start, end) {
  return (end - start) / durationDay;
}, function(date2) {
  return date2.getUTCDate() - 1;
});
var utcDay_default = utcDay;
var utcDays = utcDay.range;

// node_modules/d3-time/src/utcWeek.js
function utcWeekday(i) {
  return newInterval(function(date2) {
    date2.setUTCDate(date2.getUTCDate() - (date2.getUTCDay() + 7 - i) % 7);
    date2.setUTCHours(0, 0, 0, 0);
  }, function(date2, step) {
    date2.setUTCDate(date2.getUTCDate() + step * 7);
  }, function(start, end) {
    return (end - start) / durationWeek;
  });
}
var utcSunday = utcWeekday(0);
var utcMonday = utcWeekday(1);
var utcTuesday = utcWeekday(2);
var utcWednesday = utcWeekday(3);
var utcThursday = utcWeekday(4);
var utcFriday = utcWeekday(5);
var utcSaturday = utcWeekday(6);
var utcSundays = utcSunday.range;
var utcMondays = utcMonday.range;
var utcTuesdays = utcTuesday.range;
var utcWednesdays = utcWednesday.range;
var utcThursdays = utcThursday.range;
var utcFridays = utcFriday.range;
var utcSaturdays = utcSaturday.range;

// node_modules/d3-time/src/utcMonth.js
var utcMonth = newInterval(function(date2) {
  date2.setUTCDate(1);
  date2.setUTCHours(0, 0, 0, 0);
}, function(date2, step) {
  date2.setUTCMonth(date2.getUTCMonth() + step);
}, function(start, end) {
  return end.getUTCMonth() - start.getUTCMonth() + (end.getUTCFullYear() - start.getUTCFullYear()) * 12;
}, function(date2) {
  return date2.getUTCMonth();
});
var utcMonth_default = utcMonth;
var utcMonths = utcMonth.range;

// node_modules/d3-time/src/utcYear.js
var utcYear = newInterval(function(date2) {
  date2.setUTCMonth(0, 1);
  date2.setUTCHours(0, 0, 0, 0);
}, function(date2, step) {
  date2.setUTCFullYear(date2.getUTCFullYear() + step);
}, function(start, end) {
  return end.getUTCFullYear() - start.getUTCFullYear();
}, function(date2) {
  return date2.getUTCFullYear();
});
utcYear.every = function(k) {
  return !isFinite(k = Math.floor(k)) || !(k > 0) ? null : newInterval(function(date2) {
    date2.setUTCFullYear(Math.floor(date2.getUTCFullYear() / k) * k);
    date2.setUTCMonth(0, 1);
    date2.setUTCHours(0, 0, 0, 0);
  }, function(date2, step) {
    date2.setUTCFullYear(date2.getUTCFullYear() + step * k);
  });
};
var utcYear_default = utcYear;
var utcYears = utcYear.range;

// node_modules/d3-time/src/ticks.js
function ticker(year2, month2, week, day2, hour2, minute2) {
  const tickIntervals = [
    [second_default, 1, durationSecond],
    [second_default, 5, 5 * durationSecond],
    [second_default, 15, 15 * durationSecond],
    [second_default, 30, 30 * durationSecond],
    [minute2, 1, durationMinute],
    [minute2, 5, 5 * durationMinute],
    [minute2, 15, 15 * durationMinute],
    [minute2, 30, 30 * durationMinute],
    [hour2, 1, durationHour],
    [hour2, 3, 3 * durationHour],
    [hour2, 6, 6 * durationHour],
    [hour2, 12, 12 * durationHour],
    [day2, 1, durationDay],
    [day2, 2, 2 * durationDay],
    [week, 1, durationWeek],
    [month2, 1, durationMonth],
    [month2, 3, 3 * durationMonth],
    [year2, 1, durationYear]
  ];
  function ticks(start, stop, count) {
    const reverse = stop < start;
    if (reverse) [start, stop] = [stop, start];
    const interval = count && typeof count.range === "function" ? count : tickInterval(start, stop, count);
    const ticks2 = interval ? interval.range(start, +stop + 1) : [];
    return reverse ? ticks2.reverse() : ticks2;
  }
  function tickInterval(start, stop, count) {
    const target = Math.abs(stop - start) / count;
    const i = bisector_default(([, , step2]) => step2).right(tickIntervals, target);
    if (i === tickIntervals.length) return year2.every(tickStep(start / durationYear, stop / durationYear, count));
    if (i === 0) return millisecond_default.every(Math.max(tickStep(start, stop, count), 1));
    const [t, step] = tickIntervals[target / tickIntervals[i - 1][2] < tickIntervals[i][2] / target ? i - 1 : i];
    return t.every(step);
  }
  return [ticks, tickInterval];
}
var [utcTicks, utcTickInterval] = ticker(utcYear_default, utcMonth_default, utcSunday, utcDay_default, utcHour_default, utcMinute_default);
var [timeTicks, timeTickInterval] = ticker(year_default, month_default, sunday, day_default, hour_default, minute_default);

// node_modules/d3-time-format/src/locale.js
function localDate(d) {
  if (0 <= d.y && d.y < 100) {
    var date2 = new Date(-1, d.m, d.d, d.H, d.M, d.S, d.L);
    date2.setFullYear(d.y);
    return date2;
  }
  return new Date(d.y, d.m, d.d, d.H, d.M, d.S, d.L);
}
function utcDate(d) {
  if (0 <= d.y && d.y < 100) {
    var date2 = new Date(Date.UTC(-1, d.m, d.d, d.H, d.M, d.S, d.L));
    date2.setUTCFullYear(d.y);
    return date2;
  }
  return new Date(Date.UTC(d.y, d.m, d.d, d.H, d.M, d.S, d.L));
}
function newDate(y2, m, d) {
  return { y: y2, m, d, H: 0, M: 0, S: 0, L: 0 };
}
function formatLocale(locale3) {
  var locale_dateTime = locale3.dateTime, locale_date = locale3.date, locale_time = locale3.time, locale_periods = locale3.periods, locale_weekdays = locale3.days, locale_shortWeekdays = locale3.shortDays, locale_months = locale3.months, locale_shortMonths = locale3.shortMonths;
  var periodRe = formatRe(locale_periods), periodLookup = formatLookup(locale_periods), weekdayRe = formatRe(locale_weekdays), weekdayLookup = formatLookup(locale_weekdays), shortWeekdayRe = formatRe(locale_shortWeekdays), shortWeekdayLookup = formatLookup(locale_shortWeekdays), monthRe = formatRe(locale_months), monthLookup = formatLookup(locale_months), shortMonthRe = formatRe(locale_shortMonths), shortMonthLookup = formatLookup(locale_shortMonths);
  var formats = {
    "a": formatShortWeekday,
    "A": formatWeekday,
    "b": formatShortMonth,
    "B": formatMonth,
    "c": null,
    "d": formatDayOfMonth,
    "e": formatDayOfMonth,
    "f": formatMicroseconds,
    "g": formatYearISO,
    "G": formatFullYearISO,
    "H": formatHour24,
    "I": formatHour12,
    "j": formatDayOfYear,
    "L": formatMilliseconds,
    "m": formatMonthNumber,
    "M": formatMinutes,
    "p": formatPeriod,
    "q": formatQuarter,
    "Q": formatUnixTimestamp,
    "s": formatUnixTimestampSeconds,
    "S": formatSeconds,
    "u": formatWeekdayNumberMonday,
    "U": formatWeekNumberSunday,
    "V": formatWeekNumberISO,
    "w": formatWeekdayNumberSunday,
    "W": formatWeekNumberMonday,
    "x": null,
    "X": null,
    "y": formatYear,
    "Y": formatFullYear,
    "Z": formatZone,
    "%": formatLiteralPercent
  };
  var utcFormats = {
    "a": formatUTCShortWeekday,
    "A": formatUTCWeekday,
    "b": formatUTCShortMonth,
    "B": formatUTCMonth,
    "c": null,
    "d": formatUTCDayOfMonth,
    "e": formatUTCDayOfMonth,
    "f": formatUTCMicroseconds,
    "g": formatUTCYearISO,
    "G": formatUTCFullYearISO,
    "H": formatUTCHour24,
    "I": formatUTCHour12,
    "j": formatUTCDayOfYear,
    "L": formatUTCMilliseconds,
    "m": formatUTCMonthNumber,
    "M": formatUTCMinutes,
    "p": formatUTCPeriod,
    "q": formatUTCQuarter,
    "Q": formatUnixTimestamp,
    "s": formatUnixTimestampSeconds,
    "S": formatUTCSeconds,
    "u": formatUTCWeekdayNumberMonday,
    "U": formatUTCWeekNumberSunday,
    "V": formatUTCWeekNumberISO,
    "w": formatUTCWeekdayNumberSunday,
    "W": formatUTCWeekNumberMonday,
    "x": null,
    "X": null,
    "y": formatUTCYear,
    "Y": formatUTCFullYear,
    "Z": formatUTCZone,
    "%": formatLiteralPercent
  };
  var parses = {
    "a": parseShortWeekday,
    "A": parseWeekday,
    "b": parseShortMonth,
    "B": parseMonth,
    "c": parseLocaleDateTime,
    "d": parseDayOfMonth,
    "e": parseDayOfMonth,
    "f": parseMicroseconds,
    "g": parseYear,
    "G": parseFullYear,
    "H": parseHour24,
    "I": parseHour24,
    "j": parseDayOfYear,
    "L": parseMilliseconds,
    "m": parseMonthNumber,
    "M": parseMinutes,
    "p": parsePeriod,
    "q": parseQuarter,
    "Q": parseUnixTimestamp,
    "s": parseUnixTimestampSeconds,
    "S": parseSeconds,
    "u": parseWeekdayNumberMonday,
    "U": parseWeekNumberSunday,
    "V": parseWeekNumberISO,
    "w": parseWeekdayNumberSunday,
    "W": parseWeekNumberMonday,
    "x": parseLocaleDate,
    "X": parseLocaleTime,
    "y": parseYear,
    "Y": parseFullYear,
    "Z": parseZone,
    "%": parseLiteralPercent
  };
  formats.x = newFormat(locale_date, formats);
  formats.X = newFormat(locale_time, formats);
  formats.c = newFormat(locale_dateTime, formats);
  utcFormats.x = newFormat(locale_date, utcFormats);
  utcFormats.X = newFormat(locale_time, utcFormats);
  utcFormats.c = newFormat(locale_dateTime, utcFormats);
  function newFormat(specifier, formats2) {
    return function(date2) {
      var string = [], i = -1, j = 0, n = specifier.length, c, pad2, format2;
      if (!(date2 instanceof Date)) date2 = /* @__PURE__ */ new Date(+date2);
      while (++i < n) {
        if (specifier.charCodeAt(i) === 37) {
          string.push(specifier.slice(j, i));
          if ((pad2 = pads[c = specifier.charAt(++i)]) != null) c = specifier.charAt(++i);
          else pad2 = c === "e" ? " " : "0";
          if (format2 = formats2[c]) c = format2(date2, pad2);
          string.push(c);
          j = i + 1;
        }
      }
      string.push(specifier.slice(j, i));
      return string.join("");
    };
  }
  function newParse(specifier, Z) {
    return function(string) {
      var d = newDate(1900, void 0, 1), i = parseSpecifier(d, specifier, string += "", 0), week, day2;
      if (i != string.length) return null;
      if ("Q" in d) return new Date(d.Q);
      if ("s" in d) return new Date(d.s * 1e3 + ("L" in d ? d.L : 0));
      if (Z && !("Z" in d)) d.Z = 0;
      if ("p" in d) d.H = d.H % 12 + d.p * 12;
      if (d.m === void 0) d.m = "q" in d ? d.q : 0;
      if ("V" in d) {
        if (d.V < 1 || d.V > 53) return null;
        if (!("w" in d)) d.w = 1;
        if ("Z" in d) {
          week = utcDate(newDate(d.y, 0, 1)), day2 = week.getUTCDay();
          week = day2 > 4 || day2 === 0 ? utcMonday.ceil(week) : utcMonday(week);
          week = utcDay_default.offset(week, (d.V - 1) * 7);
          d.y = week.getUTCFullYear();
          d.m = week.getUTCMonth();
          d.d = week.getUTCDate() + (d.w + 6) % 7;
        } else {
          week = localDate(newDate(d.y, 0, 1)), day2 = week.getDay();
          week = day2 > 4 || day2 === 0 ? monday.ceil(week) : monday(week);
          week = day_default.offset(week, (d.V - 1) * 7);
          d.y = week.getFullYear();
          d.m = week.getMonth();
          d.d = week.getDate() + (d.w + 6) % 7;
        }
      } else if ("W" in d || "U" in d) {
        if (!("w" in d)) d.w = "u" in d ? d.u % 7 : "W" in d ? 1 : 0;
        day2 = "Z" in d ? utcDate(newDate(d.y, 0, 1)).getUTCDay() : localDate(newDate(d.y, 0, 1)).getDay();
        d.m = 0;
        d.d = "W" in d ? (d.w + 6) % 7 + d.W * 7 - (day2 + 5) % 7 : d.w + d.U * 7 - (day2 + 6) % 7;
      }
      if ("Z" in d) {
        d.H += d.Z / 100 | 0;
        d.M += d.Z % 100;
        return utcDate(d);
      }
      return localDate(d);
    };
  }
  function parseSpecifier(d, specifier, string, j) {
    var i = 0, n = specifier.length, m = string.length, c, parse;
    while (i < n) {
      if (j >= m) return -1;
      c = specifier.charCodeAt(i++);
      if (c === 37) {
        c = specifier.charAt(i++);
        parse = parses[c in pads ? specifier.charAt(i++) : c];
        if (!parse || (j = parse(d, string, j)) < 0) return -1;
      } else if (c != string.charCodeAt(j++)) {
        return -1;
      }
    }
    return j;
  }
  function parsePeriod(d, string, i) {
    var n = periodRe.exec(string.slice(i));
    return n ? (d.p = periodLookup.get(n[0].toLowerCase()), i + n[0].length) : -1;
  }
  function parseShortWeekday(d, string, i) {
    var n = shortWeekdayRe.exec(string.slice(i));
    return n ? (d.w = shortWeekdayLookup.get(n[0].toLowerCase()), i + n[0].length) : -1;
  }
  function parseWeekday(d, string, i) {
    var n = weekdayRe.exec(string.slice(i));
    return n ? (d.w = weekdayLookup.get(n[0].toLowerCase()), i + n[0].length) : -1;
  }
  function parseShortMonth(d, string, i) {
    var n = shortMonthRe.exec(string.slice(i));
    return n ? (d.m = shortMonthLookup.get(n[0].toLowerCase()), i + n[0].length) : -1;
  }
  function parseMonth(d, string, i) {
    var n = monthRe.exec(string.slice(i));
    return n ? (d.m = monthLookup.get(n[0].toLowerCase()), i + n[0].length) : -1;
  }
  function parseLocaleDateTime(d, string, i) {
    return parseSpecifier(d, locale_dateTime, string, i);
  }
  function parseLocaleDate(d, string, i) {
    return parseSpecifier(d, locale_date, string, i);
  }
  function parseLocaleTime(d, string, i) {
    return parseSpecifier(d, locale_time, string, i);
  }
  function formatShortWeekday(d) {
    return locale_shortWeekdays[d.getDay()];
  }
  function formatWeekday(d) {
    return locale_weekdays[d.getDay()];
  }
  function formatShortMonth(d) {
    return locale_shortMonths[d.getMonth()];
  }
  function formatMonth(d) {
    return locale_months[d.getMonth()];
  }
  function formatPeriod(d) {
    return locale_periods[+(d.getHours() >= 12)];
  }
  function formatQuarter(d) {
    return 1 + ~~(d.getMonth() / 3);
  }
  function formatUTCShortWeekday(d) {
    return locale_shortWeekdays[d.getUTCDay()];
  }
  function formatUTCWeekday(d) {
    return locale_weekdays[d.getUTCDay()];
  }
  function formatUTCShortMonth(d) {
    return locale_shortMonths[d.getUTCMonth()];
  }
  function formatUTCMonth(d) {
    return locale_months[d.getUTCMonth()];
  }
  function formatUTCPeriod(d) {
    return locale_periods[+(d.getUTCHours() >= 12)];
  }
  function formatUTCQuarter(d) {
    return 1 + ~~(d.getUTCMonth() / 3);
  }
  return {
    format: function(specifier) {
      var f = newFormat(specifier += "", formats);
      f.toString = function() {
        return specifier;
      };
      return f;
    },
    parse: function(specifier) {
      var p = newParse(specifier += "", false);
      p.toString = function() {
        return specifier;
      };
      return p;
    },
    utcFormat: function(specifier) {
      var f = newFormat(specifier += "", utcFormats);
      f.toString = function() {
        return specifier;
      };
      return f;
    },
    utcParse: function(specifier) {
      var p = newParse(specifier += "", true);
      p.toString = function() {
        return specifier;
      };
      return p;
    }
  };
}
var pads = { "-": "", "_": " ", "0": "0" };
var numberRe = /^\s*\d+/;
var percentRe = /^%/;
var requoteRe = /[\\^$*+?|[\]().{}]/g;
function pad(value, fill, width) {
  var sign2 = value < 0 ? "-" : "", string = (sign2 ? -value : value) + "", length = string.length;
  return sign2 + (length < width ? new Array(width - length + 1).join(fill) + string : string);
}
function requote(s) {
  return s.replace(requoteRe, "\\$&");
}
function formatRe(names) {
  return new RegExp("^(?:" + names.map(requote).join("|") + ")", "i");
}
function formatLookup(names) {
  return new Map(names.map((name, i) => [name.toLowerCase(), i]));
}
function parseWeekdayNumberSunday(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 1));
  return n ? (d.w = +n[0], i + n[0].length) : -1;
}
function parseWeekdayNumberMonday(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 1));
  return n ? (d.u = +n[0], i + n[0].length) : -1;
}
function parseWeekNumberSunday(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.U = +n[0], i + n[0].length) : -1;
}
function parseWeekNumberISO(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.V = +n[0], i + n[0].length) : -1;
}
function parseWeekNumberMonday(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.W = +n[0], i + n[0].length) : -1;
}
function parseFullYear(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 4));
  return n ? (d.y = +n[0], i + n[0].length) : -1;
}
function parseYear(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.y = +n[0] + (+n[0] > 68 ? 1900 : 2e3), i + n[0].length) : -1;
}
function parseZone(d, string, i) {
  var n = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(string.slice(i, i + 6));
  return n ? (d.Z = n[1] ? 0 : -(n[2] + (n[3] || "00")), i + n[0].length) : -1;
}
function parseQuarter(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 1));
  return n ? (d.q = n[0] * 3 - 3, i + n[0].length) : -1;
}
function parseMonthNumber(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.m = n[0] - 1, i + n[0].length) : -1;
}
function parseDayOfMonth(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.d = +n[0], i + n[0].length) : -1;
}
function parseDayOfYear(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 3));
  return n ? (d.m = 0, d.d = +n[0], i + n[0].length) : -1;
}
function parseHour24(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.H = +n[0], i + n[0].length) : -1;
}
function parseMinutes(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.M = +n[0], i + n[0].length) : -1;
}
function parseSeconds(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 2));
  return n ? (d.S = +n[0], i + n[0].length) : -1;
}
function parseMilliseconds(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 3));
  return n ? (d.L = +n[0], i + n[0].length) : -1;
}
function parseMicroseconds(d, string, i) {
  var n = numberRe.exec(string.slice(i, i + 6));
  return n ? (d.L = Math.floor(n[0] / 1e3), i + n[0].length) : -1;
}
function parseLiteralPercent(d, string, i) {
  var n = percentRe.exec(string.slice(i, i + 1));
  return n ? i + n[0].length : -1;
}
function parseUnixTimestamp(d, string, i) {
  var n = numberRe.exec(string.slice(i));
  return n ? (d.Q = +n[0], i + n[0].length) : -1;
}
function parseUnixTimestampSeconds(d, string, i) {
  var n = numberRe.exec(string.slice(i));
  return n ? (d.s = +n[0], i + n[0].length) : -1;
}
function formatDayOfMonth(d, p) {
  return pad(d.getDate(), p, 2);
}
function formatHour24(d, p) {
  return pad(d.getHours(), p, 2);
}
function formatHour12(d, p) {
  return pad(d.getHours() % 12 || 12, p, 2);
}
function formatDayOfYear(d, p) {
  return pad(1 + day_default.count(year_default(d), d), p, 3);
}
function formatMilliseconds(d, p) {
  return pad(d.getMilliseconds(), p, 3);
}
function formatMicroseconds(d, p) {
  return formatMilliseconds(d, p) + "000";
}
function formatMonthNumber(d, p) {
  return pad(d.getMonth() + 1, p, 2);
}
function formatMinutes(d, p) {
  return pad(d.getMinutes(), p, 2);
}
function formatSeconds(d, p) {
  return pad(d.getSeconds(), p, 2);
}
function formatWeekdayNumberMonday(d) {
  var day2 = d.getDay();
  return day2 === 0 ? 7 : day2;
}
function formatWeekNumberSunday(d, p) {
  return pad(sunday.count(year_default(d) - 1, d), p, 2);
}
function dISO(d) {
  var day2 = d.getDay();
  return day2 >= 4 || day2 === 0 ? thursday(d) : thursday.ceil(d);
}
function formatWeekNumberISO(d, p) {
  d = dISO(d);
  return pad(thursday.count(year_default(d), d) + (year_default(d).getDay() === 4), p, 2);
}
function formatWeekdayNumberSunday(d) {
  return d.getDay();
}
function formatWeekNumberMonday(d, p) {
  return pad(monday.count(year_default(d) - 1, d), p, 2);
}
function formatYear(d, p) {
  return pad(d.getFullYear() % 100, p, 2);
}
function formatYearISO(d, p) {
  d = dISO(d);
  return pad(d.getFullYear() % 100, p, 2);
}
function formatFullYear(d, p) {
  return pad(d.getFullYear() % 1e4, p, 4);
}
function formatFullYearISO(d, p) {
  var day2 = d.getDay();
  d = day2 >= 4 || day2 === 0 ? thursday(d) : thursday.ceil(d);
  return pad(d.getFullYear() % 1e4, p, 4);
}
function formatZone(d) {
  var z = d.getTimezoneOffset();
  return (z > 0 ? "-" : (z *= -1, "+")) + pad(z / 60 | 0, "0", 2) + pad(z % 60, "0", 2);
}
function formatUTCDayOfMonth(d, p) {
  return pad(d.getUTCDate(), p, 2);
}
function formatUTCHour24(d, p) {
  return pad(d.getUTCHours(), p, 2);
}
function formatUTCHour12(d, p) {
  return pad(d.getUTCHours() % 12 || 12, p, 2);
}
function formatUTCDayOfYear(d, p) {
  return pad(1 + utcDay_default.count(utcYear_default(d), d), p, 3);
}
function formatUTCMilliseconds(d, p) {
  return pad(d.getUTCMilliseconds(), p, 3);
}
function formatUTCMicroseconds(d, p) {
  return formatUTCMilliseconds(d, p) + "000";
}
function formatUTCMonthNumber(d, p) {
  return pad(d.getUTCMonth() + 1, p, 2);
}
function formatUTCMinutes(d, p) {
  return pad(d.getUTCMinutes(), p, 2);
}
function formatUTCSeconds(d, p) {
  return pad(d.getUTCSeconds(), p, 2);
}
function formatUTCWeekdayNumberMonday(d) {
  var dow = d.getUTCDay();
  return dow === 0 ? 7 : dow;
}
function formatUTCWeekNumberSunday(d, p) {
  return pad(utcSunday.count(utcYear_default(d) - 1, d), p, 2);
}
function UTCdISO(d) {
  var day2 = d.getUTCDay();
  return day2 >= 4 || day2 === 0 ? utcThursday(d) : utcThursday.ceil(d);
}
function formatUTCWeekNumberISO(d, p) {
  d = UTCdISO(d);
  return pad(utcThursday.count(utcYear_default(d), d) + (utcYear_default(d).getUTCDay() === 4), p, 2);
}
function formatUTCWeekdayNumberSunday(d) {
  return d.getUTCDay();
}
function formatUTCWeekNumberMonday(d, p) {
  return pad(utcMonday.count(utcYear_default(d) - 1, d), p, 2);
}
function formatUTCYear(d, p) {
  return pad(d.getUTCFullYear() % 100, p, 2);
}
function formatUTCYearISO(d, p) {
  d = UTCdISO(d);
  return pad(d.getUTCFullYear() % 100, p, 2);
}
function formatUTCFullYear(d, p) {
  return pad(d.getUTCFullYear() % 1e4, p, 4);
}
function formatUTCFullYearISO(d, p) {
  var day2 = d.getUTCDay();
  d = day2 >= 4 || day2 === 0 ? utcThursday(d) : utcThursday.ceil(d);
  return pad(d.getUTCFullYear() % 1e4, p, 4);
}
function formatUTCZone() {
  return "+0000";
}
function formatLiteralPercent() {
  return "%";
}
function formatUnixTimestamp(d) {
  return +d;
}
function formatUnixTimestampSeconds(d) {
  return Math.floor(+d / 1e3);
}

// node_modules/d3-time-format/src/defaultLocale.js
var locale2;
var timeFormat;
var timeParse;
var utcFormat;
var utcParse;
defaultLocale2({
  dateTime: "%x, %X",
  date: "%-m/%-d/%Y",
  time: "%-I:%M:%S %p",
  periods: ["AM", "PM"],
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
function defaultLocale2(definition) {
  locale2 = formatLocale(definition);
  timeFormat = locale2.format;
  timeParse = locale2.parse;
  utcFormat = locale2.utcFormat;
  utcParse = locale2.utcParse;
  return locale2;
}

// node_modules/d3-scale/src/time.js
function date(t) {
  return new Date(t);
}
function number2(t) {
  return t instanceof Date ? +t : +/* @__PURE__ */ new Date(+t);
}
function calendar(ticks, tickInterval, year2, month2, week, day2, hour2, minute2, second2, format2) {
  var scale = continuous(), invert = scale.invert, domain = scale.domain;
  var formatMillisecond = format2(".%L"), formatSecond = format2(":%S"), formatMinute = format2("%I:%M"), formatHour = format2("%I %p"), formatDay = format2("%a %d"), formatWeek = format2("%b %d"), formatMonth = format2("%B"), formatYear2 = format2("%Y");
  function tickFormat2(date2) {
    return (second2(date2) < date2 ? formatMillisecond : minute2(date2) < date2 ? formatSecond : hour2(date2) < date2 ? formatMinute : day2(date2) < date2 ? formatHour : month2(date2) < date2 ? week(date2) < date2 ? formatDay : formatWeek : year2(date2) < date2 ? formatMonth : formatYear2)(date2);
  }
  scale.invert = function(y2) {
    return new Date(invert(y2));
  };
  scale.domain = function(_) {
    return arguments.length ? domain(Array.from(_, number2)) : domain().map(date);
  };
  scale.ticks = function(interval) {
    var d = domain();
    return ticks(d[0], d[d.length - 1], interval == null ? 10 : interval);
  };
  scale.tickFormat = function(count, specifier) {
    return specifier == null ? tickFormat2 : format2(specifier);
  };
  scale.nice = function(interval) {
    var d = domain();
    if (!interval || typeof interval.range !== "function") interval = tickInterval(d[0], d[d.length - 1], interval == null ? 10 : interval);
    return interval ? domain(nice(d, interval)) : scale;
  };
  scale.copy = function() {
    return copy(scale, calendar(ticks, tickInterval, year2, month2, week, day2, hour2, minute2, second2, format2));
  };
  return scale;
}
function time() {
  return initRange.apply(calendar(timeTicks, timeTickInterval, year_default, month_default, sunday, day_default, hour_default, minute_default, second_default, timeFormat).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}

// node_modules/d3-axis/src/array.js
var slice = Array.prototype.slice;

// node_modules/d3-axis/src/identity.js
function identity_default2(x2) {
  return x2;
}

// node_modules/d3-axis/src/axis.js
var top = 1;
var right = 2;
var bottom = 3;
var left = 4;
var epsilon = 1e-6;
function translateX(x2) {
  return "translate(" + (x2 + 0.5) + ",0)";
}
function translateY(y2) {
  return "translate(0," + (y2 + 0.5) + ")";
}
function number3(scale) {
  return function(d) {
    return +scale(d);
  };
}
function center(scale) {
  var offset = Math.max(0, scale.bandwidth() - 1) / 2;
  if (scale.round()) offset = Math.round(offset);
  return function(d) {
    return +scale(d) + offset;
  };
}
function entering() {
  return !this.__axis;
}
function axis(orient, scale) {
  var tickArguments = [], tickValues = null, tickFormat2 = null, tickSizeInner = 6, tickSizeOuter = 6, tickPadding = 3, k = orient === top || orient === left ? -1 : 1, x2 = orient === left || orient === right ? "x" : "y", transform = orient === top || orient === bottom ? translateX : translateY;
  function axis2(context) {
    var values = tickValues == null ? scale.ticks ? scale.ticks.apply(scale, tickArguments) : scale.domain() : tickValues, format2 = tickFormat2 == null ? scale.tickFormat ? scale.tickFormat.apply(scale, tickArguments) : identity_default2 : tickFormat2, spacing = Math.max(tickSizeInner, 0) + tickPadding, range = scale.range(), range0 = +range[0] + 0.5, range1 = +range[range.length - 1] + 0.5, position = (scale.bandwidth ? center : number3)(scale.copy()), selection2 = context.selection ? context.selection() : context, path2 = selection2.selectAll(".domain").data([null]), tick = selection2.selectAll(".tick").data(values, scale).order(), tickExit = tick.exit(), tickEnter = tick.enter().append("g").attr("class", "tick"), line = tick.select("line"), text = tick.select("text");
    path2 = path2.merge(path2.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor"));
    tick = tick.merge(tickEnter);
    line = line.merge(tickEnter.append("line").attr("stroke", "currentColor").attr(x2 + "2", k * tickSizeInner));
    text = text.merge(tickEnter.append("text").attr("fill", "currentColor").attr(x2, k * spacing).attr("dy", orient === top ? "0em" : orient === bottom ? "0.71em" : "0.32em"));
    if (context !== selection2) {
      path2 = path2.transition(context);
      tick = tick.transition(context);
      line = line.transition(context);
      text = text.transition(context);
      tickExit = tickExit.transition(context).attr("opacity", epsilon).attr("transform", function(d) {
        return isFinite(d = position(d)) ? transform(d) : this.getAttribute("transform");
      });
      tickEnter.attr("opacity", epsilon).attr("transform", function(d) {
        var p = this.parentNode.__axis;
        return transform(p && isFinite(p = p(d)) ? p : position(d));
      });
    }
    tickExit.remove();
    path2.attr("d", orient === left || orient == right ? tickSizeOuter ? "M" + k * tickSizeOuter + "," + range0 + "H0.5V" + range1 + "H" + k * tickSizeOuter : "M0.5," + range0 + "V" + range1 : tickSizeOuter ? "M" + range0 + "," + k * tickSizeOuter + "V0.5H" + range1 + "V" + k * tickSizeOuter : "M" + range0 + ",0.5H" + range1);
    tick.attr("opacity", 1).attr("transform", function(d) {
      return transform(position(d));
    });
    line.attr(x2 + "2", k * tickSizeInner);
    text.attr(x2, k * spacing).text(format2);
    selection2.filter(entering).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", orient === right ? "start" : orient === left ? "end" : "middle");
    selection2.each(function() {
      this.__axis = position;
    });
  }
  axis2.scale = function(_) {
    return arguments.length ? (scale = _, axis2) : scale;
  };
  axis2.ticks = function() {
    return tickArguments = slice.call(arguments), axis2;
  };
  axis2.tickArguments = function(_) {
    return arguments.length ? (tickArguments = _ == null ? [] : slice.call(_), axis2) : tickArguments.slice();
  };
  axis2.tickValues = function(_) {
    return arguments.length ? (tickValues = _ == null ? null : slice.call(_), axis2) : tickValues && tickValues.slice();
  };
  axis2.tickFormat = function(_) {
    return arguments.length ? (tickFormat2 = _, axis2) : tickFormat2;
  };
  axis2.tickSize = function(_) {
    return arguments.length ? (tickSizeInner = tickSizeOuter = +_, axis2) : tickSizeInner;
  };
  axis2.tickSizeInner = function(_) {
    return arguments.length ? (tickSizeInner = +_, axis2) : tickSizeInner;
  };
  axis2.tickSizeOuter = function(_) {
    return arguments.length ? (tickSizeOuter = +_, axis2) : tickSizeOuter;
  };
  axis2.tickPadding = function(_) {
    return arguments.length ? (tickPadding = +_, axis2) : tickPadding;
  };
  return axis2;
}
function axisBottom(scale) {
  return axis(bottom, scale);
}
function axisLeft(scale) {
  return axis(left, scale);
}

// src/config.js
var config = {
  positionType: {
    upLeft: 1,
    upRight: 2,
    downLeft: 3,
    downRight: 4
  },
  // Font families
  fontFamily: "xkcd",
  fallbackFontFamily: "Arial, sans-serif",
  // SVG filter IDs
  filterUrl: "url(#xkcdify)",
  filterUrlPie: "url(#xkcdify-pie)",
  // SVG defaults
  svgStrokeWidth: 3,
  aspectRatio: 2 / 3,
  // Margins for charts with axes
  margin: {
    top: 50,
    right: 30,
    bottom: 50,
    left: 50
  },
  marginTopWithTitle: 60,
  marginLeftWithYLabel: 70,
  // Margin for charts without axes (Pie, Radar)
  marginScalar: 50,
  // Axis and label font sizes
  tickFontSize: 16,
  titleFontSize: 20,
  labelFontSize: 17,
  tooltipFontSize: 15,
  // Dot sizes (multiplied by dotSize option)
  dotInitRadius: 3.5,
  dotHoverRadius: 6,
  // Bar chart
  barCornerRadius: 2,
  barStrokeWidth: 3,
  bandPadding: 0.4,
  // Pie chart
  pieStrokeWidth: 2,
  // Tooltip/legend shared
  tooltipMouseOffset: 10,
  scatterMouseOffset: 5,
  swatchSize: 8,
  swatchCornerRadius: 2,
  itemRowHeight: 20,
  itemTextOffset: 12,
  itemXOffset: 15,
  backgroundCornerRadius: 5,
  backgroundStrokeWidth: 2,
  tooltipBackgroundOpacity: 0.9,
  legendBackgroundOpacity: 0.85,
  // Default tick counts
  defaultTickCount: 3,
  // Radar chart
  radarAreaOpacity: 0.2,
  // Selection box
  boxSelectMinDrag: 4
};
var config_default = config;

// src/utils/addAxis.js
function styleAxisParts(parent, { fontFamily, unxkcdify, stroke }) {
  parent.selectAll(".domain").attr("filter", !unxkcdify ? config_default.filterUrl : null).style("stroke", stroke);
  parent.selectAll(".tick > text").style("font-family", fontFamily).style("font-size", config_default.tickFontSize).style("fill", stroke);
}
var yAxis = (parent, {
  yScale,
  tickCount,
  fontFamily,
  unxkcdify,
  stroke
}) => {
  parent.append("g").call(
    axisLeft(yScale).tickSize(1).tickPadding(10).ticks(tickCount, "s")
  );
  styleAxisParts(parent, { fontFamily, unxkcdify, stroke });
};
var xAxis = (parent, {
  xScale,
  tickCount,
  moveDown,
  fontFamily,
  unxkcdify,
  stroke
}) => {
  parent.append("g").attr("transform", `translate(0,${moveDown})`).call(
    axisBottom(xScale).tickSize(0).tickPadding(6).ticks(tickCount)
  );
  styleAxisParts(parent, { fontFamily, unxkcdify, stroke });
};
var addAxis_default = {
  xAxis,
  yAxis
};

// src/components/Tooltip.js
function tooltipPositionType(tipX, tipY, width, height) {
  if (tipX > width / 2 && tipY < height / 2) {
    return config_default.positionType.downLeft;
  } else if (tipX > width / 2 && tipY > height / 2) {
    return config_default.positionType.upLeft;
  } else if (tipX < width / 2 && tipY > height / 2) {
    return config_default.positionType.upRight;
  }
  return config_default.positionType.downRight;
}
var Tooltip = class {
  constructor({
    parent,
    title: title2,
    items,
    position,
    unxkcdify,
    backgroundColor,
    strokeColor
  }) {
    this.title = title2;
    this.items = items;
    this.position = position;
    this.filter = !unxkcdify ? config_default.filterUrl : null;
    this.backgroundColor = backgroundColor;
    this.strokeColor = strokeColor;
    this.svg = parent.append("svg").attr("x", this._getUpLeftX()).attr("y", this._getUpLeftY()).style("visibility", "hidden");
    this.tipBackground = this.svg.append("rect").style("fill", this.backgroundColor).attr("fill-opacity", config_default.tooltipBackgroundOpacity).attr("stroke", strokeColor).attr("stroke-width", config_default.backgroundStrokeWidth).attr("rx", config_default.backgroundCornerRadius).attr("ry", config_default.backgroundCornerRadius).attr("filter", this.filter).attr("width", this._getBackgroundWidth()).attr("height", this._getBackgroundHeight()).attr("x", 5).attr("y", 5);
    this.tipTitle = this.svg.append("text").style("font-size", config_default.tooltipFontSize).style("font-weight", "bold").style("fill", this.strokeColor).attr("x", config_default.itemXOffset).attr("y", 25).text(title2);
    this.tipItems = items.map((item, i) => this._generateTipItem(item, i));
  }
  show() {
    this.svg.style("visibility", "visible");
  }
  hide() {
    this.svg.style("visibility", "hidden");
  }
  update({ title: title2, items, position }) {
    if (title2 && title2 !== this.title) {
      this.title = title2;
      this.tipTitle.text(title2);
    }
    if (items && JSON.stringify(items) !== JSON.stringify(this.items)) {
      this.items = items;
      this.tipItems.forEach((g) => g.svg.remove());
      this.tipItems = this.items.map((item, i) => this._generateTipItem(item, i));
      const maxWidth = Math.max(
        ...this.tipItems.map((item) => item.width),
        this.tipTitle.node().getBBox().width
      );
      this.tipBackground.attr("width", maxWidth + config_default.itemXOffset).attr("height", this._getBackgroundHeight());
    }
    if (position) {
      this.position = position;
      this.svg.attr("x", this._getUpLeftX());
      this.svg.attr("y", this._getUpLeftY());
    }
  }
  _generateTipItem(item, i) {
    const svg = this.svg.append("svg");
    const itemY = 37 + config_default.itemRowHeight * i;
    svg.append("rect").style("fill", item.color).attr("width", config_default.swatchSize).attr("height", config_default.swatchSize).attr("rx", config_default.swatchCornerRadius).attr("ry", config_default.swatchCornerRadius).attr("filter", this.filter).attr("x", config_default.itemXOffset).attr("y", itemY);
    svg.append("text").style("font-size", config_default.tooltipFontSize).style("fill", this.strokeColor).attr("x", config_default.itemXOffset + config_default.itemTextOffset).attr("y", itemY + config_default.swatchSize).text(item.text);
    const bbox = svg.node().getBBox();
    return {
      svg,
      width: bbox.width + config_default.itemXOffset,
      height: bbox.height + 10
    };
  }
  _getBackgroundWidth() {
    const maxItemLength = this.items.reduce(
      (pre, cur) => pre > cur.text.length ? pre : cur.text.length,
      0
    );
    const maxLength = Math.max(maxItemLength, this.title.length);
    return maxLength * 7.4 + 25;
  }
  _getBackgroundHeight() {
    const rows = this.items.length + 1;
    return rows * config_default.itemRowHeight + 10;
  }
  _getUpLeftX() {
    if (this.position.type === config_default.positionType.upRight || this.position.type === config_default.positionType.downRight) {
      return this.position.x;
    }
    return this.position.x - this._getBackgroundWidth() - config_default.itemRowHeight;
  }
  _getUpLeftY() {
    if (this.position.type === config_default.positionType.downLeft || this.position.type === config_default.positionType.downRight) {
      return this.position.y;
    }
    return this.position.y - this._getBackgroundHeight() - config_default.itemRowHeight;
  }
};
var Tooltip_default = Tooltip;

// src/utils/fontData.js
var fontData_default = "data:font/ttf;base64,AAEAAAANAIAAAwBQRkZUTT5QrlAAAM4AAAAAHEdERUYAKQCTAADN4AAAAB5PUy8yVi7ftQAAAVgAAABWY21hcL4SoukAAAPkAAADKmdhc3D//wADAADN2AAAAAhnbHlmXxu1YwAACCwAAMD8aGVhZMzxKp4AAADcAAAANmhoZWEITQRIAAABFAAAACRobXR4B2AJegAAAbAAAAI0bG9jYW3dnyQAAAcQAAABHG1heHAA3wKgAAABOAAAACBuYW1lbi7owQAAySgAAALBcG9zdIi9we4AAMvsAAAB6QABAAAAAQAAyGnjNl8PPPUACwNYAAAAALSS9AAAAAAAtJL0AAAF/vIEpwNXAAAACAACAAAAAAAAAAEAAANX/vIATQTIAAAAAASnAAEAAAAAAAAAAAAAAAAAAACNAAEAAACNAp0AEAAAAAAAAgAAAAEAAQAAAEAAAAAAAAAAAQFvAZAABQAAAiwCVwAAAHcCLAJXAAABmgAqAN0AAAMABQMAAAAAAACAAACHAgAAQAAAAAAAAAAAUGZFZAAAACD//wJY/wAATQNXAQ4AAAABAAAAAAAAAawAAAAAAAABHQAAAQAAAAC6AA4BBgATAhMAEwHKABQCLAAIAfoABwCUABMBIAATARcAFAICABQB9wARANkAFAHiAAsArwATAZMADQHjABQAlgATAcwAEwHfAAUBwQATAgoAEgHMABQBuQARAaUAEwG8AAYArQAQAOAAEAGOABQCFwAUAY4AEgGsABQCGAAUAcQAEQGvABMB1AATAfQAFAHaABMB7QARAeIAEwGwABMAnAATAicAEgHVABIBwQANAgUAEwHGABMB6QATAcsADQJCAA0BvgAUAdMAEAHlABQBxgARAaoAFAJtABMB1gAUAgkAEAH9ABMBRgARAZMAEAFcABEBpwAUAf8AEwGlABABcAAPAYEACwGsABABsAAKAc8AEwH6ABMBZgASAOMACwFmABQBuwATAKsAEQI/ABQBcgATAZMAFAG5ABAB2AATAbUAFAF+AA0BcwARAaMACgGUABMB0gAUAf8AEgG2ABQBnwAUAR4AEwCcABMBLwASAlAAFACWABQB/gATAhYAFAHbABEB9QASAdgAEQIAABQBTgAUAmoAEwJqABAB4QAUAhMAEwItABUBSAASAv8AEwM9AA8BwQATA5gAEwMIABQDCgARBMgAEQOFABMDjAAUAyoAEwN6ABMDXAAUA0sAEgMEABQDVwATAxYADwNbABMC7gATAj0AEAIjABMCUQAUApsAEwIqABQB2QAMAewAEgIaABICKQATAqsAEgDMABQAygATAAAABQAAAAMAAAAsAAAABAAAAPQAAQAAAAACJAADAAEAAAAsAAMACgAAAPQABADIAAAALAAgAAQADABfAH4ApgCxAMUAyQDSANwA9wESAVADoyAZIB0gPSIaIisiSCJgImUia///AAAAIABhAKYAsQDFAMkA0gDcAPcBEgFQA6MgGCAcID0iGiIrIkgiYCJkImr////j/+L/u/+x/57/m/+T/4r/cP9a/x383wAAAADgLt5n3ljePN4l3iLd/wABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFgAAAAAAAAAAAAAAAAAAAAAAjACLAG4AaAAMAAAAAAEwAAAAAAAAABgAAAAgAAAAXwAAAAMAAABhAAAAfgAAAEMAAACmAAAApgAAAGEAAACxAAAAsQAAAGIAAADFAAAAxQAAAGMAAADJAAAAyQAAAGQAAADSAAAA0gAAAGUAAADcAAAA3AAAAGYAAAD3AAAA9wAAAGcAAAESAAABEgAAAGwAAAFQAAABUAAAAG0AAAOjAAADowAAAIIAACAYAAAgGAAAAIwAACAZAAAgGQAAAIsAACAcAAAgHAAAAG4AACAdAAAgHQAAAGgAACA9AAAgPQAAAGsAACIaAAAiGgAAAIEAACIrAAAiKwAAAIMAACJIAAAiSAAAAIQAACJgAAAiYAAAAIUAACJkAAAiZQAAAIYAACJqAAAiawAAAGkAAfOCAAHzggAAAIoAAAEGAAABAAAAAAAAAAECAAAAAgAAAAAAAAAAAAAAAAAAAAEAAAMEBQYHCAkKCwwNDg8QERITFBUWFxgZGhscHR4fICEiIyQlJicoKSorLC0uLzAxMjM0NTY3ODk6Ozw9Pj9AQUIAQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaW1xdXl9gAABjAGQAAGYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIUAAABihocAAAAAAACDAAAAAAAAAACBAIQAAAAAAAAAAAAAAABuaIyLZwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFoAvgHWAz4EIAToBSQFjgX6BtAHQgeAB7AH4ghwCRwJSgosCwALigxWDPANbg5ADuwPOg/CECwQphESEcwSyBNWFEIU2hWKFj4WwheeGCYYXBj+GZgZ9BqyGzYb1Bx4HUweHB7GHyYfuCBUISQhviIuIs4jUCP0JGIkziUCJZomOibCJ0wn1ihyKVQp1ipGKyArvCwYLL4tPC3ILnIvQC+iMDwwyDFGMbYyWjL+M7A0djVGNXw2MDaiNw43wDjEOYY6SDsGO5A8RD0EPcY+ij9mQGRBLkIgQzBD3kVORnxIAknGSyJL7E0qTqpQOlE0UehTIFQoVW5WSlbUV+ZYnFlYWfZaklsoW8ZcZGAMYD5gfgACAA7/zwCUAk8AHQA7AAATNhcWFx4BFRwCFRQHBhUUBwYmJyY3NicuAScmNhIyFjIXFhcWDgEHBiMiBwYjIicmIyInJjc2NzYyF0oUBwsICgMMBRAHIAQHAgMEAgQBBgk2BBMCCAkEAQUQARIFAgcFEA8HCAIJCQkNDBUQFgECSAcEBhkhHUkkTEkKFwcCAwgCAQ8FCmKrCAUpAxkP/hkZCAkaCA0SARUFBAUGHB4bFhAMBAACABMByADhAsYAHgBAAAATNhceAQcOAQcGBwYdAQYHBi8BJjc2Jy4BNjc+Awc2MzIXHgEUFxYHFA4BFQYHDgQjBicuATc+ATc0NzahHAkEFwIBAQECAgsNECEKBgkLCAIBAwECAQMDCnEGFhcFBgQBAwMBAgEFAgUHBA4DEgUNBgIBAwEFAgK8CgkEPQIBCwECDVUdEgoDBQsGC1o9CQUIBQYEDwMHCAYFBgsTBw0gCBohCS0HAwQDAQIDAwgZJhMzFBAmCAAAAAIAE//LAfQCMgCtAMUAACQiBiMiBw4BFxYHDgEHBicmJyY3ND4BNTQjIg4BFRQGFRQHBgcGBwYjIicmNTQnJjQ3Njc2NQciBiYnJicmNzY3PgE3PgE3PgEjIgcOAQcGJyY3NDc+ATMyNzYzMjU0NzY3PgI3PgE3NjU0Njc2MzIXFhcUFgcOARUGFjc2PwI+ATc2PwEXHgEHBgczMjc2HwEyFhUUFxYHDgEmBw4BFzY3NjMyFhceAQcOAQcnNDY3NiMiDgEjDwEOAQcUDgEVBjMwNzYBlw4UBggCAwQCBAQCFwEGEhANAwEBAQEBGxgHBwMLBAICDxAFCggHAgYDBA0EKhoIDAMBBgoWCRIQGggCAwoEDzcHEgYODAkBAgMqBwQQJQYFDA0CAQMDAQIIAgQJAwIUEwQGAQQEAQMBAwcDGRgGBAgDDwwIERYFCgcCCwgaIgICAgUECxgMMh0EAQwBCAoUHRoOBQMBAwUNF50NAQEEAQgOBhkDAQcBAQEBAw8okQQCBGQCBA0EDQEFAgEWBTEKHA4BAwQFAgReBQ0dDwMCAgMDBwMCCAcSAggyMAIBBQIFBxUMBwsFAggCBAMHDVgLAgEDCBIMCgsCAxwECgIBAgEEAhwhBgozCRYDBA0BAQUHMAUwCAohAwoDAwECAiAVGAs4CAUFBhxAJxACAwoFCgQCChUMBwQCAgFVAQEBAgQLBiYFCQUBQANTAwgBAgEXCycMAwcFAQIDBgAABQAU/78BpwJgALgAygDVAO0A/wAAEzYXFhcWFRczMhYzMj4BPwE+Ajc+ARceAQcGFjMyHgEzMhcWDgEvARcWBwYzMjM2MzYXFhcWFxYHBgcGFRQGBwYHBiMiBwYXFgcGFAYnLgInJjU0LgEiBisBFQYHBicmJzQnJi8CLgEnJicmJy4CND4BNzQ+BTc2FRQXFhcWFxY3PgE3Njc2NCYiIwYmIyImNCcmJyYnLgE3NjU0PgE1PgE3PgE3NjM3JjI3PgEzMjc2FzQ+AScmKwEVFAYVBzc2NTQ2BzciBwYHBhcWMzIXLgEHBhUUBwYXFTc+ATc2JzQmNCY9ATQHNDY1JyIHDgEHBgcXOgE+ASa1BAkIBQQBCgQKAQICAQEBAQECAQUHCgwEAgEECAkwBAMFBgIQEygSAQMHAQMBBwUEFh4UEBsGBgYHEQUhCggNJgIBBAQBAQMCAwgGAgwCCAIIBg8FFwMLBAoMAQMCAQENEisGAgQBCgMCAgEBAQECAgUCCQIWDAMGDBALAQIBAQMFAQEDAwIXAQIVAgIBDwUDAgICAwQBFgYDBwYBAgUCBgUFGwQFAQI2AgEBAgkIBQIJCQZHBQUMCQEBBAYGBK8JCgscAgMCDAwgBQwDAQF6AQEEBQgDBQgEEgcJBAECAloGAQEICBoaAQgJAQICBAYDDwcCAw4bDAYJBBIGJAUGAwodFAMBAgwJEh4nNSctHAcCBCUIBgcRBAMZGAUEEQkBAQ4RBBICBQYCARMsEAUBCgQJAwIjIwkMLhAEBQEcCQgHBQQIBQMFBAICAQIBCAsIDwMMFhILBQUdBA45CQkFAQoOAgIDAREUDDoBAgQDDQ0CCCUGAwwDAQUCBAMKFSGVBA0GAgEKCyUOHAUEBAwmHjgbFBUWBw0pCwUBAwo6CAVqDAYGIBIlNwMHBgQCAQGQDT8LKgIDDS5hFgECAwQAAAAABQAI//0CCAH6ACcANwBkAIgAmAAAEzYXMh4FFx4BFxYVFBcWBwYHBgcOAScmNz4BNzY3PgE3PgEyFyYjIgcGIgYHBhcWFxY2NyUyFgcUBhUUBiIPAQ4CBw4BBwYHBicuATU0Nz4BNzY3Njc2NzYzMjYzNhcWBzIWMzIXFhceARcWBxUGFQYHBgcOASYnLgE1NCY1Jjc+ATc2FzQnJicmBwYHBhcWNzY3NnESGwYLCgcKBAsBAwEDBQUPGAcaGyEHIQhNDgITBAIDBBYGBA0GQA0HFQ0FDgUEAwEBBgs7BQEVCQsBAQcGDF8COzUGBzUHHw0EEg8GMh47CAcGBDFfAQMHAhIBDg4EOwMWAgMEAw0KJgUiBAECGRYcEyovEQgSAQYDBi0hB0E/CgEBAwYDAwcECRkUGQHzBwECAwMGAggBAgUDBQEDCh83ESAjEgQHAhF0DTMDAgYHFAIBBUwLDQQJEA0YHAMGRRk0GgsBBwIFDQ5fAj45CAk+CSkCAQsKBwgSQyhFBQQKBjFfBw8NBAgD4w0GBgIBDwUcDQQEAyMZGRUPEQMQBxkEAQUBIRQtSgMBbAYKAgEBBAwWHgkEAwkTGwADAAf/8AHXAjsAWABtAIMAABMyFx4BFxYHFAcGBwYPARcWHwE3Njc2NzYfAhYGBwYXHgEXFjIeARcWBw4BIyInJi8BBgcGBwYiNTQnJicmJyY3NjU0Njc+ATc+AScmJyY3Njc+ATMyNzYXJiMiBiMOARceARcWNzY3NjU0JyYTLgEvAQcOARcWFxYXFjc2NzY/AScmlwobJk4DAgUCBCQECgoMDDISAwsBCQIGFg4DAwYGAgsFFgUFAgsKAQkHAikFDg0IEA07Rw8DAi8NEBk3EBceAh4HAQwDCAEHEQ4WBAQIBRcCBAUOPAwBAg0ECwsEBCMMBQwXCwUREjcKLAkUCiQVCQcJDh8MEB4gGgMGEhICOwMGRCslCAEGGTAEDAoKCSsPCBgBCQMIBwQKETQNBgoFEQYFDg8BCw4FGRILDgtTEgMDAgIBBAQPID5aOQQBBCAEAQcCBQYHER8yLiIOChwECkwCAwEhFRQ4BQMLFxYJDxYQEv7TCCgHEAYTLTIkCRAJAwMGIBoFCRESAAAAAQATAcYAbwLFACQAABM2FxYXHgEGFRQXFgYHIgYiBw4BJy4BJzQmNSY3NC4BNSY3PgEzIAgEBgUBAwMEBgUCBQQCAxwHBQ8BBAEBAQICBAgHAsAFBgMnJRYeGi4EBQ4CBwQGBAMCEQUCBwEDfgQLEAQWBg4GAAAAAQAT/5oA/AKHAEQAABcUBiMiJyYnJicmJy4FNiY2Jjc2NzY3NjQ3PgE3PgE3NjU0Njc2NzYWHwEHDgEHBgcOAQcGBwYXFhcWFxYXFgcG6BcKCQ0lGB4VFQUBBQIEAQQBAwECAQICDAcCBAEIAgstCgQVBwUUFxMNCgMDDAIEBgotEBUGJygIBgwgEScRDgZPBhELHiIrMjUSBBMFEgQSBhUJGgc3DkMHAgYIAhIGHE4JBAMCHAcHCgwHFxQJBgsEBgMFQCArE4J1GBAkMRsgDRQIAAABABT/mgDxAoAARQAAEzYzMhYXFjMyFxYXHgEXFhcWFxYGBwYXFgYHBhUUBwYHDgMHBicmNTc+ATc+ATc2Nz4BNDUmJyYnJicmNCYnJicmNzYoBAgGKAMCAwEFARASKAYSBxACBQQGAgECEAMBGxkwBQgFEBINCRIHAxgEAhADNw8CCAQFAQ0MFAgvDAoDAwUHAn0DDAMCCQIVFkARLRw9DBt2EAgCA0IDAQQKMyw3Bg0EBgQDCA8LHAsRBgMUA0BeCy4MIUcLATEoIQ0INwwKBgURFgAAAAABABQAAAHcAgwAlAAAEzYzMhYXHgEHBhcWHwE2NzY3NhYXFgcUDgEHBhcyHgEzFjcWNh4CFxYHBiMiFRQGLwEWFx4DBhQGBw4BDwEiBwYnIicuAScHBgcUDgQHBicuAjY3NiYHDgI1NAcGJy4BNTQ3NjU0MzI/ASMiJyY1NDc2NzY3NCcmJyYnJjc+ARceARcWFxY2JzQnJjc24ggBBCEDBQkBAQICBQITGBULDw8NEQYIDgUzAwELEgkiDQgHCQIGAQUBBAsELxsTKQoEBgICAwUBAgcDAwMDCBAKIAcTBgIGAQEBAQIDAwQVGA8GBAQCBQMCHhwIFhYQBwUFAQIlJSFbCAwLFV4cAQsuDRADAQoLDQwGHgoVDgMBAQIBBAMCBgYHAgIhCAYJBkIPFxoXBQcHEhkMAQgPBTQIAQICAwEDCwMPAg0GFwIEBAICMQcDBQcCCAIKAQQLBAQCBQIkCBUIDVkUBhAGCQQFAwQBAgcaYRMFAwUCHRoBAwoWEAoKCQoIBwIDJyYGCBcTBgsHAgECCScUFhAICgsBCQUUCRIIAgIGBC4oFxMAAAEAEQAuAdEB4wBJAAAkFAYVBwYjBwYHBicuAicmNzY/AQcOAQciJyY3Njc2NzY3PgEzMjc2JicmNz4BNzYXFhcWHQEWFx4BFxYHBicmJyYGBwYVBgcUARkOAwIDAwECCg4ECQUDBAICAgEjG0caEAcMBwQVBRIPAQI+Hh8BAQECAgUGBwshBwgGAxxRLAgFAwMJO1QMAwIBAgEFSAIJAQEBAQEBCRAEBQUGCQcKQ0cBAQwBDxgNCQsDBAMBAwcBAlgMDwwOBwIGBwgvIRspBQMCCCANBhYDAgQBBQoQL1EFAQAAAAEAFP9WALQAXwAlAAA3NhcWFxYHDgEHBg8BDgEHIgcGJicmNTQ2JyY2MjY3NicmNzY3NowJCAgGCQYDHAoCAgICJgQNDAIQBBAGAQIOCh8HCwMCBAUCDV0CBwgVHyoVPA0CBAMGJwEFAggFEQgDDgMFESsSGigaCAcDBgABAAsA3QG7AUEAGwAAEz4BFhcWFxYHBgcOASMGByIHBiYnJjc2NTQ3NvoPeigGBwIBDAcbEWECM14bGB8WCA0iCz9mATwCAwIGCBsXCQYBAQMDAwMFCRYgDQQCBQICAAABABP/4gCPAHEAHgAANz4BFxYyFhUUFxYHBg8BBicuAScmNzQ+AjU0Nz4BMhENEQoICgUNDBMMCg0VEAoGBQIBAQEEAwZfDwMMCAoDBAgXFiUCBggHBQsSDwUBBAMDAQUQCwgAAQAN/7wBbwJNAGAAADcPAQYPATIGBwYHDgEHBicmIicmNzY/AjY/AiY3PgE3NjU0Nz4BNzY1ND4BNzY3PgE3NiM2Nz4BNzYXFjMeARcWBg8BBhQGDwIGDwIGFRQGFRQHBhUUBhUUBgcUBqIRCAgJCAEDAggCARIGCg0OBgUMFAcEHAQEBAUOAQcFEAYGBwUQBgcQEgECBwQCBREEFAEBDQEFKA0DAwoBBR8JFRIIBAMEBAUECAcMBxMNDAEPWyMQEREQBQQRCgQNAgMHBwULLhIGOAgJCQghAQ8KMAwOAQMODC4KDAMCIyUBBgsGCAcXHwIBGgUgEAUBCgQMRQglIgIPCAgICQkJEBACAR4CBA4rBQMcAgMcAwEfAAACABQACQG9AlUAUgByAAAlIgYjIgcGIyInJicuAScuATU0JyY1NDc2NTQ2NzY3NjQ2MzI3Njc2HgEzMhYVFhcWFxYXFhcWFx4BFxYXHgEHFRYHBgcGBwYVFAYHBgcGBwYHBgImJyYGBwYHBgcGBwYXFhceARcWNzY/ATU0Jy4BJyYnASoCHAIGBwkdHgodGQslAwIVBBcNAh4JGQgJGQIECQwJCCEEBgUYBgQGGB8IBAgVEQcWAgICBhEBAgICCwoFAxYDEg0NFBADAmMMAgMUBAoSBwQKCQcLBQsKIxA+NCURBxkIDg4dKxsMAwMECg8HJQcFJAQBCjM4RioIBgpUECsICwQZBggCAgEEDAICBAYGBwgFBAwWCSkICgILYg8QBx4fIR4KBgMCIwMWDg8LCAMCAc8MBAQWBg8rFQYWPTo0HBQTJQUTMCI3FylYPRURCBABAAAAAAEAEwASAHACOwAYAAATNhYXHgEHBgcGBwYmJyYnJjc2EzYnJjc2PhcNAwoBAwQFBgsEKAYFBAUCAgYCAgQGBAI3BAYOODSq5AsNAgEGAwIICRETAQY1L2UJCAAAAQAT/+ABqAJfAJoAABMyPgE3MhQyFhcWFx4BBxYXFgcGFxYHBgcGBwYHBhQHBgcGDwEUBw4BBwYHDgEPATc2MzIXMhcWNhYzMhUUFxYGFRQHBic0LgEjJgYnJiMiBwYHIgYjBwYjIicmJyYnLgE1NCciNj8BNDY3PgE3Njc2Nz4BNzYyNjc2JyYnJjc2JicmJyYGByIGDwE0BwYnJicmJyY3PgE3Njc25gQaFgQBCCMBAwcNJAIEBBIFAQIHAwIBAwIHCAMEBwILCwYbAiYJEAYJTQsKCgYKCH01CQYKBgQPDQcKEBEBExcBBTcEChNoBwkTBAoDAwIKAgMBDQsGBQoCAQUDA0AWBx0JICcPBQMiBAMCFQQSCQEGAgEBCgQJHw4xDQEiBUMDBAYDEA8DAwUFDhUeLS4CWwIBAQQJAQMDBhwGBwklBQEFEyogAQMMIQgDBAYHBBINCAQbAikIDggLTQoJAgEDAwICAgYDDQEgAg0ICAMCAwIBAwICAgMCAQEBAwIEAwcFGQcFAgwHBgJBFQceCCAqEAMBKAYFJQkuJAUSBwECDwIGBAIKBxAFPQIDBAQDCAgHCA4PERUeFRYAAAABAAX/6AG6AlkAjwAAJTQ2NTQmJyYnJgcOAiYnLgE3Njc+ATc2NzY0Njc2IyIjBiMGBwYmIyImJyY3Njc2NzY3NjU2HgEzFhcWFx4BBwYVFAYUBwYHDgEHFxQeARceARcWFxYXFhcWFx4BBwYVFg8BMg4BBw4BByIHDgIHBicuAScmJy4DJyY/ARcWFx4BFxYfATc2Nz4BNzYBYAYHAwYuKBoHEwcLBw8FBAIPBBAHCgcGGwQDBQIJCQc7IgoaBxYNBAUFBhY1IUZLCgEGDgMWCwIECQUGAw0NCzUJEwEMGh4DAhgCBAgLDA0DAQEGCQMCAh8CAQwQBAYdAwIEBRooBCM2LR8ODA0FCAIFBBcyEQkHAwUfBQsqGBsrEQggBwmeBSEHDzQFCxAOAwEDAQUGDg8SChUGFAsPBwYEJQQDAQIEAgQIERUHCgQNAQMIAgEBAQEBCgICBCIKBAUDCwQGBUQMGQEEAQcIAwEKAgQDBQ4OCwQDEj8EAhNGJQMSFwUHGAEEBAcFAQcRDg8ODBYICwQKCjsKAwQDBQ85BQsPCAECCAUnDxQAAQAT/+0BmQJRAF8AABMyHgMcARUUBwYHBgcOARUUMjY3Njc2OwE3NjQnNC4CNjM1Njc2FhcWFxYHDgEVBhcUFh8BBgcGIyInJicmNTQnJj0BNCcmBgcGIgcOAQcGJyY3PgE3Njc2NzY3Nl8KDgoFAgQCAgEMAwwJDQUhJjctEgICAQICAQIDDQ4XDAUDCAcBAQUKCAcCBQYLGw4ECgoCAgQIAQIxCjMIAgMzDjscDgEBDgIJBQICAg8FAlEBBwMPBhkFIAMCCxEvDEMFAQIBCQsPDxBjDwIQDw8KBAIDBAIJByIgFAt7C5tIAjUNKQkECQoJDxIKDAwYcUwJAQICAw4CAg0CCiwXIBk1Dj4MAxUmEQUAAQAS//EB5QJnAIoAAAE2Fx4DFxYGBwYHBgciBw4BBxYXNjc2FhceARcWMxcWFxYVFDMyFxYGBwYXFgYPARQOARUUBw4BJyYnLgEnJiMiJy4BNTQnLgI1NCcmNzY3PgEzMhYVFB4BFxYXFjIXFhcWNzY/ATY3PgE3Njc2JyYnJgcGBw4BJyYjIicmNzY3Nj8BNhcWMzYBtA8JBQUGBAEEDgsRXCY8JRUGAgEBAgUqEzIKAw4DBQEKGAwRAQMHBQQGCQICGgkGIwgeGFkgFgYDEgIBBAIKCR0EAgQEAwUJAwMCBgoNCAIGAg4PCgYJDBYYFCsSAwMBBxgECwUGAQMRHjgiCAYqBAMECAsKAgUBAgkcGAUCCdMCYgUFAgwEFAIHFwUHCwQCBwIMIiABCAcEBAUBBAEDBhASGAkDIRFyDhUCBDgMCAIhBAIFDw4HCggDAQYDAggHHgIBBAIOBAQHCRAcCA8KBQYKBwcIAx0RDAYIBgcCBRIDAgEGIgoZHCEgNhQjFQ4JBwgFAxUVOoMJFQUCAQMCDQAAAgAU/+EBpQJlAFMAZgAAEzYXHgEVFBYVFAcOAQcGIyIHBgcOAwcOARQzNjc2NzYXFjMyFhcWFx4BFRQHDgEHBhUUDwEiBw4BJyYnLgEnJicmNDc2NzY3Njc2NzYzMjU+ARMmBwYHBgcGFhcWFxY3Njc2JyboCCUFEAUEARgCBgcNJy0VBA0GCAQBAgEHCS0wSzMSBQMcAQIFBg4BAhQKAyURAg0iVCopCxQmBw8CAgEHCgUCBR8iIx4HAgEkaCJQGSIvAgEQBwsYNzkgEwoBAQJiAwcBDAQCBwIKFgYEAQQiJzcKIRAhGAgQCwIEFAsRGgocBAQGBiQKGAsSMQoDAwodDQgUCRAVCBA6GTYMDz0LOiAQCx80OyAaAgIW/l0pFwcNEQcDKg0TECQhEyETGRIAAAABABH/0wGTAlMAVAAAEzIVFDIVFx4BBwYjIgYVFAcGBwYHDgEHDgEHDgEHBgcGIgcGJyYnJjc2NzY1PgE3Njc2PwE+AzU3NDY3NiYjIicmBwYjIgYjBiYnJjc2NzY3NhSo0wYIBwMBAQIBDQIKIBoSAwcEAhADBhYDChQEAgQJGBsDBAsJEAYBEgIBEwEVDAEDAgEBJAQGBCsoJiARDA0JEAsWCwUFDgcaBzUJAk8GAgIGBQcNFxYBAwIKQDczCBAPCDYQG1kRLy0GBAwNDwgLFxJFHAYITAUDRwQ8HAIGAwMBAQJIBwkEAgEDAwMBChkXCwYFAgcCBAAAAAADABP/7AF/AloAWwB2AIsAABMyNjc2FxYXFhceARUfARYXFhcWFxYXFgcOAwcGBwYUFx4BFRQXFhcWFxYGBw4BBwYHDgEHDgEHBiYvASInLgE0Jy4BNz4BPwE2Nz4BPwEnJicmNz4CNz4BFyYjIgcOAQcGFx4BMzI2NzYnLgE1NCcmMRQmByYiBwYPARceARcWNzY3NicuAScmuQULBxcRHQcCAwIUDAcBAgQBBggDAQEHAwUECAQLDBARCiQEEAcCAgIFBAIWAwYGByAJBQ0KNWceCAMHBhUDBAIDAQ4CCgoHBykMBwoSFzopCRYMEwkqOwgJEgwRJwQGFAY5BAIjCBMCAxIDAwQNDgcPTQwEBgcXID0eFg0IBgMQFgoCVAQBAQUJCQMCAR8DBwgCAwcBBiMRCxIWCgoECAUOCQwCDQgkAgEGFyoLBQMqCwgxAwYJCRwEAggDEAgXBgcGKAoCBDYWBiYCFBcKDCoJBgYKGDxJEBkKDwcUVAkGCScNDxQGIxcHDxAfCg4IAQEBBOsLCjJVGQ4TDAIDGBIfEiITGRMJAAACAAb/6AGWAmwAXgBxAAATNhcyHgEXHgEXHgEXFjMyFx4BHwIeAxQWFBUWBwYUBhUGBwYHDgEHBgcGBwYVFAYHBi8BLgEnNzY3Njc+ATc2NzY1Nw4BByIGByMGJicmJyY3ND4BNzY3Nj8BNhcmBw4BBw4BFxY3Njc2Nz4BJybJIwMBBgkEDCMFAQ4BAQICFAoOAQEMAgYCAwIBBgUGAw8FGAUTBhsFDAMCCwUIGBkBBgIIBgMGAgEQARMHCQwRQQ0CBQICAy0JNRcaGQMDARExGBIMFDwPEB03DQYDBgkcJDMsFwoDAhYCZwUBAgIBAhAFAQcDAxYMDg4NBgEDAQICBAQFCwwKBgsDFR4JUBFDFVkZMAUCBQYPAgMICAMOAxkVCQwUDjEDTgoPDysKGAIBAQICAg4uOjYBBQgDKi4VBwYMTAMFCTMeDScMDgEBGhYbDQYFPAAAAAIAEAA2AIcB6gAXADEAABM2FjM2FhUUMzIXFgcGBwYiBgcGLwEmNhE2FxYXFhceAQcGBwYHBiIVFCMiJyY3PgEyPAMgAwkOAgMDBgMGDQ8KDQINFRIFHxMbGAEBBQUCBAcOBwICBhMEExwCAQwGAeUFBQEJBQMHDBEbDQ8GAQQPDghJ/rkUCQkEAgUEGgoSCAQEBQIGCAokBxoAAAIAEP9MALkB0AAkAFoAABMHMgcGDwEGJyYnJiIuAScmNjI2NzY1NDY3NhcWMzIXFhUUBwYDNjMyFxYfARYHBhUGBwYHDgEHDgMVDgEVFAcGIicuAicmNz4BPwE+ATc+ATc2NzQ3PgGtDgMKAgMHDh4MBgMGAgICAQQCBAUGHAUJDQQFDgoOBwU0EAUQBAIBBgkHAwcFAQQEGQUBAwICAQcWBRcGAgwHAggHAgIBAQEBAQMSCxcBBQQKAXITBgECBQ4JAwwIDxIDAhIKBwgBAhUCAgcDChEbCgoI/ucECwQCGSoIBgIqBQEMCzUHAgQDAwEDBgECDwQEAQYHBRMHAgkBAQIEAgkIGC82IgkHBgAAAQAU/+MBaQIsAEEAAAE2FhcWFxYGBwYjIgYHFBceARceARceARcWFxYXFgcOAQcGJyYnLgEnJicuAScmJyYnJjc2NzY3Njc2NzYzMjc+AQEqDAwPEAMFE0ltBwIdAQ0IQQYVFwwKFA4SBAYDCxAKBggSFA4CBAgOJg8HKQgNMSgDAQIDEgQHDBMpPBcEAQYPOAIlBwIPEAYKGEptFwIDCwdDBhMfDQsYDhIGCQMMGA0GAgURDgQJAhArFAklDBQrJQ4DDxQIAgcMDR48GQYTOQAAAAACABQAqQHvAcoAIgBSAAABMjc2FxYXFgcGJyYGBwYjDgEHDgEnJiMiLwE9ATQ+ATc+ARc+Ah4BFx4BFBUGFRYGBwYHBicmIyIHBiMiJjU0IyImNzI1ND4BNzYzMjU+ARcWAUggNyoMBgIFBwwMBQofJCF4HCEgRwMGAgUICBgfAg+nlwUaDhQLAwEFAgEMEBgMKU8uDCJsLAsPCgECBwICDRUCBgYEAr0mQQG4CggMBhEeCA0DAgYFBgIBBQQDAwMIBxIUBwgEAQULtAEEAgEGBwQFAggKCQ4LAgMDCgcECgQKAQMmAQIEBwcBAwIHCgUHAAAAAQAS/+MBZwIsAEUAABM+ARceARcWMzIXFhcWFxYXHgUXFAcGBwYHDgEHBgcOAQcGBwYnLgEnJjc2Nz4DNzY3PgE3NjUuASMiJy4BNzYqDwwMBzgPBgEEFzwpEwwHBAUGBAMBAwEBAygxDQgpBw8mDggEAg4UEggGChALAwYCKgInAgYdBkEIDQEdAghsSRMFAwIbDwIHBDkTBhk8Hg0MBwICBQMIAw0DBQQOJSsUDCYIFCsQAgkEDhEFAgUOGAwDCQQqBCwEDBoGQwcLAwIXbUoYCgYAAAAAAgAU/+MBhwJkAGIAfAAAEz4BFzIeATMeARceARUUFxYXFgcOAQcGBw4BBwYHBgcGFx4CBwYHBicuAScuAScmJzQ3Njc2Nz4BNz4CJyInJicmBwYHBgcGBwYVFAcGJyYnNzY3Njc2NTQ2Nz4DNzYTNjMWFxYdAQcGBwYjIicuBScmNz4BmwRMEgooCAEFHwEEDwQKBQQIBRUGAgICIwwxKgoEBQIBEAEDAxcWBQUNAgEHAQ4BCwY0NxYLHgUCBAEBAgIEHRssJyAVCAUJAgYFDxkLBAMEDRIIIggEBAIFBBYSBgkOIgoTFAkKCwIWBAoDBQEBAQIOBhYCVAQMAQoIARMBARMDAQQKHh0gDy4HAgQFJgopFAUEBAoFJw8QBggIAgEOBQUNBS8UEhUMHyIUCiwMBRMOAQoRCgkKCSAVEgwJAgIBBgUBAhEbGgcZFAgBAhoEAgUCAwEH/gkCASYMCgoWFgMDFAQJAwUEBgUHFQkYAAAAAgAUAA4B9QIuAJgArQAAEzI2MzI0NzYWFxYzMhYVFBcWBwYXFhcUFxY+ATc2JyYnLgEnJgcGBw4BBwYXHgI3Njc2FxYzMhQXFgcGBwYHBgcGJyYnJicmJyYjIiY0JyYnJjU0Nz4BNz4BNzY3NhcWFzIWFx4BFxYXFjMyFhUWBg8BDgcmBiMiJyYnLgEnJiMmDgEHBicmJy4DJyY1NDc2FyYHDgEHBgcGFxY3Njc2NzY3Njc22QEUAQIYCzMJBgECEQcHAQIDDAIDAQgJAhEaCAcHIAYsKyAXGDoOEAkFIiwyPUkeCQUBAgUJCQICAiNOUS8KAggRGxISBwECEQIEDAYNBzodBigGMzYgFSMHAQoCBiQLEQwCAgEJDQwSAwIDBwQHBQQDAhwQGwYDAwcQAQIBARUgCigICxEHBwMFAgQdHF8LFQ0ICwoEBAIBCBgRCAUEAgMFBwGHDgQJBAUGBA8CAQkIDBMDDTgNAwEHDgYpQxQLCiEDFwwKFBVbJCw4HjcWAgQaCw0HBAcNBwMECw4gAgIGAQIEEQsYCRwIAgQqGC0aMRxjJQgjAxsEAQcMBQYBAiMPFiAIHQEdchIDAwQHBgcEBAICDAgDAgQWBggBEhUDCAEBDAUHAwwEBxo2KygqBA0ICRIRERACAQMLFQsFBAgLCQ0AAgARABsBogJZAEEAXQAAEzYWFxYzMhYXFhceARceAR8BFgcGDwEGBwYjIicuATc2LwEuAQciBiMPAQ4BFQYVFAcOASImJyY3Njc2NzY3Njc2FyYHBgcGBw4CBwYVFB4BMxc2JicmJzQuAScm3BErCQYCAyAGFQICBwEHFgQECgcDBgIBAQkRBxISBAQFAwEgdSAFDAQECwIFBwUCESoKAQUMEwgDAgERKSwdQxQRIhMCCgQDAwIFT1ICEQEOAQYDBAUCDQJWAwYHBB4JIgQFEAIQayIkVmIjBgMDAQ8LCg0fMzwYBAUDAgEsCDEELQsUFAsIChQ6TXYXCQgOK3ItHVMODx87BxcHCw8HDQQBAwMBAVEBCR0FBwcFIAACABP/7AGIAkYAZQChAAAAMhYzMhcWMzIWBwYHBgcGBw4CDwEUFh8BHgIXFjMyFhcWFx4BDwEGBwYVFAYHBgcOASciJicuAScmIyInJicmJyY3NiYnJjU0JyY3Njc+ATMyNjU3NhcWNhcyHgEzFhcWFxYyByYHBgcGHgEVFBceARcWBxQfARYVFBYXFhcWNjc+AScmJyYnJicmJy4BNzQ3PgEzMjc+ATc2JyYnJiMiAVcCCAIDAggGBAkDAQIDGxwMAgYiBgcVCwwDEA4ECAECFAMGBwQEAgcIAwUZCQwkCT4KAw8DDjYKAw8VBwkCAgIIAgEFAwcDAgICFAMQCAQNHTIbBQwEAQcLBCQeEgEGAl4YJDAdAwIDAwQHAgkCAQIMLAoDIyAeBggLAwYFBQgYRCoOCQMBAwMcBAkqGDYGAwMDEhIFAwIcCAUPLwQBDR4jIQYBBhQCBAELBgYCCQkECBoGCREIQBElGwQHAgMYBAYJAgICAgECGQgDCAptTSBKCAU3DSgMHwkJBAcHAQ8EAgoRBAEEAQEBAg4IAQQwBAMFCgMHDQMJCg97D18kGg0YBAMEGAEBAgEKBAc1ER8JCgYTIRUMCQgTCgYFEBEKLxUMBgUKCQAAAQATAAQBrgJsAGQAABM2FhcWFxYXFhceAgcGBwYHBiY0IicmJyYHDgEHBgcOAhUGFxYXFhcWFxY2NzY3NjcyNzYXFhcWBw4BIyIGBw4BIyIHBiYnJicuAicmNDc1NjU0NzY3NjU0Njc2NzY3Njc28QwlBQEKCR0WBwEMBgEBDQkGAwsGBRceGRYKIwspEAMFBBACAQYFCBAZFTkVOCEXBQIGDA8QAgINBCQDAhkEB0QGAg4TQhVLHAEJBgEBAQEJCgMCCgMCAwQiNSsXAmoCBQQBAwIUEQ4BFQ8GCggGAwEDBAUXEA8MBSYQPTMHEgoBIlAnEg8QHAwIBAgXHxQBAwcNDQgKFQcjDwQGHwQGAwcbVAQWFAoFIwgJCAYdJCsFBAMEGwQCCRA6VxYMAAAAAAIAFAATAc4CUwBTAHkAAAAyFjMXMhYXFhcWFx4BFxYXFg4BFQYHDgIVDgEHIhUUBhYGBwYHBgcOASMiBwYnLgInJiMiJyY1NDY1PgE1NCY1Jjc+Ajc2NzMWFx4BFxYzFwcuAQcOAh4BFRQXFgcGBwYzMjc2Nz4BNzY3NicuBCcmIyYBbAISAgUBCQMQDREBAQMBAgICAQQDBwIFAwEXAgEIAigOJioUAgVgEQcIHBYEEgoCAgECAwMFAQoBARYHBwsHBh4jRisFHwwTAwtyGEkWCAgCAgMDAwYCBwQJFEghKxY6Cw0FAg8DCREHGAEjBwwCCBEFDAQSGiEGBA0KDgIDBxMFHBUGDgoBBScBAgELAikMIRQLAgccAgYHAQUGBAYGCCEZJRgT60ACDQQRHgoFAgMCCAIVAg0IDAkXCw4FAgMEAwkFAh4dsHgbDhcLHA9AGB4rGyAHDhIHFQEdBAABABP/5gG3AjwAfAAAATMWFxYXFhUUFxYHBgcGJyYiJyYHBgcOAiMGFRQWHQE2FzIXFhceAgcXFgYHDgEjIicmByMHDgEHBhceAR8BFjc+ATc+ATIXFDMyFxYVFAYHBgcGBw4BIyImJyYiLgE3PgEnJjc2PQEnJjU0NzYzMjc2Nz4CNzY3PgEBKC81DxECAQIGDwcCCR4EEgILRD43BQsJAQYBSDIEFxQCAQgFAQIDAgQDGwQCChNHMgEBBwECAgEBAQEDdQwyDAgpHwIGDQsGEhcvUTENCEYMDS4FBAQMBAICDAEDCwQFBQ8JEQcUIREIGRMNEh8JCwI8AQgICAQFBgYPCAMFEAsBAggLChICAwMBCQEhDCUNBgcHBAEHBgMCARsEBA0ECQEgG0kgOgcCBAICAx0DCQQDBQIBCwYQFQ4CAxUNBAQNBwMCDwoPDgwNIJU0TU4MDAUMEwkGCgQCCQUBAQYBBAABABEAHgHHAkUAVgAAEzYWFxYXFh8BMhcWBgciJyYjLgEiJiMmBgcGBwYPATcyNjc2FxYXHgEHDgEjIgcGDwMOAQcGBw4EBwYnLgEnJjc2Nz4DNzY3PgE3PgE3PgGeDVoQBTViAwYHBAIRCBQTOQQPFAwkAzgTBwMKEQQBCQFUDhQaFQIFCwEBCAIEBA5APCsDAgYBAgcBAgMEBAYIDxELAwcICgMCBwMHBwkHAgsDAQQBBCQCQwIHBAIECAIDFAsjAgEDAQMGBwINBSZJOBQBBwICAgIBAhsFBAkGDwgFAyAQJgoaFgMNCQQLAwMCAgUHDTI8IBtWHDYhLw0EIgUBCAEKGAAAAAABABMAEAG7AkgAlwAAEzYXFh8BHgEXHgEHBgcGJicmJyYnJgYHDgEVFAcGFRQHDgEHFAcGFx4BFxYXFhcWFxY3Njc2NzY1NCciDgEnLgInJjc2MzI1NDYzMhceARceAxUXFhcWBw4CBwYHBhUUBicmBgcGBwYHBicuAScuAScuAScmIycmLwEmJy4DJyY3ND4BMzI0NjU+ATc+ATMyNzbFKSAiECwNEgcRBAkJAwwQFTcFDiQOJQkHGgcSAQUPAQQDAgEJAQEMCxMiKhEMGx4cDQseBzIiBwcFBAEBBAMFA0gYKQgDEgMCDAcGAwYCAQYBDgQFBAoHRAUDFQIHAgMTKSgMDgcGEQMIKQQCAQQDBAQKCAIEAgIBAwIFBAMBCQIzDQwyBgQCAgJFAwgJBhAFCQMGFxITAQUIBhEDBggDBQUEGAIDChoFAgEHLQkFFBIeEzYHDBcWER4FAgQJIh8jHRcFAgMCAgUGDgwQBgYCAwkGAgYCAQYECAUDAyAOJgomBAsKDAkCBkQBAQ0BAwEDAgYOBAcCAgoCBSgIBAYHBwcKLQgPCBANHhgCLR4GGQIOVwwLHwIEAAEAEwAAAYkCJABaAAABNTQ3NjU+ATcXFhceAxQVFgYHBhcWBwYHBicuAScmNDc0PwEnJgcGIyIPAQ4BBwYHBiMiBwYnJjQmJyY3ND4BNTY1JjY3Njc2NzYzMhYXFhceAQ8BFD4BFwEyAwQCBgwWFgYDBAEBAQ4BAgcFEBYHDwkMBgMCAQECChhcIAENDAIBAwIIAQQHAgMCGRcGBAQDAgMBAQgDAwcFBQobEAgCAgEEAgQCOlAVAU0NCSQwFS8eCgICBgQGDAkXCTLqIFsYDwgMAgYLDA8ZC2oCERMjAQMQBQUbEjESVwMOAwIBAgIGCgkdBxERAwkIAXMUGJBeCAwECAcBA3g+HAELCgEAAAAAAQATAAUAdQI1ACEAABMyNjMyFhcWFRQWFRQWFx4BBw4BIyImJyYnJicmJy4BNzYrARAGEAsCAwUHBAIBAgQPFwsJBwUEBwMCAgEDAQMCMwIFCQ9UMXcsN3cIBRcHDAYFCwkWJ4BoAgGkCT0AAQASABECAgJPAGsAAAE+AhY3HgEXFgcGBwYnJgYHIg4BFRceARcWFRQWBgcUDgEHBhUUBgcGMwcGDwEOAQcGBw4BBwYnJicuAyMnIiYnJjc+ATc2FxYXFh8BNz4BNzY3NjU0LgInJiMiBwYmJy4BNzY3Njc2AUAmCDIHJR8PBAQEAgcJFxhZBAEMCwEBAwEPBAICBgUCAhgLBwIBAQIBASMFBAQDIw0uGxwLAgQDAwEBAhsCDgMCCBASBAwIDRYPEhUSEBYKHwMCCwIEAwcwDy0KBwMCAgYLJEECPggBCAQCAQMIBh4SBAYBAQcEAwMBAwQNBT4iEghICgIeGQMGBAg1DwkCAgMCAiQEAgQEEQQOCgoGAQMBAgEeBBkWCwgEBAEFDhYMCAUFCREYEzxQGysQNQoUCwMGBwQLEBEGCgIGAAAAAQAS//kBsAJRAGYAAAE2Fx4BBw4BBw4BBwYXFhceAR8BMhcWFRQWFxYXFgcUBiIOAScmIyIvASYnJicuASMiJicmJx0BFAcOAiYnJjc2JyY1NCcmNjc2FxYXFhUUFxYHFBcWHwEWBwYXFD4BNz4BNzY0NgE9EgQUBAkDIwoKaBAKAwcEBCgSEwYiPhMEDhgIBAkEBh0CAwQPBAMaQBECARkCAS0DFRQDBAsmDgQDAQEQAgcEBggEEhwDAwcDAQUBAgICAQICCAkDClclFR0CTwIFFxMPCB4FBnAVDQIECQgiDQ4iPAMBGQQMNBIeAgoGAgMDHBExOxADAhciAxUKL2c2CAkEBAYLBjOndg4LJRAKRwkEAQIGBAoLGAwJAicHDxAPAQICAQcLBBBbIRMEEgAAAAABAA3/+wGbAisAOQAAEzYzMhcWFxYGBwYHBhcWFxY2NzY3PgEyFxYXFjMyFxYHDgEnJgcOAQcGIyImJyYnJicmNz4BNzY3Ni0IGBYEBwICBQQBBgURBAcMThUYIgYnBxUhAQECBQQCCQgMFCxJCy8JFC4GIAQJAxYKDQsBBAIDAgICJQYEBjIabhcEdmIiCAECEgoLBQEHAQYEAxMHEhEGAgMZAw0DCA0ECgMULjaKDkcaHTRGAAAAAQAT/+sB3wJbAIIAAAA2HgIVFBcWFxYHDgEHBhQXFgcGIyIHDgEnJicmJyY1NDc2PwE2JicmIyIGBwYHDgEjIicuAS8BIi8BHwEeARUUHgEVBhcWBg8BFg4BBwYnJjU0LgEnJicmJyYnJjU0JyY1JjY3NjcyFhcWNhYVFBcWFxYzMjY3PgE3PgEzMjY3NDMBbwgjDh8NCAIBCQIEAwUFAwMEAQMKAhQGCQgLBAQHBAcCAwMEBgYFLxYlIAUeBh8IAxIFCgIQCgECAQYCAQIEAgEDAQEKBBMSBQUCAgEDBAQBAgICAgMBBgsKFgUQAQICIQsVAhcKBCMPCxQIByACARcBCAJXBAIGHgQDIxJSSFQOPBMiTwwJBwgMAwQBAwgKEA4oShwQeBQEbhYiOiE2GgQLBgMNBQkTDD1DBF8GARsbAgMXEzsJAgEQAgICBAMEAQQIAwcgKh86CgwXChwtTFgwDAoCBgMCAiECAQ8cAx8pFhAbDAoiEAIBAAABABMAIAGfAn4AVwAAATYXFhcWBwYHBhcWBwYHBgcGIyInLgI1LgEnJicmLwEXFBYXFBYVFBcWBwYHBicmNTQnJjU0JicmNzQ3NhczMh8BMh4BFxYVBhcWFxYXFh8BJzQnJjc2AVoSGhYCAQIMAgcECggDCggDFgIPCwEIBQIuCQYlNSoQAgUBBAIICgQfEQUMAgsHAQIBCRUPDAQJCgIEBAECARotFjAnDgcGAQMFCggCbREODAkOBhsgV0B7YSgPCwEGCQEFBAMGQgoHL0NGGh8KUxsNQg4FGEUOBwQCAgYNCAMYYBdbDkF2PggVAggHCAoBBAECMFEhSS0QCQcuB2N3NzAAAAACABP/9AHBAksAOwBmAAATNhceARcyFhcWFxYXMzIWHwEWFxYXFAcGBwYHBgcGBwYHBiYvASYnJicmJyYnJjY3PgE3Nj8BNjc+AhcmIyIGBwYHBhcWFxYXHgEXFjc+AjM+ATc2NzY1NCcmNTQmJyYnJgcGJrwYJAQmBAEpBQIDAgIBARwDBxsVCQIGChghBwEMNTkXDgkoBBgtGBYJBQMBAwEEAgEHAQQIECUqDAoRFwICAyEIMggECQEDBBYFFQgVGgMJBQEKOw0XERMGBhcKGx4XCAgXAkEKDwEIAhUEAQICARgEBxk4GC44GSwuQAcBDkIVCAICAgIMFzEtJBMhEBAKSwsFHgYdCB5JIgoGBkcCJA1MUScyAxofKwkXBAoJAQMCAzsTISksQBoPEgIEIgsdCQcGBQ0AAAAAAgANAAYBowJhAE8AagAAAQ8BDgEPARYGBwYHDgEnJgcGFxYXHgEHDgEHBicuAScmNTQ2NzQ+ATU3JyY3Njc+Azc2NzYXFjMWFx4BFxYzMhceARcWFxYXFhcWFAcGJyYHBhUUFxYHBh8BHgE3PgE3PgEnJjU0Jy4BAZ8JAgEGAgQBJAcoLxBTFxcBBQQDBQIDAgIJDxMHCAwFCwQBAQEBCRgJCAsFDBoiBhYrGyYkAQ4DCywEAQMCAwEUAgQBBQYCAQECArE5OQUCAwMDAgwLRBIYOwoLDQQCDgw0AYAXBAQLAwcCJAUbDgUDAwIBAk1NCQQgBwoJBQYDBAwTMXM1XRoLIRYEEgMKHBkHAwwODwMKBwQKCwYBBSAFAwUCFgYIAQMfCgECMgMEigwXAwYHAgVMRhcCAgECAx0PDyIEAgkSFhIhAAAAAAIADQAGAhsCZQBPAI4AABM2MzIXMh4BMzIWFxYXFhcWFRQWFRYHBhcWBwYPARQWHwEWMzIfAQcGBw4CJyYnJi8BBwYHDgEHBicmIyIuAicuAScmJyY3Njc+ATcyNhcuAQcGJyYHBgcOAQcGFx4BFxYXFhcWNjc+ATU0Ji8BJi8BJicmNz4BNzYzMh4BFxYfATc2NzY1NCcmJwYnJswVGw4aAQQDAQUmCRoZHRAVBQMDAwEBEwkCCxQDFBQBAhQUAQEJAQ8OAhEOFy8KCRoQAjIKJg4GCA0/JhYTAgwDBQcJEBYxED8OAQhMCQwKFg8GCxsZChgFBQEBCxQLEhodEBMVDRwGBAQoChELAQELCQUIBAUBDxUGERQZCQsKBBIVFxIMBwJYDQsCAQ8HESEqKzkMBx0ILgYHBQk9GQIUAQsBCwwUEwoKCAEPCwEFDRUYBQkaBwEaAgoDAiAiIigEIQULNEE1Tj8VNQUFUggBBw8GAgoZIg4+FRskKykmFRMbBQQCCgYSAgEFAwMdCxEIDAkNCwQBAQoNBQwNEBATIw0lNzE5HA4NCAACABT/8gGYAl4AcACMAAATNhYXFjMyFjM2FjIWFx4BFxYVFBYHBgcOAQcGBw4CBwYHBgcXFhcWMzYWFxYfAR4BFRQ3Nh4BFQ4BBwYnJicmJyYnJicmJyYnBxQOARUGFhcWBw4BJyYVFCMiJi8BNzY3NicuAScmNjc2NzY3Njc2BxQWFRQXFh0BNz4BNz4BNzY9AScmJyYjJgYHBv0CMA8PBAETAgIJAggCAwsCAggBBgIEBQUICwUHBgopJSIjGxoHBAMCLAUCAgIHIQIBExECBxEOBRMEAw0eEg0CC0ApFwIBAgQGAQELBAgCARETDwUFAQMBDgoBAQIECgYCBAMfMl0gngYCBw4EFAQYThkyCxkQCAoGQAlVAlwCBgQFCAEICQEBFQECBAIRAyYEBxMIDQ8GCwgJJhQTEBgWCgYBLQcCBAMGMgQDAgElKAIMCAkIAgUFAxo5Fg8EDzkkHB4IGCEIGisTHBcHCAEBAgEKEA8vRwyiWgsaCQ4rBgIGBRIdBgJxBAkGBwohPBIDAQQBBS8XLyAJBQsBAQEDAg4AAAEAEP/5AawCTgB0AAA2NCY1NCcmNzYyFxYXHgEXFjMyNzY3PgE3NCcuASMiBwYnLgEnJi8BIicmNjQ+Ajc2NzY3PgE3PgEWMzIXFhUUFhUWFxYHBicmIyImIyImBw4BBwYXFhcWNz4BNzI3NhczFxYXFhcWBwYHBisBIiYnJicmJywGBREUDQ4OCyUbIRQKFhMMDRYbEgEaDQ8QK1UzEQMRBhYDBAIEBAULBQ4CBysJOAMdBAcsBAQTJiIHAQcKEQcPBAgDBQEGPCAjRA8HAQIFAgMCHwcBJjgnHhk6DQ8BAQgOQCs6FxRDGSEGBgd+AgYCAwcbEwwNCSofGwcEBgYYHywxMBkNBhoRBwEFBRUNCRgKIA4bChkFDyUIHAIIAQIBBBQTBQEJAgkDBhoKBQIDHAMENiAOEhoBAQMCCQEKDgENISkvGiklPj8rIRceDQwIAAABABQAKgG+Am8APAAAATYzNx4BHwEWBwYjIgcGBwYHDgEVFg4BFxYVFgcGFRQHBi8BBicmNzYmPQEOAQcGLwE3PgE3Njc+ATc+AQFBPBAgAgoDAQEIBBAOCAUmODcGAQMEAQIDAQQDDAIQEQoLCQECBQcvDiQWBwEBDRMQOgUbBBduAmoEAQMLAhUaCAQCAQQFCQECBRUKpTVaKEsEAwQHBAECAQILCRE55ytjAQsCBRMGERYPAgENAQYBBhAAAAABABH/4AGfAk0AYAAAATYXHgEXFhcUHgEXFhcUFxYUBwYPAQ4BBwYHDgEjIgcGBwYnJicuATUnLgEnJicmNzY3NjU0NjU2NzY3Fx4BBwYVBgcGFRQHBhUUFx4BFxY3Njc2NzYnJicmIyInJjYzMgE7ARsGGQEBBgICARMFAgIBBAYFCjcYDAUHHQIHFgURERMqIQQWAQIFAhgICAUDCgIEAggLERQPCwIDAwQDBQgOAhQIIkMaESkIBQgFEQICBwcFCgsEAkwBAQEaCQoRAQUIA0BGCwIDOxY1EQ8fWRkMBggYDwMGBQIEGwQcAQMDCgUwOzl6VBcEDAgTBAsVGQgKBwoEAwomCAkFDSFEU0FDDCsJKUMaGTw3KFIuTQsWFSAAAAAAAQAUAAQBgwJAAGkAAAE+ATMyFRQeARUUBwYHDgEHDgEHDgEPARYGBw4BIyIVFAYmJyYnJicuAScuAScmJyY1NCcuATQuAjU0Jy4BJyY1NDY3PgEfARYUFhUeARceARcWHwE3ND4BNzY3NjU0Njc+ATc2NzY3NgE9CAcSFgYJCgYKAwcDBCIDARIDAQENBQUWBAINFAkUBgQEBRYFAwUCCwgDCwIPDQIKBAMIAgQHDA0ICxISCgEYAQIOAggXDA0CAQEGAwIMAQIXAgIEARcNAjcIAQYCBA8EByYXKAsWDhOHHA9WBwcBJQkKGQEDAwIDBwoIAgQmDwcKBh8dCQcUFgM5CCcCIQMCCAUgBAgHCgoHCAICGxsEFQMIUAUJKwwqPyAtAQgNBSsDAgYNJwgMXQkMCwRWMAAAAQAT//UCRgJwAIwAAAEyNjI2MzIWFxYXHgEXFBYXFgYHBhUOAgcGBwYVFAYPAQ4BIgcGJy4BNTQnJicmIyIHBgcGBwYnJicuATUnJicmJyYnJicmJy4BNzQ+ATc2FzIeASMWFx4BFxYVFBcWFxYXFjc2NzY3PgEXFhcWFxQeARUGFx4BNz4BNzY3PgE1NDc2JyYnJicmJyY2Ad8CEQIFAQQcBA8HAgkBBAEBBAIEAQUNAhATBAwHBwQfAhEwMggaBQkEBwECBxwSHB4lEQYFBBAECQIFAgQEAQIFDQQCAwYLAxUMAhIOAgUBBAYEBAIBBAcKAgYONBgLDR0FAwYHAQMCAgoGEREcPAsFAgIHAwUDAggDBAoCAQUCYQ4BCwMPIAxFBgNlBwYvBQYKEBMbBisWBgECEQoJBSANJhEDDgIDBQwHDQ0yERsDAhUIBQQfAwoUEjMCBFgIPHgfCSEEAQQGAg0EGxsPBSuSMTYFCgQCGyoMAwQLXywHCAIHAwMDCAIGBQEFLh0MCxJRJA8EAyYFBAYITS49HQIIFQgRAAABABT//QGvAlcAZQAANyIGIyImJzQmPgI3PgE3Nj8BJyY1NCcmJy4BJyY3Njc2PwE2HgMXFhceAR8BNzY3Njc2NzYWFxYXFgcGBwYHBgcGFxYXFhcWFxYXFgcGIyIHBicmJyYnJi8BIg4BBwYHDgEjTQEMAgQkAQEKBQ0BBxsEAiojCwwNExkDGw8CAgENCQgFAgYJBwcBCyQODwoRFyEDKgIBFwweAgIFCQEBG0ITDRACGSIuIw8MAgIDAwQEAwIQDwYSBhIePhYPAR8pCQYJBxkCFQUYAwkIFgkVAg0uBwRJOxUWAQIWHjIFMh8DEQgJBgMCAQIICAgBC0UaGRMfJzUFPQoVDAcGCAUCBBEOKGQkGRcDKzo8LhsVBwkHCQkICAcBAw0oKlMlGDZHDgkSDicAAAEAEAADAeICOABIAAABNh4BBwYHBgcOAgcGBw4BBwYVFAcGIyImJy4BNzY3Njc2JyYnLgMnJjc2PwEXFhcWFxYXHgI1NDY3Njc2NzY1Njc2FzIBvA0NDAIIFy0iChsXDQkDAQMDBwocEgUKAQYBBAEJAgECCA0UD1UKJQIFDgISDwgNDA4BJAsDLCcnAwgKBC4wAQQKDgcCNQMHGgsjHjoxDyMhFw4YBi0JFVQdBAcKBicSIQZYEgMGCAsiG30GQgoUDAIGBQQHGBkBNgsDQj8BAjsCCA8HPkELDQUMAgAAAQATABsB2gJIAGsAAAE+ARceAR8BHgEVFBcWFRQXFgcGFRQHBgcGBw4BBw4BFRQyNjc2FxYXHgEHBgcGJyYHIgYHIg4BIiYnLgE3Njc2NzY3Njc2NzYnJgcOAQcGIw4BIw4BIyImJy4CNjQ+BDc2NzY3NjMyAVcCKwIJIgIFBAgDCgMGDAQLD11ZHwYVAg43FyUSLYlFBQQIAQMSIlILRBFJEwYeFhoRAw8DCQ8lMQUTBw1YG0QQBAlRDiQPLwgLFgoIGgkMCAgCAwIBBAIHAwoCEg0qejQTCQJFAQIBAQgCAgIDAQIBAwsBDBMNBgEDEBZeWiYHGQIQSgMBAgIFAwEEAyUHDwUJBwECBAECAQQDEhAXKTBABRULFVgbSBABBA0CBAMIAQQBBgYRBQgHBgQEAwQBBQEJAgMSCAAAAAABABH/ogEfAnwAWQAAEz4CNzYzHgE2NDYWFRQ3NjMyFhcWBwYjIhUOAS8BBwYWFxYUFxYUBwYdATMyNTY3NhYXFjMyFxYXFgYHBiIHBiciBiInLgE3Njc0Njc2JyY1NjU0JyY3NicWAwoJCAkICxUOCwsMBzsqFAYEAQEKBQGFDg4CAgICAgECAQIYGBABAisHBgwKCAcBAgEFBgoBAmQKLxsREwsGAgIFAQEDAwEEAwECAgJZBA4IBAUCAwECAQIDAgEBAwcFFyIBAgUBAiksYwMCzAECaQICHR0BAQEDAQMDCAcTFQsFBgECAgUFCRodBykWIxknCQsXJTsnIx1CVyYAAAEAEP+8AXMCQwBwAAAlHgIfARYfARYXFgcGIyIHBicuAScmJy4BMy4CLwEmNTQmNS4BJzQmNTQnJjU0JjUvASYvAi4BNScuAicuATc2NzI+ATMyHgEXFhcWIyIWFx4BFxYXHgIVFBYVFhcWFRceARceARceARceARcBJwEEBwICFwYGAgMUDQUCBA4NCgYRAQIIAgMBAgcQBQQQDwEMAQ0SBw0OBAUEBAQECBIBCQkCCR8FBAkBEhIDCQoHAgkOCQIBBwcFBAMHAgEREA8FDwYBAQQBBg8FBAQFAgQBegIHDwUFMAkLBgYuCwUHBwMCDQQLEAQFBA4dCQoiAQIfAQMcAwIcAwcpDgQCHgEiCQkJCAgIDwEjARIQAghFDAwCBwUKFgQUEwwNCQcJBgsGASUjAgEcARYfDAUCAwcDDDAKCQwLBAgDAAABABH/mwE4Am4ASwAAEzI2FxYzMhcWFBcWFxIHBgIVBiMiBwYnJiMiBwYjIicmIyI0JyY3NjMyNzYzFjc2OwE3NjU0Nic0LwIiJyYHBicuAScmNzYzMjc2SAo6Bw9PIgYIBQkBCAUBBQMPBQMHEgwfVQgCFxUMCgMCBAYFBgUEAgYOOy0HFRACAQUBBQIpKAoJBwYcIRMEBwcGCgQCAgJrAwMDAwQCBwoo/t4xBf7xBRUDBwUDBAEGBQIGBxMdAgYDBgELBmAzeS+yIAgBAgMDAgEBCg8dCgkDAgAAAQAUAUUBgQJkAEkAABMUBhUUBgcGJicuAjU0NzY1NDY3Njc2NzY3PgQ3NhYVFDMyFhUUFxYXFgcXFgYHBicuAScuASMiJyYvAQcOAgcGFRQOAX8OIwYMCQ4KBAMDAwoBCAILFyQQAwUDBQkHCxkDAhlOMwcPAgIDCRQVBA8WER0IAgMNDg4OBAEFCAMNCQoBhQITAQMhAgQEDgoEBwUJAwEFAwwCDAILNFAVBAgFBQMCAwQEAhoCBVE2CxoFDAwKCAgBBSgRHgwPEA4QCwMKEQYaAgESFQAAAQAT/8UB1wAjAB0AACU2FxYfAQcGIwcGByIHDgEnLgEnJjc+ARcWMjY3NgGtCQkICAgGCAsKBTs3AgSjMygZBwYDAxY6Ry1kH0YfBAUEExQNEgUDAQICAgEBBgoIHBYIAgEEAQIAAAACABAAAgF+AZcARwBkAAASMjYzNjMeARcUFx4DFxYyNDYXHgEXFhcWBgcGFxYXFhceAQcGBwYmJyY1NC8BBwYHBgcGJicmJyY1JyY3NSY3Njc+AT8BFy4BIyIGBwYHBhUUFxY+ATc2NTQ3Njc2IwYmJyafBhYDBQ0IGwEOAgMEDgIDBAwQEgkCAgEECAgKBgYDBxcIAQgMDQkgDQkHBwkDHR4JKyshEw4IBAwFAhUOIQclCApKAQwFAiUEIhIOCRI5LgsVBQIBAQMLFAMEAY0JAQEKAgEMAgcCHQYQBAYCAggNCQEFOBgeKB0IFQ8FDREZAgITDwsBAg4OCAMXFQILAxILHxADCh4NFRs4Ji0KJAUHTAEXGQQlKyQbKw8fEigSJBcIIw4CBQEUCAkAAAAAAgAPACABSgJkAFIAagAAEzYzMhceAQcGFQc3Njc+AT8BPgEzMhcWMzIWMhYXFhceAQcGFAcGBwYVFAYHDgEHBicmJyYnJgcGNQYHDgEuAicmNz4BNzY3ND4BNTY0NzY3NhcmBgcGBw4DBwYdARceATc2Nz4BJyY2BxUWBgMCAgMBBxETAgUDAgUhCicEAQMCCQISBA0ECAsDAQIHAwUeBwstDx4eHQoCCAgFBgQFBAcGAwgBFAgCBwIFAQEBAgECAgGzCQ4TIxQHCAMFAwgSGycYEAsQCQQFAlkLDgd7IysEDwUNCgECAgEECAYBBxEGEhEcXRAGEAkbBQgFBC4GChgEBgYFCgIEBQMEAgICAgIDAQcBETsLghM5NwkZEAMKHwsJKB37BQIJESgPFgsfDCQFCA0TBA0KEBkyMEEAAAABAAsADgFjAdkAWgAAEzYWFxYzMhceARcWFRQXFgcGBw4CIiY0JyYnJicmIyIGBw4BBwYHDgEXFjc2NzYXFhcWBwYVBwYPAQ4BJyIHBicuATU0IyImJyY3Njc+AT8BPgE3Njc+ATMywQkuBQMDBBEEDwEVAwUGAwoDBQMDAhIFDAQRCAcQOxMCCwEDAwgFBAo9UREvCAYIERcHBgYGBgNBCAYDJTkLGAMEHgUiCwsFAQ4BAgIEARUuCSkEAwHVBAEFAw4EFwIaCgUECBIKBQECAQICCQISBhUJQicFGAMJBgxGGDsLEAQMBAQOIAsDAwICAgIDEQEBDQkCCQMBHQk2SEIFAh8CBAMHBDMxCh4AAAIAEAAfAYQCigBEAFsAAAE0PgI3PgIeATMWFwcUBgcOARUUBhcWFAcGBwYiJyYHBgciIyIVDgEjIicuAScmNzY3Njc2MzI3Njc2HwE2Nz4BNzYDJgcGBwYHBhceARcWNzY/ATU0NzYnJgFNAQIEAQIDBgMJAgoMAQUBAQQJAgEBAg4GJgQGCB0SAgQEAzYQRSsHEgMFCAMNFzAfBgIMBSkyExoBAQQRBQJCCi4lFxUTGQYEHCMZHC8TDAIEBQkCeAMDAQMCAwIBAQIBDBUIQxkWUxIMcxMLcBEtBQICAwQMAQECBicGIw8VNhImQCcWBQIICggKEBJBhQQC/tYGCAcSECo5KRsRAQEFCQgGCAQsSBkoAAIACgAJAYwBwQBCAFcAADciJwYXFBcWFxYXFjY3NhcWFxYHBgcOASMiBw4BJyYnJic0JyY3Njc2Nz4BNzYXNjc2Fx4BFxYHBgcOASIHBgcGJyY3JgcGBw4BFxY+ATM+ATc2NzYnLgFuCQcHAgYFDhQVCkwUFRMLCAkJAwEBDAIBCCBzGzAVFAIEDR4QFwkBBDMSJQIaBBYsCykKJQQBEAYZBAoXSWESAp8fLiIbChIBAj5MChsMBggBAgYDGMgMIxMEEBAOFAQCBQUEAgERFAQDAwQJBA4GDBUfGxAEEDZWLhgIBQksCRICBQEGDQMZCiU4HBoJHAQJBgkMAqoNFxAjDSABAgYIAgMHCwsYCgUTAAAAAAEAE//6AakCUABoAAATNDYyFhczFhcWFRQXFgcGByIGJyYnJicmJyYGBwYHBg8BNzYyFxYfAQcOAQ8BFx4BFx4BBw4EIgYjBicmNTYmNS4BJy4BJzQnJiMiLwEmJyY3Njc2PwE1Njc+AT8BNjc+ATc2NzbwDRISBwhNHggBBQMIDwQOBwsICxMTGxkVCwoHBwIBEy8PBAwBAQgHFTMMAQEKBAMEBQECAwIGAwsDFQcSAQgBAgEBBAECARwtDwQCAQIECBMdGBACBQEEAQIJBQ4VEw8OCQJNAgEBAQ8kCgEDAg8FEQQHAQIICwcIAQEGDQ4ZHRsUAQMEChkSBwcDBAEJBpQZD0gUAwMDAgECAgQLMBRMCQ8VEhUYERcCAQwEBQgNCA8DBwEBGTUFAQ8HBxUHFxQKCAMCAAIAE/8OAdYBowB3AJkAAAE2FhcWMzIWFx4BFx4BFxYVFAcGFhcyFhceAQcGFxYHDgEHBgcOAQcGBwYVFAYHBiMiFAcGJy4CIyInLgEnJicmNzYzMjY0FxYGMxYXFhceATMyNzY3NiciBwYHBicuAjQjBiYnJicmNzY/AT4BNzY3NjMyNzYXJgcOARUUFxY3Njc+ATc2NzY9ATQ3NicmNzYnJjU2JicmARMTMwgDBQMQBQMaBAULAgYMAgMJAhICBAEDAgIGBQEJBAUCAhkKCRoFIAgWDAQfLh8DCQYBDDQLJgcSAwIEBw4CDAMCAwUNBwkdFkYfLiIzDgICAQUmPikOAQkIAQUsCAkPDgYEBgEBAwEUHhoFAQsTUBUTLTEgGC4TDRcRBwEDAwIDBQQBAwUBAQ8HDQGfBAIFAwcBARAEBBUDCgsPGQUBARIEBjUUESRSFAM2CxIICjYQDxwFAgEUBAsCBAQJAQICHgYgChgaDwgSDAQDAg0DERUYERgkNnMOAQQeBgMIAQMDAgElDQ0nKDcrCQMCBwMzGBoHDEMFBQ1OOzggGAgECA8VFgQGChMLIQcKAwMKEw8EBQIMAwUAAAAAAQASABgBQwJKAFQAABM2MzIfAhYfATQ3Njc+AT8BMjc+ATcyPgE1NhceARcWFxYXFgcGFRQHBg8BBiYnLgE3NTQ2JicmJwcGBwYHBgcGBw4BBwYnLgEnJjc+AScmNzYnJikGDQ4GBwEKAQEEAwQCDwYGAgUDHAIBERADIwMTAwQHDAUSBQEBAQgKAQ0OEAgBAQEEAQ8QHw8bEw4BAhQDCgUGDwsGAgUEAwMCAQICAQMCSAIGBhWMGy8BAgIHBA8GBQUDCgIEBAEDCAELAQEJEg03PwordwoJCAgCAwUGCQorEF9RGgoLBAYXKkc3GTEFAQUBAQsICg8fQTujEQUFAjBWAAACAAsAJgC6AewAJgBJAAATNhcWFxYVFAcOAQcOAgcGJyYHDgEHIg4BIyIGJyYnJjc2PwE+AQc3MzIXFhUUFx4BBw4BFhUWHwEGBwYHBiMiJicmJy4CNTZjHQ0QFAkCAQUFAgMDAw8MEA8EDgQBBAMBAxcFCQYQFQIGBQYnFwUTEgcGAgQDAwIBBgIGBQUGBgUHDREPBgYCAQMBAgHoBAUFDgUDDwQDEQUCBQIBAwYJBwIBAgIBBwEDDCELAQQEBRCsBwQDBQMECDYSHBE2CBkKCw8CAwUGDBITGRAZFxlcAAIAFP9BAT8CGQAdAJkAAAE2FhcWFx4BBw4CBw4BIyIHBiMGJjc+AjI1JjYDFAYUBiMGJicmByM0JiMiJicmIyInJjU0Njc2FxYXFhcWFDMyNDc+ASc0NzY3NjU0PgE1Njc2JzQmNSY1Ni8BJicmNTQ2NzYWFRYXHgEXHgEGFxYVFBYVFDMyFBYXFhUGFxUGFgcOAQcGDwEUBxQGFxYGFRQGBwYVFAcGAQAGEgIBCA0HAQECCQECGAIDAQEOGBgIAQQDAgIaNxARAQItAgECARkCARkCAwIBDQgFCw0NCQMOHgoGBwsKLQIKCwcJAgMGAQQGBAEBBAIDAQQLEBQKBQIBAgIBAQEBAQMCAQEBAwEBAQMBAQIBCAEDBAsBAQ0UCwkkCwIXAgUFAggMDQoMCg0DBBYBAwEtGAIODAEDEf05AQICBAIFAgECAQwRAgMLBxINCQUGBAMEGAUCAgICAhcEAgoMEBIDAgYGAR4deRIBKAEBBAkEFBMBBigTDAIDCgIqBQISAgEGBgQFCgUHBgoSFQMIGykYHAQGAgUaBTMBBgQMARIDAhABAhgIBwMBEgUAAAABABP/0QGUAhwAaAAANwcOARUUBw4BBwYnJjc0NjQ3PgE1PgE3NjU0NzIXFhUUFxYXFA8BNzY3PgEzMjY3Njc2FxYXFgcGBwYHIgcGBwYWHwEyFhcWFxYXFhcWBwYXFh8BFgYiBw4BBwYmNCMiJyYnJicuAScmbAICBAQFDBEbCQcCAQECBgIMCAIRCgkXAwMBCAENChIMNQIBSQUDBhUJBREHCgwgKBABHzEHAgYFBAEaAwYFEDMSCUwBAgYDAgIBCAQDARkCAhADAgQGDTI3DCsMGLMRECgISAYKBAECCwgaChURDBBgARLUMAwFEwUBAQkGAwQ5VkgJDAoOCiUxBAMDBwcDIA4JCRUaCRcjCQMHAgITAwYDCz4VCU0CAQYEDAsCDAMCCAECAgQGCQ0yQg8nBw8AAAABABH/7gCEAmsAPAAAEzYzMhcWFRQWBwYVFAYVDgEHFAcGFBceARUeARcWFxYXFBYHFAYHBiYnLgEnNCYnJicmNTQnJjc2NTQ3NjcECSQHAgQDAgUBBgEDAQICAwEIAgEECQIDARAGBRwFBg8BAwEHCgMDBQcNBwcCZwQJBAwICwoQGxcmGh8vGh0MBysEA2sBBjkHAgICEgMNBgUSAgICAwQSBAEKAxVQDxgZFipCbWUdGhkAAAAAAQAUAAACGgHHAG8AABM2Fx4BFxYXFhcUNzY3Njc+ARcWFx4BHQEeARUeAhcWBw4BBwYHBg8BJy4BNzQ3PgEmJyYnJgcOAQcGBwYHBiMiJjU0JyYvAQcGBw4BFRQHBhcUFhcWBw4BBwYnJjU0JyY1NDc+AjU/ATY/AjacCxAIIAUQAxIBBgECN0gJJQkPEgcVAQIEBAMBBQgCBgQCBwYUFAcKAwEMBAIEAQYUDhcJJwwsEQILBA8ZFAYEEAcJDgoFDwQEAQQBAgQFCBMYAw8CCgQDBgMBBQUKCQkiAcUCBAIUBxUJJRsDCAIDURMCAQICEgclBQIBBAEHGScFIWQYMCsXBwYBAQgLCxEMaCwaIhBRAwIOBSkQPmIOCwQWR2EkHQ0GChAXCzIFAhQSDASsAgcJCwQBAQIJDQQKLyJPFBIXExwsCQgBARE5AAABABP/5wFLAa8AUQAAEzYWFxYfARYXFhceARUUFxYXFBcWFAcGDwEUBwYmJyY3NjQnJicuAScmBwYHBgcOARcWFx4BDwEGBw4BByInJicmNzQ3Njc2FxYVFDc2NzYzNq8FJwQCDAsWDAEEAhEKCAICAwMECgQTBBcCEgYFBQUPBRgGAg8NFBoLCQQBAgEFBgQCAQMFEBQQCwUFAwEFAg4OBgYQIhIZAQwBrAMFBAIECxYgBQQCNQQGKBkoEgYTUhAeDQgCAgEPAQcbG2QiHjsWNQMCBwYUGhkVGyUuAxBTCAYFBQoGARYLIxjASgYDAwMDBAIJDiIJDgQAAAACABT/+gFtAaYAOwBdAAATMjYzNhcWFx4BFxQWFRQWFBceAQcGBwYHDgEHBgcOASMiBwYHBiYnLgInJicmNTQ2NzY/ATQ2NzY3NhcHBiMiJiMiJy4BJyYGIicmBwYHBhceATMyNzY3NicmJyaxAg8DKR0RCgYaAQ4IBAgEBwoDAQQCEgIQEQgfAwEKHiAXNg4CBAUBGxAEBQsOEAYYBxwWElwODgECEAECAgINAQMCDgIEES4OBg0HEhcVJSkZGAkFAQ0BmQYHEgkIBBsDARgBAhACChZEHSMDAQgEGQMXEQgXBhMFBAgLAQMDARA4Di4lHCUuFwoCHQcaBwRhCAcPBAMJAgMEAgcTMV8pIBMMFRkuKS8YAyIAAgAQ/y8BlgG9AFYAcQAAEzYXFhcWMzYWFxYXHgEXFgcUBhUUBw4DBwYHBgcGJyYvARUUDgEVBhUUBiMiBicuAScmNz4CNzY1Njc2JyY2NzY1NDc+Ajc+ATc+ATc2Nz4BFxYXJgcGDwEXFB4BFRczMhcWFxY3PgEnJicmJybbBBIvEQkDAh4EFwoCBAIMBwgIBAQCBggSDRcGQS0nHQ8CBQINBgQIDAYKBREGAgQDAQQCAQQHAgIFBRUEBwQBAh8JBwkHBgMBJwkIDCMaJQ8HAQEBAgYHERkdJSEsGQ8ECwsNGgG7AgQLDQcBIQckJQYIBzI4Ax4CBQwGCAQHCBIGDAIRDAgOBxMUApwEByILGAQEAgIDCioRWXIXPBgiBh4OBjQLCgQGGQUJBQEDEgMDBAIBAwIFAQFJBAkLEwkNAxksEEsKEAUIBwpJQBUWFwwYAAAAAAIAE/7yAbMBjQBvAIoAABMyNjMyNjM2MzI3PgEXFjMyFx4BFx4BFxYXFjY3PgEXHgEVFA4BFQYHBhcWBwYHBhcWFzYXHgQXFgcGBwYmJyYnJicuAzUuATc1JjcGDwEGJyYnJjU0JyYnNC4BNCY1JjY3PgE/AT4BNz4BFyYHBgcOARcWNzY3Njc2Nz4BNTQuAScuAScmgAEHAQIIAR4CBgMBHwIEBwURBwsFCBEEDAcEAwQDCg8RBgYIAwIQAgUIBgMXKgkJDQ8DBwMEAwIEEAkVCygKEwEOCgEBAQICAwEGCBMcFC0nHg4hBAkMAgEBAQUCAwsDCAQYAgUodBwfMR8PBw4cRCMjGAMQAQEODg4BAhQCBwFlBgcRAwEGAQIFAgcDBA4CCAsGAQgHAwIBBxAPIx8DEglYBg8MCRiUVhIICwsCBAEDBgUMEgoFBBUOHgMeJwIIBAUBBhkCBCU+DQcFCw0MCRcHAQYMLAIGBAIJAwojBQUrAxAJIgQJLBsKFSI9HEcdMAkFFxAOVgQIQQYCBgYBAg4CBwAAAAABABT/+gGNAasAQQAAEz4BMzYWFx4HFx4BBgcGFQYnJicuAQcGBwYzMhUUFhcWFxYHBiMiJyYnLgEnLgI1NDc2NzY3NjMyNzalAzsDAzgMAhMFDwcNCAoECwIEEAsRGQ0QGE0VLxMIBQMGAQICBQkLHxAFBwQBCAICBgEEDBIGAgIBAgocAaUBBAEOBAEHAgYEBwYJBQ0IHAQDAQoVCwcKCQULIA4NM3AXMgcVCQsGCBgKKBMPJx0kPBArEgYGBwgXAAAAAQANABMBXAHDAGcAABM2FxYXFhcWFQcGBwYnJgcGBwYXFj8CNjc2MzIeAhceARcWMRYVFBcWBgcGBwYHBgcGIicuAycmJyY+ATc2FhcUFhUUFxY3Njc+Azc2JicmBw4BBwYnLgQnJicmNjc2qA0VDQwOBAUKCQgLDCsmCwgKCAIcHBoQFhEKCw0ECwQIFwQDAwMOFSURBg8kBy8IJBQJDAUKBBcFBQ4HDhIKAwoXCQk1EwQXDA4BAQoDBh4eJCcTEAUMAwcGBQ0GCjMrIwHBAgQCBgYKDAEUEQIEBA4oCw0TAgIEAg4ICAUCAgUCBBUIBwsDCQw5SyIRBQ4QAwsCCgUIBg0FGxwfEgQBAgYPAxAECxUJAQgQBBUMFwsIPQQIDxAJAwIEAQMBAwUGDw8zThYRAAABABH/9AFMAl4AXQAAEjQ2MxYXFhcWBwYHBg8BMzIXFhUUFhQjBw4BKwEiBwYHBhUUFxYXFjY/ARcWFxYHBgcOAjUGBwYnLgEnJicmNzY3Njc2JgcGJyYnJjc2Nz4BMjY3Njc+ATc2NzY0kwkBCgsWAwMKBgcBAgIlRBALAwMCAgsFPzsBAQoCIwkMDycKCQ4WCAUBAQ4DEg8HCD0uEA8MCg4PBQMBAgIEDBEUCQoCBgQFCgM0CgIDAwwBBAEEBwMCTwQLAgIEBgpFLRgDCggHAxIBDgsGBQoDAlIMH2IiCQMDCwoJAQMJBREWDQILCAEBAxMdCw4RDy86NSQRGwoPBQMBBgYIGQkLAwEHBRYQNgULBxgOCAQAAQAKAAQBfAGmAFEAAAE+ARcWFxYXFhQHBgcGBwYHIgcOAQcGJyYnJjc+Ajc+ATc2NTQ2Nz4BFRQ3NhceAQcGFAcGBwYHBhYXFhceARcyNz4BNzY3NjQnJicmJyY3NgEuDwURCA0PAwIBAQQIFhkHAwMJOxwtHk4WGQ4BAwQEAgYBAxADBQYDAxUTBwMCBA4CBQQCAwIFDQcLGTYhGhUEBAECAgECAQ4FAwIBmwkCAQIbIiMaXAYEGDcdHwIDCBcGCgUNRlBHByEZBQMaAwYHBSYEBQYBAQIDCQcKDAcOCywWMwgCRw4cDwcDARMOIB8bAQROAwIZGiAKCAcAAQAT/+0BcAGqAEkAABMUFhUUFxYXFh8BNz4CNzY3Njc+AjU2PwE2Fx4BFxYHBgcOAQcGFQ4BBwYjBicuAScuAScmJy4FJyY3Njc2FRQXFhQWVAgFEA0QFQUTBAoJAQgBByIFDQkGBwoKAgUgAQcIBRoaFSIbARUECw0QCggVAQIOAiADAwUHBgsHAgIECRIZAQIGAXgCEQMGDSo4QEERJAkWFQISAgtqESQZAQwHCQEBAhMCCBIKTlE0RDYCBB4EBwUFBBYGCSMGZxENGBwWJiASFwUMAQIJAwICBAkAAAABABQAAAGrAdgAcAAAATYXFjMyFxYXFgYXFgYVFAcOAQcGFRQPASMiNTQjIicmNTQnJicmBwYHBicmNzYnLgEnNCcmPQE3PgEzMhYVFBcWFx4CFxYVFhcWPgE3Njc0Nz4BFxYXHgEUFhUeAhcWFxYyNzY3Njc0Njc2JyY2AWMRDgMDBAwOAwIDAQEGFAYfDgoSEhEaAwgNGwMCDAEJHiYoFwgCAQMFDAEDAgUFCQ0QDAEEBQECAQEEAwYBBQcDEgwKChIQDgUBCAUBBAcDCQoHBQgXEgoBBQEBBAQEAccRBwIICR4LEAoEiAQeRRY+DgoCAwsMBgEPHwgDBgMlARE+AwMoDQIBAwU/EwgYFEdMCgoFCAsIAQRhCiQWBRYOKQYBBgwGLCMBEA8IAwIKAQkGDgUOERQKJBINCBk8Ii8ZMx8vBAUmAAAAAQASAA8B2AHwAGwAAAE2FhUUFxYXFgYHBgcOARcWFxYXFhcWFx4BBhUGIyIGLgInJiciLgEnLgEnLgEHDgIHDgEHDgEHDgEnLgE3Njc+ATc2Nz4BPwInJiMiJicmNTQnJjU0NhcWFx4BFx4BMzI3Njc2Nz4BNzYBbwYbCBQBARwJCSEjCQIGGAkSLScDDwMBCQYIAhAECQcCAwQCGBgBDjUMBgoFAQMDAQZAAwYwCBYWEBYIBwwQCDIJDQYDIgIKBwkIBAJIDgwHBx4HCQsEDAgVUgIFPRICCAEBDwIDAe4CBAQDBQ0QCCcJCistDQMKDgYSLUcFFwgFEQENCwIBAgIDAicqARM1CAQKBAEDAwEJRwQHOgocCAsPEQ0YEAc+Cg0JBCYCCggKCkgPDgECCgsICR4BAQkDBwgVTFEWAwkHBg8CBwAAAAEAFP9WAZQBZAB4AAAFIgYjIgcOASMiJyYvASImNC4BNz4BFzI2MzcyFxYXFhcWNzY0NzY3Nj8BBwYHBgcGBwYmJyYnJjU0JyY3Njc2NTY/ATYzMhcWBwYXFhcWFxY2NzY3NjU0NzY0PwE0NjMyNzYXHgEHBhcWFxYHBgcGBwYVFAYPARYGAS0BEAECAgEmHSYrPBoJAgkDAQECCgEBBAICBx8NMR4mHgggBxoSAQIBByk9EA8IAgkoCRcIHgIBAQIHAQUEAQYMEQcJBQcEAggHDQouESQSFQQEAwMOBggDCgwGAgICAgIKDQkHBQIHAxIIBwEilQoCAQgOFBcHEQYLBgYECgEBARUJFgoBAQMQBAkiWQQiIAo1HwgCAgIFBQUMDSsvDQgIMzorBAYaBAEGBwlDQEQiFBAEAhINHBodCQEODFoPDwQJAQMLBQoREgwLQk9HOwUCGAcEBScLCwIgAAAAAQAUAAMBeQGCAI8AABM/ATQzMj8BKgEGIyIHIgYHBjU0Jj4BNDI3NjI3NhYzMjc2FRQzMhYyFRQWFBYHBhUUBiMiBiMiBwYPARQGBwYHDgMPATcyNjMyNhczOgEzFhceARcWMxYXHgEGFRQHBicuAiMiJyYGBw4BBwYjIg4BJyYGFCImJyYnJicmPwE0NzY1NzQ/AjY/ATI24QcIAQMJCQgaIgEODANOCzMEAQgEAgEaAgUyAUQIoAMCBAIGBAICDwIBEQECIhYVBzMGFw8FBgIGBQoLAiAIBSMIBAM1AxMDAhYBCAcMCAMBAgkNIQQMBwEHAgQ1DwQtBwYGAQ4JAwEmBgoFDAQEAgcFEyEzHwQdBAQEBQEJARoJCQIJCQEBAQIHGAMSDQQCAgIBAgEEBA4CCQIBCAQEAgQCAxERIhYYBwE7BhcQBgUCBQQKAgQGAQMCAQMBBAEJAwYMAw0GCAYBAgIBAgECAQICAgICAQEGAgIBBQYGBBASIgEhMwEiAQQhBQQEBAoAAAAAAQAT/5cA+QKLAI4AABIyNjMyNz4BJy4BJyYnLgEnJjc2NTQyNDc+ATc2NzYzMjYzNhcWFRQHBgcGBwYPARceARceATMyFx4BBwYHDgEUFxYVFxYHBgcGBwYHDgEVBwYXFjc2MzI3Nh8CFgcGIyIPAQ4BBwYnJicmIyIuAScuATU0Jy4BNzY3Njc2PwEnJgcGJy4BJzQmNSY2NzIrBBIDBgoIAwEBEAEDDw0IBAEBAgQOAxcEBQcbFgcSAhQaDwkHHhwIGAcFBAUbBQIKAQIDAwEDAQIBCQYIBg4GBgMCBAkMAhEIFR8ICgYMBgYTEgwHCQYFDgQCAgMHAw0VIwkCAgMMDQILGQMFCgEGDR8HCAMDBQcRBhgQCAEFAQkFAgFDCAgGBAYIHwMIGxceIRMBAgcGBhoFFgICBRUGAwgGDiALBwMDBg8NCRIYKRIFEg4MLQIBBwQPBwkIARAiHx4EBAwfDgIjAg4hHAcBAQIHCQYSGwoKAgEBAwEGAQIJAggKAQcVAwIDBTYKJxY2FBcMEAoPBAIHBAcLBA4GCBEBAAABABMABQB1AjUAIQAAEzI2MzIWFxYVFBYVFBYXHgEHDgEjIiYnJicmJyYnLgE3NisBEAYQCwIDBQcEAgECBA8XCwkHBQQHAwICAQMBAwIzAgUJD1Qxdyw3dwgFFwcMBgULCRYngGgCAaQJPQABABL/kQEKApYAegAAEzI+ATc2FxYXFhcWMzIeARcWFxYHBiMiFRQHBhUUFxYzHgEXFhcUFxYHBgcGBwYHBhceAR8BFBcWFxYHBhUUBiMiFRQGBwYHDgEmIy4BNz4BNzYXFjc2Nz4BJyYnJjU0JyY3Njc2NDYnLgE1NDc2Nz4BJyYHBicmNTQ2SQMEBQMHGxILHwwHAgEDBQITAwQNEwcDChEhFgQEBgQMAQMGCAEJGQQaAgQRAQUBAQMKAgMWBAsCAxsOCQ4JBhEKIx0CAQwECR0TDxALBAgCBQcQAwgCAwUEBg4OCRASEQ4DEBUVDgkWDgKPAgIBAgICAwgOBwQIAxghKSg2AgMPHAkMCwgBBQIFBgEDBB8IBAsBBAoSJgQKAwMDAxA7RisIAQIPAwcYBQMEAwEDARESCiICBQYFBQUfDTYLJg0hBgUJIhUQBwUIBg4NGBokFBgiGzAPDgMCBg4hCg4AAAABABQBAgIpAbcASgAAARQWFRQXFgcUBgcVBw4BBwYHDgEnJicmMSYnJicmBwYHBgcOAiInJjU0NzY1NDY3PgE3Njc2MzIXFjMWFx4BNz4BJyY3NhY3NhYCGAoEAwICAQEBBAIHBQ1ZHzEOBgkLNw4fKg4cHQYECgkODw8OBCoJAyoDBRIWFiYfDgI6DhMSFA4jAQEUAwkDBh4BrAEEAQIEBBMFCgMDAgEEAgkIFTcDBQkEBgckBg8XBxwbAwIJBBARCQ8OAgMCKwYCGgICBwgPByYICwIIBx8FCxEDAQIFBQAAAAABABT/WgBvAqsARgAAEzQ3NDc2NzYzMhYVFBcWFxYHBhcWFAcGBxYXFhUUFxYHBgcOAScuATc2JyY2NzY3NjU0NhcWMycmIiY1JyY3NicmNDc2NzYcAgcGEwoMBQwDAgMCBQUBAgUHFRYJBgIBAwIGARISHQkDAgQCBAMEAQIPBwMBBQgGDwQDAQEDAgICAgMCdwsUBAcHAgEQBggDBDc4OTUwRBoIDgIHEgx1UywsIhoaBggDBRItMkQakhIXAQIDBwoBAQQEBwEGAxIRCAdsBQQbJQAAAAACABMARwHXAk4AUAB3AAATMjYzMjc2Nz4BNzY3MiYnJjY3Njc2MhcWHwEHFAcVFhcWFxY3NhcWFRYHBgcOAScuASMnBwYXFhUGIyIHBiMiBicmJyY0JyY9AQcGJyYnLgEXNhYXHgEXFgYHBgcGJyYjIgcGBwYjIicmJy4DNDY3PgE3Njc2GQEEAgQECBcdJhwgAQICAgMGEA8GAxACBgcOAQIBBAUmQSsKBQgIAgMSDU8bCBkDDAIDCAMCBQIEBgwCDAMMBwUFCy46IxgKAwLnC4QeHQ0EAgECAw0DJ10fFhU0TSgGCQkGBgEDAQECAgQJERklNQGVBgMHAwQIAgIBUQ0UDAkKAgICCgwWHx0QFgcBAQQHBwEFCAMlCQsGBAIDAQQBITISBwYNBwsGAQIEAwQHD0MyAgMDAQwEHeIBAgEBBAcEJgoOAwECAwEBEQkGBBEECAMFAwUECAUGCAcKAAAAAAQAFP/aAe4DRwAqAEEAoACxAAAANhYXFhceARcWBxQHBhUUBgcOAQciBwYHBicuAScuAT8BNjc+ATc2NTQ3FyYjBgcGJyYHBhUUFhQeAhc3PgE3NgMVBw4BBw4BBwYHBhUUBw4BJyYnJjU0Nz4BNzY3PgI1Njc2NzYjIj8BPgIzNhcWFxYzMhYXFhcWFx4BFCMiBiMiBg8BDgEnJiMuAScmJyY3NjQnJicmJwcGBw4BIzcmIyIGBwYHBjM+AjU0JyYBAhQhBCACBBYCBwIFAyMKAiMDBgIBGScjCBwEAwkBAgQaBSEFBhk4BAMWAwEKCAoSAQIBBQERFRIIDpwBAQQCAQsCCAMFCwMuCgYGBQUDBQIHBgIYCAIoGxQKAgUUBAMNCwgsCSUKBgQDJwksFBoHAQIBAgMDAQMCAgMVAQkNBA0ECAUFAgICBwYBBCcpKBUyE24HBwQVCBUbBAIHWFAWHQNDBAECEgIEKAgcDRIMBQYKNwUBGgECAQgKEAQfCggjAhQ5IQcaAQEDAghWCAMCAQICCxMlBggFBAIFAQcIDxAb/fwPBgYXCglADSwKDwIPCQIBAgIHBx4cHBAmDScgD1kQBxdSNxMKDwMCDAYCBA8KBi0PRFt3TQ4oHh8HBAQDDAEDAQkBAg0MDAtEDSk2CwwHBwIBBvsGFQ0eVBADCQgBEiw5AAACABH/xwG1A1EAIACEAAAANhYXFgcGBw4BBwYjIgYHDgEHBgcOASciJyY1NDY3NjcHNjMyFhcWFxYHDgEjIg4EByIOARQVFBYPATYXFhceAQcOAQcGJyYPARUUFiIXFgcUNjc+ATc2Nz4BFxYVFBcWBgcGIyIOAQcGIwYnJicmNjc2JyY3Nj0BNDY3PgM3NgFDGAsNFgEBGQMaBxUDATQEBCIDBwsKDBEEEBAFDyxaHQ5CMRAKBwEBCAoTIxsqGyMQLgwDAwIGAQFdBQEJDhkHAgsCBxcZOhIIBAQGAhYGC1gPDiMXQAYTAgMLCgsSFEVVECUCYBcOBAIDAwMDCAUFCRgTEwgWDUsDSwYEDBYMFxYDFwcVLwUGHwICCggDAhQSDQgIEC5P9AIEDQoTFQoMBgIBBQMIAgEDAwULBjIyDgkBAgIiEQMQBhADAggCREMEBAYMAQEBAQ0CAQUDAQMJFQsICBcGBggNAgUMDQkNBiYFCAgXp4lJHBcNCggGAQICDQAAAwAS/8MB0gM6ACkAYACAAAATNhcWMhcWFx4BFxYXFhUUMzIXFgcOAQcGIyImJyYGJicmJyYnJjY3PgETNjIXFhcWFx4BFx4CFxYHDgQHDgEHBicuAScmIyInLgEnLgE3Njc2JyY+Ajc2NzY3NhcmJyYGBwYHBhYXFhcWMzI3Njc+Azc2NzYnLgEnJncODAgMCAgLCEQBIiYOAwcEAgQDEQMLEAcsBQQCJQ0PLyUHBgEHBgZaBy8FBQ4sHyQmDAcFAwEICAEDAgQGBRRGOkouAhcEAwUEDh0wCgQFAgUFAgEBDAQIAwoJKkQNXhAvEiUUGwgGExgLIxcVGREWCQgKAwcBBgYJFgcNDg8DNgQGBAgGBwRAARoKBAMCIBEFBAoCCxAEAgIZCwwuJA4PCQ8MBv7uBAQDAgQPEi4oFxcgCzVSCigPHBcNNzgHCRQBCAQFCRJOKw5EETQZDgECMwYWAw0UVhUEagsDAiQpNUszXhsODAgDBAgGEAYcBBNIa00WDwECAAMAEf/RAbEC/QAXACkAfgAAATcXHgEXHgIOAgcOAQcGBwYmJyY3Nic2MzIWFxYVFAcGBwYmJyY1NAQ0PgE3NhcWFxYVBgcGBwYHDgEjIgYjIg4BBwYnLgMnJicuATU0JyYnJicuAScmNzY3NjU0Njc2Fx4BFxYXFhcWFxYzMjc+AScmNjc2NzYnJjY3ASsREB0OBgMDAQEBAwECEgkVAhcuBwsGEKwXCgsNDQ8EAR8cGBQPAS8LDQIIDgkMBgEJBw4HDAokBQMZAgEHCgMyLw0OBQoFDgMGHggOCwYDAw0DBg4CAgQLBAYWEg0BAwEBEBAmDxY2HAUKAQEGAgIDAQQECBEC9QgECAgKBQkHCwUNAwkYBQwBCBETGxAnBREJEBILCQgCGxcBGRILFaEEAgMCBQgFHhBptUk5IhEQDiIMAgIBCwoDAwIHAwcCAyADAgwVIxEFBlkoU5wVAwYEBRQDBAQDBwkOkqw9PhQHJgYgAwIvBgmqdxQVEgYAAwAUACsB2AH5AB4APQBeAAATNjMyHgIVFgcGJzQPAQYHJgYuAicmNTQ2NzY1NBc2FhcWFxYVFAcOASMGIwYHBicuAS8BNzYyNTQ3NjcHNhcWFxYHBhUUBiMiBwYnJiMiNTQnLgInJjY1NDY3NuwQAgYPAhUECA0CCQIHDwwLCwMJAwcQCASaAjgOEQYFAwIMAxjLbyUHGQ0KAQEIBwYpFoQJGA4LCw8NBg8BAwUQFwcFAgMEBQQBBAQOBAYB9AUHBhABDBEZAgQNAwsBAQMHAwsDCAsMHgICAQSiAQECAgYGExIIBQ0CAQQBAwESFg4HBwEEBAICpQUIBxYaDAYBAhYFDQwEAgECAQcRAgMYAgUdAgMAAgAUAa0BJQLZAEAAggAAEiImIyInJjM0JyY3PgQ3NhcWBxQXHgMXFhUUHgIfAh4BHQEUIgcGJyIvAS4BJyY3Ni4BJy4BJyYjIic2FxYXFBcVMzYWFxYzMgcUFxYUFhQWFRQWFxYVFAcGIyIGIyIVFCYVFAYuAjU0IyInNCc0JyYnLgE1NCYnJjU0uwIMAgQEAQEDCAoCAwICBQQHDhkBBwUHBBUCAwMEBAECAgECBAQOGAEDBAsIAgIBAQMGAQIEAgICAaUGIhEBAQECEAYJAwQCFAYIBwQBBQIBBgMJBAYEEQIGBQMOAgIEBQMBESMEBAKHDAcDAwcTCwIFAwQDAQIIDAMCAwIMBB4CAwIBBwoJAwMGBg0BKQ0GFgsCAQIPFBYBAgsOAwYDBgkrAwMBBAEBAQINCg4GAyAKDAgEEAIFDAgZBAYSFAYCAQEBAgICAwMCAyoGEAMEBRYFIAQBIwIDDiIAAAAAAgATACwCRgJaAD4AgQAAATYWFx4BBwYWBgcGBwYVFhcWFxYzMhcWBwYVFAYjIhUUBwYmJyYnJicuAjc0Njc2MzI3Njc2NzYzMjc2NzYXFAYVFAcOAQcOAQcGDwEXFhUUHgEXFhceAQcGFgYHBicmJyYnJicuASMiJy4BNDY1NDc+ATM2Nz4BNzY3NjM2FhcWASwMDRAOAgwLAkMWNS8YASlEOQ0ECgwNBwQNBQYGEjMwIzEtBAEMEwESKiwCAw4yGggLBgMCDw4KCP0FBgcnBQsYCgw0ExAPLDYFGgoiEwYEBggGIQ8hPQcgNAkDIwMBCwYEAgUEEgINEBQsJDgGAggODw8OAlQGBxEQDQ0MAkQUMCkVBAUfNUcQDhERCgUHDwIDAggkNignIwsDEDEGBiAnKA4vFAYLBg8OBgNZBQcDBgMEIQMJFggKMBAQDwMFIykFFwcbGQkFChADEwYNOgcYJRIGIhQKCwYRCBUGBhUKDhEhIDICAQEIEA8AAAAAAgAQADICRAJYAD8AgwAAATYyHgEXFhcWMhcWFxYXFjMyFx4BFRYOAQcGBwYHBgcGIyI1NCImNTQnJjc2MzI3Njc2NzQnJicuATc2JjY3Ngc0JjU0NzY3NhceARceAh8BMhYXFhUUFhQOAQcGIyIGBwYHBgcGBwYnLgE3NicmNjc+AzU0PwEnJicuAScuAScmARYFCQYLAgoODwQGCAwaMg4DAiwqEgETDAEELTEjFxYmFBUKDQQHDQwJBA43RikBGBZOFkMBAhgBDg/aBA4PBgcQDAwwHBoaEx4CEgQFAgEEBQsBAyMDCTUcCj0hECEGBwMDBQYUIg4qLCYQEBMbJgoYCwYlBwcCVQMDBwEGDg8GCAkULw4oJyAGBjEQAwsjJygaFiQHAg8HBQoREQ4RRDcfBQQVE0YURAEBGA4PEWoDBwUJDxEDBAEBCCsZFRUQGBUGBhQHDwUJCQgUIgYRJhUKOg0GEwMQBQQGCRkbCyUeIgQDEA8RGSAIFgkEIAQDAAAAAAMAFP/oAcADSABbAGUAhQAAADIWMzIXFgcOAQcGFRQGBwYjIg8BFxYHDgEiBwYnLgE1Jjc2JyY3Ni8BBwYUDgIHBgcGJy4BNz4CPwE2PwE1NDc2NDc+AzI2NzYXFhUUMzIfATc2Fx4BFwcmBxU3PgE3NiYDNhYVFBYVFjMyFgYHBgcGIicmJzQuATUmNjc2JyY+AQF2BggCAwwrCAEWBAI3CyEEBhMMAgIBAQwEDhAkBRMGBwoHAwIQBAIMDQ4NFwEKCg4fEgEQDgYOBBMXLBUCAQQCAwIGAwwEJgcGAgMEBA0RHAUYATQIIQgUIQMCD2wNJAsCAQIBAwMKHRARERYFAgICBQQCAQIVGwLfChVPUAo3AgIDBTgGESMXFh8cJAwGBwUBDwMYHSMuExJfZR4NCwwUDxYCDAMEFQwYGxUGGwQTGhoMCgoCAUQIBAQDAgEBBQYGAgQiIAEBBQEMA1IIBbADCDAZFDz95AIPCAMGAgQPFAcZEQoJDRQBBAUBBRkEBAECERIAAgAT/8AB7QMQACsAlQAAAT4CMzIWMzIXHgEHBgcOASIHBiMmBwYmJyYjIicmNTQ2NzY3NjMyNzYXFhc2HgEXHgEHFA4BIyIGJyYHBgcGFBcWHwE3Njc2Fx4BFx4CBgcGFRQHBicmJyYnBg8BNzY3NjcyFRQfAQYWFxYXFgcGBwYvAQcOAQcOASMiJyY1NCcmNz4BNC4BNzQ3Njc+ATM2Nz4CAVkIEAgDAQUBAhEOAwgDBAISCiQKLnEbFzgFAwQDBwYOExEIBAwIHiVMME4KBwsECgUBBBgHAh0CBSLMCQQDAgIBCAcrSAoCEQIBBgICBAUPGQsFJywTAQEBDicSlT0yCgoBCQkDAgIWCAQOGA0hEGAMFIwXGAoJAwIBAQECAgEGBxINNgqOGRUwGQMJAgQBARURDwwFCAQLCQICBAQCBQMLCxESDgICBQMEBAICqQEBBgECDxkeCAsEAwIBCgIBDT0yCwoEBQECCQIIBgMOBw4HCgYDCA0KBQEBBDU/cwIFAxkBBQEDBQEJBgIPKQYCBAwLBgIBDgECFgYFAwcSFEktiGMCwwcCCAcBARAJAQECAQAAAAAEABX/4QIGA1cAIwA9AH8ArAAAATYWFxYHBgcGFAYHDgEjIgcGBwYnJjU0NzY1NDY/ATYzMjc2BzY3MhYXFgcGBwYHDgIHDgEnLgE3Njc+ARc2FxYXHgEfARYXFgYHBhUUBgcOAQcGFRQGBw4BByIHBiInIiYnJicmNTQnJicmNTQ3Njc2NzY3PgE3NjMyNzYzMhcnBgcOAScmIicmBw4BBw4BFRQGFhcWFx4BFxY3Njc+BDc2NCYnLgEnJgGxChQRCAEBCwgdBwQgBgEKEQ8IDRwHByEFDAcCARwd2wYRAh8DCQ0GFhESBgcLBQ4PEBAGBQkWAzxOBRhiKwsaAgUIDAIEBAMQAwMLAwQmChpMEwIPClIFAREFJicWBA0PCQYZCQQLCg4KNwscDw0HCxEJMg4FBgkNDAcKBwoFES8OChMEBAMECwwdHg4TRSwFDQYIBwQSFQ0EFggPA1MECREICxEMCggcBAIkChMDAQkTDwsICQEDKAMMBxobDQUFFgQKGwwWDxgJCAgFDgEMCxEQFhgDPeADBRY4Dz0RFyhaEU8HBgQFLAQDEwMGAgMlCBMkAwUDAwgCDygYAQIIGi0fIUocawoEGBcTEDkFDwYKZwYGBwsDBgQDBQMJQSEXVBQLBEcNDhcZGQoFAgklBAoGCAwIJWSGHQoWAwYAAgASAZwBIQLKADsAkwAAEzQ2NTQ3NjQ3NhcWNzIeARcWFRYjIhQiFRQGIyIHDgEVFAYVBhUUBwYnLgE2NzY1MDciPgEiNiI+ATc2Fw8BBg8BFAcGFRQHBiMiBicmFRQnJicmIyI1NCYnJjU0Nz4BNz4BNz4BNzY1NDY3PgM3NjM3PgUzMhcWFRQWNxcVFA4BFAcOAgcOAQcGFRQGQQgPAxIdAwIBAQYHAQEBAQIGDAMMDQEIBQgWEAgSCAkGAwQBAwMCBgIFCAIDoQUBAQECAQwHBwIBBwECEQsFBAIDDAEBAQMIBAICAwIFAwUUAQEDAwQCCgUBAgQECQYKBQkODgEBAhAIAwIIBwECAgMEBwKaAgYBBQsDBAYKBgIBCw8FAwQFBgIDDyYCEwMCBgEoAxAHBQIDKiURBwMJBQUICw0CA3YMAwICAwICHhoWCAkGAQICBwIBBQQDAgwRCQkCAgclCQQMBQUNBwoDAiEFAgUEBQIQAQEEBAkFBQ8OAwECAQQCBh0EBAIBDBABAwYDBAMCDAACABP/9ALZAdYAgwCiAAABHgEyFhceARQOAQcOAScmNSYjIicuASMiBwYHDgQHBhcWFx4BFxY2NzY3Nh8BNCcmNjc+ATc0Njc+ATc+BDM2FxYXHgEUFxYXFgYHBgcOAQcGBwYnBw4BIwYHBicmJyYvAQ8BDgEHBgcGJicmJyYnLgEnNC4BNSY3Njc2NzYFIicmBgcGBwYWFxYyNzY3Njc+AScuAScmFAYiJy4BAR8RFAYYBgQDAQMBAhsHDwICBBELEBIZGxMSAw4GCgcDEAMCCgQZBxM+Fx4WEBIMAQUBBgEMAQQBCjwWAwsDCgsJRgw3IAcZBggFBAUHDAMBCBkhFTkBBwcNARcHEyM5GAEBBQECAgUDH1kOMwUCDisaEBkCAQIDAgcgERhdATwEAQEHDC4QCQ8UByQVNyQSBg4KBwgpGAkYCAMCDQGwBg4cCwYIBwQJBAcTBwsBBBELBg8LFQQQCA4OCisfHhUIGQQIAQcJEQsOCQQEDlAOAzADAQsCIFMKAQYBAwEDAw4lCCQEDhIZE0AOGgMBEBwkDiYBAgMFBgIGBw01AgIIAQIDBgMlDgIBAgEFDBwRMxECBwoEFBZLMBoYXXgDAgUNMU0sUA4FCRYqFgYQOhsdMQMBBhAFBAsAAwAP//UDGQGlAHsAmwC3AAABPgEXFhcWFx4BFxYHBgcGBwYjIhUOAQcGJyYjIiYnJicmJyY/AQcGBwYVFAcOAQciBgcjBw4CJyYGJicmIyInJicmJyY2NzY1NDc2NzI+ATc2NzYWFxYXHgEzMhcWFxYzMh4BHwEeARcUFhUWDwE2NzY3Njc+ATM3PgEFNCYHBgcGBwYXHgEyNzY3Nj8BNTQnJicmIyIHBi8BJgUmBw4BBwYXFhcWMzI3Njc2NTQnLgEnJicmBwYCGRkxFw0FAh4gOAsKBwsNFSs1CgMBKAw6CQMDDTkFAgMOCwYDAgYXDgUPFkYQAgQCAggIFBQEBQokAwYBBhoOCgYIDQ4HAxkVDgEFCQQTGAgZAgEICA8JFSAZEQkDAQoKBQQFEQEEAQEBAgIKFQ8bCSECAgII/qkLASQbDAUHEQoZLhIlJxsHCAYQHA4CAQYJCwQmAWwGCxIqBAQDBiMLFzYvMA0EGgMUAxIcExEOAZMOBBINDAQUFUIjHx4tFSIbIAECCwEICQMiCwYDESYWKBELMQ8FAgQNFSsCAQECAgUCAgMECgMEGg4VDBQwWBAEBQ4rJQoEBwINBAICAgECAQoOCw8JCg0FBgUmBgQTCBMKDwUIKCgdIQwhAQEFPQIHAQo9GyY3IRQQBgwnGw8RGRYMHxEJBAgLBAgLAwwTUhwWFTEPBR4fJw4KFiUFEAMSDgkCAgAAAAEAEwAIAZoCZAB0AAABNhcWMzIWFxYGBwYHBgcGDwEVDgEVDgEHBgcGBw4BFxY3NjMyFxYyFx4CFxYzMhYPASYHBgcGJyYnJiIHBgciBgcGJyYGDwEiJyYjIicmNzY3PgI3NhcWNz4BNz4BNzYvASMiJicmNj8BMzI2NzYzMjc2AWQWAQICBRMCAQcDBQQGFSk2CwEFAQQBAgIBAwIBAgEEDB8nDQUOAwIKBgIFAQQCAwcBAwoOCQgIBgUqAgUkAjoOFgECCQYGOBEIAQMDBQEBBQMJDAQKECQQEggBBAgCCwQCJjUfAgEFDAgqKW8CARIeFAgCXgYBAhwHBBYCAgYHBQoCASYdXgoUIyElPiUDAgwCAQIEAwEDAgUFBQgeBQ8BAwoBAQcIAgEBAwEFAQIBAQEBAQkEBQYUEwYDAwEBAwEDAQEFCCqWHnYvEQ8aDQgIBgcCAQkEAAAAAAIAEwAUA3ECagDjAQEAABMyNjM3PgEzFjc2NzYXFhceARcWMzIVFBcWBhQGFA4BBw4BJyYGBw4BByIeARUWFx4BMzI3NhcWBwYXFgYjIgcOAScmJyYHBicVFB8BNz4CMz4BNzY3Njc2FhcWNzY/ATY3NjU0Njc2NzY3PgEzMjYyNjMyNzYXHgEfAh4BFxYXFhUUFxYHHAIGHQEOAQcGBwYnJiMiJjc2JicuAScmIyIGIwYHBgcOAQcGIyIHDgEHFAcGBwYHBiYHBicmBwYHDgIHBicmNTQmNS4CJyY1JicuAycmNzY3NjQ3Njc2BSYHBgcGDwEyBg8BPgE3PgE3Mjc2MzI1NCcmJy4BWAEgAQsLFQECAw5OKDAUAQEIAQIBAgMDBAkEBgECFwUVUycORgMBBQYEAQICBQkMWCURCgQCAQcDAgUFHAIEBA89BwoHAQoCBgQBB0gODAEKRg4yBQIBAQMBCxQGDAEBCBkdCRwDARAEDQQHAgYgBhoKCQgIEwUwIx0CDAEBARMEAwYLCwQDCAkCAgECAQoBAgIBDQEDImcdBCQFCgIDDAoDAgQLAQUNBTIGCx0eUAktCScdByIJCwwCAwIBCAYDAgEBAwUJAQEKBQUECxcCPQ4OEQ8YAxABAwIGCBsIBi4OEwYEKisSDBYHKQI4DQMEBgIDCwkDBgIDAQQDBAgGBgEMAgYEAwMBAwQCBQcKBBsDFhoBHgwfCAMQHw4QBgMDCgUGAQQEAgMKAQIYjBEFBAECAgQRAgIBBwMBCQQBBAQfBGRHFgECJQIBFkErDR4LCAEDCQEPBgcHBxQFM1VIGQYGH28LFhENBAUEEAEBAwgLBCANCmsPBzYIFw0DAQMHAggDBAQDBRIFGk0KNgcDBgMGBAMLAQwCDAgBBwgLDQIRAghIVwx8Aj4KBwsECAYMCA8IBQQCAQkSKgoJDBooESUJBxABBgEBBgEDAgEDIBYdCiYAAAACABQAEALjAlUAqgDQAAAAMhYzMhYXFhcWFxYHDgEHDgEHBhUUIyIHDgEHBgciBwYmIyInLgEnLgEiFAYVBgcGBwYHDgEHBiYvASYnJjQnLgE1NCcmJyY0Nz4BNzY3PgEzMjc+ATc2FxYXFhceARQHDgEnJi8BNCY1LgEjIgcOAQcGFRQXHgUXFh8BMzI3NjMyNjM2FxY3NicmJyYnJjY3Njc2NTQ+ATc2Nz4BMjc+ARcWFxYXFgcmIyIGBwYHBgcGFx4BNzY3Njc2NTQ3NicmJyYPAQYnLgIiBwYCZgIUAQMeCBwICAoHAwEFAQIQBQYBAgkLMQ87DwQkBwwEFgUBIAEBFQIIAgoQHAcCAykMGUoHChwgEAUJFwMGAwECAwoCDDMIKAYDAQIdBRYZDx8HBwQPDwQVBQECAhsBHwQQEw8jBxMMAgYCBQcKCBIQESJDHwcFBAcEBwkHAQEECg4MAgICAgwDBwwEAwsOBx0EBAwyEhgSEQgKYQsCARgFGwMBCBgNDEg4QhYDBAMCBAsMFQ0DDhEEAggKBAQLAhENIQsoExUnHy0IDgUNJwUGAgMMEC8IIQIGAQMHARABAhEEDQIQCg8KAgICCQECCQUEDCAQBAcMMQcIBgwiDUkJES0IOU0MJQECCQEDCAUZBQoGKwgPBAgDAQECAR4BBBIVED0ZQD0wIwYQBgsICwgSBgYWBQcBBgUBAQMIKTENC0IMPAkVBQQcBAYVFgshBA0TBAYSEAIENg0bBygPAxpOSEElHyY7CQQDAwEMHSorGxIDBQUKBQQUAgYAAAAAAgARAAwC4wJqAO8BEQAAARQGFAcGJyYnJjYnJjU0JgcGBw4BBwYXFhcWNzY3PgEVNjMyNzYyHwE3NjU0NzYmJyY1NDc2NzY3Njc2MzI1PgEXFjMyFhcWFx4BFzIWMzIWNzIeATIWHwEeARceAgcGHAEGBwYHBhUUBgcGBwYHFx4CMzIWFxYXHgEXHgEHFx4BIyIXFgcOAQ8BJyY1NCcuAScuAScuAScHBhceAhUWBwYjIgcGJyYnJiMiBwYVFAYHIgcOAQcOASMOASciLgEjIiY1Jy4BJy4BJyY3NjU0NzY3PgEzMj4BMzY3Njc2Fx4CFRQfARQXFhcWBwY3JgcGBwYHBhYXFgYVFz4CNz4BMzI3Njc2Nz4BJy4BJyYBMgYGCREJAwICAgIKCR4jGBYODQIBDiFWHw8FBg0EBwgHCgkJAgEBAQICAgYFEBEEGygVBAMBIQYMCwkjAgMFBBwDASECAQgBAQMEAgUDAwUMAQEDAQEBAQETDAQlCykMJAUHBBcUAQMzAwEFAhQBAREBAgMGAQICAQcFCxUOCAcGCRwfFEsPCBgBBAICAQICAggJCwEJFhMEAQEBAQELEwUBCgYjCAIPAgwpCQIIBQIFIQECBwMfLAgIBAIMFSsIIwMBDA0BBgEPHCgLAhALBgUCAQIBBgfxGQ0sGAUDAgICAwMBBwYREw0YBwIMNQwcDwQGAQMkFx0BsgIEAggJBQMEAwYDBBMPGgECKRwqKiY6IyFLEAYHAgMBBwgJCQgfES4iAgR8CAoOTQYFAwMHKRgNAQMDAQIMAwMBAg8BGQkBBQUIBQQEHQgFCwUKBAcCBQQyCwQBAyAGFwMLAQYEEQ8wBgMFAR4CASgBCgsjBgcHBgQBAQgGBQkVIisbEToJBBQCbj8CAQoMAQYKDgMMIAchHgISDAQXAgcFDgEBAgIBAgIBDQIBAgQCE0wsKxUMCh4mRToLJQgJAwEMAwILAgoKBAEHBwEIAxYSEBBnBQcXMQoDAyQLBhwMGwcEAwEBAwMQCBEZBhwGDSQNDwAAAwAR//0EpwJcAQYBNwE8AAABNhcWFxYVFBcWFRQGBwYmJyYnLgEnJicmBw4BBwYVFBceARcWFxYzMjc2MzI2OwE3NDY3NicmNDc2NTQmNzY3NjMyFhUUFxYfAh4BNTY3PgE3NjcXFhcWMzIXFgcGBw4BFxYXFhcWMzYWFxYHBgcGJyYnJicmNTQ3NicmIiMnBxQGBwYXFgYjIgYiJy4BJwcGDwIGDwEOASMiDgEjIg4BIyIHBiYnLgEvAS4BJyYnNCYnJj0BBwYHBhUUBgcGDwEOASMiBwYHDgEnJiMmJyYjLgE0Jy4BPwE2NzY3NjU0PwE+ATMyNzY3NhcWFxYzMjM2Fx4BFx4BDwE2Nz4BNzY3NjU0NjMFNCYjIgYHBgcGBwYXFhcWFx4BFxYyNzY3PgE3Njc+AScuATUuAScmBw4CIwciJyYXNicHFAJnHSYPDxkHBgUMEAQIDAIBCAIGDQYFFz4NDw4HCA8SCwwaLiQrBwMbAwUBAgEBAwQDBAQBAQQGGhQKAgcCAQYEsQEBAg4CAxIUFAECAgYGBxEXBAMDAgMBAQYFAgIIAQYNBgIFFBYWCgcDBgEDBJcEDgEBAQEFAQUDAhYQCg0GBAUDBgYEAwUEAiMEAg0NAQIVFAQOBA41EQodAgIBBQMcCwMBCQUCBQIPAgMKEgxGBQEECT8QNgstARYHBgICFQUTBw0QAQgdBwUODgEcAgEMGBYUDQoPCwIBAhQaL0QNBAIBAQEQAwsCCSAOLwT+jQsBAh8ICQ8jDw4DAQgEBQITBwgkFB0fEjILCAcQEwcBBgYjExMXAgUDAQIKCQ3jBAEBAkkTDgYPGQ4CDA0QDwgGBAIIDAQDBAQPCwQDDWgxNDY0JhMNDxIFBRASEysJOwslBgcjBQUeEU4bKQUJCgUDBA5sNAEBAQEKCxBvESsSAQIBAg0ObaQlGVEFChITDQwBCQQdBgIFCQECIg8mDzlaHAcBAQIsDD4MMhIEDRYGCQgOCgkHCAMDBAMDDwMFBQMBAgwKBRcDAwIGAyEoAQ0DITUiDgcKAgIBHwMDDxsQQgQKHAcIAw4MBwYBGgQKJXk4OAIUPggHAgEVFQMdChMEAgIBGBAEBw5ONRArDQ4KOgsbBh0xEwMEMlUCER4KCxo5QkIrFRUKDwYTAwQGCRYNMg8MBxJWIQYUARQnCAkKAQIBAQkNyAkLBgYAAAIAE//8A2ECTACsAPcAACUGBwYjIicqAQYHBgcGJyYjIicmJyY1Jjc2Nz4BNzY3Njc+ATMyNzY3Mj4BMzYVFBceAQcGFgcGFjc+ATc+ATcyNjc2NzYzMhYyFjMXHgEVFgcGFRQHBiMmBw4BBwYHDgEXFhUHNhcWMzIXFhcWMzIXFgcGFAcOAQcGJy4EJyYVFAcGFRYHBhUUFxY3NjM+ATc+ARYXFhcWBg8CBgcOAQcGIyInLgEnJicBFjsBMjc2FhceARceAgcGFRQGIyInJiMiJyYjIhUGDwEXFhUWMzY3NjIXFjMWFRQ3Njc1NicmNTQjIgYHDgEnJgcGIyIHBiMiFQGmDgcIEhkYFAgYDDIlSiQCBQwEARAFAQYHAQEHAQYBAQMBDAUDEiIsBx0oDLUHBQgCAQYCAgEDASIBAhoGAhAEW4gaGgILBAMBAQEDBgoEDQImIWcNFAooGw0EAQUBBxILKVgYDwYHAgMBAQUBBAELAwksCSsdIxgGAwEBAhQOAgISUQINLhw8HioDDAMFAwoMHFMyCkQONxkVCAUYBAID/tYKCB8WEBQ4AgEMAQsIAQIBDA8MBgMzMBkUBgMEDwMFBQEBIG0RhAEDBA4EFAcKBgMBAgoBAhAGNhwiAW8qDQUDMg4BAgIEAQUKEwcBFQ0RBgoZLzUOEjAPN1hlBQQHBwwBAQIIDAIDAgwEAgwDAwECAQgCAwsBBAEXBQEKCAQECAEKDAYBAgsBAgwCAgEFDAYEBBwgFQUDAgoFBQcMBRACBAIBDgECBAEFBAUIBQIFAQYHCyZmTgECBAIDEQIJAgYCBAIKDBAKCgwBBAoCCwMMBgMIBgMOAVsCAgICAwIEAQkCHQEBCAcOAwIFAwkydhkLCgcFCRMCAgMCCQgTY0sDhiQPGxkKAgQHAQUCAgcDNQAAAAEAFAABA2UCbgCNAAABMjYzMh4CFxYHBiMiBwYHDgEHBiMiBw4BIyIVFAcGFRQOAQcGBwYVFAYPAR4BFRYGFRYHBhUUBwYuASMiJyYnJjY3PgE3PgE3Nj0BIyImBw4BBwYHFxYHDgEVFAcOAgcGJicmNz4BNzYnNTQ3Bw4BJyIuATU0IyInJjU0NzY3Njc2FxY3NjM2NzY3NgMxBggHCAoEBAIDAwgFAQMCIAc4BwwNDggLXQ8BCAIEBgECBQQFAwIBAwEFAgYGDAISEwEIBQEDAgQCAgkBAwgCDxoRMhUaRA4MJQEBCAEEBgEECQkHLwUJBAYMAgkCAwwTMwQBEA4DAgcHBQc6MVKrHgYMDBOmERVdLAJsAgcHDwQIChEDAgYBBgECAgMLNFQgCgoGISsKGSAUBAMqExIBDwEDFAMHBAYBBgUBAgMSBgUCOQoIUQgSSRB6OhkEAgIJAQEGMjmPFhYTLCAGKxwFBAgFCw8Wnw1EeBoCDwECAQIEAwECBwgSEQUHAgIOHAwCAQIIAwQLBAAAAgAT/8QDAwJeAJ0A1wAAATIWMzIWFBYHDgIHBgcGBwYHBhcyHwEWFxYXFjIWFxYXFhceARcWFxYGBwYHDgEHDgIHBhQGJicmIiYjJicmBwYnJicmJyYjBgcOAgcOAgcGJicmJy4BNCcmJyY2NzQ2PwEyNzY3Njc2MzYXHgEHBhcWBw4BFxYXHgEXFjc2NzYXFjYmJyYnJicmNzYzMjc2NzY3NhcWFxYyFgcmBwYVFAcGFx4CFxYfARYXFhcWMzI3Njc2NzYnJicuAicmBgcGJyYxLgI3Mjc2NzY3PgEnLgECqgEXAgMLBwEBAgIBAwcIDCIQBgcBAgoNDCEEAgQSBAMEAwEBBAEEAwEVDyAXGB0dBgoHBwoeIQIEBhcBBgsMCgcICw0JAgMCBiEXEhYODxgTFxMrBQMUBhkFDwUDAQQDAQEBAgEGBhgMAgoFAQkBAQEBAwQEAgEEBhAQHVEuGyIGAQEBAQUDAQcCBAcOBQIHFSgqFkUVJRICFnU/Hh0FEgsEAwIBBgEBEQYNDwYWGAQZHSQeGAkILwYUDgsSPgYPCAQCBQECAgECIzQ0ERsEBTQCPhUVCBMGBBMOAgMOEQ0nCwQCAQIEBhAHAxIHBQQCBQIKAgoqEUAaORkbFQ8DCAIBAgIBAwECCwMLDAEBAwUSDiEaCgQDBAcEBAcEAwIFBQILAxoGCiArG6ckBTgZGRcRBQYCAgIMA1ECARsaAwR4OEERGBQBAxgOAQIKAlRcBx9DFFASBAkHEQoUBQIDAgwGCSsHBQYHAgMKMBQfJw9IaF0RCRcKBAIJHSQ6MB8dEAIIBAECAQIFDgYBGBMCAwkKESsOKwcJEwAAAgAT//wDUwJ2AO0BCgAAATYXHgQUFhQPARQGDwEUBicmJyYHDgEHDgQHBhYVBhcWNzYXFjEyFhcWFAcGFxYGIgcOAScmBwYnJgYHBgcGFwYHMzI3NjsBMhYfATY3NDU2Nz4BJyY2NTQ2NzY3Njc2NzYzMjU2MhYXFhcWMzIWFxYXHgEOAQcGFAYHBgcOAQcGKwEXFhcWFxYXHgEHBhUUBwYnJicmNTQmJyYnLgInLgEnLgEnJgcUBw4CBw4BBw4BBwYHBicmLwEGBwYHBiMiDgIHDgEHBgcOAQcGJyY1NCcmNz4CNzY3Njc0NzY3PgE3Njc2BSYHBiMiDwEXFB4BFRYVFjM2NzY3Njc+AScmJyYBT0QPAgsIAggFBQQLAwMsAgQDBhsokw8CBgQDAgEBAwEFAhxmEQYCCgIDAgMCAQYEAwcbBAgzGBcQAwIFCAIBAgMHHG5OFSEZCwQEAQEDBQYPAwEFCQ4MAgkgHAceCwcCGSUJJyYLAwgqBwgBAgQCDwcGGQcKAQI3DioUCBxMGS8NAwMEBQYDBgYPHwgGDwgPKQMJBgEEYAQFGQICAQEBAQMBAggCBQIFBhUVBA4CAQcJCgEEAQMGJDMJDhIOLi8PFREeChkFBQICBQMBAgYEAQMFBgktCxQ4SwGDOTQNAgEICAIBAQIBAg4XbiMaEwsDAQMTJwJwBggBAwQECwgPCwQEAgoBAgUBAwQCBAIDIgoBAwEDBgQITAcQAQECBg8ECwQFDgEDAwQKAwYHBAgEAgMCBBZgKgwCGRURDQQNCgEOAgEnIyXWFAgkBhIPAQEECxIPAgoCAQMCCRYHKg4OAQEgFiEHBgQXBAYCAxcECxU4GS8sDAMCOQQCAwEGBQECCAYNDjAMFSEDBwUBBEgCAxYEAwUECg0RFQwWRBMrDAUGAQICBBUKDgMFAQQGBgYCAgEDCgMBBAECAwkYBwgHExUyGgQMWDxWNRUgBgkfBAkPEmAKJQkGBg4DCQUBBCsoDAIIDwsTCwYGEREiAAAAAwAU//4DNgJQAOMA/wEbAAATNhcWFx4BFx4BFxY3FxYfAhYfARYVFAYHBgcOAQ8BFx4BFxYXHgEfATIXFjMyFhcWFzc0NSc2NzY3Njc2NzYXFh8BNhYzMhYVFDMeAQcGBwYHDgMHBgcGBwYfARYXFhcWFxYXHgEHBgcGBwYjJicmJyYjLgE1NCYjIiYnNCYvAS4CFQYUFxYVFBcWFRQGBwYiBwYiJiMiJyInLgE1NA8BHAEjIhUUBwYPAScmJyYnLgEnJicmLwEUFxYXFhQHDgMHBiYnJicmNzYnJicmJzQmNS4BNzY3NhQ2MzI2MzIXJgcVFhcUFgcGFDI3PgE/ATY3NjU0JyYjIicmFzI2MzI3NjM+ATc+ATU0JyYnJgcGFRQjDgEXFXkRUAcnCzMIBwkHCgECAgIDAwIDAwMDCiloDBMNEQ8EFQRFFgEDAQIBEAYBAiIGFgICAQsLDQYOEyRAFR5BDwYDJQEGJQIEAgMEERU3BwoDCgkUERkYBAkGCxURBRFCGi4OBQIBCQgFEwcMCwEdDwECIlADARsBGg4OAwcFAQEEAgQECQsEAwUGDwIBAwIBAg4CAQECEAIWEAYMAgQIBR0LKjglChABAwUDAgEFAwYFBR8GDAkIBAICAQICAwQCAgIQCAUMCwgSBQxEUwYKAgQBAgIMBTgHHjEaGAwLAwIQHvEBGwIKORIECzENFCAUMUwkEyYCBQECAkwEBwEGAhIFBAMGCAEDAwMEBAUFBQIdGA4QRSgECQQFBwILAiAQAQIBAQwEJQkiDtxOPDgNAwQHEgkRAwECBwcCARIjBQQBKQsPHSMdBAYDBQMHBAUMAggEBxMPAglKHjwTCwoEBgUEDQERASYTASgCA0wVAgEVCwoDBQIBAVwCBDsFBAoOCwkHCQMDBQEBAhQCBAQHCA4DCAQBAgEGChQeDAkcCB0aEQYIGR5EEwkXBAMLBQgCAwEDBR4ZMhMOCG+aBwEbAQQsBCAHBQQMB0IIDgIgGgIWBw4+BAIRAwwTGxkMCAkJBw2hChMGAhQJDSMKCAkVAwEECggDAjcLFgACABL/7AMmAlYAkwCqAAABNhceARUUFxYXFhcWFxYVFBcWBxQHBhUUBicmIyInJjc2Ji8BByIHBicmFQ4CDwEcAQYVBgcGBwYVDgEHBgcGJy4BJyY3PgEmBgcGBwYmJy4BJy4CNCcuATU0JyY3Njc2NzY/ARcWFxYUBhUUBwYXFhcWNzY3PgEfATc+ATc2NzY1NDc+ATc2NzY1NDc2NzI2MhcuAQcOAQcGNzY3PgEzMj8BJicmJy4BAjUVKAgiCykcEgUOAwwCBAIEBCIJAwQICgYCBAcFAyQoQTkbDQEDAwEBAQILAgMDARIFBwUGEg0FAgcFAgYCLgk1SBNACwIWBAEJBgUIDwEDBAMJDQYCCQgTFgcCAgkSDAQRDzBXEAlADgUJBhADCwoCAwQMAxcFCwgVBgMLCCgLCQgHKhgJBQIcDksNDCAdAxIHAQUwAk8HFAQaAgELK0gvFD0VTg4HFhxpBAQCAwcQBgMTCwIHrxsMAQgIAgIDAxcRAgICBAYCEEwTAwYDBR0EBQECDAgGBxMDASQCDAUZDgQFCAENBQIHBwYHDTQSDgEEaVM8XAgDBAUDAw0EDRAFA1G+SRoKCwwXCgYQBwM2IUwQORQEAgMFByEGMggRAQMGFQEHVggCBARSViICAQIBBwICESwSBhRCAAEAFP/3At8CIwB6AAAXIiYjIiYnJjU0JyYnJjU2NzYnNCcmNzY3NhYXFhUUBw4CBwYXHgE3PgE3NjcyFxY1JjUmNjc2NzY3NjU2NzY3NhcWFAcOAQcGFBcWFx4BNzY3Njc2Fx4BFxYGBw4BBw4BBwYnJicmFRQGIyIGBwYHIgcGIyIHBiInJmMBEgECHAESAgEEAwIFBAEBBAUFFRoNCAgCBAQCAQQKBw8WElEOHigIBgQJBAcGAwEFAwIBBgUQIwIBAgMFAQMDCRYILg5UFhorEAkHAwMFDBcGKQoLZA8/LBsGCw0FBC8CDRwHBhgTCQcKOgYEAgkdBCoFAwQDEhUrdTc3JSEIGg0MBQcLIB8wLgMGPUwLPi8eEAEBFAcPAgIBAhcMKrMhEQ03BQIPEAcGAQIXDloID1gIH1sPKw0FAgMMBgYEAQUFBQ4XEQQBCgECEQIJGBEHDAUHEA4CCQQEDAMEBAMAAAIAEwAZAzICWgCtANgAACUUBhQGIyI0JyInJjU0JwYVFAcGBwYVFAYHIg4BBw4BBwYjIicuAScmJyYnJicmNz4BNTc2NTQ2NzY3Njc+ATcyPgEXMhY7ARQXFhcWMzIXFhceARUUFxYXFjU3NDY3PgE3NhcWMhYXFhceARceARceARcnNCYnJjc2NzY3NhcWFxYHBgcOARQWFxQXFgcGMzIPAQ4BBwYiJyYjIicmNCcmJyYnJi8BIhYXFgYHBgEmJyIvAQYHDgEHBgcGHQEXFhceATMyNzY3Njc+AyYnLgEnJicmDgEmAfEGCBYXBAMEBAUBFRcoByoCAQcLAgUjCCQYExIKDAQLCh0PBAEBBAECAQISAwEIDxIPJwwDCgUGAgQBAQsKBgUECywOJAklCBgDAwEECgIQCBALBgQMAQYnAjQDBzsPBiIGAQMBCAgFBgoLBxYTBAMDAwIDAgMBBgQGBAIECgMCCgMEFAUCBQMTCBIYLRkwFCINAQYBAgECAf7RAgQBDA4MDA4LCgIBAgcHBA0PEA4PGDglFQIHAwICAwURFR0QDQIYDDoECgQIAgIGBz+5BQIDEDk9KAcCASYBBQgCBBECCwYDCQIFDB0+FDQtGgQNAwQCBQhKBAEUJx4aJQIDAQEBAgUFCQgWBx0HJgIBDiYfGh1GXywUBAgBAgkGGAQSVAReCRBgEwcwBx8HSBSkSy0LEAQDCgkHBwkIGyo7Gz4UEIpYCwYKAwEJAQICARAFBBIZPyNPIEIVjAkgkwIBAYgKAQEBExodKjwIAQQxMxcXBhIKBQgyID4FEwkQEw0aHRQbCQcIBgQAAAIAD//fAvACaACdALMAABciJi8BNCcmJyY1NCcuASc0JyY3Njc2NzY3Njc2NzYyFjIWFxYXFhcWBw4BJyYnJgcGBw4BFxYXFjc2NzYzMjc2Fjc2JzQ3NjU2Nz4BNzY3Njc2PwE0NhcWNTQeATMyFhceARcWFx4BFxYXFhceAQcGFAYVFCYnJjU0JjY3NicmJy4BIyInJg8BFxQGFQYHBicmJyYGBw4BIyIOAScmAS4BNTQnJicmIyIHBhUUNz4BNzYWF6cJIAwLBRYWCwICDAICCAgEHR0hDxIcDRMWDCkGCB8CAQsVEgYRDAoJKBMTFTUvIRYcFicNECkdIwYECAoQAQICAwgDBgMIAxMMFRkOAgQzCgcLDQIDJAgFEAUOCAcaCREDAgMHAgYECC8FCgYBBAMBAgoFBRITGB9TIQEJAxMMEiMCAgcNEj8LARwTBQQByQQNHBMVDwYcGBEECCwHDkcRHg4HBwMCDCwWBQICASsPAgQVcTtBPzESEhsHCwYEBhECAgkQLBAMCAEJJwkICRdbQLBPMQsDAggRFQoLAgUEAgcYPwUqHQs3Ck0cMBMLAQIEBAQDAQEHCSULBx0GEh0WRCFCGBEKIF0HBAIJAgcBBg0IAwQSBAMSIkEiBwIDCAQNCD8GMS4fAwcFBgEJDR4CAQECAUoHIAYJOyQTDl9LDAMBAgEBAgECAAAAAAIAE//4AzYCZwDIAOQAADcOAisBLgEnNzQ3NicmNjc2LwImJyY3PgE3Njc2FxYXFjMyFxYzMhYXFhUUNzY3NjU0NjQ2MzI3Njc+AjM2FxYVFBYHFAcGJyYHBgcOAQcOARcWFxYzMjc2MzI2MzY3NjIXFjMyFxYXHgEVFBcWFxYHBgcGFAYHBgcGBw4BBwYnJi8CJjc+ATc2FxYVFDIVFBYVFBcWMzI3PgE3Njc2JicuAScmBwYjIhQjIgcGJy4CJyYnBwYHBhUUBgcGBw4BJyYOARcTJgYPARccARYVHwEWFxY3Njc2NTQ3NicuAScmewcFEBAUAgkCAQIFBgMDAgcCAQoRBAQFBAsXESI+RSAlFAMCGQwBAiIFDgUEBQMPIQIEBSkZBSMkDS0cFgIBCg4dIRoTKwwlCRMGAgQEAwQOHxYDAiACCQIFIwcIAQYnFhgEEAMCCgUEBhIJIQUGCi8lAw8MRDUSDgwBAQUEDBAPAgMEBRkaKxMYIh4IDgQCEAoHKAgSJCcOBQUHBwkNEAsRCRoJBgkGCSIGIxQaYCEMBAUBdhJEDwsBAQELCyQiEy0hHQUICQUmCxkqBgMDAwoDSUYeQQYDHQQKSCYDBBEVFA8QFBEMGAsFEwoTCCYHFAgDDAoHBAMBEwIcBBsEAQkHAhANBgESBQMMEQcHBAMNAxYJFUALFAMDDgoPAgIDBAQWDRoEIAQDBAUrHB8lJRAGIAIDBhwHAQQBBTcSGxgWFwkJBQIBAwMDBAYECAILISMKDhURHRkRRQoIGAIEExYEAwMDAwMJCRkxDBAHCwECHwQXCQwKCAQEiCkBzgUBBwQKAR4vFVgDBAEBBQsfHQgDChYQCSQHEAAAAAACABP/9QLGAkkAaQCRAAATNhceARcWDwEyNjMeARczNhcWFxYzMhYXFhcWFRQHBgcGBw4BBwYHBgcGJyImLwEuAScmNjc0Njc2PwE2ByIHBg8BBhUGBwYHBicmJyY3Njc+AScmBw4BBwYHBgcGIyInJjc2NzYXFjc2BSInJgcGBwYHBhcWFxYXFjc2NzY3NicmJyYjBhYGBwYHBicuAicm2288EAwFBgICBhkGAgcCEiUoGgERBAImBAQIJgMLCQMEBygOFxEyHCsMASYCJCAgCAMEBQMBFjEMB2oGBSQDCwIBBQUGBRMlBwMBAQgBAQEBDAMQAwgSCggBBg4QEAEBJhoUBA0vARoQBQEGDgoNBQ4OBwgNEhgeJywjFxEOFzgXDwEBAQECDQ0GBAQDAQMCNhMEAQcJCQ4PAQIJAgESDAEPJwUHDDo/GA84CQMKEDwOGQsiBwwCBAESHEc2FWQWAREEaDkOBg4BBAECPUqiU1gFBQECDwYSFKUWrxgQBwIEAgQDAgoCExQICR0RAgEED4IHAgkWHyQhW0ceDxYGBwkNLCNDMypDHw0BDRIBAgQDAwIFDAMJAAEAEP+mAhsCfwBZAAABMjYXHgE3NhcWMzIWFRQXFgcOAgcGJyYHBi8BBwYHBgcOARQGFQYHDgEnJgcGJicmJy4CJyYnJicmNz4BFx4BFRcWFx4BFxYzNjc+ATc+ATc2Nz4BNz4BARQBBwIcNUE8CwgCAwgFChQFBQUFCAkbOjEgCgIIAQsHAQgUFgoDDAQEBAUaBQMGCR0TCSUCAQ4ICw4RCxAfBQQIBgcGCAICCAEPAwMKAwsFBgIMBBwCfAMBCwYBAQQDDAUGCBMNAwQDAgQDCAUECAMgaQU5TwcwDHECiBYHCQECBAUEBwMMEC0iF1cCARgODxUJCAoeBQ0GFw8ODREHNgVeCw9jFk44QAgTBRsAAAEAE//KAfwCggDCAAAlMjYzNhYfAhYHDgUHBiMiBwYmIwYjIiYiBw4BBwYmBwYnJicmJzQnJicmNjc2NzY3NjU0NjQ2NTQuAicmJy4BJyYnJicmMzImMzI3Njc2NzYzMhceARcWNjc+ARUUFxY2MzYXFhUUFxYfAQcOAxUUIyIvASY3IyInJgcOASYnJhYXHgEzMhceARcWFRQXFhcWBwYjIhUUBiYUFRQHBhUUBwYHBgcGBw4BDwEWNjIWNzY3NhY3NjMyNz4BAaICEgIPBwsNAQMMAwMDBAMHAwgJCAQCOQEGLwMMCwUITQYJHQsUDx0XEAIFBwIBGhElHBkQBSEmFwwYBiUKBhAGCgcOAQIHAQICAQYEBwYBAygFBgI8AQM0BwVJFRQsDBIHBgYFBQQEAgMCARQmAwYOBBMXDA4oEyseHQcCCgghAgEPAxMDCgQKFAoFAgoBDAIKHRUYGhkICQYDCgQDAQosBA1JBQgXCAwnJgEBDDoNAQMKDA8mEwQFAgIBAgEDAgEEAwEBAgIBAQQCAwIDDAgIAgUHCwoxFS4vKgwDBAIoBC0CBCsMIAcoEgsXChEHDxUWBAgHAgIBBQIBBAECAQICAgIBAgEFAQcGAwQGBRkYCwQFAgUFEgUECBoDAwEBBQEFAgYQDCgTBBgEDAQCBgsxGBkRAwIGAgICBAofBgMXGickDQ8GAw8GBgEEBAEEAQIDAQIFBA0AAAAAAQAU/1MCKQMMAHkAABc0JjU0JjUmNzQ2FzIzHwEeARceAR8BNzY3PgE3Njc2NzY3NjUmNz4BNz4CNz4BNzY3NhcWMxYXFjMyFhcWFxYVFAcGBwYHBicmJyYvASImIwcGDwEGBwYXFgcOAQcGBwYHDgEHBgcGBwYHBg8CBg8BBiInJicuATYNEwIBJQkCAwMDAgkDBRYBDAw9CwIIAgQYFQIBAwIBBgIJAwEFBAICFwoRGAYGAx4oCwUCAx0GBggGCQICAgsQFg4CCgsJBRYGBA4ECAQDAgECBgQKBgEHAwMCAgEODAERCQYBDQ0PHA8UDywJCgMEGoQBFQECHQEFDAUbAgEDAgwEBhkBDA1ATgwpDh56ahQMEQwBAR8NQQ0EMgweFjkKEQcCAgEBCwUkCw0IBgUTBAEHCgcJDgkGFgwKAQ4pOEAmBAUBAxgVRSADLBQIAxsDQU4JQyEDARkZEygICggHBgEBGAAAAAIAEwB/AnUB3QBDAHwAABM+AzIzMhYXFhcWFx4BNzY3PgEzMh4BFxYHDgEHBg8BDgEnIgYnJicuAScmByIHBgcGBwYnJjY3PgE/ATQ2NzY3Nhc2FxYXHgEXFh8BNzY3Njc2MzIXFhcWBgcGBwYHBiMiBwYnJicmJyYnJicmBgcOASMiJy4BPgE3NqMHCwMHCQkQMgICCy1IFgsQFikRCwgFGAwDCwoFIgwXBwoEKwYCCBMfFxE+Dy4fBBcoHRgPDBISAQ4BBAEBGQcDDh5FFBkSTBoREAkUExMVGRYXFgkGERsBAgYPJiIPAhgXBwkSGSUJFAsOHSMCHkALAxIIBxIRBAoHCx4B1QIDAgEJAwIDDTYRBAYILRMJDQwCChQJKAkUBAYEEQEEAwQUDyoGEgIHDCQdCAcPERgVAgUCAgMeBAILGJ8DBQQdCgoQCQYGBQUODB4cCxIICAwUNA0IARADBQQHBQsMDwoOARAEGQgQBgYKLA4LIAABABQAIAIIAiMAbAAAEzIXNzY3NhcWMzIWMzIWBwYPARc6ATM2Fh8BFRwBFQcUBgcGJyMHBhUXMjYzNhYHBgcGJyYPAgYHDgEnJicmNDY0PgE/AQYjIgYHIyImLwE0JyYnJjc2NzY/ATY3Njc2NSYiBwYnLgE1NDc2wkwKGBUICAoEBwUHAwcPAgMNCxQVKQsUDggJAQwFLV0dERIiI1gXFxcQBQgEO0pOEwUxEggSFA4EAgMCAwEkNQsECAMDAg4GBgQJBAMDBAINZSwFBQsJCwFHGykSKhYXJQG3AzAsCAsEAgQbCQ4bFwEBAwkJFQULAwQDCAEIAyMiAwEBAS0QBQwFAQIFAQtyHAsCCggGBgQJCAcIAlcHAQEBAQIBAgMcEAUGAgsLBQoMGxAUAgECAgIDDBQjBAcAAAAAAgAMAD8BsQJEAEsAZwAAATI2MzYXFgcGBwYVFgYVFAYHBhcWNz4BNzI+ATM2MhcUFhcUFhUUBg8BNAcGJyYGBw4BBwYHBiYnJjc2ND4BNz4BNz4BNzY3NjU0NhM2HgIXFhQHDgEnJgcGJyYnJjc2MzI2NzYXFgE4ASEBChUSAQIHAgEUiR8dAwIIB0MQBRMPBBIvAhYBBwoEBAcGEA99CQNEAwchJRgNDw0FHycCCRsLDioTHxAPGFQIDAQHAwUHDjEzZ0lFEgcEAgMGDQMGJlOcKgIkHAQTEAgOBgEDARgBA4ccGQEBAQEHAQIBAgIBBgEBCQUIIwUEAwUCAQEJAwEGAQICAgcSFREFBB4lAggXCw0nEx8ODwECG/55BQYHDgMGGgcNCAMGCQkNBRgNCAwGBQwGAQAAAgASAFsBxAJTAEIAYQAAEjYzMhceARceARcWMzIXFjMyFxYXHgIXHgEHDgEHBgcGJyYHBiYnJicmJyY3PgE3NhcWMj4BNzY3Jy4BJy4CJyYTNjIXFhcWFxYXHgIHBgcGIyInJgYHBicmJyY3NjdSGggLGgxDCwkdBxABAhYvCQIPEAUEBAMCBAIEBjsVCjcVBAVJEmQDAwgWBQUGAwUHBxsVPTFFDxEBBQiHDQUKKQQFSgJ4DglGPQUCAgEJAQIEEQoiMzoWiww5DAcFBA4WRAI1HhQJQw0LHQgSFi0MDgEBBggCBB4GCRkBAQcEAgEIAgECBAEFCgsZDwgEAwUEBAcBAQIEBIgSBgYuBwj+lQECAQIBBQIIBQ4IDA4HBAQCAgIJCQYcGAgMAgAAAgASAAwB8wJgAEkAaQAAEyImIyInJjc+ATc2FhcWFxY3NhYVFBYXFhUUFjIWFxYXHgEUBwYjIgYjIgYHBgcGBwYnJjU0NzY3Njc+ATc+AT8BJy4BJyYnLgEnNjcyFhQyFxYXFg4BFRQHBicuAicmJyY3Njc+ATUm2AIOAQIEBAICBAkEJggHBgUCAzAyCyoaBAgFBw4BBAECDAEQAQNMDh8uHQkPFBYIAiEiGwQNAQU/CAcIEi0KFgknHrYJIQMIBAcCAgECBA8TEAMMCQICAggDAgIBBQECFQkIBxQQCQQCAgICBgUCATIFAj8LLAUCHggCAxUCBBoLFBJOESdGLAMEDg8PCQsCMzQiBRABCEAGBgcQOwoYDDMhPwQGCAQkDAIQZqcZqQ4RCQEDAwIEAggXD4w0wTIxAAAAAAIAE//lAgMCegA/AGoAAAE2Fx4BFRQHBgcGBwYHBjMyFxYVFBcWFxYXFhceAQYVFAYjIhUUIyImJyYnLgEnJjU0JyY2NzY3PgE3Njc2NzY3NhYXFhUWBhUCFQYHBiIVFAYnJicmPgE1Njc2Nz4BNz4BNzQ2NzY3NjU2AR4IFBAIIBQqFCU7DwQECSYYBSkSGwoIBgoGCgsEAhAFFwUDDBReHi4HCAIMFhICCQIQPzofDsoWDQQFAQoSAwICBBYNKQMBAwQFAgECAQIBAQQBCAECAQIBAnUFBwYJCxcxHywUKD4dCCgaBAEHOBsnEw8EBBsUAgQMAgYLBQMWJ4UZJgUDBwoQGCwVAgsCGD86MxYGAwgVGQogbQP+8AUgNC0JDhIDCRAENTcDXAcEJxkXGBUuCA9kEyYCBAobAAAQABL/+AKEAtIA6AF4AZgByAHrAhoCQQJMAlcCYAJrAnUCfwKHAo8CnAAAEyImNTQnLgE3PgE/ATY3Njc2Nz4BFxYXFjc2NzY1MxY3PgEnND4BNzYyNTQ2NzY3PgI3NjU0NzI/Aj4BNzY3NjMyNzY3MjYXFjc2FxYyFgcGFxYGFQYjIg4BJicuAQcOAgcOAQcGIyIUIw4BFRQzMhYXFDMyFxYVFxYHBhYXMj4BFxYzMhYXFhUUFxYUBw4BByIVFAcGFRQjIgcGByIHBgcGFRQHDgEXFhQHDgErAQYnLgErARQHBicmBwYiJy4BBhUUBiInJgcGIjU0BwYnJgcGJy4DNScmJy4BNTQnLgInJic3NAcGBwYjIgcGIgcGFxYyNzYWFxY/ATYXFjMyFx4BNzYXMhUUFjY0MzI3NjIXFDMyFxY2FxYzMhUUFxY/AS4BNzYXFhUwBzYXFhUUFj4CMz4CFhcWFRQyNjc+ARYVFjI3PgE3Njc2JicuASciJgcGJyYHBicmBwYiBwYnJgcOAScmIgcGIhQGJyY0IyImFy4BPQEGBwYHBhceARcWFx4BFxYVFzQzNi4BNTQmJyYkNDY1NDY3NicmJyYHBiMOAyMiJyYHBhUUBhUOAQcGMxY3NhcWPgE3NjU0NzY3BzQiBwYnJgcGIyIeARcWFR4BFxYXFhceARcUFRQWPwE2OwETJgcGLwEUHwEUHgEUHgEzNhYVFDI1NDY7AScmNzQ+ATU+ATc2NzYxMAcGJyYjIhc0PgEnIi8BBw4CBwYVBgcOAgc3NjU2NTQ2NDc+Ajc+ATc0NiY0NjMyFhUUBiMiJzYzMhYUDwEmJyY3NhceAQYHJyYnNjMyFhQHBi4BNiU2FhcWBgcGJyYFNh8BBw4BJy4BNzYXFgYnJjQFNhcWBwYiJgc3NhcWFxYzFg8BJyZLCB8GCQMIAQoCAwMQBgwDBg0sDwoCBAsFCwoCAwcNAwEBBgECBB8KEAkHBQMCBAoBBQUCAQQCEx4RBAMCAQoDHQUMCQ8MBQICAQICAggBBAMHBAUDBhkGBxIOCwgaAwQBAgECCQYLIgIDAgQLAwgCAgEHAxoRAwIlFRobDwMCAgEDAQIVCAUEBAMNBQEBHQkDAwUCAQECEwQkBwwDBQECDg0FCwsFGAIBBQQYDAgJCQceFxcNBQQPBQEFBAMGDwcBBQICAwQBBwdCDBYDAgQCAQEUAwcIBBQFBQQFBAIIDwoDAQIFBAYICAkECQkEAwUEFgEDAQUIOAcDAgMDBQkKCgMDBwgPBg0GDQIFBAYBBA0JCwQGBwkCAw0JARIGAQYBFAMEAwoLDhAGJw8TDhoNERIKDQcVBREMBwUGEwUFIAMCBhYEDQMCCQsDAwMCAwcGAQEKAQwDAgcDBAEEAwIGBwEHATUGBQECBgUCAggDAQMFAgcGDAcLAQEHCQQGAgICCQgODgwDAgoJBAPaAgYUDgcJCAYEAgQBAwEDAQMHAgMBBQEDBgQMBwddBBkaCgUCAgEBAgIBBxMOGgYHAQIJAQIBBAEBCAEJFAgCAgG0CAMDAgcGCAYFAgIJBRABAwQCCgsBBgQFBgcDAgYBCMoOBAIMEAQDOQcCAxAIBwwDBJkGDQcBBAYJDr4JAwIQCwoJCgIBRQoHAQEECgoCAf5XBAwHBAMEBwYCNQkCAQUGBwFfBAUDAgIHAwIBAwYCBQEBCQgGBw0BRQgDAQYIJAgBHAEGBwQCCgIGDAgHAwQFBwMCAgEDAQIDDQkKDAMHAgUZAgQBAQQJAwYBCAoKCgIBBAIXDQgCAQIKAQEHDQwFGwYQAwUJAQQBAQIDBgsBAgMFBQQVBQYIAQ0CBA0FAQQNBQYKGBAHAQMBAwgOGg0GAwMCHAMBFwEDBgsDAwICAgEPEHYkAQYLDDsCAg4CAgkCBQECAgICBAgHAwMBAgEBAgoHCQUEBAgLCwgEAwcCAQICAgIIESgFEQYLBgccIwg+NHwFAwcRCwMDBwwDAgIBBg4HAwoPCgMHBgEFBAEDBAEEBAMCAwIFCBcHAwIDAQIFBAUDDA0FCQIJAgIGBgICAQEDAQUCAQUGAgEDAgIDAQIJBgEEAQYJCgkKCwYBBwEBBAkEBQYDAgECBgYDAwMBBAMDAwQKAQMECb4ZNQ0NAwMEBQQICi8MVBEOLw4OBgUCAxQjBAkfBzMfCBMFBxMGDgUGBAYEAgEDAgEICwkFExRGBXEhDQYBBAMDBAQGDjwOBC0QDB6QBAsGAwUFBigDDAcLHgshJwsYChEMAwYIAQQCBQEcBAwJBQEBAnsjLCQTDQMCAgMBAQIKGUE9AwoOAwwOCRAgCAIGCANBAhkQAgkJBQQRGQYqAgxdAxgjCwECAgIGBSYKEhQXFgwGEAgEEZAICg8CAwwTCQwECggHBAUICQgECgUGBQgIBxYEBwYCEAgGAgQLBgICAQwKCgoGBAgHAQMCAwgCBwYGAQEOAQYFBAIDBQ8BBgMBAwEGCQYECAAAAAABABQCGQCnAvcAHQAAEzYzMhYXFhUWBw4CBwYHDgEHBicmJyYjIjU2NzZtCAYDIQQCAgwHDREEDwIBAwUIEh4EAgIEASscAvIFFQQCBxQQChooCCMLDAUCAwIECgQUFlc7AAAAAQATAfAApALuACYAABM2FxYXFhceARcUFxYHDgEHBiInLgEnLgEnJjc2IyI1NCcmJyY3NiYGGyQHBQkDDgEGDAICAwoDLAcJAwIBEwsMAgECAwQDBAQFCALrAwcKFxAHAicIAxgvHhIJCAMGBwoXJUQMDQIBAgMCAQkHEhoAAAAAAA4ArgABAAAAAAAAAGQAygABAAAAAAABAAsBRwABAAAAAAACAAcBYwABAAAAAAADAAsBgwABAAAAAAAEABMBtwABAAAAAAAFAAwB5QABAAAAAAAGAAoCCAADAAEECQAAAMgAAAADAAEECQABABYBLwADAAEECQACAA4BUwADAAEECQADABYBawADAAEECQAEACYBjwADAAEECQAFABgBywADAAEECQAGABQB8gBDAG8AcAB5AHIAaQBnAGgAdAAgACgAYwApACAAaQBwAHkAdABoAG8AbgAvAHgAawBjAGQALQBmAG8AbgB0ACAAYwBvAG4AdAByAGkAYgB1AHQAbwByAHMALAAgAEMAcgBlAGEAdABpAHYAZQAgAEMAbwBtAG0AbwBuAHMAIABBAHQAdAByAGkAYgB1AHQAaQBvAG4ALQBOAG8AbgBDAG8AbQBtAGUAcgBjAGkAYQBsACAAMwAuADAAIABMAGkAYwBlAG4AcwBlAABDb3B5cmlnaHQgKGMpIGlweXRob24veGtjZC1mb250IGNvbnRyaWJ1dG9ycywgQ3JlYXRpdmUgQ29tbW9ucyBBdHRyaWJ1dGlvbi1Ob25Db21tZXJjaWFsIDMuMCBMaWNlbnNlAAB4AGsAYwBkACAAUwBjAHIAaQBwAHQAAHhrY2QgU2NyaXB0AABSAGUAZwB1AGwAYQByAABSZWd1bGFyAAB4AGsAYwBkACAAUwBjAHIAaQBwAHQAAHhrY2QgU2NyaXB0AAB4AGsAYwBkAC0AUwBjAHIAaQBwAHQALQBSAGUAZwB1AGwAYQByAAB4a2NkLVNjcmlwdC1SZWd1bGFyAABWAGUAcgBzAGkAbwBuACAAMQAuADAAIAAAVmVyc2lvbiAxLjAgAAB4AGsAYwBkAFMAYwByAGkAcAB0AAB4a2NkU2NyaXB0AAAAAAACAAAAAAAA/4AAMwAAAAAAAAAAAAAAAAAAAAAAAAAAAI0AAAABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMwA0ADUANgA3ADgAOQA6ADsAPAA9AD4APwBAAEEAQgBEAEUARgBHAEgASQBKAEsATABNAE4ATwBQAFEAUgBTAFQAVQBWAFcAWABZAFoAWwBcAF0AXgBfAGAAYQDoAJMAYwBlANMAaAC4ALUBAgEDAQQBBQEGALQBBwEIAQkBCgELAQwBDQEOAQ8BEAERARIBEwEUARUBFgEXARgApQEZAJwApwCPAJQAlQEaARsBHAC3ALYHdW5pMjI2QQd1bmkyMjZCB3VuaTIwM0QHRW1hY3Jvbg1PaHVuZ2FydW1sYXV0A2NfbwNvX28WSV9oeXBoZW5fcF9yX29fbl9vX3VfbgNFX0EDQ19PA0NfUgVPX0NfSANFX0UDVF9UA0xfQgNFX1IDUl9SA0xfQQNMX0wDT19OA0NfQQNQX1MDVF9PBVNpZ21hC2Jhcl9ncmVhdGVyCGxlc3NfYmFyBnUxRjM4MgAAAAAAAAH//wACAAEAAAAMAAAAFgAAAAIAAQADAIwAAQAEAAAAAgAAAAAAAAABAAAAANUqxk8AAAAAtJL0AAAAAAC0kvQA";

// src/utils/addFont.js
var fontLoaded = false;
async function loadFont() {
  if (fontLoaded) return;
  const font = new FontFace("xkcd", `url("${fontData_default}")`);
  const loaded = await font.load();
  document.fonts.add(loaded);
  fontLoaded = true;
}
function addFont(parent) {
  parent.append("defs").append("style").attr("type", "text/css").text(`@font-face {
      font-family: "xkcd";
      src: url("${fontData_default}") format("truetype");
    }`);
}

// src/utils/addFilter.js
function addXkcdNoise(filter) {
  filter.call((f) => f.append("feTurbulence").attr("type", "fractalNoise").attr("baseFrequency", "0.05").attr("result", "noise")).call((f) => f.append("feDisplacementMap").attr("scale", "5").attr("xChannelSelector", "R").attr("yChannelSelector", "G").attr("in", "SourceGraphic").attr("in2", "noise"));
}
function addFilter(parent) {
  addXkcdNoise(
    parent.append("filter").attr("id", "xkcdify").attr("filterUnits", "userSpaceOnUse").attr("x", -5).attr("y", -5).attr("width", "100%").attr("height", "100%")
  );
  addXkcdNoise(
    parent.append("filter").attr("id", "xkcdify-pie")
  );
}

// src/utils/addLabels.js
var title = (parent, text, fill) => {
  parent.append("text").style("font-size", config_default.titleFontSize).style("font-weight", "bold").style("fill", fill).attr("x", "50%").attr("y", 30).attr("text-anchor", "middle").text(text);
};
var xLabel = (parent, text, fill) => {
  parent.append("text").style("font-size", config_default.labelFontSize).style("fill", fill).attr("x", "50%").attr("y", parent.attr("height") - 10).attr("text-anchor", "middle").text(text);
};
var yLabel = (parent, text, fill) => {
  parent.append("text").attr("text-anchor", "end").attr("dy", ".75em").attr("transform", "rotate(-90)").style("font-size", config_default.labelFontSize).style("fill", fill).text(text).attr("y", 6).call((f) => {
    const textLength = f.node().getComputedTextLength();
    f.attr("x", 0 - parent.attr("height") / 2 + textLength / 2);
  });
};
var addLabels_default = {
  title,
  xLabel,
  yLabel
};

// src/utils/colors.js
var colors_default = ["#dd4528", "#28a3dd", "#f3db52", "#ed84b5", "#4ab74e", "#9179c0", "#8e6d5a", "#f19839", "#949494"];

// src/utils/initChart.js
function applyDefaults(options, datasets) {
  const merged = {
    unxkcdify: false,
    dataColors: colors_default,
    fontFamily: config_default.fontFamily,
    strokeColor: "black",
    backgroundColor: "white",
    ...options
  };
  if (datasets) {
    merged.dataColors = datasets.map(
      (ds, i) => ds.color || merged.dataColors[i % merged.dataColors.length]
    );
  }
  return merged;
}
function setupMargin({ title: title2, xLabel: xLabel2, yLabel: yLabel2 }) {
  const m = { ...config_default.margin };
  if (title2) m.top = config_default.marginTopWithTitle;
  if (yLabel2) m.left = config_default.marginLeftWithYLabel;
  return m;
}
function resolveFilterAndFont(options, usePieFilter) {
  if (options.unxkcdify) {
    return { filter: null, fontFamily: config_default.fallbackFontFamily };
  }
  return {
    filter: usePieFilter ? config_default.filterUrlPie : config_default.filterUrl,
    fontFamily: options.fontFamily || config_default.fontFamily
  };
}
function createSvgEl(svg, { strokeWidth, fontFamily, backgroundColor }) {
  const svgEl = select_default2(svg).style("stroke-width", strokeWidth || config_default.svgStrokeWidth).style("font-family", fontFamily).style("background", backgroundColor).attr("width", svg.parentElement.clientWidth).attr("height", Math.min(svg.parentElement.clientWidth * config_default.aspectRatio, window.innerHeight));
  svgEl.selectAll("*").remove();
  return svgEl;
}
function setupChartGroup(svgEl, margin, { title: title2, xLabel: xLabel2, yLabel: yLabel2, strokeColor }) {
  const chart = svgEl.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
  const width = svgEl.attr("width") - margin.left - margin.right;
  const height = svgEl.attr("height") - margin.top - margin.bottom;
  addFont(svgEl);
  addFilter(svgEl);
  if (title2) addLabels_default.title(svgEl, title2, strokeColor);
  if (xLabel2) addLabels_default.xLabel(svgEl, xLabel2, strokeColor);
  if (yLabel2) addLabels_default.yLabel(svgEl, yLabel2, strokeColor);
  return { chart, width, height };
}
function setupChartGroupSimple(svgEl, { title: title2, strokeColor }) {
  const m = config_default.marginScalar;
  const chart = svgEl.append("g").attr("transform", `translate(${svgEl.attr("width") / 2},${svgEl.attr("height") / 2})`);
  const width = svgEl.attr("width");
  const height = svgEl.attr("height");
  addFont(svgEl);
  addFilter(svgEl);
  if (title2) addLabels_default.title(svgEl, title2, strokeColor);
  return { chart, width, height };
}
function createTooltip(svgEl, options) {
  return new Tooltip_default({
    parent: svgEl,
    title: "",
    items: [],
    position: { x: 0, y: 0, type: config_default.positionType.downRight },
    unxkcdify: options.unxkcdify,
    strokeColor: options.strokeColor,
    backgroundColor: options.backgroundColor
  });
}

// src/Bar.js
var Bar = class {
  constructor(svg, {
    title: title2,
    xLabel: xLabel2,
    yLabel: yLabel2,
    data: { labels, datasets },
    options
  }) {
    this.options = applyDefaults({
      yTickCount: config_default.defaultTickCount,
      ...options
    });
    this.title = title2;
    this.xLabel = xLabel2;
    this.yLabel = yLabel2;
    this.data = { labels, datasets };
    const margin = setupMargin({ title: title2, xLabel: xLabel2, yLabel: yLabel2 });
    const { filter, fontFamily } = resolveFilterAndFont(this.options, false);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroup(
      this.svgEl,
      margin,
      { title: title2, xLabel: xLabel2, yLabel: yLabel2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.margin = margin;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    const xScale = band().range([0, this.width]).domain(this.data.labels).padding(config_default.bandPadding);
    const allData = this.data.datasets.reduce((pre, cur) => pre.concat(cur.data), []);
    const yScale = linear2().domain([0, Math.max(...allData)]).range([this.height, 0]);
    const graphPart = this.chart.append("g");
    addAxis_default.xAxis(graphPart, {
      xScale,
      tickCount: config_default.defaultTickCount,
      moveDown: this.height,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    addAxis_default.yAxis(graphPart, {
      yScale,
      tickCount: this.options.yTickCount,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    graphPart.selectAll(".xkcd-chart-bar").data(this.data.datasets[0].data).enter().append("rect").attr("class", "xkcd-chart-bar").attr("x", (d, i) => xScale(this.data.labels[i])).attr("width", xScale.bandwidth()).attr("y", (d) => yScale(d)).attr("height", (d) => this.height - yScale(d)).attr("fill", "none").attr("pointer-events", "all").attr("stroke", this.options.strokeColor).attr("stroke-width", config_default.barStrokeWidth).attr("rx", config_default.barCornerRadius).attr("filter", this.filter).on("mouseover", (d, i, nodes) => {
      select_default2(nodes[i]).attr("fill", this.options.dataColors[i]);
      tooltip.show();
    }).on("mouseout", (d, i, nodes) => {
      select_default2(nodes[i]).attr("fill", "none");
      tooltip.hide();
    }).on("click", (d, i) => {
      if (this.options.onSelect) {
        this.options.onSelect({ index: i, label: this.data.labels[i], value: d }, event.shiftKey);
      }
    }).on("mousemove", (d, i, nodes) => {
      const tipX = mouse_default(nodes[i])[0] + this.margin.left + config_default.tooltipMouseOffset;
      const tipY = mouse_default(nodes[i])[1] + this.margin.top + config_default.tooltipMouseOffset;
      tooltip.update({
        title: this.data.labels[i],
        items: [{
          color: this.options.dataColors[i],
          text: `${this.data.datasets[0].label || ""}: ${d}`
        }],
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
    });
  }
};
var Bar_default = Bar;

// node_modules/d3-path/src/path.js
var pi = Math.PI;
var tau = 2 * pi;
var epsilon2 = 1e-6;
var tauEpsilon = tau - epsilon2;
function Path() {
  this._x0 = this._y0 = // start of current subpath
  this._x1 = this._y1 = null;
  this._ = "";
}
function path() {
  return new Path();
}
Path.prototype = path.prototype = {
  constructor: Path,
  moveTo: function(x2, y2) {
    this._ += "M" + (this._x0 = this._x1 = +x2) + "," + (this._y0 = this._y1 = +y2);
  },
  closePath: function() {
    if (this._x1 !== null) {
      this._x1 = this._x0, this._y1 = this._y0;
      this._ += "Z";
    }
  },
  lineTo: function(x2, y2) {
    this._ += "L" + (this._x1 = +x2) + "," + (this._y1 = +y2);
  },
  quadraticCurveTo: function(x1, y1, x2, y2) {
    this._ += "Q" + +x1 + "," + +y1 + "," + (this._x1 = +x2) + "," + (this._y1 = +y2);
  },
  bezierCurveTo: function(x1, y1, x2, y2, x3, y3) {
    this._ += "C" + +x1 + "," + +y1 + "," + +x2 + "," + +y2 + "," + (this._x1 = +x3) + "," + (this._y1 = +y3);
  },
  arcTo: function(x1, y1, x2, y2, r) {
    x1 = +x1, y1 = +y1, x2 = +x2, y2 = +y2, r = +r;
    var x0 = this._x1, y0 = this._y1, x21 = x2 - x1, y21 = y2 - y1, x01 = x0 - x1, y01 = y0 - y1, l01_2 = x01 * x01 + y01 * y01;
    if (r < 0) throw new Error("negative radius: " + r);
    if (this._x1 === null) {
      this._ += "M" + (this._x1 = x1) + "," + (this._y1 = y1);
    } else if (!(l01_2 > epsilon2)) ;
    else if (!(Math.abs(y01 * x21 - y21 * x01) > epsilon2) || !r) {
      this._ += "L" + (this._x1 = x1) + "," + (this._y1 = y1);
    } else {
      var x20 = x2 - x0, y20 = y2 - y0, l21_2 = x21 * x21 + y21 * y21, l20_2 = x20 * x20 + y20 * y20, l21 = Math.sqrt(l21_2), l01 = Math.sqrt(l01_2), l = r * Math.tan((pi - Math.acos((l21_2 + l01_2 - l20_2) / (2 * l21 * l01))) / 2), t01 = l / l01, t21 = l / l21;
      if (Math.abs(t01 - 1) > epsilon2) {
        this._ += "L" + (x1 + t01 * x01) + "," + (y1 + t01 * y01);
      }
      this._ += "A" + r + "," + r + ",0,0," + +(y01 * x20 > x01 * y20) + "," + (this._x1 = x1 + t21 * x21) + "," + (this._y1 = y1 + t21 * y21);
    }
  },
  arc: function(x2, y2, r, a0, a1, ccw) {
    x2 = +x2, y2 = +y2, r = +r, ccw = !!ccw;
    var dx = r * Math.cos(a0), dy = r * Math.sin(a0), x0 = x2 + dx, y0 = y2 + dy, cw = 1 ^ ccw, da = ccw ? a0 - a1 : a1 - a0;
    if (r < 0) throw new Error("negative radius: " + r);
    if (this._x1 === null) {
      this._ += "M" + x0 + "," + y0;
    } else if (Math.abs(this._x1 - x0) > epsilon2 || Math.abs(this._y1 - y0) > epsilon2) {
      this._ += "L" + x0 + "," + y0;
    }
    if (!r) return;
    if (da < 0) da = da % tau + tau;
    if (da > tauEpsilon) {
      this._ += "A" + r + "," + r + ",0,1," + cw + "," + (x2 - dx) + "," + (y2 - dy) + "A" + r + "," + r + ",0,1," + cw + "," + (this._x1 = x0) + "," + (this._y1 = y0);
    } else if (da > epsilon2) {
      this._ += "A" + r + "," + r + ",0," + +(da >= pi) + "," + cw + "," + (this._x1 = x2 + r * Math.cos(a1)) + "," + (this._y1 = y2 + r * Math.sin(a1));
    }
  },
  rect: function(x2, y2, w, h) {
    this._ += "M" + (this._x0 = this._x1 = +x2) + "," + (this._y0 = this._y1 = +y2) + "h" + +w + "v" + +h + "h" + -w + "Z";
  },
  toString: function() {
    return this._;
  }
};
var path_default = path;

// node_modules/d3-shape/src/constant.js
function constant_default3(x2) {
  return function constant() {
    return x2;
  };
}

// node_modules/d3-shape/src/math.js
var abs = Math.abs;
var atan2 = Math.atan2;
var cos = Math.cos;
var max = Math.max;
var min = Math.min;
var sin = Math.sin;
var sqrt = Math.sqrt;
var epsilon3 = 1e-12;
var pi2 = Math.PI;
var halfPi = pi2 / 2;
var tau2 = 2 * pi2;
function acos(x2) {
  return x2 > 1 ? 0 : x2 < -1 ? pi2 : Math.acos(x2);
}
function asin(x2) {
  return x2 >= 1 ? halfPi : x2 <= -1 ? -halfPi : Math.asin(x2);
}

// node_modules/d3-shape/src/arc.js
function arcInnerRadius(d) {
  return d.innerRadius;
}
function arcOuterRadius(d) {
  return d.outerRadius;
}
function arcStartAngle(d) {
  return d.startAngle;
}
function arcEndAngle(d) {
  return d.endAngle;
}
function arcPadAngle(d) {
  return d && d.padAngle;
}
function intersect(x0, y0, x1, y1, x2, y2, x3, y3) {
  var x10 = x1 - x0, y10 = y1 - y0, x32 = x3 - x2, y32 = y3 - y2, t = y32 * x10 - x32 * y10;
  if (t * t < epsilon3) return;
  t = (x32 * (y0 - y2) - y32 * (x0 - x2)) / t;
  return [x0 + t * x10, y0 + t * y10];
}
function cornerTangents(x0, y0, x1, y1, r1, rc, cw) {
  var x01 = x0 - x1, y01 = y0 - y1, lo = (cw ? rc : -rc) / sqrt(x01 * x01 + y01 * y01), ox = lo * y01, oy = -lo * x01, x11 = x0 + ox, y11 = y0 + oy, x10 = x1 + ox, y10 = y1 + oy, x00 = (x11 + x10) / 2, y00 = (y11 + y10) / 2, dx = x10 - x11, dy = y10 - y11, d2 = dx * dx + dy * dy, r = r1 - rc, D = x11 * y10 - x10 * y11, d = (dy < 0 ? -1 : 1) * sqrt(max(0, r * r * d2 - D * D)), cx0 = (D * dy - dx * d) / d2, cy0 = (-D * dx - dy * d) / d2, cx1 = (D * dy + dx * d) / d2, cy1 = (-D * dx + dy * d) / d2, dx0 = cx0 - x00, dy0 = cy0 - y00, dx1 = cx1 - x00, dy1 = cy1 - y00;
  if (dx0 * dx0 + dy0 * dy0 > dx1 * dx1 + dy1 * dy1) cx0 = cx1, cy0 = cy1;
  return {
    cx: cx0,
    cy: cy0,
    x01: -ox,
    y01: -oy,
    x11: cx0 * (r1 / r - 1),
    y11: cy0 * (r1 / r - 1)
  };
}
function arc_default() {
  var innerRadius = arcInnerRadius, outerRadius = arcOuterRadius, cornerRadius = constant_default3(0), padRadius = null, startAngle = arcStartAngle, endAngle = arcEndAngle, padAngle = arcPadAngle, context = null;
  function arc() {
    var buffer, r, r0 = +innerRadius.apply(this, arguments), r1 = +outerRadius.apply(this, arguments), a0 = startAngle.apply(this, arguments) - halfPi, a1 = endAngle.apply(this, arguments) - halfPi, da = abs(a1 - a0), cw = a1 > a0;
    if (!context) context = buffer = path_default();
    if (r1 < r0) r = r1, r1 = r0, r0 = r;
    if (!(r1 > epsilon3)) context.moveTo(0, 0);
    else if (da > tau2 - epsilon3) {
      context.moveTo(r1 * cos(a0), r1 * sin(a0));
      context.arc(0, 0, r1, a0, a1, !cw);
      if (r0 > epsilon3) {
        context.moveTo(r0 * cos(a1), r0 * sin(a1));
        context.arc(0, 0, r0, a1, a0, cw);
      }
    } else {
      var a01 = a0, a11 = a1, a00 = a0, a10 = a1, da0 = da, da1 = da, ap = padAngle.apply(this, arguments) / 2, rp = ap > epsilon3 && (padRadius ? +padRadius.apply(this, arguments) : sqrt(r0 * r0 + r1 * r1)), rc = min(abs(r1 - r0) / 2, +cornerRadius.apply(this, arguments)), rc0 = rc, rc1 = rc, t02, t12;
      if (rp > epsilon3) {
        var p0 = asin(rp / r0 * sin(ap)), p1 = asin(rp / r1 * sin(ap));
        if ((da0 -= p0 * 2) > epsilon3) p0 *= cw ? 1 : -1, a00 += p0, a10 -= p0;
        else da0 = 0, a00 = a10 = (a0 + a1) / 2;
        if ((da1 -= p1 * 2) > epsilon3) p1 *= cw ? 1 : -1, a01 += p1, a11 -= p1;
        else da1 = 0, a01 = a11 = (a0 + a1) / 2;
      }
      var x01 = r1 * cos(a01), y01 = r1 * sin(a01), x10 = r0 * cos(a10), y10 = r0 * sin(a10);
      if (rc > epsilon3) {
        var x11 = r1 * cos(a11), y11 = r1 * sin(a11), x00 = r0 * cos(a00), y00 = r0 * sin(a00), oc;
        if (da < pi2 && (oc = intersect(x01, y01, x00, y00, x11, y11, x10, y10))) {
          var ax = x01 - oc[0], ay = y01 - oc[1], bx = x11 - oc[0], by = y11 - oc[1], kc = 1 / sin(acos((ax * bx + ay * by) / (sqrt(ax * ax + ay * ay) * sqrt(bx * bx + by * by))) / 2), lc = sqrt(oc[0] * oc[0] + oc[1] * oc[1]);
          rc0 = min(rc, (r0 - lc) / (kc - 1));
          rc1 = min(rc, (r1 - lc) / (kc + 1));
        }
      }
      if (!(da1 > epsilon3)) context.moveTo(x01, y01);
      else if (rc1 > epsilon3) {
        t02 = cornerTangents(x00, y00, x01, y01, r1, rc1, cw);
        t12 = cornerTangents(x11, y11, x10, y10, r1, rc1, cw);
        context.moveTo(t02.cx + t02.x01, t02.cy + t02.y01);
        if (rc1 < rc) context.arc(t02.cx, t02.cy, rc1, atan2(t02.y01, t02.x01), atan2(t12.y01, t12.x01), !cw);
        else {
          context.arc(t02.cx, t02.cy, rc1, atan2(t02.y01, t02.x01), atan2(t02.y11, t02.x11), !cw);
          context.arc(0, 0, r1, atan2(t02.cy + t02.y11, t02.cx + t02.x11), atan2(t12.cy + t12.y11, t12.cx + t12.x11), !cw);
          context.arc(t12.cx, t12.cy, rc1, atan2(t12.y11, t12.x11), atan2(t12.y01, t12.x01), !cw);
        }
      } else context.moveTo(x01, y01), context.arc(0, 0, r1, a01, a11, !cw);
      if (!(r0 > epsilon3) || !(da0 > epsilon3)) context.lineTo(x10, y10);
      else if (rc0 > epsilon3) {
        t02 = cornerTangents(x10, y10, x11, y11, r0, -rc0, cw);
        t12 = cornerTangents(x01, y01, x00, y00, r0, -rc0, cw);
        context.lineTo(t02.cx + t02.x01, t02.cy + t02.y01);
        if (rc0 < rc) context.arc(t02.cx, t02.cy, rc0, atan2(t02.y01, t02.x01), atan2(t12.y01, t12.x01), !cw);
        else {
          context.arc(t02.cx, t02.cy, rc0, atan2(t02.y01, t02.x01), atan2(t02.y11, t02.x11), !cw);
          context.arc(0, 0, r0, atan2(t02.cy + t02.y11, t02.cx + t02.x11), atan2(t12.cy + t12.y11, t12.cx + t12.x11), cw);
          context.arc(t12.cx, t12.cy, rc0, atan2(t12.y11, t12.x11), atan2(t12.y01, t12.x01), !cw);
        }
      } else context.arc(0, 0, r0, a10, a00, cw);
    }
    context.closePath();
    if (buffer) return context = null, buffer + "" || null;
  }
  arc.centroid = function() {
    var r = (+innerRadius.apply(this, arguments) + +outerRadius.apply(this, arguments)) / 2, a = (+startAngle.apply(this, arguments) + +endAngle.apply(this, arguments)) / 2 - pi2 / 2;
    return [cos(a) * r, sin(a) * r];
  };
  arc.innerRadius = function(_) {
    return arguments.length ? (innerRadius = typeof _ === "function" ? _ : constant_default3(+_), arc) : innerRadius;
  };
  arc.outerRadius = function(_) {
    return arguments.length ? (outerRadius = typeof _ === "function" ? _ : constant_default3(+_), arc) : outerRadius;
  };
  arc.cornerRadius = function(_) {
    return arguments.length ? (cornerRadius = typeof _ === "function" ? _ : constant_default3(+_), arc) : cornerRadius;
  };
  arc.padRadius = function(_) {
    return arguments.length ? (padRadius = _ == null ? null : typeof _ === "function" ? _ : constant_default3(+_), arc) : padRadius;
  };
  arc.startAngle = function(_) {
    return arguments.length ? (startAngle = typeof _ === "function" ? _ : constant_default3(+_), arc) : startAngle;
  };
  arc.endAngle = function(_) {
    return arguments.length ? (endAngle = typeof _ === "function" ? _ : constant_default3(+_), arc) : endAngle;
  };
  arc.padAngle = function(_) {
    return arguments.length ? (padAngle = typeof _ === "function" ? _ : constant_default3(+_), arc) : padAngle;
  };
  arc.context = function(_) {
    return arguments.length ? (context = _ == null ? null : _, arc) : context;
  };
  return arc;
}

// node_modules/d3-shape/src/curve/linear.js
function Linear(context) {
  this._context = context;
}
Linear.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    if (this._line || this._line !== 0 && this._point === 1) this._context.closePath();
    this._line = 1 - this._line;
  },
  point: function(x2, y2) {
    x2 = +x2, y2 = +y2;
    switch (this._point) {
      case 0:
        this._point = 1;
        this._line ? this._context.lineTo(x2, y2) : this._context.moveTo(x2, y2);
        break;
      case 1:
        this._point = 2;
      // proceed
      default:
        this._context.lineTo(x2, y2);
        break;
    }
  }
};
function linear_default(context) {
  return new Linear(context);
}

// node_modules/d3-shape/src/point.js
function x(p) {
  return p[0];
}
function y(p) {
  return p[1];
}

// node_modules/d3-shape/src/line.js
function line_default() {
  var x2 = x, y2 = y, defined = constant_default3(true), context = null, curve = linear_default, output = null;
  function line(data) {
    var i, n = data.length, d, defined0 = false, buffer;
    if (context == null) output = curve(buffer = path_default());
    for (i = 0; i <= n; ++i) {
      if (!(i < n && defined(d = data[i], i, data)) === defined0) {
        if (defined0 = !defined0) output.lineStart();
        else output.lineEnd();
      }
      if (defined0) output.point(+x2(d, i, data), +y2(d, i, data));
    }
    if (buffer) return output = null, buffer + "" || null;
  }
  line.x = function(_) {
    return arguments.length ? (x2 = typeof _ === "function" ? _ : constant_default3(+_), line) : x2;
  };
  line.y = function(_) {
    return arguments.length ? (y2 = typeof _ === "function" ? _ : constant_default3(+_), line) : y2;
  };
  line.defined = function(_) {
    return arguments.length ? (defined = typeof _ === "function" ? _ : constant_default3(!!_), line) : defined;
  };
  line.curve = function(_) {
    return arguments.length ? (curve = _, context != null && (output = curve(context)), line) : curve;
  };
  line.context = function(_) {
    return arguments.length ? (_ == null ? context = output = null : output = curve(context = _), line) : context;
  };
  return line;
}

// node_modules/d3-shape/src/descending.js
function descending_default(a, b) {
  return b < a ? -1 : b > a ? 1 : b >= a ? 0 : NaN;
}

// node_modules/d3-shape/src/identity.js
function identity_default3(d) {
  return d;
}

// node_modules/d3-shape/src/pie.js
function pie_default() {
  var value = identity_default3, sortValues = descending_default, sort = null, startAngle = constant_default3(0), endAngle = constant_default3(tau2), padAngle = constant_default3(0);
  function pie(data) {
    var i, n = data.length, j, k, sum = 0, index = new Array(n), arcs = new Array(n), a0 = +startAngle.apply(this, arguments), da = Math.min(tau2, Math.max(-tau2, endAngle.apply(this, arguments) - a0)), a1, p = Math.min(Math.abs(da) / n, padAngle.apply(this, arguments)), pa = p * (da < 0 ? -1 : 1), v;
    for (i = 0; i < n; ++i) {
      if ((v = arcs[index[i] = i] = +value(data[i], i, data)) > 0) {
        sum += v;
      }
    }
    if (sortValues != null) index.sort(function(i2, j2) {
      return sortValues(arcs[i2], arcs[j2]);
    });
    else if (sort != null) index.sort(function(i2, j2) {
      return sort(data[i2], data[j2]);
    });
    for (i = 0, k = sum ? (da - n * pa) / sum : 0; i < n; ++i, a0 = a1) {
      j = index[i], v = arcs[j], a1 = a0 + (v > 0 ? v * k : 0) + pa, arcs[j] = {
        data: data[j],
        index: i,
        value: v,
        startAngle: a0,
        endAngle: a1,
        padAngle: p
      };
    }
    return arcs;
  }
  pie.value = function(_) {
    return arguments.length ? (value = typeof _ === "function" ? _ : constant_default3(+_), pie) : value;
  };
  pie.sortValues = function(_) {
    return arguments.length ? (sortValues = _, sort = null, pie) : sortValues;
  };
  pie.sort = function(_) {
    return arguments.length ? (sort = _, sortValues = null, pie) : sort;
  };
  pie.startAngle = function(_) {
    return arguments.length ? (startAngle = typeof _ === "function" ? _ : constant_default3(+_), pie) : startAngle;
  };
  pie.endAngle = function(_) {
    return arguments.length ? (endAngle = typeof _ === "function" ? _ : constant_default3(+_), pie) : endAngle;
  };
  pie.padAngle = function(_) {
    return arguments.length ? (padAngle = typeof _ === "function" ? _ : constant_default3(+_), pie) : padAngle;
  };
  return pie;
}

// node_modules/d3-shape/src/noop.js
function noop_default() {
}

// node_modules/d3-shape/src/curve/linearClosed.js
function LinearClosed(context) {
  this._context = context;
}
LinearClosed.prototype = {
  areaStart: noop_default,
  areaEnd: noop_default,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    if (this._point) this._context.closePath();
  },
  point: function(x2, y2) {
    x2 = +x2, y2 = +y2;
    if (this._point) this._context.lineTo(x2, y2);
    else this._point = 1, this._context.moveTo(x2, y2);
  }
};
function linearClosed_default(context) {
  return new LinearClosed(context);
}

// node_modules/d3-shape/src/curve/monotone.js
function sign(x2) {
  return x2 < 0 ? -1 : 1;
}
function slope3(that, x2, y2) {
  var h0 = that._x1 - that._x0, h1 = x2 - that._x1, s0 = (that._y1 - that._y0) / (h0 || h1 < 0 && -0), s1 = (y2 - that._y1) / (h1 || h0 < 0 && -0), p = (s0 * h1 + s1 * h0) / (h0 + h1);
  return (sign(s0) + sign(s1)) * Math.min(Math.abs(s0), Math.abs(s1), 0.5 * Math.abs(p)) || 0;
}
function slope2(that, t) {
  var h = that._x1 - that._x0;
  return h ? (3 * (that._y1 - that._y0) / h - t) / 2 : t;
}
function point2(that, t02, t12) {
  var x0 = that._x0, y0 = that._y0, x1 = that._x1, y1 = that._y1, dx = (x1 - x0) / 3;
  that._context.bezierCurveTo(x0 + dx, y0 + dx * t02, x1 - dx, y1 - dx * t12, x1, y1);
}
function MonotoneX(context) {
  this._context = context;
}
MonotoneX.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN;
    this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        point2(this, this._t0, slope2(this, this._t0));
        break;
    }
    if (this._line || this._line !== 0 && this._point === 1) this._context.closePath();
    this._line = 1 - this._line;
  },
  point: function(x2, y2) {
    var t12 = NaN;
    x2 = +x2, y2 = +y2;
    if (x2 === this._x1 && y2 === this._y1) return;
    switch (this._point) {
      case 0:
        this._point = 1;
        this._line ? this._context.lineTo(x2, y2) : this._context.moveTo(x2, y2);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        point2(this, slope2(this, t12 = slope3(this, x2, y2)), t12);
        break;
      default:
        point2(this, this._t0, t12 = slope3(this, x2, y2));
        break;
    }
    this._x0 = this._x1, this._x1 = x2;
    this._y0 = this._y1, this._y1 = y2;
    this._t0 = t12;
  }
};
function MonotoneY(context) {
  this._context = new ReflectContext(context);
}
(MonotoneY.prototype = Object.create(MonotoneX.prototype)).point = function(x2, y2) {
  MonotoneX.prototype.point.call(this, y2, x2);
};
function ReflectContext(context) {
  this._context = context;
}
ReflectContext.prototype = {
  moveTo: function(x2, y2) {
    this._context.moveTo(y2, x2);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(x2, y2) {
    this._context.lineTo(y2, x2);
  },
  bezierCurveTo: function(x1, y1, x2, y2, x3, y3) {
    this._context.bezierCurveTo(y1, x1, y2, x2, y3, x3);
  }
};
function monotoneX(context) {
  return new MonotoneX(context);
}

// src/utils/addLegend.js
function addLegend(parent, {
  items,
  position,
  unxkcdify,
  parentWidth,
  parentHeight,
  strokeColor,
  backgroundColor
}) {
  const filter = !unxkcdify ? config_default.filterUrl : null;
  const legend = parent.append("svg");
  const backgroundLayer = legend.append("svg");
  const textLayer = legend.append("svg");
  items.forEach((item, i) => {
    const itemY = 17 + config_default.itemRowHeight * i;
    textLayer.append("rect").style("fill", item.color).attr("width", config_default.swatchSize).attr("height", config_default.swatchSize).attr("filter", filter).attr("rx", config_default.swatchCornerRadius).attr("ry", config_default.swatchCornerRadius).attr("x", config_default.itemXOffset).attr("y", itemY);
    textLayer.append("text").style("font-size", config_default.tooltipFontSize).style("fill", strokeColor).attr("x", config_default.itemXOffset + config_default.itemTextOffset).attr("y", itemY + config_default.swatchSize).text(item.text);
  });
  setTimeout(() => {
    const bbox = textLayer.node().getBBox();
    const backgroundWidth = bbox.width + config_default.itemXOffset;
    const backgroundHeight = bbox.height + 10;
    let legendX = 0;
    let legendY = 0;
    if (position === config_default.positionType.downLeft || position === config_default.positionType.downRight) {
      legendY = parentHeight - backgroundHeight - 13;
    }
    if (position === config_default.positionType.upRight || position === config_default.positionType.downRight) {
      legendX = parentWidth - backgroundWidth - 13;
    }
    backgroundLayer.append("rect").style("fill", backgroundColor).attr("filter", filter).attr("fill-opacity", config_default.legendBackgroundOpacity).attr("stroke", strokeColor).attr("stroke-width", config_default.backgroundStrokeWidth).attr("width", backgroundWidth).attr("height", backgroundHeight).attr("rx", config_default.backgroundCornerRadius).attr("ry", config_default.backgroundCornerRadius).attr("x", 8).attr("y", 5);
    legend.attr("x", legendX).attr("y", legendY);
  }, 10);
}

// src/Line.js
var Line = class {
  constructor(svg, {
    title: title2,
    xLabel: xLabel2,
    yLabel: yLabel2,
    data: { labels, datasets },
    options
  }) {
    this.options = applyDefaults({
      yTickCount: config_default.defaultTickCount,
      legendPosition: config_default.positionType.upLeft,
      showLegend: true,
      ...options
    }, datasets);
    this.title = title2;
    this.xLabel = xLabel2;
    this.yLabel = yLabel2;
    this.data = { labels, datasets };
    const margin = setupMargin({ title: title2, xLabel: xLabel2, yLabel: yLabel2 });
    const { filter, fontFamily } = resolveFilterAndFont(this.options, false);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroup(
      this.svgEl,
      margin,
      { title: title2, xLabel: xLabel2, yLabel: yLabel2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.margin = margin;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    const xScale = point().domain(this.data.labels).range([0, this.width]);
    const allData = this.data.datasets.reduce((pre, cur) => pre.concat(cur.data), []);
    const yScale = linear2().domain([Math.min(...allData), Math.max(...allData)]).range([this.height, 0]);
    const graphPart = this.chart.append("g").attr("pointer-events", "all");
    addAxis_default.xAxis(graphPart, {
      xScale,
      tickCount: config_default.defaultTickCount,
      moveDown: this.height,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    addAxis_default.yAxis(graphPart, {
      yScale,
      tickCount: this.options.yTickCount,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    this.svgEl.selectAll(".domain").attr("filter", this.filter);
    const theLine = line_default().x((d, i) => xScale(this.data.labels[i])).y((d) => yScale(d)).curve(monotoneX);
    graphPart.selectAll(".xkcd-chart-line").data(this.data.datasets).enter().append("path").attr("class", "xkcd-chart-line").attr("d", (d) => theLine(d.data)).attr("fill", "none").attr("stroke", (d, i) => this.options.dataColors[i]).attr("filter", this.filter);
    const verticalLine = graphPart.append("line").attr("x1", 30).attr("y1", 0).attr("x2", 30).attr("y2", this.height).attr("stroke", "#aaa").attr("stroke-width", 1.5).attr("stroke-dasharray", "7,7").style("visibility", "hidden");
    const circles = this.data.datasets.map((dataset, i) => graphPart.append("circle").style("stroke", this.options.dataColors[i]).style("fill", this.options.dataColors[i]).attr("r", config_default.dotInitRadius).style("visibility", "hidden"));
    graphPart.append("rect").attr("width", this.width).attr("height", this.height).attr("fill", "none").on("mouseover", () => {
      circles.forEach((circle) => circle.style("visibility", "visible"));
      verticalLine.style("visibility", "visible");
      tooltip.show();
    }).on("mouseout", () => {
      circles.forEach((circle) => circle.style("visibility", "hidden"));
      verticalLine.style("visibility", "hidden");
      tooltip.hide();
    }).on("click", (d, i, nodes) => {
      if (this.options.onSelect) {
        const labelXs = this.data.labels.map((label) => xScale(label) + this.margin.left);
        const mouseLabelDistances = labelXs.map(
          (labelX) => Math.abs(labelX - mouse_default(nodes[i])[0] - this.margin.left)
        );
        const nearestIndex = mouseLabelDistances.indexOf(Math.min(...mouseLabelDistances));
        this.options.onSelect({
          index: nearestIndex,
          label: this.data.labels[nearestIndex],
          values: this.data.datasets.map((dataset) => ({
            label: dataset.label,
            value: dataset.data[nearestIndex]
          }))
        }, event.shiftKey);
      }
    }).on("mousemove", (d, i, nodes) => {
      const tipX = mouse_default(nodes[i])[0] + this.margin.left + config_default.tooltipMouseOffset;
      const tipY = mouse_default(nodes[i])[1] + this.margin.top + config_default.tooltipMouseOffset;
      const labelXs = this.data.labels.map((label) => xScale(label) + this.margin.left);
      const mouseLabelDistances = labelXs.map(
        (labelX) => Math.abs(labelX - mouse_default(nodes[i])[0] - this.margin.left)
      );
      const nearestIndex = mouseLabelDistances.indexOf(Math.min(...mouseLabelDistances));
      verticalLine.attr("x1", xScale(this.data.labels[nearestIndex])).attr("x2", xScale(this.data.labels[nearestIndex]));
      this.data.datasets.forEach((dataset, j) => {
        circles[j].style("visibility", "visible").attr("cx", xScale(this.data.labels[nearestIndex])).attr("cy", yScale(dataset.data[nearestIndex]));
      });
      const tooltipItems = this.data.datasets.map((dataset, j) => ({
        color: this.options.dataColors[j],
        text: `${this.data.datasets[j].label || ""}: ${this.data.datasets[j].data[nearestIndex]}`
      }));
      tooltip.update({
        title: this.data.labels[nearestIndex],
        items: tooltipItems,
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
    });
    if (this.options.showLegend) {
      const legendItems = this.data.datasets.map((dataset, i) => ({
        color: this.options.dataColors[i],
        text: dataset.label
      }));
      addLegend(graphPart, {
        items: legendItems,
        position: this.options.legendPosition,
        unxkcdify: this.options.unxkcdify,
        parentWidth: this.width,
        parentHeight: this.height,
        backgroundColor: this.options.backgroundColor,
        strokeColor: this.options.strokeColor
      });
    }
  }
};
var Line_default = Line;

// src/Pie.js
var Pie = class {
  constructor(svg, {
    title: title2,
    data: { labels, datasets },
    options
  }) {
    this.options = applyDefaults({
      innerRadius: 0.5,
      legendPosition: config_default.positionType.upLeft,
      showLegend: true,
      ...options
    });
    this.title = title2;
    this.data = { labels, datasets };
    const { filter, fontFamily } = resolveFilterAndFont(this.options, true);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroupSimple(
      this.svgEl,
      { title: title2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    const radius = Math.min(this.width, this.height) / 2 - config_default.marginScalar;
    const thePie = pie_default();
    const dataReady = thePie(this.data.datasets[0].data);
    const theArc = arc_default().innerRadius(radius * (this.options.innerRadius || 0.5)).outerRadius(radius);
    this.chart.selectAll(".xkcd-chart-arc").data(dataReady).enter().append("path").attr("class", ".xkcd-chart-arc").attr("d", theArc).attr("fill", "none").attr("stroke", this.options.strokeColor).attr("stroke-width", config_default.pieStrokeWidth).attr("fill", (d, i) => this.options.dataColors[i]).attr("filter", this.filter).on("mouseover", (d, i, nodes) => {
      select_default2(nodes[i]).attr("fill-opacity", 0.6);
      tooltip.show();
    }).on("mouseout", (d, i, nodes) => {
      select_default2(nodes[i]).attr("fill-opacity", 1);
      tooltip.hide();
    }).on("click", (d, i) => {
      if (this.options.onSelect) {
        this.options.onSelect({
          index: i,
          label: this.data.labels[i],
          value: d.data
        }, event.shiftKey);
      }
    }).on("mousemove", (d, i, nodes) => {
      const tipX = mouse_default(nodes[i])[0] + this.width / 2 + config_default.tooltipMouseOffset;
      const tipY = mouse_default(nodes[i])[1] + this.height / 2 + config_default.tooltipMouseOffset;
      tooltip.update({
        title: this.data.labels[i],
        items: [{
          color: this.options.dataColors[i],
          text: `${this.data.datasets[0].label || ""}: ${d.data}`
        }],
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
    });
    if (this.options.showLegend) {
      const legendItems = this.data.datasets[0].data.map((data, i) => ({ color: this.options.dataColors[i], text: this.data.labels[i] }));
      const legendG = this.svgEl.append("g").attr("transform", "translate(0, 30)");
      addLegend(legendG, {
        items: legendItems,
        position: this.options.legendPosition,
        unxkcdify: this.options.unxkcdify,
        parentWidth: this.width,
        parentHeight: this.height,
        strokeColor: this.options.strokeColor,
        backgroundColor: this.options.backgroundColor
      });
    }
  }
};
var Pie_default = Pie;

// src/Radar.js
var angleOffset = -Math.PI / 2;
var Radar = class {
  constructor(svg, {
    title: title2,
    data: { labels, datasets },
    options
  }) {
    this.options = applyDefaults({
      showLabels: false,
      ticksCount: config_default.defaultTickCount,
      showLegend: false,
      legendPosition: config_default.positionType.upLeft,
      dotSize: 1,
      ...options
    }, datasets);
    this.title = title2;
    this.data = { labels, datasets };
    this.directionsCount = datasets[0].data.length;
    const { filter, fontFamily } = resolveFilterAndFont(this.options, true);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroupSimple(
      this.svgEl,
      { title: title2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    const dotInitSize = config_default.dotInitRadius * (this.options.dotSize || 1);
    const dotHoverSize = config_default.dotHoverRadius * (this.options.dotSize || 1);
    const radius = Math.min(this.width, this.height) / 2 - config_default.marginScalar;
    const angleStep = Math.PI * 2 / this.directionsCount;
    const allDataValues = this.data.datasets.reduce((acc, cur) => acc.concat(cur.data), []);
    const maxValue = Math.max(...allDataValues);
    const allMaxData = Array(this.directionsCount).fill(maxValue);
    const valueScale = linear2().domain([0, maxValue]).range([0, radius]);
    const getX = (d, i) => valueScale(d) * Math.cos(angleStep * i + angleOffset);
    const getY = (d, i) => valueScale(d) * Math.sin(angleStep * i + angleOffset);
    const theLine = line_default().x(getX).y(getY).curve(linearClosed_default);
    const ticks = valueScale.ticks(this.options.ticksCount || config_default.defaultTickCount);
    const grid = this.chart.append("g").attr("class", "xkcd-chart-radar-grid").attr("stroke-width", "1").attr("filter", this.filter);
    grid.selectAll(".xkcd-chart-radar-level").data(ticks).enter().append("path").attr("class", "xkcd-chart-radar-level").attr("d", (d) => theLine(Array(this.directionsCount).fill(d))).style("fill", "none").attr("stroke", this.options.strokeColor).attr("stroke-dasharray", "7,7");
    grid.selectAll(".xkcd-chart-radar-line").data(allMaxData).enter().append("line").attr("class", ".xkcd-chart-radar-line").attr("stroke", this.options.strokeColor).attr("x1", 0).attr("y1", 0).attr("x2", getX).attr("y2", getY);
    grid.selectAll(".xkcd-chart-radar-tick").data(ticks).enter().append("text").attr("class", "xkcd-chart-radar-tick").attr("x", (d) => getX(d, 0)).attr("y", (d) => getY(d, 0)).style("font-size", config_default.tickFontSize).style("fill", this.options.strokeColor).attr("text-anchor", "end").attr("dx", "-.125em").attr("dy", ".35em").text((d) => d);
    if (this.options.showLabels) {
      grid.selectAll(".xkcd-chart-radar-label").data(allMaxData.map((d) => d * 1.15)).enter().append("text").attr("class", "xkcd-chart-radar-label").style("font-size", config_default.tickFontSize).style("fill", this.options.strokeColor).attr("x", (d, i) => (radius + 10) * Math.cos(angleStep * i + angleOffset)).attr("y", (d, i) => (radius + 10) * Math.sin(angleStep * i + angleOffset)).attr("dy", ".35em").attr("text-anchor", (d, i, nodes) => {
        const node = select_default2(nodes[i]);
        return node.attr("x") < 0 ? "end" : "start";
      }).text((d, i) => this.data.labels[i]);
    }
    const layers = this.chart.selectAll(".xkcd-chart-radar-group").data(this.data.datasets).enter().append("g").attr("class", "xkcd-chart-radar-group").attr("filter", this.filter).attr("stroke", (d, i) => this.options.dataColors[i]).attr("fill", (d, i) => this.options.dataColors[i]);
    layers.selectAll("circle").data((dataset) => dataset.data).enter().append("circle").attr("r", dotInitSize).attr("cx", getX).attr("cy", getY).attr("pointer-events", "all").on("click", (d, i) => {
      if (this.options.onSelect) {
        this.options.onSelect({
          index: i,
          label: this.data.labels[i],
          values: this.data.datasets.map((dataset) => ({
            label: dataset.label,
            value: dataset.data[i]
          }))
        }, event.shiftKey);
      }
    }).on("mouseover", (d, i, nodes) => {
      select_default2(nodes[i]).attr("r", dotHoverSize);
      const tipX = getX(d, i) + this.width / 2;
      const tipY = getY(d, i) + this.height / 2;
      tooltip.update({
        title: this.data.labels[i],
        items: this.data.datasets.map((dataset, datasetIndex) => ({
          color: this.options.dataColors[datasetIndex],
          text: `${dataset.label || ""}: ${dataset.data[i]}`
        })),
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
      tooltip.show();
    }).on("mouseout", (d, i, nodes) => {
      select_default2(nodes[i]).attr("r", dotInitSize);
      tooltip.hide();
    });
    layers.selectAll("path").data((dataset) => [dataset.data]).enter().append("path").attr("d", theLine).attr("pointer-events", "none").style("fill-opacity", config_default.radarAreaOpacity);
    if (this.options.showLegend) {
      const legendItems = this.data.datasets.map((data, i) => ({ color: this.options.dataColors[i], text: data.label || "" }));
      const legendG = this.svgEl.append("g").attr("transform", "translate(0, 30)");
      addLegend(legendG, {
        items: legendItems,
        position: this.options.legendPosition,
        unxkcdify: this.options.unxkcdify,
        parentWidth: this.width,
        parentHeight: this.height,
        backgroundColor: this.options.backgroundColor,
        strokeColor: this.options.strokeColor
      });
    }
  }
};
var Radar_default = Radar;

// src/Scatter.js
var import_dayjs = __toESM(require_dayjs_min());
var Scatter = class {
  constructor(svg, {
    title: title2,
    xLabel: xLabel2,
    yLabel: yLabel2,
    data: { datasets },
    options
  }) {
    this.options = applyDefaults({
      dotSize: 1,
      showLine: false,
      timeFormat: "",
      xTickCount: config_default.defaultTickCount,
      yTickCount: config_default.defaultTickCount,
      legendPosition: config_default.positionType.upLeft,
      showLegend: true,
      ...options
    }, datasets);
    this.title = title2;
    this.xLabel = xLabel2;
    this.yLabel = yLabel2;
    this.data = { datasets };
    const margin = setupMargin({ title: title2, xLabel: xLabel2, yLabel: yLabel2 });
    const { filter, fontFamily } = resolveFilterAndFont(this.options, false);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroup(
      this.svgEl,
      margin,
      { title: title2, xLabel: xLabel2, yLabel: yLabel2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.margin = margin;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    if (this.options.timeFormat) {
      this.data.datasets.forEach((dataset) => {
        dataset.data.forEach((d) => {
          d.x = (0, import_dayjs.default)(d.x);
        });
      });
    }
    const allData = this.data.datasets.reduce((pre, cur) => pre.concat(cur.data), []);
    const allDataX = allData.map((d) => d.x);
    const allDataY = allData.map((d) => d.y);
    let xScale = linear2().domain([Math.min(...allDataX), Math.max(...allDataX)]).range([0, this.width]);
    if (this.options.timeFormat) {
      xScale = time().domain([Math.min(...allDataX), Math.max(...allDataX)]).range([0, this.width]);
    }
    const yScale = linear2().domain([Math.min(...allDataY), Math.max(...allDataY)]).range([this.height, 0]);
    const graphPart = this.chart.append("g").attr("pointer-events", "all");
    addAxis_default.xAxis(graphPart, {
      xScale,
      tickCount: this.options.xTickCount,
      moveDown: this.height,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    addAxis_default.yAxis(graphPart, {
      yScale,
      tickCount: this.options.yTickCount,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    if (this.options.showLine) {
      const theLine = line_default().x((d) => xScale(d.x)).y((d) => yScale(d.y)).curve(monotoneX);
      graphPart.selectAll(".xkcd-chart-xyline").data(this.data.datasets).enter().append("path").attr("class", "xkcd-chart-xyline").attr("d", (d) => theLine(d.data)).attr("fill", "none").attr("stroke", (d, i) => this.options.dataColors[i]).attr("filter", this.filter);
    }
    const dotInitSize = config_default.dotInitRadius * (this.options.dotSize || 1);
    const dotHoverSize = config_default.dotHoverRadius * (this.options.dotSize || 1);
    graphPart.selectAll(".xkcd-chart-xycircle-group").data(this.data.datasets).enter().append("g").attr("class", ".xkcd-chart-xycircle-group").attr("filter", this.filter).attr("xy-group-index", (d, i) => i).selectAll(".xkcd-chart-xycircle-circle").data((dataset) => dataset.data).enter().append("circle").style("stroke", (d, i, nodes) => {
      const xyGroupIndex = Number(select_default2(nodes[i].parentElement).attr("xy-group-index"));
      return this.options.dataColors[xyGroupIndex];
    }).style("fill", (d, i, nodes) => {
      const xyGroupIndex = Number(select_default2(nodes[i].parentElement).attr("xy-group-index"));
      return this.options.dataColors[xyGroupIndex];
    }).attr("r", dotInitSize).attr("cx", (d) => xScale(d.x)).attr("cy", (d) => yScale(d.y)).attr("pointer-events", "all").on("click", (d, i, nodes) => {
      if (this.options.onSelect) {
        const xyGroupIndex = Number(select_default2(nodes[i].parentElement).attr("xy-group-index"));
        this.options.onSelect({
          dataset_index: xyGroupIndex,
          point_index: i,
          label: this.data.datasets[xyGroupIndex].label,
          x: d.x,
          y: d.y
        }, event.shiftKey);
      }
    }).on("mouseover", (d, i, nodes) => {
      const xyGroupIndex = Number(select_default2(nodes[i].parentElement).attr("xy-group-index"));
      select_default2(nodes[i]).attr("r", dotHoverSize);
      const tipX = xScale(d.x) + this.margin.left + config_default.scatterMouseOffset;
      const tipY = yScale(d.y) + this.margin.top + config_default.scatterMouseOffset;
      tooltip.update({
        title: this.options.timeFormat ? (0, import_dayjs.default)(this.data.datasets[xyGroupIndex].data[i].x).format(this.options.timeFormat) : `${this.data.datasets[xyGroupIndex].data[i].x}`,
        items: [{
          color: this.options.dataColors[xyGroupIndex],
          text: `${this.data.datasets[xyGroupIndex].label || ""}: ${d.y}`
        }],
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
      tooltip.show();
    }).on("mouseout", (d, i, nodes) => {
      select_default2(nodes[i]).attr("r", dotInitSize);
      tooltip.hide();
    });
    if (this.options.onSelect) {
      let dragStart = null;
      const selRect = graphPart.append("rect").attr("class", "xkcd-chart-select-rect").attr("fill", "rgba(0,0,0,0.1)").attr("stroke", this.options.strokeColor).attr("stroke-width", 1).attr("stroke-dasharray", "4,4").style("visibility", "hidden");
      graphPart.insert("rect", ":first-child").attr("class", "xkcd-chart-drag-overlay").attr("width", this.width).attr("height", this.height).attr("fill", "none").attr("pointer-events", "all").on("mousedown", () => {
        const e = event;
        if (e.button !== 0) return;
        const svgNode = this.svgEl.node();
        const pt = svgNode.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const local = pt.matrixTransform(graphPart.node().getScreenCTM().inverse());
        dragStart = { x: local.x, y: local.y };
        selRect.style("visibility", "hidden");
      });
      select_default2(window).on("mousemove.scatter-box", () => {
        if (!dragStart) return;
        const e = event;
        const svgNode = this.svgEl.node();
        const pt = svgNode.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const local = pt.matrixTransform(graphPart.node().getScreenCTM().inverse());
        const x2 = Math.max(0, Math.min(dragStart.x, local.x));
        const y2 = Math.max(0, Math.min(dragStart.y, local.y));
        const w = Math.min(Math.abs(local.x - dragStart.x), this.width - x2);
        const h = Math.min(Math.abs(local.y - dragStart.y), this.height - y2);
        selRect.attr("x", x2).attr("y", y2).attr("width", w).attr("height", h).style("visibility", "visible");
      }).on("mouseup.scatter-box", () => {
        if (!dragStart) return;
        const e = event;
        const svgNode = this.svgEl.node();
        const pt = svgNode.createSVGPoint();
        pt.x = e.clientX;
        pt.y = e.clientY;
        const local = pt.matrixTransform(graphPart.node().getScreenCTM().inverse());
        const x0 = Math.min(dragStart.x, local.x);
        const x1 = Math.max(dragStart.x, local.x);
        const y0 = Math.min(dragStart.y, local.y);
        const y1 = Math.max(dragStart.y, local.y);
        dragStart = null;
        selRect.style("visibility", "hidden");
        if (x1 - x0 < config_default.boxSelectMinDrag && y1 - y0 < config_default.boxSelectMinDrag) return;
        const dataX0 = xScale.invert(x0);
        const dataX1 = xScale.invert(x1);
        const dataY0 = yScale.invert(y1);
        const dataY1 = yScale.invert(y0);
        const selected = [];
        this.data.datasets.forEach((dataset, dsIdx) => {
          dataset.data.forEach((d, ptIdx) => {
            if (d.x >= dataX0 && d.x <= dataX1 && d.y >= dataY0 && d.y <= dataY1) {
              selected.push({
                dataset_index: dsIdx,
                point_index: ptIdx,
                label: dataset.label,
                x: d.x,
                y: d.y
              });
            }
          });
        });
        if (selected.length > 0) {
          this.options.onSelect(selected, e.shiftKey);
        }
      });
    }
    if (this.options.showLegend) {
      const legendItems = this.data.datasets.map(
        (dataset, i) => ({
          color: this.options.dataColors[i],
          text: dataset.label
        })
      );
      addLegend(graphPart, {
        items: legendItems,
        position: this.options.legendPosition,
        unxkcdify: this.options.unxkcdify,
        parentWidth: this.width,
        parentHeight: this.height,
        strokeColor: this.options.strokeColor,
        backgroundColor: this.options.backgroundColor
      });
    }
  }
};
var Scatter_default = Scatter;

// src/StackedBar.js
var StackedBar = class {
  constructor(svg, {
    title: title2,
    xLabel: xLabel2,
    yLabel: yLabel2,
    data: { labels, datasets },
    options
  }) {
    this.options = applyDefaults({
      yTickCount: config_default.defaultTickCount,
      legendPosition: config_default.positionType.upLeft,
      showLegend: true,
      ...options
    }, datasets);
    this.title = title2;
    this.xLabel = xLabel2;
    this.yLabel = yLabel2;
    this.data = { labels, datasets };
    const margin = setupMargin({ title: title2, xLabel: xLabel2, yLabel: yLabel2 });
    const { filter, fontFamily } = resolveFilterAndFont(this.options, false);
    this.filter = filter;
    this.fontFamily = fontFamily;
    this.svgEl = createSvgEl(svg, { fontFamily, backgroundColor: this.options.backgroundColor });
    const { chart, width, height } = setupChartGroup(
      this.svgEl,
      margin,
      { title: title2, xLabel: xLabel2, yLabel: yLabel2, strokeColor: this.options.strokeColor }
    );
    this.chart = chart;
    this.width = width;
    this.height = height;
    this.margin = margin;
    this.render();
  }
  render() {
    const tooltip = createTooltip(this.svgEl, this.options);
    const xScale = band().range([0, this.width]).domain(this.data.labels).padding(config_default.bandPadding);
    const allCols = this.data.datasets.reduce((r, a) => a.data.map((b, i) => (r[i] || 0) + b), []);
    const yScale = linear2().domain([0, Math.max(...allCols)]).range([this.height, 0]);
    const graphPart = this.chart.append("g");
    addAxis_default.xAxis(graphPart, {
      xScale,
      tickCount: config_default.defaultTickCount,
      moveDown: this.height,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    addAxis_default.yAxis(graphPart, {
      yScale,
      tickCount: this.options.yTickCount,
      fontFamily: this.fontFamily,
      unxkcdify: this.options.unxkcdify,
      stroke: this.options.strokeColor
    });
    const mergedData = this.data.datasets.reduce((pre, cur) => pre.concat(cur.data), []);
    const dataLength = this.data.datasets[0].data.length;
    const offsets = this.data.datasets.reduce((r, x2, i) => {
      if (i > 0) {
        r.push(x2.data.map((y2, j) => this.data.datasets[i - 1].data[j] + r[i - 1][j]));
      } else {
        r.push(new Array(x2.data.length).fill(0));
      }
      return r;
    }, []).flat();
    graphPart.selectAll(".xkcd-chart-stacked-bar").data(mergedData).enter().append("rect").attr("class", "xkcd-chart-stacked-bar").attr("x", (d, i) => xScale(this.data.labels[i % dataLength])).attr("width", xScale.bandwidth()).attr("y", (d, i) => yScale(d + offsets[i])).attr("height", (d) => this.height - yScale(d)).attr("fill", (d, i) => this.options.dataColors[Math.floor(i / dataLength)]).attr("pointer-events", "all").attr("stroke", this.options.strokeColor).attr("stroke-width", config_default.barStrokeWidth).attr("rx", config_default.barCornerRadius).attr("filter", this.filter).on("mouseover", () => tooltip.show()).on("mouseout", () => tooltip.hide()).on("click", (d, i) => {
      const colIndex = i % dataLength;
      const dsIndex = Math.floor(i / dataLength);
      if (this.options.onSelect) {
        this.options.onSelect({
          index: colIndex,
          label: this.data.labels[colIndex],
          dataset: this.data.datasets[dsIndex].label,
          value: d
        }, event.shiftKey);
      }
    }).on("mousemove", (d, i, nodes) => {
      const tipX = mouse_default(nodes[i])[0] + this.margin.left + config_default.tooltipMouseOffset;
      const tipY = mouse_default(nodes[i])[1] + this.margin.top + config_default.tooltipMouseOffset;
      const tooltipItems = this.data.datasets.map((dataset, j) => ({
        color: this.options.dataColors[j],
        text: `${this.data.datasets[j].label || ""}: ${this.data.datasets[j].data[i % dataLength]}`
      })).reverse();
      tooltip.update({
        title: this.data.labels[i],
        items: tooltipItems,
        position: {
          x: tipX,
          y: tipY,
          type: tooltipPositionType(tipX, tipY, this.width, this.height)
        }
      });
    });
    if (this.options.showLegend) {
      const legendItems = this.data.datasets.map((dataset, j) => ({
        color: this.options.dataColors[j],
        text: `${this.data.datasets[j].label || ""}`
      })).reverse();
      addLegend(graphPart, {
        items: legendItems,
        position: this.options.legendPosition,
        unxkcdify: this.options.unxkcdify,
        parentWidth: this.width,
        parentHeight: this.height,
        strokeColor: this.options.strokeColor,
        backgroundColor: this.options.backgroundColor
      });
    }
  }
};
var StackedBar_default = StackedBar;

// src/widget.js
var chartTypes = { Bar: Bar_default, Line: Line_default, Pie: Pie_default, Radar: Radar_default, Scatter: Scatter_default, StackedBar: StackedBar_default };
async function render({ model, el }) {
  el.innerHTML = "";
  await loadFont();
  var width = model.get("width");
  var height = model.get("height");
  var container = document.createElement("div");
  container.style.width = width + "px";
  container.style.height = height + "px";
  el.appendChild(container);
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "chart");
  container.appendChild(svg);
  var chartType = model.get("chart_type");
  var config2 = JSON.parse(model.get("config"));
  config2.options = config2.options || {};
  config2.options.onSelect = (payload, shiftKey) => {
    var items = Array.isArray(payload) ? payload : [payload];
    if (!shiftKey) {
      model.set("selection", JSON.stringify(items));
    } else {
      var current = JSON.parse(model.get("selection") || "[]");
      items.forEach((item) => {
        var key = JSON.stringify(item);
        var idx = current.findIndex((existing) => JSON.stringify(existing) === key);
        if (idx >= 0) {
          current.splice(idx, 1);
        } else {
          current.push(item);
        }
      });
      model.set("selection", JSON.stringify(current));
    }
    model.save_changes();
  };
  new chartTypes[chartType](svg, config2);
}
var widget_default = { render };
export {
  Bar_default as Bar,
  Line_default as Line,
  Pie_default as Pie,
  Radar_default as Radar,
  Scatter_default as Scatter,
  StackedBar_default as StackedBar,
  widget_default as default
};
