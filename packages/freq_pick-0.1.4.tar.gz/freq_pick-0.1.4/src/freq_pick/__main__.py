"""Module entry point for python -m freq_pick."""

from freq_pick.cli import main


if __name__ == "__main__":
    main()
