"""Tests for resume_review, interview_prep, career_advice tools."""

import pytest

from sborka_career_mcp.tools.resume import resume_review
from sborka_career_mcp.tools.interview import interview_prep
from sborka_career_mcp.tools.career import career_advice


SAMPLE_RESUME = """
Иван Петров
Email: ivan@example.com | Telegram: @ivan_dev

О себе:
Senior Python-разработчик с 5-летним опытом. Разработал микросервисную архитектуру,
которая обрабатывает 10M запросов в день. Увеличил производительность системы на 40%.

Опыт работы:
2020-2024 — Lead Developer в TechCorp
- Руководил командой из 8 разработчиков
- Внедрил CI/CD, сократив время деплоя с 2 часов до 15 минут
- Разработал API-gateway на FastAPI

Навыки: Python, FastAPI, PostgreSQL, Docker, Kubernetes, Redis

Образование:
МГУ, факультет ВМК, 2018
"""

MINIMAL_RESUME = "Ищу работу программистом."


@pytest.mark.asyncio
async def test_resume_review_good():
    result = await resume_review(SAMPLE_RESUME, "Python-разработчик")
    assert "/100" in result
    assert "sborka.work" in result
    assert "summary" in result or "experience" in result


@pytest.mark.asyncio
async def test_resume_review_minimal():
    result = await resume_review(MINIMAL_RESUME)
    assert "/100" in result
    assert "Добавьте" in result or "слишком короткое" in result


@pytest.mark.asyncio
async def test_interview_prep_tech():
    result = await interview_prep("Python-разработчик", "Яндекс", "tech")
    assert "Python" in result or "GIL" in result
    assert "STAR" in result
    assert "sborka.work" in result


@pytest.mark.asyncio
async def test_interview_prep_behavioral():
    result = await interview_prep("Product Manager", interview_type="behavioral")
    assert "Поведенческие" in result
    assert "STAR" in result


@pytest.mark.asyncio
async def test_career_advice_job_search():
    result = await career_advice("job_search", "Python Developer", "Senior Python Developer")
    assert "Системный поиск" in result
    assert "sborka.work" in result


@pytest.mark.asyncio
async def test_career_advice_career_change():
    result = await career_advice("career_change", "QA Engineer", "Python Developer")
    assert "Смена профессии" in result
    assert "QA Engineer" in result


@pytest.mark.asyncio
async def test_career_advice_unknown_scenario():
    result = await career_advice("unknown_scenario")
    assert "Неизвестный сценарий" in result
