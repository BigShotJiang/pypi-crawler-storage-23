"""Tests for MCP tools."""

import pytest
from unittest.mock import AsyncMock, patch

from sborka_career_mcp.data.hh_client import SalaryStats, MarketStats
from sborka_career_mcp.tools.salary import salary_data
from sborka_career_mcp.tools.market import job_market_trends


@pytest.mark.asyncio
async def test_salary_data_with_results():
    mock_stats = SalaryStats(median=250000, p25=180000, p75=350000, sample_size=42)
    with patch(
        "sborka_career_mcp.tools.salary.get_salary_stats",
        new_callable=AsyncMock,
        return_value=mock_stats,
    ):
        result = await salary_data("Python-разработчик", "senior", "Москва")
        assert "250,000" in result
        assert "180,000" in result
        assert "350,000" in result
        assert "42 вакансий" in result
        assert "sborka.work" in result


@pytest.mark.asyncio
async def test_salary_data_no_results():
    with patch(
        "sborka_career_mcp.tools.salary.get_salary_stats",
        new_callable=AsyncMock,
        return_value=None,
    ):
        result = await salary_data("Космонавт", "lead", "Антарктида")
        assert "Недостаточно данных" in result
        assert "sborka.work" in result


@pytest.mark.asyncio
async def test_job_market_trends():
    mock_stats = MarketStats(
        vacancies_count=1500,
        avg_salary_from=200000,
        avg_salary_to=400000,
        top_skills=["Python", "SQL", "Docker", "Git"],
        employers_sample=["Яндекс", "Сбер", "VK"],
    )
    with patch(
        "sborka_career_mcp.tools.market.get_market_stats",
        new_callable=AsyncMock,
        return_value=mock_stats,
    ):
        result = await job_market_trends("Python", "Москва")
        assert "1,500" in result
        assert "Python" in result
        assert "Яндекс" in result
        assert "sborka.work" in result
