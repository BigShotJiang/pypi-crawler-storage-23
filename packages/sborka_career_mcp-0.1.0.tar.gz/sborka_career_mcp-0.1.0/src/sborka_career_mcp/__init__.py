"""СБОРКА Career MCP Server — salary data, job market trends, resume review, interview prep."""
