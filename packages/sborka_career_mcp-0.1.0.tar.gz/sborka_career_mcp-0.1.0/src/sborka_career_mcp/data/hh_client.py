"""HH.ru API client for fetching vacancy and salary data."""

import statistics
from dataclasses import dataclass

import httpx

HH_API = "https://api.hh.ru"
USER_AGENT = "sborka-career-mcp/0.1 (tim.zinin@gmail.com)"


@dataclass
class SalaryStats:
    median: int
    p25: int
    p75: int
    sample_size: int
    currency: str = "RUB"


@dataclass
class MarketStats:
    vacancies_count: int
    avg_salary_from: int | None
    avg_salary_to: int | None
    top_skills: list[str]
    employers_sample: list[str]


async def search_vacancies(
    position: str,
    area: str | None = None,
    experience: str | None = None,
    only_with_salary: bool = True,
    per_page: int = 100,
) -> dict:
    """Search HH.ru vacancies. Returns raw API response."""
    params: dict = {
        "text": position,
        "per_page": per_page,
        "only_with_salary": str(only_with_salary).lower(),
    }
    if area:
        area_id = await _resolve_area(area)
        if area_id:
            params["area"] = area_id
    if experience:
        params["experience"] = _map_experience(experience)

    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            f"{HH_API}/vacancies",
            params=params,
            headers={"User-Agent": USER_AGENT},
        )
        resp.raise_for_status()
        return resp.json()


async def get_salary_stats(
    position: str,
    area: str | None = None,
    experience: str | None = None,
) -> SalaryStats | None:
    """Get salary statistics for a position."""
    data = await search_vacancies(position, area, experience, only_with_salary=True)
    items = data.get("items", [])
    if not items:
        return None

    salaries: list[int] = []
    for item in items:
        sal = item.get("salary")
        if not sal:
            continue
        currency = sal.get("currency", "RUR")
        if currency not in ("RUR", "RUB"):
            continue
        fr = sal.get("from")
        to = sal.get("to")
        if fr and to:
            salaries.append((fr + to) // 2)
        elif fr:
            salaries.append(fr)
        elif to:
            salaries.append(to)

    if len(salaries) < 3:
        return None

    salaries.sort()
    n = len(salaries)
    return SalaryStats(
        median=int(statistics.median(salaries)),
        p25=salaries[n // 4],
        p75=salaries[3 * n // 4],
        sample_size=n,
    )


async def get_market_stats(
    position: str,
    area: str | None = None,
) -> MarketStats:
    """Get market overview for a position."""
    data = await search_vacancies(position, area, experience=None, only_with_salary=False)
    items = data.get("items", [])
    total = data.get("found", len(items))

    salary_froms = []
    salary_tos = []
    skills_counter: dict[str, int] = {}
    employers: set[str] = set()

    for item in items:
        sal = item.get("salary")
        if sal and sal.get("currency") in ("RUR", "RUB"):
            if sal.get("from"):
                salary_froms.append(sal["from"])
            if sal.get("to"):
                salary_tos.append(sal["to"])

        for skill in item.get("key_skills", []):
            name = skill.get("name", "")
            if name:
                skills_counter[name] = skills_counter.get(name, 0) + 1

        emp = item.get("employer", {}).get("name")
        if emp:
            employers.add(emp)

    top_skills = sorted(skills_counter, key=skills_counter.get, reverse=True)[:10]

    return MarketStats(
        vacancies_count=total,
        avg_salary_from=int(statistics.mean(salary_froms)) if salary_froms else None,
        avg_salary_to=int(statistics.mean(salary_tos)) if salary_tos else None,
        top_skills=top_skills,
        employers_sample=list(employers)[:10],
    )


async def _resolve_area(city_name: str) -> str | None:
    """Resolve city name to HH area ID."""
    city_map = {
        "москва": "1", "санкт-петербург": "2", "петербург": "2",
        "новосибирск": "4", "екатеринбург": "3", "казань": "88",
        "нижний новгород": "66", "самара": "78", "ростов-на-дону": "76",
        "красноярск": "54", "воронеж": "26", "краснодар": "53",
        "remote": "113", "удалённая": "113", "удаленная": "113",
    }
    key = city_name.lower().strip()
    if key in city_map:
        return city_map[key]

    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(
            f"{HH_API}/suggests/areas",
            params={"text": city_name},
            headers={"User-Agent": USER_AGENT},
        )
        if resp.status_code == 200:
            items = resp.json().get("items", [])
            if items:
                return str(items[0]["id"])
    return None


def _map_experience(grade: str) -> str:
    """Map grade to HH experience filter."""
    grade_lower = grade.lower()
    if grade_lower in ("junior", "стажёр", "intern"):
        return "noExperience"
    if grade_lower in ("middle", "миддл"):
        return "between1And3"
    if grade_lower in ("senior", "сеньор", "синьор"):
        return "between3And6"
    if grade_lower in ("lead", "лид", "principal", "staff"):
        return "moreThan6"
    return "between1And3"
