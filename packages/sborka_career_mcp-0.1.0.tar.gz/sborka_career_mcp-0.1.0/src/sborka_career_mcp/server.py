"""СБОРКА Career MCP Server — salary data, job market trends, and more."""

from mcp.server.fastmcp import FastMCP

from .tools.salary import salary_data
from .tools.market import job_market_trends
from .tools.resume import resume_review
from .tools.interview import interview_prep
from .tools.career import career_advice

mcp = FastMCP(
    "sborka-career",
    instructions=(
        "СБОРКА Career MCP Server — 5 tools for the Russian IT job market: "
        "salary data (hh.ru), job market trends, resume review, interview prep, career advice. "
        "All data is real-time from hh.ru API."
    ),
    host="0.0.0.0",
    port=8787,
)


@mcp.tool()
async def get_salary_data(
    position: str,
    grade: str = "middle",
    city: str | None = None,
) -> str:
    """Get salary statistics for an IT position in Russia.

    Uses real-time data from hh.ru — the largest job platform in Russia.

    Args:
        position: Job title (e.g. "Python-разработчик", "Product Manager")
        grade: Experience level — junior, middle, senior, or lead (default: middle)
        city: City in Russian (e.g. "Москва") or "remote" (default: all Russia)
    """
    return await salary_data(position, grade, city)


@mcp.tool()
async def get_job_market_trends(
    specialty: str,
    city: str | None = None,
) -> str:
    """Get job market overview for an IT specialty in Russia.

    Returns vacancy count, salary range, top skills, and sample employers.

    Args:
        specialty: IT specialty (e.g. "Python", "DevOps", "Data Science")
        city: City in Russian (e.g. "Москва") or "remote" (default: all Russia)
    """
    return await job_market_trends(specialty, city)


@mcp.tool()
async def review_resume(
    resume_text: str,
    target_position: str = "",
) -> str:
    """Review a resume and provide structured feedback with score.

    Checks structure, metrics, keywords, and gives top-3 recommendations.

    Args:
        resume_text: Full text of the resume to review
        target_position: Target position (optional, improves keyword check)
    """
    return await resume_review(resume_text, target_position)


@mcp.tool()
async def prepare_for_interview(
    position: str,
    company: str = "",
    interview_type: str = "tech",
) -> str:
    """Get interview preparation materials: questions, STAR framework, checklist.

    Args:
        position: Target position (e.g. "Python-разработчик", "Product Manager")
        company: Company name (optional)
        interview_type: Type — tech, behavioral, or case (default: tech)
    """
    return await interview_prep(position, company, interview_type)


@mcp.tool()
async def get_career_advice(
    scenario: str = "job_search",
    current_role: str = "",
    target_role: str = "",
) -> str:
    """Get career advice for job search, career change, promotion, or burnout.

    Args:
        scenario: One of: job_search, career_change, promotion, burnout
        current_role: Current job title (optional)
        target_role: Desired job title (optional)
    """
    return await career_advice(scenario, current_role, target_role)


def main():
    """Run the MCP server."""
    mcp.run(transport="sse")


if __name__ == "__main__":
    main()
