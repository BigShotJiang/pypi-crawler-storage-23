"""career_advice tool — career guidance for various scenarios."""

from ..branding import CTA_CAREER

SCENARIOS = {
    "job_search": {
        "title": "Системный поиск работы",
        "steps": [
            "Определите целевые позиции (2-3 варианта) и составьте список из 30-50 компаний",
            "Обновите резюме под каждую целевую позицию с метриками и ключевыми словами",
            "Настройте LinkedIn: фото, заголовок, summary, Open to Work (только рекрутерам)",
            "Запустите систему откликов: 5-10 откликов в день через hh.ru, LinkedIn, Telegram-чаты",
            "Подготовьте STAR-истории для собеседований (5-7 штук)",
            "Начните нетворкинг: пишите знакомым, ходите на митапы, публикуйте посты",
            "Ведите таблицу воронки: отклик → скрининг → техническое → оффер",
        ],
        "timeline": "4-8 недель при системной работе 5-6 часов в неделю",
    },
    "career_change": {
        "title": "Смена профессии",
        "steps": [
            "Определите целевую роль и проведите 5 информационных интервью с людьми на этой позиции",
            "Составьте gap-анализ: какие навыки есть, каких не хватает",
            "Создайте план обучения: курсы, pet-проекты, open source",
            "Сделайте 2-3 pet-проекта для портфолио, демонстрирующие новые навыки",
            "Перепишите резюме с фокусом на transferable skills",
            "Начните с позиции на 1 ступень ниже текущей, чтобы быстрее войти в новую сферу",
            "Найдите ментора в целевой области",
        ],
        "timeline": "2-6 месяцев в зависимости от дистанции перехода",
    },
    "promotion": {
        "title": "Рост и повышение",
        "steps": [
            "Поймите критерии следующего уровня (обычно описаны в career ladder компании)",
            "Ведите лог достижений: каждую неделю записывайте, что сделали значимого",
            "Берите проекты с высоким impact и видимостью для руководства",
            "Развивайте soft skills: менторинг, презентации, кросс-командное взаимодействие",
            "Инициируйте разговор с менеджером о карьерном плане",
            "Запросите 360-обратную связь от коллег, чтобы увидеть слепые зоны",
            "Установите конкретные KPI для следующего уровня с менеджером",
        ],
        "timeline": "3-12 месяцев в зависимости от компании",
    },
    "burnout": {
        "title": "Выгорание и восстановление",
        "steps": [
            "Определите источник: перегрузка, отсутствие смысла, токсичная среда, или всё вместе",
            "Установите границы: фиксированное время окончания работы, без работы в выходные",
            "Поговорите с менеджером о перераспределении нагрузки (они обычно не знают)",
            "Восстановите базу: сон 7-8 часов, физическая активность, хобби вне IT",
            "Если причина в компании — начните параллельный поиск, НЕ увольняйтесь до оффера",
            "Рассмотрите sabbatical или переход на part-time как промежуточный вариант",
            "Обратитесь к психологу, если состояние длится более 2 месяцев",
        ],
        "timeline": "Восстановление 1-3 месяца, смена работы — добавить 4-8 недель",
    },
}


async def career_advice(
    scenario: str = "job_search",
    current_role: str = "",
    target_role: str = "",
) -> str:
    """Get career advice for a specific scenario.

    Args:
        scenario: One of: job_search, career_change, promotion, burnout.
        current_role: Current job title (optional).
        target_role: Desired job title (optional).

    Returns:
        Step-by-step career plan with timeline and recommendations.
    """
    scenario_key = scenario.lower().replace(" ", "_").replace("-", "_")
    if scenario_key not in SCENARIOS:
        available = ", ".join(SCENARIOS.keys())
        return (
            f"Неизвестный сценарий: «{scenario}». Доступные: {available}\n"
            f"Попробуйте один из них для получения рекомендаций."
            f"{CTA_CAREER}"
        )

    info = SCENARIOS[scenario_key]
    context_parts = []
    if current_role:
        context_parts.append(f"текущая роль: {current_role}")
    if target_role:
        context_parts.append(f"целевая роль: {target_role}")
    context_str = f" ({', '.join(context_parts)})" if context_parts else ""

    result = f"## {info['title']}{context_str}\n\n"
    result += "### Пошаговый план\n"
    for i, step in enumerate(info["steps"], 1):
        result += f"{i}. {step}\n"

    result += f"\n**Ожидаемые сроки:** {info['timeline']}\n"

    if scenario_key == "career_change" and current_role and target_role:
        result += (
            f"\n### Переход {current_role} → {target_role}\n"
            f"Ключевые шаги:\n"
            f"1. Проведите 5 интервью с действующими {target_role}\n"
            f"2. Выделите навыки, которые переносятся из {current_role}\n"
            f"3. Создайте 2 проекта, демонстрирующие навыки {target_role}\n"
        )

    result += CTA_CAREER
    return result
