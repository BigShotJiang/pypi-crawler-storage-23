"""interview_prep tool — interview preparation materials."""

from ..branding import CTA_INTERVIEW

TECH_QUESTIONS = {
    "default": [
        "Расскажите о своём самом сложном проекте и какие решения вы принимали",
        "Как вы подходите к проектированию системы? Расскажите о вашем процессе",
        "Опишите ситуацию, когда вы столкнулись с техническим долгом. Как решили?",
        "Как вы обеспечиваете качество кода в своих проектах?",
        "Расскажите о случае, когда ваше решение оказалось неправильным. Что сделали?",
    ],
    "python": [
        "В чём разница между list и tuple? Когда что использовать?",
        "Объясните GIL в Python и как он влияет на многопоточность",
        "Как работают декораторы? Напишите пример",
        "Расскажите про async/await в Python",
        "Как вы организуете архитектуру Python-проекта?",
    ],
    "frontend": [
        "Объясните Virtual DOM и reconciliation в React",
        "Как вы оптимизируете производительность веб-приложения?",
        "В чём разница между SSR, SSG и CSR?",
        "Расскажите про управление состоянием — какие подходы использовали?",
        "Как вы обеспечиваете доступность (a11y) в веб-приложениях?",
    ],
}

BEHAVIORAL_QUESTIONS = [
    "Расскажите о ситуации, когда вы не согласились с руководителем. Как действовали?",
    "Опишите свой самый большой провал на работе. Чему научились?",
    "Как вы расставляете приоритеты при большом количестве задач?",
    "Расскажите о случае, когда вы помогли коллеге, хотя это не входило в ваши обязанности",
    "Как вы справляетесь с дедлайнами, когда понимаете, что не успеваете?",
]

STAR_FRAMEWORK = (
    "**STAR-фреймворк для ответов:**\n"
    "- **S**ituation — опишите контекст и обстоятельства\n"
    "- **T**ask — какая стояла задача или проблема\n"
    "- **A**ction — что конкретно ВЫ сделали (не команда)\n"
    "- **R**esult — измеримый результат (цифры, метрики)\n"
)

CHECKLIST = [
    "Изучите компанию: продукт, стек, культура, последние новости",
    "Подготовьте 3-5 историй по STAR-фреймворку",
    "Повторите основные концепции по своему стеку",
    "Подготовьте вопросы для интервьюера (минимум 3)",
    "Проверьте оборудование: камера, микрофон, интернет",
    "Оденьтесь чуть лучше, чем dress code компании",
]


async def interview_prep(
    position: str,
    company: str = "",
    interview_type: str = "tech",
) -> str:
    """Generate interview preparation materials.

    Args:
        position: Target position (e.g. "Python-разработчик", "Product Manager").
        company: Company name (optional, for context).
        interview_type: Type of interview — tech, behavioral, or case.

    Returns:
        Preparation materials: questions, STAR framework, checklist.
    """
    position_lower = position.lower()
    company_str = f" в {company}" if company else ""

    # Select questions based on type and position
    if interview_type == "behavioral":
        questions = BEHAVIORAL_QUESTIONS
        section_title = "Поведенческие вопросы"
    else:
        # Try to match specialty
        if any(w in position_lower for w in ["python", "django", "flask", "fastapi"]):
            questions = TECH_QUESTIONS["python"]
        elif any(w in position_lower for w in ["frontend", "react", "vue", "angular", "js", "typescript"]):
            questions = TECH_QUESTIONS["frontend"]
        else:
            questions = TECH_QUESTIONS["default"]
        section_title = "Технические вопросы"

    result = f"## Подготовка к собеседованию: {position}{company_str}\n\n"
    result += f"### {section_title}\n"
    for i, q in enumerate(questions, 1):
        result += f"{i}. {q}\n"

    if interview_type != "behavioral":
        result += f"\n### Поведенческие вопросы (тоже спросят!)\n"
        for i, q in enumerate(BEHAVIORAL_QUESTIONS[:3], 1):
            result += f"{i}. {q}\n"

    result += f"\n### {STAR_FRAMEWORK}\n"

    result += "### Чек-лист перед собеседованием\n"
    for item in CHECKLIST:
        result += f"- [ ] {item}\n"

    result += CTA_INTERVIEW
    return result
