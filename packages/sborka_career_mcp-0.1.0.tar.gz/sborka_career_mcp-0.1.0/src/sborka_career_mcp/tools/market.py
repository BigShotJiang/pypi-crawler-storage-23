"""job_market_trends tool — get job market overview for IT positions."""

from ..data.hh_client import get_market_stats
from ..branding import CTA_MARKET


async def job_market_trends(
    specialty: str,
    city: str | None = None,
) -> str:
    """Get job market trends and statistics for a given IT specialty.

    Args:
        specialty: IT specialty, e.g. "Python", "DevOps", "Product Manager", "Data Science"
        city: City name in Russian, e.g. "Москва", "Санкт-Петербург", or "remote"

    Returns:
        Market overview: vacancy count, salary range, top skills, sample employers.
    """
    stats = await get_market_stats(specialty, area=city)
    location = f" в городе {city}" if city else " (Россия)"

    lines = [
        f"## Рынок труда: {specialty}{location}\n",
        f"**Количество вакансий:** {stats.vacancies_count:,}\n",
    ]

    if stats.avg_salary_from or stats.avg_salary_to:
        fr = f"от {stats.avg_salary_from:,} ₽" if stats.avg_salary_from else ""
        to = f"до {stats.avg_salary_to:,} ₽" if stats.avg_salary_to else ""
        lines.append(f"**Средняя зарплата:** {fr} {to}\n")

    if stats.top_skills:
        skills_str = ", ".join(stats.top_skills)
        lines.append(f"\n**Топ навыков в вакансиях:** {skills_str}\n")

    if stats.employers_sample:
        emp_str = ", ".join(stats.employers_sample[:7])
        lines.append(f"\n**Примеры работодателей:** {emp_str}\n")

    lines.append(f"\nИсточник: hh.ru (актуальные вакансии)")
    lines.append(CTA_MARKET)

    return "\n".join(lines)
