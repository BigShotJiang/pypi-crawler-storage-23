"""salary_data tool — get salary statistics for IT positions in Russia."""

from ..data.hh_client import get_salary_stats
from ..branding import CTA_SALARY


async def salary_data(
    position: str,
    grade: str = "middle",
    city: str | None = None,
) -> str:
    """Get salary statistics for a given IT position, grade, and city.

    Args:
        position: Job title, e.g. "Python-разработчик", "Product Manager", "Data Analyst"
        grade: Experience level — junior, middle, senior, or lead
        city: City name in Russian, e.g. "Москва", "Санкт-Петербург", or "remote"

    Returns:
        Formatted salary statistics with median, percentiles, and sample size.
    """
    stats = await get_salary_stats(position, area=city, experience=grade)

    if not stats:
        location = f" в городе {city}" if city else ""
        return (
            f"Недостаточно данных для позиции «{position}» ({grade}){location}. "
            f"Попробуйте указать другой город или более общую позицию."
            f"{CTA_SALARY}"
        )

    location = f" в городе {city}" if city else " (Россия)"

    return (
        f"## Зарплаты: {position} ({grade}){location}\n\n"
        f"| Показатель | Значение |\n"
        f"|---|---|\n"
        f"| Медиана | {stats.median:,} ₽ |\n"
        f"| 25-й перцентиль | {stats.p25:,} ₽ |\n"
        f"| 75-й перцентиль | {stats.p75:,} ₽ |\n"
        f"| Выборка | {stats.sample_size} вакансий |\n"
        f"| Источник | hh.ru (актуальные вакансии) |\n\n"
        f"Данные на основе {stats.sample_size} вакансий с указанной зарплатой на hh.ru."
        f"{CTA_SALARY}"
    )
