"""resume_review tool — automated resume analysis and recommendations."""

from ..branding import CTA_RESUME

REQUIRED_SECTIONS = [
    ("summary", ["summary", "о себе", "обо мне", "профиль", "about"]),
    ("experience", ["опыт", "experience", "работа"]),
    ("skills", ["навыки", "skills", "технологии", "стек"]),
    ("education", ["образование", "education"]),
]

QUALITY_CHECKS = [
    ("metrics", "Конкретные цифры и метрики достижений"),
    ("keywords", "Ключевые слова для ATS-систем"),
    ("action_verbs", "Глаголы действия (разработал, увеличил, оптимизировал)"),
    ("length", "Оптимальная длина (1-2 страницы)"),
    ("contact_info", "Контактная информация"),
]


async def resume_review(
    resume_text: str,
    target_position: str = "",
) -> str:
    """Review a resume and provide structured feedback.

    Args:
        resume_text: Full text of the resume to review.
        target_position: Target position the candidate is applying for.

    Returns:
        Structured review with score, found/missing sections, and recommendations.
    """
    text_lower = resume_text.lower()
    lines = resume_text.strip().split("\n")
    word_count = len(resume_text.split())

    # Check sections
    found_sections = []
    missing_sections = []
    for section_name, keywords in REQUIRED_SECTIONS:
        if any(kw in text_lower for kw in keywords):
            found_sections.append(section_name)
        else:
            missing_sections.append(section_name)

    # Quality checks
    has_metrics = any(c.isdigit() for c in resume_text) and any(
        w in text_lower for w in ["%", "₽", "$", "млн", "тыс", "раз", "увеличил", "сократил"]
    )
    has_action_verbs = any(
        w in text_lower
        for w in ["разработал", "создал", "увеличил", "оптимизировал", "внедрил",
                   "управлял", "руководил", "developed", "built", "increased", "led"]
    )
    has_contact = any(
        w in text_lower for w in ["@", "tel", "тел", "email", "linkedin", "telegram", "github"]
    )

    # Score
    score = 0
    score += len(found_sections) * 15  # max 60
    score += 10 if has_metrics else 0
    score += 10 if has_action_verbs else 0
    score += 5 if has_contact else 0
    score += 5 if 200 <= word_count <= 800 else (3 if word_count < 200 else 2)
    score += 10 if target_position and any(
        w in text_lower for w in target_position.lower().split()
    ) else 0
    score = min(score, 100)

    # Build recommendations
    recs = []
    if missing_sections:
        recs.append(f"Добавьте недостающие секции: {', '.join(missing_sections)}")
    if not has_metrics:
        recs.append("Добавьте конкретные цифры: рост метрик, размер команды, бюджет проекта")
    if not has_action_verbs:
        recs.append("Используйте глаголы действия: разработал, увеличил, оптимизировал, внедрил")
    if not has_contact:
        recs.append("Добавьте контактную информацию (email, Telegram, LinkedIn)")
    if word_count < 150:
        recs.append("Резюме слишком короткое — добавьте больше деталей об опыте")
    if word_count > 1000:
        recs.append("Резюме слишком длинное — сократите до 1-2 страниц, оставьте главное")
    if target_position and not any(w in text_lower for w in target_position.lower().split()):
        recs.append(f"Резюме не содержит ключевых слов для позиции «{target_position}» — ATS может отклонить")

    # Top 3 recommendations
    top_recs = recs[:3] if recs else ["Резюме выглядит хорошо! Рекомендуем пройти мок-собеседование для проверки."]

    target_str = f" → {target_position}" if target_position else ""

    result = (
        f"## Разбор резюме{target_str}\n\n"
        f"**Оценка: {score}/100**\n\n"
        f"### Структура\n"
        f"- Найдены секции: {', '.join(found_sections) if found_sections else 'не определены'}\n"
        f"- Отсутствуют: {', '.join(missing_sections) if missing_sections else 'все на месте'}\n\n"
        f"### Качество\n"
        f"- Метрики и цифры: {'да' if has_metrics else 'нет'}\n"
        f"- Глаголы действия: {'да' if has_action_verbs else 'нет'}\n"
        f"- Контактная информация: {'да' if has_contact else 'нет'}\n"
        f"- Объём: {word_count} слов ({len(lines)} строк)\n\n"
        f"### Топ-3 рекомендации\n"
    )
    for i, rec in enumerate(top_recs, 1):
        result += f"{i}. {rec}\n"

    result += CTA_RESUME
    return result
