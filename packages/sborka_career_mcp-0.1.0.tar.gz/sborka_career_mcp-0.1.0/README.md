# СБОРКА Career MCP Server

MCP server with 5 tools for the Russian IT job market. Real-time data from hh.ru API.

## Tools

| Tool | Description |
|------|-------------|
| `get_salary_data` | Salary statistics (median, p25, p75) for IT positions |
| `get_job_market_trends` | Market overview: vacancies, skills, employers |
| `review_resume` | Resume review with score 0-100 and recommendations |
| `prepare_for_interview` | Interview prep: questions, STAR framework, checklist |
| `get_career_advice` | Career guidance: job search, career change, promotion, burnout |

## Quick Start

### Claude Desktop / Claude Code

```json
{
  "mcpServers": {
    "sborka-career": {
      "command": "uvx",
      "args": ["sborka-career-mcp"]
    }
  }
}
```

### SSE (Remote)

```json
{
  "mcpServers": {
    "sborka-career": {
      "url": "https://mcp.sborka.work/sse"
    }
  }
}
```

## Examples

**Salary data:**
```
> get_salary_data(position="Python-разработчик", grade="senior", city="Москва")

Медиана: 280,000 ₽ | P25: 200,000 ₽ | P75: 380,000 ₽ | Выборка: 47 вакансий
```

**Resume review:**
```
> review_resume(resume_text="...", target_position="DevOps Engineer")

Оценка: 72/100
Рекомендации: добавить метрики, ключевые слова для ATS, контактную информацию
```

**Interview prep:**
```
> prepare_for_interview(position="Product Manager", company="Яндекс", interview_type="behavioral")

5 типовых вопросов + STAR-фреймворк + чек-лист подготовки
```

## Install from source

```bash
git clone https://github.com/TimmyZinin/sborka-career-mcp.git
cd sborka-career-mcp
pip install -e .
sborka-career-mcp
```

## Docker

```bash
docker build -t sborka-career-mcp .
docker run -p 8787:8787 sborka-career-mcp
```

## Powered by

[СБОРКА](https://sborka.work) — career club for Middle/Senior/Lead IT professionals. Mentors, mock interviews, resume review. Average member gets an offer in 6-8 weeks.

Telegram: [@Sborka_work_bot](https://t.me/Sborka_work_bot)
