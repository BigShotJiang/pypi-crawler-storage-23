"""Allow running as `python -m trufflehog_redactor`."""

from trufflehog_redactor.cli import main

main()
