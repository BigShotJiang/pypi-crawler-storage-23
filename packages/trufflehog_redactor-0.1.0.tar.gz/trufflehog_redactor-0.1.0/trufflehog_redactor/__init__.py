"""Interactive TUI for redacting secrets found by TruffleHog."""

__version__ = "0.1.0"
