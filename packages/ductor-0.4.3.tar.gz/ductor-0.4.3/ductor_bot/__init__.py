"""ductor: Telegram bot powered by Claude Code CLI and Codex CLI."""

__version__ = "0.4.3"
