"""Automatic file cleanup for workspace directories."""

from ductor_bot.cleanup.observer import CleanupObserver as CleanupObserver

__all__ = ["CleanupObserver"]
