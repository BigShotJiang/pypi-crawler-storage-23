from __future__ import annotations

from typing import Any

from .._types import ModelInfo, ModelListResponse


class Models:
    """Sync models: client.models.list() / client.models.retrieve(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    def list(self) -> ModelListResponse:
        resp = self._client._http.get(  # type: ignore[attr-defined]
            self._client._build_url("/v1/models"),  # type: ignore[attr-defined]
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return ModelListResponse(**resp.json())

    def retrieve(self, model_id: str) -> ModelInfo:
        resp = self._client._http.get(  # type: ignore[attr-defined]
            self._client._build_url(f"/v1/models/{model_id}"),  # type: ignore[attr-defined]
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return ModelInfo(**resp.json())


class AsyncModels:
    """Async models: client.models.list() / client.models.retrieve(...)"""

    def __init__(self, client: object) -> None:
        self._client = client

    async def list(self) -> ModelListResponse:
        resp = await self._client._http.get(  # type: ignore[attr-defined]
            self._client._build_url("/v1/models"),  # type: ignore[attr-defined]
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return ModelListResponse(**resp.json())

    async def retrieve(self, model_id: str) -> ModelInfo:
        resp = await self._client._http.get(  # type: ignore[attr-defined]
            self._client._build_url(f"/v1/models/{model_id}"),  # type: ignore[attr-defined]
            headers=self._client._headers,  # type: ignore[attr-defined]
            timeout=self._client.timeout,  # type: ignore[attr-defined]
        )
        self._client._raise_for_status(resp)  # type: ignore[attr-defined]
        return ModelInfo(**resp.json())
