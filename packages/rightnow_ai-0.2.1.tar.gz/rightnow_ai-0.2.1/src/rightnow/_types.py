from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ── Chat Completions ────────────────────────────────────────────────────────


class FunctionCall(BaseModel):
    name: str
    arguments: str


class ToolCall(BaseModel):
    id: str
    type: str = "function"
    function: FunctionCall


class ChatMessage(BaseModel):
    role: str
    content: str | None = None
    tool_calls: list[ToolCall] | None = None


class Choice(BaseModel):
    index: int
    message: ChatMessage
    finish_reason: str | None = None


class DeltaContent(BaseModel):
    role: str | None = None
    content: str | None = None
    tool_calls: list[ToolCall] | None = None


class StreamChoice(BaseModel):
    index: int
    delta: DeltaContent
    finish_reason: str | None = None


class UsageInfo(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletion(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: list[Choice]
    usage: UsageInfo | None = None


class ChatCompletionChunk(BaseModel):
    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: list[StreamChoice]


# ── Embeddings ──────────────────────────────────────────────────────────────


class EmbeddingData(BaseModel):
    object: str = "embedding"
    index: int
    embedding: list[float]


class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: list[EmbeddingData]
    model: str
    usage: UsageInfo | None = None


# ── Models ──────────────────────────────────────────────────────────────────


class ModelInfo(BaseModel):
    id: str
    object: str = "model"
    created: int
    owned_by: str


class ModelListResponse(BaseModel):
    object: str = "list"
    data: list[ModelInfo]


# ── Dialects ────────────────────────────────────────────────────────────────


class DialectScore(BaseModel):
    dialect: str
    confidence: float


class DialectDetectResponse(BaseModel):
    primary_dialect: str
    confidence: float
    scores: list[DialectScore]


# ── Documents ───────────────────────────────────────────────────────────────


class DocumentResponse(BaseModel):
    result: Any
    model: str
    usage: UsageInfo | None = None


# ── Audio ───────────────────────────────────────────────────────────────────


class TranscriptionResponse(BaseModel):
    text: str
    language: str | None = None
