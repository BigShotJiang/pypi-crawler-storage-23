from __future__ import annotations

VERSION = "0.2.1"
DEFAULT_BASE_URL = "https://api.rightnowai.co"
DEFAULT_TIMEOUT = 300.0
DEFAULT_MAX_RETRIES = 2
