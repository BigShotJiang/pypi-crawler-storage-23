class MyClass:
    def __init__(self, status):
        self.status = status
