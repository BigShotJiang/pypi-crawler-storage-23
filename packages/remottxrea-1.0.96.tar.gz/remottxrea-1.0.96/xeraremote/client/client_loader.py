# remottxrea/client/client_loader.py

import os

from pyrogram import Client

from ..config.main_config import ( 
    SESSIONS_DIR
)

from ..session.session_data_manager import (
    session_data_manager
)


class ClientLoader:

    def load(self, phone: str) -> Client:

        data = session_data_manager.load(phone)

        if not data:
            raise Exception(
                f"No session data for {phone}"
            )

        device = data["device"]

        return Client(
            name=os.path.join(SESSIONS_DIR, phone),
            api_id=device["api_id"],
            api_hash=device["api_hash"],
            device_model=device["device_model"],
            system_version=device["system_version"],
            app_version=device["app_version"],
            lang_code=device["lang_code"]
        )
