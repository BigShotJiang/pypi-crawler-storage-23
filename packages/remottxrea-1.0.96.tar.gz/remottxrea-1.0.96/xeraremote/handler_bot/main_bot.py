# remottxrea/bot/main_bot.py

import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message

from ..config import main_config
from .command_router import CommandRouter


router = CommandRouter()


# ==========================================================
# CREATE BOT CLIENT
# ==========================================================

def create_app() -> Client:

    if not main_config.BOT_TOKEN:
        raise ValueError("BOT_TOKEN is not set")

    if not main_config.API_ID:
        raise ValueError("API_ID is not set")

    if not main_config.API_HASH:
        raise ValueError("API_HASH is not set")

    return Client(
        name="remottxrea_bot",
        bot_token=main_config.BOT_TOKEN,
        api_id=main_config.API_ID,
        api_hash=main_config.API_HASH,
        workers=1  # جلوگیری از race
    )


# ==========================================================
# STARTUP LOGIC
# ==========================================================

async def startup():

    print("🔄 Loading sessions...")

    # فقط load_all داریم — watcher حذف شده
    await router.registry.runner.load_all()

    print("✅ Session pool ready")


# ==========================================================
# ENTRY POINT
# ==========================================================

def run():

    app = create_app()

    @app.on_message(filters.private)
    async def on_message(client: Client, message: Message):
        await router.dispatch(client, message)

    async def main():
        await startup()
        await app.start()
        print("🚀 Bot started")
        await idle()

    from pyrogram import idle

    asyncio.run(main())


if __name__ == "__main__":
    run()