# places/ — Place Notes

This directory stores markdown notes about places, environments, and contexts relevant to Tako's work.

Guidelines:

- One file per place or context.
- Capture stable constraints and setup notes.
- No secrets.

