# areas/ — Areas (PARA)

Areas are ongoing responsibilities with no "done", only "maintained".

Examples: health, finances, infrastructure, relationships, ops.

Conventions:

- Keep one area per Markdown file.
- Areas can own recurring checklists and standards.
- Tasks can reference an area even when they are not part of a specific project.

