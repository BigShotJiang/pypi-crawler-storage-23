# dcg-sci-tool

Scientific computing tools for data analysis.

## Prerequisite

自行准备 `PyPI` 发布密钥到 `C:/Users/dcg89/.pypirc`，格式如下：

```
[pypi]
  username = __token__
  password = pypi-xxxxxxx
```


## Installation 

`pip install dcg-sci-tool`

## build
`python -m build`

注意：需要手动删除上一次构建产物

## publish
`twine upload dist/*`


