import argparse
import sys
def main():
    print("欢迎使用dcg-sci-tool！这是一个用于科学计算的工具包。")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())