# Changelog

## [0.1.3] - 2026-02-25

### Fixed
- 修复导出问题

## [0.1.2] - 2026-02-25

### Added
- 新增 `detect_O2_molecules` 方法
- 新增 `detect_CO_CO2_molecules` 方法

## [0.1.1] - 2026-02-24

### Added
- 新增 `extract_atom_types` 方法
- 新增 `sum_to_n` 方法