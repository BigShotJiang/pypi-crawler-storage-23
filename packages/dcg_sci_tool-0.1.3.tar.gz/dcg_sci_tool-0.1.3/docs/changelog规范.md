# Changelog

本项目版本变更记录遵循 [语义化版本 2.0.0](https://semver.org/lang/zh-CN/)。

## [Unreleased] - 尚未发布

### Added
- 新功能A描述
- 新功能B描述

### Changed
- 现有功能变更描述

### Deprecated
- 即将废弃的功能

### Removed
- 已移除的功能

### Fixed
- Bug修复描述

### Security
- 安全性修复

## [1.2.0] - 2023-10-15

### Added
- 新增API端点 `/api/v2/users`
- 添加对Python 3.11的官方支持
- 新增配置项 `MAX_RETRIES`

### Changed
- **重大变更**：数据库连接配置方式变更（详见迁移指南）
- 优化了缓存机制，性能提升约30%
- 更新最小依赖版本：`requests>=2.28.0`

### Fixed
- 修复了内存泄漏问题（#123）
- 修复了时区处理错误（#145）
- 修复了并发写入时的数据竞争问题

### Security
- 升级了加密库以修复CVE-2023-12345漏洞

## [1.1.4] - 2023-09-10

### Fixed
- 修复了Windows下的路径处理问题（#112）
- 修正了文档中的错误示例

## [1.1.0] - 2023-08-01

### Added
- 新增命令行工具 `mycli`
- 添加异步API支持

### Changed
- 优化了错误消息的可读性
- 重构了内部模块结构

### Deprecated
- 废弃 `old_function()`，将在2.0.0移除，请使用 `new_function()`

## [1.0.0] - 2023-06-01

### Added
- 首次稳定版发布
- 完整的API文档
- 单元测试覆盖率95%+

### Changed
- API接口全部稳定

## [0.9.0] - 2023-05-01

### Added
- 预览版发布
- 基础功能实现