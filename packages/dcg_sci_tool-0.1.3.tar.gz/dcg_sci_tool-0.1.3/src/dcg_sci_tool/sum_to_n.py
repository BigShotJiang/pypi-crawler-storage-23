"""
Core summation module.
"""

    

def sum_to_n(n: int) -> int:
    """
    Calculate the sum of all integers from 1 to n inclusive.

    Args:
        n (int): The upper limit (must be a positive integer).

    Returns:
        int: The sum 1 + 2 + ... + n.

    Raises:
        ValueError: If n is not a positive integer.

    Examples:
        >>> sum_to_n(5)
        15
        >>> sum_to_n(100)
        5050
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer.")
    return n * (n + 1) // 2  # 使用高斯求和公式，效率O(1)