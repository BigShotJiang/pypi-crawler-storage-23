"""
dcg-sci-tool is a Python package that provides utility functions for scientific computing. It includes functions for summing numbers to a target value and extracting atom types from molecular data. This package is designed to be easy to use and integrate into various scientific workflows.
"""

from .sum_to_n import sum_to_n
from .extract_atom_types import extract_atom_types
from .detect_O2_molecules import detect_O2_molecules
from .detect_CO_CO2_molecules import detect_CO_CO2_molecules

__version__ = "0.1.3"
__all__ = ["sum_to_n", "extract_atom_types","detect_O2_molecules","detect_CO_CO2_molecules"]