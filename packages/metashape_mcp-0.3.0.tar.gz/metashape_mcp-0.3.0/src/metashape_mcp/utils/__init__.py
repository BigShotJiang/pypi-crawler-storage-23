"""Utility modules for Metashape MCP server."""
