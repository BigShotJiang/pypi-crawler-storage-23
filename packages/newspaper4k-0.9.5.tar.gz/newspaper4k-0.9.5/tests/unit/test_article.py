# pytest file for testing the article class
import io
import pickle
from datetime import datetime
from pathlib import Path

import pytest
from dateutil.parser import parse as date_parser

import newspaper
from newspaper import urls
from newspaper.article import Article, ArticleDownloadState, ArticleException
from newspaper.configuration import Configuration


class TestArticle:
    def test_article(self, cnn_article):
        article = newspaper.Article(cnn_article["url"], fetch_images=False)
        article.download(input_html=cnn_article["html_content"])
        article.parse()
        assert article.url == cnn_article["url"]
        assert article.download_state == ArticleDownloadState.SUCCESS
        assert article.download_exception_msg is None
        assert len(article.html) == 75404

        assert article.text.strip() == cnn_article["text_content"].strip()
        assert article.title == "After storm, forecasters see smooth sailing for Thanksgiving"
        assert article.authors == [
            "Dana A. Ford",
            "James S.A. Corey",
            "Chien-Ming Wang",
            "Tom Watkins",
        ]
        assert (article.publish_date - date_parser("2013-11-27T00:00:00Z", ignoretz=True)).days == 0
        assert article.top_image == "http://i2.cdn.turner.com/cnn/dam/assets/131129200805-01-weather-1128-story-top.jpg"
        assert article.movies == []
        assert article.keywords == []
        assert article.meta_keywords == [
            "winter storm",
            "holiday travel",
            "Thanksgiving storm",
            "Thanksgiving winter storm",
        ]
        assert article.meta_lang == "en"
        assert (
            article.meta_description == "A strong storm struck much of the eastern United "
            "States on Wednesday, complicating holiday plans for many "
            "of the 43 million Americans expected to travel."
        )

    def test_call_parse_before_download(self):
        article = newspaper.Article("http://www.cnn.com")
        with pytest.raises(ArticleException):
            article.parse()

    def test_call_nlp_before_download(self):
        article = newspaper.Article("http://www.cnn.com")
        with pytest.raises(ArticleException):
            article.nlp()

    def test_call_nlp_before_parse(self, cnn_article):
        article = newspaper.Article(cnn_article["url"], fetch_images=False)
        article.download(input_html=cnn_article["html_content"])
        with pytest.raises(ArticleException):
            article.nlp()

    def test_meta_refresh(self, meta_refresh):
        config = Configuration()
        config.follow_meta_refresh = True
        article = Article("", config=config)
        for html, title in meta_refresh:
            article.download(input_html=html)
            article.parse()
            assert article.title == title

    # If this test is failing, you may need to download an ntlk tokenizer
    # try running:
    # import ntlk
    # nltk.download('punkt_tab')
    def test_article_nlp(self, cnn_article):
        article = newspaper.Article(cnn_article["url"], fetch_images=False)
        article.download(input_html=cnn_article["html_content"])
        article.parse()
        article.nlp()

        assert sorted(article.keywords) == sorted(cnn_article["keywords"])
        assert article.summary.strip() == cnn_article["summary"].strip()

    def test_download_inexisting_file(self):
        url = "file://" + str(Path(__file__).resolve().parent / "data/html/does_not_exist.html")
        article = Article(url=url)
        article.download()
        assert article.download_state == ArticleDownloadState.FAILED_RESPONSE
        assert "No such file or directory" in article.download_exception_msg
        assert article.html == ""

    def test_download_file_schema(self):
        test_file = Path(__file__).resolve().parent.parent / "data/html/cnn_article.html"
        url = "file://" + str(test_file)
        article = Article(url=url)
        article.download()

        assert len(article.html) > 75000
        assert article.download_state == ArticleDownloadState.SUCCESS
        assert article.download_exception_msg is None

    def test_get_video_links(self, article_video_fixture):
        for test_case in article_video_fixture:
            article = Article(url=test_case["url"], fetch_images=False)
            article.download(input_html=test_case["html"])
            article.parse()

            assert sorted(article.movies) == sorted(test_case["movies"])

    def test_get_top_image(self, top_image_fixture):
        for test_case in top_image_fixture:
            article = Article(url=test_case["url"], fetch_images=False)
            article.download(input_html=test_case["html"])
            article.parse()

            assert article.top_image == test_case["top_image"]

    def test_known_websites(self, known_websites):
        errors = {}

        def add_error(file, field):
            if file not in errors:
                errors[file] = []
            errors[file].append(field)

        for test_case in known_websites:
            article = Article(
                url=test_case["url"],
                fetch_images=False,
            )
            article.download(test_case["html"])
            article.parse()
            article.nlp()
            # for now we skip it because it is not reliable
            for k in test_case["metadata"]:
                if k in ["html", "url", "language", "text_cleaned", "images"]:
                    continue
                if k in ["top_img", "meta_img"]:
                    if urls.get_path(getattr(article, k)) != urls.get_path(test_case["metadata"][k]):
                        add_error(test_case["file"], k)
                    continue
                if k in ["imgs", "images", "movies"]:
                    u1 = [urls.get_path(u) for u in getattr(article, k)]
                    u2 = [urls.get_path(u) for u in test_case["metadata"][k]]
                    if sorted(u1) != sorted(u2):
                        add_error(test_case["file"], k)
                    continue

                if isinstance(getattr(article, k), list):
                    if sorted(getattr(article, k)) != sorted(test_case["metadata"][k]):
                        add_error(test_case["file"], k)
                elif isinstance(getattr(article, k), datetime):
                    if str(getattr(article, k))[:10] != test_case["metadata"][k][:10]:
                        add_error(test_case["file"], k)
                else:
                    if getattr(article, k) != test_case["metadata"][k]:
                        add_error(test_case["file"], k)

        assert len(errors) == 0, f"Test case failed on : {errors}"

    def test_json_ld_with_null_entries(self):
        html = (
            "<html><head>"
            '<script type="application/ld+json">'
            '[{"@type":"Article","headline":"Test"}, null]'
            "</script>"
            "</head><body><p>Hello world</p></body></html>"
        )
        article = Article("http://example.com", fetch_images=False)
        article.download(input_html=html)
        article.parse()
        assert isinstance(article.authors, list)

    def test_pickle(self, cnn_article):
        article = newspaper.article(
            cnn_article["url"],
            input_html=cnn_article["html_content"],
            fetch_images=False,
        )
        bytes_io = io.BytesIO()
        pickle.dump(article, bytes_io)

        bytes_io.seek(0)

        article_ = pickle.load(bytes_io)
        assert article == article_
