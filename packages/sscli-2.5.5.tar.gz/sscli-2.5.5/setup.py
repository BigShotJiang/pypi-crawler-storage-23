from setuptools import setup, find_packages

setup(
    name="sscli",
    version="2.4.1",
    description="Seed & Source CLI - Multi-tenant SaaS scaffolding with Merchant Dashboard",
    long_description=open("README.md").read() if open("README.md").name else "",
    packages=find_packages(include=["foundry*"]),
    package_data={
        "": ["*.md", "*.json"],
    },
    entry_points={
        "console_scripts": [
            "sscli=foundry.manage:app",
        ],
    },
    install_requires=[
        "typer[all]>=0.13.0",
        "rich",
        "questionary",
        "requests",
        "python-dotenv",
        "pydantic>=2.0.0",
        "httpx>=0.27.0",
        "tomlkit>=0.14.0",
        "pyyaml>=6.0",
    ],
    python_requires=">=3.9",
)
