"""
Development debugging and build tools
"""

from foundry.constants import console
import subprocess
import sys
import os
import platform


def get_sscli_version():
    """Get the current sscli version from pyproject.toml"""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib
        except ImportError:
            return 'unknown'
    
    from pathlib import Path
    try:
        import foundry
        foundry_path = Path(foundry.__file__).parent.parent
        pyproject_path = foundry_path / "pyproject.toml"
        
        if pyproject_path.exists():
            with open(pyproject_path, 'rb') as f:
                data = tomllib.load(f)
            return data.get('project', {}).get('version', 'unknown')
    except Exception:
        pass
    
    return 'unknown'


def check_build_version():
    """Check the actual build version (local vs pip)"""
    console.print("\n[bold cyan]Build Version Information[/bold cyan]")
    console.print("=" * 50)
    
    version = get_sscli_version()
    console.print(f"[green]✓[/green] Current version: [bold]{version}[/bold]")
    
    # Check if running from local build or pip
    try:
        import foundry
        foundry_path = os.path.dirname(foundry.__file__)
        
        # Check if it's in a .venv or site-packages
        if '.venv' in foundry_path:
            console.print(f"[yellow]→[/yellow] Source: [bold]Local development build[/bold]")
            console.print(f"   Location: {foundry_path}")
        elif 'site-packages' in foundry_path:
            console.print(f"[yellow]→[/yellow] Source: [bold]Installed pip package[/bold]")
            console.print(f"   Location: {foundry_path}")
        else:
            console.print(f"[yellow]→[/yellow] Source: [bold]Custom location[/bold]")
            console.print(f"   Location: {foundry_path}")
    except Exception as e:
        console.print(f"[red]✗[/red] Could not determine source: {e}")
    
    print()


def check_build_differences():
    """Compare differences between local build and pip package"""
    console.print("\n[bold cyan]Build Comparison[/bold cyan]")
    console.print("=" * 50)
    
    try:
        # Get local version
        local_version = get_sscli_version()
        
        # Try to get pip version
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "sscli"],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            pip_version = "not installed"
            for line in result.stdout.split('\n'):
                if line.startswith('Version:'):
                    pip_version = line.split(':')[1].strip()
                    break
        else:
            pip_version = "not installed"
        
        console.print(f"Local build:  {local_version}")
        console.print(f"Pip package:  {pip_version}")
        
        if local_version == pip_version:
            console.print("\n[green]✓[/green] Versions match")
        else:
            console.print(f"\n[yellow]⚠[/yellow]  Versions differ")
            console.print("\nUse: [cyan]sscli dev swap[/cyan] to toggle between them")
    
    except Exception as e:
        console.print(f"[red]✗[/red] Error checking versions: {e}")
    
    print()


def run_development_tests():
    """Run development and debugging tests"""
    console.print("\n[bold cyan]Development Tests[/bold cyan]")
    console.print("=" * 50)
    
    # Test imports
    console.print("[cyan]→[/cyan] Testing core imports...")
    try:
        from foundry import cli
        from foundry import animations
        from foundry import auth
        from foundry import gate
        console.print("[green]✓[/green] All core modules imported successfully")
    except ImportError as e:
        console.print(f"[red]✗[/red] Import failed: {e}")
    
    # Test basic connectivity
    console.print("\n[cyan]→[/cyan] Testing environment...")
    try:
        console.print(f"[green]✓[/green] Python: {sys.version.split()[0]}")
        console.print(f"[green]✓[/green] Platform: {platform.system()} {platform.release()}")
    except Exception as e:
        console.print(f"[red]✗[/red] Environment check failed: {e}")
    
    print()


def show_development_info():
    """Show detailed development environment information"""
    console.print("\n[bold cyan]Development Environment[/bold cyan]")
    console.print("=" * 50)
    
    console.print(f"\n[bold]System:[/bold]")
    console.print(f"  OS:        {platform.system()} {platform.release()}")
    console.print(f"  Python:    {sys.version.split()[0]}")
    console.print(f"  Executable: {sys.executable}")
    
    console.print(f"\n[bold]Environment:[/bold]")
    if 'VIRTUAL_ENV' in os.environ:
        console.print(f"  Virtual Env: {os.environ['VIRTUAL_ENV']}")
    else:
        console.print(f"  Virtual Env: Not detected")
    
    console.print(f"  Working Dir: {os.getcwd()}")
    
    console.print(f"\n[bold]Packages:[/bold]")
    packages = ['typer', 'rich', 'questionary', 'requests', 'pydantic', 'httpx']
    for pkg in packages:
        try:
            mod = __import__(pkg)
            version = getattr(mod, '__version__', 'installed')
            console.print(f"  ✓ {pkg}: {version}")
        except ImportError:
            console.print(f"  ✗ {pkg}: NOT INSTALLED")
    
    print()
