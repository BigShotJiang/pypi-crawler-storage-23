"""
Dry-Run Engine for Phase 2 of the Codemod Transformation Engine.

Allows users to preview code transformations before applying them.
Generates unified diffs, JSON output, and statistics.

Key Features:
- Execute codemods without writing to disk
- Capture all would-be modifications
- Generate unified diff output (compatible with 'git apply', 'less', etc.)
- JSON export for CI/CD integration
- Summary statistics (lines added/removed per file)
"""

import json
import difflib
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional, Callable, Dict, List, Tuple
from datetime import datetime
import copy


@dataclass
class FileModification:
    """Represents a single file modification in a dry-run."""
    file_path: str
    original_content: str
    modified_content: str
    changes_made: int = 0
    error: Optional[str] = None
    success: bool = True
    
    def __post_init__(self):
        """Calculate changes if not set."""
        if self.success and (not self.changes_made and 
                            self.original_content != self.modified_content):
            self.changes_made = 1
    
    def get_line_stats(self) -> Tuple[int, int]:
        """
        Calculate added and removed lines.
        
        Returns:
            Tuple of (lines_added, lines_removed)
        """
        orig_lines = self.original_content.splitlines(keepends=True)
        mod_lines = self.modified_content.splitlines(keepends=True)
        
        diff = list(difflib.unified_diff(
            orig_lines, mod_lines,
            n=0,  # No context lines for stat calculation
            lineterm=''
        ))
        
        added = sum(1 for line in diff if line.startswith('+') and not line.startswith('+++'))
        removed = sum(1 for line in diff if line.startswith('-') and not line.startswith('---'))
        
        return added, removed
    
    def has_changes(self) -> bool:
        """Check if this file has actual modifications."""
        return self.original_content != self.modified_content and self.success
    
    def as_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        added, removed = self.get_line_stats() if self.success else (0, 0)
        return {
            "file_path": self.file_path,
            "success": self.success,
            "error": self.error,
            "changes_made": self.changes_made,
            "lines_added": added if self.success else 0,
            "lines_removed": removed if self.success else 0,
            "has_changes": self.has_changes()
        }


@dataclass
class DryRunResult:
    """Aggregated result of a dry-run operation."""
    modifications: List[FileModification] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    total_files: int = 0
    successful_files: int = 0
    failed_files: int = 0
    total_changes: int = 0
    total_lines_added: int = 0
    total_lines_removed: int = 0
    
    def add_modification(self, mod: FileModification) -> None:
        """Add a modification to the result."""
        self.modifications.append(mod)
        self.total_files += 1
        
        if mod.success:
            self.successful_files += 1
            self.total_changes += mod.changes_made
            added, removed = mod.get_line_stats()
            self.total_lines_added += added
            self.total_lines_removed += removed
        else:
            self.failed_files += 1
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        return {
            "timestamp": self.timestamp,
            "total_files": self.total_files,
            "successful_files": self.successful_files,
            "failed_files": self.failed_files,
            "total_changes": self.total_changes,
            "total_lines_added": self.total_lines_added,
            "total_lines_removed": self.total_lines_removed,
            "files_with_changes": sum(1 for m in self.modifications if m.has_changes())
        }
    
    def get_files_with_changes(self) -> List[FileModification]:
        """Get only modifications that have actual changes."""
        return [m for m in self.modifications if m.has_changes()]


class DryRunEngine:
    """
    Main engine for previewing code transformations without applying them.
    
    Provides multiple output formats:
    - Unified diff (default)
    - JSON (for integration with CI/CD tools)
    - Statistics summary
    
    Usage:
        engine = DryRunEngine()
        result = engine.preview_transformation(
            file_path,
            codemod,
            original_content,
            modified_content
        )
        print(engine.as_unified_diff())
    """
    
    def __init__(self):
        """Initialize the dry-run engine."""
        self.result = DryRunResult()
    
    def preview_transformation(
        self,
        file_path: Path,
        original_content: str,
        modified_content: str,
        changes_made: int = 1,
        error: Optional[str] = None
    ) -> FileModification:
        """
        Record a single file transformation preview.
        
        Args:
            file_path: Path to the file being transformed
            original_content: Original file content
            modified_content: Modified file content (what it would become)
            changes_made: Number of modifications applied (default: 1)
            error: Error message if transformation failed (optional)
        
        Returns:
            FileModification object
        """
        str_path = str(file_path)
        success = error is None
        
        mod = FileModification(
            file_path=str_path,
            original_content=original_content,
            modified_content=modified_content,
            changes_made=changes_made if success else 0,
            error=error,
            success=success
        )
        
        self.result.add_modification(mod)
        return mod
    
    def preview_all(
        self,
        project_path: Path,
        codemod_fn: Callable[[Path, str], Tuple[str, Optional[str]]],
        file_pattern: str = "**/*.py"
    ) -> DryRunResult:
        """
        Preview multiple file transformations.
        
        Args:
            project_path: Root directory to scan
            codemod_fn: Function that takes (file_path, content) and returns (modified_content, error)
            file_pattern: Glob pattern for files to process (default: **/*.py)
        
        Returns:
            DryRunResult containing all modifications
        """
        self.result = DryRunResult()  # Reset for batch operation
        
        project_path = Path(project_path)
        if not project_path.exists():
            self.result.add_modification(FileModification(
                file_path=str(project_path),
                original_content="",
                modified_content="",
                error=f"Project path not found: {project_path}",
                success=False
            ))
            return self.result
        
        for file_path in project_path.glob(file_pattern):
            if file_path.is_file():
                try:
                    original_content = file_path.read_text(encoding="utf-8")
                    modified_content, error = codemod_fn(file_path, original_content)
                    
                    if error is None and modified_content is None:
                        continue  # Skip if no modification
                    
                    if modified_content is None:
                        modified_content = original_content
                    
                    self.preview_transformation(
                        file_path,
                        original_content,
                        modified_content,
                        error=error
                    )
                except Exception as e:
                    self.preview_transformation(
                        file_path,
                        "",
                        "",
                        error=f"Failed to process file: {str(e)}"
                    )
        
        return self.result
    
    def as_unified_diff(self, context_lines: int = 3) -> str:
        """
        Export modifications as unified diff format.
        
        Format is compatible with:
        - 'git apply' for patching
        - 'less' for viewing
        - Piping to other diff tools
        
        Args:
            context_lines: Number of context lines around changes (default: 3)
        
        Returns:
            String containing unified diff for all modifications with changes
        """
        output_lines = []
        
        # Header
        output_lines.append(f"Dry-Run Preview - {self.result.timestamp}")
        output_lines.append(f"Files with changes: {len(self.result.get_files_with_changes())}")
        output_lines.append("")
        
        # Generate diffs for each file with changes
        for mod in self.result.get_files_with_changes():
            if not mod.success:
                continue
            
            orig_lines = mod.original_content.splitlines(keepends=True)
            mod_lines = mod.modified_content.splitlines(keepends=True)
            
            # Generate unified diff
            diff_lines = difflib.unified_diff(
                orig_lines,
                mod_lines,
                fromfile=f"a/{mod.file_path}",
                tofile=f"b/{mod.file_path}",
                n=context_lines,
                lineterm=''
            )
            
            output_lines.extend(diff_lines)
            output_lines.append("")  # Blank line between files
        
        return "\n".join(output_lines)
    
    def as_json(self, include_content: bool = False) -> str:
        """
        Export modifications as JSON.
        
        Args:
            include_content: If True, include full original/modified content
                           (default: False for brevity in CI/CD)
        
        Returns:
            JSON string of the dry-run result
        """
        summary = self.result.get_summary()
        modifications = []
        
        for mod in self.result.modifications:
            mod_data = mod.as_dict()
            
            if include_content:
                mod_data["original_content"] = mod.original_content
                mod_data["modified_content"] = mod.modified_content
            
            modifications.append(mod_data)
        
        output = {
            "summary": summary,
            "modifications": modifications
        }
        
        return json.dumps(output, indent=2)
    
    def as_stats(self, verbose: bool = True) -> str:
        """
        Export summary statistics.
        
        Args:
            verbose: If True, show per-file stats; if False, show only totals
        
        Returns:
            Formatted statistics string
        """
        summary = self.result.get_summary()
        lines = []
        
        # Header
        lines.append("=" * 60)
        lines.append("DRY-RUN PREVIEW STATISTICS")
        lines.append("=" * 60)
        lines.append("")
        
        # Summary section
        lines.append("SUMMARY:")
        lines.append(f"  Total Files Processed:  {summary['total_files']}")
        lines.append(f"  Files with Changes:     {summary['files_with_changes']}")
        lines.append(f"  Successful:             {summary['successful_files']}")
        lines.append(f"  Failed:                 {summary['failed_files']}")
        lines.append("")
        
        # Code changes section
        lines.append("CODE CHANGES:")
        lines.append(f"  Total Modifications:    {summary['total_changes']}")
        lines.append(f"  Lines Added:            {summary['total_lines_added']}")
        lines.append(f"  Lines Removed:          {summary['total_lines_removed']}")
        lines.append("")
        
        # Per-file details (if verbose and there are changes)
        if verbose and self.result.get_files_with_changes():
            lines.append("PER-FILE BREAKDOWN:")
            lines.append("")
            
            for mod in self.result.get_files_with_changes():
                added, removed = mod.get_line_stats()
                lines.append(f"  📄 {mod.file_path}")
                lines.append(f"     Changes:  {mod.changes_made}")
                lines.append(f"     +Lines:   {added}")
                lines.append(f"     -Lines:   {removed}")
            
            lines.append("")
        
        # Error section (if any)
        failed_mods = [m for m in self.result.modifications if not m.success]
        if failed_mods:
            lines.append("ERRORS:")
            lines.append("")
            for mod in failed_mods:
                lines.append(f"  ❌ {mod.file_path}")
                lines.append(f"     Error: {mod.error}")
            lines.append("")
        
        lines.append("=" * 60)
        
        return "\n".join(lines)
    
    def has_changes(self) -> bool:
        """Check if any modifications have actual changes."""
        return len(self.result.get_files_with_changes()) > 0
    
    def has_errors(self) -> bool:
        """Check if any transformations failed."""
        return self.result.failed_files > 0
    
    def get_summary_line(self) -> str:
        """Get a single-line summary for quick reference."""
        summary = self.result.get_summary()
        return (
            f"{summary['files_with_changes']} files, "
            f"{summary['total_lines_added']}⬆️  "
            f"{summary['total_lines_removed']}⬇️"
        )


class DryRunCodemodWrapper:
    """
    Wrapper that adapts the DryRunEngine to work with BaseCodemod instances.
    
    This allows existing codemods to be executed in dry-run mode without
    modifying their implementation.
    
    Usage:
        engine = DryRunEngine()
        wrapper = DryRunCodemodWrapper(engine, codemod)
        wrapper.apply_to_file(file_path)
    """
    
    def __init__(self, engine: DryRunEngine, codemod_class: type):
        """
        Initialize the wrapper.
        
        Args:
            engine: DryRunEngine instance
            codemod_class: The codemod class (not instance)
        """
        self.engine = engine
        self.codemod_class = codemod_class
    
    def apply_to_file(self, file_path: Path, *args, **kwargs) -> FileModification:
        """
        Apply a codemod to a file in dry-run mode.
        
        Args:
            file_path: Path to file to transform
            *args, **kwargs: Arguments to pass to codemod constructor
        
        Returns:
            FileModification with the results
        """
        if not file_path.exists():
            return self.engine.preview_transformation(
                file_path,
                "",
                "",
                error=f"File not found: {file_path}"
            )
        
        try:
            original_content = file_path.read_text(encoding="utf-8")
            
            # Create codemod instance with a mock that doesn't write
            codemod = self.codemod_class(*args, **kwargs)
            
            # We need to capture the output without writing
            # This is a bit hacky but allows us to use existing codemods
            import tempfile
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix=file_path.suffix,
                delete=False,
                dir=file_path.parent,
                encoding="utf-8"
            ) as tmp:
                tmp.write(original_content)
                tmp_path = Path(tmp.name)
            
            try:
                # Apply transformation to temp file
                result = codemod.apply(tmp_path)
                
                if result.success:
                    modified_content = tmp_path.read_text(encoding="utf-8")
                else:
                    modified_content = original_content
                
                return self.engine.preview_transformation(
                    file_path,
                    original_content,
                    modified_content,
                    changes_made=result.changes_made,
                    error=result.error if not result.success else None
                )
            finally:
                # Clean up temp file
                tmp_path.unlink(missing_ok=True)
        
        except Exception as e:
            return self.engine.preview_transformation(
                file_path,
                "",
                "",
                error=f"Codemod execution failed: {str(e)}"
            )
