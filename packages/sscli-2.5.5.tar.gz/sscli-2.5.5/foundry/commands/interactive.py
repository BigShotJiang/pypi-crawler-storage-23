import typer
from foundry.telemetry import log_event

interactive_app = typer.Typer(help="Interactive modes for Seed & Source.")


@interactive_app.callback(invoke_without_command=True)
def interactive_default(ctx: typer.Context):
    """Start the default interactive menu."""
    if ctx.invoked_subcommand is None:
        log_event("COMMAND", "interactive")
        from foundry.interactive import interactive_menu

        interactive_menu()


@interactive_app.command("animated")
def interactive_animated():
    """Start the robust animated interactive experience."""
    log_event("COMMAND", "interactive animated")
    from foundry.interactive import run_animated_experience

    run_animated_experience()
