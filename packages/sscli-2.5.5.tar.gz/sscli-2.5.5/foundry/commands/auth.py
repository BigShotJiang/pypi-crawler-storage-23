import typer
from foundry.auth import login_flow, logout, get_current_license_info
from foundry.telemetry import log_event
from foundry.constants import console


auth_app = typer.Typer(help="Manage authentication and licenses.")


@auth_app.command("login")
def auth_login():
    """Login to Seed & Source to unlock ALPHA/PRO templates."""
    log_event("COMMAND", "auth login")
    if login_flow():
        auth_info = get_current_license_info()
        console.print(f"\n[green]✓ You are now authenticated as {auth_info.get('tier', 'user').upper()}[/green]")
    else:
        console.print("\n[yellow]⚠️  Login was not completed.[/yellow]")


@auth_app.command("logout")
def auth_logout():
    """Clear local credentials."""
    log_event("COMMAND", "auth logout")
    logout()


def run_whoami():
    """Display current user and license tier."""
    log_event("COMMAND", "whoami")
    info = get_current_license_info(verify=True)
    if not info or not info.get("authorized", False):
        console.print("Not logged in. Use 'sscli auth login' to authenticate.")
        return

    from rich.console import Console
    from rich.panel import Panel

    stat_console = Console()
    status_color = "green" if info.get("status") != "expired" else "red"

    tier_str = info.get('tier', 'free').upper()
    org_name = info.get('org_name')
    if org_name:
        tier_display = f"{tier_str} (via {org_name})"
    else:
        tier_display = tier_str

    stat_console.print(
        Panel(
            f"👤 [bold]User:[/bold] {info.get('user_id', 'Unknown')}\n"
            f"🏆 [bold]Tier:[/bold] {tier_display}\n"
            f"📅 [bold]Expires:[/bold] {info.get('expires', 'N/A')}\n"
            f"✨ [bold]Status:[/bold] [{status_color}]{info.get('status', 'active').upper()}[/{status_color}]",
            title="User Profile",
            expand=False,
        )
    )
