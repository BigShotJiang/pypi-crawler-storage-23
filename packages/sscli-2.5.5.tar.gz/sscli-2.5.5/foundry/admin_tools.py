"""
PactaPay Admin Tools - Interactive management of multi-tenant SaaS models.

This module provides a CLI interface for managing:
- Tenants: Create, list, configure SaaS customers
- Integrations: Register and manage Shopify, Stripe, WooCommerce connections
- Commercial Agreements: View and track orders that trigger token generation
- Security Tokens: Monitor and revoke generated credentials
- Artifacts: View webhook processing history for debugging
"""

import questionary
from questionary import Choice
from foundry.constants import console, QUESTIONARY_STYLE


def pactapay_admin_menu():
    """Main menu for PactaPay admin and tenant management."""
    console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]   PactaPay Admin Tools[/bold cyan]")
    console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")
    
    console.print("[yellow]Note:[/yellow] These tools require a running Rails API with database connection.\n")

    while True:
        action = questionary.select(
            "Admin Operations:",
            choices=[
                Choice("🏢 Manage Tenants", value="tenants", description="Create and manage SaaS customer accounts"),
                Choice("🔗 Manage Integrations (Shopify, Stripe, etc)", value="integrations", description="Register payment and commerce integrations"),
                Choice("📦 View Commercial Agreements (Orders)", value="agreements", description="Track orders and trigger token generation"),
                Choice("🎫 Monitor Security Tokens", value="tokens", description="View and revoke generated API credentials"),
                Choice("🔍 Debug & View Artifacts (Webhook History)", value="artifacts", description="Inspect webhook processing for debugging"),
                "Back",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values
        if action == "tenants":
            action = "🏢 Manage Tenants"
        elif action == "integrations":
            action = "🔗 Manage Integrations (Shopify, Stripe, etc)"
        elif action == "agreements":
            action = "📦 View Commercial Agreements (Orders)"
        elif action == "tokens":
            action = "🎫 Monitor Security Tokens"
        elif action == "artifacts":
            action = "🔍 Debug & View Artifacts (Webhook History)"

        if action == "Back":
            break

        if action == "🏢 Manage Tenants":
            manage_tenants_menu()
        elif action == "🔗 Manage Integrations (Shopify, Stripe, etc)":
            manage_integrations_menu()
        elif action == "📦 View Commercial Agreements (Orders)":
            view_agreements_menu()
        elif action == "🎫 Monitor Security Tokens":
            monitor_tokens_menu()
        elif action == "🔍 Debug & View Artifacts (Webhook History)":
            view_artifacts_menu()


def manage_tenants_menu():
    """Manage SaaS tenant accounts."""
    console.print("\n[bold]Tenant Management[/bold]")
    console.print("Represents a SaaS customer account (e.g., 'PactaPay Inc').\n")

    action = questionary.select(
        "Choose action:",
        choices=[
            Choice("➕ Create New Tenant", value="create", description="Add a new SaaS customer account"),
            Choice("📋 List All Tenants", value="list", description="View all existing tenants"),
            Choice("✏️  View Tenant Details", value="details", description="Inspect a specific tenant's configuration"),
            "Back",
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    # Map choice values
    if action == "create":
        action = "➕ Create New Tenant"
    elif action == "list":
        action = "📋 List All Tenants"
    elif action == "details":
        action = "✏️  View Tenant Details"

    if action == "➕ Create New Tenant":
        _create_tenant()
    elif action == "📋 List All Tenants":
        _list_tenants()
    elif action == "✏️  View Tenant Details":
        _view_tenant_details()


def _create_tenant():
    """Interactive tenant creation."""
    console.print("\n[bold]Create New Tenant[/bold]")
    console.print("[dim]A tenant represents a SaaS customer account.\n[/dim]")

    name = questionary.text("Tenant name (e.g., 'PactaPay Inc'):").ask()
    subdomain = questionary.text("Subdomain for routing (e.g., 'pactapay'):").ask()
    
    plan = questionary.select(
        "Service plan:",
        choices=[
            Choice("free", value="free", description="Free tier (basic features)"),
            Choice("pro", value="pro", description="Professional plan (advanced features)"),
            Choice("enterprise", value="enterprise", description="Enterprise plan (custom SLA)"),
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    console.print(f"\n[bold green]✓ Ready to create:[/bold green]")
    console.print(f"  Name: {name}")
    console.print(f"  Subdomain: {subdomain}")
    console.print(f"  Plan: {plan}\n")

    confirm = questionary.confirm("Create this tenant?").ask()
    if confirm:
        console.print("[bold yellow]→[/bold yellow] Run this in your Rails console:\n")
        console.print(f"""[cyan]
rails console
> Tenant.create!(
>   name: "{name}",
>   subdomain: "{subdomain}",
>   plan: "{plan}"
> )
        [/cyan]\n""")
        input("Press Enter after running the command...")


def _list_tenants():
    """List all tenants."""
    console.print("\n[bold]All Tenants[/bold]")
    console.print("[dim]Run this in your Rails console to see all tenants:\n[/dim]")
    console.print("""[cyan]
rails console
> Tenant.all.map { |t| "#{t.id}: #{t.name} (#{t.subdomain}) - #{t.plan}" }
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _view_tenant_details():
    """View details for a specific tenant."""
    tenant_id = questionary.text("Enter Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Tenant Details - {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tenant.inspect
> 
> # View associated integrations
> tenant.integrations
>
> # View associated tokens
> tenant.security_tokens.count
    [/cyan]\n""")
    input("Press Enter after viewing...")


def manage_integrations_menu():
    """Manage platform integrations (Shopify, Stripe, etc)."""
    console.print("\n[bold]Integration Management[/bold]")
    console.print("[dim]Register and manage connections to Shopify, Stripe, WooCommerce, etc.\n[/dim]")

    action = questionary.select(
        "Choose action:",
        choices=[
            Choice("➕ Register New Integration", value="register", description="Connect a new external platform account"),
            Choice("📋 List Integrations for Tenant", value="list", description="View all integrations configured for a tenant"),
            Choice("🔄 Update Integration Credentials", value="update", description="Modify API keys or secrets for an integration"),
            Choice("❌ Remove Integration", value="remove", description="Permanently delete a platform connection"),
            "Back",
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    # Map choice values
    if action == "register":
        action = "➕ Register New Integration"
    elif action == "list":
        action = "📋 List Integrations for Tenant"
    elif action == "update":
        action = "🔄 Update Integration Credentials"
    elif action == "remove":
        action = "❌ Remove Integration"

    if action == "➕ Register New Integration":
        _register_integration()
    elif action == "📋 List Integrations for Tenant":
        _list_integrations()
    elif action == "🔄 Update Integration Credentials":
        _update_integration()
    elif action == "❌ Remove Integration":
        _remove_integration()


def _register_integration():
    """Register a new platform integration."""
    console.print("\n[bold]Register New Integration[/bold]")
    console.print("[dim]Connect a Shopify store, Stripe account, or other platform.\n[/dim]")

    tenant_id = questionary.text("Tenant ID:").ask()
    
    provider = questionary.select(
        "Platform type:",
        choices=["shopify", "stripe", "woocommerce"],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    platform_domain = questionary.text(
        f"Platform domain (e.g., 'my-store.myshopify.com' for Shopify):"
    ).ask()

    console.print(f"\n[bold yellow]→[/bold yellow] Run this in your Rails console:\n")
    
    if provider == "shopify":
        console.print("""[cyan]
rails console
> Integration.create!(
>   tenant_id: """ + tenant_id + """,
>   provider_type: "shopify",
>   platform_domain: """ + f'"{platform_domain}"' + """,
>   platform_token: "shpua_YOUR_API_TOKEN",      # Get from Shopify Partner Dashboard
>   webhook_secret: "shpss_YOUR_WEBHOOK_SECRET"  # Get from Shopify Partner Dashboard
> )
        [/cyan]""")
    elif provider == "stripe":
        console.print("""[cyan]
rails console
> Integration.create!(
>   tenant_id: """ + tenant_id + """,
>   provider_type: "stripe",
>   platform_domain: """ + f'"{platform_domain}"' + """,
>   platform_token: "sk_live_YOUR_STRIPE_KEY",   # Your Stripe Secret Key
>   webhook_secret: "whsec_YOUR_WEBHOOK_SECRET"  # Get from Stripe Dashboard
> )
        [/cyan]""")
    
    console.print()
    input("Press Enter after running the command...")


def _list_integrations():
    """List integrations for a tenant."""
    tenant_id = questionary.text("Enter Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Integrations for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tenant.integrations.map {{ |i| "ID: {{i.id}}, Provider: {{i.provider_type}}, Domain: {{i.platform_domain}}" }}
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _update_integration():
    """Update integration credentials."""
    console.print("\n[bold]Update Integration Credentials[/bold]")
    integration_id = questionary.text("Integration ID:").ask()
    
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> integration = Integration.find({integration_id})
> integration.update!(
>   platform_token: "NEW_API_TOKEN",
>   webhook_secret: "NEW_WEBHOOK_SECRET"
> )
> integration.inspect
    [/cyan]\n""")
    input("Press Enter after updating...")


def _remove_integration():
    """Remove an integration."""
    console.print("\n[bold]Remove Integration[/bold]")
    integration_id = questionary.text("Integration ID to remove:").ask()
    
    confirm = questionary.confirm(
        f"Delete integration {integration_id}? (This cannot be undone)"
    ).ask()
    
    if confirm:
        console.print("[dim]Run this in your Rails console:\n[/dim]")
        console.print(f"""[cyan]
rails console
> Integration.find({integration_id}).destroy!
        [/cyan]\n""")
    input("Press Enter after confirming...")


def view_agreements_menu():
    """View commercial agreements (orders that triggered token generation)."""
    console.print("\n[bold]Commercial Agreements[/bold]")
    console.print("[dim]Orders and transactions that trigger token generation.\n[/dim]")

    action = questionary.select(
        "Choose action:",
        choices=[
            Choice("📋 List Agreements for Tenant", value="list", description="Browse all orders and license transactions"),
            Choice("🔍 View Agreement Details", value="details", description="Inspect raw order data and linked tokens"),
            Choice("📊 Agreement Statistics", value="stats", description="View volume and status breakdowns"),
            "Back",
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    # Map choice values
    if action == "list":
        action = "📋 List Agreements for Tenant"
    elif action == "details":
        action = "🔍 View Agreement Details"
    elif action == "stats":
        action = "📊 Agreement Statistics"

    if action == "📋 List Agreements for Tenant":
        _list_agreements()
    elif action == "🔍 View Agreement Details":
        _view_agreement_details()
    elif action == "📊 Agreement Statistics":
        _agreement_stats()


def _list_agreements():
    """List all agreements for a tenant."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Agreements for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tenant.commercial_agreements.map {{ |a| "ID: {{a.id}}, Order: {{a.external_order_id}}, Status: {{a.status}}, Date: {{a.created_at}}" }}
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _view_agreement_details():
    """View details of a specific agreement."""
    agreement_id = questionary.text("Agreement ID:").ask()
    
    console.print(f"\n[bold]Agreement {agreement_id} Details[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> agreement = CommercialAgreement.find({agreement_id})
> agreement.inspect
>
> # View associated token
> agreement.security_token&.inspect
>
> # View raw order data
> puts JSON.pretty_generate(agreement.order_data)
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _agreement_stats():
    """Show agreement statistics."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Agreement Statistics for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> puts "Total Agreements: #{{tenant.commercial_agreements.count}}"
> puts "Processed: #{{tenant.commercial_agreements.where(status: 'processed').count}}"
> puts "Pending: #{{tenant.commercial_agreements.where(status: 'pending').count}}"
> puts "Failed: #{{tenant.commercial_agreements.where(status: 'failed').count}}"
    [/cyan]\n""")
    input("Press Enter after viewing...")


def monitor_tokens_menu():
    """Monitor security tokens (credentials delivered to customers)."""
    console.print("\n[bold]Security Tokens[/bold]")
    console.print("[dim]Credentials generated and delivered to customers for redemption.\n[/dim]")

    action = questionary.select(
        "Choose action:",
        choices=[
            Choice("📋 List Tokens for Tenant", value="list", description="Browse all issued security tokens"),
            Choice("🔍 View Token Details", value="details", description="Check expiration and usage status"),
            Choice("🎯 Search Token by Value", value="search", description="Find a specific token by its unique string"),
            Choice("🚫 Revoke Token", value="revoke", description="Immediately invalidate a security token"),
            Choice("📊 Token Statistics", value="stats", description="View redemption and revocation metrics"),
            "Back",
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    # Map choice values
    if action == "list":
        action = "📋 List Tokens for Tenant"
    elif action == "details":
        action = "🔍 View Token Details"
    elif action == "search":
        action = "🎯 Search Token by Value"
    elif action == "revoke":
        action = "🚫 Revoke Token"
    elif action == "stats":
        action = "📊 Token Statistics"

    if action == "📋 List Tokens for Tenant":
        _list_tokens()
    elif action == "🔍 View Token Details":
        _view_token_details()
    elif action == "🎯 Search Token by Value":
        _search_token()
    elif action == "🚫 Revoke Token":
        _revoke_token()
    elif action == "📊 Token Statistics":
        _token_stats()


def _list_tokens():
    """List tokens for a tenant."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Security Tokens for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tenant.security_tokens.map {{ |t| "ID: {{t.id}}, Token: {{t.token[0..10]}}..., Expires: {{t.expires_at}}, Revoked: {{t.revoked_at}}" }}
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _view_token_details():
    """View a specific token's details."""
    token_id = questionary.text("Token ID:").ask()
    
    console.print(f"\n[bold]Token {token_id} Details[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> token = SecurityToken.find({token_id})
> token.inspect
>
> # View associated agreement (order)
> token.commercial_agreement&.inspect
>
> # View redemption status
> token.revoked_at.nil? ? "Active" : "Revoked at " + token.revoked_at.to_s
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _search_token():
    """Search for a token by its value."""
    token_value = questionary.text("Token value (full or partial):").ask()
    
    console.print(f"\n[bold]Search Results for '{token_value}'[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> SecurityToken.where("token ILIKE ?", "%{token_value}%").map {{ |t| "ID: {{t.id}}, Tenant: {{t.tenant.name}}, Status: {{t.revoked_at.nil? ? 'Active' : 'Revoked'}}" }}
    [/cyan]\n""")
    input("Press Enter after searching...")


def _revoke_token():
    """Revoke a security token."""
    token_id = questionary.text("Token ID to revoke:").ask()
    
    console.print(f"\n[bold yellow]WARNING:[/bold yellow] Revoking a token will prevent its redemption.\n")
    
    reason = questionary.text("Reason for revocation (optional):").ask()
    
    confirm = questionary.confirm("Revoke this token?").ask()
    if confirm:
        console.print("[dim]Run this in your Rails console:\n[/dim]")
        console.print(f"""[cyan]
rails console
> token = SecurityToken.find({token_id})
> token.update!(revoked_at: Time.current)
> # Optional: log the reason
> puts "Revoked at: {{token.revoked_at}}"
        [/cyan]\n""")
    input("Press Enter after revoking...")


def _token_stats():
    """Show token statistics."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Token Statistics for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tokens = tenant.security_tokens
> puts "Total Tokens: #{{tokens.count}}"
> puts "Active: #{{tokens.where(revoked_at: nil).count}}"
> puts "Revoked: #{{tokens.where.not(revoked_at: nil).count}}"
> puts "Expired: #{{tokens.where("expires_at < ?", Time.current).count}}"
    [/cyan]\n""")
    input("Press Enter after viewing...")


def view_artifacts_menu():
    """View artifacts (webhook processing history for debugging)."""
    console.print("\n[bold]Artifacts (Webhook Idempotency & History)[/bold]")
    console.print("[dim]Markers that prevent duplicate webhook processing. Useful for debugging.\n[/dim]")

    action = questionary.select(
        "Choose action:",
        choices=[
            Choice("📋 List Recent Artifacts", value="list", description="Browse recent webhook event records"),
            Choice("🔍 View Artifact Details", value="details", description="Inspect processing results and timestamps"),
            Choice("🐛 Check for Duplicate Webhooks", value="duplicates", description="Verify if an event ID was processed multiple times"),
            Choice("📊 Webhook Processing Statistics", value="stats", description="View event volume and success rates"),
            "Back",
        ],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    # Map choice values
    if action == "list":
        action = "📋 List Recent Artifacts"
    elif action == "details":
        action = "🔍 View Artifact Details"
    elif action == "duplicates":
        action = "🐛 Check for Duplicate Webhooks"
    elif action == "stats":
        action = "📊 Webhook Processing Statistics"

    if action == "📋 List Recent Artifacts":
        _list_artifacts()
    elif action == "🔍 View Artifact Details":
        _view_artifact_details()
    elif action == "🐛 Check for Duplicate Webhooks":
        _check_duplicates()
    elif action == "📊 Webhook Processing Statistics":
        _artifact_stats()


def _list_artifacts():
    """List recent artifacts."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    limit = questionary.text("Number of recent artifacts (default 20):", default="20").ask()
    
    console.print(f"\n[bold]Recent Artifacts for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> tenant.artifacts.order(created_at: :desc).limit({limit}).map {{ |a| "ID: {{a.id}}, Event: {{a.event_type}}, External ID: {{a.external_id}}, Processed: {{a.processed_at}}" }}
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _view_artifact_details():
    """View a specific artifact's details."""
    artifact_id = questionary.text("Artifact ID:").ask()
    
    console.print(f"\n[bold]Artifact {artifact_id} Details[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> artifact = Artifact.find({artifact_id})
> artifact.inspect
>
> # Check if this event was processed multiple times
> Artifact.where(external_id: artifact.external_id).count
    [/cyan]\n""")
    input("Press Enter after viewing...")


def _check_duplicates():
    """Check for duplicate webhook processing."""
    event_id = questionary.text("External Event ID (Shopify webhook ID, Stripe event ID, etc):").ask()
    
    console.print(f"\n[bold]Checking for Duplicate Processing of Event {event_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> duplicates = Artifact.where(external_id: "{event_id}")
> puts "Found {{duplicates.count}} processing record(s):"
> duplicates.each {{ |a| puts "  - {{a.event_type}} at {{a.processed_at}}" }}
>
> # If count > 1, it was reprocessed (Shopify retry, etc)
    [/cyan]\n""")
    input("Press Enter after checking...")


def _artifact_stats():
    """Show webhook processing statistics."""
    tenant_id = questionary.text("Tenant ID or Subdomain:").ask()
    
    console.print(f"\n[bold]Webhook Processing Stats for Tenant {tenant_id}[/bold]")
    console.print("[dim]Run this in your Rails console:\n[/dim]")
    console.print(f"""[cyan]
rails console
> tenant = Tenant.find_by(id: {tenant_id}) || Tenant.find_by(subdomain: "{tenant_id}")
> artifacts = tenant.artifacts
> 
> puts "Total Webhook Events: #{{artifacts.count}}"
> puts ""
> puts "Event Breakdown:"
> artifacts.group(:event_type).count.each {{ |event, count| puts "  {{event}}: {{count}}" }}
> 
> puts ""
> puts "Last Event: #{{artifacts.order(processed_at: :desc).first&.processed_at}}"
    [/cyan]\n""")
    input("Press Enter after viewing...")
