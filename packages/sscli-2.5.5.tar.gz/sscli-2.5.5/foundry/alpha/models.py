from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Optional


class ExpirationStatus(Enum):
    """Expiration status of an alpha package."""

    ACTIVE = "active"
    WARNING = "warning"  # Within 7 days of expiration
    EXPIRED = "expired"


@dataclass
class AlphaInfo:
    """Information extracted from alpha watermark."""

    user_id: str
    email: str
    issue_date: date
    expires: date
    status: ExpirationStatus
    days_remaining: int
