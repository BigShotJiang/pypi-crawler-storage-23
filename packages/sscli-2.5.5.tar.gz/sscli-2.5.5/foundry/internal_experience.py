from foundry.constants import console
from foundry.actions.documentation import run_view_docs
from foundry.interactive_utils import pause
from foundry.animations import (AnimationSequence, InteractiveAnimationEngine)
from foundry.animations.scenes import (LogoDisperseAnimation,
                                       LogoRevealAnimation,
                                       LogoStaticAnimation,
                                       ForgeAnimation)

def run_internal_animated_experience():
    """Plays the internal development animation sequence with industrial theme."""
    engine = InteractiveAnimationEngine(fps=60, console=console)

    # 1. Play Intro Sequence once (industrial theme)
    try:
        intro = AnimationSequence(
            [
                LogoRevealAnimation(duration=1.2),
                LogoStaticAnimation(duration=1.0),
                LogoDisperseAnimation(duration=2.0),
            ]
        )
        engine.play(intro)
    except KeyboardInterrupt:
        console.print("[yellow]Goodbye![/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error during intro: {e}[/]")

    # 2. Main Menu Loop with Forge theme
    while True:
        try:
            # Play Forge animation with industrial menu
            choice = engine.play(ForgeAnimation())

            if not choice or choice == "Back to Main":
                console.print("[yellow]Goodbye![/yellow]")
                break

            # Dispatch the choice for internal ops
            try:
                from foundry.ops.manager import InternalManager
                from foundry.ops.runner import run_verification_script
                manager = InternalManager()

                if choice == "Verify Builds":
                    manager.verify_builds()
                    pause()
                elif choice == "Hygiene Check":
                    run_verification_script(manager.root_dir, "verify_hygiene", "Code Hygiene (File Lengths)")
                    pause()
                elif choice == "Full Suite":
                    manager.verify_full_suite()
                    pause()
                elif choice == "Clean Reports":
                    manager.clean_reports()
                    pause()
                elif choice == "View Docs":
                    run_view_docs(interactive=True)
                    pause()
                elif choice == "Back to Main":
                    break

            except ImportError:
                console.print("[red]Ops manager not available in this build.[/]")
                break

        except KeyboardInterrupt:
            console.print("[yellow]Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error during menu: {e}[/]")
            break
