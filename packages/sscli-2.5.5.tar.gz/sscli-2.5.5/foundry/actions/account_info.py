"""Account information and management experience."""

import questionary
from questionary import Choice
from rich.panel import Panel
from rich.table import Table

from foundry.auth import get_current_license_info, logout
from foundry.constants import console, QUESTIONARY_STYLE


def show_account_info(auth_info: dict) -> None:
    """Display account information in a formatted panel."""
    tier_str = auth_info.get('tier', 'free').upper()
    org_name = auth_info.get('org_name')
    email = auth_info.get('email', 'Not available')
    status = auth_info.get('status', 'active')
    
    # Determine status color
    status_color = "green" if status == "active" else "red"
    tier_display = f"{tier_str} (via {org_name})" if org_name else tier_str
    
    # Create info panel
    info_table = Table(show_header=False, box=None)
    info_table.add_row("[bold]Email:[/bold]", email)
    info_table.add_row("[bold]License Tier:[/bold]", tier_display)
    info_table.add_row("[bold]Status:[/bold]", f"[{status_color}]{status.upper()}[/{status_color}]")
    
    panel = Panel(
        info_table,
        title="[bold cyan]Account Information[/bold cyan]",
        expand=False,
        border_style="cyan"
    )
    
    console.print(f"\n{panel}\n")


def account_info_menu(auth_info: dict) -> bool:
    """
    Display account menu with options to refresh, logout, or return.
    
    Returns:
        True if returning to main menu, False if logout was selected.
    """
    while True:
        show_account_info(auth_info)
        
        choice = questionary.select(
            "Account Options",
            choices=[
                Choice("🔄 Refresh Account Info", value="refresh"),
                Choice("🚪 Logout", value="logout"),
                "← Back to Main Menu",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values
        if choice == "refresh":
            choice = "🔄 Refresh Account Info"
        elif choice == "logout":
            choice = "🚪 Logout"
        
        if choice == "🔄 Refresh Account Info":
            # Get fresh auth info from server
            try:
                auth_info = get_current_license_info(verify=True)
                console.print("[green]✓ Account info refreshed[/green]\n")
            except Exception as e:
                console.print(f"[red]✗ Failed to refresh:[/red] {e}\n")
        
        elif choice == "🚪 Logout":
            confirm = questionary.confirm(
                "Are you sure you want to logout?",
                default=False
            ).ask()
            
            if confirm:
                logout()
                console.print("[green]✓ Successfully logged out[/green]\n")
                return False  # Signal logout
        
        elif choice == "← Back to Main Menu":
            return True  # Signal return to main menu
