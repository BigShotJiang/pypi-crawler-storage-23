"""
Development tools for sscli - status, build, and swap functionality
Internal development only - not available in production installs
"""
import subprocess
import questionary
import json
from pathlib import Path
from foundry.constants import console
from foundry.utils import is_internal_dev
from rich.panel import Panel
from rich.table import Table
import sys
import os
import importlib.util
# Detect venv location
def get_venv_path():
    """Detect Python virtual environment."""
    # First priority: VIRTUAL_ENV environment variable (most reliable)
    if os.environ.get('VIRTUAL_ENV'):
        venv = Path(os.environ['VIRTUAL_ENV'])
        if (venv / 'bin' / 'pip').exists() or (venv / 'bin' / 'python').exists():
            return venv
    
    # Second priority: Try to find venv near the script
    stack_cli_root = get_stack_cli_root()
    for venv_candidate in ['venv', '.venv', 'env']:
        venv_path = stack_cli_root / venv_candidate
        if (venv_path / 'bin' / 'python').exists():
            return venv_path
    
    # Third priority: try using sys.prefix (venv's location when activated)
    if hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix:
        # We're in a virtual environment
        return Path(sys.prefix)
    
    return None

def get_stack_cli_root():
    """Get the stack-cli root directory."""
    # First, try FOUNDRY_ROOT environment variable
    if os.environ.get('FOUNDRY_ROOT'):
        foundry_root = Path(os.environ['FOUNDRY_ROOT'])
        stack_cli_path = foundry_root / 'tooling' / 'stack-cli'
        if stack_cli_path.exists():
            return stack_cli_path
    
    # Check if foundry module is loaded from editable source
    try:
        import foundry
        foundry_file = Path(foundry.__file__).resolve()
        # foundry/__init__.py -> foundry -> stack-cli root
        candidate = foundry_file.parent.parent.parent
        pyproject = candidate / 'pyproject.toml'
        if pyproject.exists():
            with open(pyproject) as f:
                if 'name = "sscli"' in f.read():
                    return candidate
    except:
        pass
    
    # Fallback: look from the development.py file location
    current_file = Path(__file__).resolve()
    candidate = current_file.parent.parent.parent
    if (candidate / 'pyproject.toml').exists():
        with open(candidate / 'pyproject.toml') as f:
            content = f.read()
            if 'name = "sscli"' in content:
                return candidate
    
    # Last resort: return None (will cause get_local_version to return "unknown")
    return None

def get_local_version():
    """Get version from local pyproject.toml."""
    stack_cli_root = get_stack_cli_root()
    if stack_cli_root is None:
        return "unknown"
    
    pyproject = stack_cli_root / 'pyproject.toml'
    if pyproject.exists():
        with open(pyproject) as f:
            for line in f:
                if line.startswith('version'):
                    return line.split('=')[1].strip().strip('"')
    return "unknown"

def get_pip_version():
    """Get installed pip package version."""
    try:
        import pkg_resources
        return pkg_resources.get_distribution('sscli').version
    except:
        return ""

def is_using_local():
    """Check if currently using local build (editable install vs PyPI)."""
    try:
        import foundry
        foundry_path = Path(foundry.__file__).resolve()
        # If foundry is in site-packages, it's a PyPI install
        # If it's not in site-packages, it's an editable install from source
        is_pypi_install = 'site-packages' in str(foundry_path)
        return not is_pypi_install
    except:
        return False

def run_build(clean=False):
    """Build distribution packages using setuptools."""
    stack_cli_root = get_stack_cli_root()
    
    console.print("[bold cyan]→[/bold cyan] [bold]Building packages...[/bold]")
    console.print("")
    
    # Clean if requested
    if clean:
        dist_dir = stack_cli_root / 'dist'
        build_dir = stack_cli_root / 'build'
        
        if dist_dir.exists():
            console.print("[yellow]Removing dist/[/yellow]")
            import shutil
            shutil.rmtree(dist_dir)
        
        if build_dir.exists():
            console.print("[yellow]Removing build/[/yellow]")
            import shutil
            shutil.rmtree(build_dir)
    
    # Create dist directory
    dist_dir = stack_cli_root / 'dist'
    dist_dir.mkdir(exist_ok=True)
    
    # Run wheel build
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "wheel", ".", "--no-deps", "-w", str(dist_dir)],
            cwd=str(stack_cli_root),
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            console.print(f"[red]Build failed:[/red]")
            console.print(result.stderr)
            return False
        
        # Build sdist using tarball
        result = subprocess.run(
            [sys.executable, "-m", "pip", "download", ".", "--no-deps", "--no-binary", ":all:", "-d", str(dist_dir)],
            cwd=str(stack_cli_root),
            capture_output=True,
            text=True
        )
        
        # Show build artifacts
        if dist_dir.exists():
            console.print("")
            artifacts = sorted(list(dist_dir.glob('*')))
            if artifacts:
                console.print("[bold]✓[/bold] Build complete")
                console.print("[bold cyan]→[/bold cyan] Build artifacts:")
                console.print("")
                for artifact in artifacts:
                    size_kb = artifact.stat().st_size / 1024
                    console.print(f"  [cyan]{artifact.name}[/cyan] ({size_kb:.0f}K)")
                console.print("")
                console.print("[bold cyan]Next steps:[/bold cyan]")
                console.print("  • Install locally:  [yellow]pip install --force-reinstall ./dist/sscli-*.whl[/yellow]")
                console.print("  • Or use swap:      [yellow]sscli swap[/yellow]")
                return True
    except Exception as e:
        console.print(f"[red]✗ Build failed: {e}[/red]")
        return False
    
    return False

def show_status(verbose=False):
    """Show development environment status."""
    stack_cli_root = get_stack_cli_root()
    venv_path = get_venv_path()
    local_version = get_local_version()
    pip_version = get_pip_version()
    using_local = is_using_local()
    
    # Header
    console.print("")
    header_panel = Panel(
        "[bold]sscli Development Status[/bold]",
        border_style="blue",
        padding=(0, 2)
    )
    console.print(header_panel)
    console.print("")
    
    # Create version table
    version_table = Table(show_header=False, show_lines=False, padding=(0, 2))
    version_table.add_column()
    version_table.add_column()
    
    local_build_info = f"[yellow]v{local_version}[/yellow] in [dim]{stack_cli_root}[/dim]" if stack_cli_root else f"[yellow]v{local_version}[/yellow] [dim](not found)[/dim]"
    version_table.add_row("  [bold]Local build:[/bold]", local_build_info)
    version_table.add_row("  [bold]Pip package:[/bold]", f"[yellow]{pip_version if pip_version else '(not installed)'}[/yellow]")
    
    console.print(version_table)
    console.print("")
    
    # Installation status
    current_status = "[yellow]LOCAL BUILD (development)[/yellow]" if using_local else f"[yellow]PIP PACKAGE (v{pip_version})[/yellow]" if pip_version else "[yellow]UNKNOWN[/yellow]"
    
    status_table = Table(show_header=False, show_lines=False, padding=(0, 2))
    status_table.add_column()
    status_table.add_column()
    status_table.add_row("  [bold]Currently using:[/bold]", current_status)
    
    console.print(status_table)
    console.print("")
    
    # Environment info
    env_table = Table(show_header=False, show_lines=False, padding=(0, 2))
    env_table.add_column()
    env_table.add_column()
    env_table.add_row("  [bold]Python:[/bold]", f"{sys.version.split()[0]}")
    env_table.add_row("  [bold]Venv:[/bold]", str(venv_path) if venv_path else "[yellow](not detected)[/yellow]")
    
    if verbose and venv_path:
        req_file = stack_cli_root / 'requirements.txt'
        if req_file.exists():
            with open(req_file) as f:
                deps = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                env_table.add_row("  [bold]Dependencies:[/bold]", f"{len(deps)} packages")
    
    console.print(env_table)
    console.print("")
    
    # Quick actions
    console.print("  [bold cyan]Quick Actions:[/bold cyan]")
    console.print("    • Show status verbose:  [yellow]sscli status --verbose[/yellow]")
    console.print("    • Build packages:       [yellow]sscli build[/yellow]")
    console.print("    • Switch installation:  [yellow]sscli swap[/yellow]")
    console.print("")
    
    return True

def run_swap(target=None):
    """Swap between local and pip versions."""
    stack_cli_root = get_stack_cli_root()
    venv_path = get_venv_path()
    pip_version = get_pip_version()
    using_local = is_using_local()
    
    if not venv_path:
        console.print("[red]✗ Virtual environment not found[/red]")
        return False
    
    venv_bin = venv_path / 'bin'
    
    # If no target specified, ask interactively
    if target is None:
        console.print("")
        console.print("[bold]Package Swap Utility[/bold]")
        console.print("")
        
        status = "[yellow]LOCAL BUILD[/yellow]" if using_local else f"[yellow]PIP PACKAGE (v{pip_version})[/yellow]" if pip_version else "[yellow]UNKNOWN[/yellow]"
        console.print(f"  Currently: {status}")
        console.print("")
        
        available = []
        if not using_local:
            available.append(("1", "Local build", "local", "v" + get_local_version()))
        if pip_version:
            available.append(("2", "Pip package", "pip", "v" + pip_version))
        if not available:
            available.append(("1", "Local build", "local", "v" + get_local_version()))
        
        console.print("  [bold]Available versions:[/bold]")
        for num, label, val, ver in available:
            console.print(f"    {num}) {label}: {ver}")
        console.print("")
        
        choice = questionary.select(
            "Switch to which installation?",
            choices=[f"{label} ({ver})" for _, label, _, ver in available] + ["Cancel"]
        ).ask()
        
        if choice and choice != "Cancel":
            target = available[[f"{label} ({ver})" for _, label, _, ver in available].index(choice)][2]
        else:
            return True  # User cancelled
    
    console.print("")
    console.print(f"[bold cyan]→[/bold cyan] [bold]Switching to {target}...[/bold]")
    
    try:
        if target == "local":
            # Install from local dist
            dist_dir = stack_cli_root / 'dist'
            wheels = list(dist_dir.glob('sscli-*.whl'))
            
            if not wheels:
                console.print("[red]✗ No wheel found in dist/. Run 'sscli build' first[/red]")
                return False
            
            wheel = wheels[0]
            console.print(f"  Installing from [cyan]{wheel.name}[/cyan]...")
            
            import os
            python_exe = venv_path / 'bin' / 'python'
            
            result = subprocess.run(
                [str(python_exe), '-m', 'pip', 'install', '--force-reinstall', str(wheel)],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                console.print("[red]✗ Installation failed[/red]")
                console.print(f"[dim]Error details: {result.stderr[:200]}[/dim]")
                return False
            
            console.print("[green]✓ Switched to local build[/green]")
            return True
        
        elif target == "pip":
            if not pip_version:
                console.print("[red]✗ sscli not available on PyPI. Build and install locally[/red]")
                return False
            
            console.print(f"  Installing sscli=={pip_version} from PyPI...")
            
            import os
            python_exe = venv_path / 'bin' / 'python'
            
            result = subprocess.run(
                [str(python_exe), '-m', 'pip', 'install', '--force-reinstall', f'sscli=={pip_version}'],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                console.print("[red]✗ Installation failed[/red]")
                console.print(f"[dim]Error details: {result.stderr[:200]}[/dim]")
                return False
            
            console.print("[green]✓ Switched to pip package[/green]")
            return True
    
    except Exception as e:
        console.print(f"[red]✗ Swap failed: {e}[/red]")
        return False
    
    return False

def run_bump_version(bump_type=None, auto_confirm=False):
    """Bump the version of sscli and all templates using VersionManager."""
    from foundry.ops.version_manager import VersionManager
    
    # If bump_type is not provided, ask interactively
    if bump_type is None:
        console.print("")
        console.print("[bold cyan]Version Bump Utility[/bold cyan]")
        console.print("")
        
        # Ask which version to bump
        bump_type = questionary.select(
            "Select version bump type:",
            choices=[
                questionary.Choice("Major (X.0.0)", value="major"),
                questionary.Choice("Minor (x.Y.0)", value="minor"),
                questionary.Choice("Patch (x.y.Z)", value="patch"),
                questionary.Choice("Cancel", value="cancel"),
            ],
        ).ask()
        
        if not bump_type or bump_type == "cancel":
            console.print("[yellow]Cancelled[/yellow]")
            return False
        
        # In interactive mode, ask for confirmation
        auto_confirm = False
    
    console.print("")
    try:
        manager = VersionManager()
        current = manager.get_current_version()
        
        # Show preview
        new_version = manager.increment_version(current, bump_type)
        console.print(f"[cyan]Current version:[/cyan] {current}")
        console.print(f"[cyan]New version:[/cyan]     {new_version}")
        console.print("")
        
        # Ask for confirmation if not auto-confirming
        if not auto_confirm:
            confirm = questionary.confirm(
                f"Bump {bump_type} version from {current} to {new_version}?",
                auto_continue=True,
                default=True
            ).ask()
            
            if not confirm:
                console.print("[yellow]Cancelled[/yellow]")
                return False
        
        # Perform the bump
        console.print("[cyan]→[/cyan] Bumping version across all repos...")
        result = manager.bump_version(bump_type)
        
        # Show results
        console.print(f"[green]✓[/green] Version bumped: {result['current']} → {result['new']}")
        console.print("")
        console.print("[cyan]Staged changes:[/cyan]")
        if result['staged_summary']:
            console.print(result['staged_summary'])
        
        console.print("")
        console.print("[bold cyan]Next steps:[/bold cyan]")
        console.print("1. Review the changes: git status")
        console.print(f"2. Commit: git commit -m 'chore: Bump version to {result['new']}'")
        console.print(f"3. Tag: git tag -a v{result['new']} -m 'Release v{result['new']}'")
        console.print(f"4. Push: git push origin main && git push origin v{result['new']}")
        
        return True
    
    except Exception as e:
        console.print(f"[red]✗ Bump failed: {e}[/red]")

        return False

def dev_tools_menu():
    """Interactive menu for development tools."""
    # Check if running in development context
    # Check environment variable first (takes precedence for CLI wrapper scripts)
    import os
    from pathlib import Path
    foundry_root = os.getenv("FOUNDRY_ROOT")
    if foundry_root:
        root_path = Path(foundry_root)
        markers = [".github", "docs", "tooling", "wiring"]
        is_dev = all((root_path / marker).exists() for marker in markers)
    else:
        is_dev = is_internal_dev()
    
    if not is_dev:
        console.print("[yellow]⚠️  Development tools are only available in development mode.[/yellow]")
        return
    
    console.clear()
    
    console.print("[bold cyan]Development Tools[/bold cyan]")
    console.print("[dim]Utilities for local development and testing[/dim]")
    console.print("")
    
    while True:
        choices = [
            questionary.Choice("📊 Show Development Status", value="status"),
            questionary.Choice("🔨 Build Distribution Package", value="build"),
            questionary.Choice("🔄 Switch Build Source (Local ↔ Pip)", value="swap"),
            questionary.Choice("📌 Bump Version (major/minor/patch)", value="bump"),
            questionary.Choice("← Back to Main Menu", value="back"),
        ]
        
        selection = questionary.select(
            "Select a development tool:",
            choices=choices,
        ).ask()
        
        if selection is None or selection == "back":
            return
        
        console.clear()
        console.print("")
        
        if selection == "status":
            show_verbose = questionary.confirm(
                "Show detailed dependency information?",
                default=False
            ).ask()
            show_status(verbose=show_verbose)
            
        elif selection == "build":
            clean = questionary.confirm(
                "Clean build artifacts before building?",
                default=False
            ).ask()
            if run_build(clean=clean):
                console.print("[green]✓[/green] Build successful")
            else:
                console.print("[red]✗[/red] Build failed")
        
        elif selection == "swap":
            # Show current status first
            show_status(verbose=False)
            console.print("")
            
            swap_choice = questionary.select(
                "Choose action:",
                choices=[
                    questionary.Choice("🔄 Toggle (interactive)", value="toggle"),
                    questionary.Choice("📦 Switch to Local Build", value="local"),
                    questionary.Choice("🐍 Switch to Pip Package", value="pip"),
                    questionary.Choice("❌ Cancel", value="cancel"),
                ],
            ).ask()
            
            if swap_choice and swap_choice != "cancel":
                if run_swap(target=None if swap_choice == "toggle" else swap_choice):
                    console.print("[green]✓[/green] Swap successful")
                else:
                    console.print("[red]✗[/red] Swap failed")
        
        elif selection == "bump":
            if run_bump_version():
                console.print("[green]✓[/green] Version bump complete")
            else:
                console.print("[red]✗[/red] Version bump failed")
        
        console.print("")
        input("[dim]Press Enter to continue...[/dim]")
        console.clear()
