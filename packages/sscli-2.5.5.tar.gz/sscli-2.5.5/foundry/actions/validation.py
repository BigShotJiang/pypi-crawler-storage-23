import subprocess
import sys

import questionary
from questionary import Choice
from foundry.constants import TEMPLATES_DIR, console, QUESTIONARY_STYLE
from rich.panel import Panel


def run_smoke_tests():
    while True:
        choice = questionary.select(
            "System Validation Menu:",
            choices=[
                Choice("🔨 Standard Smoke Tests (Build Verification)", value="smoke"),
                Choice("📦 Template Installation Tests (Setup Scripts)", value="install"),
                Choice("🚀 Runtime Services Tests (Live Containers)", value="runtime"),
                Choice("✅ Run All Validations", value="all"),
                "Back",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values
        if choice == "smoke":
            choice = "Standard Smoke Tests (Build Verification)"
        elif choice == "install":
            choice = "Template Installation Tests (Setup Scripts)"
        elif choice == "runtime":
            choice = "Runtime Services Tests (Live Containers)"
        elif choice == "all":
            choice = "Run All Validations"

        if choice == "Back":
            break

        if choice == "Standard Smoke Tests (Build Verification)":
            _run_script("scripts/verify_templates.py", "Build Verification")
            _pause()
        elif choice == "Template Installation Tests (Setup Scripts)":
            _run_script("scripts/verify_installation.py", "Installation Verification")
            _pause()
        elif choice == "Runtime Services Tests (Live Containers)":
            _run_script("scripts/verify_runtime.py", "Runtime Verification")
            _pause()
        elif choice == "Run All Validations":
            _clear_report()
            _run_script("scripts/verify_templates.py", "Build Verification")
            _run_script("scripts/verify_installation.py", "Installation Verification")
            _run_script("scripts/verify_runtime.py", "Runtime Verification")
            _pause()


def _clear_report():
    report_path = TEMPLATES_DIR / "verification_results.csv"
    if report_path.exists():
        try:
            report_path.unlink()
            console.print("[dim]Cleared previous verification report.[/dim]")
        except Exception as e:
            console.print(f"[red]Warning: Could not clear report file: {e}[/red]")


def _run_script(script_name: str, title: str):
    console.print(
        Panel(
            f"[bold yellow]Running {title}[/bold yellow]\n[dim]Executing {script_name}...[/dim]"
        )
    )

    script_path = TEMPLATES_DIR / script_name

    # Safety check: if script is not found locally, it might be that we are running 
    # as a PyPI package without access to the monorepo root.
    if not script_path.exists():
        console.print(f"[red]Error: {script_name} not found at {script_path}[/red]")
        console.print("[yellow]Note: Validation commands require the full monorepo to be locally available.[/yellow]")
        return

    try:
        # Determine the command based on script extension
        if script_name.endswith(".py"):
            cmd = [sys.executable, str(script_path)]
        elif script_name.endswith(".ps1"):
            cmd = ["powershell.exe", "-File", str(script_path)]
        else:
            # Fallback to shell execution for other scripts
            cmd = [str(script_path)]

        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
        )

        for line in process.stdout:
            console.print(f"  {line.strip()}")

        process.wait()

        if process.returncode == 0:
            console.print(f"\n[bold green]{title} Completed Successfully![/bold green]")
        else:
            console.print(f"\n[bold red]{title} Failed![/bold red]")

    except Exception as e:
        console.print(f"[bold red]Failed to execute {script_name}:[/bold red] {e}")


def _pause():
    input("\nPress Enter to continue...")
