import questionary
import shutil
from questionary import Choice
from foundry.auth import get_current_license_info
from foundry.constants import TIER_HIERARCHY, console, QUESTIONARY_STYLE
from foundry.utils import get_template_info, get_templates
from rich.panel import Panel

def get_interactive_config(template_name=None):
    """Gathers all configuration interactively from the user."""
    # Filter templates based on user tier for a cleaner experience
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)
    
    if not template_name:
        available_templates = []
        for tmpl in get_templates():
            info = get_template_info(tmpl.name)
            tmpl_tier = info.get("tier", "free").lower()
            if user_rank >= TIER_HIERARCHY.get(tmpl_tier, 0):
                available_templates.append(tmpl.name)

        if not available_templates:
            console.print("[yellow]No templates available for your current tier.[/yellow]")
            return None

        # Add Back button for better navigation
        choices = ["Back"] + [Choice(t, value=t, description=f"Deploy {t} template") for t in available_templates]

        template_name = questionary.select(
            "Select a template to deploy:", 
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()

        if template_name == "Back" or not template_name:
            return None

        console.print(Panel(f"[bold]Configuring {template_name}[/bold]", style="blue"))

    app_name = questionary.text(
        "Enter your Application Name:", default=f"my-{template_name}"
    ).ask()
    
    # PRO Feature Injection
    if user_rank >= TIER_HIERARCHY.get("pro"):
        with_commerce = questionary.confirm(
            "Would you like to include Commerce modules (Shopify/Stripe)?", 
            default=False
        ).ask()
        
        with_merchant_dashboard = False
        if with_commerce and template_name == "react-client":
            with_merchant_dashboard = questionary.confirm(
                "Include Merchant Dashboard (order management UI)?",
                default=False
            ).ask()
        
        with_tunnel = questionary.confirm(
            "Enable local tunneling (ngrok)?", 
            default=False
        ).ask()
        with_landing = questionary.confirm(
            "Include a static landing page (Astro)?",
            default=False
        ).ask()
        with_admin = questionary.confirm(
            "Inject NiceGUI-based admin panel?",
            default=False
        ).ask()
        with_sqlite = questionary.confirm(
            "Setup local SQLite persistence with Alembic?",
            default=False
        ).ask()
        with_ingestor = questionary.confirm(
            "Inject Data Ingestor adapter pattern?",
            default=False
        ).ask()
        with_auth = questionary.confirm(
            "Inject authentication features?",
            default=False
        ).ask()
    else:
        with_commerce = with_tunnel = with_landing = with_admin = with_sqlite = with_ingestor = with_auth = with_merchant_dashboard = False

    use_linters = questionary.confirm(
        "Enable default linters (Ruff/Rubocop/ESLint)?", default=True
    ).ask()
    
    secrets_strategy = questionary.select(
        "Select Secrets Management Strategy:",
        choices=[
            Choice("Dotenv (Standard .env files)", value="dotenv", description="Simple .env files in project root"),
            Choice("Doppler (Managed cloud secrets)", value="doppler", description="Secrets stored in Doppler's cloud platform"),
            Choice("Environment Only (PaaS/CI friendly)", value="env", description="Load secrets from environment variables only"),
        ],
        default="Dotenv (Standard .env files)",
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    # Map choice values back
    if secrets_strategy == "dotenv":
        secrets_strategy = "Dotenv (Standard .env files)"
    elif secrets_strategy == "doppler":
        secrets_strategy = "Doppler (Managed cloud secrets)"
    elif secrets_strategy == "env":
        secrets_strategy = "Environment Only (PaaS/CI friendly)"

    # GitHub Repository Configuration
    gh_available = shutil.which("gh") is not None
    create_github_repo = False
    github_config = None

    if gh_available:
        create_github_repo = questionary.confirm(
            "🚀 Would you like to create a GitHub repository for this project?",
            default=False
        ).ask()

        if create_github_repo:
            repo_name = questionary.text(
                "    Repository Name:", default=app_name
            ).ask()
            repo_description = questionary.text(
                "    Repository Description:", 
                default=f"✨ {template_name} project created with Seed & Source"
            ).ask()
            repo_visibility = questionary.select(
                "    Repository Visibility:",
                choices=[
                    Choice("Private", value="private"),
                    Choice("Public", value="public")
                ],
                default="private",
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()
            github_config = {
                "name": repo_name,
                "description": repo_description,
                "visibility": repo_visibility
            }
    
    return {
        "template_name": template_name,
        "app_name": app_name,
        "with_commerce": with_commerce,
        "with_tunnel": with_tunnel,
        "with_landing": with_landing,
        "with_admin": with_admin,
        "with_sqlite": with_sqlite,
        "with_ingestor": with_ingestor,
        "with_auth": with_auth,
        "with_merchant_dashboard": with_merchant_dashboard,
        "use_linters": use_linters,
        "secrets_strategy": secrets_strategy,
        "github_config": github_config
    }
