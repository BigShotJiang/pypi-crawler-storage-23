import sys
import json
from pathlib import Path
from typing import Optional
from foundry.constants import console

def apply_landing_blueprint(path: Path, content_path: Optional[str] = None, theme: Optional[str] = None):
    blueprint_file = path / "blueprint.json"
    if not blueprint_file.exists():
        return

    try:
        blueprint_data = json.loads(blueprint_file.read_text(encoding="utf-8"))
        
        # Override with custom content if provided
        if content_path:
            custom_content_file = Path(content_path)
            if custom_content_file.exists():
                custom_data = json.loads(custom_content_file.read_text(encoding="utf-8"))
                # Basic merge - custom data takes precedence
                blueprint_data.update(custom_data)
                console.print(f"   - Applied custom content blueprint from {content_path}")
            else:
                console.print(f"   [yellow]⚠️  Custom content file {content_path} not found.[/yellow]")

        # Override theme if provided
        if theme:
            blueprint_data["theme"] = theme
            console.print(f"   - Applied theme: {theme}")

        blueprint_file.write_text(json.dumps(blueprint_data, indent=2), encoding="utf-8")
        
    except Exception as e:
        console.print(f"   [yellow]⚠️  Failed to apply landing blueprint: {e}[/yellow]")

def inject_metadata(path: Path, template: str, app_name: str):
    console.print(f"   - Injecting name '{app_name}' into configuration...")
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
        path / "astro.config.mjs",
    ]
    for f in files_to_touch:
        if f.exists():
            content = f.read_text(encoding="utf-8")
            new_content = content.replace(f"{template}", app_name)
            new_content = new_content.replace("StackApp", app_name.capitalize())
            f.write_text(new_content, encoding="utf-8")

def validate_and_fix_pyproject(path: Path):
    pyproject = path / "pyproject.toml"
    if not pyproject.exists(): return
    try:
        content = pyproject.read_text(encoding="utf-8")
        fixed_lines = []
        in_dependencies_section = False
        for line in content.splitlines():
            if line.strip().startswith("[tool.poetry"):
                in_dependencies_section = "dependencies" in line
            elif line.strip().startswith("["):
                in_dependencies_section = False
            if in_dependencies_section and " = " in line and not line.strip().startswith("#"):
                key, value = line.split(" = ", 1)
                key, value = key.strip(), value.strip()
                if (value and not value.startswith(('"', "'", "{", "["))):
                    if value[0].isdigit() or value[0] in "^~<>=!":
                        value = f'"{value}"'
                        line = f"{key} = {value}"
            fixed_lines.append(line)
        fixed_content = "\n".join(fixed_lines) + "\n"
        try:
            if sys.version_info >= (3, 11):
                import tomllib
                tomllib.loads(fixed_content)
            elif fixed_content.count("[") != fixed_content.count("]"):
                raise ValueError("Mismatched brackets")
        except Exception as parse_error:
            console.print(f"   [yellow]⚠️  TOML validation failed: {parse_error}[/yellow]")
            return
        pyproject.write_text(fixed_content, encoding="utf-8")
        console.print("   - Validated and fixed pyproject.toml (ensured quoted versions)")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Could not validate pyproject.toml: {e}[/yellow]")

def disable_linters(path: Path, template: str):
    if (path / "pyproject.toml").exists():
        pyproject = path / "pyproject.toml"
        content = pyproject.read_text(encoding="utf-8")
        filtered_lines, skip_tool_section = [], False
        for line in content.splitlines():
            if any(line.strip().startswith(x) for x in ["[tool.ruff", "[tool.mypy"]):
                skip_tool_section = True
                continue
            elif line.strip().startswith("[") and skip_tool_section:
                skip_tool_section = False
            if skip_tool_section or line.startswith(("ruff =", "mypy =")):
                continue
            filtered_lines.append(line)
        pyproject.write_text("\n".join(filtered_lines) + "\n", encoding="utf-8")
        console.print("   - Removed Ruff/MyPy dependencies and tool configuration from pyproject.toml")
    if (path / "Gemfile").exists():
        gemfile = path / "Gemfile"
        content = gemfile.read_text(encoding="utf-8")
        new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace("gem 'rubocop-rails'", "# gem 'rubocop-rails'")
        gemfile.write_text(new_content, encoding="utf-8")
        console.print("   - Commented out Rubocop in Gemfile")

def regenerate_poetry_lock(path: Path):
    import subprocess
    if not (path / "pyproject.toml").exists() or not (path / "poetry.lock").exists(): return
    console.print("   - Regenerating poetry.lock...")
    try:
        result = subprocess.run(["poetry", "lock", "--no-update"], cwd=str(path), capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            console.print("   - poetry.lock regenerated successfully")
        else:
            console.print(f"   [yellow]⚠️  Could not regenerate poetry.lock: {result.stderr.strip()}[/yellow]")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Unexpected error regenerating poetry.lock: {str(e)}[/yellow]")
