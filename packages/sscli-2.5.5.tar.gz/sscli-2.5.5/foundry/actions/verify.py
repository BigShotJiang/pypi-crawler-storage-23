#!/usr/bin/env python3
"""
Native Python Template Verification System Wrapper.
Modular implementation moved to foundry.actions.verification.
"""

import sys
from typing import Optional
from pathlib import Path

# Relative imports to work within the foundry package
from .verification.verifier import TemplateVerifier
from .verification.reports import generate_reports, print_summary


def run_verification(include_docker: bool = True, output_reports: bool = True):
    """Entry point for template verification."""
    # Find root directory (foundry-meta)
    root_dir = Path(__file__).resolve().parent.parent.parent.parent.parent
    
    verifier = TemplateVerifier(root_dir=root_dir)
    results = verifier.verify_all(include_docker=include_docker)

    if output_reports:
        generate_reports(results, root_dir)

    exit_code = print_summary(results)
    sys.exit(exit_code)
