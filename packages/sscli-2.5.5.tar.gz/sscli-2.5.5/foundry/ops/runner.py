import platform
import sys
import subprocess
from pathlib import Path
from rich.panel import Panel
from foundry.constants import console


def run_verification_script(root_dir: Path, script_base_name: str, title: str):
    """Wrapper to run verification scripts across platforms."""
    is_windows = platform.system() == "Windows"
    ext = ".ps1" if is_windows else ".py"
    subdir = "scripts/win" if is_windows else "scripts"
    full_name = f"{script_base_name}{ext}"

    console.print(Panel(f"[bold yellow]Running {title}[/bold yellow]"))
    script_path = root_dir / subdir / full_name

    if not script_path.exists():
        console.print(f"[red]Error: {full_name} not found![/red]")
        return

    try:
        cmd = ["powershell.exe", "-File", str(script_path)] if is_windows else [sys.executable, str(script_path)]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

        for line in process.stdout:
            console.print(f"  {line.strip()}")

        process.wait()
        if process.returncode == 0:
            console.print(f"\n[bold green]{title} Completed Successfully![/bold green]")
        else:
            console.print(f"\n[bold red]{title} Failed![/bold red]")

    except Exception as e:
        console.print(f"[bold red]Failed to execute {full_name}:[/bold red] {e}")
