"""
Main animation orchestration engine.
Combines clock, animations, input, and rendering.
"""

import select
import sys
import termios
import tty
from typing import Optional

from rich.console import Console
from rich.live import Live
from rich.text import Text

from ..animation import Animation
from ..core import FRAME_HEIGHT, FRAME_WIDTH
from .clock import AnimationClock
from .frame_buffer import FrameBuffer
from .state import AnimationState


class InteractiveAnimationEngine:
    """
    Orchestrates animations with input handling and layered rendering.
    """

    def __init__(self, fps: int = 60, console: Optional[Console] = None):
        self.console = console or Console()
        self.clock = AnimationClock(fps=fps)
        self.state = AnimationState()
        self.buffer = FrameBuffer(width=FRAME_WIDTH, height=FRAME_HEIGHT)
        self.is_running = False

    def play(self, animation: Animation) -> Optional[str]:
        """
        Main execution loop. Plays an animation until completion or user exit.
        """
        self.is_running = True
        self.clock.reset()

        # Initial render
        self.buffer.clear()
        animation.render(self.buffer, self.state)

        # Save terminal settings for non-blocking input
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        try:
            tty.setcbreak(fd)
            with Live(
                self._get_renderable(),
                console=self.console,
                auto_refresh=False,
                screen=True,
            ) as live:
                while self.is_running and not animation.is_complete:
                    # 1. Timing
                    dt = self.clock.tick()

                    # 2. Update State & Animation
                    self.state = self.state.with_updates(
                        frame=self.clock.frame_count,
                        elapsed_time=self.clock.elapsed_time,
                    )

                    # 3. Handle Input (Non-blocking)
                    if select.select([sys.stdin], [], [], 0)[0]:
                        key = sys.stdin.read(1)
                        if key == "\x1b":  # Escape sequence
                            # Read more for arrows
                            next_chars = sys.stdin.read(2)
                            if next_chars == "[A":
                                key = "up"
                            elif next_chars == "[B":
                                key = "down"
                        elif key == "\n" or key == "\r":
                            key = "enter"
                        elif key == "q":
                            self.is_running = False
                            break

                        # Process key in animation and update state if needed
                        action = animation.handle_input(key)
                        if action == "SELECT":
                            from ...constants import ANIMATED_MENU_ITEMS

                            return ANIMATED_MENU_ITEMS[self.state.menu_selected_index]
                        elif action:
                            return action

                        # Simple internal state management for menu navigation
                        if key == "up":
                            self.state = self.state.with_updates(
                                menu_selected_index=max(
                                    0, self.state.menu_selected_index - 1
                                )
                            )
                        elif key == "down":
                            from ...constants import ANIMATED_MENU_ITEMS

                            self.state = self.state.with_updates(
                                menu_selected_index=min(
                                    len(ANIMATED_MENU_ITEMS) - 1,
                                    self.state.menu_selected_index + 1,
                                )
                            )

                    self.state = animation.update(dt, self.state)

                    # 4. Render
                    self.buffer.clear()
                    animation.render(self.buffer, self.state)

                    # 5. Composite & Update Display
                    live.update(self._get_renderable())
                    live.refresh()

                    # Check for final action
                    if animation.final_action:
                        return animation.final_action
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        return self.state.final_action

    def _get_renderable(self) -> Text:
        """Composite buffer and return as single Rich Text object."""
        lines = self.buffer.render()
        result = Text("\n").join(lines)
        return result
