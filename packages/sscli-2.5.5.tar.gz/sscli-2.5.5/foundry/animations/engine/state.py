"""
Animation state models for Foundry CLI using Pydantic.
Enables state snapshots for debugging and testing.
"""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ScenePhase(str, Enum):
    """Animation lifecycle phases."""

    ENTRANCE = "entrance"
    LOGO_SLIDE = "logo_slide"
    LOGO_DISSOLVE = "logo_dissolve"
    MENU = "menu"
    RAIN = "rain"
    TRANQUILITY = "tranquility"


class AnimationState(BaseModel):
    """
    Complete animation state snapshot.

    This is the single source of truth for animation frame data.
    Immutable pattern is preferred for thread-safety and debugging.
    """

    # Timing
    frame: int = Field(0, description="Global frame counter")
    elapsed_time: float = Field(0.0, description="Elapsed time in seconds")
    scene_phase: ScenePhase = Field(ScenePhase.ENTRANCE, description="Current scene")

    # Environment
    sun_x: float = Field(45.0, description="Sun horizontal position (pixels)")
    sun_y: float = Field(18.0, description="Sun vertical position (pixels)")
    sun_progress: float = Field(0.0, description="Sun animation progress (0.0-1.0)")

    # Nature
    tree_growth: float = Field(0.0, description="Tree growth progress (0.0-1.0)")
    grass_wind: float = Field(0.6, description="Grass wind intensity (0.0-3.0)")

    # Particles
    flare_count: int = Field(0, description="Active flare particles")
    wind_particle_count: int = Field(0, description="Active wind particles")

    # UI
    menu_opacity: float = Field(0.0, description="Menu fade-in progress (0.0-1.0)")
    menu_selected_index: int = Field(0, description="Selected menu item index")

    # User action (None until interaction)
    final_action: Optional[str] = Field(None, description="User selected action")

    model_config = {"frozen": True, "use_enum_values": True}

    def with_updates(self, **kwargs) -> "AnimationState":
        """Create new state with selective updates (immutable pattern)."""
        return self.model_copy(update=kwargs)
