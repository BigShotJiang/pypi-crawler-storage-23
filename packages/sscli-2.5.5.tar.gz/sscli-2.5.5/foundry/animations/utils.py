from typing import List, Union
from rich.cells import cell_len
from rich.text import Text
from .core import FRAME_WIDTH


def center_content(lines: List[Union[str, Text]], width: int = FRAME_WIDTH) -> List[Text]:
    """Horizontally center content block."""
    return align_content(lines, width=width, mode="center")


def right_align_content(lines: List[Union[str, Text]], width: int = FRAME_WIDTH, margin: int = 4) -> List[Text]:
    """Right-align content block with margin."""
    return align_content(lines, width=width, mode="right", margin=margin)


def align_content(lines: List[Union[str, Text]], width: int = FRAME_WIDTH, mode: str = "center", margin: int = 4) -> List[Text]:
    """Align content block (center, left, or right). Support for Rich markup strings."""
    if not lines: return []
    text_lines = []
    for line in lines:
        if isinstance(line, str):
            text_lines.append(Text.from_markup(line) if "[" in line and "]" in line else Text(line))
        else:
            text_lines.append(line.copy())

    max_w = max(cell_len(t.plain) for t in text_lines if t.plain.strip()) if text_lines else 0
    if max_w >= width: return text_lines

    if mode == "center": offset = (width - max_w) // 2
    elif mode == "right": offset = width - max_w - margin
    else: offset = margin
    
    offset = max(0, offset)
    aligned = []
    for t in text_lines:
        new_text = Text(" " * offset)
        new_text.append(t)
        aligned.append(new_text)
    return aligned
