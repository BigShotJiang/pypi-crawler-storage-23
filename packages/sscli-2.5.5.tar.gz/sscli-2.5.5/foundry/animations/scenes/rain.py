"""
Rain of characters animation scene.
"""

import random

from ..animation import Animation, AnimationConfig
from ..assets import SMALL_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase

RAIN_CHARS = ".,'| "


class RainAnimation(Animation):
    """
    Rain animation: Characters fall from the sky while a small logo is displayed.
    """

    def __init__(self, duration: float = 4.0):
        super().__init__(AnimationConfig(duration=duration))
        self.particles = []

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        # Add new particles
        if len(self.particles) < 50:
            self.particles.append(
                {
                    "x": random.randint(0, FRAME_WIDTH - 1),
                    "y": random.uniform(-10, 0),
                    "speed": random.uniform(5, 15),
                    "char": random.choice(RAIN_CHARS),
                }
            )

        # Update existing
        active = []
        for p in self.particles:
            p["y"] += p["speed"] * dt
            if p["y"] < FRAME_HEIGHT:
                active.append(p)
        self.particles = active

        return state.with_updates(scene_phase=ScenePhase.RAIN)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)
        # Tree grows slowly during rain
        render_base_background(
            bg_canvas,
            tree_growth=0.3 + (self.get_progress() * 0.4),
            grass_wind=state.grass_wind,
        )
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Particle layer
        part_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        for p in self.particles:
            if 0 <= int(p["y"]) < FRAME_HEIGHT:
                part_canvas.draw_text(
                    p["char"], int(p["x"]), int(p["y"]), style="blue dim"
                )
        frame_buffer.add_layer("rain", part_canvas.buffer)

        # 3. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        logo_y = FRAME_HEIGHT // 3
        for i, line in enumerate(SMALL_LOGO):
            logo_x = (FRAME_WIDTH - len(line)) // 2
            logo_canvas.draw_text(line, logo_x, logo_y + i, style="bold blue")
        frame_buffer.add_layer("logo", logo_canvas.buffer)
