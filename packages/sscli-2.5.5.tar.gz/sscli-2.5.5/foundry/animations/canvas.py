from typing import List, Optional, Union
from rich.text import Text

# Import constants from core to avoid duplication
from .core import FRAME_WIDTH, FRAME_HEIGHT


class Canvas:
    """A virtual buffer for layered ASCII rendering."""

    def __init__(self, width: int = FRAME_WIDTH, height: int = FRAME_HEIGHT):
        self.width, self.height = width, height
        self.buffer: List[Text] = [Text(" " * width) for _ in range(height)]

    def clear(self):
        """Reset the canvas buffer."""
        self.buffer = [Text(" " * self.width) for _ in range(self.height)]

    def draw_text(self, text: Union[str, Text], x: int, y: int, style: Optional[str] = None):
        """Draw text or a Rich Text object at specific coordinates."""
        if not (0 <= y < self.height): return
        content = Text(text) if isinstance(text, str) else text.copy()
        if style: content.stylize(style)
        if x < 0:
            content, x = content[abs(x) :], 0
        if len(content.plain) > self.width - x:
            content = content[: self.width - x]
        target_line = self.buffer[y]
        prefix = target_line[0:x]
        suffix_start = x + len(content.plain)
        suffix = target_line[suffix_start:] if suffix_start < self.width else Text("")
        self.buffer[y] = Text.assemble(prefix, content, suffix)

    def draw_text_transparent(self, text: Union[str, Text], x: int, y: int, style: Optional[str] = None):
        """Draw text skipping spaces (transparency). Optimized to only rebuild affected range."""
        if not (0 <= y < self.height): return
        content = Text(text) if isinstance(text, str) else text
        plain, c_len = content.plain, len(content.plain)
        if x + c_len <= 0 or x >= self.width: return
        target_line = self.buffer[y]
        start_x, end_x = max(0, x), min(self.width, x + c_len)
        prefix, suffix = target_line[0:start_x], target_line[end_x:]
        middle = Text()
        for i in range(start_x, end_x):
            char = plain[i - x]
            if char != " ":
                char_text = content[i - x : i - x + 1]
                if style: char_text.stylize(style)
                middle.append(char_text)
            else:
                middle.append(target_line[i : i + 1])
        self.buffer[y] = Text.assemble(prefix, middle, suffix)

    def draw_sprite(self, sprite: List[Union[str, Text]], x: int, y: int, style: Optional[str] = None, transparent: bool = False):
        """Draw a multi-line ASCII sprite at specific coordinates."""
        for i, line in enumerate(sprite):
            if transparent:
                self.draw_text_transparent(line, x, y + i, style=style)
            else:
                self.draw_text(line, x, y + i, style=style)

    def render(self) -> List[Text]:
        """Return the current buffer contents."""
        return self.buffer
