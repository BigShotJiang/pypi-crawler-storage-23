"""
Base animation abstraction enabling extensible animation system.
"""

from .base import Animation, AnimationConfig
from .composites import AnimationGroup, AnimationSequence

__all__ = ["Animation", "AnimationConfig", "AnimationGroup", "AnimationSequence"]
