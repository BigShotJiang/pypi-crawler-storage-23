"""
Delta Store: Versioned Codemod Catalog Manager

Manages a centralized, versioned catalog of codemods (transformations) that can
be applied to upgrade projects between template versions. Provides methods to
load, retrieve, and validate codemods for safe project upgrades.

Catalog Structure:
  foundry/codemods/catalog/
  ├── python-saas/
  │   ├── 2.2.0-2.3.0/
  │   │   ├── 010-001-PY-pydantic-v1-v2.yaml
  │   │   ├── manifest.json
  │   └── 2.3.0-2.4.0/
  │       └── ...
  ├── static-landing/
  │   └── ...
  └── rails-api/
      └── ...
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
import json
import yaml
from packaging import version


@dataclass
class CodemodMetadata:
    """Metadata for a single codemod transformation."""
    
    id: str
    """Unique identifier (e.g., '010-001-PY-pydantic-v1-to-v2')"""
    
    name: str
    """Human-readable name of the codemod"""
    
    description: str
    """What this codemod does and why it's necessary"""
    
    from_version: str
    """Version this codemod starts applying from (e.g., '2.2.0')"""
    
    to_version: str
    """Version this codemod applies until (e.g., '2.3.0')"""
    
    affected_templates: List[str]
    """Which template(s) this applies to (e.g., ['python-saas'])"""
    
    risk_level: str
    """Risk severity: 'low', 'medium', 'high', 'critical'"""
    
    requires_manual_review: bool = False
    """Flag indicating if manual review is required before applying"""
    
    rollback_safe: bool = True
    """Whether this codemod can be safely rolled back"""
    
    implementation_type: str = "yaml"
    """Type of implementation: 'yaml', 'astgrep', 'synvert', 'python'"""
    
    file_patterns: List[str] = field(default_factory=list)
    """Target file patterns (e.g., ['*.py', 'pyproject.toml'])"""
    
    tags: List[str] = field(default_factory=list)
    """Tags for categorization (e.g., ['dependency-upgrade', 'breaking-change'])"""
    
    dependencies: List[str] = field(default_factory=list)
    """IDs of other codemods that must be applied first"""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metadata to dictionary for serialization."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CodemodMetadata":
        """Create metadata from dictionary."""
        return cls(**data)


@dataclass
class CodemodDefinition:
    """Complete codemod definition including metadata and implementation."""
    
    metadata: CodemodMetadata
    implementation: Dict[str, Any]
    """Implementation details (rules, patterns, script, etc.)"""
    
    test_instructions: Optional[str] = None
    """How to test this codemod after application"""
    
    rollback_instructions: Optional[str] = None
    """How to rollback if something goes wrong"""


class DeltaStore:
    """
    Centralized manager for versioned codemod catalog.
    
    Loads and manages a catalog of codemods organized by template and version
    ranges. Provides methods to retrieve applicable codemods for upgrading
    projects between versions.
    """
    
    def __init__(self, catalog_root: Optional[Path] = None):
        """
        Initialize the Delta Store.
        
        Args:
            catalog_root: Path to catalog root directory.
                         Defaults to foundry/codemods/catalog
        """
        if catalog_root is None:
            catalog_root = Path(__file__).parent / "catalog"
        
        self.catalog_root = catalog_root
        self._catalog_cache: Dict[str, CodemodDefinition] = {}
        self._manifest_cache: Dict[str, Dict[str, Any]] = {}
        self._loaded = False
    
    def load_catalog(self) -> Dict[str, CodemodDefinition]:
        """
        Load all available codemods from the catalog directory.
        
        Recursively discovers all YAML codemod files and manifest.json files,
        parses them, and builds the in-memory catalog cache.
        
        Returns:
            Dictionary of CodemodDefinition objects keyed by codemod ID
            
        Raises:
            FileNotFoundError: If catalog root doesn't exist
            ValueError: If codemod files are malformed
        """
        if self._loaded:
            return self._catalog_cache
        
        if not self.catalog_root.exists():
            raise FileNotFoundError(f"Catalog root not found: {self.catalog_root}")
        
        # Discover all YAML codemod files
        yaml_files = list(self.catalog_root.glob("**/[0-9]*-[0-9]*-*.yaml"))
        
        for yaml_file in yaml_files:
            try:
                definition = self._load_codemod_file(yaml_file)
                self._catalog_cache[definition.metadata.id] = definition
            except (yaml.YAMLError, ValueError, KeyError) as e:
                raise ValueError(f"Failed to load codemod {yaml_file}: {e}")
        
        self._loaded = True
        return self._catalog_cache
    
    def _load_codemod_file(self, yaml_file: Path) -> CodemodDefinition:
        """
        Load a single codemod definition from a YAML file.
        
        Args:
            yaml_file: Path to YAML codemod file
            
        Returns:
            CodemodDefinition object
            
        Raises:
            ValueError: If required metadata is missing
        """
        with open(yaml_file, 'r') as f:
            data = yaml.safe_load(f)
        
        # Validate required metadata fields
        required_fields = {
            'id', 'name', 'description', 'from_version', 'to_version',
            'affected_templates', 'risk_level'
        }
        metadata_data = data.get('metadata', {})
        
        missing = required_fields - set(metadata_data.keys())
        if missing:
            raise ValueError(f"Missing required metadata fields: {missing}")
        
        # Set defaults for optional fields
        metadata_data.setdefault('requires_manual_review', False)
        metadata_data.setdefault('rollback_safe', True)
        metadata_data.setdefault('implementation_type', 'yaml')
        metadata_data.setdefault('file_patterns', [])
        metadata_data.setdefault('tags', [])
        metadata_data.setdefault('dependencies', [])
        
        metadata = CodemodMetadata.from_dict(metadata_data)
        
        return CodemodDefinition(
            metadata=metadata,
            implementation=data.get('implementation', {}),
            test_instructions=data.get('test_instructions'),
            rollback_instructions=data.get('rollback_instructions')
        )
    
    def get_codemods_for_template(
        self,
        template: str,
        from_version: str,
        to_version: str
    ) -> List[CodemodDefinition]:
        """
        Get all applicable codemods for upgrading a template.
        
        Returns codemods that:
        - Apply to the specified template
        - Have from_version >= the provided from_version
        - Have to_version <= the provided to_version
        - Are in dependency order
        
        Args:
            template: Template name (e.g., 'python-saas', 'react-client')
            from_version: Current version (e.g., '2.2.0')
            to_version: Target version (e.g., '2.3.0')
            
        Returns:
            List of applicable CodemodDefinition objects in dependency order
            
        Raises:
            ValueError: If version strings are invalid or upgrade path is invalid
        """
        self.load_catalog()
        
        # Validate versions
        try:
            from_ver = version.parse(from_version)
            to_ver = version.parse(to_version)
        except version.InvalidVersion as e:
            raise ValueError(f"Invalid version string: {e}")
        
        if to_ver <= from_ver:
            raise ValueError(
                f"Target version {to_version} must be greater than "
                f"current version {from_version}"
            )
        
        # Filter applicable codemods
        applicable = []
        for codemod_def in self._catalog_cache.values():
            metadata = codemod_def.metadata
            
            # Check template
            if template not in metadata.affected_templates:
                continue
            
            # Check version range
            codemod_from = version.parse(metadata.from_version)
            codemod_to = version.parse(metadata.to_version)
            
            # Codemod applies if its range overlaps with upgrade range
            if codemod_from <= to_ver and codemod_to > from_ver:
                applicable.append(codemod_def)
        
        # Sort by version and resolve dependencies
        applicable.sort(
            key=lambda x: version.parse(x.metadata.from_version)
        )
        
        return self._resolve_dependencies(applicable)
    
    def _resolve_dependencies(
        self,
        codemods: List[CodemodDefinition]
    ) -> List[CodemodDefinition]:
        """
        Sort codemods into dependency order.
        
        Args:
            codemods: List of CodemodDefinition objects
            
        Returns:
            List sorted so dependencies appear before dependents
            
        Raises:
            ValueError: If circular dependencies are detected
        """
        # Build dependency graph
        codemod_by_id = {cm.metadata.id: cm for cm in codemods}
        in_degree = {cm.metadata.id: 0 for cm in codemods}
        graph: Dict[str, List[str]] = {cm.metadata.id: [] for cm in codemods}
        
        for codemod in codemods:
            for dep_id in codemod.metadata.dependencies:
                if dep_id in graph:
                    graph[dep_id].append(codemod.metadata.id)
                    in_degree[codemod.metadata.id] += 1
        
        # Topological sort (Kahn's algorithm)
        queue = [id for id, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            current_id = queue.pop(0)
            result.append(codemod_by_id[current_id])
            
            for dep_id in graph.get(current_id, []):
                in_degree[dep_id] -= 1
                if in_degree[dep_id] == 0:
                    queue.append(dep_id)
        
        if len(result) != len(codemods):
            raise ValueError("Circular dependency detected in codemods")
        
        return result
    
    def get_codemod(self, codemod_id: str) -> Optional[CodemodDefinition]:
        """
        Get a specific codemod by ID.
        
        Args:
            codemod_id: Unique codemod identifier
            
        Returns:
            CodemodDefinition if found, None otherwise
        """
        self.load_catalog()
        return self._catalog_cache.get(codemod_id)
    
    def list_available_codemods(
        self,
        template: Optional[str] = None,
        risk_level: Optional[str] = None
    ) -> List[CodemodMetadata]:
        """
        List all available codemods, optionally filtered.
        
        Args:
            template: Filter by affected template (optional)
            risk_level: Filter by risk level (optional)
            
        Returns:
            List of CodemodMetadata objects
        """
        self.load_catalog()
        
        results = []
        for codemod_def in self._catalog_cache.values():
            metadata = codemod_def.metadata
            
            if template and template not in metadata.affected_templates:
                continue
            
            if risk_level and metadata.risk_level != risk_level:
                continue
            
            results.append(metadata)
        
        # Sort by id for consistent ordering
        results.sort(key=lambda m: m.id)
        return results
    
    def validate_upgrade_path(
        self,
        template: str,
        from_version: str,
        to_version: str
    ) -> Dict[str, Any]:
        """
        Validate that an upgrade path is supported and safe.
        
        Checks:
        - Version strings are valid
        - Target > current
        - Codemods exist for this template and version range
        - No circular dependencies
        - No critical codemods without manual review options
        
        Args:
            template: Template name
            from_version: Current version
            to_version: Target version
            
        Returns:
            Dictionary with validation results:
            {
                'valid': bool,
                'codemods': List[str],  # IDs of applicable codemods
                'warnings': List[str],  # Non-blocking issues
                'errors': List[str],    # Blocking issues
                'requires_review': bool,
                'risk_level': str       # 'low', 'medium', 'high', 'critical'
            }
        """
        result: Dict[str, Any] = {
            'valid': True,
            'codemods': [],
            'warnings': [],
            'errors': [],
            'requires_review': False,
            'risk_level': 'low'
        }
        
        # Validate versions
        try:
            from_ver = version.parse(from_version)
            to_ver = version.parse(to_version)
        except version.InvalidVersion as e:
            result['valid'] = False
            result['errors'].append(f"Invalid version: {e}")
            return result
        
        if to_ver <= from_ver:
            result['valid'] = False
            result['errors'].append(
                f"Target version must be greater than current version"
            )
            return result
        
        # Get applicable codemods
        try:
            codemods = self.get_codemods_for_template(
                template, from_version, to_version
            )
        except ValueError as e:
            result['valid'] = False
            result['errors'].append(str(e))
            return result
        
        if not codemods:
            result['warnings'].append(
                f"No codemods found for {template} "
                f"from {from_version} to {to_version}"
            )
        
        result['codemods'] = [cm.metadata.id for cm in codemods]
        
        # Check for manual review requirements
        max_risk = 'low'
        risk_levels = ['low', 'medium', 'high', 'critical']
        
        for codemod in codemods:
            metadata = codemod.metadata
            
            if metadata.requires_manual_review:
                result['requires_review'] = True
            
            # Track max risk level
            codemod_risk_idx = risk_levels.index(metadata.risk_level)
            if codemod_risk_idx > risk_levels.index(max_risk):
                max_risk = metadata.risk_level
            
            # Check if rollback-safe
            if not metadata.rollback_safe:
                result['warnings'].append(
                    f"Codemod {metadata.id} is not rollback-safe"
                )
        
        result['risk_level'] = max_risk
        
        return result
    
    def get_catalogs_for_template(self, template: str) -> List[str]:
        """
        Get all version ranges available for a template.
        
        Args:
            template: Template name
            
        Returns:
            List of version range strings (e.g., ['2.2.0-2.3.0', '2.3.0-2.4.0'])
        """
        if not self.catalog_root.exists():
            return []
        
        template_root = self.catalog_root / template
        if not template_root.exists():
            return []
        
        ranges = []
        for version_dir in template_root.iterdir():
            if version_dir.is_dir() and '-' in version_dir.name:
                ranges.append(version_dir.name)
        
        return sorted(ranges)
    
    def export_catalog(self) -> Dict[str, Any]:
        """
        Export entire catalog as a structured dictionary.
        
        Returns:
            Dictionary representation of complete catalog
        """
        self.load_catalog()
        
        export = {}
        for codemod_id, codemod_def in self._catalog_cache.items():
            export[codemod_id] = {
                'metadata': codemod_def.metadata.to_dict(),
                'implementation': codemod_def.implementation,
                'test_instructions': codemod_def.test_instructions,
                'rollback_instructions': codemod_def.rollback_instructions
            }
        
        return export
