"""
Monkeypatching questionary to support unique styling for Choice descriptions.
This is necessary because questionary 2.1.1 bundles unselected titles and 
descriptions under the same 'class:text' style token.

NOTE: This patch is optional and gracefully degrades if the target classes
are not available in the installed questionary version.
"""

import questionary.prompts.common


def apply_description_patch():
    """Applies the monkeypatch to questionary if the class is available."""
    
    # Check if ChoiceList exists (questionary >= 2.1.0)
    if not hasattr(questionary.prompts.common, 'ChoiceList'):
        # Silently skip patch for questionary versions that don't have ChoiceList
        return

    # Avoid double patching
    if hasattr(questionary.prompts.common.ChoiceList, "_original_get_choice_tokens"):
        return

    try:
        # Store original method
        original_method = questionary.prompts.common.ChoiceList._get_choice_tokens
        questionary.prompts.common.ChoiceList._original_get_choice_tokens = original_method

        def patched_get_choice_tokens(self):
            # Call original to get the standard token list
            tokens = original_method(self)
            
            new_tokens = []
            for style, text in tokens:
                # intercepted description lines start with "  Description: " 
                # and are currently assigned "class:text"
                if style == "class:text" and text.startswith("  Description: "):
                    new_tokens.append(("class:description", text))
                else:
                    new_tokens.append((style, text))
            
            return new_tokens

        # Apply patch
        questionary.prompts.common.ChoiceList._get_choice_tokens = patched_get_choice_tokens
    except (AttributeError, TypeError) as e:
        # Silently fail if anything goes wrong with patching
        pass
