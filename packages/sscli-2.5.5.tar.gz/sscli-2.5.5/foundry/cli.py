from typing import Optional
from foundry.constants import console
import typer
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.actions.validation import run_smoke_tests
from foundry.actions.verify import run_verification
from foundry.actions.upgrade import run_upgrade
from foundry.auth import get_current_license_info, logout
from foundry.telemetry import log_event
from foundry.commands.auth import auth_app, run_whoami
from foundry.commands.interactive import interactive_app
from foundry.utils import is_internal_dev

app = typer.Typer(
    help="Seed & Source CLI Tool",
    no_args_is_help=False,
    add_completion=True,
)

# Add sub-apps from separate modules
app.add_typer(auth_app, name="auth")
app.add_typer(interactive_app, name="interactive")

# Only expose dev tools in internal development mode
if is_internal_dev():
    from foundry.commands.dev import dev_app
    app.add_typer(dev_app, name="dev", help="Development and maintenance tools")
    
    from foundry.ops.cli import ops_app
    app.add_typer(ops_app, name="ops", help="Internal operations and maintenance.")


@app.callback(invoke_without_command=True)
def default_action(ctx: typer.Context):
    """Default action: show interactive menu if no command is provided."""
    if ctx.invoked_subcommand is None:
        from foundry.interactive import interactive_menu
        interactive_menu()


@app.command("whoami")
def whoami():
    run_whoami()


@app.command("logout")
def logout_cmd():
    """Clear local credentials and logout."""
    log_event("COMMAND", "logout")
    logout()


@app.command("explore")
def explore():
    """List available templates."""
    log_event("COMMAND", "explore")
    run_explore()


@app.command("new")
def new(
    template: str = typer.Option(..., help="Name of the template to use"),
    name: str = typer.Option(..., help="Name of the application"),
    target: Optional[str] = typer.Option(
        None, help="Target directory (defaults to name)"
    ),
    no_lint: bool = typer.Option(False, "--no-lint", help="Disable default linters"),
    with_commerce: bool = typer.Option(
        False, "--with-commerce", help="Inject Commerce modules (Shopify/Stripe)"
    ),
    with_tunnel: bool = typer.Option(
        False, "--with-tunnel", help="Enable local tunneling (ngrok)"
    ),
    with_landing: bool = typer.Option(
        False, "--with-landing", help="Include static landing page (Astro)"
    ),
    with_admin: bool = typer.Option(
        False, "--with-admin", help="Inject NiceGUI-based admin panel"
    ),
    with_sqlite: bool = typer.Option(
        False, "--with-sqlite", help="Setup local SQLite persistence with Alembic"
    ),
    with_ingestor: bool = typer.Option(
        False, "--with-ingestor", help="Inject Data Ingestor adapter pattern"
    ),
    with_auth: bool = typer.Option(
        False, "--with-auth", help="Inject authentication features"
    ),
    with_merchant_dashboard: bool = typer.Option(
        False, "--with-merchant-dashboard", help="Include Merchant Dashboard (requires --with-commerce)"
    ),
    secrets: str = typer.Option(
        "Dotenv (Standard .env files)", help="Secrets management strategy"
    ),
    content: Optional[str] = typer.Option(
        None, "--content", help="Path to a JSON content blueprint for static-landing"
    ),
    theme: Optional[str] = typer.Option(
        None, "--theme", help="Theme to apply to the landing page (emerald, midnight, etc.)"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without applying them"),
    json: bool = typer.Option(False, "--json", help="Output results in JSON format (with --dry-run)"),
    stats: bool = typer.Option(False, "--stats", help="Show only statistics (with --dry-run)"),
    output: Optional[str] = typer.Option(None, "--output", help="Save dry-run output to file"),
):
    """Generate a new project from a template."""
    # Validation: merchant-dashboard requires commerce
    if with_merchant_dashboard and not with_commerce:
        console.print("[red]❌ Error: --with-merchant-dashboard requires --with-commerce to be enabled.[/red]")
        console.print("[yellow]Use: sscli new react-client --with-commerce --with-merchant-dashboard --name [name][/yellow]")
        raise typer.Exit(code=1)
    
    log_event("COMMAND", f"new --template {template} --name {name} --commerce {with_commerce} --tunnel {with_tunnel} --landing {with_landing} --admin {with_admin} --sqlite {with_sqlite} --ingestor {with_ingestor} --auth {with_auth} --merchant-dashboard {with_merchant_dashboard} --dry-run {dry_run}")
    run_generator(
        template_name=template,
        app_name=name,
        target_dir_name=target,
        use_linters=not no_lint,
        with_commerce=with_commerce,
        with_tunnel=with_tunnel,
        with_landing=with_landing,
        with_admin=with_admin,
        with_sqlite=with_sqlite,
        with_ingestor=with_ingestor,
        with_auth=with_auth,
        with_merchant_dashboard=with_merchant_dashboard,
        interactive=False,
        secrets_strategy=secrets,
        content_path=content,
        theme=theme,
        dry_run=dry_run,
        json_output=json,
        stats_only=stats,
        output_file=output,
    )


@app.command("setup")
def setup(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable detailed logging"
    ),
    force: bool = typer.Option(
        False, "--force", help="Force setup even if already configured"
    ),
    skip_deps: bool = typer.Option(
        False, "--skip-deps", help="Skip dependency installation"
    ),
    env: str = typer.Option("dev", "--env", help="Environment to setup (default: dev)"),
    strategy: Optional[str] = typer.Option(
        None, "--strategy", help="Setup strategy (docker, etc)"
    ),
):
    """Run setup for templates."""
    log_event("COMMAND", f"setup --env {env}")
    run_setup(
        verbose=verbose, force=force, skip_deps=skip_deps, env=env, strategy=strategy
    )


@app.command("validate")
def validate():
    """Run smoke tests."""
    log_event("COMMAND", "validate")
    run_smoke_tests()


@app.command("health")
def health():
    """Check configuration and health of templates."""
    log_event("COMMAND", "health")
    run_health_check()


@app.command("verify")
def verify(
    skip_docker: bool = typer.Option(
        False, "--skip-docker", help="Skip Docker builds (faster, less thorough)"
    ),
    no_reports: bool = typer.Option(
        False, "--no-reports", help="Skip generating CSV/MD reports"
    ),
):
    """Verify template integrity and buildability."""
    log_event("COMMAND", "verify")
    run_verification(include_docker=not skip_docker, output_reports=not no_reports)


@app.command("upgrade")
def upgrade(
    project_path: Optional[str] = typer.Argument(
        None, help="Path to project (defaults to current directory)"
    ),
    to_version: Optional[str] = typer.Option(
        None, "--to-version", help="Target version (defaults to latest)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview changes without applying them"
    ),
    force: bool = typer.Option(
        False, "--force", help="Skip git status checks"
    ),
    interactive: bool = typer.Option(
        False, "--interactive", "-i", help="Confirm each codemod before applying"
    ),
    skip_verification: bool = typer.Option(
        False, "--skip-verification", help="Skip post-upgrade verification checks"
    ),
):
    """Upgrade a project to a newer template version."""
    log_event("COMMAND", f"upgrade --to-version {to_version} --dry-run {dry_run}")
    
    if not run_upgrade(
        project_path=project_path,
        to_version=to_version,
        dry_run=dry_run,
        force=force,
        interactive=interactive,
        skip_verification=skip_verification,
    ):
        raise typer.Exit(code=1)