"""
Comprehensive tests for the Upgrade Command (Phase 3 of Codemod Transformation Engine).

Tests:
- Upgrade planning with dry-run
- Upgrade execution with sequential codemods
- Version detection from project files
- Error handling and rollback
- Interactive mode
- Upgrade history tracking
- Multi-step upgrades
- Git integration
- Metadata management
"""

import pytest
import tempfile
import json
import shutil
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch

from foundry.actions.upgrade import (
    UpgradeCommand,
    MetadataTracker,
    ProjectMetadata,
    UpgradeHistory,
    UpgradeStep,
    run_upgrade,
)
from foundry.codemods.delta_store import CodemodMetadata, CodemodDefinition


class TestMetadataTracker:
    """Tests for MetadataTracker."""

    def test_metadata_file_location(self):
        """Test metadata file is in correct location."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)
            assert tracker.metadata_file == project_path / ".seed-source-metadata.json"

    def test_save_and_load_metadata(self):
        """Test saving and loading metadata."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)

            # Create and save metadata
            metadata = ProjectMetadata(
                current_version="1.0.0",
                template_type="python-saas",
                created_at="2025-01-01T00:00:00",
            )
            tracker.save(metadata)

            # Load and verify
            loaded = tracker.load()
            assert loaded.current_version == "1.0.0"
            assert loaded.template_type == "python-saas"

    def test_metadata_with_upgrade_history(self):
        """Test metadata with upgrade history."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)

            metadata = ProjectMetadata(
                current_version="1.0.0",
                template_type="python-saas",
                created_at="2025-01-01T00:00:00",
            )

            # Add upgrade history
            tracker.add_upgrade_history(
                metadata,
                from_version="1.0.0",
                to_version="1.1.0",
                steps=["codemod-001"],
                success=True,
            )

            # Verify history was added
            assert len(metadata.upgrade_history) == 1
            assert metadata.upgrade_history[0].from_version == "1.0.0"
            assert metadata.upgrade_history[0].to_version == "1.1.0"
            assert metadata.current_version == "1.1.0"

    @patch("foundry.actions.upgrade.MetadataTracker._detect_template_type")
    @patch("foundry.actions.upgrade.MetadataTracker._detect_version")
    def test_infer_metadata(self, mock_detect_version, mock_detect_template):
        """Test inferring metadata from project files."""
        mock_detect_version.return_value = "1.0.0"
        mock_detect_template.return_value = "react-client"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)
            tracker = MetadataTracker(project_path)

            metadata = tracker._infer_metadata()

            assert metadata.current_version == "1.0.0"
            assert metadata.template_type == "react-client"

    def test_detect_template_type_python_saas(self):
        """Test detecting python-saas template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            # Create python-saas structure
            (project_path / "pyproject.toml").write_text("[tool.poetry]\n")
            (project_path / "src" / "core").mkdir(parents=True)

            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()

            assert template == "python-saas"

    def test_detect_template_type_react_client(self):
        """Test detecting react-client template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            # Create react-client structure
            (project_path / "package.json").write_text('{"name": "app"}')
            (project_path / "src" / "components").mkdir(parents=True)
            vite_config = project_path / "vite.config.js"
            vite_config.write_text("// vite")

            tracker = MetadataTracker(project_path)
            template = tracker._detect_template_type()

            assert template == "react-client"

    def test_detect_version_from_pyproject(self):
        """Test detecting version from pyproject.toml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            pyproject = project_path / "pyproject.toml"
            pyproject.write_text('version = "2.1.0"\n')

            tracker = MetadataTracker(project_path)
            version = tracker._detect_version()

            assert version == "2.1.0"

    def test_detect_version_from_package_json(self):
        """Test detecting version from package.json."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            package_json = project_path / "package.json"
            package_json.write_text('{"version": "1.5.0"}')

            tracker = MetadataTracker(project_path)
            version = tracker._detect_version()

            assert version == "1.5.0"


class TestUpgradeCommand:
    """Tests for UpgradeCommand."""

    @pytest.fixture
    def project_path(self):
        """Create a temporary project directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_upgrade_command_initialization(self, project_path):
        """Test initializing UpgradeCommand."""
        cmd = UpgradeCommand(project_path)

        assert cmd.project_path == project_path
        assert cmd.delta_store is not None
        assert cmd.metadata_tracker is not None

    @patch("foundry.actions.upgrade.UpgradeCommand._get_latest_version")
    @patch("foundry.actions.upgrade.MetadataTracker.load")
    @patch("foundry.actions.upgrade.DeltaStore.get_codemods_for_template")
    def test_plan_upgrade(
        self,
        mock_get_codemods,
        mock_load_metadata,
        mock_get_latest_version,
        project_path,
    ):
        """Test planning an upgrade."""
        # Setup mocks
        metadata = ProjectMetadata(
            current_version="1.0.0",
            template_type="python-saas",
            created_at="2025-01-01",
        )
        mock_load_metadata.return_value = metadata
        mock_get_latest_version.return_value = "1.1.0"

        codemod_metadata = CodemodMetadata(
            id="001-upgrade",
            name="Upgrade Dependency",
            description="Upgrade pydantic",
            from_version="1.0.0",
            to_version="1.1.0",
            affected_templates=["python-saas"],
            risk_level="low",
        )
        codemod_def = CodemodDefinition(
            metadata=codemod_metadata,
            implementation={},
        )
        mock_get_codemods.return_value = [codemod_def]

        # Test plan
        with patch.object(UpgradeCommand, "_get_latest_version", return_value="1.1.0"):
            cmd = UpgradeCommand(project_path)
            cmd.metadata_tracker.load = mock_load_metadata
            cmd.delta_store.get_codemods_for_template = mock_get_codemods

            steps, target_version = cmd.plan_upgrade()

        assert len(steps) == 1
        assert target_version == "1.1.0"
        assert steps[0].codemod_id == "001-upgrade"

    def test_plan_upgrade_already_latest(self, project_path):
        """Test planning when already at latest version."""
        with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
            metadata = ProjectMetadata(
                current_version="1.1.0",
                template_type="python-saas",
                created_at="2025-01-01",
            )
            mock_load.return_value = metadata

            with patch("foundry.actions.upgrade.DeltaStore.get_codemods_for_template") as mock_codemods:
                mock_codemods.return_value = []

                cmd = UpgradeCommand(project_path)
                steps, target_version = cmd.plan_upgrade(to_version="1.1.0")

        assert len(steps) == 0

    @patch("foundry.actions.upgrade.UpgradeCommand._create_backup")
    @patch("foundry.actions.upgrade.UpgradeCommand.plan_upgrade")
    @patch("foundry.actions.upgrade.MetadataTracker.load")
    def test_execute_upgrade_failure_rollback(
        self,
        mock_load,
        mock_plan,
        mock_backup,
        project_path,
    ):
        """Test that failed upgrade triggers rollback."""
        metadata = ProjectMetadata(
            current_version="1.0.0",
            template_type="python-saas",
            created_at="2025-01-01",
        )
        mock_load.return_value = metadata

        step = UpgradeStep(
            index=1,
            codemod_id="001",
            codemod_name="Test Codemod",
            from_version="1.0.0",
            to_version="1.1.0",
            description="Test",
            risk_level="low",
        )
        mock_plan.return_value = ([step], "1.1.0")

        backup_path = Path(project_path) / ".upgrades" / "backup_001"
        mock_backup.return_value = backup_path

        cmd = UpgradeCommand(project_path)

        # Mock apply_codemod to fail
        with patch.object(cmd, "_apply_codemod", return_value=False):
            with patch.object(cmd, "_rollback_to_backup") as mock_rollback:
                result = cmd.execute_upgrade()

        assert result is False
        mock_rollback.assert_called_once()

    def test_create_backup(self, project_path):
        """Test creating a backup of the project."""
        # Create some project files
        (project_path / "src").mkdir()
        (project_path / "src" / "main.py").write_text("# code")
        (project_path / "pyproject.toml").write_text("[project]")

        cmd = UpgradeCommand(project_path)
        backup_path = cmd._create_backup()

        # Verify backup exists and contains files
        assert backup_path.exists()
        assert (backup_path / "src" / "main.py").exists()
        assert (backup_path / "pyproject.toml").exists()

    def test_backup_excludes_unwanted_dirs(self, project_path):
        """Test that backup excludes node_modules, venv, etc."""
        # Create directories that should be excluded
        (project_path / "node_modules").mkdir()
        (project_path / "node_modules" / "package").mkdir()
        (project_path / "venv").mkdir()
        (project_path / "src").mkdir()
        (project_path / "src" / "main.py").write_text("code")

        cmd = UpgradeCommand(project_path)
        backup_path = cmd._create_backup()

        # Verify exclusions
        assert not (backup_path / "node_modules").exists()
        assert not (backup_path / "venv").exists()
        assert (backup_path / "src" / "main.py").exists()

    @patch("foundry.actions.upgrade.UpgradeCommand._rollback_to_backup")
    def test_rollback_to_backup(self, mock_rollback, project_path):
        """Test rolling back to a backup."""
        # Create backup
        backup_path = Path(project_path) / ".upgrades" / "backup"
        backup_path.mkdir(parents=True)
        (backup_path / "backup_file.txt").write_text("backup content")

        # Create current project file
        (project_path / "backup_file.txt").write_text("current content")

        cmd = UpgradeCommand(project_path)
        cmd.backup_path = backup_path
        cmd._rollback_to_backup()

        # Verify restores from backup
        assert (project_path / "backup_file.txt").read_text() == "backup content"

    def test_get_upgrade_steps(self, project_path):
        """Test getting upgrade steps without executing."""
        with patch("foundry.actions.upgrade.MetadataTracker.load") as mock_load:
            metadata = ProjectMetadata(
                current_version="1.0.0",
                template_type="python-saas",
                created_at="2025-01-01",
            )
            mock_load.return_value = metadata

            codemod_metadata = CodemodMetadata(
                id="001",
                name="Step 1",
                description="Upgrade A",
                from_version="1.0.0",
                to_version="1.0.5",
                affected_templates=["python-saas"],
                risk_level="low",
            )
            codemod_def = CodemodDefinition(
                metadata=codemod_metadata,
                implementation={},
            )

            with patch.object(
                UpgradeCommand,
                "delta_store"
            ) as mock_store:
                mock_store.get_codemods_for_template.return_value = [codemod_def]

                cmd = UpgradeCommand(project_path)
                steps = cmd.get_upgrade_steps("1.0.0", "1.0.5")

        assert len(steps) == 1
        assert steps[0].codemod_name == "Step 1"

    def test_apply_codemod_interactive_yes(self, project_path):
        """Test applying codemod in interactive mode with yes."""
        step = UpgradeStep(
            index=1,
            codemod_id="001",
            codemod_name="Test",
            from_version="1.0.0",
            to_version="1.1.0",
            description="Test codemod",
            risk_level="low",
        )

        cmd = UpgradeCommand(project_path)

        with patch("foundry.constants.console.input", return_value="yes"):
            result = cmd._apply_codemod(step, interactive=True)

        assert result is True

    def test_apply_codemod_interactive_no(self, project_path):
        """Test skipping codemod in interactive mode."""
        step = UpgradeStep(
            index=1,
            codemod_id="001",
            codemod_name="Test",
            from_version="1.0.0",
            to_version="1.1.0",
            description="Test codemod",
            risk_level="low",
        )

        cmd = UpgradeCommand(project_path)

        with patch("foundry.constants.console.input", return_value="no"):
            result = cmd._apply_codemod(step, interactive=True)

        # Still returns True because we "successfully" skipped it
        assert result is True

    @patch("subprocess.run")
    def test_commit_upgrade(self, mock_run, project_path):
        """Test committing upgrade to git."""
        mock_run.return_value = Mock(returncode=0)

        cmd = UpgradeCommand(project_path)
        cmd._commit_upgrade("1.0.0", "1.1.0")

        # Verify git commands were called
        assert mock_run.call_count == 2

    def test_upgrade_history_tracking(self, project_path):
        """Test that upgrade history is properly tracked."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_project = Path(tmpdir)
            metadata = ProjectMetadata(
                current_version="1.0.0",
                template_type="python-saas",
                created_at="2025-01-01",
            )

            tracker = MetadataTracker(test_project)
            tracker.add_upgrade_history(
                metadata,
                from_version="1.0.0",
                to_version="1.1.0",
                steps=["codemod-001", "codemod-002"],
                success=True,
            )

            # Verify history
            assert len(metadata.upgrade_history) == 1
            history = metadata.upgrade_history[0]
            assert history.from_version == "1.0.0"
            assert history.to_version == "1.1.0"
            assert history.steps_applied == 2
            assert history.status == "success"


class TestRunUpgradeFunction:
    """Tests for the run_upgrade function."""

    def test_run_upgrade_dry_run(self):
        """Test run_upgrade with dry-run flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            with patch("foundry.actions.upgrade.UpgradeCommand.preview_upgrade") as mock_preview:
                mock_preview.return_value = Mock()

                result = run_upgrade(
                    project_path=project_path,
                    dry_run=True,
                )

            # Should return True for successful dry-run
            assert isinstance(result, bool)

    def test_run_upgrade_executes(self):
        """Test run_upgrade executes properly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            with patch.object(UpgradeCommand, "execute_upgrade") as mock_execute:
                mock_execute.return_value = True

                result = run_upgrade(
                    project_path=project_path,
                    to_version="1.1.0",
                )

            assert isinstance(result, bool)

    def test_run_upgrade_error_handling(self):
        """Test run_upgrade handles errors gracefully."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            with patch.object(UpgradeCommand, "__init__", side_effect=Exception("Test error")):
                result = run_upgrade(project_path=project_path)

            assert result is False


class TestUpgradeStep:
    """Tests for UpgradeStep."""

    def test_upgrade_step_creation(self):
        """Test creating an UpgradeStep."""
        step = UpgradeStep(
            index=1,
            codemod_id="001",
            codemod_name="Pydantic v1->v2",
            from_version="1.0.0",
            to_version="1.1.0",
            description="Upgrade pydantic to v2",
            risk_level="high",
            requires_manual_review=True,
        )

        assert step.index == 1
        assert step.codemod_id == "001"
        assert step.risk_level == "high"
        assert step.requires_manual_review is True


class TestUpgradeHistory:
    """Tests for UpgradeHistory."""

    def test_upgrade_history_creation(self):
        """Test creating an UpgradeHistory record."""
        history = UpgradeHistory(
            timestamp="2025-01-01T12:00:00",
            from_version="1.0.0",
            to_version="1.1.0",
            steps_applied=2,
            steps_successful=2,
            status="success",
            codemod_ids=["001", "002"],
        )

        assert history.from_version == "1.0.0"
        assert history.to_version == "1.1.0"
        assert history.status == "success"

    def test_upgrade_history_with_error(self):
        """Test UpgradeHistory with error."""
        history = UpgradeHistory(
            timestamp="2025-01-01T12:00:00",
            from_version="1.0.0",
            to_version="1.1.0",
            steps_applied=2,
            steps_successful=1,
            status="failed",
            error_message="Codemod execution failed",
        )

        assert history.status == "failed"
        assert history.error_message == "Codemod execution failed"


class TestIntegration:
    """Integration tests combining multiple components."""

    def test_full_upgrade_workflow(self):
        """Test a complete upgrade workflow."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir)

            # Create a minimal project
            (project_path / "pyproject.toml").write_text('version = "1.0.0"\n')

            with patch("foundry.actions.upgrade.UpgradeCommand.plan_upgrade") as mock_plan:
                step = UpgradeStep(
                    index=1,
                    codemod_id="001",
                    codemod_name="Upgrade",
                    from_version="1.0.0",
                    to_version="1.1.0",
                    description="Test",
                    risk_level="low",
                )
                mock_plan.return_value = ([step], "1.1.0")

                with patch.object(UpgradeCommand, "_create_backup") as mock_backup:
                    mock_backup.return_value = Path(project_path) / ".backup"

                    with patch.object(UpgradeCommand, "_apply_codemod") as mock_apply:
                        mock_apply.return_value = True

                        with patch.object(UpgradeCommand, "_commit_upgrade"):
                            cmd = UpgradeCommand(project_path)
                            result = cmd.execute_upgrade(force=True)

            # Should succeed
            assert result is True
