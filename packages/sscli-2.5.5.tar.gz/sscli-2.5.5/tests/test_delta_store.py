"""
Test suite for Delta Store: Versioned Codemod Catalog Manager

Tests catalog loading, codemod retrieval, version matching, dependency
resolution, and upgrade path validation.
"""

import pytest
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import yaml

from foundry.codemods.delta_store import (
    CodemodMetadata,
    CodemodDefinition,
    DeltaStore
)


class TestCodemodMetadata:
    """Test CodemodMetadata dataclass."""
    
    def test_metadata_creation(self):
        """Test creating metadata object."""
        metadata = CodemodMetadata(
            id="010-001-PY-test",
            name="Test Codemod",
            description="Test description",
            from_version="2.0.0",
            to_version="2.1.0",
            affected_templates=["python-saas"],
            risk_level="low"
        )
        
        assert metadata.id == "010-001-PY-test"
        assert metadata.name == "Test Codemod"
        assert metadata.risk_level == "low"
        assert metadata.requires_manual_review is False
        assert metadata.rollback_safe is True
    
    def test_metadata_to_dict(self):
        """Test converting metadata to dictionary."""
        metadata = CodemodMetadata(
            id="010-001-PY-test",
            name="Test Codemod",
            description="Test description",
            from_version="2.0.0",
            to_version="2.1.0",
            affected_templates=["python-saas"],
            risk_level="low",
            tags=["test"]
        )
        
        data = metadata.to_dict()
        assert isinstance(data, dict)
        assert data["id"] == "010-001-PY-test"
        assert data["tags"] == ["test"]
    
    def test_metadata_from_dict(self):
        """Test creating metadata from dictionary."""
        data = {
            "id": "010-001-PY-test",
            "name": "Test Codemod",
            "description": "Test description",
            "from_version": "2.0.0",
            "to_version": "2.1.0",
            "affected_templates": ["python-saas"],
            "risk_level": "low"
        }
        
        metadata = CodemodMetadata.from_dict(data)
        assert metadata.id == "010-001-PY-test"
        assert metadata.name == "Test Codemod"


class TestDeltaStoreLoading:
    """Test Delta Store catalog loading."""
    
    def test_load_catalog_from_real_path(self):
        """Test loading catalog from actual directory."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            catalog = store.load_catalog()
            
            # Should load at least the sample codemods
            assert len(catalog) > 0
            assert isinstance(catalog, dict)
            
            # Check that loaded items are CodemodDefinition objects
            for codemod_id, codemod_def in catalog.items():
                assert isinstance(codemod_def, CodemodDefinition)
                assert isinstance(codemod_def.metadata, CodemodMetadata)
    
    def test_load_missing_catalog(self):
        """Test loading from non-existent catalog."""
        store = DeltaStore(Path("/nonexistent/catalog"))
        
        with pytest.raises(FileNotFoundError):
            store.load_catalog()
    
    def test_load_catalog_caching(self):
        """Test that catalog is cached after first load."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Load twice
            catalog1 = store.load_catalog()
            catalog2 = store.load_catalog()
            
            # Should return the same cached object
            assert catalog1 is catalog2


class TestCodemodRetrieval:
    """Test retrieving specific codemods."""
    
    def test_get_specific_codemod(self):
        """Test retrieving a specific codemod by ID."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Get a codemod if any exist
            all_codemods = store.list_available_codemods()
            if all_codemods:
                codemod_id = all_codemods[0].id
                codemod = store.get_codemod(codemod_id)
                
                assert codemod is not None
                assert codemod.metadata.id == codemod_id
    
    def test_get_nonexistent_codemod(self):
        """Test retrieving a non-existent codemod."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemod = store.get_codemod("nonexistent-id")
            
            assert codemod is None
    
    def test_list_available_codemods(self):
        """Test listing all available codemods."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods()
            
            assert isinstance(codemods, list)
            for metadata in codemods:
                assert isinstance(metadata, CodemodMetadata)
    
    def test_list_codemods_by_template(self):
        """Test filtering codemods by template."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods(template="python-saas")
            
            for metadata in codemods:
                assert "python-saas" in metadata.affected_templates
    
    def test_list_codemods_by_risk_level(self):
        """Test filtering codemods by risk level."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods(risk_level="low")
            
            for metadata in codemods:
                assert metadata.risk_level == "low"


class TestVersionMatching:
    """Test version range matching logic."""
    
    def test_get_codemods_for_upgrade(self):
        """Test retrieving codemods for a version upgrade."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            # Try to get codemods for python-saas upgrade
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            assert isinstance(codemods, list)
            for codemod in codemods:
                assert isinstance(codemod, CodemodDefinition)
    
    def test_invalid_version_format(self):
        """Test that invalid version format raises error."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "invalid", "2.3.0"
                )
    
    def test_to_version_less_than_from_version(self):
        """Test that to_version < from_version raises error."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "2.3.0", "2.2.0"
                )
    
    def test_same_versions_rejected(self):
        """Test that same from and to versions are rejected."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "python-saas", "2.3.0", "2.3.0"
                )


class TestDependencyResolution:
    """Test codemod dependency resolution."""
    
    def test_dependency_ordering(self):
        """Test that codemods are ordered correctly for dependencies."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            # Build a set of seen IDs to verify ordering
            seen_ids = set()
            for codemod in codemods:
                # All dependencies should have been seen already
                for dep_id in codemod.metadata.dependencies:
                    assert dep_id in seen_ids
                seen_ids.add(codemod.metadata.id)
    
    def test_circular_dependency_detection(self):
        """Test that circular dependencies are detected."""
        with TemporaryDirectory() as tmpdir:
            catalog_root = Path(tmpdir)
            template_root = catalog_root / "test-template" / "1.0.0-2.0.0"
            template_root.mkdir(parents=True)
            
            # Create codemods with circular dependency
            codemod1 = {
                "metadata": {
                    "id": "001",
                    "name": "CM 1",
                    "description": "Test",
                    "from_version": "1.0.0",
                    "to_version": "2.0.0",
                    "affected_templates": ["test-template"],
                    "risk_level": "low",
                    "dependencies": ["002"]
                },
                "implementation": {}
            }
            
            codemod2 = {
                "metadata": {
                    "id": "002",
                    "name": "CM 2",
                    "description": "Test",
                    "from_version": "1.0.0",
                    "to_version": "2.0.0",
                    "affected_templates": ["test-template"],
                    "risk_level": "low",
                    "dependencies": ["001"]
                },
                "implementation": {}
            }
            
            with open(template_root / "001.yaml", "w") as f:
                yaml.dump(codemod1, f)
            
            with open(template_root / "002.yaml", "w") as f:
                yaml.dump(codemod2, f)
            
            store = DeltaStore(catalog_root)
            store.load_catalog()
            
            # Should raise error on circular dependency
            with pytest.raises(ValueError):
                store.get_codemods_for_template(
                    "test-template", "1.0.0", "2.0.0"
                )


class TestUpgradePathValidation:
    """Test upgrade path validation."""
    
    def test_valid_upgrade_path(self):
        """Test validating a valid upgrade path."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "python-saas", "2.2.0", "2.3.0"
            )
            
            assert isinstance(result, dict)
            assert "valid" in result
            assert "codemods" in result
            assert "warnings" in result
            assert "errors" in result
            assert "requires_review" in result
            assert "risk_level" in result
    
    def test_invalid_version_in_validation(self):
        """Test validation with invalid version."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "python-saas", "invalid", "2.3.0"
            )
            
            assert result["valid"] is False
            assert len(result["errors"]) > 0
    
    def test_validation_risk_tracking(self):
        """Test that validation tracks maximum risk level."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "rails-api", "2.2.0", "2.3.0"
            )
            
            if result["valid"] and result["codemods"]:
                # Check that risk_level is one of the valid options
                assert result["risk_level"] in ["low", "medium", "high", "critical"]
    
    def test_validation_manual_review_flag(self):
        """Test that manual review requirement is tracked."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            result = store.validate_upgrade_path(
                "rails-api", "2.2.0", "2.3.0"
            )
            
            # Rails API has high-risk codemod that requires review
            if result["valid"] and "010-004-RAILS-upgrade-7-2" in result["codemods"]:
                assert result["requires_review"] is True


class TestManifestHandling:
    """Test handling of manifest.json files."""
    
    def test_get_catalogs_for_template(self):
        """Test retrieving available version ranges for a template."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            catalogs = store.get_catalogs_for_template("python-saas")
            
            assert isinstance(catalogs, list)
            for catalog_range in catalogs:
                assert "-" in catalog_range


class TestCatalogExport:
    """Test exporting the catalog."""
    
    def test_export_catalog(self):
        """Test exporting entire catalog as dictionary."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            export = store.export_catalog()
            
            assert isinstance(export, dict)
            for codemod_id, codemod_data in export.items():
                assert "metadata" in codemod_data
                assert "implementation" in codemod_data


class TestEmptyCatalog:
    """Test behavior with empty catalog."""
    
    def test_empty_catalog_operations(self):
        """Test operations on empty catalog."""
        with TemporaryDirectory() as tmpdir:
            store = DeltaStore(Path(tmpdir))
            store.load_catalog()
            
            # Should return empty results
            assert len(store.list_available_codemods()) == 0
            assert store.get_codemod("any-id") is None
            
            # Should return empty codemod list for upgrade
            codemods = store.get_codemods_for_template(
                "python-saas", "2.2.0", "2.3.0"
            )
            assert len(codemods) == 0


class TestCodemodDefinitionLoading:
    """Test loading complete codemod definitions."""
    
    def test_codemod_definition_structure(self):
        """Test that loaded codemods have complete structure."""
        catalog_root = Path(__file__).parent.parent / "codemods" / "catalog"
        
        if catalog_root.exists():
            store = DeltaStore(catalog_root)
            codemods = store.list_available_codemods()
            
            if codemods:
                codemod_id = codemods[0].id
                codemod_def = store.get_codemod(codemod_id)
                
                assert codemod_def is not None
                assert hasattr(codemod_def, "metadata")
                assert hasattr(codemod_def, "implementation")
                assert hasattr(codemod_def, "test_instructions")
                assert hasattr(codemod_def, "rollback_instructions")
