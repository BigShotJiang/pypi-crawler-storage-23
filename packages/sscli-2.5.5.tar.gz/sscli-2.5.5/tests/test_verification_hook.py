"""
Comprehensive tests for the Verification Hook system (Phase 2).

Tests verify:
1. Project type detection across all template types
2. Validator selection based on project type
3. Validator execution (mocked external tools)
4. Pass/fail reporting
5. Error handling and graceful degradation
6. JSON serialization
7. Custom validator configuration

Run with: pytest tests/test_verification_hook.py -v
"""

import pytest
import json
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

from foundry.safety.verification_hook import (
    VerificationHook,
    ProjectType,
    ValidatorCommand,
    ValidationResult,
    ValidationReport,
)


class TestProjectTypeDetection:
    """Test project type detection from directory structure."""

    def test_detect_python_project(self, tmp_path):
        """Test detection of Python projects."""
        hook = VerificationHook()

        # Create Python project structure
        (tmp_path / "pyproject.toml").write_text("[build-system]\n")
        (tmp_path / "src").mkdir()

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.PYTHON

    def test_detect_python_project_with_setup_py(self, tmp_path):
        """Test detection of Python projects with setup.py."""
        hook = VerificationHook()
        (tmp_path / "setup.py").write_text("from setuptools import setup\n")

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.PYTHON

    def test_detect_ruby_project(self, tmp_path):
        """Test detection of Ruby/Rails projects."""
        hook = VerificationHook()

        # Create Rails project structure
        (tmp_path / "config").mkdir()
        (tmp_path / "app").mkdir()
        (tmp_path / "config" / "routes.rb").write_text("Rails.application.routes.draw do\nend\n")

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.RUBY

    def test_detect_react_project(self, tmp_path):
        """Test detection of React projects."""
        hook = VerificationHook()

        # Create React package.json
        package_json = {
            "name": "react-app",
            "dependencies": {"react": "^18.0.0"},
        }
        (tmp_path / "package.json").write_text(json.dumps(package_json))

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.REACT

    def test_detect_javascript_project(self, tmp_path):
        """Test detection of plain JavaScript projects."""
        hook = VerificationHook()

        # Create Node package.json (no React)
        package_json = {
            "name": "node-app",
            "dependencies": {"express": "^4.0.0"},
        }
        (tmp_path / "package.json").write_text(json.dumps(package_json))

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.JAVASCRIPT

    def test_detect_astro_project(self, tmp_path):
        """Test detection of Astro projects."""
        hook = VerificationHook()

        # Create Astro config
        (tmp_path / "astro.config.mjs").write_text("export default {}\n")

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.ASTRO

    def test_detect_astro_project_via_package_json(self, tmp_path):
        """Test detection of Astro via package.json."""
        hook = VerificationHook()

        package_json = {"name": "astro-app", "dependencies": {"astro": "^3.0.0"}}
        (tmp_path / "package.json").write_text(json.dumps(package_json))

        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.ASTRO

    def test_detect_unknown_project(self, tmp_path):
        """Test detection of unknown project types."""
        hook = VerificationHook()
        project_type = hook.detect_project_type(tmp_path)
        assert project_type == ProjectType.UNKNOWN

    def test_detect_project_invalid_package_json(self, tmp_path):
        """Test handling of malformed package.json."""
        hook = VerificationHook()

        # Create invalid JSON
        (tmp_path / "package.json").write_text("{invalid json")

        # Should gracefully return NODE type
        project_type = hook.detect_project_type(tmp_path)
        assert project_type in [ProjectType.NODE, ProjectType.UNKNOWN]


class TestValidatorSelection:
    """Test validator selection based on project type."""

    def test_get_validators_python(self):
        """Test getting Python validators."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.PYTHON)

        assert len(validators) > 0
        validator_names = {v.name for v in validators}
        assert "ruff-check" in validator_names
        assert "pytest-syntax" in validator_names

    def test_get_validators_ruby(self):
        """Test getting Ruby validators."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.RUBY)

        assert len(validators) > 0
        validator_names = {v.name for v in validators}
        assert "rubocop" in validator_names

    def test_get_validators_javascript(self):
        """Test getting JavaScript validators."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.JAVASCRIPT)

        assert len(validators) > 0
        validator_names = {v.name for v in validators}
        assert "eslint" in validator_names

    def test_get_validators_react(self):
        """Test getting React validators."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.REACT)

        assert len(validators) > 0
        validator_names = {v.name for v in validators}
        assert "eslint" in validator_names

    def test_get_validators_astro(self):
        """Test getting Astro validators."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.ASTRO)

        assert len(validators) > 0
        validator_names = {v.name for v in validators}
        assert "astro-build" in validator_names

    def test_get_validators_unknown_type(self):
        """Test getting validators for unknown type."""
        hook = VerificationHook()
        validators = hook.get_validators(ProjectType.UNKNOWN)

        assert validators == []

    def test_validators_have_required_fields(self):
        """Test that all validators have required configuration."""
        hook = VerificationHook()

        for project_type, validators in hook.validators_config.items():
            for validator in validators:
                assert validator.name
                assert validator.command
                assert validator.description
                assert isinstance(validator.critical, bool)
                assert isinstance(validator.enabled, bool)


class TestValidatorExecution:
    """Test validator execution with mocked subprocess calls."""

    def test_run_single_validator_success(self, tmp_path):
        """Test successful validator execution."""
        hook = VerificationHook()
        validator = ValidatorCommand(
            name="test-validator",
            command=["echo", "success"],
            description="Test validator",
            critical=True,
        )

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(
                returncode=0, stdout="Test passed", stderr=""
            )

            result = hook._run_validator(validator, tmp_path)

            assert result.success is True
            assert result.exit_code == 0
            assert result.output == "Test passed"
            assert result.validator_name == "test-validator"
            assert result.critical is True

    def test_run_single_validator_failure(self, tmp_path):
        """Test failed validator execution."""
        hook = VerificationHook()
        validator = ValidatorCommand(
            name="test-validator",
            command=["test", "-f", "/nonexistent"],
            description="Test validator",
            critical=True,
        )

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(
                returncode=1, stdout="", stderr="File not found"
            )

            result = hook._run_validator(validator, tmp_path)

            assert result.success is False
            assert result.exit_code == 1
            assert "File not found" in result.error_output

    def test_run_validator_timeout(self, tmp_path):
        """Test validator timeout handling."""
        hook = VerificationHook()
        validator = ValidatorCommand(
            name="slow-validator",
            command=["sleep", "1000"],
            description="Slow validator",
            critical=True,
        )

        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.TimeoutExpired(
                cmd="sleep 1000", timeout=300
            )

            result = hook._run_validator(validator, tmp_path)

            assert result.success is False
            assert "timed out" in result.error_output.lower()

    def test_run_validator_not_found(self, tmp_path):
        """Test validator command not found."""
        hook = VerificationHook()
        validator = ValidatorCommand(
            name="missing-validator",
            command=["nonexistent-command"],
            description="Missing validator",
            critical=True,
        )

        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("Command not found")

            result = hook._run_validator(validator, tmp_path)

            assert result.success is False
            assert "not found" in result.error_output.lower()

    def test_run_validator_disabled(self, tmp_path):
        """Test skipping disabled validators."""
        hook = VerificationHook()
        validator = ValidatorCommand(
            name="disabled-validator",
            command=["echo", "should-not-run"],
            description="Disabled validator",
            enabled=False,
        )

        result = hook._run_validator(validator, tmp_path)

        assert result.success is True
        assert result.exit_code == 0
        assert result.output == "(skipped)"

    def test_run_multiple_validators(self, tmp_path):
        """Test running multiple validators."""
        hook = VerificationHook()

        with patch.object(hook, "_run_validator") as mock_run:
            # Create mock results
            mock_run.side_effect = [
                ValidationResult(
                    validator_name="validator-1",
                    success=True,
                    exit_code=0,
                    critical=False,
                ),
                ValidationResult(
                    validator_name="validator-2",
                    success=False,
                    exit_code=1,
                    critical=True,
                ),
            ]

            report = hook.run_validators(tmp_path)

            assert report.validators_run == 2
            assert report.validators_passed == 1
            assert report.validators_failed == 1
            assert report.critical_failures == 1


class TestValidationReport:
    """Test ValidationReport data structure and formatting."""

    def test_report_passed(self):
        """Test report with all validators passing."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
        )
        report.results = [
            ValidationResult(
                validator_name="validator-1",
                success=True,
                exit_code=0,
                critical=False,
            ),
        ]
        report.validators_run = 1
        report.validators_passed = 1
        report.validators_failed = 0

        assert report.passed is True
        assert report.has_critical_failures is False

    def test_report_failed_non_critical(self):
        """Test report with non-critical failure."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
        )
        report.results = [
            ValidationResult(
                validator_name="validator-1",
                success=False,
                exit_code=1,
                critical=False,
            ),
        ]
        report.validators_run = 1
        report.validators_passed = 0
        report.validators_failed = 1

        assert report.passed is False
        assert report.has_critical_failures is False

    def test_report_failed_critical(self):
        """Test report with critical failure."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
        )
        report.results = [
            ValidationResult(
                validator_name="validator-1",
                success=False,
                exit_code=1,
                critical=True,
            ),
        ]
        report.validators_run = 1
        report.validators_passed = 0
        report.validators_failed = 1
        report.critical_failures = 1

        assert report.passed is False
        assert report.has_critical_failures is True

    def test_report_str_representation(self):
        """Test human-readable report formatting."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
            validators_passed=1,
            validators_failed=0,
            validators_run=1,
        )

        report_str = str(report)

        assert "Verification Report" in report_str
        assert "1/1" in report_str
        assert "✓ All validators passed" in report_str

    def test_report_str_with_failures(self):
        """Test report formatting with failures."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
            validators_passed=0,
            validators_failed=1,
            validators_run=1,
        )
        report.results = [
            ValidationResult(
                validator_name="test-validator",
                success=False,
                exit_code=1,
                error_output="Some error occurred",
                critical=True,
            ),
        ]

        report_str = str(report)

        assert "FAILURES" in report_str
        assert "test-validator" in report_str

    def test_report_to_dict(self):
        """Test converting report to dictionary."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
            validators_passed=1,
            validators_failed=0,
            validators_run=1,
        )

        report_dict = report.to_dict()

        assert report_dict["project_type"] == "python"
        assert report_dict["validators_run"] == 1
        assert report_dict["passed"] is True
        assert isinstance(report_dict["timestamp"], str)

    def test_report_as_json(self):
        """Test converting report to JSON."""
        report = ValidationReport(
            project_path=Path("/tmp/test"),
            project_type=ProjectType.PYTHON,
            validators_passed=1,
            validators_failed=0,
            validators_run=1,
        )

        json_str = report.as_json()
        parsed = json.loads(json_str)

        assert parsed["project_type"] == "python"
        assert parsed["validators_run"] == 1
        assert parsed["passed"] is True


class TestValidatorConfiguration:
    """Test validator configuration and customization."""

    def test_configure_validator_enable(self):
        """Test enabling/disabling validators."""
        hook = VerificationHook()

        hook.configure_validator(ProjectType.PYTHON, "ruff-check", enabled=False)

        validators = hook.get_validators(ProjectType.PYTHON)
        ruff_validator = next(v for v in validators if v.name == "ruff-check")
        assert ruff_validator.enabled is False

    def test_configure_validator_critical(self):
        """Test setting validator criticality."""
        hook = VerificationHook()

        hook.configure_validator(
            ProjectType.PYTHON, "mypy", critical=True
        )

        validators = hook.get_validators(ProjectType.PYTHON)
        mypy_validator = next(v for v in validators if v.name == "mypy")
        assert mypy_validator.critical is True

    def test_add_custom_validator(self):
        """Test adding custom validators."""
        hook = VerificationHook()

        hook.add_custom_validator(
            ProjectType.PYTHON,
            name="custom-check",
            command=["custom-tool", "check"],
            description="Custom validation tool",
            critical=True,
        )

        validators = hook.get_validators(ProjectType.PYTHON)
        custom_validator = next(v for v in validators if v.name == "custom-check")

        assert custom_validator.name == "custom-check"
        assert custom_validator.critical is True
        assert custom_validator.enabled is True

    def test_get_install_command(self):
        """Test getting installation commands for validators."""
        command = VerificationHook.get_command_to_enable_validator(
            ProjectType.PYTHON, "ruff"
        )
        assert "pip install ruff" in command

        command = VerificationHook.get_command_to_enable_validator(
            ProjectType.JAVASCRIPT, "eslint"
        )
        assert "npm install" in command

    def test_get_install_command_unknown_validator(self):
        """Test getting install command for unknown validator."""
        command = VerificationHook.get_command_to_enable_validator(
            ProjectType.PYTHON, "nonexistent-validator"
        )
        assert command is None


class TestSkipVerification:
    """Test skip verification flag."""

    def test_skip_verification_flag(self, tmp_path):
        """Test that skip_verification flag skips all checks."""
        hook = VerificationHook(skip_verification=True)

        # Create Python project
        (tmp_path / "pyproject.toml").write_text("[build-system]\n")
        (tmp_path / "src").mkdir()

        report = hook.run_validators(tmp_path)

        assert report.validators_run == 0
        assert report.validators_passed == 0
        assert report.validators_failed == 0

    def test_normal_verification(self, tmp_path):
        """Test normal verification with skip_verification=False."""
        hook = VerificationHook(skip_verification=False)

        # Create Python project
        (tmp_path / "pyproject.toml").write_text("[build-system]\n")
        (tmp_path / "src").mkdir()

        with patch.object(hook, "_run_validator") as mock_run:
            mock_run.return_value = ValidationResult(
                validator_name="test",
                success=True,
                exit_code=0,
            )

            report = hook.run_validators(tmp_path)

            # Should have run some validators
            assert report.validators_run > 0


class TestIntegration:
    """Integration tests with real project detection."""

    def test_full_workflow_python_project(self, tmp_path):
        """Test full workflow for Python project."""
        hook = VerificationHook()

        # Create Python project
        (tmp_path / "pyproject.toml").write_text("[build-system]\n")
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("print('hello')\n")

        with patch.object(hook, "_run_validator") as mock_run:
            mock_run.return_value = ValidationResult(
                validator_name="test",
                success=True,
                exit_code=0,
            )

            # Detect project type
            project_type = hook.detect_project_type(tmp_path)
            assert project_type == ProjectType.PYTHON

            # Get validators
            validators = hook.get_validators(project_type)
            assert len(validators) > 0

            # Run validators
            report = hook.run_validators(tmp_path)
            assert report.project_type == ProjectType.PYTHON
            assert report.validators_run > 0

            # Format output
            text_report = hook.format_report(report)
            assert "python" in text_report.lower()

            json_report = hook.as_json(report)
            parsed = json.loads(json_report)
            assert parsed["project_type"] == "python"

    def test_full_workflow_react_project(self, tmp_path):
        """Test full workflow for React project."""
        hook = VerificationHook()

        # Create React project
        package_json = {"name": "react-app", "dependencies": {"react": "^18.0.0"}}
        (tmp_path / "package.json").write_text(json.dumps(package_json))
        (tmp_path / "src").mkdir()

        with patch.object(hook, "_run_validator") as mock_run:
            mock_run.return_value = ValidationResult(
                validator_name="test",
                success=True,
                exit_code=0,
            )

            project_type = hook.detect_project_type(tmp_path)
            assert project_type == ProjectType.REACT

            validators = hook.get_validators(project_type)
            assert len(validators) > 0

            report = hook.run_validators(tmp_path)
            assert report.project_type == ProjectType.REACT


class TestValidatorCommand:
    """Test ValidatorCommand data structure."""

    def test_validator_command_creation(self):
        """Test creating validator command."""
        cmd = ValidatorCommand(
            name="test-validator",
            command=["test", "arg1", "arg2"],
            description="Test validator",
            critical=True,
            enabled=True,
        )

        assert cmd.name == "test-validator"
        assert cmd.command == ["test", "arg1", "arg2"]
        assert cmd.critical is True
        assert cmd.enabled is True

    def test_validator_command_str(self):
        """Test validator command string representation."""
        cmd = ValidatorCommand(
            name="test",
            command=["echo", "hello"],
            description="Test",
        )

        assert "test" in str(cmd)
        assert "echo hello" in str(cmd)


class TestValidationResult:
    """Test ValidationResult data structure."""

    def test_validation_result_success(self):
        """Test successful validation result."""
        result = ValidationResult(
            validator_name="test",
            success=True,
            exit_code=0,
            output="All checks passed",
            critical=True,
        )

        assert result.success is True
        assert "✓" in str(result)
        assert result.to_dict()["success"] is True

    def test_validation_result_failure(self):
        """Test failed validation result."""
        result = ValidationResult(
            validator_name="test",
            success=False,
            exit_code=1,
            error_output="Syntax error",
            critical=True,
        )

        assert result.success is False
        assert "✗" in str(result)
        assert result.to_dict()["success"] is False

    def test_validation_result_to_dict(self):
        """Test converting result to dictionary."""
        result = ValidationResult(
            validator_name="test",
            success=True,
            exit_code=0,
            output="Output",
            error_output="Error",
            duration_ms=123.45,
            critical=False,
        )

        result_dict = result.to_dict()

        assert result_dict["validator_name"] == "test"
        assert result_dict["success"] is True
        assert result_dict["exit_code"] == 0
        assert result_dict["duration_ms"] == 123.45
