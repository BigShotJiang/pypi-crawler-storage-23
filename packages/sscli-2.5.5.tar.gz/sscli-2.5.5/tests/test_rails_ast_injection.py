"""
Integration Tests for Rails AST Injection using Synvert

Tests verify that:
1. SynvertAdapter can inspect Ruby environment
2. Synvert rewriters execute correctly
3. Rails routes.rb is modified correctly
4. Models are updated properly
5. Idempotency is preserved (no duplicate injections)
6. Syntax validation works

Run with: pytest tests/test_rails_ast_injection.py -v
"""

import pytest
import subprocess
from pathlib import Path
from foundry.tools.synvert_adapter import SynvertAdapter


class TestSynvertEnvironment:
    """Test Synvert environment setup and verification."""
    
    def test_ruby_detection(self):
        """Test that Ruby is detected and version checked."""
        result = subprocess.run(
            ["ruby", "-v"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Ruby not available"
        assert "ruby" in result.stdout.lower()
    
    def test_adapter_initialization_requires_rails_project(self, tmp_path):
        """Test adapter requires a valid project path."""
        # Empty directory - this should still initialize
        # (Ruby/Synvert checks happen separately)
        try:
            adapter = SynvertAdapter(tmp_path)
            assert adapter.project_path == tmp_path
        except RuntimeError:
            # Expected if Ruby/Synvert not available in test env
            pytest.skip("Ruby or Synvert not available in test environment")


class TestRailsProjectFixture:
    """Fixtures for minimal Rails project structure."""
    
    @staticmethod
    def create_rails_project(tmp_path):
        """Create minimal Rails project structure for testing."""
        # Create directory structure
        (tmp_path / "config").mkdir()
        (tmp_path / "app" / "models").mkdir(parents=True)
        (tmp_path / "app" / "controllers").mkdir(parents=True)
        (tmp_path / "db" / "migrate").mkdir(parents=True)
        
        # Create routes.rb
        routes_content = '''Rails.application.routes.draw do
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
  
  # Reveal health status on /up that returns 200 if app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check
  
  # Define your application routes per the DSL in this file. Here is an example of a resource route.
  # If you had a books resource route, would generate these URI patterns:
  #
  # GET       /books
  # GET       /books/:id
  # POST      /books
  # GET       /books/:id/edit
  # PATCH/PUT /books/:id
  # DELETE    /books/:id
  #
  # config/routes.rb is where you define your routes. Each route is a rule telling Rails
  # which controller and action to run, depending on the HTTP method and URL.
end
'''
        (tmp_path / "config" / "routes.rb").write_text(routes_content)
        
        # Create Order model
        order_model = '''class Order < ApplicationRecord
  belongs_to :tenant
  
  validates :customer_email, presence: true
end
'''
        (tmp_path / "app" / "models" / "order.rb").write_text(order_model)
        
        # Create Tenant model
        tenant_model = '''class Tenant < ApplicationRecord
  validates :name, presence: true
end
'''
        (tmp_path / "app" / "models" / "tenant.rb").write_text(tenant_model)
        
        return tmp_path
    
    @pytest.fixture
    def rails_project(self, tmp_path):
        """Fixture providing a minimal Rails project."""
        return self.create_rails_project(tmp_path)


class TestWebhookRouteInjection(TestRailsProjectFixture):
    """Test Synvert webhook route injection."""
    
    def test_add_webhook_routes_generates_rewriter(self, rails_project):
        """Test that add_webhook_routes creates valid Synvert code."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError as e:
            pytest.skip(f"Synvert unavailable: {str(e)}")
        
        # Mock the inline_rewrite to verify the generated code
        # (actual execution requires Synvert gem)
        result = adapter.add_webhook_routes(
            namespace="webhooks",
            route_specs=[("post", "shopify", "webhooks/shopify#handle")]
        )
        
        # Check that rewriter code was generated
        assert result is not None
        assert isinstance(result, dict)
        assert "success" in result
    
    def test_webhook_routes_prevent_duplicates(self, rails_project):
        """Test that webhook injection prevents duplicate namespaces."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        routes_file = rails_project / "config" / "routes.rb"
        routes_content = routes_file.read_text()
        
        # If webhook namespace doesn't exist, verify the rewriter would add it
        if "namespace :webhooks" not in routes_content:
            result = adapter.add_webhook_routes()
            # The unless_exist_node guard prevents duplicates
            assert result["success"] or "unless_exist_node" in str(result)
    
    def test_webhook_routes_structure(self, rails_project):
        """Test that webhook routes have correct structure."""
        routes_file = rails_project / "config" / "routes.rb"
        routes_content = routes_file.read_text()
        
        # Verify initial structure
        assert "Rails.application.routes.draw do" in routes_content
        assert "end" in routes_content
        
        # After injection, should have namespace :webhooks
        # (This test documents expected structure)


class TestModelAssociationInjection(TestRailsProjectFixture):
    """Test Synvert model association injection."""
    
    def test_add_model_association_generates_rewriter(self, rails_project):
        """Test that add_model_association creates valid Synvert code."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError as e:
            pytest.skip(f"Synvert unavailable: {str(e)}")
        
        result = adapter.add_model_association(
            model_name="Order",
            association_type="has_many",
            target="items",
            class_name="OrderItem",
            dependent="destroy"
        )
        
        assert isinstance(result, dict)
        assert "success" in result
    
    def test_belongs_to_association(self, rails_project):
        """Test belongs_to association injection."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # Order already has belongs_to :tenant in our fixture
        order_content = (rails_project / "app" / "models" / "order.rb").read_text()
        assert "belongs_to :tenant" in order_content
    
    def test_association_prevents_duplicates(self, rails_project):
        """Test that association injection prevents duplicates."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # First injection
        result1 = adapter.add_model_association(
            model_name="Order",
            association_type="has_many",
            target="items"
        )
        
        if result1["success"]:
            # Second injection should be idempotent (unless_exist_node)
            result2 = adapter.add_model_association(
                model_name="Order",
                association_type="has_many",
                target="items"
            )
            
            # Both should succeed (idempotent)
            assert result1["success"]
            assert result2["success"]


class TestSyntaxValidation(TestRailsProjectFixture):
    """Test Ruby syntax validation after transformations."""
    
    def test_validate_valid_ruby_file(self, rails_project):
        """Test validation of syntactically valid Ruby file."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        routes_file = rails_project / "config" / "routes.rb"
        validation = adapter.validate_ruby_syntax(routes_file)
        
        assert isinstance(validation, dict)
        assert "valid" in validation
        assert "error" in validation
        # Routes file should be valid
        assert validation["valid"] is True
    
    def test_validate_invalid_ruby_file(self, rails_project):
        """Test validation detects syntax errors."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # Create invalid Ruby file
        bad_file = rails_project / "app" / "models" / "bad_model.rb"
        bad_file.write_text("class BadModel < ApplicationRecord\n  invalid syntax here }")
        
        validation = adapter.validate_ruby_syntax(bad_file)
        
        assert isinstance(validation, dict)
        assert validation["valid"] is False
        assert validation["error"] is not None


class TestIdempotency:
    """Test that transformations are idempotent."""
    
    def test_webhook_routes_idempotent(self, rails_project):
        """Test that applying webhook routes twice produces idempotent result."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        files_before = set(rails_project.glob("**/*.rb"))
        
        # Apply twice
        result1 = adapter.add_webhook_routes()
        result2 = adapter.add_webhook_routes()
        
        # Should both succeed
        assert result1["success"] or "unless_exist_node" in str(result1)
        assert result2["success"] or "unless_exist_node" in str(result2)
        
        # Should not create duplicates
        files_after = set(rails_project.glob("**/*.rb"))
        assert len(files_after - files_before) <= 1  # At most 1 new file
    
    def test_association_idempotent(self, rails_project):
        """Test that model associations can be added idempotently."""
        try:
            adapter = SynvertAdapter(rails_project)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # Apply same association twice
        target = "items"
        for attempt in range(2):
            result = adapter.add_model_association(
                model_name="Order",
                association_type="has_many",
                target=target
            )
            # unless_exist_node prevents duplicates
            assert result["success"] or "exists" in str(result).lower()


class TestEdgeCases:
    """Test edge cases and error handling."""
    
    def test_missing_routes_file(self, tmp_path):
        """Test handling of missing routes.rb."""
        try:
            adapter = SynvertAdapter(tmp_path)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # No routes.rb - rewriter should handle gracefully
        result = adapter.add_webhook_routes()
        
        # Should either fail gracefully or have guards in rewriter
        assert isinstance(result, dict)
        assert "success" in result
    
    def test_missing_model_file(self, tmp_path):
        """Test handling of missing model file."""
        try:
            adapter = SynvertAdapter(tmp_path)
        except RuntimeError:
            pytest.skip("Synvert unavailable")
        
        # Model file doesn't exist
        result = adapter.add_model_association(
            model_name="NonExistent",
            association_type="has_many",
            target="items"
        )
        
        # Should handle gracefully
        assert isinstance(result, dict)
        assert "success" in result


# CLI Integration Test Example
def test_feature_injection_flow_example():
    """
    Example: How to use SynvertAdapter from foundry/actions/features.py
    
    This demonstrates the integration pattern used in the actual stack-cli.
    """
    # In features.py:
    # from foundry.tools.synvert_adapter import SynvertAdapter
    # 
    # def _inject_rails_commerce_routes(path: Path):
    #     try:
    #         adapter = SynvertAdapter(path)
    #         result = adapter.add_webhook_routes(...)
    #         if result['success']:
    #             console.print("✓ Routes injected via Synvert")
    #     except RuntimeError as e:
    #         console.print(f"⚠ Synvert unavailable: {e}")
    #         # Fall back to string-based injection
    pass
