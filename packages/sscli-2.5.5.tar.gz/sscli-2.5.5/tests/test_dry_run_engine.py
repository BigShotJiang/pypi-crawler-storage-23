"""
Comprehensive tests for the Dry-Run Engine (Phase 2).

Tests:
- Single file transformation preview
- Multi-file batch preview
- Diff generation for various scenarios
- JSON export
- Statistics generation
- File safety (no files actually modified)
- Error handling
"""

import pytest
import tempfile
import json
from pathlib import Path
from foundry.safety import (
    DryRunEngine,
    DryRunResult,
    FileModification,
    DryRunCodemodWrapper,
)


class TestFileModification:
    """Tests for FileModification dataclass."""
    
    def test_file_modification_creation(self):
        """Test creating a FileModification."""
        mod = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new",
            changes_made=1
        )
        assert mod.file_path == "test.py"
        assert mod.original_content == "old"
        assert mod.modified_content == "new"
        assert mod.success is True
        assert mod.error is None
    
    def test_file_modification_with_error(self):
        """Test FileModification with error."""
        mod = FileModification(
            file_path="test.py",
            original_content="",
            modified_content="",
            error="Custom error"
        )
        assert mod.success is False
        assert mod.error == "Custom error"
        assert mod.has_changes() is False
    
    def test_has_changes_detection(self):
        """Test change detection."""
        # No changes
        mod1 = FileModification(
            file_path="test.py",
            original_content="same",
            modified_content="same"
        )
        assert mod1.has_changes() is False
        
        # Has changes
        mod2 = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new"
        )
        assert mod2.has_changes() is True
    
    def test_line_stats_calculation(self):
        """Test line addition/removal calculation."""
        mod = FileModification(
            file_path="test.py",
            original_content="line1\nline2\nline3\n",
            modified_content="line1\nline2_modified\nline3\nline4\n"
        )
        added, removed = mod.get_line_stats()
        assert added > 0  # Should have added line4
        assert removed > 0  # Should have removed or modified line2
    
    def test_as_dict_conversion(self):
        """Test conversion to dictionary."""
        mod = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new",
            changes_made=1
        )
        d = mod.as_dict()
        assert d["file_path"] == "test.py"
        assert d["success"] is True
        assert d["changes_made"] == 1
        assert "lines_added" in d
        assert "lines_removed" in d


class TestDryRunResult:
    """Tests for DryRunResult aggregation."""
    
    def test_result_creation(self):
        """Test creating a DryRunResult."""
        result = DryRunResult()
        assert result.total_files == 0
        assert result.successful_files == 0
        assert result.failed_files == 0
    
    def test_add_modification(self):
        """Test adding modifications to result."""
        result = DryRunResult()
        
        mod = FileModification(
            file_path="test.py",
            original_content="old",
            modified_content="new",
            changes_made=1
        )
        result.add_modification(mod)
        
        assert result.total_files == 1
        assert result.successful_files == 1
        assert result.failed_files == 0
        assert result.total_changes == 1
    
    def test_add_failed_modification(self):
        """Test adding failed modification."""
        result = DryRunResult()
        
        mod = FileModification(
            file_path="test.py",
            original_content="",
            modified_content="",
            error="Parse error",
            success=False
        )
        result.add_modification(mod)
        
        assert result.total_files == 1
        assert result.successful_files == 0
        assert result.failed_files == 1
    
    def test_get_summary(self):
        """Test summary statistics."""
        result = DryRunResult()
        
        mod1 = FileModification(
            file_path="test1.py",
            original_content="old",
            modified_content="new",
            changes_made=1
        )
        mod2 = FileModification(
            file_path="test2.py",
            original_content="same",
            modified_content="same"
        )
        
        result.add_modification(mod1)
        result.add_modification(mod2)
        
        summary = result.get_summary()
        assert summary["total_files"] == 2
        assert summary["successful_files"] == 2
        assert summary["files_with_changes"] == 1  # Only one has actual changes
    
    def test_get_files_with_changes(self):
        """Test filtering files with actual changes."""
        result = DryRunResult()
        
        # File with changes
        mod1 = FileModification(
            file_path="test1.py",
            original_content="old",
            modified_content="new"
        )
        # File without changes
        mod2 = FileModification(
            file_path="test2.py",
            original_content="same",
            modified_content="same"
        )
        
        result.add_modification(mod1)
        result.add_modification(mod2)
        
        changed = result.get_files_with_changes()
        assert len(changed) == 1
        assert changed[0].file_path == "test1.py"


class TestDryRunEngine:
    """Tests for the main DryRunEngine."""
    
    def test_engine_creation(self):
        """Test creating a DryRunEngine."""
        engine = DryRunEngine()
        assert engine.result.total_files == 0
        assert engine.has_changes() is False
        assert engine.has_errors() is False
    
    def test_single_file_preview(self):
        """Test previewing a single file transformation."""
        engine = DryRunEngine()
        
        mod = engine.preview_transformation(
            Path("test.py"),
            original_content="def hello():\n    pass\n",
            modified_content="def hello():\n    print('hello')\n",
            changes_made=1
        )
        
        assert mod.success is True
        assert engine.result.total_files == 1
        assert engine.has_changes() is True
    
    def test_multiple_file_preview(self):
        """Test previewing multiple file transformations."""
        engine = DryRunEngine()
        
        for i in range(3):
            engine.preview_transformation(
                Path(f"test{i}.py"),
                original_content="old",
                modified_content="new" if i < 2 else "old",  # Last one unchanged
                changes_made=1
            )
        
        assert engine.result.total_files == 3
        assert len(engine.result.get_files_with_changes()) == 2
    
    def test_unified_diff_format(self):
        """Test unified diff generation."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="line1\nline2\nline3\n",
            modified_content="line1\nline2_modified\nline3\n",
            changes_made=1
        )
        
        diff = engine.as_unified_diff()
        
        # Unified diff should contain standard headers
        assert "---" in diff
        assert "+++" in diff
        assert "-line2" in diff
        assert "+line2_modified" in diff
    
    def test_unified_diff_with_multiple_files(self):
        """Test unified diff with multiple files."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("file1.py"),
            original_content="a\nb\nc\n",
            modified_content="a\nb_modified\nc\n"
        )
        engine.preview_transformation(
            Path("file2.py"),
            original_content="x\ny\nz\n",
            modified_content="x\ny_modified\nz\n"
        )
        
        diff = engine.as_unified_diff()
        
        # Should contain both files
        assert "file1.py" in diff
        assert "file2.py" in diff
    
    def test_json_export_without_content(self):
        """Test JSON export without full content."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="old",
            modified_content="new"
        )
        
        json_output = engine.as_json(include_content=False)
        data = json.loads(json_output)
        
        assert "summary" in data
        assert "modifications" in data
        assert data["summary"]["total_files"] == 1
        assert "original_content" not in data["modifications"][0]
    
    def test_json_export_with_content(self):
        """Test JSON export with full content."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="old content",
            modified_content="new content"
        )
        
        json_output = engine.as_json(include_content=True)
        data = json.loads(json_output)
        
        assert data["modifications"][0]["original_content"] == "old content"
        assert data["modifications"][0]["modified_content"] == "new content"
    
    def test_stats_output_default(self):
        """Test default stats output."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="a\nb\nc\n",
            modified_content="a\nb_modified\nline_added\nc\n"
        )
        
        stats = engine.as_stats(verbose=False)
        
        assert "STATISTICS" in stats
        assert "Files with Changes" in stats
        assert "Lines Added" in stats
        assert "Lines Removed" in stats
    
    def test_stats_output_verbose(self):
        """Test verbose stats output."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="a\nb\n",
            modified_content="a\nb_modified\nc\n"
        )
        
        stats = engine.as_stats(verbose=True)
        
        assert "test.py" in stats
        assert "PER-FILE" in stats or "BREAKDOWN" in stats
    
    def test_stats_with_errors(self):
        """Test stats output with errors."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="",
            modified_content="",
            error="Parse error"
        )
        
        stats = engine.as_stats()
        
        assert "ERRORS" in stats
        assert "Parse error" in stats
    
    def test_summary_line(self):
        """Test summary line generation."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test1.py"),
            original_content="a\n",
            modified_content="a\nb\n"
        )
        engine.preview_transformation(
            Path("test2.py"),
            original_content="x\n",
            modified_content="x\ny\n"
        )
        
        summary = engine.get_summary_line()
        
        # Should contain file count and line changes
        assert "files" in summary or "Files" in summary.lower()
        assert "2" in summary  # 2 files with changes
    
    def test_no_changes_detected(self):
        """Test when no changes are made."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="same",
            modified_content="same"
        )
        
        assert engine.has_changes() is False
        assert engine.has_errors() is False
    
    def test_error_detection(self):
        """Test error detection."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="",
            modified_content="",
            error="Some error"
        )
        
        assert engine.has_errors() is True
    
    def test_batch_preview_with_glob(self):
        """Test batch preview with file globbing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            
            # Create test files
            (tmppath / "file1.py").write_text("old1")
            (tmppath / "file2.py").write_text("old2")
            
            engine = DryRunEngine()
            
            def simple_codemod(file_path: Path, content: str):
                """Simple transformation for testing."""
                if "old" in content:
                    return (content.replace("old", "new"), None)
                return (None, None)  # Skip if no match
            
            result = engine.preview_all(tmppath, simple_codemod)
            
            # Should process both files
            assert result.total_files == 2
            # Only files with actual changes are counted in files_with_changes
            assert result.successful_files == 2
    
    def test_batch_preview_nonexistent_path(self):
        """Test batch preview with nonexistent path."""
        engine = DryRunEngine()
        
        def dummy_codemod(file_path: Path, content: str):
            return (content, None)
        
        result = engine.preview_all(
            Path("/nonexistent/path"),
            dummy_codemod
        )
        
        assert result.failed_files > 0
        assert engine.has_errors() is True
    
    def test_diff_skipability(self):
        """Test that diff output can be piped to tools."""
        engine = DryRunEngine()
        
        engine.preview_transformation(
            Path("test.py"),
            original_content="def foo():\n    pass\n",
            modified_content="def foo():\n    print('modified')\n"
        )
        
        diff = engine.as_unified_diff()
        
        # Unified diff should be patchable
        # Can't actually test pipability here, but check format is correct
        lines = diff.split('\n')
        diff_lines = [l for l in lines if l.startswith('---') or l.startswith('+++')]
        assert len(diff_lines) >= 2


class TestDryRunCodemodWrapper:
    """Tests for the codemod wrapper."""
    
    def test_wrapper_creation(self):
        """Test creating a wrapper (mock codemod for testing)."""
        engine = DryRunEngine()
        
        # Using a mock codemod class
        class MockCodemod:
            def apply(self, path):
                from foundry.codemods.base import ModificationResult
                return ModificationResult(success=True,修改_path=path, changes_made=1)
        
        # This should not raise an error
        wrapper = DryRunCodemodWrapper(engine, MockCodemod)
        assert wrapper.engine is engine
        assert wrapper.codemod_class is MockCodemod


class TestDryRunIntegration:
    """Integration tests for dry-run features."""
    
    def test_full_workflow_single_file(self):
        """Test complete dry-run workflow for single file."""
        engine = DryRunEngine()
        
        # Preview transformation
        engine.preview_transformation(
            Path("config.toml"),
            original_content="[tool]\nversion = '1.0.0'\n",
            modified_content="[tool]\nversion = '1.0.1'\n",
            changes_made=1
        )
        
        # Check results
        assert engine.has_changes()
        assert not engine.has_errors()
        
        # Export formats
        assert engine.as_unified_diff()
        assert engine.as_json()
        assert engine.as_stats()
    
    def test_full_workflow_multiple_files(self):
        """Test complete dry-run workflow for multiple files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            
            engine = DryRunEngine()
            
            # Add multiple previews
            for i in range(5):
                engine.preview_transformation(
                    Path(f"file{i}.py"),
                    original_content=f"version = {i}",
                    modified_content=f"version = {i+1}",
                    changes_made=1
                )
            
            # Verify aggregation
            summary = engine.result.get_summary()
            assert summary["total_files"] == 5
            assert summary["files_with_changes"] == 5
            
            # Verify all output formats work
            diff = engine.as_unified_diff()
            assert len(diff) > 100  # Non-trivial output
            
            json_data = json.loads(engine.as_json())
            assert len(json_data["modifications"]) == 5
            
            stats = engine.as_stats()
            assert "5" in stats  # Should mention 5 files
