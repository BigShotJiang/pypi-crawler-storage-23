"""
Comprehensive tests for GitGuard safety mechanism.
Tests clean repo detection, dirty repo detection, and various git states.
"""

import subprocess
import tempfile
from pathlib import Path
import pytest

from foundry.safety import GitGuard, GitGuardConfig, GitStatusError


class TestGitGuardBasics:
    """Test fundamental GitGuard operations."""

    def test_not_git_repo(self, tmp_path):
        """Test detection when not in a git repository."""
        guard = GitGuard(cwd=tmp_path)
        assert guard.is_git_repo() is False

    def test_is_git_repo(self, tmp_path):
        """Test detection of valid git repository."""
        # Initialize git repo
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        assert guard.is_git_repo() is True

    def test_get_git_root(self, tmp_path):
        """Test finding git root directory."""
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        root = guard.get_git_root()
        assert root == tmp_path

    def test_get_git_root_not_repo(self, tmp_path):
        """Test get_git_root returns None when not in repo."""
        guard = GitGuard(cwd=tmp_path)
        assert guard.get_git_root() is None


class TestGitStatusSummary:
    """Test git status summary functionality."""

    def setup_repo(self, tmp_path):
        """Helper to setup a basic git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        # Configure git user
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        return tmp_path

    def test_clean_repo(self, tmp_path):
        """Test status of a clean repository."""
        tmp_path = self.setup_repo(tmp_path)

        # Create and commit a file
        file_path = tmp_path / "test.txt"
        file_path.write_text("content")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        status = guard.get_status_summary()

        assert status["is_git_repo"] is True
        assert status["is_clean"] is True
        assert len(status["staged_files"]) == 0
        assert len(status["unstaged_files"]) == 0
        assert len(status["untracked_files"]) == 0
        assert len(status["merge_conflicts"]) == 0

    def test_untracked_files(self, tmp_path):
        """Test detection of untracked files."""
        tmp_path = self.setup_repo(tmp_path)

        # Create untracked file
        (tmp_path / "untracked.txt").write_text("content")

        guard = GitGuard(cwd=tmp_path)
        status = guard.get_status_summary()

        assert status["is_git_repo"] is True
        assert status["is_clean"] is False
        assert "untracked.txt" in status["untracked_files"]

    def test_staged_changes(self, tmp_path):
        """Test detection of staged changes."""
        tmp_path = self.setup_repo(tmp_path)

        # Create and commit initial file
        file_path = tmp_path / "test.txt"
        file_path.write_text("original")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        # Modify and stage
        file_path.write_text("modified")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        status = guard.get_status_summary()

        assert status["is_clean"] is False
        assert "test.txt" in status["staged_files"]

    def test_unstaged_changes(self, tmp_path):
        """Test detection of unstaged changes."""
        tmp_path = self.setup_repo(tmp_path)

        # Create and commit initial file
        file_path = tmp_path / "test.txt"
        file_path.write_text("original")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        # Modify without staging
        file_path.write_text("modified")

        guard = GitGuard(cwd=tmp_path)
        status = guard.get_status_summary()

        assert status["is_clean"] is False
        assert "test.txt" in status["unstaged_files"]


class TestStatusClean:
    """Test status_clean method."""

    def setup_repo(self, tmp_path):
        """Helper to setup a basic git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        return tmp_path

    def test_clean_repo_returns_true(self, tmp_path):
        """Test status_clean returns True for clean repo."""
        tmp_path = self.setup_repo(tmp_path)

        file_path = tmp_path / "test.txt"
        file_path.write_text("content")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        is_clean, message = guard.status_clean()

        assert is_clean is True
        assert "clean" in message.lower()

    def test_dirty_repo_returns_false(self, tmp_path):
        """Test status_clean returns False for dirty repo."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked.txt").write_text("content")

        guard = GitGuard(cwd=tmp_path)
        is_clean, message = guard.status_clean()

        assert is_clean is False
        assert "uncommitted" in message.lower() or "untracked" in message.lower()

    def test_not_git_repo_returns_false(self, tmp_path):
        """Test status_clean returns False when not in git repo."""
        guard = GitGuard(cwd=tmp_path)
        is_clean, message = guard.status_clean()

        assert is_clean is False
        assert "not" in message.lower() and "git" in message.lower()

    def test_message_includes_issue_details(self, tmp_path):
        """Test that message includes details about issues."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked1.txt").write_text("content1")
        (tmp_path / "untracked2.txt").write_text("content2")

        guard = GitGuard(cwd=tmp_path)
        is_clean, message = guard.status_clean()

        assert is_clean is False
        assert "2" in message  # Should mention count of untracked files


class TestRequireCleanStatus:
    """Test require_clean_status method."""

    def setup_repo(self, tmp_path):
        """Helper to setup a basic git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        return tmp_path

    def test_raises_on_dirty_repo(self, tmp_path):
        """Test require_clean_status raises on dirty repo."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked.txt").write_text("content")

        guard = GitGuard(cwd=tmp_path)

        with pytest.raises(GitStatusError):
            guard.require_clean_status()

    def test_no_raise_on_clean_repo(self, tmp_path):
        """Test require_clean_status doesn't raise on clean repo."""
        tmp_path = self.setup_repo(tmp_path)

        file_path = tmp_path / "test.txt"
        file_path.write_text("content")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        guard = GitGuard(cwd=tmp_path)
        # Should not raise
        guard.require_clean_status()

    def test_exception_contains_helpful_message(self, tmp_path):
        """Test exception message is helpful."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked.txt").write_text("content")

        guard = GitGuard(cwd=tmp_path)

        with pytest.raises(GitStatusError) as exc_info:
            guard.require_clean_status()

        assert "uncommitted" in str(exc_info.value).lower()


class TestGitGuardConfig:
    """Test GitGuardConfig options."""

    def setup_repo(self, tmp_path):
        """Helper to setup a basic git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=str(tmp_path),
            capture_output=True,
        )
        return tmp_path

    def test_allow_untracked_files(self, tmp_path):
        """Test allow_untracked configuration."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked.txt").write_text("content")

        config = GitGuardConfig(allow_untracked=True)
        guard = GitGuard(cwd=tmp_path, config=config)

        is_clean, message = guard.status_clean()
        assert is_clean is True

    def test_allow_unstaged_changes(self, tmp_path):
        """Test allow_unstaged configuration."""
        tmp_path = self.setup_repo(tmp_path)

        file_path = tmp_path / "test.txt"
        file_path.write_text("original")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        file_path.write_text("modified")

        config = GitGuardConfig(allow_unstaged=True)
        guard = GitGuard(cwd=tmp_path, config=config)

        is_clean, message = guard.status_clean()
        assert is_clean is True

    def test_allow_staged_changes(self, tmp_path):
        """Test allow_staged configuration."""
        tmp_path = self.setup_repo(tmp_path)

        file_path = tmp_path / "test.txt"
        file_path.write_text("original")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        file_path.write_text("modified")
        subprocess.run(
            ["git", "add", "test.txt"],
            cwd=str(tmp_path),
            capture_output=True,
            check=True,
        )

        config = GitGuardConfig(allow_staged=True)
        guard = GitGuard(cwd=tmp_path, config=config)

        is_clean, message = guard.status_clean()
        assert is_clean is True

    def test_default_config_is_strict(self, tmp_path):
        """Test that default config is strict (not allowing any changes)."""
        tmp_path = self.setup_repo(tmp_path)

        (tmp_path / "untracked.txt").write_text("content")

        guard = GitGuard(cwd=tmp_path)  # Default config
        is_clean, message = guard.status_clean()

        assert is_clean is False


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_timeout_handling(self, tmp_path):
        """Test handling of git command timeout."""
        guard = GitGuard(cwd=tmp_path)
        # Should not crash even if git command times out
        # (handled gracefully in is_git_repo)
        result = guard.is_git_repo()
        assert isinstance(result, bool)

    def test_invalid_git_dir(self, tmp_path):
        """Test handling of invalid git directory."""
        guard = GitGuard(cwd=tmp_path / "nonexistent")
        # Should handle gracefully
        assert guard.is_git_repo() is False

    def test_status_summary_with_non_repo(self, tmp_path):
        """Test get_status_summary with non-git directory."""
        guard = GitGuard(cwd=tmp_path)
        status = guard.get_status_summary()

        assert status["is_git_repo"] is False
        assert status["is_clean"] is False
