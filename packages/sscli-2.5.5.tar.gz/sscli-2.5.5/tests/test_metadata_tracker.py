"""
Comprehensive tests for the Metadata Tracker (Phase 3).

Tests:
- Metadata creation and initialization
- Metadata reading and writing
- Feature tracking (add/remove)
- Modification tracking
- Version updates and upgrade history
- Schema validation
- Status reporting
"""

import pytest
import tempfile
import json
from pathlib import Path
from datetime import datetime
from foundry.metadata import (
    ProjectMetadata,
    MetadataTracker,
    ModificationRecord,
    UpgradeRecord,
)


class TestModificationRecord:
    """Tests for ModificationRecord dataclass."""

    def test_modification_record_creation(self):
        """Test creating a ModificationRecord."""
        mod = ModificationRecord(
            file="src/core/entities.py",
            reason="added custom validation"
        )
        assert mod.file == "src/core/entities.py"
        assert mod.reason == "added custom validation"
        assert mod.timestamp is not None

    def test_modification_record_to_dict(self):
        """Test converting ModificationRecord to dict."""
        mod = ModificationRecord(
            file="src/utils.py",
            reason="custom helper"
        )
        d = mod.to_dict()
        assert d["file"] == "src/utils.py"
        assert d["reason"] == "custom helper"
        assert "timestamp" in d

    def test_modification_record_from_dict(self):
        """Test creating ModificationRecord from dict."""
        d = {
            "file": "src/test.py",
            "reason": "testing",
            "timestamp": "2026-02-18T12:00:00+00:00"
        }
        mod = ModificationRecord.from_dict(d)
        assert mod.file == "src/test.py"
        assert mod.reason == "testing"


class TestUpgradeRecord:
    """Tests for UpgradeRecord dataclass."""

    def test_upgrade_record_creation(self):
        """Test creating an UpgradeRecord."""
        rec = UpgradeRecord(
            from_version="2.2.0",
            to_version="2.3.0"
        )
        assert rec.from_version == "2.2.0"
        assert rec.to_version == "2.3.0"
        assert rec.timestamp is not None
        assert rec.applied_codemods == []
        assert rec.conflicts == []

    def test_upgrade_record_with_codemods(self):
        """Test UpgradeRecord with codemod tracking."""
        rec = UpgradeRecord(
            from_version="2.1.0",
            to_version="2.2.0",
            applied_codemods=["add_feature_flag", "update_routes"],
            conflicts=["src/routes.py"]
        )
        assert len(rec.applied_codemods) == 2
        assert "add_feature_flag" in rec.applied_codemods
        assert len(rec.conflicts) == 1

    def test_upgrade_record_to_dict(self):
        """Test converting UpgradeRecord to dict."""
        rec = UpgradeRecord(
            from_version="2.0.0",
            to_version="2.1.0",
            applied_codemods=["schema_update"],
            notes="Minor version bump"
        )
        d = rec.to_dict()
        assert d["from_version"] == "2.0.0"
        assert d["to_version"] == "2.1.0"
        assert "schema_update" in d["applied_codemods"]
        assert d["notes"] == "Minor version bump"


class TestProjectMetadata:
    """Tests for ProjectMetadata dataclass."""

    def test_metadata_creation_minimal(self):
        """Test creating metadata with required fields."""
        metadata = ProjectMetadata(
            installed_template_name="python-saas",
            installed_template_version="2.3.0",
            created_at="2026-02-18T12:00:00+00:00",
            sscli_version="2.3.0"
        )
        assert metadata.installed_template_name == "python-saas"
        assert metadata.installed_template_version == "2.3.0"
        assert metadata.features_enabled == []
        assert metadata.custom_modifications == []

    def test_metadata_creation_with_features(self):
        """Test creating metadata with features."""
        metadata = ProjectMetadata(
            installed_template_name="react-client",
            installed_template_version="1.5.0",
            created_at="2026-02-18T12:00:00+00:00",
            sscli_version="2.3.0",
            features_enabled=["commerce", "auth", "email"]
        )
        assert len(metadata.features_enabled) == 3
        assert "commerce" in metadata.features_enabled

    def test_metadata_to_dict(self):
        """Test converting metadata to dict."""
        mod = ModificationRecord(file="test.py", reason="testing")
        metadata = ProjectMetadata(
            installed_template_name="python-saas",
            installed_template_version="2.3.0",
            created_at="2026-02-18T12:00:00+00:00",
            sscli_version="2.3.0",
            custom_modifications=[mod],
            project_name="test-app"
        )
        d = metadata.to_dict()
        assert d["template"] == "python-saas"
        assert d["version"] == "2.3.0"
        assert len(d["custom_modifications"]) == 1
        assert d["project_name"] == "test-app"

    def test_metadata_from_dict(self):
        """Test creating metadata from dict."""
        data = {
            "template": "rails-api",
            "version": "1.0.0",
            "created_at": "2026-02-18T12:00:00+00:00",
            "sscli_version": "2.3.0",
            "features": ["auth"],
            "custom_modifications": [],
            "project_name": "my-app",
            "notes": "Test project"
        }
        metadata = ProjectMetadata.from_dict(data)
        assert metadata.installed_template_name == "rails-api"
        assert metadata.installed_template_version == "1.0.0"
        assert metadata.project_name == "my-app"

    def test_metadata_roundtrip(self):
        """Test metadata dict roundtrip (to_dict -> from_dict)."""
        original = ProjectMetadata(
            installed_template_name="python-saas",
            installed_template_version="2.3.0",
            created_at="2026-02-18T12:00:00+00:00",
            sscli_version="2.3.0",
            features_enabled=["commerce", "auth"],
            project_name="my-project"
        )
        
        # Convert to dict and back
        data = original.to_dict()
        restored = ProjectMetadata.from_dict(data)
        
        assert restored.installed_template_name == original.installed_template_name
        assert restored.installed_template_version == original.installed_template_version
        assert restored.features_enabled == original.features_enabled


class TestMetadataTracker:
    """Tests for MetadataTracker class."""

    @pytest.fixture
    def temp_project(self):
        """Create a temporary project directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_tracker_initialization(self, temp_project):
        """Test initializing tracker for a project."""
        tracker = MetadataTracker(temp_project)
        assert tracker.project_path == temp_project
        assert tracker.metadata_dir == temp_project / ".sscli"
        assert tracker.metadata_file == temp_project / ".sscli" / "metadata.json"

    def test_init_project(self, temp_project):
        """Test initializing metadata for a new project."""
        tracker = MetadataTracker(temp_project)
        metadata = tracker.init_project(
            template_name="python-saas",
            version="2.3.0",
            features=["commerce", "auth"],
            project_name="test-app"
        )
        
        assert metadata.installed_template_name == "python-saas"
        assert metadata.installed_template_version == "2.3.0"
        assert len(metadata.features_enabled) == 2
        assert metadata.project_name == "test-app"
        assert metadata.created_at is not None
        assert tracker.metadata_file.exists()

    def test_write_and_read_project(self, temp_project):
        """Test writing and reading metadata."""
        tracker = MetadataTracker(temp_project)
        
        # Initialize and write
        original = tracker.init_project(
            template_name="react-client",
            version="1.5.0",
            features=["auth"],
            project_name="frontend"
        )
        
        # Read back
        loaded = tracker.read_project()
        assert loaded is not None
        assert loaded.installed_template_name == "react-client"
        assert loaded.installed_template_version == "1.5.0"
        assert loaded.project_name == "frontend"

    def test_read_nonexistent_project(self, temp_project):
        """Test reading from a project without metadata."""
        tracker = MetadataTracker(temp_project)
        loaded = tracker.read_project()
        assert loaded is None

    def test_metadata_file_format(self, temp_project):
        """Test that metadata is written in correct JSON format."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            template_name="python-saas",
            version="2.3.0",
            features=["commerce"]
        )
        
        # Read raw JSON
        raw = tracker.metadata_file.read_text(encoding="utf-8")
        data = json.loads(raw)
        
        assert data["template"] == "python-saas"
        assert data["version"] == "2.3.0"
        assert "features" in data
        assert "created_at" in data

    def test_update_version(self, temp_project):
        """Test updating template version."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            template_name="python-saas",
            version="2.2.0"
        )
        
        # Update version
        success = tracker.update_version("2.3.0")
        assert success is True
        
        # Verify update
        metadata = tracker.read_project()
        assert metadata.installed_template_version == "2.3.0"
        assert len(metadata.upgrade_history) == 1
        assert metadata.upgrade_history[0].from_version == "2.2.0"
        assert metadata.upgrade_history[0].to_version == "2.3.0"

    def test_update_version_with_codemods(self, temp_project):
        """Test version update with codemod tracking."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            template_name="python-saas",
            version="2.1.0"
        )
        
        # Update with codemods
        success = tracker.update_version_with_codemods(
            new_version="2.2.0",
            applied_codemods=["update_routes", "migrate_auth"],
            conflicts=["src/auth.py"],
            notes="Upgrade with auth migration"
        )
        assert success is True
        
        # Verify
        metadata = tracker.read_project()
        upgrade = metadata.upgrade_history[0]
        assert len(upgrade.applied_codemods) == 2
        assert "update_routes" in upgrade.applied_codemods
        assert "src/auth.py" in upgrade.conflicts
        assert upgrade.notes == "Upgrade with auth migration"

    def test_mark_modified(self, temp_project):
        """Test marking files as modified."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        # Mark file as modified
        success = tracker.mark_modified(
            file_path="src/core/entities.py",
            reason="added custom validation"
        )
        assert success is True
        
        # Verify
        metadata = tracker.read_project()
        assert len(metadata.custom_modifications) == 1
        assert metadata.custom_modifications[0].file == "src/core/entities.py"

    def test_mark_multiple_modifications(self, temp_project):
        """Test marking multiple files as modified."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        # Mark multiple files
        tracker.mark_modified("src/file1.py", "custom change 1")
        tracker.mark_modified("src/file2.py", "custom change 2")
        tracker.mark_modified("src/file3.py", "custom change 3")
        
        # Verify
        metadata = tracker.read_project()
        assert len(metadata.custom_modifications) == 3

    def test_mark_modified_update_existing(self, temp_project):
        """Test updating an existing modification tracking."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        # Mark file
        tracker.mark_modified("src/file.py", "reason 1")
        
        # Update same file
        tracker.mark_modified("src/file.py", "reason 2")
        
        # Should still have only one entry
        metadata = tracker.read_project()
        assert len(metadata.custom_modifications) == 1
        assert metadata.custom_modifications[0].reason == "reason 2"

    def test_clear_modifications(self, temp_project):
        """Test clearing modification tracking."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        # Add modifications
        tracker.mark_modified("src/file1.py", "change 1")
        tracker.mark_modified("src/file2.py", "change 2")
        
        # Clear specific file
        success = tracker.clear_modifications("src/file1.py")
        assert success is True
        
        metadata = tracker.read_project()
        assert len(metadata.custom_modifications) == 1
        assert metadata.custom_modifications[0].file == "src/file2.py"

    def test_clear_all_modifications(self, temp_project):
        """Test clearing all modifications."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        # Add modifications
        tracker.mark_modified("src/file1.py", "change 1")
        tracker.mark_modified("src/file2.py", "change 2")
        
        # Clear all
        success = tracker.clear_modifications()
        assert success is True
        
        metadata = tracker.read_project()
        assert len(metadata.custom_modifications) == 0

    def test_add_feature(self, temp_project):
        """Test adding a single feature."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0", features=["auth"])
        
        # Add feature
        success = tracker.add_feature("commerce")
        assert success is True
        
        metadata = tracker.read_project()
        assert "commerce" in metadata.features_enabled
        assert len(metadata.features_enabled) == 2

    def test_add_duplicate_feature(self, temp_project):
        """Test that duplicate features are not added."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0", features=["auth"])
        
        # Try to add existing feature
        tracker.add_feature("auth")
        
        metadata = tracker.read_project()
        assert metadata.features_enabled.count("auth") == 1

    def test_remove_feature(self, temp_project):
        """Test removing a feature."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            "python-saas", 
            "2.3.0", 
            features=["auth", "commerce", "email"]
        )
        
        # Remove feature
        success = tracker.remove_feature("email")
        assert success is True
        
        metadata = tracker.read_project()
        assert "email" not in metadata.features_enabled
        assert len(metadata.features_enabled) == 2

    def test_add_multiple_features(self, temp_project):
        """Test adding multiple features at once."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("react-client", "1.5.0", features=["auth"])
        
        # Add multiple features
        success = tracker.add_features(["commerce", "email", "notifications"])
        assert success is True
        
        metadata = tracker.read_project()
        assert len(metadata.features_enabled) == 4
        assert "commerce" in metadata.features_enabled
        assert "email" in metadata.features_enabled

    def test_validate_valid_metadata(self, temp_project):
        """Test validation of valid metadata."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.3.0")
        
        is_valid, errors = tracker.validate()
        assert is_valid is True
        assert len(errors) == 0

    def test_validate_missing_file(self, temp_project):
        """Test validation when metadata file doesn't exist."""
        tracker = MetadataTracker(temp_project)
        
        is_valid, errors = tracker.validate()
        assert is_valid is False
        assert len(errors) > 0
        assert "Metadata file does not exist" in errors[0]

    def test_validate_corrupted_json(self, temp_project):
        """Test validation of corrupted JSON."""
        tracker = MetadataTracker(temp_project)
        
        # Create invalid JSON
        tracker.metadata_dir.mkdir(parents=True, exist_ok=True)
        tracker.metadata_file.write_text("{ invalid json }", encoding="utf-8")
        
        is_valid, errors = tracker.validate()
        assert is_valid is False
        assert len(errors) > 0

    def test_validate_missing_required_fields(self, temp_project):
        """Test validation with missing required fields."""
        tracker = MetadataTracker(temp_project)
        tracker.metadata_dir.mkdir(parents=True, exist_ok=True)
        
        # Write incomplete metadata
        incomplete_data = {
            "template": "python-saas",
            # Missing version, created_at, sscli_version
        }
        tracker.metadata_file.write_text(
            json.dumps(incomplete_data),
            encoding="utf-8"
        )
        
        is_valid, errors = tracker.validate()
        assert is_valid is False
        assert len(errors) > 0

    def test_validate_invalid_timestamp(self, temp_project):
        """Test validation with invalid timestamp format."""
        tracker = MetadataTracker(temp_project)
        tracker.metadata_dir.mkdir(parents=True, exist_ok=True)
        
        # Write metadata with invalid timestamp
        bad_data = {
            "template": "python-saas",
            "version": "2.3.0",
            "created_at": "not-a-timestamp",
            "sscli_version": "2.3.0",
            "features": [],
            "custom_modifications": [],
            "upgrade_history": []
        }
        tracker.metadata_file.write_text(
            json.dumps(bad_data),
            encoding="utf-8"
        )
        
        is_valid, errors = tracker.validate()
        assert is_valid is False
        assert any("timestamp" in e.lower() for e in errors)

    def test_get_status(self, temp_project):
        """Test getting metadata status."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            "python-saas",
            "2.3.0",
            features=["commerce", "auth"],
            project_name="my-app"
        )
        tracker.mark_modified("src/file.py", "custom change")
        
        status = tracker.get_status()
        assert status["status"] == "valid"
        assert status["template"] == "python-saas"
        assert status["version"] == "2.3.0"
        assert status["modifications_count"] == 1
        assert len(status["features"]) == 2

    def test_get_status_no_metadata(self, temp_project):
        """Test getting status when no metadata exists."""
        tracker = MetadataTracker(temp_project)
        status = tracker.get_status()
        assert status["status"] == "no_metadata"

    def test_metadata_persistence(self, temp_project):
        """Test that metadata persists across tracker instances."""
        # Create and save with first tracker
        tracker1 = MetadataTracker(temp_project)
        tracker1.init_project("python-saas", "2.3.0", features=["auth"])
        tracker1.mark_modified("src/file.py", "change")
        
        # Load with second tracker
        tracker2 = MetadataTracker(temp_project)
        metadata = tracker2.read_project()
        
        assert metadata.installed_template_name == "python-saas"
        assert "auth" in metadata.features_enabled
        assert len(metadata.custom_modifications) == 1

    def test_upgrade_history_accumulation(self, temp_project):
        """Test that upgrade history accumulates over time."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project("python-saas", "2.0.0")
        
        # Multiple upgrades
        tracker.update_version("2.1.0")
        tracker.update_version("2.2.0")
        tracker.update_version("2.3.0")
        
        metadata = tracker.read_project()
        assert len(metadata.upgrade_history) == 3
        assert metadata.upgrade_history[0].from_version == "2.0.0"
        assert metadata.upgrade_history[2].to_version == "2.3.0"

    def test_different_project_paths(self):
        """Test tracker with different project paths."""
        with tempfile.TemporaryDirectory() as tmpdir1:
            with tempfile.TemporaryDirectory() as tmpdir2:
                path1 = Path(tmpdir1)
                path2 = Path(tmpdir2)
                
                # Create metadata in project 1
                tracker1 = MetadataTracker(path1)
                tracker1.init_project("python-saas", "2.3.0")
                
                # Create metadata in project 2
                tracker2 = MetadataTracker(path2)
                tracker2.init_project("react-client", "1.5.0")
                
                # Verify isolation
                assert tracker1.read_project().installed_template_name == "python-saas"
                assert tracker2.read_project().installed_template_name == "react-client"


class TestMetadataIntegration:
    """Integration tests for metadata system."""

    @pytest.fixture
    def temp_project(self):
        """Create a temporary project directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_full_project_lifecycle(self, temp_project):
        """Test a complete project lifecycle with metadata."""
        tracker = MetadataTracker(temp_project)
        
        # Initialize project
        tracker.init_project(
            template_name="python-saas",
            version="2.0.0",
            features=["auth"],
            project_name="my-app"
        )
        
        # User makes modifications
        tracker.mark_modified("src/core/entities.py", "added validation")
        tracker.mark_modified("src/routes.py", "custom endpoints")
        
        # Add features later
        tracker.add_features(["commerce", "email"])
        
        # Upgrade template
        tracker.update_version_with_codemods(
            new_version="2.1.0",
            applied_codemods=["update_auth", "new_routes"],
            conflicts=[],
            notes="Clean upgrade"
        )
        
        # Verify final state
        metadata = tracker.read_project()
        assert metadata.installed_template_version == "2.1.0"
        assert len(metadata.features_enabled) == 3
        assert len(metadata.custom_modifications) == 2
        assert len(metadata.upgrade_history) == 1

    def test_schema_compliance(self, temp_project):
        """Test that generated metadata complies with expected schema."""
        tracker = MetadataTracker(temp_project)
        tracker.init_project(
            "python-saas",
            "2.3.0",
            features=["commerce", "auth"],
            project_name="test"
        )
        
        # Read the raw JSON
        raw_json = tracker.metadata_file.read_text(encoding="utf-8")
        data = json.loads(raw_json)
        
        # Verify schema
        required_keys = [
            "template", "version", "created_at", 
            "sscli_version", "features", "custom_modifications",
            "upgrade_history"
        ]
        for key in required_keys:
            assert key in data, f"Missing required key: {key}"
        
        # Verify types
        assert isinstance(data["template"], str)
        assert isinstance(data["version"], str)
        assert isinstance(data["features"], list)
        assert isinstance(data["custom_modifications"], list)
        assert isinstance(data["upgrade_history"], list)
