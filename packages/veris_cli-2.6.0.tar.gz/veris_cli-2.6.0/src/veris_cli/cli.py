"""CLI for Veris – Connect agents to simulations."""

import os
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from importlib import resources
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import click
import httpx

from veris_cli import output, prompts, templates
from veris_cli.api import VerisAPI
from veris_cli.config import Config, ProjectConfig


def get_script_path(script_name: str) -> Path:
    """Get path to a script file from the package."""
    try:
        # Python 3.9+
        files = resources.files("veris_cli.scripts")
        return files / script_name
    except AttributeError:
        # Fallback for older Python
        import pkg_resources

        return Path(pkg_resources.resource_filename("veris_cli.scripts", script_name))


def run_script(script_name: str, *args: str) -> int:
    """Run a bash script from the package."""
    script_path = get_script_path(script_name)
    # Run with bash explicitly, don't rely on executable bit
    result = subprocess.run(["bash", str(script_path), *args], cwd=Path.cwd())
    return result.returncode


def _get_profile(ctx: click.Context) -> str | None:
    """Get profile from Click context."""
    return ctx.obj.get("profile") if ctx.obj else None


@click.group()
@click.version_option(prog_name="veris")
@click.option("--profile", default=None, help="Named profile to use (default: active profile)")
@click.pass_context
def cli(ctx, profile):
    """Veris CLI - Connect your existing agent to Veris simulations."""
    ctx.ensure_object(dict)
    ctx.obj["profile"] = profile


@cli.command()
@click.argument("api_key", required=False, default=None)
@click.option(
    "--backend-url",
    default=None,
    help="Backend URL (default: https://sandbox.api.veris.ai)",
)
@click.pass_context
def login(ctx, api_key: str | None, backend_url: str | None):
    """Authenticate with Veris via Google login or API key.

    Usage:
      veris login                     # Browser-based Google login
      veris login <api-key>           # Direct API key login (for CI/scripts)
      veris login --backend-url URL   # Specify backend URL
    """
    profile = _get_profile(ctx)
    config = Config(profile=profile)

    if backend_url:
        # Save backend URL into the profile
        profile_data = config._load_profile()
        profile_data["backend_url"] = backend_url
        config._save_profile(profile_data)

    # Direct API key login (backwards compatible, useful for CI)
    if api_key:
        effective_url = backend_url or config.get_backend_url()
        config.set_api_key(api_key, effective_url)
        output.print_success(f"API key saved to {config.config_file}")
        output.print_info(f"Backend URL: {effective_url}")
        if config.profile != "default":
            output.print_info(f"Profile: {config.profile}")
        return

    # Browser-based Google OAuth login
    effective_url = backend_url or config.get_backend_url()
    result: dict[str, str] = {}
    server_ready = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            query = parse_qs(urlparse(self.path).query)
            if "token" in query:
                result["token"] = query["token"][0]
                result["email"] = query.get("email", [""])[0]
                result["name"] = query.get("name", [""])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body style='font-family:system-ui;display:flex;"
                    b"justify-content:center;align-items:center;height:100vh;margin:0'>"
                    b"<div style='text-align:center'>"
                    b"<h2>Login successful!</h2>"
                    b"<p>You can close this tab and return to the CLI.</p>"
                    b"</div></body></html>"
                )
            else:
                error = query.get("error", ["Unknown error"])[0]
                result["error"] = error
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    f"<html><body><h2>Login failed: {error}</h2></body></html>".encode()
                )

        def log_message(self, *args):
            pass  # Suppress request logs

    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]

    def serve():
        server_ready.set()
        server.handle_request()  # Handle exactly one request then stop

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    server_ready.wait()

    login_url = f"{effective_url}/v1/auth/google/login?cli_port={port}"
    output.print_info("Opening browser to log in with Google...")
    webbrowser.open(login_url)

    # Wait for the callback (timeout after 2 minutes)
    thread.join(timeout=120)
    server.server_close()

    if "error" in result:
        output.print_error(f"Login failed: {result['error']}")
        sys.exit(1)
    elif "token" not in result:
        output.print_error("Login timed out. Please try again.")
        sys.exit(1)

    # Save credentials
    config.set_api_key(result["token"], effective_url)

    email = result.get("email", "")
    if email:
        output.print_success(f"Logged in as {email}")
    else:
        output.print_success("Logged in successfully")
    output.print_info(f"API key saved to {config.config_file}")


@cli.command()
@click.option("--name", default=None, help="Environment name (will prompt if not provided)")
@click.pass_context
def init(ctx, name: str):
    """Creates .veris/ folder and environment"""
    profile = _get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"

    # Create directory if it doesn't exist
    veris_dir.mkdir(parents=True, exist_ok=True)

    # Create files (only if they don't exist)
    dockerfile_path = veris_dir / "Dockerfile.sandbox"
    veris_yaml_path = veris_dir / "veris.yaml"
    env_sim_path = veris_dir / ".env.simulation"
    gitignore_path = veris_dir / ".gitignore"

    created_files = []

    if not dockerfile_path.exists():
        dockerfile_path.write_text(templates.get_dockerfile_sandbox())
        created_files.append("  - .veris/Dockerfile.sandbox - Docker image template")
    else:
        output.print_info("Skipping .veris/Dockerfile.sandbox (already exists)")

    if not veris_yaml_path.exists():
        veris_yaml_path.write_text(templates.get_veris_yaml())
        created_files.append("  - .veris/veris.yaml - Simulation configuration")
    else:
        output.print_info("Skipping .veris/veris.yaml (already exists)")

    if not env_sim_path.exists():
        env_sim_path.write_text(templates.get_env_simulation())
        created_files.append("  - .veris/.env.simulation - Environment variables")
    else:
        output.print_info("Skipping .veris/.env.simulation (already exists)")

    if not gitignore_path.exists():
        gitignore_path.write_text(templates.get_gitignore())
        created_files.append("  - .veris/.gitignore - Git ignore rules")
    else:
        output.print_info("Skipping .veris/.gitignore (already exists)")

    # Create .dockerignore at project root (used by `veris env push`)
    dockerignore_path = Path.cwd() / ".dockerignore"
    if not dockerignore_path.exists():
        dockerignore_path.write_text(templates.get_dockerignore())
        created_files.append("  - .dockerignore - Build context exclusions for `veris env push`")
    else:
        output.print_info("Skipping .dockerignore (already exists)")

    if created_files:
        output.print_success("Created files:")
        for file in created_files:
            output.print_info(file)

    # Check if environment already exists in project config
    project_config = ProjectConfig(profile=profile)
    existing_env_id = project_config.get_environment_id()

    if existing_env_id:
        existing_name = project_config._load_profile().get("environment_name", "unknown")
        output.print_info(f"Environment already configured: {existing_env_id} ({existing_name})")
        if not prompts.confirm_action("Re-create environment?", default=False):
            return

    # Prompt for environment name
    if not name:
        name = prompts.prompt_environment_name()
        if not name:
            output.print_error("Environment name is required")
            sys.exit(1)

    # Create environment on the backend
    output.print_info(f"\nCreating environment '{name}'...")
    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment(name=name)

        environment = result.get("environment", {})
        env_id = environment.get("id")

        if not env_id:
            output.print_error("Failed to get environment ID from response")
            sys.exit(1)

        # Save environment ID to project config only on success
        project_config.set_environment_id(env_id, name)

        output.print_success(f"Environment created: {env_id}")
        output.print_info("Environment ID saved to .veris/config.yaml")
        output.print_info("\nNext steps:")
        output.print_info("  1. Edit .veris/Dockerfile.sandbox to match your agent")
        output.print_info("  2. Edit .veris/veris.yaml with your agent settings")
        output.print_info("  3. Run 'veris env set KEY=VALUE --secret' to add API keys")
        output.print_info("  4. Run 'veris env push' to build and push your image")

    except ValueError as e:
        output.print_error(str(e))
        output.print_info("You can create the environment later with 'veris env push'")
    except httpx.ConnectError:
        output.print_error(
            f"Could not connect to backend at {Config(profile=profile).get_backend_url()}"
        )
        output.print_info(
            "Is the backend running? You can create the environment later with 'veris env push'"
        )
    except Exception as e:
        output.print_error(f"Failed to create environment: {e}")
        output.print_info("You can create the environment later with 'veris env push'")


# Environment commands
@cli.group()
def env():
    """Environment management commands"""
    pass


@env.command(name="build")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.option("--no-cache", is_flag=True, help="Build without using cache")
@click.pass_context
def env_build(ctx, tag: str, no_cache: bool):
    """Build Docker image locally (without pushing)"""
    profile = _get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"

    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    project_config = ProjectConfig(profile=profile)
    env_id = project_config.get_environment_id()

    if not env_id:
        output.print_error("No environment configured. Run 'veris init' first.")
        sys.exit(1)

    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment_tag(environment_id=env_id, tag=tag)

        image_uri = result.get("image_uri")
        push_creds = result.get("push_credentials", {})

        if not push_creds:
            output.print_error("No push credentials received from backend")
            sys.exit(1)

        username = push_creds.get("username", "_token")
        password = push_creds.get("password", "")
        registry = push_creds.get("registry", "us-docker.pkg.dev")

        output.print_success(f"Tag created: {tag}")
        output.print_info(f"Building image: {image_uri}\n")

        no_cache_flag = "1" if no_cache else "0"
        exit_code = run_script(
            "docker_build.sh",
            str(dockerfile),
            image_uri,
            registry,
            username,
            password,
            no_cache_flag,
        )

        if exit_code != 0:
            output.print_error("Docker build failed")
            sys.exit(exit_code)

        output.print_success(f"\nImage built: {image_uri}")
        output.print_info("Run 'veris env push' to push the image")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to build: {e}")
        sys.exit(1)


@env.command(name="push")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.option("--no-cache", is_flag=True, help="Build without using cache (local build only)")
@click.option("--remote", is_flag=True, help="Build remotely via Cloud Build instead of locally")
@click.pass_context
def env_push(ctx, tag: str, no_cache: bool, remote: bool):
    """Build and push environment image.

    By default, builds locally with Docker and pushes the image.
    Use --remote to upload the build context and build via Cloud Build instead.
    """
    profile = _get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"

    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    project_config = ProjectConfig(profile=profile)
    env_id = project_config.get_environment_id()

    if not env_id:
        output.print_error("No environment configured. Run 'veris init' first.")
        sys.exit(1)

    if remote:
        _env_push_remote(env_id, tag, profile)
    else:
        _env_push_local(env_id, tag, no_cache, dockerfile, profile)


def _env_push_local(
    env_id: str, tag: str, no_cache: bool, dockerfile: Path, profile: str | None = None
):
    """Build locally with Docker and push the image."""
    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment_tag(environment_id=env_id, tag=tag)

        image_uri = result.get("image_uri")
        push_creds = result.get("push_credentials", {})

        if not push_creds:
            output.print_error("No push credentials received from backend")
            sys.exit(1)

        username = push_creds.get("username", "_token")
        password = push_creds.get("password", "")
        registry = push_creds.get("registry", "us-docker.pkg.dev")

        output.print_success(f"Tag created: {tag}")
        output.print_info(f"Building and pushing image: {image_uri}\n")

        # Build image
        no_cache_flag = "1" if no_cache else "0"
        exit_code = run_script(
            "docker_build.sh",
            str(dockerfile),
            image_uri,
            registry,
            username,
            password,
            no_cache_flag,
        )
        if exit_code != 0:
            output.print_error("Docker build failed")
            sys.exit(exit_code)

        # Push image
        output.print_info("\nPushing image...\n")
        exit_code = run_script("docker_push.sh", image_uri, registry, username, password)

        if exit_code != 0:
            output.print_error("Docker push failed")
            sys.exit(exit_code)

        output.print_success(f"\nImage pushed: {image_uri}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to push: {e}")
        sys.exit(1)


def _env_push_remote(env_id: str, tag: str, profile: str | None = None):
    """Upload build context and build via Cloud Build."""
    tarball_path = None
    try:
        from veris_cli.build_context import create_build_context

        # 1. Create build context tarball
        output.print_info("Packaging build context...")
        tarball_path, size = create_build_context(Path.cwd())
        size_mb = size / 1024 / 1024
        output.print_success(f"Build context: {size_mb:.1f} MB")

        # 2. Create build on backend → get signed upload URL
        api = VerisAPI(profile=profile)
        build_result = api.create_build(environment_id=env_id, tag=tag)
        build_id = build_result["build_id"]
        upload_url = build_result["upload_url"]

        # 3. Upload tarball to signed URL
        output.print_info("Uploading build context...")
        with open(tarball_path, "rb") as f:
            upload_resp = httpx.put(
                upload_url,
                content=f,
                headers={"Content-Type": "application/gzip"},
                timeout=300,
            )
        if upload_resp.status_code not in (200, 201):
            output.print_error(f"Upload failed: {upload_resp.status_code} {upload_resp.text}")
            sys.exit(1)
        output.print_success("Upload complete")

        # 4. Trigger Cloud Build
        output.print_info("Starting Cloud Build...")
        api.notify_build_uploaded(environment_id=env_id, build_id=build_id)

        # 5. Poll until complete or failed
        from rich.console import Console
        from rich.live import Live
        from rich.spinner import Spinner

        console = Console()
        with Live(Spinner("dots", text="Building image..."), console=console, refresh_per_second=4):
            while True:
                time.sleep(2)
                status_result = api.get_build_status(environment_id=env_id, build_id=build_id)
                status = status_result.get("status", "")

                if status == "complete":
                    break
                elif status == "failed":
                    error = status_result.get("error", "Unknown error")
                    output.print_error(f"Build failed: {error}")
                    sys.exit(1)

        image_uri = status_result.get("image_uri", "")
        output.print_success(f"Image pushed: {image_uri}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to push: {e}")
        sys.exit(1)
    finally:
        if tarball_path:
            tarball_path.unlink(missing_ok=True)


@env.command(name="set")
@click.argument("key_values", nargs=-1, required=True)
@click.option("--secret", is_flag=True, help="Mark all values as secret (encrypted at rest)")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def env_set(ctx, key_values: tuple[str, ...], secret: bool, env_id: str):
    """Set environment variables (injected into pods at runtime).

    Pass one or more KEY=VALUE pairs:

      veris env set OPENAI_API_KEY=sk-... --secret
      veris env set DB_HOST=localhost DB_PORT=5432
    """
    profile = _get_profile(ctx)
    # Parse KEY=VALUE pairs
    variables = []
    for item in key_values:
        if "=" not in item:
            output.print_error(f"Invalid format: '{item}'. Expected KEY=VALUE.")
            sys.exit(1)
        key, _, value = item.partition("=")
        key = key.strip()
        if not key:
            output.print_error(f"Empty key in: '{item}'")
            sys.exit(1)
        variables.append({"key": key, "value": value, "is_secret": secret})

    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        if not env_id:
            output.print_error("No environment configured. Use --env-id or run 'veris init' first.")
            sys.exit(1)

        result = api.upsert_environment_variables(env_id, variables)
        count = len(result.get("variables", []))
        output.print_success(f"{count} variable(s) saved to environment {env_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to set variables: {e}")
        sys.exit(1)


@env.command(name="vars")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def env_vars(ctx, env_id: str):
    """List environment variables"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        if not env_id:
            output.print_error("No environment configured. Use --env-id or run 'veris init' first.")
            sys.exit(1)

        result = api.list_environment_variables(env_id)
        output.print_environment_variables_table(result.get("variables", []))

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list variables: {e}")
        sys.exit(1)


@env.command(name="rm")
@click.argument("key")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def env_rm(ctx, key: str, env_id: str):
    """Remove an environment variable by key.

    Example: veris env rm OPENAI_API_KEY
    """
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        if not env_id:
            output.print_error("No environment configured. Use --env-id or run 'veris init' first.")
            sys.exit(1)

        api.delete_environment_variable(env_id, key)
        output.print_success(f"Variable '{key}' removed from environment {env_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to remove variable: {e}")
        sys.exit(1)


@env.command(name="list")
@click.option("--status", default=None, help="Filter by status (e.g., ready)")
@click.pass_context
def env_list(ctx, status: str):
    """List environments"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        result = api.list_environments(status=status)
        output.print_environments_table(result.get("environments", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list environments: {e}")
        sys.exit(1)


# Scenario commands
@cli.group()
def scenarios():
    """Scenario management commands"""
    pass


@scenarios.command(name="list")
@click.option("--env-id", default=None, help="Filter by environment ID")
@click.pass_context
def scenarios_list(ctx, env_id: str):
    """List scenarios"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        result = api.list_scenario_sets(environment_id=env_id)
        output.print_scenario_sets_table(result)
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list scenarios: {e}")
        sys.exit(1)


@scenarios.command(name="generate")
@click.option("--env-id", default=None, help="Environment ID")
@click.option("--num", default=5, help="Number of scenarios to generate (default: 5)")
@click.option("--image-tag", default=None, help="Image tag to use (default: latest)")
@click.pass_context
def scenarios_generate(ctx, env_id: str, num: int, image_tag: str):
    """Generate scenarios + grader via K8s job.

    Launches an async job that explores your agent code, generates test
    scenarios and a grader definition. Poll with 'veris scenarios list'
    to check when generation is complete.
    """
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        if not env_id:
            result = api.list_environments(status="ready")
            env_id = prompts.select_environment(result.get("environments", []))
            if not env_id:
                output.print_error("No environment selected")
                sys.exit(1)

        output.print_info(f"Generating {num} scenario(s) for environment {env_id}...")
        result = api.generate_scenario_set(
            environment_id=env_id,
            num_scenarios=num,
            image_tag=image_tag,
        )

        set_id = result.get("id", "")
        output.print_success(f"Scenario generation started: {set_id}")
        output.print_info("Status: generating")
        output.print_info("Poll with 'veris scenarios list' to check when generation is complete")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to generate scenarios: {e}")
        sys.exit(1)


# Run commands
@cli.group()
def run():
    """Run management commands"""
    pass


@run.command(name="create")
@click.option("--scenario-set-id", default=None, help="Scenario set ID")
@click.option("--env-id", default=None, help="Environment ID")
@click.option("--concurrency", default=10, help="Parallel jobs per scenario (default: 10)")
@click.option(
    "--simulation-timeout",
    default=None,
    type=int,
    help="Simulation timeout in seconds (60-3600)",
)
@click.pass_context
def run_create(ctx, scenario_set_id: str, env_id: str, concurrency: int, simulation_timeout: int):
    """Create a new run (interactive if flags omitted)"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        # Interactive mode if flags are missing
        if not scenario_set_id:
            result = api.list_scenario_sets()
            scenario_set_id = prompts.select_scenario(result)
            if not scenario_set_id:
                output.print_error("No scenario selected")
                sys.exit(1)

        if not env_id:
            result = api.list_environments(status="ready")
            env_id = prompts.select_environment(result.get("environments", []))
            if not env_id:
                output.print_error("No environment selected")
                sys.exit(1)

        if not scenario_set_id or not env_id:
            concurrency = prompts.prompt_concurrency(default=concurrency)

        # Build optional config
        config = {}
        if simulation_timeout is not None:
            config["simulation_timeout"] = simulation_timeout

        # Create run
        result = api.create_run(
            scenario_set_id=scenario_set_id,
            environment_id=env_id,
            parallel_jobs=concurrency,
            config=config or None,
        )

        run_id = result.get("id")
        output.print_success(f"Run created: {run_id}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create run: {e}")
        sys.exit(1)


@run.command(name="status")
@click.argument("run_id")
@click.option("--watch", is_flag=True, help="Poll every 3 seconds")
@click.pass_context
def run_status(ctx, run_id: str, watch: bool):
    """Get run status"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            from rich.live import Live

            with Live(console=output.console, refresh_per_second=1) as live:
                while True:
                    run_data = api.get_run(run_id)
                    live.update(output.build_run_details_group(run_data))

                    status = run_data.get("status", "")
                    if status in ["completed", "failed", "cancelled"]:
                        break

                    time.sleep(3)

            # Print final state so it persists after Live clears
            output.print_run_details(run_data)
        else:
            run_data = api.get_run(run_id)
            output.print_run_details(run_data)

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get run status: {e}")
        sys.exit(1)


@run.command(name="logs")
@click.argument("run_id")
@click.option("--follow", is_flag=True, help="Poll for new events")
@click.pass_context
def run_logs(ctx, run_id: str, follow: bool):
    """Get run logs/events"""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if follow:
            last_count = 0
            while True:
                result = api.get_run_events(run_id)
                events = result.get("events", [])
                new_events = events[last_count:]

                if new_events:
                    output.print_run_events(new_events)
                    last_count = len(events)

                time.sleep(3)
        else:
            result = api.get_run_events(run_id)
            output.print_run_events(result.get("events", []))

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get run logs: {e}")
        sys.exit(1)


@run.command(name="cancel")
@click.argument("run_id")
@click.pass_context
def run_cancel(ctx, run_id: str):
    """Cancel a run"""
    profile = _get_profile(ctx)
    try:
        if not prompts.confirm_action(f"Cancel run {run_id}?", default=False):
            output.print_info("Cancelled")
            return

        api = VerisAPI(profile=profile)
        api.cancel_run(run_id)
        output.print_success(f"Run {run_id} cancelled")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to cancel run: {e}")
        sys.exit(1)


# Evaluation-run commands
@cli.group(name="evaluation-runs")
def eval_group():
    """Evaluation run commands"""
    pass


@eval_group.command(name="create")
@click.option("--run-id", default=None, help="Run ID to evaluate")
@click.option("--grader-id", default=None, help="Grader ID to use")
@click.pass_context
def eval_create(ctx, run_id: str, grader_id: str):
    """Trigger grading on a completed run.

    Launches an async K8s grading job that evaluates every simulation
    in the run against the specified grader. Poll with 'veris eval list'
    to check progress.
    """
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not run_id:
            result = api.list_runs(status="completed")
            runs = result.get("runs", [])
            if not runs:
                output.print_error("No completed runs found")
                sys.exit(1)
            choices = [{"id": r.get("id", ""), "title": r.get("id", "")} for r in runs]
            run_id = prompts.select_from_list("Select a completed run:", choices)
            if not run_id:
                output.print_error("No run selected")
                sys.exit(1)

        if not grader_id:
            run_data = api.get_run(run_id)
            env_id = run_data.get("environment_id")
            if not env_id:
                output.print_error("Could not determine environment from run")
                sys.exit(1)
            graders_result = api.list_graders(environment_id=env_id)
            graders = graders_result.get("graders", [])
            if not graders:
                output.print_error(
                    f"No graders found for environment {env_id}. "
                    "Generate scenarios first with 'veris scenarios generate'."
                )
                sys.exit(1)
            choices = [
                {
                    "id": g.get("id", ""),
                    "title": f"{g.get('id', '')} (tags: {g.get('tags', [])})",
                }
                for g in graders
            ]
            grader_id = prompts.select_from_list("Select a grader:", choices)
            if not grader_id:
                output.print_error("No grader selected")
                sys.exit(1)

        output.print_info(f"Triggering evaluation on run {run_id} with grader {grader_id}...")
        result = api.trigger_evaluation(run_id=run_id, grader_id=grader_id)

        eval_run_id = result.get("evaluation_run_id", "")
        output.print_success(f"Evaluation started: {eval_run_id}")
        output.print_info(f"Check progress with 'veris evaluation-runs list --run-id {run_id}'")
        output.print_info(
            f"View results with 'veris evaluation-runs status --run-id {run_id} {eval_run_id}'"
        )

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create evaluation: {e}")
        sys.exit(1)


@eval_group.command(name="list")
@click.option("--run-id", required=True, help="Run ID to list evaluations for")
@click.pass_context
def eval_list(ctx, run_id: str):
    """List evaluation runs for a given run."""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        result = api.list_evaluation_runs(run_id=run_id)
        output.print_evaluation_runs_table(result.get("evaluation_runs", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list evaluations: {e}")
        sys.exit(1)


@eval_group.command(name="status")
@click.argument("eval_run_id")
@click.option("--run-id", required=True, help="Parent run ID")
@click.option("--watch", is_flag=True, help="Poll every 5 seconds until complete")
@click.pass_context
def eval_status(ctx, eval_run_id: str, run_id: str, watch: bool):
    """Get evaluation run status and results."""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            while True:
                data = api.get_evaluation_run(run_id=run_id, eval_run_id=eval_run_id)
                output.print_evaluation_run_details(data)

                status = data.get("status", "")
                if status in ["completed", "failed"]:
                    break

                time.sleep(5)
        else:
            data = api.get_evaluation_run(run_id=run_id, eval_run_id=eval_run_id)
            output.print_evaluation_run_details(data)

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get evaluation status: {e}")
        sys.exit(1)


# Eval commands (graders)
@cli.group(name="eval")
def eval_graders():
    """Eval commands (graders)"""
    pass


@eval_graders.command(name="list")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def graders_list(ctx, env_id: str):
    """List graders for an environment."""
    profile = _get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_config = ProjectConfig(profile=profile)
            env_id = project_config.get_environment_id()

        if not env_id:
            output.print_error("No environment ID. Use --env-id or run 'veris init' first.")
            sys.exit(1)

        result = api.list_graders(environment_id=env_id)
        output.print_graders_table(result.get("graders", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list graders: {e}")
        sys.exit(1)


# Profile commands
@cli.group()
def profile():
    """Manage named profiles for different environments."""
    pass


@profile.command(name="list")
def profile_list():
    """List all profiles in global config."""
    config = Config()
    profiles = config.list_profiles()
    active = config.get_active_profile() or "default"

    if not profiles:
        output.print_info("No profiles configured. Run 'veris login' to create one.")
        return

    for name in profiles:
        marker = " (active)" if name == active else ""
        output.print_info(f"  {name}{marker}")


@profile.command(name="show")
@click.pass_context
def profile_show(ctx):
    """Show active profile's settings."""
    profile_name = _get_profile(ctx)
    config = Config(profile=profile_name)
    project_config = ProjectConfig(profile=profile_name)

    output.print_info(f"Profile: {config.profile}")

    global_data = config._load_profile()
    if global_data:
        output.print_info("\nGlobal settings (~/.veris/config.yaml):")
        for k, v in global_data.items():
            display_v = v
            if k == "api_key" and v:
                display_v = v[:8] + "..." if len(v) > 8 else v
            output.print_info(f"  {k}: {display_v}")
    else:
        output.print_info("\nNo global settings for this profile.")

    project_data = project_config._load_profile()
    if project_data:
        output.print_info("\nProject settings (.veris/config.yaml):")
        for k, v in project_data.items():
            output.print_info(f"  {k}: {v}")


@profile.command(name="use")
@click.argument("name")
def profile_use(name: str):
    """Set active profile in global config."""
    config = Config()
    profiles = config.list_profiles()

    if profiles and name not in profiles:
        output.print_error(f"Profile '{name}' does not exist.")
        output.print_info(f"Available profiles: {', '.join(profiles)}")
        sys.exit(1)

    config.set_active_profile(name)
    output.print_success(f"Active profile set to '{name}'")


@profile.command(name="delete")
@click.argument("name")
def profile_delete(name: str):
    """Remove a profile from global config."""
    if name == "default":
        output.print_error("Cannot delete the default profile.")
        sys.exit(1)

    config = Config()
    if config.delete_profile(name):
        output.print_success(f"Profile '{name}' deleted")
    else:
        output.print_error(f"Profile '{name}' not found")
        sys.exit(1)


def _load_dotenv(path: Path) -> dict[str, str]:
    """Parse and return environment variables from a .env file."""
    env = {}
    if not path.exists():
        return env

    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            # Strip quotes from value
            v = v.strip().strip('"').strip("'")
            env[k.strip()] = v
    return env


def _resolve_scenarios(scenarios_dir: Path, scenario_args: tuple[str, ...]) -> list[str]:
    """Resolve scenario IDs from arguments or by scanning scenarios directory.

    Returns a list of scenario IDs (e.g., ['checkout', 'payment']).
    """
    # If specific scenarios are provided, use them as-is
    if scenario_args:
        return list(scenario_args)

    # Otherwise, scan the scenarios directory
    if not scenarios_dir.exists():
        # Fallback to default scenario
        return ["customer_browse_and_purchase"]

    scenarios = []

    for entry in sorted(scenarios_dir.iterdir()):
        if entry.is_file():
            # Strip extension to get scenario ID
            # e.g., checkout.yaml -> checkout
            stem = entry.stem
            if stem and not stem.startswith("."):
                scenarios.append(stem)
        elif entry.is_dir():
            # Use directory name as scenario ID
            # e.g., checkout/ -> checkout
            if not entry.name.startswith("."):
                scenarios.append(entry.name)

    # If no scenarios found, use default
    if not scenarios:
        scenarios = ["customer_browse_and_purchase"]

    return scenarios


def _resolve_env_simulation_path(veris_dir: Path, profile_name: str) -> Path:
    """Resolve .env.simulation file path based on profile.

    Default profile -> .veris/.env.simulation
    Named profile -> .veris/.env.simulation.<profile> (falls back to default)
    """
    if profile_name == "default":
        return veris_dir / ".env.simulation"

    profile_path = veris_dir / f".env.simulation.{profile_name}"
    if profile_path.exists():
        return profile_path

    default_path = veris_dir / ".env.simulation"
    if default_path.exists():
        output.print_info(
            f"No .env.simulation.{profile_name} found, falling back to .env.simulation"
        )
    return default_path


@run.command(name="local")
@click.argument("scenarios", nargs=-1)
@click.option("--skip-build", is_flag=True, help="Skip building the Docker image")
@click.option("--image", default="veris-sandbox", help="Docker image name (default: veris-sandbox)")
@click.option("--platform", default="linux/amd64", help="Docker platform (default: linux/amd64)")
@click.option(
    "--scenarios-dir", default="./scenarios", help="Path to scenarios folder (default: ./scenarios)"
)
@click.option(
    "--concurrency", default=None, type=int, help="Max parallel containers (default: unbounded)"
)
@click.pass_context
def run_local(
    ctx,
    scenarios: tuple[str, ...],
    skip_build: bool,
    image: str,
    platform: str,
    scenarios_dir: str,
    concurrency: int | None,
):
    """Run scenarios locally in Docker containers.

    Examples:
      veris run local                                     # run all scenarios in ./scenarios/
      veris run local checkout payment                    # run two specific scenarios in parallel
      veris run local --scenarios-dir ./tests/scenarios   # custom folder
      veris run local checkout --skip-build               # skip Docker build step
    """
    profile = _get_profile(ctx)
    config = Config(profile=profile)
    resolved_profile = config.profile

    project_root = Path.cwd()
    veris_dir = project_root / ".veris"
    dockerfile = veris_dir / "Dockerfile.sandbox"
    veris_yaml = veris_dir / "veris.yaml"
    scenarios_path = project_root / scenarios_dir

    # 1. Validate prerequisites
    if not dockerfile.exists():
        output.print_error(".veris/Dockerfile.sandbox not found. Run 'veris init' first.")
        sys.exit(1)

    if not veris_yaml.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris init' first.")
        sys.exit(1)

    # 2. Load env files: .veris/.env.simulation (infra) then .env (agent, takes precedence)
    env_sim_path = _resolve_env_simulation_path(veris_dir, resolved_profile)
    env_vars = _load_dotenv(env_sim_path)
    env_vars.update(_load_dotenv(project_root / ".env"))

    # Merge into os.environ for subprocess
    for k, v in env_vars.items():
        os.environ.setdefault(k, v)

    # 3. Resolve scenario list
    scenario_list = _resolve_scenarios(scenarios_path, scenarios)

    output.print_info(f"Running {len(scenario_list)} scenario(s): {', '.join(scenario_list)}")

    # 4. Build image once (unless --skip-build)
    if not skip_build:
        output.print_info(f"\nBuilding Docker image: {image}")
        build_cmd = [
            "docker",
            "buildx",
            "build",
            "--platform",
            platform,
            "--load",
            "-f",
            str(dockerfile),
            "-t",
            image,
            str(project_root),
        ]

        result = subprocess.run(build_cmd)
        if result.returncode != 0:
            output.print_error("Docker build failed")
            sys.exit(result.returncode)

        output.print_success("Docker image built successfully\n")
    else:
        output.print_info("Skipping Docker build\n")

    # 5. Launch containers in parallel
    run_id = secrets.token_hex(4)
    run_dir = veris_dir / "logs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    runs = []  # List of (scenario, sim_id, process, logs_dir) tuples

    # Helper to launch a single container
    def launch_container(scenario_id: str):
        sim_id = secrets.token_hex(4)
        logs_dir = run_dir / sim_id
        logs_dir.mkdir(parents=True, exist_ok=True)

        container_name = f"veris-sim-{sim_id}"

        # Build docker run command
        docker_cmd = [
            "docker",
            "run",
            "--rm",
            "--name",
            container_name,
            "--platform",
            platform,
        ]

        # Pass all environment variables from .env file
        for key, value in env_vars.items():
            docker_cmd.extend(["-e", f"{key}={value}"])

        # Add SCENARIO_ID
        docker_cmd.extend(["-e", f"SCENARIO_ID={scenario_id}"])

        # Add volume mounts
        docker_cmd.extend(
            [
                "-v",
                f"{veris_yaml}:/config/veris.yaml:ro",
                "-v",
                f"{logs_dir}:/sessions",
            ]
        )

        # Mount scenarios directory if it exists
        if scenarios_path.exists():
            docker_cmd.extend(["-v", f"{scenarios_path}:/scenarios:ro"])

        docker_cmd.append(image)

        # Launch non-blocking
        process = subprocess.Popen(docker_cmd)

        return (scenario_id, sim_id, process, logs_dir)

    # Launch all containers (with concurrency limit if specified)
    if concurrency:
        # Launch in batches
        for i in range(0, len(scenario_list), concurrency):
            batch = scenario_list[i : i + concurrency]
            batch_runs = [launch_container(s) for s in batch]
            runs.extend(batch_runs)

            # Wait for this batch to complete before starting next
            for _, _, proc, _ in batch_runs:
                proc.wait()
    else:
        # Launch all at once
        runs = [launch_container(s) for s in scenario_list]

    output.print_info(f"Run ID: {run_id}")
    output.print_info(f"Launched {len(runs)} container(s)\n")

    # 6. Wait for all to complete (if not already waited due to concurrency)
    if not concurrency:
        for scenario_id, sim_id, proc, _ in runs:
            output.print_info(f"Waiting for {scenario_id} (sim_id: {sim_id})...")
            proc.wait()

    # 7. Collect exit codes and print summary
    output.print_info("\n" + "=" * 60)
    output.print_success("All containers finished\n")

    # Print summary table
    print(f"{'Scenario':<30} {'Sim ID':<12} {'Exit Code':<12} {'Logs Path'}")
    print("-" * 100)

    for scenario_id, sim_id, proc, logs_dir in runs:
        exit_code = proc.returncode if proc.returncode is not None else proc.poll()
        logs_path = logs_dir.relative_to(project_root)
        print(f"{scenario_id:<30} {sim_id:<12} {exit_code:<12} {logs_path}")

    # 8. Dump logs
    output.print_info("\n" + "=" * 60)
    output.print_info("Logs:\n")

    for scenario_id, sim_id, _, logs_dir in runs:
        output.print_info(f"--- {scenario_id} (sim_id: {sim_id}) ---")

        # Find all .log files recursively
        log_files = sorted(logs_dir.glob("**/*.log"))

        if not log_files:
            output.print_info("  (no log files found)\n")
            continue

        for log_file in log_files:
            log_name = log_file.relative_to(logs_dir)
            output.print_info(f"\n  [{log_name}]")
            try:
                content = log_file.read_text()
                # Indent each line for better readability
                for line in content.splitlines():
                    print(f"    {line}")
            except Exception as e:
                output.print_error(f"    Failed to read log: {e}")

        print()


def main():
    """Main entry point"""
    cli()


if __name__ == "__main__":
    main()
