"""Configuration management for Veris CLI."""

from pathlib import Path
from typing import Optional

import yaml


DEFAULT_PROFILE = "default"


def _extract_profile(raw: dict, profile_name: str) -> dict:
    """Extract a profile's data from raw YAML, handling both flat and profiled formats.

    If raw has a 'profiles' key, returns data for the given profile.
    If raw is flat (legacy), treats entire dict as the 'default' profile.
    """
    if "profiles" in raw:
        return dict(raw["profiles"].get(profile_name, {}))
    # Legacy flat format — only the default profile has data
    if profile_name == DEFAULT_PROFILE:
        return {k: v for k, v in raw.items() if k != "active_profile"}
    return {}


def _migrate_if_needed(raw: dict) -> dict:
    """Wrap flat config into profiled format if not already migrated."""
    if "profiles" in raw:
        return raw
    active = raw.pop("active_profile", None)
    migrated: dict = {"profiles": {DEFAULT_PROFILE: raw}}
    if active:
        migrated["active_profile"] = active
    return migrated


class Config:
    """Manages CLI configuration stored in ~/.veris/config.yaml"""

    def __init__(self, profile: Optional[str] = None):
        self.config_dir = Path.home() / ".veris"
        self.config_file = self.config_dir / "config.yaml"
        self._explicit_profile = profile

    @property
    def profile(self) -> str:
        """Resolved profile name: explicit > active_profile > 'default'."""
        if self._explicit_profile:
            return self._explicit_profile
        return self.get_active_profile() or DEFAULT_PROFILE

    def load(self) -> dict:
        """Load raw configuration from ~/.veris/config.yaml"""
        if not self.config_file.exists():
            return {}

        with open(self.config_file, "r") as f:
            return yaml.safe_load(f) or {}

    def save(self, config: dict) -> None:
        """Save raw configuration to ~/.veris/config.yaml"""
        self.config_dir.mkdir(parents=True, exist_ok=True)

        with open(self.config_file, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)

    def _load_profile(self) -> dict:
        """Load the active profile's data."""
        raw = self.load()
        return _extract_profile(raw, self.profile)

    def _save_profile(self, data: dict) -> None:
        """Save data under the active profile, migrating flat format if needed."""
        raw = self.load()
        raw = _migrate_if_needed(raw)
        raw.setdefault("profiles", {})[self.profile] = data
        self.save(raw)

    def get_api_key(self) -> Optional[str]:
        """Get API key from config"""
        return self._load_profile().get("api_key")

    def get_backend_url(self) -> str:
        """Get backend URL from config, defaults to prod"""
        return (
            self._load_profile()
            .get("backend_url", "https://sandbox.api.veris.ai")
            .strip()
            .rstrip("/")
        )

    def set_api_key(self, api_key: str, backend_url: str = "https://sandbox.api.veris.ai") -> None:
        """Set API key and backend URL in config"""
        profile_data = self._load_profile()
        profile_data["api_key"] = api_key
        profile_data["backend_url"] = backend_url
        self._save_profile(profile_data)

    def get_active_profile(self) -> Optional[str]:
        """Read active_profile from global config file."""
        raw = self.load()
        return raw.get("active_profile")

    def set_active_profile(self, name: str) -> None:
        """Write active_profile to global config file."""
        raw = self.load()
        raw = _migrate_if_needed(raw)
        raw["active_profile"] = name
        self.save(raw)

    def list_profiles(self) -> list[str]:
        """Return list of profile names from global config."""
        raw = self.load()
        if "profiles" in raw:
            return list(raw["profiles"].keys())
        # Legacy flat — only default exists
        if raw:
            return [DEFAULT_PROFILE]
        return []

    def delete_profile(self, name: str) -> bool:
        """Remove a profile from global config. Returns True if deleted."""
        raw = self.load()
        raw = _migrate_if_needed(raw)
        profiles = raw.get("profiles", {})
        if name not in profiles:
            return False
        del profiles[name]
        # If the active profile was deleted, clear it
        if raw.get("active_profile") == name:
            raw.pop("active_profile", None)
        self.save(raw)
        return True


class ProjectConfig:
    """Manages project-level configuration stored in .veris/config.yaml"""

    def __init__(self, project_dir: Optional[Path] = None, profile: Optional[str] = None):
        self.project_dir = project_dir or Path.cwd()
        self.veris_dir = self.project_dir / ".veris"
        self.config_file = self.veris_dir / "config.yaml"
        self._explicit_profile = profile

    @property
    def profile(self) -> str:
        """Resolved profile name: explicit > global active_profile > 'default'."""
        if self._explicit_profile:
            return self._explicit_profile
        # Read active_profile from the global config (not project config)
        return Config().get_active_profile() or DEFAULT_PROFILE

    def load(self) -> dict:
        """Load raw project configuration from .veris/config.yaml"""
        if not self.config_file.exists():
            return {}

        with open(self.config_file, "r") as f:
            return yaml.safe_load(f) or {}

    def save(self, config: dict) -> None:
        """Save raw project configuration to .veris/config.yaml"""
        self.veris_dir.mkdir(parents=True, exist_ok=True)

        with open(self.config_file, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False)

    def _load_profile(self) -> dict:
        """Load the active profile's data."""
        raw = self.load()
        return _extract_profile(raw, self.profile)

    def _save_profile(self, data: dict) -> None:
        """Save data under the active profile, migrating flat format if needed."""
        raw = self.load()
        raw = _migrate_if_needed(raw)
        raw.setdefault("profiles", {})[self.profile] = data
        self.save(raw)

    def get_environment_id(self) -> Optional[str]:
        """Get environment ID from project config"""
        return self._load_profile().get("environment_id")

    def set_environment_id(self, environment_id: str, environment_name: str) -> None:
        """Set environment ID in project config"""
        profile_data = self._load_profile()
        profile_data["environment_id"] = environment_id
        profile_data["environment_name"] = environment_name
        self._save_profile(profile_data)
