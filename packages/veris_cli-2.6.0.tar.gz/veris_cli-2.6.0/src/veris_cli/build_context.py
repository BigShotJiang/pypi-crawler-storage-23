"""Build context tarball creation for `veris env push`.

Packages the project root into a .tar.gz, respecting .dockerignore patterns.
"""

import os
import tarfile
import tempfile
from pathlib import Path

import pathspec

# 500 MB size cap
MAX_TARBALL_SIZE = 500 * 1024 * 1024


def _load_dockerignore(project_root: Path) -> pathspec.PathSpec:
    """Load .dockerignore patterns from project root (if present)."""
    dockerignore = project_root / ".dockerignore"
    if dockerignore.exists():
        patterns = dockerignore.read_text().splitlines()
    else:
        patterns = []
    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)


def create_build_context(
    project_root: Path,
    output_path: Path | None = None,
) -> tuple[Path, int]:
    """Create a tar.gz build context from the project root.

    Respects .dockerignore at the project root (if present).
    Always includes .veris/Dockerfile.sandbox even if matched by ignore.
    Always excludes .git/ regardless of .dockerignore.

    Args:
        project_root: Root directory to package.
        output_path: Where to write the tarball. If None, uses a tempfile.

    Returns:
        Tuple of (tarball_path, size_bytes).

    Raises:
        ValueError: If tarball exceeds the size cap or Dockerfile.sandbox is missing.
    """
    spec = _load_dockerignore(project_root)

    if output_path is None:
        fd, tmp = tempfile.mkstemp(suffix=".tar.gz", prefix="veris-build-")
        os.close(fd)
        output_path = Path(tmp)

    dockerfile = project_root / ".veris" / "Dockerfile.sandbox"
    if not dockerfile.exists():
        raise ValueError(".veris/Dockerfile.sandbox not found")

    file_count = 0
    dockerfile_rel = os.path.join(".veris", "Dockerfile.sandbox")
    dockerfile_added = False

    with tarfile.open(output_path, "w:gz") as tar:
        for root, dirs, files in os.walk(project_root):
            # Always skip .git directory
            if ".git" in dirs:
                dirs.remove(".git")

            rel_root = Path(root).relative_to(project_root)

            # Filter out ignored directories in-place to avoid descending
            dirs[:] = [
                d
                for d in dirs
                if not spec.match_file(str(rel_root / d) + "/")
                and not spec.match_file(str(rel_root / d))
            ]

            for f in files:
                rel_path = str(rel_root / f)
                if rel_path == ".":
                    rel_path = f

                # Skip ignored files (but always include .veris/Dockerfile.sandbox)
                if spec.match_file(rel_path) and rel_path != dockerfile_rel:
                    continue

                full_path = Path(root) / f
                tar.add(str(full_path), arcname=rel_path)
                file_count += 1
                if rel_path == dockerfile_rel:
                    dockerfile_added = True

        # If the Dockerfile wasn't added (e.g. .veris/ dir was ignored), add it explicitly
        if not dockerfile_added:
            tar.add(str(dockerfile), arcname=dockerfile_rel)
            file_count += 1

    size = output_path.stat().st_size
    if size > MAX_TARBALL_SIZE:
        output_path.unlink()
        raise ValueError(
            f"Build context is {size / 1024 / 1024:.1f} MB, "
            f"exceeding the {MAX_TARBALL_SIZE / 1024 / 1024:.0f} MB limit. "
            "Add large directories to .dockerignore."
        )

    return output_path, size
