"""Interactive prompts using questionary."""

from typing import Any, Optional

import questionary


def select_scenario(scenarios: list[dict[str, Any]]) -> Optional[str]:
    """Interactive scenario selection."""
    if not scenarios:
        return None

    choices = [
        questionary.Choice(
            title=f"{s.get('title', '')} ({s.get('id', '')})",
            value=s.get("id", ""),
        )
        for s in scenarios
    ]

    answer = questionary.select(
        "Select a scenario:",
        choices=choices,
    ).ask()

    return answer


def select_environment(environments: list[dict[str, Any]]) -> Optional[str]:
    """Interactive environment selection."""
    if not environments:
        return None

    choices = [
        questionary.Choice(
            title=f"{e.get('name', '')} ({e.get('id', '')})",
            value=e.get("id", ""),
        )
        for e in environments
    ]

    return questionary.select(
        "Choose environment:",
        choices=choices,
    ).ask()


def prompt_concurrency(default: int = 5) -> int:
    """Prompt for concurrency value."""
    answer = questionary.text(
        "Concurrency (parallel runs):",
        default=str(default),
        validate=lambda x: x.isdigit() and int(x) > 0,
    ).ask()

    return int(answer) if answer else default


def confirm_action(message: str, default: bool = False) -> bool:
    """Confirm a destructive action."""
    return questionary.confirm(message, default=default).ask()


def prompt_environment_name() -> Optional[str]:
    """Prompt for environment name."""
    answer = questionary.text(
        "Environment name:",
        validate=lambda x: len(x) > 0 or "Name cannot be empty",
    ).ask()

    return answer


def select_from_list(prompt: str, items: list[dict[str, Any]]) -> Optional[str]:
    """Generic interactive selection from a list of {id, title} dicts."""
    if not items:
        return None

    choices = [
        questionary.Choice(title=item.get("title", item.get("id", "")), value=item.get("id", ""))
        for item in items
    ]

    return questionary.select(prompt, choices=choices).ask()
