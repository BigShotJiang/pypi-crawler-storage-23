class TokenError(Exception):
    pass
