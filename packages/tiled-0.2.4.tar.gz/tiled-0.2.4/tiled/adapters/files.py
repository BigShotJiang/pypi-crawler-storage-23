raise Exception(
    """The way that tiled serves files has changed.

See documentation section "Serve a Directory of Files".
"""
)
