import hashlib
from typing import Tuple
from google.cloud import storage # type: ignore
from .protocols import BlobStore

class GCSBlobStore(BlobStore):
    def __init__(self, bucket_name: str, project_id: str | None = None):
        """
        Args:
            bucket_name: Name of the GCS bucket
            project_id: Optional GCP project ID
        """
        self.bucket_name = bucket_name
        self.client = storage.Client(project=project_id)
        self.bucket = self.client.bucket(bucket_name)

    def put(self, *, path_hint: str, content_type: str, data: bytes) -> Tuple[str, int, str]:
        """
        Stores data to GCS.

        Args:
            path_hint: Suggested key/path in the bucket.
            content_type: MIME type of the content.
            data: The bytes to store.

        Returns:
            (payload_ref, size_bytes, sha256_hash)
        """
        size_bytes = len(data)
        sha256_hash = hashlib.sha256(data).hexdigest()
        
        # Create blob
        blob = self.bucket.blob(path_hint)
        
        # Upload with content type
        blob.upload_from_string(data, content_type=content_type)
        
        # Construct reference URI (gs://bucket/path)
        payload_ref = f"gs://{self.bucket_name}/{path_hint}"
        
        return payload_ref, size_bytes, sha256_hash
    def get(self, payload_ref: str) -> bytes:
        """
        Retrieves data from GCS.
        """
        if not payload_ref.startswith("gs://"):
             raise ValueError(f"Unsupported payload_ref: {payload_ref}")
        
        # gs://bucket/path
        parts = payload_ref[5:].split("/", 1)
        if len(parts) < 2:
            raise ValueError(f"Invalid GCS ref: {payload_ref}")
        
        bucket_name, path = parts
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(path)
        return blob.download_as_bytes()
