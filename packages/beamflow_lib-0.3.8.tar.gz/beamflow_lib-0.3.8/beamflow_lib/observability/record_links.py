from datetime import datetime, UTC
from typing import Optional
from .model import RecordLink, RecordLinkKind

# This file can contain additional logic for RecordLink processing if needed.
# The primary ingestion is handled in ingestion.py for consistency with other events.
